/*     */ package org.springframework.web.servlet.mvc.method.annotation;
/*     */ 
/*     */ import java.lang.reflect.AnnotatedElement;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Parameter;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.function.Predicate;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.springframework.context.EmbeddedValueResolverAware;
/*     */ import org.springframework.core.annotation.AnnotatedElementUtils;
/*     */ import org.springframework.core.annotation.MergedAnnotation;
/*     */ import org.springframework.core.annotation.MergedAnnotations;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.stereotype.Controller;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.StringValueResolver;
/*     */ import org.springframework.web.accept.ContentNegotiationManager;
/*     */ import org.springframework.web.bind.annotation.CrossOrigin;
/*     */ import org.springframework.web.bind.annotation.RequestBody;
/*     */ import org.springframework.web.bind.annotation.RequestMapping;
/*     */ import org.springframework.web.bind.annotation.RequestMethod;
/*     */ import org.springframework.web.cors.CorsConfiguration;
/*     */ import org.springframework.web.method.HandlerMethod;
/*     */ import org.springframework.web.servlet.handler.MatchableHandlerMapping;
/*     */ import org.springframework.web.servlet.handler.RequestMatchResult;
/*     */ import org.springframework.web.servlet.mvc.condition.ConsumesRequestCondition;
/*     */ import org.springframework.web.servlet.mvc.condition.PatternsRequestCondition;
/*     */ import org.springframework.web.servlet.mvc.condition.RequestCondition;
/*     */ import org.springframework.web.servlet.mvc.condition.RequestMethodsRequestCondition;
/*     */ import org.springframework.web.servlet.mvc.method.RequestMappingInfo;
/*     */ import org.springframework.web.servlet.mvc.method.RequestMappingInfo.Builder;
/*     */ import org.springframework.web.servlet.mvc.method.RequestMappingInfo.BuilderConfiguration;
/*     */ import org.springframework.web.servlet.mvc.method.RequestMappingInfoHandlerMapping;
/*     */ import org.springframework.web.util.UrlPathHelper;
/*     */ import org.springframework.web.util.pattern.PathPatternParser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RequestMappingHandlerMapping
/*     */   extends RequestMappingInfoHandlerMapping
/*     */   implements MatchableHandlerMapping, EmbeddedValueResolverAware
/*     */ {
/*  79 */   private boolean useSuffixPatternMatch = false;
/*     */   
/*  81 */   private boolean useRegisteredSuffixPatternMatch = false;
/*     */   
/*  83 */   private boolean useTrailingSlashMatch = true;
/*     */   
/*  85 */   private Map<String, Predicate<Class<?>>> pathPrefixes = Collections.emptyMap();
/*     */   
/*  87 */   private ContentNegotiationManager contentNegotiationManager = new ContentNegotiationManager();
/*     */   
/*     */   @Nullable
/*     */   private StringValueResolver embeddedValueResolver;
/*     */   
/*  92 */   private RequestMappingInfo.BuilderConfiguration config = new RequestMappingInfo.BuilderConfiguration();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public void setUseSuffixPatternMatch(boolean useSuffixPatternMatch)
/*     */   {
/* 110 */     this.useSuffixPatternMatch = useSuffixPatternMatch;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public void setUseRegisteredSuffixPatternMatch(boolean useRegisteredSuffixPatternMatch)
/*     */   {
/* 126 */     this.useRegisteredSuffixPatternMatch = useRegisteredSuffixPatternMatch;
/* 127 */     this.useSuffixPatternMatch = ((useRegisteredSuffixPatternMatch) || (this.useSuffixPatternMatch));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUseTrailingSlashMatch(boolean useTrailingSlashMatch)
/*     */   {
/* 136 */     this.useTrailingSlashMatch = useTrailingSlashMatch;
/* 137 */     if (getPatternParser() != null) {
/* 138 */       getPatternParser().setMatchOptionalTrailingSeparator(useTrailingSlashMatch);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPathPrefixes(Map<String, Predicate<Class<?>>> prefixes)
/*     */   {
/* 155 */     this.pathPrefixes = (!prefixes.isEmpty() ? Collections.unmodifiableMap(new LinkedHashMap(prefixes)) : Collections.emptyMap());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<String, Predicate<Class<?>>> getPathPrefixes()
/*     */   {
/* 163 */     return this.pathPrefixes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setContentNegotiationManager(ContentNegotiationManager contentNegotiationManager)
/*     */   {
/* 171 */     Assert.notNull(contentNegotiationManager, "ContentNegotiationManager must not be null");
/* 172 */     this.contentNegotiationManager = contentNegotiationManager;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ContentNegotiationManager getContentNegotiationManager()
/*     */   {
/* 179 */     return this.contentNegotiationManager;
/*     */   }
/*     */   
/*     */   public void setEmbeddedValueResolver(StringValueResolver resolver)
/*     */   {
/* 184 */     this.embeddedValueResolver = resolver;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/* 191 */     this.config = new RequestMappingInfo.BuilderConfiguration();
/* 192 */     this.config.setTrailingSlashMatch(useTrailingSlashMatch());
/* 193 */     this.config.setContentNegotiationManager(getContentNegotiationManager());
/*     */     
/* 195 */     if (getPatternParser() != null) {
/* 196 */       this.config.setPatternParser(getPatternParser());
/* 197 */       Assert.isTrue((!this.useSuffixPatternMatch) && (!this.useRegisteredSuffixPatternMatch), "Suffix pattern matching not supported with PathPatternParser.");
/*     */     }
/*     */     else
/*     */     {
/* 201 */       this.config.setSuffixPatternMatch(useSuffixPatternMatch());
/* 202 */       this.config.setRegisteredSuffixPatternMatch(useRegisteredSuffixPatternMatch());
/* 203 */       this.config.setPathMatcher(getPathMatcher());
/*     */     }
/*     */     
/* 206 */     super.afterPropertiesSet();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public boolean useSuffixPatternMatch()
/*     */   {
/* 217 */     return this.useSuffixPatternMatch;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public boolean useRegisteredSuffixPatternMatch()
/*     */   {
/* 227 */     return this.useRegisteredSuffixPatternMatch;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean useTrailingSlashMatch()
/*     */   {
/* 234 */     return this.useTrailingSlashMatch;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   @Deprecated
/*     */   public List<String> getFileExtensions()
/*     */   {
/* 246 */     return this.config.getFileExtensions();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isHandler(Class<?> beanType)
/*     */   {
/* 257 */     return (AnnotatedElementUtils.hasAnnotation(beanType, Controller.class)) || 
/* 258 */       (AnnotatedElementUtils.hasAnnotation(beanType, RequestMapping.class));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected RequestMappingInfo getMappingForMethod(Method method, Class<?> handlerType)
/*     */   {
/* 272 */     RequestMappingInfo info = createRequestMappingInfo(method);
/* 273 */     if (info != null) {
/* 274 */       RequestMappingInfo typeInfo = createRequestMappingInfo(handlerType);
/* 275 */       if (typeInfo != null) {
/* 276 */         info = typeInfo.combine(info);
/*     */       }
/* 278 */       String prefix = getPathPrefix(handlerType);
/* 279 */       if (prefix != null) {
/* 280 */         info = RequestMappingInfo.paths(new String[] { prefix }).options(this.config).build().combine(info);
/*     */       }
/*     */     }
/* 283 */     return info;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   String getPathPrefix(Class<?> handlerType) {
/* 288 */     for (Map.Entry<String, Predicate<Class<?>>> entry : this.pathPrefixes.entrySet()) {
/* 289 */       if (((Predicate)entry.getValue()).test(handlerType)) {
/* 290 */         String prefix = (String)entry.getKey();
/* 291 */         if (this.embeddedValueResolver != null) {
/* 292 */           prefix = this.embeddedValueResolver.resolveStringValue(prefix);
/*     */         }
/* 294 */         return prefix;
/*     */       }
/*     */     }
/* 297 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   private RequestMappingInfo createRequestMappingInfo(AnnotatedElement element)
/*     */   {
/* 309 */     RequestMapping requestMapping = (RequestMapping)AnnotatedElementUtils.findMergedAnnotation(element, RequestMapping.class);
/*     */     
/* 311 */     RequestCondition<?> condition = (element instanceof Class) ? getCustomTypeCondition((Class)element) : getCustomMethodCondition((Method)element);
/* 312 */     return requestMapping != null ? createRequestMappingInfo(requestMapping, condition) : null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected RequestCondition<?> getCustomTypeCondition(Class<?> handlerType)
/*     */   {
/* 328 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected RequestCondition<?> getCustomMethodCondition(Method method)
/*     */   {
/* 344 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected RequestMappingInfo createRequestMappingInfo(RequestMapping requestMapping, @Nullable RequestCondition<?> customCondition)
/*     */   {
/* 363 */     RequestMappingInfo.Builder builder = RequestMappingInfo.paths(resolveEmbeddedValuesInPatterns(requestMapping.path())).methods(requestMapping.method()).params(requestMapping.params()).headers(requestMapping.headers()).consumes(requestMapping.consumes()).produces(requestMapping.produces()).mappingName(requestMapping.name());
/* 364 */     if (customCondition != null) {
/* 365 */       builder.customCondition(customCondition);
/*     */     }
/* 367 */     return builder.options(this.config).build();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String[] resolveEmbeddedValuesInPatterns(String[] patterns)
/*     */   {
/* 375 */     if (this.embeddedValueResolver == null) {
/* 376 */       return patterns;
/*     */     }
/*     */     
/* 379 */     String[] resolvedPatterns = new String[patterns.length];
/* 380 */     for (int i = 0; i < patterns.length; i++) {
/* 381 */       resolvedPatterns[i] = this.embeddedValueResolver.resolveStringValue(patterns[i]);
/*     */     }
/* 383 */     return resolvedPatterns;
/*     */   }
/*     */   
/*     */ 
/*     */   public void registerMapping(RequestMappingInfo mapping, Object handler, Method method)
/*     */   {
/* 389 */     super.registerMapping(mapping, handler, method);
/* 390 */     updateConsumesCondition(mapping, method);
/*     */   }
/*     */   
/*     */   protected void registerHandlerMethod(Object handler, Method method, RequestMappingInfo mapping)
/*     */   {
/* 395 */     super.registerHandlerMethod(handler, method, mapping);
/* 396 */     updateConsumesCondition(mapping, method);
/*     */   }
/*     */   
/*     */   private void updateConsumesCondition(RequestMappingInfo info, Method method) {
/* 400 */     ConsumesRequestCondition condition = info.getConsumesCondition();
/* 401 */     if (!condition.isEmpty()) {
/* 402 */       for (Parameter parameter : method.getParameters()) {
/* 403 */         MergedAnnotation<RequestBody> annot = MergedAnnotations.from(parameter).get(RequestBody.class);
/* 404 */         if (annot.isPresent()) {
/* 405 */           condition.setBodyRequired(annot.getBoolean("required"));
/* 406 */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public RequestMatchResult match(HttpServletRequest request, String pattern)
/*     */   {
/* 414 */     Assert.isNull(getPatternParser(), "This HandlerMapping requires a PathPattern");
/* 415 */     RequestMappingInfo info = RequestMappingInfo.paths(new String[] { pattern }).options(this.config).build();
/* 416 */     RequestMappingInfo match = info.getMatchingCondition(request);
/* 417 */     return (match != null) && (match.getPatternsCondition() != null) ? new RequestMatchResult(
/*     */     
/* 419 */       (String)match.getPatternsCondition().getPatterns().iterator().next(), 
/* 420 */       UrlPathHelper.getResolvedLookupPath(request), 
/* 421 */       getPathMatcher()) : null;
/*     */   }
/*     */   
/*     */   protected CorsConfiguration initCorsConfiguration(Object handler, Method method, RequestMappingInfo mappingInfo)
/*     */   {
/* 426 */     HandlerMethod handlerMethod = createHandlerMethod(handler, method);
/* 427 */     Class<?> beanType = handlerMethod.getBeanType();
/* 428 */     CrossOrigin typeAnnotation = (CrossOrigin)AnnotatedElementUtils.findMergedAnnotation(beanType, CrossOrigin.class);
/* 429 */     CrossOrigin methodAnnotation = (CrossOrigin)AnnotatedElementUtils.findMergedAnnotation(method, CrossOrigin.class);
/*     */     
/* 431 */     if ((typeAnnotation == null) && (methodAnnotation == null)) {
/* 432 */       return null;
/*     */     }
/*     */     
/* 435 */     CorsConfiguration config = new CorsConfiguration();
/* 436 */     updateCorsConfig(config, typeAnnotation);
/* 437 */     updateCorsConfig(config, methodAnnotation);
/*     */     
/* 439 */     if (CollectionUtils.isEmpty(config.getAllowedMethods())) {
/* 440 */       for (RequestMethod allowedMethod : mappingInfo.getMethodsCondition().getMethods()) {
/* 441 */         config.addAllowedMethod(allowedMethod.name());
/*     */       }
/*     */     }
/* 444 */     return config.applyPermitDefaultValues();
/*     */   }
/*     */   
/*     */   private void updateCorsConfig(CorsConfiguration config, @Nullable CrossOrigin annotation) {
/* 448 */     if (annotation == null) {
/* 449 */       return;
/*     */     }
/* 451 */     for (String origin : annotation.origins()) {
/* 452 */       config.addAllowedOrigin(resolveCorsAnnotationValue(origin));
/*     */     }
/* 454 */     for (String patterns : annotation.originPatterns()) {
/* 455 */       config.addAllowedOriginPattern(resolveCorsAnnotationValue(patterns));
/*     */     }
/* 457 */     for (RequestMethod method : annotation.methods()) {
/* 458 */       config.addAllowedMethod(method.name());
/*     */     }
/* 460 */     for (String header : annotation.allowedHeaders()) {
/* 461 */       config.addAllowedHeader(resolveCorsAnnotationValue(header));
/*     */     }
/* 463 */     for (String header : annotation.exposedHeaders()) {
/* 464 */       config.addExposedHeader(resolveCorsAnnotationValue(header));
/*     */     }
/*     */     
/* 467 */     String allowCredentials = resolveCorsAnnotationValue(annotation.allowCredentials());
/* 468 */     if ("true".equalsIgnoreCase(allowCredentials)) {
/* 469 */       config.setAllowCredentials(Boolean.valueOf(true));
/*     */     }
/* 471 */     else if ("false".equalsIgnoreCase(allowCredentials)) {
/* 472 */       config.setAllowCredentials(Boolean.valueOf(false));
/*     */     }
/* 474 */     else if (!allowCredentials.isEmpty()) {
/* 475 */       throw new IllegalStateException("@CrossOrigin's allowCredentials value must be \"true\", \"false\", or an empty string (\"\"): current value is [" + allowCredentials + "]");
/*     */     }
/*     */     
/*     */ 
/* 479 */     if (annotation.maxAge() >= 0L) {
/* 480 */       config.setMaxAge(Long.valueOf(annotation.maxAge()));
/*     */     }
/*     */   }
/*     */   
/*     */   private String resolveCorsAnnotationValue(String value) {
/* 485 */     if (this.embeddedValueResolver != null) {
/* 486 */       String resolved = this.embeddedValueResolver.resolveStringValue(value);
/* 487 */       return resolved != null ? resolved : "";
/*     */     }
/*     */     
/* 490 */     return value;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\mvc\method\annotation\RequestMappingHandlerMapping.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */