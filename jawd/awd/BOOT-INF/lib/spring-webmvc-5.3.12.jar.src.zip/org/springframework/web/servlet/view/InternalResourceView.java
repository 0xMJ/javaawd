/*     */ package org.springframework.web.servlet.view;
/*     */ 
/*     */ import java.util.Map;
/*     */ import javax.servlet.RequestDispatcher;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.util.WebUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InternalResourceView
/*     */   extends AbstractUrlBasedView
/*     */ {
/*  68 */   private boolean alwaysInclude = false;
/*     */   
/*  70 */   private boolean preventDispatchLoop = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public InternalResourceView() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public InternalResourceView(String url)
/*     */   {
/*  87 */     super(url);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public InternalResourceView(String url, boolean alwaysInclude)
/*     */   {
/*  96 */     super(url);
/*  97 */     this.alwaysInclude = alwaysInclude;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAlwaysInclude(boolean alwaysInclude)
/*     */   {
/* 110 */     this.alwaysInclude = alwaysInclude;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPreventDispatchLoop(boolean preventDispatchLoop)
/*     */   {
/* 121 */     this.preventDispatchLoop = preventDispatchLoop;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isContextRequired()
/*     */   {
/* 129 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void renderMergedOutputModel(Map<String, Object> model, HttpServletRequest request, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/* 142 */     exposeModelAsRequestAttributes(model, request);
/*     */     
/*     */ 
/* 145 */     exposeHelpers(request);
/*     */     
/*     */ 
/* 148 */     String dispatcherPath = prepareForRendering(request, response);
/*     */     
/*     */ 
/* 151 */     RequestDispatcher rd = getRequestDispatcher(request, dispatcherPath);
/* 152 */     if (rd == null) {
/* 153 */       throw new ServletException("Could not get RequestDispatcher for [" + getUrl() + "]: Check that the corresponding file exists within your web application archive!");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 158 */     if (useInclude(request, response)) {
/* 159 */       response.setContentType(getContentType());
/* 160 */       if (this.logger.isDebugEnabled()) {
/* 161 */         this.logger.debug("Including [" + getUrl() + "]");
/*     */       }
/* 163 */       rd.include(request, response);
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 168 */       if (this.logger.isDebugEnabled()) {
/* 169 */         this.logger.debug("Forwarding to [" + getUrl() + "]");
/*     */       }
/* 171 */       rd.forward(request, response);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void exposeHelpers(HttpServletRequest request)
/*     */     throws Exception
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String prepareForRendering(HttpServletRequest request, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/* 204 */     String path = getUrl();
/* 205 */     Assert.state(path != null, "'url' not set");
/*     */     
/* 207 */     if (this.preventDispatchLoop) {
/* 208 */       String uri = request.getRequestURI();
/* 209 */       if (path.startsWith("/") ? uri.equals(path) : uri.equals(StringUtils.applyRelativePath(uri, path))) {
/* 210 */         throw new ServletException("Circular view path [" + path + "]: would dispatch back to the current handler URL [" + uri + "] again. Check your ViewResolver setup! (Hint: This may be the result of an unspecified view, due to default view name generation.)");
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 215 */     return path;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected RequestDispatcher getRequestDispatcher(HttpServletRequest request, String path)
/*     */   {
/* 229 */     return request.getRequestDispatcher(path);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean useInclude(HttpServletRequest request, HttpServletResponse response)
/*     */   {
/* 247 */     return (this.alwaysInclude) || (WebUtils.isIncludeRequest(request)) || (response.isCommitted());
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\view\InternalResourceView.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */