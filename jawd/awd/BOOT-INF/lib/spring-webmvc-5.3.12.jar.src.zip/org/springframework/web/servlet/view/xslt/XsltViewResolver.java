/*     */ package org.springframework.web.servlet.view.xslt;
/*     */ 
/*     */ import java.util.Properties;
/*     */ import javax.xml.transform.ErrorListener;
/*     */ import javax.xml.transform.URIResolver;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.web.servlet.view.AbstractUrlBasedView;
/*     */ import org.springframework.web.servlet.view.UrlBasedViewResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XsltViewResolver
/*     */   extends UrlBasedViewResolver
/*     */ {
/*     */   @Nullable
/*     */   private String sourceKey;
/*     */   @Nullable
/*     */   private URIResolver uriResolver;
/*     */   @Nullable
/*     */   private ErrorListener errorListener;
/*  48 */   private boolean indent = true;
/*     */   
/*     */   @Nullable
/*     */   private Properties outputProperties;
/*     */   
/*  53 */   private boolean cacheTemplates = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public XsltViewResolver()
/*     */   {
/*  60 */     setViewClass(requiredViewClass());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSourceKey(String sourceKey)
/*     */   {
/*  73 */     this.sourceKey = sourceKey;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUriResolver(URIResolver uriResolver)
/*     */   {
/*  81 */     this.uriResolver = uriResolver;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setErrorListener(ErrorListener errorListener)
/*     */   {
/*  94 */     this.errorListener = errorListener;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setIndent(boolean indent)
/*     */   {
/* 105 */     this.indent = indent;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOutputProperties(Properties outputProperties)
/*     */   {
/* 115 */     this.outputProperties = outputProperties;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCacheTemplates(boolean cacheTemplates)
/*     */   {
/* 124 */     this.cacheTemplates = cacheTemplates;
/*     */   }
/*     */   
/*     */ 
/*     */   protected Class<?> requiredViewClass()
/*     */   {
/* 130 */     return XsltView.class;
/*     */   }
/*     */   
/*     */   protected AbstractUrlBasedView instantiateView()
/*     */   {
/* 135 */     return getViewClass() == XsltView.class ? new XsltView() : super.instantiateView();
/*     */   }
/*     */   
/*     */   protected AbstractUrlBasedView buildView(String viewName) throws Exception
/*     */   {
/* 140 */     XsltView view = (XsltView)super.buildView(viewName);
/* 141 */     if (this.sourceKey != null) {
/* 142 */       view.setSourceKey(this.sourceKey);
/*     */     }
/* 144 */     if (this.uriResolver != null) {
/* 145 */       view.setUriResolver(this.uriResolver);
/*     */     }
/* 147 */     if (this.errorListener != null) {
/* 148 */       view.setErrorListener(this.errorListener);
/*     */     }
/* 150 */     view.setIndent(this.indent);
/* 151 */     if (this.outputProperties != null) {
/* 152 */       view.setOutputProperties(this.outputProperties);
/*     */     }
/* 154 */     view.setCacheTemplates(this.cacheTemplates);
/* 155 */     return view;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\view\xslt\XsltViewResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */