/*     */ package org.springframework.web.servlet.support;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.http.CacheControl;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.HttpRequestMethodNotSupportedException;
/*     */ import org.springframework.web.HttpSessionRequiredException;
/*     */ import org.springframework.web.context.support.WebApplicationObjectSupport;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class WebContentGenerator
/*     */   extends WebApplicationObjectSupport
/*     */ {
/*     */   public static final String METHOD_GET = "GET";
/*     */   public static final String METHOD_HEAD = "HEAD";
/*     */   public static final String METHOD_POST = "POST";
/*     */   private static final String HEADER_PRAGMA = "Pragma";
/*     */   private static final String HEADER_EXPIRES = "Expires";
/*     */   protected static final String HEADER_CACHE_CONTROL = "Cache-Control";
/*     */   @Nullable
/*     */   private Set<String> supportedMethods;
/*     */   @Nullable
/*     */   private String allowHeader;
/*  92 */   private boolean requireSession = false;
/*     */   
/*     */   @Nullable
/*     */   private CacheControl cacheControl;
/*     */   
/*  97 */   private int cacheSeconds = -1;
/*     */   
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   private String[] varyByRequestHeaders;
/*     */   
/*     */ 
/*     */ 
/* 106 */   private boolean useExpiresHeader = false;
/*     */   
/*     */ 
/* 109 */   private boolean useCacheControlHeader = true;
/*     */   
/*     */ 
/* 112 */   private boolean useCacheControlNoStore = true;
/*     */   
/* 114 */   private boolean alwaysMustRevalidate = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WebContentGenerator()
/*     */   {
/* 122 */     this(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WebContentGenerator(boolean restrictDefaultSupportedMethods)
/*     */   {
/* 132 */     if (restrictDefaultSupportedMethods) {
/* 133 */       this.supportedMethods = new LinkedHashSet(4);
/* 134 */       this.supportedMethods.add("GET");
/* 135 */       this.supportedMethods.add("HEAD");
/* 136 */       this.supportedMethods.add("POST");
/*     */     }
/* 138 */     initAllowHeader();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public WebContentGenerator(String... supportedMethods)
/*     */   {
/* 146 */     setSupportedMethods(supportedMethods);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setSupportedMethods(@Nullable String... methods)
/*     */   {
/* 156 */     if (!ObjectUtils.isEmpty(methods)) {
/* 157 */       this.supportedMethods = new LinkedHashSet(Arrays.asList(methods));
/*     */     }
/*     */     else {
/* 160 */       this.supportedMethods = null;
/*     */     }
/* 162 */     initAllowHeader();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public final String[] getSupportedMethods()
/*     */   {
/* 170 */     return this.supportedMethods != null ? StringUtils.toStringArray(this.supportedMethods) : null;
/*     */   }
/*     */   
/*     */   private void initAllowHeader() {
/*     */     Collection<String> allowedMethods;
/* 175 */     if (this.supportedMethods == null) {
/* 176 */       Collection<String> allowedMethods = new ArrayList(HttpMethod.values().length - 1);
/* 177 */       for (HttpMethod method : HttpMethod.values()) {
/* 178 */         if (method != HttpMethod.TRACE)
/* 179 */           allowedMethods.add(method.name());
/*     */       }
/*     */     } else {
/*     */       Collection<String> allowedMethods;
/* 183 */       if (this.supportedMethods.contains(HttpMethod.OPTIONS.name())) {
/* 184 */         allowedMethods = this.supportedMethods;
/*     */       }
/*     */       else {
/* 187 */         allowedMethods = new ArrayList(this.supportedMethods);
/* 188 */         allowedMethods.add(HttpMethod.OPTIONS.name());
/*     */       }
/*     */     }
/* 191 */     this.allowHeader = StringUtils.collectionToCommaDelimitedString(allowedMethods);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected String getAllowHeader()
/*     */   {
/* 205 */     return this.allowHeader;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final void setRequireSession(boolean requireSession)
/*     */   {
/* 212 */     this.requireSession = requireSession;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final boolean isRequireSession()
/*     */   {
/* 219 */     return this.requireSession;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setCacheControl(@Nullable CacheControl cacheControl)
/*     */   {
/* 228 */     this.cacheControl = cacheControl;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public final CacheControl getCacheControl()
/*     */   {
/* 238 */     return this.cacheControl;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setCacheSeconds(int seconds)
/*     */   {
/* 254 */     this.cacheSeconds = seconds;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final int getCacheSeconds()
/*     */   {
/* 261 */     return this.cacheSeconds;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setVaryByRequestHeaders(@Nullable String... varyByRequestHeaders)
/*     */   {
/* 274 */     this.varyByRequestHeaders = varyByRequestHeaders;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public final String[] getVaryByRequestHeaders()
/*     */   {
/* 283 */     return this.varyByRequestHeaders;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public final void setUseExpiresHeader(boolean useExpiresHeader)
/*     */   {
/* 296 */     this.useExpiresHeader = useExpiresHeader;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public final boolean isUseExpiresHeader()
/*     */   {
/* 305 */     return this.useExpiresHeader;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public final void setUseCacheControlHeader(boolean useCacheControlHeader)
/*     */   {
/* 317 */     this.useCacheControlHeader = useCacheControlHeader;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public final boolean isUseCacheControlHeader()
/*     */   {
/* 326 */     return this.useCacheControlHeader;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public final void setUseCacheControlNoStore(boolean useCacheControlNoStore)
/*     */   {
/* 336 */     this.useCacheControlNoStore = useCacheControlNoStore;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public final boolean isUseCacheControlNoStore()
/*     */   {
/* 345 */     return this.useCacheControlNoStore;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public final void setAlwaysMustRevalidate(boolean mustRevalidate)
/*     */   {
/* 358 */     this.alwaysMustRevalidate = mustRevalidate;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public final boolean isAlwaysMustRevalidate()
/*     */   {
/* 367 */     return this.alwaysMustRevalidate;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final void checkRequest(HttpServletRequest request)
/*     */     throws ServletException
/*     */   {
/* 379 */     String method = request.getMethod();
/* 380 */     if ((this.supportedMethods != null) && (!this.supportedMethods.contains(method))) {
/* 381 */       throw new HttpRequestMethodNotSupportedException(method, this.supportedMethods);
/*     */     }
/*     */     
/*     */ 
/* 385 */     if ((this.requireSession) && (request.getSession(false) == null)) {
/* 386 */       throw new HttpSessionRequiredException("Pre-existing session required but none found");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final void prepareResponse(HttpServletResponse response)
/*     */   {
/* 397 */     if (this.cacheControl != null) {
/* 398 */       if (this.logger.isTraceEnabled()) {
/* 399 */         this.logger.trace("Applying default " + getCacheControl());
/*     */       }
/* 401 */       applyCacheControl(response, this.cacheControl);
/*     */     }
/*     */     else {
/* 404 */       if (this.logger.isTraceEnabled()) {
/* 405 */         this.logger.trace("Applying default cacheSeconds=" + this.cacheSeconds);
/*     */       }
/* 407 */       applyCacheSeconds(response, this.cacheSeconds);
/*     */     }
/* 409 */     if (this.varyByRequestHeaders != null) {
/* 410 */       for (String value : getVaryRequestHeadersToAdd(response, this.varyByRequestHeaders)) {
/* 411 */         response.addHeader("Vary", value);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final void applyCacheControl(HttpServletResponse response, CacheControl cacheControl)
/*     */   {
/* 423 */     String ccValue = cacheControl.getHeaderValue();
/* 424 */     if (ccValue != null)
/*     */     {
/* 426 */       response.setHeader("Cache-Control", ccValue);
/*     */       
/* 428 */       if (response.containsHeader("Pragma"))
/*     */       {
/* 430 */         response.setHeader("Pragma", "");
/*     */       }
/* 432 */       if (response.containsHeader("Expires"))
/*     */       {
/* 434 */         response.setHeader("Expires", "");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final void applyCacheSeconds(HttpServletResponse response, int cacheSeconds)
/*     */   {
/* 450 */     if ((this.useExpiresHeader) || (!this.useCacheControlHeader))
/*     */     {
/* 452 */       if (cacheSeconds > 0) {
/* 453 */         cacheForSeconds(response, cacheSeconds);
/*     */       }
/* 455 */       else if (cacheSeconds == 0) {
/* 456 */         preventCaching(response);
/*     */       }
/*     */     }
/*     */     else {
/*     */       CacheControl cControl;
/* 461 */       if (cacheSeconds > 0) {
/* 462 */         CacheControl cControl = CacheControl.maxAge(cacheSeconds, TimeUnit.SECONDS);
/* 463 */         if (this.alwaysMustRevalidate)
/* 464 */           cControl = cControl.mustRevalidate();
/*     */       } else {
/*     */         CacheControl cControl;
/* 467 */         if (cacheSeconds == 0) {
/* 468 */           cControl = this.useCacheControlNoStore ? CacheControl.noStore() : CacheControl.noCache();
/*     */         }
/*     */         else
/* 471 */           cControl = CacheControl.empty();
/*     */       }
/* 473 */       applyCacheControl(response, cControl);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   protected final void checkAndPrepare(HttpServletRequest request, HttpServletResponse response, boolean lastModified)
/*     */     throws ServletException
/*     */   {
/* 490 */     checkRequest(request);
/* 491 */     prepareResponse(response);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   protected final void checkAndPrepare(HttpServletRequest request, HttpServletResponse response, int cacheSeconds, boolean lastModified)
/*     */     throws ServletException
/*     */   {
/* 507 */     checkRequest(request);
/* 508 */     applyCacheSeconds(response, cacheSeconds);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   protected final void applyCacheSeconds(HttpServletResponse response, int cacheSeconds, boolean mustRevalidate)
/*     */   {
/* 526 */     if (cacheSeconds > 0) {
/* 527 */       cacheForSeconds(response, cacheSeconds, mustRevalidate);
/*     */     }
/* 529 */     else if (cacheSeconds == 0) {
/* 530 */       preventCaching(response);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   protected final void cacheForSeconds(HttpServletResponse response, int seconds)
/*     */   {
/* 544 */     cacheForSeconds(response, seconds, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   protected final void cacheForSeconds(HttpServletResponse response, int seconds, boolean mustRevalidate)
/*     */   {
/* 560 */     if (this.useExpiresHeader)
/*     */     {
/* 562 */       response.setDateHeader("Expires", System.currentTimeMillis() + seconds * 1000L);
/*     */     }
/* 564 */     else if (response.containsHeader("Expires"))
/*     */     {
/* 566 */       response.setHeader("Expires", "");
/*     */     }
/*     */     
/* 569 */     if (this.useCacheControlHeader)
/*     */     {
/* 571 */       String headerValue = "max-age=" + seconds;
/* 572 */       if ((mustRevalidate) || (this.alwaysMustRevalidate)) {
/* 573 */         headerValue = headerValue + ", must-revalidate";
/*     */       }
/* 575 */       response.setHeader("Cache-Control", headerValue);
/*     */     }
/*     */     
/* 578 */     if (response.containsHeader("Pragma"))
/*     */     {
/* 580 */       response.setHeader("Pragma", "");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   protected final void preventCaching(HttpServletResponse response)
/*     */   {
/* 592 */     response.setHeader("Pragma", "no-cache");
/*     */     
/* 594 */     if (this.useExpiresHeader)
/*     */     {
/* 596 */       response.setDateHeader("Expires", 1L);
/*     */     }
/*     */     
/* 599 */     if (this.useCacheControlHeader)
/*     */     {
/*     */ 
/* 602 */       response.setHeader("Cache-Control", "no-cache");
/* 603 */       if (this.useCacheControlNoStore) {
/* 604 */         response.addHeader("Cache-Control", "no-store");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private Collection<String> getVaryRequestHeadersToAdd(HttpServletResponse response, String[] varyByRequestHeaders)
/*     */   {
/* 611 */     if (!response.containsHeader("Vary")) {
/* 612 */       return Arrays.asList(varyByRequestHeaders);
/*     */     }
/* 614 */     Collection<String> result = new ArrayList(varyByRequestHeaders.length);
/* 615 */     Collections.addAll(result, varyByRequestHeaders);
/* 616 */     for (String header : response.getHeaders("Vary")) {
/* 617 */       for (String existing : StringUtils.tokenizeToStringArray(header, ",")) {
/* 618 */         if ("*".equals(existing)) {
/* 619 */           return Collections.emptyList();
/*     */         }
/* 621 */         for (String value : varyByRequestHeaders) {
/* 622 */           if (value.equalsIgnoreCase(existing)) {
/* 623 */             result.remove(value);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 628 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\support\WebContentGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */