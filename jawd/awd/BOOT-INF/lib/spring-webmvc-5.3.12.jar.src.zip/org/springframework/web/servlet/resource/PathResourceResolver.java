/*     */ package org.springframework.web.servlet.resource;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.URL;
/*     */ import java.net.URLDecoder;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.core.io.ClassPathResource;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.UrlResource;
/*     */ import org.springframework.http.server.PathContainer;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.context.support.ServletContextResource;
/*     */ import org.springframework.web.util.ServletRequestPathUtils;
/*     */ import org.springframework.web.util.UriUtils;
/*     */ import org.springframework.web.util.UrlPathHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PathResourceResolver
/*     */   extends AbstractResourceResolver
/*     */ {
/*     */   @Nullable
/*     */   private Resource[] allowedLocations;
/*  61 */   private final Map<Resource, Charset> locationCharsets = new HashMap(4);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   private UrlPathHelper urlPathHelper;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAllowedLocations(@Nullable Resource... locations)
/*     */   {
/*  85 */     this.allowedLocations = locations;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public Resource[] getAllowedLocations() {
/*  90 */     return this.allowedLocations;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLocationCharsets(Map<Resource, Charset> locationCharsets)
/*     */   {
/* 103 */     this.locationCharsets.clear();
/* 104 */     this.locationCharsets.putAll(locationCharsets);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<Resource, Charset> getLocationCharsets()
/*     */   {
/* 112 */     return Collections.unmodifiableMap(this.locationCharsets);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUrlPathHelper(@Nullable UrlPathHelper urlPathHelper)
/*     */   {
/* 122 */     this.urlPathHelper = urlPathHelper;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public UrlPathHelper getUrlPathHelper()
/*     */   {
/* 131 */     return this.urlPathHelper;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Resource resolveResourceInternal(@Nullable HttpServletRequest request, String requestPath, List<? extends Resource> locations, ResourceResolverChain chain)
/*     */   {
/* 139 */     return getResource(requestPath, request, locations);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected String resolveUrlPathInternal(String resourcePath, List<? extends Resource> locations, ResourceResolverChain chain)
/*     */   {
/* 146 */     return (StringUtils.hasText(resourcePath)) && 
/* 147 */       (getResource(resourcePath, null, locations) != null) ? resourcePath : null;
/*     */   }
/*     */   
/*     */ 
/*     */   @Nullable
/*     */   private Resource getResource(String resourcePath, @Nullable HttpServletRequest request, List<? extends Resource> locations)
/*     */   {
/* 154 */     for (Resource location : locations) {
/*     */       try {
/* 156 */         String pathToUse = encodeOrDecodeIfNecessary(resourcePath, request, location);
/* 157 */         Resource resource = getResource(pathToUse, location);
/* 158 */         if (resource != null) {
/* 159 */           return resource;
/*     */         }
/*     */       }
/*     */       catch (IOException ex) {
/* 163 */         if (this.logger.isDebugEnabled()) {
/* 164 */           String error = "Skip location [" + location + "] due to error";
/* 165 */           if (this.logger.isTraceEnabled()) {
/* 166 */             this.logger.trace(error, ex);
/*     */           }
/*     */           else {
/* 169 */             this.logger.debug(error + ": " + ex.getMessage());
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 174 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected Resource getResource(String resourcePath, Resource location)
/*     */     throws IOException
/*     */   {
/* 187 */     Resource resource = location.createRelative(resourcePath);
/* 188 */     if (resource.isReadable()) {
/* 189 */       if (checkResource(resource, location)) {
/* 190 */         return resource;
/*     */       }
/* 192 */       if (this.logger.isWarnEnabled()) {
/* 193 */         Resource[] allowedLocations = getAllowedLocations();
/* 194 */         this.logger.warn("Resource path \"" + resourcePath + "\" was successfully resolved but resource \"" + resource
/* 195 */           .getURL() + "\" is neither under the current location \"" + location
/* 196 */           .getURL() + "\" nor under any of the allowed locations " + (allowedLocations != null ? 
/* 197 */           Arrays.asList(allowedLocations) : "[]"));
/*     */       }
/*     */     }
/* 200 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean checkResource(Resource resource, Resource location)
/*     */     throws IOException
/*     */   {
/* 214 */     if (isResourceUnderLocation(resource, location)) {
/* 215 */       return true;
/*     */     }
/* 217 */     Resource[] allowedLocations = getAllowedLocations();
/* 218 */     if (allowedLocations != null) {
/* 219 */       for (Resource current : allowedLocations) {
/* 220 */         if (isResourceUnderLocation(resource, current)) {
/* 221 */           return true;
/*     */         }
/*     */       }
/*     */     }
/* 225 */     return false;
/*     */   }
/*     */   
/*     */   private boolean isResourceUnderLocation(Resource resource, Resource location) throws IOException {
/* 229 */     if (resource.getClass() != location.getClass()) {
/* 230 */       return false;
/*     */     }
/*     */     
/*     */     String locationPath;
/*     */     
/*     */     String resourcePath;
/* 236 */     if ((resource instanceof UrlResource)) {
/* 237 */       String resourcePath = resource.getURL().toExternalForm();
/* 238 */       locationPath = StringUtils.cleanPath(location.getURL().toString());
/*     */     } else { String locationPath;
/* 240 */       if ((resource instanceof ClassPathResource)) {
/* 241 */         String resourcePath = ((ClassPathResource)resource).getPath();
/* 242 */         locationPath = StringUtils.cleanPath(((ClassPathResource)location).getPath());
/*     */       } else { String locationPath;
/* 244 */         if ((resource instanceof ServletContextResource)) {
/* 245 */           String resourcePath = ((ServletContextResource)resource).getPath();
/* 246 */           locationPath = StringUtils.cleanPath(((ServletContextResource)location).getPath());
/*     */         }
/*     */         else {
/* 249 */           resourcePath = resource.getURL().getPath();
/* 250 */           locationPath = StringUtils.cleanPath(location.getURL().getPath());
/*     */         }
/*     */       } }
/* 253 */     if (locationPath.equals(resourcePath)) {
/* 254 */       return true;
/*     */     }
/* 256 */     String locationPath = locationPath + "/";
/* 257 */     return (resourcePath.startsWith(locationPath)) && (!isInvalidEncodedPath(resourcePath));
/*     */   }
/*     */   
/*     */   private String encodeOrDecodeIfNecessary(String path, @Nullable HttpServletRequest request, Resource location) {
/* 261 */     if (shouldDecodeRelativePath(location, request)) {
/* 262 */       return UriUtils.decode(path, StandardCharsets.UTF_8);
/*     */     }
/* 264 */     if ((shouldEncodeRelativePath(location)) && (request != null)) {
/* 265 */       Charset charset = (Charset)this.locationCharsets.getOrDefault(location, StandardCharsets.UTF_8);
/* 266 */       StringBuilder sb = new StringBuilder();
/* 267 */       StringTokenizer tokenizer = new StringTokenizer(path, "/");
/* 268 */       while (tokenizer.hasMoreTokens()) {
/* 269 */         String value = UriUtils.encode(tokenizer.nextToken(), charset);
/* 270 */         sb.append(value);
/* 271 */         sb.append('/');
/*     */       }
/* 273 */       if (!path.endsWith("/")) {
/* 274 */         sb.setLength(sb.length() - 1);
/*     */       }
/* 276 */       return sb.toString();
/*     */     }
/*     */     
/* 279 */     return path;
/*     */   }
/*     */   
/*     */   private boolean shouldDecodeRelativePath(Resource location, @Nullable HttpServletRequest request)
/*     */   {
/* 284 */     return (!(location instanceof UrlResource)) && (request != null) && 
/* 285 */       (ServletRequestPathUtils.hasCachedPath(request)) && 
/* 286 */       ((ServletRequestPathUtils.getCachedPath(request) instanceof PathContainer));
/*     */   }
/*     */   
/*     */   private boolean shouldEncodeRelativePath(Resource location) {
/* 290 */     return ((location instanceof UrlResource)) && (this.urlPathHelper != null) && 
/* 291 */       (this.urlPathHelper.isUrlDecode());
/*     */   }
/*     */   
/*     */   private boolean isInvalidEncodedPath(String resourcePath) {
/* 295 */     if (resourcePath.contains("%")) {
/*     */       try
/*     */       {
/* 298 */         String decodedPath = URLDecoder.decode(resourcePath, "UTF-8");
/* 299 */         if ((decodedPath.contains("../")) || (decodedPath.contains("..\\"))) {
/* 300 */           this.logger.warn("Resolved resource path contains encoded \"../\" or \"..\\\": " + resourcePath);
/* 301 */           return true;
/*     */         }
/*     */       }
/*     */       catch (IllegalArgumentException localIllegalArgumentException) {}catch (UnsupportedEncodingException localUnsupportedEncodingException) {}
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 311 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\resource\PathResourceResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */