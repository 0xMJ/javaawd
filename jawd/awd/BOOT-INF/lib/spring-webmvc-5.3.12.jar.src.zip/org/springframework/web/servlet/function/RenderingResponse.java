/*    */ package org.springframework.web.servlet.function;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.Map;
/*    */ import java.util.function.Consumer;
/*    */ import javax.servlet.http.Cookie;
/*    */ import org.springframework.http.HttpHeaders;
/*    */ import org.springframework.http.HttpStatus;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.MultiValueMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract interface RenderingResponse
/*    */   extends ServerResponse
/*    */ {
/*    */   public abstract String name();
/*    */   
/*    */   public abstract Map<String, Object> model();
/*    */   
/*    */   public static Builder from(RenderingResponse other)
/*    */   {
/* 57 */     return new DefaultRenderingResponseBuilder(other);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static Builder create(String name)
/*    */   {
/* 66 */     return new DefaultRenderingResponseBuilder(name);
/*    */   }
/*    */   
/*    */   public static abstract interface Builder
/*    */   {
/*    */     public abstract Builder modelAttribute(Object paramObject);
/*    */     
/*    */     public abstract Builder modelAttribute(String paramString, @Nullable Object paramObject);
/*    */     
/*    */     public abstract Builder modelAttributes(Object... paramVarArgs);
/*    */     
/*    */     public abstract Builder modelAttributes(Collection<?> paramCollection);
/*    */     
/*    */     public abstract Builder modelAttributes(Map<String, ?> paramMap);
/*    */     
/*    */     public abstract Builder header(String paramString, String... paramVarArgs);
/*    */     
/*    */     public abstract Builder headers(Consumer<HttpHeaders> paramConsumer);
/*    */     
/*    */     public abstract Builder status(HttpStatus paramHttpStatus);
/*    */     
/*    */     public abstract Builder status(int paramInt);
/*    */     
/*    */     public abstract Builder cookie(Cookie paramCookie);
/*    */     
/*    */     public abstract Builder cookies(Consumer<MultiValueMap<String, Cookie>> paramConsumer);
/*    */     
/*    */     public abstract RenderingResponse build();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\function\RenderingResponse.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */