/*    */ package org.springframework.web.servlet.view.script;
/*    */ 
/*    */ import org.springframework.web.servlet.view.AbstractUrlBasedView;
/*    */ import org.springframework.web.servlet.view.UrlBasedViewResolver;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ScriptTemplateViewResolver
/*    */   extends UrlBasedViewResolver
/*    */ {
/*    */   public ScriptTemplateViewResolver()
/*    */   {
/* 44 */     setViewClass(requiredViewClass());
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ScriptTemplateViewResolver(String prefix, String suffix)
/*    */   {
/* 55 */     this();
/* 56 */     setPrefix(prefix);
/* 57 */     setSuffix(suffix);
/*    */   }
/*    */   
/*    */ 
/*    */   protected Class<?> requiredViewClass()
/*    */   {
/* 63 */     return ScriptTemplateView.class;
/*    */   }
/*    */   
/*    */   protected AbstractUrlBasedView instantiateView()
/*    */   {
/* 68 */     return getViewClass() == ScriptTemplateView.class ? new ScriptTemplateView() : super.instantiateView();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\view\script\ScriptTemplateViewResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */