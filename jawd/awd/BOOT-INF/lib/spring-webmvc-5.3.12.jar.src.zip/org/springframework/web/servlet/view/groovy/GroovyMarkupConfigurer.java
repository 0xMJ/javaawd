/*     */ package org.springframework.web.servlet.view.groovy;
/*     */ 
/*     */ import groovy.text.markup.MarkupTemplateEngine;
/*     */ import groovy.text.markup.MarkupTemplateEngine.TemplateResource;
/*     */ import groovy.text.markup.TemplateConfiguration;
/*     */ import groovy.text.markup.TemplateResolver;
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ import java.net.URLClassLoader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextAware;
/*     */ import org.springframework.context.i18n.LocaleContextHolder;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GroovyMarkupConfigurer
/*     */   extends TemplateConfiguration
/*     */   implements GroovyMarkupConfig, ApplicationContextAware, InitializingBean
/*     */ {
/*  89 */   private String resourceLoaderPath = "classpath:";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   private MarkupTemplateEngine templateEngine;
/*     */   
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   private ApplicationContext applicationContext;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setResourceLoaderPath(String resourceLoaderPath)
/*     */   {
/* 107 */     this.resourceLoaderPath = resourceLoaderPath;
/*     */   }
/*     */   
/*     */   public String getResourceLoaderPath() {
/* 111 */     return this.resourceLoaderPath;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTemplateEngine(MarkupTemplateEngine templateEngine)
/*     */   {
/* 121 */     this.templateEngine = templateEngine;
/*     */   }
/*     */   
/*     */   public MarkupTemplateEngine getTemplateEngine()
/*     */   {
/* 126 */     Assert.state(this.templateEngine != null, "No MarkupTemplateEngine set");
/* 127 */     return this.templateEngine;
/*     */   }
/*     */   
/*     */   public void setApplicationContext(ApplicationContext applicationContext)
/*     */   {
/* 132 */     this.applicationContext = applicationContext;
/*     */   }
/*     */   
/*     */   protected ApplicationContext getApplicationContext() {
/* 136 */     Assert.state(this.applicationContext != null, "No ApplicationContext set");
/* 137 */     return this.applicationContext;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLocale(Locale locale)
/*     */   {
/* 146 */     super.setLocale(locale);
/*     */   }
/*     */   
/*     */   public void afterPropertiesSet()
/*     */     throws Exception
/*     */   {
/* 152 */     if (this.templateEngine == null) {
/* 153 */       this.templateEngine = createTemplateEngine();
/*     */     }
/*     */   }
/*     */   
/*     */   protected MarkupTemplateEngine createTemplateEngine() throws IOException {
/* 158 */     if (this.templateEngine == null) {
/* 159 */       ClassLoader templateClassLoader = createTemplateClassLoader();
/* 160 */       this.templateEngine = new MarkupTemplateEngine(templateClassLoader, this, new LocaleTemplateResolver(null));
/*     */     }
/* 162 */     return this.templateEngine;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected ClassLoader createTemplateClassLoader()
/*     */     throws IOException
/*     */   {
/* 170 */     String[] paths = StringUtils.commaDelimitedListToStringArray(getResourceLoaderPath());
/* 171 */     List<URL> urls = new ArrayList();
/* 172 */     for (String path : paths) {
/* 173 */       Resource[] resources = getApplicationContext().getResources(path);
/* 174 */       if (resources.length > 0) {
/* 175 */         for (Resource resource : resources) {
/* 176 */           if (resource.exists()) {
/* 177 */             urls.add(resource.getURL());
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 182 */     ClassLoader classLoader = getApplicationContext().getClassLoader();
/* 183 */     Assert.state(classLoader != null, "No ClassLoader");
/* 184 */     return !urls.isEmpty() ? new URLClassLoader((URL[])urls.toArray(new URL[0]), classLoader) : classLoader;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected URL resolveTemplate(ClassLoader classLoader, String templatePath)
/*     */     throws IOException
/*     */   {
/* 196 */     MarkupTemplateEngine.TemplateResource resource = MarkupTemplateEngine.TemplateResource.parse(templatePath);
/* 197 */     Locale locale = LocaleContextHolder.getLocale();
/* 198 */     URL url = classLoader.getResource(resource.withLocale(StringUtils.replace(locale.toString(), "-", "_")).toString());
/* 199 */     if (url == null) {
/* 200 */       url = classLoader.getResource(resource.withLocale(locale.getLanguage()).toString());
/*     */     }
/* 202 */     if (url == null) {
/* 203 */       url = classLoader.getResource(resource.withLocale(null).toString());
/*     */     }
/* 205 */     if (url == null) {
/* 206 */       throw new IOException("Unable to load template:" + templatePath);
/*     */     }
/* 208 */     return url;
/*     */   }
/*     */   
/*     */ 
/*     */   private class LocaleTemplateResolver
/*     */     implements TemplateResolver
/*     */   {
/*     */     @Nullable
/*     */     private ClassLoader classLoader;
/*     */     
/*     */ 
/*     */     private LocaleTemplateResolver() {}
/*     */     
/*     */     public void configure(ClassLoader templateClassLoader, TemplateConfiguration configuration)
/*     */     {
/* 223 */       this.classLoader = templateClassLoader;
/*     */     }
/*     */     
/*     */     public URL resolveTemplate(String templatePath) throws IOException
/*     */     {
/* 228 */       Assert.state(this.classLoader != null, "No template ClassLoader available");
/* 229 */       return GroovyMarkupConfigurer.this.resolveTemplate(this.classLoader, templatePath);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\view\groovy\GroovyMarkupConfigurer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */