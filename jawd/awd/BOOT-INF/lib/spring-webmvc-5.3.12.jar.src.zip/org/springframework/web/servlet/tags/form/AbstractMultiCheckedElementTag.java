/*     */ package org.springframework.web.servlet.tags.form;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import org.springframework.beans.BeanWrapper;
/*     */ import org.springframework.beans.PropertyAccessorFactory;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.servlet.support.BindStatus;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractMultiCheckedElementTag
/*     */   extends AbstractCheckedElementTag
/*     */ {
/*     */   private static final String SPAN_TAG = "span";
/*     */   @Nullable
/*     */   private Object items;
/*     */   @Nullable
/*     */   private String itemValue;
/*     */   @Nullable
/*     */   private String itemLabel;
/*  74 */   private String element = "span";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   private String delimiter;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setItems(Object items)
/*     */   {
/*  90 */     Assert.notNull(items, "'items' must not be null");
/*  91 */     this.items = items;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected Object getItems()
/*     */   {
/* 100 */     return this.items;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setItemValue(String itemValue)
/*     */   {
/* 109 */     Assert.hasText(itemValue, "'itemValue' must not be empty");
/* 110 */     this.itemValue = itemValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected String getItemValue()
/*     */   {
/* 119 */     return this.itemValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setItemLabel(String itemLabel)
/*     */   {
/* 128 */     Assert.hasText(itemLabel, "'itemLabel' must not be empty");
/* 129 */     this.itemLabel = itemLabel;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected String getItemLabel()
/*     */   {
/* 138 */     return this.itemLabel;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDelimiter(String delimiter)
/*     */   {
/* 147 */     this.delimiter = delimiter;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public String getDelimiter()
/*     */   {
/* 156 */     return this.delimiter;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setElement(String element)
/*     */   {
/* 165 */     Assert.hasText(element, "'element' cannot be null or blank");
/* 166 */     this.element = element;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getElement()
/*     */   {
/* 174 */     return this.element;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String resolveId()
/*     */     throws JspException
/*     */   {
/* 184 */     Object id = evaluate("id", getId());
/* 185 */     if (id != null) {
/* 186 */       String idString = id.toString();
/* 187 */       return StringUtils.hasText(idString) ? TagIdGenerator.nextId(idString, this.pageContext) : null;
/*     */     }
/* 189 */     return autogenerateId();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int writeTagContent(TagWriter tagWriter)
/*     */     throws JspException
/*     */   {
/* 200 */     Object items = getItems();
/* 201 */     Object itemsObject = (items instanceof String) ? evaluate("items", items) : items;
/*     */     
/* 203 */     String itemValue = getItemValue();
/* 204 */     String itemLabel = getItemLabel();
/*     */     
/* 206 */     String valueProperty = itemValue != null ? ObjectUtils.getDisplayString(evaluate("itemValue", itemValue)) : null;
/*     */     
/* 208 */     String labelProperty = itemLabel != null ? ObjectUtils.getDisplayString(evaluate("itemLabel", itemLabel)) : null;
/*     */     
/* 210 */     Class<?> boundType = getBindStatus().getValueType();
/* 211 */     if ((itemsObject == null) && (boundType != null) && (boundType.isEnum())) {
/* 212 */       itemsObject = boundType.getEnumConstants();
/*     */     }
/*     */     
/* 215 */     if (itemsObject == null) {
/* 216 */       throw new IllegalArgumentException("Attribute 'items' is required and must be a Collection, an Array or a Map");
/*     */     }
/*     */     
/* 219 */     if (itemsObject.getClass().isArray()) {
/* 220 */       Object[] itemsArray = (Object[])itemsObject;
/* 221 */       for (int i = 0; i < itemsArray.length; i++) {
/* 222 */         Object item = itemsArray[i];
/* 223 */         writeObjectEntry(tagWriter, valueProperty, labelProperty, item, i);
/*     */       }
/*     */     }
/* 226 */     else if ((itemsObject instanceof Collection)) {
/* 227 */       Collection<?> optionCollection = (Collection)itemsObject;
/* 228 */       int itemIndex = 0;
/* 229 */       for (Iterator<?> it = optionCollection.iterator(); it.hasNext(); itemIndex++) {
/* 230 */         Object item = it.next();
/* 231 */         writeObjectEntry(tagWriter, valueProperty, labelProperty, item, itemIndex);
/*     */       }
/*     */     }
/* 234 */     else if ((itemsObject instanceof Map)) {
/* 235 */       Map<?, ?> optionMap = (Map)itemsObject;
/* 236 */       int itemIndex = 0;
/* 237 */       for (Iterator it = optionMap.entrySet().iterator(); it.hasNext(); itemIndex++) {
/* 238 */         Map.Entry entry = (Map.Entry)it.next();
/* 239 */         writeMapEntry(tagWriter, valueProperty, labelProperty, entry, itemIndex);
/*     */       }
/*     */     }
/*     */     else {
/* 243 */       throw new IllegalArgumentException("Attribute 'items' must be an array, a Collection or a Map");
/*     */     }
/*     */     
/* 246 */     return 0;
/*     */   }
/*     */   
/*     */   private void writeObjectEntry(TagWriter tagWriter, @Nullable String valueProperty, @Nullable String labelProperty, Object item, int itemIndex)
/*     */     throws JspException
/*     */   {
/* 252 */     BeanWrapper wrapper = PropertyAccessorFactory.forBeanPropertyAccess(item);
/*     */     Object renderValue;
/* 254 */     Object renderValue; if (valueProperty != null) {
/* 255 */       renderValue = wrapper.getPropertyValue(valueProperty);
/*     */     } else { Object renderValue;
/* 257 */       if ((item instanceof Enum)) {
/* 258 */         renderValue = ((Enum)item).name();
/*     */       }
/*     */       else
/* 261 */         renderValue = item;
/*     */     }
/* 263 */     Object renderLabel = labelProperty != null ? wrapper.getPropertyValue(labelProperty) : item;
/* 264 */     writeElementTag(tagWriter, item, renderValue, renderLabel, itemIndex);
/*     */   }
/*     */   
/*     */   private void writeMapEntry(TagWriter tagWriter, @Nullable String valueProperty, @Nullable String labelProperty, Map.Entry<?, ?> entry, int itemIndex)
/*     */     throws JspException
/*     */   {
/* 270 */     Object mapKey = entry.getKey();
/* 271 */     Object mapValue = entry.getValue();
/* 272 */     BeanWrapper mapKeyWrapper = PropertyAccessorFactory.forBeanPropertyAccess(mapKey);
/* 273 */     BeanWrapper mapValueWrapper = PropertyAccessorFactory.forBeanPropertyAccess(mapValue);
/*     */     
/* 275 */     Object renderValue = valueProperty != null ? mapKeyWrapper.getPropertyValue(valueProperty) : mapKey.toString();
/*     */     
/* 277 */     Object renderLabel = labelProperty != null ? mapValueWrapper.getPropertyValue(labelProperty) : mapValue.toString();
/* 278 */     writeElementTag(tagWriter, mapKey, renderValue, renderLabel, itemIndex);
/*     */   }
/*     */   
/*     */   private void writeElementTag(TagWriter tagWriter, Object item, @Nullable Object value, @Nullable Object label, int itemIndex)
/*     */     throws JspException
/*     */   {
/* 284 */     tagWriter.startTag(getElement());
/* 285 */     if (itemIndex > 0) {
/* 286 */       Object resolvedDelimiter = evaluate("delimiter", getDelimiter());
/* 287 */       if (resolvedDelimiter != null) {
/* 288 */         tagWriter.appendValue(resolvedDelimiter.toString());
/*     */       }
/*     */     }
/* 291 */     tagWriter.startTag("input");
/* 292 */     String id = resolveId();
/* 293 */     Assert.state(id != null, "Attribute 'id' is required");
/* 294 */     writeOptionalAttribute(tagWriter, "id", id);
/* 295 */     writeOptionalAttribute(tagWriter, "name", getName());
/* 296 */     writeOptionalAttributes(tagWriter);
/* 297 */     tagWriter.writeAttribute("type", getInputType());
/* 298 */     renderFromValue(item, value, tagWriter);
/* 299 */     tagWriter.endTag();
/* 300 */     tagWriter.startTag("label");
/* 301 */     tagWriter.writeAttribute("for", id);
/* 302 */     tagWriter.appendValue(convertToDisplayString(label));
/* 303 */     tagWriter.endTag();
/* 304 */     tagWriter.endTag();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\tags\form\AbstractMultiCheckedElementTag.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */