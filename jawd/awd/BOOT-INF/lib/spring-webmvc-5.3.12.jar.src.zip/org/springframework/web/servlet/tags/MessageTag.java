/*     */ package org.springframework.web.servlet.tags;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.JspTagException;
/*     */ import javax.servlet.jsp.JspWriter;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import org.springframework.context.MessageSource;
/*     */ import org.springframework.context.MessageSourceResolvable;
/*     */ import org.springframework.context.NoSuchMessageException;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.servlet.support.RequestContext;
/*     */ import org.springframework.web.util.JavaScriptUtils;
/*     */ import org.springframework.web.util.TagUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MessageTag
/*     */   extends HtmlEscapingAwareTag
/*     */   implements ArgumentAware
/*     */ {
/*     */   public static final String DEFAULT_ARGUMENT_SEPARATOR = ",";
/*     */   @Nullable
/*     */   private MessageSourceResolvable message;
/*     */   @Nullable
/*     */   private String code;
/*     */   @Nullable
/*     */   private Object arguments;
/* 165 */   private String argumentSeparator = ",";
/*     */   
/* 167 */   private List<Object> nestedArguments = Collections.emptyList();
/*     */   
/*     */   @Nullable
/*     */   private String text;
/*     */   
/*     */   @Nullable
/*     */   private String var;
/*     */   
/* 175 */   private String scope = "page";
/*     */   
/* 177 */   private boolean javaScriptEscape = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMessage(MessageSourceResolvable message)
/*     */   {
/* 186 */     this.message = message;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setCode(String code)
/*     */   {
/* 193 */     this.code = code;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setArguments(Object arguments)
/*     */   {
/* 202 */     this.arguments = arguments;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setArgumentSeparator(String argumentSeparator)
/*     */   {
/* 211 */     this.argumentSeparator = argumentSeparator;
/*     */   }
/*     */   
/*     */   public void addArgument(@Nullable Object argument) throws JspTagException
/*     */   {
/* 216 */     this.nestedArguments.add(argument);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setText(String text)
/*     */   {
/* 223 */     this.text = text;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setVar(String var)
/*     */   {
/* 233 */     this.var = var;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setScope(String scope)
/*     */   {
/* 244 */     this.scope = scope;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setJavaScriptEscape(boolean javaScriptEscape)
/*     */     throws JspException
/*     */   {
/* 252 */     this.javaScriptEscape = javaScriptEscape;
/*     */   }
/*     */   
/*     */   protected final int doStartTagInternal()
/*     */     throws JspException, IOException
/*     */   {
/* 258 */     this.nestedArguments = new ArrayList();
/* 259 */     return 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int doEndTag()
/*     */     throws JspException
/*     */   {
/*     */     try
/*     */     {
/* 274 */       String msg = resolveMessage();
/*     */       
/*     */ 
/* 277 */       msg = htmlEscape(msg);
/* 278 */       msg = this.javaScriptEscape ? JavaScriptUtils.javaScriptEscape(msg) : msg;
/*     */       
/*     */ 
/* 281 */       if (this.var != null) {
/* 282 */         this.pageContext.setAttribute(this.var, msg, TagUtils.getScope(this.scope));
/*     */       }
/*     */       else {
/* 285 */         writeMessage(msg);
/*     */       }
/*     */       
/* 288 */       return 6;
/*     */     }
/*     */     catch (IOException ex) {
/* 291 */       throw new JspTagException(ex.getMessage(), ex);
/*     */     }
/*     */     catch (NoSuchMessageException ex) {
/* 294 */       throw new JspTagException(getNoSuchMessageExceptionDescription(ex));
/*     */     }
/*     */   }
/*     */   
/*     */   public void release()
/*     */   {
/* 300 */     super.release();
/* 301 */     this.arguments = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String resolveMessage()
/*     */     throws JspException, NoSuchMessageException
/*     */   {
/* 310 */     MessageSource messageSource = getMessageSource();
/*     */     
/*     */ 
/* 313 */     if (this.message != null)
/*     */     {
/* 315 */       return messageSource.getMessage(this.message, getRequestContext().getLocale());
/*     */     }
/*     */     
/* 318 */     if ((this.code != null) || (this.text != null))
/*     */     {
/* 320 */       Object[] argumentsArray = resolveArguments(this.arguments);
/* 321 */       if (!this.nestedArguments.isEmpty()) {
/* 322 */         argumentsArray = appendArguments(argumentsArray, this.nestedArguments.toArray());
/*     */       }
/*     */       
/* 325 */       if (this.text != null)
/*     */       {
/* 327 */         String msg = messageSource.getMessage(this.code, argumentsArray, this.text, 
/* 328 */           getRequestContext().getLocale());
/* 329 */         return msg != null ? msg : "";
/*     */       }
/*     */       
/*     */ 
/* 333 */       return messageSource.getMessage(this.code, argumentsArray, 
/* 334 */         getRequestContext().getLocale());
/*     */     }
/*     */     
/*     */ 
/* 338 */     throw new JspTagException("No resolvable message");
/*     */   }
/*     */   
/*     */   private Object[] appendArguments(@Nullable Object[] sourceArguments, Object[] additionalArguments) {
/* 342 */     if (ObjectUtils.isEmpty(sourceArguments)) {
/* 343 */       return additionalArguments;
/*     */     }
/* 345 */     Object[] arguments = new Object[sourceArguments.length + additionalArguments.length];
/* 346 */     System.arraycopy(sourceArguments, 0, arguments, 0, sourceArguments.length);
/* 347 */     System.arraycopy(additionalArguments, 0, arguments, sourceArguments.length, additionalArguments.length);
/* 348 */     return arguments;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected Object[] resolveArguments(@Nullable Object arguments)
/*     */     throws JspException
/*     */   {
/* 360 */     if ((arguments instanceof String)) {
/* 361 */       return StringUtils.delimitedListToStringArray((String)arguments, this.argumentSeparator);
/*     */     }
/* 363 */     if ((arguments instanceof Object[])) {
/* 364 */       return (Object[])arguments;
/*     */     }
/* 366 */     if ((arguments instanceof Collection)) {
/* 367 */       return ((Collection)arguments).toArray();
/*     */     }
/* 369 */     if (arguments != null)
/*     */     {
/* 371 */       return new Object[] { arguments };
/*     */     }
/*     */     
/* 374 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void writeMessage(String msg)
/*     */     throws IOException
/*     */   {
/* 385 */     this.pageContext.getOut().write(msg);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected MessageSource getMessageSource()
/*     */   {
/* 392 */     return getRequestContext().getMessageSource();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected String getNoSuchMessageExceptionDescription(NoSuchMessageException ex)
/*     */   {
/* 399 */     return ex.getMessage();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\tags\MessageTag.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */