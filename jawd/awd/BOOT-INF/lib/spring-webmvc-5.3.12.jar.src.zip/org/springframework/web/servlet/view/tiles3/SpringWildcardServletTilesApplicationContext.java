/*     */ package org.springframework.web.servlet.view.tiles3;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.Locale;
/*     */ import javax.servlet.ServletContext;
/*     */ import org.apache.tiles.request.ApplicationResource;
/*     */ import org.apache.tiles.request.locale.URLApplicationResource;
/*     */ import org.apache.tiles.request.servlet.ServletApplicationContext;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.support.ResourcePatternResolver;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.web.context.support.ServletContextResourcePatternResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpringWildcardServletTilesApplicationContext
/*     */   extends ServletApplicationContext
/*     */ {
/*     */   private final ResourcePatternResolver resolver;
/*     */   
/*     */   public SpringWildcardServletTilesApplicationContext(ServletContext servletContext)
/*     */   {
/*  52 */     super(servletContext);
/*  53 */     this.resolver = new ServletContextResourcePatternResolver(servletContext);
/*     */   }
/*     */   
/*     */ 
/*     */   @Nullable
/*     */   public ApplicationResource getResource(String localePath)
/*     */   {
/*  60 */     Collection<ApplicationResource> urlSet = getResources(localePath);
/*  61 */     if (!CollectionUtils.isEmpty(urlSet)) {
/*  62 */       return (ApplicationResource)urlSet.iterator().next();
/*     */     }
/*  64 */     return null;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public ApplicationResource getResource(ApplicationResource base, Locale locale)
/*     */   {
/*  70 */     Collection<ApplicationResource> urlSet = getResources(base.getLocalePath(locale));
/*  71 */     if (!CollectionUtils.isEmpty(urlSet)) {
/*  72 */       return (ApplicationResource)urlSet.iterator().next();
/*     */     }
/*  74 */     return null;
/*     */   }
/*     */   
/*     */   public Collection<ApplicationResource> getResources(String path)
/*     */   {
/*     */     try
/*     */     {
/*  81 */       resources = this.resolver.getResources(path);
/*     */     } catch (IOException ex) {
/*     */       Resource[] resources;
/*  84 */       ((ServletContext)getContext()).log("Resource retrieval failed for path: " + path, ex);
/*  85 */       return Collections.emptyList(); }
/*     */     Resource[] resources;
/*  87 */     if (ObjectUtils.isEmpty(resources)) {
/*  88 */       ((ServletContext)getContext()).log("No resources found for path pattern: " + path);
/*  89 */       return Collections.emptyList();
/*     */     }
/*     */     
/*  92 */     Collection<ApplicationResource> resourceList = new ArrayList(resources.length);
/*  93 */     for (Resource resource : resources) {
/*     */       try {
/*  95 */         URL url = resource.getURL();
/*  96 */         resourceList.add(new URLApplicationResource(url.toExternalForm(), url));
/*     */       }
/*     */       catch (IOException ex)
/*     */       {
/* 100 */         throw new IllegalArgumentException("No URL for " + resource, ex);
/*     */       }
/*     */     }
/* 103 */     return resourceList;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\view\tiles3\SpringWildcardServletTilesApplicationContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */