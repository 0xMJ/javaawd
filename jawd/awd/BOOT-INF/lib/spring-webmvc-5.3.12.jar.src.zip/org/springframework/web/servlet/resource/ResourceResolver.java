package org.springframework.web.servlet.resource;

import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.springframework.core.io.Resource;
import org.springframework.lang.Nullable;

public abstract interface ResourceResolver
{
  @Nullable
  public abstract Resource resolveResource(@Nullable HttpServletRequest paramHttpServletRequest, String paramString, List<? extends Resource> paramList, ResourceResolverChain paramResourceResolverChain);
  
  @Nullable
  public abstract String resolveUrlPath(String paramString, List<? extends Resource> paramList, ResourceResolverChain paramResourceResolverChain);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\resource\ResourceResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */