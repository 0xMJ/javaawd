/*    */ package org.springframework.web.servlet.handler;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.web.servlet.HandlerInterceptor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UserRoleAuthorizationInterceptor
/*    */   implements HandlerInterceptor
/*    */ {
/*    */   @Nullable
/*    */   private String[] authorizedRoles;
/*    */   
/*    */   public final void setAuthorizedRoles(String... authorizedRoles)
/*    */   {
/* 47 */     this.authorizedRoles = authorizedRoles;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public final boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
/*    */     throws ServletException, IOException
/*    */   {
/* 55 */     if (this.authorizedRoles != null) {
/* 56 */       for (String role : this.authorizedRoles) {
/* 57 */         if (request.isUserInRole(role)) {
/* 58 */           return true;
/*    */         }
/*    */       }
/*    */     }
/* 62 */     handleNotAuthorized(request, response, handler);
/* 63 */     return false;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected void handleNotAuthorized(HttpServletRequest request, HttpServletResponse response, Object handler)
/*    */     throws ServletException, IOException
/*    */   {
/* 80 */     response.sendError(403);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\handler\UserRoleAuthorizationInterceptor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */