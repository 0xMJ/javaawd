/*      */ package org.springframework.web.servlet.mvc.method;
/*      */ 
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Set;
/*      */ import javax.servlet.http.HttpServletRequest;
/*      */ import org.springframework.http.HttpMethod;
/*      */ import org.springframework.lang.Nullable;
/*      */ import org.springframework.util.Assert;
/*      */ import org.springframework.util.ObjectUtils;
/*      */ import org.springframework.util.PathMatcher;
/*      */ import org.springframework.util.StringUtils;
/*      */ import org.springframework.web.accept.ContentNegotiationManager;
/*      */ import org.springframework.web.bind.annotation.RequestMethod;
/*      */ import org.springframework.web.servlet.mvc.condition.AbstractRequestCondition;
/*      */ import org.springframework.web.servlet.mvc.condition.ConsumesRequestCondition;
/*      */ import org.springframework.web.servlet.mvc.condition.HeadersRequestCondition;
/*      */ import org.springframework.web.servlet.mvc.condition.ParamsRequestCondition;
/*      */ import org.springframework.web.servlet.mvc.condition.PathPatternsRequestCondition;
/*      */ import org.springframework.web.servlet.mvc.condition.PatternsRequestCondition;
/*      */ import org.springframework.web.servlet.mvc.condition.ProducesRequestCondition;
/*      */ import org.springframework.web.servlet.mvc.condition.RequestCondition;
/*      */ import org.springframework.web.servlet.mvc.condition.RequestConditionHolder;
/*      */ import org.springframework.web.servlet.mvc.condition.RequestMethodsRequestCondition;
/*      */ import org.springframework.web.util.UrlPathHelper;
/*      */ import org.springframework.web.util.pattern.PathPatternParser;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class RequestMappingInfo
/*      */   implements RequestCondition<RequestMappingInfo>
/*      */ {
/*   68 */   private static final PathPatternsRequestCondition EMPTY_PATH_PATTERNS = new PathPatternsRequestCondition();
/*      */   
/*   70 */   private static final PatternsRequestCondition EMPTY_PATTERNS = new PatternsRequestCondition(new String[0]);
/*      */   
/*   72 */   private static final RequestMethodsRequestCondition EMPTY_REQUEST_METHODS = new RequestMethodsRequestCondition(new RequestMethod[0]);
/*      */   
/*   74 */   private static final ParamsRequestCondition EMPTY_PARAMS = new ParamsRequestCondition(new String[0]);
/*      */   
/*   76 */   private static final HeadersRequestCondition EMPTY_HEADERS = new HeadersRequestCondition(new String[0]);
/*      */   
/*   78 */   private static final ConsumesRequestCondition EMPTY_CONSUMES = new ConsumesRequestCondition(new String[0]);
/*      */   
/*   80 */   private static final ProducesRequestCondition EMPTY_PRODUCES = new ProducesRequestCondition(new String[0]);
/*      */   
/*   82 */   private static final RequestConditionHolder EMPTY_CUSTOM = new RequestConditionHolder(null);
/*      */   
/*      */ 
/*      */   @Nullable
/*      */   private final String name;
/*      */   
/*      */ 
/*      */   @Nullable
/*      */   private final PathPatternsRequestCondition pathPatternsCondition;
/*      */   
/*      */ 
/*      */   @Nullable
/*      */   private final PatternsRequestCondition patternsCondition;
/*      */   
/*      */ 
/*      */   private final RequestMethodsRequestCondition methodsCondition;
/*      */   
/*      */ 
/*      */   private final ParamsRequestCondition paramsCondition;
/*      */   
/*      */ 
/*      */   private final HeadersRequestCondition headersCondition;
/*      */   
/*      */ 
/*      */   private final ConsumesRequestCondition consumesCondition;
/*      */   
/*      */ 
/*      */   private final ProducesRequestCondition producesCondition;
/*      */   
/*      */ 
/*      */   private final RequestConditionHolder customConditionHolder;
/*      */   
/*      */   private final int hashCode;
/*      */   
/*      */   private final BuilderConfiguration options;
/*      */   
/*      */ 
/*      */   @Deprecated
/*      */   public RequestMappingInfo(@Nullable String name, @Nullable PatternsRequestCondition patterns, @Nullable RequestMethodsRequestCondition methods, @Nullable ParamsRequestCondition params, @Nullable HeadersRequestCondition headers, @Nullable ConsumesRequestCondition consumes, @Nullable ProducesRequestCondition produces, @Nullable RequestCondition<?> custom)
/*      */   {
/*  122 */     this(name, null, patterns != null ? patterns : EMPTY_PATTERNS, methods != null ? methods : EMPTY_REQUEST_METHODS, params != null ? params : EMPTY_PARAMS, headers != null ? headers : EMPTY_HEADERS, consumes != null ? consumes : EMPTY_CONSUMES, produces != null ? produces : EMPTY_PRODUCES, custom != null ? new RequestConditionHolder(custom) : EMPTY_CUSTOM, new BuilderConfiguration());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public RequestMappingInfo(@Nullable PatternsRequestCondition patterns, @Nullable RequestMethodsRequestCondition methods, @Nullable ParamsRequestCondition params, @Nullable HeadersRequestCondition headers, @Nullable ConsumesRequestCondition consumes, @Nullable ProducesRequestCondition produces, @Nullable RequestCondition<?> custom)
/*      */   {
/*  144 */     this(null, patterns, methods, params, headers, consumes, produces, custom);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public RequestMappingInfo(RequestMappingInfo info, @Nullable RequestCondition<?> customRequestCondition)
/*      */   {
/*  153 */     this(info.name, info.patternsCondition, info.methodsCondition, info.paramsCondition, info.headersCondition, info.consumesCondition, info.producesCondition, customRequestCondition);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private RequestMappingInfo(@Nullable String name, @Nullable PathPatternsRequestCondition pathPatternsCondition, @Nullable PatternsRequestCondition patternsCondition, RequestMethodsRequestCondition methodsCondition, ParamsRequestCondition paramsCondition, HeadersRequestCondition headersCondition, ConsumesRequestCondition consumesCondition, ProducesRequestCondition producesCondition, RequestConditionHolder customCondition, BuilderConfiguration options)
/*      */   {
/*  165 */     Assert.isTrue((pathPatternsCondition != null) || (patternsCondition != null), "Neither PathPatterns nor String patterns condition");
/*      */     
/*      */ 
/*  168 */     this.name = (StringUtils.hasText(name) ? name : null);
/*  169 */     this.pathPatternsCondition = pathPatternsCondition;
/*  170 */     this.patternsCondition = patternsCondition;
/*  171 */     this.methodsCondition = methodsCondition;
/*  172 */     this.paramsCondition = paramsCondition;
/*  173 */     this.headersCondition = headersCondition;
/*  174 */     this.consumesCondition = consumesCondition;
/*  175 */     this.producesCondition = producesCondition;
/*  176 */     this.customConditionHolder = customCondition;
/*  177 */     this.options = options;
/*      */     
/*  179 */     this.hashCode = calculateHashCode(this.pathPatternsCondition, this.patternsCondition, this.methodsCondition, this.paramsCondition, this.headersCondition, this.consumesCondition, this.producesCondition, this.customConditionHolder);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Nullable
/*      */   public String getName()
/*      */   {
/*  191 */     return this.name;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Nullable
/*      */   public PathPatternsRequestCondition getPathPatternsCondition()
/*      */   {
/*  204 */     return this.pathPatternsCondition;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Nullable
/*      */   public PatternsRequestCondition getPatternsCondition()
/*      */   {
/*  215 */     return this.patternsCondition;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public <T> RequestCondition<T> getActivePatternsCondition()
/*      */   {
/*  225 */     if (this.pathPatternsCondition != null) {
/*  226 */       return this.pathPatternsCondition;
/*      */     }
/*  228 */     if (this.patternsCondition != null) {
/*  229 */       return this.patternsCondition;
/*      */     }
/*      */     
/*      */ 
/*  233 */     throw new IllegalStateException();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Set<String> getDirectPaths()
/*      */   {
/*  242 */     RequestCondition<?> condition = getActivePatternsCondition();
/*  243 */     return (condition instanceof PathPatternsRequestCondition) ? ((PathPatternsRequestCondition)condition)
/*  244 */       .getDirectPaths() : ((PatternsRequestCondition)condition)
/*  245 */       .getDirectPaths();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Set<String> getPatternValues()
/*      */   {
/*  254 */     RequestCondition<?> condition = getActivePatternsCondition();
/*  255 */     return (condition instanceof PathPatternsRequestCondition) ? ((PathPatternsRequestCondition)condition)
/*  256 */       .getPatternValues() : ((PatternsRequestCondition)condition)
/*  257 */       .getPatterns();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public RequestMethodsRequestCondition getMethodsCondition()
/*      */   {
/*  265 */     return this.methodsCondition;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public ParamsRequestCondition getParamsCondition()
/*      */   {
/*  273 */     return this.paramsCondition;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public HeadersRequestCondition getHeadersCondition()
/*      */   {
/*  281 */     return this.headersCondition;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public ConsumesRequestCondition getConsumesCondition()
/*      */   {
/*  289 */     return this.consumesCondition;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public ProducesRequestCondition getProducesCondition()
/*      */   {
/*  297 */     return this.producesCondition;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   @Nullable
/*      */   public RequestCondition<?> getCustomCondition()
/*      */   {
/*  305 */     return this.customConditionHolder.getCondition();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public RequestMappingInfo addCustomCondition(RequestCondition<?> customCondition)
/*      */   {
/*  315 */     return new RequestMappingInfo(this.name, this.pathPatternsCondition, this.patternsCondition, this.methodsCondition, this.paramsCondition, this.headersCondition, this.consumesCondition, this.producesCondition, new RequestConditionHolder(customCondition), this.options);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public RequestMappingInfo combine(RequestMappingInfo other)
/*      */   {
/*  330 */     String name = combineNames(other);
/*      */     
/*      */ 
/*      */ 
/*  334 */     PathPatternsRequestCondition pathPatterns = (this.pathPatternsCondition != null) && (other.pathPatternsCondition != null) ? this.pathPatternsCondition.combine(other.pathPatternsCondition) : null;
/*      */     
/*      */ 
/*      */ 
/*  338 */     PatternsRequestCondition patterns = (this.patternsCondition != null) && (other.patternsCondition != null) ? this.patternsCondition.combine(other.patternsCondition) : null;
/*      */     
/*  340 */     RequestMethodsRequestCondition methods = this.methodsCondition.combine(other.methodsCondition);
/*  341 */     ParamsRequestCondition params = this.paramsCondition.combine(other.paramsCondition);
/*  342 */     HeadersRequestCondition headers = this.headersCondition.combine(other.headersCondition);
/*  343 */     ConsumesRequestCondition consumes = this.consumesCondition.combine(other.consumesCondition);
/*  344 */     ProducesRequestCondition produces = this.producesCondition.combine(other.producesCondition);
/*  345 */     RequestConditionHolder custom = this.customConditionHolder.combine(other.customConditionHolder);
/*      */     
/*  347 */     return new RequestMappingInfo(name, pathPatterns, patterns, methods, params, headers, consumes, produces, custom, this.options);
/*      */   }
/*      */   
/*      */   @Nullable
/*      */   private String combineNames(RequestMappingInfo other)
/*      */   {
/*  353 */     if ((this.name != null) && (other.name != null)) {
/*  354 */       String separator = "#";
/*  355 */       return this.name + separator + other.name;
/*      */     }
/*  357 */     if (this.name != null) {
/*  358 */       return this.name;
/*      */     }
/*      */     
/*  361 */     return other.name;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Nullable
/*      */   public RequestMappingInfo getMatchingCondition(HttpServletRequest request)
/*      */   {
/*  377 */     RequestMethodsRequestCondition methods = this.methodsCondition.getMatchingCondition(request);
/*  378 */     if (methods == null) {
/*  379 */       return null;
/*      */     }
/*  381 */     ParamsRequestCondition params = this.paramsCondition.getMatchingCondition(request);
/*  382 */     if (params == null) {
/*  383 */       return null;
/*      */     }
/*  385 */     HeadersRequestCondition headers = this.headersCondition.getMatchingCondition(request);
/*  386 */     if (headers == null) {
/*  387 */       return null;
/*      */     }
/*  389 */     ConsumesRequestCondition consumes = this.consumesCondition.getMatchingCondition(request);
/*  390 */     if (consumes == null) {
/*  391 */       return null;
/*      */     }
/*  393 */     ProducesRequestCondition produces = this.producesCondition.getMatchingCondition(request);
/*  394 */     if (produces == null) {
/*  395 */       return null;
/*      */     }
/*  397 */     PathPatternsRequestCondition pathPatterns = null;
/*  398 */     if (this.pathPatternsCondition != null) {
/*  399 */       pathPatterns = this.pathPatternsCondition.getMatchingCondition(request);
/*  400 */       if (pathPatterns == null) {
/*  401 */         return null;
/*      */       }
/*      */     }
/*  404 */     PatternsRequestCondition patterns = null;
/*  405 */     if (this.patternsCondition != null) {
/*  406 */       patterns = this.patternsCondition.getMatchingCondition(request);
/*  407 */       if (patterns == null) {
/*  408 */         return null;
/*      */       }
/*      */     }
/*  411 */     RequestConditionHolder custom = this.customConditionHolder.getMatchingCondition(request);
/*  412 */     if (custom == null) {
/*  413 */       return null;
/*      */     }
/*  415 */     return new RequestMappingInfo(this.name, pathPatterns, patterns, methods, params, headers, consumes, produces, custom, this.options);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int compareTo(RequestMappingInfo other, HttpServletRequest request)
/*      */   {
/*  430 */     if (HttpMethod.HEAD.matches(request.getMethod())) {
/*  431 */       int result = this.methodsCondition.compareTo(other.getMethodsCondition(), request);
/*  432 */       if (result != 0) {
/*  433 */         return result;
/*      */       }
/*      */     }
/*  436 */     int result = getActivePatternsCondition().compareTo(other.getActivePatternsCondition(), request);
/*  437 */     if (result != 0) {
/*  438 */       return result;
/*      */     }
/*  440 */     result = this.paramsCondition.compareTo(other.getParamsCondition(), request);
/*  441 */     if (result != 0) {
/*  442 */       return result;
/*      */     }
/*  444 */     result = this.headersCondition.compareTo(other.getHeadersCondition(), request);
/*  445 */     if (result != 0) {
/*  446 */       return result;
/*      */     }
/*  448 */     result = this.consumesCondition.compareTo(other.getConsumesCondition(), request);
/*  449 */     if (result != 0) {
/*  450 */       return result;
/*      */     }
/*  452 */     result = this.producesCondition.compareTo(other.getProducesCondition(), request);
/*  453 */     if (result != 0) {
/*  454 */       return result;
/*      */     }
/*      */     
/*  457 */     result = this.methodsCondition.compareTo(other.getMethodsCondition(), request);
/*  458 */     if (result != 0) {
/*  459 */       return result;
/*      */     }
/*  461 */     result = this.customConditionHolder.compareTo(other.customConditionHolder, request);
/*  462 */     if (result != 0) {
/*  463 */       return result;
/*      */     }
/*  465 */     return 0;
/*      */   }
/*      */   
/*      */   public boolean equals(@Nullable Object other)
/*      */   {
/*  470 */     if (this == other) {
/*  471 */       return true;
/*      */     }
/*  473 */     if (!(other instanceof RequestMappingInfo)) {
/*  474 */       return false;
/*      */     }
/*  476 */     RequestMappingInfo otherInfo = (RequestMappingInfo)other;
/*  477 */     return (getActivePatternsCondition().equals(otherInfo.getActivePatternsCondition())) && 
/*  478 */       (this.methodsCondition.equals(otherInfo.methodsCondition)) && 
/*  479 */       (this.paramsCondition.equals(otherInfo.paramsCondition)) && 
/*  480 */       (this.headersCondition.equals(otherInfo.headersCondition)) && 
/*  481 */       (this.consumesCondition.equals(otherInfo.consumesCondition)) && 
/*  482 */       (this.producesCondition.equals(otherInfo.producesCondition)) && 
/*  483 */       (this.customConditionHolder.equals(otherInfo.customConditionHolder));
/*      */   }
/*      */   
/*      */   public int hashCode()
/*      */   {
/*  488 */     return this.hashCode;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static int calculateHashCode(@Nullable PathPatternsRequestCondition pathPatterns, @Nullable PatternsRequestCondition patterns, RequestMethodsRequestCondition methods, ParamsRequestCondition params, HeadersRequestCondition headers, ConsumesRequestCondition consumes, ProducesRequestCondition produces, RequestConditionHolder custom)
/*      */   {
/*  497 */     return 
/*      */     
/*      */ 
/*  500 */       (pathPatterns != null ? pathPatterns : patterns).hashCode() * 31 + methods.hashCode() + params.hashCode() + headers.hashCode() + consumes.hashCode() + produces.hashCode() + custom.hashCode();
/*      */   }
/*      */   
/*      */   public String toString()
/*      */   {
/*  505 */     StringBuilder builder = new StringBuilder("{");
/*  506 */     if (!this.methodsCondition.isEmpty()) {
/*  507 */       Set<RequestMethod> httpMethods = this.methodsCondition.getMethods();
/*  508 */       builder.append(httpMethods.size() == 1 ? httpMethods.iterator().next() : httpMethods);
/*      */     }
/*      */     
/*      */ 
/*  512 */     builder.append(' ').append(getActivePatternsCondition());
/*      */     
/*  514 */     if (!this.paramsCondition.isEmpty()) {
/*  515 */       builder.append(", params ").append(this.paramsCondition);
/*      */     }
/*  517 */     if (!this.headersCondition.isEmpty()) {
/*  518 */       builder.append(", headers ").append(this.headersCondition);
/*      */     }
/*  520 */     if (!this.consumesCondition.isEmpty()) {
/*  521 */       builder.append(", consumes ").append(this.consumesCondition);
/*      */     }
/*  523 */     if (!this.producesCondition.isEmpty()) {
/*  524 */       builder.append(", produces ").append(this.producesCondition);
/*      */     }
/*  526 */     if (!this.customConditionHolder.isEmpty()) {
/*  527 */       builder.append(", and ").append(this.customConditionHolder);
/*      */     }
/*  529 */     builder.append('}');
/*  530 */     return builder.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Builder mutate()
/*      */   {
/*  539 */     return new MutateBuilder(this);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Builder paths(String... paths)
/*      */   {
/*  549 */     return new DefaultBuilder(paths);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static abstract interface Builder
/*      */   {
/*      */     public abstract Builder paths(String... paramVarArgs);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public abstract Builder methods(RequestMethod... paramVarArgs);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public abstract Builder params(String... paramVarArgs);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public abstract Builder headers(String... paramVarArgs);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public abstract Builder consumes(String... paramVarArgs);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public abstract Builder produces(String... paramVarArgs);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public abstract Builder mappingName(String paramString);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public abstract Builder customCondition(RequestCondition<?> paramRequestCondition);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public abstract Builder options(RequestMappingInfo.BuilderConfiguration paramBuilderConfiguration);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public abstract RequestMappingInfo build();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private static class DefaultBuilder
/*      */     implements RequestMappingInfo.Builder
/*      */   {
/*      */     private String[] paths;
/*      */     
/*      */ 
/*      */ 
/*  616 */     private RequestMethod[] methods = new RequestMethod[0];
/*      */     
/*  618 */     private String[] params = new String[0];
/*      */     
/*  620 */     private String[] headers = new String[0];
/*      */     
/*  622 */     private String[] consumes = new String[0];
/*      */     
/*  624 */     private String[] produces = new String[0];
/*      */     
/*      */     private boolean hasContentType;
/*      */     
/*      */     private boolean hasAccept;
/*      */     
/*      */     @Nullable
/*      */     private String mappingName;
/*      */     
/*      */     @Nullable
/*      */     private RequestCondition<?> customCondition;
/*      */     
/*  636 */     private RequestMappingInfo.BuilderConfiguration options = new RequestMappingInfo.BuilderConfiguration();
/*      */     
/*      */     public DefaultBuilder(String... paths) {
/*  639 */       this.paths = paths;
/*      */     }
/*      */     
/*      */     public RequestMappingInfo.Builder paths(String... paths)
/*      */     {
/*  644 */       this.paths = paths;
/*  645 */       return this;
/*      */     }
/*      */     
/*      */     public DefaultBuilder methods(RequestMethod... methods)
/*      */     {
/*  650 */       this.methods = methods;
/*  651 */       return this;
/*      */     }
/*      */     
/*      */     public DefaultBuilder params(String... params)
/*      */     {
/*  656 */       this.params = params;
/*  657 */       return this;
/*      */     }
/*      */     
/*      */     public DefaultBuilder headers(String... headers)
/*      */     {
/*  662 */       for (String header : headers)
/*      */       {
/*  664 */         this.hasContentType = ((this.hasContentType) || (header.contains("Content-Type")) || (header.contains("content-type")));
/*      */         
/*  666 */         this.hasAccept = ((this.hasAccept) || (header.contains("Accept")) || (header.contains("accept")));
/*      */       }
/*  668 */       this.headers = headers;
/*  669 */       return this;
/*      */     }
/*      */     
/*      */     public DefaultBuilder consumes(String... consumes)
/*      */     {
/*  674 */       this.consumes = consumes;
/*  675 */       return this;
/*      */     }
/*      */     
/*      */     public DefaultBuilder produces(String... produces)
/*      */     {
/*  680 */       this.produces = produces;
/*  681 */       return this;
/*      */     }
/*      */     
/*      */     public DefaultBuilder mappingName(String name)
/*      */     {
/*  686 */       this.mappingName = name;
/*  687 */       return this;
/*      */     }
/*      */     
/*      */     public DefaultBuilder customCondition(RequestCondition<?> condition)
/*      */     {
/*  692 */       this.customCondition = condition;
/*  693 */       return this;
/*      */     }
/*      */     
/*      */     public RequestMappingInfo.Builder options(RequestMappingInfo.BuilderConfiguration options)
/*      */     {
/*  698 */       this.options = options;
/*  699 */       return this;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public RequestMappingInfo build()
/*      */     {
/*  706 */       PathPatternsRequestCondition pathPatterns = null;
/*  707 */       PatternsRequestCondition patterns = null;
/*      */       
/*  709 */       if (this.options.patternParser != null)
/*      */       {
/*      */ 
/*  712 */         pathPatterns = ObjectUtils.isEmpty(this.paths) ? RequestMappingInfo.EMPTY_PATH_PATTERNS : new PathPatternsRequestCondition(this.options.patternParser, this.paths);
/*      */ 
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/*      */ 
/*  720 */         patterns = ObjectUtils.isEmpty(this.paths) ? RequestMappingInfo.EMPTY_PATTERNS : new PatternsRequestCondition(this.paths, null, this.options.getPathMatcher(), this.options.useSuffixPatternMatch(), this.options.useTrailingSlashMatch(), this.options.getFileExtensions());
/*      */       }
/*      */       
/*  723 */       ContentNegotiationManager manager = this.options.getContentNegotiationManager();
/*      */       
/*  725 */       return new RequestMappingInfo(this.mappingName, pathPatterns, patterns, 
/*      */       
/*  727 */         ObjectUtils.isEmpty(this.methods) ? 
/*  728 */         RequestMappingInfo.EMPTY_REQUEST_METHODS : new RequestMethodsRequestCondition(this.methods), 
/*  729 */         ObjectUtils.isEmpty(this.params) ? 
/*  730 */         RequestMappingInfo.EMPTY_PARAMS : new ParamsRequestCondition(this.params), 
/*  731 */         ObjectUtils.isEmpty(this.headers) ? 
/*  732 */         RequestMappingInfo.EMPTY_HEADERS : new HeadersRequestCondition(this.headers), 
/*  733 */         (ObjectUtils.isEmpty(this.consumes)) && (!this.hasContentType) ? 
/*  734 */         RequestMappingInfo.EMPTY_CONSUMES : new ConsumesRequestCondition(this.consumes, this.headers), 
/*  735 */         (ObjectUtils.isEmpty(this.produces)) && (!this.hasAccept) ? 
/*  736 */         RequestMappingInfo.EMPTY_PRODUCES : new ProducesRequestCondition(this.produces, this.headers, manager), this.customCondition != null ? new RequestConditionHolder(this.customCondition) : 
/*      */         
/*  738 */         RequestMappingInfo.EMPTY_CUSTOM, this.options, null);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private static class MutateBuilder
/*      */     implements RequestMappingInfo.Builder
/*      */   {
/*      */     @Nullable
/*      */     private String name;
/*      */     
/*      */     @Nullable
/*      */     private PathPatternsRequestCondition pathPatternsCondition;
/*      */     
/*      */     @Nullable
/*      */     private PatternsRequestCondition patternsCondition;
/*      */     
/*      */     private RequestMethodsRequestCondition methodsCondition;
/*      */     
/*      */     private ParamsRequestCondition paramsCondition;
/*      */     
/*      */     private HeadersRequestCondition headersCondition;
/*      */     
/*      */     private ConsumesRequestCondition consumesCondition;
/*      */     
/*      */     private ProducesRequestCondition producesCondition;
/*      */     
/*      */     private RequestConditionHolder customConditionHolder;
/*      */     private RequestMappingInfo.BuilderConfiguration options;
/*      */     
/*      */     public MutateBuilder(RequestMappingInfo other)
/*      */     {
/*  770 */       this.name = other.name;
/*  771 */       this.pathPatternsCondition = other.pathPatternsCondition;
/*  772 */       this.patternsCondition = other.patternsCondition;
/*  773 */       this.methodsCondition = other.methodsCondition;
/*  774 */       this.paramsCondition = other.paramsCondition;
/*  775 */       this.headersCondition = other.headersCondition;
/*  776 */       this.consumesCondition = other.consumesCondition;
/*  777 */       this.producesCondition = other.producesCondition;
/*  778 */       this.customConditionHolder = other.customConditionHolder;
/*  779 */       this.options = other.options;
/*      */     }
/*      */     
/*      */ 
/*      */     public RequestMappingInfo.Builder paths(String... paths)
/*      */     {
/*  785 */       if (this.options.patternParser != null)
/*      */       {
/*  787 */         this.pathPatternsCondition = (ObjectUtils.isEmpty(paths) ? RequestMappingInfo.EMPTY_PATH_PATTERNS : new PathPatternsRequestCondition(this.options.patternParser, paths));
/*      */ 
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/*      */ 
/*  795 */         this.patternsCondition = (ObjectUtils.isEmpty(paths) ? RequestMappingInfo.EMPTY_PATTERNS : new PatternsRequestCondition(paths, null, this.options.getPathMatcher(), this.options.useSuffixPatternMatch(), this.options.useTrailingSlashMatch(), this.options.getFileExtensions()));
/*      */       }
/*  797 */       return this;
/*      */     }
/*      */     
/*      */ 
/*      */     public RequestMappingInfo.Builder methods(RequestMethod... methods)
/*      */     {
/*  803 */       this.methodsCondition = (ObjectUtils.isEmpty(methods) ? RequestMappingInfo.EMPTY_REQUEST_METHODS : new RequestMethodsRequestCondition(methods));
/*  804 */       return this;
/*      */     }
/*      */     
/*      */ 
/*      */     public RequestMappingInfo.Builder params(String... params)
/*      */     {
/*  810 */       this.paramsCondition = (ObjectUtils.isEmpty(params) ? RequestMappingInfo.EMPTY_PARAMS : new ParamsRequestCondition(params));
/*  811 */       return this;
/*      */     }
/*      */     
/*      */ 
/*      */     public RequestMappingInfo.Builder headers(String... headers)
/*      */     {
/*  817 */       this.headersCondition = (ObjectUtils.isEmpty(headers) ? RequestMappingInfo.EMPTY_HEADERS : new HeadersRequestCondition(headers));
/*  818 */       return this;
/*      */     }
/*      */     
/*      */ 
/*      */     public RequestMappingInfo.Builder consumes(String... consumes)
/*      */     {
/*  824 */       this.consumesCondition = (ObjectUtils.isEmpty(consumes) ? RequestMappingInfo.EMPTY_CONSUMES : new ConsumesRequestCondition(consumes));
/*  825 */       return this;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public RequestMappingInfo.Builder produces(String... produces)
/*      */     {
/*  832 */       this.producesCondition = (ObjectUtils.isEmpty(produces) ? RequestMappingInfo.EMPTY_PRODUCES : new ProducesRequestCondition(produces, null, this.options.getContentNegotiationManager()));
/*  833 */       return this;
/*      */     }
/*      */     
/*      */     public RequestMappingInfo.Builder mappingName(String name)
/*      */     {
/*  838 */       this.name = name;
/*  839 */       return this;
/*      */     }
/*      */     
/*      */     public RequestMappingInfo.Builder customCondition(RequestCondition<?> condition)
/*      */     {
/*  844 */       this.customConditionHolder = new RequestConditionHolder(condition);
/*  845 */       return this;
/*      */     }
/*      */     
/*      */     public RequestMappingInfo.Builder options(RequestMappingInfo.BuilderConfiguration options)
/*      */     {
/*  850 */       this.options = options;
/*  851 */       return this;
/*      */     }
/*      */     
/*      */     public RequestMappingInfo build()
/*      */     {
/*  856 */       return new RequestMappingInfo(this.name, this.pathPatternsCondition, this.patternsCondition, this.methodsCondition, this.paramsCondition, this.headersCondition, this.consumesCondition, this.producesCondition, this.customConditionHolder, this.options, null);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static class BuilderConfiguration
/*      */   {
/*      */     @Nullable
/*      */     private PathPatternParser patternParser;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     @Nullable
/*      */     private PathMatcher pathMatcher;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  880 */     private boolean trailingSlashMatch = true;
/*      */     
/*  882 */     private boolean suffixPatternMatch = false;
/*      */     
/*  884 */     private boolean registeredSuffixPatternMatch = false;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     @Nullable
/*      */     private ContentNegotiationManager contentNegotiationManager;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void setPatternParser(@Nullable PathPatternParser patternParser)
/*      */     {
/*  899 */       this.patternParser = patternParser;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     @Nullable
/*      */     public PathPatternParser getPatternParser()
/*      */     {
/*  909 */       return this.patternParser;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     @Deprecated
/*      */     public void setUrlPathHelper(@Nullable UrlPathHelper urlPathHelper) {}
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     @Nullable
/*      */     @Deprecated
/*      */     public UrlPathHelper getUrlPathHelper()
/*      */     {
/*  932 */       return UrlPathHelper.defaultInstance;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public void setPathMatcher(@Nullable PathMatcher pathMatcher)
/*      */     {
/*  940 */       this.pathMatcher = pathMatcher;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     @Nullable
/*      */     public PathMatcher getPathMatcher()
/*      */     {
/*  948 */       return this.pathMatcher;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public void setTrailingSlashMatch(boolean trailingSlashMatch)
/*      */     {
/*  956 */       this.trailingSlashMatch = trailingSlashMatch;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public boolean useTrailingSlashMatch()
/*      */     {
/*  963 */       return this.trailingSlashMatch;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     @Deprecated
/*      */     public void setSuffixPatternMatch(boolean suffixPatternMatch)
/*      */     {
/*  975 */       this.suffixPatternMatch = suffixPatternMatch;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     @Deprecated
/*      */     public boolean useSuffixPatternMatch()
/*      */     {
/*  985 */       return this.suffixPatternMatch;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     @Deprecated
/*      */     public void setRegisteredSuffixPatternMatch(boolean registeredSuffixPatternMatch)
/*      */     {
/* 1000 */       this.registeredSuffixPatternMatch = registeredSuffixPatternMatch;
/* 1001 */       this.suffixPatternMatch = ((registeredSuffixPatternMatch) || (this.suffixPatternMatch));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     @Deprecated
/*      */     public boolean useRegisteredSuffixPatternMatch()
/*      */     {
/* 1013 */       return this.registeredSuffixPatternMatch;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     @Nullable
/*      */     @Deprecated
/*      */     public List<String> getFileExtensions()
/*      */     {
/* 1027 */       if ((useRegisteredSuffixPatternMatch()) && (this.contentNegotiationManager != null)) {
/* 1028 */         return this.contentNegotiationManager.getAllFileExtensions();
/*      */       }
/* 1030 */       return null;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public void setContentNegotiationManager(ContentNegotiationManager contentNegotiationManager)
/*      */     {
/* 1038 */       this.contentNegotiationManager = contentNegotiationManager;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     @Nullable
/*      */     public ContentNegotiationManager getContentNegotiationManager()
/*      */     {
/* 1047 */       return this.contentNegotiationManager;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\mvc\method\RequestMappingInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */