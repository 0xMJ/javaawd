package org.springframework.web.servlet.function;

@FunctionalInterface
public abstract interface HandlerFunction<T extends ServerResponse>
{
  public abstract T handle(ServerRequest paramServerRequest)
    throws Exception;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\function\HandlerFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */