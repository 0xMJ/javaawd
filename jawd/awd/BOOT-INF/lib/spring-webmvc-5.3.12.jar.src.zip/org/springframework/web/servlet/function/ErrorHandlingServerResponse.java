/*     */ package org.springframework.web.servlet.function;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.Predicate;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.servlet.ModelAndView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class ErrorHandlingServerResponse
/*     */   implements ServerResponse
/*     */ {
/*  43 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/*  45 */   private final List<ErrorHandler<?>> errorHandlers = new ArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */   protected final <T extends ServerResponse> void addErrorHandler(Predicate<Throwable> predicate, BiFunction<Throwable, ServerRequest, T> errorHandler)
/*     */   {
/*  51 */     Assert.notNull(predicate, "Predicate must not be null");
/*  52 */     Assert.notNull(errorHandler, "ErrorHandler must not be null");
/*  53 */     this.errorHandlers.add(new ErrorHandler(predicate, errorHandler));
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   protected final ModelAndView handleError(Throwable t, HttpServletRequest servletRequest, HttpServletResponse servletResponse, ServerResponse.Context context)
/*     */     throws ServletException, IOException
/*     */   {
/*  60 */     ServerResponse serverResponse = errorResponse(t, servletRequest);
/*  61 */     if (serverResponse != null) {
/*  62 */       return serverResponse.writeTo(servletRequest, servletResponse, context);
/*     */     }
/*  64 */     if ((t instanceof ServletException)) {
/*  65 */       throw ((ServletException)t);
/*     */     }
/*  67 */     if ((t instanceof IOException)) {
/*  68 */       throw ((IOException)t);
/*     */     }
/*     */     
/*  71 */     throw new ServletException(t);
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   protected final ServerResponse errorResponse(Throwable t, HttpServletRequest servletRequest)
/*     */   {
/*  77 */     for (ErrorHandler<?> errorHandler : this.errorHandlers) {
/*  78 */       if (errorHandler.test(t))
/*     */       {
/*  80 */         ServerRequest serverRequest = (ServerRequest)servletRequest.getAttribute(RouterFunctions.REQUEST_ATTRIBUTE);
/*  81 */         return errorHandler.handle(t, serverRequest);
/*     */       }
/*     */     }
/*  84 */     return null;
/*     */   }
/*     */   
/*     */   private static class ErrorHandler<T extends ServerResponse>
/*     */   {
/*     */     private final Predicate<Throwable> predicate;
/*     */     private final BiFunction<Throwable, ServerRequest, T> responseProvider;
/*     */     
/*     */     public ErrorHandler(Predicate<Throwable> predicate, BiFunction<Throwable, ServerRequest, T> responseProvider)
/*     */     {
/*  94 */       Assert.notNull(predicate, "Predicate must not be null");
/*  95 */       Assert.notNull(responseProvider, "ResponseProvider must not be null");
/*  96 */       this.predicate = predicate;
/*  97 */       this.responseProvider = responseProvider;
/*     */     }
/*     */     
/*     */     public boolean test(Throwable t) {
/* 101 */       return this.predicate.test(t);
/*     */     }
/*     */     
/*     */     public T handle(Throwable t, ServerRequest serverRequest) {
/* 105 */       return (ServerResponse)this.responseProvider.apply(t, serverRequest);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\function\ErrorHandlingServerResponse.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */