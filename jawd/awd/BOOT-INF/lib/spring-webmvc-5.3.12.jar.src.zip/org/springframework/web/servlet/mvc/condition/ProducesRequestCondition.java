/*     */ package org.springframework.web.servlet.mvc.condition;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.HttpMediaTypeException;
/*     */ import org.springframework.web.HttpMediaTypeNotAcceptableException;
/*     */ import org.springframework.web.accept.ContentNegotiationManager;
/*     */ import org.springframework.web.context.request.ServletWebRequest;
/*     */ import org.springframework.web.cors.CorsUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ProducesRequestCondition
/*     */   extends AbstractRequestCondition<ProducesRequestCondition>
/*     */ {
/*  53 */   private static final ContentNegotiationManager DEFAULT_CONTENT_NEGOTIATION_MANAGER = new ContentNegotiationManager();
/*     */   
/*     */ 
/*  56 */   private static final ProducesRequestCondition EMPTY_CONDITION = new ProducesRequestCondition(new String[0]);
/*     */   
/*     */ 
/*  59 */   private static final List<ProduceMediaTypeExpression> MEDIA_TYPE_ALL_LIST = Collections.singletonList(new ProduceMediaTypeExpression("*/*"));
/*     */   
/*  61 */   private static final String MEDIA_TYPES_ATTRIBUTE = ProducesRequestCondition.class.getName() + ".MEDIA_TYPES";
/*     */   
/*     */ 
/*     */ 
/*     */   private final List<ProduceMediaTypeExpression> expressions;
/*     */   
/*     */ 
/*     */ 
/*     */   private final ContentNegotiationManager contentNegotiationManager;
/*     */   
/*     */ 
/*     */ 
/*     */   public ProducesRequestCondition(String... produces)
/*     */   {
/*  75 */     this(produces, null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ProducesRequestCondition(String[] produces, @Nullable String[] headers)
/*     */   {
/*  87 */     this(produces, headers, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ProducesRequestCondition(String[] produces, @Nullable String[] headers, @Nullable ContentNegotiationManager manager)
/*     */   {
/* 100 */     this.expressions = parseExpressions(produces, headers);
/* 101 */     if (this.expressions.size() > 1) {
/* 102 */       Collections.sort(this.expressions);
/*     */     }
/* 104 */     this.contentNegotiationManager = (manager != null ? manager : DEFAULT_CONTENT_NEGOTIATION_MANAGER);
/*     */   }
/*     */   
/*     */   private List<ProduceMediaTypeExpression> parseExpressions(String[] produces, @Nullable String[] headers) {
/* 108 */     Set<ProduceMediaTypeExpression> result = null;
/* 109 */     if (!ObjectUtils.isEmpty(headers)) { HeadersRequestCondition.HeaderExpression expr;
/* 110 */       for (String header : headers) {
/* 111 */         expr = new HeadersRequestCondition.HeaderExpression(header);
/* 112 */         if (("Accept".equalsIgnoreCase(expr.name)) && (expr.value != null)) {
/* 113 */           for (MediaType mediaType : MediaType.parseMediaTypes((String)expr.value)) {
/* 114 */             result = result != null ? result : new LinkedHashSet();
/* 115 */             result.add(new ProduceMediaTypeExpression(mediaType, expr.isNegated));
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 120 */     if (!ObjectUtils.isEmpty(produces)) {
/* 121 */       for (String produce : produces) {
/* 122 */         result = result != null ? result : new LinkedHashSet();
/* 123 */         result.add(new ProduceMediaTypeExpression(produce));
/*     */       }
/*     */     }
/* 126 */     return result != null ? new ArrayList(result) : Collections.emptyList();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private ProducesRequestCondition(List<ProduceMediaTypeExpression> expressions, ProducesRequestCondition other)
/*     */   {
/* 134 */     this.expressions = expressions;
/* 135 */     this.contentNegotiationManager = other.contentNegotiationManager;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Set<MediaTypeExpression> getExpressions()
/*     */   {
/* 143 */     return new LinkedHashSet(this.expressions);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Set<MediaType> getProducibleMediaTypes()
/*     */   {
/* 150 */     Set<MediaType> result = new LinkedHashSet();
/* 151 */     for (ProduceMediaTypeExpression expression : this.expressions) {
/* 152 */       if (!expression.isNegated()) {
/* 153 */         result.add(expression.getMediaType());
/*     */       }
/*     */     }
/* 156 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isEmpty()
/*     */   {
/* 164 */     return this.expressions.isEmpty();
/*     */   }
/*     */   
/*     */   protected List<ProduceMediaTypeExpression> getContent()
/*     */   {
/* 169 */     return this.expressions;
/*     */   }
/*     */   
/*     */   protected String getToStringInfix()
/*     */   {
/* 174 */     return " || ";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ProducesRequestCondition combine(ProducesRequestCondition other)
/*     */   {
/* 184 */     return !other.expressions.isEmpty() ? other : this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public ProducesRequestCondition getMatchingCondition(HttpServletRequest request)
/*     */   {
/* 200 */     if (CorsUtils.isPreFlightRequest(request)) {
/* 201 */       return EMPTY_CONDITION;
/*     */     }
/* 203 */     if (isEmpty()) {
/* 204 */       return this;
/*     */     }
/*     */     try
/*     */     {
/* 208 */       acceptedMediaTypes = getAcceptedMediaTypes(request);
/*     */     } catch (HttpMediaTypeException ex) {
/*     */       List<MediaType> acceptedMediaTypes;
/* 211 */       return null; }
/*     */     List<MediaType> acceptedMediaTypes;
/* 213 */     List<ProduceMediaTypeExpression> result = getMatchingExpressions(acceptedMediaTypes);
/* 214 */     if (!CollectionUtils.isEmpty(result)) {
/* 215 */       return new ProducesRequestCondition(result, this);
/*     */     }
/* 217 */     if (MediaType.ALL.isPresentIn(acceptedMediaTypes)) {
/* 218 */       return EMPTY_CONDITION;
/*     */     }
/*     */     
/* 221 */     return null;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private List<ProduceMediaTypeExpression> getMatchingExpressions(List<MediaType> acceptedMediaTypes)
/*     */   {
/* 227 */     List<ProduceMediaTypeExpression> result = null;
/* 228 */     for (ProduceMediaTypeExpression expression : this.expressions) {
/* 229 */       if (expression.match(acceptedMediaTypes)) {
/* 230 */         result = result != null ? result : new ArrayList();
/* 231 */         result.add(expression);
/*     */       }
/*     */     }
/* 234 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int compareTo(ProducesRequestCondition other, HttpServletRequest request)
/*     */   {
/*     */     try
/*     */     {
/* 257 */       List<MediaType> acceptedMediaTypes = getAcceptedMediaTypes(request);
/* 258 */       for (MediaType acceptedMediaType : acceptedMediaTypes) {
/* 259 */         int thisIndex = indexOfEqualMediaType(acceptedMediaType);
/* 260 */         int otherIndex = other.indexOfEqualMediaType(acceptedMediaType);
/* 261 */         int result = compareMatchingMediaTypes(this, thisIndex, other, otherIndex);
/* 262 */         if (result != 0) {
/* 263 */           return result;
/*     */         }
/* 265 */         thisIndex = indexOfIncludedMediaType(acceptedMediaType);
/* 266 */         otherIndex = other.indexOfIncludedMediaType(acceptedMediaType);
/* 267 */         result = compareMatchingMediaTypes(this, thisIndex, other, otherIndex);
/* 268 */         if (result != 0) {
/* 269 */           return result;
/*     */         }
/*     */       }
/* 272 */       return 0;
/*     */     }
/*     */     catch (HttpMediaTypeNotAcceptableException ex)
/*     */     {
/* 276 */       throw new IllegalStateException("Cannot compare without having any requested media types", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private List<MediaType> getAcceptedMediaTypes(HttpServletRequest request)
/*     */     throws HttpMediaTypeNotAcceptableException
/*     */   {
/* 284 */     List<MediaType> result = (List)request.getAttribute(MEDIA_TYPES_ATTRIBUTE);
/* 285 */     if (result == null) {
/* 286 */       result = this.contentNegotiationManager.resolveMediaTypes(new ServletWebRequest(request));
/* 287 */       request.setAttribute(MEDIA_TYPES_ATTRIBUTE, result);
/*     */     }
/* 289 */     return result;
/*     */   }
/*     */   
/*     */   private int indexOfEqualMediaType(MediaType mediaType) {
/* 293 */     for (int i = 0; i < getExpressionsToCompare().size(); i++) {
/* 294 */       MediaType currentMediaType = ((ProduceMediaTypeExpression)getExpressionsToCompare().get(i)).getMediaType();
/* 295 */       if ((mediaType.getType().equalsIgnoreCase(currentMediaType.getType())) && 
/* 296 */         (mediaType.getSubtype().equalsIgnoreCase(currentMediaType.getSubtype()))) {
/* 297 */         return i;
/*     */       }
/*     */     }
/* 300 */     return -1;
/*     */   }
/*     */   
/*     */   private int indexOfIncludedMediaType(MediaType mediaType) {
/* 304 */     for (int i = 0; i < getExpressionsToCompare().size(); i++) {
/* 305 */       if (mediaType.includes(((ProduceMediaTypeExpression)getExpressionsToCompare().get(i)).getMediaType())) {
/* 306 */         return i;
/*     */       }
/*     */     }
/* 309 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */   private int compareMatchingMediaTypes(ProducesRequestCondition condition1, int index1, ProducesRequestCondition condition2, int index2)
/*     */   {
/* 315 */     int result = 0;
/* 316 */     if (index1 != index2) {
/* 317 */       result = index2 - index1;
/*     */     }
/* 319 */     else if (index1 != -1) {
/* 320 */       ProduceMediaTypeExpression expr1 = (ProduceMediaTypeExpression)condition1.getExpressionsToCompare().get(index1);
/* 321 */       ProduceMediaTypeExpression expr2 = (ProduceMediaTypeExpression)condition2.getExpressionsToCompare().get(index2);
/* 322 */       result = expr1.compareTo(expr2);
/* 323 */       result = result != 0 ? result : expr1.getMediaType().compareTo(expr2.getMediaType());
/*     */     }
/* 325 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private List<ProduceMediaTypeExpression> getExpressionsToCompare()
/*     */   {
/* 333 */     return this.expressions.isEmpty() ? MEDIA_TYPE_ALL_LIST : this.expressions;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void clearMediaTypesAttribute(HttpServletRequest request)
/*     */   {
/* 344 */     request.removeAttribute(MEDIA_TYPES_ATTRIBUTE);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   static class ProduceMediaTypeExpression
/*     */     extends AbstractMediaTypeExpression
/*     */   {
/*     */     ProduceMediaTypeExpression(MediaType mediaType, boolean negated)
/*     */     {
/* 354 */       super(negated);
/*     */     }
/*     */     
/*     */     ProduceMediaTypeExpression(String expression) {
/* 358 */       super();
/*     */     }
/*     */     
/*     */     public final boolean match(List<MediaType> acceptedMediaTypes) {
/* 362 */       boolean match = matchMediaType(acceptedMediaTypes);
/* 363 */       return (!isNegated()) == match;
/*     */     }
/*     */     
/*     */     private boolean matchMediaType(List<MediaType> acceptedMediaTypes) {
/* 367 */       for (MediaType acceptedMediaType : acceptedMediaTypes) {
/* 368 */         if ((getMediaType().isCompatibleWith(acceptedMediaType)) && (matchParameters(acceptedMediaType))) {
/* 369 */           return true;
/*     */         }
/*     */       }
/* 372 */       return false;
/*     */     }
/*     */     
/*     */     private boolean matchParameters(MediaType acceptedMediaType) {
/* 376 */       for (String name : getMediaType().getParameters().keySet()) {
/* 377 */         String s1 = getMediaType().getParameter(name);
/* 378 */         String s2 = acceptedMediaType.getParameter(name);
/* 379 */         if ((StringUtils.hasText(s1)) && (StringUtils.hasText(s2)) && (!s1.equalsIgnoreCase(s2))) {
/* 380 */           return false;
/*     */         }
/*     */       }
/* 383 */       return true;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\mvc\condition\ProducesRequestCondition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */