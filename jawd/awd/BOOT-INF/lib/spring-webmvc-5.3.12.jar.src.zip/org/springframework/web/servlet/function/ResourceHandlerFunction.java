/*     */ package org.springframework.web.servlet.function;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import java.util.EnumSet;
/*     */ import java.util.Set;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.HttpStatus;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ResourceHandlerFunction
/*     */   implements HandlerFunction<ServerResponse>
/*     */ {
/*  42 */   private static final Set<HttpMethod> SUPPORTED_METHODS = EnumSet.of(HttpMethod.GET, HttpMethod.HEAD, HttpMethod.OPTIONS);
/*     */   
/*     */   private final Resource resource;
/*     */   
/*     */ 
/*     */   public ResourceHandlerFunction(Resource resource)
/*     */   {
/*  49 */     this.resource = resource;
/*     */   }
/*     */   
/*     */ 
/*     */   public ServerResponse handle(ServerRequest request)
/*     */   {
/*  55 */     HttpMethod method = request.method();
/*  56 */     if (method != null) {
/*  57 */       switch (method) {
/*     */       case GET: 
/*  59 */         return EntityResponse.fromObject(this.resource).build();
/*     */       case HEAD: 
/*  61 */         Resource headResource = new HeadMethodResource(this.resource);
/*  62 */         return EntityResponse.fromObject(headResource).build();
/*     */       case OPTIONS: 
/*  64 */         return 
/*  65 */           ((ServerResponse.BodyBuilder)ServerResponse.ok().allow(SUPPORTED_METHODS)).build();
/*     */       }
/*     */     }
/*  68 */     return 
/*  69 */       ((ServerResponse.BodyBuilder)ServerResponse.status(HttpStatus.METHOD_NOT_ALLOWED).allow(SUPPORTED_METHODS)).build();
/*     */   }
/*     */   
/*     */   private static class HeadMethodResource
/*     */     implements Resource
/*     */   {
/*  75 */     private static final byte[] EMPTY = new byte[0];
/*     */     private final Resource delegate;
/*     */     
/*     */     public HeadMethodResource(Resource delegate)
/*     */     {
/*  80 */       this.delegate = delegate;
/*     */     }
/*     */     
/*     */     public InputStream getInputStream() throws IOException
/*     */     {
/*  85 */       return new ByteArrayInputStream(EMPTY);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public boolean exists()
/*     */     {
/*  92 */       return this.delegate.exists();
/*     */     }
/*     */     
/*     */     public URL getURL() throws IOException
/*     */     {
/*  97 */       return this.delegate.getURL();
/*     */     }
/*     */     
/*     */     public URI getURI() throws IOException
/*     */     {
/* 102 */       return this.delegate.getURI();
/*     */     }
/*     */     
/*     */     public File getFile() throws IOException
/*     */     {
/* 107 */       return this.delegate.getFile();
/*     */     }
/*     */     
/*     */     public long contentLength() throws IOException
/*     */     {
/* 112 */       return this.delegate.contentLength();
/*     */     }
/*     */     
/*     */     public long lastModified() throws IOException
/*     */     {
/* 117 */       return this.delegate.lastModified();
/*     */     }
/*     */     
/*     */     public Resource createRelative(String relativePath) throws IOException
/*     */     {
/* 122 */       return this.delegate.createRelative(relativePath);
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     public String getFilename()
/*     */     {
/* 128 */       return this.delegate.getFilename();
/*     */     }
/*     */     
/*     */     public String getDescription()
/*     */     {
/* 133 */       return this.delegate.getDescription();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\function\ResourceHandlerFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */