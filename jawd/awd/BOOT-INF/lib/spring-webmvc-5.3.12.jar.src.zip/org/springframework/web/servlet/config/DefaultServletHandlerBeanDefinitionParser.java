/*    */ package org.springframework.web.servlet.config;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.springframework.beans.MutablePropertyValues;
/*    */ import org.springframework.beans.factory.config.BeanDefinition;
/*    */ import org.springframework.beans.factory.parsing.BeanComponentDefinition;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*    */ import org.springframework.beans.factory.support.ManagedMap;
/*    */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*    */ import org.springframework.beans.factory.xml.BeanDefinitionParser;
/*    */ import org.springframework.beans.factory.xml.ParserContext;
/*    */ import org.springframework.beans.factory.xml.XmlReaderContext;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.StringUtils;
/*    */ import org.springframework.web.servlet.handler.SimpleUrlHandlerMapping;
/*    */ import org.springframework.web.servlet.resource.DefaultServletHttpRequestHandler;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class DefaultServletHandlerBeanDefinitionParser
/*    */   implements BeanDefinitionParser
/*    */ {
/*    */   @Nullable
/*    */   public BeanDefinition parse(Element element, ParserContext parserContext)
/*    */   {
/* 50 */     Object source = parserContext.extractSource(element);
/*    */     
/* 52 */     String defaultServletName = element.getAttribute("default-servlet-name");
/* 53 */     RootBeanDefinition defaultServletHandlerDef = new RootBeanDefinition(DefaultServletHttpRequestHandler.class);
/* 54 */     defaultServletHandlerDef.setSource(source);
/* 55 */     defaultServletHandlerDef.setRole(2);
/* 56 */     if (StringUtils.hasText(defaultServletName)) {
/* 57 */       defaultServletHandlerDef.getPropertyValues().add("defaultServletName", defaultServletName);
/*    */     }
/* 59 */     String defaultServletHandlerName = parserContext.getReaderContext().generateBeanName(defaultServletHandlerDef);
/* 60 */     parserContext.getRegistry().registerBeanDefinition(defaultServletHandlerName, defaultServletHandlerDef);
/* 61 */     parserContext.registerComponent(new BeanComponentDefinition(defaultServletHandlerDef, defaultServletHandlerName));
/*    */     
/* 63 */     Map<String, String> urlMap = new ManagedMap();
/* 64 */     urlMap.put("/**", defaultServletHandlerName);
/*    */     
/* 66 */     RootBeanDefinition handlerMappingDef = new RootBeanDefinition(SimpleUrlHandlerMapping.class);
/* 67 */     handlerMappingDef.setSource(source);
/* 68 */     handlerMappingDef.setRole(2);
/* 69 */     handlerMappingDef.getPropertyValues().add("urlMap", urlMap);
/*    */     
/* 71 */     String handlerMappingBeanName = parserContext.getReaderContext().generateBeanName(handlerMappingDef);
/* 72 */     parserContext.getRegistry().registerBeanDefinition(handlerMappingBeanName, handlerMappingDef);
/* 73 */     parserContext.registerComponent(new BeanComponentDefinition(handlerMappingDef, handlerMappingBeanName));
/*    */     
/*    */ 
/* 76 */     MvcNamespaceUtils.registerDefaultComponents(parserContext, source);
/*    */     
/* 78 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\config\DefaultServletHandlerBeanDefinitionParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */