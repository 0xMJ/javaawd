package org.springframework.web.servlet.mvc;

import javax.servlet.http.HttpServletRequest;

@Deprecated
public abstract interface LastModified
{
  public abstract long getLastModified(HttpServletRequest paramHttpServletRequest);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\mvc\LastModified.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */