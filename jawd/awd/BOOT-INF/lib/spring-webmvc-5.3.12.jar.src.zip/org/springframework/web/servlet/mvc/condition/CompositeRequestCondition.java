/*     */ package org.springframework.web.servlet.mvc.condition;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CompositeRequestCondition
/*     */   extends AbstractRequestCondition<CompositeRequestCondition>
/*     */ {
/*     */   private final RequestConditionHolder[] requestConditions;
/*     */   
/*     */   public CompositeRequestCondition(RequestCondition<?>... requestConditions)
/*     */   {
/*  55 */     this.requestConditions = wrap(requestConditions);
/*     */   }
/*     */   
/*     */   private CompositeRequestCondition(RequestConditionHolder[] requestConditions) {
/*  59 */     this.requestConditions = requestConditions;
/*     */   }
/*     */   
/*     */   private RequestConditionHolder[] wrap(RequestCondition<?>... rawConditions)
/*     */   {
/*  64 */     RequestConditionHolder[] wrappedConditions = new RequestConditionHolder[rawConditions.length];
/*  65 */     for (int i = 0; i < rawConditions.length; i++) {
/*  66 */       wrappedConditions[i] = new RequestConditionHolder(rawConditions[i]);
/*     */     }
/*  68 */     return wrappedConditions;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isEmpty()
/*     */   {
/*  76 */     return ObjectUtils.isEmpty(this.requestConditions);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public List<RequestCondition<?>> getConditions()
/*     */   {
/*  83 */     return unwrap();
/*     */   }
/*     */   
/*     */   private List<RequestCondition<?>> unwrap() {
/*  87 */     List<RequestCondition<?>> result = new ArrayList();
/*  88 */     for (RequestConditionHolder holder : this.requestConditions) {
/*  89 */       result.add(holder.getCondition());
/*     */     }
/*  91 */     return result;
/*     */   }
/*     */   
/*     */   protected Collection<?> getContent()
/*     */   {
/*  96 */     return !isEmpty() ? getConditions() : Collections.emptyList();
/*     */   }
/*     */   
/*     */   protected String getToStringInfix()
/*     */   {
/* 101 */     return " && ";
/*     */   }
/*     */   
/*     */   private int getLength() {
/* 105 */     return this.requestConditions.length;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CompositeRequestCondition combine(CompositeRequestCondition other)
/*     */   {
/* 115 */     if ((isEmpty()) && (other.isEmpty())) {
/* 116 */       return this;
/*     */     }
/* 118 */     if (other.isEmpty()) {
/* 119 */       return this;
/*     */     }
/* 121 */     if (isEmpty()) {
/* 122 */       return other;
/*     */     }
/*     */     
/* 125 */     assertNumberOfConditions(other);
/* 126 */     RequestConditionHolder[] combinedConditions = new RequestConditionHolder[getLength()];
/* 127 */     for (int i = 0; i < getLength(); i++) {
/* 128 */       combinedConditions[i] = this.requestConditions[i].combine(other.requestConditions[i]);
/*     */     }
/* 130 */     return new CompositeRequestCondition(combinedConditions);
/*     */   }
/*     */   
/*     */   private void assertNumberOfConditions(CompositeRequestCondition other)
/*     */   {
/* 135 */     Assert.isTrue(getLength() == other.getLength(), "Cannot combine CompositeRequestConditions with a different number of conditions. " + 
/*     */     
/* 137 */       ObjectUtils.nullSafeToString(this.requestConditions) + " and  " + 
/* 138 */       ObjectUtils.nullSafeToString(other.requestConditions));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public CompositeRequestCondition getMatchingCondition(HttpServletRequest request)
/*     */   {
/* 149 */     if (isEmpty()) {
/* 150 */       return this;
/*     */     }
/* 152 */     RequestConditionHolder[] matchingConditions = new RequestConditionHolder[getLength()];
/* 153 */     for (int i = 0; i < getLength(); i++) {
/* 154 */       matchingConditions[i] = this.requestConditions[i].getMatchingCondition(request);
/* 155 */       if (matchingConditions[i] == null) {
/* 156 */         return null;
/*     */       }
/*     */     }
/* 159 */     return new CompositeRequestCondition(matchingConditions);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int compareTo(CompositeRequestCondition other, HttpServletRequest request)
/*     */   {
/* 168 */     if ((isEmpty()) && (other.isEmpty())) {
/* 169 */       return 0;
/*     */     }
/* 171 */     if (isEmpty()) {
/* 172 */       return 1;
/*     */     }
/* 174 */     if (other.isEmpty()) {
/* 175 */       return -1;
/*     */     }
/*     */     
/* 178 */     assertNumberOfConditions(other);
/* 179 */     for (int i = 0; i < getLength(); i++) {
/* 180 */       int result = this.requestConditions[i].compareTo(other.requestConditions[i], request);
/* 181 */       if (result != 0) {
/* 182 */         return result;
/*     */       }
/*     */     }
/* 185 */     return 0;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\mvc\condition\CompositeRequestCondition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */