/*    */ package org.springframework.web.servlet.view.tiles3;
/*    */ 
/*    */ import org.apache.tiles.request.render.Renderer;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.web.servlet.view.AbstractUrlBasedView;
/*    */ import org.springframework.web.servlet.view.UrlBasedViewResolver;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TilesViewResolver
/*    */   extends UrlBasedViewResolver
/*    */ {
/*    */   @Nullable
/*    */   private Renderer renderer;
/*    */   @Nullable
/*    */   private Boolean alwaysInclude;
/*    */   
/*    */   public TilesViewResolver()
/*    */   {
/* 48 */     setViewClass(requiredViewClass());
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setRenderer(Renderer renderer)
/*    */   {
/* 58 */     this.renderer = renderer;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setAlwaysInclude(Boolean alwaysInclude)
/*    */   {
/* 69 */     this.alwaysInclude = alwaysInclude;
/*    */   }
/*    */   
/*    */ 
/*    */   protected Class<?> requiredViewClass()
/*    */   {
/* 75 */     return TilesView.class;
/*    */   }
/*    */   
/*    */   protected AbstractUrlBasedView instantiateView()
/*    */   {
/* 80 */     return getViewClass() == TilesView.class ? new TilesView() : super.instantiateView();
/*    */   }
/*    */   
/*    */   protected TilesView buildView(String viewName) throws Exception
/*    */   {
/* 85 */     TilesView view = (TilesView)super.buildView(viewName);
/* 86 */     if (this.renderer != null) {
/* 87 */       view.setRenderer(this.renderer);
/*    */     }
/* 89 */     if (this.alwaysInclude != null) {
/* 90 */       view.setAlwaysInclude(this.alwaysInclude.booleanValue());
/*    */     }
/* 92 */     return view;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\view\tiles3\TilesViewResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */