/*     */ package org.springframework.web.servlet.tags.form;
/*     */ 
/*     */ import java.nio.charset.UnsupportedCharsetException;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import org.springframework.core.Conventions;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.servlet.support.RequestContext;
/*     */ import org.springframework.web.servlet.support.RequestDataValueProcessor;
/*     */ import org.springframework.web.util.HtmlUtils;
/*     */ import org.springframework.web.util.UriUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FormTag
/*     */   extends AbstractHtmlElementTag
/*     */ {
/*     */   private static final String DEFAULT_METHOD = "post";
/*     */   public static final String DEFAULT_COMMAND_NAME = "command";
/*     */   private static final String MODEL_ATTRIBUTE = "modelAttribute";
/* 262 */   public static final String MODEL_ATTRIBUTE_VARIABLE_NAME = Conventions.getQualifiedAttributeName(AbstractFormTag.class, "modelAttribute");
/*     */   
/*     */ 
/*     */   private static final String DEFAULT_METHOD_PARAM = "_method";
/*     */   
/*     */ 
/*     */   private static final String FORM_TAG = "form";
/*     */   
/*     */   private static final String INPUT_TAG = "input";
/*     */   
/*     */   private static final String ACTION_ATTRIBUTE = "action";
/*     */   
/*     */   private static final String METHOD_ATTRIBUTE = "method";
/*     */   
/*     */   private static final String TARGET_ATTRIBUTE = "target";
/*     */   
/*     */   private static final String ENCTYPE_ATTRIBUTE = "enctype";
/*     */   
/*     */   private static final String ACCEPT_CHARSET_ATTRIBUTE = "accept-charset";
/*     */   
/*     */   private static final String ONSUBMIT_ATTRIBUTE = "onsubmit";
/*     */   
/*     */   private static final String ONRESET_ATTRIBUTE = "onreset";
/*     */   
/*     */   private static final String AUTOCOMPLETE_ATTRIBUTE = "autocomplete";
/*     */   
/*     */   private static final String NAME_ATTRIBUTE = "name";
/*     */   
/*     */   private static final String VALUE_ATTRIBUTE = "value";
/*     */   
/*     */   private static final String TYPE_ATTRIBUTE = "type";
/*     */   
/*     */   @Nullable
/*     */   private TagWriter tagWriter;
/*     */   
/* 297 */   private String modelAttribute = "command";
/*     */   
/*     */   @Nullable
/*     */   private String name;
/*     */   
/*     */   @Nullable
/*     */   private String action;
/*     */   
/*     */   @Nullable
/*     */   private String servletRelativeAction;
/*     */   
/* 308 */   private String method = "post";
/*     */   
/*     */   @Nullable
/*     */   private String target;
/*     */   
/*     */   @Nullable
/*     */   private String enctype;
/*     */   
/*     */   @Nullable
/*     */   private String acceptCharset;
/*     */   
/*     */   @Nullable
/*     */   private String onsubmit;
/*     */   
/*     */   @Nullable
/*     */   private String onreset;
/*     */   
/*     */   @Nullable
/*     */   private String autocomplete;
/*     */   
/* 328 */   private String methodParam = "_method";
/*     */   
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   private String previousNestedPath;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setModelAttribute(String modelAttribute)
/*     */   {
/* 340 */     this.modelAttribute = modelAttribute;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected String getModelAttribute()
/*     */   {
/* 347 */     return this.modelAttribute;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setName(String name)
/*     */   {
/* 357 */     this.name = name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected String getName()
/*     */     throws JspException
/*     */   {
/* 366 */     return this.name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAction(@Nullable String action)
/*     */   {
/* 374 */     this.action = (action != null ? action : "");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected String getAction()
/*     */   {
/* 382 */     return this.action;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setServletRelativeAction(@Nullable String servletRelativeAction)
/*     */   {
/* 392 */     this.servletRelativeAction = servletRelativeAction;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected String getServletRelativeAction()
/*     */   {
/* 401 */     return this.servletRelativeAction;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMethod(String method)
/*     */   {
/* 409 */     this.method = method;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected String getMethod()
/*     */   {
/* 416 */     return this.method;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTarget(String target)
/*     */   {
/* 424 */     this.target = target;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public String getTarget()
/*     */   {
/* 432 */     return this.target;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEnctype(String enctype)
/*     */   {
/* 440 */     this.enctype = enctype;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected String getEnctype()
/*     */   {
/* 448 */     return this.enctype;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAcceptCharset(String acceptCharset)
/*     */   {
/* 456 */     this.acceptCharset = acceptCharset;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected String getAcceptCharset()
/*     */   {
/* 464 */     return this.acceptCharset;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOnsubmit(String onsubmit)
/*     */   {
/* 472 */     this.onsubmit = onsubmit;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected String getOnsubmit()
/*     */   {
/* 480 */     return this.onsubmit;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOnreset(String onreset)
/*     */   {
/* 488 */     this.onreset = onreset;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected String getOnreset()
/*     */   {
/* 496 */     return this.onreset;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAutocomplete(String autocomplete)
/*     */   {
/* 504 */     this.autocomplete = autocomplete;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected String getAutocomplete()
/*     */   {
/* 512 */     return this.autocomplete;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setMethodParam(String methodParam)
/*     */   {
/* 519 */     this.methodParam = methodParam;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getMethodParam()
/*     */   {
/* 527 */     return this.methodParam;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected boolean isMethodBrowserSupported(String method)
/*     */   {
/* 534 */     return ("get".equalsIgnoreCase(method)) || ("post".equalsIgnoreCase(method));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int writeTagContent(TagWriter tagWriter)
/*     */     throws JspException
/*     */   {
/* 546 */     this.tagWriter = tagWriter;
/*     */     
/* 548 */     tagWriter.startTag("form");
/* 549 */     writeDefaultAttributes(tagWriter);
/* 550 */     tagWriter.writeAttribute("action", resolveAction());
/* 551 */     writeOptionalAttribute(tagWriter, "method", getHttpMethod());
/* 552 */     writeOptionalAttribute(tagWriter, "target", getTarget());
/* 553 */     writeOptionalAttribute(tagWriter, "enctype", getEnctype());
/* 554 */     writeOptionalAttribute(tagWriter, "accept-charset", getAcceptCharset());
/* 555 */     writeOptionalAttribute(tagWriter, "onsubmit", getOnsubmit());
/* 556 */     writeOptionalAttribute(tagWriter, "onreset", getOnreset());
/* 557 */     writeOptionalAttribute(tagWriter, "autocomplete", getAutocomplete());
/*     */     
/* 559 */     tagWriter.forceBlock();
/*     */     
/* 561 */     if (!isMethodBrowserSupported(getMethod())) {
/* 562 */       assertHttpMethod(getMethod());
/* 563 */       String inputName = getMethodParam();
/* 564 */       String inputType = "hidden";
/* 565 */       tagWriter.startTag("input");
/* 566 */       writeOptionalAttribute(tagWriter, "type", inputType);
/* 567 */       writeOptionalAttribute(tagWriter, "name", inputName);
/* 568 */       writeOptionalAttribute(tagWriter, "value", processFieldValue(inputName, getMethod(), inputType));
/* 569 */       tagWriter.endTag();
/*     */     }
/*     */     
/*     */ 
/* 573 */     String modelAttribute = resolveModelAttribute();
/* 574 */     this.pageContext.setAttribute(MODEL_ATTRIBUTE_VARIABLE_NAME, modelAttribute, 2);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 579 */     this.previousNestedPath = ((String)this.pageContext.getAttribute("nestedPath", 2));
/* 580 */     this.pageContext.setAttribute("nestedPath", modelAttribute + ".", 2);
/*     */     
/*     */ 
/* 583 */     return 1;
/*     */   }
/*     */   
/*     */   private String getHttpMethod() {
/* 587 */     return isMethodBrowserSupported(getMethod()) ? getMethod() : "post";
/*     */   }
/*     */   
/*     */   private void assertHttpMethod(String method) {
/* 591 */     for (HttpMethod httpMethod : ) {
/* 592 */       if (httpMethod.name().equalsIgnoreCase(method)) {
/* 593 */         return;
/*     */       }
/*     */     }
/* 596 */     throw new IllegalArgumentException("Invalid HTTP method: " + method);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected String autogenerateId()
/*     */     throws JspException
/*     */   {
/* 604 */     return resolveModelAttribute();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected String resolveModelAttribute()
/*     */     throws JspException
/*     */   {
/* 612 */     Object resolvedModelAttribute = evaluate("modelAttribute", getModelAttribute());
/* 613 */     if (resolvedModelAttribute == null) {
/* 614 */       throw new IllegalArgumentException("modelAttribute must not be null");
/*     */     }
/* 616 */     return (String)resolvedModelAttribute;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String resolveAction()
/*     */     throws JspException
/*     */   {
/* 630 */     String action = getAction();
/* 631 */     String servletRelativeAction = getServletRelativeAction();
/* 632 */     if (StringUtils.hasText(action)) {
/* 633 */       action = getDisplayString(evaluate("action", action));
/* 634 */       return processAction(action);
/*     */     }
/* 636 */     if (StringUtils.hasText(servletRelativeAction)) {
/* 637 */       String pathToServlet = getRequestContext().getPathToServlet();
/* 638 */       if ((servletRelativeAction.startsWith("/")) && 
/* 639 */         (!servletRelativeAction.startsWith(getRequestContext().getContextPath()))) {
/* 640 */         servletRelativeAction = pathToServlet + servletRelativeAction;
/*     */       }
/* 642 */       servletRelativeAction = getDisplayString(evaluate("action", servletRelativeAction));
/* 643 */       return processAction(servletRelativeAction);
/*     */     }
/*     */     
/* 646 */     String requestUri = getRequestContext().getRequestUri();
/* 647 */     String encoding = this.pageContext.getResponse().getCharacterEncoding();
/*     */     try {
/* 649 */       requestUri = UriUtils.encodePath(requestUri, encoding);
/*     */     }
/*     */     catch (UnsupportedCharsetException localUnsupportedCharsetException) {}
/*     */     
/*     */ 
/* 654 */     ServletResponse response = this.pageContext.getResponse();
/* 655 */     if ((response instanceof HttpServletResponse)) {
/* 656 */       requestUri = ((HttpServletResponse)response).encodeURL(requestUri);
/* 657 */       String queryString = getRequestContext().getQueryString();
/* 658 */       if (StringUtils.hasText(queryString)) {
/* 659 */         requestUri = requestUri + "?" + HtmlUtils.htmlEscape(queryString);
/*     */       }
/*     */     }
/* 662 */     if (StringUtils.hasText(requestUri)) {
/* 663 */       return processAction(requestUri);
/*     */     }
/*     */     
/* 666 */     throw new IllegalArgumentException("Attribute 'action' is required. Attempted to resolve against current request URI but request URI was null.");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String processAction(String action)
/*     */   {
/* 677 */     RequestDataValueProcessor processor = getRequestContext().getRequestDataValueProcessor();
/* 678 */     ServletRequest request = this.pageContext.getRequest();
/* 679 */     if ((processor != null) && ((request instanceof HttpServletRequest))) {
/* 680 */       action = processor.processAction((HttpServletRequest)request, action, getHttpMethod());
/*     */     }
/* 682 */     return action;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int doEndTag()
/*     */     throws JspException
/*     */   {
/* 691 */     RequestDataValueProcessor processor = getRequestContext().getRequestDataValueProcessor();
/* 692 */     ServletRequest request = this.pageContext.getRequest();
/* 693 */     if ((processor != null) && ((request instanceof HttpServletRequest))) {
/* 694 */       writeHiddenFields(processor.getExtraHiddenFields((HttpServletRequest)request));
/*     */     }
/* 696 */     Assert.state(this.tagWriter != null, "No TagWriter set");
/* 697 */     this.tagWriter.endTag();
/* 698 */     return 6;
/*     */   }
/*     */   
/*     */ 
/*     */   private void writeHiddenFields(@Nullable Map<String, String> hiddenFields)
/*     */     throws JspException
/*     */   {
/* 705 */     if (!CollectionUtils.isEmpty(hiddenFields)) {
/* 706 */       Assert.state(this.tagWriter != null, "No TagWriter set");
/* 707 */       this.tagWriter.appendValue("<div>\n");
/* 708 */       for (Map.Entry<String, String> entry : hiddenFields.entrySet()) {
/* 709 */         this.tagWriter.appendValue("<input type=\"hidden\" ");
/* 710 */         this.tagWriter.appendValue("name=\"" + (String)entry.getKey() + "\" value=\"" + (String)entry.getValue() + "\" ");
/* 711 */         this.tagWriter.appendValue("/>\n");
/*     */       }
/* 713 */       this.tagWriter.appendValue("</div>");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void doFinally()
/*     */   {
/* 722 */     super.doFinally();
/*     */     
/* 724 */     this.pageContext.removeAttribute(MODEL_ATTRIBUTE_VARIABLE_NAME, 2);
/* 725 */     if (this.previousNestedPath != null)
/*     */     {
/* 727 */       this.pageContext.setAttribute("nestedPath", this.previousNestedPath, 2);
/*     */     }
/*     */     else
/*     */     {
/* 731 */       this.pageContext.removeAttribute("nestedPath", 2);
/*     */     }
/* 733 */     this.tagWriter = null;
/* 734 */     this.previousNestedPath = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String resolveCssClass()
/*     */     throws JspException
/*     */   {
/* 743 */     return ObjectUtils.getDisplayString(evaluate("cssClass", getCssClass()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPath(String path)
/*     */   {
/* 752 */     throw new UnsupportedOperationException("The 'path' attribute is not supported for forms");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCssErrorClass(String cssErrorClass)
/*     */   {
/* 761 */     throw new UnsupportedOperationException("The 'cssErrorClass' attribute is not supported for forms");
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\tags\form\FormTag.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */