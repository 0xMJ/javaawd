/*     */ package org.springframework.web.servlet.tags.form;
/*     */ 
/*     */ import javax.servlet.jsp.JspException;
/*     */ import org.springframework.web.servlet.support.BindStatus;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CheckboxTag
/*     */   extends AbstractSingleCheckedElementTag
/*     */ {
/*     */   protected int writeTagContent(TagWriter tagWriter)
/*     */     throws JspException
/*     */   {
/* 229 */     super.writeTagContent(tagWriter);
/*     */     
/* 231 */     if (!isDisabled())
/*     */     {
/* 233 */       tagWriter.startTag("input");
/* 234 */       tagWriter.writeAttribute("type", "hidden");
/* 235 */       String name = "_" + getName();
/* 236 */       tagWriter.writeAttribute("name", name);
/* 237 */       tagWriter.writeAttribute("value", processFieldValue(name, "on", "hidden"));
/* 238 */       tagWriter.endTag();
/*     */     }
/*     */     
/* 241 */     return 0;
/*     */   }
/*     */   
/*     */   protected void writeTagDetails(TagWriter tagWriter) throws JspException
/*     */   {
/* 246 */     tagWriter.writeAttribute("type", getInputType());
/*     */     
/* 248 */     Object boundValue = getBoundValue();
/* 249 */     Class<?> valueType = getBindStatus().getValueType();
/*     */     
/* 251 */     if ((Boolean.class == valueType) || (Boolean.TYPE == valueType))
/*     */     {
/* 253 */       if ((boundValue instanceof String)) {
/* 254 */         boundValue = Boolean.valueOf((String)boundValue);
/*     */       }
/* 256 */       Boolean booleanValue = boundValue != null ? (Boolean)boundValue : Boolean.FALSE;
/* 257 */       renderFromBoolean(booleanValue, tagWriter);
/*     */     }
/*     */     else
/*     */     {
/* 261 */       Object value = getValue();
/* 262 */       if (value == null) {
/* 263 */         throw new IllegalArgumentException("Attribute 'value' is required when binding to non-boolean values");
/*     */       }
/* 265 */       Object resolvedValue = (value instanceof String) ? evaluate("value", value) : value;
/* 266 */       renderFromValue(resolvedValue, tagWriter);
/*     */     }
/*     */   }
/*     */   
/*     */   protected String getInputType()
/*     */   {
/* 272 */     return "checkbox";
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\tags\form\CheckboxTag.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */