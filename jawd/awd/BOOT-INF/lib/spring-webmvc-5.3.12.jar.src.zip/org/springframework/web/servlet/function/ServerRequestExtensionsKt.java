/*    */ package org.springframework.web.servlet.function;
/*    */ 
/*    */ import java.net.InetSocketAddress;
/*    */ import java.security.Principal;
/*    */ import java.util.Optional;
/*    */ import java.util.OptionalLong;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ import org.springframework.core.ParameterizedTypeReference;
/*    */ import org.springframework.http.MediaType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv={1, 1, 18}, bv={1, 0, 3}, k=2, d1={"\0004\n\000\n\002\020\000\n\002\030\002\n\000\n\002\020\016\n\002\b\004\n\002\020\t\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\000\032\024\020\000\032\004\030\0010\001*\0020\0022\006\020\003\032\0020\004\032\036\020\005\032\002H\006\"\n\b\000\020\006\030\001*\0020\001*\0020\002H\b¢\006\002\020\007\032\021\020\b\032\004\030\0010\t*\0020\n¢\006\002\020\013\032\f\020\f\032\004\030\0010\r*\0020\n\032\024\020\016\032\004\030\0010\004*\0020\0022\006\020\003\032\0020\004\032\f\020\017\032\004\030\0010\020*\0020\002\032\f\020\021\032\004\030\0010\022*\0020\002¨\006\023"}, d2={"attributeOrNull", "", "Lorg/springframework/web/servlet/function/ServerRequest;", "name", "", "body", "T", "(Lorg/springframework/web/servlet/function/ServerRequest;)Ljava/lang/Object;", "contentLengthOrNull", "", "Lorg/springframework/web/servlet/function/ServerRequest$Headers;", "(Lorg/springframework/web/servlet/function/ServerRequest$Headers;)Ljava/lang/Long;", "contentTypeOrNull", "Lorg/springframework/http/MediaType;", "paramOrNull", "principalOrNull", "Ljava/security/Principal;", "remoteAddressOrNull", "Ljava/net/InetSocketAddress;", "spring-webmvc"})
/*    */ public final class ServerRequestExtensionsKt
/*    */ {
/*    */   @Nullable
/*    */   public static final InetSocketAddress remoteAddressOrNull(@NotNull ServerRequest $this$remoteAddressOrNull)
/*    */   {
/* 30 */     Intrinsics.checkParameterIsNotNull($this$remoteAddressOrNull, "$this$remoteAddressOrNull");return (InetSocketAddress)$this$remoteAddressOrNull.remoteAddress().orElse(null);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   @Nullable
/*    */   public static final Object attributeOrNull(@NotNull ServerRequest $this$attributeOrNull, @NotNull String name)
/*    */   {
/* 48 */     Intrinsics.checkParameterIsNotNull($this$attributeOrNull, "$this$attributeOrNull");Intrinsics.checkParameterIsNotNull(name, "name");return $this$attributeOrNull.attribute(name).orElse(null);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   @Nullable
/*    */   public static final String paramOrNull(@NotNull ServerRequest $this$paramOrNull, @NotNull String name)
/*    */   {
/* 56 */     Intrinsics.checkParameterIsNotNull($this$paramOrNull, "$this$paramOrNull");Intrinsics.checkParameterIsNotNull(name, "name");return (String)$this$paramOrNull.param(name).orElse(null);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   @Nullable
/*    */   public static final Principal principalOrNull(@NotNull ServerRequest $this$principalOrNull)
/*    */   {
/* 64 */     Intrinsics.checkParameterIsNotNull($this$principalOrNull, "$this$principalOrNull");return (Principal)$this$principalOrNull.principal().orElse(null);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   @Nullable
/*    */   public static final Long contentLengthOrNull(@NotNull ServerRequest.Headers $this$contentLengthOrNull)
/*    */   {
/* 72 */     Intrinsics.checkParameterIsNotNull($this$contentLengthOrNull, "$this$contentLengthOrNull");OptionalLong localOptionalLong1 = $this$contentLengthOrNull.contentLength();int i = 0;int j = 0;OptionalLong it = localOptionalLong1;
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 82 */     int $i$a$-let-ServerRequestExtensionsKt$contentLengthOrNull$1 = 0;Intrinsics.checkExpressionValueIsNotNull(it, "it");return tmp25_23.isPresent() ? Long.valueOf(it.getAsLong()) : null;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   @Nullable
/*    */   public static final MediaType contentTypeOrNull(@NotNull ServerRequest.Headers $this$contentTypeOrNull)
/*    */   {
/* 80 */     Intrinsics.checkParameterIsNotNull($this$contentTypeOrNull, "$this$contentTypeOrNull");return (MediaType)$this$contentTypeOrNull.contentType().orElse(null);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\function\ServerRequestExtensionsKt.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */