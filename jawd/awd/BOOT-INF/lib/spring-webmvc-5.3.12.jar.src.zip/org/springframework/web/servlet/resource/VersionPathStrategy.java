package org.springframework.web.servlet.resource;

import org.springframework.lang.Nullable;

public abstract interface VersionPathStrategy
{
  @Nullable
  public abstract String extractVersion(String paramString);
  
  public abstract String removeVersion(String paramString1, String paramString2);
  
  public abstract String addVersion(String paramString1, String paramString2);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\resource\VersionPathStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */