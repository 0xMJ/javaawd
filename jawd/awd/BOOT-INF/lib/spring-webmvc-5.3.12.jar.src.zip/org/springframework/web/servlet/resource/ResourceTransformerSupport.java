/*     */ package org.springframework.web.servlet.resource;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.util.UrlPathHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ResourceTransformerSupport
/*     */   implements ResourceTransformer
/*     */ {
/*     */   @Nullable
/*     */   private ResourceUrlProvider resourceUrlProvider;
/*     */   
/*     */   public void setResourceUrlProvider(@Nullable ResourceUrlProvider resourceUrlProvider)
/*     */   {
/*  50 */     this.resourceUrlProvider = resourceUrlProvider;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public ResourceUrlProvider getResourceUrlProvider()
/*     */   {
/*  58 */     return this.resourceUrlProvider;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected String resolveUrlPath(String resourcePath, HttpServletRequest request, Resource resource, ResourceTransformerChain transformerChain)
/*     */   {
/*  77 */     if (resourcePath.startsWith("/"))
/*     */     {
/*  79 */       ResourceUrlProvider urlProvider = findResourceUrlProvider(request);
/*  80 */       return urlProvider != null ? urlProvider.getForRequestUrl(request, resourcePath) : null;
/*     */     }
/*     */     
/*     */ 
/*  84 */     return transformerChain.getResolverChain().resolveUrlPath(resourcePath, 
/*  85 */       Collections.singletonList(resource));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String toAbsolutePath(String path, HttpServletRequest request)
/*     */   {
/*  98 */     String absolutePath = path;
/*  99 */     if (!path.startsWith("/")) {
/* 100 */       ResourceUrlProvider urlProvider = findResourceUrlProvider(request);
/* 101 */       Assert.state(urlProvider != null, "No ResourceUrlProvider");
/* 102 */       String requestPath = urlProvider.getUrlPathHelper().getRequestUri(request);
/* 103 */       absolutePath = StringUtils.applyRelativePath(requestPath, path);
/*     */     }
/* 105 */     return StringUtils.cleanPath(absolutePath);
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private ResourceUrlProvider findResourceUrlProvider(HttpServletRequest request) {
/* 110 */     if (this.resourceUrlProvider != null) {
/* 111 */       return this.resourceUrlProvider;
/*     */     }
/* 113 */     return (ResourceUrlProvider)request.getAttribute(ResourceUrlProviderExposingInterceptor.RESOURCE_URL_PROVIDER_ATTR);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\resource\ResourceTransformerSupport.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */