/*     */ package org.springframework.web.servlet.function;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.UncheckedIOException;
/*     */ import java.net.URL;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.Optional;
/*     */ import java.util.function.Function;
/*     */ import org.springframework.core.io.ClassPathResource;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.UrlResource;
/*     */ import org.springframework.http.server.PathContainer;
/*     */ import org.springframework.http.server.RequestPath;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ResourceUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.util.pattern.PathPattern;
/*     */ import org.springframework.web.util.pattern.PathPatternParser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class PathResourceLookupFunction
/*     */   implements Function<ServerRequest, Optional<Resource>>
/*     */ {
/*     */   private final PathPattern pattern;
/*     */   private final Resource location;
/*     */   
/*     */   public PathResourceLookupFunction(String pattern, Resource location)
/*     */   {
/*  49 */     Assert.hasLength(pattern, "'pattern' must not be empty");
/*  50 */     Assert.notNull(location, "'location' must not be null");
/*  51 */     this.pattern = PathPatternParser.defaultInstance.parse(pattern);
/*  52 */     this.location = location;
/*     */   }
/*     */   
/*     */ 
/*     */   public Optional<Resource> apply(ServerRequest request)
/*     */   {
/*  58 */     PathContainer pathContainer = request.requestPath().pathWithinApplication();
/*  59 */     if (!this.pattern.matches(pathContainer)) {
/*  60 */       return Optional.empty();
/*     */     }
/*     */     
/*  63 */     pathContainer = this.pattern.extractPathWithinPattern(pathContainer);
/*  64 */     String path = processPath(pathContainer.value());
/*  65 */     if (path.contains("%")) {
/*  66 */       path = StringUtils.uriDecode(path, StandardCharsets.UTF_8);
/*     */     }
/*  68 */     if ((!StringUtils.hasLength(path)) || (isInvalidPath(path))) {
/*  69 */       return Optional.empty();
/*     */     }
/*     */     try
/*     */     {
/*  73 */       Resource resource = this.location.createRelative(path);
/*  74 */       if ((resource.isReadable()) && (isResourceUnderLocation(resource))) {
/*  75 */         return Optional.of(resource);
/*     */       }
/*     */       
/*  78 */       return Optional.empty();
/*     */     }
/*     */     catch (IOException ex)
/*     */     {
/*  82 */       throw new UncheckedIOException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */   private String processPath(String path) {
/*  87 */     boolean slash = false;
/*  88 */     for (int i = 0; i < path.length(); i++) {
/*  89 */       if (path.charAt(i) == '/') {
/*  90 */         slash = true;
/*     */       }
/*  92 */       else if ((path.charAt(i) > ' ') && (path.charAt(i) != '')) {
/*  93 */         if ((i == 0) || ((i == 1) && (slash))) {
/*  94 */           return path;
/*     */         }
/*  96 */         path = slash ? "/" + path.substring(i) : path.substring(i);
/*  97 */         return path;
/*     */       }
/*     */     }
/* 100 */     return slash ? "/" : "";
/*     */   }
/*     */   
/*     */   private boolean isInvalidPath(String path) {
/* 104 */     if ((path.contains("WEB-INF")) || (path.contains("META-INF"))) {
/* 105 */       return true;
/*     */     }
/* 107 */     if (path.contains(":/")) {
/* 108 */       String relativePath = path.charAt(0) == '/' ? path.substring(1) : path;
/* 109 */       if ((ResourceUtils.isUrl(relativePath)) || (relativePath.startsWith("url:"))) {
/* 110 */         return true;
/*     */       }
/*     */     }
/* 113 */     return (path.contains("..")) && (StringUtils.cleanPath(path).contains("../"));
/*     */   }
/*     */   
/*     */   private boolean isResourceUnderLocation(Resource resource) throws IOException {
/* 117 */     if (resource.getClass() != this.location.getClass()) {
/* 118 */       return false;
/*     */     }
/*     */     
/*     */     String locationPath;
/*     */     
/*     */     String resourcePath;
/* 124 */     if ((resource instanceof UrlResource)) {
/* 125 */       String resourcePath = resource.getURL().toExternalForm();
/* 126 */       locationPath = StringUtils.cleanPath(this.location.getURL().toString());
/*     */     } else { String locationPath;
/* 128 */       if ((resource instanceof ClassPathResource)) {
/* 129 */         String resourcePath = ((ClassPathResource)resource).getPath();
/* 130 */         locationPath = StringUtils.cleanPath(((ClassPathResource)this.location).getPath());
/*     */       }
/*     */       else {
/* 133 */         resourcePath = resource.getURL().getPath();
/* 134 */         locationPath = StringUtils.cleanPath(this.location.getURL().getPath());
/*     */       }
/*     */     }
/* 137 */     if (locationPath.equals(resourcePath)) {
/* 138 */       return true;
/*     */     }
/* 140 */     String locationPath = locationPath + "/";
/* 141 */     if (!resourcePath.startsWith(locationPath)) {
/* 142 */       return false;
/*     */     }
/* 144 */     return (!resourcePath.contains("%")) || 
/* 145 */       (!StringUtils.uriDecode(resourcePath, StandardCharsets.UTF_8).contains("../"));
/*     */   }
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/* 151 */     return this.pattern + " -> " + this.location;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\function\PathResourceLookupFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */