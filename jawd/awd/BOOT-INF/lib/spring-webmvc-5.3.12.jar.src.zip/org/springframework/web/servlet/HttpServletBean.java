/*     */ package org.springframework.web.servlet;
/*     */ 
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import javax.servlet.ServletConfig;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServlet;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.BeanWrapper;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.MutablePropertyValues;
/*     */ import org.springframework.beans.PropertyAccessorFactory;
/*     */ import org.springframework.beans.PropertyValue;
/*     */ import org.springframework.beans.PropertyValues;
/*     */ import org.springframework.context.EnvironmentAware;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.env.EnvironmentCapable;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceEditor;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.context.support.ServletContextResourceLoader;
/*     */ import org.springframework.web.context.support.StandardServletEnvironment;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class HttpServletBean
/*     */   extends HttpServlet
/*     */   implements EnvironmentCapable, EnvironmentAware
/*     */ {
/*  86 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/*     */   @Nullable
/*     */   private ConfigurableEnvironment environment;
/*     */   
/*  91 */   private final Set<String> requiredProperties = new HashSet(4);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final void addRequiredProperty(String property)
/*     */   {
/* 104 */     this.requiredProperties.add(property);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEnvironment(Environment environment)
/*     */   {
/* 116 */     Assert.isInstanceOf(ConfigurableEnvironment.class, environment, "ConfigurableEnvironment required");
/* 117 */     this.environment = ((ConfigurableEnvironment)environment);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ConfigurableEnvironment getEnvironment()
/*     */   {
/* 127 */     if (this.environment == null) {
/* 128 */       this.environment = createEnvironment();
/*     */     }
/* 130 */     return this.environment;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ConfigurableEnvironment createEnvironment()
/*     */   {
/* 139 */     return new StandardServletEnvironment();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void init()
/*     */     throws ServletException
/*     */   {
/* 152 */     PropertyValues pvs = new ServletConfigPropertyValues(getServletConfig(), this.requiredProperties);
/* 153 */     if (!pvs.isEmpty()) {
/*     */       try {
/* 155 */         BeanWrapper bw = PropertyAccessorFactory.forBeanPropertyAccess(this);
/* 156 */         ResourceLoader resourceLoader = new ServletContextResourceLoader(getServletContext());
/* 157 */         bw.registerCustomEditor(Resource.class, new ResourceEditor(resourceLoader, getEnvironment()));
/* 158 */         initBeanWrapper(bw);
/* 159 */         bw.setPropertyValues(pvs, true);
/*     */       }
/*     */       catch (BeansException ex) {
/* 162 */         if (this.logger.isErrorEnabled()) {
/* 163 */           this.logger.error("Failed to set bean properties on servlet '" + getServletName() + "'", ex);
/*     */         }
/* 165 */         throw ex;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 170 */     initServletBean();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void initBeanWrapper(BeanWrapper bw)
/*     */     throws BeansException
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void initServletBean()
/*     */     throws ServletException
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public String getServletName()
/*     */   {
/* 202 */     return getServletConfig() != null ? getServletConfig().getServletName() : null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class ServletConfigPropertyValues
/*     */     extends MutablePropertyValues
/*     */   {
/*     */     public ServletConfigPropertyValues(ServletConfig config, Set<String> requiredProperties)
/*     */       throws ServletException
/*     */     {
/* 221 */       Set<String> missingProps = !CollectionUtils.isEmpty(requiredProperties) ? new HashSet(requiredProperties) : null;
/*     */       
/*     */ 
/* 224 */       Enumeration<String> paramNames = config.getInitParameterNames();
/* 225 */       while (paramNames.hasMoreElements()) {
/* 226 */         String property = (String)paramNames.nextElement();
/* 227 */         Object value = config.getInitParameter(property);
/* 228 */         addPropertyValue(new PropertyValue(property, value));
/* 229 */         if (missingProps != null) {
/* 230 */           missingProps.remove(property);
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 235 */       if (!CollectionUtils.isEmpty(missingProps))
/*     */       {
/*     */ 
/*     */ 
/* 239 */         throw new ServletException("Initialization from ServletConfig for servlet '" + config.getServletName() + "' failed; the following required properties were missing: " + StringUtils.collectionToDelimitedString(missingProps, ", "));
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\HttpServletBean.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */