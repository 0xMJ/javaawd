/*    */ package org.springframework.web.servlet.theme;
/*    */ 
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FixedThemeResolver
/*    */   extends AbstractThemeResolver
/*    */ {
/*    */   public String resolveThemeName(HttpServletRequest request)
/*    */   {
/* 41 */     return getDefaultThemeName();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void setThemeName(HttpServletRequest request, @Nullable HttpServletResponse response, @Nullable String themeName)
/*    */   {
/* 48 */     throw new UnsupportedOperationException("Cannot change theme - use a different theme resolution strategy");
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\theme\FixedThemeResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */