/*     */ package org.springframework.web.servlet.mvc.condition;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.springframework.http.InvalidMediaTypeException;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.cors.CorsUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ConsumesRequestCondition
/*     */   extends AbstractRequestCondition<ConsumesRequestCondition>
/*     */ {
/*  53 */   private static final ConsumesRequestCondition EMPTY_CONDITION = new ConsumesRequestCondition(new String[0]);
/*     */   
/*     */ 
/*     */   private final List<ConsumeMediaTypeExpression> expressions;
/*     */   
/*  58 */   private boolean bodyRequired = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ConsumesRequestCondition(String... consumes)
/*     */   {
/*  68 */     this(consumes, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ConsumesRequestCondition(String[] consumes, @Nullable String[] headers)
/*     */   {
/*  80 */     this.expressions = parseExpressions(consumes, headers);
/*  81 */     if (this.expressions.size() > 1) {
/*  82 */       Collections.sort(this.expressions);
/*     */     }
/*     */   }
/*     */   
/*     */   private static List<ConsumeMediaTypeExpression> parseExpressions(String[] consumes, @Nullable String[] headers) {
/*  87 */     Set<ConsumeMediaTypeExpression> result = null;
/*  88 */     if (!ObjectUtils.isEmpty(headers)) { HeadersRequestCondition.HeaderExpression expr;
/*  89 */       for (String header : headers) {
/*  90 */         expr = new HeadersRequestCondition.HeaderExpression(header);
/*  91 */         if (("Content-Type".equalsIgnoreCase(expr.name)) && (expr.value != null)) {
/*  92 */           result = result != null ? result : new LinkedHashSet();
/*  93 */           for (MediaType mediaType : MediaType.parseMediaTypes((String)expr.value)) {
/*  94 */             result.add(new ConsumeMediaTypeExpression(mediaType, expr.isNegated));
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*  99 */     if (!ObjectUtils.isEmpty(consumes)) {
/* 100 */       result = result != null ? result : new LinkedHashSet();
/* 101 */       for (String consume : consumes) {
/* 102 */         result.add(new ConsumeMediaTypeExpression(consume));
/*     */       }
/*     */     }
/* 105 */     return result != null ? new ArrayList(result) : Collections.emptyList();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private ConsumesRequestCondition(List<ConsumeMediaTypeExpression> expressions)
/*     */   {
/* 113 */     this.expressions = expressions;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Set<MediaTypeExpression> getExpressions()
/*     */   {
/* 121 */     return new LinkedHashSet(this.expressions);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Set<MediaType> getConsumableMediaTypes()
/*     */   {
/* 128 */     Set<MediaType> result = new LinkedHashSet();
/* 129 */     for (ConsumeMediaTypeExpression expression : this.expressions) {
/* 130 */       if (!expression.isNegated()) {
/* 131 */         result.add(expression.getMediaType());
/*     */       }
/*     */     }
/* 134 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isEmpty()
/*     */   {
/* 142 */     return this.expressions.isEmpty();
/*     */   }
/*     */   
/*     */   protected Collection<ConsumeMediaTypeExpression> getContent()
/*     */   {
/* 147 */     return this.expressions;
/*     */   }
/*     */   
/*     */   protected String getToStringInfix()
/*     */   {
/* 152 */     return " || ";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBodyRequired(boolean bodyRequired)
/*     */   {
/* 166 */     this.bodyRequired = bodyRequired;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isBodyRequired()
/*     */   {
/* 174 */     return this.bodyRequired;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ConsumesRequestCondition combine(ConsumesRequestCondition other)
/*     */   {
/* 185 */     return !other.expressions.isEmpty() ? other : this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public ConsumesRequestCondition getMatchingCondition(HttpServletRequest request)
/*     */   {
/* 201 */     if (CorsUtils.isPreFlightRequest(request)) {
/* 202 */       return EMPTY_CONDITION;
/*     */     }
/* 204 */     if (isEmpty()) {
/* 205 */       return this;
/*     */     }
/* 207 */     if ((!hasBody(request)) && (!this.bodyRequired)) {
/* 208 */       return EMPTY_CONDITION;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 216 */       contentType = StringUtils.hasLength(request.getContentType()) ? MediaType.parseMediaType(request.getContentType()) : MediaType.APPLICATION_OCTET_STREAM;
/*     */     }
/*     */     catch (InvalidMediaTypeException ex) {
/*     */       MediaType contentType;
/* 220 */       return null;
/*     */     }
/*     */     MediaType contentType;
/* 223 */     List<ConsumeMediaTypeExpression> result = getMatchingExpressions(contentType);
/* 224 */     return !CollectionUtils.isEmpty(result) ? new ConsumesRequestCondition(result) : null;
/*     */   }
/*     */   
/*     */   private boolean hasBody(HttpServletRequest request) {
/* 228 */     String contentLength = request.getHeader("Content-Length");
/* 229 */     String transferEncoding = request.getHeader("Transfer-Encoding");
/* 230 */     return (StringUtils.hasText(transferEncoding)) || (
/* 231 */       (StringUtils.hasText(contentLength)) && (!contentLength.trim().equals("0")));
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private List<ConsumeMediaTypeExpression> getMatchingExpressions(MediaType contentType) {
/* 236 */     List<ConsumeMediaTypeExpression> result = null;
/* 237 */     for (ConsumeMediaTypeExpression expression : this.expressions) {
/* 238 */       if (expression.match(contentType)) {
/* 239 */         result = result != null ? result : new ArrayList();
/* 240 */         result.add(expression);
/*     */       }
/*     */     }
/* 243 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int compareTo(ConsumesRequestCondition other, HttpServletRequest request)
/*     */   {
/* 259 */     if ((this.expressions.isEmpty()) && (other.expressions.isEmpty())) {
/* 260 */       return 0;
/*     */     }
/* 262 */     if (this.expressions.isEmpty()) {
/* 263 */       return 1;
/*     */     }
/* 265 */     if (other.expressions.isEmpty()) {
/* 266 */       return -1;
/*     */     }
/*     */     
/* 269 */     return ((ConsumeMediaTypeExpression)this.expressions.get(0)).compareTo((AbstractMediaTypeExpression)other.expressions.get(0));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static class ConsumeMediaTypeExpression
/*     */     extends AbstractMediaTypeExpression
/*     */   {
/*     */     ConsumeMediaTypeExpression(String expression)
/*     */     {
/* 280 */       super();
/*     */     }
/*     */     
/*     */     ConsumeMediaTypeExpression(MediaType mediaType, boolean negated) {
/* 284 */       super(negated);
/*     */     }
/*     */     
/*     */     public final boolean match(MediaType contentType) {
/* 288 */       boolean match = getMediaType().includes(contentType);
/* 289 */       return (!isNegated()) == match;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\mvc\condition\ConsumesRequestCondition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */