package org.springframework.web.servlet.mvc.condition;

import javax.servlet.http.HttpServletRequest;
import org.springframework.lang.Nullable;

public abstract interface RequestCondition<T>
{
  public abstract T combine(T paramT);
  
  @Nullable
  public abstract T getMatchingCondition(HttpServletRequest paramHttpServletRequest);
  
  public abstract int compareTo(T paramT, HttpServletRequest paramHttpServletRequest);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\mvc\condition\RequestCondition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */