package org.springframework.web.servlet.tags;

import javax.servlet.jsp.JspTagException;
import org.springframework.lang.Nullable;

public abstract interface ArgumentAware
{
  public abstract void addArgument(@Nullable Object paramObject)
    throws JspTagException;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\tags\ArgumentAware.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */