/*     */ package org.springframework.web.servlet.view.freemarker;
/*     */ 
/*     */ import freemarker.core.ParseException;
/*     */ import freemarker.ext.jsp.TaglibFactory;
/*     */ import freemarker.ext.servlet.AllHttpScopesHashModel;
/*     */ import freemarker.ext.servlet.HttpRequestHashModel;
/*     */ import freemarker.ext.servlet.HttpRequestParametersHashModel;
/*     */ import freemarker.ext.servlet.HttpSessionHashModel;
/*     */ import freemarker.ext.servlet.ServletContextHashModel;
/*     */ import freemarker.template.Configuration;
/*     */ import freemarker.template.DefaultObjectWrapperBuilder;
/*     */ import freemarker.template.ObjectWrapper;
/*     */ import freemarker.template.SimpleHash;
/*     */ import freemarker.template.Template;
/*     */ import freemarker.template.TemplateException;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import javax.servlet.GenericServlet;
/*     */ import javax.servlet.ServletConfig;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanFactoryUtils;
/*     */ import org.springframework.beans.factory.BeanInitializationException;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.context.ApplicationContextException;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.servlet.support.RequestContextUtils;
/*     */ import org.springframework.web.servlet.view.AbstractTemplateView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FreeMarkerView
/*     */   extends AbstractTemplateView
/*     */ {
/*     */   @Nullable
/*     */   private String encoding;
/*     */   @Nullable
/*     */   private Configuration configuration;
/*     */   @Nullable
/*     */   private TaglibFactory taglibFactory;
/*     */   @Nullable
/*     */   private ServletContextHashModel servletContextHashModel;
/*     */   
/*     */   public void setEncoding(@Nullable String encoding)
/*     */   {
/* 112 */     this.encoding = encoding;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected String getEncoding()
/*     */   {
/* 120 */     return this.encoding;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setConfiguration(@Nullable Configuration configuration)
/*     */   {
/* 133 */     this.configuration = configuration;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected Configuration getConfiguration()
/*     */   {
/* 141 */     return this.configuration;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Configuration obtainConfiguration()
/*     */   {
/* 151 */     Configuration configuration = getConfiguration();
/* 152 */     Assert.state(configuration != null, "No Configuration set");
/* 153 */     return configuration;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void initServletContext(ServletContext servletContext)
/*     */     throws BeansException
/*     */   {
/* 167 */     if (getConfiguration() != null) {
/* 168 */       this.taglibFactory = new TaglibFactory(servletContext);
/*     */     }
/*     */     else {
/* 171 */       FreeMarkerConfig config = autodetectConfiguration();
/* 172 */       setConfiguration(config.getConfiguration());
/* 173 */       this.taglibFactory = config.getTaglibFactory();
/*     */     }
/*     */     
/* 176 */     GenericServlet servlet = new GenericServletAdapter(null);
/*     */     try {
/* 178 */       servlet.init(new DelegatingServletConfig(null));
/*     */     }
/*     */     catch (ServletException ex) {
/* 181 */       throw new BeanInitializationException("Initialization of GenericServlet adapter failed", ex);
/*     */     }
/* 183 */     this.servletContextHashModel = new ServletContextHashModel(servlet, getObjectWrapper());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected FreeMarkerConfig autodetectConfiguration()
/*     */     throws BeansException
/*     */   {
/*     */     try
/*     */     {
/* 195 */       return (FreeMarkerConfig)BeanFactoryUtils.beanOfTypeIncludingAncestors(
/* 196 */         obtainApplicationContext(), FreeMarkerConfig.class, true, false);
/*     */     }
/*     */     catch (NoSuchBeanDefinitionException ex) {
/* 199 */       throw new ApplicationContextException("Must define a single FreeMarkerConfig bean in this web application context (may be inherited): FreeMarkerConfigurer is the usual implementation. This bean may be given any name.", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ObjectWrapper getObjectWrapper()
/*     */   {
/* 212 */     ObjectWrapper ow = obtainConfiguration().getObjectWrapper();
/* 213 */     return ow != null ? ow : new DefaultObjectWrapperBuilder(Configuration.DEFAULT_INCOMPATIBLE_IMPROVEMENTS)
/* 214 */       .build();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean checkResource(Locale locale)
/*     */     throws Exception
/*     */   {
/* 224 */     String url = getUrl();
/* 225 */     Assert.state(url != null, "'url' not set");
/*     */     
/*     */     try
/*     */     {
/* 229 */       getTemplate(url, locale);
/* 230 */       return true;
/*     */     }
/*     */     catch (FileNotFoundException ex)
/*     */     {
/* 234 */       return false;
/*     */     }
/*     */     catch (ParseException ex) {
/* 237 */       throw new ApplicationContextException("Failed to parse [" + url + "]", ex);
/*     */     }
/*     */     catch (IOException ex) {
/* 240 */       throw new ApplicationContextException("Failed to load [" + url + "]", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void renderMergedTemplateModel(Map<String, Object> model, HttpServletRequest request, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/* 254 */     exposeHelpers(model, request);
/* 255 */     doRender(model, request, response);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void exposeHelpers(Map<String, Object> model, HttpServletRequest request)
/*     */     throws Exception
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void doRender(Map<String, Object> model, HttpServletRequest request, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/* 298 */     exposeModelAsRequestAttributes(model, request);
/*     */     
/* 300 */     SimpleHash fmModel = buildTemplateModel(model, request, response);
/*     */     
/*     */ 
/* 303 */     Locale locale = RequestContextUtils.getLocale(request);
/* 304 */     processTemplate(getTemplate(locale), fmModel, response);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected SimpleHash buildTemplateModel(Map<String, Object> model, HttpServletRequest request, HttpServletResponse response)
/*     */   {
/* 318 */     AllHttpScopesHashModel fmModel = new AllHttpScopesHashModel(getObjectWrapper(), getServletContext(), request);
/* 319 */     fmModel.put("JspTaglibs", this.taglibFactory);
/* 320 */     fmModel.put("Application", this.servletContextHashModel);
/* 321 */     fmModel.put("Session", buildSessionModel(request, response));
/* 322 */     fmModel.put("Request", new HttpRequestHashModel(request, response, getObjectWrapper()));
/* 323 */     fmModel.put("RequestParameters", new HttpRequestParametersHashModel(request));
/* 324 */     fmModel.putAll(model);
/* 325 */     return fmModel;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private HttpSessionHashModel buildSessionModel(HttpServletRequest request, HttpServletResponse response)
/*     */   {
/* 336 */     HttpSession session = request.getSession(false);
/* 337 */     if (session != null) {
/* 338 */       return new HttpSessionHashModel(session, getObjectWrapper());
/*     */     }
/*     */     
/* 341 */     return new HttpSessionHashModel(null, request, response, getObjectWrapper());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Template getTemplate(Locale locale)
/*     */     throws IOException
/*     */   {
/* 357 */     String url = getUrl();
/* 358 */     Assert.state(url != null, "'url' not set");
/* 359 */     return getTemplate(url, locale);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Template getTemplate(String name, Locale locale)
/*     */     throws IOException
/*     */   {
/* 373 */     return getEncoding() != null ? 
/* 374 */       obtainConfiguration().getTemplate(name, locale, getEncoding()) : 
/* 375 */       obtainConfiguration().getTemplate(name, locale);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void processTemplate(Template template, SimpleHash model, HttpServletResponse response)
/*     */     throws IOException, TemplateException
/*     */   {
/* 391 */     template.process(model, response.getWriter());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private class DelegatingServletConfig
/*     */     implements ServletConfig
/*     */   {
/*     */     private DelegatingServletConfig() {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     @Nullable
/*     */     public String getServletName()
/*     */     {
/* 418 */       return FreeMarkerView.this.getBeanName();
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     public ServletContext getServletContext()
/*     */     {
/* 424 */       return FreeMarkerView.this.getServletContext();
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     public String getInitParameter(String paramName)
/*     */     {
/* 430 */       return null;
/*     */     }
/*     */     
/*     */     public Enumeration<String> getInitParameterNames()
/*     */     {
/* 435 */       return Collections.enumeration(Collections.emptySet());
/*     */     }
/*     */   }
/*     */   
/*     */   private static class GenericServletAdapter
/*     */     extends GenericServlet
/*     */   {
/*     */     public void service(ServletRequest servletRequest, ServletResponse servletResponse) {}
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\view\freemarker\FreeMarkerView.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */