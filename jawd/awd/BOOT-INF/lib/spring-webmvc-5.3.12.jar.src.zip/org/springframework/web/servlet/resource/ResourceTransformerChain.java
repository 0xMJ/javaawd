package org.springframework.web.servlet.resource;

import java.io.IOException;
import javax.servlet.http.HttpServletRequest;
import org.springframework.core.io.Resource;

public abstract interface ResourceTransformerChain
{
  public abstract ResourceResolverChain getResolverChain();
  
  public abstract Resource transform(HttpServletRequest paramHttpServletRequest, Resource paramResource)
    throws IOException;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\resource\ResourceTransformerChain.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */