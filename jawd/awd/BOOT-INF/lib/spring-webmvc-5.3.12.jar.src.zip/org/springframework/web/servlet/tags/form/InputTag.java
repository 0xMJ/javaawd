/*     */ package org.springframework.web.servlet.tags.form;
/*     */ 
/*     */ import java.util.Map;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InputTag
/*     */   extends AbstractHtmlInputElementTag
/*     */ {
/*     */   public static final String SIZE_ATTRIBUTE = "size";
/*     */   public static final String MAXLENGTH_ATTRIBUTE = "maxlength";
/*     */   public static final String ALT_ATTRIBUTE = "alt";
/*     */   public static final String ONSELECT_ATTRIBUTE = "onselect";
/*     */   public static final String AUTOCOMPLETE_ATTRIBUTE = "autocomplete";
/*     */   @Nullable
/*     */   private String size;
/*     */   @Nullable
/*     */   private String maxlength;
/*     */   @Nullable
/*     */   private String alt;
/*     */   @Nullable
/*     */   private String onselect;
/*     */   @Nullable
/*     */   private String autocomplete;
/*     */   
/*     */   public void setSize(String size)
/*     */   {
/* 272 */     this.size = size;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected String getSize()
/*     */   {
/* 280 */     return this.size;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMaxlength(String maxlength)
/*     */   {
/* 288 */     this.maxlength = maxlength;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected String getMaxlength()
/*     */   {
/* 296 */     return this.maxlength;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAlt(String alt)
/*     */   {
/* 304 */     this.alt = alt;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected String getAlt()
/*     */   {
/* 312 */     return this.alt;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOnselect(String onselect)
/*     */   {
/* 320 */     this.onselect = onselect;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected String getOnselect()
/*     */   {
/* 328 */     return this.onselect;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAutocomplete(String autocomplete)
/*     */   {
/* 336 */     this.autocomplete = autocomplete;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected String getAutocomplete()
/*     */   {
/* 344 */     return this.autocomplete;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int writeTagContent(TagWriter tagWriter)
/*     */     throws JspException
/*     */   {
/* 355 */     tagWriter.startTag("input");
/*     */     
/* 357 */     writeDefaultAttributes(tagWriter);
/* 358 */     Map<String, Object> attributes = getDynamicAttributes();
/* 359 */     if ((attributes == null) || (!attributes.containsKey("type"))) {
/* 360 */       tagWriter.writeAttribute("type", getType());
/*     */     }
/* 362 */     writeValue(tagWriter);
/*     */     
/*     */ 
/* 365 */     writeOptionalAttribute(tagWriter, "size", getSize());
/* 366 */     writeOptionalAttribute(tagWriter, "maxlength", getMaxlength());
/* 367 */     writeOptionalAttribute(tagWriter, "alt", getAlt());
/* 368 */     writeOptionalAttribute(tagWriter, "onselect", getOnselect());
/* 369 */     writeOptionalAttribute(tagWriter, "autocomplete", getAutocomplete());
/*     */     
/* 371 */     tagWriter.endTag();
/* 372 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void writeValue(TagWriter tagWriter)
/*     */     throws JspException
/*     */   {
/* 381 */     String value = getDisplayString(getBoundValue(), getPropertyEditor());
/* 382 */     String type = null;
/* 383 */     Map<String, Object> attributes = getDynamicAttributes();
/* 384 */     if (attributes != null) {
/* 385 */       type = (String)attributes.get("type");
/*     */     }
/* 387 */     if (type == null) {
/* 388 */       type = getType();
/*     */     }
/* 390 */     tagWriter.writeAttribute("value", processFieldValue(getName(), value, type));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isValidDynamicAttribute(String localName, Object value)
/*     */   {
/* 399 */     return (!"type".equals(localName)) || ((!"checkbox".equals(value)) && (!"radio".equals(value)));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getType()
/*     */   {
/* 408 */     return "text";
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\tags\form\InputTag.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */