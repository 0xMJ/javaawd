/*     */ package org.springframework.web.servlet.view.tiles3;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import javax.el.ArrayELResolver;
/*     */ import javax.el.BeanELResolver;
/*     */ import javax.el.CompositeELResolver;
/*     */ import javax.el.ListELResolver;
/*     */ import javax.el.MapELResolver;
/*     */ import javax.el.ResourceBundleELResolver;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.jsp.JspApplicationContext;
/*     */ import javax.servlet.jsp.JspFactory;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.tiles.TilesContainer;
/*     */ import org.apache.tiles.TilesException;
/*     */ import org.apache.tiles.definition.DefinitionsFactory;
/*     */ import org.apache.tiles.definition.DefinitionsReader;
/*     */ import org.apache.tiles.definition.dao.BaseLocaleUrlDefinitionDAO;
/*     */ import org.apache.tiles.definition.dao.CachingLocaleUrlDefinitionDAO;
/*     */ import org.apache.tiles.definition.digester.DigesterDefinitionsReader;
/*     */ import org.apache.tiles.el.ELAttributeEvaluator;
/*     */ import org.apache.tiles.el.ScopeELResolver;
/*     */ import org.apache.tiles.el.TilesContextBeanELResolver;
/*     */ import org.apache.tiles.el.TilesContextELResolver;
/*     */ import org.apache.tiles.evaluator.AttributeEvaluator;
/*     */ import org.apache.tiles.evaluator.AttributeEvaluatorFactory;
/*     */ import org.apache.tiles.evaluator.BasicAttributeEvaluatorFactory;
/*     */ import org.apache.tiles.evaluator.impl.DirectAttributeEvaluator;
/*     */ import org.apache.tiles.extras.complete.CompleteAutoloadTilesContainerFactory;
/*     */ import org.apache.tiles.extras.complete.CompleteAutoloadTilesInitializer;
/*     */ import org.apache.tiles.factory.AbstractTilesContainerFactory;
/*     */ import org.apache.tiles.factory.BasicTilesContainerFactory;
/*     */ import org.apache.tiles.impl.mgmt.CachingTilesContainer;
/*     */ import org.apache.tiles.locale.LocaleResolver;
/*     */ import org.apache.tiles.preparer.factory.PreparerFactory;
/*     */ import org.apache.tiles.request.ApplicationContext;
/*     */ import org.apache.tiles.request.ApplicationContextAware;
/*     */ import org.apache.tiles.request.ApplicationResource;
/*     */ import org.apache.tiles.startup.DefaultTilesInitializer;
/*     */ import org.apache.tiles.startup.TilesInitializer;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.BeanWrapper;
/*     */ import org.springframework.beans.PropertyAccessorFactory;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.web.context.ServletContextAware;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TilesConfigurer
/*     */   implements ServletContextAware, InitializingBean, DisposableBean
/*     */ {
/* 131 */   private static final boolean tilesElPresent = ClassUtils.isPresent("org.apache.tiles.el.ELAttributeEvaluator", TilesConfigurer.class.getClassLoader());
/*     */   
/*     */ 
/* 134 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/*     */   @Nullable
/*     */   private TilesInitializer tilesInitializer;
/*     */   
/*     */   @Nullable
/*     */   private String[] definitions;
/*     */   
/* 142 */   private boolean checkRefresh = false;
/*     */   
/* 144 */   private boolean validateDefinitions = true;
/*     */   
/*     */   @Nullable
/*     */   private Class<? extends DefinitionsFactory> definitionsFactoryClass;
/*     */   
/*     */   @Nullable
/*     */   private Class<? extends PreparerFactory> preparerFactoryClass;
/*     */   
/* 152 */   private boolean useMutableTilesContainer = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   private ServletContext servletContext;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTilesInitializer(TilesInitializer tilesInitializer)
/*     */   {
/* 167 */     this.tilesInitializer = tilesInitializer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCompleteAutoload(boolean completeAutoload)
/*     */   {
/* 181 */     if (completeAutoload) {
/*     */       try {
/* 183 */         this.tilesInitializer = new SpringCompleteAutoloadTilesInitializer(null);
/*     */       }
/*     */       catch (Throwable ex) {
/* 186 */         throw new IllegalStateException("Tiles-Extras 3.0 not available", ex);
/*     */       }
/*     */       
/*     */     } else {
/* 190 */       this.tilesInitializer = null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDefinitions(String... definitions)
/*     */   {
/* 199 */     this.definitions = definitions;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCheckRefresh(boolean checkRefresh)
/*     */   {
/* 207 */     this.checkRefresh = checkRefresh;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setValidateDefinitions(boolean validateDefinitions)
/*     */   {
/* 214 */     this.validateDefinitions = validateDefinitions;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDefinitionsFactoryClass(Class<? extends DefinitionsFactory> definitionsFactoryClass)
/*     */   {
/* 227 */     this.definitionsFactoryClass = definitionsFactoryClass;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPreparerFactoryClass(Class<? extends PreparerFactory> preparerFactoryClass)
/*     */   {
/* 250 */     this.preparerFactoryClass = preparerFactoryClass;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUseMutableTilesContainer(boolean useMutableTilesContainer)
/*     */   {
/* 260 */     this.useMutableTilesContainer = useMutableTilesContainer;
/*     */   }
/*     */   
/*     */   public void setServletContext(ServletContext servletContext)
/*     */   {
/* 265 */     this.servletContext = servletContext;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */     throws TilesException
/*     */   {
/* 275 */     Assert.state(this.servletContext != null, "No ServletContext available");
/* 276 */     ApplicationContext preliminaryContext = new SpringWildcardServletTilesApplicationContext(this.servletContext);
/* 277 */     if (this.tilesInitializer == null) {
/* 278 */       this.tilesInitializer = new SpringTilesInitializer(null);
/*     */     }
/* 280 */     this.tilesInitializer.initialize(preliminaryContext);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void destroy()
/*     */     throws TilesException
/*     */   {
/* 289 */     if (this.tilesInitializer != null) {
/* 290 */       this.tilesInitializer.destroy();
/*     */     }
/*     */   }
/*     */   
/*     */   private class SpringTilesInitializer extends DefaultTilesInitializer
/*     */   {
/*     */     private SpringTilesInitializer() {}
/*     */     
/*     */     protected AbstractTilesContainerFactory createContainerFactory(ApplicationContext context) {
/* 299 */       return new TilesConfigurer.SpringTilesContainerFactory(TilesConfigurer.this, null);
/*     */     }
/*     */   }
/*     */   
/*     */   private class SpringTilesContainerFactory extends BasicTilesContainerFactory
/*     */   {
/*     */     private SpringTilesContainerFactory() {}
/*     */     
/*     */     protected TilesContainer createDecoratedContainer(TilesContainer originalContainer, ApplicationContext context) {
/* 308 */       return TilesConfigurer.this.useMutableTilesContainer ? new CachingTilesContainer(originalContainer) : originalContainer;
/*     */     }
/*     */     
/*     */     protected List<ApplicationResource> getSources(ApplicationContext applicationContext)
/*     */     {
/* 313 */       if (TilesConfigurer.this.definitions != null) {
/* 314 */         List<ApplicationResource> result = new ArrayList();
/* 315 */         for (String definition : TilesConfigurer.this.definitions) {
/* 316 */           Collection<ApplicationResource> resources = applicationContext.getResources(definition);
/* 317 */           if (resources != null) {
/* 318 */             result.addAll(resources);
/*     */           }
/*     */         }
/* 321 */         return result;
/*     */       }
/*     */       
/* 324 */       return super.getSources(applicationContext);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     protected BaseLocaleUrlDefinitionDAO instantiateLocaleDefinitionDao(ApplicationContext applicationContext, LocaleResolver resolver)
/*     */     {
/* 331 */       BaseLocaleUrlDefinitionDAO dao = super.instantiateLocaleDefinitionDao(applicationContext, resolver);
/* 332 */       if ((TilesConfigurer.this.checkRefresh) && ((dao instanceof CachingLocaleUrlDefinitionDAO))) {
/* 333 */         ((CachingLocaleUrlDefinitionDAO)dao).setCheckRefresh(true);
/*     */       }
/* 335 */       return dao;
/*     */     }
/*     */     
/*     */     protected DefinitionsReader createDefinitionsReader(ApplicationContext context)
/*     */     {
/* 340 */       DigesterDefinitionsReader reader = (DigesterDefinitionsReader)super.createDefinitionsReader(context);
/* 341 */       reader.setValidating(TilesConfigurer.this.validateDefinitions);
/* 342 */       return reader;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     protected DefinitionsFactory createDefinitionsFactory(ApplicationContext applicationContext, LocaleResolver resolver)
/*     */     {
/* 349 */       if (TilesConfigurer.this.definitionsFactoryClass != null) {
/* 350 */         DefinitionsFactory factory = (DefinitionsFactory)BeanUtils.instantiateClass(TilesConfigurer.this.definitionsFactoryClass);
/* 351 */         if ((factory instanceof ApplicationContextAware)) {
/* 352 */           ((ApplicationContextAware)factory).setApplicationContext(applicationContext);
/*     */         }
/* 354 */         BeanWrapper bw = PropertyAccessorFactory.forBeanPropertyAccess(factory);
/* 355 */         if (bw.isWritableProperty("localeResolver")) {
/* 356 */           bw.setPropertyValue("localeResolver", resolver);
/*     */         }
/* 358 */         if (bw.isWritableProperty("definitionDAO")) {
/* 359 */           bw.setPropertyValue("definitionDAO", createLocaleDefinitionDao(applicationContext, resolver));
/*     */         }
/* 361 */         return factory;
/*     */       }
/*     */       
/* 364 */       return super.createDefinitionsFactory(applicationContext, resolver);
/*     */     }
/*     */     
/*     */ 
/*     */     protected PreparerFactory createPreparerFactory(ApplicationContext context)
/*     */     {
/* 370 */       if (TilesConfigurer.this.preparerFactoryClass != null) {
/* 371 */         return (PreparerFactory)BeanUtils.instantiateClass(TilesConfigurer.this.preparerFactoryClass);
/*     */       }
/*     */       
/* 374 */       return super.createPreparerFactory(context);
/*     */     }
/*     */     
/*     */ 
/*     */     protected LocaleResolver createLocaleResolver(ApplicationContext context)
/*     */     {
/* 380 */       return new SpringLocaleResolver();
/*     */     }
/*     */     
/*     */     protected AttributeEvaluatorFactory createAttributeEvaluatorFactory(ApplicationContext context, LocaleResolver resolver)
/*     */     {
/*     */       AttributeEvaluator evaluator;
/*     */       AttributeEvaluator evaluator;
/* 387 */       if ((TilesConfigurer.tilesElPresent) && (JspFactory.getDefaultFactory() != null)) {
/* 388 */         evaluator = new TilesConfigurer.TilesElActivator(TilesConfigurer.this, null).createEvaluator();
/*     */       }
/*     */       else {
/* 391 */         evaluator = new DirectAttributeEvaluator();
/*     */       }
/* 393 */       return new BasicAttributeEvaluatorFactory(evaluator);
/*     */     }
/*     */   }
/*     */   
/*     */   private static class SpringCompleteAutoloadTilesInitializer
/*     */     extends CompleteAutoloadTilesInitializer
/*     */   {
/*     */     protected AbstractTilesContainerFactory createContainerFactory(ApplicationContext context)
/*     */     {
/* 402 */       return new TilesConfigurer.SpringCompleteAutoloadTilesContainerFactory(null);
/*     */     }
/*     */   }
/*     */   
/*     */   private static class SpringCompleteAutoloadTilesContainerFactory
/*     */     extends CompleteAutoloadTilesContainerFactory
/*     */   {
/*     */     protected LocaleResolver createLocaleResolver(ApplicationContext applicationContext)
/*     */     {
/* 411 */       return new SpringLocaleResolver();
/*     */     }
/*     */   }
/*     */   
/*     */   private class TilesElActivator {
/*     */     private TilesElActivator() {}
/*     */     
/*     */     public AttributeEvaluator createEvaluator() {
/* 419 */       ELAttributeEvaluator evaluator = new ELAttributeEvaluator();
/* 420 */       evaluator.setExpressionFactory(
/* 421 */         JspFactory.getDefaultFactory().getJspApplicationContext(TilesConfigurer.this.servletContext).getExpressionFactory());
/* 422 */       evaluator.setResolver(new TilesConfigurer.CompositeELResolverImpl());
/* 423 */       return evaluator;
/*     */     }
/*     */   }
/*     */   
/*     */   private static class CompositeELResolverImpl extends CompositeELResolver
/*     */   {
/*     */     public CompositeELResolverImpl()
/*     */     {
/* 431 */       add(new ScopeELResolver());
/* 432 */       add(new TilesContextELResolver(new TilesContextBeanELResolver()));
/* 433 */       add(new TilesContextBeanELResolver());
/* 434 */       add(new ArrayELResolver(false));
/* 435 */       add(new ListELResolver(false));
/* 436 */       add(new MapELResolver(false));
/* 437 */       add(new ResourceBundleELResolver());
/* 438 */       add(new BeanELResolver(false));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\view\tiles3\TilesConfigurer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */