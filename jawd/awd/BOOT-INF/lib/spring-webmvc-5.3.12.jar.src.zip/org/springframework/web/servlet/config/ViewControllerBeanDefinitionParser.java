/*     */ package org.springframework.web.servlet.config;
/*     */ 
/*     */ import java.util.Map;
/*     */ import org.springframework.beans.MutablePropertyValues;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.ConstructorArgumentValues;
/*     */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*     */ import org.springframework.beans.factory.parsing.BeanComponentDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.ManagedMap;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.beans.factory.xml.BeanDefinitionParser;
/*     */ import org.springframework.beans.factory.xml.ParserContext;
/*     */ import org.springframework.http.HttpStatus;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.web.servlet.handler.SimpleUrlHandlerMapping;
/*     */ import org.springframework.web.servlet.mvc.ParameterizableViewController;
/*     */ import org.springframework.web.servlet.view.RedirectView;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ViewControllerBeanDefinitionParser
/*     */   implements BeanDefinitionParser
/*     */ {
/*     */   private static final String HANDLER_MAPPING_BEAN_NAME = "org.springframework.web.servlet.config.viewControllerHandlerMapping";
/*     */   
/*     */   public BeanDefinition parse(Element element, ParserContext parserContext)
/*     */   {
/*  65 */     Object source = parserContext.extractSource(element);
/*     */     
/*     */ 
/*  68 */     BeanDefinition hm = registerHandlerMapping(parserContext, source);
/*     */     
/*     */ 
/*  71 */     MvcNamespaceUtils.registerDefaultComponents(parserContext, source);
/*     */     
/*     */ 
/*  74 */     RootBeanDefinition controller = new RootBeanDefinition(ParameterizableViewController.class);
/*  75 */     controller.setSource(source);
/*     */     
/*  77 */     HttpStatus statusCode = null;
/*  78 */     if (element.hasAttribute("status-code")) {
/*  79 */       int statusValue = Integer.parseInt(element.getAttribute("status-code"));
/*  80 */       statusCode = HttpStatus.valueOf(statusValue);
/*     */     }
/*     */     
/*  83 */     String name = element.getLocalName();
/*  84 */     switch (name) {
/*     */     case "view-controller": 
/*  86 */       if (element.hasAttribute("view-name")) {
/*  87 */         controller.getPropertyValues().add("viewName", element.getAttribute("view-name"));
/*     */       }
/*  89 */       if (statusCode != null) {
/*  90 */         controller.getPropertyValues().add("statusCode", statusCode);
/*     */       }
/*     */       break;
/*     */     case "redirect-view-controller": 
/*  94 */       controller.getPropertyValues().add("view", getRedirectView(element, statusCode, source));
/*  95 */       break;
/*     */     case "status-controller": 
/*  97 */       controller.getPropertyValues().add("statusCode", statusCode);
/*  98 */       controller.getPropertyValues().add("statusOnly", Boolean.valueOf(true));
/*  99 */       break;
/*     */     
/*     */     default: 
/* 102 */       throw new IllegalStateException("Unexpected tag name: " + name);
/*     */     }
/*     */     
/* 105 */     Object urlMap = (Map)hm.getPropertyValues().get("urlMap");
/* 106 */     if (urlMap == null) {
/* 107 */       urlMap = new ManagedMap();
/* 108 */       hm.getPropertyValues().add("urlMap", urlMap);
/*     */     }
/* 110 */     ((Map)urlMap).put(element.getAttribute("path"), controller);
/*     */     
/* 112 */     return null;
/*     */   }
/*     */   
/*     */   private BeanDefinition registerHandlerMapping(ParserContext context, @Nullable Object source) {
/* 116 */     if (context.getRegistry().containsBeanDefinition("org.springframework.web.servlet.config.viewControllerHandlerMapping")) {
/* 117 */       return context.getRegistry().getBeanDefinition("org.springframework.web.servlet.config.viewControllerHandlerMapping");
/*     */     }
/* 119 */     RootBeanDefinition beanDef = new RootBeanDefinition(SimpleUrlHandlerMapping.class);
/* 120 */     beanDef.setRole(2);
/* 121 */     context.getRegistry().registerBeanDefinition("org.springframework.web.servlet.config.viewControllerHandlerMapping", beanDef);
/* 122 */     context.registerComponent(new BeanComponentDefinition(beanDef, "org.springframework.web.servlet.config.viewControllerHandlerMapping"));
/*     */     
/* 124 */     beanDef.setSource(source);
/* 125 */     beanDef.getPropertyValues().add("order", "1");
/* 126 */     beanDef.getPropertyValues().add("pathMatcher", MvcNamespaceUtils.registerPathMatcher(null, context, source));
/* 127 */     beanDef.getPropertyValues().add("urlPathHelper", MvcNamespaceUtils.registerUrlPathHelper(null, context, source));
/* 128 */     RuntimeBeanReference corsConfigurationsRef = MvcNamespaceUtils.registerCorsConfigurations(null, context, source);
/* 129 */     beanDef.getPropertyValues().add("corsConfigurations", corsConfigurationsRef);
/*     */     
/* 131 */     return beanDef;
/*     */   }
/*     */   
/*     */   private RootBeanDefinition getRedirectView(Element element, @Nullable HttpStatus status, @Nullable Object source) {
/* 135 */     RootBeanDefinition redirectView = new RootBeanDefinition(RedirectView.class);
/* 136 */     redirectView.setSource(source);
/* 137 */     redirectView.getConstructorArgumentValues().addIndexedArgumentValue(0, element.getAttribute("redirect-url"));
/*     */     
/* 139 */     if (status != null) {
/* 140 */       redirectView.getPropertyValues().add("statusCode", status);
/*     */     }
/*     */     
/* 143 */     if (element.hasAttribute("context-relative")) {
/* 144 */       redirectView.getPropertyValues().add("contextRelative", element.getAttribute("context-relative"));
/*     */     }
/*     */     else {
/* 147 */       redirectView.getPropertyValues().add("contextRelative", Boolean.valueOf(true));
/*     */     }
/*     */     
/* 150 */     if (element.hasAttribute("keep-query-params")) {
/* 151 */       redirectView.getPropertyValues().add("propagateQueryParams", element.getAttribute("keep-query-params"));
/*     */     }
/*     */     
/* 154 */     return redirectView;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\config\ViewControllerBeanDefinitionParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */