/*     */ package org.springframework.web.servlet.support;
/*     */ 
/*     */ import java.util.EnumSet;
/*     */ import javax.servlet.DispatcherType;
/*     */ import javax.servlet.Filter;
/*     */ import javax.servlet.FilterRegistration.Dynamic;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletRegistration.Dynamic;
/*     */ import org.springframework.context.ApplicationContextInitializer;
/*     */ import org.springframework.core.Conventions;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.web.context.AbstractContextLoaderInitializer;
/*     */ import org.springframework.web.context.WebApplicationContext;
/*     */ import org.springframework.web.servlet.DispatcherServlet;
/*     */ import org.springframework.web.servlet.FrameworkServlet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractDispatcherServletInitializer
/*     */   extends AbstractContextLoaderInitializer
/*     */ {
/*     */   public static final String DEFAULT_SERVLET_NAME = "dispatcher";
/*     */   
/*     */   public void onStartup(ServletContext servletContext)
/*     */     throws ServletException
/*     */   {
/*  63 */     super.onStartup(servletContext);
/*  64 */     registerDispatcherServlet(servletContext);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void registerDispatcherServlet(ServletContext servletContext)
/*     */   {
/*  79 */     String servletName = getServletName();
/*  80 */     Assert.hasLength(servletName, "getServletName() must not return null or empty");
/*     */     
/*  82 */     WebApplicationContext servletAppContext = createServletApplicationContext();
/*  83 */     Assert.notNull(servletAppContext, "createServletApplicationContext() must not return null");
/*     */     
/*  85 */     FrameworkServlet dispatcherServlet = createDispatcherServlet(servletAppContext);
/*  86 */     Assert.notNull(dispatcherServlet, "createDispatcherServlet(WebApplicationContext) must not return null");
/*  87 */     dispatcherServlet.setContextInitializers(getServletApplicationContextInitializers());
/*     */     
/*  89 */     ServletRegistration.Dynamic registration = servletContext.addServlet(servletName, dispatcherServlet);
/*  90 */     if (registration == null) {
/*  91 */       throw new IllegalStateException("Failed to register servlet with name '" + servletName + "'. Check if there is another servlet registered under the same name.");
/*     */     }
/*     */     
/*     */ 
/*  95 */     registration.setLoadOnStartup(1);
/*  96 */     registration.addMapping(getServletMappings());
/*  97 */     registration.setAsyncSupported(isAsyncSupported());
/*     */     
/*  99 */     Filter[] filters = getServletFilters();
/* 100 */     if (!ObjectUtils.isEmpty(filters)) {
/* 101 */       for (Filter filter : filters) {
/* 102 */         registerServletFilter(servletContext, filter);
/*     */       }
/*     */     }
/*     */     
/* 106 */     customizeRegistration(registration);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getServletName()
/*     */   {
/* 115 */     return "dispatcher";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract WebApplicationContext createServletApplicationContext();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected FrameworkServlet createDispatcherServlet(WebApplicationContext servletAppContext)
/*     */   {
/* 135 */     return new DispatcherServlet(servletAppContext);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected ApplicationContextInitializer<?>[] getServletApplicationContextInitializers()
/*     */   {
/* 148 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract String[] getServletMappings();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected Filter[] getServletFilters()
/*     */   {
/* 165 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected FilterRegistration.Dynamic registerServletFilter(ServletContext servletContext, Filter filter)
/*     */   {
/* 186 */     String filterName = Conventions.getVariableName(filter);
/* 187 */     FilterRegistration.Dynamic registration = servletContext.addFilter(filterName, filter);
/*     */     
/* 189 */     if (registration == null) {
/* 190 */       int counter = 0;
/* 191 */       while (registration == null) {
/* 192 */         if (counter == 100) {
/* 193 */           throw new IllegalStateException("Failed to register filter with name '" + filterName + "'. Check if there is another filter registered under the same name.");
/*     */         }
/*     */         
/* 196 */         registration = servletContext.addFilter(filterName + "#" + counter, filter);
/* 197 */         counter++;
/*     */       }
/*     */     }
/*     */     
/* 201 */     registration.setAsyncSupported(isAsyncSupported());
/* 202 */     registration.addMappingForServletNames(getDispatcherTypes(), false, new String[] { getServletName() });
/* 203 */     return registration;
/*     */   }
/*     */   
/*     */   private EnumSet<DispatcherType> getDispatcherTypes() {
/* 207 */     return isAsyncSupported() ? 
/* 208 */       EnumSet.of(DispatcherType.REQUEST, DispatcherType.FORWARD, DispatcherType.INCLUDE, DispatcherType.ASYNC) : 
/* 209 */       EnumSet.of(DispatcherType.REQUEST, DispatcherType.FORWARD, DispatcherType.INCLUDE);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isAsyncSupported()
/*     */   {
/* 218 */     return true;
/*     */   }
/*     */   
/*     */   protected void customizeRegistration(ServletRegistration.Dynamic registration) {}
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\support\AbstractDispatcherServletInitializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */