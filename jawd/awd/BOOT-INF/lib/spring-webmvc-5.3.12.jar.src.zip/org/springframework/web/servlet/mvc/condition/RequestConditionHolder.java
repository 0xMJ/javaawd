/*     */ package org.springframework.web.servlet.mvc.condition;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RequestConditionHolder
/*     */   extends AbstractRequestCondition<RequestConditionHolder>
/*     */ {
/*     */   @Nullable
/*     */   private final RequestCondition<Object> condition;
/*     */   
/*     */   public RequestConditionHolder(@Nullable RequestCondition<?> requestCondition)
/*     */   {
/*  52 */     this.condition = requestCondition;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public RequestCondition<?> getCondition()
/*     */   {
/*  61 */     return this.condition;
/*     */   }
/*     */   
/*     */   protected Collection<?> getContent()
/*     */   {
/*  66 */     return this.condition != null ? Collections.singleton(this.condition) : Collections.emptyList();
/*     */   }
/*     */   
/*     */   protected String getToStringInfix()
/*     */   {
/*  71 */     return " ";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RequestConditionHolder combine(RequestConditionHolder other)
/*     */   {
/*  81 */     if ((this.condition == null) && (other.condition == null)) {
/*  82 */       return this;
/*     */     }
/*  84 */     if (this.condition == null) {
/*  85 */       return other;
/*     */     }
/*  87 */     if (other.condition == null) {
/*  88 */       return this;
/*     */     }
/*     */     
/*  91 */     assertEqualConditionTypes(this.condition, other.condition);
/*  92 */     RequestCondition<?> combined = (RequestCondition)this.condition.combine(other.condition);
/*  93 */     return new RequestConditionHolder(combined);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void assertEqualConditionTypes(RequestCondition<?> thisCondition, RequestCondition<?> otherCondition)
/*     */   {
/* 101 */     Class<?> clazz = thisCondition.getClass();
/* 102 */     Class<?> otherClazz = otherCondition.getClass();
/* 103 */     if (!clazz.equals(otherClazz)) {
/* 104 */       throw new ClassCastException("Incompatible request conditions: " + clazz + " and " + otherClazz);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public RequestConditionHolder getMatchingCondition(HttpServletRequest request)
/*     */   {
/* 116 */     if (this.condition == null) {
/* 117 */       return this;
/*     */     }
/* 119 */     RequestCondition<?> match = (RequestCondition)this.condition.getMatchingCondition(request);
/* 120 */     return match != null ? new RequestConditionHolder(match) : null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int compareTo(RequestConditionHolder other, HttpServletRequest request)
/*     */   {
/* 130 */     if ((this.condition == null) && (other.condition == null)) {
/* 131 */       return 0;
/*     */     }
/* 133 */     if (this.condition == null) {
/* 134 */       return 1;
/*     */     }
/* 136 */     if (other.condition == null) {
/* 137 */       return -1;
/*     */     }
/*     */     
/* 140 */     assertEqualConditionTypes(this.condition, other.condition);
/* 141 */     return this.condition.compareTo(other.condition, request);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-webmvc-5.3.12.jar!\org\springframework\web\servlet\mvc\condition\RequestConditionHolder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */