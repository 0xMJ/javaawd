/*      */ package org.unbescape.html;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.Reader;
/*      */ import java.io.Writer;
/*      */ import java.util.Map;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ final class HtmlEscapeUtil
/*      */ {
/*      */   private static final char REFERENCE_PREFIX = '&';
/*      */   private static final char REFERENCE_NUMERIC_PREFIX2 = '#';
/*      */   private static final char REFERENCE_HEXA_PREFIX3_UPPER = 'X';
/*      */   private static final char REFERENCE_HEXA_PREFIX3_LOWER = 'x';
/*   73 */   private static final char[] REFERENCE_DECIMAL_PREFIX = "&#".toCharArray();
/*   74 */   private static final char[] REFERENCE_HEXA_PREFIX = "&#x".toCharArray();
/*      */   
/*      */ 
/*      */   private static final char REFERENCE_SUFFIX = ';';
/*      */   
/*      */ 
/*   80 */   private static char[] HEXA_CHARS_UPPER = "0123456789ABCDEF".toCharArray();
/*   81 */   private static char[] HEXA_CHARS_LOWER = "0123456789abcdef".toCharArray();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static String escape(String text, HtmlEscapeType escapeType, HtmlEscapeLevel escapeLevel)
/*      */   {
/*   99 */     if (text == null) {
/*  100 */       return null;
/*      */     }
/*      */     
/*  103 */     int level = escapeLevel.getEscapeLevel();
/*  104 */     boolean useHtml5 = escapeType.getUseHtml5();
/*  105 */     boolean useNCRs = escapeType.getUseNCRs();
/*  106 */     boolean useHexa = escapeType.getUseHexa();
/*      */     
/*      */ 
/*  109 */     HtmlEscapeSymbols symbols = useHtml5 ? HtmlEscapeSymbols.HTML5_SYMBOLS : HtmlEscapeSymbols.HTML4_SYMBOLS;
/*      */     
/*  111 */     StringBuilder strBuilder = null;
/*      */     
/*  113 */     int offset = 0;
/*  114 */     int max = text.length();
/*      */     
/*  116 */     int readOffset = 0;
/*      */     
/*  118 */     for (int i = 0; i < max; i++)
/*      */     {
/*  120 */       char c = text.charAt(i);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  127 */       if ((c > '') || (level >= symbols.ESCAPE_LEVELS[c]))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  135 */         if ((c <= '') || (level >= symbols.ESCAPE_LEVELS['']))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  144 */           int codepoint = Character.codePointAt(text, i);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  153 */           if (strBuilder == null) {
/*  154 */             strBuilder = new StringBuilder(max + 20);
/*      */           }
/*      */           
/*  157 */           if (i - readOffset > 0) {
/*  158 */             strBuilder.append(text, readOffset, i);
/*      */           }
/*      */           
/*  161 */           if (Character.charCount(codepoint) > 1)
/*      */           {
/*  163 */             i++;
/*      */           }
/*      */           
/*  166 */           readOffset = i + 1;
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  177 */           if (useNCRs)
/*      */           {
/*      */ 
/*  180 */             if (codepoint < 12287)
/*      */             {
/*      */ 
/*  183 */               short ncrIndex = symbols.NCRS_BY_CODEPOINT[codepoint];
/*  184 */               if (ncrIndex != 0)
/*      */               {
/*  186 */                 strBuilder.append(symbols.SORTED_NCRS[ncrIndex]);
/*  187 */                 continue;
/*      */               }
/*      */             }
/*  190 */             else if (symbols.NCRS_BY_CODEPOINT_OVERFLOW != null)
/*      */             {
/*      */ 
/*  193 */               Short ncrIndex = (Short)symbols.NCRS_BY_CODEPOINT_OVERFLOW.get(Integer.valueOf(codepoint));
/*  194 */               if (ncrIndex != null) {
/*  195 */                 strBuilder.append(symbols.SORTED_NCRS[ncrIndex.shortValue()]);
/*  196 */                 continue;
/*      */               }
/*      */             }
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  207 */           if (useHexa) {
/*  208 */             strBuilder.append(REFERENCE_HEXA_PREFIX);
/*  209 */             strBuilder.append(Integer.toHexString(codepoint));
/*      */           } else {
/*  211 */             strBuilder.append(REFERENCE_DECIMAL_PREFIX);
/*  212 */             strBuilder.append(String.valueOf(codepoint));
/*      */           }
/*  214 */           strBuilder.append(';');
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  226 */     if (strBuilder == null) {
/*  227 */       return text;
/*      */     }
/*      */     
/*  230 */     if (max - readOffset > 0) {
/*  231 */       strBuilder.append(text, readOffset, max);
/*      */     }
/*      */     
/*  234 */     return strBuilder.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static void escape(Reader reader, Writer writer, HtmlEscapeType escapeType, HtmlEscapeLevel escapeLevel)
/*      */     throws IOException
/*      */   {
/*  253 */     if (reader == null) {
/*  254 */       return;
/*      */     }
/*      */     
/*  257 */     int level = escapeLevel.getEscapeLevel();
/*  258 */     boolean useHtml5 = escapeType.getUseHtml5();
/*  259 */     boolean useNCRs = escapeType.getUseNCRs();
/*  260 */     boolean useHexa = escapeType.getUseHexa();
/*      */     
/*      */ 
/*  263 */     HtmlEscapeSymbols symbols = useHtml5 ? HtmlEscapeSymbols.HTML5_SYMBOLS : HtmlEscapeSymbols.HTML4_SYMBOLS;
/*      */     
/*      */ 
/*      */ 
/*  267 */     int c2 = reader.read();
/*      */     
/*  269 */     while (c2 >= 0)
/*      */     {
/*  271 */       int c1 = c2;
/*  272 */       c2 = reader.read();
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  279 */       if ((c1 <= 127) && (level < symbols.ESCAPE_LEVELS[c1])) {
/*  280 */         writer.write(c1);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/*  288 */       else if ((c1 > 127) && (level < symbols.ESCAPE_LEVELS['']))
/*      */       {
/*  290 */         writer.write(c1);
/*      */ 
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/*      */ 
/*  298 */         int codepoint = codePointAt((char)c1, (char)c2);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  306 */         if (Character.charCount(codepoint) > 1)
/*      */         {
/*  308 */           c1 = c2;
/*  309 */           c2 = reader.read();
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  321 */         if (useNCRs)
/*      */         {
/*      */ 
/*  324 */           if (codepoint < 12287)
/*      */           {
/*      */ 
/*  327 */             short ncrIndex = symbols.NCRS_BY_CODEPOINT[codepoint];
/*  328 */             if (ncrIndex != 0)
/*      */             {
/*  330 */               writer.write(symbols.SORTED_NCRS[ncrIndex]);
/*  331 */               continue;
/*      */             }
/*      */           }
/*  334 */           else if (symbols.NCRS_BY_CODEPOINT_OVERFLOW != null)
/*      */           {
/*      */ 
/*  337 */             Short ncrIndex = (Short)symbols.NCRS_BY_CODEPOINT_OVERFLOW.get(Integer.valueOf(codepoint));
/*  338 */             if (ncrIndex != null) {
/*  339 */               writer.write(symbols.SORTED_NCRS[ncrIndex.shortValue()]);
/*  340 */               continue;
/*      */             }
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  351 */         if (useHexa) {
/*  352 */           writer.write(REFERENCE_HEXA_PREFIX);
/*  353 */           writer.write(Integer.toHexString(codepoint));
/*      */         } else {
/*  355 */           writer.write(REFERENCE_DECIMAL_PREFIX);
/*  356 */           writer.write(String.valueOf(codepoint));
/*      */         }
/*  358 */         writer.write(59);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static void escape(char[] text, int offset, int len, Writer writer, HtmlEscapeType escapeType, HtmlEscapeLevel escapeLevel)
/*      */     throws IOException
/*      */   {
/*  375 */     if ((text == null) || (text.length == 0)) {
/*  376 */       return;
/*      */     }
/*      */     
/*  379 */     int level = escapeLevel.getEscapeLevel();
/*  380 */     boolean useHtml5 = escapeType.getUseHtml5();
/*  381 */     boolean useNCRs = escapeType.getUseNCRs();
/*  382 */     boolean useHexa = escapeType.getUseHexa();
/*      */     
/*      */ 
/*  385 */     HtmlEscapeSymbols symbols = useHtml5 ? HtmlEscapeSymbols.HTML5_SYMBOLS : HtmlEscapeSymbols.HTML4_SYMBOLS;
/*      */     
/*  387 */     int max = offset + len;
/*      */     
/*  389 */     int readOffset = offset;
/*      */     
/*  391 */     for (int i = offset; i < max; i++)
/*      */     {
/*  393 */       char c = text[i];
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  400 */       if ((c > '') || (level >= symbols.ESCAPE_LEVELS[c]))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  408 */         if ((c <= '') || (level >= symbols.ESCAPE_LEVELS[(127 + 1)]))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  416 */           int codepoint = Character.codePointAt(text, i);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  424 */           if (i - readOffset > 0) {
/*  425 */             writer.write(text, readOffset, i - readOffset);
/*      */           }
/*      */           
/*  428 */           if (Character.charCount(codepoint) > 1)
/*      */           {
/*  430 */             i++;
/*      */           }
/*      */           
/*  433 */           readOffset = i + 1;
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  444 */           if (useNCRs)
/*      */           {
/*      */ 
/*  447 */             if (codepoint < 12287)
/*      */             {
/*      */ 
/*  450 */               short ncrIndex = symbols.NCRS_BY_CODEPOINT[codepoint];
/*  451 */               if (ncrIndex != 0)
/*      */               {
/*  453 */                 writer.write(symbols.SORTED_NCRS[ncrIndex]);
/*  454 */                 continue;
/*      */               }
/*      */             }
/*  457 */             else if (symbols.NCRS_BY_CODEPOINT_OVERFLOW != null)
/*      */             {
/*      */ 
/*  460 */               Short ncrIndex = (Short)symbols.NCRS_BY_CODEPOINT_OVERFLOW.get(Integer.valueOf(codepoint));
/*  461 */               if (ncrIndex != null) {
/*  462 */                 writer.write(symbols.SORTED_NCRS[ncrIndex.shortValue()]);
/*  463 */                 continue;
/*      */               }
/*      */             }
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  474 */           if (useHexa) {
/*  475 */             writer.write(REFERENCE_HEXA_PREFIX);
/*  476 */             writer.write(Integer.toHexString(codepoint));
/*      */           } else {
/*  478 */             writer.write(REFERENCE_DECIMAL_PREFIX);
/*  479 */             writer.write(String.valueOf(codepoint));
/*      */           }
/*  481 */           writer.write(59);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  492 */     if (max - readOffset > 0) {
/*  493 */       writer.write(text, readOffset, max - readOffset);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static int translateIllFormedCodepoint(int codepoint)
/*      */   {
/*  510 */     switch (codepoint) {
/*  511 */     case 0:  return 65533;
/*  512 */     case 128:  return 8364;
/*  513 */     case 130:  return 8218;
/*  514 */     case 131:  return 402;
/*  515 */     case 132:  return 8222;
/*  516 */     case 133:  return 8230;
/*  517 */     case 134:  return 8224;
/*  518 */     case 135:  return 8225;
/*  519 */     case 136:  return 710;
/*  520 */     case 137:  return 8240;
/*  521 */     case 138:  return 352;
/*  522 */     case 139:  return 8249;
/*  523 */     case 140:  return 338;
/*  524 */     case 142:  return 381;
/*  525 */     case 145:  return 8216;
/*  526 */     case 146:  return 8217;
/*  527 */     case 147:  return 8220;
/*  528 */     case 148:  return 8221;
/*  529 */     case 149:  return 8226;
/*  530 */     case 150:  return 8211;
/*  531 */     case 151:  return 8212;
/*  532 */     case 152:  return 732;
/*  533 */     case 153:  return 8482;
/*  534 */     case 154:  return 353;
/*  535 */     case 155:  return 8250;
/*  536 */     case 156:  return 339;
/*  537 */     case 158:  return 382;
/*  538 */     case 159:  return 376;
/*      */     }
/*      */     
/*  541 */     if ((codepoint >= 55296) && (codepoint <= 57343))
/*  542 */       return 65533;
/*  543 */     if (codepoint > 1114111) {
/*  544 */       return 65533;
/*      */     }
/*  546 */     return codepoint;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static int parseIntFromReference(String text, int start, int end, int radix)
/*      */   {
/*  558 */     int result = 0;
/*  559 */     for (int i = start; i < end; i++) {
/*  560 */       char c = text.charAt(i);
/*  561 */       int n = -1;
/*  562 */       for (int j = 0; j < HEXA_CHARS_UPPER.length; j++) {
/*  563 */         if ((c == HEXA_CHARS_UPPER[j]) || (c == HEXA_CHARS_LOWER[j])) {
/*  564 */           n = j;
/*  565 */           break;
/*      */         }
/*      */       }
/*  568 */       result *= radix;
/*  569 */       if (result < 0) {
/*  570 */         return 65533;
/*      */       }
/*  572 */       result += n;
/*  573 */       if (result < 0) {
/*  574 */         return 65533;
/*      */       }
/*      */     }
/*  577 */     return result;
/*      */   }
/*      */   
/*      */   static int parseIntFromReference(char[] text, int start, int end, int radix) {
/*  581 */     int result = 0;
/*  582 */     for (int i = start; i < end; i++) {
/*  583 */       char c = text[i];
/*  584 */       int n = -1;
/*  585 */       for (int j = 0; j < HEXA_CHARS_UPPER.length; j++) {
/*  586 */         if ((c == HEXA_CHARS_UPPER[j]) || (c == HEXA_CHARS_LOWER[j])) {
/*  587 */           n = j;
/*  588 */           break;
/*      */         }
/*      */       }
/*  591 */       result *= radix;
/*  592 */       if (result < 0) {
/*  593 */         return 65533;
/*      */       }
/*  595 */       result += n;
/*  596 */       if (result < 0) {
/*  597 */         return 65533;
/*      */       }
/*      */     }
/*  600 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static String unescape(String text)
/*      */   {
/*  618 */     if (text == null) {
/*  619 */       return null;
/*      */     }
/*      */     
/*      */ 
/*  623 */     HtmlEscapeSymbols symbols = HtmlEscapeSymbols.HTML5_SYMBOLS;
/*  624 */     StringBuilder strBuilder = null;
/*      */     
/*  626 */     int offset = 0;
/*  627 */     int max = text.length();
/*      */     
/*  629 */     int readOffset = 0;
/*  630 */     int referenceOffset = 0;
/*      */     
/*  632 */     for (int i = 0; i < max; i++)
/*      */     {
/*  634 */       char c = text.charAt(i);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  640 */       if ((c == '&') && (i + 1 < max))
/*      */       {
/*      */ 
/*      */ 
/*  644 */         int codepoint = 0;
/*      */         
/*  646 */         if (c == '&')
/*      */         {
/*  648 */           char c1 = text.charAt(i + 1);
/*      */           
/*  650 */           if ((c1 == ' ') || (c1 == '\n') || (c1 == '\t') || (c1 == '\f') || (c1 == '<') || (c1 == '&')) {
/*      */             continue;
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  659 */           if (c1 == '#')
/*      */           {
/*  661 */             if (i + 2 >= max) {
/*      */               continue;
/*      */             }
/*      */             
/*      */ 
/*  666 */             char c2 = text.charAt(i + 2);
/*      */             
/*  668 */             if (((c2 == 'x') || (c2 == 'X')) && (i + 3 < max))
/*      */             {
/*      */ 
/*  671 */               int f = i + 3;
/*  672 */               while (f < max) {
/*  673 */                 char cf = text.charAt(f);
/*  674 */                 if (((cf < '0') || (cf > '9')) && ((cf < 'A') || (cf > 'F')) && ((cf < 'a') || (cf > 'f'))) {
/*      */                   break;
/*      */                 }
/*  677 */                 f++;
/*      */               }
/*      */               
/*  680 */               if (f - (i + 3) <= 0) {
/*      */                 continue;
/*      */               }
/*      */               
/*      */ 
/*  685 */               codepoint = parseIntFromReference(text, i + 3, f, 16);
/*  686 */               referenceOffset = f - 1;
/*      */               
/*  688 */               if ((f < max) && (text.charAt(f) == ';')) {
/*  689 */                 referenceOffset++;
/*      */               }
/*      */               
/*  692 */               codepoint = translateIllFormedCodepoint(codepoint);
/*      */             }
/*      */             else
/*      */             {
/*  696 */               if ((c2 < '0') || (c2 > '9')) {
/*      */                 continue;
/*      */               }
/*  699 */               int f = i + 2;
/*  700 */               while (f < max) {
/*  701 */                 char cf = text.charAt(f);
/*  702 */                 if ((cf < '0') || (cf > '9')) {
/*      */                   break;
/*      */                 }
/*  705 */                 f++;
/*      */               }
/*      */               
/*  708 */               if (f - (i + 2) <= 0) {
/*      */                 continue;
/*      */               }
/*      */               
/*      */ 
/*  713 */               codepoint = parseIntFromReference(text, i + 2, f, 10);
/*  714 */               referenceOffset = f - 1;
/*      */               
/*  716 */               if ((f < max) && (text.charAt(f) == ';')) {
/*  717 */                 referenceOffset++;
/*      */               }
/*      */               
/*  720 */               codepoint = translateIllFormedCodepoint(codepoint);
/*      */ 
/*      */ 
/*      */             }
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */           }
/*      */           else
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*  734 */             int f = i + 1;
/*  735 */             while (f < max) {
/*  736 */               char cf = text.charAt(f);
/*  737 */               if (((cf < 'a') || (cf > 'z')) && ((cf < 'A') || (cf > 'Z')) && ((cf < '0') || (cf > '9'))) {
/*      */                 break;
/*      */               }
/*  740 */               f++;
/*      */             }
/*      */             
/*  743 */             if (f - (i + 1) <= 0) {
/*      */               continue;
/*      */             }
/*      */             
/*      */ 
/*  748 */             if ((f < max) && (text.charAt(f) == ';')) {
/*  749 */               f++;
/*      */             }
/*      */             
/*  752 */             int ncrPosition = HtmlEscapeSymbols.binarySearch(symbols.SORTED_NCRS, text, i, f);
/*  753 */             if (ncrPosition >= 0) {
/*  754 */               codepoint = symbols.SORTED_CODEPOINTS[ncrPosition];
/*  755 */             } else { if (ncrPosition == Integer.MIN_VALUE) {
/*      */                 continue;
/*      */               }
/*  758 */               if (ncrPosition < -10)
/*      */               {
/*  760 */                 int partialIndex = -1 * (ncrPosition + 10);
/*  761 */                 char[] partialMatch = symbols.SORTED_NCRS[partialIndex];
/*  762 */                 codepoint = symbols.SORTED_CODEPOINTS[partialIndex];
/*  763 */                 f -= f - i - partialMatch.length;
/*      */               }
/*      */               else {
/*  766 */                 throw new RuntimeException("Invalid unescape codepoint after search: " + ncrPosition);
/*      */               }
/*      */             }
/*  769 */             referenceOffset = f - 1;
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  782 */         if (strBuilder == null) {
/*  783 */           strBuilder = new StringBuilder(max + 5);
/*      */         }
/*      */         
/*  786 */         if (i - readOffset > 0) {
/*  787 */           strBuilder.append(text, readOffset, i);
/*      */         }
/*      */         
/*  790 */         i = referenceOffset;
/*  791 */         readOffset = i + 1;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  801 */         if (codepoint > 65535) {
/*  802 */           strBuilder.append(Character.toChars(codepoint));
/*  803 */         } else if (codepoint < 0)
/*      */         {
/*  805 */           int[] codepoints = symbols.DOUBLE_CODEPOINTS[(-1 * codepoint - 1)];
/*  806 */           if (codepoints[0] > 65535) {
/*  807 */             strBuilder.append(Character.toChars(codepoints[0]));
/*      */           } else {
/*  809 */             strBuilder.append((char)codepoints[0]);
/*      */           }
/*  811 */           if (codepoints[1] > 65535) {
/*  812 */             strBuilder.append(Character.toChars(codepoints[1]));
/*      */           } else {
/*  814 */             strBuilder.append((char)codepoints[1]);
/*      */           }
/*      */         } else {
/*  817 */           strBuilder.append((char)codepoint);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  830 */     if (strBuilder == null) {
/*  831 */       return text;
/*      */     }
/*      */     
/*  834 */     if (max - readOffset > 0) {
/*  835 */       strBuilder.append(text, readOffset, max);
/*      */     }
/*      */     
/*  838 */     return strBuilder.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static void unescape(Reader reader, Writer writer)
/*      */     throws IOException
/*      */   {
/*  858 */     if (reader == null) {
/*  859 */       return;
/*      */     }
/*      */     
/*      */ 
/*  863 */     HtmlEscapeSymbols symbols = HtmlEscapeSymbols.HTML5_SYMBOLS;
/*      */     
/*  865 */     char[] escapes = new char[10];
/*  866 */     int escapei = 0;
/*      */     
/*      */ 
/*      */ 
/*  870 */     int c2 = reader.read();
/*      */     
/*  872 */     while (c2 >= 0)
/*      */     {
/*  874 */       int c1 = c2;
/*  875 */       c2 = reader.read();
/*      */       
/*  877 */       escapei = 0;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  883 */       if ((c1 != 38) || (c2 < 0)) {
/*  884 */         writer.write(c1);
/*      */       }
/*      */       else
/*      */       {
/*  888 */         int codepoint = 0;
/*      */         
/*  890 */         if (c1 == 38)
/*      */         {
/*  892 */           if ((c2 == 32) || (c2 == 10) || (c2 == 9) || (c2 == 12) || (c2 == 60) || (c2 == 38))
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  899 */             writer.write(c1);
/*  900 */             continue;
/*      */           }
/*  902 */           if (c2 == 35)
/*      */           {
/*  904 */             int c3 = reader.read();
/*      */             
/*  906 */             if (c3 < 0)
/*      */             {
/*  908 */               writer.write(c1);
/*  909 */               writer.write(c2);
/*  910 */               c1 = c2;
/*  911 */               c2 = c3;
/*  912 */               continue;
/*      */             }
/*      */             
/*  915 */             if ((c3 == 120) || (c3 == 88))
/*      */             {
/*      */ 
/*  918 */               int ce = reader.read();
/*  919 */               while ((ce >= 0) && (
/*  920 */                 ((ce >= 48) && (ce <= 57)) || ((ce >= 65) && (ce <= 70)) || ((ce >= 97) && (ce <= 102))))
/*      */               {
/*      */ 
/*  923 */                 if (escapei == escapes.length)
/*      */                 {
/*  925 */                   char[] newEscapes = new char[escapes.length + 4];
/*  926 */                   System.arraycopy(escapes, 0, newEscapes, 0, escapes.length);
/*  927 */                   escapes = newEscapes;
/*      */                 }
/*  929 */                 escapes[escapei] = ((char)ce);
/*  930 */                 ce = reader.read();
/*  931 */                 escapei++;
/*      */               }
/*      */               
/*  934 */               if (escapei == 0)
/*      */               {
/*  936 */                 writer.write(c1);
/*  937 */                 writer.write(c2);
/*  938 */                 writer.write(c3);
/*  939 */                 c1 = c3;
/*  940 */                 c2 = ce;
/*  941 */                 continue;
/*      */               }
/*      */               
/*  944 */               c1 = escapes[(escapei - 1)];
/*  945 */               c2 = ce;
/*      */               
/*  947 */               codepoint = parseIntFromReference(escapes, 0, escapei, 16);
/*      */               
/*  949 */               if (c2 == 59)
/*      */               {
/*  951 */                 c1 = c2;
/*  952 */                 c2 = reader.read();
/*      */               }
/*      */               
/*  955 */               codepoint = translateIllFormedCodepoint(codepoint);
/*      */               
/*  957 */               escapei = 0;
/*      */ 
/*      */ 
/*      */             }
/*  961 */             else if ((c3 >= 48) && (c3 <= 57))
/*      */             {
/*      */ 
/*  964 */               int ce = c3;
/*  965 */               while ((ce >= 0) && 
/*  966 */                 (ce >= 48) && (ce <= 57))
/*      */               {
/*      */ 
/*  969 */                 if (escapei == escapes.length)
/*      */                 {
/*  971 */                   char[] newEscapes = new char[escapes.length + 4];
/*  972 */                   System.arraycopy(escapes, 0, newEscapes, 0, escapes.length);
/*  973 */                   escapes = newEscapes;
/*      */                 }
/*  975 */                 escapes[escapei] = ((char)ce);
/*  976 */                 ce = reader.read();
/*  977 */                 escapei++;
/*      */               }
/*      */               
/*  980 */               if (escapei == 0)
/*      */               {
/*  982 */                 writer.write(c1);
/*  983 */                 writer.write(c2);
/*  984 */                 c1 = c2;
/*  985 */                 c2 = c3;
/*  986 */                 continue;
/*      */               }
/*      */               
/*  989 */               c1 = escapes[(escapei - 1)];
/*  990 */               c2 = ce;
/*      */               
/*  992 */               codepoint = parseIntFromReference(escapes, 0, escapei, 10);
/*      */               
/*  994 */               if (c2 == 59)
/*      */               {
/*  996 */                 c1 = c2;
/*  997 */                 c2 = reader.read();
/*      */               }
/*      */               
/* 1000 */               codepoint = translateIllFormedCodepoint(codepoint);
/*      */               
/* 1002 */               escapei = 0;
/*      */ 
/*      */             }
/*      */             else
/*      */             {
/*      */ 
/* 1008 */               writer.write(c1);
/* 1009 */               writer.write(c2);
/* 1010 */               c1 = c2;
/* 1011 */               c2 = c3;
/* 1012 */               continue;
/*      */             }
/*      */             
/*      */ 
/*      */             int ce;
/*      */           }
/*      */           else
/*      */           {
/* 1020 */             int ce = c2;
/* 1021 */             while ((ce >= 0) && (
/* 1022 */               ((ce >= 48) && (ce <= 57)) || ((ce >= 65) && (ce <= 90)) || ((ce >= 97) && (ce <= 122))))
/*      */             {
/*      */ 
/* 1025 */               if (escapei == escapes.length)
/*      */               {
/* 1027 */                 char[] newEscapes = new char[escapes.length + 4];
/* 1028 */                 System.arraycopy(escapes, 0, newEscapes, 0, escapes.length);
/* 1029 */                 escapes = newEscapes;
/*      */               }
/* 1031 */               escapes[escapei] = ((char)ce);
/* 1032 */               ce = reader.read();
/* 1033 */               escapei++;
/*      */             }
/*      */             
/* 1036 */             if (escapei == 0)
/*      */             {
/* 1038 */               writer.write(c1);
/* 1039 */               continue;
/*      */             }
/*      */             
/* 1042 */             if (escapei + 2 >= escapes.length)
/*      */             {
/* 1044 */               char[] newEscapes = new char[escapes.length + 4];
/* 1045 */               System.arraycopy(escapes, 0, newEscapes, 0, escapes.length);
/* 1046 */               escapes = newEscapes;
/*      */             }
/*      */             
/* 1049 */             System.arraycopy(escapes, 0, escapes, 1, escapei);
/* 1050 */             escapes[0] = ((char)c1);
/* 1051 */             escapei++;
/*      */             
/* 1053 */             if (ce == 59)
/*      */             {
/* 1055 */               escapes[(escapei++)] = ((char)ce);
/* 1056 */               ce = reader.read();
/*      */             }
/*      */             
/* 1059 */             c1 = escapes[(escapei - 1)];
/* 1060 */             c2 = ce;
/*      */             
/* 1062 */             int ncrPosition = HtmlEscapeSymbols.binarySearch(symbols.SORTED_NCRS, escapes, 0, escapei);
/* 1063 */             if (ncrPosition >= 0) {
/* 1064 */               codepoint = symbols.SORTED_CODEPOINTS[ncrPosition];
/* 1065 */               escapei = 0;
/* 1066 */             } else { if (ncrPosition == Integer.MIN_VALUE)
/*      */               {
/* 1068 */                 writer.write(escapes, 0, escapei);
/* 1069 */                 continue; }
/* 1070 */               if (ncrPosition < -10)
/*      */               {
/* 1072 */                 int partialIndex = -1 * (ncrPosition + 10);
/* 1073 */                 char[] partialMatch = symbols.SORTED_NCRS[partialIndex];
/* 1074 */                 codepoint = symbols.SORTED_CODEPOINTS[partialIndex];
/* 1075 */                 System.arraycopy(escapes, partialMatch.length, escapes, 0, escapei - partialMatch.length);
/* 1076 */                 escapei -= partialMatch.length;
/*      */               }
/*      */               else {
/* 1079 */                 throw new RuntimeException("Invalid unescape codepoint after search: " + ncrPosition);
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1094 */         if (codepoint > 65535) {
/* 1095 */           writer.write(Character.toChars(codepoint));
/* 1096 */         } else if (codepoint < 0)
/*      */         {
/* 1098 */           int[] codepoints = symbols.DOUBLE_CODEPOINTS[(-1 * codepoint - 1)];
/* 1099 */           if (codepoints[0] > 65535) {
/* 1100 */             writer.write(Character.toChars(codepoints[0]));
/*      */           } else {
/* 1102 */             writer.write((char)codepoints[0]);
/*      */           }
/* 1104 */           if (codepoints[1] > 65535) {
/* 1105 */             writer.write(Character.toChars(codepoints[1]));
/*      */           } else {
/* 1107 */             writer.write((char)codepoints[1]);
/*      */           }
/*      */         } else {
/* 1110 */           writer.write((char)codepoint);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1119 */         if (escapei > 0) {
/* 1120 */           writer.write(escapes, 0, escapei);
/* 1121 */           escapei = 0;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static void unescape(char[] text, int offset, int len, Writer writer)
/*      */     throws IOException
/*      */   {
/* 1142 */     if (text == null) {
/* 1143 */       return;
/*      */     }
/*      */     
/* 1146 */     HtmlEscapeSymbols symbols = HtmlEscapeSymbols.HTML5_SYMBOLS;
/*      */     
/* 1148 */     int max = offset + len;
/*      */     
/* 1150 */     int readOffset = offset;
/* 1151 */     int referenceOffset = offset;
/*      */     
/* 1153 */     for (int i = offset; i < max; i++)
/*      */     {
/* 1155 */       char c = text[i];
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1161 */       if ((c == '&') && (i + 1 < max))
/*      */       {
/*      */ 
/*      */ 
/* 1165 */         int codepoint = 0;
/*      */         
/* 1167 */         if (c == '&')
/*      */         {
/* 1169 */           char c1 = text[(i + 1)];
/*      */           
/* 1171 */           if ((c1 == ' ') || (c1 == '\n') || (c1 == '\t') || (c1 == '\f') || (c1 == '<') || (c1 == '&')) {
/*      */             continue;
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1180 */           if (c1 == '#')
/*      */           {
/* 1182 */             if (i + 2 >= max) {
/*      */               continue;
/*      */             }
/*      */             
/*      */ 
/* 1187 */             char c2 = text[(i + 2)];
/*      */             
/* 1189 */             if (((c2 == 'x') || (c2 == 'X')) && (i + 3 < max))
/*      */             {
/*      */ 
/* 1192 */               int f = i + 3;
/* 1193 */               while (f < max) {
/* 1194 */                 char cf = text[f];
/* 1195 */                 if (((cf < '0') || (cf > '9')) && ((cf < 'A') || (cf > 'F')) && ((cf < 'a') || (cf > 'f'))) {
/*      */                   break;
/*      */                 }
/* 1198 */                 f++;
/*      */               }
/*      */               
/* 1201 */               if (f - (i + 3) <= 0) {
/*      */                 continue;
/*      */               }
/*      */               
/*      */ 
/* 1206 */               codepoint = parseIntFromReference(text, i + 3, f, 16);
/* 1207 */               referenceOffset = f - 1;
/*      */               
/* 1209 */               if ((f < max) && (text[f] == ';')) {
/* 1210 */                 referenceOffset++;
/*      */               }
/*      */               
/* 1213 */               codepoint = translateIllFormedCodepoint(codepoint);
/*      */             }
/*      */             else
/*      */             {
/* 1217 */               if ((c2 < '0') || (c2 > '9')) {
/*      */                 continue;
/*      */               }
/* 1220 */               int f = i + 2;
/* 1221 */               while (f < max) {
/* 1222 */                 char cf = text[f];
/* 1223 */                 if ((cf < '0') || (cf > '9')) {
/*      */                   break;
/*      */                 }
/* 1226 */                 f++;
/*      */               }
/*      */               
/* 1229 */               if (f - (i + 2) <= 0) {
/*      */                 continue;
/*      */               }
/*      */               
/*      */ 
/* 1234 */               codepoint = parseIntFromReference(text, i + 2, f, 10);
/* 1235 */               referenceOffset = f - 1;
/*      */               
/* 1237 */               if ((f < max) && (text[f] == ';')) {
/* 1238 */                 referenceOffset++;
/*      */               }
/*      */               
/* 1241 */               codepoint = translateIllFormedCodepoint(codepoint);
/*      */ 
/*      */ 
/*      */             }
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */           }
/*      */           else
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/* 1255 */             int f = i + 1;
/* 1256 */             while (f < max) {
/* 1257 */               char cf = text[f];
/* 1258 */               if (((cf < 'a') || (cf > 'z')) && ((cf < 'A') || (cf > 'Z')) && ((cf < '0') || (cf > '9'))) {
/*      */                 break;
/*      */               }
/* 1261 */               f++;
/*      */             }
/*      */             
/* 1264 */             if (f - (i + 1) <= 0) {
/*      */               continue;
/*      */             }
/*      */             
/*      */ 
/* 1269 */             if ((f < max) && (text[f] == ';')) {
/* 1270 */               f++;
/*      */             }
/*      */             
/* 1273 */             int ncrPosition = HtmlEscapeSymbols.binarySearch(symbols.SORTED_NCRS, text, i, f);
/* 1274 */             if (ncrPosition >= 0) {
/* 1275 */               codepoint = symbols.SORTED_CODEPOINTS[ncrPosition];
/* 1276 */             } else { if (ncrPosition == Integer.MIN_VALUE) {
/*      */                 continue;
/*      */               }
/* 1279 */               if (ncrPosition < -10)
/*      */               {
/* 1281 */                 int partialIndex = -1 * (ncrPosition + 10);
/* 1282 */                 char[] partialMatch = symbols.SORTED_NCRS[partialIndex];
/* 1283 */                 codepoint = symbols.SORTED_CODEPOINTS[partialIndex];
/* 1284 */                 f -= f - i - partialMatch.length;
/*      */               }
/*      */               else {
/* 1287 */                 throw new RuntimeException("Invalid unescape codepoint after search: " + ncrPosition);
/*      */               }
/*      */             }
/* 1290 */             referenceOffset = f - 1;
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1302 */         if (i - readOffset > 0) {
/* 1303 */           writer.write(text, readOffset, i - readOffset);
/*      */         }
/*      */         
/* 1306 */         i = referenceOffset;
/* 1307 */         readOffset = i + 1;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1317 */         if (codepoint > 65535) {
/* 1318 */           writer.write(Character.toChars(codepoint));
/* 1319 */         } else if (codepoint < 0)
/*      */         {
/* 1321 */           int[] codepoints = symbols.DOUBLE_CODEPOINTS[(-1 * codepoint - 1)];
/* 1322 */           if (codepoints[0] > 65535) {
/* 1323 */             writer.write(Character.toChars(codepoints[0]));
/*      */           } else {
/* 1325 */             writer.write((char)codepoints[0]);
/*      */           }
/* 1327 */           if (codepoints[1] > 65535) {
/* 1328 */             writer.write(Character.toChars(codepoints[1]));
/*      */           } else {
/* 1330 */             writer.write((char)codepoints[1]);
/*      */           }
/*      */         } else {
/* 1333 */           writer.write((char)codepoint);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1345 */     if (max - readOffset > 0) {
/* 1346 */       writer.write(text, readOffset, max - readOffset);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private static int codePointAt(char c1, char c2)
/*      */   {
/* 1355 */     if ((Character.isHighSurrogate(c1)) && 
/* 1356 */       (c2 >= 0) && 
/* 1357 */       (Character.isLowSurrogate(c2))) {
/* 1358 */       return Character.toCodePoint(c1, c2);
/*      */     }
/*      */     
/*      */ 
/* 1362 */     return c1;
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\unbescape-1.1.6.RELEASE.jar!\org\unbescape\html\HtmlEscapeUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */