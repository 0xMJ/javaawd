/*     */ package org.unbescape.html;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum HtmlEscapeLevel
/*     */ {
/*  73 */   LEVEL_0_ONLY_MARKUP_SIGNIFICANT_EXCEPT_APOS(0), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  79 */   LEVEL_1_ONLY_MARKUP_SIGNIFICANT(1), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  84 */   LEVEL_2_ALL_NON_ASCII_PLUS_MARKUP_SIGNIFICANT(2), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  90 */   LEVEL_3_ALL_NON_ALPHANUMERIC(3), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  95 */   LEVEL_4_ALL_CHARACTERS(4);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final int escapeLevel;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static HtmlEscapeLevel forLevel(int level)
/*     */   {
/* 112 */     switch (level) {
/* 113 */     case 0:  return LEVEL_0_ONLY_MARKUP_SIGNIFICANT_EXCEPT_APOS;
/* 114 */     case 1:  return LEVEL_1_ONLY_MARKUP_SIGNIFICANT;
/* 115 */     case 2:  return LEVEL_2_ALL_NON_ASCII_PLUS_MARKUP_SIGNIFICANT;
/* 116 */     case 3:  return LEVEL_3_ALL_NON_ALPHANUMERIC;
/* 117 */     case 4:  return LEVEL_4_ALL_CHARACTERS;
/*     */     }
/* 119 */     throw new IllegalArgumentException("No escape level enum constant defined for level: " + level);
/*     */   }
/*     */   
/*     */ 
/*     */   private HtmlEscapeLevel(int escapeLevel)
/*     */   {
/* 125 */     this.escapeLevel = escapeLevel;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getEscapeLevel()
/*     */   {
/* 134 */     return this.escapeLevel;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\unbescape-1.1.6.RELEASE.jar!\org\unbescape\html\HtmlEscapeLevel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */