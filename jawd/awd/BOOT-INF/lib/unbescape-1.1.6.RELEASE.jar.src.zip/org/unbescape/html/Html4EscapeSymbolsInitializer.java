/*     */ package org.unbescape.html;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class Html4EscapeSymbolsInitializer
/*     */ {
/*     */   static HtmlEscapeSymbols initializeHtml4()
/*     */   {
/*  39 */     HtmlEscapeSymbols.References html4References = new HtmlEscapeSymbols.References();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  50 */     html4References.addReference(34, "&quot;");
/*  51 */     html4References.addReference(38, "&amp;");
/*  52 */     html4References.addReference(60, "&lt;");
/*  53 */     html4References.addReference(62, "&gt;");
/*     */     
/*  55 */     html4References.addReference(160, "&nbsp;");
/*  56 */     html4References.addReference(161, "&iexcl;");
/*  57 */     html4References.addReference(162, "&cent;");
/*  58 */     html4References.addReference(163, "&pound;");
/*  59 */     html4References.addReference(164, "&curren;");
/*  60 */     html4References.addReference(165, "&yen;");
/*  61 */     html4References.addReference(166, "&brvbar;");
/*  62 */     html4References.addReference(167, "&sect;");
/*  63 */     html4References.addReference(168, "&uml;");
/*  64 */     html4References.addReference(169, "&copy;");
/*  65 */     html4References.addReference(170, "&ordf;");
/*  66 */     html4References.addReference(171, "&laquo;");
/*  67 */     html4References.addReference(172, "&not;");
/*  68 */     html4References.addReference(173, "&shy;");
/*  69 */     html4References.addReference(174, "&reg;");
/*  70 */     html4References.addReference(175, "&macr;");
/*  71 */     html4References.addReference(176, "&deg;");
/*  72 */     html4References.addReference(177, "&plusmn;");
/*  73 */     html4References.addReference(178, "&sup2;");
/*  74 */     html4References.addReference(179, "&sup3;");
/*  75 */     html4References.addReference(180, "&acute;");
/*  76 */     html4References.addReference(181, "&micro;");
/*  77 */     html4References.addReference(182, "&para;");
/*  78 */     html4References.addReference(183, "&middot;");
/*  79 */     html4References.addReference(184, "&cedil;");
/*  80 */     html4References.addReference(185, "&sup1;");
/*  81 */     html4References.addReference(186, "&ordm;");
/*  82 */     html4References.addReference(187, "&raquo;");
/*  83 */     html4References.addReference(188, "&frac14;");
/*  84 */     html4References.addReference(189, "&frac12;");
/*  85 */     html4References.addReference(190, "&frac34;");
/*  86 */     html4References.addReference(191, "&iquest;");
/*  87 */     html4References.addReference(192, "&Agrave;");
/*  88 */     html4References.addReference(193, "&Aacute;");
/*  89 */     html4References.addReference(194, "&Acirc;");
/*  90 */     html4References.addReference(195, "&Atilde;");
/*  91 */     html4References.addReference(196, "&Auml;");
/*  92 */     html4References.addReference(197, "&Aring;");
/*  93 */     html4References.addReference(198, "&AElig;");
/*  94 */     html4References.addReference(199, "&Ccedil;");
/*  95 */     html4References.addReference(200, "&Egrave;");
/*  96 */     html4References.addReference(201, "&Eacute;");
/*  97 */     html4References.addReference(202, "&Ecirc;");
/*  98 */     html4References.addReference(203, "&Euml;");
/*  99 */     html4References.addReference(204, "&Igrave;");
/* 100 */     html4References.addReference(205, "&Iacute;");
/* 101 */     html4References.addReference(206, "&Icirc;");
/* 102 */     html4References.addReference(207, "&Iuml;");
/* 103 */     html4References.addReference(208, "&ETH;");
/* 104 */     html4References.addReference(209, "&Ntilde;");
/* 105 */     html4References.addReference(210, "&Ograve;");
/* 106 */     html4References.addReference(211, "&Oacute;");
/* 107 */     html4References.addReference(212, "&Ocirc;");
/* 108 */     html4References.addReference(213, "&Otilde;");
/* 109 */     html4References.addReference(214, "&Ouml;");
/* 110 */     html4References.addReference(215, "&times;");
/* 111 */     html4References.addReference(216, "&Oslash;");
/* 112 */     html4References.addReference(217, "&Ugrave;");
/* 113 */     html4References.addReference(218, "&Uacute;");
/* 114 */     html4References.addReference(219, "&Ucirc;");
/* 115 */     html4References.addReference(220, "&Uuml;");
/* 116 */     html4References.addReference(221, "&Yacute;");
/* 117 */     html4References.addReference(222, "&THORN;");
/* 118 */     html4References.addReference(223, "&szlig;");
/* 119 */     html4References.addReference(224, "&agrave;");
/* 120 */     html4References.addReference(225, "&aacute;");
/* 121 */     html4References.addReference(226, "&acirc;");
/* 122 */     html4References.addReference(227, "&atilde;");
/* 123 */     html4References.addReference(228, "&auml;");
/* 124 */     html4References.addReference(229, "&aring;");
/* 125 */     html4References.addReference(230, "&aelig;");
/* 126 */     html4References.addReference(231, "&ccedil;");
/* 127 */     html4References.addReference(232, "&egrave;");
/* 128 */     html4References.addReference(233, "&eacute;");
/* 129 */     html4References.addReference(234, "&ecirc;");
/* 130 */     html4References.addReference(235, "&euml;");
/* 131 */     html4References.addReference(236, "&igrave;");
/* 132 */     html4References.addReference(237, "&iacute;");
/* 133 */     html4References.addReference(238, "&icirc;");
/* 134 */     html4References.addReference(239, "&iuml;");
/* 135 */     html4References.addReference(240, "&eth;");
/* 136 */     html4References.addReference(241, "&ntilde;");
/* 137 */     html4References.addReference(242, "&ograve;");
/* 138 */     html4References.addReference(243, "&oacute;");
/* 139 */     html4References.addReference(244, "&ocirc;");
/* 140 */     html4References.addReference(245, "&otilde;");
/* 141 */     html4References.addReference(246, "&ouml;");
/* 142 */     html4References.addReference(247, "&divide;");
/* 143 */     html4References.addReference(248, "&oslash;");
/* 144 */     html4References.addReference(249, "&ugrave;");
/* 145 */     html4References.addReference(250, "&uacute;");
/* 146 */     html4References.addReference(251, "&ucirc;");
/* 147 */     html4References.addReference(252, "&uuml;");
/* 148 */     html4References.addReference(253, "&yacute;");
/* 149 */     html4References.addReference(254, "&thorn;");
/* 150 */     html4References.addReference(255, "&yuml;");
/*     */     
/*     */ 
/* 153 */     html4References.addReference(402, "&fnof;");
/* 154 */     html4References.addReference(913, "&Alpha;");
/* 155 */     html4References.addReference(914, "&Beta;");
/* 156 */     html4References.addReference(915, "&Gamma;");
/* 157 */     html4References.addReference(916, "&Delta;");
/* 158 */     html4References.addReference(917, "&Epsilon;");
/* 159 */     html4References.addReference(918, "&Zeta;");
/* 160 */     html4References.addReference(919, "&Eta;");
/* 161 */     html4References.addReference(920, "&Theta;");
/* 162 */     html4References.addReference(921, "&Iota;");
/* 163 */     html4References.addReference(922, "&Kappa;");
/* 164 */     html4References.addReference(923, "&Lambda;");
/* 165 */     html4References.addReference(924, "&Mu;");
/* 166 */     html4References.addReference(925, "&Nu;");
/* 167 */     html4References.addReference(926, "&Xi;");
/* 168 */     html4References.addReference(927, "&Omicron;");
/* 169 */     html4References.addReference(928, "&Pi;");
/* 170 */     html4References.addReference(929, "&Rho;");
/* 171 */     html4References.addReference(931, "&Sigma;");
/* 172 */     html4References.addReference(932, "&Tau;");
/* 173 */     html4References.addReference(933, "&Upsilon;");
/* 174 */     html4References.addReference(934, "&Phi;");
/* 175 */     html4References.addReference(935, "&Chi;");
/* 176 */     html4References.addReference(936, "&Psi;");
/* 177 */     html4References.addReference(937, "&Omega;");
/* 178 */     html4References.addReference(945, "&alpha;");
/* 179 */     html4References.addReference(946, "&beta;");
/* 180 */     html4References.addReference(947, "&gamma;");
/* 181 */     html4References.addReference(948, "&delta;");
/* 182 */     html4References.addReference(949, "&epsilon;");
/* 183 */     html4References.addReference(950, "&zeta;");
/* 184 */     html4References.addReference(951, "&eta;");
/* 185 */     html4References.addReference(952, "&theta;");
/* 186 */     html4References.addReference(953, "&iota;");
/* 187 */     html4References.addReference(954, "&kappa;");
/* 188 */     html4References.addReference(955, "&lambda;");
/* 189 */     html4References.addReference(956, "&mu;");
/* 190 */     html4References.addReference(957, "&nu;");
/* 191 */     html4References.addReference(958, "&xi;");
/* 192 */     html4References.addReference(959, "&omicron;");
/* 193 */     html4References.addReference(960, "&pi;");
/* 194 */     html4References.addReference(961, "&rho;");
/* 195 */     html4References.addReference(962, "&sigmaf;");
/* 196 */     html4References.addReference(963, "&sigma;");
/* 197 */     html4References.addReference(964, "&tau;");
/* 198 */     html4References.addReference(965, "&upsilon;");
/* 199 */     html4References.addReference(966, "&phi;");
/* 200 */     html4References.addReference(967, "&chi;");
/* 201 */     html4References.addReference(968, "&psi;");
/* 202 */     html4References.addReference(969, "&omega;");
/* 203 */     html4References.addReference(977, "&thetasym;");
/* 204 */     html4References.addReference(978, "&upsih;");
/* 205 */     html4References.addReference(982, "&piv;");
/*     */     
/* 207 */     html4References.addReference(8226, "&bull;");
/* 208 */     html4References.addReference(8230, "&hellip;");
/* 209 */     html4References.addReference(8242, "&prime;");
/* 210 */     html4References.addReference(8243, "&Prime;");
/* 211 */     html4References.addReference(8254, "&oline;");
/* 212 */     html4References.addReference(8260, "&frasl;");
/*     */     
/* 214 */     html4References.addReference(8472, "&weierp;");
/* 215 */     html4References.addReference(8465, "&image;");
/* 216 */     html4References.addReference(8476, "&real;");
/* 217 */     html4References.addReference(8482, "&trade;");
/* 218 */     html4References.addReference(8501, "&alefsym;");
/*     */     
/* 220 */     html4References.addReference(8592, "&larr;");
/* 221 */     html4References.addReference(8593, "&uarr;");
/* 222 */     html4References.addReference(8594, "&rarr;");
/* 223 */     html4References.addReference(8595, "&darr;");
/* 224 */     html4References.addReference(8596, "&harr;");
/* 225 */     html4References.addReference(8629, "&crarr;");
/* 226 */     html4References.addReference(8656, "&lArr;");
/* 227 */     html4References.addReference(8657, "&uArr;");
/* 228 */     html4References.addReference(8658, "&rArr;");
/* 229 */     html4References.addReference(8659, "&dArr;");
/* 230 */     html4References.addReference(8660, "&hArr;");
/*     */     
/* 232 */     html4References.addReference(8704, "&forall;");
/* 233 */     html4References.addReference(8706, "&part;");
/* 234 */     html4References.addReference(8707, "&exist;");
/* 235 */     html4References.addReference(8709, "&empty;");
/* 236 */     html4References.addReference(8711, "&nabla;");
/* 237 */     html4References.addReference(8712, "&isin;");
/* 238 */     html4References.addReference(8713, "&notin;");
/* 239 */     html4References.addReference(8715, "&ni;");
/* 240 */     html4References.addReference(8719, "&prod;");
/* 241 */     html4References.addReference(8721, "&sum;");
/* 242 */     html4References.addReference(8722, "&minus;");
/* 243 */     html4References.addReference(8727, "&lowast;");
/* 244 */     html4References.addReference(8730, "&radic;");
/* 245 */     html4References.addReference(8733, "&prop;");
/* 246 */     html4References.addReference(8734, "&infin;");
/* 247 */     html4References.addReference(8736, "&ang;");
/* 248 */     html4References.addReference(8743, "&and;");
/* 249 */     html4References.addReference(8744, "&or;");
/* 250 */     html4References.addReference(8745, "&cap;");
/* 251 */     html4References.addReference(8746, "&cup;");
/* 252 */     html4References.addReference(8747, "&int;");
/* 253 */     html4References.addReference(8756, "&there4;");
/* 254 */     html4References.addReference(8764, "&sim;");
/* 255 */     html4References.addReference(8773, "&cong;");
/* 256 */     html4References.addReference(8776, "&asymp;");
/* 257 */     html4References.addReference(8800, "&ne;");
/* 258 */     html4References.addReference(8801, "&equiv;");
/* 259 */     html4References.addReference(8804, "&le;");
/* 260 */     html4References.addReference(8805, "&ge;");
/* 261 */     html4References.addReference(8834, "&sub;");
/* 262 */     html4References.addReference(8835, "&sup;");
/* 263 */     html4References.addReference(8836, "&nsub;");
/* 264 */     html4References.addReference(8838, "&sube;");
/* 265 */     html4References.addReference(8839, "&supe;");
/* 266 */     html4References.addReference(8853, "&oplus;");
/* 267 */     html4References.addReference(8855, "&otimes;");
/* 268 */     html4References.addReference(8869, "&perp;");
/* 269 */     html4References.addReference(8901, "&sdot;");
/*     */     
/* 271 */     html4References.addReference(8968, "&lceil;");
/* 272 */     html4References.addReference(8969, "&rceil;");
/* 273 */     html4References.addReference(8970, "&lfloor;");
/* 274 */     html4References.addReference(8971, "&rfloor;");
/* 275 */     html4References.addReference(9001, "&lang;");
/* 276 */     html4References.addReference(9002, "&rang;");
/*     */     
/* 278 */     html4References.addReference(9674, "&loz;");
/* 279 */     html4References.addReference(9824, "&spades;");
/* 280 */     html4References.addReference(9827, "&clubs;");
/* 281 */     html4References.addReference(9829, "&hearts;");
/* 282 */     html4References.addReference(9830, "&diams;");
/*     */     
/*     */ 
/* 285 */     html4References.addReference(338, "&OElig;");
/* 286 */     html4References.addReference(339, "&oelig;");
/* 287 */     html4References.addReference(352, "&Scaron;");
/* 288 */     html4References.addReference(353, "&scaron;");
/* 289 */     html4References.addReference(376, "&Yuml;");
/*     */     
/* 291 */     html4References.addReference(710, "&circ;");
/* 292 */     html4References.addReference(732, "&tilde;");
/*     */     
/* 294 */     html4References.addReference(8194, "&ensp;");
/* 295 */     html4References.addReference(8195, "&emsp;");
/* 296 */     html4References.addReference(8201, "&thinsp;");
/* 297 */     html4References.addReference(8204, "&zwnj;");
/* 298 */     html4References.addReference(8205, "&zwj;");
/* 299 */     html4References.addReference(8206, "&lrm;");
/* 300 */     html4References.addReference(8207, "&rlm;");
/* 301 */     html4References.addReference(8211, "&ndash;");
/* 302 */     html4References.addReference(8212, "&mdash;");
/* 303 */     html4References.addReference(8216, "&lsquo;");
/* 304 */     html4References.addReference(8217, "&rsquo;");
/* 305 */     html4References.addReference(8218, "&sbquo;");
/* 306 */     html4References.addReference(8220, "&ldquo;");
/* 307 */     html4References.addReference(8221, "&rdquo;");
/* 308 */     html4References.addReference(8222, "&bdquo;");
/* 309 */     html4References.addReference(8224, "&dagger;");
/* 310 */     html4References.addReference(8225, "&Dagger;");
/* 311 */     html4References.addReference(8240, "&permil;");
/* 312 */     html4References.addReference(8249, "&lsaquo;");
/* 313 */     html4References.addReference(8250, "&rsaquo;");
/* 314 */     html4References.addReference(8364, "&euro;");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 327 */     byte[] escapeLevels = new byte[''];
/* 328 */     Arrays.fill(escapeLevels, (byte)3);
/* 329 */     for (char c = 'A'; c <= 'Z'; c = (char)(c + '\001')) {
/* 330 */       escapeLevels[c] = 4;
/*     */     }
/* 332 */     for (char c = 'a'; c <= 'z'; c = (char)(c + '\001')) {
/* 333 */       escapeLevels[c] = 4;
/*     */     }
/* 335 */     for (char c = '0'; c <= '9'; c = (char)(c + '\001')) {
/* 336 */       escapeLevels[c] = 4;
/*     */     }
/* 338 */     escapeLevels[39] = 1;
/* 339 */     escapeLevels[34] = 0;
/* 340 */     escapeLevels[60] = 0;
/* 341 */     escapeLevels[62] = 0;
/* 342 */     escapeLevels[38] = 0;
/* 343 */     escapeLevels[''] = 2;
/*     */     
/*     */ 
/* 346 */     return new HtmlEscapeSymbols(html4References, escapeLevels);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\unbescape-1.1.6.RELEASE.jar!\org\unbescape\html\Html4EscapeSymbolsInitializer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */