/*     */ package org.unbescape.html;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class HtmlEscapeSymbols
/*     */ {
/*     */   static final int NCRS_BY_CODEPOINT_LEN = 12287;
/*  96 */   final short[] NCRS_BY_CODEPOINT = new short['⿿'];
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   final Map<Integer, Short> NCRS_BY_CODEPOINT_OVERFLOW;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static final char MAX_ASCII_CHAR = '';
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 123 */   final byte[] ESCAPE_LEVELS = new byte[''];
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   final char[][] SORTED_NCRS;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   final int[] SORTED_CODEPOINTS;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   final int[][] DOUBLE_CODEPOINTS;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static final short NO_NCR = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 182 */   static final HtmlEscapeSymbols HTML4_SYMBOLS = ;
/* 183 */   static final HtmlEscapeSymbols HTML5_SYMBOLS = Html5EscapeSymbolsInitializer.initializeHtml5();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   HtmlEscapeSymbols(References references, byte[] escapeLevels)
/*     */   {
/* 200 */     System.arraycopy(escapeLevels, 0, this.ESCAPE_LEVELS, 0, 129);
/*     */     
/*     */ 
/*     */ 
/* 204 */     List<char[]> ncrs = new ArrayList(references.references.size() + 5);
/* 205 */     List<Integer> codepoints = new ArrayList(references.references.size() + 5);
/* 206 */     List<int[]> doubleCodepoints = new ArrayList(100);
/* 207 */     Map<Integer, Short> ncrsByCodepointOverflow = new HashMap(20);
/*     */     
/*     */ 
/* 210 */     for (Reference reference : references.references)
/*     */     {
/* 212 */       char[] referenceNcr = reference.ncr;
/* 213 */       int[] referenceCodepoints = reference.codepoints;
/*     */       
/* 215 */       ncrs.add(referenceNcr);
/*     */       
/* 217 */       if (referenceCodepoints.length == 1)
/*     */       {
/*     */ 
/* 220 */         int referenceCodepoint = referenceCodepoints[0];
/* 221 */         codepoints.add(Integer.valueOf(referenceCodepoint));
/*     */       }
/* 223 */       else if (referenceCodepoints.length == 2)
/*     */       {
/*     */ 
/*     */ 
/* 227 */         doubleCodepoints.add(referenceCodepoints);
/*     */         
/* 229 */         codepoints.add(Integer.valueOf(-1 * doubleCodepoints.size()));
/*     */       }
/*     */       else
/*     */       {
/* 233 */         throw new RuntimeException("Unsupported codepoints #: " + referenceCodepoints.length + " for " + new String(referenceNcr));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 242 */     Arrays.fill(this.NCRS_BY_CODEPOINT, (short)0);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 248 */     this.SORTED_NCRS = new char[ncrs.size()][];
/* 249 */     this.SORTED_CODEPOINTS = new int[codepoints.size()];
/*     */     
/* 251 */     Object ncrsOrdered = new ArrayList(ncrs);
/* 252 */     Collections.sort((List)ncrsOrdered, new Comparator() {
/*     */       public int compare(char[] o1, char[] o2) {
/* 254 */         return HtmlEscapeSymbols.compare(o1, o2, 0, o2.length);
/*     */       }
/*     */     });
/*     */     
/* 258 */     for (short i = 0; i < this.SORTED_NCRS.length; i = (short)(i + 1))
/*     */     {
/* 260 */       char[] ncr = (char[])((List)ncrsOrdered).get(i);
/* 261 */       this.SORTED_NCRS[i] = ncr;
/*     */       
/* 263 */       for (short j = 0; j < this.SORTED_NCRS.length; j = (short)(j + 1))
/*     */       {
/* 265 */         if (Arrays.equals(ncr, (char[])ncrs.get(j)))
/*     */         {
/* 267 */           int cp = ((Integer)codepoints.get(j)).intValue();
/* 268 */           this.SORTED_CODEPOINTS[i] = cp;
/*     */           
/* 270 */           if (cp <= 0)
/*     */             break;
/* 272 */           if (cp < 12287)
/*     */           {
/* 274 */             if (this.NCRS_BY_CODEPOINT[cp] == 0)
/*     */             {
/* 276 */               this.NCRS_BY_CODEPOINT[cp] = i; break;
/*     */             }
/* 278 */             int positionOfCurrent = positionInList(ncrs, this.SORTED_NCRS[this.NCRS_BY_CODEPOINT[cp]]);
/* 279 */             int positionOfNew = positionInList(ncrs, ncr);
/* 280 */             if (positionOfNew < positionOfCurrent)
/*     */             {
/*     */ 
/*     */ 
/* 284 */               this.NCRS_BY_CODEPOINT[cp] = i;
/*     */             }
/* 286 */             break;
/*     */           }
/*     */           
/* 289 */           ncrsByCodepointOverflow.put(Integer.valueOf(cp), Short.valueOf(i)); break;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 303 */     if (ncrsByCodepointOverflow.size() > 0) {
/* 304 */       this.NCRS_BY_CODEPOINT_OVERFLOW = ncrsByCodepointOverflow;
/*     */     } else {
/* 306 */       this.NCRS_BY_CODEPOINT_OVERFLOW = null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 311 */     if (doubleCodepoints.size() > 0) {
/* 312 */       this.DOUBLE_CODEPOINTS = new int[doubleCodepoints.size()][];
/* 313 */       for (int i = 0; i < this.DOUBLE_CODEPOINTS.length; i++) {
/* 314 */         this.DOUBLE_CODEPOINTS[i] = ((int[])doubleCodepoints.get(i));
/*     */       }
/*     */     } else {
/* 317 */       this.DOUBLE_CODEPOINTS = null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static int positionInList(List<char[]> list, char[] element)
/*     */   {
/* 330 */     int i = 0;
/* 331 */     for (char[] e : list) {
/* 332 */       if (Arrays.equals(e, element)) {
/* 333 */         return i;
/*     */       }
/* 335 */       i++;
/*     */     }
/* 337 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static int compare(char[] ncr, String text, int start, int end)
/*     */   {
/* 361 */     int textLen = end - start;
/* 362 */     int maxCommon = Math.min(ncr.length, textLen);
/*     */     
/*     */ 
/* 365 */     for (int i = 1; i < maxCommon; i++) {
/* 366 */       char tc = text.charAt(start + i);
/* 367 */       if (ncr[i] < tc) {
/* 368 */         if (tc == ';') {
/* 369 */           return 1;
/*     */         }
/* 371 */         return -1; }
/* 372 */       if (ncr[i] > tc) {
/* 373 */         if (ncr[i] == ';') {
/* 374 */           return -1;
/*     */         }
/* 376 */         return 1;
/*     */       }
/*     */     }
/* 379 */     if (ncr.length > i) {
/* 380 */       if (ncr[i] == ';') {
/* 381 */         return -1;
/*     */       }
/* 383 */       return 1;
/*     */     }
/* 385 */     if (textLen > i) {
/* 386 */       if (text.charAt(start + i) == ';') {
/* 387 */         return 1;
/*     */       }
/*     */       
/* 390 */       return -(textLen - i + 10);
/*     */     }
/* 392 */     return 0;
/*     */   }
/*     */   
/*     */   private static int compare(char[] ncr, char[] text, int start, int end) {
/* 396 */     int textLen = end - start;
/* 397 */     int maxCommon = Math.min(ncr.length, textLen);
/*     */     
/*     */ 
/* 400 */     for (int i = 1; i < maxCommon; i++) {
/* 401 */       char tc = text[(start + i)];
/* 402 */       if (ncr[i] < tc) {
/* 403 */         if (tc == ';') {
/* 404 */           return 1;
/*     */         }
/* 406 */         return -1; }
/* 407 */       if (ncr[i] > tc) {
/* 408 */         if (ncr[i] == ';') {
/* 409 */           return -1;
/*     */         }
/* 411 */         return 1;
/*     */       }
/*     */     }
/* 414 */     if (ncr.length > i) {
/* 415 */       if (ncr[i] == ';') {
/* 416 */         return -1;
/*     */       }
/* 418 */       return 1;
/*     */     }
/* 420 */     if (textLen > i) {
/* 421 */       if (text[(start + i)] == ';') {
/* 422 */         return 1;
/*     */       }
/*     */       
/* 425 */       return -(textLen - i + 10);
/*     */     }
/* 427 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static int binarySearch(char[][] values, String text, int start, int end)
/*     */   {
/* 444 */     int low = 0;
/* 445 */     int high = values.length - 1;
/*     */     
/* 447 */     int partialIndex = Integer.MIN_VALUE;
/* 448 */     int partialValue = Integer.MIN_VALUE;
/*     */     
/* 450 */     while (low <= high)
/*     */     {
/* 452 */       int mid = low + high >>> 1;
/* 453 */       char[] midVal = values[mid];
/*     */       
/* 455 */       int cmp = compare(midVal, text, start, end);
/*     */       
/* 457 */       if (cmp == -1) {
/* 458 */         low = mid + 1;
/* 459 */       } else if (cmp == 1) {
/* 460 */         high = mid - 1;
/* 461 */       } else if (cmp < -10)
/*     */       {
/* 463 */         low = mid + 1;
/* 464 */         if ((partialIndex == Integer.MIN_VALUE) || (partialValue < cmp)) {
/* 465 */           partialIndex = mid;
/* 466 */           partialValue = cmp;
/*     */         }
/*     */       }
/*     */       else {
/* 470 */         return mid;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 475 */     if (partialIndex != Integer.MIN_VALUE)
/*     */     {
/* 477 */       return -1 * (partialIndex + 10);
/*     */     }
/*     */     
/* 480 */     return Integer.MIN_VALUE;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   static int binarySearch(char[][] values, char[] text, int start, int end)
/*     */   {
/* 487 */     int low = 0;
/* 488 */     int high = values.length - 1;
/*     */     
/* 490 */     int partialIndex = Integer.MIN_VALUE;
/* 491 */     int partialValue = Integer.MIN_VALUE;
/*     */     
/* 493 */     while (low <= high)
/*     */     {
/* 495 */       int mid = low + high >>> 1;
/* 496 */       char[] midVal = values[mid];
/*     */       
/* 498 */       int cmp = compare(midVal, text, start, end);
/*     */       
/* 500 */       if (cmp == -1) {
/* 501 */         low = mid + 1;
/* 502 */       } else if (cmp == 1) {
/* 503 */         high = mid - 1;
/* 504 */       } else if (cmp < -10)
/*     */       {
/* 506 */         low = mid + 1;
/* 507 */         if ((partialIndex == Integer.MIN_VALUE) || (partialValue < cmp)) {
/* 508 */           partialIndex = mid;
/* 509 */           partialValue = cmp;
/*     */         }
/*     */       }
/*     */       else {
/* 513 */         return mid;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 518 */     if (partialIndex != Integer.MIN_VALUE)
/*     */     {
/* 520 */       return -1 * (partialIndex + 10);
/*     */     }
/*     */     
/* 523 */     return Integer.MIN_VALUE;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static final class References
/*     */   {
/* 540 */     private final List<HtmlEscapeSymbols.Reference> references = new ArrayList(200);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     void addReference(int codepoint, String ncr)
/*     */     {
/* 547 */       this.references.add(new HtmlEscapeSymbols.Reference(ncr, new int[] { codepoint }, null));
/*     */     }
/*     */     
/*     */     void addReference(int codepoint0, int codepoint1, String ncr) {
/* 551 */       this.references.add(new HtmlEscapeSymbols.Reference(ncr, new int[] { codepoint0, codepoint1 }, null));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static final class Reference
/*     */   {
/*     */     private final char[] ncr;
/*     */     
/*     */     private final int[] codepoints;
/*     */     
/*     */     private Reference(String ncr, int[] codepoints)
/*     */     {
/* 564 */       this.ncr = ncr.toCharArray();
/* 565 */       this.codepoints = codepoints;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\unbescape-1.1.6.RELEASE.jar!\org\unbescape\html\HtmlEscapeSymbols.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */