/*     */ package org.unbescape.html;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum HtmlEscapeType
/*     */ {
/*  69 */   HTML4_NAMED_REFERENCES_DEFAULT_TO_DECIMAL(true, false, false), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  74 */   HTML4_NAMED_REFERENCES_DEFAULT_TO_HEXA(true, true, false), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  79 */   HTML5_NAMED_REFERENCES_DEFAULT_TO_DECIMAL(true, false, true), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  84 */   HTML5_NAMED_REFERENCES_DEFAULT_TO_HEXA(true, true, true), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  89 */   DECIMAL_REFERENCES(false, false, false), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  94 */   HEXADECIMAL_REFERENCES(false, true, false);
/*     */   
/*     */   private final boolean useNCRs;
/*     */   private final boolean useHexa;
/*     */   private final boolean useHtml5;
/*     */   
/*     */   private HtmlEscapeType(boolean useNCRs, boolean useHexa, boolean useHtml5)
/*     */   {
/* 102 */     this.useNCRs = useNCRs;
/* 103 */     this.useHexa = useHexa;
/* 104 */     this.useHtml5 = useHtml5;
/*     */   }
/*     */   
/*     */   boolean getUseNCRs() {
/* 108 */     return this.useNCRs;
/*     */   }
/*     */   
/*     */   boolean getUseHexa() {
/* 112 */     return this.useHexa;
/*     */   }
/*     */   
/*     */   boolean getUseHtml5() {
/* 116 */     return this.useHtml5;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\unbescape-1.1.6.RELEASE.jar!\org\unbescape\html\HtmlEscapeType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */