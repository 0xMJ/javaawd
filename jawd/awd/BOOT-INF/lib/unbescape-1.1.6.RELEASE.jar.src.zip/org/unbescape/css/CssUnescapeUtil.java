/*     */ package org.unbescape.css;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.io.Writer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class CssUnescapeUtil
/*     */ {
/*     */   private static final char ESCAPE_PREFIX = '\\';
/* 113 */   private static char[] HEXA_CHARS_UPPER = "0123456789ABCDEF".toCharArray();
/* 114 */   private static char[] HEXA_CHARS_LOWER = "0123456789abcdef".toCharArray();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static int parseIntFromReference(String text, int start, int end, int radix)
/*     */   {
/* 135 */     int result = 0;
/* 136 */     for (int i = start; i < end; i++) {
/* 137 */       char c = text.charAt(i);
/* 138 */       int n = -1;
/* 139 */       for (int j = 0; j < HEXA_CHARS_UPPER.length; j++) {
/* 140 */         if ((c == HEXA_CHARS_UPPER[j]) || (c == HEXA_CHARS_LOWER[j])) {
/* 141 */           n = j;
/* 142 */           break;
/*     */         }
/*     */       }
/* 145 */       result = radix * result + n;
/*     */     }
/* 147 */     return result;
/*     */   }
/*     */   
/*     */   static int parseIntFromReference(char[] text, int start, int end, int radix) {
/* 151 */     int result = 0;
/* 152 */     for (int i = start; i < end; i++) {
/* 153 */       char c = text[i];
/* 154 */       int n = -1;
/* 155 */       for (int j = 0; j < HEXA_CHARS_UPPER.length; j++) {
/* 156 */         if ((c == HEXA_CHARS_UPPER[j]) || (c == HEXA_CHARS_LOWER[j])) {
/* 157 */           n = j;
/* 158 */           break;
/*     */         }
/*     */       }
/* 161 */       result = radix * result + n;
/*     */     }
/* 163 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static String unescape(String text)
/*     */   {
/* 175 */     if (text == null) {
/* 176 */       return null;
/*     */     }
/*     */     
/* 179 */     StringBuilder strBuilder = null;
/*     */     
/* 181 */     int offset = 0;
/* 182 */     int max = text.length();
/*     */     
/* 184 */     int readOffset = 0;
/* 185 */     int referenceOffset = 0;
/*     */     
/* 187 */     for (int i = 0; i < max; i++)
/*     */     {
/* 189 */       char c = text.charAt(i);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 195 */       if ((c == '\\') && (i + 1 < max))
/*     */       {
/*     */ 
/*     */ 
/* 199 */         int codepoint = -1;
/*     */         
/* 201 */         if (c == '\\')
/*     */         {
/* 203 */           char c1 = text.charAt(i + 1);
/*     */           
/* 205 */           switch (c1) {
/*     */           case '\n': 
/* 207 */             codepoint = -2;referenceOffset = i + 1; break;
/*     */           
/*     */ 
/*     */           case ' ': 
/*     */           case '!': 
/*     */           case '"': 
/*     */           case '#': 
/*     */           case '$': 
/*     */           case '%': 
/*     */           case '&': 
/*     */           case '\'': 
/*     */           case '(': 
/*     */           case ')': 
/*     */           case '*': 
/*     */           case '+': 
/*     */           case ',': 
/*     */           case '-': 
/*     */           case '.': 
/*     */           case '/': 
/*     */           case ':': 
/*     */           case ';': 
/*     */           case '<': 
/*     */           case '=': 
/*     */           case '>': 
/*     */           case '?': 
/*     */           case '@': 
/*     */           case '[': 
/*     */           case '\\': 
/*     */           case ']': 
/*     */           case '^': 
/*     */           case '_': 
/*     */           case '`': 
/*     */           case '{': 
/*     */           case '|': 
/*     */           case '}': 
/*     */           case '~': 
/* 243 */             codepoint = c1;referenceOffset = i + 1;
/*     */           }
/*     */           
/* 246 */           if (codepoint == -1)
/*     */           {
/* 248 */             if (((c1 >= '0') && (c1 <= '9')) || ((c1 >= 'A') && (c1 <= 'F')) || ((c1 >= 'a') && (c1 <= 'f')))
/*     */             {
/*     */ 
/* 251 */               int f = i + 2;
/* 252 */               while ((f < i + 7) && (f < max)) {
/* 253 */                 char cf = text.charAt(f);
/* 254 */                 if (((cf < '0') || (cf > '9')) && ((cf < 'A') || (cf > 'F')) && ((cf < 'a') || (cf > 'f'))) {
/*     */                   break;
/*     */                 }
/* 257 */                 f++;
/*     */               }
/*     */               
/* 260 */               codepoint = parseIntFromReference(text, i + 1, f, 16);
/*     */               
/*     */ 
/* 263 */               referenceOffset = f - 1;
/*     */               
/*     */ 
/* 266 */               if ((f < max) && (text.charAt(f) == ' ')) {
/* 267 */                 referenceOffset++;
/*     */               }
/*     */               
/*     */             }
/*     */             else
/*     */             {
/* 273 */               if ((c1 == '\r') || (c1 == '\f'))
/*     */               {
/*     */ 
/*     */ 
/* 277 */                 i++;
/* 278 */                 continue;
/*     */               }
/*     */               
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 285 */               codepoint = c1;
/* 286 */               referenceOffset = i + 1;
/*     */             }
/*     */           }
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 301 */         if (strBuilder == null) {
/* 302 */           strBuilder = new StringBuilder(max + 5);
/*     */         }
/*     */         
/* 305 */         if (i - readOffset > 0) {
/* 306 */           strBuilder.append(text, readOffset, i);
/*     */         }
/*     */         
/* 309 */         i = referenceOffset;
/* 310 */         readOffset = i + 1;
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 320 */         if (codepoint > 65535) {
/* 321 */           strBuilder.append(Character.toChars(codepoint));
/* 322 */         } else if (codepoint != -2) {
/* 323 */           strBuilder.append((char)codepoint);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 336 */     if (strBuilder == null) {
/* 337 */       return text;
/*     */     }
/*     */     
/* 340 */     if (max - readOffset > 0) {
/* 341 */       strBuilder.append(text, readOffset, max);
/*     */     }
/*     */     
/* 344 */     return strBuilder.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static void unescape(Reader reader, Writer writer)
/*     */     throws IOException
/*     */   {
/* 361 */     if (reader == null) {
/* 362 */       return;
/*     */     }
/*     */     
/* 365 */     int escapei = 0;
/* 366 */     char[] escapes = new char[6];
/*     */     
/*     */ 
/* 369 */     int c2 = reader.read();
/*     */     
/* 371 */     while (c2 >= 0)
/*     */     {
/* 373 */       int c1 = c2;
/* 374 */       c2 = reader.read();
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 380 */       if ((c1 != 92) || (c2 < 0)) {
/* 381 */         writer.write(c1);
/*     */       }
/*     */       else
/*     */       {
/* 385 */         int codepoint = -1;
/*     */         
/* 387 */         if (c1 == 92)
/*     */         {
/* 389 */           switch (c2) {
/*     */           case 10: 
/* 391 */             codepoint = -2;c1 = c2;c2 = reader.read(); break;
/*     */           
/*     */ 
/*     */           case 32: 
/*     */           case 33: 
/*     */           case 34: 
/*     */           case 35: 
/*     */           case 36: 
/*     */           case 37: 
/*     */           case 38: 
/*     */           case 39: 
/*     */           case 40: 
/*     */           case 41: 
/*     */           case 42: 
/*     */           case 43: 
/*     */           case 44: 
/*     */           case 45: 
/*     */           case 46: 
/*     */           case 47: 
/*     */           case 58: 
/*     */           case 59: 
/*     */           case 60: 
/*     */           case 61: 
/*     */           case 62: 
/*     */           case 63: 
/*     */           case 64: 
/*     */           case 91: 
/*     */           case 92: 
/*     */           case 93: 
/*     */           case 94: 
/*     */           case 95: 
/*     */           case 96: 
/*     */           case 123: 
/*     */           case 124: 
/*     */           case 125: 
/*     */           case 126: 
/* 427 */             codepoint = c2;c1 = c2;c2 = reader.read();
/*     */           }
/*     */           
/* 430 */           if (codepoint == -1)
/*     */           {
/* 432 */             if (((c2 >= 48) && (c2 <= 57)) || ((c2 >= 65) && (c2 <= 70)) || ((c2 >= 97) && (c2 <= 102)))
/*     */             {
/*     */ 
/* 435 */               escapei = 0;
/* 436 */               int ce = c2;
/* 437 */               while ((ce >= 0) && (escapei < 6) && (
/* 438 */                 ((ce >= 48) && (ce <= 57)) || ((ce >= 65) && (ce <= 70)) || ((ce >= 97) && (ce <= 102))))
/*     */               {
/*     */ 
/* 441 */                 escapes[escapei] = ((char)ce);
/* 442 */                 ce = reader.read();
/* 443 */                 escapei++;
/*     */               }
/*     */               
/* 446 */               c1 = escapes[5];
/* 447 */               c2 = ce;
/*     */               
/* 449 */               codepoint = parseIntFromReference(escapes, 0, escapei, 16);
/*     */               
/*     */ 
/* 452 */               if (c2 == 32) {
/* 453 */                 c1 = c2;
/* 454 */                 c2 = reader.read();
/*     */               }
/*     */               
/*     */             }
/*     */             else
/*     */             {
/* 460 */               if ((c2 == 13) || (c2 == 12))
/*     */               {
/*     */ 
/*     */ 
/* 464 */                 writer.write(c1);
/* 465 */                 continue;
/*     */               }
/*     */               
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 472 */               codepoint = c2;
/*     */               
/* 474 */               c1 = c2;
/* 475 */               c2 = reader.read();
/*     */             }
/*     */           }
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 491 */         if (codepoint > 65535) {
/* 492 */           writer.write(Character.toChars(codepoint));
/* 493 */         } else if (codepoint != -2) {
/* 494 */           writer.write((char)codepoint);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static void unescape(char[] text, int offset, int len, Writer writer)
/*     */     throws IOException
/*     */   {
/* 512 */     if (text == null) {
/* 513 */       return;
/*     */     }
/*     */     
/* 516 */     int max = offset + len;
/*     */     
/* 518 */     int readOffset = offset;
/* 519 */     int referenceOffset = offset;
/*     */     
/* 521 */     for (int i = offset; i < max; i++)
/*     */     {
/* 523 */       char c = text[i];
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 529 */       if ((c == '\\') && (i + 1 < max))
/*     */       {
/*     */ 
/*     */ 
/* 533 */         int codepoint = -1;
/*     */         
/* 535 */         if (c == '\\')
/*     */         {
/* 537 */           char c1 = text[(i + 1)];
/*     */           
/* 539 */           switch (c1) {
/*     */           case '\n': 
/* 541 */             codepoint = -2;referenceOffset = i + 1; break;
/*     */           
/*     */ 
/*     */           case ' ': 
/*     */           case '!': 
/*     */           case '"': 
/*     */           case '#': 
/*     */           case '$': 
/*     */           case '%': 
/*     */           case '&': 
/*     */           case '\'': 
/*     */           case '(': 
/*     */           case ')': 
/*     */           case '*': 
/*     */           case '+': 
/*     */           case ',': 
/*     */           case '-': 
/*     */           case '.': 
/*     */           case '/': 
/*     */           case ':': 
/*     */           case ';': 
/*     */           case '<': 
/*     */           case '=': 
/*     */           case '>': 
/*     */           case '?': 
/*     */           case '@': 
/*     */           case '[': 
/*     */           case '\\': 
/*     */           case ']': 
/*     */           case '^': 
/*     */           case '_': 
/*     */           case '`': 
/*     */           case '{': 
/*     */           case '|': 
/*     */           case '}': 
/*     */           case '~': 
/* 577 */             codepoint = c1;referenceOffset = i + 1;
/*     */           }
/*     */           
/* 580 */           if (codepoint == -1)
/*     */           {
/* 582 */             if (((c1 >= '0') && (c1 <= '9')) || ((c1 >= 'A') && (c1 <= 'F')) || ((c1 >= 'a') && (c1 <= 'f')))
/*     */             {
/*     */ 
/* 585 */               int f = i + 2;
/* 586 */               while ((f < i + 7) && (f < max)) {
/* 587 */                 char cf = text[f];
/* 588 */                 if (((cf < '0') || (cf > '9')) && ((cf < 'A') || (cf > 'F')) && ((cf < 'a') || (cf > 'f'))) {
/*     */                   break;
/*     */                 }
/* 591 */                 f++;
/*     */               }
/*     */               
/* 594 */               codepoint = parseIntFromReference(text, i + 1, f, 16);
/*     */               
/*     */ 
/* 597 */               referenceOffset = f - 1;
/*     */               
/*     */ 
/* 600 */               if ((f < max) && (text[f] == ' ')) {
/* 601 */                 referenceOffset++;
/*     */               }
/*     */               
/*     */             }
/*     */             else
/*     */             {
/* 607 */               if ((c1 == '\r') || (c1 == '\f'))
/*     */               {
/*     */ 
/*     */ 
/* 611 */                 i++;
/* 612 */                 continue;
/*     */               }
/*     */               
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 619 */               codepoint = c1;
/* 620 */               referenceOffset = i + 1;
/*     */             }
/*     */           }
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 634 */         if (i - readOffset > 0) {
/* 635 */           writer.write(text, readOffset, i - readOffset);
/*     */         }
/*     */         
/* 638 */         i = referenceOffset;
/* 639 */         readOffset = i + 1;
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 649 */         if (codepoint > 65535) {
/* 650 */           writer.write(Character.toChars(codepoint));
/* 651 */         } else if (codepoint != -2) {
/* 652 */           writer.write((char)codepoint);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 664 */     if (max - readOffset > 0) {
/* 665 */       writer.write(text, readOffset, max - readOffset);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\unbescape-1.1.6.RELEASE.jar!\org\unbescape\css\CssUnescapeUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */