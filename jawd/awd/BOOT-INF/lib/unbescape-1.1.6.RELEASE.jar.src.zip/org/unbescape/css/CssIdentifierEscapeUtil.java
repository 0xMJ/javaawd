/*     */ package org.unbescape.css;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.io.Writer;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class CssIdentifierEscapeUtil
/*     */ {
/*     */   private static final char ESCAPE_PREFIX = '\\';
/* 110 */   private static char[] HEXA_CHARS_UPPER = "0123456789ABCDEF".toCharArray();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 116 */   private static int BACKSLASH_CHARS_LEN = 127;
/* 117 */   private static char BACKSLASH_CHARS_NO_ESCAPE = '\000';
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 135 */   private static char[] BACKSLASH_CHARS = new char[BACKSLASH_CHARS_LEN];
/* 136 */   static { Arrays.fill(BACKSLASH_CHARS, BACKSLASH_CHARS_NO_ESCAPE);
/* 137 */     BACKSLASH_CHARS[32] = ' ';
/* 138 */     BACKSLASH_CHARS[33] = '!';
/* 139 */     BACKSLASH_CHARS[34] = '"';
/* 140 */     BACKSLASH_CHARS[35] = '#';
/* 141 */     BACKSLASH_CHARS[36] = '$';
/* 142 */     BACKSLASH_CHARS[37] = '%';
/* 143 */     BACKSLASH_CHARS[38] = '&';
/* 144 */     BACKSLASH_CHARS[39] = '\'';
/* 145 */     BACKSLASH_CHARS[40] = '(';
/* 146 */     BACKSLASH_CHARS[41] = ')';
/* 147 */     BACKSLASH_CHARS[42] = '*';
/* 148 */     BACKSLASH_CHARS[43] = '+';
/* 149 */     BACKSLASH_CHARS[44] = ',';
/*     */     
/* 151 */     BACKSLASH_CHARS[45] = '-';
/* 152 */     BACKSLASH_CHARS[46] = '.';
/* 153 */     BACKSLASH_CHARS[47] = '/';
/*     */     
/*     */ 
/* 156 */     BACKSLASH_CHARS[59] = ';';
/* 157 */     BACKSLASH_CHARS[60] = '<';
/* 158 */     BACKSLASH_CHARS[61] = '=';
/* 159 */     BACKSLASH_CHARS[62] = '>';
/* 160 */     BACKSLASH_CHARS[63] = '?';
/* 161 */     BACKSLASH_CHARS[64] = '@';
/* 162 */     BACKSLASH_CHARS[91] = '[';
/* 163 */     BACKSLASH_CHARS[92] = '\\';
/* 164 */     BACKSLASH_CHARS[93] = ']';
/* 165 */     BACKSLASH_CHARS[94] = '^';
/*     */     
/* 167 */     BACKSLASH_CHARS[95] = '_';
/* 168 */     BACKSLASH_CHARS[96] = '`';
/* 169 */     BACKSLASH_CHARS[123] = '{';
/* 170 */     BACKSLASH_CHARS[124] = '|';
/* 171 */     BACKSLASH_CHARS[125] = '}';
/* 172 */     BACKSLASH_CHARS[126] = '~';
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 186 */     ESCAPE_LEVELS = new byte['¡'];
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 191 */     Arrays.fill(ESCAPE_LEVELS, (byte)3);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 196 */     for (char c = ''; c < '¡'; c = (char)(c + '\001')) {
/* 197 */       ESCAPE_LEVELS[c] = 2;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 203 */     for (char c = 'A'; c <= 'Z'; c = (char)(c + '\001')) {
/* 204 */       ESCAPE_LEVELS[c] = 4;
/*     */     }
/* 206 */     for (char c = 'a'; c <= 'z'; c = (char)(c + '\001')) {
/* 207 */       ESCAPE_LEVELS[c] = 4;
/*     */     }
/* 209 */     for (char c = '0'; c <= '9'; c = (char)(c + '\001')) {
/* 210 */       ESCAPE_LEVELS[c] = 4;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 216 */     ESCAPE_LEVELS[32] = 1;
/* 217 */     ESCAPE_LEVELS[33] = 1;
/* 218 */     ESCAPE_LEVELS[34] = 1;
/* 219 */     ESCAPE_LEVELS[35] = 1;
/* 220 */     ESCAPE_LEVELS[36] = 1;
/* 221 */     ESCAPE_LEVELS[37] = 1;
/* 222 */     ESCAPE_LEVELS[38] = 1;
/* 223 */     ESCAPE_LEVELS[39] = 1;
/* 224 */     ESCAPE_LEVELS[40] = 1;
/* 225 */     ESCAPE_LEVELS[41] = 1;
/* 226 */     ESCAPE_LEVELS[42] = 1;
/* 227 */     ESCAPE_LEVELS[43] = 1;
/* 228 */     ESCAPE_LEVELS[44] = 1;
/*     */     
/* 230 */     ESCAPE_LEVELS[45] = 1;
/* 231 */     ESCAPE_LEVELS[46] = 1;
/* 232 */     ESCAPE_LEVELS[47] = 1;
/*     */     
/* 234 */     ESCAPE_LEVELS[58] = 1;
/* 235 */     ESCAPE_LEVELS[59] = 1;
/* 236 */     ESCAPE_LEVELS[60] = 1;
/* 237 */     ESCAPE_LEVELS[61] = 1;
/* 238 */     ESCAPE_LEVELS[62] = 1;
/* 239 */     ESCAPE_LEVELS[63] = 1;
/* 240 */     ESCAPE_LEVELS[64] = 1;
/* 241 */     ESCAPE_LEVELS[91] = 1;
/* 242 */     ESCAPE_LEVELS[92] = 1;
/* 243 */     ESCAPE_LEVELS[93] = 1;
/* 244 */     ESCAPE_LEVELS[94] = 1;
/*     */     
/* 246 */     ESCAPE_LEVELS[95] = 1;
/* 247 */     ESCAPE_LEVELS[96] = 1;
/* 248 */     ESCAPE_LEVELS[123] = 1;
/* 249 */     ESCAPE_LEVELS[124] = 1;
/* 250 */     ESCAPE_LEVELS[125] = 1;
/* 251 */     ESCAPE_LEVELS[126] = 1;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 258 */     for (char c = '\000'; c <= '\037'; c = (char)(c + '\001')) {
/* 259 */       ESCAPE_LEVELS[c] = 1;
/*     */     }
/* 261 */     for (char c = ''; c <= ''; c = (char)(c + '\001')) {
/* 262 */       ESCAPE_LEVELS[c] = 1;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final char ESCAPE_LEVELS_LEN = '¡';
/*     */   
/*     */ 
/*     */ 
/*     */   private static final byte[] ESCAPE_LEVELS;
/*     */   
/*     */ 
/*     */ 
/*     */   static char[] toCompactHexa(int codepoint, char next, int level)
/*     */   {
/* 280 */     boolean needTrailingSpace = (level < 4) && (((next >= '0') && (next <= '9')) || ((next >= 'A') && (next <= 'F')) || ((next >= 'a') && (next <= 'f')));
/*     */     
/*     */ 
/* 283 */     if (codepoint == 0) {
/* 284 */       return new char[] { needTrailingSpace ? new char[] { '0', ' ' } : 48 };
/*     */     }
/* 286 */     int div = 20;
/* 287 */     char[] result = null;
/* 288 */     while ((result == null) && (div >= 0)) {
/* 289 */       if ((codepoint >>> div) % 16 > 0) {
/* 290 */         result = new char[div / 4 + (needTrailingSpace ? 2 : 1)];
/*     */       }
/* 292 */       div -= 4;
/*     */     }
/* 294 */     div = 0;
/* 295 */     for (int i = needTrailingSpace ? result.length - 2 : result.length - 1; i >= 0; i--) {
/* 296 */       result[i] = HEXA_CHARS_UPPER[((codepoint >>> div) % 16)];
/* 297 */       div += 4;
/*     */     }
/* 299 */     if (needTrailingSpace) {
/* 300 */       result[(result.length - 1)] = ' ';
/*     */     }
/*     */     
/* 303 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static char[] toSixDigitHexa(int codepoint, char next, int level)
/*     */   {
/* 311 */     boolean needTrailingSpace = false;
/*     */     
/* 313 */     char[] result = new char[6];
/*     */     
/*     */ 
/*     */ 
/* 317 */     result[5] = HEXA_CHARS_UPPER[(codepoint % 16)];
/* 318 */     result[4] = HEXA_CHARS_UPPER[((codepoint >>> 4) % 16)];
/* 319 */     result[3] = HEXA_CHARS_UPPER[((codepoint >>> 8) % 16)];
/* 320 */     result[2] = HEXA_CHARS_UPPER[((codepoint >>> 12) % 16)];
/* 321 */     result[1] = HEXA_CHARS_UPPER[((codepoint >>> 16) % 16)];
/* 322 */     result[0] = HEXA_CHARS_UPPER[((codepoint >>> 20) % 16)];
/* 323 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static String escape(String text, CssIdentifierEscapeType escapeType, CssIdentifierEscapeLevel escapeLevel)
/*     */   {
/* 333 */     if (text == null) {
/* 334 */       return null;
/*     */     }
/*     */     
/* 337 */     int level = escapeLevel.getEscapeLevel();
/* 338 */     boolean useBackslashEscapes = escapeType.getUseBackslashEscapes();
/* 339 */     boolean useCompactHexa = escapeType.getUseCompactHexa();
/*     */     
/* 341 */     StringBuilder strBuilder = null;
/*     */     
/* 343 */     int offset = 0;
/* 344 */     int max = text.length();
/*     */     
/* 346 */     int readOffset = 0;
/*     */     
/* 348 */     for (int i = 0; i < max; i++)
/*     */     {
/* 350 */       int codepoint = Character.codePointAt(text, i);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 357 */       if ((codepoint > 159) || (level >= ESCAPE_LEVELS[codepoint]) || ((i <= 0) && (codepoint >= 48) && (codepoint <= 57)))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 367 */         if ((codepoint == 45) && (level < 3)) {
/* 368 */           if ((i <= 0) && (i + 1 < max))
/*     */           {
/*     */ 
/* 371 */             char c1 = text.charAt(i + 1);
/* 372 */             if ((c1 != '-') && ((c1 < '0') || (c1 > '9'))) {}
/*     */ 
/*     */ 
/*     */           }
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */         }
/* 381 */         else if ((codepoint != 95) || (level >= 3) || (i <= 0))
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 389 */           if ((codepoint > 159) && (level < ESCAPE_LEVELS[' ']))
/*     */           {
/* 391 */             if (Character.charCount(codepoint) > 1)
/*     */             {
/* 393 */               i++;
/*     */ 
/*     */ 
/*     */             }
/*     */             
/*     */ 
/*     */ 
/*     */ 
/*     */           }
/*     */           else
/*     */           {
/*     */ 
/*     */ 
/*     */ 
/* 407 */             if (strBuilder == null) {
/* 408 */               strBuilder = new StringBuilder(max + 20);
/*     */             }
/*     */             
/* 411 */             if (i - readOffset > 0) {
/* 412 */               strBuilder.append(text, readOffset, i);
/*     */             }
/*     */             
/* 415 */             if (Character.charCount(codepoint) > 1)
/*     */             {
/* 417 */               i++;
/*     */             }
/*     */             
/* 420 */             readOffset = i + 1;
/*     */             
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 431 */             if ((useBackslashEscapes) && (codepoint < BACKSLASH_CHARS_LEN))
/*     */             {
/*     */ 
/* 434 */               char escape = BACKSLASH_CHARS[codepoint];
/*     */               
/* 436 */               if (escape != BACKSLASH_CHARS_NO_ESCAPE)
/*     */               {
/* 438 */                 strBuilder.append('\\');
/* 439 */                 strBuilder.append(escape);
/* 440 */                 continue;
/*     */               }
/*     */             }
/*     */             
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 450 */             char next = i + 1 < max ? text.charAt(i + 1) : '\000';
/*     */             
/* 452 */             if (useCompactHexa) {
/* 453 */               strBuilder.append('\\');
/* 454 */               strBuilder.append(toCompactHexa(codepoint, next, level));
/*     */             }
/*     */             else
/*     */             {
/* 458 */               strBuilder.append('\\');
/* 459 */               strBuilder.append(toSixDigitHexa(codepoint, next, level));
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 471 */     if (strBuilder == null) {
/* 472 */       return text;
/*     */     }
/*     */     
/* 475 */     if (max - readOffset > 0) {
/* 476 */       strBuilder.append(text, readOffset, max);
/*     */     }
/*     */     
/* 479 */     return strBuilder.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static void escape(Reader reader, Writer writer, CssIdentifierEscapeType escapeType, CssIdentifierEscapeLevel escapeLevel)
/*     */     throws IOException
/*     */   {
/* 496 */     if (reader == null) {
/* 497 */       return;
/*     */     }
/*     */     
/* 500 */     int level = escapeLevel.getEscapeLevel();
/* 501 */     boolean useBackslashEscapes = escapeType.getUseBackslashEscapes();
/* 502 */     boolean useCompactHexa = escapeType.getUseCompactHexa();
/*     */     
/*     */ 
/*     */ 
/* 506 */     int c1 = -1;
/* 507 */     int c2 = reader.read();
/*     */     
/* 509 */     while (c2 >= 0)
/*     */     {
/* 511 */       int c0 = c1;
/* 512 */       c1 = c2;
/* 513 */       c2 = reader.read();
/*     */       
/* 515 */       int codepoint = codePointAt((char)c1, (char)c2);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 522 */       if ((codepoint <= 159) && (level < ESCAPE_LEVELS[codepoint]) && ((c0 >= 0) || (codepoint < 48) || (codepoint > 57)))
/*     */       {
/*     */ 
/* 525 */         writer.write(c1);
/*     */ 
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/*     */ 
/*     */ 
/* 533 */         if ((codepoint == 45) && (level < 3)) {
/* 534 */           if ((c0 >= 0) || (c2 < 0)) {
/* 535 */             writer.write(c1);
/* 536 */             continue;
/*     */           }
/* 538 */           if ((c2 != 45) && ((c2 < 48) || (c2 > 57))) {
/* 539 */             writer.write(c1);
/* 540 */             continue;
/*     */           }
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 548 */         if ((codepoint == 95) && (level < 3) && (c0 >= 0)) {
/* 549 */           writer.write(c1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         }
/* 557 */         else if ((codepoint > 159) && (level < ESCAPE_LEVELS[' ']))
/*     */         {
/* 559 */           writer.write(c1);
/*     */           
/* 561 */           if (Character.charCount(codepoint) > 1)
/*     */           {
/*     */ 
/* 564 */             writer.write(c2);
/*     */             
/* 566 */             c0 = c1;
/* 567 */             c1 = c2;
/* 568 */             c2 = reader.read();
/*     */ 
/*     */ 
/*     */           }
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/* 582 */           if (Character.charCount(codepoint) > 1)
/*     */           {
/* 584 */             c0 = c1;
/* 585 */             c1 = c2;
/* 586 */             c2 = reader.read();
/*     */           }
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 598 */           if ((useBackslashEscapes) && (codepoint < BACKSLASH_CHARS_LEN))
/*     */           {
/*     */ 
/* 601 */             char escape = BACKSLASH_CHARS[codepoint];
/*     */             
/* 603 */             if (escape != BACKSLASH_CHARS_NO_ESCAPE)
/*     */             {
/* 605 */               writer.write(92);
/* 606 */               writer.write(escape);
/* 607 */               continue;
/*     */             }
/*     */           }
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 616 */           char next = c2 >= 0 ? (char)c2 : '\000';
/*     */           
/* 618 */           if (useCompactHexa) {
/* 619 */             writer.write(92);
/* 620 */             writer.write(toCompactHexa(codepoint, next, level));
/*     */           }
/*     */           else
/*     */           {
/* 624 */             writer.write(92);
/* 625 */             writer.write(toSixDigitHexa(codepoint, next, level));
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static void escape(char[] text, int offset, int len, Writer writer, CssIdentifierEscapeType escapeType, CssIdentifierEscapeLevel escapeLevel)
/*     */     throws IOException
/*     */   {
/* 642 */     if ((text == null) || (text.length == 0)) {
/* 643 */       return;
/*     */     }
/*     */     
/* 646 */     int level = escapeLevel.getEscapeLevel();
/* 647 */     boolean useBackslashEscapes = escapeType.getUseBackslashEscapes();
/* 648 */     boolean useCompactHexa = escapeType.getUseCompactHexa();
/*     */     
/* 650 */     int max = offset + len;
/*     */     
/* 652 */     int readOffset = offset;
/*     */     
/* 654 */     for (int i = offset; i < max; i++)
/*     */     {
/* 656 */       int codepoint = Character.codePointAt(text, i);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 663 */       if ((codepoint > 159) || (level >= ESCAPE_LEVELS[codepoint]) || ((i <= offset) && (codepoint >= 48) && (codepoint <= 57)))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 673 */         if ((codepoint == 45) && (level < 3)) {
/* 674 */           if ((i <= offset) && (i + 1 < max))
/*     */           {
/*     */ 
/* 677 */             char c1 = text[(i + 1)];
/* 678 */             if ((c1 != '-') && ((c1 < '0') || (c1 > '9'))) {}
/*     */ 
/*     */ 
/*     */           }
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */         }
/* 687 */         else if ((codepoint != 95) || (level >= 3) || (i <= offset))
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 695 */           if ((codepoint > 159) && (level < ESCAPE_LEVELS[' ']))
/*     */           {
/* 697 */             if (Character.charCount(codepoint) > 1)
/*     */             {
/* 699 */               i++;
/*     */ 
/*     */ 
/*     */             }
/*     */             
/*     */ 
/*     */ 
/*     */ 
/*     */           }
/*     */           else
/*     */           {
/*     */ 
/*     */ 
/* 712 */             if (i - readOffset > 0) {
/* 713 */               writer.write(text, readOffset, i - readOffset);
/*     */             }
/*     */             
/* 716 */             if (Character.charCount(codepoint) > 1)
/*     */             {
/* 718 */               i++;
/*     */             }
/*     */             
/* 721 */             readOffset = i + 1;
/*     */             
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 732 */             if ((useBackslashEscapes) && (codepoint < BACKSLASH_CHARS_LEN))
/*     */             {
/*     */ 
/* 735 */               char escape = BACKSLASH_CHARS[codepoint];
/*     */               
/* 737 */               if (escape != BACKSLASH_CHARS_NO_ESCAPE)
/*     */               {
/* 739 */                 writer.write(92);
/* 740 */                 writer.write(escape);
/* 741 */                 continue;
/*     */               }
/*     */             }
/*     */             
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 751 */             char next = i + 1 < max ? text[(i + 1)] : '\000';
/*     */             
/* 753 */             if (useCompactHexa) {
/* 754 */               writer.write(92);
/* 755 */               writer.write(toCompactHexa(codepoint, next, level));
/*     */             }
/*     */             else
/*     */             {
/* 759 */               writer.write(92);
/* 760 */               writer.write(toSixDigitHexa(codepoint, next, level));
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 771 */     if (max - readOffset > 0) {
/* 772 */       writer.write(text, readOffset, max - readOffset);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static int codePointAt(char c1, char c2)
/*     */   {
/* 781 */     if ((Character.isHighSurrogate(c1)) && 
/* 782 */       (c2 >= 0) && 
/* 783 */       (Character.isLowSurrogate(c2))) {
/* 784 */       return Character.toCodePoint(c1, c2);
/*     */     }
/*     */     
/*     */ 
/* 788 */     return c1;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\unbescape-1.1.6.RELEASE.jar!\org\unbescape\css\CssIdentifierEscapeUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */