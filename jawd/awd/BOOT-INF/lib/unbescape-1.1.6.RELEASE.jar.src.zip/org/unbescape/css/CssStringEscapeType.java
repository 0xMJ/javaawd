/*    */ package org.unbescape.css;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum CssStringEscapeType
/*    */ {
/* 59 */   BACKSLASH_ESCAPES_DEFAULT_TO_COMPACT_HEXA(true, true), 
/*    */   
/*    */ 
/*    */ 
/*    */ 
/* 64 */   BACKSLASH_ESCAPES_DEFAULT_TO_SIX_DIGIT_HEXA(true, false), 
/*    */   
/*    */ 
/*    */ 
/*    */ 
/* 69 */   COMPACT_HEXA(false, true), 
/*    */   
/*    */ 
/*    */ 
/*    */ 
/* 74 */   SIX_DIGIT_HEXA(false, false);
/*    */   
/*    */   private final boolean useBackslashEscapes;
/*    */   private final boolean useCompactHexa;
/*    */   
/*    */   private CssStringEscapeType(boolean useBackslashEscapes, boolean useCompactHexa)
/*    */   {
/* 81 */     this.useBackslashEscapes = useBackslashEscapes;
/* 82 */     this.useCompactHexa = useCompactHexa;
/*    */   }
/*    */   
/*    */   public boolean getUseBackslashEscapes() {
/* 86 */     return this.useBackslashEscapes;
/*    */   }
/*    */   
/*    */   public boolean getUseCompactHexa() {
/* 90 */     return this.useCompactHexa;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\unbescape-1.1.6.RELEASE.jar!\org\unbescape\css\CssStringEscapeType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */