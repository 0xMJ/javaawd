/*     */ package org.unbescape.java;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum JavaEscapeLevel
/*     */ {
/*  76 */   LEVEL_1_BASIC_ESCAPE_SET(1), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  81 */   LEVEL_2_ALL_NON_ASCII_PLUS_BASIC_ESCAPE_SET(2), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  87 */   LEVEL_3_ALL_NON_ALPHANUMERIC(3), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  92 */   LEVEL_4_ALL_CHARACTERS(4);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final int escapeLevel;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static JavaEscapeLevel forLevel(int level)
/*     */   {
/* 109 */     switch (level) {
/* 110 */     case 1:  return LEVEL_1_BASIC_ESCAPE_SET;
/* 111 */     case 2:  return LEVEL_2_ALL_NON_ASCII_PLUS_BASIC_ESCAPE_SET;
/* 112 */     case 3:  return LEVEL_3_ALL_NON_ALPHANUMERIC;
/* 113 */     case 4:  return LEVEL_4_ALL_CHARACTERS;
/*     */     }
/* 115 */     throw new IllegalArgumentException("No escape level enum constant defined for level: " + level);
/*     */   }
/*     */   
/*     */ 
/*     */   private JavaEscapeLevel(int escapeLevel)
/*     */   {
/* 121 */     this.escapeLevel = escapeLevel;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getEscapeLevel()
/*     */   {
/* 130 */     return this.escapeLevel;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\unbescape-1.1.6.RELEASE.jar!\org\unbescape\java\JavaEscapeLevel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */