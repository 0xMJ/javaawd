/*      */ package org.unbescape.java;
/*      */ 
/*      */ import java.io.CharArrayWriter;
/*      */ import java.io.IOException;
/*      */ import java.io.Reader;
/*      */ import java.io.Writer;
/*      */ import java.util.Arrays;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ final class JavaEscapeUtil
/*      */ {
/*      */   private static final char ESCAPE_PREFIX = '\\';
/*      */   private static final char ESCAPE_UHEXA_PREFIX2 = 'u';
/*  110 */   private static final char[] ESCAPE_UHEXA_PREFIX = "\\u".toCharArray();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  115 */   private static char[] HEXA_CHARS_UPPER = "0123456789ABCDEF".toCharArray();
/*  116 */   private static char[] HEXA_CHARS_LOWER = "0123456789abcdef".toCharArray();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  122 */   private static int SEC_CHARS_LEN = 93;
/*  123 */   private static char SEC_CHARS_NO_SEC = '*';
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  141 */   private static char[] SEC_CHARS = new char[SEC_CHARS_LEN];
/*  142 */   static { Arrays.fill(SEC_CHARS, SEC_CHARS_NO_SEC);
/*  143 */     SEC_CHARS[8] = 'b';
/*  144 */     SEC_CHARS[9] = 't';
/*  145 */     SEC_CHARS[10] = 'n';
/*  146 */     SEC_CHARS[12] = 'f';
/*  147 */     SEC_CHARS[13] = 'r';
/*  148 */     SEC_CHARS[34] = '"';
/*      */     
/*      */ 
/*  151 */     SEC_CHARS[39] = '\'';
/*  152 */     SEC_CHARS[92] = '\\';
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  166 */     ESCAPE_LEVELS = new byte['¡'];
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  171 */     Arrays.fill(ESCAPE_LEVELS, (byte)3);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  176 */     for (char c = ''; c < '¡'; c = (char)(c + '\001')) {
/*  177 */       ESCAPE_LEVELS[c] = 2;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  183 */     for (char c = 'A'; c <= 'Z'; c = (char)(c + '\001')) {
/*  184 */       ESCAPE_LEVELS[c] = 4;
/*      */     }
/*  186 */     for (char c = 'a'; c <= 'z'; c = (char)(c + '\001')) {
/*  187 */       ESCAPE_LEVELS[c] = 4;
/*      */     }
/*  189 */     for (char c = '0'; c <= '9'; c = (char)(c + '\001')) {
/*  190 */       ESCAPE_LEVELS[c] = 4;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  196 */     ESCAPE_LEVELS[8] = 1;
/*  197 */     ESCAPE_LEVELS[9] = 1;
/*  198 */     ESCAPE_LEVELS[10] = 1;
/*  199 */     ESCAPE_LEVELS[12] = 1;
/*  200 */     ESCAPE_LEVELS[13] = 1;
/*  201 */     ESCAPE_LEVELS[34] = 1;
/*      */     
/*      */ 
/*  204 */     ESCAPE_LEVELS[39] = 3;
/*  205 */     ESCAPE_LEVELS[92] = 1;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  211 */     for (char c = '\000'; c <= '\037'; c = (char)(c + '\001')) {
/*  212 */       ESCAPE_LEVELS[c] = 1;
/*      */     }
/*  214 */     for (char c = ''; c <= ''; c = (char)(c + '\001')) {
/*  215 */       ESCAPE_LEVELS[c] = 1;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static char[] toUHexa(int codepoint)
/*      */   {
/*  230 */     char[] result = new char[4];
/*  231 */     result[3] = HEXA_CHARS_UPPER[(codepoint % 16)];
/*  232 */     result[2] = HEXA_CHARS_UPPER[((codepoint >>> 4) % 16)];
/*  233 */     result[1] = HEXA_CHARS_UPPER[((codepoint >>> 8) % 16)];
/*  234 */     result[0] = HEXA_CHARS_UPPER[((codepoint >>> 12) % 16)];
/*  235 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static String escape(String text, JavaEscapeLevel escapeLevel)
/*      */   {
/*  245 */     if (text == null) {
/*  246 */       return null;
/*      */     }
/*      */     
/*  249 */     int level = escapeLevel.getEscapeLevel();
/*      */     
/*  251 */     StringBuilder strBuilder = null;
/*      */     
/*  253 */     int offset = 0;
/*  254 */     int max = text.length();
/*      */     
/*  256 */     int readOffset = 0;
/*      */     
/*  258 */     for (int i = 0; i < max; i++)
/*      */     {
/*  260 */       int codepoint = Character.codePointAt(text, i);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  267 */       if ((codepoint > 159) || (level >= ESCAPE_LEVELS[codepoint]))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  274 */         if ((codepoint > 159) && (level < ESCAPE_LEVELS[' ']))
/*      */         {
/*  276 */           if (Character.charCount(codepoint) > 1)
/*      */           {
/*  278 */             i++;
/*      */ 
/*      */ 
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*  292 */           if (strBuilder == null) {
/*  293 */             strBuilder = new StringBuilder(max + 20);
/*      */           }
/*      */           
/*  296 */           if (i - readOffset > 0) {
/*  297 */             strBuilder.append(text, readOffset, i);
/*      */           }
/*      */           
/*  300 */           if (Character.charCount(codepoint) > 1)
/*      */           {
/*  302 */             i++;
/*      */           }
/*      */           
/*  305 */           readOffset = i + 1;
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  316 */           if (codepoint < SEC_CHARS_LEN)
/*      */           {
/*      */ 
/*  319 */             char sec = SEC_CHARS[codepoint];
/*      */             
/*  321 */             if (sec != SEC_CHARS_NO_SEC)
/*      */             {
/*  323 */               strBuilder.append('\\');
/*  324 */               strBuilder.append(sec);
/*  325 */               continue;
/*      */             }
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  334 */           if (Character.charCount(codepoint) > 1) {
/*  335 */             char[] codepointChars = Character.toChars(codepoint);
/*  336 */             strBuilder.append(ESCAPE_UHEXA_PREFIX);
/*  337 */             strBuilder.append(toUHexa(codepointChars[0]));
/*  338 */             strBuilder.append(ESCAPE_UHEXA_PREFIX);
/*  339 */             strBuilder.append(toUHexa(codepointChars[1]));
/*      */           }
/*      */           else
/*      */           {
/*  343 */             strBuilder.append(ESCAPE_UHEXA_PREFIX);
/*  344 */             strBuilder.append(toUHexa(codepoint));
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  356 */     if (strBuilder == null) {
/*  357 */       return text;
/*      */     }
/*      */     
/*  360 */     if (max - readOffset > 0) {
/*  361 */       strBuilder.append(text, readOffset, max);
/*      */     }
/*      */     
/*  364 */     return strBuilder.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final char ESCAPE_LEVELS_LEN = '¡';
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static void escape(Reader reader, Writer writer, JavaEscapeLevel escapeLevel)
/*      */     throws IOException
/*      */   {
/*  381 */     if (reader == null) {
/*  382 */       return;
/*      */     }
/*      */     
/*  385 */     int level = escapeLevel.getEscapeLevel();
/*      */     
/*      */ 
/*      */ 
/*  389 */     int c2 = reader.read();
/*      */     
/*  391 */     while (c2 >= 0)
/*      */     {
/*  393 */       int c1 = c2;
/*  394 */       c2 = reader.read();
/*      */       
/*  396 */       int codepoint = codePointAt((char)c1, (char)c2);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  403 */       if ((codepoint <= 159) && (level < ESCAPE_LEVELS[codepoint])) {
/*  404 */         writer.write(c1);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/*  411 */       else if ((codepoint > 159) && (level < ESCAPE_LEVELS[' ']))
/*      */       {
/*  413 */         writer.write(c1);
/*      */         
/*  415 */         if (Character.charCount(codepoint) > 1)
/*      */         {
/*      */ 
/*  418 */           writer.write(c2);
/*      */           
/*  420 */           c1 = c2;
/*  421 */           c2 = reader.read();
/*      */ 
/*      */ 
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*  435 */         if (Character.charCount(codepoint) > 1)
/*      */         {
/*  437 */           c1 = c2;
/*  438 */           c2 = reader.read();
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  450 */         if (codepoint < SEC_CHARS_LEN)
/*      */         {
/*      */ 
/*  453 */           char sec = SEC_CHARS[codepoint];
/*      */           
/*  455 */           if (sec != SEC_CHARS_NO_SEC)
/*      */           {
/*  457 */             writer.write(92);
/*  458 */             writer.write(sec);
/*  459 */             continue;
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  468 */         if (Character.charCount(codepoint) > 1) {
/*  469 */           char[] codepointChars = Character.toChars(codepoint);
/*  470 */           writer.write(ESCAPE_UHEXA_PREFIX);
/*  471 */           writer.write(toUHexa(codepointChars[0]));
/*  472 */           writer.write(ESCAPE_UHEXA_PREFIX);
/*  473 */           writer.write(toUHexa(codepointChars[1]));
/*      */         }
/*      */         else
/*      */         {
/*  477 */           writer.write(ESCAPE_UHEXA_PREFIX);
/*  478 */           writer.write(toUHexa(codepoint));
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static void escape(char[] text, int offset, int len, Writer writer, JavaEscapeLevel escapeLevel)
/*      */     throws IOException
/*      */   {
/*  494 */     if ((text == null) || (text.length == 0)) {
/*  495 */       return;
/*      */     }
/*      */     
/*  498 */     int level = escapeLevel.getEscapeLevel();
/*      */     
/*  500 */     int max = offset + len;
/*      */     
/*  502 */     int readOffset = offset;
/*      */     
/*  504 */     for (int i = offset; i < max; i++)
/*      */     {
/*  506 */       int codepoint = Character.codePointAt(text, i);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  513 */       if ((codepoint > 159) || (level >= ESCAPE_LEVELS[codepoint]))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  520 */         if ((codepoint > 159) && (level < ESCAPE_LEVELS[' ']))
/*      */         {
/*  522 */           if (Character.charCount(codepoint) > 1)
/*      */           {
/*  524 */             i++;
/*      */ 
/*      */ 
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/*      */ 
/*      */ 
/*  537 */           if (i - readOffset > 0) {
/*  538 */             writer.write(text, readOffset, i - readOffset);
/*      */           }
/*      */           
/*  541 */           if (Character.charCount(codepoint) > 1)
/*      */           {
/*  543 */             i++;
/*      */           }
/*      */           
/*  546 */           readOffset = i + 1;
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  557 */           if (codepoint < SEC_CHARS_LEN)
/*      */           {
/*      */ 
/*  560 */             char sec = SEC_CHARS[codepoint];
/*      */             
/*  562 */             if (sec != SEC_CHARS_NO_SEC)
/*      */             {
/*  564 */               writer.write(92);
/*  565 */               writer.write(sec);
/*  566 */               continue;
/*      */             }
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  575 */           if (Character.charCount(codepoint) > 1) {
/*  576 */             char[] codepointChars = Character.toChars(codepoint);
/*  577 */             writer.write(ESCAPE_UHEXA_PREFIX);
/*  578 */             writer.write(toUHexa(codepointChars[0]));
/*  579 */             writer.write(ESCAPE_UHEXA_PREFIX);
/*  580 */             writer.write(toUHexa(codepointChars[1]));
/*      */           }
/*      */           else
/*      */           {
/*  584 */             writer.write(ESCAPE_UHEXA_PREFIX);
/*  585 */             writer.write(toUHexa(codepoint));
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  596 */     if (max - readOffset > 0) {
/*  597 */       writer.write(text, readOffset, max - readOffset);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final byte[] ESCAPE_LEVELS;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static int parseIntFromReference(String text, int start, int end, int radix)
/*      */   {
/*  616 */     int result = 0;
/*  617 */     for (int i = start; i < end; i++) {
/*  618 */       char c = text.charAt(i);
/*  619 */       int n = -1;
/*  620 */       for (int j = 0; j < HEXA_CHARS_UPPER.length; j++) {
/*  621 */         if ((c == HEXA_CHARS_UPPER[j]) || (c == HEXA_CHARS_LOWER[j])) {
/*  622 */           n = j;
/*  623 */           break;
/*      */         }
/*      */       }
/*  626 */       result = radix * result + n;
/*      */     }
/*  628 */     return result;
/*      */   }
/*      */   
/*      */   static int parseIntFromReference(char[] text, int start, int end, int radix) {
/*  632 */     int result = 0;
/*  633 */     for (int i = start; i < end; i++) {
/*  634 */       char c = text[i];
/*  635 */       int n = -1;
/*  636 */       for (int j = 0; j < HEXA_CHARS_UPPER.length; j++) {
/*  637 */         if ((c == HEXA_CHARS_UPPER[j]) || (c == HEXA_CHARS_LOWER[j])) {
/*  638 */           n = j;
/*  639 */           break;
/*      */         }
/*      */       }
/*  642 */       result = radix * result + n;
/*      */     }
/*  644 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static boolean isOctalEscape(String text, int start, int end)
/*      */   {
/*  653 */     if (start >= end) {
/*  654 */       return false;
/*      */     }
/*      */     
/*  657 */     char c1 = text.charAt(start);
/*  658 */     if ((c1 < '0') || (c1 > '7')) {
/*  659 */       return false;
/*      */     }
/*      */     
/*  662 */     if (start + 1 >= end) {
/*  663 */       return c1 != '0';
/*      */     }
/*      */     
/*  666 */     char c2 = text.charAt(start + 1);
/*  667 */     if ((c2 < '0') || (c2 > '7')) {
/*  668 */       return c1 != '0';
/*      */     }
/*      */     
/*  671 */     if (start + 2 >= end) {
/*  672 */       return (c1 != '0') || (c2 != '0');
/*      */     }
/*      */     
/*  675 */     char c3 = text.charAt(start + 2);
/*  676 */     if ((c3 < '0') || (c3 > '7')) {
/*  677 */       return (c1 != '0') || (c2 != '0');
/*      */     }
/*      */     
/*  680 */     return (c1 != '0') || (c2 != '0') || (c3 != '0');
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   static boolean isOctalEscape(char[] text, int start, int end)
/*      */   {
/*  687 */     if (start >= end) {
/*  688 */       return false;
/*      */     }
/*      */     
/*  691 */     char c1 = text[start];
/*  692 */     if ((c1 < '0') || (c1 > '7')) {
/*  693 */       return false;
/*      */     }
/*      */     
/*  696 */     if (start + 1 >= end) {
/*  697 */       return c1 != '0';
/*      */     }
/*      */     
/*  700 */     char c2 = text[(start + 1)];
/*  701 */     if ((c2 < '0') || (c2 > '7')) {
/*  702 */       return c1 != '0';
/*      */     }
/*      */     
/*  705 */     if (start + 2 >= end) {
/*  706 */       return (c1 != '0') || (c2 != '0');
/*      */     }
/*      */     
/*  709 */     char c3 = text[(start + 2)];
/*  710 */     if ((c3 < '0') || (c3 > '7')) {
/*  711 */       return (c1 != '0') || (c2 != '0');
/*      */     }
/*      */     
/*  714 */     return (c1 != '0') || (c2 != '0') || (c3 != '0');
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static String unicodeUnescape(String text)
/*      */   {
/*  727 */     if (text == null) {
/*  728 */       return null;
/*      */     }
/*      */     
/*  731 */     StringBuilder strBuilder = null;
/*      */     
/*  733 */     int offset = 0;
/*  734 */     int max = text.length();
/*      */     
/*  736 */     int readOffset = 0;
/*  737 */     int referenceOffset = 0;
/*      */     
/*  739 */     for (int i = 0; i < max; i++)
/*      */     {
/*  741 */       char c = text.charAt(i);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  747 */       if ((c == '\\') && (i + 1 < max))
/*      */       {
/*      */ 
/*      */ 
/*  751 */         int codepoint = -1;
/*      */         
/*  753 */         if (c == '\\')
/*      */         {
/*  755 */           char c1 = text.charAt(i + 1);
/*      */           
/*  757 */           if (c1 == 'u')
/*      */           {
/*      */ 
/*  760 */             int f = i + 2;
/*      */             
/*  762 */             while (f < max) {
/*  763 */               char cf = text.charAt(f);
/*  764 */               if (cf != 'u') {
/*      */                 break;
/*      */               }
/*  767 */               f++;
/*      */             }
/*  769 */             int s = f;
/*      */             
/*  771 */             while ((f < s + 4) && (f < max)) {
/*  772 */               char cf = text.charAt(f);
/*  773 */               if (((cf < '0') || (cf > '9')) && ((cf < 'A') || (cf > 'F')) && ((cf < 'a') || (cf > 'f'))) {
/*      */                 break;
/*      */               }
/*  776 */               f++;
/*      */             }
/*      */             
/*  779 */             if (f - s < 4)
/*      */             {
/*      */ 
/*  782 */               i++;
/*  783 */               continue;
/*      */             }
/*      */             
/*  786 */             codepoint = parseIntFromReference(text, s, f, 16);
/*      */             
/*      */ 
/*  789 */             referenceOffset = f - 1;
/*      */ 
/*      */ 
/*      */           }
/*      */           else
/*      */           {
/*      */ 
/*  796 */             i++;
/*  797 */             continue;
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  810 */         if (strBuilder == null) {
/*  811 */           strBuilder = new StringBuilder(max + 5);
/*      */         }
/*      */         
/*  814 */         if (i - readOffset > 0) {
/*  815 */           strBuilder.append(text, readOffset, i);
/*      */         }
/*      */         
/*  818 */         i = referenceOffset;
/*  819 */         readOffset = i + 1;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  829 */         if (codepoint > 65535) {
/*  830 */           strBuilder.append(Character.toChars(codepoint));
/*      */         } else {
/*  832 */           strBuilder.append((char)codepoint);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  845 */     if (strBuilder == null) {
/*  846 */       return text;
/*      */     }
/*      */     
/*  849 */     if (max - readOffset > 0) {
/*  850 */       strBuilder.append(text, readOffset, max);
/*      */     }
/*      */     
/*  853 */     return strBuilder.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static boolean requiresUnicodeUnescape(char[] text, int offset, int len)
/*      */   {
/*  865 */     if (text == null) {
/*  866 */       return false;
/*      */     }
/*      */     
/*  869 */     int max = offset + len;
/*      */     
/*  871 */     for (int i = offset; i < max; i++)
/*      */     {
/*  873 */       char c = text[i];
/*      */       
/*  875 */       if ((c == '\\') && (i + 1 < max))
/*      */       {
/*      */ 
/*      */ 
/*  879 */         if (c == '\\')
/*      */         {
/*  881 */           char c1 = text[(i + 1)];
/*      */           
/*  883 */           if (c1 == 'u')
/*      */           {
/*  885 */             return true;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  892 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static void unicodeUnescape(char[] text, int offset, int len, Writer writer)
/*      */     throws IOException
/*      */   {
/*  906 */     if (text == null) {
/*  907 */       return;
/*      */     }
/*      */     
/*  910 */     int max = offset + len;
/*      */     
/*  912 */     int readOffset = offset;
/*  913 */     int referenceOffset = offset;
/*      */     
/*  915 */     for (int i = offset; i < max; i++)
/*      */     {
/*  917 */       char c = text[i];
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  923 */       if ((c == '\\') && (i + 1 < max))
/*      */       {
/*      */ 
/*      */ 
/*  927 */         int codepoint = -1;
/*      */         
/*  929 */         if (c == '\\')
/*      */         {
/*  931 */           char c1 = text[(i + 1)];
/*      */           
/*  933 */           if (c1 == 'u')
/*      */           {
/*      */ 
/*  936 */             int f = i + 2;
/*      */             
/*  938 */             while (f < max) {
/*  939 */               char cf = text[f];
/*  940 */               if (cf != 'u') {
/*      */                 break;
/*      */               }
/*  943 */               f++;
/*      */             }
/*  945 */             int s = f;
/*      */             
/*  947 */             while ((f < s + 4) && (f < max)) {
/*  948 */               char cf = text[f];
/*  949 */               if (((cf < '0') || (cf > '9')) && ((cf < 'A') || (cf > 'F')) && ((cf < 'a') || (cf > 'f'))) {
/*      */                 break;
/*      */               }
/*  952 */               f++;
/*      */             }
/*      */             
/*  955 */             if (f - s < 4)
/*      */             {
/*      */ 
/*  958 */               i++;
/*  959 */               continue;
/*      */             }
/*      */             
/*  962 */             codepoint = parseIntFromReference(text, s, f, 16);
/*      */             
/*      */ 
/*  965 */             referenceOffset = f - 1;
/*      */ 
/*      */ 
/*      */           }
/*      */           else
/*      */           {
/*      */ 
/*  972 */             i++;
/*  973 */             continue;
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  985 */         if (i - readOffset > 0) {
/*  986 */           writer.write(text, readOffset, i - readOffset);
/*      */         }
/*      */         
/*  989 */         i = referenceOffset;
/*  990 */         readOffset = i + 1;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1000 */         if (codepoint > 65535) {
/* 1001 */           writer.write(Character.toChars(codepoint));
/*      */         } else {
/* 1003 */           writer.write((char)codepoint);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1015 */     if (max - readOffset > 0) {
/* 1016 */       writer.write(text, readOffset, max - readOffset);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static String unescape(String text)
/*      */   {
/* 1031 */     if (text == null) {
/* 1032 */       return null;
/*      */     }
/*      */     
/*      */ 
/* 1036 */     String unicodeEscapedText = unicodeUnescape(text);
/*      */     
/* 1038 */     StringBuilder strBuilder = null;
/*      */     
/* 1040 */     int offset = 0;
/* 1041 */     int max = unicodeEscapedText.length();
/*      */     
/* 1043 */     int readOffset = 0;
/* 1044 */     int referenceOffset = 0;
/*      */     
/* 1046 */     for (int i = 0; i < max; i++)
/*      */     {
/* 1048 */       char c = unicodeEscapedText.charAt(i);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1054 */       if ((c == '\\') && (i + 1 < max))
/*      */       {
/*      */ 
/*      */ 
/* 1058 */         int codepoint = -1;
/*      */         
/* 1060 */         if (c == '\\')
/*      */         {
/* 1062 */           char c1 = unicodeEscapedText.charAt(i + 1);
/*      */           
/* 1064 */           switch (c1) {
/* 1065 */           case '0':  if (!isOctalEscape(unicodeEscapedText, i + 1, max)) { codepoint = 0;referenceOffset = i + 1; }
/*      */             break; case 'b':  codepoint = 8;referenceOffset = i + 1; break;
/* 1067 */           case 't':  codepoint = 9;referenceOffset = i + 1; break;
/* 1068 */           case 'n':  codepoint = 10;referenceOffset = i + 1; break;
/* 1069 */           case 'f':  codepoint = 12;referenceOffset = i + 1; break;
/* 1070 */           case 'r':  codepoint = 13;referenceOffset = i + 1; break;
/* 1071 */           case '"':  codepoint = 34;referenceOffset = i + 1; break;
/* 1072 */           case '\'':  codepoint = 39;referenceOffset = i + 1; break;
/* 1073 */           case '\\':  codepoint = 92;referenceOffset = i + 1;
/*      */           }
/*      */           
/* 1076 */           if (codepoint == -1)
/*      */           {
/* 1078 */             if ((c1 >= '0') && (c1 <= '7'))
/*      */             {
/*      */ 
/* 1081 */               int f = i + 2;
/* 1082 */               while ((f < i + 4) && (f < max)) {
/* 1083 */                 char cf = unicodeEscapedText.charAt(f);
/* 1084 */                 if ((cf < '0') || (cf > '7')) {
/*      */                   break;
/*      */                 }
/* 1087 */                 f++;
/*      */               }
/*      */               
/* 1090 */               codepoint = parseIntFromReference(unicodeEscapedText, i + 1, f, 8);
/*      */               
/* 1092 */               if (codepoint > 255)
/*      */               {
/* 1094 */                 codepoint = parseIntFromReference(unicodeEscapedText, i + 1, f - 1, 8);
/* 1095 */                 referenceOffset = f - 2;
/*      */               } else {
/* 1097 */                 referenceOffset = f - 1;
/*      */ 
/*      */               }
/*      */               
/*      */ 
/*      */             }
/*      */             else
/*      */             {
/*      */ 
/* 1106 */               i++;
/* 1107 */               continue;
/*      */             }
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1122 */         if (strBuilder == null) {
/* 1123 */           strBuilder = new StringBuilder(max + 5);
/*      */         }
/*      */         
/* 1126 */         if (i - readOffset > 0) {
/* 1127 */           strBuilder.append(unicodeEscapedText, readOffset, i);
/*      */         }
/*      */         
/* 1130 */         i = referenceOffset;
/* 1131 */         readOffset = i + 1;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1141 */         if (codepoint > 65535) {
/* 1142 */           strBuilder.append(Character.toChars(codepoint));
/*      */         } else {
/* 1144 */           strBuilder.append((char)codepoint);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1157 */     if (strBuilder == null) {
/* 1158 */       return unicodeEscapedText;
/*      */     }
/*      */     
/* 1161 */     if (max - readOffset > 0) {
/* 1162 */       strBuilder.append(unicodeEscapedText, readOffset, max);
/*      */     }
/*      */     
/* 1165 */     return strBuilder.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static void unescape(Reader reader, Writer writer)
/*      */     throws IOException
/*      */   {
/* 1182 */     if (reader == null) {
/* 1183 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1199 */     char[] buffer = new char[20];
/*      */     
/* 1201 */     int read = reader.read(buffer, 0, buffer.length);
/* 1202 */     if (read < 0) {
/* 1203 */       return;
/*      */     }
/*      */     
/* 1206 */     int bufferSize = read;
/*      */     
/* 1208 */     while ((bufferSize > 0) || (read >= 0))
/*      */     {
/* 1210 */       int nonEscCounter = 0;
/*      */       
/* 1212 */       int n = bufferSize;
/* 1213 */       while ((nonEscCounter < 8) && (n-- != 0)) {
/* 1214 */         if (buffer[n] == '\\') {
/* 1215 */           nonEscCounter = 0;
/*      */         }
/*      */         else {
/* 1218 */           nonEscCounter++;
/*      */         }
/*      */       }
/* 1221 */       if ((nonEscCounter < 8) && (read >= 0))
/*      */       {
/*      */ 
/* 1224 */         if (bufferSize == buffer.length)
/*      */         {
/* 1226 */           char[] newBuffer = new char[buffer.length + buffer.length / 2];
/* 1227 */           System.arraycopy(buffer, 0, newBuffer, 0, buffer.length);
/* 1228 */           buffer = newBuffer;
/*      */         }
/*      */         
/* 1231 */         read = reader.read(buffer, bufferSize, buffer.length - bufferSize);
/* 1232 */         if (read >= 0) {
/* 1233 */           bufferSize += read;
/*      */         }
/*      */         
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/* 1240 */         n = n < 0 ? bufferSize : n + nonEscCounter;
/*      */         
/*      */ 
/* 1243 */         unescape(buffer, 0, n, writer);
/*      */         
/* 1245 */         System.arraycopy(buffer, n, buffer, 0, bufferSize - n);
/* 1246 */         bufferSize -= n;
/*      */         
/* 1248 */         read = reader.read(buffer, bufferSize, buffer.length - bufferSize);
/* 1249 */         if (read >= 0) {
/* 1250 */           bufferSize += read;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static void unescape(char[] text, int offset, int len, Writer writer)
/*      */     throws IOException
/*      */   {
/* 1268 */     if (text == null) {
/* 1269 */       return;
/*      */     }
/*      */     
/* 1272 */     char[] unicodeEscapedText = text;
/* 1273 */     int unicodeEscapedOffset = offset;
/* 1274 */     int unicodeEscapedLen = len;
/* 1275 */     if (requiresUnicodeUnescape(text, offset, len)) {
/* 1276 */       CharArrayWriter charArrayWriter = new CharArrayWriter(len + 2);
/* 1277 */       unicodeUnescape(text, offset, len, charArrayWriter);
/* 1278 */       unicodeEscapedText = charArrayWriter.toCharArray();
/* 1279 */       unicodeEscapedOffset = 0;
/* 1280 */       unicodeEscapedLen = unicodeEscapedText.length;
/*      */     }
/*      */     
/* 1283 */     int max = unicodeEscapedOffset + unicodeEscapedLen;
/*      */     
/* 1285 */     int readOffset = unicodeEscapedOffset;
/* 1286 */     int referenceOffset = unicodeEscapedOffset;
/*      */     
/* 1288 */     for (int i = unicodeEscapedOffset; i < max; i++)
/*      */     {
/* 1290 */       char c = unicodeEscapedText[i];
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1296 */       if ((c == '\\') && (i + 1 < max))
/*      */       {
/*      */ 
/*      */ 
/* 1300 */         int codepoint = -1;
/*      */         
/* 1302 */         if (c == '\\')
/*      */         {
/* 1304 */           char c1 = unicodeEscapedText[(i + 1)];
/*      */           
/* 1306 */           switch (c1) {
/* 1307 */           case '0':  if (!isOctalEscape(unicodeEscapedText, i + 1, max)) { codepoint = 0;referenceOffset = i + 1; }
/*      */             break; case 'b':  codepoint = 8;referenceOffset = i + 1; break;
/* 1309 */           case 't':  codepoint = 9;referenceOffset = i + 1; break;
/* 1310 */           case 'n':  codepoint = 10;referenceOffset = i + 1; break;
/* 1311 */           case 'f':  codepoint = 12;referenceOffset = i + 1; break;
/* 1312 */           case 'r':  codepoint = 13;referenceOffset = i + 1; break;
/* 1313 */           case '"':  codepoint = 34;referenceOffset = i + 1; break;
/* 1314 */           case '\'':  codepoint = 39;referenceOffset = i + 1; break;
/* 1315 */           case '\\':  codepoint = 92;referenceOffset = i + 1;
/*      */           }
/*      */           
/* 1318 */           if (codepoint == -1)
/*      */           {
/* 1320 */             if ((c1 >= '0') && (c1 <= '7'))
/*      */             {
/*      */ 
/* 1323 */               int f = i + 2;
/* 1324 */               while ((f < i + 4) && (f < max)) {
/* 1325 */                 char cf = unicodeEscapedText[f];
/* 1326 */                 if ((cf < '0') || (cf > '7')) {
/*      */                   break;
/*      */                 }
/* 1329 */                 f++;
/*      */               }
/*      */               
/* 1332 */               codepoint = parseIntFromReference(unicodeEscapedText, i + 1, f, 8);
/*      */               
/* 1334 */               if (codepoint > 255)
/*      */               {
/* 1336 */                 codepoint = parseIntFromReference(unicodeEscapedText, i + 1, f - 1, 8);
/* 1337 */                 referenceOffset = f - 2;
/*      */               } else {
/* 1339 */                 referenceOffset = f - 1;
/*      */ 
/*      */               }
/*      */               
/*      */ 
/*      */             }
/*      */             else
/*      */             {
/*      */ 
/* 1348 */               i++;
/* 1349 */               continue;
/*      */             }
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1363 */         if (i - readOffset > 0) {
/* 1364 */           writer.write(unicodeEscapedText, readOffset, i - readOffset);
/*      */         }
/*      */         
/* 1367 */         i = referenceOffset;
/* 1368 */         readOffset = i + 1;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1378 */         if (codepoint > 65535) {
/* 1379 */           writer.write(Character.toChars(codepoint));
/*      */         } else {
/* 1381 */           writer.write((char)codepoint);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1393 */     if (max - readOffset > 0) {
/* 1394 */       writer.write(unicodeEscapedText, readOffset, max - readOffset);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static int codePointAt(char c1, char c2)
/*      */   {
/* 1404 */     if ((Character.isHighSurrogate(c1)) && 
/* 1405 */       (c2 >= 0) && 
/* 1406 */       (Character.isLowSurrogate(c2))) {
/* 1407 */       return Character.toCodePoint(c1, c2);
/*      */     }
/*      */     
/*      */ 
/* 1411 */     return c1;
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\unbescape-1.1.6.RELEASE.jar!\org\unbescape\java\JavaEscapeUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */