package org.unbescape.xml;

abstract interface XmlCodepointValidator
{
  public abstract boolean isValid(int paramInt);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\unbescape-1.1.6.RELEASE.jar!\org\unbescape\xml\XmlCodepointValidator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */