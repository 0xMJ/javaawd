/*    */ package org.unbescape.xml;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum XmlEscapeType
/*    */ {
/* 57 */   CHARACTER_ENTITY_REFERENCES_DEFAULT_TO_DECIMAL(true, false), 
/*    */   
/*    */ 
/*    */ 
/*    */ 
/* 62 */   CHARACTER_ENTITY_REFERENCES_DEFAULT_TO_HEXA(true, true), 
/*    */   
/*    */ 
/*    */ 
/*    */ 
/* 67 */   DECIMAL_REFERENCES(false, false), 
/*    */   
/*    */ 
/*    */ 
/*    */ 
/* 72 */   HEXADECIMAL_REFERENCES(false, true);
/*    */   
/*    */   private final boolean useCERs;
/*    */   private final boolean useHexa;
/*    */   
/*    */   private XmlEscapeType(boolean useCERs, boolean useHexa)
/*    */   {
/* 79 */     this.useCERs = useCERs;
/* 80 */     this.useHexa = useHexa;
/*    */   }
/*    */   
/*    */   boolean getUseCERs() {
/* 84 */     return this.useCERs;
/*    */   }
/*    */   
/*    */   boolean getUseHexa() {
/* 88 */     return this.useHexa;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\unbescape-1.1.6.RELEASE.jar!\org\unbescape\xml\XmlEscapeType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */