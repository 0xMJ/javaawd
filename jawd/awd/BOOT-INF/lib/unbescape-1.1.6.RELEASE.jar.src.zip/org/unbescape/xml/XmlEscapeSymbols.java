/*     */ package org.unbescape.xml;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class XmlEscapeSymbols
/*     */ {
/* 108 */   static final XmlEscapeSymbols XML10_SYMBOLS = Xml10EscapeSymbolsInitializer.initializeXml10(false);
/* 109 */   static final XmlEscapeSymbols XML11_SYMBOLS = Xml11EscapeSymbolsInitializer.initializeXml11(false);
/* 110 */   static final XmlEscapeSymbols XML10_ATTRIBUTE_SYMBOLS = Xml10EscapeSymbolsInitializer.initializeXml10(true);
/* 111 */   static final XmlEscapeSymbols XML11_ATTRIBUTE_SYMBOLS = Xml11EscapeSymbolsInitializer.initializeXml11(true);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static final char LEVELS_LEN = '¡';
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 137 */   final byte[] ESCAPE_LEVELS = new byte['¡'];
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   final int[] SORTED_CODEPOINTS;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   final char[][] SORTED_CERS_BY_CODEPOINT;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   final char[][] SORTED_CERS;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   final int[] SORTED_CODEPOINTS_BY_CER;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   final XmlCodepointValidator CODEPOINT_VALIDATOR;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   XmlEscapeSymbols(References references, byte[] escapeLevels, XmlCodepointValidator codepointValidator)
/*     */   {
/* 192 */     this.CODEPOINT_VALIDATOR = codepointValidator;
/*     */     
/*     */ 
/* 195 */     System.arraycopy(escapeLevels, 0, this.ESCAPE_LEVELS, 0, 161);
/*     */     
/*     */ 
/* 198 */     int structureLen = references.references.size();
/*     */     
/*     */ 
/* 201 */     List<char[]> cers = new ArrayList(structureLen + 5);
/* 202 */     List<Integer> codepoints = new ArrayList(structureLen + 5);
/*     */     
/*     */ 
/* 205 */     for (Reference reference : references.references) {
/* 206 */       cers.add(reference.cer);
/* 207 */       codepoints.add(Integer.valueOf(reference.codepoint));
/*     */     }
/*     */     
/*     */ 
/* 211 */     this.SORTED_CODEPOINTS = new int[structureLen];
/* 212 */     this.SORTED_CERS_BY_CODEPOINT = new char[structureLen][];
/* 213 */     this.SORTED_CERS = new char[structureLen][];
/* 214 */     this.SORTED_CODEPOINTS_BY_CER = new int[structureLen];
/*     */     
/* 216 */     Object cersOrdered = new ArrayList(cers);
/* 217 */     Collections.sort((List)cersOrdered, new Comparator() {
/*     */       public int compare(char[] o1, char[] o2) {
/* 219 */         return new String(o1).compareTo(new String(o2));
/*     */       }
/*     */       
/* 222 */     });
/* 223 */     List<Integer> codepointsOrdered = new ArrayList(codepoints);
/* 224 */     Collections.sort(codepointsOrdered);
/*     */     
/*     */ 
/* 227 */     for (short i = 0; i < structureLen; i = (short)(i + 1))
/*     */     {
/* 229 */       int codepoint = ((Integer)codepointsOrdered.get(i)).intValue();
/* 230 */       this.SORTED_CODEPOINTS[i] = codepoint;
/* 231 */       for (short j = 0; j < structureLen; j = (short)(j + 1)) {
/* 232 */         if (codepoint == ((Integer)codepoints.get(j)).intValue()) {
/* 233 */           this.SORTED_CERS_BY_CODEPOINT[i] = ((char[])cers.get(j));
/* 234 */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 241 */     for (short i = 0; i < structureLen; i = (short)(i + 1))
/*     */     {
/* 243 */       char[] cer = (char[])((List)cersOrdered).get(i);
/* 244 */       this.SORTED_CERS[i] = cer;
/* 245 */       for (short j = 0; j < structureLen; j = (short)(j + 1)) {
/* 246 */         if (Arrays.equals(cer, (char[])cers.get(j))) {
/* 247 */           this.SORTED_CODEPOINTS_BY_CER[i] = ((Integer)codepoints.get(j)).intValue();
/* 248 */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static int compare(char[] cer, String text, int start, int end)
/*     */   {
/* 265 */     int textLen = end - start;
/* 266 */     int maxCommon = Math.min(cer.length, textLen);
/*     */     
/*     */ 
/* 269 */     for (int i = 1; i < maxCommon; i++) {
/* 270 */       char tc = text.charAt(start + i);
/* 271 */       if (cer[i] < tc)
/* 272 */         return -1;
/* 273 */       if (cer[i] > tc) {
/* 274 */         return 1;
/*     */       }
/*     */     }
/* 277 */     if (cer.length > i) {
/* 278 */       return 1;
/*     */     }
/* 280 */     if (textLen > i) {
/* 281 */       return -1;
/*     */     }
/* 283 */     return 0;
/*     */   }
/*     */   
/*     */   private static int compare(char[] cer, char[] text, int start, int end) {
/* 287 */     int textLen = end - start;
/* 288 */     int maxCommon = Math.min(cer.length, textLen);
/*     */     
/*     */ 
/* 291 */     for (int i = 1; i < maxCommon; i++) {
/* 292 */       char tc = text[(start + i)];
/* 293 */       if (cer[i] < tc)
/* 294 */         return -1;
/* 295 */       if (cer[i] > tc) {
/* 296 */         return 1;
/*     */       }
/*     */     }
/* 299 */     if (cer.length > i) {
/* 300 */       return 1;
/*     */     }
/* 302 */     if (textLen > i) {
/* 303 */       return -1;
/*     */     }
/* 305 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static int binarySearch(char[][] values, String text, int start, int end)
/*     */   {
/* 319 */     int low = 0;
/* 320 */     int high = values.length - 1;
/*     */     
/* 322 */     while (low <= high)
/*     */     {
/* 324 */       int mid = low + high >>> 1;
/* 325 */       char[] midVal = values[mid];
/*     */       
/* 327 */       int cmp = compare(midVal, text, start, end);
/*     */       
/* 329 */       if (cmp == -1) {
/* 330 */         low = mid + 1;
/* 331 */       } else if (cmp == 1) {
/* 332 */         high = mid - 1;
/*     */       }
/*     */       else {
/* 335 */         return mid;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 340 */     return Integer.MIN_VALUE;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   static int binarySearch(char[][] values, char[] text, int start, int end)
/*     */   {
/* 347 */     int low = 0;
/* 348 */     int high = values.length - 1;
/*     */     
/* 350 */     while (low <= high)
/*     */     {
/* 352 */       int mid = low + high >>> 1;
/* 353 */       char[] midVal = values[mid];
/*     */       
/* 355 */       int cmp = compare(midVal, text, start, end);
/*     */       
/* 357 */       if (cmp == -1) {
/* 358 */         low = mid + 1;
/* 359 */       } else if (cmp == 1) {
/* 360 */         high = mid - 1;
/*     */       }
/*     */       else {
/* 363 */         return mid;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 368 */     return Integer.MIN_VALUE;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static final class References
/*     */   {
/* 385 */     private final List<XmlEscapeSymbols.Reference> references = new ArrayList(200);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     void addReference(int codepoint, String cer)
/*     */     {
/* 392 */       this.references.add(new XmlEscapeSymbols.Reference(cer, codepoint, null));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static final class Reference
/*     */   {
/*     */     private final char[] cer;
/*     */     
/*     */     private final int codepoint;
/*     */     
/*     */ 
/*     */     private Reference(String cer, int codepoint)
/*     */     {
/* 406 */       this.cer = cer.toCharArray();
/* 407 */       this.codepoint = codepoint;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\unbescape-1.1.6.RELEASE.jar!\org\unbescape\xml\XmlEscapeSymbols.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */