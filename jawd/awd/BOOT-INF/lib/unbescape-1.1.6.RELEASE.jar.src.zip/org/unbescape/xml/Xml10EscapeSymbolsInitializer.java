/*     */ package org.unbescape.xml;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class Xml10EscapeSymbolsInitializer
/*     */ {
/*     */   static XmlEscapeSymbols initializeXml10(boolean attributes)
/*     */   {
/*  39 */     XmlEscapeSymbols.References xml10References = new XmlEscapeSymbols.References();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  47 */     xml10References.addReference(34, "&quot;");
/*  48 */     xml10References.addReference(38, "&amp;");
/*  49 */     xml10References.addReference(39, "&apos;");
/*  50 */     xml10References.addReference(60, "&lt;");
/*  51 */     xml10References.addReference(62, "&gt;");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  64 */     byte[] escapeLevels = new byte['¡'];
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  69 */     Arrays.fill(escapeLevels, (byte)3);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  74 */     for (char c = ''; c < '¡'; c = (char)(c + '\001')) {
/*  75 */       escapeLevels[c] = 2;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  81 */     for (char c = 'A'; c <= 'Z'; c = (char)(c + '\001')) {
/*  82 */       escapeLevels[c] = 4;
/*     */     }
/*  84 */     for (char c = 'a'; c <= 'z'; c = (char)(c + '\001')) {
/*  85 */       escapeLevels[c] = 4;
/*     */     }
/*  87 */     for (char c = '0'; c <= '9'; c = (char)(c + '\001')) {
/*  88 */       escapeLevels[c] = 4;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  94 */     escapeLevels[39] = 1;
/*  95 */     escapeLevels[34] = 1;
/*  96 */     escapeLevels[60] = 1;
/*  97 */     escapeLevels[62] = 1;
/*  98 */     escapeLevels[38] = 1;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 104 */     if (attributes) {
/* 105 */       escapeLevels[9] = 1;
/* 106 */       escapeLevels[10] = 1;
/* 107 */       escapeLevels[13] = 1;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 114 */     for (char c = ''; c <= ''; c = (char)(c + '\001')) {
/* 115 */       escapeLevels[c] = 1;
/*     */     }
/* 117 */     for (char c = ''; c <= ''; c = (char)(c + '\001')) {
/* 118 */       escapeLevels[c] = 1;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 124 */     return new XmlEscapeSymbols(xml10References, escapeLevels, new Xml10CodepointValidator());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static final class Xml10CodepointValidator
/*     */     implements XmlCodepointValidator
/*     */   {
/*     */     public boolean isValid(int codepoint)
/*     */     {
/* 143 */       if (codepoint < 32) {
/* 144 */         return (codepoint == 9) || (codepoint == 10) || (codepoint == 13);
/*     */       }
/* 146 */       if (codepoint <= 55295) {
/* 147 */         return true;
/*     */       }
/* 149 */       if (codepoint < 57344) {
/* 150 */         return false;
/*     */       }
/* 152 */       if (codepoint <= 65533) {
/* 153 */         return true;
/*     */       }
/* 155 */       if (codepoint < 65536) {
/* 156 */         return false;
/*     */       }
/* 158 */       return true;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\unbescape-1.1.6.RELEASE.jar!\org\unbescape\xml\Xml10EscapeSymbolsInitializer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */