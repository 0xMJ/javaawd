/*     */ package org.unbescape.xml;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class Xml11EscapeSymbolsInitializer
/*     */ {
/*     */   static XmlEscapeSymbols initializeXml11(boolean attributes)
/*     */   {
/*  39 */     XmlEscapeSymbols.References xml11References = new XmlEscapeSymbols.References();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  47 */     xml11References.addReference(34, "&quot;");
/*  48 */     xml11References.addReference(38, "&amp;");
/*  49 */     xml11References.addReference(39, "&apos;");
/*  50 */     xml11References.addReference(60, "&lt;");
/*  51 */     xml11References.addReference(62, "&gt;");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  66 */     byte[] escapeLevels = new byte['¡'];
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  71 */     Arrays.fill(escapeLevels, (byte)3);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  76 */     for (char c = ''; c < '¡'; c = (char)(c + '\001')) {
/*  77 */       escapeLevels[c] = 2;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  83 */     for (char c = 'A'; c <= 'Z'; c = (char)(c + '\001')) {
/*  84 */       escapeLevels[c] = 4;
/*     */     }
/*  86 */     for (char c = 'a'; c <= 'z'; c = (char)(c + '\001')) {
/*  87 */       escapeLevels[c] = 4;
/*     */     }
/*  89 */     for (char c = '0'; c <= '9'; c = (char)(c + '\001')) {
/*  90 */       escapeLevels[c] = 4;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  96 */     escapeLevels[39] = 1;
/*  97 */     escapeLevels[34] = 1;
/*  98 */     escapeLevels[60] = 1;
/*  99 */     escapeLevels[62] = 1;
/* 100 */     escapeLevels[38] = 1;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 106 */     if (attributes) {
/* 107 */       escapeLevels[9] = 1;
/* 108 */       escapeLevels[10] = 1;
/* 109 */       escapeLevels[13] = 1;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 116 */     for (char c = '\001'; c <= '\b'; c = (char)(c + '\001')) {
/* 117 */       escapeLevels[c] = 1;
/*     */     }
/* 119 */     escapeLevels[11] = 1;
/* 120 */     escapeLevels[12] = 1;
/* 121 */     for (char c = '\016'; c <= '\037'; c = (char)(c + '\001')) {
/* 122 */       escapeLevels[c] = 1;
/*     */     }
/* 124 */     for (char c = ''; c <= ''; c = (char)(c + '\001')) {
/* 125 */       escapeLevels[c] = 1;
/*     */     }
/* 127 */     for (char c = ''; c <= ''; c = (char)(c + '\001')) {
/* 128 */       escapeLevels[c] = 1;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 134 */     return new XmlEscapeSymbols(xml11References, escapeLevels, new Xml11CodepointValidator());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static final class Xml11CodepointValidator
/*     */     implements XmlCodepointValidator
/*     */   {
/*     */     public boolean isValid(int codepoint)
/*     */     {
/* 153 */       if (codepoint == 0) {
/* 154 */         return false;
/*     */       }
/* 156 */       if (codepoint <= 55295) {
/* 157 */         return true;
/*     */       }
/* 159 */       if (codepoint < 57344) {
/* 160 */         return false;
/*     */       }
/* 162 */       if (codepoint <= 65533) {
/* 163 */         return true;
/*     */       }
/* 165 */       if (codepoint < 65536) {
/* 166 */         return false;
/*     */       }
/* 168 */       return true;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\unbescape-1.1.6.RELEASE.jar!\org\unbescape\xml\Xml11EscapeSymbolsInitializer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */