/*      */ package org.unbescape.xml;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.Reader;
/*      */ import java.io.Writer;
/*      */ import java.util.Arrays;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ final class XmlEscapeUtil
/*      */ {
/*      */   private static final char REFERENCE_PREFIX = '&';
/*      */   private static final char REFERENCE_NUMERIC_PREFIX2 = '#';
/*      */   private static final char REFERENCE_HEXA_PREFIX3 = 'x';
/*   79 */   private static final char[] REFERENCE_DECIMAL_PREFIX = "&#".toCharArray();
/*   80 */   private static final char[] REFERENCE_HEXA_PREFIX = "&#x".toCharArray();
/*      */   
/*      */ 
/*      */ 
/*      */   private static final char REFERENCE_SUFFIX = ';';
/*      */   
/*      */ 
/*      */ 
/*   88 */   private static char[] HEXA_CHARS_UPPER = "0123456789ABCDEF".toCharArray();
/*   89 */   private static char[] HEXA_CHARS_LOWER = "0123456789abcdef".toCharArray();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static String escape(String text, XmlEscapeSymbols symbols, XmlEscapeType escapeType, XmlEscapeLevel escapeLevel)
/*      */   {
/*  108 */     if (text == null) {
/*  109 */       return null;
/*      */     }
/*      */     
/*  112 */     int level = escapeLevel.getEscapeLevel();
/*  113 */     boolean useCERs = escapeType.getUseCERs();
/*  114 */     boolean useHexa = escapeType.getUseHexa();
/*      */     
/*  116 */     StringBuilder strBuilder = null;
/*      */     
/*  118 */     int offset = 0;
/*  119 */     int max = text.length();
/*      */     
/*  121 */     int readOffset = 0;
/*      */     
/*  123 */     for (int i = 0; i < max; i++)
/*      */     {
/*  125 */       int codepoint = Character.codePointAt(text, i);
/*      */       
/*      */ 
/*  128 */       boolean codepointValid = symbols.CODEPOINT_VALIDATOR.isValid(codepoint);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  135 */       if ((codepoint > 159) || (level >= symbols.ESCAPE_LEVELS[codepoint]) || (!codepointValid))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  145 */         if ((codepoint > 159) && (level < symbols.ESCAPE_LEVELS[' ']) && (codepointValid))
/*      */         {
/*      */ 
/*      */ 
/*  149 */           if (Character.charCount(codepoint) > 1)
/*      */           {
/*  151 */             i++;
/*      */ 
/*      */ 
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*  165 */           if (strBuilder == null) {
/*  166 */             strBuilder = new StringBuilder(max + 20);
/*      */           }
/*      */           
/*  169 */           if (i - readOffset > 0) {
/*  170 */             strBuilder.append(text, readOffset, i);
/*      */           }
/*      */           
/*  173 */           if (Character.charCount(codepoint) > 1)
/*      */           {
/*  175 */             i++;
/*      */           }
/*      */           
/*  178 */           readOffset = i + 1;
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  185 */           if (codepointValid)
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  198 */             if (useCERs)
/*      */             {
/*      */ 
/*      */ 
/*  202 */               int codepointIndex = Arrays.binarySearch(symbols.SORTED_CODEPOINTS, codepoint);
/*      */               
/*  204 */               if (codepointIndex >= 0)
/*      */               {
/*  206 */                 strBuilder.append(symbols.SORTED_CERS_BY_CODEPOINT[codepointIndex]);
/*  207 */                 continue;
/*      */               }
/*      */             }
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  216 */             if (useHexa) {
/*  217 */               strBuilder.append(REFERENCE_HEXA_PREFIX);
/*  218 */               strBuilder.append(Integer.toHexString(codepoint));
/*      */             } else {
/*  220 */               strBuilder.append(REFERENCE_DECIMAL_PREFIX);
/*  221 */               strBuilder.append(String.valueOf(codepoint));
/*      */             }
/*  223 */             strBuilder.append(';');
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  235 */     if (strBuilder == null) {
/*  236 */       return text;
/*      */     }
/*      */     
/*  239 */     if (max - readOffset > 0) {
/*  240 */       strBuilder.append(text, readOffset, max);
/*      */     }
/*      */     
/*  243 */     return strBuilder.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static void escape(Reader reader, Writer writer, XmlEscapeSymbols symbols, XmlEscapeType escapeType, XmlEscapeLevel escapeLevel)
/*      */     throws IOException
/*      */   {
/*  263 */     if (reader == null) {
/*  264 */       return;
/*      */     }
/*      */     
/*  267 */     int level = escapeLevel.getEscapeLevel();
/*  268 */     boolean useCERs = escapeType.getUseCERs();
/*  269 */     boolean useHexa = escapeType.getUseHexa();
/*      */     
/*      */ 
/*      */ 
/*  273 */     int c2 = reader.read();
/*      */     
/*  275 */     while (c2 >= 0)
/*      */     {
/*  277 */       int c1 = c2;
/*  278 */       c2 = reader.read();
/*      */       
/*  280 */       int codepoint = codePointAt((char)c1, (char)c2);
/*      */       
/*      */ 
/*  283 */       boolean codepointValid = symbols.CODEPOINT_VALIDATOR.isValid(codepoint);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  290 */       if ((codepoint <= 159) && (level < symbols.ESCAPE_LEVELS[codepoint]) && (codepointValid))
/*      */       {
/*      */ 
/*  293 */         writer.write(c1);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/*  301 */       else if ((codepoint > 159) && (level < symbols.ESCAPE_LEVELS[' ']) && (codepointValid))
/*      */       {
/*      */ 
/*      */ 
/*  305 */         writer.write(c1);
/*      */         
/*  307 */         if (Character.charCount(codepoint) > 1)
/*      */         {
/*      */ 
/*  310 */           writer.write(c2);
/*      */           
/*  312 */           c1 = c2;
/*  313 */           c2 = reader.read();
/*      */ 
/*      */ 
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*  327 */         if (Character.charCount(codepoint) > 1)
/*      */         {
/*  329 */           c1 = c2;
/*  330 */           c2 = reader.read();
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  338 */         if (codepointValid)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  352 */           if (useCERs)
/*      */           {
/*      */ 
/*      */ 
/*  356 */             int codepointIndex = Arrays.binarySearch(symbols.SORTED_CODEPOINTS, codepoint);
/*      */             
/*  358 */             if (codepointIndex >= 0)
/*      */             {
/*  360 */               writer.write(symbols.SORTED_CERS_BY_CODEPOINT[codepointIndex]);
/*  361 */               continue;
/*      */             }
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  370 */           if (useHexa) {
/*  371 */             writer.write(REFERENCE_HEXA_PREFIX);
/*  372 */             writer.write(Integer.toHexString(codepoint));
/*      */           } else {
/*  374 */             writer.write(REFERENCE_DECIMAL_PREFIX);
/*  375 */             writer.write(String.valueOf(codepoint));
/*      */           }
/*  377 */           writer.write(59);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static void escape(char[] text, int offset, int len, Writer writer, XmlEscapeSymbols symbols, XmlEscapeType escapeType, XmlEscapeLevel escapeLevel)
/*      */     throws IOException
/*      */   {
/*  395 */     if ((text == null) || (text.length == 0)) {
/*  396 */       return;
/*      */     }
/*      */     
/*  399 */     int level = escapeLevel.getEscapeLevel();
/*  400 */     boolean useCERs = escapeType.getUseCERs();
/*  401 */     boolean useHexa = escapeType.getUseHexa();
/*      */     
/*  403 */     int max = offset + len;
/*      */     
/*  405 */     int readOffset = offset;
/*      */     
/*  407 */     for (int i = offset; i < max; i++)
/*      */     {
/*  409 */       int codepoint = Character.codePointAt(text, i);
/*      */       
/*      */ 
/*  412 */       boolean codepointValid = symbols.CODEPOINT_VALIDATOR.isValid(codepoint);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  419 */       if ((codepoint > 159) || (level >= symbols.ESCAPE_LEVELS[codepoint]) || (!codepointValid))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  429 */         if ((codepoint > 159) && (level < symbols.ESCAPE_LEVELS[' ']) && (codepointValid))
/*      */         {
/*      */ 
/*      */ 
/*  433 */           if (Character.charCount(codepoint) > 1)
/*      */           {
/*  435 */             i++;
/*      */ 
/*      */ 
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/*      */ 
/*      */ 
/*  448 */           if (i - readOffset > 0) {
/*  449 */             writer.write(text, readOffset, i - readOffset);
/*      */           }
/*      */           
/*  452 */           if (Character.charCount(codepoint) > 1)
/*      */           {
/*  454 */             i++;
/*      */           }
/*      */           
/*  457 */           readOffset = i + 1;
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  464 */           if (codepointValid)
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  477 */             if (useCERs)
/*      */             {
/*      */ 
/*      */ 
/*  481 */               int codepointIndex = Arrays.binarySearch(symbols.SORTED_CODEPOINTS, codepoint);
/*      */               
/*  483 */               if (codepointIndex >= 0)
/*      */               {
/*  485 */                 writer.write(symbols.SORTED_CERS_BY_CODEPOINT[codepointIndex]);
/*  486 */                 continue;
/*      */               }
/*      */             }
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  495 */             if (useHexa) {
/*  496 */               writer.write(REFERENCE_HEXA_PREFIX);
/*  497 */               writer.write(Integer.toHexString(codepoint));
/*      */             } else {
/*  499 */               writer.write(REFERENCE_DECIMAL_PREFIX);
/*  500 */               writer.write(String.valueOf(codepoint));
/*      */             }
/*  502 */             writer.write(59);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  513 */     if (max - readOffset > 0) {
/*  514 */       writer.write(text, readOffset, max - readOffset);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static int parseIntFromReference(String text, int start, int end, int radix)
/*      */   {
/*  533 */     int result = 0;
/*  534 */     for (int i = start; i < end; i++) {
/*  535 */       char c = text.charAt(i);
/*  536 */       int n = -1;
/*  537 */       for (int j = 0; j < HEXA_CHARS_UPPER.length; j++) {
/*  538 */         if ((c == HEXA_CHARS_UPPER[j]) || (c == HEXA_CHARS_LOWER[j])) {
/*  539 */           n = j;
/*  540 */           break;
/*      */         }
/*      */       }
/*  543 */       result = radix * result + n;
/*      */     }
/*  545 */     return result;
/*      */   }
/*      */   
/*      */   static int parseIntFromReference(char[] text, int start, int end, int radix) {
/*  549 */     int result = 0;
/*  550 */     for (int i = start; i < end; i++) {
/*  551 */       char c = text[i];
/*  552 */       int n = -1;
/*  553 */       for (int j = 0; j < HEXA_CHARS_UPPER.length; j++) {
/*  554 */         if ((c == HEXA_CHARS_UPPER[j]) || (c == HEXA_CHARS_LOWER[j])) {
/*  555 */           n = j;
/*  556 */           break;
/*      */         }
/*      */       }
/*  559 */       result = radix * result + n;
/*      */     }
/*  561 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static String unescape(String text, XmlEscapeSymbols symbols)
/*      */   {
/*  577 */     if (text == null) {
/*  578 */       return null;
/*      */     }
/*      */     
/*  581 */     StringBuilder strBuilder = null;
/*      */     
/*  583 */     int offset = 0;
/*  584 */     int max = text.length();
/*      */     
/*  586 */     int readOffset = 0;
/*  587 */     int referenceOffset = 0;
/*      */     
/*  589 */     for (int i = 0; i < max; i++)
/*      */     {
/*  591 */       char c = text.charAt(i);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  597 */       if ((c == '&') && (i + 1 < max))
/*      */       {
/*      */ 
/*      */ 
/*  601 */         int codepoint = 0;
/*      */         
/*  603 */         if (c == '&')
/*      */         {
/*  605 */           char c1 = text.charAt(i + 1);
/*      */           
/*  607 */           if ((c1 == ' ') || (c1 == '\n') || (c1 == '\t') || (c1 == '\f') || (c1 == '<') || (c1 == '&')) {
/*      */             continue;
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  616 */           if (c1 == '#')
/*      */           {
/*  618 */             if (i + 2 >= max) {
/*      */               continue;
/*      */             }
/*      */             
/*      */ 
/*  623 */             char c2 = text.charAt(i + 2);
/*      */             
/*  625 */             if ((c2 == 'x') && (i + 3 < max))
/*      */             {
/*      */ 
/*  628 */               int f = i + 3;
/*  629 */               while (f < max) {
/*  630 */                 char cf = text.charAt(f);
/*  631 */                 if (((cf < '0') || (cf > '9')) && ((cf < 'A') || (cf > 'F')) && ((cf < 'a') || (cf > 'f'))) {
/*      */                   break;
/*      */                 }
/*  634 */                 f++;
/*      */               }
/*      */               
/*  637 */               if (f - (i + 3) <= 0) {
/*      */                 continue;
/*      */               }
/*      */               
/*      */ 
/*  642 */               if ((f >= max) || (text.charAt(f) != ';')) {
/*      */                 continue;
/*      */               }
/*      */               
/*  646 */               f++;
/*      */               
/*  648 */               codepoint = parseIntFromReference(text, i + 3, f - 1, 16);
/*  649 */               referenceOffset = f - 1;
/*      */             }
/*      */             else
/*      */             {
/*  653 */               if ((c2 < '0') || (c2 > '9')) {
/*      */                 continue;
/*      */               }
/*  656 */               int f = i + 2;
/*  657 */               while (f < max) {
/*  658 */                 char cf = text.charAt(f);
/*  659 */                 if ((cf < '0') || (cf > '9')) {
/*      */                   break;
/*      */                 }
/*  662 */                 f++;
/*      */               }
/*      */               
/*  665 */               if (f - (i + 2) <= 0) {
/*      */                 continue;
/*      */               }
/*      */               
/*      */ 
/*  670 */               if ((f >= max) || (text.charAt(f) != ';')) {
/*      */                 continue;
/*      */               }
/*      */               
/*  674 */               f++;
/*      */               
/*  676 */               codepoint = parseIntFromReference(text, i + 2, f - 1, 10);
/*  677 */               referenceOffset = f - 1;
/*      */ 
/*      */ 
/*      */             }
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */           }
/*      */           else
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*  691 */             int f = i + 1;
/*  692 */             while (f < max) {
/*  693 */               char cf = text.charAt(f);
/*  694 */               if (((cf < 'a') || (cf > 'z')) && ((cf < 'A') || (cf > 'Z')) && ((cf < '0') || (cf > '9'))) {
/*      */                 break;
/*      */               }
/*  697 */               f++;
/*      */             }
/*      */             
/*  700 */             if (f - (i + 1) <= 0) {
/*      */               continue;
/*      */             }
/*      */             
/*      */ 
/*  705 */             if ((f < max) && (text.charAt(f) == ';')) {
/*  706 */               f++;
/*      */             }
/*      */             
/*  709 */             int ncrPosition = XmlEscapeSymbols.binarySearch(symbols.SORTED_CERS, text, i, f);
/*  710 */             if (ncrPosition < 0) continue;
/*  711 */             codepoint = symbols.SORTED_CODEPOINTS_BY_CER[ncrPosition];
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  717 */             referenceOffset = f - 1;
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  730 */         if (strBuilder == null) {
/*  731 */           strBuilder = new StringBuilder(max + 5);
/*      */         }
/*      */         
/*  734 */         if (i - readOffset > 0) {
/*  735 */           strBuilder.append(text, readOffset, i);
/*      */         }
/*      */         
/*  738 */         i = referenceOffset;
/*  739 */         readOffset = i + 1;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  749 */         if (codepoint > 65535) {
/*  750 */           strBuilder.append(Character.toChars(codepoint));
/*      */         } else {
/*  752 */           strBuilder.append((char)codepoint);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  765 */     if (strBuilder == null) {
/*  766 */       return text;
/*      */     }
/*      */     
/*  769 */     if (max - readOffset > 0) {
/*  770 */       strBuilder.append(text, readOffset, max);
/*      */     }
/*      */     
/*  773 */     return strBuilder.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static void unescape(Reader reader, Writer writer, XmlEscapeSymbols symbols)
/*      */     throws IOException
/*      */   {
/*  790 */     if (reader == null) {
/*  791 */       return;
/*      */     }
/*      */     
/*  794 */     char[] escapes = new char[10];
/*  795 */     int escapei = 0;
/*      */     
/*      */ 
/*      */ 
/*  799 */     int c2 = reader.read();
/*      */     
/*  801 */     while (c2 >= 0)
/*      */     {
/*  803 */       int c1 = c2;
/*  804 */       c2 = reader.read();
/*      */       
/*  806 */       escapei = 0;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  812 */       if ((c1 != 38) || (c2 < 0)) {
/*  813 */         writer.write(c1);
/*      */       }
/*      */       else
/*      */       {
/*  817 */         int codepoint = 0;
/*      */         
/*  819 */         if (c1 == 38)
/*      */         {
/*  821 */           if ((c2 == 32) || (c2 == 10) || (c2 == 9) || (c2 == 12) || (c2 == 60) || (c2 == 38))
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  828 */             writer.write(c1);
/*  829 */             continue;
/*      */           }
/*  831 */           if (c2 == 35)
/*      */           {
/*  833 */             int c3 = reader.read();
/*      */             
/*  835 */             if (c3 < 0)
/*      */             {
/*  837 */               writer.write(c1);
/*  838 */               writer.write(c2);
/*  839 */               c1 = c2;
/*  840 */               c2 = c3;
/*  841 */               continue;
/*      */             }
/*      */             
/*  844 */             if (c3 == 120)
/*      */             {
/*      */ 
/*  847 */               int ce = reader.read();
/*  848 */               while ((ce >= 0) && (
/*  849 */                 ((ce >= 48) && (ce <= 57)) || ((ce >= 65) && (ce <= 70)) || ((ce >= 97) && (ce <= 102))))
/*      */               {
/*      */ 
/*  852 */                 if (escapei == escapes.length)
/*      */                 {
/*  854 */                   char[] newEscapes = new char[escapes.length + 4];
/*  855 */                   System.arraycopy(escapes, 0, newEscapes, 0, escapes.length);
/*  856 */                   escapes = newEscapes;
/*      */                 }
/*  858 */                 escapes[escapei] = ((char)ce);
/*  859 */                 ce = reader.read();
/*  860 */                 escapei++;
/*      */               }
/*      */               
/*  863 */               if (escapei == 0)
/*      */               {
/*  865 */                 writer.write(c1);
/*  866 */                 writer.write(c2);
/*  867 */                 writer.write(c3);
/*  868 */                 c1 = c3;
/*  869 */                 c2 = ce;
/*  870 */                 continue;
/*      */               }
/*      */               
/*  873 */               if (ce != 59)
/*      */               {
/*  875 */                 writer.write(c1);
/*  876 */                 writer.write(c2);
/*  877 */                 writer.write(c3);
/*  878 */                 writer.write(escapes, 0, escapei);
/*  879 */                 c1 = escapes[(escapei - 1)];
/*  880 */                 c2 = ce;
/*  881 */                 continue;
/*      */               }
/*      */               
/*  884 */               c1 = ce;
/*  885 */               c2 = reader.read();
/*      */               
/*  887 */               codepoint = parseIntFromReference(escapes, 0, escapei, 16);
/*      */ 
/*      */ 
/*      */             }
/*  891 */             else if ((c3 >= 48) && (c3 <= 57))
/*      */             {
/*      */ 
/*  894 */               int ce = c3;
/*  895 */               while ((ce >= 0) && 
/*  896 */                 (ce >= 48) && (ce <= 57))
/*      */               {
/*      */ 
/*  899 */                 if (escapei == escapes.length)
/*      */                 {
/*  901 */                   char[] newEscapes = new char[escapes.length + 4];
/*  902 */                   System.arraycopy(escapes, 0, newEscapes, 0, escapes.length);
/*  903 */                   escapes = newEscapes;
/*      */                 }
/*  905 */                 escapes[escapei] = ((char)ce);
/*  906 */                 ce = reader.read();
/*  907 */                 escapei++;
/*      */               }
/*      */               
/*  910 */               if (escapei == 0)
/*      */               {
/*  912 */                 writer.write(c1);
/*  913 */                 writer.write(c2);
/*  914 */                 c1 = c2;
/*  915 */                 c2 = c3;
/*  916 */                 continue;
/*      */               }
/*      */               
/*  919 */               if (ce != 59)
/*      */               {
/*  921 */                 writer.write(c1);
/*  922 */                 writer.write(c2);
/*  923 */                 writer.write(escapes, 0, escapei);
/*  924 */                 c1 = escapes[(escapei - 1)];
/*  925 */                 c2 = ce;
/*  926 */                 continue;
/*      */               }
/*      */               
/*  929 */               c1 = ce;
/*  930 */               c2 = reader.read();
/*      */               
/*  932 */               codepoint = parseIntFromReference(escapes, 0, escapei, 10);
/*      */ 
/*      */             }
/*      */             else
/*      */             {
/*      */ 
/*  938 */               writer.write(c1);
/*  939 */               writer.write(c2);
/*  940 */               c1 = c2;
/*  941 */               c2 = c3;
/*  942 */               continue;
/*      */             }
/*      */             
/*      */ 
/*      */             int ce;
/*      */           }
/*      */           else
/*      */           {
/*  950 */             int ce = c2;
/*  951 */             while ((ce >= 0) && (
/*  952 */               ((ce >= 48) && (ce <= 57)) || ((ce >= 65) && (ce <= 90)) || ((ce >= 97) && (ce <= 122))))
/*      */             {
/*      */ 
/*  955 */               if (escapei == escapes.length)
/*      */               {
/*  957 */                 char[] newEscapes = new char[escapes.length + 4];
/*  958 */                 System.arraycopy(escapes, 0, newEscapes, 0, escapes.length);
/*  959 */                 escapes = newEscapes;
/*      */               }
/*  961 */               escapes[escapei] = ((char)ce);
/*  962 */               ce = reader.read();
/*  963 */               escapei++;
/*      */             }
/*      */             
/*  966 */             if (escapei == 0)
/*      */             {
/*  968 */               writer.write(c1);
/*  969 */               continue;
/*      */             }
/*      */             
/*  972 */             if (escapei + 2 >= escapes.length)
/*      */             {
/*  974 */               char[] newEscapes = new char[escapes.length + 4];
/*  975 */               System.arraycopy(escapes, 0, newEscapes, 0, escapes.length);
/*  976 */               escapes = newEscapes;
/*      */             }
/*      */             
/*  979 */             System.arraycopy(escapes, 0, escapes, 1, escapei);
/*  980 */             escapes[0] = ((char)c1);
/*  981 */             escapei++;
/*      */             
/*  983 */             if (ce == 59)
/*      */             {
/*  985 */               escapes[(escapei++)] = ((char)ce);
/*  986 */               ce = reader.read();
/*      */             }
/*      */             
/*  989 */             c1 = escapes[(escapei - 1)];
/*  990 */             c2 = ce;
/*      */             
/*  992 */             int ncrPosition = XmlEscapeSymbols.binarySearch(symbols.SORTED_CERS, escapes, 0, escapei);
/*  993 */             if (ncrPosition >= 0) {
/*  994 */               codepoint = symbols.SORTED_CODEPOINTS_BY_CER[ncrPosition];
/*      */             }
/*      */             else {
/*  997 */               writer.write(escapes, 0, escapei);
/*  998 */               continue;
/*      */             }
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1013 */         if (codepoint > 65535) {
/* 1014 */           writer.write(Character.toChars(codepoint));
/*      */         } else {
/* 1016 */           writer.write((char)codepoint);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static void unescape(char[] text, int offset, int len, Writer writer, XmlEscapeSymbols symbols)
/*      */     throws IOException
/*      */   {
/* 1035 */     if (text == null) {
/* 1036 */       return;
/*      */     }
/*      */     
/* 1039 */     int max = offset + len;
/*      */     
/* 1041 */     int readOffset = offset;
/* 1042 */     int referenceOffset = offset;
/*      */     
/* 1044 */     for (int i = offset; i < max; i++)
/*      */     {
/* 1046 */       char c = text[i];
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1052 */       if ((c == '&') && (i + 1 < max))
/*      */       {
/*      */ 
/*      */ 
/* 1056 */         int codepoint = 0;
/*      */         
/* 1058 */         if (c == '&')
/*      */         {
/* 1060 */           char c1 = text[(i + 1)];
/*      */           
/* 1062 */           if ((c1 == ' ') || (c1 == '\n') || (c1 == '\t') || (c1 == '\f') || (c1 == '<') || (c1 == '&')) {
/*      */             continue;
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1071 */           if (c1 == '#')
/*      */           {
/* 1073 */             if (i + 2 >= max) {
/*      */               continue;
/*      */             }
/*      */             
/*      */ 
/* 1078 */             char c2 = text[(i + 2)];
/*      */             
/* 1080 */             if ((c2 == 'x') && (i + 3 < max))
/*      */             {
/*      */ 
/* 1083 */               int f = i + 3;
/* 1084 */               while (f < max) {
/* 1085 */                 char cf = text[f];
/* 1086 */                 if (((cf < '0') || (cf > '9')) && ((cf < 'A') || (cf > 'F')) && ((cf < 'a') || (cf > 'f'))) {
/*      */                   break;
/*      */                 }
/* 1089 */                 f++;
/*      */               }
/*      */               
/* 1092 */               if (f - (i + 3) <= 0) {
/*      */                 continue;
/*      */               }
/*      */               
/*      */ 
/* 1097 */               if ((f >= max) || (text[f] != ';')) {
/*      */                 continue;
/*      */               }
/*      */               
/* 1101 */               f++;
/*      */               
/* 1103 */               codepoint = parseIntFromReference(text, i + 3, f - 1, 16);
/* 1104 */               referenceOffset = f - 1;
/*      */             }
/*      */             else
/*      */             {
/* 1108 */               if ((c2 < '0') || (c2 > '9')) {
/*      */                 continue;
/*      */               }
/* 1111 */               int f = i + 2;
/* 1112 */               while (f < max) {
/* 1113 */                 char cf = text[f];
/* 1114 */                 if ((cf < '0') || (cf > '9')) {
/*      */                   break;
/*      */                 }
/* 1117 */                 f++;
/*      */               }
/*      */               
/* 1120 */               if (f - (i + 2) <= 0) {
/*      */                 continue;
/*      */               }
/*      */               
/*      */ 
/* 1125 */               if ((f >= max) || (text[f] != ';')) {
/*      */                 continue;
/*      */               }
/*      */               
/* 1129 */               f++;
/*      */               
/* 1131 */               codepoint = parseIntFromReference(text, i + 2, f - 1, 10);
/* 1132 */               referenceOffset = f - 1;
/*      */ 
/*      */ 
/*      */             }
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */           }
/*      */           else
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/* 1146 */             int f = i + 1;
/* 1147 */             while (f < max) {
/* 1148 */               char cf = text[f];
/* 1149 */               if (((cf < 'a') || (cf > 'z')) && ((cf < 'A') || (cf > 'Z')) && ((cf < '0') || (cf > '9'))) {
/*      */                 break;
/*      */               }
/* 1152 */               f++;
/*      */             }
/*      */             
/* 1155 */             if (f - (i + 1) <= 0) {
/*      */               continue;
/*      */             }
/*      */             
/*      */ 
/* 1160 */             if ((f < max) && (text[f] == ';')) {
/* 1161 */               f++;
/*      */             }
/*      */             
/* 1164 */             int ncrPosition = XmlEscapeSymbols.binarySearch(symbols.SORTED_CERS, text, i, f);
/* 1165 */             if (ncrPosition < 0) continue;
/* 1166 */             codepoint = symbols.SORTED_CODEPOINTS_BY_CER[ncrPosition];
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1172 */             referenceOffset = f - 1;
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1184 */         if (i - readOffset > 0) {
/* 1185 */           writer.write(text, readOffset, i - readOffset);
/*      */         }
/*      */         
/* 1188 */         i = referenceOffset;
/* 1189 */         readOffset = i + 1;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1199 */         if (codepoint > 65535) {
/* 1200 */           writer.write(Character.toChars(codepoint));
/*      */         } else {
/* 1202 */           writer.write((char)codepoint);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1214 */     if (max - readOffset > 0) {
/* 1215 */       writer.write(text, readOffset, max - readOffset);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private static int codePointAt(char c1, char c2)
/*      */   {
/* 1224 */     if ((Character.isHighSurrogate(c1)) && 
/* 1225 */       (c2 >= 0) && 
/* 1226 */       (Character.isLowSurrogate(c2))) {
/* 1227 */       return Character.toCodePoint(c1, c2);
/*      */     }
/*      */     
/*      */ 
/* 1231 */     return c1;
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\unbescape-1.1.6.RELEASE.jar!\org\unbescape\xml\XmlEscapeUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */