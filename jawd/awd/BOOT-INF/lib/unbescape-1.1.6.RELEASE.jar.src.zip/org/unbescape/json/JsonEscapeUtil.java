/*      */ package org.unbescape.json;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.Reader;
/*      */ import java.io.Writer;
/*      */ import java.util.Arrays;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ final class JsonEscapeUtil
/*      */ {
/*      */   private static final char ESCAPE_PREFIX = '\\';
/*      */   private static final char ESCAPE_UHEXA_PREFIX2 = 'u';
/*   82 */   private static final char[] ESCAPE_UHEXA_PREFIX = "\\u".toCharArray();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*   87 */   private static char[] HEXA_CHARS_UPPER = "0123456789ABCDEF".toCharArray();
/*   88 */   private static char[] HEXA_CHARS_LOWER = "0123456789abcdef".toCharArray();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   94 */   private static int SEC_CHARS_LEN = 93;
/*   95 */   private static char SEC_CHARS_NO_SEC = '*';
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  113 */   private static char[] SEC_CHARS = new char[SEC_CHARS_LEN];
/*  114 */   static { Arrays.fill(SEC_CHARS, SEC_CHARS_NO_SEC);
/*  115 */     SEC_CHARS[8] = 'b';
/*  116 */     SEC_CHARS[9] = 't';
/*  117 */     SEC_CHARS[10] = 'n';
/*  118 */     SEC_CHARS[12] = 'f';
/*  119 */     SEC_CHARS[13] = 'r';
/*  120 */     SEC_CHARS[34] = '"';
/*  121 */     SEC_CHARS[92] = '\\';
/*      */     
/*  123 */     SEC_CHARS[47] = '/';
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  137 */     ESCAPE_LEVELS = new byte['¡'];
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  142 */     Arrays.fill(ESCAPE_LEVELS, (byte)3);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  147 */     for (char c = ''; c < '¡'; c = (char)(c + '\001')) {
/*  148 */       ESCAPE_LEVELS[c] = 2;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  154 */     for (char c = 'A'; c <= 'Z'; c = (char)(c + '\001')) {
/*  155 */       ESCAPE_LEVELS[c] = 4;
/*      */     }
/*  157 */     for (char c = 'a'; c <= 'z'; c = (char)(c + '\001')) {
/*  158 */       ESCAPE_LEVELS[c] = 4;
/*      */     }
/*  160 */     for (char c = '0'; c <= '9'; c = (char)(c + '\001')) {
/*  161 */       ESCAPE_LEVELS[c] = 4;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  167 */     ESCAPE_LEVELS[8] = 1;
/*  168 */     ESCAPE_LEVELS[9] = 1;
/*  169 */     ESCAPE_LEVELS[10] = 1;
/*  170 */     ESCAPE_LEVELS[12] = 1;
/*  171 */     ESCAPE_LEVELS[13] = 1;
/*  172 */     ESCAPE_LEVELS[34] = 1;
/*  173 */     ESCAPE_LEVELS[92] = 1;
/*      */     
/*  175 */     ESCAPE_LEVELS[47] = 1;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  180 */     ESCAPE_LEVELS[38] = 1;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  186 */     for (char c = '\000'; c <= '\037'; c = (char)(c + '\001')) {
/*  187 */       ESCAPE_LEVELS[c] = 1;
/*      */     }
/*  189 */     for (char c = ''; c <= ''; c = (char)(c + '\001')) {
/*  190 */       ESCAPE_LEVELS[c] = 1;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static char[] toUHexa(int codepoint)
/*      */   {
/*  205 */     char[] result = new char[4];
/*  206 */     result[3] = HEXA_CHARS_UPPER[(codepoint % 16)];
/*  207 */     result[2] = HEXA_CHARS_UPPER[((codepoint >>> 4) % 16)];
/*  208 */     result[1] = HEXA_CHARS_UPPER[((codepoint >>> 8) % 16)];
/*  209 */     result[0] = HEXA_CHARS_UPPER[((codepoint >>> 12) % 16)];
/*  210 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static String escape(String text, JsonEscapeType escapeType, JsonEscapeLevel escapeLevel)
/*      */   {
/*  220 */     if (text == null) {
/*  221 */       return null;
/*      */     }
/*      */     
/*  224 */     int level = escapeLevel.getEscapeLevel();
/*  225 */     boolean useSECs = escapeType.getUseSECs();
/*      */     
/*  227 */     StringBuilder strBuilder = null;
/*      */     
/*  229 */     int offset = 0;
/*  230 */     int max = text.length();
/*      */     
/*  232 */     int readOffset = 0;
/*      */     
/*  234 */     for (int i = 0; i < max; i++)
/*      */     {
/*  236 */       int codepoint = Character.codePointAt(text, i);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  243 */       if ((codepoint > 159) || (level >= ESCAPE_LEVELS[codepoint]))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  251 */         if ((codepoint != 47) || (level >= 3) || ((i != 0) && (text.charAt(i - 1) == '<')))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  258 */           if ((codepoint > 159) && (level < ESCAPE_LEVELS[' ']))
/*      */           {
/*  260 */             if (Character.charCount(codepoint) > 1)
/*      */             {
/*  262 */               i++;
/*      */ 
/*      */ 
/*      */             }
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */           }
/*      */           else
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*  276 */             if (strBuilder == null) {
/*  277 */               strBuilder = new StringBuilder(max + 20);
/*      */             }
/*      */             
/*  280 */             if (i - readOffset > 0) {
/*  281 */               strBuilder.append(text, readOffset, i);
/*      */             }
/*      */             
/*  284 */             if (Character.charCount(codepoint) > 1)
/*      */             {
/*  286 */               i++;
/*      */             }
/*      */             
/*  289 */             readOffset = i + 1;
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  300 */             if ((useSECs) && (codepoint < SEC_CHARS_LEN))
/*      */             {
/*      */ 
/*  303 */               char sec = SEC_CHARS[codepoint];
/*      */               
/*  305 */               if (sec != SEC_CHARS_NO_SEC)
/*      */               {
/*  307 */                 strBuilder.append('\\');
/*  308 */                 strBuilder.append(sec);
/*  309 */                 continue;
/*      */               }
/*      */             }
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  318 */             if (Character.charCount(codepoint) > 1) {
/*  319 */               char[] codepointChars = Character.toChars(codepoint);
/*  320 */               strBuilder.append(ESCAPE_UHEXA_PREFIX);
/*  321 */               strBuilder.append(toUHexa(codepointChars[0]));
/*  322 */               strBuilder.append(ESCAPE_UHEXA_PREFIX);
/*  323 */               strBuilder.append(toUHexa(codepointChars[1]));
/*      */             }
/*      */             else
/*      */             {
/*  327 */               strBuilder.append(ESCAPE_UHEXA_PREFIX);
/*  328 */               strBuilder.append(toUHexa(codepoint));
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  340 */     if (strBuilder == null) {
/*  341 */       return text;
/*      */     }
/*      */     
/*  344 */     if (max - readOffset > 0) {
/*  345 */       strBuilder.append(text, readOffset, max);
/*      */     }
/*      */     
/*  348 */     return strBuilder.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final char ESCAPE_LEVELS_LEN = '¡';
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static void escape(Reader reader, Writer writer, JsonEscapeType escapeType, JsonEscapeLevel escapeLevel)
/*      */     throws IOException
/*      */   {
/*  365 */     if (reader == null) {
/*  366 */       return;
/*      */     }
/*      */     
/*  369 */     int level = escapeLevel.getEscapeLevel();
/*  370 */     boolean useSECs = escapeType.getUseSECs();
/*      */     
/*      */ 
/*      */ 
/*  374 */     int c1 = -1;
/*  375 */     int c2 = reader.read();
/*      */     
/*  377 */     while (c2 >= 0)
/*      */     {
/*  379 */       int c0 = c1;
/*  380 */       c1 = c2;
/*  381 */       c2 = reader.read();
/*      */       
/*  383 */       int codepoint = codePointAt((char)c1, (char)c2);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  389 */       if ((codepoint <= 159) && (level < ESCAPE_LEVELS[codepoint])) {
/*  390 */         writer.write(c1);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/*  398 */       else if ((codepoint == 47) && (level < 3) && (c0 != 60)) {
/*  399 */         writer.write(c1);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/*  406 */       else if ((codepoint > 159) && (level < ESCAPE_LEVELS[' ']))
/*      */       {
/*  408 */         writer.write(c1);
/*      */         
/*  410 */         if (Character.charCount(codepoint) > 1)
/*      */         {
/*      */ 
/*  413 */           writer.write(c2);
/*      */           
/*  415 */           c0 = c1;
/*  416 */           c1 = c2;
/*  417 */           c2 = reader.read();
/*      */ 
/*      */ 
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*  431 */         if (Character.charCount(codepoint) > 1)
/*      */         {
/*  433 */           c0 = c1;
/*  434 */           c1 = c2;
/*  435 */           c2 = reader.read();
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  447 */         if ((useSECs) && (codepoint < SEC_CHARS_LEN))
/*      */         {
/*      */ 
/*  450 */           char sec = SEC_CHARS[codepoint];
/*      */           
/*  452 */           if (sec != SEC_CHARS_NO_SEC)
/*      */           {
/*  454 */             writer.write(92);
/*  455 */             writer.write(sec);
/*  456 */             continue;
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  465 */         if (Character.charCount(codepoint) > 1) {
/*  466 */           char[] codepointChars = Character.toChars(codepoint);
/*  467 */           writer.write(ESCAPE_UHEXA_PREFIX);
/*  468 */           writer.write(toUHexa(codepointChars[0]));
/*  469 */           writer.write(ESCAPE_UHEXA_PREFIX);
/*  470 */           writer.write(toUHexa(codepointChars[1]));
/*      */         }
/*      */         else
/*      */         {
/*  474 */           writer.write(ESCAPE_UHEXA_PREFIX);
/*  475 */           writer.write(toUHexa(codepoint));
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static void escape(char[] text, int offset, int len, Writer writer, JsonEscapeType escapeType, JsonEscapeLevel escapeLevel)
/*      */     throws IOException
/*      */   {
/*  493 */     if ((text == null) || (text.length == 0)) {
/*  494 */       return;
/*      */     }
/*      */     
/*  497 */     int level = escapeLevel.getEscapeLevel();
/*  498 */     boolean useSECs = escapeType.getUseSECs();
/*      */     
/*  500 */     int max = offset + len;
/*      */     
/*  502 */     int readOffset = offset;
/*      */     
/*  504 */     for (int i = offset; i < max; i++)
/*      */     {
/*  506 */       int codepoint = Character.codePointAt(text, i);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  513 */       if ((codepoint > 159) || (level >= ESCAPE_LEVELS[codepoint]))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  521 */         if ((codepoint != 47) || (level >= 3) || ((i != offset) && (text[(i - 1)] == '<')))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  528 */           if ((codepoint > 159) && (level < ESCAPE_LEVELS[' ']))
/*      */           {
/*  530 */             if (Character.charCount(codepoint) > 1)
/*      */             {
/*  532 */               i++;
/*      */ 
/*      */ 
/*      */             }
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */           }
/*      */           else
/*      */           {
/*      */ 
/*      */ 
/*  545 */             if (i - readOffset > 0) {
/*  546 */               writer.write(text, readOffset, i - readOffset);
/*      */             }
/*      */             
/*  549 */             if (Character.charCount(codepoint) > 1)
/*      */             {
/*  551 */               i++;
/*      */             }
/*      */             
/*  554 */             readOffset = i + 1;
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  565 */             if ((useSECs) && (codepoint < SEC_CHARS_LEN))
/*      */             {
/*      */ 
/*  568 */               char sec = SEC_CHARS[codepoint];
/*      */               
/*  570 */               if (sec != SEC_CHARS_NO_SEC)
/*      */               {
/*  572 */                 writer.write(92);
/*  573 */                 writer.write(sec);
/*  574 */                 continue;
/*      */               }
/*      */             }
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  583 */             if (Character.charCount(codepoint) > 1) {
/*  584 */               char[] codepointChars = Character.toChars(codepoint);
/*  585 */               writer.write(ESCAPE_UHEXA_PREFIX);
/*  586 */               writer.write(toUHexa(codepointChars[0]));
/*  587 */               writer.write(ESCAPE_UHEXA_PREFIX);
/*  588 */               writer.write(toUHexa(codepointChars[1]));
/*      */             }
/*      */             else
/*      */             {
/*  592 */               writer.write(ESCAPE_UHEXA_PREFIX);
/*  593 */               writer.write(toUHexa(codepoint));
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  605 */     if (max - readOffset > 0) {
/*  606 */       writer.write(text, readOffset, max - readOffset);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final byte[] ESCAPE_LEVELS;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static int parseIntFromReference(String text, int start, int end, int radix)
/*      */   {
/*  625 */     int result = 0;
/*  626 */     for (int i = start; i < end; i++) {
/*  627 */       char c = text.charAt(i);
/*  628 */       int n = -1;
/*  629 */       for (int j = 0; j < HEXA_CHARS_UPPER.length; j++) {
/*  630 */         if ((c == HEXA_CHARS_UPPER[j]) || (c == HEXA_CHARS_LOWER[j])) {
/*  631 */           n = j;
/*  632 */           break;
/*      */         }
/*      */       }
/*  635 */       result = radix * result + n;
/*      */     }
/*  637 */     return result;
/*      */   }
/*      */   
/*      */   static int parseIntFromReference(char[] text, int start, int end, int radix) {
/*  641 */     int result = 0;
/*  642 */     for (int i = start; i < end; i++) {
/*  643 */       char c = text[i];
/*  644 */       int n = -1;
/*  645 */       for (int j = 0; j < HEXA_CHARS_UPPER.length; j++) {
/*  646 */         if ((c == HEXA_CHARS_UPPER[j]) || (c == HEXA_CHARS_LOWER[j])) {
/*  647 */           n = j;
/*  648 */           break;
/*      */         }
/*      */       }
/*  651 */       result = radix * result + n;
/*      */     }
/*  653 */     return result;
/*      */   }
/*      */   
/*      */   static int parseIntFromReference(int[] text, int start, int end, int radix) {
/*  657 */     int result = 0;
/*  658 */     for (int i = start; i < end; i++) {
/*  659 */       char c = (char)text[i];
/*  660 */       int n = -1;
/*  661 */       for (int j = 0; j < HEXA_CHARS_UPPER.length; j++) {
/*  662 */         if ((c == HEXA_CHARS_UPPER[j]) || (c == HEXA_CHARS_LOWER[j])) {
/*  663 */           n = j;
/*  664 */           break;
/*      */         }
/*      */       }
/*  667 */       result = radix * result + n;
/*      */     }
/*  669 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static String unescape(String text)
/*      */   {
/*  681 */     if (text == null) {
/*  682 */       return null;
/*      */     }
/*      */     
/*  685 */     StringBuilder strBuilder = null;
/*      */     
/*  687 */     int offset = 0;
/*  688 */     int max = text.length();
/*      */     
/*  690 */     int readOffset = 0;
/*  691 */     int referenceOffset = 0;
/*      */     
/*  693 */     for (int i = 0; i < max; i++)
/*      */     {
/*  695 */       char c = text.charAt(i);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  701 */       if ((c == '\\') && (i + 1 < max))
/*      */       {
/*      */ 
/*      */ 
/*  705 */         int codepoint = -1;
/*      */         
/*  707 */         if (c == '\\')
/*      */         {
/*  709 */           char c1 = text.charAt(i + 1);
/*      */           
/*  711 */           switch (c1) {
/*  712 */           case 'b':  codepoint = 8;referenceOffset = i + 1; break;
/*  713 */           case 't':  codepoint = 9;referenceOffset = i + 1; break;
/*  714 */           case 'n':  codepoint = 10;referenceOffset = i + 1; break;
/*  715 */           case 'f':  codepoint = 12;referenceOffset = i + 1; break;
/*  716 */           case 'r':  codepoint = 13;referenceOffset = i + 1; break;
/*  717 */           case '"':  codepoint = 34;referenceOffset = i + 1; break;
/*  718 */           case '\\':  codepoint = 92;referenceOffset = i + 1; break;
/*  719 */           case '/':  codepoint = 47;referenceOffset = i + 1;
/*      */           }
/*      */           
/*  722 */           if (codepoint == -1)
/*      */           {
/*  724 */             if (c1 == 'u')
/*      */             {
/*      */ 
/*  727 */               int f = i + 2;
/*  728 */               while ((f < i + 6) && (f < max)) {
/*  729 */                 char cf = text.charAt(f);
/*  730 */                 if (((cf < '0') || (cf > '9')) && ((cf < 'A') || (cf > 'F')) && ((cf < 'a') || (cf > 'f'))) {
/*      */                   break;
/*      */                 }
/*  733 */                 f++;
/*      */               }
/*      */               
/*  736 */               if (f - (i + 2) < 4)
/*      */               {
/*      */ 
/*  739 */                 i++;
/*  740 */                 continue;
/*      */               }
/*      */               
/*  743 */               codepoint = parseIntFromReference(text, i + 2, f, 16);
/*      */               
/*      */ 
/*  746 */               referenceOffset = f - 1;
/*      */ 
/*      */ 
/*      */             }
/*      */             else
/*      */             {
/*      */ 
/*      */ 
/*  754 */               i++;
/*  755 */               continue;
/*      */             }
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  770 */         if (strBuilder == null) {
/*  771 */           strBuilder = new StringBuilder(max + 5);
/*      */         }
/*      */         
/*  774 */         if (i - readOffset > 0) {
/*  775 */           strBuilder.append(text, readOffset, i);
/*      */         }
/*      */         
/*  778 */         i = referenceOffset;
/*  779 */         readOffset = i + 1;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  789 */         if (codepoint > 65535) {
/*  790 */           strBuilder.append(Character.toChars(codepoint));
/*      */         } else {
/*  792 */           strBuilder.append((char)codepoint);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  805 */     if (strBuilder == null) {
/*  806 */       return text;
/*      */     }
/*      */     
/*  809 */     if (max - readOffset > 0) {
/*  810 */       strBuilder.append(text, readOffset, max);
/*      */     }
/*      */     
/*  813 */     return strBuilder.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static void unescape(Reader reader, Writer writer)
/*      */     throws IOException
/*      */   {
/*  829 */     if (reader == null) {
/*  830 */       return;
/*      */     }
/*      */     
/*  833 */     int[] escapes = new int[4];
/*      */     
/*      */ 
/*  836 */     int c2 = reader.read();
/*      */     
/*  838 */     while (c2 >= 0)
/*      */     {
/*  840 */       int c1 = c2;
/*  841 */       c2 = reader.read();
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  847 */       if ((c1 != 92) || (c2 < 0)) {
/*  848 */         writer.write(c1);
/*      */       }
/*      */       else
/*      */       {
/*  852 */         int codepoint = -1;
/*      */         
/*  854 */         if (c1 == 92)
/*      */         {
/*  856 */           switch (c2) {
/*  857 */           case 98:  codepoint = 8;c1 = c2;c2 = reader.read(); break;
/*  858 */           case 116:  codepoint = 9;c1 = c2;c2 = reader.read(); break;
/*  859 */           case 110:  codepoint = 10;c1 = c2;c2 = reader.read(); break;
/*  860 */           case 102:  codepoint = 12;c1 = c2;c2 = reader.read(); break;
/*  861 */           case 114:  codepoint = 13;c1 = c2;c2 = reader.read(); break;
/*  862 */           case 34:  codepoint = 34;c1 = c2;c2 = reader.read(); break;
/*  863 */           case 92:  codepoint = 92;c1 = c2;c2 = reader.read(); break;
/*  864 */           case 47:  codepoint = 47;c1 = c2;c2 = reader.read();
/*      */           }
/*      */           
/*  867 */           if (codepoint == -1)
/*      */           {
/*  869 */             if (c2 == 117)
/*      */             {
/*      */ 
/*  872 */               int escapei = 0;
/*  873 */               int ce = reader.read();
/*  874 */               while ((ce >= 0) && (escapei < 4) && (
/*  875 */                 ((ce >= 48) && (ce <= 57)) || ((ce >= 65) && (ce <= 70)) || ((ce >= 97) && (ce <= 102))))
/*      */               {
/*      */ 
/*  878 */                 escapes[escapei] = ce;
/*  879 */                 ce = reader.read();
/*  880 */                 escapei++;
/*      */               }
/*      */               
/*  883 */               if (escapei < 4)
/*      */               {
/*      */ 
/*  886 */                 writer.write(c1);
/*  887 */                 writer.write(c2);
/*  888 */                 for (int i = 0; i < escapei; i++) {
/*  889 */                   c1 = c2;
/*  890 */                   c2 = escapes[i];
/*  891 */                   writer.write(c2);
/*      */                 }
/*  893 */                 c1 = c2;
/*  894 */                 c2 = ce;
/*  895 */                 continue;
/*      */               }
/*      */               
/*  898 */               c1 = escapes[3];
/*  899 */               c2 = ce;
/*      */               
/*  901 */               codepoint = parseIntFromReference(escapes, 0, 4, 16);
/*      */ 
/*      */ 
/*      */             }
/*      */             else
/*      */             {
/*      */ 
/*      */ 
/*  909 */               writer.write(c1);
/*  910 */               writer.write(c2);
/*      */               
/*  912 */               c1 = c2;
/*  913 */               c2 = reader.read();
/*      */               
/*  915 */               continue;
/*      */             }
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  932 */         if (codepoint > 65535) {
/*  933 */           writer.write(Character.toChars(codepoint));
/*      */         } else {
/*  935 */           writer.write((char)codepoint);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static void unescape(char[] text, int offset, int len, Writer writer)
/*      */     throws IOException
/*      */   {
/*  953 */     if (text == null) {
/*  954 */       return;
/*      */     }
/*      */     
/*  957 */     int max = offset + len;
/*      */     
/*  959 */     int readOffset = offset;
/*  960 */     int referenceOffset = offset;
/*      */     
/*  962 */     for (int i = offset; i < max; i++)
/*      */     {
/*  964 */       char c = text[i];
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  970 */       if ((c == '\\') && (i + 1 < max))
/*      */       {
/*      */ 
/*      */ 
/*  974 */         int codepoint = -1;
/*      */         
/*  976 */         if (c == '\\')
/*      */         {
/*  978 */           char c1 = text[(i + 1)];
/*      */           
/*  980 */           switch (c1) {
/*  981 */           case 'b':  codepoint = 8;referenceOffset = i + 1; break;
/*  982 */           case 't':  codepoint = 9;referenceOffset = i + 1; break;
/*  983 */           case 'n':  codepoint = 10;referenceOffset = i + 1; break;
/*  984 */           case 'f':  codepoint = 12;referenceOffset = i + 1; break;
/*  985 */           case 'r':  codepoint = 13;referenceOffset = i + 1; break;
/*  986 */           case '"':  codepoint = 34;referenceOffset = i + 1; break;
/*  987 */           case '\\':  codepoint = 92;referenceOffset = i + 1; break;
/*  988 */           case '/':  codepoint = 47;referenceOffset = i + 1;
/*      */           }
/*      */           
/*  991 */           if (codepoint == -1)
/*      */           {
/*  993 */             if (c1 == 'u')
/*      */             {
/*      */ 
/*  996 */               int f = i + 2;
/*  997 */               while ((f < i + 6) && (f < max)) {
/*  998 */                 char cf = text[f];
/*  999 */                 if (((cf < '0') || (cf > '9')) && ((cf < 'A') || (cf > 'F')) && ((cf < 'a') || (cf > 'f'))) {
/*      */                   break;
/*      */                 }
/* 1002 */                 f++;
/*      */               }
/*      */               
/* 1005 */               if (f - (i + 2) < 4)
/*      */               {
/*      */ 
/* 1008 */                 i++;
/* 1009 */                 continue;
/*      */               }
/*      */               
/* 1012 */               codepoint = parseIntFromReference(text, i + 2, f, 16);
/*      */               
/*      */ 
/* 1015 */               referenceOffset = f - 1;
/*      */ 
/*      */ 
/*      */             }
/*      */             else
/*      */             {
/*      */ 
/*      */ 
/* 1023 */               i++;
/* 1024 */               continue;
/*      */             }
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1038 */         if (i - readOffset > 0) {
/* 1039 */           writer.write(text, readOffset, i - readOffset);
/*      */         }
/*      */         
/* 1042 */         i = referenceOffset;
/* 1043 */         readOffset = i + 1;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1053 */         if (codepoint > 65535) {
/* 1054 */           writer.write(Character.toChars(codepoint));
/*      */         } else {
/* 1056 */           writer.write((char)codepoint);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1068 */     if (max - readOffset > 0) {
/* 1069 */       writer.write(text, readOffset, max - readOffset);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private static int codePointAt(char c1, char c2)
/*      */   {
/* 1078 */     if ((Character.isHighSurrogate(c1)) && 
/* 1079 */       (c2 >= 0) && 
/* 1080 */       (Character.isLowSurrogate(c2))) {
/* 1081 */       return Character.toCodePoint(c1, c2);
/*      */     }
/*      */     
/*      */ 
/* 1085 */     return c1;
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\unbescape-1.1.6.RELEASE.jar!\org\unbescape\json\JsonEscapeUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */