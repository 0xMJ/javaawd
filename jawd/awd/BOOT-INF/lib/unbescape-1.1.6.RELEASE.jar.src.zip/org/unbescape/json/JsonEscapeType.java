/*    */ package org.unbescape.json;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum JsonEscapeType
/*    */ {
/* 51 */   SINGLE_ESCAPE_CHARS_DEFAULT_TO_UHEXA(true), 
/*    */   
/*    */ 
/*    */ 
/*    */ 
/* 56 */   UHEXA(false);
/*    */   
/*    */   private final boolean useSECs;
/*    */   
/*    */   private JsonEscapeType(boolean useSECs)
/*    */   {
/* 62 */     this.useSECs = useSECs;
/*    */   }
/*    */   
/*    */   boolean getUseSECs() {
/* 66 */     return this.useSECs;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\unbescape-1.1.6.RELEASE.jar!\org\unbescape\json\JsonEscapeType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */