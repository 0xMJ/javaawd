/*     */ package org.unbescape;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ClassLoaderUtils
/*     */ {
/*  46 */   private static final ClassLoader classClassLoader = getClassClassLoader(ClassLoaderUtils.class);
/*  47 */   private static final ClassLoader systemClassLoader = getSystemClassLoader();
/*  48 */   private static final boolean systemClassLoaderAccessibleFromClassClassLoader = isKnownClassLoaderAccessibleFrom(systemClassLoader, classClassLoader);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static InputStream loadResourceAsStream(String resourceName)
/*     */     throws IOException
/*     */   {
/*  75 */     InputStream inputStream = findResourceAsStream(resourceName);
/*  76 */     if (inputStream != null) {
/*  77 */       return inputStream;
/*     */     }
/*     */     
/*     */ 
/*  81 */     throw new IOException("Could not locate resource '" + resourceName + "' in the application's class path");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static InputStream findResourceAsStream(String resourceName)
/*     */   {
/* 102 */     ClassLoader contextClassLoader = getThreadContextClassLoader();
/* 103 */     if (contextClassLoader != null) {
/* 104 */       InputStream inputStream = contextClassLoader.getResourceAsStream(resourceName);
/* 105 */       if (inputStream != null) {
/* 106 */         return inputStream;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 116 */     if (!isKnownLeafClassLoader(contextClassLoader))
/*     */     {
/*     */ 
/* 119 */       if ((classClassLoader != null) && (classClassLoader != contextClassLoader)) {
/* 120 */         InputStream inputStream = classClassLoader.getResourceAsStream(resourceName);
/* 121 */         if (inputStream != null) {
/* 122 */           return inputStream;
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 127 */       if (!systemClassLoaderAccessibleFromClassClassLoader)
/*     */       {
/*     */ 
/* 130 */         if ((systemClassLoader != null) && (systemClassLoader != contextClassLoader) && (systemClassLoader != classClassLoader)) {
/* 131 */           InputStream inputStream = systemClassLoader.getResourceAsStream(resourceName);
/* 132 */           if (inputStream != null) {
/* 133 */             return inputStream;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 142 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static ClassLoader getThreadContextClassLoader()
/*     */   {
/*     */     try
/*     */     {
/* 155 */       return Thread.currentThread().getContextClassLoader();
/*     */     }
/*     */     catch (SecurityException se) {}
/* 158 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static ClassLoader getClassClassLoader(Class<?> clazz)
/*     */   {
/*     */     try
/*     */     {
/* 169 */       return clazz.getClassLoader();
/*     */     }
/*     */     catch (SecurityException se) {}
/* 172 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static ClassLoader getSystemClassLoader()
/*     */   {
/*     */     try
/*     */     {
/* 183 */       return ClassLoader.getSystemClassLoader();
/*     */     }
/*     */     catch (SecurityException se) {}
/* 186 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean isKnownClassLoaderAccessibleFrom(ClassLoader accessibleCL, ClassLoader fromCL)
/*     */   {
/* 197 */     if (fromCL == null) {
/* 198 */       return false;
/*     */     }
/*     */     
/* 201 */     ClassLoader parent = fromCL;
/*     */     
/*     */     try
/*     */     {
/* 205 */       while ((parent != null) && (parent != accessibleCL)) {
/* 206 */         parent = parent.getParent();
/*     */       }
/*     */       
/* 209 */       return (parent != null) && (parent == accessibleCL);
/*     */     }
/*     */     catch (SecurityException se) {}
/*     */     
/* 213 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean isKnownLeafClassLoader(ClassLoader classLoader)
/*     */   {
/* 227 */     if (classLoader == null) {
/* 228 */       return false;
/*     */     }
/*     */     
/* 231 */     if (!isKnownClassLoaderAccessibleFrom(classClassLoader, classLoader))
/*     */     {
/* 233 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 238 */     return systemClassLoaderAccessibleFromClassClassLoader;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\unbescape-1.1.6.RELEASE.jar!\org\unbescape\ClassLoaderUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */