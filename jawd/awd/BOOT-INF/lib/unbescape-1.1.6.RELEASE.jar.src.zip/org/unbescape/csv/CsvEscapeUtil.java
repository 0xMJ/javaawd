/*     */ package org.unbescape.csv;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.io.Writer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class CsvEscapeUtil
/*     */ {
/*     */   private static final char DOUBLE_QUOTE = '"';
/*  76 */   private static final char[] TWO_DOUBLE_QUOTES = "\"\"".toCharArray();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static String escape(String text)
/*     */   {
/*  93 */     if (text == null) {
/*  94 */       return null;
/*     */     }
/*     */     
/*  97 */     StringBuilder strBuilder = null;
/*     */     
/*  99 */     int offset = 0;
/* 100 */     int max = text.length();
/*     */     
/* 102 */     int readOffset = 0;
/*     */     
/* 104 */     for (int i = 0; i < max; i++)
/*     */     {
/* 106 */       char c = text.charAt(i);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 113 */       if (((c < 'a') || (c > 'z')) && ((c < 'A') || (c > 'Z')) && ((c < '0') || (c > '9')))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 122 */         if (strBuilder == null) {
/* 123 */           strBuilder = new StringBuilder(max + 20);
/*     */           
/*     */ 
/* 126 */           strBuilder.append('"');
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 132 */         if (i - readOffset > 0) {
/* 133 */           strBuilder.append(text, readOffset, i);
/*     */         }
/*     */         
/* 136 */         readOffset = i + 1;
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 141 */         if (c == '"') {
/* 142 */           strBuilder.append(TWO_DOUBLE_QUOTES);
/*     */         }
/*     */         else
/*     */         {
/* 146 */           strBuilder.append(c);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 158 */     if (strBuilder == null) {
/* 159 */       return text;
/*     */     }
/*     */     
/* 162 */     if (max - readOffset > 0) {
/* 163 */       strBuilder.append(text, readOffset, max);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 168 */     strBuilder.append('"');
/*     */     
/* 170 */     return strBuilder.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static void escape(Reader reader, Writer writer)
/*     */     throws IOException
/*     */   {
/* 186 */     if (reader == null) {
/* 187 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 196 */     int doQuote = -1;
/*     */     
/* 198 */     int bufferSize = 0;
/* 199 */     char[] buffer = new char[10];
/*     */     
/* 201 */     int read = reader.read(buffer, 0, buffer.length);
/* 202 */     if (read < 0) {
/* 203 */       return;
/*     */     }
/*     */     
/*     */ 
/* 207 */     while ((doQuote < 0) && (read >= 0))
/*     */     {
/* 209 */       int i = bufferSize;
/* 210 */       bufferSize += read;
/*     */       
/* 212 */       while ((doQuote < 0) && (i < bufferSize)) {
/* 213 */         char cq = buffer[(i++)];
/* 214 */         if (((cq < 'a') || (cq > 'z')) && ((cq < 'A') || (cq > 'Z')) && ((cq < '0') || (cq > '9'))) {
/* 215 */           doQuote = 1;
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 220 */       if ((doQuote < 0) && (read >= 0))
/*     */       {
/* 222 */         if (bufferSize == buffer.length)
/*     */         {
/* 224 */           char[] newBuffer = new char[buffer.length + buffer.length / 2];
/* 225 */           System.arraycopy(buffer, 0, newBuffer, 0, buffer.length);
/* 226 */           buffer = newBuffer;
/*     */         }
/*     */         
/* 229 */         read = reader.read(buffer, bufferSize, buffer.length - bufferSize);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 235 */     doQuote = Math.max(doQuote, 0);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 241 */     if (doQuote == 1) {
/* 242 */       writer.write(34);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 249 */     if (bufferSize > 0)
/*     */     {
/*     */ 
/* 252 */       for (int i = 0; i < bufferSize; i++)
/*     */       {
/* 254 */         char c = buffer[i];
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 259 */         if (c == '"') {
/* 260 */           writer.write(TWO_DOUBLE_QUOTES);
/*     */         } else {
/* 262 */           writer.write(c);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 273 */     if (read >= 0)
/*     */     {
/*     */ 
/*     */ 
/* 277 */       int c1 = -1;
/* 278 */       int c2 = reader.read();
/*     */       
/* 280 */       while (c2 >= 0)
/*     */       {
/* 282 */         c1 = c2;
/* 283 */         c2 = reader.read();
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 288 */         if (c1 == 34) {
/* 289 */           writer.write(TWO_DOUBLE_QUOTES);
/*     */         } else {
/* 291 */           writer.write(c1);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 302 */     if (doQuote == 1) {
/* 303 */       writer.write(34);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static void escape(char[] text, int offset, int len, Writer writer)
/*     */     throws IOException
/*     */   {
/* 318 */     if ((text == null) || (text.length == 0)) {
/* 319 */       return;
/*     */     }
/*     */     
/* 322 */     int max = offset + len;
/*     */     
/* 324 */     int readOffset = offset;
/*     */     
/* 326 */     for (int i = offset; i < max; i++)
/*     */     {
/* 328 */       char c = text[i];
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 335 */       if (((c < 'a') || (c > 'z')) && ((c < 'A') || (c > 'Z')) && ((c < '0') || (c > '9')))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 344 */         if (readOffset == offset)
/*     */         {
/*     */ 
/* 347 */           writer.write(34);
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 353 */         if (i - readOffset > 0) {
/* 354 */           writer.write(text, readOffset, i - readOffset);
/*     */         }
/*     */         
/* 357 */         readOffset = i + 1;
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 362 */         if (c == '"') {
/* 363 */           writer.write(TWO_DOUBLE_QUOTES);
/*     */         }
/*     */         else
/*     */         {
/* 367 */           writer.write(c);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 378 */     if (max - readOffset > 0) {
/* 379 */       writer.write(text, readOffset, max - readOffset);
/*     */     }
/*     */     
/* 382 */     if (readOffset > offset)
/*     */     {
/*     */ 
/* 385 */       writer.write(34);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static String unescape(String text)
/*     */   {
/* 404 */     if (text == null) {
/* 405 */       return null;
/*     */     }
/*     */     
/* 408 */     StringBuilder strBuilder = null;
/*     */     
/* 410 */     int offset = 0;
/* 411 */     int max = text.length();
/*     */     
/* 413 */     int readOffset = 0;
/* 414 */     int referenceOffset = 0;
/*     */     
/* 416 */     boolean isQuoted = false;
/*     */     
/* 418 */     for (int i = 0; i < max; i++)
/*     */     {
/* 420 */       char c = text.charAt(i);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 425 */       if ((i <= 0) || (c == '"'))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 433 */         if (c == '"')
/*     */         {
/* 435 */           if (i == 0)
/*     */           {
/*     */ 
/*     */ 
/* 439 */             if (i + 1 < max)
/*     */             {
/*     */ 
/*     */ 
/*     */ 
/* 444 */               if (text.charAt(max - 1) == '"')
/*     */               {
/* 446 */                 isQuoted = true;
/*     */                 
/* 448 */                 referenceOffset = i + 1;
/* 449 */                 readOffset = i + 1;
/*     */               }
/*     */               
/*     */             }
/*     */             
/*     */ 
/*     */           }
/*     */           else
/*     */           {
/* 458 */             if ((isQuoted) && (i + 2 < max))
/*     */             {
/*     */ 
/* 461 */               char c1 = text.charAt(i + 1);
/* 462 */               if (c1 == '"')
/*     */               {
/* 464 */                 referenceOffset = i + 1;
/*     */               }
/*     */             } else {
/* 467 */               if ((!isQuoted) || (i + 1 < max)) {
/*     */                 continue;
/*     */               }
/* 470 */               referenceOffset = i + 1;
/*     */             }
/*     */             
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 493 */             if (strBuilder == null) {
/* 494 */               strBuilder = new StringBuilder(max + 5);
/*     */             }
/*     */             
/* 497 */             if (i - readOffset > 0) {
/* 498 */               strBuilder.append(text, readOffset, i);
/*     */             }
/*     */             
/* 501 */             i = referenceOffset;
/* 502 */             readOffset = i + 1;
/*     */             
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 510 */             if (referenceOffset < max) {
/* 511 */               strBuilder.append(c);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 524 */     if (strBuilder == null) {
/* 525 */       return text;
/*     */     }
/*     */     
/* 528 */     if (max - readOffset > 0) {
/* 529 */       strBuilder.append(text, readOffset, max);
/*     */     }
/*     */     
/* 532 */     return strBuilder.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static void unescape(Reader reader, Writer writer)
/*     */     throws IOException
/*     */   {
/* 549 */     if (reader == null) {
/* 550 */       return;
/*     */     }
/*     */     
/* 553 */     boolean isQuoted = false;
/*     */     
/*     */ 
/*     */ 
/* 557 */     int c2 = reader.read();
/*     */     
/* 559 */     if (c2 < 0)
/*     */     {
/* 561 */       return; }
/* 562 */     if (c2 == 34) {
/* 563 */       int c1 = c2;
/* 564 */       c2 = reader.read();
/* 565 */       if (c2 < 0)
/*     */       {
/*     */ 
/* 568 */         writer.write(c1);
/* 569 */         return;
/*     */       }
/* 571 */       isQuoted = true;
/*     */     }
/*     */     
/*     */ 
/* 575 */     while (c2 >= 0)
/*     */     {
/* 577 */       int c1 = c2;
/* 578 */       c2 = reader.read();
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 583 */       if (c1 != 34) {
/* 584 */         writer.write(c1);
/*     */ 
/*     */ 
/*     */       }
/* 588 */       else if (c2 < 0)
/*     */       {
/* 590 */         if (!isQuoted)
/*     */         {
/* 592 */           writer.write(c1);
/*     */         }
/*     */         
/*     */       }
/* 596 */       else if (c2 == 34)
/*     */       {
/*     */ 
/*     */ 
/* 600 */         writer.write(34);
/* 601 */         c1 = c2;
/* 602 */         c2 = reader.read();
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/*     */ 
/* 608 */         writer.write(34);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static void unescape(char[] text, int offset, int len, Writer writer)
/*     */     throws IOException
/*     */   {
/* 627 */     if (text == null) {
/* 628 */       return;
/*     */     }
/*     */     
/*     */ 
/* 632 */     int max = offset + len;
/*     */     
/* 634 */     int readOffset = offset;
/* 635 */     int referenceOffset = offset;
/*     */     
/* 637 */     boolean isQuoted = false;
/*     */     
/* 639 */     for (int i = offset; i < max; i++)
/*     */     {
/* 641 */       char c = text[i];
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 646 */       if ((i <= offset) || (c == '"'))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 654 */         if (c == '"')
/*     */         {
/* 656 */           if (i == offset)
/*     */           {
/*     */ 
/*     */ 
/* 660 */             if (i + 1 < max)
/*     */             {
/*     */ 
/*     */ 
/*     */ 
/* 665 */               if (text[(max - 1)] == '"')
/*     */               {
/* 667 */                 isQuoted = true;
/*     */                 
/* 669 */                 referenceOffset = i + 1;
/* 670 */                 readOffset = i + 1;
/*     */               }
/*     */               
/*     */             }
/*     */             
/*     */ 
/*     */           }
/*     */           else
/*     */           {
/* 679 */             if ((isQuoted) && (i + 2 < max))
/*     */             {
/*     */ 
/* 682 */               char c1 = text[(i + 1)];
/* 683 */               if (c1 == '"')
/*     */               {
/* 685 */                 referenceOffset = i + 1;
/*     */               }
/*     */             } else {
/* 688 */               if ((!isQuoted) || (i + 1 < max)) {
/*     */                 continue;
/*     */               }
/* 691 */               referenceOffset = i + 1;
/*     */             }
/*     */             
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 713 */             if (i - readOffset > 0) {
/* 714 */               writer.write(text, readOffset, i - readOffset);
/*     */             }
/*     */             
/* 717 */             i = referenceOffset;
/* 718 */             readOffset = i + 1;
/*     */             
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 726 */             if (referenceOffset < max) {
/* 727 */               writer.write(c);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 739 */     if (max - readOffset > 0) {
/* 740 */       writer.write(text, readOffset, max - readOffset);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\unbescape-1.1.6.RELEASE.jar!\org\unbescape\csv\CsvEscapeUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */