/*     */ package org.unbescape.csv;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.io.Writer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CsvEscape
/*     */ {
/*     */   public static String escapeCsv(String text)
/*     */   {
/* 137 */     return CsvEscapeUtil.escape(text);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void escapeCsv(String text, Writer writer)
/*     */     throws IOException
/*     */   {
/* 160 */     if (writer == null) {
/* 161 */       throw new IllegalArgumentException("Argument 'writer' cannot be null");
/*     */     }
/*     */     
/* 164 */     CsvEscapeUtil.escape(new InternalStringReader(text), writer);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void escapeCsv(Reader reader, Writer writer)
/*     */     throws IOException
/*     */   {
/* 187 */     if (writer == null) {
/* 188 */       throw new IllegalArgumentException("Argument 'writer' cannot be null");
/*     */     }
/*     */     
/* 191 */     CsvEscapeUtil.escape(reader, writer);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void escapeCsv(char[] text, int offset, int len, Writer writer)
/*     */     throws IOException
/*     */   {
/* 213 */     if (writer == null) {
/* 214 */       throw new IllegalArgumentException("Argument 'writer' cannot be null");
/*     */     }
/*     */     
/* 217 */     int textLen = text == null ? 0 : text.length;
/*     */     
/* 219 */     if ((offset < 0) || (offset > textLen)) {
/* 220 */       throw new IllegalArgumentException("Invalid (offset, len). offset=" + offset + ", len=" + len + ", text.length=" + textLen);
/*     */     }
/*     */     
/*     */ 
/* 224 */     if ((len < 0) || (offset + len > textLen)) {
/* 225 */       throw new IllegalArgumentException("Invalid (offset, len). offset=" + offset + ", len=" + len + ", text.length=" + textLen);
/*     */     }
/*     */     
/*     */ 
/* 229 */     CsvEscapeUtil.escape(text, offset, len, writer);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String unescapeCsv(String text)
/*     */   {
/* 255 */     return CsvEscapeUtil.unescape(text);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void unescapeCsv(String text, Writer writer)
/*     */     throws IOException
/*     */   {
/* 278 */     if (writer == null) {
/* 279 */       throw new IllegalArgumentException("Argument 'writer' cannot be null");
/*     */     }
/*     */     
/* 282 */     CsvEscapeUtil.unescape(new InternalStringReader(text), writer);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void unescapeCsv(Reader reader, Writer writer)
/*     */     throws IOException
/*     */   {
/* 306 */     if (writer == null) {
/* 307 */       throw new IllegalArgumentException("Argument 'writer' cannot be null");
/*     */     }
/*     */     
/* 310 */     CsvEscapeUtil.unescape(reader, writer);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void unescapeCsv(char[] text, int offset, int len, Writer writer)
/*     */     throws IOException
/*     */   {
/* 333 */     if (writer == null) {
/* 334 */       throw new IllegalArgumentException("Argument 'writer' cannot be null");
/*     */     }
/*     */     
/* 337 */     int textLen = text == null ? 0 : text.length;
/*     */     
/* 339 */     if ((offset < 0) || (offset > textLen)) {
/* 340 */       throw new IllegalArgumentException("Invalid (offset, len). offset=" + offset + ", len=" + len + ", text.length=" + textLen);
/*     */     }
/*     */     
/*     */ 
/* 344 */     if ((len < 0) || (offset + len > textLen)) {
/* 345 */       throw new IllegalArgumentException("Invalid (offset, len). offset=" + offset + ", len=" + len + ", text.length=" + textLen);
/*     */     }
/*     */     
/*     */ 
/* 349 */     CsvEscapeUtil.unescape(text, offset, len, writer);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final class InternalStringReader
/*     */     extends Reader
/*     */   {
/*     */     private String str;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private int length;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 373 */     private int next = 0;
/*     */     
/*     */     public InternalStringReader(String s)
/*     */     {
/* 377 */       this.str = s;
/* 378 */       this.length = s.length();
/*     */     }
/*     */     
/*     */     public int read() throws IOException
/*     */     {
/* 383 */       if (this.next >= this.length) {
/* 384 */         return -1;
/*     */       }
/* 386 */       return this.str.charAt(this.next++);
/*     */     }
/*     */     
/*     */     public int read(char[] cbuf, int off, int len) throws IOException
/*     */     {
/* 391 */       if ((off < 0) || (off > cbuf.length) || (len < 0) || (off + len > cbuf.length) || (off + len < 0))
/*     */       {
/* 393 */         throw new IndexOutOfBoundsException(); }
/* 394 */       if (len == 0) {
/* 395 */         return 0;
/*     */       }
/* 397 */       if (this.next >= this.length) {
/* 398 */         return -1;
/*     */       }
/* 400 */       int n = Math.min(this.length - this.next, len);
/* 401 */       this.str.getChars(this.next, this.next + n, cbuf, off);
/* 402 */       this.next += n;
/* 403 */       return n;
/*     */     }
/*     */     
/*     */     public void close() throws IOException
/*     */     {
/* 408 */       this.str = null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\unbescape-1.1.6.RELEASE.jar!\org\unbescape\csv\CsvEscape.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */