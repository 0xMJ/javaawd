/*     */ package org.unbescape.properties;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.io.Writer;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class PropertiesValueEscapeUtil
/*     */ {
/*     */   private static final char ESCAPE_PREFIX = '\\';
/*  89 */   private static final char[] ESCAPE_UHEXA_PREFIX = "\\u".toCharArray();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  94 */   private static char[] HEXA_CHARS_UPPER = "0123456789ABCDEF".toCharArray();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 100 */   private static int SEC_CHARS_LEN = 93;
/* 101 */   private static char SEC_CHARS_NO_SEC = '*';
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 119 */   private static char[] SEC_CHARS = new char[SEC_CHARS_LEN];
/* 120 */   static { Arrays.fill(SEC_CHARS, SEC_CHARS_NO_SEC);
/* 121 */     SEC_CHARS[9] = 't';
/* 122 */     SEC_CHARS[10] = 'n';
/* 123 */     SEC_CHARS[12] = 'f';
/* 124 */     SEC_CHARS[13] = 'r';
/* 125 */     SEC_CHARS[92] = '\\';
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 139 */     ESCAPE_LEVELS = new byte['¡'];
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 144 */     Arrays.fill(ESCAPE_LEVELS, (byte)3);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 149 */     for (char c = ''; c < '¡'; c = (char)(c + '\001')) {
/* 150 */       ESCAPE_LEVELS[c] = 2;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 156 */     for (char c = 'A'; c <= 'Z'; c = (char)(c + '\001')) {
/* 157 */       ESCAPE_LEVELS[c] = 4;
/*     */     }
/* 159 */     for (char c = 'a'; c <= 'z'; c = (char)(c + '\001')) {
/* 160 */       ESCAPE_LEVELS[c] = 4;
/*     */     }
/* 162 */     for (char c = '0'; c <= '9'; c = (char)(c + '\001')) {
/* 163 */       ESCAPE_LEVELS[c] = 4;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 169 */     ESCAPE_LEVELS[9] = 1;
/* 170 */     ESCAPE_LEVELS[10] = 1;
/* 171 */     ESCAPE_LEVELS[12] = 1;
/* 172 */     ESCAPE_LEVELS[13] = 1;
/* 173 */     ESCAPE_LEVELS[92] = 1;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 179 */     for (char c = '\000'; c <= '\037'; c = (char)(c + '\001')) {
/* 180 */       ESCAPE_LEVELS[c] = 1;
/*     */     }
/* 182 */     for (char c = ''; c <= ''; c = (char)(c + '\001')) {
/* 183 */       ESCAPE_LEVELS[c] = 1;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final char ESCAPE_LEVELS_LEN = '¡';
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static char[] toUHexa(int codepoint)
/*     */   {
/* 198 */     char[] result = new char[4];
/* 199 */     result[3] = HEXA_CHARS_UPPER[(codepoint % 16)];
/* 200 */     result[2] = HEXA_CHARS_UPPER[((codepoint >>> 4) % 16)];
/* 201 */     result[1] = HEXA_CHARS_UPPER[((codepoint >>> 8) % 16)];
/* 202 */     result[0] = HEXA_CHARS_UPPER[((codepoint >>> 12) % 16)];
/* 203 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static String escape(String text, PropertiesValueEscapeLevel escapeLevel)
/*     */   {
/* 213 */     if (text == null) {
/* 214 */       return null;
/*     */     }
/*     */     
/* 217 */     int level = escapeLevel.getEscapeLevel();
/*     */     
/* 219 */     StringBuilder strBuilder = null;
/*     */     
/* 221 */     int offset = 0;
/* 222 */     int max = text.length();
/*     */     
/* 224 */     int readOffset = 0;
/*     */     
/* 226 */     for (int i = 0; i < max; i++)
/*     */     {
/* 228 */       int codepoint = Character.codePointAt(text, i);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 235 */       if ((codepoint > 159) || (level >= ESCAPE_LEVELS[codepoint]))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 242 */         if ((codepoint > 159) && (level < ESCAPE_LEVELS[' ']))
/*     */         {
/* 244 */           if (Character.charCount(codepoint) > 1)
/*     */           {
/* 246 */             i++;
/*     */ 
/*     */ 
/*     */           }
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/* 260 */           if (strBuilder == null) {
/* 261 */             strBuilder = new StringBuilder(max + 20);
/*     */           }
/*     */           
/* 264 */           if (i - readOffset > 0) {
/* 265 */             strBuilder.append(text, readOffset, i);
/*     */           }
/*     */           
/* 268 */           if (Character.charCount(codepoint) > 1)
/*     */           {
/* 270 */             i++;
/*     */           }
/*     */           
/* 273 */           readOffset = i + 1;
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 284 */           if (codepoint < SEC_CHARS_LEN)
/*     */           {
/*     */ 
/* 287 */             char sec = SEC_CHARS[codepoint];
/*     */             
/* 289 */             if (sec != SEC_CHARS_NO_SEC)
/*     */             {
/* 291 */               strBuilder.append('\\');
/* 292 */               strBuilder.append(sec);
/* 293 */               continue;
/*     */             }
/*     */           }
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 302 */           if (Character.charCount(codepoint) > 1) {
/* 303 */             char[] codepointChars = Character.toChars(codepoint);
/* 304 */             strBuilder.append(ESCAPE_UHEXA_PREFIX);
/* 305 */             strBuilder.append(toUHexa(codepointChars[0]));
/* 306 */             strBuilder.append(ESCAPE_UHEXA_PREFIX);
/* 307 */             strBuilder.append(toUHexa(codepointChars[1]));
/*     */           }
/*     */           else
/*     */           {
/* 311 */             strBuilder.append(ESCAPE_UHEXA_PREFIX);
/* 312 */             strBuilder.append(toUHexa(codepoint));
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 324 */     if (strBuilder == null) {
/* 325 */       return text;
/*     */     }
/*     */     
/* 328 */     if (max - readOffset > 0) {
/* 329 */       strBuilder.append(text, readOffset, max);
/*     */     }
/*     */     
/* 332 */     return strBuilder.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final byte[] ESCAPE_LEVELS;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static void escape(Reader reader, Writer writer, PropertiesValueEscapeLevel escapeLevel)
/*     */     throws IOException
/*     */   {
/* 351 */     if (reader == null) {
/* 352 */       return;
/*     */     }
/*     */     
/* 355 */     int level = escapeLevel.getEscapeLevel();
/*     */     
/*     */ 
/*     */ 
/* 359 */     int c2 = reader.read();
/*     */     
/* 361 */     while (c2 >= 0)
/*     */     {
/* 363 */       int c1 = c2;
/* 364 */       c2 = reader.read();
/*     */       
/* 366 */       int codepoint = codePointAt((char)c1, (char)c2);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 373 */       if ((codepoint <= 159) && (level < ESCAPE_LEVELS[codepoint])) {
/* 374 */         writer.write(c1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/* 381 */       else if ((codepoint > 159) && (level < ESCAPE_LEVELS[' ']))
/*     */       {
/* 383 */         writer.write(c1);
/*     */         
/* 385 */         if (Character.charCount(codepoint) > 1)
/*     */         {
/*     */ 
/* 388 */           writer.write(c2);
/*     */           
/* 390 */           c1 = c2;
/* 391 */           c2 = reader.read();
/*     */ 
/*     */ 
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 405 */         if (Character.charCount(codepoint) > 1)
/*     */         {
/* 407 */           c1 = c2;
/* 408 */           c2 = reader.read();
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 420 */         if (codepoint < SEC_CHARS_LEN)
/*     */         {
/*     */ 
/* 423 */           char sec = SEC_CHARS[codepoint];
/*     */           
/* 425 */           if (sec != SEC_CHARS_NO_SEC)
/*     */           {
/* 427 */             writer.write(92);
/* 428 */             writer.write(sec);
/* 429 */             continue;
/*     */           }
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 438 */         if (Character.charCount(codepoint) > 1) {
/* 439 */           char[] codepointChars = Character.toChars(codepoint);
/* 440 */           writer.write(ESCAPE_UHEXA_PREFIX);
/* 441 */           writer.write(toUHexa(codepointChars[0]));
/* 442 */           writer.write(ESCAPE_UHEXA_PREFIX);
/* 443 */           writer.write(toUHexa(codepointChars[1]));
/*     */         }
/*     */         else
/*     */         {
/* 447 */           writer.write(ESCAPE_UHEXA_PREFIX);
/* 448 */           writer.write(toUHexa(codepoint));
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static void escape(char[] text, int offset, int len, Writer writer, PropertiesValueEscapeLevel escapeLevel)
/*     */     throws IOException
/*     */   {
/* 465 */     if ((text == null) || (text.length == 0)) {
/* 466 */       return;
/*     */     }
/*     */     
/* 469 */     int level = escapeLevel.getEscapeLevel();
/*     */     
/* 471 */     int max = offset + len;
/*     */     
/* 473 */     int readOffset = offset;
/*     */     
/* 475 */     for (int i = offset; i < max; i++)
/*     */     {
/* 477 */       int codepoint = Character.codePointAt(text, i);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 484 */       if ((codepoint > 159) || (level >= ESCAPE_LEVELS[codepoint]))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 491 */         if ((codepoint > 159) && (level < ESCAPE_LEVELS[' ']))
/*     */         {
/* 493 */           if (Character.charCount(codepoint) > 1)
/*     */           {
/* 495 */             i++;
/*     */ 
/*     */ 
/*     */           }
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/*     */ 
/*     */ 
/* 508 */           if (i - readOffset > 0) {
/* 509 */             writer.write(text, readOffset, i - readOffset);
/*     */           }
/*     */           
/* 512 */           if (Character.charCount(codepoint) > 1)
/*     */           {
/* 514 */             i++;
/*     */           }
/*     */           
/* 517 */           readOffset = i + 1;
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 528 */           if (codepoint < SEC_CHARS_LEN)
/*     */           {
/*     */ 
/* 531 */             char sec = SEC_CHARS[codepoint];
/*     */             
/* 533 */             if (sec != SEC_CHARS_NO_SEC)
/*     */             {
/* 535 */               writer.write(92);
/* 536 */               writer.write(sec);
/* 537 */               continue;
/*     */             }
/*     */           }
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 546 */           if (Character.charCount(codepoint) > 1) {
/* 547 */             char[] codepointChars = Character.toChars(codepoint);
/* 548 */             writer.write(ESCAPE_UHEXA_PREFIX);
/* 549 */             writer.write(toUHexa(codepointChars[0]));
/* 550 */             writer.write(ESCAPE_UHEXA_PREFIX);
/* 551 */             writer.write(toUHexa(codepointChars[1]));
/*     */           }
/*     */           else
/*     */           {
/* 555 */             writer.write(ESCAPE_UHEXA_PREFIX);
/* 556 */             writer.write(toUHexa(codepoint));
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 567 */     if (max - readOffset > 0) {
/* 568 */       writer.write(text, readOffset, max - readOffset);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static int codePointAt(char c1, char c2)
/*     */   {
/* 577 */     if ((Character.isHighSurrogate(c1)) && 
/* 578 */       (c2 >= 0) && 
/* 579 */       (Character.isLowSurrogate(c2))) {
/* 580 */       return Character.toCodePoint(c1, c2);
/*     */     }
/*     */     
/*     */ 
/* 584 */     return c1;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\unbescape-1.1.6.RELEASE.jar!\org\unbescape\properties\PropertiesValueEscapeUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */