/*     */ package org.unbescape.properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum PropertiesValueEscapeLevel
/*     */ {
/*  72 */   LEVEL_1_BASIC_ESCAPE_SET(1), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  77 */   LEVEL_2_ALL_NON_ASCII_PLUS_BASIC_ESCAPE_SET(2), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  83 */   LEVEL_3_ALL_NON_ALPHANUMERIC(3), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  88 */   LEVEL_4_ALL_CHARACTERS(4);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final int escapeLevel;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static PropertiesValueEscapeLevel forLevel(int level)
/*     */   {
/* 105 */     switch (level) {
/* 106 */     case 1:  return LEVEL_1_BASIC_ESCAPE_SET;
/* 107 */     case 2:  return LEVEL_2_ALL_NON_ASCII_PLUS_BASIC_ESCAPE_SET;
/* 108 */     case 3:  return LEVEL_3_ALL_NON_ALPHANUMERIC;
/* 109 */     case 4:  return LEVEL_4_ALL_CHARACTERS;
/*     */     }
/* 111 */     throw new IllegalArgumentException("No escape level enum constant defined for level: " + level);
/*     */   }
/*     */   
/*     */ 
/*     */   private PropertiesValueEscapeLevel(int escapeLevel)
/*     */   {
/* 117 */     this.escapeLevel = escapeLevel;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getEscapeLevel()
/*     */   {
/* 126 */     return this.escapeLevel;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\unbescape-1.1.6.RELEASE.jar!\org\unbescape\properties\PropertiesValueEscapeLevel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */