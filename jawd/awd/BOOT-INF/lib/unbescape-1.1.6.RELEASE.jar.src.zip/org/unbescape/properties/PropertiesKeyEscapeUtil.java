/*     */ package org.unbescape.properties;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.io.Writer;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class PropertiesKeyEscapeUtil
/*     */ {
/*     */   private static final char ESCAPE_PREFIX = '\\';
/*  89 */   private static final char[] ESCAPE_UHEXA_PREFIX = "\\u".toCharArray();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  94 */   private static char[] HEXA_CHARS_UPPER = "0123456789ABCDEF".toCharArray();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 100 */   private static int SEC_CHARS_LEN = 93;
/* 101 */   private static char SEC_CHARS_NO_SEC = '*';
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 119 */   private static char[] SEC_CHARS = new char[SEC_CHARS_LEN];
/* 120 */   static { Arrays.fill(SEC_CHARS, SEC_CHARS_NO_SEC);
/* 121 */     SEC_CHARS[9] = 't';
/* 122 */     SEC_CHARS[10] = 'n';
/* 123 */     SEC_CHARS[12] = 'f';
/* 124 */     SEC_CHARS[13] = 'r';
/* 125 */     SEC_CHARS[32] = ' ';
/* 126 */     SEC_CHARS[58] = ':';
/* 127 */     SEC_CHARS[59] = '=';
/* 128 */     SEC_CHARS[92] = '\\';
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 142 */     ESCAPE_LEVELS = new byte['¡'];
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 147 */     Arrays.fill(ESCAPE_LEVELS, (byte)3);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 152 */     for (char c = ''; c < '¡'; c = (char)(c + '\001')) {
/* 153 */       ESCAPE_LEVELS[c] = 2;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 159 */     for (char c = 'A'; c <= 'Z'; c = (char)(c + '\001')) {
/* 160 */       ESCAPE_LEVELS[c] = 4;
/*     */     }
/* 162 */     for (char c = 'a'; c <= 'z'; c = (char)(c + '\001')) {
/* 163 */       ESCAPE_LEVELS[c] = 4;
/*     */     }
/* 165 */     for (char c = '0'; c <= '9'; c = (char)(c + '\001')) {
/* 166 */       ESCAPE_LEVELS[c] = 4;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 172 */     ESCAPE_LEVELS[9] = 1;
/* 173 */     ESCAPE_LEVELS[10] = 1;
/* 174 */     ESCAPE_LEVELS[12] = 1;
/* 175 */     ESCAPE_LEVELS[13] = 1;
/* 176 */     ESCAPE_LEVELS[32] = 1;
/* 177 */     ESCAPE_LEVELS[58] = 1;
/* 178 */     ESCAPE_LEVELS[59] = 1;
/* 179 */     ESCAPE_LEVELS[92] = 1;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 185 */     for (char c = '\000'; c <= '\037'; c = (char)(c + '\001')) {
/* 186 */       ESCAPE_LEVELS[c] = 1;
/*     */     }
/* 188 */     for (char c = ''; c <= ''; c = (char)(c + '\001')) {
/* 189 */       ESCAPE_LEVELS[c] = 1;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final char ESCAPE_LEVELS_LEN = '¡';
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static char[] toUHexa(int codepoint)
/*     */   {
/* 204 */     char[] result = new char[4];
/* 205 */     result[3] = HEXA_CHARS_UPPER[(codepoint % 16)];
/* 206 */     result[2] = HEXA_CHARS_UPPER[((codepoint >>> 4) % 16)];
/* 207 */     result[1] = HEXA_CHARS_UPPER[((codepoint >>> 8) % 16)];
/* 208 */     result[0] = HEXA_CHARS_UPPER[((codepoint >>> 12) % 16)];
/* 209 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static String escape(String text, PropertiesKeyEscapeLevel escapeLevel)
/*     */   {
/* 219 */     if (text == null) {
/* 220 */       return null;
/*     */     }
/*     */     
/* 223 */     int level = escapeLevel.getEscapeLevel();
/*     */     
/* 225 */     StringBuilder strBuilder = null;
/*     */     
/* 227 */     int offset = 0;
/* 228 */     int max = text.length();
/*     */     
/* 230 */     int readOffset = 0;
/*     */     
/* 232 */     for (int i = 0; i < max; i++)
/*     */     {
/* 234 */       int codepoint = Character.codePointAt(text, i);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 241 */       if ((codepoint > 159) || (level >= ESCAPE_LEVELS[codepoint]))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 248 */         if ((codepoint > 159) && (level < ESCAPE_LEVELS[' ']))
/*     */         {
/* 250 */           if (Character.charCount(codepoint) > 1)
/*     */           {
/* 252 */             i++;
/*     */ 
/*     */ 
/*     */           }
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/* 266 */           if (strBuilder == null) {
/* 267 */             strBuilder = new StringBuilder(max + 20);
/*     */           }
/*     */           
/* 270 */           if (i - readOffset > 0) {
/* 271 */             strBuilder.append(text, readOffset, i);
/*     */           }
/*     */           
/* 274 */           if (Character.charCount(codepoint) > 1)
/*     */           {
/* 276 */             i++;
/*     */           }
/*     */           
/* 279 */           readOffset = i + 1;
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 290 */           if (codepoint < SEC_CHARS_LEN)
/*     */           {
/*     */ 
/* 293 */             char sec = SEC_CHARS[codepoint];
/*     */             
/* 295 */             if (sec != SEC_CHARS_NO_SEC)
/*     */             {
/* 297 */               strBuilder.append('\\');
/* 298 */               strBuilder.append(sec);
/* 299 */               continue;
/*     */             }
/*     */           }
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 308 */           if (Character.charCount(codepoint) > 1) {
/* 309 */             char[] codepointChars = Character.toChars(codepoint);
/* 310 */             strBuilder.append(ESCAPE_UHEXA_PREFIX);
/* 311 */             strBuilder.append(toUHexa(codepointChars[0]));
/* 312 */             strBuilder.append(ESCAPE_UHEXA_PREFIX);
/* 313 */             strBuilder.append(toUHexa(codepointChars[1]));
/*     */           }
/*     */           else
/*     */           {
/* 317 */             strBuilder.append(ESCAPE_UHEXA_PREFIX);
/* 318 */             strBuilder.append(toUHexa(codepoint));
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 330 */     if (strBuilder == null) {
/* 331 */       return text;
/*     */     }
/*     */     
/* 334 */     if (max - readOffset > 0) {
/* 335 */       strBuilder.append(text, readOffset, max);
/*     */     }
/*     */     
/* 338 */     return strBuilder.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final byte[] ESCAPE_LEVELS;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static void escape(Reader reader, Writer writer, PropertiesKeyEscapeLevel escapeLevel)
/*     */     throws IOException
/*     */   {
/* 357 */     if (reader == null) {
/* 358 */       return;
/*     */     }
/*     */     
/* 361 */     int level = escapeLevel.getEscapeLevel();
/*     */     
/*     */ 
/*     */ 
/* 365 */     int c2 = reader.read();
/*     */     
/* 367 */     while (c2 >= 0)
/*     */     {
/* 369 */       int c1 = c2;
/* 370 */       c2 = reader.read();
/*     */       
/* 372 */       int codepoint = codePointAt((char)c1, (char)c2);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 379 */       if ((codepoint <= 159) && (level < ESCAPE_LEVELS[codepoint])) {
/* 380 */         writer.write(c1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/* 387 */       else if ((codepoint > 159) && (level < ESCAPE_LEVELS[' ']))
/*     */       {
/* 389 */         writer.write(c1);
/*     */         
/* 391 */         if (Character.charCount(codepoint) > 1)
/*     */         {
/*     */ 
/* 394 */           writer.write(c2);
/*     */           
/* 396 */           c1 = c2;
/* 397 */           c2 = reader.read();
/*     */ 
/*     */ 
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 411 */         if (Character.charCount(codepoint) > 1)
/*     */         {
/* 413 */           c1 = c2;
/* 414 */           c2 = reader.read();
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 426 */         if (codepoint < SEC_CHARS_LEN)
/*     */         {
/*     */ 
/* 429 */           char sec = SEC_CHARS[codepoint];
/*     */           
/* 431 */           if (sec != SEC_CHARS_NO_SEC)
/*     */           {
/* 433 */             writer.write(92);
/* 434 */             writer.write(sec);
/* 435 */             continue;
/*     */           }
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 444 */         if (Character.charCount(codepoint) > 1) {
/* 445 */           char[] codepointChars = Character.toChars(codepoint);
/* 446 */           writer.write(ESCAPE_UHEXA_PREFIX);
/* 447 */           writer.write(toUHexa(codepointChars[0]));
/* 448 */           writer.write(ESCAPE_UHEXA_PREFIX);
/* 449 */           writer.write(toUHexa(codepointChars[1]));
/*     */         }
/*     */         else
/*     */         {
/* 453 */           writer.write(ESCAPE_UHEXA_PREFIX);
/* 454 */           writer.write(toUHexa(codepoint));
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static void escape(char[] text, int offset, int len, Writer writer, PropertiesKeyEscapeLevel escapeLevel)
/*     */     throws IOException
/*     */   {
/* 471 */     if ((text == null) || (text.length == 0)) {
/* 472 */       return;
/*     */     }
/*     */     
/* 475 */     int level = escapeLevel.getEscapeLevel();
/*     */     
/* 477 */     int max = offset + len;
/*     */     
/* 479 */     int readOffset = offset;
/*     */     
/* 481 */     for (int i = offset; i < max; i++)
/*     */     {
/* 483 */       int codepoint = Character.codePointAt(text, i);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 490 */       if ((codepoint > 159) || (level >= ESCAPE_LEVELS[codepoint]))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 497 */         if ((codepoint > 159) && (level < ESCAPE_LEVELS[' ']))
/*     */         {
/* 499 */           if (Character.charCount(codepoint) > 1)
/*     */           {
/* 501 */             i++;
/*     */ 
/*     */ 
/*     */           }
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/*     */ 
/*     */ 
/* 514 */           if (i - readOffset > 0) {
/* 515 */             writer.write(text, readOffset, i - readOffset);
/*     */           }
/*     */           
/* 518 */           if (Character.charCount(codepoint) > 1)
/*     */           {
/* 520 */             i++;
/*     */           }
/*     */           
/* 523 */           readOffset = i + 1;
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 534 */           if (codepoint < SEC_CHARS_LEN)
/*     */           {
/*     */ 
/* 537 */             char sec = SEC_CHARS[codepoint];
/*     */             
/* 539 */             if (sec != SEC_CHARS_NO_SEC)
/*     */             {
/* 541 */               writer.write(92);
/* 542 */               writer.write(sec);
/* 543 */               continue;
/*     */             }
/*     */           }
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 552 */           if (Character.charCount(codepoint) > 1) {
/* 553 */             char[] codepointChars = Character.toChars(codepoint);
/* 554 */             writer.write(ESCAPE_UHEXA_PREFIX);
/* 555 */             writer.write(toUHexa(codepointChars[0]));
/* 556 */             writer.write(ESCAPE_UHEXA_PREFIX);
/* 557 */             writer.write(toUHexa(codepointChars[1]));
/*     */           }
/*     */           else
/*     */           {
/* 561 */             writer.write(ESCAPE_UHEXA_PREFIX);
/* 562 */             writer.write(toUHexa(codepoint));
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 573 */     if (max - readOffset > 0) {
/* 574 */       writer.write(text, readOffset, max - readOffset);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static int codePointAt(char c1, char c2)
/*     */   {
/* 583 */     if ((Character.isHighSurrogate(c1)) && 
/* 584 */       (c2 >= 0) && 
/* 585 */       (Character.isLowSurrogate(c2))) {
/* 586 */       return Character.toCodePoint(c1, c2);
/*     */     }
/*     */     
/*     */ 
/* 590 */     return c1;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\unbescape-1.1.6.RELEASE.jar!\org\unbescape\properties\PropertiesKeyEscapeUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */