/*     */ package org.unbescape.uri;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.io.Writer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class UriEscapeUtil
/*     */ {
/*     */   private static final char ESCAPE_PREFIX = '%';
/*     */   
/*     */   static abstract enum UriEscapeType
/*     */   {
/*  71 */     PATH, 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  78 */     PATH_SEGMENT, 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  85 */     QUERY_PARAM, 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 100 */     FRAGMENT_ID;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private UriEscapeType() {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public abstract boolean isAllowed(int paramInt);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public boolean canPlusEscapeWhitespace()
/*     */     {
/* 123 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private static boolean isPchar(int c)
/*     */     {
/* 131 */       return (isUnreserved(c)) || (isSubDelim(c)) || (58 == c) || (64 == c);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private static boolean isUnreserved(int c)
/*     */     {
/* 139 */       return (isAlpha(c)) || (isDigit(c)) || (45 == c) || (46 == c) || (95 == c) || (126 == c);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private static boolean isReserved(int c)
/*     */     {
/* 147 */       return (isGenDelim(c)) || (isSubDelim(c));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private static boolean isSubDelim(int c)
/*     */     {
/* 155 */       return (33 == c) || (36 == c) || (38 == c) || (39 == c) || (40 == c) || (41 == c) || (42 == c) || (43 == c) || (44 == c) || (59 == c) || (61 == c);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private static boolean isGenDelim(int c)
/*     */     {
/* 164 */       return (58 == c) || (47 == c) || (63 == c) || (35 == c) || (91 == c) || (93 == c) || (64 == c);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     static boolean isAlpha(int c)
/*     */     {
/* 172 */       return ((c >= 65) && (c <= 90)) || ((c >= 97) && (c <= 122));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private static boolean isDigit(int c)
/*     */     {
/* 180 */       return (c >= 48) && (c <= 57);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 198 */   private static char[] HEXA_CHARS_UPPER = "0123456789ABCDEF".toCharArray();
/* 199 */   private static char[] HEXA_CHARS_LOWER = "0123456789abcdef".toCharArray();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static char[] printHexa(byte b)
/*     */   {
/* 214 */     char[] result = new char[2];
/* 215 */     result[0] = HEXA_CHARS_UPPER[(b >> 4 & 0xF)];
/* 216 */     result[1] = HEXA_CHARS_UPPER[(b & 0xF)];
/* 217 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   static byte parseHexa(char c1, char c2)
/*     */   {
/* 223 */     byte result = 0;
/* 224 */     for (int j = 0; j < HEXA_CHARS_UPPER.length; j++) {
/* 225 */       if ((c1 == HEXA_CHARS_UPPER[j]) || (c1 == HEXA_CHARS_LOWER[j])) {
/* 226 */         result = (byte)(result + (j << 4));
/* 227 */         break;
/*     */       }
/*     */     }
/* 230 */     for (int j = 0; j < HEXA_CHARS_UPPER.length; j++) {
/* 231 */       if ((c2 == HEXA_CHARS_UPPER[j]) || (c2 == HEXA_CHARS_LOWER[j])) {
/* 232 */         result = (byte)(result + j);
/* 233 */         break;
/*     */       }
/*     */     }
/* 236 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static String escape(String text, UriEscapeType escapeType, String encoding)
/*     */   {
/* 253 */     if (text == null) {
/* 254 */       return null;
/*     */     }
/*     */     
/* 257 */     StringBuilder strBuilder = null;
/*     */     
/* 259 */     int offset = 0;
/* 260 */     int max = text.length();
/*     */     
/* 262 */     int readOffset = 0;
/*     */     
/* 264 */     for (int i = 0; i < max; i++)
/*     */     {
/* 266 */       int codepoint = Character.codePointAt(text, i);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 272 */       if (!UriEscapeType.isAlpha(codepoint))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 279 */         if (!escapeType.isAllowed(codepoint))
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 290 */           if (strBuilder == null) {
/* 291 */             strBuilder = new StringBuilder(max + 20);
/*     */           }
/*     */           
/* 294 */           if (i - readOffset > 0) {
/* 295 */             strBuilder.append(text, readOffset, i);
/*     */           }
/*     */           
/* 298 */           if (Character.charCount(codepoint) > 1)
/*     */           {
/* 300 */             i++;
/*     */           }
/*     */           
/* 303 */           readOffset = i + 1;
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           try
/*     */           {
/* 316 */             charAsBytes = new String(Character.toChars(codepoint)).getBytes(encoding);
/*     */           } catch (UnsupportedEncodingException e) { byte[] charAsBytes;
/* 318 */             throw new IllegalArgumentException("Exception while escaping URI: Bad encoding '" + encoding + "'", e); }
/*     */           byte[] charAsBytes;
/* 320 */           for (byte b : charAsBytes) {
/* 321 */             strBuilder.append('%');
/* 322 */             strBuilder.append(printHexa(b));
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 336 */     if (strBuilder == null) {
/* 337 */       return text;
/*     */     }
/*     */     
/* 340 */     if (max - readOffset > 0) {
/* 341 */       strBuilder.append(text, readOffset, max);
/*     */     }
/*     */     
/* 344 */     return strBuilder.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static void escape(Reader reader, Writer writer, UriEscapeType escapeType, String encoding)
/*     */     throws IOException
/*     */   {
/* 364 */     if (reader == null) {
/* 365 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 370 */     int c2 = reader.read();
/*     */     
/* 372 */     while (c2 >= 0)
/*     */     {
/* 374 */       int c1 = c2;
/* 375 */       c2 = reader.read();
/*     */       
/* 377 */       int codepoint = codePointAt((char)c1, (char)c2);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 383 */       if (UriEscapeType.isAlpha(codepoint)) {
/* 384 */         writer.write(c1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/* 391 */       else if (escapeType.isAllowed(codepoint)) {
/* 392 */         writer.write(c1);
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 402 */         if (Character.charCount(codepoint) > 1)
/*     */         {
/* 404 */           c1 = c2;
/* 405 */           c2 = reader.read();
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         try
/*     */         {
/* 419 */           charAsBytes = new String(Character.toChars(codepoint)).getBytes(encoding);
/*     */         } catch (UnsupportedEncodingException e) { byte[] charAsBytes;
/* 421 */           throw new IllegalArgumentException("Exception while escaping URI: Bad encoding '" + encoding + "'", e); }
/*     */         byte[] charAsBytes;
/* 423 */         for (byte b : charAsBytes) {
/* 424 */           writer.write(37);
/* 425 */           writer.write(printHexa(b));
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static void escape(char[] text, int offset, int len, Writer writer, UriEscapeType escapeType, String encoding)
/*     */     throws IOException
/*     */   {
/* 445 */     if ((text == null) || (text.length == 0)) {
/* 446 */       return;
/*     */     }
/*     */     
/* 449 */     int max = offset + len;
/*     */     
/* 451 */     int readOffset = offset;
/*     */     
/* 453 */     for (int i = offset; i < max; i++)
/*     */     {
/* 455 */       int codepoint = Character.codePointAt(text, i);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 461 */       if (!UriEscapeType.isAlpha(codepoint))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 468 */         if (!escapeType.isAllowed(codepoint))
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 479 */           if (i - readOffset > 0) {
/* 480 */             writer.write(text, readOffset, i - readOffset);
/*     */           }
/*     */           
/* 483 */           if (Character.charCount(codepoint) > 1)
/*     */           {
/* 485 */             i++;
/*     */           }
/*     */           
/* 488 */           readOffset = i + 1;
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           try
/*     */           {
/* 501 */             charAsBytes = new String(Character.toChars(codepoint)).getBytes(encoding);
/*     */           } catch (UnsupportedEncodingException e) { byte[] charAsBytes;
/* 503 */             throw new IllegalArgumentException("Exception while escaping URI: Bad encoding '" + encoding + "'", e); }
/*     */           byte[] charAsBytes;
/* 505 */           for (byte b : charAsBytes) {
/* 506 */             writer.write(37);
/* 507 */             writer.write(printHexa(b));
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 521 */     if (max - readOffset > 0) {
/* 522 */       writer.write(text, readOffset, max - readOffset);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static String unescape(String text, UriEscapeType escapeType, String encoding)
/*     */   {
/* 543 */     if (text == null) {
/* 544 */       return null;
/*     */     }
/*     */     
/* 547 */     StringBuilder strBuilder = null;
/*     */     
/* 549 */     int offset = 0;
/* 550 */     int max = text.length();
/*     */     
/* 552 */     int readOffset = 0;
/*     */     
/* 554 */     for (int i = 0; i < max; i++)
/*     */     {
/* 556 */       char c = text.charAt(i);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 562 */       if ((c == '%') || ((c == '+') && (escapeType.canPlusEscapeWhitespace())))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 573 */         if (strBuilder == null) {
/* 574 */           strBuilder = new StringBuilder(max + 5);
/*     */         }
/*     */         
/* 577 */         if (i - readOffset > 0) {
/* 578 */           strBuilder.append(text, readOffset, i);
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 585 */         if (c == '+')
/*     */         {
/* 587 */           strBuilder.append(' ');
/* 588 */           readOffset = i + 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 603 */           byte[] bytes = new byte[(max - i) / 3];
/* 604 */           char aheadC = c;
/* 605 */           int pos = 0;
/*     */           
/* 607 */           while ((i + 2 < max) && (aheadC == '%')) {
/* 608 */             bytes[(pos++)] = parseHexa(text.charAt(i + 1), text.charAt(i + 2));
/* 609 */             i += 3;
/* 610 */             if (i < max) {
/* 611 */               aheadC = text.charAt(i);
/*     */             }
/*     */           }
/*     */           
/* 615 */           if ((i < max) && (aheadC == '%'))
/*     */           {
/* 617 */             throw new IllegalArgumentException("Incomplete escaping sequence in input");
/*     */           }
/*     */           try
/*     */           {
/* 621 */             strBuilder.append(new String(bytes, 0, pos, encoding));
/*     */           } catch (UnsupportedEncodingException e) {
/* 623 */             throw new IllegalArgumentException("Exception while escaping URI: Bad encoding '" + encoding + "'", e);
/*     */           }
/*     */           
/*     */ 
/* 627 */           readOffset = i;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 639 */     if (strBuilder == null) {
/* 640 */       return text;
/*     */     }
/*     */     
/* 643 */     if (max - readOffset > 0) {
/* 644 */       strBuilder.append(text, readOffset, max);
/*     */     }
/*     */     
/* 647 */     return strBuilder.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static void unescape(Reader reader, Writer writer, UriEscapeType escapeType, String encoding)
/*     */     throws IOException
/*     */   {
/* 664 */     if (reader == null) {
/* 665 */       return;
/*     */     }
/*     */     
/* 668 */     byte[] escapes = new byte[4];
/*     */     
/*     */ 
/* 671 */     int c2 = reader.read();
/*     */     
/* 673 */     while (c2 >= 0)
/*     */     {
/* 675 */       int c1 = c2;
/* 676 */       c2 = reader.read();
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 682 */       if (((c1 != 37) || (c2 < 0)) && ((c1 != 43) || (!escapeType.canPlusEscapeWhitespace()))) {
/* 683 */         writer.write(c1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/* 691 */       else if (c1 == 43)
/*     */       {
/* 693 */         writer.write(32);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 706 */         int pos = 0;
/*     */         
/* 708 */         int ce0 = c1;
/* 709 */         int ce1 = c2;
/* 710 */         int ce2 = reader.read();
/*     */         
/* 712 */         while ((ce0 == 37) && (ce1 >= 0) && (ce2 >= 0))
/*     */         {
/* 714 */           if (pos == escapes.length)
/*     */           {
/* 716 */             byte[] newEscapes = new byte[escapes.length + 4];
/* 717 */             System.arraycopy(escapes, 0, newEscapes, 0, escapes.length);
/* 718 */             escapes = newEscapes;
/*     */           }
/*     */           
/* 721 */           escapes[(pos++)] = parseHexa((char)ce1, (char)ce2);
/*     */           
/* 723 */           ce0 = reader.read();
/* 724 */           ce1 = ce0 != 37 ? 0 : ce0 < 0 ? ce0 : reader.read();
/* 725 */           ce2 = ce0 != 37 ? 0 : ce1 < 0 ? ce1 : reader.read();
/*     */         }
/*     */         
/*     */ 
/* 729 */         if (ce0 == 37)
/*     */         {
/* 731 */           throw new IllegalArgumentException("Incomplete escaping sequence in input");
/*     */         }
/*     */         
/* 734 */         c2 = ce0;
/*     */         try
/*     */         {
/* 737 */           writer.write(new String(escapes, 0, pos, encoding));
/*     */         } catch (UnsupportedEncodingException e) {
/* 739 */           throw new IllegalArgumentException("Exception while escaping URI: Bad encoding '" + encoding + "'", e);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static void unescape(char[] text, int offset, int len, Writer writer, UriEscapeType escapeType, String encoding)
/*     */     throws IOException
/*     */   {
/* 758 */     if (text == null) {
/* 759 */       return;
/*     */     }
/*     */     
/* 762 */     int max = offset + len;
/*     */     
/* 764 */     int readOffset = offset;
/*     */     
/* 766 */     for (int i = offset; i < max; i++)
/*     */     {
/* 768 */       char c = text[i];
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 774 */       if ((c == '%') || ((c == '+') && (escapeType.canPlusEscapeWhitespace())))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 784 */         if (i - readOffset > 0) {
/* 785 */           writer.write(text, readOffset, i - readOffset);
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 792 */         if (c == '+')
/*     */         {
/* 794 */           writer.write(32);
/* 795 */           readOffset = i + 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 809 */           byte[] bytes = new byte[(max - i) / 3];
/* 810 */           char aheadC = c;
/* 811 */           int pos = 0;
/*     */           
/* 813 */           while ((i + 2 < max) && (aheadC == '%')) {
/* 814 */             bytes[(pos++)] = parseHexa(text[(i + 1)], text[(i + 2)]);
/* 815 */             i += 3;
/* 816 */             if (i < max) {
/* 817 */               aheadC = text[i];
/*     */             }
/*     */           }
/*     */           
/* 821 */           if ((i < max) && (aheadC == '%'))
/*     */           {
/* 823 */             throw new IllegalArgumentException("Incomplete escaping sequence in input");
/*     */           }
/*     */           try
/*     */           {
/* 827 */             writer.write(new String(bytes, 0, pos, encoding));
/*     */           } catch (UnsupportedEncodingException e) {
/* 829 */             throw new IllegalArgumentException("Exception while escaping URI: Bad encoding '" + encoding + "'", e);
/*     */           }
/*     */           
/*     */ 
/* 833 */           readOffset = i;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 845 */     if (max - readOffset > 0) {
/* 846 */       writer.write(text, readOffset, max - readOffset);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static int codePointAt(char c1, char c2)
/*     */   {
/* 855 */     if ((Character.isHighSurrogate(c1)) && 
/* 856 */       (c2 >= 0) && 
/* 857 */       (Character.isLowSurrogate(c2))) {
/* 858 */       return Character.toCodePoint(c1, c2);
/*     */     }
/*     */     
/*     */ 
/* 862 */     return c1;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\unbescape-1.1.6.RELEASE.jar!\org\unbescape\uri\UriEscapeUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */