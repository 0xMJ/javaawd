/*      */ package org.unbescape.javascript;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.Reader;
/*      */ import java.io.Writer;
/*      */ import java.util.Arrays;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ final class JavaScriptEscapeUtil
/*      */ {
/*      */   private static final char ESCAPE_PREFIX = '\\';
/*      */   private static final char ESCAPE_XHEXA_PREFIX2 = 'x';
/*      */   private static final char ESCAPE_UHEXA_PREFIX2 = 'u';
/*   84 */   private static final char[] ESCAPE_XHEXA_PREFIX = "\\x".toCharArray();
/*   85 */   private static final char[] ESCAPE_UHEXA_PREFIX = "\\u".toCharArray();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*   90 */   private static char[] HEXA_CHARS_UPPER = "0123456789ABCDEF".toCharArray();
/*   91 */   private static char[] HEXA_CHARS_LOWER = "0123456789abcdef".toCharArray();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   97 */   private static int SEC_CHARS_LEN = 93;
/*   98 */   private static char SEC_CHARS_NO_SEC = '*';
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  116 */   private static char[] SEC_CHARS = new char[SEC_CHARS_LEN];
/*  117 */   static { Arrays.fill(SEC_CHARS, SEC_CHARS_NO_SEC);
/*  118 */     SEC_CHARS[0] = '0';
/*  119 */     SEC_CHARS[8] = 'b';
/*  120 */     SEC_CHARS[9] = 't';
/*  121 */     SEC_CHARS[10] = 'n';
/*  122 */     SEC_CHARS[12] = 'f';
/*  123 */     SEC_CHARS[13] = 'r';
/*  124 */     SEC_CHARS[34] = '"';
/*  125 */     SEC_CHARS[39] = '\'';
/*  126 */     SEC_CHARS[92] = '\\';
/*      */     
/*  128 */     SEC_CHARS[47] = '/';
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  142 */     ESCAPE_LEVELS = new byte['¡'];
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  147 */     Arrays.fill(ESCAPE_LEVELS, (byte)3);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  152 */     for (char c = ''; c < '¡'; c = (char)(c + '\001')) {
/*  153 */       ESCAPE_LEVELS[c] = 2;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  159 */     for (char c = 'A'; c <= 'Z'; c = (char)(c + '\001')) {
/*  160 */       ESCAPE_LEVELS[c] = 4;
/*      */     }
/*  162 */     for (char c = 'a'; c <= 'z'; c = (char)(c + '\001')) {
/*  163 */       ESCAPE_LEVELS[c] = 4;
/*      */     }
/*  165 */     for (char c = '0'; c <= '9'; c = (char)(c + '\001')) {
/*  166 */       ESCAPE_LEVELS[c] = 4;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  172 */     ESCAPE_LEVELS[0] = 1;
/*  173 */     ESCAPE_LEVELS[8] = 1;
/*  174 */     ESCAPE_LEVELS[9] = 1;
/*  175 */     ESCAPE_LEVELS[10] = 1;
/*  176 */     ESCAPE_LEVELS[12] = 1;
/*  177 */     ESCAPE_LEVELS[13] = 1;
/*  178 */     ESCAPE_LEVELS[34] = 1;
/*  179 */     ESCAPE_LEVELS[39] = 1;
/*  180 */     ESCAPE_LEVELS[92] = 1;
/*      */     
/*  182 */     ESCAPE_LEVELS[47] = 1;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  187 */     ESCAPE_LEVELS[38] = 1;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  193 */     for (char c = '\001'; c <= '\037'; c = (char)(c + '\001')) {
/*  194 */       ESCAPE_LEVELS[c] = 1;
/*      */     }
/*  196 */     for (char c = ''; c <= ''; c = (char)(c + '\001')) {
/*  197 */       ESCAPE_LEVELS[c] = 1;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static char[] toXHexa(int codepoint)
/*      */   {
/*  212 */     char[] result = new char[2];
/*  213 */     result[1] = HEXA_CHARS_UPPER[(codepoint % 16)];
/*  214 */     result[0] = HEXA_CHARS_UPPER[((codepoint >>> 4) % 16)];
/*  215 */     return result;
/*      */   }
/*      */   
/*      */   static char[] toUHexa(int codepoint)
/*      */   {
/*  220 */     char[] result = new char[4];
/*  221 */     result[3] = HEXA_CHARS_UPPER[(codepoint % 16)];
/*  222 */     result[2] = HEXA_CHARS_UPPER[((codepoint >>> 4) % 16)];
/*  223 */     result[1] = HEXA_CHARS_UPPER[((codepoint >>> 8) % 16)];
/*  224 */     result[0] = HEXA_CHARS_UPPER[((codepoint >>> 12) % 16)];
/*  225 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static String escape(String text, JavaScriptEscapeType escapeType, JavaScriptEscapeLevel escapeLevel)
/*      */   {
/*  236 */     if (text == null) {
/*  237 */       return null;
/*      */     }
/*      */     
/*  240 */     int level = escapeLevel.getEscapeLevel();
/*  241 */     boolean useSECs = escapeType.getUseSECs();
/*  242 */     boolean useXHexa = escapeType.getUseXHexa();
/*      */     
/*  244 */     StringBuilder strBuilder = null;
/*      */     
/*  246 */     int offset = 0;
/*  247 */     int max = text.length();
/*      */     
/*  249 */     int readOffset = 0;
/*      */     
/*  251 */     for (int i = 0; i < max; i++)
/*      */     {
/*  253 */       int codepoint = Character.codePointAt(text, i);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  260 */       if ((codepoint > 159) || (level >= ESCAPE_LEVELS[codepoint]))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  268 */         if ((codepoint != 47) || (level >= 3) || ((i != 0) && (text.charAt(i - 1) == '<')))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  277 */           if ((codepoint > 159) && (level < ESCAPE_LEVELS[' ']) && (codepoint != 8232) && (codepoint != 8233))
/*      */           {
/*      */ 
/*  280 */             if (Character.charCount(codepoint) > 1)
/*      */             {
/*  282 */               i++;
/*      */ 
/*      */ 
/*      */             }
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */           }
/*      */           else
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*  296 */             if (strBuilder == null) {
/*  297 */               strBuilder = new StringBuilder(max + 20);
/*      */             }
/*      */             
/*  300 */             if (i - readOffset > 0) {
/*  301 */               strBuilder.append(text, readOffset, i);
/*      */             }
/*      */             
/*  304 */             if (Character.charCount(codepoint) > 1)
/*      */             {
/*  306 */               i++;
/*      */             }
/*      */             
/*  309 */             readOffset = i + 1;
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  320 */             if ((useSECs) && (codepoint < SEC_CHARS_LEN))
/*      */             {
/*      */ 
/*  323 */               char sec = SEC_CHARS[codepoint];
/*      */               
/*  325 */               if (sec != SEC_CHARS_NO_SEC)
/*      */               {
/*  327 */                 strBuilder.append('\\');
/*  328 */                 strBuilder.append(sec);
/*  329 */                 continue;
/*      */               }
/*      */             }
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  338 */             if ((useXHexa) && (codepoint <= 255))
/*      */             {
/*  340 */               strBuilder.append(ESCAPE_XHEXA_PREFIX);
/*  341 */               strBuilder.append(toXHexa(codepoint));
/*      */ 
/*      */ 
/*      */             }
/*  345 */             else if (Character.charCount(codepoint) > 1) {
/*  346 */               char[] codepointChars = Character.toChars(codepoint);
/*  347 */               strBuilder.append(ESCAPE_UHEXA_PREFIX);
/*  348 */               strBuilder.append(toUHexa(codepointChars[0]));
/*  349 */               strBuilder.append(ESCAPE_UHEXA_PREFIX);
/*  350 */               strBuilder.append(toUHexa(codepointChars[1]));
/*      */             }
/*      */             else
/*      */             {
/*  354 */               strBuilder.append(ESCAPE_UHEXA_PREFIX);
/*  355 */               strBuilder.append(toUHexa(codepoint));
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  367 */     if (strBuilder == null) {
/*  368 */       return text;
/*      */     }
/*      */     
/*  371 */     if (max - readOffset > 0) {
/*  372 */       strBuilder.append(text, readOffset, max);
/*      */     }
/*      */     
/*  375 */     return strBuilder.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final char ESCAPE_LEVELS_LEN = '¡';
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static void escape(Reader reader, Writer writer, JavaScriptEscapeType escapeType, JavaScriptEscapeLevel escapeLevel)
/*      */     throws IOException
/*      */   {
/*  393 */     if (reader == null) {
/*  394 */       return;
/*      */     }
/*      */     
/*  397 */     int level = escapeLevel.getEscapeLevel();
/*  398 */     boolean useSECs = escapeType.getUseSECs();
/*  399 */     boolean useXHexa = escapeType.getUseXHexa();
/*      */     
/*      */ 
/*      */ 
/*  403 */     int c1 = -1;
/*  404 */     int c2 = reader.read();
/*      */     
/*  406 */     while (c2 >= 0)
/*      */     {
/*  408 */       int c0 = c1;
/*  409 */       c1 = c2;
/*  410 */       c2 = reader.read();
/*      */       
/*  412 */       int codepoint = codePointAt((char)c1, (char)c2);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  419 */       if ((codepoint <= 159) && (level < ESCAPE_LEVELS[codepoint])) {
/*  420 */         writer.write(c1);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/*  428 */       else if ((codepoint == 47) && (level < 3) && (c0 != 60)) {
/*  429 */         writer.write(c1);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/*  438 */       else if ((codepoint > 159) && (level < ESCAPE_LEVELS[' ']) && (codepoint != 8232) && (codepoint != 8233))
/*      */       {
/*      */ 
/*  441 */         writer.write(c1);
/*      */         
/*  443 */         if (Character.charCount(codepoint) > 1)
/*      */         {
/*      */ 
/*  446 */           writer.write(c2);
/*      */           
/*  448 */           c0 = c1;
/*  449 */           c1 = c2;
/*  450 */           c2 = reader.read();
/*      */ 
/*      */ 
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*  464 */         if (Character.charCount(codepoint) > 1)
/*      */         {
/*  466 */           c0 = c1;
/*  467 */           c1 = c2;
/*  468 */           c2 = reader.read();
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  480 */         if ((useSECs) && (codepoint < SEC_CHARS_LEN))
/*      */         {
/*      */ 
/*  483 */           char sec = SEC_CHARS[codepoint];
/*      */           
/*  485 */           if (sec != SEC_CHARS_NO_SEC)
/*      */           {
/*  487 */             writer.write(92);
/*  488 */             writer.write(sec);
/*  489 */             continue;
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  498 */         if ((useXHexa) && (codepoint <= 255))
/*      */         {
/*  500 */           writer.write(ESCAPE_XHEXA_PREFIX);
/*  501 */           writer.write(toXHexa(codepoint));
/*      */ 
/*      */ 
/*      */         }
/*  505 */         else if (Character.charCount(codepoint) > 1) {
/*  506 */           char[] codepointChars = Character.toChars(codepoint);
/*  507 */           writer.write(ESCAPE_UHEXA_PREFIX);
/*  508 */           writer.write(toUHexa(codepointChars[0]));
/*  509 */           writer.write(ESCAPE_UHEXA_PREFIX);
/*  510 */           writer.write(toUHexa(codepointChars[1]));
/*      */         }
/*      */         else
/*      */         {
/*  514 */           writer.write(ESCAPE_UHEXA_PREFIX);
/*  515 */           writer.write(toUHexa(codepoint));
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static void escape(char[] text, int offset, int len, Writer writer, JavaScriptEscapeType escapeType, JavaScriptEscapeLevel escapeLevel)
/*      */     throws IOException
/*      */   {
/*  531 */     if ((text == null) || (text.length == 0)) {
/*  532 */       return;
/*      */     }
/*      */     
/*  535 */     int level = escapeLevel.getEscapeLevel();
/*  536 */     boolean useSECs = escapeType.getUseSECs();
/*  537 */     boolean useXHexa = escapeType.getUseXHexa();
/*      */     
/*  539 */     int max = offset + len;
/*      */     
/*  541 */     int readOffset = offset;
/*      */     
/*  543 */     for (int i = offset; i < max; i++)
/*      */     {
/*  545 */       int codepoint = Character.codePointAt(text, i);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  552 */       if ((codepoint > 159) || (level >= ESCAPE_LEVELS[codepoint]))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  560 */         if ((codepoint != 47) || (level >= 3) || ((i != 0) && (text[(i - 1)] == '<')))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  569 */           if ((codepoint > 159) && (level < ESCAPE_LEVELS[' ']) && (codepoint != 8232) && (codepoint != 8233))
/*      */           {
/*      */ 
/*  572 */             if (Character.charCount(codepoint) > 1)
/*      */             {
/*  574 */               i++;
/*      */ 
/*      */ 
/*      */             }
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */           }
/*      */           else
/*      */           {
/*      */ 
/*      */ 
/*  587 */             if (i - readOffset > 0) {
/*  588 */               writer.write(text, readOffset, i - readOffset);
/*      */             }
/*      */             
/*  591 */             if (Character.charCount(codepoint) > 1)
/*      */             {
/*  593 */               i++;
/*      */             }
/*      */             
/*  596 */             readOffset = i + 1;
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  607 */             if ((useSECs) && (codepoint < SEC_CHARS_LEN))
/*      */             {
/*      */ 
/*  610 */               char sec = SEC_CHARS[codepoint];
/*      */               
/*  612 */               if (sec != SEC_CHARS_NO_SEC)
/*      */               {
/*  614 */                 writer.write(92);
/*  615 */                 writer.write(sec);
/*  616 */                 continue;
/*      */               }
/*      */             }
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  625 */             if ((useXHexa) && (codepoint <= 255))
/*      */             {
/*  627 */               writer.write(ESCAPE_XHEXA_PREFIX);
/*  628 */               writer.write(toXHexa(codepoint));
/*      */ 
/*      */ 
/*      */             }
/*  632 */             else if (Character.charCount(codepoint) > 1) {
/*  633 */               char[] codepointChars = Character.toChars(codepoint);
/*  634 */               writer.write(ESCAPE_UHEXA_PREFIX);
/*  635 */               writer.write(toUHexa(codepointChars[0]));
/*  636 */               writer.write(ESCAPE_UHEXA_PREFIX);
/*  637 */               writer.write(toUHexa(codepointChars[1]));
/*      */             }
/*      */             else
/*      */             {
/*  641 */               writer.write(ESCAPE_UHEXA_PREFIX);
/*  642 */               writer.write(toUHexa(codepoint));
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  654 */     if (max - readOffset > 0) {
/*  655 */       writer.write(text, readOffset, max - readOffset);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final byte[] ESCAPE_LEVELS;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static int parseIntFromReference(String text, int start, int end, int radix)
/*      */   {
/*  674 */     int result = 0;
/*  675 */     for (int i = start; i < end; i++) {
/*  676 */       char c = text.charAt(i);
/*  677 */       int n = -1;
/*  678 */       for (int j = 0; j < HEXA_CHARS_UPPER.length; j++) {
/*  679 */         if ((c == HEXA_CHARS_UPPER[j]) || (c == HEXA_CHARS_LOWER[j])) {
/*  680 */           n = j;
/*  681 */           break;
/*      */         }
/*      */       }
/*  684 */       result = radix * result + n;
/*      */     }
/*  686 */     return result;
/*      */   }
/*      */   
/*      */   static int parseIntFromReference(char[] text, int start, int end, int radix) {
/*  690 */     int result = 0;
/*  691 */     for (int i = start; i < end; i++) {
/*  692 */       char c = text[i];
/*  693 */       int n = -1;
/*  694 */       for (int j = 0; j < HEXA_CHARS_UPPER.length; j++) {
/*  695 */         if ((c == HEXA_CHARS_UPPER[j]) || (c == HEXA_CHARS_LOWER[j])) {
/*  696 */           n = j;
/*  697 */           break;
/*      */         }
/*      */       }
/*  700 */       result = radix * result + n;
/*      */     }
/*  702 */     return result;
/*      */   }
/*      */   
/*      */   static int parseIntFromReference(int[] text, int start, int end, int radix) {
/*  706 */     int result = 0;
/*  707 */     for (int i = start; i < end; i++) {
/*  708 */       char c = (char)text[i];
/*  709 */       int n = -1;
/*  710 */       for (int j = 0; j < HEXA_CHARS_UPPER.length; j++) {
/*  711 */         if ((c == HEXA_CHARS_UPPER[j]) || (c == HEXA_CHARS_LOWER[j])) {
/*  712 */           n = j;
/*  713 */           break;
/*      */         }
/*      */       }
/*  716 */       result = radix * result + n;
/*      */     }
/*  718 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static boolean isOctalEscape(String text, int start, int end)
/*      */   {
/*  727 */     if (start >= end) {
/*  728 */       return false;
/*      */     }
/*      */     
/*  731 */     char c1 = text.charAt(start);
/*  732 */     if ((c1 < '0') || (c1 > '7')) {
/*  733 */       return false;
/*      */     }
/*      */     
/*  736 */     if (start + 1 >= end) {
/*  737 */       return c1 != '0';
/*      */     }
/*      */     
/*  740 */     char c2 = text.charAt(start + 1);
/*  741 */     if ((c2 < '0') || (c2 > '7')) {
/*  742 */       return c1 != '0';
/*      */     }
/*      */     
/*  745 */     if (start + 2 >= end) {
/*  746 */       return (c1 != '0') || (c2 != '0');
/*      */     }
/*      */     
/*  749 */     char c3 = text.charAt(start + 2);
/*  750 */     if ((c3 < '0') || (c3 > '7')) {
/*  751 */       return (c1 != '0') || (c2 != '0');
/*      */     }
/*      */     
/*  754 */     return (c1 != '0') || (c2 != '0') || (c3 != '0');
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   static boolean isOctalEscape(char[] text, int start, int end)
/*      */   {
/*  761 */     if (start >= end) {
/*  762 */       return false;
/*      */     }
/*      */     
/*  765 */     char c1 = text[start];
/*  766 */     if ((c1 < '0') || (c1 > '7')) {
/*  767 */       return false;
/*      */     }
/*      */     
/*  770 */     if (start + 1 >= end) {
/*  771 */       return c1 != '0';
/*      */     }
/*      */     
/*  774 */     char c2 = text[(start + 1)];
/*  775 */     if ((c2 < '0') || (c2 > '7')) {
/*  776 */       return c1 != '0';
/*      */     }
/*      */     
/*  779 */     if (start + 2 >= end) {
/*  780 */       return (c1 != '0') || (c2 != '0');
/*      */     }
/*      */     
/*  783 */     char c3 = text[(start + 2)];
/*  784 */     if ((c3 < '0') || (c3 > '7')) {
/*  785 */       return (c1 != '0') || (c2 != '0');
/*      */     }
/*      */     
/*  788 */     return (c1 != '0') || (c2 != '0') || (c3 != '0');
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static String unescape(String text)
/*      */   {
/*  800 */     if (text == null) {
/*  801 */       return null;
/*      */     }
/*      */     
/*  804 */     StringBuilder strBuilder = null;
/*      */     
/*  806 */     int offset = 0;
/*  807 */     int max = text.length();
/*      */     
/*  809 */     int readOffset = 0;
/*  810 */     int referenceOffset = 0;
/*      */     
/*  812 */     for (int i = 0; i < max; i++)
/*      */     {
/*  814 */       char c = text.charAt(i);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  820 */       if ((c == '\\') && (i + 1 < max))
/*      */       {
/*      */ 
/*      */ 
/*  824 */         int codepoint = -1;
/*      */         
/*  826 */         if (c == '\\')
/*      */         {
/*  828 */           char c1 = text.charAt(i + 1);
/*      */           
/*  830 */           switch (c1) {
/*  831 */           case '0':  if (!isOctalEscape(text, i + 1, max)) { codepoint = 0;referenceOffset = i + 1; }
/*      */             break; case 'b':  codepoint = 8;referenceOffset = i + 1; break;
/*  833 */           case 't':  codepoint = 9;referenceOffset = i + 1; break;
/*  834 */           case 'n':  codepoint = 10;referenceOffset = i + 1; break;
/*  835 */           case 'v':  codepoint = 11;referenceOffset = i + 1; break;
/*  836 */           case 'f':  codepoint = 12;referenceOffset = i + 1; break;
/*  837 */           case 'r':  codepoint = 13;referenceOffset = i + 1; break;
/*  838 */           case '"':  codepoint = 34;referenceOffset = i + 1; break;
/*  839 */           case '\'':  codepoint = 39;referenceOffset = i + 1; break;
/*  840 */           case '\\':  codepoint = 92;referenceOffset = i + 1; break;
/*  841 */           case '/':  codepoint = 47;referenceOffset = i + 1; break;
/*      */           case '\n': 
/*  843 */             codepoint = -2;referenceOffset = i + 1;
/*      */           }
/*      */           
/*  846 */           if (codepoint == -1)
/*      */           {
/*  848 */             if (c1 == 'x')
/*      */             {
/*      */ 
/*  851 */               int f = i + 2;
/*  852 */               while ((f < i + 4) && (f < max)) {
/*  853 */                 char cf = text.charAt(f);
/*  854 */                 if (((cf < '0') || (cf > '9')) && ((cf < 'A') || (cf > 'F')) && ((cf < 'a') || (cf > 'f'))) {
/*      */                   break;
/*      */                 }
/*  857 */                 f++;
/*      */               }
/*      */               
/*  860 */               if (f - (i + 2) < 2)
/*      */               {
/*      */ 
/*  863 */                 i++;
/*  864 */                 continue;
/*      */               }
/*      */               
/*  867 */               codepoint = parseIntFromReference(text, i + 2, f, 16);
/*      */               
/*      */ 
/*  870 */               referenceOffset = f - 1;
/*      */ 
/*      */ 
/*      */             }
/*  874 */             else if (c1 == 'u')
/*      */             {
/*      */ 
/*  877 */               int f = i + 2;
/*  878 */               while ((f < i + 6) && (f < max)) {
/*  879 */                 char cf = text.charAt(f);
/*  880 */                 if (((cf < '0') || (cf > '9')) && ((cf < 'A') || (cf > 'F')) && ((cf < 'a') || (cf > 'f'))) {
/*      */                   break;
/*      */                 }
/*  883 */                 f++;
/*      */               }
/*      */               
/*  886 */               if (f - (i + 2) < 4)
/*      */               {
/*      */ 
/*  889 */                 i++;
/*  890 */                 continue;
/*      */               }
/*      */               
/*  893 */               codepoint = parseIntFromReference(text, i + 2, f, 16);
/*      */               
/*      */ 
/*  896 */               referenceOffset = f - 1;
/*      */ 
/*      */ 
/*      */             }
/*  900 */             else if ((c1 >= '0') && (c1 <= '7'))
/*      */             {
/*      */ 
/*  903 */               int f = i + 2;
/*  904 */               while ((f < i + 4) && (f < max)) {
/*  905 */                 char cf = text.charAt(f);
/*  906 */                 if ((cf < '0') || (cf > '7')) {
/*      */                   break;
/*      */                 }
/*  909 */                 f++;
/*      */               }
/*      */               
/*  912 */               codepoint = parseIntFromReference(text, i + 1, f, 8);
/*      */               
/*  914 */               if (codepoint > 255)
/*      */               {
/*  916 */                 codepoint = parseIntFromReference(text, i + 1, f - 1, 8);
/*  917 */                 referenceOffset = f - 2;
/*      */               } else {
/*  919 */                 referenceOffset = f - 1;
/*      */               }
/*      */             }
/*      */             else
/*      */             {
/*  924 */               if ((c1 == '8') || (c1 == '9') || (c1 == '\r') || (c1 == ' ') || (c1 == ' '))
/*      */               {
/*      */ 
/*      */ 
/*      */ 
/*  929 */                 i++;
/*  930 */                 continue;
/*      */               }
/*      */               
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  937 */               codepoint = c1;
/*  938 */               referenceOffset = i + 1;
/*      */             }
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  953 */         if (strBuilder == null) {
/*  954 */           strBuilder = new StringBuilder(max + 5);
/*      */         }
/*      */         
/*  957 */         if (i - readOffset > 0) {
/*  958 */           strBuilder.append(text, readOffset, i);
/*      */         }
/*      */         
/*  961 */         i = referenceOffset;
/*  962 */         readOffset = i + 1;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  972 */         if (codepoint > 65535) {
/*  973 */           strBuilder.append(Character.toChars(codepoint));
/*  974 */         } else if (codepoint != -2) {
/*  975 */           strBuilder.append((char)codepoint);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  988 */     if (strBuilder == null) {
/*  989 */       return text;
/*      */     }
/*      */     
/*  992 */     if (max - readOffset > 0) {
/*  993 */       strBuilder.append(text, readOffset, max);
/*      */     }
/*      */     
/*  996 */     return strBuilder.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static void unescape(Reader reader, Writer writer)
/*      */     throws IOException
/*      */   {
/* 1013 */     if (reader == null) {
/* 1014 */       return;
/*      */     }
/*      */     
/* 1017 */     int escapei = 0;
/* 1018 */     char[] escapes = new char[4];
/*      */     
/*      */ 
/* 1021 */     int c2 = reader.read();
/*      */     
/* 1023 */     while (c2 >= 0)
/*      */     {
/* 1025 */       int c1 = c2;
/* 1026 */       c2 = reader.read();
/*      */       
/* 1028 */       escapei = 0;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1034 */       if ((c1 != 92) || (c2 < 0)) {
/* 1035 */         writer.write(c1);
/*      */       }
/*      */       else
/*      */       {
/* 1039 */         int codepoint = -1;
/*      */         
/* 1041 */         if (c1 == 92)
/*      */         {
/* 1043 */           switch (c2) {
/* 1044 */           case 98:  codepoint = 8;c1 = c2;c2 = reader.read(); break;
/* 1045 */           case 116:  codepoint = 9;c1 = c2;c2 = reader.read(); break;
/* 1046 */           case 110:  codepoint = 10;c1 = c2;c2 = reader.read(); break;
/* 1047 */           case 118:  codepoint = 11;c1 = c2;c2 = reader.read(); break;
/* 1048 */           case 102:  codepoint = 12;c1 = c2;c2 = reader.read(); break;
/* 1049 */           case 114:  codepoint = 13;c1 = c2;c2 = reader.read(); break;
/* 1050 */           case 34:  codepoint = 34;c1 = c2;c2 = reader.read(); break;
/* 1051 */           case 39:  codepoint = 39;c1 = c2;c2 = reader.read(); break;
/* 1052 */           case 92:  codepoint = 92;c1 = c2;c2 = reader.read(); break;
/* 1053 */           case 47:  codepoint = 47;c1 = c2;c2 = reader.read(); break;
/*      */           case 10: 
/* 1055 */             codepoint = -2;c1 = c2;c2 = reader.read();
/*      */           }
/*      */           
/* 1058 */           if (codepoint == -1)
/*      */           {
/* 1060 */             if (c2 == 120)
/*      */             {
/*      */ 
/* 1063 */               escapei = 0;
/* 1064 */               int ce = reader.read();
/* 1065 */               while ((ce >= 0) && (escapei < 2) && (
/* 1066 */                 ((ce >= 48) && (ce <= 57)) || ((ce >= 65) && (ce <= 70)) || ((ce >= 97) && (ce <= 102))))
/*      */               {
/*      */ 
/* 1069 */                 escapes[escapei] = ((char)ce);
/* 1070 */                 ce = reader.read();
/* 1071 */                 escapei++;
/*      */               }
/*      */               
/* 1074 */               if (escapei < 2)
/*      */               {
/*      */ 
/* 1077 */                 writer.write(c1);
/* 1078 */                 writer.write(c2);
/* 1079 */                 for (int i = 0; i < escapei; i++) {
/* 1080 */                   c1 = c2;
/* 1081 */                   c2 = escapes[i];
/* 1082 */                   writer.write(c2);
/*      */                 }
/* 1084 */                 c1 = c2;
/* 1085 */                 c2 = ce;
/* 1086 */                 continue;
/*      */               }
/*      */               
/* 1089 */               c1 = escapes[3];
/* 1090 */               c2 = ce;
/*      */               
/* 1092 */               codepoint = parseIntFromReference(escapes, 0, 2, 16);
/*      */               
/* 1094 */               escapei = 0;
/*      */ 
/*      */ 
/*      */             }
/* 1098 */             else if (c2 == 117)
/*      */             {
/*      */ 
/* 1101 */               escapei = 0;
/* 1102 */               int ce = reader.read();
/* 1103 */               while ((ce >= 0) && (escapei < 4) && (
/* 1104 */                 ((ce >= 48) && (ce <= 57)) || ((ce >= 65) && (ce <= 70)) || ((ce >= 97) && (ce <= 102))))
/*      */               {
/*      */ 
/* 1107 */                 escapes[escapei] = ((char)ce);
/* 1108 */                 ce = reader.read();
/* 1109 */                 escapei++;
/*      */               }
/*      */               
/* 1112 */               if (escapei < 4)
/*      */               {
/*      */ 
/* 1115 */                 writer.write(c1);
/* 1116 */                 writer.write(c2);
/* 1117 */                 for (int i = 0; i < escapei; i++) {
/* 1118 */                   c1 = c2;
/* 1119 */                   c2 = escapes[i];
/* 1120 */                   writer.write(c2);
/*      */                 }
/* 1122 */                 c1 = c2;
/* 1123 */                 c2 = ce;
/* 1124 */                 continue;
/*      */               }
/*      */               
/* 1127 */               c1 = escapes[3];
/* 1128 */               c2 = ce;
/*      */               
/* 1130 */               codepoint = parseIntFromReference(escapes, 0, 4, 16);
/*      */               
/* 1132 */               escapei = 0;
/*      */ 
/*      */ 
/*      */             }
/* 1136 */             else if ((c2 >= 48) && (c2 <= 55))
/*      */             {
/*      */ 
/*      */ 
/*      */ 
/* 1141 */               escapei = 0;
/* 1142 */               int ce = c2;
/* 1143 */               while ((ce >= 0) && (escapei < 3) && 
/* 1144 */                 (ce >= 48) && (ce <= 55))
/*      */               {
/*      */ 
/* 1147 */                 escapes[escapei] = ((char)ce);
/* 1148 */                 ce = reader.read();
/* 1149 */                 escapei++;
/*      */               }
/*      */               
/* 1152 */               c1 = escapes[(escapei - 1)];
/* 1153 */               c2 = ce;
/*      */               
/* 1155 */               codepoint = parseIntFromReference(escapes, 0, escapei, 8);
/*      */               
/* 1157 */               if (codepoint > 255)
/*      */               {
/* 1159 */                 codepoint = parseIntFromReference(escapes, 0, escapei - 1, 8);
/* 1160 */                 System.arraycopy(escapes, escapei - 2, escapes, 0, 1);
/* 1161 */                 escapei = 1;
/* 1162 */               } else if ((codepoint == 0) && (escapei > 1))
/*      */               {
/*      */ 
/* 1165 */                 System.arraycopy(escapes, 1, escapes, 0, escapei - 1);
/* 1166 */                 escapei--;
/*      */               } else {
/* 1168 */                 escapei = 0;
/*      */               }
/*      */             }
/*      */             else
/*      */             {
/* 1173 */               if ((c2 == 56) || (c2 == 57) || (c2 == 13) || (c2 == 8232) || (c2 == 8233))
/*      */               {
/*      */ 
/*      */ 
/*      */ 
/* 1178 */                 writer.write(c1);
/* 1179 */                 writer.write(c2);
/*      */                 
/* 1181 */                 c1 = c2;
/* 1182 */                 c2 = reader.read();
/*      */                 
/* 1184 */                 continue;
/*      */               }
/*      */               
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1191 */               codepoint = c2;
/*      */               
/* 1193 */               c1 = c2;
/* 1194 */               c2 = reader.read();
/*      */               
/* 1196 */               escapei = 0;
/*      */             }
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1212 */         if (codepoint > 65535) {
/* 1213 */           writer.write(Character.toChars(codepoint));
/* 1214 */         } else if (codepoint != -2) {
/* 1215 */           writer.write((char)codepoint);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1224 */         if (escapei > 0) {
/* 1225 */           writer.write(escapes, 0, escapei);
/* 1226 */           escapei = 0;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static void unescape(char[] text, int offset, int len, Writer writer)
/*      */     throws IOException
/*      */   {
/* 1244 */     if (text == null) {
/* 1245 */       return;
/*      */     }
/*      */     
/* 1248 */     int max = offset + len;
/*      */     
/* 1250 */     int readOffset = offset;
/* 1251 */     int referenceOffset = offset;
/*      */     
/* 1253 */     for (int i = offset; i < max; i++)
/*      */     {
/* 1255 */       char c = text[i];
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1261 */       if ((c == '\\') && (i + 1 < max))
/*      */       {
/*      */ 
/*      */ 
/* 1265 */         int codepoint = -1;
/*      */         
/* 1267 */         if (c == '\\')
/*      */         {
/* 1269 */           char c1 = text[(i + 1)];
/*      */           
/* 1271 */           switch (c1) {
/* 1272 */           case '0':  if (!isOctalEscape(text, i + 1, max)) { codepoint = 0;referenceOffset = i + 1; }
/*      */             break; case 'b':  codepoint = 8;referenceOffset = i + 1; break;
/* 1274 */           case 't':  codepoint = 9;referenceOffset = i + 1; break;
/* 1275 */           case 'n':  codepoint = 10;referenceOffset = i + 1; break;
/* 1276 */           case 'v':  codepoint = 11;referenceOffset = i + 1; break;
/* 1277 */           case 'f':  codepoint = 12;referenceOffset = i + 1; break;
/* 1278 */           case 'r':  codepoint = 13;referenceOffset = i + 1; break;
/* 1279 */           case '"':  codepoint = 34;referenceOffset = i + 1; break;
/* 1280 */           case '\'':  codepoint = 39;referenceOffset = i + 1; break;
/* 1281 */           case '\\':  codepoint = 92;referenceOffset = i + 1; break;
/* 1282 */           case '/':  codepoint = 47;referenceOffset = i + 1; break;
/*      */           case '\n': 
/* 1284 */             codepoint = -2;referenceOffset = i + 1;
/*      */           }
/*      */           
/* 1287 */           if (codepoint == -1)
/*      */           {
/* 1289 */             if (c1 == 'x')
/*      */             {
/*      */ 
/* 1292 */               int f = i + 2;
/* 1293 */               while ((f < i + 4) && (f < max)) {
/* 1294 */                 char cf = text[f];
/* 1295 */                 if (((cf < '0') || (cf > '9')) && ((cf < 'A') || (cf > 'F')) && ((cf < 'a') || (cf > 'f'))) {
/*      */                   break;
/*      */                 }
/* 1298 */                 f++;
/*      */               }
/*      */               
/* 1301 */               if (f - (i + 2) < 2)
/*      */               {
/*      */ 
/* 1304 */                 i++;
/* 1305 */                 continue;
/*      */               }
/*      */               
/* 1308 */               codepoint = parseIntFromReference(text, i + 2, f, 16);
/*      */               
/*      */ 
/* 1311 */               referenceOffset = f - 1;
/*      */ 
/*      */ 
/*      */             }
/* 1315 */             else if (c1 == 'u')
/*      */             {
/*      */ 
/* 1318 */               int f = i + 2;
/* 1319 */               while ((f < i + 6) && (f < max)) {
/* 1320 */                 char cf = text[f];
/* 1321 */                 if (((cf < '0') || (cf > '9')) && ((cf < 'A') || (cf > 'F')) && ((cf < 'a') || (cf > 'f'))) {
/*      */                   break;
/*      */                 }
/* 1324 */                 f++;
/*      */               }
/*      */               
/* 1327 */               if (f - (i + 2) < 4)
/*      */               {
/*      */ 
/* 1330 */                 i++;
/* 1331 */                 continue;
/*      */               }
/*      */               
/* 1334 */               codepoint = parseIntFromReference(text, i + 2, f, 16);
/*      */               
/*      */ 
/* 1337 */               referenceOffset = f - 1;
/*      */ 
/*      */ 
/*      */             }
/* 1341 */             else if ((c1 >= '0') && (c1 <= '7'))
/*      */             {
/*      */ 
/* 1344 */               int f = i + 2;
/* 1345 */               while ((f < i + 4) && (f < max)) {
/* 1346 */                 char cf = text[f];
/* 1347 */                 if ((cf < '0') || (cf > '7')) {
/*      */                   break;
/*      */                 }
/* 1350 */                 f++;
/*      */               }
/*      */               
/* 1353 */               codepoint = parseIntFromReference(text, i + 1, f, 8);
/* 1354 */               if (codepoint > 255)
/*      */               {
/* 1356 */                 codepoint = parseIntFromReference(text, i + 1, f - 1, 8);
/* 1357 */                 referenceOffset = f - 2;
/*      */               } else {
/* 1359 */                 referenceOffset = f - 1;
/*      */               }
/*      */             }
/*      */             else
/*      */             {
/* 1364 */               if ((c1 == '8') || (c1 == '9') || (c1 == '\r') || (c1 == ' ') || (c1 == ' '))
/*      */               {
/*      */ 
/*      */ 
/*      */ 
/* 1369 */                 i++;
/* 1370 */                 continue;
/*      */               }
/*      */               
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1377 */               codepoint = c1;
/* 1378 */               referenceOffset = i + 1;
/*      */             }
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1392 */         if (i - readOffset > 0) {
/* 1393 */           writer.write(text, readOffset, i - readOffset);
/*      */         }
/*      */         
/* 1396 */         i = referenceOffset;
/* 1397 */         readOffset = i + 1;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1407 */         if (codepoint > 65535) {
/* 1408 */           writer.write(Character.toChars(codepoint));
/* 1409 */         } else if (codepoint != -2) {
/* 1410 */           writer.write((char)codepoint);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1422 */     if (max - readOffset > 0) {
/* 1423 */       writer.write(text, readOffset, max - readOffset);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private static int codePointAt(char c1, char c2)
/*      */   {
/* 1432 */     if ((Character.isHighSurrogate(c1)) && 
/* 1433 */       (c2 >= 0) && 
/* 1434 */       (Character.isLowSurrogate(c2))) {
/* 1435 */       return Character.toCodePoint(c1, c2);
/*      */     }
/*      */     
/*      */ 
/* 1439 */     return c1;
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\unbescape-1.1.6.RELEASE.jar!\org\unbescape\javascript\JavaScriptEscapeUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */