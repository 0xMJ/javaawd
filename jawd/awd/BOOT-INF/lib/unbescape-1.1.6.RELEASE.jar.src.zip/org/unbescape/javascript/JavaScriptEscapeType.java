/*    */ package org.unbescape.javascript;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum JavaScriptEscapeType
/*    */ {
/* 62 */   SINGLE_ESCAPE_CHARS_DEFAULT_TO_XHEXA_AND_UHEXA(true, true), 
/*    */   
/*    */ 
/*    */ 
/*    */ 
/* 67 */   SINGLE_ESCAPE_CHARS_DEFAULT_TO_UHEXA(true, false), 
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 73 */   XHEXA_DEFAULT_TO_UHEXA(false, true), 
/*    */   
/*    */ 
/*    */ 
/*    */ 
/* 78 */   UHEXA(false, false);
/*    */   
/*    */   private final boolean useSECs;
/*    */   private final boolean useXHexa;
/*    */   
/*    */   private JavaScriptEscapeType(boolean useSECs, boolean useXHexa)
/*    */   {
/* 85 */     this.useSECs = useSECs;
/* 86 */     this.useXHexa = useXHexa;
/*    */   }
/*    */   
/*    */   boolean getUseSECs() {
/* 90 */     return this.useSECs;
/*    */   }
/*    */   
/*    */   boolean getUseXHexa() {
/* 94 */     return this.useXHexa;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\unbescape-1.1.6.RELEASE.jar!\org\unbescape\javascript\JavaScriptEscapeType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */