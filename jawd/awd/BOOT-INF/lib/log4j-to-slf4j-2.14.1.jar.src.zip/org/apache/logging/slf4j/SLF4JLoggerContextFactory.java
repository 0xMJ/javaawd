/*    */ package org.apache.logging.slf4j;
/*    */ 
/*    */ import java.net.URI;
/*    */ import org.apache.logging.log4j.spi.LoggerContext;
/*    */ import org.apache.logging.log4j.spi.LoggerContextFactory;
/*    */ import org.apache.logging.log4j.status.StatusLogger;
/*    */ import org.apache.logging.log4j.util.LoaderUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SLF4JLoggerContextFactory
/*    */   implements LoggerContextFactory
/*    */ {
/* 30 */   private static final StatusLogger LOGGER = ;
/* 31 */   private static LoggerContext context = new SLF4JLoggerContext();
/*    */   
/*    */   public SLF4JLoggerContextFactory()
/*    */   {
/* 35 */     boolean misconfigured = false;
/*    */     try {
/* 37 */       LoaderUtil.loadClass("org.slf4j.helpers.Log4jLoggerFactory");
/* 38 */       misconfigured = true;
/*    */     } catch (ClassNotFoundException classNotFoundIsGood) {
/* 40 */       LOGGER.debug("org.slf4j.helpers.Log4jLoggerFactory is not on classpath. Good!");
/*    */     }
/* 42 */     if (misconfigured) {
/* 43 */       throw new IllegalStateException("slf4j-impl jar is mutually exclusive with log4j-to-slf4j jar (the first routes calls from SLF4J to Log4j, the second from Log4j to SLF4J)");
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public LoggerContext getContext(String fqcn, ClassLoader loader, Object externalContext, boolean currentContext)
/*    */   {
/* 51 */     return context;
/*    */   }
/*    */   
/*    */ 
/*    */   public LoggerContext getContext(String fqcn, ClassLoader loader, Object externalContext, boolean currentContext, URI configLocation, String name)
/*    */   {
/* 57 */     return context;
/*    */   }
/*    */   
/*    */   public void removeContext(LoggerContext ignored) {}
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\log4j-to-slf4j-2.14.1.jar!\org\apache\logging\slf4j\SLF4JLoggerContextFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */