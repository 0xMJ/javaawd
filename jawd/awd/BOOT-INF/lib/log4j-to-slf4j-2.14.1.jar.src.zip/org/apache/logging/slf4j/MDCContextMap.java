/*     */ package org.apache.logging.slf4j;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import org.apache.logging.log4j.spi.CleanableThreadContextMap;
/*     */ import org.apache.logging.log4j.util.SortedArrayStringMap;
/*     */ import org.apache.logging.log4j.util.StringMap;
/*     */ import org.slf4j.MDC;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MDCContextMap
/*     */   implements CleanableThreadContextMap
/*     */ {
/*  32 */   private static final StringMap EMPTY_CONTEXT_DATA = new SortedArrayStringMap(1);
/*     */   
/*  34 */   static { EMPTY_CONTEXT_DATA.freeze(); }
/*     */   
/*     */ 
/*     */   public void put(String key, String value)
/*     */   {
/*  39 */     MDC.put(key, value);
/*     */   }
/*     */   
/*     */   public void putAll(Map<String, String> m)
/*     */   {
/*  44 */     for (Map.Entry<String, String> entry : m.entrySet()) {
/*  45 */       MDC.put((String)entry.getKey(), (String)entry.getValue());
/*     */     }
/*     */   }
/*     */   
/*     */   public String get(String key)
/*     */   {
/*  51 */     return MDC.get(key);
/*     */   }
/*     */   
/*     */   public void remove(String key)
/*     */   {
/*  56 */     MDC.remove(key);
/*     */   }
/*     */   
/*     */ 
/*     */   public void removeAll(Iterable<String> keys)
/*     */   {
/*  62 */     for (String key : keys) {
/*  63 */       MDC.remove(key);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean containsKey(String key)
/*     */   {
/*  74 */     Map<String, String> map = MDC.getCopyOfContextMap();
/*  75 */     return (map != null) && (map.containsKey(key));
/*     */   }
/*     */   
/*     */ 
/*     */   public Map<String, String> getCopy()
/*     */   {
/*  81 */     return MDC.getCopyOfContextMap();
/*     */   }
/*     */   
/*     */ 
/*     */   public Map<String, String> getImmutableMapOrNull()
/*     */   {
/*  87 */     return MDC.getCopyOfContextMap();
/*     */   }
/*     */   
/*     */   public boolean isEmpty()
/*     */   {
/*  92 */     Map<String, String> map = MDC.getCopyOfContextMap();
/*  93 */     return (map == null) || (map.isEmpty());
/*     */   }
/*     */   
/*     */   public StringMap getReadOnlyContextData()
/*     */   {
/*  98 */     Map<String, String> copy = getCopy();
/*  99 */     if (copy.isEmpty()) {
/* 100 */       return EMPTY_CONTEXT_DATA;
/*     */     }
/* 102 */     StringMap result = new SortedArrayStringMap();
/* 103 */     for (Map.Entry<String, String> entry : copy.entrySet()) {
/* 104 */       result.putValue((String)entry.getKey(), entry.getValue());
/*     */     }
/* 106 */     return result;
/*     */   }
/*     */   
/*     */   public void clear() {}
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\log4j-to-slf4j-2.14.1.jar!\org\apache\logging\slf4j\MDCContextMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */