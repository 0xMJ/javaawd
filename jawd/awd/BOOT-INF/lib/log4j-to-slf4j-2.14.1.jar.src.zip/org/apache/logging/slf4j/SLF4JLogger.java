/*     */ package org.apache.logging.slf4j;
/*     */ 
/*     */ import org.apache.logging.log4j.Level;
/*     */ import org.apache.logging.log4j.message.LoggerNameAwareMessage;
/*     */ import org.apache.logging.log4j.message.Message;
/*     */ import org.apache.logging.log4j.message.MessageFactory;
/*     */ import org.apache.logging.log4j.spi.AbstractLogger;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.MarkerFactory;
/*     */ import org.slf4j.spi.LocationAwareLogger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SLF4JLogger
/*     */   extends AbstractLogger
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private final Logger logger;
/*     */   private final LocationAwareLogger locationAwareLogger;
/*     */   
/*     */   public SLF4JLogger(String name, MessageFactory messageFactory, Logger logger)
/*     */   {
/*  38 */     super(name, messageFactory);
/*  39 */     this.logger = logger;
/*  40 */     this.locationAwareLogger = ((logger instanceof LocationAwareLogger) ? (LocationAwareLogger)logger : null);
/*     */   }
/*     */   
/*     */   public SLF4JLogger(String name, Logger logger) {
/*  44 */     super(name);
/*  45 */     this.logger = logger;
/*  46 */     this.locationAwareLogger = ((logger instanceof LocationAwareLogger) ? (LocationAwareLogger)logger : null);
/*     */   }
/*     */   
/*     */   private int convertLevel(Level level) {
/*  50 */     switch (level.getStandardLevel()) {
/*     */     case DEBUG: 
/*  52 */       return 10;
/*     */     case TRACE: 
/*  54 */       return 0;
/*     */     case INFO: 
/*  56 */       return 20;
/*     */     case WARN: 
/*  58 */       return 30;
/*     */     case ERROR: 
/*  60 */       return 40;
/*     */     }
/*  62 */     return 40;
/*     */   }
/*     */   
/*     */ 
/*     */   public Level getLevel()
/*     */   {
/*  68 */     if (this.logger.isTraceEnabled()) {
/*  69 */       return Level.TRACE;
/*     */     }
/*  71 */     if (this.logger.isDebugEnabled()) {
/*  72 */       return Level.DEBUG;
/*     */     }
/*  74 */     if (this.logger.isInfoEnabled()) {
/*  75 */       return Level.INFO;
/*     */     }
/*  77 */     if (this.logger.isWarnEnabled()) {
/*  78 */       return Level.WARN;
/*     */     }
/*  80 */     if (this.logger.isErrorEnabled()) {
/*  81 */       return Level.ERROR;
/*     */     }
/*     */     
/*     */ 
/*  85 */     return Level.OFF;
/*     */   }
/*     */   
/*     */   public Logger getLogger() {
/*  89 */     return this.locationAwareLogger != null ? this.locationAwareLogger : this.logger;
/*     */   }
/*     */   
/*     */   private org.slf4j.Marker getMarker(org.apache.logging.log4j.Marker marker) {
/*  93 */     if (marker == null) {
/*  94 */       return null;
/*     */     }
/*  96 */     org.slf4j.Marker slf4jMarker = MarkerFactory.getMarker(marker.getName());
/*  97 */     org.apache.logging.log4j.Marker[] parents = marker.getParents();
/*  98 */     if (parents != null) {
/*  99 */       for (org.apache.logging.log4j.Marker parent : parents) {
/* 100 */         org.slf4j.Marker slf4jParent = getMarker(parent);
/* 101 */         if (!slf4jMarker.contains(slf4jParent)) {
/* 102 */           slf4jMarker.add(slf4jParent);
/*     */         }
/*     */       }
/*     */     }
/* 106 */     return slf4jMarker;
/*     */   }
/*     */   
/*     */   public boolean isEnabled(Level level, org.apache.logging.log4j.Marker marker, Message data, Throwable t)
/*     */   {
/* 111 */     return isEnabledFor(level, marker);
/*     */   }
/*     */   
/*     */   public boolean isEnabled(Level level, org.apache.logging.log4j.Marker marker, CharSequence data, Throwable t)
/*     */   {
/* 116 */     return isEnabledFor(level, marker);
/*     */   }
/*     */   
/*     */   public boolean isEnabled(Level level, org.apache.logging.log4j.Marker marker, Object data, Throwable t)
/*     */   {
/* 121 */     return isEnabledFor(level, marker);
/*     */   }
/*     */   
/*     */   public boolean isEnabled(Level level, org.apache.logging.log4j.Marker marker, String data)
/*     */   {
/* 126 */     return isEnabledFor(level, marker);
/*     */   }
/*     */   
/*     */   public boolean isEnabled(Level level, org.apache.logging.log4j.Marker marker, String data, Object... p1)
/*     */   {
/* 131 */     return isEnabledFor(level, marker);
/*     */   }
/*     */   
/*     */   public boolean isEnabled(Level level, org.apache.logging.log4j.Marker marker, String message, Object p0)
/*     */   {
/* 136 */     return isEnabledFor(level, marker);
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isEnabled(Level level, org.apache.logging.log4j.Marker marker, String message, Object p0, Object p1)
/*     */   {
/* 142 */     return isEnabledFor(level, marker);
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isEnabled(Level level, org.apache.logging.log4j.Marker marker, String message, Object p0, Object p1, Object p2)
/*     */   {
/* 148 */     return isEnabledFor(level, marker);
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isEnabled(Level level, org.apache.logging.log4j.Marker marker, String message, Object p0, Object p1, Object p2, Object p3)
/*     */   {
/* 154 */     return isEnabledFor(level, marker);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isEnabled(Level level, org.apache.logging.log4j.Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4)
/*     */   {
/* 161 */     return isEnabledFor(level, marker);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isEnabled(Level level, org.apache.logging.log4j.Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5)
/*     */   {
/* 168 */     return isEnabledFor(level, marker);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isEnabled(Level level, org.apache.logging.log4j.Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6)
/*     */   {
/* 175 */     return isEnabledFor(level, marker);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isEnabled(Level level, org.apache.logging.log4j.Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7)
/*     */   {
/* 183 */     return isEnabledFor(level, marker);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isEnabled(Level level, org.apache.logging.log4j.Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8)
/*     */   {
/* 191 */     return isEnabledFor(level, marker);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isEnabled(Level level, org.apache.logging.log4j.Marker marker, String message, Object p0, Object p1, Object p2, Object p3, Object p4, Object p5, Object p6, Object p7, Object p8, Object p9)
/*     */   {
/* 199 */     return isEnabledFor(level, marker);
/*     */   }
/*     */   
/*     */   public boolean isEnabled(Level level, org.apache.logging.log4j.Marker marker, String data, Throwable t)
/*     */   {
/* 204 */     return isEnabledFor(level, marker);
/*     */   }
/*     */   
/*     */   private boolean isEnabledFor(Level level, org.apache.logging.log4j.Marker marker) {
/* 208 */     org.slf4j.Marker slf4jMarker = getMarker(marker);
/* 209 */     switch (level.getStandardLevel()) {
/*     */     case DEBUG: 
/* 211 */       return this.logger.isDebugEnabled(slf4jMarker);
/*     */     case TRACE: 
/* 213 */       return this.logger.isTraceEnabled(slf4jMarker);
/*     */     case INFO: 
/* 215 */       return this.logger.isInfoEnabled(slf4jMarker);
/*     */     case WARN: 
/* 217 */       return this.logger.isWarnEnabled(slf4jMarker);
/*     */     case ERROR: 
/* 219 */       return this.logger.isErrorEnabled(slf4jMarker);
/*     */     }
/* 221 */     return this.logger.isErrorEnabled(slf4jMarker);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void logMessage(String fqcn, Level level, org.apache.logging.log4j.Marker marker, Message message, Throwable t)
/*     */   {
/* 228 */     if (this.locationAwareLogger != null) {
/* 229 */       if ((message instanceof LoggerNameAwareMessage)) {
/* 230 */         ((LoggerNameAwareMessage)message).setLoggerName(getName());
/*     */       }
/* 232 */       this.locationAwareLogger.log(getMarker(marker), fqcn, convertLevel(level), message.getFormattedMessage(), message
/* 233 */         .getParameters(), t);
/*     */     } else {
/* 235 */       switch (level.getStandardLevel()) {
/*     */       case DEBUG: 
/* 237 */         this.logger.debug(getMarker(marker), message.getFormattedMessage(), message.getParameters(), t);
/* 238 */         break;
/*     */       case TRACE: 
/* 240 */         this.logger.trace(getMarker(marker), message.getFormattedMessage(), message.getParameters(), t);
/* 241 */         break;
/*     */       case INFO: 
/* 243 */         this.logger.info(getMarker(marker), message.getFormattedMessage(), message.getParameters(), t);
/* 244 */         break;
/*     */       case WARN: 
/* 246 */         this.logger.warn(getMarker(marker), message.getFormattedMessage(), message.getParameters(), t);
/* 247 */         break;
/*     */       case ERROR: 
/* 249 */         this.logger.error(getMarker(marker), message.getFormattedMessage(), message.getParameters(), t);
/* 250 */         break;
/*     */       default: 
/* 252 */         this.logger.error(getMarker(marker), message.getFormattedMessage(), message.getParameters(), t);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\log4j-to-slf4j-2.14.1.jar!\org\apache\logging\slf4j\SLF4JLogger.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */