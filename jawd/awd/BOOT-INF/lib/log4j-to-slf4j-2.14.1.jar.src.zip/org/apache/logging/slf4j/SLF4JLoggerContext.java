/*    */ package org.apache.logging.slf4j;
/*    */ 
/*    */ import org.apache.logging.log4j.message.MessageFactory;
/*    */ import org.apache.logging.log4j.spi.ExtendedLogger;
/*    */ import org.apache.logging.log4j.spi.LoggerContext;
/*    */ import org.apache.logging.log4j.spi.LoggerRegistry;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SLF4JLoggerContext
/*    */   implements LoggerContext
/*    */ {
/* 29 */   private final LoggerRegistry<ExtendedLogger> loggerRegistry = new LoggerRegistry();
/*    */   
/*    */   public Object getExternalContext()
/*    */   {
/* 33 */     return null;
/*    */   }
/*    */   
/*    */   public ExtendedLogger getLogger(String name)
/*    */   {
/* 38 */     if (!this.loggerRegistry.hasLogger(name)) {
/* 39 */       this.loggerRegistry.putIfAbsent(name, null, new SLF4JLogger(name, LoggerFactory.getLogger(name)));
/*    */     }
/* 41 */     return this.loggerRegistry.getLogger(name);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public ExtendedLogger getLogger(String name, MessageFactory messageFactory)
/*    */   {
/* 48 */     if (!this.loggerRegistry.hasLogger(name))
/*    */     {
/* 50 */       this.loggerRegistry.putIfAbsent(name, null, new SLF4JLogger(name, messageFactory, 
/* 51 */         LoggerFactory.getLogger(name)));
/*    */     }
/*    */     
/* 54 */     return this.loggerRegistry.getLogger(name);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public boolean hasLogger(String name)
/*    */   {
/* 61 */     return this.loggerRegistry.hasLogger(name);
/*    */   }
/*    */   
/*    */   public boolean hasLogger(String name, MessageFactory messageFactory)
/*    */   {
/* 66 */     return this.loggerRegistry.hasLogger(name, messageFactory);
/*    */   }
/*    */   
/*    */   public boolean hasLogger(String name, Class<? extends MessageFactory> messageFactoryClass)
/*    */   {
/* 71 */     return this.loggerRegistry.hasLogger(name, messageFactoryClass);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\log4j-to-slf4j-2.14.1.jar!\org\apache\logging\slf4j\SLF4JLoggerContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */