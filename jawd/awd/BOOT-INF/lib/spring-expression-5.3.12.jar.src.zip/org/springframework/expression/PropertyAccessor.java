package org.springframework.expression;

import org.springframework.lang.Nullable;

public abstract interface PropertyAccessor
{
  @Nullable
  public abstract Class<?>[] getSpecificTargetClasses();
  
  public abstract boolean canRead(EvaluationContext paramEvaluationContext, @Nullable Object paramObject, String paramString)
    throws AccessException;
  
  public abstract TypedValue read(EvaluationContext paramEvaluationContext, @Nullable Object paramObject, String paramString)
    throws AccessException;
  
  public abstract boolean canWrite(EvaluationContext paramEvaluationContext, @Nullable Object paramObject, String paramString)
    throws AccessException;
  
  public abstract void write(EvaluationContext paramEvaluationContext, @Nullable Object paramObject1, String paramString, @Nullable Object paramObject2)
    throws AccessException;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-expression-5.3.12.jar!\org\springframework\expression\PropertyAccessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */