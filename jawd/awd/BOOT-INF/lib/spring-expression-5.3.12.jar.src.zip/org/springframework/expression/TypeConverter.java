package org.springframework.expression;

import org.springframework.core.convert.TypeDescriptor;
import org.springframework.lang.Nullable;

public abstract interface TypeConverter
{
  public abstract boolean canConvert(@Nullable TypeDescriptor paramTypeDescriptor1, TypeDescriptor paramTypeDescriptor2);
  
  @Nullable
  public abstract Object convertValue(@Nullable Object paramObject, @Nullable TypeDescriptor paramTypeDescriptor1, TypeDescriptor paramTypeDescriptor2);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-expression-5.3.12.jar!\org\springframework\expression\TypeConverter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */