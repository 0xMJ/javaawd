package org.springframework.expression;

import java.util.List;
import org.springframework.core.convert.TypeDescriptor;
import org.springframework.lang.Nullable;

@FunctionalInterface
public abstract interface ConstructorResolver
{
  @Nullable
  public abstract ConstructorExecutor resolve(EvaluationContext paramEvaluationContext, String paramString, List<TypeDescriptor> paramList)
    throws AccessException;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-expression-5.3.12.jar!\org\springframework\expression\ConstructorResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */