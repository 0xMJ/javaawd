package org.springframework.expression.spel;

import org.springframework.expression.EvaluationException;
import org.springframework.expression.TypedValue;
import org.springframework.lang.Nullable;

public abstract interface SpelNode
{
  @Nullable
  public abstract Object getValue(ExpressionState paramExpressionState)
    throws EvaluationException;
  
  public abstract TypedValue getTypedValue(ExpressionState paramExpressionState)
    throws EvaluationException;
  
  public abstract boolean isWritable(ExpressionState paramExpressionState)
    throws EvaluationException;
  
  public abstract void setValue(ExpressionState paramExpressionState, @Nullable Object paramObject)
    throws EvaluationException;
  
  public abstract String toStringAST();
  
  public abstract int getChildCount();
  
  public abstract SpelNode getChild(int paramInt);
  
  @Nullable
  public abstract Class<?> getObjectClass(@Nullable Object paramObject);
  
  public abstract int getStartPosition();
  
  public abstract int getEndPosition();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-expression-5.3.12.jar!\org\springframework\expression\spel\SpelNode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */