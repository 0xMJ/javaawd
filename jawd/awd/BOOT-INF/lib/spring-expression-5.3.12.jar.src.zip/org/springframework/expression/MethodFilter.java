package org.springframework.expression;

import java.lang.reflect.Method;
import java.util.List;

@FunctionalInterface
public abstract interface MethodFilter
{
  public abstract List<Method> filter(List<Method> paramList);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-expression-5.3.12.jar!\org\springframework\expression\MethodFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */