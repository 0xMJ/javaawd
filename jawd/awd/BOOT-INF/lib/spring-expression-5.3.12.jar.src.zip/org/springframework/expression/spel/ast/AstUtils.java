/*    */ package org.springframework.expression.spel.ast;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.springframework.expression.PropertyAccessor;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AstUtils
/*    */ {
/*    */   public static List<PropertyAccessor> getPropertyAccessorsToTry(@Nullable Class<?> targetType, List<PropertyAccessor> propertyAccessors)
/*    */   {
/* 48 */     List<PropertyAccessor> specificAccessors = new ArrayList();
/* 49 */     List<PropertyAccessor> generalAccessors = new ArrayList();
/* 50 */     for (PropertyAccessor resolver : propertyAccessors) {
/* 51 */       Class<?>[] targets = resolver.getSpecificTargetClasses();
/* 52 */       if (targets == null) {
/* 53 */         generalAccessors.add(resolver);
/*    */ 
/*    */       }
/* 56 */       else if (targetType != null) {
/* 57 */         for (Class<?> clazz : targets) {
/* 58 */           if (clazz == targetType) {
/* 59 */             specificAccessors.add(resolver);
/*    */           }
/* 61 */           else if (clazz.isAssignableFrom(targetType))
/*    */           {
/* 63 */             generalAccessors.add(resolver);
/*    */           }
/*    */         }
/*    */       }
/*    */     }
/*    */     
/* 69 */     Object resolvers = new ArrayList(specificAccessors.size() + generalAccessors.size());
/* 70 */     ((List)resolvers).addAll(specificAccessors);
/* 71 */     ((List)resolvers).addAll(generalAccessors);
/* 72 */     return (List<PropertyAccessor>)resolvers;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-expression-5.3.12.jar!\org\springframework\expression\spel\ast\AstUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */