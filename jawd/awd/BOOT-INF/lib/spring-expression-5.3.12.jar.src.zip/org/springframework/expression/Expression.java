package org.springframework.expression;

import org.springframework.core.convert.TypeDescriptor;
import org.springframework.lang.Nullable;

public abstract interface Expression
{
  public abstract String getExpressionString();
  
  @Nullable
  public abstract Object getValue()
    throws EvaluationException;
  
  @Nullable
  public abstract <T> T getValue(@Nullable Class<T> paramClass)
    throws EvaluationException;
  
  @Nullable
  public abstract Object getValue(@Nullable Object paramObject)
    throws EvaluationException;
  
  @Nullable
  public abstract <T> T getValue(@Nullable Object paramObject, @Nullable Class<T> paramClass)
    throws EvaluationException;
  
  @Nullable
  public abstract Object getValue(EvaluationContext paramEvaluationContext)
    throws EvaluationException;
  
  @Nullable
  public abstract Object getValue(EvaluationContext paramEvaluationContext, @Nullable Object paramObject)
    throws EvaluationException;
  
  @Nullable
  public abstract <T> T getValue(EvaluationContext paramEvaluationContext, @Nullable Class<T> paramClass)
    throws EvaluationException;
  
  @Nullable
  public abstract <T> T getValue(EvaluationContext paramEvaluationContext, @Nullable Object paramObject, @Nullable Class<T> paramClass)
    throws EvaluationException;
  
  @Nullable
  public abstract Class<?> getValueType()
    throws EvaluationException;
  
  @Nullable
  public abstract Class<?> getValueType(@Nullable Object paramObject)
    throws EvaluationException;
  
  @Nullable
  public abstract Class<?> getValueType(EvaluationContext paramEvaluationContext)
    throws EvaluationException;
  
  @Nullable
  public abstract Class<?> getValueType(EvaluationContext paramEvaluationContext, @Nullable Object paramObject)
    throws EvaluationException;
  
  @Nullable
  public abstract TypeDescriptor getValueTypeDescriptor()
    throws EvaluationException;
  
  @Nullable
  public abstract TypeDescriptor getValueTypeDescriptor(@Nullable Object paramObject)
    throws EvaluationException;
  
  @Nullable
  public abstract TypeDescriptor getValueTypeDescriptor(EvaluationContext paramEvaluationContext)
    throws EvaluationException;
  
  @Nullable
  public abstract TypeDescriptor getValueTypeDescriptor(EvaluationContext paramEvaluationContext, @Nullable Object paramObject)
    throws EvaluationException;
  
  public abstract boolean isWritable(@Nullable Object paramObject)
    throws EvaluationException;
  
  public abstract boolean isWritable(EvaluationContext paramEvaluationContext)
    throws EvaluationException;
  
  public abstract boolean isWritable(EvaluationContext paramEvaluationContext, @Nullable Object paramObject)
    throws EvaluationException;
  
  public abstract void setValue(@Nullable Object paramObject1, @Nullable Object paramObject2)
    throws EvaluationException;
  
  public abstract void setValue(EvaluationContext paramEvaluationContext, @Nullable Object paramObject)
    throws EvaluationException;
  
  public abstract void setValue(EvaluationContext paramEvaluationContext, @Nullable Object paramObject1, @Nullable Object paramObject2)
    throws EvaluationException;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-expression-5.3.12.jar!\org\springframework\expression\Expression.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */