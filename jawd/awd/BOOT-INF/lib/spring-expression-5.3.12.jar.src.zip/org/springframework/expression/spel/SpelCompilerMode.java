package org.springframework.expression.spel;

public enum SpelCompilerMode
{
  OFF,  IMMEDIATE,  MIXED;
  
  private SpelCompilerMode() {}
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-expression-5.3.12.jar!\org\springframework\expression\spel\SpelCompilerMode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */