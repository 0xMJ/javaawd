package org.springframework.expression;

public abstract interface ExpressionParser
{
  public abstract Expression parseExpression(String paramString)
    throws ParseException;
  
  public abstract Expression parseExpression(String paramString, ParserContext paramParserContext)
    throws ParseException;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-expression-5.3.12.jar!\org\springframework\expression\ExpressionParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */