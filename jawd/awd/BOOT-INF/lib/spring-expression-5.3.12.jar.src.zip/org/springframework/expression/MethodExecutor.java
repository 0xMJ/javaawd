package org.springframework.expression;

public abstract interface MethodExecutor
{
  public abstract TypedValue execute(EvaluationContext paramEvaluationContext, Object paramObject, Object... paramVarArgs)
    throws AccessException;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-expression-5.3.12.jar!\org\springframework\expression\MethodExecutor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */