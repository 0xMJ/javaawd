package org.springframework.expression;

import org.springframework.lang.Nullable;

public abstract interface TypeComparator
{
  public abstract boolean canCompare(@Nullable Object paramObject1, @Nullable Object paramObject2);
  
  public abstract int compare(@Nullable Object paramObject1, @Nullable Object paramObject2)
    throws EvaluationException;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-expression-5.3.12.jar!\org\springframework\expression\TypeComparator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */