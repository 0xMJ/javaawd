/*     */ package org.springframework.expression.spel.ast;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum TypeCode
/*     */ {
/*  30 */   OBJECT(Object.class), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  35 */   BOOLEAN(Boolean.TYPE), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  40 */   BYTE(Byte.TYPE), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  45 */   CHAR(Character.TYPE), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  50 */   DOUBLE(Double.TYPE), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  55 */   FLOAT(Float.TYPE), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  60 */   INT(Integer.TYPE), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  65 */   LONG(Long.TYPE), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  70 */   SHORT(Short.TYPE);
/*     */   
/*     */ 
/*     */   private Class<?> type;
/*     */   
/*     */   private TypeCode(Class<?> type)
/*     */   {
/*  77 */     this.type = type;
/*     */   }
/*     */   
/*     */   public Class<?> getType()
/*     */   {
/*  82 */     return this.type;
/*     */   }
/*     */   
/*     */   public static TypeCode forName(String name)
/*     */   {
/*  87 */     TypeCode[] tcs = values();
/*  88 */     for (int i = 1; i < tcs.length; i++) {
/*  89 */       if (tcs[i].name().equalsIgnoreCase(name)) {
/*  90 */         return tcs[i];
/*     */       }
/*     */     }
/*  93 */     return OBJECT;
/*     */   }
/*     */   
/*     */   public static TypeCode forClass(Class<?> clazz) {
/*  97 */     TypeCode[] allValues = values();
/*  98 */     for (TypeCode typeCode : allValues) {
/*  99 */       if (clazz == typeCode.getType()) {
/* 100 */         return typeCode;
/*     */       }
/*     */     }
/* 103 */     return OBJECT;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-expression-5.3.12.jar!\org\springframework\expression\spel\ast\TypeCode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */