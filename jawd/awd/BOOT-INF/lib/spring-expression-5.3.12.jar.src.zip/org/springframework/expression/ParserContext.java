/*    */ package org.springframework.expression;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract interface ParserContext
/*    */ {
/* 61 */   public static final ParserContext TEMPLATE_EXPRESSION = new ParserContext()
/*    */   {
/*    */     public boolean isTemplate()
/*    */     {
/* 65 */       return true;
/*    */     }
/*    */     
/*    */     public String getExpressionPrefix()
/*    */     {
/* 70 */       return "#{";
/*    */     }
/*    */     
/*    */     public String getExpressionSuffix()
/*    */     {
/* 75 */       return "}";
/*    */     }
/*    */   };
/*    */   
/*    */   public abstract boolean isTemplate();
/*    */   
/*    */   public abstract String getExpressionPrefix();
/*    */   
/*    */   public abstract String getExpressionSuffix();
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-expression-5.3.12.jar!\org\springframework\expression\ParserContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */