package org.springframework.expression;

import java.util.List;
import org.springframework.core.convert.TypeDescriptor;
import org.springframework.lang.Nullable;

public abstract interface MethodResolver
{
  @Nullable
  public abstract MethodExecutor resolve(EvaluationContext paramEvaluationContext, Object paramObject, String paramString, List<TypeDescriptor> paramList)
    throws AccessException;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-expression-5.3.12.jar!\org\springframework\expression\MethodResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */