package org.springframework.expression;

import java.util.List;
import org.springframework.lang.Nullable;

public abstract interface EvaluationContext
{
  public abstract TypedValue getRootObject();
  
  public abstract List<PropertyAccessor> getPropertyAccessors();
  
  public abstract List<ConstructorResolver> getConstructorResolvers();
  
  public abstract List<MethodResolver> getMethodResolvers();
  
  @Nullable
  public abstract BeanResolver getBeanResolver();
  
  public abstract TypeLocator getTypeLocator();
  
  public abstract TypeConverter getTypeConverter();
  
  public abstract TypeComparator getTypeComparator();
  
  public abstract OperatorOverloader getOperatorOverloader();
  
  public abstract void setVariable(String paramString, @Nullable Object paramObject);
  
  @Nullable
  public abstract Object lookupVariable(String paramString);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-expression-5.3.12.jar!\org\springframework\expression\EvaluationContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */