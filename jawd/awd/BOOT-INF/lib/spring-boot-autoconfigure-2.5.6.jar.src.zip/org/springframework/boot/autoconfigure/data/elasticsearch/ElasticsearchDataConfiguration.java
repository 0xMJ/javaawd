/*     */ package org.springframework.boot.autoconfigure.data.elasticsearch;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import org.elasticsearch.action.support.IndicesOptions;
/*     */ import org.elasticsearch.client.RestHighLevelClient;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.domain.EntityScanner;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.data.elasticsearch.annotations.Document;
/*     */ import org.springframework.data.elasticsearch.client.reactive.ReactiveElasticsearchClient;
/*     */ import org.springframework.data.elasticsearch.core.ElasticsearchOperations;
/*     */ import org.springframework.data.elasticsearch.core.ElasticsearchRestTemplate;
/*     */ import org.springframework.data.elasticsearch.core.ReactiveElasticsearchOperations;
/*     */ import org.springframework.data.elasticsearch.core.ReactiveElasticsearchTemplate;
/*     */ import org.springframework.data.elasticsearch.core.RefreshPolicy;
/*     */ import org.springframework.data.elasticsearch.core.convert.ElasticsearchConverter;
/*     */ import org.springframework.data.elasticsearch.core.convert.ElasticsearchCustomConversions;
/*     */ import org.springframework.data.elasticsearch.core.convert.MappingElasticsearchConverter;
/*     */ import org.springframework.data.elasticsearch.core.mapping.SimpleElasticsearchMappingContext;
/*     */ import org.springframework.web.reactive.function.client.WebClient;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class ElasticsearchDataConfiguration
/*     */ {
/*     */   @Configuration(proxyBeanMethods=false)
/*     */   static class BaseConfiguration
/*     */   {
/*     */     @Bean
/*     */     @ConditionalOnMissingBean
/*     */     ElasticsearchCustomConversions elasticsearchCustomConversions()
/*     */     {
/*  62 */       return new ElasticsearchCustomConversions(Collections.emptyList());
/*     */     }
/*     */     
/*     */     @Bean
/*     */     @ConditionalOnMissingBean
/*     */     SimpleElasticsearchMappingContext mappingContext(ApplicationContext applicationContext, ElasticsearchCustomConversions elasticsearchCustomConversions) throws ClassNotFoundException
/*     */     {
/*  69 */       SimpleElasticsearchMappingContext mappingContext = new SimpleElasticsearchMappingContext();
/*  70 */       mappingContext.setInitialEntitySet(new EntityScanner(applicationContext).scan(new Class[] { Document.class }));
/*  71 */       mappingContext.setSimpleTypeHolder(elasticsearchCustomConversions.getSimpleTypeHolder());
/*  72 */       return mappingContext;
/*     */     }
/*     */     
/*     */     @Bean
/*     */     @ConditionalOnMissingBean
/*     */     ElasticsearchConverter elasticsearchConverter(SimpleElasticsearchMappingContext mappingContext, ElasticsearchCustomConversions elasticsearchCustomConversions)
/*     */     {
/*  79 */       MappingElasticsearchConverter converter = new MappingElasticsearchConverter(mappingContext);
/*  80 */       converter.setConversions(elasticsearchCustomConversions);
/*  81 */       return converter;
/*     */     }
/*     */   }
/*     */   
/*     */   @Configuration(proxyBeanMethods=false)
/*     */   @ConditionalOnClass({RestHighLevelClient.class})
/*     */   static class RestClientConfiguration
/*     */   {
/*     */     @Bean
/*     */     @ConditionalOnMissingBean(value={ElasticsearchOperations.class}, name={"elasticsearchTemplate"})
/*     */     @ConditionalOnBean({RestHighLevelClient.class})
/*     */     ElasticsearchRestTemplate elasticsearchTemplate(RestHighLevelClient client, ElasticsearchConverter converter)
/*     */     {
/*  94 */       return new ElasticsearchRestTemplate(client, converter);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   @Configuration(proxyBeanMethods=false)
/*     */   @ConditionalOnClass({WebClient.class, ReactiveElasticsearchOperations.class})
/*     */   static class ReactiveRestClientConfiguration
/*     */   {
/*     */     @Bean
/*     */     @ConditionalOnMissingBean(value={ReactiveElasticsearchOperations.class}, name={"reactiveElasticsearchTemplate"})
/*     */     @ConditionalOnBean({ReactiveElasticsearchClient.class})
/*     */     ReactiveElasticsearchTemplate reactiveElasticsearchTemplate(ReactiveElasticsearchClient client, ElasticsearchConverter converter)
/*     */     {
/* 108 */       ReactiveElasticsearchTemplate template = new ReactiveElasticsearchTemplate(client, converter);
/* 109 */       template.setIndicesOptions(IndicesOptions.strictExpandOpenAndForbidClosed());
/* 110 */       template.setRefreshPolicy(RefreshPolicy.IMMEDIATE);
/* 111 */       return template;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\data\elasticsearch\ElasticsearchDataConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */