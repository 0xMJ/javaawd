/*    */ package org.springframework.boot.autoconfigure.mustache;
/*    */ 
/*    */ import org.springframework.boot.autoconfigure.template.AbstractTemplateViewResolverProperties;
/*    */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @ConfigurationProperties(prefix="spring.mustache")
/*    */ public class MustacheProperties
/*    */   extends AbstractTemplateViewResolverProperties
/*    */ {
/*    */   public static final String DEFAULT_PREFIX = "classpath:/templates/";
/*    */   public static final String DEFAULT_SUFFIX = ".mustache";
/* 38 */   private String prefix = "classpath:/templates/";
/*    */   
/*    */ 
/*    */ 
/*    */ 
/* 43 */   private String suffix = ".mustache";
/*    */   
/*    */   public MustacheProperties() {
/* 46 */     super("classpath:/templates/", ".mustache");
/*    */   }
/*    */   
/*    */   public String getPrefix()
/*    */   {
/* 51 */     return this.prefix;
/*    */   }
/*    */   
/*    */   public void setPrefix(String prefix)
/*    */   {
/* 56 */     this.prefix = prefix;
/*    */   }
/*    */   
/*    */   public String getSuffix()
/*    */   {
/* 61 */     return this.suffix;
/*    */   }
/*    */   
/*    */   public void setSuffix(String suffix)
/*    */   {
/* 66 */     this.suffix = suffix;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\mustache\MustacheProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */