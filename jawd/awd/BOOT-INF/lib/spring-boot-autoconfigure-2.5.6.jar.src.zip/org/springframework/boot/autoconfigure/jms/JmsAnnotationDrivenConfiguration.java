/*     */ package org.springframework.boot.autoconfigure.jms;
/*     */ 
/*     */ import javax.jms.ConnectionFactory;
/*     */ import javax.jms.ExceptionListener;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnJndi;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnSingleCandidate;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.jms.annotation.EnableJms;
/*     */ import org.springframework.jms.config.DefaultJmsListenerContainerFactory;
/*     */ import org.springframework.jms.support.converter.MessageConverter;
/*     */ import org.springframework.jms.support.destination.DestinationResolver;
/*     */ import org.springframework.jms.support.destination.JndiDestinationResolver;
/*     */ import org.springframework.transaction.jta.JtaTransactionManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods=false)
/*     */ @ConditionalOnClass({EnableJms.class})
/*     */ class JmsAnnotationDrivenConfiguration
/*     */ {
/*     */   private final ObjectProvider<DestinationResolver> destinationResolver;
/*     */   private final ObjectProvider<JtaTransactionManager> transactionManager;
/*     */   private final ObjectProvider<MessageConverter> messageConverter;
/*     */   private final ObjectProvider<ExceptionListener> exceptionListener;
/*     */   private final JmsProperties properties;
/*     */   
/*     */   JmsAnnotationDrivenConfiguration(ObjectProvider<DestinationResolver> destinationResolver, ObjectProvider<JtaTransactionManager> transactionManager, ObjectProvider<MessageConverter> messageConverter, ObjectProvider<ExceptionListener> exceptionListener, JmsProperties properties)
/*     */   {
/*  61 */     this.destinationResolver = destinationResolver;
/*  62 */     this.transactionManager = transactionManager;
/*  63 */     this.messageConverter = messageConverter;
/*  64 */     this.exceptionListener = exceptionListener;
/*  65 */     this.properties = properties;
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   DefaultJmsListenerContainerFactoryConfigurer jmsListenerContainerFactoryConfigurer() {
/*  71 */     DefaultJmsListenerContainerFactoryConfigurer configurer = new DefaultJmsListenerContainerFactoryConfigurer();
/*  72 */     configurer.setDestinationResolver((DestinationResolver)this.destinationResolver.getIfUnique());
/*  73 */     configurer.setTransactionManager((JtaTransactionManager)this.transactionManager.getIfUnique());
/*  74 */     configurer.setMessageConverter((MessageConverter)this.messageConverter.getIfUnique());
/*  75 */     configurer.setExceptionListener((ExceptionListener)this.exceptionListener.getIfUnique());
/*  76 */     configurer.setJmsProperties(this.properties);
/*  77 */     return configurer;
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnSingleCandidate(ConnectionFactory.class)
/*     */   @ConditionalOnMissingBean(name={"jmsListenerContainerFactory"})
/*     */   DefaultJmsListenerContainerFactory jmsListenerContainerFactory(DefaultJmsListenerContainerFactoryConfigurer configurer, ConnectionFactory connectionFactory)
/*     */   {
/*  85 */     DefaultJmsListenerContainerFactory factory = new DefaultJmsListenerContainerFactory();
/*  86 */     configurer.configure(factory, connectionFactory);
/*  87 */     return factory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Configuration(proxyBeanMethods=false)
/*     */   @ConditionalOnJndi
/*     */   static class JndiConfiguration
/*     */   {
/*     */     @Bean
/*     */     @ConditionalOnMissingBean({DestinationResolver.class})
/*     */     JndiDestinationResolver destinationResolver()
/*     */     {
/* 104 */       JndiDestinationResolver resolver = new JndiDestinationResolver();
/* 105 */       resolver.setFallbackToDynamicDestination(true);
/* 106 */       return resolver;
/*     */     }
/*     */   }
/*     */   
/*     */   @Configuration(proxyBeanMethods=false)
/*     */   @EnableJms
/*     */   @ConditionalOnMissingBean(name={"org.springframework.jms.config.internalJmsListenerAnnotationProcessor"})
/*     */   static class EnableJmsConfiguration {}
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\jms\JmsAnnotationDrivenConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */