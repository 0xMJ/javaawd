/*    */ package org.springframework.boot.autoconfigure.security.servlet;
/*    */ 
/*    */ import java.util.function.Function;
/*    */ import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
/*    */ import org.springframework.security.web.util.matcher.RequestMatcher;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AntPathRequestMatcherProvider
/*    */   implements RequestMatcherProvider
/*    */ {
/*    */   private final Function<String, String> pathFactory;
/*    */   
/*    */   public AntPathRequestMatcherProvider(Function<String, String> pathFactory)
/*    */   {
/* 35 */     this.pathFactory = pathFactory;
/*    */   }
/*    */   
/*    */   public RequestMatcher getRequestMatcher(String pattern)
/*    */   {
/* 40 */     return new AntPathRequestMatcher((String)this.pathFactory.apply(pattern));
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\security\servlet\AntPathRequestMatcherProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */