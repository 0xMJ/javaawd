/*     */ package org.springframework.boot.autoconfigure.jms;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix="spring.jms")
/*     */ public class JmsProperties
/*     */ {
/*  37 */   private boolean pubSubDomain = false;
/*     */   
/*     */ 
/*     */ 
/*     */   private String jndiName;
/*     */   
/*     */ 
/*     */ 
/*  45 */   private final Cache cache = new Cache();
/*     */   
/*  47 */   private final Listener listener = new Listener();
/*     */   
/*  49 */   private final Template template = new Template();
/*     */   
/*     */   public boolean isPubSubDomain() {
/*  52 */     return this.pubSubDomain;
/*     */   }
/*     */   
/*     */   public void setPubSubDomain(boolean pubSubDomain) {
/*  56 */     this.pubSubDomain = pubSubDomain;
/*     */   }
/*     */   
/*     */   public String getJndiName() {
/*  60 */     return this.jndiName;
/*     */   }
/*     */   
/*     */   public void setJndiName(String jndiName) {
/*  64 */     this.jndiName = jndiName;
/*     */   }
/*     */   
/*     */   public Cache getCache() {
/*  68 */     return this.cache;
/*     */   }
/*     */   
/*     */   public Listener getListener() {
/*  72 */     return this.listener;
/*     */   }
/*     */   
/*     */   public Template getTemplate() {
/*  76 */     return this.template;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Cache
/*     */   {
/*  84 */     private boolean enabled = true;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  89 */     private boolean consumers = false;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  94 */     private boolean producers = true;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  99 */     private int sessionCacheSize = 1;
/*     */     
/*     */     public boolean isEnabled() {
/* 102 */       return this.enabled;
/*     */     }
/*     */     
/*     */     public void setEnabled(boolean enabled) {
/* 106 */       this.enabled = enabled;
/*     */     }
/*     */     
/*     */     public boolean isConsumers() {
/* 110 */       return this.consumers;
/*     */     }
/*     */     
/*     */     public void setConsumers(boolean consumers) {
/* 114 */       this.consumers = consumers;
/*     */     }
/*     */     
/*     */     public boolean isProducers() {
/* 118 */       return this.producers;
/*     */     }
/*     */     
/*     */     public void setProducers(boolean producers) {
/* 122 */       this.producers = producers;
/*     */     }
/*     */     
/*     */     public int getSessionCacheSize() {
/* 126 */       return this.sessionCacheSize;
/*     */     }
/*     */     
/*     */     public void setSessionCacheSize(int sessionCacheSize) {
/* 130 */       this.sessionCacheSize = sessionCacheSize;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Listener
/*     */   {
/* 140 */     private boolean autoStartup = true;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private JmsProperties.AcknowledgeMode acknowledgeMode;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private Integer concurrency;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private Integer maxConcurrency;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 163 */     private Duration receiveTimeout = Duration.ofSeconds(1L);
/*     */     
/*     */     public boolean isAutoStartup() {
/* 166 */       return this.autoStartup;
/*     */     }
/*     */     
/*     */     public void setAutoStartup(boolean autoStartup) {
/* 170 */       this.autoStartup = autoStartup;
/*     */     }
/*     */     
/*     */     public JmsProperties.AcknowledgeMode getAcknowledgeMode() {
/* 174 */       return this.acknowledgeMode;
/*     */     }
/*     */     
/*     */     public void setAcknowledgeMode(JmsProperties.AcknowledgeMode acknowledgeMode) {
/* 178 */       this.acknowledgeMode = acknowledgeMode;
/*     */     }
/*     */     
/*     */     public Integer getConcurrency() {
/* 182 */       return this.concurrency;
/*     */     }
/*     */     
/*     */     public void setConcurrency(Integer concurrency) {
/* 186 */       this.concurrency = concurrency;
/*     */     }
/*     */     
/*     */     public Integer getMaxConcurrency() {
/* 190 */       return this.maxConcurrency;
/*     */     }
/*     */     
/*     */     public void setMaxConcurrency(Integer maxConcurrency) {
/* 194 */       this.maxConcurrency = maxConcurrency;
/*     */     }
/*     */     
/*     */     public String formatConcurrency() {
/* 198 */       if (this.concurrency == null) {
/* 199 */         return this.maxConcurrency != null ? "1-" + this.maxConcurrency : null;
/*     */       }
/* 201 */       return this.maxConcurrency != null ? this.concurrency + "-" + this.maxConcurrency : 
/* 202 */         String.valueOf(this.concurrency);
/*     */     }
/*     */     
/*     */     public Duration getReceiveTimeout() {
/* 206 */       return this.receiveTimeout;
/*     */     }
/*     */     
/*     */     public void setReceiveTimeout(Duration receiveTimeout) {
/* 210 */       this.receiveTimeout = receiveTimeout;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Template
/*     */   {
/*     */     private String defaultDestination;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private Duration deliveryDelay;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private JmsProperties.DeliveryMode deliveryMode;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private Integer priority;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private Duration timeToLive;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private Boolean qosEnabled;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private Duration receiveTimeout;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String getDefaultDestination()
/*     */     {
/* 258 */       return this.defaultDestination;
/*     */     }
/*     */     
/*     */     public void setDefaultDestination(String defaultDestination) {
/* 262 */       this.defaultDestination = defaultDestination;
/*     */     }
/*     */     
/*     */     public Duration getDeliveryDelay() {
/* 266 */       return this.deliveryDelay;
/*     */     }
/*     */     
/*     */     public void setDeliveryDelay(Duration deliveryDelay) {
/* 270 */       this.deliveryDelay = deliveryDelay;
/*     */     }
/*     */     
/*     */     public JmsProperties.DeliveryMode getDeliveryMode() {
/* 274 */       return this.deliveryMode;
/*     */     }
/*     */     
/*     */     public void setDeliveryMode(JmsProperties.DeliveryMode deliveryMode) {
/* 278 */       this.deliveryMode = deliveryMode;
/*     */     }
/*     */     
/*     */     public Integer getPriority() {
/* 282 */       return this.priority;
/*     */     }
/*     */     
/*     */     public void setPriority(Integer priority) {
/* 286 */       this.priority = priority;
/*     */     }
/*     */     
/*     */     public Duration getTimeToLive() {
/* 290 */       return this.timeToLive;
/*     */     }
/*     */     
/*     */     public void setTimeToLive(Duration timeToLive) {
/* 294 */       this.timeToLive = timeToLive;
/*     */     }
/*     */     
/*     */     public boolean determineQosEnabled() {
/* 298 */       if (this.qosEnabled != null) {
/* 299 */         return this.qosEnabled.booleanValue();
/*     */       }
/* 301 */       return (getDeliveryMode() != null) || (getPriority() != null) || (getTimeToLive() != null);
/*     */     }
/*     */     
/*     */     public Boolean getQosEnabled() {
/* 305 */       return this.qosEnabled;
/*     */     }
/*     */     
/*     */     public void setQosEnabled(Boolean qosEnabled) {
/* 309 */       this.qosEnabled = qosEnabled;
/*     */     }
/*     */     
/*     */     public Duration getReceiveTimeout() {
/* 313 */       return this.receiveTimeout;
/*     */     }
/*     */     
/*     */     public void setReceiveTimeout(Duration receiveTimeout) {
/* 317 */       this.receiveTimeout = receiveTimeout;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static enum AcknowledgeMode
/*     */   {
/* 335 */     AUTO(1), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 342 */     CLIENT(2), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 349 */     DUPS_OK(3);
/*     */     
/*     */     private final int mode;
/*     */     
/*     */     private AcknowledgeMode(int mode) {
/* 354 */       this.mode = mode;
/*     */     }
/*     */     
/*     */     public int getMode() {
/* 358 */       return this.mode;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static enum DeliveryMode
/*     */   {
/* 370 */     NON_PERSISTENT(1), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 376 */     PERSISTENT(2);
/*     */     
/*     */     private final int value;
/*     */     
/*     */     private DeliveryMode(int value) {
/* 381 */       this.value = value;
/*     */     }
/*     */     
/*     */     public int getValue() {
/* 385 */       return this.value;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\jms\JmsProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */