/*    */ package org.springframework.boot.autoconfigure.hateoas;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.ObjectMapper;
/*    */ import org.springframework.boot.autoconfigure.AutoConfigureAfter;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
/*    */ import org.springframework.boot.autoconfigure.data.rest.RepositoryRestMvcAutoConfiguration;
/*    */ import org.springframework.boot.autoconfigure.http.HttpMessageConvertersAutoConfiguration;
/*    */ import org.springframework.boot.autoconfigure.jackson.JacksonAutoConfiguration;
/*    */ import org.springframework.boot.autoconfigure.web.servlet.WebMvcAutoConfiguration;
/*    */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.hateoas.EntityModel;
/*    */ import org.springframework.hateoas.client.LinkDiscoverers;
/*    */ import org.springframework.hateoas.config.EnableHypermediaSupport;
/*    */ import org.springframework.hateoas.mediatype.hal.HalConfiguration;
/*    */ import org.springframework.http.MediaType;
/*    */ import org.springframework.plugin.core.Plugin;
/*    */ import org.springframework.web.bind.annotation.RequestMapping;
/*    */ import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerAdapter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods=false)
/*    */ @ConditionalOnClass({EntityModel.class, RequestMapping.class, RequestMappingHandlerAdapter.class, Plugin.class})
/*    */ @ConditionalOnWebApplication
/*    */ @AutoConfigureAfter({WebMvcAutoConfiguration.class, JacksonAutoConfiguration.class, HttpMessageConvertersAutoConfiguration.class, RepositoryRestMvcAutoConfiguration.class})
/*    */ @EnableConfigurationProperties({HateoasProperties.class})
/*    */ public class HypermediaAutoConfiguration
/*    */ {
/*    */   @Bean
/*    */   @ConditionalOnMissingBean
/*    */   @ConditionalOnClass(name={"com.fasterxml.jackson.databind.ObjectMapper"})
/*    */   @ConditionalOnProperty(prefix="spring.hateoas", name={"use-hal-as-default-json-media-type"}, matchIfMissing=true)
/*    */   HalConfiguration applicationJsonHalConfiguration()
/*    */   {
/* 67 */     return new HalConfiguration().withMediaType(MediaType.APPLICATION_JSON);
/*    */   }
/*    */   
/*    */   @Configuration(proxyBeanMethods=false)
/*    */   @ConditionalOnMissingBean({LinkDiscoverers.class})
/*    */   @ConditionalOnClass({ObjectMapper.class})
/*    */   @EnableHypermediaSupport(type={org.springframework.hateoas.config.EnableHypermediaSupport.HypermediaType.HAL})
/*    */   protected static class HypermediaConfiguration {}
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\hateoas\HypermediaAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */