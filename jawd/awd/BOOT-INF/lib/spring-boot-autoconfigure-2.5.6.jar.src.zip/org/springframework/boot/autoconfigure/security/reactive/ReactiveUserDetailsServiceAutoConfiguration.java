/*    */ package org.springframework.boot.autoconfigure.security.reactive;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.regex.Matcher;
/*    */ import java.util.regex.Pattern;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.beans.factory.ObjectProvider;
/*    */ import org.springframework.boot.autoconfigure.AutoConfigureAfter;
/*    */ import org.springframework.boot.autoconfigure.condition.AnyNestedCondition;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication.Type;
/*    */ import org.springframework.boot.autoconfigure.rsocket.RSocketMessagingAutoConfiguration;
/*    */ import org.springframework.boot.autoconfigure.security.SecurityProperties;
/*    */ import org.springframework.boot.autoconfigure.security.SecurityProperties.User;
/*    */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Conditional;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.ConfigurationCondition.ConfigurationPhase;
/*    */ import org.springframework.messaging.rsocket.annotation.support.RSocketMessageHandler;
/*    */ import org.springframework.security.authentication.ReactiveAuthenticationManager;
/*    */ import org.springframework.security.core.userdetails.MapReactiveUserDetailsService;
/*    */ import org.springframework.security.core.userdetails.ReactiveUserDetailsService;
/*    */ import org.springframework.security.core.userdetails.User;
/*    */ import org.springframework.security.core.userdetails.User.UserBuilder;
/*    */ import org.springframework.security.core.userdetails.UserDetails;
/*    */ import org.springframework.security.crypto.password.PasswordEncoder;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods=false)
/*    */ @ConditionalOnClass({ReactiveAuthenticationManager.class})
/*    */ @ConditionalOnMissingBean(value={ReactiveAuthenticationManager.class, ReactiveUserDetailsService.class}, type={"org.springframework.security.oauth2.jwt.ReactiveJwtDecoder", "org.springframework.security.oauth2.server.resource.introspection.ReactiveOpaqueTokenIntrospector"})
/*    */ @Conditional({ReactiveUserDetailsServiceCondition.class})
/*    */ @EnableConfigurationProperties({SecurityProperties.class})
/*    */ @AutoConfigureAfter({RSocketMessagingAutoConfiguration.class})
/*    */ public class ReactiveUserDetailsServiceAutoConfiguration
/*    */ {
/*    */   private static final String NOOP_PASSWORD_PREFIX = "{noop}";
/* 68 */   private static final Pattern PASSWORD_ALGORITHM_PATTERN = Pattern.compile("^\\{.+}.*$");
/*    */   
/* 70 */   private static final Log logger = LogFactory.getLog(ReactiveUserDetailsServiceAutoConfiguration.class);
/*    */   
/*    */   @Bean
/*    */   public MapReactiveUserDetailsService reactiveUserDetailsService(SecurityProperties properties, ObjectProvider<PasswordEncoder> passwordEncoder)
/*    */   {
/* 75 */     SecurityProperties.User user = properties.getUser();
/* 76 */     UserDetails userDetails = getUserDetails(user, getOrDeducePassword(user, (PasswordEncoder)passwordEncoder.getIfAvailable()));
/* 77 */     return new MapReactiveUserDetailsService(new UserDetails[] { userDetails });
/*    */   }
/*    */   
/*    */   private UserDetails getUserDetails(SecurityProperties.User user, String password) {
/* 81 */     List<String> roles = user.getRoles();
/* 82 */     return User.withUsername(user.getName()).password(password).roles(StringUtils.toStringArray(roles)).build();
/*    */   }
/*    */   
/*    */   private String getOrDeducePassword(SecurityProperties.User user, PasswordEncoder encoder) {
/* 86 */     String password = user.getPassword();
/* 87 */     if (user.isPasswordGenerated()) {
/* 88 */       logger.info(String.format("%n%nUsing generated security password: %s%n", new Object[] { user.getPassword() }));
/*    */     }
/* 90 */     if ((encoder != null) || (PASSWORD_ALGORITHM_PATTERN.matcher(password).matches())) {
/* 91 */       return password;
/*    */     }
/* 93 */     return "{noop}" + password;
/*    */   }
/*    */   
/*    */   static class ReactiveUserDetailsServiceCondition extends AnyNestedCondition
/*    */   {
/*    */     ReactiveUserDetailsServiceCondition() {
/* 99 */       super();
/*    */     }
/*    */     
/*    */     @ConditionalOnWebApplication(type=ConditionalOnWebApplication.Type.REACTIVE)
/*    */     static class ReactiveWebApplicationCondition {}
/*    */     
/*    */     @ConditionalOnBean({RSocketMessageHandler.class})
/*    */     static class RSocketSecurityEnabledCondition {}
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\security\reactive\ReactiveUserDetailsServiceAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */