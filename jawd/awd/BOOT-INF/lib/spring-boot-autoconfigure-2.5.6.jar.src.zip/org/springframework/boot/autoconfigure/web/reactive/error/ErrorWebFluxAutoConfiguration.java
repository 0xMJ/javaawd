/*    */ package org.springframework.boot.autoconfigure.web.reactive.error;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.stream.Collectors;
/*    */ import java.util.stream.Stream;
/*    */ import org.springframework.beans.factory.ObjectProvider;
/*    */ import org.springframework.boot.autoconfigure.AutoConfigureBefore;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication.Type;
/*    */ import org.springframework.boot.autoconfigure.condition.SearchStrategy;
/*    */ import org.springframework.boot.autoconfigure.web.ResourceProperties;
/*    */ import org.springframework.boot.autoconfigure.web.ServerProperties;
/*    */ import org.springframework.boot.autoconfigure.web.WebProperties;
/*    */ import org.springframework.boot.autoconfigure.web.reactive.WebFluxAutoConfiguration;
/*    */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*    */ import org.springframework.boot.web.reactive.error.DefaultErrorAttributes;
/*    */ import org.springframework.boot.web.reactive.error.ErrorAttributes;
/*    */ import org.springframework.boot.web.reactive.error.ErrorWebExceptionHandler;
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.core.annotation.Order;
/*    */ import org.springframework.http.codec.ServerCodecConfigurer;
/*    */ import org.springframework.web.reactive.config.WebFluxConfigurer;
/*    */ import org.springframework.web.reactive.result.view.ViewResolver;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods=false)
/*    */ @ConditionalOnWebApplication(type=ConditionalOnWebApplication.Type.REACTIVE)
/*    */ @ConditionalOnClass({WebFluxConfigurer.class})
/*    */ @AutoConfigureBefore({WebFluxAutoConfiguration.class})
/*    */ @EnableConfigurationProperties({ServerProperties.class, ResourceProperties.class, WebProperties.class})
/*    */ public class ErrorWebFluxAutoConfiguration
/*    */ {
/*    */   private final ServerProperties serverProperties;
/*    */   
/*    */   public ErrorWebFluxAutoConfiguration(ServerProperties serverProperties)
/*    */   {
/* 63 */     this.serverProperties = serverProperties;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   @Bean
/*    */   @ConditionalOnMissingBean(value={ErrorWebExceptionHandler.class}, search=SearchStrategy.CURRENT)
/*    */   @Order(-1)
/*    */   public ErrorWebExceptionHandler errorWebExceptionHandler(ErrorAttributes errorAttributes, ResourceProperties resourceProperties, WebProperties webProperties, ObjectProvider<ViewResolver> viewResolvers, ServerCodecConfigurer serverCodecConfigurer, ApplicationContext applicationContext)
/*    */   {
/* 75 */     DefaultErrorWebExceptionHandler exceptionHandler = new DefaultErrorWebExceptionHandler(errorAttributes, resourceProperties.hasBeenCustomized() ? resourceProperties : webProperties.getResources(), this.serverProperties.getError(), applicationContext);
/* 76 */     exceptionHandler.setViewResolvers((List)viewResolvers.orderedStream().collect(Collectors.toList()));
/* 77 */     exceptionHandler.setMessageWriters(serverCodecConfigurer.getWriters());
/* 78 */     exceptionHandler.setMessageReaders(serverCodecConfigurer.getReaders());
/* 79 */     return exceptionHandler;
/*    */   }
/*    */   
/*    */   @Bean
/*    */   @ConditionalOnMissingBean(value={ErrorAttributes.class}, search=SearchStrategy.CURRENT)
/*    */   public DefaultErrorAttributes errorAttributes() {
/* 85 */     return new DefaultErrorAttributes();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\web\reactive\error\ErrorWebFluxAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */