/*    */ package org.springframework.boot.autoconfigure.condition;
/*    */ 
/*    */ import org.springframework.beans.BeansException;
/*    */ import org.springframework.beans.factory.BeanFactory;
/*    */ import org.springframework.beans.factory.BeanFactoryAware;
/*    */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*    */ import org.springframework.boot.autoconfigure.AutoConfigurationImportEvent;
/*    */ import org.springframework.boot.autoconfigure.AutoConfigurationImportListener;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ConditionEvaluationReportAutoConfigurationImportListener
/*    */   implements AutoConfigurationImportListener, BeanFactoryAware
/*    */ {
/*    */   private ConfigurableListableBeanFactory beanFactory;
/*    */   
/*    */   public void onAutoConfigurationImportEvent(AutoConfigurationImportEvent event)
/*    */   {
/* 39 */     if (this.beanFactory != null) {
/* 40 */       ConditionEvaluationReport report = ConditionEvaluationReport.get(this.beanFactory);
/* 41 */       report.recordEvaluationCandidates(event.getCandidateConfigurations());
/* 42 */       report.recordExclusions(event.getExclusions());
/*    */     }
/*    */   }
/*    */   
/*    */   public void setBeanFactory(BeanFactory beanFactory) throws BeansException
/*    */   {
/* 48 */     this.beanFactory = ((beanFactory instanceof ConfigurableListableBeanFactory) ? (ConfigurableListableBeanFactory)beanFactory : null);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\condition\ConditionEvaluationReportAutoConfigurationImportListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */