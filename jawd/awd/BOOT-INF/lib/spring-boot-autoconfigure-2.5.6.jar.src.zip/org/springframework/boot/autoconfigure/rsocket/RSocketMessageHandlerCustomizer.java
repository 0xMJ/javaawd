package org.springframework.boot.autoconfigure.rsocket;

import org.springframework.messaging.rsocket.annotation.support.RSocketMessageHandler;

@FunctionalInterface
public abstract interface RSocketMessageHandlerCustomizer
{
  public abstract void customize(RSocketMessageHandler paramRSocketMessageHandler);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\rsocket\RSocketMessageHandlerCustomizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */