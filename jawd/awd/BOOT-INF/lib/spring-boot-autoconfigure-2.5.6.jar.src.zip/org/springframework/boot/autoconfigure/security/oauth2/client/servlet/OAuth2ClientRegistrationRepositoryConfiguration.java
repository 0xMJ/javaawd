/*    */ package org.springframework.boot.autoconfigure.security.oauth2.client.servlet;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.security.oauth2.client.ClientsConfiguredCondition;
/*    */ import org.springframework.boot.autoconfigure.security.oauth2.client.OAuth2ClientProperties;
/*    */ import org.springframework.boot.autoconfigure.security.oauth2.client.OAuth2ClientPropertiesRegistrationAdapter;
/*    */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Conditional;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.security.oauth2.client.registration.ClientRegistration;
/*    */ import org.springframework.security.oauth2.client.registration.ClientRegistrationRepository;
/*    */ import org.springframework.security.oauth2.client.registration.InMemoryClientRegistrationRepository;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods=false)
/*    */ @EnableConfigurationProperties({OAuth2ClientProperties.class})
/*    */ @Conditional({ClientsConfiguredCondition.class})
/*    */ class OAuth2ClientRegistrationRepositoryConfiguration
/*    */ {
/*    */   @Bean
/*    */   @ConditionalOnMissingBean({ClientRegistrationRepository.class})
/*    */   InMemoryClientRegistrationRepository clientRegistrationRepository(OAuth2ClientProperties properties)
/*    */   {
/* 49 */     List<ClientRegistration> registrations = new ArrayList(OAuth2ClientPropertiesRegistrationAdapter.getClientRegistrations(properties).values());
/* 50 */     return new InMemoryClientRegistrationRepository(registrations);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\security\oauth2\client\servlet\OAuth2ClientRegistrationRepositoryConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */