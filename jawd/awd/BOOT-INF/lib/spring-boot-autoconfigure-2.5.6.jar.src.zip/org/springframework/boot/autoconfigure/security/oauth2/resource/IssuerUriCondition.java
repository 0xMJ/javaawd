/*    */ package org.springframework.boot.autoconfigure.security.oauth2.resource;
/*    */ 
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionMessage;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionMessage.Builder;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionMessage.ItemsBuilder;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionOutcome;
/*    */ import org.springframework.boot.autoconfigure.condition.SpringBootCondition;
/*    */ import org.springframework.context.annotation.ConditionContext;
/*    */ import org.springframework.core.env.Environment;
/*    */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IssuerUriCondition
/*    */   extends SpringBootCondition
/*    */ {
/*    */   public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata)
/*    */   {
/* 38 */     ConditionMessage.Builder message = ConditionMessage.forCondition("OpenID Connect Issuer URI Condition", new Object[0]);
/* 39 */     Environment environment = context.getEnvironment();
/* 40 */     String issuerUri = environment.getProperty("spring.security.oauth2.resourceserver.jwt.issuer-uri");
/* 41 */     String jwkSetUri = environment.getProperty("spring.security.oauth2.resourceserver.jwt.jwk-set-uri");
/* 42 */     if (!StringUtils.hasText(issuerUri)) {
/* 43 */       return ConditionOutcome.noMatch(message.didNotFind("issuer-uri property").atAll());
/*    */     }
/* 45 */     if (StringUtils.hasText(jwkSetUri)) {
/* 46 */       return ConditionOutcome.noMatch(message.found("jwk-set-uri property").items(new Object[] { jwkSetUri }));
/*    */     }
/* 48 */     return ConditionOutcome.match(message.foundExactly("issuer-uri property"));
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\security\oauth2\resource\IssuerUriCondition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */