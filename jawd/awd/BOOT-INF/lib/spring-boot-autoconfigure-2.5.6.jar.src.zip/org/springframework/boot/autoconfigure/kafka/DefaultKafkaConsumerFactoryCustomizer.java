package org.springframework.boot.autoconfigure.kafka;

import org.springframework.kafka.core.DefaultKafkaConsumerFactory;

@FunctionalInterface
public abstract interface DefaultKafkaConsumerFactoryCustomizer
{
  public abstract void customize(DefaultKafkaConsumerFactory<?, ?> paramDefaultKafkaConsumerFactory);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\kafka\DefaultKafkaConsumerFactoryCustomizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */