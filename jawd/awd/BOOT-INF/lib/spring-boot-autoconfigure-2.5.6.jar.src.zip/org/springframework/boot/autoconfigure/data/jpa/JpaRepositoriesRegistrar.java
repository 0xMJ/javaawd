/*    */ package org.springframework.boot.autoconfigure.data.jpa;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.util.Locale;
/*    */ import org.springframework.boot.autoconfigure.data.AbstractRepositoryConfigurationSourceSupport;
/*    */ import org.springframework.core.env.Environment;
/*    */ import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
/*    */ import org.springframework.data.jpa.repository.config.JpaRepositoryConfigExtension;
/*    */ import org.springframework.data.repository.config.BootstrapMode;
/*    */ import org.springframework.data.repository.config.RepositoryConfigurationExtension;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class JpaRepositoriesRegistrar
/*    */   extends AbstractRepositoryConfigurationSourceSupport
/*    */ {
/* 41 */   private BootstrapMode bootstrapMode = null;
/*    */   
/*    */   protected Class<? extends Annotation> getAnnotation()
/*    */   {
/* 45 */     return EnableJpaRepositories.class;
/*    */   }
/*    */   
/*    */   protected Class<?> getConfiguration()
/*    */   {
/* 50 */     return EnableJpaRepositoriesConfiguration.class;
/*    */   }
/*    */   
/*    */   protected RepositoryConfigurationExtension getRepositoryConfigurationExtension()
/*    */   {
/* 55 */     return new JpaRepositoryConfigExtension();
/*    */   }
/*    */   
/*    */   protected BootstrapMode getBootstrapMode()
/*    */   {
/* 60 */     return this.bootstrapMode == null ? BootstrapMode.DEFAULT : this.bootstrapMode;
/*    */   }
/*    */   
/*    */   public void setEnvironment(Environment environment)
/*    */   {
/* 65 */     super.setEnvironment(environment);
/* 66 */     configureBootstrapMode(environment);
/*    */   }
/*    */   
/*    */   private void configureBootstrapMode(Environment environment) {
/* 70 */     String property = environment.getProperty("spring.data.jpa.repositories.bootstrap-mode");
/* 71 */     if (StringUtils.hasText(property)) {
/* 72 */       this.bootstrapMode = BootstrapMode.valueOf(property.toUpperCase(Locale.ENGLISH));
/*    */     }
/*    */   }
/*    */   
/*    */   @EnableJpaRepositories
/*    */   private static class EnableJpaRepositoriesConfiguration {}
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\data\jpa\JpaRepositoriesRegistrar.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */