/*    */ package org.springframework.boot.autoconfigure.condition;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.lang.annotation.Documented;
/*    */ import java.lang.annotation.Retention;
/*    */ import java.lang.annotation.RetentionPolicy;
/*    */ import java.lang.annotation.Target;
/*    */ import org.springframework.context.annotation.Conditional;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Target({java.lang.annotation.ElementType.TYPE, java.lang.annotation.ElementType.METHOD})
/*    */ @Retention(RetentionPolicy.RUNTIME)
/*    */ @Documented
/*    */ @Conditional({OnWebApplicationCondition.class})
/*    */ public @interface ConditionalOnWebApplication
/*    */ {
/*    */   Type type() default Type.ANY;
/*    */   
/*    */   public static enum Type
/*    */   {
/* 56 */     ANY, 
/*    */     
/*    */ 
/*    */ 
/*    */ 
/* 61 */     SERVLET, 
/*    */     
/*    */ 
/*    */ 
/*    */ 
/* 66 */     REACTIVE;
/*    */     
/*    */     private Type() {}
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\condition\ConditionalOnWebApplication.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */