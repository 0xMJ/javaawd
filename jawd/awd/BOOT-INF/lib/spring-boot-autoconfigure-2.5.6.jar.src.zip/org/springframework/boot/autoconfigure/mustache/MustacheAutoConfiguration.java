/*    */ package org.springframework.boot.autoconfigure.mustache;
/*    */ 
/*    */ import com.samskivert.mustache.Mustache;
/*    */ import com.samskivert.mustache.Mustache.Collector;
/*    */ import com.samskivert.mustache.Mustache.Compiler;
/*    */ import com.samskivert.mustache.Mustache.TemplateLoader;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.template.TemplateLocation;
/*    */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.Import;
/*    */ import org.springframework.core.env.Environment;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods=false)
/*    */ @ConditionalOnClass({Mustache.class})
/*    */ @EnableConfigurationProperties({MustacheProperties.class})
/*    */ @Import({MustacheServletWebConfiguration.class, MustacheReactiveWebConfiguration.class})
/*    */ public class MustacheAutoConfiguration
/*    */ {
/* 49 */   private static final Log logger = LogFactory.getLog(MustacheAutoConfiguration.class);
/*    */   
/*    */   private final MustacheProperties mustache;
/*    */   private final ApplicationContext applicationContext;
/*    */   
/*    */   public MustacheAutoConfiguration(MustacheProperties mustache, ApplicationContext applicationContext)
/*    */   {
/* 56 */     this.mustache = mustache;
/* 57 */     this.applicationContext = applicationContext;
/* 58 */     checkTemplateLocationExists();
/*    */   }
/*    */   
/*    */   public void checkTemplateLocationExists() {
/* 62 */     if (this.mustache.isCheckTemplateLocation()) {
/* 63 */       TemplateLocation location = new TemplateLocation(this.mustache.getPrefix());
/* 64 */       if ((!location.exists(this.applicationContext)) && (logger.isWarnEnabled())) {
/* 65 */         logger.warn("Cannot find template location: " + location + " (please add some templates, check your Mustache configuration, or set spring.mustache.check-template-location=false)");
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   @Bean
/*    */   @ConditionalOnMissingBean
/*    */   public Mustache.Compiler mustacheCompiler(Mustache.TemplateLoader mustacheTemplateLoader, Environment environment)
/*    */   {
/* 75 */     return Mustache.compiler().withLoader(mustacheTemplateLoader).withCollector(collector(environment));
/*    */   }
/*    */   
/*    */   @Deprecated
/*    */   private Mustache.Collector collector(Environment environment) {
/* 80 */     MustacheEnvironmentCollector collector = new MustacheEnvironmentCollector();
/* 81 */     collector.setEnvironment(environment);
/* 82 */     return collector;
/*    */   }
/*    */   
/*    */   @Bean
/*    */   @ConditionalOnMissingBean({Mustache.TemplateLoader.class})
/*    */   public MustacheResourceTemplateLoader mustacheTemplateLoader()
/*    */   {
/* 89 */     MustacheResourceTemplateLoader loader = new MustacheResourceTemplateLoader(this.mustache.getPrefix(), this.mustache.getSuffix());
/* 90 */     loader.setCharset(this.mustache.getCharsetName());
/* 91 */     return loader;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\mustache\MustacheAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */