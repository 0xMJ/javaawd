/*    */ package org.springframework.boot.autoconfigure.availability;
/*    */ 
/*    */ import org.springframework.boot.availability.ApplicationAvailabilityBean;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods=false)
/*    */ public class ApplicationAvailabilityAutoConfiguration
/*    */ {
/*    */   @Bean
/*    */   public ApplicationAvailabilityBean applicationAvailability()
/*    */   {
/* 35 */     return new ApplicationAvailabilityBean();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\availability\ApplicationAvailabilityAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */