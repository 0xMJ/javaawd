package org.springframework.boot.autoconfigure.cache;

import org.springframework.data.redis.cache.RedisCacheManager.RedisCacheManagerBuilder;

@FunctionalInterface
public abstract interface RedisCacheManagerBuilderCustomizer
{
  public abstract void customize(RedisCacheManager.RedisCacheManagerBuilder paramRedisCacheManagerBuilder);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\cache\RedisCacheManagerBuilderCustomizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */