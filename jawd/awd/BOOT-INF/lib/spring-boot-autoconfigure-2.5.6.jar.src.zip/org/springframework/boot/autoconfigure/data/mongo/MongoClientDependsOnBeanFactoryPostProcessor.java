/*    */ package org.springframework.boot.autoconfigure.data.mongo;
/*    */ 
/*    */ import com.mongodb.client.MongoClient;
/*    */ import org.springframework.boot.autoconfigure.AbstractDependsOnBeanFactoryPostProcessor;
/*    */ import org.springframework.core.annotation.Order;
/*    */ import org.springframework.data.mongodb.core.MongoClientFactoryBean;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Order(Integer.MAX_VALUE)
/*    */ public class MongoClientDependsOnBeanFactoryPostProcessor
/*    */   extends AbstractDependsOnBeanFactoryPostProcessor
/*    */ {
/*    */   public MongoClientDependsOnBeanFactoryPostProcessor(Class<?>... dependsOn)
/*    */   {
/* 45 */     super(MongoClient.class, MongoClientFactoryBean.class, dependsOn);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\data\mongo\MongoClientDependsOnBeanFactoryPostProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */