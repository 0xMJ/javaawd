/*    */ package org.springframework.boot.autoconfigure.security.oauth2.client.reactive;
/*    */ 
/*    */ import org.springframework.boot.autoconfigure.AutoConfigureBefore;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication.Type;
/*    */ import org.springframework.boot.autoconfigure.condition.NoneNestedConditions;
/*    */ import org.springframework.boot.autoconfigure.security.oauth2.client.OAuth2ClientProperties;
/*    */ import org.springframework.boot.autoconfigure.security.reactive.ReactiveSecurityAutoConfiguration;
/*    */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*    */ import org.springframework.context.annotation.Conditional;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.ConfigurationCondition.ConfigurationPhase;
/*    */ import org.springframework.context.annotation.Import;
/*    */ import org.springframework.security.config.annotation.web.reactive.EnableWebFluxSecurity;
/*    */ import org.springframework.security.oauth2.client.registration.ClientRegistration;
/*    */ import reactor.core.publisher.Flux;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods=false)
/*    */ @AutoConfigureBefore({ReactiveSecurityAutoConfiguration.class})
/*    */ @EnableConfigurationProperties({OAuth2ClientProperties.class})
/*    */ @Conditional({NonServletApplicationCondition.class})
/*    */ @ConditionalOnClass({Flux.class, EnableWebFluxSecurity.class, ClientRegistration.class})
/*    */ @Import({ReactiveOAuth2ClientConfigurations.ReactiveClientRegistrationRepositoryConfiguration.class, ReactiveOAuth2ClientConfigurations.ReactiveOAuth2ClientConfiguration.class})
/*    */ public class ReactiveOAuth2ClientAutoConfiguration
/*    */ {
/*    */   static class NonServletApplicationCondition
/*    */     extends NoneNestedConditions
/*    */   {
/*    */     NonServletApplicationCondition()
/*    */     {
/* 54 */       super();
/*    */     }
/*    */     
/*    */     @ConditionalOnWebApplication(type=ConditionalOnWebApplication.Type.SERVLET)
/*    */     static class ServletApplicationCondition {}
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\security\oauth2\client\reactive\ReactiveOAuth2ClientAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */