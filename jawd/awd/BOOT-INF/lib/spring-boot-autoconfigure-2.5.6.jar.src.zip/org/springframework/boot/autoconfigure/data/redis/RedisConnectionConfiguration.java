/*     */ package org.springframework.boot.autoconfigure.data.redis;
/*     */ 
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.data.redis.connection.RedisClusterConfiguration;
/*     */ import org.springframework.data.redis.connection.RedisNode;
/*     */ import org.springframework.data.redis.connection.RedisPassword;
/*     */ import org.springframework.data.redis.connection.RedisSentinelConfiguration;
/*     */ import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class RedisConnectionConfiguration
/*     */ {
/*     */   private final RedisProperties properties;
/*     */   private final RedisSentinelConfiguration sentinelConfiguration;
/*     */   private final RedisClusterConfiguration clusterConfiguration;
/*     */   
/*     */   protected RedisConnectionConfiguration(RedisProperties properties, ObjectProvider<RedisSentinelConfiguration> sentinelConfigurationProvider, ObjectProvider<RedisClusterConfiguration> clusterConfigurationProvider)
/*     */   {
/*  52 */     this.properties = properties;
/*  53 */     this.sentinelConfiguration = ((RedisSentinelConfiguration)sentinelConfigurationProvider.getIfAvailable());
/*  54 */     this.clusterConfiguration = ((RedisClusterConfiguration)clusterConfigurationProvider.getIfAvailable());
/*     */   }
/*     */   
/*     */   protected final RedisStandaloneConfiguration getStandaloneConfig() {
/*  58 */     RedisStandaloneConfiguration config = new RedisStandaloneConfiguration();
/*  59 */     if (StringUtils.hasText(this.properties.getUrl())) {
/*  60 */       ConnectionInfo connectionInfo = parseUrl(this.properties.getUrl());
/*  61 */       config.setHostName(connectionInfo.getHostName());
/*  62 */       config.setPort(connectionInfo.getPort());
/*  63 */       config.setUsername(connectionInfo.getUsername());
/*  64 */       config.setPassword(RedisPassword.of(connectionInfo.getPassword()));
/*     */     }
/*     */     else {
/*  67 */       config.setHostName(this.properties.getHost());
/*  68 */       config.setPort(this.properties.getPort());
/*  69 */       config.setUsername(this.properties.getUsername());
/*  70 */       config.setPassword(RedisPassword.of(this.properties.getPassword()));
/*     */     }
/*  72 */     config.setDatabase(this.properties.getDatabase());
/*  73 */     return config;
/*     */   }
/*     */   
/*     */   protected final RedisSentinelConfiguration getSentinelConfig() {
/*  77 */     if (this.sentinelConfiguration != null) {
/*  78 */       return this.sentinelConfiguration;
/*     */     }
/*  80 */     RedisProperties.Sentinel sentinelProperties = this.properties.getSentinel();
/*  81 */     if (sentinelProperties != null) {
/*  82 */       RedisSentinelConfiguration config = new RedisSentinelConfiguration();
/*  83 */       config.master(sentinelProperties.getMaster());
/*  84 */       config.setSentinels(createSentinels(sentinelProperties));
/*  85 */       config.setUsername(this.properties.getUsername());
/*  86 */       if (this.properties.getPassword() != null) {
/*  87 */         config.setPassword(RedisPassword.of(this.properties.getPassword()));
/*     */       }
/*  89 */       if (sentinelProperties.getPassword() != null) {
/*  90 */         config.setSentinelPassword(RedisPassword.of(sentinelProperties.getPassword()));
/*     */       }
/*  92 */       config.setDatabase(this.properties.getDatabase());
/*  93 */       return config;
/*     */     }
/*  95 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final RedisClusterConfiguration getClusterConfiguration()
/*     */   {
/* 103 */     if (this.clusterConfiguration != null) {
/* 104 */       return this.clusterConfiguration;
/*     */     }
/* 106 */     if (this.properties.getCluster() == null) {
/* 107 */       return null;
/*     */     }
/* 109 */     RedisProperties.Cluster clusterProperties = this.properties.getCluster();
/* 110 */     RedisClusterConfiguration config = new RedisClusterConfiguration(clusterProperties.getNodes());
/* 111 */     if (clusterProperties.getMaxRedirects() != null) {
/* 112 */       config.setMaxRedirects(clusterProperties.getMaxRedirects().intValue());
/*     */     }
/* 114 */     config.setUsername(this.properties.getUsername());
/* 115 */     if (this.properties.getPassword() != null) {
/* 116 */       config.setPassword(RedisPassword.of(this.properties.getPassword()));
/*     */     }
/* 118 */     return config;
/*     */   }
/*     */   
/*     */   protected final RedisProperties getProperties() {
/* 122 */     return this.properties;
/*     */   }
/*     */   
/*     */   private List<RedisNode> createSentinels(RedisProperties.Sentinel sentinel) {
/* 126 */     List<RedisNode> nodes = new ArrayList();
/* 127 */     for (String node : sentinel.getNodes()) {
/*     */       try {
/* 129 */         String[] parts = StringUtils.split(node, ":");
/* 130 */         Assert.state(parts.length == 2, "Must be defined as 'host:port'");
/* 131 */         nodes.add(new RedisNode(parts[0], Integer.parseInt(parts[1])));
/*     */       }
/*     */       catch (RuntimeException ex) {
/* 134 */         throw new IllegalStateException("Invalid redis sentinel property '" + node + "'", ex);
/*     */       }
/*     */     }
/* 137 */     return nodes;
/*     */   }
/*     */   
/*     */   protected ConnectionInfo parseUrl(String url) {
/*     */     try {
/* 142 */       URI uri = new URI(url);
/* 143 */       String scheme = uri.getScheme();
/* 144 */       if ((!"redis".equals(scheme)) && (!"rediss".equals(scheme))) {
/* 145 */         throw new RedisUrlSyntaxException(url);
/*     */       }
/* 147 */       boolean useSsl = "rediss".equals(scheme);
/* 148 */       String username = null;
/* 149 */       String password = null;
/* 150 */       if (uri.getUserInfo() != null) {
/* 151 */         String candidate = uri.getUserInfo();
/* 152 */         int index = candidate.indexOf(':');
/* 153 */         if (index >= 0) {
/* 154 */           username = candidate.substring(0, index);
/* 155 */           password = candidate.substring(index + 1);
/*     */         }
/*     */         else {
/* 158 */           password = candidate;
/*     */         }
/*     */       }
/* 161 */       return new ConnectionInfo(uri, useSsl, username, password);
/*     */     }
/*     */     catch (URISyntaxException ex) {
/* 164 */       throw new RedisUrlSyntaxException(url, ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   static class ConnectionInfo
/*     */   {
/*     */     private final URI uri;
/*     */     
/*     */     private final boolean useSsl;
/*     */     private final String username;
/*     */     private final String password;
/*     */     
/*     */     ConnectionInfo(URI uri, boolean useSsl, String username, String password)
/*     */     {
/* 179 */       this.uri = uri;
/* 180 */       this.useSsl = useSsl;
/* 181 */       this.username = username;
/* 182 */       this.password = password;
/*     */     }
/*     */     
/*     */     boolean isUseSsl() {
/* 186 */       return this.useSsl;
/*     */     }
/*     */     
/*     */     String getHostName() {
/* 190 */       return this.uri.getHost();
/*     */     }
/*     */     
/*     */     int getPort() {
/* 194 */       return this.uri.getPort();
/*     */     }
/*     */     
/*     */     String getUsername() {
/* 198 */       return this.username;
/*     */     }
/*     */     
/*     */     String getPassword() {
/* 202 */       return this.password;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\data\redis\RedisConnectionConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */