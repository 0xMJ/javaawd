/*    */ package org.springframework.boot.autoconfigure.sql.init;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.springframework.boot.sql.init.DatabaseInitializationSettings;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class SettingsCreator
/*    */ {
/*    */   static DatabaseInitializationSettings createFrom(SqlInitializationProperties properties)
/*    */   {
/* 37 */     DatabaseInitializationSettings settings = new DatabaseInitializationSettings();
/* 38 */     settings.setSchemaLocations(
/* 39 */       scriptLocations(properties.getSchemaLocations(), "schema", properties.getPlatform()));
/* 40 */     settings.setDataLocations(scriptLocations(properties.getDataLocations(), "data", properties.getPlatform()));
/* 41 */     settings.setContinueOnError(properties.isContinueOnError());
/* 42 */     settings.setSeparator(properties.getSeparator());
/* 43 */     settings.setEncoding(properties.getEncoding());
/* 44 */     settings.setMode(properties.getMode());
/* 45 */     return settings;
/*    */   }
/*    */   
/*    */   private static List<String> scriptLocations(List<String> locations, String fallback, String platform) {
/* 49 */     if (locations != null) {
/* 50 */       return locations;
/*    */     }
/* 52 */     List<String> fallbackLocations = new ArrayList();
/* 53 */     fallbackLocations.add("optional:classpath*:" + fallback + "-" + platform + ".sql");
/* 54 */     fallbackLocations.add("optional:classpath*:" + fallback + ".sql");
/* 55 */     return fallbackLocations;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\sql\init\SettingsCreator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */