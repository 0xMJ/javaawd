/*    */ package org.springframework.boot.autoconfigure.condition;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.springframework.context.annotation.ConfigurationCondition.ConfigurationPhase;
/*    */ import org.springframework.core.annotation.Order;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Order(2147483627)
/*    */ public abstract class AnyNestedCondition
/*    */   extends AbstractNestedCondition
/*    */ {
/*    */   public AnyNestedCondition(ConfigurationCondition.ConfigurationPhase configurationPhase)
/*    */   {
/* 61 */     super(configurationPhase);
/*    */   }
/*    */   
/*    */   protected ConditionOutcome getFinalMatchOutcome(AbstractNestedCondition.MemberMatchOutcomes memberOutcomes)
/*    */   {
/* 66 */     boolean match = !memberOutcomes.getMatches().isEmpty();
/* 67 */     List<ConditionMessage> messages = new ArrayList();
/* 68 */     messages.add(ConditionMessage.forCondition("AnyNestedCondition", new Object[0]).because(memberOutcomes
/* 69 */       .getMatches().size() + " matched " + memberOutcomes.getNonMatches().size() + " did not"));
/* 70 */     for (ConditionOutcome outcome : memberOutcomes.getAll()) {
/* 71 */       messages.add(outcome.getConditionMessage());
/*    */     }
/* 73 */     return new ConditionOutcome(match, ConditionMessage.of(messages));
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\condition\AnyNestedCondition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */