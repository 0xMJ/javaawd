/*    */ package org.springframework.boot.autoconfigure.neo4j;
/*    */ 
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.neo4j.driver.Logger;
/*    */ import org.neo4j.driver.Logging;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class Neo4jSpringJclLogging
/*    */   implements Logging
/*    */ {
/*    */   private static final String AUTOMATIC_PREFIX = "org.neo4j.driver.";
/*    */   
/*    */   public Logger getLog(String name)
/*    */   {
/* 40 */     String requestedLog = name;
/* 41 */     if (!requestedLog.startsWith("org.neo4j.driver.")) {
/* 42 */       requestedLog = "org.neo4j.driver." + name;
/*    */     }
/* 44 */     Log springJclLog = LogFactory.getLog(requestedLog);
/* 45 */     return new SpringJclLogger(springJclLog);
/*    */   }
/*    */   
/*    */   private static final class SpringJclLogger implements Logger
/*    */   {
/*    */     private final Log delegate;
/*    */     
/*    */     SpringJclLogger(Log delegate) {
/* 53 */       this.delegate = delegate;
/*    */     }
/*    */     
/*    */     public void error(String message, Throwable cause)
/*    */     {
/* 58 */       this.delegate.error(message, cause);
/*    */     }
/*    */     
/*    */     public void info(String format, Object... params)
/*    */     {
/* 63 */       this.delegate.info(String.format(format, params));
/*    */     }
/*    */     
/*    */     public void warn(String format, Object... params)
/*    */     {
/* 68 */       this.delegate.warn(String.format(format, params));
/*    */     }
/*    */     
/*    */     public void warn(String message, Throwable cause)
/*    */     {
/* 73 */       this.delegate.warn(message, cause);
/*    */     }
/*    */     
/*    */     public void debug(String format, Object... params)
/*    */     {
/* 78 */       if (isDebugEnabled()) {
/* 79 */         this.delegate.debug(String.format(format, params));
/*    */       }
/*    */     }
/*    */     
/*    */     public void trace(String format, Object... params)
/*    */     {
/* 85 */       if (isTraceEnabled()) {
/* 86 */         this.delegate.trace(String.format(format, params));
/*    */       }
/*    */     }
/*    */     
/*    */     public boolean isTraceEnabled()
/*    */     {
/* 92 */       return this.delegate.isTraceEnabled();
/*    */     }
/*    */     
/*    */     public boolean isDebugEnabled()
/*    */     {
/* 97 */       return this.delegate.isDebugEnabled();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\neo4j\Neo4jSpringJclLogging.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */