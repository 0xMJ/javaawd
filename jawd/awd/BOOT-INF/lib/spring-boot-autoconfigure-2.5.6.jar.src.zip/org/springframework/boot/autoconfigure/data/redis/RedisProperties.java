/*     */ package org.springframework.boot.autoconfigure.data.redis;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.util.List;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix="spring.redis")
/*     */ public class RedisProperties
/*     */ {
/*  41 */   private int database = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String url;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  52 */   private String host = "localhost";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String username;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String password;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  67 */   private int port = 6379;
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean ssl;
/*     */   
/*     */ 
/*     */ 
/*     */   private Duration timeout;
/*     */   
/*     */ 
/*     */ 
/*     */   private Duration connectTimeout;
/*     */   
/*     */ 
/*     */ 
/*     */   private String clientName;
/*     */   
/*     */ 
/*     */ 
/*     */   private ClientType clientType;
/*     */   
/*     */ 
/*     */ 
/*     */   private Sentinel sentinel;
/*     */   
/*     */ 
/*     */ 
/*     */   private Cluster cluster;
/*     */   
/*     */ 
/*  98 */   private final Jedis jedis = new Jedis();
/*     */   
/* 100 */   private final Lettuce lettuce = new Lettuce();
/*     */   
/*     */   public int getDatabase() {
/* 103 */     return this.database;
/*     */   }
/*     */   
/*     */   public void setDatabase(int database) {
/* 107 */     this.database = database;
/*     */   }
/*     */   
/*     */   public String getUrl() {
/* 111 */     return this.url;
/*     */   }
/*     */   
/*     */   public void setUrl(String url) {
/* 115 */     this.url = url;
/*     */   }
/*     */   
/*     */   public String getHost() {
/* 119 */     return this.host;
/*     */   }
/*     */   
/*     */   public void setHost(String host) {
/* 123 */     this.host = host;
/*     */   }
/*     */   
/*     */   public String getUsername() {
/* 127 */     return this.username;
/*     */   }
/*     */   
/*     */   public void setUsername(String username) {
/* 131 */     this.username = username;
/*     */   }
/*     */   
/*     */   public String getPassword() {
/* 135 */     return this.password;
/*     */   }
/*     */   
/*     */   public void setPassword(String password) {
/* 139 */     this.password = password;
/*     */   }
/*     */   
/*     */   public int getPort() {
/* 143 */     return this.port;
/*     */   }
/*     */   
/*     */   public void setPort(int port) {
/* 147 */     this.port = port;
/*     */   }
/*     */   
/*     */   public boolean isSsl() {
/* 151 */     return this.ssl;
/*     */   }
/*     */   
/*     */   public void setSsl(boolean ssl) {
/* 155 */     this.ssl = ssl;
/*     */   }
/*     */   
/*     */   public void setTimeout(Duration timeout) {
/* 159 */     this.timeout = timeout;
/*     */   }
/*     */   
/*     */   public Duration getTimeout() {
/* 163 */     return this.timeout;
/*     */   }
/*     */   
/*     */   public Duration getConnectTimeout() {
/* 167 */     return this.connectTimeout;
/*     */   }
/*     */   
/*     */   public void setConnectTimeout(Duration connectTimeout) {
/* 171 */     this.connectTimeout = connectTimeout;
/*     */   }
/*     */   
/*     */   public String getClientName() {
/* 175 */     return this.clientName;
/*     */   }
/*     */   
/*     */   public void setClientName(String clientName) {
/* 179 */     this.clientName = clientName;
/*     */   }
/*     */   
/*     */   public ClientType getClientType() {
/* 183 */     return this.clientType;
/*     */   }
/*     */   
/*     */   public void setClientType(ClientType clientType) {
/* 187 */     this.clientType = clientType;
/*     */   }
/*     */   
/*     */   public Sentinel getSentinel() {
/* 191 */     return this.sentinel;
/*     */   }
/*     */   
/*     */   public void setSentinel(Sentinel sentinel) {
/* 195 */     this.sentinel = sentinel;
/*     */   }
/*     */   
/*     */   public Cluster getCluster() {
/* 199 */     return this.cluster;
/*     */   }
/*     */   
/*     */   public void setCluster(Cluster cluster) {
/* 203 */     this.cluster = cluster;
/*     */   }
/*     */   
/*     */   public Jedis getJedis() {
/* 207 */     return this.jedis;
/*     */   }
/*     */   
/*     */   public Lettuce getLettuce() {
/* 211 */     return this.lettuce;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static enum ClientType
/*     */   {
/* 222 */     LETTUCE, 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 227 */     JEDIS;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private ClientType() {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Pool
/*     */   {
/* 240 */     private int maxIdle = 8;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 247 */     private int minIdle = 0;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 253 */     private int maxActive = 8;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 260 */     private Duration maxWait = Duration.ofMillis(-1L);
/*     */     
/*     */ 
/*     */     private Duration timeBetweenEvictionRuns;
/*     */     
/*     */ 
/*     */ 
/*     */     public int getMaxIdle()
/*     */     {
/* 269 */       return this.maxIdle;
/*     */     }
/*     */     
/*     */     public void setMaxIdle(int maxIdle) {
/* 273 */       this.maxIdle = maxIdle;
/*     */     }
/*     */     
/*     */     public int getMinIdle() {
/* 277 */       return this.minIdle;
/*     */     }
/*     */     
/*     */     public void setMinIdle(int minIdle) {
/* 281 */       this.minIdle = minIdle;
/*     */     }
/*     */     
/*     */     public int getMaxActive() {
/* 285 */       return this.maxActive;
/*     */     }
/*     */     
/*     */     public void setMaxActive(int maxActive) {
/* 289 */       this.maxActive = maxActive;
/*     */     }
/*     */     
/*     */     public Duration getMaxWait() {
/* 293 */       return this.maxWait;
/*     */     }
/*     */     
/*     */     public void setMaxWait(Duration maxWait) {
/* 297 */       this.maxWait = maxWait;
/*     */     }
/*     */     
/*     */     public Duration getTimeBetweenEvictionRuns() {
/* 301 */       return this.timeBetweenEvictionRuns;
/*     */     }
/*     */     
/*     */     public void setTimeBetweenEvictionRuns(Duration timeBetweenEvictionRuns) {
/* 305 */       this.timeBetweenEvictionRuns = timeBetweenEvictionRuns;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Cluster
/*     */   {
/*     */     private List<String> nodes;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private Integer maxRedirects;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public List<String> getNodes()
/*     */     {
/* 328 */       return this.nodes;
/*     */     }
/*     */     
/*     */     public void setNodes(List<String> nodes) {
/* 332 */       this.nodes = nodes;
/*     */     }
/*     */     
/*     */     public Integer getMaxRedirects() {
/* 336 */       return this.maxRedirects;
/*     */     }
/*     */     
/*     */     public void setMaxRedirects(Integer maxRedirects) {
/* 340 */       this.maxRedirects = maxRedirects;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Sentinel
/*     */   {
/*     */     private String master;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private List<String> nodes;
/*     */     
/*     */ 
/*     */ 
/*     */     private String password;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public String getMaster()
/*     */     {
/* 366 */       return this.master;
/*     */     }
/*     */     
/*     */     public void setMaster(String master) {
/* 370 */       this.master = master;
/*     */     }
/*     */     
/*     */     public List<String> getNodes() {
/* 374 */       return this.nodes;
/*     */     }
/*     */     
/*     */     public void setNodes(List<String> nodes) {
/* 378 */       this.nodes = nodes;
/*     */     }
/*     */     
/*     */     public String getPassword() {
/* 382 */       return this.password;
/*     */     }
/*     */     
/*     */     public void setPassword(String password) {
/* 386 */       this.password = password;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Jedis
/*     */   {
/*     */     private RedisProperties.Pool pool;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public RedisProperties.Pool getPool()
/*     */     {
/* 402 */       return this.pool;
/*     */     }
/*     */     
/*     */     public void setPool(RedisProperties.Pool pool) {
/* 406 */       this.pool = pool;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Lettuce
/*     */   {
/* 419 */     private Duration shutdownTimeout = Duration.ofMillis(100L);
/*     */     
/*     */ 
/*     */ 
/*     */     private RedisProperties.Pool pool;
/*     */     
/*     */ 
/* 426 */     private final Cluster cluster = new Cluster();
/*     */     
/*     */     public Duration getShutdownTimeout() {
/* 429 */       return this.shutdownTimeout;
/*     */     }
/*     */     
/*     */     public void setShutdownTimeout(Duration shutdownTimeout) {
/* 433 */       this.shutdownTimeout = shutdownTimeout;
/*     */     }
/*     */     
/*     */     public RedisProperties.Pool getPool() {
/* 437 */       return this.pool;
/*     */     }
/*     */     
/*     */     public void setPool(RedisProperties.Pool pool) {
/* 441 */       this.pool = pool;
/*     */     }
/*     */     
/*     */     public Cluster getCluster() {
/* 445 */       return this.cluster;
/*     */     }
/*     */     
/*     */     public static class Cluster
/*     */     {
/* 450 */       private final Refresh refresh = new Refresh();
/*     */       
/*     */       public Refresh getRefresh() {
/* 453 */         return this.refresh;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       public static class Refresh
/*     */       {
/* 463 */         private boolean dynamicRefreshSources = true;
/*     */         
/*     */ 
/*     */ 
/*     */         private Duration period;
/*     */         
/*     */ 
/*     */ 
/*     */         private boolean adaptive;
/*     */         
/*     */ 
/*     */ 
/*     */         public boolean isDynamicRefreshSources()
/*     */         {
/* 477 */           return this.dynamicRefreshSources;
/*     */         }
/*     */         
/*     */         public void setDynamicRefreshSources(boolean dynamicRefreshSources) {
/* 481 */           this.dynamicRefreshSources = dynamicRefreshSources;
/*     */         }
/*     */         
/*     */         public Duration getPeriod() {
/* 485 */           return this.period;
/*     */         }
/*     */         
/*     */         public void setPeriod(Duration period) {
/* 489 */           this.period = period;
/*     */         }
/*     */         
/*     */         public boolean isAdaptive() {
/* 493 */           return this.adaptive;
/*     */         }
/*     */         
/*     */         public void setAdaptive(boolean adaptive) {
/* 497 */           this.adaptive = adaptive;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\data\redis\RedisProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */