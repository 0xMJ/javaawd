/*     */ package org.springframework.boot.autoconfigure.mongo;
/*     */ 
/*     */ import com.mongodb.ConnectionString;
/*     */ import org.bson.UuidRepresentation;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.boot.context.properties.DeprecatedConfigurationProperty;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix="spring.data.mongodb")
/*     */ public class MongoProperties
/*     */ {
/*     */   public static final int DEFAULT_PORT = 27017;
/*     */   public static final String DEFAULT_URI = "mongodb://localhost/test";
/*     */   private String host;
/*  60 */   private Integer port = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String uri;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String database;
/*     */   
/*     */ 
/*     */ 
/*     */   private String authenticationDatabase;
/*     */   
/*     */ 
/*     */ 
/*  78 */   private final Gridfs gridfs = new Gridfs();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String username;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private char[] password;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String replicaSetName;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private Class<?> fieldNamingStrategy;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 103 */   private UuidRepresentation uuidRepresentation = UuidRepresentation.JAVA_LEGACY;
/*     */   
/*     */ 
/*     */   private Boolean autoIndexCreation;
/*     */   
/*     */ 
/*     */   public String getHost()
/*     */   {
/* 111 */     return this.host;
/*     */   }
/*     */   
/*     */   public void setHost(String host) {
/* 115 */     this.host = host;
/*     */   }
/*     */   
/*     */   public String getDatabase() {
/* 119 */     return this.database;
/*     */   }
/*     */   
/*     */   public void setDatabase(String database) {
/* 123 */     this.database = database;
/*     */   }
/*     */   
/*     */   public String getAuthenticationDatabase() {
/* 127 */     return this.authenticationDatabase;
/*     */   }
/*     */   
/*     */   public void setAuthenticationDatabase(String authenticationDatabase) {
/* 131 */     this.authenticationDatabase = authenticationDatabase;
/*     */   }
/*     */   
/*     */   public String getUsername() {
/* 135 */     return this.username;
/*     */   }
/*     */   
/*     */   public void setUsername(String username) {
/* 139 */     this.username = username;
/*     */   }
/*     */   
/*     */   public char[] getPassword() {
/* 143 */     return this.password;
/*     */   }
/*     */   
/*     */   public void setPassword(char[] password) {
/* 147 */     this.password = password;
/*     */   }
/*     */   
/*     */   public String getReplicaSetName() {
/* 151 */     return this.replicaSetName;
/*     */   }
/*     */   
/*     */   public void setReplicaSetName(String replicaSetName) {
/* 155 */     this.replicaSetName = replicaSetName;
/*     */   }
/*     */   
/*     */   public Class<?> getFieldNamingStrategy() {
/* 159 */     return this.fieldNamingStrategy;
/*     */   }
/*     */   
/*     */   public void setFieldNamingStrategy(Class<?> fieldNamingStrategy) {
/* 163 */     this.fieldNamingStrategy = fieldNamingStrategy;
/*     */   }
/*     */   
/*     */   public UuidRepresentation getUuidRepresentation() {
/* 167 */     return this.uuidRepresentation;
/*     */   }
/*     */   
/*     */   public void setUuidRepresentation(UuidRepresentation uuidRepresentation) {
/* 171 */     this.uuidRepresentation = uuidRepresentation;
/*     */   }
/*     */   
/*     */   public String getUri() {
/* 175 */     return this.uri;
/*     */   }
/*     */   
/*     */   public String determineUri() {
/* 179 */     return this.uri != null ? this.uri : "mongodb://localhost/test";
/*     */   }
/*     */   
/*     */   public void setUri(String uri) {
/* 183 */     this.uri = uri;
/*     */   }
/*     */   
/*     */   public Integer getPort() {
/* 187 */     return this.port;
/*     */   }
/*     */   
/*     */   public void setPort(Integer port) {
/* 191 */     this.port = port;
/*     */   }
/*     */   
/*     */   public Gridfs getGridfs() {
/* 195 */     return this.gridfs;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @DeprecatedConfigurationProperty(replacement="spring.data.mongodb.gridfs.database")
/*     */   @Deprecated
/*     */   public String getGridFsDatabase()
/*     */   {
/* 207 */     return this.gridfs.getDatabase();
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public void setGridFsDatabase(String gridFsDatabase) {
/* 212 */     this.gridfs.setDatabase(gridFsDatabase);
/*     */   }
/*     */   
/*     */   public String getMongoClientDatabase() {
/* 216 */     if (this.database != null) {
/* 217 */       return this.database;
/*     */     }
/* 219 */     return new ConnectionString(determineUri()).getDatabase();
/*     */   }
/*     */   
/*     */   public Boolean isAutoIndexCreation() {
/* 223 */     return this.autoIndexCreation;
/*     */   }
/*     */   
/*     */   public void setAutoIndexCreation(Boolean autoIndexCreation) {
/* 227 */     this.autoIndexCreation = autoIndexCreation;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static class Gridfs
/*     */   {
/*     */     private String database;
/*     */     
/*     */ 
/*     */     private String bucket;
/*     */     
/*     */ 
/*     */ 
/*     */     public String getDatabase()
/*     */     {
/* 243 */       return this.database;
/*     */     }
/*     */     
/*     */     public void setDatabase(String database) {
/* 247 */       this.database = database;
/*     */     }
/*     */     
/*     */     public String getBucket() {
/* 251 */       return this.bucket;
/*     */     }
/*     */     
/*     */     public void setBucket(String bucket) {
/* 255 */       this.bucket = bucket;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\mongo\MongoProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */