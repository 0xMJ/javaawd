/*     */ package org.springframework.boot.autoconfigure.task;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties("spring.task.execution")
/*     */ public class TaskExecutionProperties
/*     */ {
/*  33 */   private final Pool pool = new Pool();
/*     */   
/*  35 */   private final Shutdown shutdown = new Shutdown();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  40 */   private String threadNamePrefix = "task-";
/*     */   
/*     */   public Pool getPool() {
/*  43 */     return this.pool;
/*     */   }
/*     */   
/*     */   public Shutdown getShutdown() {
/*  47 */     return this.shutdown;
/*     */   }
/*     */   
/*     */   public String getThreadNamePrefix() {
/*  51 */     return this.threadNamePrefix;
/*     */   }
/*     */   
/*     */   public void setThreadNamePrefix(String threadNamePrefix) {
/*  55 */     this.threadNamePrefix = threadNamePrefix;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Pool
/*     */   {
/*  64 */     private int queueCapacity = Integer.MAX_VALUE;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  69 */     private int coreSize = 8;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  76 */     private int maxSize = Integer.MAX_VALUE;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  82 */     private boolean allowCoreThreadTimeout = true;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  87 */     private Duration keepAlive = Duration.ofSeconds(60L);
/*     */     
/*     */     public int getQueueCapacity() {
/*  90 */       return this.queueCapacity;
/*     */     }
/*     */     
/*     */     public void setQueueCapacity(int queueCapacity) {
/*  94 */       this.queueCapacity = queueCapacity;
/*     */     }
/*     */     
/*     */     public int getCoreSize() {
/*  98 */       return this.coreSize;
/*     */     }
/*     */     
/*     */     public void setCoreSize(int coreSize) {
/* 102 */       this.coreSize = coreSize;
/*     */     }
/*     */     
/*     */     public int getMaxSize() {
/* 106 */       return this.maxSize;
/*     */     }
/*     */     
/*     */     public void setMaxSize(int maxSize) {
/* 110 */       this.maxSize = maxSize;
/*     */     }
/*     */     
/*     */     public boolean isAllowCoreThreadTimeout() {
/* 114 */       return this.allowCoreThreadTimeout;
/*     */     }
/*     */     
/*     */     public void setAllowCoreThreadTimeout(boolean allowCoreThreadTimeout) {
/* 118 */       this.allowCoreThreadTimeout = allowCoreThreadTimeout;
/*     */     }
/*     */     
/*     */     public Duration getKeepAlive() {
/* 122 */       return this.keepAlive;
/*     */     }
/*     */     
/*     */     public void setKeepAlive(Duration keepAlive) {
/* 126 */       this.keepAlive = keepAlive;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Shutdown
/*     */   {
/*     */     private boolean awaitTermination;
/*     */     
/*     */ 
/*     */     private Duration awaitTerminationPeriod;
/*     */     
/*     */ 
/*     */ 
/*     */     public boolean isAwaitTermination()
/*     */     {
/* 144 */       return this.awaitTermination;
/*     */     }
/*     */     
/*     */     public void setAwaitTermination(boolean awaitTermination) {
/* 148 */       this.awaitTermination = awaitTermination;
/*     */     }
/*     */     
/*     */     public Duration getAwaitTerminationPeriod() {
/* 152 */       return this.awaitTerminationPeriod;
/*     */     }
/*     */     
/*     */     public void setAwaitTerminationPeriod(Duration awaitTerminationPeriod) {
/* 156 */       this.awaitTerminationPeriod = awaitTerminationPeriod;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\task\TaskExecutionProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */