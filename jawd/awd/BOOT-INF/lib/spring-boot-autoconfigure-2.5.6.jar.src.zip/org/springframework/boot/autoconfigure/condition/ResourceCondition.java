/*    */ package org.springframework.boot.autoconfigure.condition;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import org.springframework.context.annotation.ConditionContext;
/*    */ import org.springframework.core.env.Environment;
/*    */ import org.springframework.core.io.Resource;
/*    */ import org.springframework.core.io.ResourceLoader;
/*    */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ResourceCondition
/*    */   extends SpringBootCondition
/*    */ {
/*    */   private final String name;
/*    */   private final String property;
/*    */   private final String[] resourceLocations;
/*    */   
/*    */   protected ResourceCondition(String name, String property, String... resourceLocations)
/*    */   {
/* 55 */     this.name = name;
/* 56 */     this.property = property;
/* 57 */     this.resourceLocations = resourceLocations;
/*    */   }
/*    */   
/*    */   public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata)
/*    */   {
/* 62 */     if (context.getEnvironment().containsProperty(this.property)) {
/* 63 */       return ConditionOutcome.match(startConditionMessage().foundExactly("property " + this.property));
/*    */     }
/* 65 */     return getResourceOutcome(context, metadata);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected ConditionOutcome getResourceOutcome(ConditionContext context, AnnotatedTypeMetadata metadata)
/*    */   {
/* 75 */     List<String> found = new ArrayList();
/* 76 */     for (String location : this.resourceLocations) {
/* 77 */       Resource resource = context.getResourceLoader().getResource(location);
/* 78 */       if ((resource != null) && (resource.exists())) {
/* 79 */         found.add(location);
/*    */       }
/*    */     }
/* 82 */     if (found.isEmpty()) {
/* 83 */       ConditionMessage message = startConditionMessage().didNotFind("resource", "resources").items(ConditionMessage.Style.QUOTE, 
/* 84 */         Arrays.asList(this.resourceLocations));
/* 85 */       return ConditionOutcome.noMatch(message);
/*    */     }
/* 87 */     ConditionMessage message = startConditionMessage().found("resource", "resources").items(ConditionMessage.Style.QUOTE, found);
/* 88 */     return ConditionOutcome.match(message);
/*    */   }
/*    */   
/*    */   protected final ConditionMessage.Builder startConditionMessage() {
/* 92 */     return ConditionMessage.forCondition("ResourceCondition", new Object[] { "(" + this.name + ")" });
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\condition\ResourceCondition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */