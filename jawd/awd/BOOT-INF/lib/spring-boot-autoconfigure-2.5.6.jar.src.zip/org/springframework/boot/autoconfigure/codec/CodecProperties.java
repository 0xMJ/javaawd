/*    */ package org.springframework.boot.autoconfigure.codec;
/*    */ 
/*    */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*    */ import org.springframework.util.unit.DataSize;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @ConfigurationProperties(prefix="spring.codec")
/*    */ public class CodecProperties
/*    */ {
/*    */   private boolean logRequestDetails;
/*    */   private DataSize maxInMemorySize;
/*    */   
/*    */   public boolean isLogRequestDetails()
/*    */   {
/* 45 */     return this.logRequestDetails;
/*    */   }
/*    */   
/*    */   public void setLogRequestDetails(boolean logRequestDetails) {
/* 49 */     this.logRequestDetails = logRequestDetails;
/*    */   }
/*    */   
/*    */   public DataSize getMaxInMemorySize() {
/* 53 */     return this.maxInMemorySize;
/*    */   }
/*    */   
/*    */   public void setMaxInMemorySize(DataSize maxInMemorySize) {
/* 57 */     this.maxInMemorySize = maxInMemorySize;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\codec\CodecProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */