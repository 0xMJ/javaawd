/*    */ package org.springframework.boot.autoconfigure.rsocket;
/*    */ 
/*    */ import io.rsocket.RSocket;
/*    */ import io.rsocket.transport.netty.server.TcpServerTransport;
/*    */ import org.springframework.boot.autoconfigure.AutoConfigureAfter;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.Scope;
/*    */ import org.springframework.messaging.rsocket.RSocketRequester;
/*    */ import org.springframework.messaging.rsocket.RSocketRequester.Builder;
/*    */ import org.springframework.messaging.rsocket.RSocketStrategies;
/*    */ import reactor.netty.http.server.HttpServer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods=false)
/*    */ @ConditionalOnClass({RSocketRequester.class, RSocket.class, HttpServer.class, TcpServerTransport.class})
/*    */ @AutoConfigureAfter({RSocketStrategiesAutoConfiguration.class})
/*    */ public class RSocketRequesterAutoConfiguration
/*    */ {
/*    */   @Bean
/*    */   @Scope("prototype")
/*    */   @ConditionalOnMissingBean
/*    */   public RSocketRequester.Builder rSocketRequesterBuilder(RSocketStrategies strategies)
/*    */   {
/* 51 */     return RSocketRequester.builder().rsocketStrategies(strategies);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\rsocket\RSocketRequesterAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */