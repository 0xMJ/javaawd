/*    */ package org.springframework.boot.autoconfigure.data.couchbase;
/*    */ 
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnSingleCandidate;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.data.couchbase.CouchbaseClientFactory;
/*    */ import org.springframework.data.couchbase.core.CouchbaseTemplate;
/*    */ import org.springframework.data.couchbase.core.convert.MappingCouchbaseConverter;
/*    */ import org.springframework.data.couchbase.repository.config.RepositoryOperationsMapping;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods=false)
/*    */ @ConditionalOnSingleCandidate(CouchbaseClientFactory.class)
/*    */ class CouchbaseClientFactoryDependentConfiguration
/*    */ {
/*    */   @Bean(name={"couchbaseTemplate"})
/*    */   @ConditionalOnMissingBean(name={"couchbaseTemplate"})
/*    */   CouchbaseTemplate couchbaseTemplate(CouchbaseClientFactory couchbaseClientFactory, MappingCouchbaseConverter mappingCouchbaseConverter)
/*    */   {
/* 43 */     return new CouchbaseTemplate(couchbaseClientFactory, mappingCouchbaseConverter);
/*    */   }
/*    */   
/*    */   @Bean(name={"couchbaseRepositoryOperationsMapping"})
/*    */   @ConditionalOnMissingBean(name={"couchbaseRepositoryOperationsMapping"})
/*    */   RepositoryOperationsMapping couchbaseRepositoryOperationsMapping(CouchbaseTemplate couchbaseTemplate) {
/* 49 */     return new RepositoryOperationsMapping(couchbaseTemplate);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\data\couchbase\CouchbaseClientFactoryDependentConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */