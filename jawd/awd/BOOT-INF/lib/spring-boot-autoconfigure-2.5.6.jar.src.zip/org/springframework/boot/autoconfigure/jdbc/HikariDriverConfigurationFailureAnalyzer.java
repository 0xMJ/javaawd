/*    */ package org.springframework.boot.autoconfigure.jdbc;
/*    */ 
/*    */ import org.springframework.boot.diagnostics.AbstractFailureAnalyzer;
/*    */ import org.springframework.boot.diagnostics.FailureAnalysis;
/*    */ import org.springframework.jdbc.CannotGetJdbcConnectionException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class HikariDriverConfigurationFailureAnalyzer
/*    */   extends AbstractFailureAnalyzer<CannotGetJdbcConnectionException>
/*    */ {
/*    */   private static final String EXPECTED_MESSAGE = "Failed to obtain JDBC Connection: cannot use driverClassName and dataSourceClassName together.";
/*    */   
/*    */   protected FailureAnalysis analyze(Throwable rootFailure, CannotGetJdbcConnectionException cause)
/*    */   {
/* 36 */     if (!"Failed to obtain JDBC Connection: cannot use driverClassName and dataSourceClassName together.".equals(cause.getMessage())) {
/* 37 */       return null;
/*    */     }
/* 39 */     return new FailureAnalysis("Configuration of the Hikari connection pool failed: 'dataSourceClassName' is not supported.", "Spring Boot auto-configures only a driver and can't specify a custom DataSource. Consider configuring the Hikari DataSource in your own configuration.", cause);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\jdbc\HikariDriverConfigurationFailureAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */