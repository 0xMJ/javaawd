package org.springframework.boot.autoconfigure.mongo.embedded;

import de.flapdoodle.embed.process.config.store.ImmutableDownloadConfig.Builder;

@FunctionalInterface
public abstract interface DownloadConfigBuilderCustomizer
{
  public abstract void customize(ImmutableDownloadConfig.Builder paramBuilder);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\mongo\embedded\DownloadConfigBuilderCustomizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */