/*    */ package org.springframework.boot.autoconfigure.mail;
/*    */ 
/*    */ import javax.activation.MimeType;
/*    */ import javax.mail.internet.MimeMessage;
/*    */ import org.springframework.boot.autoconfigure.condition.AnyNestedCondition;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*    */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*    */ import org.springframework.context.annotation.Conditional;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.ConfigurationCondition.ConfigurationPhase;
/*    */ import org.springframework.context.annotation.Import;
/*    */ import org.springframework.mail.MailSender;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods=false)
/*    */ @ConditionalOnClass({MimeMessage.class, MimeType.class, MailSender.class})
/*    */ @ConditionalOnMissingBean({MailSender.class})
/*    */ @Conditional({MailSenderCondition.class})
/*    */ @EnableConfigurationProperties({MailProperties.class})
/*    */ @Import({MailSenderJndiConfiguration.class, MailSenderPropertiesConfiguration.class})
/*    */ public class MailSenderAutoConfiguration
/*    */ {
/*    */   static class MailSenderCondition
/*    */     extends AnyNestedCondition
/*    */   {
/*    */     MailSenderCondition()
/*    */     {
/* 57 */       super();
/*    */     }
/*    */     
/*    */     @ConditionalOnProperty(prefix="spring.mail", name={"jndi-name"})
/*    */     static class JndiNameProperty {}
/*    */     
/*    */     @ConditionalOnProperty(prefix="spring.mail", name={"host"})
/*    */     static class HostProperty {}
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\mail\MailSenderAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */