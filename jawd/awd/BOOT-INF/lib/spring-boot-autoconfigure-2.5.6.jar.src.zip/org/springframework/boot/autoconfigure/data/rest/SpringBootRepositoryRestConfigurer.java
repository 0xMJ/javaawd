/*    */ package org.springframework.boot.autoconfigure.data.rest;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.ObjectMapper;
/*    */ import org.springframework.core.annotation.Order;
/*    */ import org.springframework.data.rest.core.config.RepositoryRestConfiguration;
/*    */ import org.springframework.data.rest.webmvc.config.RepositoryRestConfigurer;
/*    */ import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;
/*    */ import org.springframework.web.servlet.config.annotation.CorsRegistry;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Order(0)
/*    */ class SpringBootRepositoryRestConfigurer
/*    */   implements RepositoryRestConfigurer
/*    */ {
/*    */   private final Jackson2ObjectMapperBuilder objectMapperBuilder;
/*    */   private final RepositoryRestProperties properties;
/*    */   
/*    */   SpringBootRepositoryRestConfigurer(Jackson2ObjectMapperBuilder objectMapperBuilder, RepositoryRestProperties properties)
/*    */   {
/* 45 */     this.objectMapperBuilder = objectMapperBuilder;
/* 46 */     this.properties = properties;
/*    */   }
/*    */   
/*    */   public void configureRepositoryRestConfiguration(RepositoryRestConfiguration config, CorsRegistry cors)
/*    */   {
/* 51 */     this.properties.applyTo(config);
/*    */   }
/*    */   
/*    */   public void configureJacksonObjectMapper(ObjectMapper objectMapper)
/*    */   {
/* 56 */     if (this.objectMapperBuilder != null) {
/* 57 */       this.objectMapperBuilder.configure(objectMapper);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\data\rest\SpringBootRepositoryRestConfigurer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */