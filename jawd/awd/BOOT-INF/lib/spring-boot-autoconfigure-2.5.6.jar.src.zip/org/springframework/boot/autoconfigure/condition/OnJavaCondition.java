/*    */ package org.springframework.boot.autoconfigure.condition;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.springframework.boot.system.JavaVersion;
/*    */ import org.springframework.context.annotation.ConditionContext;
/*    */ import org.springframework.core.annotation.Order;
/*    */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Order(-2147483628)
/*    */ class OnJavaCondition
/*    */   extends SpringBootCondition
/*    */ {
/* 39 */   private static final JavaVersion JVM_VERSION = ;
/*    */   
/*    */   public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata)
/*    */   {
/* 43 */     Map<String, Object> attributes = metadata.getAnnotationAttributes(ConditionalOnJava.class.getName());
/* 44 */     ConditionalOnJava.Range range = (ConditionalOnJava.Range)attributes.get("range");
/* 45 */     JavaVersion version = (JavaVersion)attributes.get("value");
/* 46 */     return getMatchOutcome(range, JVM_VERSION, version);
/*    */   }
/*    */   
/*    */   protected ConditionOutcome getMatchOutcome(ConditionalOnJava.Range range, JavaVersion runningVersion, JavaVersion version) {
/* 50 */     boolean match = isWithin(runningVersion, range, version);
/* 51 */     String expected = String.format(range != ConditionalOnJava.Range.EQUAL_OR_NEWER ? "(older than %s)" : "(%s or newer)", new Object[] { version });
/*    */     
/* 53 */     ConditionMessage message = ConditionMessage.forCondition(ConditionalOnJava.class, new Object[] { expected }).foundExactly(runningVersion);
/* 54 */     return new ConditionOutcome(match, message);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private boolean isWithin(JavaVersion runningVersion, ConditionalOnJava.Range range, JavaVersion version)
/*    */   {
/* 65 */     if (range == ConditionalOnJava.Range.EQUAL_OR_NEWER) {
/* 66 */       return runningVersion.isEqualOrNewerThan(version);
/*    */     }
/* 68 */     if (range == ConditionalOnJava.Range.OLDER_THAN) {
/* 69 */       return runningVersion.isOlderThan(version);
/*    */     }
/* 71 */     throw new IllegalStateException("Unknown range " + range);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\condition\OnJavaCondition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */