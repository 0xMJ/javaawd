/*     */ package org.springframework.boot.autoconfigure.validation;
/*     */ 
/*     */ import javax.validation.ValidationException;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.boot.validation.MessageInterpolatorFactory;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextAware;
/*     */ import org.springframework.validation.Errors;
/*     */ import org.springframework.validation.SmartValidator;
/*     */ import org.springframework.validation.beanvalidation.OptionalValidatorFactoryBean;
/*     */ import org.springframework.validation.beanvalidation.SpringValidatorAdapter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ValidatorAdapter
/*     */   implements SmartValidator, ApplicationContextAware, InitializingBean, DisposableBean
/*     */ {
/*     */   private final SmartValidator target;
/*     */   private final boolean existingBean;
/*     */   
/*     */   ValidatorAdapter(SmartValidator target, boolean existingBean)
/*     */   {
/*  50 */     this.target = target;
/*  51 */     this.existingBean = existingBean;
/*     */   }
/*     */   
/*     */   public final org.springframework.validation.Validator getTarget() {
/*  55 */     return this.target;
/*     */   }
/*     */   
/*     */   public boolean supports(Class<?> clazz)
/*     */   {
/*  60 */     return this.target.supports(clazz);
/*     */   }
/*     */   
/*     */   public void validate(Object target, Errors errors)
/*     */   {
/*  65 */     this.target.validate(target, errors);
/*     */   }
/*     */   
/*     */   public void validate(Object target, Errors errors, Object... validationHints)
/*     */   {
/*  70 */     this.target.validate(target, errors, validationHints);
/*     */   }
/*     */   
/*     */   public void setApplicationContext(ApplicationContext applicationContext) throws BeansException
/*     */   {
/*  75 */     if ((!this.existingBean) && ((this.target instanceof ApplicationContextAware))) {
/*  76 */       ((ApplicationContextAware)this.target).setApplicationContext(applicationContext);
/*     */     }
/*     */   }
/*     */   
/*     */   public void afterPropertiesSet() throws Exception
/*     */   {
/*  82 */     if ((!this.existingBean) && ((this.target instanceof InitializingBean))) {
/*  83 */       ((InitializingBean)this.target).afterPropertiesSet();
/*     */     }
/*     */   }
/*     */   
/*     */   public void destroy() throws Exception
/*     */   {
/*  89 */     if ((!this.existingBean) && ((this.target instanceof DisposableBean))) {
/*  90 */       ((DisposableBean)this.target).destroy();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static org.springframework.validation.Validator get(ApplicationContext applicationContext, org.springframework.validation.Validator validator)
/*     */   {
/* 106 */     if (validator != null) {
/* 107 */       return wrap(validator, false);
/*     */     }
/* 109 */     return getExistingOrCreate(applicationContext);
/*     */   }
/*     */   
/*     */   private static org.springframework.validation.Validator getExistingOrCreate(ApplicationContext applicationContext) {
/* 113 */     org.springframework.validation.Validator existing = getExisting(applicationContext);
/* 114 */     if (existing != null) {
/* 115 */       return wrap(existing, true);
/*     */     }
/* 117 */     return create();
/*     */   }
/*     */   
/*     */   private static org.springframework.validation.Validator getExisting(ApplicationContext applicationContext) {
/*     */     try {
/* 122 */       javax.validation.Validator validator = (javax.validation.Validator)applicationContext.getBean(javax.validation.Validator.class);
/* 123 */       if ((validator instanceof org.springframework.validation.Validator)) {
/* 124 */         return (org.springframework.validation.Validator)validator;
/*     */       }
/* 126 */       return new SpringValidatorAdapter(validator);
/*     */     }
/*     */     catch (NoSuchBeanDefinitionException ex) {}
/* 129 */     return null;
/*     */   }
/*     */   
/*     */   private static org.springframework.validation.Validator create()
/*     */   {
/* 134 */     OptionalValidatorFactoryBean validator = new OptionalValidatorFactoryBean();
/*     */     try {
/* 136 */       MessageInterpolatorFactory factory = new MessageInterpolatorFactory();
/* 137 */       validator.setMessageInterpolator(factory.getObject());
/*     */     }
/*     */     catch (ValidationException localValidationException) {}
/*     */     
/*     */ 
/* 142 */     return wrap(validator, false);
/*     */   }
/*     */   
/*     */   private static org.springframework.validation.Validator wrap(org.springframework.validation.Validator validator, boolean existingBean) {
/* 146 */     if ((validator instanceof javax.validation.Validator)) {
/* 147 */       if ((validator instanceof SpringValidatorAdapter)) {
/* 148 */         return new ValidatorAdapter((SpringValidatorAdapter)validator, existingBean);
/*     */       }
/* 150 */       return new ValidatorAdapter(new SpringValidatorAdapter((javax.validation.Validator)validator), existingBean);
/*     */     }
/*     */     
/* 153 */     return validator;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\validation\ValidatorAdapter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */