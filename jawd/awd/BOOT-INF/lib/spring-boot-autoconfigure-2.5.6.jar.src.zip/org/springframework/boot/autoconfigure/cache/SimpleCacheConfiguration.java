/*    */ package org.springframework.boot.autoconfigure.cache;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.cache.CacheManager;
/*    */ import org.springframework.cache.concurrent.ConcurrentMapCacheManager;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Conditional;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods=false)
/*    */ @ConditionalOnMissingBean({CacheManager.class})
/*    */ @Conditional({CacheCondition.class})
/*    */ class SimpleCacheConfiguration
/*    */ {
/*    */   @Bean
/*    */   ConcurrentMapCacheManager cacheManager(CacheProperties cacheProperties, CacheManagerCustomizers cacheManagerCustomizers)
/*    */   {
/* 41 */     ConcurrentMapCacheManager cacheManager = new ConcurrentMapCacheManager();
/* 42 */     List<String> cacheNames = cacheProperties.getCacheNames();
/* 43 */     if (!cacheNames.isEmpty()) {
/* 44 */       cacheManager.setCacheNames(cacheNames);
/*    */     }
/* 46 */     return (ConcurrentMapCacheManager)cacheManagerCustomizers.customize(cacheManager);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\cache\SimpleCacheConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */