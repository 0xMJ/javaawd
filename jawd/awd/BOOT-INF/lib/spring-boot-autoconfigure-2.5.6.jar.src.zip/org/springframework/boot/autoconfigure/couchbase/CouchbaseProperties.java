/*     */ package org.springframework.boot.autoconfigure.couchbase;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix="spring.couchbase")
/*     */ public class CouchbaseProperties
/*     */ {
/*     */   private String connectionString;
/*     */   private String username;
/*     */   private String password;
/*  52 */   private final Env env = new Env();
/*     */   
/*     */   public String getConnectionString() {
/*  55 */     return this.connectionString;
/*     */   }
/*     */   
/*     */   public void setConnectionString(String connectionString) {
/*  59 */     this.connectionString = connectionString;
/*     */   }
/*     */   
/*     */   public String getUsername() {
/*  63 */     return this.username;
/*     */   }
/*     */   
/*     */   public void setUsername(String username) {
/*  67 */     this.username = username;
/*     */   }
/*     */   
/*     */   public String getPassword() {
/*  71 */     return this.password;
/*     */   }
/*     */   
/*     */   public void setPassword(String password) {
/*  75 */     this.password = password;
/*     */   }
/*     */   
/*     */   public Env getEnv() {
/*  79 */     return this.env;
/*     */   }
/*     */   
/*     */   public static class Env
/*     */   {
/*  84 */     private final CouchbaseProperties.Io io = new CouchbaseProperties.Io();
/*     */     
/*  86 */     private final CouchbaseProperties.Ssl ssl = new CouchbaseProperties.Ssl();
/*     */     
/*  88 */     private final CouchbaseProperties.Timeouts timeouts = new CouchbaseProperties.Timeouts();
/*     */     
/*     */     public CouchbaseProperties.Io getIo() {
/*  91 */       return this.io;
/*     */     }
/*     */     
/*     */     public CouchbaseProperties.Ssl getSsl() {
/*  95 */       return this.ssl;
/*     */     }
/*     */     
/*     */     public CouchbaseProperties.Timeouts getTimeouts() {
/*  99 */       return this.timeouts;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Io
/*     */   {
/* 109 */     private int minEndpoints = 1;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 114 */     private int maxEndpoints = 12;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 120 */     private Duration idleHttpConnectionTimeout = Duration.ofMillis(4500L);
/*     */     
/*     */     public int getMinEndpoints() {
/* 123 */       return this.minEndpoints;
/*     */     }
/*     */     
/*     */     public void setMinEndpoints(int minEndpoints) {
/* 127 */       this.minEndpoints = minEndpoints;
/*     */     }
/*     */     
/*     */     public int getMaxEndpoints() {
/* 131 */       return this.maxEndpoints;
/*     */     }
/*     */     
/*     */     public void setMaxEndpoints(int maxEndpoints) {
/* 135 */       this.maxEndpoints = maxEndpoints;
/*     */     }
/*     */     
/*     */     public Duration getIdleHttpConnectionTimeout() {
/* 139 */       return this.idleHttpConnectionTimeout;
/*     */     }
/*     */     
/*     */     public void setIdleHttpConnectionTimeout(Duration idleHttpConnectionTimeout) {
/* 143 */       this.idleHttpConnectionTimeout = idleHttpConnectionTimeout;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Ssl
/*     */   {
/*     */     private Boolean enabled;
/*     */     
/*     */ 
/*     */ 
/*     */     private String keyStore;
/*     */     
/*     */ 
/*     */ 
/*     */     private String keyStorePassword;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public Boolean getEnabled()
/*     */     {
/* 167 */       return Boolean.valueOf(this.enabled != null ? this.enabled.booleanValue() : StringUtils.hasText(this.keyStore));
/*     */     }
/*     */     
/*     */     public void setEnabled(Boolean enabled) {
/* 171 */       this.enabled = enabled;
/*     */     }
/*     */     
/*     */     public String getKeyStore() {
/* 175 */       return this.keyStore;
/*     */     }
/*     */     
/*     */     public void setKeyStore(String keyStore) {
/* 179 */       this.keyStore = keyStore;
/*     */     }
/*     */     
/*     */     public String getKeyStorePassword() {
/* 183 */       return this.keyStorePassword;
/*     */     }
/*     */     
/*     */     public void setKeyStorePassword(String keyStorePassword) {
/* 187 */       this.keyStorePassword = keyStorePassword;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Timeouts
/*     */   {
/* 197 */     private Duration connect = Duration.ofSeconds(10L);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 202 */     private Duration disconnect = Duration.ofSeconds(10L);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 207 */     private Duration keyValue = Duration.ofMillis(2500L);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 212 */     private Duration keyValueDurable = Duration.ofSeconds(10L);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 217 */     private Duration query = Duration.ofSeconds(75L);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 222 */     private Duration view = Duration.ofSeconds(75L);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 227 */     private Duration search = Duration.ofSeconds(75L);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 232 */     private Duration analytics = Duration.ofSeconds(75L);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 237 */     private Duration management = Duration.ofSeconds(75L);
/*     */     
/*     */     public Duration getConnect() {
/* 240 */       return this.connect;
/*     */     }
/*     */     
/*     */     public void setConnect(Duration connect) {
/* 244 */       this.connect = connect;
/*     */     }
/*     */     
/*     */     public Duration getDisconnect() {
/* 248 */       return this.disconnect;
/*     */     }
/*     */     
/*     */     public void setDisconnect(Duration disconnect) {
/* 252 */       this.disconnect = disconnect;
/*     */     }
/*     */     
/*     */     public Duration getKeyValue() {
/* 256 */       return this.keyValue;
/*     */     }
/*     */     
/*     */     public void setKeyValue(Duration keyValue) {
/* 260 */       this.keyValue = keyValue;
/*     */     }
/*     */     
/*     */     public Duration getKeyValueDurable() {
/* 264 */       return this.keyValueDurable;
/*     */     }
/*     */     
/*     */     public void setKeyValueDurable(Duration keyValueDurable) {
/* 268 */       this.keyValueDurable = keyValueDurable;
/*     */     }
/*     */     
/*     */     public Duration getQuery() {
/* 272 */       return this.query;
/*     */     }
/*     */     
/*     */     public void setQuery(Duration query) {
/* 276 */       this.query = query;
/*     */     }
/*     */     
/*     */     public Duration getView() {
/* 280 */       return this.view;
/*     */     }
/*     */     
/*     */     public void setView(Duration view) {
/* 284 */       this.view = view;
/*     */     }
/*     */     
/*     */     public Duration getSearch() {
/* 288 */       return this.search;
/*     */     }
/*     */     
/*     */     public void setSearch(Duration search) {
/* 292 */       this.search = search;
/*     */     }
/*     */     
/*     */     public Duration getAnalytics() {
/* 296 */       return this.analytics;
/*     */     }
/*     */     
/*     */     public void setAnalytics(Duration analytics) {
/* 300 */       this.analytics = analytics;
/*     */     }
/*     */     
/*     */     public Duration getManagement() {
/* 304 */       return this.management;
/*     */     }
/*     */     
/*     */     public void setManagement(Duration management) {
/* 308 */       this.management = management;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\couchbase\CouchbaseProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */