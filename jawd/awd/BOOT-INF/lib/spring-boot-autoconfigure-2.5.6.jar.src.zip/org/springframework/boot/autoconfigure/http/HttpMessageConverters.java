/*     */ package org.springframework.boot.autoconfigure.http;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.http.converter.support.AllEncompassingFormHttpMessageConverter;
/*     */ import org.springframework.http.converter.xml.AbstractXmlHttpMessageConverter;
/*     */ import org.springframework.http.converter.xml.MappingJackson2XmlHttpMessageConverter;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.web.client.RestTemplate;
/*     */ import org.springframework.web.servlet.config.annotation.WebMvcConfigurationSupport;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpMessageConverters
/*     */   implements Iterable<HttpMessageConverter<?>>
/*     */ {
/*     */   private static final List<Class<?>> NON_REPLACING_CONVERTERS;
/*     */   private static final Map<Class<?>, Class<?>> EQUIVALENT_CONVERTERS;
/*     */   private final List<HttpMessageConverter<?>> converters;
/*     */   
/*     */   static
/*     */   {
/*  62 */     List<Class<?>> nonReplacingConverters = new ArrayList();
/*  63 */     addClassIfExists(nonReplacingConverters, "org.springframework.hateoas.server.mvc.TypeConstrainedMappingJackson2HttpMessageConverter");
/*     */     
/*  65 */     NON_REPLACING_CONVERTERS = Collections.unmodifiableList(nonReplacingConverters);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  71 */     Map<Class<?>, Class<?>> equivalentConverters = new HashMap();
/*  72 */     putIfExists(equivalentConverters, "org.springframework.http.converter.json.MappingJackson2HttpMessageConverter", "org.springframework.http.converter.json.GsonHttpMessageConverter");
/*     */     
/*  74 */     EQUIVALENT_CONVERTERS = Collections.unmodifiableMap(equivalentConverters);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpMessageConverters(HttpMessageConverter<?>... additionalConverters)
/*     */   {
/*  88 */     this(Arrays.asList(additionalConverters));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpMessageConverters(Collection<HttpMessageConverter<?>> additionalConverters)
/*     */   {
/* 100 */     this(true, additionalConverters);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpMessageConverters(boolean addDefaultConverters, Collection<HttpMessageConverter<?>> converters)
/*     */   {
/* 112 */     List<HttpMessageConverter<?>> combined = getCombinedConverters(converters, addDefaultConverters ? 
/* 113 */       getDefaultConverters() : Collections.emptyList());
/* 114 */     combined = postProcessConverters(combined);
/* 115 */     this.converters = Collections.unmodifiableList(combined);
/*     */   }
/*     */   
/*     */   private List<HttpMessageConverter<?>> getCombinedConverters(Collection<HttpMessageConverter<?>> converters, List<HttpMessageConverter<?>> defaultConverters)
/*     */   {
/* 120 */     List<HttpMessageConverter<?>> combined = new ArrayList();
/* 121 */     List<HttpMessageConverter<?>> processing = new ArrayList(converters);
/* 122 */     for (HttpMessageConverter<?> defaultConverter : defaultConverters) {
/* 123 */       Iterator<HttpMessageConverter<?>> iterator = processing.iterator();
/* 124 */       while (iterator.hasNext()) {
/* 125 */         HttpMessageConverter<?> candidate = (HttpMessageConverter)iterator.next();
/* 126 */         if (isReplacement(defaultConverter, candidate)) {
/* 127 */           combined.add(candidate);
/* 128 */           iterator.remove();
/*     */         }
/*     */       }
/* 131 */       combined.add(defaultConverter);
/* 132 */       if ((defaultConverter instanceof AllEncompassingFormHttpMessageConverter)) {
/* 133 */         configurePartConverters((AllEncompassingFormHttpMessageConverter)defaultConverter, converters);
/*     */       }
/*     */     }
/* 136 */     combined.addAll(0, processing);
/* 137 */     return combined;
/*     */   }
/*     */   
/*     */   private boolean isReplacement(HttpMessageConverter<?> defaultConverter, HttpMessageConverter<?> candidate) {
/* 141 */     for (Class<?> nonReplacingConverter : NON_REPLACING_CONVERTERS) {
/* 142 */       if (nonReplacingConverter.isInstance(candidate)) {
/* 143 */         return false;
/*     */       }
/*     */     }
/* 146 */     Object converterClass = defaultConverter.getClass();
/* 147 */     if (ClassUtils.isAssignableValue((Class)converterClass, candidate)) {
/* 148 */       return true;
/*     */     }
/* 150 */     Class<?> equivalentClass = (Class)EQUIVALENT_CONVERTERS.get(converterClass);
/* 151 */     return (equivalentClass != null) && (ClassUtils.isAssignableValue(equivalentClass, candidate));
/*     */   }
/*     */   
/*     */   private void configurePartConverters(AllEncompassingFormHttpMessageConverter formConverter, Collection<HttpMessageConverter<?>> converters)
/*     */   {
/* 156 */     List<HttpMessageConverter<?>> partConverters = formConverter.getPartConverters();
/* 157 */     List<HttpMessageConverter<?>> combinedConverters = getCombinedConverters(converters, partConverters);
/* 158 */     combinedConverters = postProcessPartConverters(combinedConverters);
/* 159 */     formConverter.setPartConverters(combinedConverters);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected List<HttpMessageConverter<?>> postProcessConverters(List<HttpMessageConverter<?>> converters)
/*     */   {
/* 169 */     return converters;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected List<HttpMessageConverter<?>> postProcessPartConverters(List<HttpMessageConverter<?>> converters)
/*     */   {
/* 181 */     return converters;
/*     */   }
/*     */   
/*     */   private List<HttpMessageConverter<?>> getDefaultConverters() {
/* 185 */     List<HttpMessageConverter<?>> converters = new ArrayList();
/* 186 */     if (ClassUtils.isPresent("org.springframework.web.servlet.config.annotation.WebMvcConfigurationSupport", null))
/*     */     {
/* 188 */       converters.addAll(new WebMvcConfigurationSupport()
/*     */       {
/*     */         public List<HttpMessageConverter<?>> defaultMessageConverters() {
/* 191 */           return super.getMessageConverters();
/*     */         }
/*     */         
/*     */ 
/*     */       }.defaultMessageConverters());
/*     */     } else {
/* 197 */       converters.addAll(new RestTemplate().getMessageConverters());
/*     */     }
/* 199 */     reorderXmlConvertersToEnd(converters);
/* 200 */     return converters;
/*     */   }
/*     */   
/*     */   private void reorderXmlConvertersToEnd(List<HttpMessageConverter<?>> converters) {
/* 204 */     List<HttpMessageConverter<?>> xml = new ArrayList();
/* 205 */     for (Iterator<HttpMessageConverter<?>> iterator = converters.iterator(); iterator.hasNext();) {
/* 206 */       HttpMessageConverter<?> converter = (HttpMessageConverter)iterator.next();
/* 207 */       if (((converter instanceof AbstractXmlHttpMessageConverter)) || ((converter instanceof MappingJackson2XmlHttpMessageConverter)))
/*     */       {
/* 209 */         xml.add(converter);
/* 210 */         iterator.remove();
/*     */       }
/*     */     }
/* 213 */     converters.addAll(xml);
/*     */   }
/*     */   
/*     */   public Iterator<HttpMessageConverter<?>> iterator()
/*     */   {
/* 218 */     return getConverters().iterator();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<HttpMessageConverter<?>> getConverters()
/*     */   {
/* 227 */     return this.converters;
/*     */   }
/*     */   
/*     */   private static void addClassIfExists(List<Class<?>> list, String className) {
/*     */     try {
/* 232 */       list.add(Class.forName(className));
/*     */     }
/*     */     catch (ClassNotFoundException|NoClassDefFoundError localClassNotFoundException) {}
/*     */   }
/*     */   
/*     */   private static void putIfExists(Map<Class<?>, Class<?>> map, String keyClassName, String valueClassName)
/*     */   {
/*     */     try
/*     */     {
/* 241 */       map.put(Class.forName(keyClassName), Class.forName(valueClassName));
/*     */     }
/*     */     catch (ClassNotFoundException|NoClassDefFoundError localClassNotFoundException) {}
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\http\HttpMessageConverters.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */