package org.springframework.boot.autoconfigure.cache;

import org.springframework.data.couchbase.cache.CouchbaseCacheManager.CouchbaseCacheManagerBuilder;

@FunctionalInterface
public abstract interface CouchbaseCacheManagerBuilderCustomizer
{
  public abstract void customize(CouchbaseCacheManager.CouchbaseCacheManagerBuilder paramCouchbaseCacheManagerBuilder);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\cache\CouchbaseCacheManagerBuilderCustomizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */