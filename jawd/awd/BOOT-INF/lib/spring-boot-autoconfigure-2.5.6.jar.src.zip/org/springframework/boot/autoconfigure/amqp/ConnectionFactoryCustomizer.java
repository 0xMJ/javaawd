package org.springframework.boot.autoconfigure.amqp;

import com.rabbitmq.client.ConnectionFactory;

@FunctionalInterface
public abstract interface ConnectionFactoryCustomizer
{
  public abstract void customize(ConnectionFactory paramConnectionFactory);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\amqp\ConnectionFactoryCustomizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */