/*     */ package org.springframework.boot.autoconfigure.data.mongo;
/*     */ 
/*     */ import com.mongodb.ClientSessionOptions;
/*     */ import com.mongodb.reactivestreams.client.ClientSession;
/*     */ import com.mongodb.reactivestreams.client.MongoClient;
/*     */ import com.mongodb.reactivestreams.client.MongoDatabase;
/*     */ import java.util.Optional;
/*     */ import org.bson.codecs.Codec;
/*     */ import org.bson.codecs.configuration.CodecRegistry;
/*     */ import org.springframework.boot.autoconfigure.AutoConfigureAfter;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.mongo.MongoProperties;
/*     */ import org.springframework.boot.autoconfigure.mongo.MongoProperties.Gridfs;
/*     */ import org.springframework.boot.autoconfigure.mongo.MongoReactiveAutoConfiguration;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.context.annotation.Import;
/*     */ import org.springframework.core.io.buffer.DataBufferFactory;
/*     */ import org.springframework.core.io.buffer.DefaultDataBufferFactory;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.dao.support.PersistenceExceptionTranslator;
/*     */ import org.springframework.data.mongodb.ReactiveMongoDatabaseFactory;
/*     */ import org.springframework.data.mongodb.core.ReactiveMongoOperations;
/*     */ import org.springframework.data.mongodb.core.ReactiveMongoTemplate;
/*     */ import org.springframework.data.mongodb.core.SimpleReactiveMongoDatabaseFactory;
/*     */ import org.springframework.data.mongodb.core.convert.MappingMongoConverter;
/*     */ import org.springframework.data.mongodb.core.convert.MongoConverter;
/*     */ import org.springframework.data.mongodb.core.convert.MongoCustomConversions;
/*     */ import org.springframework.data.mongodb.core.convert.NoOpDbRefResolver;
/*     */ import org.springframework.data.mongodb.core.mapping.MongoMappingContext;
/*     */ import org.springframework.data.mongodb.gridfs.ReactiveGridFsOperations;
/*     */ import org.springframework.data.mongodb.gridfs.ReactiveGridFsTemplate;
/*     */ import org.springframework.util.StringUtils;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods=false)
/*     */ @ConditionalOnClass({MongoClient.class, ReactiveMongoTemplate.class})
/*     */ @ConditionalOnBean({MongoClient.class})
/*     */ @EnableConfigurationProperties({MongoProperties.class})
/*     */ @Import({MongoDataConfiguration.class})
/*     */ @AutoConfigureAfter({MongoReactiveAutoConfiguration.class})
/*     */ public class MongoReactiveDataAutoConfiguration
/*     */ {
/*     */   @Bean
/*     */   @ConditionalOnMissingBean({ReactiveMongoDatabaseFactory.class})
/*     */   public SimpleReactiveMongoDatabaseFactory reactiveMongoDatabaseFactory(MongoProperties properties, MongoClient mongo)
/*     */   {
/*  84 */     String database = properties.getMongoClientDatabase();
/*  85 */     return new SimpleReactiveMongoDatabaseFactory(mongo, database);
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean({ReactiveMongoOperations.class})
/*     */   public ReactiveMongoTemplate reactiveMongoTemplate(ReactiveMongoDatabaseFactory reactiveMongoDatabaseFactory, MongoConverter converter)
/*     */   {
/*  92 */     return new ReactiveMongoTemplate(reactiveMongoDatabaseFactory, converter);
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean({MongoConverter.class})
/*     */   public MappingMongoConverter mappingMongoConverter(MongoMappingContext context, MongoCustomConversions conversions)
/*     */   {
/*  99 */     MappingMongoConverter mappingConverter = new MappingMongoConverter(NoOpDbRefResolver.INSTANCE, context);
/* 100 */     mappingConverter.setCustomConversions(conversions);
/* 101 */     return mappingConverter;
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean({DataBufferFactory.class})
/*     */   public DefaultDataBufferFactory dataBufferFactory() {
/* 107 */     return new DefaultDataBufferFactory();
/*     */   }
/*     */   
/*     */ 
/*     */   @Bean
/*     */   @ConditionalOnMissingBean({ReactiveGridFsOperations.class})
/*     */   public ReactiveGridFsTemplate reactiveGridFsTemplate(ReactiveMongoDatabaseFactory reactiveMongoDatabaseFactory, MappingMongoConverter mappingMongoConverter, DataBufferFactory dataBufferFactory, MongoProperties properties)
/*     */   {
/* 115 */     return new ReactiveGridFsTemplate(dataBufferFactory, new GridFsReactiveMongoDatabaseFactory(reactiveMongoDatabaseFactory, properties), mappingMongoConverter, properties
/*     */     
/* 117 */       .getGridfs().getBucket());
/*     */   }
/*     */   
/*     */ 
/*     */   static class GridFsReactiveMongoDatabaseFactory
/*     */     implements ReactiveMongoDatabaseFactory
/*     */   {
/*     */     private final ReactiveMongoDatabaseFactory delegate;
/*     */     
/*     */     private final MongoProperties properties;
/*     */     
/*     */ 
/*     */     GridFsReactiveMongoDatabaseFactory(ReactiveMongoDatabaseFactory delegate, MongoProperties properties)
/*     */     {
/* 131 */       this.delegate = delegate;
/* 132 */       this.properties = properties;
/*     */     }
/*     */     
/*     */     public boolean hasCodecFor(Class<?> type)
/*     */     {
/* 137 */       return this.delegate.hasCodecFor(type);
/*     */     }
/*     */     
/*     */     public Mono<MongoDatabase> getMongoDatabase() throws DataAccessException
/*     */     {
/* 142 */       String gridFsDatabase = this.properties.getGridfs().getDatabase();
/* 143 */       if (StringUtils.hasText(gridFsDatabase)) {
/* 144 */         return this.delegate.getMongoDatabase(gridFsDatabase);
/*     */       }
/* 146 */       return this.delegate.getMongoDatabase();
/*     */     }
/*     */     
/*     */     public Mono<MongoDatabase> getMongoDatabase(String dbName) throws DataAccessException
/*     */     {
/* 151 */       return this.delegate.getMongoDatabase(dbName);
/*     */     }
/*     */     
/*     */     public <T> Optional<Codec<T>> getCodecFor(Class<T> type)
/*     */     {
/* 156 */       return this.delegate.getCodecFor(type);
/*     */     }
/*     */     
/*     */     public PersistenceExceptionTranslator getExceptionTranslator()
/*     */     {
/* 161 */       return this.delegate.getExceptionTranslator();
/*     */     }
/*     */     
/*     */     public CodecRegistry getCodecRegistry()
/*     */     {
/* 166 */       return this.delegate.getCodecRegistry();
/*     */     }
/*     */     
/*     */     public Mono<ClientSession> getSession(ClientSessionOptions options)
/*     */     {
/* 171 */       return this.delegate.getSession(options);
/*     */     }
/*     */     
/*     */     public ReactiveMongoDatabaseFactory withSession(ClientSession session)
/*     */     {
/* 176 */       return this.delegate.withSession(session);
/*     */     }
/*     */     
/*     */     public boolean isTransactionActive()
/*     */     {
/* 181 */       return this.delegate.isTransactionActive();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\data\mongo\MongoReactiveDataAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */