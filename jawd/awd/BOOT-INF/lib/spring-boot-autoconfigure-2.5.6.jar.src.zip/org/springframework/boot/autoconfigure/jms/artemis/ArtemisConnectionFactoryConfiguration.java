/*    */ package org.springframework.boot.autoconfigure.jms.artemis;
/*    */ 
/*    */ import javax.jms.ConnectionFactory;
/*    */ import org.apache.activemq.artemis.jms.client.ActiveMQConnectionFactory;
/*    */ import org.apache.commons.pool2.PooledObject;
/*    */ import org.messaginghub.pooled.jms.JmsPoolConnectionFactory;
/*    */ import org.springframework.beans.factory.ListableBeanFactory;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*    */ import org.springframework.boot.autoconfigure.jms.JmsPoolConnectionFactoryFactory;
/*    */ import org.springframework.boot.autoconfigure.jms.JmsProperties;
/*    */ import org.springframework.boot.autoconfigure.jms.JmsProperties.Cache;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.jms.connection.CachingConnectionFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods=false)
/*    */ @ConditionalOnMissingBean({ConnectionFactory.class})
/*    */ class ArtemisConnectionFactoryConfiguration
/*    */ {
/*    */   @Configuration(proxyBeanMethods=false)
/*    */   @ConditionalOnClass({CachingConnectionFactory.class})
/*    */   @ConditionalOnProperty(prefix="spring.artemis.pool", name={"enabled"}, havingValue="false", matchIfMissing=true)
/*    */   static class SimpleConnectionFactoryConfiguration
/*    */   {
/*    */     private final ArtemisProperties properties;
/*    */     private final ListableBeanFactory beanFactory;
/*    */     
/*    */     SimpleConnectionFactoryConfiguration(ArtemisProperties properties, ListableBeanFactory beanFactory)
/*    */     {
/* 57 */       this.properties = properties;
/* 58 */       this.beanFactory = beanFactory;
/*    */     }
/*    */     
/*    */     @Bean(name={"jmsConnectionFactory"})
/*    */     @ConditionalOnProperty(prefix="spring.jms.cache", name={"enabled"}, havingValue="true", matchIfMissing=true)
/*    */     CachingConnectionFactory cachingJmsConnectionFactory(JmsProperties jmsProperties)
/*    */     {
/* 65 */       JmsProperties.Cache cacheProperties = jmsProperties.getCache();
/* 66 */       CachingConnectionFactory connectionFactory = new CachingConnectionFactory(createConnectionFactory());
/* 67 */       connectionFactory.setCacheConsumers(cacheProperties.isConsumers());
/* 68 */       connectionFactory.setCacheProducers(cacheProperties.isProducers());
/* 69 */       connectionFactory.setSessionCacheSize(cacheProperties.getSessionCacheSize());
/* 70 */       return connectionFactory;
/*    */     }
/*    */     
/*    */     @Bean(name={"jmsConnectionFactory"})
/*    */     @ConditionalOnProperty(prefix="spring.jms.cache", name={"enabled"}, havingValue="false")
/*    */     ActiveMQConnectionFactory jmsConnectionFactory() {
/* 76 */       return createConnectionFactory();
/*    */     }
/*    */     
/*    */     private ActiveMQConnectionFactory createConnectionFactory() {
/* 80 */       return 
/* 81 */         new ArtemisConnectionFactoryFactory(this.beanFactory, this.properties).createConnectionFactory(ActiveMQConnectionFactory.class);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   @Configuration(proxyBeanMethods=false)
/*    */   @ConditionalOnClass({JmsPoolConnectionFactory.class, PooledObject.class})
/*    */   @ConditionalOnProperty(prefix="spring.artemis.pool", name={"enabled"}, havingValue="true")
/*    */   static class PooledConnectionFactoryConfiguration
/*    */   {
/*    */     @Bean(destroyMethod="stop")
/*    */     JmsPoolConnectionFactory jmsConnectionFactory(ListableBeanFactory beanFactory, ArtemisProperties properties)
/*    */     {
/* 94 */       ActiveMQConnectionFactory connectionFactory = new ArtemisConnectionFactoryFactory(beanFactory, properties).createConnectionFactory(ActiveMQConnectionFactory.class);
/* 95 */       return new JmsPoolConnectionFactoryFactory(properties.getPool())
/* 96 */         .createPooledConnectionFactory(connectionFactory);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\jms\artemis\ArtemisConnectionFactoryConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */