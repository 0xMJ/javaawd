/*     */ package org.springframework.boot.autoconfigure.data.mongo;
/*     */ 
/*     */ import com.mongodb.ClientSessionOptions;
/*     */ import com.mongodb.client.ClientSession;
/*     */ import com.mongodb.client.MongoDatabase;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.mongo.MongoProperties;
/*     */ import org.springframework.boot.autoconfigure.mongo.MongoProperties.Gridfs;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.dao.support.PersistenceExceptionTranslator;
/*     */ import org.springframework.data.mongodb.MongoDatabaseFactory;
/*     */ import org.springframework.data.mongodb.core.MongoOperations;
/*     */ import org.springframework.data.mongodb.core.MongoTemplate;
/*     */ import org.springframework.data.mongodb.core.convert.DbRefResolver;
/*     */ import org.springframework.data.mongodb.core.convert.DefaultDbRefResolver;
/*     */ import org.springframework.data.mongodb.core.convert.MappingMongoConverter;
/*     */ import org.springframework.data.mongodb.core.convert.MongoConverter;
/*     */ import org.springframework.data.mongodb.core.convert.MongoCustomConversions;
/*     */ import org.springframework.data.mongodb.core.mapping.MongoMappingContext;
/*     */ import org.springframework.data.mongodb.gridfs.GridFsOperations;
/*     */ import org.springframework.data.mongodb.gridfs.GridFsTemplate;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods=false)
/*     */ @ConditionalOnBean({MongoDatabaseFactory.class})
/*     */ class MongoDatabaseFactoryDependentConfiguration
/*     */ {
/*     */   private final MongoProperties properties;
/*     */   
/*     */   MongoDatabaseFactoryDependentConfiguration(MongoProperties properties)
/*     */   {
/*  57 */     this.properties = properties;
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean({MongoOperations.class})
/*     */   MongoTemplate mongoTemplate(MongoDatabaseFactory factory, MongoConverter converter) {
/*  63 */     return new MongoTemplate(factory, converter);
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean({MongoConverter.class})
/*     */   MappingMongoConverter mappingMongoConverter(MongoDatabaseFactory factory, MongoMappingContext context, MongoCustomConversions conversions)
/*     */   {
/*  70 */     DbRefResolver dbRefResolver = new DefaultDbRefResolver(factory);
/*  71 */     MappingMongoConverter mappingConverter = new MappingMongoConverter(dbRefResolver, context);
/*  72 */     mappingConverter.setCustomConversions(conversions);
/*  73 */     return mappingConverter;
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean({GridFsOperations.class})
/*     */   GridFsTemplate gridFsTemplate(MongoDatabaseFactory factory, MongoTemplate mongoTemplate) {
/*  79 */     return new GridFsTemplate(new GridFsMongoDatabaseFactory(factory, this.properties), mongoTemplate
/*  80 */       .getConverter(), this.properties.getGridfs().getBucket());
/*     */   }
/*     */   
/*     */ 
/*     */   static class GridFsMongoDatabaseFactory
/*     */     implements MongoDatabaseFactory
/*     */   {
/*     */     private final MongoDatabaseFactory mongoDatabaseFactory;
/*     */     
/*     */     private final MongoProperties properties;
/*     */     
/*     */ 
/*     */     GridFsMongoDatabaseFactory(MongoDatabaseFactory mongoDatabaseFactory, MongoProperties properties)
/*     */     {
/*  94 */       Assert.notNull(mongoDatabaseFactory, "MongoDatabaseFactory must not be null");
/*  95 */       Assert.notNull(properties, "Properties must not be null");
/*  96 */       this.mongoDatabaseFactory = mongoDatabaseFactory;
/*  97 */       this.properties = properties;
/*     */     }
/*     */     
/*     */     public MongoDatabase getMongoDatabase() throws DataAccessException
/*     */     {
/* 102 */       String gridFsDatabase = this.properties.getGridfs().getDatabase();
/* 103 */       if (StringUtils.hasText(gridFsDatabase)) {
/* 104 */         return this.mongoDatabaseFactory.getMongoDatabase(gridFsDatabase);
/*     */       }
/* 106 */       return this.mongoDatabaseFactory.getMongoDatabase();
/*     */     }
/*     */     
/*     */     public MongoDatabase getMongoDatabase(String dbName) throws DataAccessException
/*     */     {
/* 111 */       return this.mongoDatabaseFactory.getMongoDatabase(dbName);
/*     */     }
/*     */     
/*     */     public PersistenceExceptionTranslator getExceptionTranslator()
/*     */     {
/* 116 */       return this.mongoDatabaseFactory.getExceptionTranslator();
/*     */     }
/*     */     
/*     */     public ClientSession getSession(ClientSessionOptions options)
/*     */     {
/* 121 */       return this.mongoDatabaseFactory.getSession(options);
/*     */     }
/*     */     
/*     */     public MongoDatabaseFactory withSession(ClientSession session)
/*     */     {
/* 126 */       return this.mongoDatabaseFactory.withSession(session);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\data\mongo\MongoDatabaseFactoryDependentConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */