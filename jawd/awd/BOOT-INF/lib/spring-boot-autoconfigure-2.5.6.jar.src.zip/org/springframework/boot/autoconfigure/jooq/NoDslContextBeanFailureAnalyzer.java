/*    */ package org.springframework.boot.autoconfigure.jooq;
/*    */ 
/*    */ import org.jooq.DSLContext;
/*    */ import org.springframework.beans.BeansException;
/*    */ import org.springframework.beans.factory.BeanFactory;
/*    */ import org.springframework.beans.factory.BeanFactoryAware;
/*    */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*    */ import org.springframework.boot.autoconfigure.r2dbc.R2dbcAutoConfiguration;
/*    */ import org.springframework.boot.diagnostics.AbstractFailureAnalyzer;
/*    */ import org.springframework.boot.diagnostics.FailureAnalysis;
/*    */ import org.springframework.core.Ordered;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class NoDslContextBeanFailureAnalyzer
/*    */   extends AbstractFailureAnalyzer<NoSuchBeanDefinitionException>
/*    */   implements Ordered, BeanFactoryAware
/*    */ {
/*    */   private BeanFactory beanFactory;
/*    */   
/*    */   protected FailureAnalysis analyze(Throwable rootFailure, NoSuchBeanDefinitionException cause)
/*    */   {
/* 37 */     if ((DSLContext.class.equals(cause.getBeanType())) && (hasR2dbcAutoConfiguration())) {
/* 38 */       return new FailureAnalysis("jOOQ has not been auto-configured as R2DBC has been auto-configured in favor of JDBC and jOOQ auto-configuration does not yet support R2DBC. ", "To use jOOQ with JDBC, exclude R2dbcAutoConfiguration. To use jOOQ with R2DBC, define your own jOOQ configuration.", cause);
/*    */     }
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 45 */     return null;
/*    */   }
/*    */   
/*    */   private boolean hasR2dbcAutoConfiguration() {
/*    */     try {
/* 50 */       this.beanFactory.getBean(R2dbcAutoConfiguration.class);
/* 51 */       return true;
/*    */     }
/*    */     catch (Exception ex) {}
/* 54 */     return false;
/*    */   }
/*    */   
/*    */ 
/*    */   public int getOrder()
/*    */   {
/* 60 */     return 0;
/*    */   }
/*    */   
/*    */   public void setBeanFactory(BeanFactory beanFactory) throws BeansException
/*    */   {
/* 65 */     this.beanFactory = beanFactory;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\jooq\NoDslContextBeanFailureAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */