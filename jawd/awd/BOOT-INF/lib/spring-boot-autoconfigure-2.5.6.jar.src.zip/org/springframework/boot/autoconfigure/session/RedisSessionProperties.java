/*     */ package org.springframework.boot.autoconfigure.session;
/*     */ 
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.session.FlushMode;
/*     */ import org.springframework.session.SaveMode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix="spring.session.redis")
/*     */ public class RedisSessionProperties
/*     */ {
/*     */   private static final String DEFAULT_CLEANUP_CRON = "0 * * * * *";
/*  37 */   private String namespace = "spring:session";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  43 */   private FlushMode flushMode = FlushMode.ON_SAVE;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  49 */   private SaveMode saveMode = SaveMode.ON_SET_ATTRIBUTE;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  55 */   private ConfigureAction configureAction = ConfigureAction.NOTIFY_KEYSPACE_EVENTS;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  60 */   private String cleanupCron = "0 * * * * *";
/*     */   
/*     */   public String getNamespace() {
/*  63 */     return this.namespace;
/*     */   }
/*     */   
/*     */   public void setNamespace(String namespace) {
/*  67 */     this.namespace = namespace;
/*     */   }
/*     */   
/*     */   public FlushMode getFlushMode() {
/*  71 */     return this.flushMode;
/*     */   }
/*     */   
/*     */   public void setFlushMode(FlushMode flushMode) {
/*  75 */     this.flushMode = flushMode;
/*     */   }
/*     */   
/*     */   public SaveMode getSaveMode() {
/*  79 */     return this.saveMode;
/*     */   }
/*     */   
/*     */   public void setSaveMode(SaveMode saveMode) {
/*  83 */     this.saveMode = saveMode;
/*     */   }
/*     */   
/*     */   public String getCleanupCron() {
/*  87 */     return this.cleanupCron;
/*     */   }
/*     */   
/*     */   public void setCleanupCron(String cleanupCron) {
/*  91 */     this.cleanupCron = cleanupCron;
/*     */   }
/*     */   
/*     */   public ConfigureAction getConfigureAction() {
/*  95 */     return this.configureAction;
/*     */   }
/*     */   
/*     */   public void setConfigureAction(ConfigureAction configureAction) {
/*  99 */     this.configureAction = configureAction;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static enum ConfigureAction
/*     */   {
/* 111 */     NOTIFY_KEYSPACE_EVENTS, 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 116 */     NONE;
/*     */     
/*     */     private ConfigureAction() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\session\RedisSessionProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */