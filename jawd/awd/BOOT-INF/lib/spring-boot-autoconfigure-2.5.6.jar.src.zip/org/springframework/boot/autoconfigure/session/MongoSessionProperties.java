/*    */ package org.springframework.boot.autoconfigure.session;
/*    */ 
/*    */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @ConfigurationProperties(prefix="spring.session.mongodb")
/*    */ public class MongoSessionProperties
/*    */ {
/* 33 */   private String collectionName = "sessions";
/*    */   
/*    */   public String getCollectionName() {
/* 36 */     return this.collectionName;
/*    */   }
/*    */   
/*    */   public void setCollectionName(String collectionName) {
/* 40 */     this.collectionName = collectionName;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\session\MongoSessionProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */