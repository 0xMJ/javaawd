/*    */ package org.springframework.boot.autoconfigure.validation;
/*    */ 
/*    */ import javax.validation.Validator;
/*    */ import javax.validation.executable.ExecutableValidator;
/*    */ import org.springframework.beans.factory.ObjectProvider;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnResource;
/*    */ import org.springframework.boot.validation.MessageInterpolatorFactory;
/*    */ import org.springframework.boot.validation.beanvalidation.FilteredMethodValidationPostProcessor;
/*    */ import org.springframework.boot.validation.beanvalidation.MethodValidationExcludeFilter;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.Import;
/*    */ import org.springframework.context.annotation.Lazy;
/*    */ import org.springframework.context.annotation.Role;
/*    */ import org.springframework.core.env.Environment;
/*    */ import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;
/*    */ import org.springframework.validation.beanvalidation.MethodValidationPostProcessor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods=false)
/*    */ @ConditionalOnClass({ExecutableValidator.class})
/*    */ @ConditionalOnResource(resources={"classpath:META-INF/services/javax.validation.spi.ValidationProvider"})
/*    */ @Import({PrimaryDefaultValidatorPostProcessor.class})
/*    */ public class ValidationAutoConfiguration
/*    */ {
/*    */   @Bean
/*    */   @Role(2)
/*    */   @ConditionalOnMissingBean({Validator.class})
/*    */   public static LocalValidatorFactoryBean defaultValidator()
/*    */   {
/* 58 */     LocalValidatorFactoryBean factoryBean = new LocalValidatorFactoryBean();
/* 59 */     MessageInterpolatorFactory interpolatorFactory = new MessageInterpolatorFactory();
/* 60 */     factoryBean.setMessageInterpolator(interpolatorFactory.getObject());
/* 61 */     return factoryBean;
/*    */   }
/*    */   
/*    */ 
/*    */   @Bean
/*    */   @ConditionalOnMissingBean
/*    */   public static MethodValidationPostProcessor methodValidationPostProcessor(Environment environment, @Lazy Validator validator, ObjectProvider<MethodValidationExcludeFilter> excludeFilters)
/*    */   {
/* 69 */     FilteredMethodValidationPostProcessor processor = new FilteredMethodValidationPostProcessor(excludeFilters.orderedStream());
/* 70 */     boolean proxyTargetClass = ((Boolean)environment.getProperty("spring.aop.proxy-target-class", Boolean.class, Boolean.valueOf(true))).booleanValue();
/* 71 */     processor.setProxyTargetClass(proxyTargetClass);
/* 72 */     processor.setValidator(validator);
/* 73 */     return processor;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\validation\ValidationAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */