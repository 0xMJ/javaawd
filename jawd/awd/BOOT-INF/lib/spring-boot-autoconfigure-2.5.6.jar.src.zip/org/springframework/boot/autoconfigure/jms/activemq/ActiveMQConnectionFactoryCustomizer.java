package org.springframework.boot.autoconfigure.jms.activemq;

import org.apache.activemq.ActiveMQConnectionFactory;

@FunctionalInterface
public abstract interface ActiveMQConnectionFactoryCustomizer
{
  public abstract void customize(ActiveMQConnectionFactory paramActiveMQConnectionFactory);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\jms\activemq\ActiveMQConnectionFactoryCustomizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */