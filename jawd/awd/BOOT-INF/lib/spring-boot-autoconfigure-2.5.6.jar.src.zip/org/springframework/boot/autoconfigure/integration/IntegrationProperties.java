/*     */ package org.springframework.boot.autoconfigure.integration;
/*     */ 
/*     */ import java.net.URI;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.boot.jdbc.DataSourceInitializationMode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix="spring.integration")
/*     */ public class IntegrationProperties
/*     */ {
/*  37 */   private final Channel channel = new Channel();
/*     */   
/*  39 */   private final Endpoint endpoint = new Endpoint();
/*     */   
/*  41 */   private final Error error = new Error();
/*     */   
/*  43 */   private final Jdbc jdbc = new Jdbc();
/*     */   
/*  45 */   private final RSocket rsocket = new RSocket();
/*     */   
/*     */   public Channel getChannel() {
/*  48 */     return this.channel;
/*     */   }
/*     */   
/*     */   public Endpoint getEndpoint() {
/*  52 */     return this.endpoint;
/*     */   }
/*     */   
/*     */   public Error getError() {
/*  56 */     return this.error;
/*     */   }
/*     */   
/*     */   public Jdbc getJdbc() {
/*  60 */     return this.jdbc;
/*     */   }
/*     */   
/*     */   public RSocket getRsocket() {
/*  64 */     return this.rsocket;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Channel
/*     */   {
/*  72 */     private boolean autoCreate = true;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  77 */     private int maxUnicastSubscribers = Integer.MAX_VALUE;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  83 */     private int maxBroadcastSubscribers = Integer.MAX_VALUE;
/*     */     
/*     */     public void setAutoCreate(boolean autoCreate) {
/*  86 */       this.autoCreate = autoCreate;
/*     */     }
/*     */     
/*     */     public boolean isAutoCreate() {
/*  90 */       return this.autoCreate;
/*     */     }
/*     */     
/*     */     public void setMaxUnicastSubscribers(int maxUnicastSubscribers) {
/*  94 */       this.maxUnicastSubscribers = maxUnicastSubscribers;
/*     */     }
/*     */     
/*     */     public int getMaxUnicastSubscribers() {
/*  98 */       return this.maxUnicastSubscribers;
/*     */     }
/*     */     
/*     */     public void setMaxBroadcastSubscribers(int maxBroadcastSubscribers) {
/* 102 */       this.maxBroadcastSubscribers = maxBroadcastSubscribers;
/*     */     }
/*     */     
/*     */     public int getMaxBroadcastSubscribers() {
/* 106 */       return this.maxBroadcastSubscribers;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Endpoint
/*     */   {
/* 117 */     private boolean throwExceptionOnLateReply = false;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 123 */     private List<String> readOnlyHeaders = new ArrayList();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 129 */     private List<String> noAutoStartup = new ArrayList();
/*     */     
/*     */     public void setThrowExceptionOnLateReply(boolean throwExceptionOnLateReply) {
/* 132 */       this.throwExceptionOnLateReply = throwExceptionOnLateReply;
/*     */     }
/*     */     
/*     */     public boolean isThrowExceptionOnLateReply() {
/* 136 */       return this.throwExceptionOnLateReply;
/*     */     }
/*     */     
/*     */     public List<String> getReadOnlyHeaders() {
/* 140 */       return this.readOnlyHeaders;
/*     */     }
/*     */     
/*     */     public void setReadOnlyHeaders(List<String> readOnlyHeaders) {
/* 144 */       this.readOnlyHeaders = readOnlyHeaders;
/*     */     }
/*     */     
/*     */     public List<String> getNoAutoStartup() {
/* 148 */       return this.noAutoStartup;
/*     */     }
/*     */     
/*     */     public void setNoAutoStartup(List<String> noAutoStartup) {
/* 152 */       this.noAutoStartup = noAutoStartup;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Error
/*     */   {
/* 163 */     private boolean requireSubscribers = true;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 169 */     private boolean ignoreFailures = true;
/*     */     
/*     */     public boolean isRequireSubscribers() {
/* 172 */       return this.requireSubscribers;
/*     */     }
/*     */     
/*     */     public void setRequireSubscribers(boolean requireSubscribers) {
/* 176 */       this.requireSubscribers = requireSubscribers;
/*     */     }
/*     */     
/*     */     public boolean isIgnoreFailures() {
/* 180 */       return this.ignoreFailures;
/*     */     }
/*     */     
/*     */     public void setIgnoreFailures(boolean ignoreFailures) {
/* 184 */       this.ignoreFailures = ignoreFailures;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Jdbc
/*     */   {
/*     */     private static final String DEFAULT_SCHEMA_LOCATION = "classpath:org/springframework/integration/jdbc/schema-@@platform@@.sql";
/*     */     
/*     */ 
/*     */ 
/* 197 */     private String schema = "classpath:org/springframework/integration/jdbc/schema-@@platform@@.sql";
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 202 */     private DataSourceInitializationMode initializeSchema = DataSourceInitializationMode.EMBEDDED;
/*     */     
/*     */     public String getSchema() {
/* 205 */       return this.schema;
/*     */     }
/*     */     
/*     */     public void setSchema(String schema) {
/* 209 */       this.schema = schema;
/*     */     }
/*     */     
/*     */     public DataSourceInitializationMode getInitializeSchema() {
/* 213 */       return this.initializeSchema;
/*     */     }
/*     */     
/*     */     public void setInitializeSchema(DataSourceInitializationMode initializeSchema) {
/* 217 */       this.initializeSchema = initializeSchema;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public static class RSocket
/*     */   {
/* 224 */     private final Client client = new Client();
/*     */     
/* 226 */     private final Server server = new Server();
/*     */     
/*     */     public Client getClient() {
/* 229 */       return this.client;
/*     */     }
/*     */     
/*     */     public Server getServer() {
/* 233 */       return this.server;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public static class Client
/*     */     {
/*     */       private String host;
/*     */       
/*     */ 
/*     */ 
/*     */       private Integer port;
/*     */       
/*     */ 
/*     */       private URI uri;
/*     */       
/*     */ 
/*     */ 
/*     */       public void setHost(String host)
/*     */       {
/* 254 */         this.host = host;
/*     */       }
/*     */       
/*     */       public String getHost() {
/* 258 */         return this.host;
/*     */       }
/*     */       
/*     */       public void setPort(Integer port) {
/* 262 */         this.port = port;
/*     */       }
/*     */       
/*     */       public Integer getPort() {
/* 266 */         return this.port;
/*     */       }
/*     */       
/*     */       public void setUri(URI uri) {
/* 270 */         this.uri = uri;
/*     */       }
/*     */       
/*     */       public URI getUri() {
/* 274 */         return this.uri;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public static class Server
/*     */     {
/*     */       private boolean messageMappingEnabled;
/*     */       
/*     */ 
/*     */       public boolean isMessageMappingEnabled()
/*     */       {
/* 287 */         return this.messageMappingEnabled;
/*     */       }
/*     */       
/*     */       public void setMessageMappingEnabled(boolean messageMappingEnabled) {
/* 291 */         this.messageMappingEnabled = messageMappingEnabled;
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\integration\IntegrationProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */