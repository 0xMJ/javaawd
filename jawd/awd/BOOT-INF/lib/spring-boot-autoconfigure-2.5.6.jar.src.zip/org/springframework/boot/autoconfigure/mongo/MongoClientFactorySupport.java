/*    */ package org.springframework.boot.autoconfigure.mongo;
/*    */ 
/*    */ import com.mongodb.MongoClientSettings;
/*    */ import com.mongodb.MongoClientSettings.Builder;
/*    */ import com.mongodb.MongoDriverInformation;
/*    */ import com.mongodb.MongoDriverInformation.Builder;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import java.util.function.BiFunction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class MongoClientFactorySupport<T>
/*    */ {
/*    */   private final List<MongoClientSettingsBuilderCustomizer> builderCustomizers;
/*    */   private final BiFunction<MongoClientSettings, MongoDriverInformation, T> clientCreator;
/*    */   
/*    */   protected MongoClientFactorySupport(List<MongoClientSettingsBuilderCustomizer> builderCustomizers, BiFunction<MongoClientSettings, MongoDriverInformation, T> clientCreator)
/*    */   {
/* 43 */     this.builderCustomizers = (builderCustomizers != null ? builderCustomizers : Collections.emptyList());
/* 44 */     this.clientCreator = clientCreator;
/*    */   }
/*    */   
/*    */   public T createMongoClient(MongoClientSettings settings) {
/* 48 */     MongoClientSettings.Builder targetSettings = MongoClientSettings.builder(settings);
/* 49 */     customize(targetSettings);
/* 50 */     return (T)this.clientCreator.apply(targetSettings.build(), driverInformation());
/*    */   }
/*    */   
/*    */   private void customize(MongoClientSettings.Builder builder) {
/* 54 */     for (MongoClientSettingsBuilderCustomizer customizer : this.builderCustomizers) {
/* 55 */       customizer.customize(builder);
/*    */     }
/*    */   }
/*    */   
/*    */   private MongoDriverInformation driverInformation() {
/* 60 */     return 
/* 61 */       MongoDriverInformation.builder(MongoDriverInformation.builder().build()).driverName("spring-boot").build();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\mongo\MongoClientFactorySupport.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */