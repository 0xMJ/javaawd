/*    */ package org.springframework.boot.autoconfigure.cache;
/*    */ 
/*    */ import com.hazelcast.core.HazelcastInstance;
/*    */ import java.io.IOException;
/*    */ import java.net.URI;
/*    */ import java.util.Properties;
/*    */ import org.springframework.beans.factory.ObjectProvider;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.core.io.Resource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods=false)
/*    */ @ConditionalOnClass({HazelcastInstance.class})
/*    */ class HazelcastJCacheCustomizationConfiguration
/*    */ {
/*    */   @Bean
/*    */   HazelcastPropertiesCustomizer hazelcastPropertiesCustomizer(ObjectProvider<HazelcastInstance> hazelcastInstance)
/*    */   {
/* 42 */     return new HazelcastPropertiesCustomizer((HazelcastInstance)hazelcastInstance.getIfUnique());
/*    */   }
/*    */   
/*    */   static class HazelcastPropertiesCustomizer implements JCachePropertiesCustomizer
/*    */   {
/*    */     private final HazelcastInstance hazelcastInstance;
/*    */     
/*    */     HazelcastPropertiesCustomizer(HazelcastInstance hazelcastInstance) {
/* 50 */       this.hazelcastInstance = hazelcastInstance;
/*    */     }
/*    */     
/*    */     public void customize(CacheProperties cacheProperties, Properties properties)
/*    */     {
/* 55 */       Resource configLocation = cacheProperties.resolveConfigLocation(cacheProperties.getJcache().getConfig());
/* 56 */       if (configLocation != null)
/*    */       {
/* 58 */         properties.setProperty("hazelcast.config.location", toUri(configLocation).toString());
/*    */       }
/* 60 */       else if (this.hazelcastInstance != null) {
/* 61 */         properties.put("hazelcast.instance.itself", this.hazelcastInstance);
/*    */       }
/*    */     }
/*    */     
/*    */     private static URI toUri(Resource config) {
/*    */       try {
/* 67 */         return config.getURI();
/*    */       }
/*    */       catch (IOException ex) {
/* 70 */         throw new IllegalArgumentException("Could not get URI from " + config, ex);
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\cache\HazelcastJCacheCustomizationConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */