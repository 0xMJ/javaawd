/*    */ package org.springframework.boot.autoconfigure.data.redis;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class RedisUrlSyntaxException
/*    */   extends RuntimeException
/*    */ {
/*    */   private final String url;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   RedisUrlSyntaxException(String url, Exception cause)
/*    */   {
/* 29 */     super(buildMessage(url), cause);
/* 30 */     this.url = url;
/*    */   }
/*    */   
/*    */   RedisUrlSyntaxException(String url) {
/* 34 */     super(buildMessage(url));
/* 35 */     this.url = url;
/*    */   }
/*    */   
/*    */   String getUrl() {
/* 39 */     return this.url;
/*    */   }
/*    */   
/*    */   private static String buildMessage(String url) {
/* 43 */     return "Invalid Redis URL '" + url + "'";
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\data\redis\RedisUrlSyntaxException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */