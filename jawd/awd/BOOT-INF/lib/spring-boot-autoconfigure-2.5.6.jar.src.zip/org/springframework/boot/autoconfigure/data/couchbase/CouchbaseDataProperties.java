/*    */ package org.springframework.boot.autoconfigure.data.couchbase;
/*    */ 
/*    */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @ConfigurationProperties(prefix="spring.data.couchbase")
/*    */ public class CouchbaseDataProperties
/*    */ {
/*    */   private boolean autoIndex;
/*    */   private String bucketName;
/*    */   private String scopeName;
/*    */   private Class<?> fieldNamingStrategy;
/* 55 */   private String typeKey = "_class";
/*    */   
/*    */   public boolean isAutoIndex() {
/* 58 */     return this.autoIndex;
/*    */   }
/*    */   
/*    */   public void setAutoIndex(boolean autoIndex) {
/* 62 */     this.autoIndex = autoIndex;
/*    */   }
/*    */   
/*    */   public String getBucketName() {
/* 66 */     return this.bucketName;
/*    */   }
/*    */   
/*    */   public void setBucketName(String bucketName) {
/* 70 */     this.bucketName = bucketName;
/*    */   }
/*    */   
/*    */   public String getScopeName() {
/* 74 */     return this.scopeName;
/*    */   }
/*    */   
/*    */   public void setScopeName(String scopeName) {
/* 78 */     this.scopeName = scopeName;
/*    */   }
/*    */   
/*    */   public Class<?> getFieldNamingStrategy() {
/* 82 */     return this.fieldNamingStrategy;
/*    */   }
/*    */   
/*    */   public void setFieldNamingStrategy(Class<?> fieldNamingStrategy) {
/* 86 */     this.fieldNamingStrategy = fieldNamingStrategy;
/*    */   }
/*    */   
/*    */   public String getTypeKey() {
/* 90 */     return this.typeKey;
/*    */   }
/*    */   
/*    */   public void setTypeKey(String typeKey) {
/* 94 */     this.typeKey = typeKey;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\data\couchbase\CouchbaseDataProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */