/*    */ package org.springframework.boot.autoconfigure.hazelcast;
/*    */ 
/*    */ import com.hazelcast.client.HazelcastClient;
/*    */ import com.hazelcast.client.config.ClientConfig;
/*    */ import com.hazelcast.client.config.XmlClientConfigBuilder;
/*    */ import com.hazelcast.client.config.YamlClientConfigBuilder;
/*    */ import com.hazelcast.core.HazelcastInstance;
/*    */ import java.io.IOException;
/*    */ import java.net.URL;
/*    */ import org.springframework.core.io.Resource;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class HazelcastClientFactory
/*    */ {
/*    */   private final ClientConfig clientConfig;
/*    */   
/*    */   public HazelcastClientFactory(Resource clientConfigLocation)
/*    */     throws IOException
/*    */   {
/* 50 */     this.clientConfig = getClientConfig(clientConfigLocation);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public HazelcastClientFactory(ClientConfig clientConfig)
/*    */   {
/* 58 */     Assert.notNull(clientConfig, "ClientConfig must not be null");
/* 59 */     this.clientConfig = clientConfig;
/*    */   }
/*    */   
/*    */   private ClientConfig getClientConfig(Resource clientConfigLocation) throws IOException {
/* 63 */     URL configUrl = clientConfigLocation.getURL();
/* 64 */     String configFileName = configUrl.getPath();
/* 65 */     if (configFileName.endsWith(".yaml")) {
/* 66 */       return new YamlClientConfigBuilder(configUrl).build();
/*    */     }
/* 68 */     return new XmlClientConfigBuilder(configUrl).build();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public HazelcastInstance getHazelcastInstance()
/*    */   {
/* 76 */     if (StringUtils.hasText(this.clientConfig.getInstanceName())) {
/* 77 */       return HazelcastClient.getOrCreateHazelcastClient(this.clientConfig);
/*    */     }
/* 79 */     return HazelcastClient.newHazelcastClient(this.clientConfig);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\hazelcast\HazelcastClientFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */