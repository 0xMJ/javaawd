/*    */ package org.springframework.boot.autoconfigure.session;
/*    */ 
/*    */ import java.time.Duration;
/*    */ import org.springframework.beans.factory.annotation.Autowired;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*    */ import org.springframework.context.annotation.Conditional;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.data.mongodb.core.ReactiveMongoOperations;
/*    */ import org.springframework.session.ReactiveSessionRepository;
/*    */ import org.springframework.session.data.mongo.ReactiveMongoSessionRepository;
/*    */ import org.springframework.session.data.mongo.config.annotation.web.reactive.ReactiveMongoWebSessionConfiguration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods=false)
/*    */ @ConditionalOnClass({ReactiveMongoOperations.class, ReactiveMongoSessionRepository.class})
/*    */ @ConditionalOnMissingBean({ReactiveSessionRepository.class})
/*    */ @ConditionalOnBean({ReactiveMongoOperations.class})
/*    */ @Conditional({ReactiveSessionCondition.class})
/*    */ @EnableConfigurationProperties({MongoSessionProperties.class})
/*    */ class MongoReactiveSessionConfiguration
/*    */ {
/*    */   @Configuration(proxyBeanMethods=false)
/*    */   static class SpringBootReactiveMongoWebSessionConfiguration
/*    */     extends ReactiveMongoWebSessionConfiguration
/*    */   {
/*    */     @Autowired
/*    */     void customize(SessionProperties sessionProperties, MongoSessionProperties mongoSessionProperties)
/*    */     {
/* 51 */       Duration timeout = sessionProperties.getTimeout();
/* 52 */       if (timeout != null) {
/* 53 */         setMaxInactiveIntervalInSeconds(Integer.valueOf((int)timeout.getSeconds()));
/*    */       }
/* 55 */       setCollectionName(mongoSessionProperties.getCollectionName());
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\session\MongoReactiveSessionConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */