/*    */ package org.springframework.boot.autoconfigure.freemarker;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.springframework.boot.autoconfigure.template.AbstractTemplateViewResolverProperties;
/*    */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @ConfigurationProperties(prefix="spring.freemarker")
/*    */ public class FreeMarkerProperties
/*    */   extends AbstractTemplateViewResolverProperties
/*    */ {
/*    */   public static final String DEFAULT_TEMPLATE_LOADER_PATH = "classpath:/templates/";
/*    */   public static final String DEFAULT_PREFIX = "";
/*    */   public static final String DEFAULT_SUFFIX = ".ftlh";
/* 44 */   private Map<String, String> settings = new HashMap();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/* 49 */   private String[] templateLoaderPath = { "classpath:/templates/" };
/*    */   
/*    */ 
/*    */ 
/*    */   private boolean preferFileSystemAccess;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public FreeMarkerProperties()
/*    */   {
/* 60 */     super("", ".ftlh");
/*    */   }
/*    */   
/*    */   public Map<String, String> getSettings() {
/* 64 */     return this.settings;
/*    */   }
/*    */   
/*    */   public void setSettings(Map<String, String> settings) {
/* 68 */     this.settings = settings;
/*    */   }
/*    */   
/*    */   public String[] getTemplateLoaderPath() {
/* 72 */     return this.templateLoaderPath;
/*    */   }
/*    */   
/*    */   public boolean isPreferFileSystemAccess() {
/* 76 */     return this.preferFileSystemAccess;
/*    */   }
/*    */   
/*    */   public void setPreferFileSystemAccess(boolean preferFileSystemAccess) {
/* 80 */     this.preferFileSystemAccess = preferFileSystemAccess;
/*    */   }
/*    */   
/*    */   public void setTemplateLoaderPath(String... templateLoaderPaths) {
/* 84 */     this.templateLoaderPath = templateLoaderPaths;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\freemarker\FreeMarkerProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */