/*    */ package org.springframework.boot.autoconfigure.session;
/*    */ 
/*    */ import org.springframework.boot.diagnostics.AbstractFailureAnalyzer;
/*    */ import org.springframework.boot.diagnostics.FailureAnalysis;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class NonUniqueSessionRepositoryFailureAnalyzer
/*    */   extends AbstractFailureAnalyzer<NonUniqueSessionRepositoryException>
/*    */ {
/*    */   protected FailureAnalysis analyze(Throwable rootFailure, NonUniqueSessionRepositoryException cause)
/*    */   {
/* 31 */     StringBuilder message = new StringBuilder();
/* 32 */     message.append(
/* 33 */       String.format("Multiple Spring Session store implementations are available on the classpath:%n", new Object[0]));
/* 34 */     for (Class<?> candidate : cause.getAvailableCandidates()) {
/* 35 */       message.append(String.format("    - %s%n", new Object[] { candidate.getName() }));
/*    */     }
/* 37 */     StringBuilder action = new StringBuilder();
/* 38 */     action.append(String.format("Consider any of the following:%n", new Object[0]));
/* 39 */     action.append(
/* 40 */       String.format("    - Define the `spring.session.store-type` property to the store you want to use%n", new Object[0]));
/* 41 */     action.append(String.format("    - Review your classpath and remove the unwanted store implementation(s)%n", new Object[0]));
/* 42 */     return new FailureAnalysis(message.toString(), action.toString(), cause);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\session\NonUniqueSessionRepositoryFailureAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */