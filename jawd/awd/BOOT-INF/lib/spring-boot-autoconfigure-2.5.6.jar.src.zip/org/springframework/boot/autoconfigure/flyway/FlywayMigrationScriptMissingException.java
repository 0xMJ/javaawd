/*    */ package org.springframework.boot.autoconfigure.flyway;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class FlywayMigrationScriptMissingException
/*    */   extends RuntimeException
/*    */ {
/*    */   private final List<String> locations;
/*    */   
/*    */   FlywayMigrationScriptMissingException(List<String> locations)
/*    */   {
/* 36 */     super("Cannot find migration scripts in: " + locations + " (please add migration scripts or check your Flyway configuration)");
/*    */     
/* 38 */     this.locations = new ArrayList(locations);
/*    */   }
/*    */   
/*    */   public List<String> getLocations() {
/* 42 */     return this.locations;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\flyway\FlywayMigrationScriptMissingException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */