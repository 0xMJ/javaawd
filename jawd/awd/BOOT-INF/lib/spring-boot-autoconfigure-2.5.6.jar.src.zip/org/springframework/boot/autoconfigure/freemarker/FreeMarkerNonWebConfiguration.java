/*    */ package org.springframework.boot.autoconfigure.freemarker;
/*    */ 
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnNotWebApplication;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.ui.freemarker.FreeMarkerConfigurationFactoryBean;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods=false)
/*    */ @ConditionalOnNotWebApplication
/*    */ class FreeMarkerNonWebConfiguration
/*    */   extends AbstractFreeMarkerConfiguration
/*    */ {
/*    */   FreeMarkerNonWebConfiguration(FreeMarkerProperties properties)
/*    */   {
/* 36 */     super(properties);
/*    */   }
/*    */   
/*    */   @Bean
/*    */   @ConditionalOnMissingBean
/*    */   FreeMarkerConfigurationFactoryBean freeMarkerConfiguration() {
/* 42 */     FreeMarkerConfigurationFactoryBean freeMarkerFactoryBean = new FreeMarkerConfigurationFactoryBean();
/* 43 */     applyProperties(freeMarkerFactoryBean);
/* 44 */     return freeMarkerFactoryBean;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\freemarker\FreeMarkerNonWebConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */