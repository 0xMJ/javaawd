/*    */ package org.springframework.boot.autoconfigure.flyway;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.Set;
/*    */ import org.springframework.boot.sql.init.dependency.AbstractBeansOfTypeDatabaseInitializerDetector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class FlywayMigrationInitializerDatabaseInitializerDetector
/*    */   extends AbstractBeansOfTypeDatabaseInitializerDetector
/*    */ {
/*    */   protected Set<Class<?>> getDatabaseInitializerBeanTypes()
/*    */   {
/* 34 */     return Collections.singleton(FlywayMigrationInitializer.class);
/*    */   }
/*    */   
/*    */   public int getOrder()
/*    */   {
/* 39 */     return 1;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\flyway\FlywayMigrationInitializerDatabaseInitializerDetector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */