/*     */ package org.springframework.boot.autoconfigure.logging;
/*     */ 
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionEvaluationReport;
/*     */ import org.springframework.boot.context.event.ApplicationFailedEvent;
/*     */ import org.springframework.boot.logging.LogLevel;
/*     */ import org.springframework.context.ApplicationContextInitializer;
/*     */ import org.springframework.context.ApplicationEvent;
/*     */ import org.springframework.context.ConfigurableApplicationContext;
/*     */ import org.springframework.context.event.ApplicationContextEvent;
/*     */ import org.springframework.context.event.ContextRefreshedEvent;
/*     */ import org.springframework.context.event.GenericApplicationListener;
/*     */ import org.springframework.context.support.GenericApplicationContext;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConditionEvaluationReportLoggingListener
/*     */   implements ApplicationContextInitializer<ConfigurableApplicationContext>
/*     */ {
/*  55 */   private final Log logger = LogFactory.getLog(getClass());
/*     */   
/*     */   private ConfigurableApplicationContext applicationContext;
/*     */   
/*     */   private ConditionEvaluationReport report;
/*     */   private final LogLevel logLevelForReport;
/*     */   
/*     */   public ConditionEvaluationReportLoggingListener()
/*     */   {
/*  64 */     this(LogLevel.DEBUG);
/*     */   }
/*     */   
/*     */   public ConditionEvaluationReportLoggingListener(LogLevel logLevelForReport) {
/*  68 */     Assert.isTrue(isInfoOrDebug(logLevelForReport), "LogLevel must be INFO or DEBUG");
/*  69 */     this.logLevelForReport = logLevelForReport;
/*     */   }
/*     */   
/*     */   private boolean isInfoOrDebug(LogLevel logLevelForReport) {
/*  73 */     return (LogLevel.INFO.equals(logLevelForReport)) || (LogLevel.DEBUG.equals(logLevelForReport));
/*     */   }
/*     */   
/*     */   public LogLevel getLogLevelForReport() {
/*  77 */     return this.logLevelForReport;
/*     */   }
/*     */   
/*     */   public void initialize(ConfigurableApplicationContext applicationContext)
/*     */   {
/*  82 */     this.applicationContext = applicationContext;
/*  83 */     applicationContext.addApplicationListener(new ConditionEvaluationReportListener(null));
/*  84 */     if ((applicationContext instanceof GenericApplicationContext))
/*     */     {
/*  86 */       this.report = ConditionEvaluationReport.get(this.applicationContext.getBeanFactory());
/*     */     }
/*     */   }
/*     */   
/*     */   protected void onApplicationEvent(ApplicationEvent event) {
/*  91 */     ConfigurableApplicationContext initializerApplicationContext = this.applicationContext;
/*  92 */     if ((event instanceof ContextRefreshedEvent)) {
/*  93 */       if (((ApplicationContextEvent)event).getApplicationContext() == initializerApplicationContext) {
/*  94 */         logAutoConfigurationReport();
/*     */       }
/*     */     }
/*  97 */     else if (((event instanceof ApplicationFailedEvent)) && 
/*  98 */       (((ApplicationFailedEvent)event).getApplicationContext() == initializerApplicationContext)) {
/*  99 */       logAutoConfigurationReport(true);
/*     */     }
/*     */   }
/*     */   
/*     */   private void logAutoConfigurationReport() {
/* 104 */     logAutoConfigurationReport(!this.applicationContext.isActive());
/*     */   }
/*     */   
/*     */   public void logAutoConfigurationReport(boolean isCrashReport) {
/* 108 */     if (this.report == null) {
/* 109 */       if (this.applicationContext == null) {
/* 110 */         this.logger.info("Unable to provide the conditions report due to missing ApplicationContext");
/* 111 */         return;
/*     */       }
/* 113 */       this.report = ConditionEvaluationReport.get(this.applicationContext.getBeanFactory());
/*     */     }
/* 115 */     if (!this.report.getConditionAndOutcomesBySource().isEmpty()) {
/* 116 */       if (getLogLevelForReport().equals(LogLevel.INFO)) {
/* 117 */         if (this.logger.isInfoEnabled()) {
/* 118 */           this.logger.info(new ConditionEvaluationReportMessage(this.report));
/*     */         }
/* 120 */         else if (isCrashReport) {
/* 121 */           logMessage("info");
/*     */         }
/*     */         
/*     */       }
/* 125 */       else if (this.logger.isDebugEnabled()) {
/* 126 */         this.logger.debug(new ConditionEvaluationReportMessage(this.report));
/*     */       }
/* 128 */       else if (isCrashReport) {
/* 129 */         logMessage("debug");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void logMessage(String logLevel)
/*     */   {
/* 136 */     this.logger.info(String.format("%n%nError starting ApplicationContext. To display the conditions report re-run your application with '" + logLevel + "' enabled.", new Object[0]));
/*     */   }
/*     */   
/*     */   private class ConditionEvaluationReportListener implements GenericApplicationListener
/*     */   {
/*     */     private ConditionEvaluationReportListener() {}
/*     */     
/*     */     public int getOrder() {
/* 144 */       return Integer.MAX_VALUE;
/*     */     }
/*     */     
/*     */     public boolean supportsEventType(ResolvableType resolvableType)
/*     */     {
/* 149 */       Class<?> type = resolvableType.getRawClass();
/* 150 */       if (type == null) {
/* 151 */         return false;
/*     */       }
/* 153 */       return (ContextRefreshedEvent.class.isAssignableFrom(type)) || 
/* 154 */         (ApplicationFailedEvent.class.isAssignableFrom(type));
/*     */     }
/*     */     
/*     */     public boolean supportsSourceType(Class<?> sourceType)
/*     */     {
/* 159 */       return true;
/*     */     }
/*     */     
/*     */     public void onApplicationEvent(ApplicationEvent event)
/*     */     {
/* 164 */       ConditionEvaluationReportLoggingListener.this.onApplicationEvent(event);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\logging\ConditionEvaluationReportLoggingListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */