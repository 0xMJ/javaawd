/*     */ package org.springframework.boot.autoconfigure.elasticsearch;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix="spring.elasticsearch.rest")
/*     */ public class ElasticsearchRestClientProperties
/*     */ {
/*  38 */   private List<String> uris = new ArrayList(Collections.singletonList("http://localhost:9200"));
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String username;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String password;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  53 */   private Duration connectionTimeout = Duration.ofSeconds(1L);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  58 */   private Duration readTimeout = Duration.ofSeconds(30L);
/*     */   
/*  60 */   private final Sniffer sniffer = new Sniffer();
/*     */   
/*     */   public List<String> getUris() {
/*  63 */     return this.uris;
/*     */   }
/*     */   
/*     */   public void setUris(List<String> uris) {
/*  67 */     this.uris = uris;
/*     */   }
/*     */   
/*     */   public String getUsername() {
/*  71 */     return this.username;
/*     */   }
/*     */   
/*     */   public void setUsername(String username) {
/*  75 */     this.username = username;
/*     */   }
/*     */   
/*     */   public String getPassword() {
/*  79 */     return this.password;
/*     */   }
/*     */   
/*     */   public void setPassword(String password) {
/*  83 */     this.password = password;
/*     */   }
/*     */   
/*     */   public Duration getConnectionTimeout() {
/*  87 */     return this.connectionTimeout;
/*     */   }
/*     */   
/*     */   public void setConnectionTimeout(Duration connectionTimeout) {
/*  91 */     this.connectionTimeout = connectionTimeout;
/*     */   }
/*     */   
/*     */   public Duration getReadTimeout() {
/*  95 */     return this.readTimeout;
/*     */   }
/*     */   
/*     */   public void setReadTimeout(Duration readTimeout) {
/*  99 */     this.readTimeout = readTimeout;
/*     */   }
/*     */   
/*     */   public Sniffer getSniffer() {
/* 103 */     return this.sniffer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Sniffer
/*     */   {
/* 111 */     private Duration interval = Duration.ofMinutes(5L);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 116 */     private Duration delayAfterFailure = Duration.ofMinutes(1L);
/*     */     
/*     */     public Duration getInterval() {
/* 119 */       return this.interval;
/*     */     }
/*     */     
/*     */     public void setInterval(Duration interval) {
/* 123 */       this.interval = interval;
/*     */     }
/*     */     
/*     */     public Duration getDelayAfterFailure() {
/* 127 */       return this.delayAfterFailure;
/*     */     }
/*     */     
/*     */     public void setDelayAfterFailure(Duration delayAfterFailure) {
/* 131 */       this.delayAfterFailure = delayAfterFailure;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\elasticsearch\ElasticsearchRestClientProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */