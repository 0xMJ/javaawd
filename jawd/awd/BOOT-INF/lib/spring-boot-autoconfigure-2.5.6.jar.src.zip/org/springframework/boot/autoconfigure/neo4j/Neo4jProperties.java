/*     */ package org.springframework.boot.autoconfigure.neo4j;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.net.URI;
/*     */ import java.time.Duration;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix="spring.neo4j")
/*     */ public class Neo4jProperties
/*     */ {
/*     */   private URI uri;
/*  43 */   private Duration connectionTimeout = Duration.ofSeconds(30L);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  48 */   private Duration maxTransactionRetryTime = Duration.ofSeconds(30L);
/*     */   
/*  50 */   private final Authentication authentication = new Authentication();
/*     */   
/*  52 */   private final Pool pool = new Pool();
/*     */   
/*  54 */   private final Security security = new Security();
/*     */   
/*     */   public URI getUri() {
/*  57 */     return this.uri;
/*     */   }
/*     */   
/*     */   public void setUri(URI uri) {
/*  61 */     this.uri = uri;
/*     */   }
/*     */   
/*     */   public Duration getConnectionTimeout() {
/*  65 */     return this.connectionTimeout;
/*     */   }
/*     */   
/*     */   public void setConnectionTimeout(Duration connectionTimeout) {
/*  69 */     this.connectionTimeout = connectionTimeout;
/*     */   }
/*     */   
/*     */   public Duration getMaxTransactionRetryTime() {
/*  73 */     return this.maxTransactionRetryTime;
/*     */   }
/*     */   
/*     */   public void setMaxTransactionRetryTime(Duration maxTransactionRetryTime) {
/*  77 */     this.maxTransactionRetryTime = maxTransactionRetryTime;
/*     */   }
/*     */   
/*     */   public Authentication getAuthentication() {
/*  81 */     return this.authentication;
/*     */   }
/*     */   
/*     */   public Pool getPool() {
/*  85 */     return this.pool;
/*     */   }
/*     */   
/*     */   public Security getSecurity() {
/*  89 */     return this.security;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Authentication
/*     */   {
/*     */     private String username;
/*     */     
/*     */ 
/*     */ 
/*     */     private String password;
/*     */     
/*     */ 
/*     */ 
/*     */     private String realm;
/*     */     
/*     */ 
/*     */ 
/*     */     private String kerberosTicket;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public String getUsername()
/*     */     {
/* 116 */       return this.username;
/*     */     }
/*     */     
/*     */     public void setUsername(String username) {
/* 120 */       this.username = username;
/*     */     }
/*     */     
/*     */     public String getPassword() {
/* 124 */       return this.password;
/*     */     }
/*     */     
/*     */     public void setPassword(String password) {
/* 128 */       this.password = password;
/*     */     }
/*     */     
/*     */     public String getRealm() {
/* 132 */       return this.realm;
/*     */     }
/*     */     
/*     */     public void setRealm(String realm) {
/* 136 */       this.realm = realm;
/*     */     }
/*     */     
/*     */     public String getKerberosTicket() {
/* 140 */       return this.kerberosTicket;
/*     */     }
/*     */     
/*     */     public void setKerberosTicket(String kerberosTicket) {
/* 144 */       this.kerberosTicket = kerberosTicket;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Pool
/*     */   {
/* 154 */     private boolean metricsEnabled = false;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 159 */     private boolean logLeakedSessions = false;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 164 */     private int maxConnectionPoolSize = 100;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private Duration idleTimeBeforeConnectionTest;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 176 */     private Duration maxConnectionLifetime = Duration.ofHours(1L);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 182 */     private Duration connectionAcquisitionTimeout = Duration.ofSeconds(60L);
/*     */     
/*     */     public boolean isLogLeakedSessions() {
/* 185 */       return this.logLeakedSessions;
/*     */     }
/*     */     
/*     */     public void setLogLeakedSessions(boolean logLeakedSessions) {
/* 189 */       this.logLeakedSessions = logLeakedSessions;
/*     */     }
/*     */     
/*     */     public int getMaxConnectionPoolSize() {
/* 193 */       return this.maxConnectionPoolSize;
/*     */     }
/*     */     
/*     */     public void setMaxConnectionPoolSize(int maxConnectionPoolSize) {
/* 197 */       this.maxConnectionPoolSize = maxConnectionPoolSize;
/*     */     }
/*     */     
/*     */     public Duration getIdleTimeBeforeConnectionTest() {
/* 201 */       return this.idleTimeBeforeConnectionTest;
/*     */     }
/*     */     
/*     */     public void setIdleTimeBeforeConnectionTest(Duration idleTimeBeforeConnectionTest) {
/* 205 */       this.idleTimeBeforeConnectionTest = idleTimeBeforeConnectionTest;
/*     */     }
/*     */     
/*     */     public Duration getMaxConnectionLifetime() {
/* 209 */       return this.maxConnectionLifetime;
/*     */     }
/*     */     
/*     */     public void setMaxConnectionLifetime(Duration maxConnectionLifetime) {
/* 213 */       this.maxConnectionLifetime = maxConnectionLifetime;
/*     */     }
/*     */     
/*     */     public Duration getConnectionAcquisitionTimeout() {
/* 217 */       return this.connectionAcquisitionTimeout;
/*     */     }
/*     */     
/*     */     public void setConnectionAcquisitionTimeout(Duration connectionAcquisitionTimeout) {
/* 221 */       this.connectionAcquisitionTimeout = connectionAcquisitionTimeout;
/*     */     }
/*     */     
/*     */     public boolean isMetricsEnabled() {
/* 225 */       return this.metricsEnabled;
/*     */     }
/*     */     
/*     */     public void setMetricsEnabled(boolean metricsEnabled) {
/* 229 */       this.metricsEnabled = metricsEnabled;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Security
/*     */   {
/* 239 */     private boolean encrypted = false;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 244 */     private TrustStrategy trustStrategy = TrustStrategy.TRUST_SYSTEM_CA_SIGNED_CERTIFICATES;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private File certFile;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 254 */     private boolean hostnameVerificationEnabled = true;
/*     */     
/*     */     public boolean isEncrypted() {
/* 257 */       return this.encrypted;
/*     */     }
/*     */     
/*     */     public void setEncrypted(boolean encrypted) {
/* 261 */       this.encrypted = encrypted;
/*     */     }
/*     */     
/*     */     public TrustStrategy getTrustStrategy() {
/* 265 */       return this.trustStrategy;
/*     */     }
/*     */     
/*     */     public void setTrustStrategy(TrustStrategy trustStrategy) {
/* 269 */       this.trustStrategy = trustStrategy;
/*     */     }
/*     */     
/*     */     public File getCertFile() {
/* 273 */       return this.certFile;
/*     */     }
/*     */     
/*     */     public void setCertFile(File certFile) {
/* 277 */       this.certFile = certFile;
/*     */     }
/*     */     
/*     */     public boolean isHostnameVerificationEnabled() {
/* 281 */       return this.hostnameVerificationEnabled;
/*     */     }
/*     */     
/*     */     public void setHostnameVerificationEnabled(boolean hostnameVerificationEnabled) {
/* 285 */       this.hostnameVerificationEnabled = hostnameVerificationEnabled;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public static enum TrustStrategy
/*     */     {
/* 293 */       TRUST_ALL_CERTIFICATES, 
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 298 */       TRUST_CUSTOM_CA_SIGNED_CERTIFICATES, 
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 303 */       TRUST_SYSTEM_CA_SIGNED_CERTIFICATES;
/*     */       
/*     */       private TrustStrategy() {}
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\neo4j\Neo4jProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */