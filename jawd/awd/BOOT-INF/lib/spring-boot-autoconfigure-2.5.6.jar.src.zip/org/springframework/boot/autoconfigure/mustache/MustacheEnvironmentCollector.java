/*    */ package org.springframework.boot.autoconfigure.mustache;
/*    */ 
/*    */ import com.samskivert.mustache.DefaultCollector;
/*    */ import com.samskivert.mustache.Mustache.VariableFetcher;
/*    */ import java.util.concurrent.atomic.AtomicBoolean;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.context.EnvironmentAware;
/*    */ import org.springframework.core.env.ConfigurableEnvironment;
/*    */ import org.springframework.core.env.Environment;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class MustacheEnvironmentCollector
/*    */   extends DefaultCollector
/*    */   implements EnvironmentAware
/*    */ {
/*    */   private ConfigurableEnvironment environment;
/* 45 */   private final Mustache.VariableFetcher propertyFetcher = new PropertyVariableFetcher(null);
/*    */   
/*    */   public void setEnvironment(Environment environment)
/*    */   {
/* 49 */     this.environment = ((ConfigurableEnvironment)environment);
/*    */   }
/*    */   
/*    */   public Mustache.VariableFetcher createFetcher(Object ctx, String name)
/*    */   {
/* 54 */     Mustache.VariableFetcher fetcher = super.createFetcher(ctx, name);
/* 55 */     if (fetcher != null) {
/* 56 */       return fetcher;
/*    */     }
/* 58 */     if (this.environment.containsProperty(name)) {
/* 59 */       return this.propertyFetcher;
/*    */     }
/* 61 */     return null;
/*    */   }
/*    */   
/*    */   private class PropertyVariableFetcher implements Mustache.VariableFetcher
/*    */   {
/* 66 */     private final Log log = LogFactory.getLog(PropertyVariableFetcher.class);
/*    */     
/* 68 */     private final AtomicBoolean logDeprecationWarning = new AtomicBoolean();
/*    */     
/*    */     private PropertyVariableFetcher() {}
/*    */     
/* 72 */     public Object get(Object ctx, String name) { String property = MustacheEnvironmentCollector.this.environment.getProperty(name);
/* 73 */       if ((property != null) && (this.logDeprecationWarning.compareAndSet(false, true))) {
/* 74 */         this.log.warn("Mustache variable resolution relied upon deprecated support for falling back to the Spring Environment. Please add values from the Environment directly to the model instead.");
/*    */       }
/*    */       
/* 77 */       return property;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\mustache\MustacheEnvironmentCollector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */