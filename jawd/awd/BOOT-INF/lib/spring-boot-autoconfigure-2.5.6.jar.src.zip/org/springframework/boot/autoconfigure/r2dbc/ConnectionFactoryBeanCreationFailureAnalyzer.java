/*    */ package org.springframework.boot.autoconfigure.r2dbc;
/*    */ 
/*    */ import org.springframework.boot.diagnostics.AbstractFailureAnalyzer;
/*    */ import org.springframework.boot.diagnostics.FailureAnalysis;
/*    */ import org.springframework.boot.r2dbc.EmbeddedDatabaseConnection;
/*    */ import org.springframework.context.EnvironmentAware;
/*    */ import org.springframework.core.env.Environment;
/*    */ import org.springframework.util.ObjectUtils;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ConnectionFactoryBeanCreationFailureAnalyzer
/*    */   extends AbstractFailureAnalyzer<ConnectionFactoryOptionsInitializer.ConnectionFactoryBeanCreationException>
/*    */   implements EnvironmentAware
/*    */ {
/*    */   private Environment environment;
/*    */   
/*    */   public void setEnvironment(Environment environment)
/*    */   {
/* 41 */     this.environment = environment;
/*    */   }
/*    */   
/*    */   protected FailureAnalysis analyze(Throwable rootFailure, ConnectionFactoryOptionsInitializer.ConnectionFactoryBeanCreationException cause)
/*    */   {
/* 46 */     return getFailureAnalysis(cause);
/*    */   }
/*    */   
/*    */   private FailureAnalysis getFailureAnalysis(ConnectionFactoryOptionsInitializer.ConnectionFactoryBeanCreationException cause) {
/* 50 */     String description = getDescription(cause);
/* 51 */     String action = getAction(cause);
/* 52 */     return new FailureAnalysis(description, action, cause);
/*    */   }
/*    */   
/*    */   private String getDescription(ConnectionFactoryOptionsInitializer.ConnectionFactoryBeanCreationException cause) {
/* 56 */     StringBuilder description = new StringBuilder();
/* 57 */     description.append("Failed to configure a ConnectionFactory: ");
/* 58 */     if (!StringUtils.hasText(cause.getProperties().getUrl())) {
/* 59 */       description.append("'url' attribute is not specified and ");
/*    */     }
/* 61 */     description.append(String.format("no embedded database could be configured.%n", new Object[0]));
/* 62 */     description.append(String.format("%nReason: %s%n", new Object[] { cause.getMessage() }));
/* 63 */     return description.toString();
/*    */   }
/*    */   
/*    */   private String getAction(ConnectionFactoryOptionsInitializer.ConnectionFactoryBeanCreationException cause) {
/* 67 */     StringBuilder action = new StringBuilder();
/* 68 */     action.append(String.format("Consider the following:%n", new Object[0]));
/* 69 */     if (EmbeddedDatabaseConnection.NONE == cause.getEmbeddedDatabaseConnection()) {
/* 70 */       action.append(String.format("\tIf you want an embedded database (H2), please put it on the classpath.%n", new Object[0]));
/*    */     }
/*    */     else {
/* 73 */       action.append(String.format("\tReview the configuration of %s%n.", new Object[] { cause.getEmbeddedDatabaseConnection() }));
/*    */     }
/*    */     
/* 76 */     action.append("\tIf you have database settings to be loaded from a particular profile you may need to activate it").append(getActiveProfiles());
/* 77 */     return action.toString();
/*    */   }
/*    */   
/*    */   private String getActiveProfiles() {
/* 81 */     StringBuilder message = new StringBuilder();
/* 82 */     String[] profiles = this.environment.getActiveProfiles();
/* 83 */     if (ObjectUtils.isEmpty(profiles)) {
/* 84 */       message.append(" (no profiles are currently active).");
/*    */     }
/*    */     else {
/* 87 */       message.append(" (the profiles ");
/* 88 */       message.append(StringUtils.arrayToCommaDelimitedString(profiles));
/* 89 */       message.append(" are currently active).");
/*    */     }
/* 91 */     return message.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\r2dbc\ConnectionFactoryBeanCreationFailureAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */