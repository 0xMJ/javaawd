/*     */ package org.springframework.boot.autoconfigure.condition;
/*     */ 
/*     */ import java.util.Map;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.boot.autoconfigure.AutoConfigurationMetadata;
/*     */ import org.springframework.boot.web.reactive.context.ConfigurableReactiveWebEnvironment;
/*     */ import org.springframework.boot.web.reactive.context.ReactiveWebApplicationContext;
/*     */ import org.springframework.context.annotation.ConditionContext;
/*     */ import org.springframework.core.annotation.Order;
/*     */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.web.context.ConfigurableWebEnvironment;
/*     */ import org.springframework.web.context.WebApplicationContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Order(-2147483628)
/*     */ class OnWebApplicationCondition
/*     */   extends FilteringSpringBootCondition
/*     */ {
/*     */   private static final String SERVLET_WEB_APPLICATION_CLASS = "org.springframework.web.context.support.GenericWebApplicationContext";
/*     */   private static final String REACTIVE_WEB_APPLICATION_CLASS = "org.springframework.web.reactive.HandlerResult";
/*     */   
/*     */   protected ConditionOutcome[] getOutcomes(String[] autoConfigurationClasses, AutoConfigurationMetadata autoConfigurationMetadata)
/*     */   {
/*  54 */     ConditionOutcome[] outcomes = new ConditionOutcome[autoConfigurationClasses.length];
/*  55 */     for (int i = 0; i < outcomes.length; i++) {
/*  56 */       String autoConfigurationClass = autoConfigurationClasses[i];
/*  57 */       if (autoConfigurationClass != null) {
/*  58 */         outcomes[i] = getOutcome(autoConfigurationMetadata
/*  59 */           .get(autoConfigurationClass, "ConditionalOnWebApplication"));
/*     */       }
/*     */     }
/*  62 */     return outcomes;
/*     */   }
/*     */   
/*     */   private ConditionOutcome getOutcome(String type) {
/*  66 */     if (type == null) {
/*  67 */       return null;
/*     */     }
/*  69 */     ConditionMessage.Builder message = ConditionMessage.forCondition(ConditionalOnWebApplication.class, new Object[0]);
/*  70 */     if ((ConditionalOnWebApplication.Type.SERVLET.name().equals(type)) && 
/*  71 */       (!FilteringSpringBootCondition.ClassNameFilter.isPresent("org.springframework.web.context.support.GenericWebApplicationContext", getBeanClassLoader()))) {
/*  72 */       return ConditionOutcome.noMatch(message.didNotFind("servlet web application classes").atAll());
/*     */     }
/*     */     
/*  75 */     if ((ConditionalOnWebApplication.Type.REACTIVE.name().equals(type)) && 
/*  76 */       (!FilteringSpringBootCondition.ClassNameFilter.isPresent("org.springframework.web.reactive.HandlerResult", getBeanClassLoader()))) {
/*  77 */       return ConditionOutcome.noMatch(message.didNotFind("reactive web application classes").atAll());
/*     */     }
/*     */     
/*  80 */     if ((!FilteringSpringBootCondition.ClassNameFilter.isPresent("org.springframework.web.context.support.GenericWebApplicationContext", getBeanClassLoader())) && 
/*  81 */       (!ClassUtils.isPresent("org.springframework.web.reactive.HandlerResult", getBeanClassLoader()))) {
/*  82 */       return ConditionOutcome.noMatch(message.didNotFind("reactive or servlet web application classes").atAll());
/*     */     }
/*  84 */     return null;
/*     */   }
/*     */   
/*     */   public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata)
/*     */   {
/*  89 */     boolean required = metadata.isAnnotated(ConditionalOnWebApplication.class.getName());
/*  90 */     ConditionOutcome outcome = isWebApplication(context, metadata, required);
/*  91 */     if ((required) && (!outcome.isMatch())) {
/*  92 */       return ConditionOutcome.noMatch(outcome.getConditionMessage());
/*     */     }
/*  94 */     if ((!required) && (outcome.isMatch())) {
/*  95 */       return ConditionOutcome.noMatch(outcome.getConditionMessage());
/*     */     }
/*  97 */     return ConditionOutcome.match(outcome.getConditionMessage());
/*     */   }
/*     */   
/*     */   private ConditionOutcome isWebApplication(ConditionContext context, AnnotatedTypeMetadata metadata, boolean required)
/*     */   {
/* 102 */     switch (deduceType(metadata)) {
/*     */     case SERVLET: 
/* 104 */       return isServletWebApplication(context);
/*     */     case REACTIVE: 
/* 106 */       return isReactiveWebApplication(context);
/*     */     }
/* 108 */     return isAnyWebApplication(context, required);
/*     */   }
/*     */   
/*     */   private ConditionOutcome isAnyWebApplication(ConditionContext context, boolean required)
/*     */   {
/* 113 */     ConditionMessage.Builder message = ConditionMessage.forCondition(ConditionalOnWebApplication.class, new Object[] { required ? "(required)" : "" });
/*     */     
/* 115 */     ConditionOutcome servletOutcome = isServletWebApplication(context);
/* 116 */     if ((servletOutcome.isMatch()) && (required)) {
/* 117 */       return new ConditionOutcome(servletOutcome.isMatch(), message.because(servletOutcome.getMessage()));
/*     */     }
/* 119 */     ConditionOutcome reactiveOutcome = isReactiveWebApplication(context);
/* 120 */     if ((reactiveOutcome.isMatch()) && (required)) {
/* 121 */       return new ConditionOutcome(reactiveOutcome.isMatch(), message.because(reactiveOutcome.getMessage()));
/*     */     }
/* 123 */     return new ConditionOutcome((servletOutcome.isMatch()) || (reactiveOutcome.isMatch()), message
/* 124 */       .because(servletOutcome.getMessage()).append("and").append(reactiveOutcome.getMessage()));
/*     */   }
/*     */   
/*     */   private ConditionOutcome isServletWebApplication(ConditionContext context) {
/* 128 */     ConditionMessage.Builder message = ConditionMessage.forCondition("", new Object[0]);
/* 129 */     if (!FilteringSpringBootCondition.ClassNameFilter.isPresent("org.springframework.web.context.support.GenericWebApplicationContext", context.getClassLoader())) {
/* 130 */       return ConditionOutcome.noMatch(message.didNotFind("servlet web application classes").atAll());
/*     */     }
/* 132 */     if (context.getBeanFactory() != null) {
/* 133 */       String[] scopes = context.getBeanFactory().getRegisteredScopeNames();
/* 134 */       if (ObjectUtils.containsElement(scopes, "session")) {
/* 135 */         return ConditionOutcome.match(message.foundExactly("'session' scope"));
/*     */       }
/*     */     }
/* 138 */     if ((context.getEnvironment() instanceof ConfigurableWebEnvironment)) {
/* 139 */       return ConditionOutcome.match(message.foundExactly("ConfigurableWebEnvironment"));
/*     */     }
/* 141 */     if ((context.getResourceLoader() instanceof WebApplicationContext)) {
/* 142 */       return ConditionOutcome.match(message.foundExactly("WebApplicationContext"));
/*     */     }
/* 144 */     return ConditionOutcome.noMatch(message.because("not a servlet web application"));
/*     */   }
/*     */   
/*     */   private ConditionOutcome isReactiveWebApplication(ConditionContext context) {
/* 148 */     ConditionMessage.Builder message = ConditionMessage.forCondition("", new Object[0]);
/* 149 */     if (!FilteringSpringBootCondition.ClassNameFilter.isPresent("org.springframework.web.reactive.HandlerResult", context.getClassLoader())) {
/* 150 */       return ConditionOutcome.noMatch(message.didNotFind("reactive web application classes").atAll());
/*     */     }
/* 152 */     if ((context.getEnvironment() instanceof ConfigurableReactiveWebEnvironment)) {
/* 153 */       return ConditionOutcome.match(message.foundExactly("ConfigurableReactiveWebEnvironment"));
/*     */     }
/* 155 */     if ((context.getResourceLoader() instanceof ReactiveWebApplicationContext)) {
/* 156 */       return ConditionOutcome.match(message.foundExactly("ReactiveWebApplicationContext"));
/*     */     }
/* 158 */     return ConditionOutcome.noMatch(message.because("not a reactive web application"));
/*     */   }
/*     */   
/*     */   private ConditionalOnWebApplication.Type deduceType(AnnotatedTypeMetadata metadata) {
/* 162 */     Map<String, Object> attributes = metadata.getAnnotationAttributes(ConditionalOnWebApplication.class.getName());
/* 163 */     if (attributes != null) {
/* 164 */       return (ConditionalOnWebApplication.Type)attributes.get("type");
/*     */     }
/* 166 */     return ConditionalOnWebApplication.Type.ANY;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\condition\OnWebApplicationCondition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */