/*    */ package org.springframework.boot.autoconfigure.data.mongo;
/*    */ 
/*    */ import com.mongodb.reactivestreams.client.MongoClient;
/*    */ import org.springframework.boot.autoconfigure.AbstractDependsOnBeanFactoryPostProcessor;
/*    */ import org.springframework.core.annotation.Order;
/*    */ import org.springframework.data.mongodb.core.ReactiveMongoClientFactoryBean;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Order(Integer.MAX_VALUE)
/*    */ public class ReactiveStreamsMongoClientDependsOnBeanFactoryPostProcessor
/*    */   extends AbstractDependsOnBeanFactoryPostProcessor
/*    */ {
/*    */   public ReactiveStreamsMongoClientDependsOnBeanFactoryPostProcessor(Class<?>... dependsOn)
/*    */   {
/* 46 */     super(MongoClient.class, ReactiveMongoClientFactoryBean.class, dependsOn);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\data\mongo\ReactiveStreamsMongoClientDependsOnBeanFactoryPostProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */