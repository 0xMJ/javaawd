/*    */ package org.springframework.boot.autoconfigure.sql.init;
/*    */ 
/*    */ import io.r2dbc.spi.ConnectionFactory;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnSingleCandidate;
/*    */ import org.springframework.boot.r2dbc.ConnectionFactoryBuilder;
/*    */ import org.springframework.boot.r2dbc.init.R2dbcScriptDatabaseInitializer;
/*    */ import org.springframework.boot.sql.init.DatabaseInitializationSettings;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.r2dbc.connection.init.DatabasePopulator;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods=false)
/*    */ @ConditionalOnClass({ConnectionFactory.class, DatabasePopulator.class})
/*    */ @ConditionalOnSingleCandidate(ConnectionFactory.class)
/*    */ class R2dbcInitializationConfiguration
/*    */ {
/*    */   @Bean
/*    */   R2dbcScriptDatabaseInitializer r2dbcScriptDatabaseInitializer(ConnectionFactory connectionFactory, SqlInitializationProperties properties)
/*    */   {
/* 45 */     DatabaseInitializationSettings settings = SettingsCreator.createFrom(properties);
/* 46 */     return new R2dbcScriptDatabaseInitializer(
/* 47 */       determineConnectionFactory(connectionFactory, properties.getUsername(), properties.getPassword()), settings);
/*    */   }
/*    */   
/*    */ 
/*    */   private static ConnectionFactory determineConnectionFactory(ConnectionFactory connectionFactory, String username, String password)
/*    */   {
/* 53 */     if ((StringUtils.hasText(username)) && (StringUtils.hasText(password))) {
/* 54 */       return 
/* 55 */         ConnectionFactoryBuilder.derivedFrom(connectionFactory).username(username).password(password).build();
/*    */     }
/* 57 */     return connectionFactory;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\sql\init\R2dbcInitializationConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */