/*     */ package org.springframework.boot.autoconfigure.data.web;
/*     */ 
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties("spring.data.web")
/*     */ public class SpringDataWebProperties
/*     */ {
/*  30 */   private final Pageable pageable = new Pageable();
/*     */   
/*  32 */   private final Sort sort = new Sort();
/*     */   
/*     */   public Pageable getPageable() {
/*  35 */     return this.pageable;
/*     */   }
/*     */   
/*     */   public Sort getSort() {
/*  39 */     return this.sort;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Pageable
/*     */   {
/*  50 */     private String pageParameter = "page";
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  55 */     private String sizeParameter = "size";
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  61 */     private boolean oneIndexedParameters = false;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  66 */     private String prefix = "";
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  72 */     private String qualifierDelimiter = "_";
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  77 */     private int defaultPageSize = 20;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  82 */     private int maxPageSize = 2000;
/*     */     
/*     */     public String getPageParameter() {
/*  85 */       return this.pageParameter;
/*     */     }
/*     */     
/*     */     public void setPageParameter(String pageParameter) {
/*  89 */       this.pageParameter = pageParameter;
/*     */     }
/*     */     
/*     */     public String getSizeParameter() {
/*  93 */       return this.sizeParameter;
/*     */     }
/*     */     
/*     */     public void setSizeParameter(String sizeParameter) {
/*  97 */       this.sizeParameter = sizeParameter;
/*     */     }
/*     */     
/*     */     public boolean isOneIndexedParameters() {
/* 101 */       return this.oneIndexedParameters;
/*     */     }
/*     */     
/*     */     public void setOneIndexedParameters(boolean oneIndexedParameters) {
/* 105 */       this.oneIndexedParameters = oneIndexedParameters;
/*     */     }
/*     */     
/*     */     public String getPrefix() {
/* 109 */       return this.prefix;
/*     */     }
/*     */     
/*     */     public void setPrefix(String prefix) {
/* 113 */       this.prefix = prefix;
/*     */     }
/*     */     
/*     */     public String getQualifierDelimiter() {
/* 117 */       return this.qualifierDelimiter;
/*     */     }
/*     */     
/*     */     public void setQualifierDelimiter(String qualifierDelimiter) {
/* 121 */       this.qualifierDelimiter = qualifierDelimiter;
/*     */     }
/*     */     
/*     */     public int getDefaultPageSize() {
/* 125 */       return this.defaultPageSize;
/*     */     }
/*     */     
/*     */     public void setDefaultPageSize(int defaultPageSize) {
/* 129 */       this.defaultPageSize = defaultPageSize;
/*     */     }
/*     */     
/*     */     public int getMaxPageSize() {
/* 133 */       return this.maxPageSize;
/*     */     }
/*     */     
/*     */     public void setMaxPageSize(int maxPageSize) {
/* 137 */       this.maxPageSize = maxPageSize;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Sort
/*     */   {
/* 150 */     private String sortParameter = "sort";
/*     */     
/*     */     public String getSortParameter() {
/* 153 */       return this.sortParameter;
/*     */     }
/*     */     
/*     */     public void setSortParameter(String sortParameter) {
/* 157 */       this.sortParameter = sortParameter;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\data\web\SpringDataWebProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */