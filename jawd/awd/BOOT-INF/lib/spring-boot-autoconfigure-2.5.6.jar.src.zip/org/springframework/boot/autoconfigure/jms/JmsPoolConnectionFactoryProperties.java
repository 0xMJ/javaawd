/*     */ package org.springframework.boot.autoconfigure.jms;
/*     */ 
/*     */ import java.time.Duration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JmsPoolConnectionFactoryProperties
/*     */ {
/*     */   private boolean enabled;
/*  39 */   private boolean blockIfFull = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  44 */   private Duration blockIfFullTimeout = Duration.ofMillis(-1L);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  49 */   private Duration idleTimeout = Duration.ofSeconds(30L);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  54 */   private int maxConnections = 1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  59 */   private int maxSessionsPerConnection = 500;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  65 */   private Duration timeBetweenExpirationCheck = Duration.ofMillis(-1L);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  71 */   private boolean useAnonymousProducers = true;
/*     */   
/*     */   public boolean isEnabled() {
/*  74 */     return this.enabled;
/*     */   }
/*     */   
/*     */   public void setEnabled(boolean enabled) {
/*  78 */     this.enabled = enabled;
/*     */   }
/*     */   
/*     */   public boolean isBlockIfFull() {
/*  82 */     return this.blockIfFull;
/*     */   }
/*     */   
/*     */   public void setBlockIfFull(boolean blockIfFull) {
/*  86 */     this.blockIfFull = blockIfFull;
/*     */   }
/*     */   
/*     */   public Duration getBlockIfFullTimeout() {
/*  90 */     return this.blockIfFullTimeout;
/*     */   }
/*     */   
/*     */   public void setBlockIfFullTimeout(Duration blockIfFullTimeout) {
/*  94 */     this.blockIfFullTimeout = blockIfFullTimeout;
/*     */   }
/*     */   
/*     */   public Duration getIdleTimeout() {
/*  98 */     return this.idleTimeout;
/*     */   }
/*     */   
/*     */   public void setIdleTimeout(Duration idleTimeout) {
/* 102 */     this.idleTimeout = idleTimeout;
/*     */   }
/*     */   
/*     */   public int getMaxConnections() {
/* 106 */     return this.maxConnections;
/*     */   }
/*     */   
/*     */   public void setMaxConnections(int maxConnections) {
/* 110 */     this.maxConnections = maxConnections;
/*     */   }
/*     */   
/*     */   public int getMaxSessionsPerConnection() {
/* 114 */     return this.maxSessionsPerConnection;
/*     */   }
/*     */   
/*     */   public void setMaxSessionsPerConnection(int maxSessionsPerConnection) {
/* 118 */     this.maxSessionsPerConnection = maxSessionsPerConnection;
/*     */   }
/*     */   
/*     */   public Duration getTimeBetweenExpirationCheck() {
/* 122 */     return this.timeBetweenExpirationCheck;
/*     */   }
/*     */   
/*     */   public void setTimeBetweenExpirationCheck(Duration timeBetweenExpirationCheck) {
/* 126 */     this.timeBetweenExpirationCheck = timeBetweenExpirationCheck;
/*     */   }
/*     */   
/*     */   public boolean isUseAnonymousProducers() {
/* 130 */     return this.useAnonymousProducers;
/*     */   }
/*     */   
/*     */   public void setUseAnonymousProducers(boolean useAnonymousProducers) {
/* 134 */     this.useAnonymousProducers = useAnonymousProducers;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\jms\JmsPoolConnectionFactoryProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */