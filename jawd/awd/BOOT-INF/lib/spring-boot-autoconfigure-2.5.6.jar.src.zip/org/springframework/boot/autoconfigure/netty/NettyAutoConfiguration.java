/*    */ package org.springframework.boot.autoconfigure.netty;
/*    */ 
/*    */ import io.netty.util.NettyRuntime;
/*    */ import io.netty.util.ResourceLeakDetector;
/*    */ import io.netty.util.ResourceLeakDetector.Level;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods=false)
/*    */ @ConditionalOnClass({NettyRuntime.class})
/*    */ @EnableConfigurationProperties({NettyProperties.class})
/*    */ public class NettyAutoConfiguration
/*    */ {
/*    */   public NettyAutoConfiguration(NettyProperties properties)
/*    */   {
/* 39 */     if (properties.getLeakDetection() != null) {
/* 40 */       NettyProperties.LeakDetection leakDetection = properties.getLeakDetection();
/* 41 */       ResourceLeakDetector.setLevel(ResourceLeakDetector.Level.valueOf(leakDetection.name()));
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\netty\NettyAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */