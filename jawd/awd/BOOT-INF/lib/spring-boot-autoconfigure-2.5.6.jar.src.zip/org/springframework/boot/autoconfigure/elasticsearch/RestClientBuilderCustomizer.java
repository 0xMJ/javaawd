package org.springframework.boot.autoconfigure.elasticsearch;

import org.apache.http.client.config.RequestConfig.Builder;
import org.apache.http.impl.nio.client.HttpAsyncClientBuilder;
import org.elasticsearch.client.RestClientBuilder;

@FunctionalInterface
public abstract interface RestClientBuilderCustomizer
{
  public abstract void customize(RestClientBuilder paramRestClientBuilder);
  
  public void customize(HttpAsyncClientBuilder builder) {}
  
  public void customize(RequestConfig.Builder builder) {}
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\elasticsearch\RestClientBuilderCustomizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */