/*     */ package org.springframework.boot.autoconfigure.ldap.embedded;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.boot.convert.Delimiter;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix="spring.ldap.embedded")
/*     */ public class EmbeddedLdapProperties
/*     */ {
/*  40 */   private int port = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  45 */   private Credential credential = new Credential();
/*     */   
/*     */ 
/*     */ 
/*     */   @Delimiter("")
/*  50 */   private List<String> baseDn = new ArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  56 */   private String ldif = "classpath:schema.ldif";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  61 */   private Validation validation = new Validation();
/*     */   
/*     */   public int getPort() {
/*  64 */     return this.port;
/*     */   }
/*     */   
/*     */   public void setPort(int port) {
/*  68 */     this.port = port;
/*     */   }
/*     */   
/*     */   public Credential getCredential() {
/*  72 */     return this.credential;
/*     */   }
/*     */   
/*     */   public void setCredential(Credential credential) {
/*  76 */     this.credential = credential;
/*     */   }
/*     */   
/*     */   public List<String> getBaseDn() {
/*  80 */     return this.baseDn;
/*     */   }
/*     */   
/*     */   public void setBaseDn(List<String> baseDn) {
/*  84 */     this.baseDn = baseDn;
/*     */   }
/*     */   
/*     */   public String getLdif() {
/*  88 */     return this.ldif;
/*     */   }
/*     */   
/*     */   public void setLdif(String ldif) {
/*  92 */     this.ldif = ldif;
/*     */   }
/*     */   
/*     */   public Validation getValidation() {
/*  96 */     return this.validation;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static class Credential
/*     */   {
/*     */     private String username;
/*     */     
/*     */ 
/*     */     private String password;
/*     */     
/*     */ 
/*     */ 
/*     */     public String getUsername()
/*     */     {
/* 112 */       return this.username;
/*     */     }
/*     */     
/*     */     public void setUsername(String username) {
/* 116 */       this.username = username;
/*     */     }
/*     */     
/*     */     public String getPassword() {
/* 120 */       return this.password;
/*     */     }
/*     */     
/*     */     public void setPassword(String password) {
/* 124 */       this.password = password;
/*     */     }
/*     */     
/*     */     boolean isAvailable() {
/* 128 */       return (StringUtils.hasText(this.username)) && (StringUtils.hasText(this.password));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Validation
/*     */   {
/* 138 */     private boolean enabled = true;
/*     */     
/*     */ 
/*     */     private Resource schema;
/*     */     
/*     */ 
/*     */     public boolean isEnabled()
/*     */     {
/* 146 */       return this.enabled;
/*     */     }
/*     */     
/*     */     public void setEnabled(boolean enabled) {
/* 150 */       this.enabled = enabled;
/*     */     }
/*     */     
/*     */     public Resource getSchema() {
/* 154 */       return this.schema;
/*     */     }
/*     */     
/*     */     public void setSchema(Resource schema) {
/* 158 */       this.schema = schema;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\ldap\embedded\EmbeddedLdapProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */