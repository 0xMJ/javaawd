/*     */ package org.springframework.boot.autoconfigure.jms;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import javax.jms.ConnectionFactory;
/*     */ import javax.jms.ExceptionListener;
/*     */ import org.springframework.jms.config.DefaultJmsListenerContainerFactory;
/*     */ import org.springframework.jms.support.converter.MessageConverter;
/*     */ import org.springframework.jms.support.destination.DestinationResolver;
/*     */ import org.springframework.transaction.jta.JtaTransactionManager;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DefaultJmsListenerContainerFactoryConfigurer
/*     */ {
/*     */   private DestinationResolver destinationResolver;
/*     */   private MessageConverter messageConverter;
/*     */   private ExceptionListener exceptionListener;
/*     */   private JtaTransactionManager transactionManager;
/*     */   private JmsProperties jmsProperties;
/*     */   
/*     */   void setDestinationResolver(DestinationResolver destinationResolver)
/*     */   {
/*  55 */     this.destinationResolver = destinationResolver;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void setMessageConverter(MessageConverter messageConverter)
/*     */   {
/*  64 */     this.messageConverter = messageConverter;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void setExceptionListener(ExceptionListener exceptionListener)
/*     */   {
/*  73 */     this.exceptionListener = exceptionListener;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void setTransactionManager(JtaTransactionManager transactionManager)
/*     */   {
/*  82 */     this.transactionManager = transactionManager;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   void setJmsProperties(JmsProperties jmsProperties)
/*     */   {
/*  90 */     this.jmsProperties = jmsProperties;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void configure(DefaultJmsListenerContainerFactory factory, ConnectionFactory connectionFactory)
/*     */   {
/* 100 */     Assert.notNull(factory, "Factory must not be null");
/* 101 */     Assert.notNull(connectionFactory, "ConnectionFactory must not be null");
/* 102 */     factory.setConnectionFactory(connectionFactory);
/* 103 */     factory.setPubSubDomain(Boolean.valueOf(this.jmsProperties.isPubSubDomain()));
/* 104 */     if (this.transactionManager != null) {
/* 105 */       factory.setTransactionManager(this.transactionManager);
/*     */     }
/*     */     else {
/* 108 */       factory.setSessionTransacted(Boolean.valueOf(true));
/*     */     }
/* 110 */     if (this.destinationResolver != null) {
/* 111 */       factory.setDestinationResolver(this.destinationResolver);
/*     */     }
/* 113 */     if (this.messageConverter != null) {
/* 114 */       factory.setMessageConverter(this.messageConverter);
/*     */     }
/* 116 */     if (this.exceptionListener != null) {
/* 117 */       factory.setExceptionListener(this.exceptionListener);
/*     */     }
/* 119 */     JmsProperties.Listener listener = this.jmsProperties.getListener();
/* 120 */     factory.setAutoStartup(listener.isAutoStartup());
/* 121 */     if (listener.getAcknowledgeMode() != null) {
/* 122 */       factory.setSessionAcknowledgeMode(Integer.valueOf(listener.getAcknowledgeMode().getMode()));
/*     */     }
/* 124 */     String concurrency = listener.formatConcurrency();
/* 125 */     if (concurrency != null) {
/* 126 */       factory.setConcurrency(concurrency);
/*     */     }
/* 128 */     Duration receiveTimeout = listener.getReceiveTimeout();
/* 129 */     if (receiveTimeout != null) {
/* 130 */       factory.setReceiveTimeout(Long.valueOf(receiveTimeout.toMillis()));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\jms\DefaultJmsListenerContainerFactoryConfigurer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */