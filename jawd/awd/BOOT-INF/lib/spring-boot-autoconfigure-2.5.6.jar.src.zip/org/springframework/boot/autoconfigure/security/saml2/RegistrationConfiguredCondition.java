/*    */ package org.springframework.boot.autoconfigure.security.saml2;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.Map;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionMessage;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionMessage.Builder;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionMessage.ItemsBuilder;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionOutcome;
/*    */ import org.springframework.boot.autoconfigure.condition.SpringBootCondition;
/*    */ import org.springframework.boot.context.properties.bind.BindResult;
/*    */ import org.springframework.boot.context.properties.bind.Bindable;
/*    */ import org.springframework.boot.context.properties.bind.Binder;
/*    */ import org.springframework.context.annotation.ConditionContext;
/*    */ import org.springframework.core.env.Environment;
/*    */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class RegistrationConfiguredCondition
/*    */   extends SpringBootCondition
/*    */ {
/*    */   private static final String PROPERTY = "spring.security.saml2.relyingparty.registration";
/* 43 */   private static final Bindable<Map<String, Saml2RelyingPartyProperties.Registration>> STRING_REGISTRATION_MAP = Bindable.mapOf(String.class, Saml2RelyingPartyProperties.Registration.class);
/*    */   
/*    */ 
/*    */   public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata)
/*    */   {
/* 48 */     ConditionMessage.Builder message = ConditionMessage.forCondition("Relying Party Registration Condition", new Object[0]);
/* 49 */     Map<String, Saml2RelyingPartyProperties.Registration> registrations = getRegistrations(context.getEnvironment());
/* 50 */     if (registrations.isEmpty()) {
/* 51 */       return ConditionOutcome.noMatch(message.didNotFind("any registrations").atAll());
/*    */     }
/* 53 */     return ConditionOutcome.match(message.found("registration", "registrations").items(registrations.keySet()));
/*    */   }
/*    */   
/*    */   private Map<String, Saml2RelyingPartyProperties.Registration> getRegistrations(Environment environment) {
/* 57 */     return (Map)Binder.get(environment).bind("spring.security.saml2.relyingparty.registration", STRING_REGISTRATION_MAP).orElse(Collections.emptyMap());
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\security\saml2\RegistrationConfiguredCondition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */