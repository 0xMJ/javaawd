/*     */ package org.springframework.boot.autoconfigure.jdbc;
/*     */ 
/*     */ import com.zaxxer.hikari.HikariDataSource;
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.OracleConnection;
/*     */ import oracle.ucp.jdbc.PoolDataSourceImpl;
/*     */ import org.apache.commons.dbcp2.BasicDataSource;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.boot.jdbc.DataSourceBuilder;
/*     */ import org.springframework.boot.jdbc.DatabaseDriver;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class DataSourceConfiguration
/*     */ {
/*     */   protected static <T> T createDataSource(DataSourceProperties properties, Class<? extends javax.sql.DataSource> type)
/*     */   {
/*  48 */     return properties.initializeDataSourceBuilder().type(type).build();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Configuration(proxyBeanMethods=false)
/*     */   @ConditionalOnClass({org.apache.tomcat.jdbc.pool.DataSource.class})
/*     */   @ConditionalOnMissingBean({javax.sql.DataSource.class})
/*     */   @ConditionalOnProperty(name={"spring.datasource.type"}, havingValue="org.apache.tomcat.jdbc.pool.DataSource", matchIfMissing=true)
/*     */   static class Tomcat
/*     */   {
/*     */     @Bean
/*     */     @ConfigurationProperties(prefix="spring.datasource.tomcat")
/*     */     org.apache.tomcat.jdbc.pool.DataSource dataSource(DataSourceProperties properties)
/*     */     {
/*  64 */       org.apache.tomcat.jdbc.pool.DataSource dataSource = (org.apache.tomcat.jdbc.pool.DataSource)DataSourceConfiguration.createDataSource(properties, org.apache.tomcat.jdbc.pool.DataSource.class);
/*     */       
/*  66 */       DatabaseDriver databaseDriver = DatabaseDriver.fromJdbcUrl(properties.determineUrl());
/*  67 */       String validationQuery = databaseDriver.getValidationQuery();
/*  68 */       if (validationQuery != null) {
/*  69 */         dataSource.setTestOnBorrow(true);
/*  70 */         dataSource.setValidationQuery(validationQuery);
/*     */       }
/*  72 */       return dataSource;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Configuration(proxyBeanMethods=false)
/*     */   @ConditionalOnClass({HikariDataSource.class})
/*     */   @ConditionalOnMissingBean({javax.sql.DataSource.class})
/*     */   @ConditionalOnProperty(name={"spring.datasource.type"}, havingValue="com.zaxxer.hikari.HikariDataSource", matchIfMissing=true)
/*     */   static class Hikari
/*     */   {
/*     */     @Bean
/*     */     @ConfigurationProperties(prefix="spring.datasource.hikari")
/*     */     HikariDataSource dataSource(DataSourceProperties properties)
/*     */     {
/*  90 */       HikariDataSource dataSource = (HikariDataSource)DataSourceConfiguration.createDataSource(properties, HikariDataSource.class);
/*  91 */       if (StringUtils.hasText(properties.getName())) {
/*  92 */         dataSource.setPoolName(properties.getName());
/*     */       }
/*  94 */       return dataSource;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Configuration(proxyBeanMethods=false)
/*     */   @ConditionalOnClass({BasicDataSource.class})
/*     */   @ConditionalOnMissingBean({javax.sql.DataSource.class})
/*     */   @ConditionalOnProperty(name={"spring.datasource.type"}, havingValue="org.apache.commons.dbcp2.BasicDataSource", matchIfMissing=true)
/*     */   static class Dbcp2
/*     */   {
/*     */     @Bean
/*     */     @ConfigurationProperties(prefix="spring.datasource.dbcp2")
/*     */     BasicDataSource dataSource(DataSourceProperties properties)
/*     */     {
/* 112 */       return (BasicDataSource)DataSourceConfiguration.createDataSource(properties, BasicDataSource.class);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Configuration(proxyBeanMethods=false)
/*     */   @ConditionalOnClass({PoolDataSourceImpl.class, OracleConnection.class})
/*     */   @ConditionalOnMissingBean({javax.sql.DataSource.class})
/*     */   @ConditionalOnProperty(name={"spring.datasource.type"}, havingValue="oracle.ucp.jdbc.PoolDataSource", matchIfMissing=true)
/*     */   static class OracleUcp
/*     */   {
/*     */     @Bean
/*     */     @ConfigurationProperties(prefix="spring.datasource.oracleucp")
/*     */     PoolDataSourceImpl dataSource(DataSourceProperties properties)
/*     */       throws SQLException
/*     */     {
/* 130 */       PoolDataSourceImpl dataSource = (PoolDataSourceImpl)DataSourceConfiguration.createDataSource(properties, PoolDataSourceImpl.class);
/* 131 */       dataSource.setValidateConnectionOnBorrow(true);
/* 132 */       if (StringUtils.hasText(properties.getName())) {
/* 133 */         dataSource.setConnectionPoolName(properties.getName());
/*     */       }
/* 135 */       return dataSource;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Configuration(proxyBeanMethods=false)
/*     */   @ConditionalOnMissingBean({javax.sql.DataSource.class})
/*     */   @ConditionalOnProperty(name={"spring.datasource.type"})
/*     */   static class Generic
/*     */   {
/*     */     @Bean
/*     */     javax.sql.DataSource dataSource(DataSourceProperties properties)
/*     */     {
/* 150 */       return properties.initializeDataSourceBuilder().build();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\jdbc\DataSourceConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */