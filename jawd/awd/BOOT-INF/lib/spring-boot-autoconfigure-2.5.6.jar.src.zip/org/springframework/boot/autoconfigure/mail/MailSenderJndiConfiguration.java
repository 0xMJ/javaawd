/*    */ package org.springframework.boot.autoconfigure.mail;
/*    */ 
/*    */ import java.nio.charset.Charset;
/*    */ import javax.mail.Session;
/*    */ import javax.naming.NamingException;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnJndi;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.jndi.JndiLocatorDelegate;
/*    */ import org.springframework.mail.javamail.JavaMailSenderImpl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods=false)
/*    */ @ConditionalOnClass({Session.class})
/*    */ @ConditionalOnProperty(prefix="spring.mail", name={"jndi-name"})
/*    */ @ConditionalOnJndi
/*    */ class MailSenderJndiConfiguration
/*    */ {
/*    */   private final MailProperties properties;
/*    */   
/*    */   MailSenderJndiConfiguration(MailProperties properties)
/*    */   {
/* 47 */     this.properties = properties;
/*    */   }
/*    */   
/*    */   @Bean
/*    */   JavaMailSenderImpl mailSender(Session session) {
/* 52 */     JavaMailSenderImpl sender = new JavaMailSenderImpl();
/* 53 */     sender.setDefaultEncoding(this.properties.getDefaultEncoding().name());
/* 54 */     sender.setSession(session);
/* 55 */     return sender;
/*    */   }
/*    */   
/*    */   @Bean
/*    */   @ConditionalOnMissingBean
/*    */   Session session() {
/* 61 */     String jndiName = this.properties.getJndiName();
/*    */     try {
/* 63 */       return (Session)JndiLocatorDelegate.createDefaultResourceRefLocator().lookup(jndiName, Session.class);
/*    */     }
/*    */     catch (NamingException ex) {
/* 66 */       throw new IllegalStateException(String.format("Unable to find Session in JNDI location %s", new Object[] { jndiName }), ex);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\mail\MailSenderJndiConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */