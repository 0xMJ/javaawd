/*     */ package org.springframework.boot.autoconfigure.orm.jpa;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.orm.jpa.vendor.Database;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix="spring.jpa")
/*     */ public class JpaProperties
/*     */ {
/*  43 */   private Map<String, String> properties = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  48 */   private final List<String> mappingResources = new ArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String databasePlatform;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Database database;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  65 */   private boolean generateDdl = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  70 */   private boolean showSql = false;
/*     */   
/*     */ 
/*     */   private Boolean openInView;
/*     */   
/*     */ 
/*     */ 
/*     */   public Map<String, String> getProperties()
/*     */   {
/*  79 */     return this.properties;
/*     */   }
/*     */   
/*     */   public void setProperties(Map<String, String> properties) {
/*  83 */     this.properties = properties;
/*     */   }
/*     */   
/*     */   public List<String> getMappingResources() {
/*  87 */     return this.mappingResources;
/*     */   }
/*     */   
/*     */   public String getDatabasePlatform() {
/*  91 */     return this.databasePlatform;
/*     */   }
/*     */   
/*     */   public void setDatabasePlatform(String databasePlatform) {
/*  95 */     this.databasePlatform = databasePlatform;
/*     */   }
/*     */   
/*     */   public Database getDatabase() {
/*  99 */     return this.database;
/*     */   }
/*     */   
/*     */   public void setDatabase(Database database) {
/* 103 */     this.database = database;
/*     */   }
/*     */   
/*     */   public boolean isGenerateDdl() {
/* 107 */     return this.generateDdl;
/*     */   }
/*     */   
/*     */   public void setGenerateDdl(boolean generateDdl) {
/* 111 */     this.generateDdl = generateDdl;
/*     */   }
/*     */   
/*     */   public boolean isShowSql() {
/* 115 */     return this.showSql;
/*     */   }
/*     */   
/*     */   public void setShowSql(boolean showSql) {
/* 119 */     this.showSql = showSql;
/*     */   }
/*     */   
/*     */   public Boolean getOpenInView() {
/* 123 */     return this.openInView;
/*     */   }
/*     */   
/*     */   public void setOpenInView(Boolean openInView) {
/* 127 */     this.openInView = openInView;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\orm\jpa\JpaProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */