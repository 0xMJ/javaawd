/*    */ package org.springframework.boot.autoconfigure.web.client;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.stream.Collectors;
/*    */ import java.util.stream.Stream;
/*    */ import org.springframework.beans.factory.ObjectProvider;
/*    */ import org.springframework.boot.autoconfigure.AutoConfigureAfter;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication.Type;
/*    */ import org.springframework.boot.autoconfigure.condition.NoneNestedConditions;
/*    */ import org.springframework.boot.autoconfigure.http.HttpMessageConverters;
/*    */ import org.springframework.boot.autoconfigure.http.HttpMessageConvertersAutoConfiguration;
/*    */ import org.springframework.boot.web.client.RestTemplateBuilder;
/*    */ import org.springframework.boot.web.client.RestTemplateCustomizer;
/*    */ import org.springframework.boot.web.client.RestTemplateRequestCustomizer;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Conditional;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.ConfigurationCondition.ConfigurationPhase;
/*    */ import org.springframework.context.annotation.Lazy;
/*    */ import org.springframework.web.client.RestTemplate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods=false)
/*    */ @AutoConfigureAfter({HttpMessageConvertersAutoConfiguration.class})
/*    */ @ConditionalOnClass({RestTemplate.class})
/*    */ @Conditional({NotReactiveWebApplicationCondition.class})
/*    */ public class RestTemplateAutoConfiguration
/*    */ {
/*    */   @Bean
/*    */   @Lazy
/*    */   @ConditionalOnMissingBean
/*    */   public RestTemplateBuilderConfigurer restTemplateBuilderConfigurer(ObjectProvider<HttpMessageConverters> messageConverters, ObjectProvider<RestTemplateCustomizer> restTemplateCustomizers, ObjectProvider<RestTemplateRequestCustomizer<?>> restTemplateRequestCustomizers)
/*    */   {
/* 61 */     RestTemplateBuilderConfigurer configurer = new RestTemplateBuilderConfigurer();
/* 62 */     configurer.setHttpMessageConverters((HttpMessageConverters)messageConverters.getIfUnique());
/* 63 */     configurer.setRestTemplateCustomizers((List)restTemplateCustomizers.orderedStream().collect(Collectors.toList()));
/* 64 */     configurer.setRestTemplateRequestCustomizers(
/* 65 */       (List)restTemplateRequestCustomizers.orderedStream().collect(Collectors.toList()));
/* 66 */     return configurer;
/*    */   }
/*    */   
/*    */   @Bean
/*    */   @Lazy
/*    */   @ConditionalOnMissingBean
/*    */   public RestTemplateBuilder restTemplateBuilder(RestTemplateBuilderConfigurer restTemplateBuilderConfigurer) {
/* 73 */     RestTemplateBuilder builder = new RestTemplateBuilder(new RestTemplateCustomizer[0]);
/* 74 */     return restTemplateBuilderConfigurer.configure(builder);
/*    */   }
/*    */   
/*    */   static class NotReactiveWebApplicationCondition extends NoneNestedConditions
/*    */   {
/*    */     NotReactiveWebApplicationCondition() {
/* 80 */       super();
/*    */     }
/*    */     
/*    */     @ConditionalOnWebApplication(type=ConditionalOnWebApplication.Type.REACTIVE)
/*    */     private static class ReactiveWebApplication {}
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\web\client\RestTemplateAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */