/*    */ package org.springframework.boot.autoconfigure.data.neo4j;
/*    */ 
/*    */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @ConfigurationProperties(prefix="spring.data.neo4j")
/*    */ public class Neo4jDataProperties
/*    */ {
/*    */   private String database;
/*    */   
/*    */   public String getDatabase()
/*    */   {
/* 36 */     return this.database;
/*    */   }
/*    */   
/*    */   public void setDatabase(String database) {
/* 40 */     this.database = database;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\data\neo4j\Neo4jDataProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */