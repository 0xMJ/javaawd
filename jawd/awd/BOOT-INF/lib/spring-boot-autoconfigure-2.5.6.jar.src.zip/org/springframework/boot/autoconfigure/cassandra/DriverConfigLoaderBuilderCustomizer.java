package org.springframework.boot.autoconfigure.cassandra;

import com.datastax.oss.driver.api.core.config.ProgrammaticDriverConfigLoaderBuilder;

public abstract interface DriverConfigLoaderBuilderCustomizer
{
  public abstract void customize(ProgrammaticDriverConfigLoaderBuilder paramProgrammaticDriverConfigLoaderBuilder);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\cassandra\DriverConfigLoaderBuilderCustomizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */