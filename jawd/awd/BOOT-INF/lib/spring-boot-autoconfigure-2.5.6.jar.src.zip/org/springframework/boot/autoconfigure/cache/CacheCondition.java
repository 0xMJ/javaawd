/*    */ package org.springframework.boot.autoconfigure.cache;
/*    */ 
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionMessage;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionMessage.Builder;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionOutcome;
/*    */ import org.springframework.boot.autoconfigure.condition.SpringBootCondition;
/*    */ import org.springframework.boot.context.properties.bind.BindException;
/*    */ import org.springframework.boot.context.properties.bind.BindResult;
/*    */ import org.springframework.boot.context.properties.bind.Binder;
/*    */ import org.springframework.context.annotation.ConditionContext;
/*    */ import org.springframework.core.env.Environment;
/*    */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*    */ import org.springframework.core.type.AnnotationMetadata;
/*    */ import org.springframework.core.type.ClassMetadata;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class CacheCondition
/*    */   extends SpringBootCondition
/*    */ {
/*    */   public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata)
/*    */   {
/* 42 */     String sourceClass = "";
/* 43 */     if ((metadata instanceof ClassMetadata)) {
/* 44 */       sourceClass = ((ClassMetadata)metadata).getClassName();
/*    */     }
/* 46 */     ConditionMessage.Builder message = ConditionMessage.forCondition("Cache", new Object[] { sourceClass });
/* 47 */     Environment environment = context.getEnvironment();
/*    */     try {
/* 49 */       BindResult<CacheType> specified = Binder.get(environment).bind("spring.cache.type", CacheType.class);
/* 50 */       if (!specified.isBound()) {
/* 51 */         return ConditionOutcome.match(message.because("automatic cache type"));
/*    */       }
/* 53 */       CacheType required = CacheConfigurations.getType(((AnnotationMetadata)metadata).getClassName());
/* 54 */       if (specified.get() == required) {
/* 55 */         return ConditionOutcome.match(message.because(specified.get() + " cache type"));
/*    */       }
/*    */     }
/*    */     catch (BindException localBindException) {}
/*    */     
/* 60 */     return ConditionOutcome.noMatch(message.because("unknown cache type"));
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\cache\CacheCondition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */