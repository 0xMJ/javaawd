/*    */ package org.springframework.boot.autoconfigure.sql.init;
/*    */ 
/*    */ import javax.sql.DataSource;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnSingleCandidate;
/*    */ import org.springframework.boot.jdbc.DataSourceBuilder;
/*    */ import org.springframework.boot.jdbc.init.DataSourceScriptDatabaseInitializer;
/*    */ import org.springframework.boot.sql.init.AbstractScriptDatabaseInitializer;
/*    */ import org.springframework.boot.sql.init.DatabaseInitializationSettings;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.jdbc.datasource.SimpleDriverDataSource;
/*    */ import org.springframework.jdbc.datasource.init.DatabasePopulator;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods=false)
/*    */ @ConditionalOnMissingBean({AbstractScriptDatabaseInitializer.class})
/*    */ @ConditionalOnSingleCandidate(DataSource.class)
/*    */ @ConditionalOnClass({DatabasePopulator.class})
/*    */ class DataSourceInitializationConfiguration
/*    */ {
/*    */   @Bean
/*    */   DataSourceScriptDatabaseInitializer dataSourceScriptDatabaseInitializer(DataSource dataSource, SqlInitializationProperties initializationProperties)
/*    */   {
/* 43 */     DatabaseInitializationSettings settings = SettingsCreator.createFrom(initializationProperties);
/* 44 */     return new DataSourceScriptDatabaseInitializer(determineDataSource(dataSource, initializationProperties
/* 45 */       .getUsername(), initializationProperties.getPassword()), settings);
/*    */   }
/*    */   
/*    */   private static DataSource determineDataSource(DataSource dataSource, String username, String password) {
/* 49 */     if ((StringUtils.hasText(username)) && (StringUtils.hasText(password))) {
/* 50 */       return 
/* 51 */         DataSourceBuilder.derivedFrom(dataSource).username(username).password(password).type(SimpleDriverDataSource.class).build();
/*    */     }
/* 53 */     return dataSource;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\sql\init\DataSourceInitializationConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */