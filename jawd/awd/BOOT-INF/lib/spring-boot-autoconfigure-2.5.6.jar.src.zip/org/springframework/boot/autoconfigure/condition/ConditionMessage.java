/*     */ package org.springframework.boot.autoconfigure.condition;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ConditionMessage
/*     */ {
/*     */   private final String message;
/*     */   
/*     */   private ConditionMessage()
/*     */   {
/*  43 */     this(null);
/*     */   }
/*     */   
/*     */   private ConditionMessage(String message) {
/*  47 */     this.message = message;
/*     */   }
/*     */   
/*     */   private ConditionMessage(ConditionMessage prior, String message) {
/*  51 */     this.message = (prior + "; " + message);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isEmpty()
/*     */   {
/*  59 */     return !StringUtils.hasLength(this.message);
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/*  64 */     if (!(obj instanceof ConditionMessage)) {
/*  65 */       return false;
/*     */     }
/*  67 */     if (obj == this) {
/*  68 */       return true;
/*     */     }
/*  70 */     return ObjectUtils.nullSafeEquals(((ConditionMessage)obj).message, this.message);
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/*  75 */     return ObjectUtils.nullSafeHashCode(this.message);
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/*  80 */     return this.message != null ? this.message : "";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ConditionMessage append(String message)
/*     */   {
/*  90 */     if (!StringUtils.hasLength(message)) {
/*  91 */       return this;
/*     */     }
/*  93 */     if (!StringUtils.hasLength(this.message)) {
/*  94 */       return new ConditionMessage(message);
/*     */     }
/*     */     
/*  97 */     return new ConditionMessage(this.message + " " + message);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Builder andCondition(Class<? extends Annotation> condition, Object... details)
/*     */   {
/* 110 */     Assert.notNull(condition, "Condition must not be null");
/* 111 */     return andCondition("@" + ClassUtils.getShortName(condition), details);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Builder andCondition(String condition, Object... details)
/*     */   {
/* 124 */     Assert.notNull(condition, "Condition must not be null");
/* 125 */     String detail = StringUtils.arrayToDelimitedString(details, " ");
/* 126 */     if (StringUtils.hasLength(detail)) {
/* 127 */       return new Builder(condition + " " + detail, null);
/*     */     }
/* 129 */     return new Builder(condition, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ConditionMessage empty()
/*     */   {
/* 137 */     return new ConditionMessage();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ConditionMessage of(String message, Object... args)
/*     */   {
/* 148 */     if (ObjectUtils.isEmpty(args)) {
/* 149 */       return new ConditionMessage(message);
/*     */     }
/* 151 */     return new ConditionMessage(String.format(message, args));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ConditionMessage of(Collection<? extends ConditionMessage> messages)
/*     */   {
/* 161 */     ConditionMessage result = new ConditionMessage();
/* 162 */     if (messages != null) {
/* 163 */       for (ConditionMessage message : messages) {
/* 164 */         result = new ConditionMessage(result, message.toString());
/*     */       }
/*     */     }
/* 167 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Builder forCondition(Class<? extends Annotation> condition, Object... details)
/*     */   {
/* 180 */     return new ConditionMessage().andCondition(condition, details);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Builder forCondition(String condition, Object... details)
/*     */   {
/* 193 */     return new ConditionMessage().andCondition(condition, details);
/*     */   }
/*     */   
/*     */ 
/*     */   public final class Builder
/*     */   {
/*     */     private final String condition;
/*     */     
/*     */ 
/*     */     private Builder(String condition)
/*     */     {
/* 204 */       this.condition = condition;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public ConditionMessage foundExactly(Object result)
/*     */     {
/* 214 */       return found("").items(new Object[] { result });
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public ConditionMessage.ItemsBuilder found(String article)
/*     */     {
/* 224 */       return found(article, article);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public ConditionMessage.ItemsBuilder found(String singular, String plural)
/*     */     {
/* 236 */       return new ConditionMessage.ItemsBuilder(ConditionMessage.this, this, "found", singular, plural, null);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public ConditionMessage.ItemsBuilder didNotFind(String article)
/*     */     {
/* 247 */       return didNotFind(article, article);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public ConditionMessage.ItemsBuilder didNotFind(String singular, String plural)
/*     */     {
/* 259 */       return new ConditionMessage.ItemsBuilder(ConditionMessage.this, this, "did not find", singular, plural, null);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public ConditionMessage resultedIn(Object result)
/*     */     {
/* 269 */       return because("resulted in " + result);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public ConditionMessage available(String item)
/*     */     {
/* 279 */       return because(item + " is available");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public ConditionMessage notAvailable(String item)
/*     */     {
/* 289 */       return because(item + " is not available");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public ConditionMessage because(String reason)
/*     */     {
/* 299 */       if (StringUtils.hasLength(reason)) {
/* 300 */         return new ConditionMessage(ConditionMessage.this, 
/* 301 */           StringUtils.hasLength(this.condition) ? this.condition + " " + reason : reason, null);
/*     */       }
/* 303 */       return new ConditionMessage(ConditionMessage.this, this.condition, null);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final class ItemsBuilder
/*     */   {
/*     */     private final ConditionMessage.Builder condition;
/*     */     
/*     */     private final String reason;
/*     */     
/*     */     private final String singular;
/*     */     
/*     */     private final String plural;
/*     */     
/*     */ 
/*     */     private ItemsBuilder(ConditionMessage.Builder condition, String reason, String singular, String plural)
/*     */     {
/* 322 */       this.condition = condition;
/* 323 */       this.reason = reason;
/* 324 */       this.singular = singular;
/* 325 */       this.plural = plural;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public ConditionMessage atAll()
/*     */     {
/* 335 */       return items(Collections.emptyList());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public ConditionMessage items(Object... items)
/*     */     {
/* 346 */       return items(ConditionMessage.Style.NORMAL, items);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public ConditionMessage items(ConditionMessage.Style style, Object... items)
/*     */     {
/* 358 */       return items(style, items != null ? Arrays.asList(items) : null);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public ConditionMessage items(Collection<?> items)
/*     */     {
/* 369 */       return items(ConditionMessage.Style.NORMAL, items);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public ConditionMessage items(ConditionMessage.Style style, Collection<?> items)
/*     */     {
/* 381 */       Assert.notNull(style, "Style must not be null");
/* 382 */       StringBuilder message = new StringBuilder(this.reason);
/* 383 */       items = style.applyTo(items);
/* 384 */       if (((this.condition == null) || (items == null) || (items.size() <= 1)) && 
/* 385 */         (StringUtils.hasLength(this.singular))) {
/* 386 */         message.append(" ").append(this.singular);
/*     */       }
/* 388 */       else if (StringUtils.hasLength(this.plural)) {
/* 389 */         message.append(" ").append(this.plural);
/*     */       }
/* 391 */       if ((items != null) && (!items.isEmpty())) {
/* 392 */         message.append(" ").append(StringUtils.collectionToDelimitedString(items, ", "));
/*     */       }
/* 394 */       return this.condition.because(message.toString());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static abstract enum Style
/*     */   {
/* 407 */     NORMAL, 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 419 */     QUOTE;
/*     */     
/*     */ 
/*     */ 
/*     */     private Style() {}
/*     */     
/*     */ 
/*     */ 
/*     */     public Collection<?> applyTo(Collection<?> items)
/*     */     {
/* 429 */       if (items == null) {
/* 430 */         return null;
/*     */       }
/* 432 */       List<Object> result = new ArrayList(items.size());
/* 433 */       for (Object item : items) {
/* 434 */         result.add(applyToItem(item));
/*     */       }
/* 436 */       return result;
/*     */     }
/*     */     
/*     */     protected abstract Object applyToItem(Object paramObject);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\condition\ConditionMessage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */