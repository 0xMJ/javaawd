/*     */ package org.springframework.boot.autoconfigure.context;
/*     */ 
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.time.Duration;
/*     */ import java.time.temporal.ChronoUnit;
/*     */ import org.springframework.boot.convert.DurationUnit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MessageSourceProperties
/*     */ {
/*  41 */   private String basename = "messages";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  46 */   private Charset encoding = StandardCharsets.UTF_8;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @DurationUnit(ChronoUnit.SECONDS)
/*     */   private Duration cacheDuration;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  60 */   private boolean fallbackToSystemLocale = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  66 */   private boolean alwaysUseMessageFormat = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  72 */   private boolean useCodeAsDefaultMessage = false;
/*     */   
/*     */   public String getBasename() {
/*  75 */     return this.basename;
/*     */   }
/*     */   
/*     */   public void setBasename(String basename) {
/*  79 */     this.basename = basename;
/*     */   }
/*     */   
/*     */   public Charset getEncoding() {
/*  83 */     return this.encoding;
/*     */   }
/*     */   
/*     */   public void setEncoding(Charset encoding) {
/*  87 */     this.encoding = encoding;
/*     */   }
/*     */   
/*     */   public Duration getCacheDuration() {
/*  91 */     return this.cacheDuration;
/*     */   }
/*     */   
/*     */   public void setCacheDuration(Duration cacheDuration) {
/*  95 */     this.cacheDuration = cacheDuration;
/*     */   }
/*     */   
/*     */   public boolean isFallbackToSystemLocale() {
/*  99 */     return this.fallbackToSystemLocale;
/*     */   }
/*     */   
/*     */   public void setFallbackToSystemLocale(boolean fallbackToSystemLocale) {
/* 103 */     this.fallbackToSystemLocale = fallbackToSystemLocale;
/*     */   }
/*     */   
/*     */   public boolean isAlwaysUseMessageFormat() {
/* 107 */     return this.alwaysUseMessageFormat;
/*     */   }
/*     */   
/*     */   public void setAlwaysUseMessageFormat(boolean alwaysUseMessageFormat) {
/* 111 */     this.alwaysUseMessageFormat = alwaysUseMessageFormat;
/*     */   }
/*     */   
/*     */   public boolean isUseCodeAsDefaultMessage() {
/* 115 */     return this.useCodeAsDefaultMessage;
/*     */   }
/*     */   
/*     */   public void setUseCodeAsDefaultMessage(boolean useCodeAsDefaultMessage) {
/* 119 */     this.useCodeAsDefaultMessage = useCodeAsDefaultMessage;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\context\MessageSourceProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */