/*    */ package org.springframework.boot.autoconfigure.sql.init;
/*    */ 
/*    */ import org.springframework.boot.autoconfigure.AutoConfigureAfter;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*    */ import org.springframework.boot.autoconfigure.condition.NoneNestedConditions;
/*    */ import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
/*    */ import org.springframework.boot.autoconfigure.r2dbc.R2dbcAutoConfiguration;
/*    */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*    */ import org.springframework.boot.sql.init.AbstractScriptDatabaseInitializer;
/*    */ import org.springframework.boot.sql.init.dependency.DatabaseInitializationDependencyConfigurer;
/*    */ import org.springframework.context.annotation.Conditional;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.ConfigurationCondition.ConfigurationPhase;
/*    */ import org.springframework.context.annotation.Import;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods=false)
/*    */ @ConditionalOnMissingBean({AbstractScriptDatabaseInitializer.class})
/*    */ @AutoConfigureAfter({R2dbcAutoConfiguration.class, DataSourceAutoConfiguration.class})
/*    */ @EnableConfigurationProperties({SqlInitializationProperties.class})
/*    */ @Import({DatabaseInitializationDependencyConfigurer.class, R2dbcInitializationConfiguration.class, DataSourceInitializationConfiguration.class})
/*    */ @ConditionalOnProperty(prefix="spring.sql.init", name={"enabled"}, matchIfMissing=true)
/*    */ @Conditional({SqlInitializationModeCondition.class})
/*    */ public class SqlInitializationAutoConfiguration
/*    */ {
/*    */   static class SqlInitializationModeCondition
/*    */     extends NoneNestedConditions
/*    */   {
/*    */     SqlInitializationModeCondition()
/*    */     {
/* 53 */       super();
/*    */     }
/*    */     
/*    */     @ConditionalOnProperty(prefix="spring.sql.init", name={"mode"}, havingValue="never")
/*    */     static class ModeIsNever {}
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\sql\init\SqlInitializationAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */