/*     */ package org.springframework.boot.autoconfigure.flyway;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.boot.context.properties.DeprecatedConfigurationProperty;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix="spring.flyway")
/*     */ public class FlywayProperties
/*     */ {
/*  46 */   private boolean enabled = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*  52 */   private boolean checkLocation = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  59 */   private List<String> locations = new ArrayList(Collections.singletonList("classpath:db/migration"));
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  64 */   private Charset encoding = StandardCharsets.UTF_8;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int connectRetries;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private Integer lockRetryCount;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String defaultSchema;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  84 */   private List<String> schemas = new ArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  90 */   private boolean createSchemas = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  95 */   private String table = "flyway_schema_history";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String tablespace;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 107 */   private String baselineDescription = "<< Flyway Baseline >>";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 112 */   private String baselineVersion = "1";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String installedBy;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 122 */   private Map<String, String> placeholders = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 127 */   private String placeholderPrefix = "${";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 132 */   private String placeholderSuffix = "}";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 137 */   private boolean placeholderReplacement = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 142 */   private String sqlMigrationPrefix = "V";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 147 */   private List<String> sqlMigrationSuffixes = new ArrayList(Collections.singleton(".sql"));
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 152 */   private String sqlMigrationSeparator = "__";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 157 */   private String repeatableSqlMigrationPrefix = "R";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String target;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String user;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String password;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String driverClassName;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String url;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 189 */   private List<String> initSqls = new ArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean baselineOnMigrate;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean cleanDisabled;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean cleanOnValidationError;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean group;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean ignoreMissingMigrations;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean ignoreIgnoredMigrations;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean ignorePendingMigrations;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 230 */   private boolean ignoreFutureMigrations = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean mixed;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean outOfOrder;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean skipDefaultCallbacks;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean skipDefaultResolvers;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 257 */   private boolean validateMigrationNaming = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 262 */   private boolean validateOnMigrate = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Boolean batch;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private File dryRunOutput;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String[] errorOverrides;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String licenseKey;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private Boolean oracleSqlplus;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private Boolean oracleSqlplusWarn;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private Boolean stream;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String undoSqlMigrationPrefix;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String[] cherryPick;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 316 */   private Map<String, String> jdbcProperties = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String oracleKerberosCacheFile;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String oracleKerberosConfigFile;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private Boolean outputQueryResults;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private Boolean skipExecutingMigrations;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String vaultUrl;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String vaultToken;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private List<String> vaultSecrets;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isEnabled()
/*     */   {
/* 359 */     return this.enabled;
/*     */   }
/*     */   
/*     */   public void setEnabled(boolean enabled) {
/* 363 */     this.enabled = enabled;
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   @DeprecatedConfigurationProperty(reason="Locations can no longer be checked accurately due to changes in Flyway's location support.")
/*     */   public boolean isCheckLocation()
/*     */   {
/* 370 */     return this.checkLocation;
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public void setCheckLocation(boolean checkLocation) {
/* 375 */     this.checkLocation = checkLocation;
/*     */   }
/*     */   
/*     */   public List<String> getLocations() {
/* 379 */     return this.locations;
/*     */   }
/*     */   
/*     */   public void setLocations(List<String> locations) {
/* 383 */     this.locations = locations;
/*     */   }
/*     */   
/*     */   public Charset getEncoding() {
/* 387 */     return this.encoding;
/*     */   }
/*     */   
/*     */   public void setEncoding(Charset encoding) {
/* 391 */     this.encoding = encoding;
/*     */   }
/*     */   
/*     */   public int getConnectRetries() {
/* 395 */     return this.connectRetries;
/*     */   }
/*     */   
/*     */   public void setConnectRetries(int connectRetries) {
/* 399 */     this.connectRetries = connectRetries;
/*     */   }
/*     */   
/*     */   public Integer getLockRetryCount() {
/* 403 */     return this.lockRetryCount;
/*     */   }
/*     */   
/*     */   public void setLockRetryCount(Integer lockRetryCount) {
/* 407 */     this.lockRetryCount = lockRetryCount;
/*     */   }
/*     */   
/*     */   public String getDefaultSchema() {
/* 411 */     return this.defaultSchema;
/*     */   }
/*     */   
/*     */   public void setDefaultSchema(String defaultSchema) {
/* 415 */     this.defaultSchema = defaultSchema;
/*     */   }
/*     */   
/*     */   public List<String> getSchemas() {
/* 419 */     return this.schemas;
/*     */   }
/*     */   
/*     */   public void setSchemas(List<String> schemas) {
/* 423 */     this.schemas = schemas;
/*     */   }
/*     */   
/*     */   public boolean isCreateSchemas() {
/* 427 */     return this.createSchemas;
/*     */   }
/*     */   
/*     */   public void setCreateSchemas(boolean createSchemas) {
/* 431 */     this.createSchemas = createSchemas;
/*     */   }
/*     */   
/*     */   public String getTable() {
/* 435 */     return this.table;
/*     */   }
/*     */   
/*     */   public void setTable(String table) {
/* 439 */     this.table = table;
/*     */   }
/*     */   
/*     */   public String getTablespace() {
/* 443 */     return this.tablespace;
/*     */   }
/*     */   
/*     */   public void setTablespace(String tablespace) {
/* 447 */     this.tablespace = tablespace;
/*     */   }
/*     */   
/*     */   public String getBaselineDescription() {
/* 451 */     return this.baselineDescription;
/*     */   }
/*     */   
/*     */   public void setBaselineDescription(String baselineDescription) {
/* 455 */     this.baselineDescription = baselineDescription;
/*     */   }
/*     */   
/*     */   public String getBaselineVersion() {
/* 459 */     return this.baselineVersion;
/*     */   }
/*     */   
/*     */   public void setBaselineVersion(String baselineVersion) {
/* 463 */     this.baselineVersion = baselineVersion;
/*     */   }
/*     */   
/*     */   public String getInstalledBy() {
/* 467 */     return this.installedBy;
/*     */   }
/*     */   
/*     */   public void setInstalledBy(String installedBy) {
/* 471 */     this.installedBy = installedBy;
/*     */   }
/*     */   
/*     */   public Map<String, String> getPlaceholders() {
/* 475 */     return this.placeholders;
/*     */   }
/*     */   
/*     */   public void setPlaceholders(Map<String, String> placeholders) {
/* 479 */     this.placeholders = placeholders;
/*     */   }
/*     */   
/*     */   public String getPlaceholderPrefix() {
/* 483 */     return this.placeholderPrefix;
/*     */   }
/*     */   
/*     */   public void setPlaceholderPrefix(String placeholderPrefix) {
/* 487 */     this.placeholderPrefix = placeholderPrefix;
/*     */   }
/*     */   
/*     */   public String getPlaceholderSuffix() {
/* 491 */     return this.placeholderSuffix;
/*     */   }
/*     */   
/*     */   public void setPlaceholderSuffix(String placeholderSuffix) {
/* 495 */     this.placeholderSuffix = placeholderSuffix;
/*     */   }
/*     */   
/*     */   public boolean isPlaceholderReplacement() {
/* 499 */     return this.placeholderReplacement;
/*     */   }
/*     */   
/*     */   public void setPlaceholderReplacement(boolean placeholderReplacement) {
/* 503 */     this.placeholderReplacement = placeholderReplacement;
/*     */   }
/*     */   
/*     */   public String getSqlMigrationPrefix() {
/* 507 */     return this.sqlMigrationPrefix;
/*     */   }
/*     */   
/*     */   public void setSqlMigrationPrefix(String sqlMigrationPrefix) {
/* 511 */     this.sqlMigrationPrefix = sqlMigrationPrefix;
/*     */   }
/*     */   
/*     */   public List<String> getSqlMigrationSuffixes() {
/* 515 */     return this.sqlMigrationSuffixes;
/*     */   }
/*     */   
/*     */   public void setSqlMigrationSuffixes(List<String> sqlMigrationSuffixes) {
/* 519 */     this.sqlMigrationSuffixes = sqlMigrationSuffixes;
/*     */   }
/*     */   
/*     */   public String getSqlMigrationSeparator() {
/* 523 */     return this.sqlMigrationSeparator;
/*     */   }
/*     */   
/*     */   public void setSqlMigrationSeparator(String sqlMigrationSeparator) {
/* 527 */     this.sqlMigrationSeparator = sqlMigrationSeparator;
/*     */   }
/*     */   
/*     */   public String getRepeatableSqlMigrationPrefix() {
/* 531 */     return this.repeatableSqlMigrationPrefix;
/*     */   }
/*     */   
/*     */   public void setRepeatableSqlMigrationPrefix(String repeatableSqlMigrationPrefix) {
/* 535 */     this.repeatableSqlMigrationPrefix = repeatableSqlMigrationPrefix;
/*     */   }
/*     */   
/*     */   public String getTarget() {
/* 539 */     return this.target;
/*     */   }
/*     */   
/*     */   public void setTarget(String target) {
/* 543 */     this.target = target;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public boolean isCreateDataSource()
/*     */   {
/* 554 */     return (this.url != null) || (this.user != null);
/*     */   }
/*     */   
/*     */   public String getUser() {
/* 558 */     return this.user;
/*     */   }
/*     */   
/*     */   public void setUser(String user) {
/* 562 */     this.user = user;
/*     */   }
/*     */   
/*     */   public String getPassword() {
/* 566 */     return this.password != null ? this.password : "";
/*     */   }
/*     */   
/*     */   public void setPassword(String password) {
/* 570 */     this.password = password;
/*     */   }
/*     */   
/*     */   public String getDriverClassName() {
/* 574 */     return this.driverClassName;
/*     */   }
/*     */   
/*     */   public void setDriverClassName(String driverClassName) {
/* 578 */     this.driverClassName = driverClassName;
/*     */   }
/*     */   
/*     */   public String getUrl() {
/* 582 */     return this.url;
/*     */   }
/*     */   
/*     */   public void setUrl(String url) {
/* 586 */     this.url = url;
/*     */   }
/*     */   
/*     */   public List<String> getInitSqls() {
/* 590 */     return this.initSqls;
/*     */   }
/*     */   
/*     */   public void setInitSqls(List<String> initSqls) {
/* 594 */     this.initSqls = initSqls;
/*     */   }
/*     */   
/*     */   public boolean isBaselineOnMigrate() {
/* 598 */     return this.baselineOnMigrate;
/*     */   }
/*     */   
/*     */   public void setBaselineOnMigrate(boolean baselineOnMigrate) {
/* 602 */     this.baselineOnMigrate = baselineOnMigrate;
/*     */   }
/*     */   
/*     */   public boolean isCleanDisabled() {
/* 606 */     return this.cleanDisabled;
/*     */   }
/*     */   
/*     */   public void setCleanDisabled(boolean cleanDisabled) {
/* 610 */     this.cleanDisabled = cleanDisabled;
/*     */   }
/*     */   
/*     */   public boolean isCleanOnValidationError() {
/* 614 */     return this.cleanOnValidationError;
/*     */   }
/*     */   
/*     */   public void setCleanOnValidationError(boolean cleanOnValidationError) {
/* 618 */     this.cleanOnValidationError = cleanOnValidationError;
/*     */   }
/*     */   
/*     */   public boolean isGroup() {
/* 622 */     return this.group;
/*     */   }
/*     */   
/*     */   public void setGroup(boolean group) {
/* 626 */     this.group = group;
/*     */   }
/*     */   
/*     */   public boolean isIgnoreMissingMigrations() {
/* 630 */     return this.ignoreMissingMigrations;
/*     */   }
/*     */   
/*     */   public void setIgnoreMissingMigrations(boolean ignoreMissingMigrations) {
/* 634 */     this.ignoreMissingMigrations = ignoreMissingMigrations;
/*     */   }
/*     */   
/*     */   public boolean isIgnoreIgnoredMigrations() {
/* 638 */     return this.ignoreIgnoredMigrations;
/*     */   }
/*     */   
/*     */   public void setIgnoreIgnoredMigrations(boolean ignoreIgnoredMigrations) {
/* 642 */     this.ignoreIgnoredMigrations = ignoreIgnoredMigrations;
/*     */   }
/*     */   
/*     */   public boolean isIgnorePendingMigrations() {
/* 646 */     return this.ignorePendingMigrations;
/*     */   }
/*     */   
/*     */   public void setIgnorePendingMigrations(boolean ignorePendingMigrations) {
/* 650 */     this.ignorePendingMigrations = ignorePendingMigrations;
/*     */   }
/*     */   
/*     */   public boolean isIgnoreFutureMigrations() {
/* 654 */     return this.ignoreFutureMigrations;
/*     */   }
/*     */   
/*     */   public void setIgnoreFutureMigrations(boolean ignoreFutureMigrations) {
/* 658 */     this.ignoreFutureMigrations = ignoreFutureMigrations;
/*     */   }
/*     */   
/*     */   public boolean isMixed() {
/* 662 */     return this.mixed;
/*     */   }
/*     */   
/*     */   public void setMixed(boolean mixed) {
/* 666 */     this.mixed = mixed;
/*     */   }
/*     */   
/*     */   public boolean isOutOfOrder() {
/* 670 */     return this.outOfOrder;
/*     */   }
/*     */   
/*     */   public void setOutOfOrder(boolean outOfOrder) {
/* 674 */     this.outOfOrder = outOfOrder;
/*     */   }
/*     */   
/*     */   public boolean isSkipDefaultCallbacks() {
/* 678 */     return this.skipDefaultCallbacks;
/*     */   }
/*     */   
/*     */   public void setSkipDefaultCallbacks(boolean skipDefaultCallbacks) {
/* 682 */     this.skipDefaultCallbacks = skipDefaultCallbacks;
/*     */   }
/*     */   
/*     */   public boolean isSkipDefaultResolvers() {
/* 686 */     return this.skipDefaultResolvers;
/*     */   }
/*     */   
/*     */   public void setSkipDefaultResolvers(boolean skipDefaultResolvers) {
/* 690 */     this.skipDefaultResolvers = skipDefaultResolvers;
/*     */   }
/*     */   
/*     */   public boolean isValidateMigrationNaming() {
/* 694 */     return this.validateMigrationNaming;
/*     */   }
/*     */   
/*     */   public void setValidateMigrationNaming(boolean validateMigrationNaming) {
/* 698 */     this.validateMigrationNaming = validateMigrationNaming;
/*     */   }
/*     */   
/*     */   public boolean isValidateOnMigrate() {
/* 702 */     return this.validateOnMigrate;
/*     */   }
/*     */   
/*     */   public void setValidateOnMigrate(boolean validateOnMigrate) {
/* 706 */     this.validateOnMigrate = validateOnMigrate;
/*     */   }
/*     */   
/*     */   public Boolean getBatch() {
/* 710 */     return this.batch;
/*     */   }
/*     */   
/*     */   public void setBatch(Boolean batch) {
/* 714 */     this.batch = batch;
/*     */   }
/*     */   
/*     */   public File getDryRunOutput() {
/* 718 */     return this.dryRunOutput;
/*     */   }
/*     */   
/*     */   public void setDryRunOutput(File dryRunOutput) {
/* 722 */     this.dryRunOutput = dryRunOutput;
/*     */   }
/*     */   
/*     */   public String[] getErrorOverrides() {
/* 726 */     return this.errorOverrides;
/*     */   }
/*     */   
/*     */   public void setErrorOverrides(String[] errorOverrides) {
/* 730 */     this.errorOverrides = errorOverrides;
/*     */   }
/*     */   
/*     */   public String getLicenseKey() {
/* 734 */     return this.licenseKey;
/*     */   }
/*     */   
/*     */   public void setLicenseKey(String licenseKey) {
/* 738 */     this.licenseKey = licenseKey;
/*     */   }
/*     */   
/*     */   public Boolean getOracleSqlplus() {
/* 742 */     return this.oracleSqlplus;
/*     */   }
/*     */   
/*     */   public void setOracleSqlplus(Boolean oracleSqlplus) {
/* 746 */     this.oracleSqlplus = oracleSqlplus;
/*     */   }
/*     */   
/*     */   public Boolean getOracleSqlplusWarn() {
/* 750 */     return this.oracleSqlplusWarn;
/*     */   }
/*     */   
/*     */   public void setOracleSqlplusWarn(Boolean oracleSqlplusWarn) {
/* 754 */     this.oracleSqlplusWarn = oracleSqlplusWarn;
/*     */   }
/*     */   
/*     */   public Boolean getStream() {
/* 758 */     return this.stream;
/*     */   }
/*     */   
/*     */   public void setStream(Boolean stream) {
/* 762 */     this.stream = stream;
/*     */   }
/*     */   
/*     */   public String getUndoSqlMigrationPrefix() {
/* 766 */     return this.undoSqlMigrationPrefix;
/*     */   }
/*     */   
/*     */   public void setUndoSqlMigrationPrefix(String undoSqlMigrationPrefix) {
/* 770 */     this.undoSqlMigrationPrefix = undoSqlMigrationPrefix;
/*     */   }
/*     */   
/*     */   public String[] getCherryPick() {
/* 774 */     return this.cherryPick;
/*     */   }
/*     */   
/*     */   public void setCherryPick(String[] cherryPick) {
/* 778 */     this.cherryPick = cherryPick;
/*     */   }
/*     */   
/*     */   public Map<String, String> getJdbcProperties() {
/* 782 */     return this.jdbcProperties;
/*     */   }
/*     */   
/*     */   public void setJdbcProperties(Map<String, String> jdbcProperties) {
/* 786 */     this.jdbcProperties = jdbcProperties;
/*     */   }
/*     */   
/*     */   public String getOracleKerberosCacheFile() {
/* 790 */     return this.oracleKerberosCacheFile;
/*     */   }
/*     */   
/*     */   public void setOracleKerberosCacheFile(String oracleKerberosCacheFile) {
/* 794 */     this.oracleKerberosCacheFile = oracleKerberosCacheFile;
/*     */   }
/*     */   
/*     */   public String getOracleKerberosConfigFile() {
/* 798 */     return this.oracleKerberosConfigFile;
/*     */   }
/*     */   
/*     */   public void setOracleKerberosConfigFile(String oracleKerberosConfigFile) {
/* 802 */     this.oracleKerberosConfigFile = oracleKerberosConfigFile;
/*     */   }
/*     */   
/*     */   public Boolean getOutputQueryResults() {
/* 806 */     return this.outputQueryResults;
/*     */   }
/*     */   
/*     */   public void setOutputQueryResults(Boolean outputQueryResults) {
/* 810 */     this.outputQueryResults = outputQueryResults;
/*     */   }
/*     */   
/*     */   public Boolean getSkipExecutingMigrations() {
/* 814 */     return this.skipExecutingMigrations;
/*     */   }
/*     */   
/*     */   public void setSkipExecutingMigrations(Boolean skipExecutingMigrations) {
/* 818 */     this.skipExecutingMigrations = skipExecutingMigrations;
/*     */   }
/*     */   
/*     */   public String getVaultUrl() {
/* 822 */     return this.vaultUrl;
/*     */   }
/*     */   
/*     */   public void setVaultUrl(String vaultUrl) {
/* 826 */     this.vaultUrl = vaultUrl;
/*     */   }
/*     */   
/*     */   public String getVaultToken() {
/* 830 */     return this.vaultToken;
/*     */   }
/*     */   
/*     */   public void setVaultToken(String vaultToken) {
/* 834 */     this.vaultToken = vaultToken;
/*     */   }
/*     */   
/*     */   public List<String> getVaultSecrets() {
/* 838 */     return this.vaultSecrets;
/*     */   }
/*     */   
/*     */   public void setVaultSecrets(List<String> vaultSecrets) {
/* 842 */     this.vaultSecrets = vaultSecrets;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\flyway\FlywayProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */