/*     */ package org.springframework.boot.autoconfigure.security;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.UUID;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.boot.web.servlet.DispatcherType;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix="spring.security")
/*     */ public class SecurityProperties
/*     */ {
/*     */   public static final int BASIC_AUTH_ORDER = 2147483642;
/*     */   public static final int IGNORED_ORDER = Integer.MIN_VALUE;
/*     */   public static final int DEFAULT_FILTER_ORDER = -100;
/*  64 */   private final Filter filter = new Filter();
/*     */   
/*  66 */   private final User user = new User();
/*     */   
/*     */   public User getUser() {
/*  69 */     return this.user;
/*     */   }
/*     */   
/*     */   public Filter getFilter() {
/*  73 */     return this.filter;
/*     */   }
/*     */   
/*     */   public static class Filter
/*     */   {
/*     */     private int order;
/*     */     
/*     */     public Filter() {
/*  81 */       this.order = -100;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  86 */     private Set<DispatcherType> dispatcherTypes = new HashSet(
/*  87 */       Arrays.asList(new DispatcherType[] { DispatcherType.ASYNC, DispatcherType.ERROR, DispatcherType.REQUEST }));
/*     */     
/*     */     public int getOrder() {
/*  90 */       return this.order;
/*     */     }
/*     */     
/*     */     public void setOrder(int order) {
/*  94 */       this.order = order;
/*     */     }
/*     */     
/*     */     public Set<DispatcherType> getDispatcherTypes() {
/*  98 */       return this.dispatcherTypes;
/*     */     }
/*     */     
/*     */     public void setDispatcherTypes(Set<DispatcherType> dispatcherTypes) {
/* 102 */       this.dispatcherTypes = dispatcherTypes;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class User
/*     */   {
/* 112 */     private String name = "user";
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 117 */     private String password = UUID.randomUUID().toString();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 122 */     private List<String> roles = new ArrayList();
/*     */     
/* 124 */     private boolean passwordGenerated = true;
/*     */     
/*     */     public String getName() {
/* 127 */       return this.name;
/*     */     }
/*     */     
/*     */     public void setName(String name) {
/* 131 */       this.name = name;
/*     */     }
/*     */     
/*     */     public String getPassword() {
/* 135 */       return this.password;
/*     */     }
/*     */     
/*     */     public void setPassword(String password) {
/* 139 */       if (!StringUtils.hasLength(password)) {
/* 140 */         return;
/*     */       }
/* 142 */       this.passwordGenerated = false;
/* 143 */       this.password = password;
/*     */     }
/*     */     
/*     */     public List<String> getRoles() {
/* 147 */       return this.roles;
/*     */     }
/*     */     
/*     */     public void setRoles(List<String> roles) {
/* 151 */       this.roles = new ArrayList(roles);
/*     */     }
/*     */     
/*     */     public boolean isPasswordGenerated() {
/* 155 */       return this.passwordGenerated;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\security\SecurityProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */