/*     */ package org.springframework.boot.autoconfigure.jms.activemq;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.Stream;
/*     */ import javax.jms.ConnectionFactory;
/*     */ import org.apache.activemq.ActiveMQConnectionFactory;
/*     */ import org.apache.commons.pool2.PooledObject;
/*     */ import org.messaginghub.pooled.jms.JmsPoolConnectionFactory;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*     */ import org.springframework.boot.autoconfigure.jms.JmsPoolConnectionFactoryFactory;
/*     */ import org.springframework.boot.autoconfigure.jms.JmsProperties;
/*     */ import org.springframework.boot.autoconfigure.jms.JmsProperties.Cache;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.jms.connection.CachingConnectionFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods=false)
/*     */ @ConditionalOnMissingBean({ConnectionFactory.class})
/*     */ class ActiveMQConnectionFactoryConfiguration
/*     */ {
/*     */   @Configuration(proxyBeanMethods=false)
/*     */   @ConditionalOnProperty(prefix="spring.activemq.pool", name={"enabled"}, havingValue="false", matchIfMissing=true)
/*     */   static class SimpleConnectionFactoryConfiguration
/*     */   {
/*     */     @Bean
/*     */     @ConditionalOnProperty(prefix="spring.jms.cache", name={"enabled"}, havingValue="false")
/*     */     ActiveMQConnectionFactory jmsConnectionFactory(ActiveMQProperties properties, ObjectProvider<ActiveMQConnectionFactoryCustomizer> factoryCustomizers)
/*     */     {
/*  59 */       return createJmsConnectionFactory(properties, factoryCustomizers);
/*     */     }
/*     */     
/*     */     private static ActiveMQConnectionFactory createJmsConnectionFactory(ActiveMQProperties properties, ObjectProvider<ActiveMQConnectionFactoryCustomizer> factoryCustomizers)
/*     */     {
/*  64 */       return 
/*     */       
/*  66 */         new ActiveMQConnectionFactoryFactory(properties, (List)factoryCustomizers.orderedStream().collect(Collectors.toList())).createConnectionFactory(ActiveMQConnectionFactory.class);
/*     */     }
/*     */     
/*     */ 
/*     */     @Configuration(proxyBeanMethods=false)
/*     */     @ConditionalOnClass({CachingConnectionFactory.class})
/*     */     @ConditionalOnProperty(prefix="spring.jms.cache", name={"enabled"}, havingValue="true", matchIfMissing=true)
/*     */     static class CachingConnectionFactoryConfiguration
/*     */     {
/*     */       @Bean
/*     */       CachingConnectionFactory jmsConnectionFactory(JmsProperties jmsProperties, ActiveMQProperties properties, ObjectProvider<ActiveMQConnectionFactoryCustomizer> factoryCustomizers)
/*     */       {
/*  78 */         JmsProperties.Cache cacheProperties = jmsProperties.getCache();
/*     */         
/*  80 */         CachingConnectionFactory connectionFactory = new CachingConnectionFactory(ActiveMQConnectionFactoryConfiguration.SimpleConnectionFactoryConfiguration.createJmsConnectionFactory(properties, factoryCustomizers));
/*  81 */         connectionFactory.setCacheConsumers(cacheProperties.isConsumers());
/*  82 */         connectionFactory.setCacheProducers(cacheProperties.isProducers());
/*  83 */         connectionFactory.setSessionCacheSize(cacheProperties.getSessionCacheSize());
/*  84 */         return connectionFactory;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Configuration(proxyBeanMethods=false)
/*     */   @ConditionalOnClass({JmsPoolConnectionFactory.class, PooledObject.class})
/*     */   static class PooledConnectionFactoryConfiguration
/*     */   {
/*     */     @Bean(destroyMethod="stop")
/*     */     @ConditionalOnProperty(prefix="spring.activemq.pool", name={"enabled"}, havingValue="true")
/*     */     JmsPoolConnectionFactory jmsConnectionFactory(ActiveMQProperties properties, ObjectProvider<ActiveMQConnectionFactoryCustomizer> factoryCustomizers)
/*     */     {
/* 101 */       ActiveMQConnectionFactory connectionFactory = new ActiveMQConnectionFactoryFactory(properties, (List)factoryCustomizers.orderedStream().collect(Collectors.toList())).createConnectionFactory(ActiveMQConnectionFactory.class);
/* 102 */       return new JmsPoolConnectionFactoryFactory(properties.getPool())
/* 103 */         .createPooledConnectionFactory(connectionFactory);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\jms\activemq\ActiveMQConnectionFactoryConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */