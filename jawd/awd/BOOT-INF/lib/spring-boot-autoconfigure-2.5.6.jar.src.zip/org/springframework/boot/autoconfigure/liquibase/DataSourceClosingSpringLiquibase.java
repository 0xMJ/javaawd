/*    */ package org.springframework.boot.autoconfigure.liquibase;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import liquibase.exception.LiquibaseException;
/*    */ import liquibase.integration.spring.SpringLiquibase;
/*    */ import org.springframework.beans.factory.DisposableBean;
/*    */ import org.springframework.util.ReflectionUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DataSourceClosingSpringLiquibase
/*    */   extends SpringLiquibase
/*    */   implements DisposableBean
/*    */ {
/* 38 */   private volatile boolean closeDataSourceOnceMigrated = true;
/*    */   
/*    */   public void setCloseDataSourceOnceMigrated(boolean closeDataSourceOnceMigrated) {
/* 41 */     this.closeDataSourceOnceMigrated = closeDataSourceOnceMigrated;
/*    */   }
/*    */   
/*    */   public void afterPropertiesSet() throws LiquibaseException
/*    */   {
/* 46 */     super.afterPropertiesSet();
/* 47 */     if (this.closeDataSourceOnceMigrated) {
/* 48 */       closeDataSource();
/*    */     }
/*    */   }
/*    */   
/*    */   private void closeDataSource() {
/* 53 */     Class<?> dataSourceClass = getDataSource().getClass();
/* 54 */     Method closeMethod = ReflectionUtils.findMethod(dataSourceClass, "close");
/* 55 */     if (closeMethod != null) {
/* 56 */       ReflectionUtils.invokeMethod(closeMethod, getDataSource());
/*    */     }
/*    */   }
/*    */   
/*    */   public void destroy() throws Exception
/*    */   {
/* 62 */     if (!this.closeDataSourceOnceMigrated) {
/* 63 */       closeDataSource();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\liquibase\DataSourceClosingSpringLiquibase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */