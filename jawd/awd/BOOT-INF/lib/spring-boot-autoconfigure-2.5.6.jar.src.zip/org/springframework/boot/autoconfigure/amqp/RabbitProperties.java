/*      */ package org.springframework.boot.autoconfigure.amqp;
/*      */ 
/*      */ import java.time.Duration;
/*      */ import java.time.temporal.ChronoUnit;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import java.util.Optional;
/*      */ import org.springframework.amqp.core.AcknowledgeMode;
/*      */ import org.springframework.amqp.rabbit.connection.AbstractConnectionFactory.AddressShuffleMode;
/*      */ import org.springframework.amqp.rabbit.connection.CachingConnectionFactory.CacheMode;
/*      */ import org.springframework.amqp.rabbit.connection.CachingConnectionFactory.ConfirmType;
/*      */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*      */ import org.springframework.boot.convert.DurationUnit;
/*      */ import org.springframework.util.CollectionUtils;
/*      */ import org.springframework.util.StringUtils;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @ConfigurationProperties(prefix="spring.rabbitmq")
/*      */ public class RabbitProperties
/*      */ {
/*      */   private static final int DEFAULT_PORT = 5672;
/*      */   private static final int DEFAULT_PORT_SECURE = 5671;
/*   57 */   private String host = "localhost";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Integer port;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*   68 */   private String username = "guest";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*   73 */   private String password = "guest";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*   78 */   private final Ssl ssl = new Ssl();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String virtualHost;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private String addresses;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*   94 */   private AbstractConnectionFactory.AddressShuffleMode addressShuffleMode = AbstractConnectionFactory.AddressShuffleMode.NONE;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @DurationUnit(ChronoUnit.SECONDS)
/*      */   private Duration requestedHeartbeat;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  106 */   private int requestedChannelMax = 2047;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean publisherReturns;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private CachingConnectionFactory.ConfirmType publisherConfirmType;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private Duration connectionTimeout;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  126 */   private Duration channelRpcTimeout = Duration.ofMinutes(10L);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  131 */   private final Cache cache = new Cache();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  136 */   private final Listener listener = new Listener();
/*      */   
/*  138 */   private final Template template = new Template();
/*      */   private List<Address> parsedAddresses;
/*      */   
/*      */   public String getHost()
/*      */   {
/*  143 */     return this.host;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String determineHost()
/*      */   {
/*  154 */     if (CollectionUtils.isEmpty(this.parsedAddresses)) {
/*  155 */       return getHost();
/*      */     }
/*  157 */     return ((Address)this.parsedAddresses.get(0)).host;
/*      */   }
/*      */   
/*      */   public void setHost(String host) {
/*  161 */     this.host = host;
/*      */   }
/*      */   
/*      */   public Integer getPort() {
/*  165 */     return this.port;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int determinePort()
/*      */   {
/*  176 */     if (CollectionUtils.isEmpty(this.parsedAddresses)) {
/*  177 */       Integer port = getPort();
/*  178 */       if (port != null) {
/*  179 */         return port.intValue();
/*      */       }
/*  181 */       return ((Boolean)Optional.ofNullable(getSsl().getEnabled()).orElse(Boolean.valueOf(false))).booleanValue() ? 5671 : 5672;
/*      */     }
/*  183 */     return ((Address)this.parsedAddresses.get(0)).port;
/*      */   }
/*      */   
/*      */   public void setPort(Integer port) {
/*  187 */     this.port = port;
/*      */   }
/*      */   
/*      */   public String getAddresses() {
/*  191 */     return this.addresses;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String determineAddresses()
/*      */   {
/*  200 */     if (CollectionUtils.isEmpty(this.parsedAddresses)) {
/*  201 */       return this.host + ":" + determinePort();
/*      */     }
/*  203 */     List<String> addressStrings = new ArrayList();
/*  204 */     for (Address parsedAddress : this.parsedAddresses) {
/*  205 */       addressStrings.add(parsedAddress.host + ":" + parsedAddress.port);
/*      */     }
/*  207 */     return StringUtils.collectionToCommaDelimitedString(addressStrings);
/*      */   }
/*      */   
/*      */   public void setAddresses(String addresses) {
/*  211 */     this.addresses = addresses;
/*  212 */     this.parsedAddresses = parseAddresses(addresses);
/*      */   }
/*      */   
/*      */   private List<Address> parseAddresses(String addresses) {
/*  216 */     List<Address> parsedAddresses = new ArrayList();
/*  217 */     for (String address : StringUtils.commaDelimitedListToStringArray(addresses)) {
/*  218 */       parsedAddresses.add(new Address(address, ((Boolean)Optional.ofNullable(getSsl().getEnabled()).orElse(Boolean.valueOf(false))).booleanValue(), null));
/*      */     }
/*  220 */     return parsedAddresses;
/*      */   }
/*      */   
/*      */   public String getUsername() {
/*  224 */     return this.username;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String determineUsername()
/*      */   {
/*  235 */     if (CollectionUtils.isEmpty(this.parsedAddresses)) {
/*  236 */       return this.username;
/*      */     }
/*  238 */     Address address = (Address)this.parsedAddresses.get(0);
/*  239 */     return address.username != null ? address.username : this.username;
/*      */   }
/*      */   
/*      */   public void setUsername(String username) {
/*  243 */     this.username = username;
/*      */   }
/*      */   
/*      */   public String getPassword() {
/*  247 */     return this.password;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String determinePassword()
/*      */   {
/*  258 */     if (CollectionUtils.isEmpty(this.parsedAddresses)) {
/*  259 */       return getPassword();
/*      */     }
/*  261 */     Address address = (Address)this.parsedAddresses.get(0);
/*  262 */     return address.password != null ? address.password : getPassword();
/*      */   }
/*      */   
/*      */   public void setPassword(String password) {
/*  266 */     this.password = password;
/*      */   }
/*      */   
/*      */   public Ssl getSsl() {
/*  270 */     return this.ssl;
/*      */   }
/*      */   
/*      */   public String getVirtualHost() {
/*  274 */     return this.virtualHost;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String determineVirtualHost()
/*      */   {
/*  285 */     if (CollectionUtils.isEmpty(this.parsedAddresses)) {
/*  286 */       return getVirtualHost();
/*      */     }
/*  288 */     Address address = (Address)this.parsedAddresses.get(0);
/*  289 */     return address.virtualHost != null ? address.virtualHost : getVirtualHost();
/*      */   }
/*      */   
/*      */   public void setVirtualHost(String virtualHost) {
/*  293 */     this.virtualHost = (StringUtils.hasText(virtualHost) ? virtualHost : "/");
/*      */   }
/*      */   
/*      */   public AbstractConnectionFactory.AddressShuffleMode getAddressShuffleMode() {
/*  297 */     return this.addressShuffleMode;
/*      */   }
/*      */   
/*      */   public void setAddressShuffleMode(AbstractConnectionFactory.AddressShuffleMode addressShuffleMode) {
/*  301 */     this.addressShuffleMode = addressShuffleMode;
/*      */   }
/*      */   
/*      */   public Duration getRequestedHeartbeat() {
/*  305 */     return this.requestedHeartbeat;
/*      */   }
/*      */   
/*      */   public void setRequestedHeartbeat(Duration requestedHeartbeat) {
/*  309 */     this.requestedHeartbeat = requestedHeartbeat;
/*      */   }
/*      */   
/*      */   public int getRequestedChannelMax() {
/*  313 */     return this.requestedChannelMax;
/*      */   }
/*      */   
/*      */   public void setRequestedChannelMax(int requestedChannelMax) {
/*  317 */     this.requestedChannelMax = requestedChannelMax;
/*      */   }
/*      */   
/*      */   public boolean isPublisherReturns() {
/*  321 */     return this.publisherReturns;
/*      */   }
/*      */   
/*      */   public void setPublisherReturns(boolean publisherReturns) {
/*  325 */     this.publisherReturns = publisherReturns;
/*      */   }
/*      */   
/*      */   public Duration getConnectionTimeout() {
/*  329 */     return this.connectionTimeout;
/*      */   }
/*      */   
/*      */   public void setPublisherConfirmType(CachingConnectionFactory.ConfirmType publisherConfirmType) {
/*  333 */     this.publisherConfirmType = publisherConfirmType;
/*      */   }
/*      */   
/*      */   public CachingConnectionFactory.ConfirmType getPublisherConfirmType() {
/*  337 */     return this.publisherConfirmType;
/*      */   }
/*      */   
/*      */   public void setConnectionTimeout(Duration connectionTimeout) {
/*  341 */     this.connectionTimeout = connectionTimeout;
/*      */   }
/*      */   
/*      */   public Duration getChannelRpcTimeout() {
/*  345 */     return this.channelRpcTimeout;
/*      */   }
/*      */   
/*      */   public void setChannelRpcTimeout(Duration channelRpcTimeout) {
/*  349 */     this.channelRpcTimeout = channelRpcTimeout;
/*      */   }
/*      */   
/*      */   public Cache getCache() {
/*  353 */     return this.cache;
/*      */   }
/*      */   
/*      */   public Listener getListener() {
/*  357 */     return this.listener;
/*      */   }
/*      */   
/*      */   public Template getTemplate() {
/*  361 */     return this.template;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public class Ssl
/*      */   {
/*      */     private static final String SUN_X509 = "SunX509";
/*      */     
/*      */ 
/*      */     private Boolean enabled;
/*      */     
/*      */ 
/*      */     private String keyStore;
/*      */     
/*      */ 
/*      */ 
/*      */     public Ssl() {}
/*      */     
/*      */ 
/*      */ 
/*  382 */     private String keyStoreType = "PKCS12";
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private String keyStorePassword;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  392 */     private String keyStoreAlgorithm = "SunX509";
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private String trustStore;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  402 */     private String trustStoreType = "JKS";
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private String trustStorePassword;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  412 */     private String trustStoreAlgorithm = "SunX509";
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private String algorithm;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  422 */     private boolean validateServerCertificate = true;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  427 */     private boolean verifyHostname = true;
/*      */     
/*      */     public Boolean getEnabled() {
/*  430 */       return this.enabled;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public boolean determineEnabled()
/*      */     {
/*  441 */       boolean defaultEnabled = ((Boolean)Optional.ofNullable(getEnabled()).orElse(Boolean.valueOf(false))).booleanValue();
/*  442 */       if (CollectionUtils.isEmpty(RabbitProperties.this.parsedAddresses)) {
/*  443 */         return defaultEnabled;
/*      */       }
/*  445 */       RabbitProperties.Address address = (RabbitProperties.Address)RabbitProperties.this.parsedAddresses.get(0);
/*  446 */       return address.determineSslEnabled(defaultEnabled);
/*      */     }
/*      */     
/*      */     public void setEnabled(Boolean enabled) {
/*  450 */       this.enabled = enabled;
/*      */     }
/*      */     
/*      */     public String getKeyStore() {
/*  454 */       return this.keyStore;
/*      */     }
/*      */     
/*      */     public void setKeyStore(String keyStore) {
/*  458 */       this.keyStore = keyStore;
/*      */     }
/*      */     
/*      */     public String getKeyStoreType() {
/*  462 */       return this.keyStoreType;
/*      */     }
/*      */     
/*      */     public void setKeyStoreType(String keyStoreType) {
/*  466 */       this.keyStoreType = keyStoreType;
/*      */     }
/*      */     
/*      */     public String getKeyStorePassword() {
/*  470 */       return this.keyStorePassword;
/*      */     }
/*      */     
/*      */     public void setKeyStorePassword(String keyStorePassword) {
/*  474 */       this.keyStorePassword = keyStorePassword;
/*      */     }
/*      */     
/*      */     public String getKeyStoreAlgorithm() {
/*  478 */       return this.keyStoreAlgorithm;
/*      */     }
/*      */     
/*      */     public void setKeyStoreAlgorithm(String keyStoreAlgorithm) {
/*  482 */       this.keyStoreAlgorithm = keyStoreAlgorithm;
/*      */     }
/*      */     
/*      */     public String getTrustStore() {
/*  486 */       return this.trustStore;
/*      */     }
/*      */     
/*      */     public void setTrustStore(String trustStore) {
/*  490 */       this.trustStore = trustStore;
/*      */     }
/*      */     
/*      */     public String getTrustStoreType() {
/*  494 */       return this.trustStoreType;
/*      */     }
/*      */     
/*      */     public void setTrustStoreType(String trustStoreType) {
/*  498 */       this.trustStoreType = trustStoreType;
/*      */     }
/*      */     
/*      */     public String getTrustStorePassword() {
/*  502 */       return this.trustStorePassword;
/*      */     }
/*      */     
/*      */     public void setTrustStorePassword(String trustStorePassword) {
/*  506 */       this.trustStorePassword = trustStorePassword;
/*      */     }
/*      */     
/*      */     public String getTrustStoreAlgorithm() {
/*  510 */       return this.trustStoreAlgorithm;
/*      */     }
/*      */     
/*      */     public void setTrustStoreAlgorithm(String trustStoreAlgorithm) {
/*  514 */       this.trustStoreAlgorithm = trustStoreAlgorithm;
/*      */     }
/*      */     
/*      */     public String getAlgorithm() {
/*  518 */       return this.algorithm;
/*      */     }
/*      */     
/*      */     public void setAlgorithm(String sslAlgorithm) {
/*  522 */       this.algorithm = sslAlgorithm;
/*      */     }
/*      */     
/*      */     public boolean isValidateServerCertificate() {
/*  526 */       return this.validateServerCertificate;
/*      */     }
/*      */     
/*      */     public void setValidateServerCertificate(boolean validateServerCertificate) {
/*  530 */       this.validateServerCertificate = validateServerCertificate;
/*      */     }
/*      */     
/*      */     public boolean getVerifyHostname() {
/*  534 */       return this.verifyHostname;
/*      */     }
/*      */     
/*      */     public void setVerifyHostname(boolean verifyHostname) {
/*  538 */       this.verifyHostname = verifyHostname;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static class Cache
/*      */   {
/*  545 */     private final Channel channel = new Channel();
/*      */     
/*  547 */     private final Connection connection = new Connection();
/*      */     
/*      */     public Channel getChannel() {
/*  550 */       return this.channel;
/*      */     }
/*      */     
/*      */     public Connection getConnection() {
/*  554 */       return this.connection;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public static class Channel
/*      */     {
/*      */       private Integer size;
/*      */       
/*      */ 
/*      */ 
/*      */       private Duration checkoutTimeout;
/*      */       
/*      */ 
/*      */ 
/*      */       public Integer getSize()
/*      */       {
/*  572 */         return this.size;
/*      */       }
/*      */       
/*      */       public void setSize(Integer size) {
/*  576 */         this.size = size;
/*      */       }
/*      */       
/*      */       public Duration getCheckoutTimeout() {
/*  580 */         return this.checkoutTimeout;
/*      */       }
/*      */       
/*      */       public void setCheckoutTimeout(Duration checkoutTimeout) {
/*  584 */         this.checkoutTimeout = checkoutTimeout;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public static class Connection
/*      */     {
/*  594 */       private CachingConnectionFactory.CacheMode mode = CachingConnectionFactory.CacheMode.CHANNEL;
/*      */       
/*      */ 
/*      */       private Integer size;
/*      */       
/*      */ 
/*      */       public CachingConnectionFactory.CacheMode getMode()
/*      */       {
/*  602 */         return this.mode;
/*      */       }
/*      */       
/*      */       public void setMode(CachingConnectionFactory.CacheMode mode) {
/*  606 */         this.mode = mode;
/*      */       }
/*      */       
/*      */       public Integer getSize() {
/*  610 */         return this.size;
/*      */       }
/*      */       
/*      */       public void setSize(Integer size) {
/*  614 */         this.size = size;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static enum ContainerType
/*      */   {
/*  626 */     SIMPLE, 
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  632 */     DIRECT;
/*      */     
/*      */ 
/*      */     private ContainerType() {}
/*      */   }
/*      */   
/*      */ 
/*      */   public static class Listener
/*      */   {
/*  641 */     private RabbitProperties.ContainerType type = RabbitProperties.ContainerType.SIMPLE;
/*      */     
/*  643 */     private final RabbitProperties.SimpleContainer simple = new RabbitProperties.SimpleContainer();
/*      */     
/*  645 */     private final RabbitProperties.DirectContainer direct = new RabbitProperties.DirectContainer();
/*      */     
/*      */     public RabbitProperties.ContainerType getType() {
/*  648 */       return this.type;
/*      */     }
/*      */     
/*      */     public void setType(RabbitProperties.ContainerType containerType) {
/*  652 */       this.type = containerType;
/*      */     }
/*      */     
/*      */     public RabbitProperties.SimpleContainer getSimple() {
/*  656 */       return this.simple;
/*      */     }
/*      */     
/*      */     public RabbitProperties.DirectContainer getDirect() {
/*  660 */       return this.direct;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static abstract class AmqpContainer
/*      */   {
/*  670 */     private boolean autoStartup = true;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private AcknowledgeMode acknowledgeMode;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private Integer prefetch;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private Boolean defaultRequeueRejected;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private Duration idleEventInterval;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  697 */     private boolean deBatchingEnabled = true;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  702 */     private final RabbitProperties.ListenerRetry retry = new RabbitProperties.ListenerRetry();
/*      */     
/*      */     public boolean isAutoStartup() {
/*  705 */       return this.autoStartup;
/*      */     }
/*      */     
/*      */     public void setAutoStartup(boolean autoStartup) {
/*  709 */       this.autoStartup = autoStartup;
/*      */     }
/*      */     
/*      */     public AcknowledgeMode getAcknowledgeMode() {
/*  713 */       return this.acknowledgeMode;
/*      */     }
/*      */     
/*      */     public void setAcknowledgeMode(AcknowledgeMode acknowledgeMode) {
/*  717 */       this.acknowledgeMode = acknowledgeMode;
/*      */     }
/*      */     
/*      */     public Integer getPrefetch() {
/*  721 */       return this.prefetch;
/*      */     }
/*      */     
/*      */     public void setPrefetch(Integer prefetch) {
/*  725 */       this.prefetch = prefetch;
/*      */     }
/*      */     
/*      */     public Boolean getDefaultRequeueRejected() {
/*  729 */       return this.defaultRequeueRejected;
/*      */     }
/*      */     
/*      */     public void setDefaultRequeueRejected(Boolean defaultRequeueRejected) {
/*  733 */       this.defaultRequeueRejected = defaultRequeueRejected;
/*      */     }
/*      */     
/*      */     public Duration getIdleEventInterval() {
/*  737 */       return this.idleEventInterval;
/*      */     }
/*      */     
/*      */     public void setIdleEventInterval(Duration idleEventInterval) {
/*  741 */       this.idleEventInterval = idleEventInterval;
/*      */     }
/*      */     
/*      */     public abstract boolean isMissingQueuesFatal();
/*      */     
/*      */     public boolean isDeBatchingEnabled() {
/*  747 */       return this.deBatchingEnabled;
/*      */     }
/*      */     
/*      */     public void setDeBatchingEnabled(boolean deBatchingEnabled) {
/*  751 */       this.deBatchingEnabled = deBatchingEnabled;
/*      */     }
/*      */     
/*      */     public RabbitProperties.ListenerRetry getRetry() {
/*  755 */       return this.retry;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static class SimpleContainer
/*      */     extends RabbitProperties.AmqpContainer
/*      */   {
/*      */     private Integer concurrency;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private Integer maxConcurrency;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private Integer batchSize;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  786 */     private boolean missingQueuesFatal = true;
/*      */     
/*      */ 
/*      */ 
/*      */     private boolean consumerBatchEnabled;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public Integer getConcurrency()
/*      */     {
/*  797 */       return this.concurrency;
/*      */     }
/*      */     
/*      */     public void setConcurrency(Integer concurrency) {
/*  801 */       this.concurrency = concurrency;
/*      */     }
/*      */     
/*      */     public Integer getMaxConcurrency() {
/*  805 */       return this.maxConcurrency;
/*      */     }
/*      */     
/*      */     public void setMaxConcurrency(Integer maxConcurrency) {
/*  809 */       this.maxConcurrency = maxConcurrency;
/*      */     }
/*      */     
/*      */     public Integer getBatchSize() {
/*  813 */       return this.batchSize;
/*      */     }
/*      */     
/*      */     public void setBatchSize(Integer batchSize) {
/*  817 */       this.batchSize = batchSize;
/*      */     }
/*      */     
/*      */     public boolean isMissingQueuesFatal()
/*      */     {
/*  822 */       return this.missingQueuesFatal;
/*      */     }
/*      */     
/*      */     public void setMissingQueuesFatal(boolean missingQueuesFatal) {
/*  826 */       this.missingQueuesFatal = missingQueuesFatal;
/*      */     }
/*      */     
/*      */     public boolean isConsumerBatchEnabled() {
/*  830 */       return this.consumerBatchEnabled;
/*      */     }
/*      */     
/*      */     public void setConsumerBatchEnabled(boolean consumerBatchEnabled) {
/*  834 */       this.consumerBatchEnabled = consumerBatchEnabled;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static class DirectContainer
/*      */     extends RabbitProperties.AmqpContainer
/*      */   {
/*      */     private Integer consumersPerQueue;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  853 */     private boolean missingQueuesFatal = false;
/*      */     
/*      */     public Integer getConsumersPerQueue() {
/*  856 */       return this.consumersPerQueue;
/*      */     }
/*      */     
/*      */     public void setConsumersPerQueue(Integer consumersPerQueue) {
/*  860 */       this.consumersPerQueue = consumersPerQueue;
/*      */     }
/*      */     
/*      */     public boolean isMissingQueuesFatal()
/*      */     {
/*  865 */       return this.missingQueuesFatal;
/*      */     }
/*      */     
/*      */     public void setMissingQueuesFatal(boolean missingQueuesFatal) {
/*  869 */       this.missingQueuesFatal = missingQueuesFatal;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static class Template
/*      */   {
/*  876 */     private final RabbitProperties.Retry retry = new RabbitProperties.Retry();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private Boolean mandatory;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private Duration receiveTimeout;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private Duration replyTimeout;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  896 */     private String exchange = "";
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  901 */     private String routingKey = "";
/*      */     
/*      */ 
/*      */     private String defaultReceiveQueue;
/*      */     
/*      */ 
/*      */ 
/*      */     public RabbitProperties.Retry getRetry()
/*      */     {
/*  910 */       return this.retry;
/*      */     }
/*      */     
/*      */     public Boolean getMandatory() {
/*  914 */       return this.mandatory;
/*      */     }
/*      */     
/*      */     public void setMandatory(Boolean mandatory) {
/*  918 */       this.mandatory = mandatory;
/*      */     }
/*      */     
/*      */     public Duration getReceiveTimeout() {
/*  922 */       return this.receiveTimeout;
/*      */     }
/*      */     
/*      */     public void setReceiveTimeout(Duration receiveTimeout) {
/*  926 */       this.receiveTimeout = receiveTimeout;
/*      */     }
/*      */     
/*      */     public Duration getReplyTimeout() {
/*  930 */       return this.replyTimeout;
/*      */     }
/*      */     
/*      */     public void setReplyTimeout(Duration replyTimeout) {
/*  934 */       this.replyTimeout = replyTimeout;
/*      */     }
/*      */     
/*      */     public String getExchange() {
/*  938 */       return this.exchange;
/*      */     }
/*      */     
/*      */     public void setExchange(String exchange) {
/*  942 */       this.exchange = exchange;
/*      */     }
/*      */     
/*      */     public String getRoutingKey() {
/*  946 */       return this.routingKey;
/*      */     }
/*      */     
/*      */     public void setRoutingKey(String routingKey) {
/*  950 */       this.routingKey = routingKey;
/*      */     }
/*      */     
/*      */     public String getDefaultReceiveQueue() {
/*  954 */       return this.defaultReceiveQueue;
/*      */     }
/*      */     
/*      */     public void setDefaultReceiveQueue(String defaultReceiveQueue) {
/*  958 */       this.defaultReceiveQueue = defaultReceiveQueue;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static class Retry
/*      */   {
/*      */     private boolean enabled;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  973 */     private int maxAttempts = 3;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  978 */     private Duration initialInterval = Duration.ofMillis(1000L);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  983 */     private double multiplier = 1.0D;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  988 */     private Duration maxInterval = Duration.ofMillis(10000L);
/*      */     
/*      */     public boolean isEnabled() {
/*  991 */       return this.enabled;
/*      */     }
/*      */     
/*      */     public void setEnabled(boolean enabled) {
/*  995 */       this.enabled = enabled;
/*      */     }
/*      */     
/*      */     public int getMaxAttempts() {
/*  999 */       return this.maxAttempts;
/*      */     }
/*      */     
/*      */     public void setMaxAttempts(int maxAttempts) {
/* 1003 */       this.maxAttempts = maxAttempts;
/*      */     }
/*      */     
/*      */     public Duration getInitialInterval() {
/* 1007 */       return this.initialInterval;
/*      */     }
/*      */     
/*      */     public void setInitialInterval(Duration initialInterval) {
/* 1011 */       this.initialInterval = initialInterval;
/*      */     }
/*      */     
/*      */     public double getMultiplier() {
/* 1015 */       return this.multiplier;
/*      */     }
/*      */     
/*      */     public void setMultiplier(double multiplier) {
/* 1019 */       this.multiplier = multiplier;
/*      */     }
/*      */     
/*      */     public Duration getMaxInterval() {
/* 1023 */       return this.maxInterval;
/*      */     }
/*      */     
/*      */     public void setMaxInterval(Duration maxInterval) {
/* 1027 */       this.maxInterval = maxInterval;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static class ListenerRetry
/*      */     extends RabbitProperties.Retry
/*      */   {
/* 1037 */     private boolean stateless = true;
/*      */     
/*      */     public boolean isStateless() {
/* 1040 */       return this.stateless;
/*      */     }
/*      */     
/*      */     public void setStateless(boolean stateless) {
/* 1044 */       this.stateless = stateless;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private static final class Address
/*      */   {
/*      */     private static final String PREFIX_AMQP = "amqp://";
/*      */     
/*      */     private static final String PREFIX_AMQP_SECURE = "amqps://";
/*      */     
/*      */     private String host;
/*      */     
/*      */     private int port;
/*      */     
/*      */     private String username;
/*      */     
/*      */     private String password;
/*      */     
/*      */     private String virtualHost;
/*      */     private Boolean secureConnection;
/*      */     
/*      */     private Address(String input, boolean sslEnabled)
/*      */     {
/* 1068 */       input = input.trim();
/* 1069 */       input = trimPrefix(input);
/* 1070 */       input = parseUsernameAndPassword(input);
/* 1071 */       input = parseVirtualHost(input);
/* 1072 */       parseHostAndPort(input, sslEnabled);
/*      */     }
/*      */     
/*      */     private String trimPrefix(String input) {
/* 1076 */       if (input.startsWith("amqps://")) {
/* 1077 */         this.secureConnection = Boolean.valueOf(true);
/* 1078 */         return input.substring("amqps://".length());
/*      */       }
/* 1080 */       if (input.startsWith("amqp://")) {
/* 1081 */         this.secureConnection = Boolean.valueOf(false);
/* 1082 */         return input.substring("amqp://".length());
/*      */       }
/* 1084 */       return input;
/*      */     }
/*      */     
/*      */     private String parseUsernameAndPassword(String input) {
/* 1088 */       if (input.contains("@")) {
/* 1089 */         String[] split = StringUtils.split(input, "@");
/* 1090 */         String creds = split[0];
/* 1091 */         input = split[1];
/* 1092 */         split = StringUtils.split(creds, ":");
/* 1093 */         this.username = split[0];
/* 1094 */         if (split.length > 0) {
/* 1095 */           this.password = split[1];
/*      */         }
/*      */       }
/* 1098 */       return input;
/*      */     }
/*      */     
/*      */     private String parseVirtualHost(String input) {
/* 1102 */       int hostIndex = input.indexOf('/');
/* 1103 */       if (hostIndex >= 0) {
/* 1104 */         this.virtualHost = input.substring(hostIndex + 1);
/* 1105 */         if (this.virtualHost.isEmpty()) {
/* 1106 */           this.virtualHost = "/";
/*      */         }
/* 1108 */         input = input.substring(0, hostIndex);
/*      */       }
/* 1110 */       return input;
/*      */     }
/*      */     
/*      */     private void parseHostAndPort(String input, boolean sslEnabled) {
/* 1114 */       int bracketIndex = input.lastIndexOf(']');
/* 1115 */       int colonIndex = input.lastIndexOf(':');
/* 1116 */       if ((colonIndex == -1) || (colonIndex < bracketIndex)) {
/* 1117 */         this.host = input;
/* 1118 */         this.port = (determineSslEnabled(sslEnabled) ? 5671 : 5672);
/*      */       }
/*      */       else {
/* 1121 */         this.host = input.substring(0, colonIndex);
/* 1122 */         this.port = Integer.parseInt(input.substring(colonIndex + 1));
/*      */       }
/*      */     }
/*      */     
/*      */     private boolean determineSslEnabled(boolean sslEnabled) {
/* 1127 */       return this.secureConnection != null ? this.secureConnection.booleanValue() : sslEnabled;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\amqp\RabbitProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */