/*    */ package org.springframework.boot.autoconfigure.template;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.springframework.boot.context.properties.bind.Binder;
/*    */ import org.springframework.core.env.Environment;
/*    */ import org.springframework.core.io.Resource;
/*    */ import org.springframework.core.io.ResourceLoader;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class PathBasedTemplateAvailabilityProvider
/*    */   implements TemplateAvailabilityProvider
/*    */ {
/*    */   private final String className;
/*    */   private final Class<TemplateAvailabilityProperties> propertiesClass;
/*    */   private final String propertyPrefix;
/*    */   
/*    */   public PathBasedTemplateAvailabilityProvider(String className, Class<? extends TemplateAvailabilityProperties> propertiesClass, String propertyPrefix)
/*    */   {
/* 46 */     this.className = className;
/* 47 */     this.propertiesClass = propertiesClass;
/* 48 */     this.propertyPrefix = propertyPrefix;
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean isTemplateAvailable(String view, Environment environment, ClassLoader classLoader, ResourceLoader resourceLoader)
/*    */   {
/* 54 */     if (ClassUtils.isPresent(this.className, classLoader)) {
/* 55 */       Binder binder = Binder.get(environment);
/* 56 */       TemplateAvailabilityProperties properties = (TemplateAvailabilityProperties)binder.bindOrCreate(this.propertyPrefix, this.propertiesClass);
/* 57 */       return isTemplateAvailable(view, resourceLoader, properties);
/*    */     }
/* 59 */     return false;
/*    */   }
/*    */   
/*    */   private boolean isTemplateAvailable(String view, ResourceLoader resourceLoader, TemplateAvailabilityProperties properties)
/*    */   {
/* 64 */     String location = properties.getPrefix() + view + properties.getSuffix();
/* 65 */     for (String path : properties.getLoaderPath()) {
/* 66 */       if (resourceLoader.getResource(path + location).exists()) {
/* 67 */         return true;
/*    */       }
/*    */     }
/* 70 */     return false;
/*    */   }
/*    */   
/*    */   protected static abstract class TemplateAvailabilityProperties
/*    */   {
/*    */     private String prefix;
/*    */     private String suffix;
/*    */     
/*    */     protected TemplateAvailabilityProperties(String prefix, String suffix)
/*    */     {
/* 80 */       this.prefix = prefix;
/* 81 */       this.suffix = suffix;
/*    */     }
/*    */     
/*    */     protected abstract List<String> getLoaderPath();
/*    */     
/*    */     public String getPrefix() {
/* 87 */       return this.prefix;
/*    */     }
/*    */     
/*    */     public void setPrefix(String prefix) {
/* 91 */       this.prefix = prefix;
/*    */     }
/*    */     
/*    */     public String getSuffix() {
/* 95 */       return this.suffix;
/*    */     }
/*    */     
/*    */     public void setSuffix(String suffix) {
/* 99 */       this.suffix = suffix;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\template\PathBasedTemplateAvailabilityProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */