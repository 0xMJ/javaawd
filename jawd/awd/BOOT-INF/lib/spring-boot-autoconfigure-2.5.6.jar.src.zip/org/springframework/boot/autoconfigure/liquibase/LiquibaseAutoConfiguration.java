/*     */ package org.springframework.boot.autoconfigure.liquibase;
/*     */ 
/*     */ import javax.sql.DataSource;
/*     */ import liquibase.change.DatabaseChange;
/*     */ import liquibase.integration.spring.SpringLiquibase;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.boot.autoconfigure.AutoConfigureAfter;
/*     */ import org.springframework.boot.autoconfigure.condition.AnyNestedCondition;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*     */ import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
/*     */ import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.boot.jdbc.DataSourceBuilder;
/*     */ import org.springframework.boot.sql.init.dependency.DatabaseInitializationDependencyConfigurer;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Conditional;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.context.annotation.ConfigurationCondition.ConfigurationPhase;
/*     */ import org.springframework.context.annotation.Import;
/*     */ import org.springframework.jdbc.core.ConnectionCallback;
/*     */ import org.springframework.jdbc.datasource.SimpleDriverDataSource;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods=false)
/*     */ @ConditionalOnClass({SpringLiquibase.class, DatabaseChange.class})
/*     */ @ConditionalOnProperty(prefix="spring.liquibase", name={"enabled"}, matchIfMissing=true)
/*     */ @Conditional({LiquibaseDataSourceCondition.class})
/*     */ @AutoConfigureAfter({DataSourceAutoConfiguration.class, HibernateJpaAutoConfiguration.class})
/*     */ @Import({DatabaseInitializationDependencyConfigurer.class})
/*     */ public class LiquibaseAutoConfiguration
/*     */ {
/*     */   @Bean
/*     */   public LiquibaseSchemaManagementProvider liquibaseDefaultDdlModeProvider(ObjectProvider<SpringLiquibase> liquibases)
/*     */   {
/*  73 */     return new LiquibaseSchemaManagementProvider(liquibases);
/*     */   }
/*     */   
/*     */   @Configuration(proxyBeanMethods=false)
/*     */   @ConditionalOnClass({ConnectionCallback.class})
/*     */   @ConditionalOnMissingBean({SpringLiquibase.class})
/*     */   @EnableConfigurationProperties({LiquibaseProperties.class})
/*     */   public static class LiquibaseConfiguration
/*     */   {
/*     */     private final LiquibaseProperties properties;
/*     */     
/*     */     public LiquibaseConfiguration(LiquibaseProperties properties) {
/*  85 */       this.properties = properties;
/*     */     }
/*     */     
/*     */     @Bean
/*     */     public SpringLiquibase liquibase(ObjectProvider<DataSource> dataSource, @LiquibaseDataSource ObjectProvider<DataSource> liquibaseDataSource)
/*     */     {
/*  91 */       SpringLiquibase liquibase = createSpringLiquibase((DataSource)liquibaseDataSource.getIfAvailable(), 
/*  92 */         (DataSource)dataSource.getIfUnique());
/*  93 */       liquibase.setChangeLog(this.properties.getChangeLog());
/*  94 */       liquibase.setClearCheckSums(this.properties.isClearChecksums());
/*  95 */       liquibase.setContexts(this.properties.getContexts());
/*  96 */       liquibase.setDefaultSchema(this.properties.getDefaultSchema());
/*  97 */       liquibase.setLiquibaseSchema(this.properties.getLiquibaseSchema());
/*  98 */       liquibase.setLiquibaseTablespace(this.properties.getLiquibaseTablespace());
/*  99 */       liquibase.setDatabaseChangeLogTable(this.properties.getDatabaseChangeLogTable());
/* 100 */       liquibase.setDatabaseChangeLogLockTable(this.properties.getDatabaseChangeLogLockTable());
/* 101 */       liquibase.setDropFirst(this.properties.isDropFirst());
/* 102 */       liquibase.setShouldRun(this.properties.isEnabled());
/* 103 */       liquibase.setLabels(this.properties.getLabels());
/* 104 */       liquibase.setChangeLogParameters(this.properties.getParameters());
/* 105 */       liquibase.setRollbackFile(this.properties.getRollbackFile());
/* 106 */       liquibase.setTestRollbackOnUpdate(this.properties.isTestRollbackOnUpdate());
/* 107 */       liquibase.setTag(this.properties.getTag());
/* 108 */       return liquibase;
/*     */     }
/*     */     
/*     */     private SpringLiquibase createSpringLiquibase(DataSource liquibaseDataSource, DataSource dataSource) {
/* 112 */       LiquibaseProperties properties = this.properties;
/* 113 */       DataSource migrationDataSource = getMigrationDataSource(liquibaseDataSource, dataSource, properties);
/* 114 */       SpringLiquibase liquibase = (migrationDataSource == liquibaseDataSource) || (migrationDataSource == dataSource) ? new SpringLiquibase() : new DataSourceClosingSpringLiquibase();
/*     */       
/*     */ 
/* 117 */       liquibase.setDataSource(migrationDataSource);
/* 118 */       return liquibase;
/*     */     }
/*     */     
/*     */     private DataSource getMigrationDataSource(DataSource liquibaseDataSource, DataSource dataSource, LiquibaseProperties properties)
/*     */     {
/* 123 */       if (liquibaseDataSource != null) {
/* 124 */         return liquibaseDataSource;
/*     */       }
/* 126 */       if (properties.getUrl() != null) {
/* 127 */         DataSourceBuilder<?> builder = DataSourceBuilder.create().type(SimpleDriverDataSource.class);
/* 128 */         builder.url(properties.getUrl());
/* 129 */         applyCommonBuilderProperties(properties, builder);
/* 130 */         return builder.build();
/*     */       }
/* 132 */       if ((properties.getUser() != null) && (dataSource != null))
/*     */       {
/* 134 */         DataSourceBuilder<?> builder = DataSourceBuilder.derivedFrom(dataSource).type(SimpleDriverDataSource.class);
/* 135 */         applyCommonBuilderProperties(properties, builder);
/* 136 */         return builder.build();
/*     */       }
/* 138 */       Assert.state(dataSource != null, "Liquibase migration DataSource missing");
/* 139 */       return dataSource;
/*     */     }
/*     */     
/*     */     private void applyCommonBuilderProperties(LiquibaseProperties properties, DataSourceBuilder<?> builder) {
/* 143 */       builder.username(properties.getUser());
/* 144 */       builder.password(properties.getPassword());
/* 145 */       if (StringUtils.hasText(properties.getDriverClassName())) {
/* 146 */         builder.driverClassName(properties.getDriverClassName());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   static final class LiquibaseDataSourceCondition extends AnyNestedCondition
/*     */   {
/*     */     LiquibaseDataSourceCondition()
/*     */     {
/* 155 */       super();
/*     */     }
/*     */     
/*     */     @ConditionalOnProperty(prefix="spring.liquibase", name={"url"})
/*     */     private static final class LiquibaseUrlCondition {}
/*     */     
/*     */     @ConditionalOnBean({DataSource.class})
/*     */     private static final class DataSourceBeanCondition {}
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\liquibase\LiquibaseAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */