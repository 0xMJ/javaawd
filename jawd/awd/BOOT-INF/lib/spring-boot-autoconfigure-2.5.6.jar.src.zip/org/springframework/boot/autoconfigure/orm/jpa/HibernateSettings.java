/*    */ package org.springframework.boot.autoconfigure.orm.jpa;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.function.Supplier;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HibernateSettings
/*    */ {
/*    */   private Supplier<String> ddlAuto;
/*    */   private Collection<HibernatePropertiesCustomizer> hibernatePropertiesCustomizers;
/*    */   
/*    */   public HibernateSettings ddlAuto(Supplier<String> ddlAuto)
/*    */   {
/* 36 */     this.ddlAuto = ddlAuto;
/* 37 */     return this;
/*    */   }
/*    */   
/*    */   public String getDdlAuto() {
/* 41 */     return this.ddlAuto != null ? (String)this.ddlAuto.get() : null;
/*    */   }
/*    */   
/*    */   public HibernateSettings hibernatePropertiesCustomizers(Collection<HibernatePropertiesCustomizer> hibernatePropertiesCustomizers)
/*    */   {
/* 46 */     this.hibernatePropertiesCustomizers = new ArrayList(hibernatePropertiesCustomizers);
/* 47 */     return this;
/*    */   }
/*    */   
/*    */   public Collection<HibernatePropertiesCustomizer> getHibernatePropertiesCustomizers() {
/* 51 */     return this.hibernatePropertiesCustomizers;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\orm\jpa\HibernateSettings.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */