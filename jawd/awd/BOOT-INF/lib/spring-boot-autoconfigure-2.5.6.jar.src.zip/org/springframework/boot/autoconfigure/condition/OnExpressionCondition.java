/*    */ package org.springframework.boot.autoconfigure.condition;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.springframework.beans.factory.config.BeanExpressionContext;
/*    */ import org.springframework.beans.factory.config.BeanExpressionResolver;
/*    */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*    */ import org.springframework.context.annotation.ConditionContext;
/*    */ import org.springframework.context.expression.StandardBeanExpressionResolver;
/*    */ import org.springframework.core.annotation.Order;
/*    */ import org.springframework.core.env.Environment;
/*    */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Order(2147483627)
/*    */ class OnExpressionCondition
/*    */   extends SpringBootCondition
/*    */ {
/*    */   public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata)
/*    */   {
/* 41 */     String expression = (String)metadata.getAnnotationAttributes(ConditionalOnExpression.class.getName()).get("value");
/* 42 */     expression = wrapIfNecessary(expression);
/* 43 */     ConditionMessage.Builder messageBuilder = ConditionMessage.forCondition(ConditionalOnExpression.class, new Object[] { "(" + expression + ")" });
/*    */     
/* 45 */     expression = context.getEnvironment().resolvePlaceholders(expression);
/* 46 */     ConfigurableListableBeanFactory beanFactory = context.getBeanFactory();
/* 47 */     if (beanFactory != null) {
/* 48 */       boolean result = evaluateExpression(beanFactory, expression).booleanValue();
/* 49 */       return new ConditionOutcome(result, messageBuilder.resultedIn(Boolean.valueOf(result)));
/*    */     }
/* 51 */     return ConditionOutcome.noMatch(messageBuilder.because("no BeanFactory available."));
/*    */   }
/*    */   
/*    */   private Boolean evaluateExpression(ConfigurableListableBeanFactory beanFactory, String expression) {
/* 55 */     BeanExpressionResolver resolver = beanFactory.getBeanExpressionResolver();
/* 56 */     if (resolver == null) {
/* 57 */       resolver = new StandardBeanExpressionResolver();
/*    */     }
/* 59 */     BeanExpressionContext expressionContext = new BeanExpressionContext(beanFactory, null);
/* 60 */     Object result = resolver.evaluate(expression, expressionContext);
/* 61 */     return Boolean.valueOf((result != null) && (((Boolean)result).booleanValue()));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private String wrapIfNecessary(String expression)
/*    */   {
/* 70 */     if (!expression.startsWith("#{")) {
/* 71 */       return "#{" + expression + "}";
/*    */     }
/* 73 */     return expression;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\condition\OnExpressionCondition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */