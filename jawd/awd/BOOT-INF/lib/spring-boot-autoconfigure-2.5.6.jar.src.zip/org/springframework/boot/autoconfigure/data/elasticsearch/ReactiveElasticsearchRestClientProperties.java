/*     */ package org.springframework.boot.autoconfigure.data.elasticsearch;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.util.unit.DataSize;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix="spring.data.elasticsearch.client.reactive")
/*     */ public class ReactiveElasticsearchRestClientProperties
/*     */ {
/*  39 */   private List<String> endpoints = new ArrayList(Collections.singletonList("localhost:9200"));
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  44 */   private boolean useSsl = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String username;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String password;
/*     */   
/*     */ 
/*     */ 
/*     */   private Duration connectionTimeout;
/*     */   
/*     */ 
/*     */ 
/*     */   private Duration socketTimeout;
/*     */   
/*     */ 
/*     */ 
/*     */   private DataSize maxInMemorySize;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<String> getEndpoints()
/*     */   {
/*  73 */     return this.endpoints;
/*     */   }
/*     */   
/*     */   public void setEndpoints(List<String> endpoints) {
/*  77 */     this.endpoints = endpoints;
/*     */   }
/*     */   
/*     */   public boolean isUseSsl() {
/*  81 */     return this.useSsl;
/*     */   }
/*     */   
/*     */   public void setUseSsl(boolean useSsl) {
/*  85 */     this.useSsl = useSsl;
/*     */   }
/*     */   
/*     */   public String getUsername() {
/*  89 */     return this.username;
/*     */   }
/*     */   
/*     */   public void setUsername(String username) {
/*  93 */     this.username = username;
/*     */   }
/*     */   
/*     */   public String getPassword() {
/*  97 */     return this.password;
/*     */   }
/*     */   
/*     */   public void setPassword(String password) {
/* 101 */     this.password = password;
/*     */   }
/*     */   
/*     */   public Duration getConnectionTimeout() {
/* 105 */     return this.connectionTimeout;
/*     */   }
/*     */   
/*     */   public void setConnectionTimeout(Duration connectionTimeout) {
/* 109 */     this.connectionTimeout = connectionTimeout;
/*     */   }
/*     */   
/*     */   public Duration getSocketTimeout() {
/* 113 */     return this.socketTimeout;
/*     */   }
/*     */   
/*     */   public void setSocketTimeout(Duration socketTimeout) {
/* 117 */     this.socketTimeout = socketTimeout;
/*     */   }
/*     */   
/*     */   public DataSize getMaxInMemorySize() {
/* 121 */     return this.maxInMemorySize;
/*     */   }
/*     */   
/*     */   public void setMaxInMemorySize(DataSize maxInMemorySize) {
/* 125 */     this.maxInMemorySize = maxInMemorySize;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\data\elasticsearch\ReactiveElasticsearchRestClientProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */