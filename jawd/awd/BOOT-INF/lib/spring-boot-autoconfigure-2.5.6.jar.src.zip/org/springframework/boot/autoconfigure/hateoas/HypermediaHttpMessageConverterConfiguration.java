/*    */ package org.springframework.boot.autoconfigure.hateoas;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.springframework.beans.BeansException;
/*    */ import org.springframework.beans.factory.BeanFactory;
/*    */ import org.springframework.beans.factory.BeanFactoryAware;
/*    */ import org.springframework.beans.factory.InitializingBean;
/*    */ import org.springframework.beans.factory.ListableBeanFactory;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.hateoas.server.mvc.TypeConstrainedMappingJackson2HttpMessageConverter;
/*    */ import org.springframework.http.MediaType;
/*    */ import org.springframework.http.converter.AbstractHttpMessageConverter;
/*    */ import org.springframework.http.converter.HttpMessageConverter;
/*    */ import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerAdapter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ @Configuration(proxyBeanMethods=false)
/*    */ public class HypermediaHttpMessageConverterConfiguration
/*    */ {
/*    */   @Bean
/*    */   @ConditionalOnProperty(prefix="spring.hateoas", name={"use-hal-as-default-json-media-type"}, matchIfMissing=true)
/*    */   public static HalMessageConverterSupportedMediaTypesCustomizer halMessageConverterSupportedMediaTypeCustomizer()
/*    */   {
/* 56 */     return new HalMessageConverterSupportedMediaTypesCustomizer(null);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private static class HalMessageConverterSupportedMediaTypesCustomizer
/*    */     implements BeanFactoryAware, InitializingBean
/*    */   {
/*    */     private volatile BeanFactory beanFactory;
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */     public void afterPropertiesSet()
/*    */     {
/* 73 */       if ((this.beanFactory instanceof ListableBeanFactory)) {
/* 74 */         configureHttpMessageConverters(((ListableBeanFactory)this.beanFactory)
/* 75 */           .getBeansOfType(RequestMappingHandlerAdapter.class).values());
/*    */       }
/*    */     }
/*    */     
/*    */     private void configureHttpMessageConverters(Collection<RequestMappingHandlerAdapter> handlerAdapters) {
/* 80 */       for (RequestMappingHandlerAdapter handlerAdapter : handlerAdapters) {
/* 81 */         for (HttpMessageConverter<?> messageConverter : handlerAdapter.getMessageConverters()) {
/* 82 */           configureHttpMessageConverter(messageConverter);
/*    */         }
/*    */       }
/*    */     }
/*    */     
/*    */     private void configureHttpMessageConverter(HttpMessageConverter<?> converter) {
/* 88 */       if ((converter instanceof TypeConstrainedMappingJackson2HttpMessageConverter)) {
/* 89 */         List<MediaType> supportedMediaTypes = new ArrayList(converter.getSupportedMediaTypes());
/* 90 */         if (!supportedMediaTypes.contains(MediaType.APPLICATION_JSON)) {
/* 91 */           supportedMediaTypes.add(MediaType.APPLICATION_JSON);
/*    */         }
/* 93 */         ((AbstractHttpMessageConverter)converter).setSupportedMediaTypes(supportedMediaTypes);
/*    */       }
/*    */     }
/*    */     
/*    */     public void setBeanFactory(BeanFactory beanFactory) throws BeansException
/*    */     {
/* 99 */       this.beanFactory = beanFactory;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\hateoas\HypermediaHttpMessageConverterConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */