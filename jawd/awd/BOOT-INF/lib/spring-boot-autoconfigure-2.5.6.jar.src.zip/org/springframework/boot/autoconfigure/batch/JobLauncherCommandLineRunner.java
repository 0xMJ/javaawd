/*    */ package org.springframework.boot.autoconfigure.batch;
/*    */ 
/*    */ import org.springframework.batch.core.explore.JobExplorer;
/*    */ import org.springframework.batch.core.launch.JobLauncher;
/*    */ import org.springframework.batch.core.repository.JobRepository;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class JobLauncherCommandLineRunner
/*    */   extends JobLauncherApplicationRunner
/*    */ {
/*    */   public JobLauncherCommandLineRunner(JobLauncher jobLauncher, JobExplorer jobExplorer, JobRepository jobRepository)
/*    */   {
/* 47 */     super(jobLauncher, jobExplorer, jobRepository);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\batch\JobLauncherCommandLineRunner.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */