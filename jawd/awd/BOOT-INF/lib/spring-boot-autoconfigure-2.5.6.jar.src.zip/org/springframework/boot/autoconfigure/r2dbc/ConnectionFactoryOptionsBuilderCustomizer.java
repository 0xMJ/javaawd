package org.springframework.boot.autoconfigure.r2dbc;

import io.r2dbc.spi.ConnectionFactoryOptions.Builder;

@FunctionalInterface
public abstract interface ConnectionFactoryOptionsBuilderCustomizer
{
  public abstract void customize(ConnectionFactoryOptions.Builder paramBuilder);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\r2dbc\ConnectionFactoryOptionsBuilderCustomizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */