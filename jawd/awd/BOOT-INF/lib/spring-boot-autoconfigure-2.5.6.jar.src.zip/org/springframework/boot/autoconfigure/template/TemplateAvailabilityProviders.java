/*     */ package org.springframework.boot.autoconfigure.template;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.io.support.SpringFactoriesLoader;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TemplateAvailabilityProviders
/*     */ {
/*     */   private final List<TemplateAvailabilityProvider> providers;
/*     */   private static final int CACHE_LIMIT = 1024;
/*  47 */   private static final TemplateAvailabilityProvider NONE = new NoTemplateAvailabilityProvider(null);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  52 */   private final Map<String, TemplateAvailabilityProvider> resolved = new ConcurrentHashMap(1024);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  57 */   private final Map<String, TemplateAvailabilityProvider> cache = new LinkedHashMap(1024, 0.75F, true)
/*     */   {
/*     */ 
/*     */     protected boolean removeEldestEntry(Map.Entry<String, TemplateAvailabilityProvider> eldest)
/*     */     {
/*     */ 
/*  63 */       if (size() > 1024) {
/*  64 */         TemplateAvailabilityProviders.this.resolved.remove(eldest.getKey());
/*  65 */         return true;
/*     */       }
/*  67 */       return false;
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TemplateAvailabilityProviders(ApplicationContext applicationContext)
/*     */   {
/*  77 */     this(applicationContext != null ? applicationContext.getClassLoader() : null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public TemplateAvailabilityProviders(ClassLoader classLoader)
/*     */   {
/*  85 */     Assert.notNull(classLoader, "ClassLoader must not be null");
/*  86 */     this.providers = SpringFactoriesLoader.loadFactories(TemplateAvailabilityProvider.class, classLoader);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected TemplateAvailabilityProviders(Collection<? extends TemplateAvailabilityProvider> providers)
/*     */   {
/*  94 */     Assert.notNull(providers, "Providers must not be null");
/*  95 */     this.providers = new ArrayList(providers);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<TemplateAvailabilityProvider> getProviders()
/*     */   {
/* 103 */     return this.providers;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TemplateAvailabilityProvider getProvider(String view, ApplicationContext applicationContext)
/*     */   {
/* 113 */     Assert.notNull(applicationContext, "ApplicationContext must not be null");
/* 114 */     return getProvider(view, applicationContext.getEnvironment(), applicationContext.getClassLoader(), applicationContext);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TemplateAvailabilityProvider getProvider(String view, Environment environment, ClassLoader classLoader, ResourceLoader resourceLoader)
/*     */   {
/* 128 */     Assert.notNull(view, "View must not be null");
/* 129 */     Assert.notNull(environment, "Environment must not be null");
/* 130 */     Assert.notNull(classLoader, "ClassLoader must not be null");
/* 131 */     Assert.notNull(resourceLoader, "ResourceLoader must not be null");
/* 132 */     Boolean useCache = (Boolean)environment.getProperty("spring.template.provider.cache", Boolean.class, Boolean.valueOf(true));
/* 133 */     if (!useCache.booleanValue()) {
/* 134 */       return findProvider(view, environment, classLoader, resourceLoader);
/*     */     }
/* 136 */     TemplateAvailabilityProvider provider = (TemplateAvailabilityProvider)this.resolved.get(view);
/* 137 */     if (provider == null) {
/* 138 */       synchronized (this.cache) {
/* 139 */         provider = findProvider(view, environment, classLoader, resourceLoader);
/* 140 */         provider = provider != null ? provider : NONE;
/* 141 */         this.resolved.put(view, provider);
/* 142 */         this.cache.put(view, provider);
/*     */       }
/*     */     }
/* 145 */     return provider != NONE ? provider : null;
/*     */   }
/*     */   
/*     */   private TemplateAvailabilityProvider findProvider(String view, Environment environment, ClassLoader classLoader, ResourceLoader resourceLoader)
/*     */   {
/* 150 */     for (TemplateAvailabilityProvider candidate : this.providers) {
/* 151 */       if (candidate.isTemplateAvailable(view, environment, classLoader, resourceLoader)) {
/* 152 */         return candidate;
/*     */       }
/*     */     }
/* 155 */     return null;
/*     */   }
/*     */   
/*     */   private static class NoTemplateAvailabilityProvider
/*     */     implements TemplateAvailabilityProvider
/*     */   {
/*     */     public boolean isTemplateAvailable(String view, Environment environment, ClassLoader classLoader, ResourceLoader resourceLoader)
/*     */     {
/* 163 */       return false;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\template\TemplateAvailabilityProviders.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */