package org.springframework.boot.autoconfigure.flyway;

import org.flywaydb.core.Flyway;

@FunctionalInterface
public abstract interface FlywayMigrationStrategy
{
  public abstract void migrate(Flyway paramFlyway);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\flyway\FlywayMigrationStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */