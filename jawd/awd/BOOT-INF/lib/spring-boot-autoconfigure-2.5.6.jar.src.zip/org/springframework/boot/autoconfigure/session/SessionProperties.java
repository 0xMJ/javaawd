/*     */ package org.springframework.boot.autoconfigure.session;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.time.temporal.ChronoUnit;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.boot.convert.DurationUnit;
/*     */ import org.springframework.boot.web.servlet.DispatcherType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix="spring.session")
/*     */ public class SessionProperties
/*     */ {
/*     */   private StoreType storeType;
/*     */   @DurationUnit(ChronoUnit.SECONDS)
/*     */   private Duration timeout;
/*  53 */   private Servlet servlet = new Servlet();
/*     */   
/*     */   public StoreType getStoreType() {
/*  56 */     return this.storeType;
/*     */   }
/*     */   
/*     */   public void setStoreType(StoreType storeType) {
/*  60 */     this.storeType = storeType;
/*     */   }
/*     */   
/*     */   public Duration getTimeout() {
/*  64 */     return this.timeout;
/*     */   }
/*     */   
/*     */   public void setTimeout(Duration timeout) {
/*  68 */     this.timeout = timeout;
/*     */   }
/*     */   
/*     */   public Servlet getServlet() {
/*  72 */     return this.servlet;
/*     */   }
/*     */   
/*     */   public void setServlet(Servlet servlet) {
/*  76 */     this.servlet = servlet;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Duration determineTimeout(Supplier<Duration> fallbackTimeout)
/*     */   {
/*  87 */     return this.timeout != null ? this.timeout : (Duration)fallbackTimeout.get();
/*     */   }
/*     */   
/*     */ 
/*     */   public static class Servlet
/*     */   {
/*     */     private int filterOrder;
/*     */     
/*     */ 
/*     */     public Servlet()
/*     */     {
/*  98 */       this.filterOrder = -2147483598;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 103 */     private Set<DispatcherType> filterDispatcherTypes = new HashSet(
/* 104 */       Arrays.asList(new DispatcherType[] { DispatcherType.ASYNC, DispatcherType.ERROR, DispatcherType.REQUEST }));
/*     */     
/*     */     public int getFilterOrder() {
/* 107 */       return this.filterOrder;
/*     */     }
/*     */     
/*     */     public void setFilterOrder(int filterOrder) {
/* 111 */       this.filterOrder = filterOrder;
/*     */     }
/*     */     
/*     */     public Set<DispatcherType> getFilterDispatcherTypes() {
/* 115 */       return this.filterDispatcherTypes;
/*     */     }
/*     */     
/*     */     public void setFilterDispatcherTypes(Set<DispatcherType> filterDispatcherTypes) {
/* 119 */       this.filterDispatcherTypes = filterDispatcherTypes;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\session\SessionProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */