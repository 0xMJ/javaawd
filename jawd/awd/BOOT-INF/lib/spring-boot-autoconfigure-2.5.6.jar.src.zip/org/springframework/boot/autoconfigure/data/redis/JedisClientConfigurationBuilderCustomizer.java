package org.springframework.boot.autoconfigure.data.redis;

import org.springframework.data.redis.connection.jedis.JedisClientConfiguration.JedisClientConfigurationBuilder;

@FunctionalInterface
public abstract interface JedisClientConfigurationBuilderCustomizer
{
  public abstract void customize(JedisClientConfiguration.JedisClientConfigurationBuilder paramJedisClientConfigurationBuilder);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\data\redis\JedisClientConfigurationBuilderCustomizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */