/*     */ package org.springframework.boot.autoconfigure.domain;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.boot.autoconfigure.AutoConfigurationPackages;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.annotation.ClassPathScanningCandidateComponentProvider;
/*     */ import org.springframework.core.type.filter.AnnotationTypeFilter;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EntityScanner
/*     */ {
/*     */   private final ApplicationContext context;
/*     */   
/*     */   public EntityScanner(ApplicationContext context)
/*     */   {
/*  50 */     Assert.notNull(context, "Context must not be null");
/*  51 */     this.context = context;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @SafeVarargs
/*     */   public final Set<Class<?>> scan(Class<? extends Annotation>... annotationTypes)
/*     */     throws ClassNotFoundException
/*     */   {
/*  62 */     List<String> packages = getPackages();
/*  63 */     if (packages.isEmpty()) {
/*  64 */       return Collections.emptySet();
/*     */     }
/*  66 */     ClassPathScanningCandidateComponentProvider scanner = createClassPathScanningCandidateComponentProvider(this.context);
/*     */     Class<? extends Annotation> annotationType;
/*  68 */     for (annotationType : annotationTypes) {
/*  69 */       scanner.addIncludeFilter(new AnnotationTypeFilter(annotationType));
/*     */     }
/*  71 */     Object entitySet = new HashSet();
/*  72 */     for (String basePackage : packages) {
/*  73 */       if (StringUtils.hasText(basePackage)) {
/*  74 */         for (BeanDefinition candidate : scanner.findCandidateComponents(basePackage)) {
/*  75 */           ((Set)entitySet).add(ClassUtils.forName(candidate.getBeanClassName(), this.context.getClassLoader()));
/*     */         }
/*     */       }
/*     */     }
/*  79 */     return (Set<Class<?>>)entitySet;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ClassPathScanningCandidateComponentProvider createClassPathScanningCandidateComponentProvider(ApplicationContext context)
/*     */   {
/*  92 */     ClassPathScanningCandidateComponentProvider scanner = new ClassPathScanningCandidateComponentProvider(false);
/*  93 */     scanner.setEnvironment(context.getEnvironment());
/*  94 */     scanner.setResourceLoader(context);
/*  95 */     return scanner;
/*     */   }
/*     */   
/*     */   private List<String> getPackages() {
/*  99 */     List<String> packages = EntityScanPackages.get(this.context).getPackageNames();
/* 100 */     if ((packages.isEmpty()) && (AutoConfigurationPackages.has(this.context))) {
/* 101 */       packages = AutoConfigurationPackages.get(this.context);
/*     */     }
/* 103 */     return packages;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\domain\EntityScanner.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */