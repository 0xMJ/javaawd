/*    */ package org.springframework.boot.autoconfigure.data.mongo;
/*    */ 
/*    */ import com.mongodb.client.MongoClient;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnSingleCandidate;
/*    */ import org.springframework.boot.autoconfigure.mongo.MongoProperties;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.data.mongodb.MongoDatabaseFactory;
/*    */ import org.springframework.data.mongodb.core.MongoDatabaseFactorySupport;
/*    */ import org.springframework.data.mongodb.core.SimpleMongoClientDatabaseFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods=false)
/*    */ @ConditionalOnMissingBean({MongoDatabaseFactory.class})
/*    */ @ConditionalOnSingleCandidate(MongoClient.class)
/*    */ class MongoDatabaseFactoryConfiguration
/*    */ {
/*    */   @Bean
/*    */   MongoDatabaseFactorySupport<?> mongoDatabaseFactory(MongoClient mongoClient, MongoProperties properties)
/*    */   {
/* 43 */     return new SimpleMongoClientDatabaseFactory(mongoClient, properties.getMongoClientDatabase());
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\data\mongo\MongoDatabaseFactoryConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */