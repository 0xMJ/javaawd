/*    */ package org.springframework.boot.autoconfigure.mail;
/*    */ 
/*    */ import javax.mail.MessagingException;
/*    */ import org.springframework.boot.autoconfigure.AutoConfigureAfter;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnSingleCandidate;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.mail.javamail.JavaMailSenderImpl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods=false)
/*    */ @AutoConfigureAfter({MailSenderAutoConfiguration.class})
/*    */ @ConditionalOnProperty(prefix="spring.mail", value={"test-connection"})
/*    */ @ConditionalOnSingleCandidate(JavaMailSenderImpl.class)
/*    */ public class MailSenderValidatorAutoConfiguration
/*    */ {
/*    */   private final JavaMailSenderImpl mailSender;
/*    */   
/*    */   public MailSenderValidatorAutoConfiguration(JavaMailSenderImpl mailSender)
/*    */   {
/* 45 */     this.mailSender = mailSender;
/* 46 */     validateConnection();
/*    */   }
/*    */   
/*    */   public void validateConnection() {
/*    */     try {
/* 51 */       this.mailSender.testConnection();
/*    */     }
/*    */     catch (MessagingException ex) {
/* 54 */       throw new IllegalStateException("Mail server is not available", ex);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\mail\MailSenderValidatorAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */