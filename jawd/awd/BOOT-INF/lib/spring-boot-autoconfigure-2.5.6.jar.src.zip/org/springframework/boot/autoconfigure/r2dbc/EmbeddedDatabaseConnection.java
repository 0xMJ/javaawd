/*    */ package org.springframework.boot.autoconfigure.r2dbc;
/*    */ 
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public enum EmbeddedDatabaseConnection
/*    */ {
/* 37 */   NONE(null, null, null), 
/*    */   
/*    */ 
/*    */ 
/*    */ 
/* 42 */   H2("H2", "io.r2dbc.h2.H2ConnectionFactoryProvider", "r2dbc:h2:mem:///%s?options=DB_CLOSE_DELAY=-1;DB_CLOSE_ON_EXIT=FALSE");
/*    */   
/*    */ 
/*    */   private final String type;
/*    */   
/*    */   private final String driverClassName;
/*    */   private final String url;
/*    */   
/*    */   private EmbeddedDatabaseConnection(String type, String driverClassName, String url)
/*    */   {
/* 52 */     this.type = type;
/* 53 */     this.driverClassName = driverClassName;
/* 54 */     this.url = url;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getDriverClassName()
/*    */   {
/* 62 */     return this.driverClassName;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getType()
/*    */   {
/* 70 */     return this.type;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getUrl(String databaseName)
/*    */   {
/* 79 */     Assert.hasText(databaseName, "DatabaseName must not be empty");
/* 80 */     return this.url != null ? String.format(this.url, new Object[] { databaseName }) : null;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static EmbeddedDatabaseConnection get(ClassLoader classLoader)
/*    */   {
/* 90 */     for (EmbeddedDatabaseConnection candidate : ) {
/* 91 */       if ((candidate != NONE) && (ClassUtils.isPresent(candidate.getDriverClassName(), classLoader))) {
/* 92 */         return candidate;
/*    */       }
/*    */     }
/* 95 */     return NONE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\r2dbc\EmbeddedDatabaseConnection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */