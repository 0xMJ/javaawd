/*    */ package org.springframework.boot.autoconfigure.http;
/*    */ 
/*    */ import com.google.gson.Gson;
/*    */ import org.springframework.boot.autoconfigure.condition.AnyNestedCondition;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*    */ import org.springframework.boot.autoconfigure.condition.NoneNestedConditions;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Conditional;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.ConfigurationCondition.ConfigurationPhase;
/*    */ import org.springframework.http.converter.json.GsonHttpMessageConverter;
/*    */ import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods=false)
/*    */ @ConditionalOnClass({Gson.class})
/*    */ class GsonHttpMessageConvertersConfiguration
/*    */ {
/*    */   @Configuration(proxyBeanMethods=false)
/*    */   @ConditionalOnBean({Gson.class})
/*    */   @Conditional({GsonHttpMessageConvertersConfiguration.PreferGsonOrJacksonAndJsonbUnavailableCondition.class})
/*    */   static class GsonHttpMessageConverterConfiguration
/*    */   {
/*    */     @Bean
/*    */     @ConditionalOnMissingBean
/*    */     GsonHttpMessageConverter gsonHttpMessageConverter(Gson gson)
/*    */     {
/* 51 */       GsonHttpMessageConverter converter = new GsonHttpMessageConverter();
/* 52 */       converter.setGson(gson);
/* 53 */       return converter;
/*    */     }
/*    */   }
/*    */   
/*    */   private static class PreferGsonOrJacksonAndJsonbUnavailableCondition extends AnyNestedCondition
/*    */   {
/*    */     PreferGsonOrJacksonAndJsonbUnavailableCondition()
/*    */     {
/* 61 */       super();
/*    */     }
/*    */     
/*    */ 
/*    */ 
/*    */     @Conditional({GsonHttpMessageConvertersConfiguration.JacksonAndJsonbUnavailableCondition.class})
/*    */     static class JacksonJsonbUnavailable {}
/*    */     
/*    */ 
/*    */     @ConditionalOnProperty(name={"spring.mvc.converters.preferred-json-mapper"}, havingValue="gson")
/*    */     static class GsonPreferred {}
/*    */   }
/*    */   
/*    */ 
/*    */   private static class JacksonAndJsonbUnavailableCondition
/*    */     extends NoneNestedConditions
/*    */   {
/*    */     JacksonAndJsonbUnavailableCondition()
/*    */     {
/* 80 */       super();
/*    */     }
/*    */     
/*    */     @ConditionalOnProperty(name={"spring.mvc.converters.preferred-json-mapper"}, havingValue="jsonb")
/*    */     static class JsonbPreferred {}
/*    */     
/*    */     @ConditionalOnBean({MappingJackson2HttpMessageConverter.class})
/*    */     static class JacksonAvailable {}
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\http\GsonHttpMessageConvertersConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */