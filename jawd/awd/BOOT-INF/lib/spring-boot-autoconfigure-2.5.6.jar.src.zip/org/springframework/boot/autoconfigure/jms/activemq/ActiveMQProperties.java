/*     */ package org.springframework.boot.autoconfigure.jms.activemq;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.springframework.boot.autoconfigure.jms.JmsPoolConnectionFactoryProperties;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.boot.context.properties.NestedConfigurationProperty;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix="spring.activemq")
/*     */ public class ActiveMQProperties
/*     */ {
/*     */   private String brokerUrl;
/*  48 */   private boolean inMemory = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String user;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String password;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  63 */   private Duration closeTimeout = Duration.ofSeconds(15L);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  69 */   private boolean nonBlockingRedelivery = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  74 */   private Duration sendTimeout = Duration.ofMillis(0L);
/*     */   @NestedConfigurationProperty
/*  76 */   private final JmsPoolConnectionFactoryProperties pool = new JmsPoolConnectionFactoryProperties();
/*     */   
/*     */ 
/*  79 */   private final Packages packages = new Packages();
/*     */   
/*     */   public String getBrokerUrl() {
/*  82 */     return this.brokerUrl;
/*     */   }
/*     */   
/*     */   public void setBrokerUrl(String brokerUrl) {
/*  86 */     this.brokerUrl = brokerUrl;
/*     */   }
/*     */   
/*     */   public boolean isInMemory() {
/*  90 */     return this.inMemory;
/*     */   }
/*     */   
/*     */   public void setInMemory(boolean inMemory) {
/*  94 */     this.inMemory = inMemory;
/*     */   }
/*     */   
/*     */   public String getUser() {
/*  98 */     return this.user;
/*     */   }
/*     */   
/*     */   public void setUser(String user) {
/* 102 */     this.user = user;
/*     */   }
/*     */   
/*     */   public String getPassword() {
/* 106 */     return this.password;
/*     */   }
/*     */   
/*     */   public void setPassword(String password) {
/* 110 */     this.password = password;
/*     */   }
/*     */   
/*     */   public Duration getCloseTimeout() {
/* 114 */     return this.closeTimeout;
/*     */   }
/*     */   
/*     */   public void setCloseTimeout(Duration closeTimeout) {
/* 118 */     this.closeTimeout = closeTimeout;
/*     */   }
/*     */   
/*     */   public boolean isNonBlockingRedelivery() {
/* 122 */     return this.nonBlockingRedelivery;
/*     */   }
/*     */   
/*     */   public void setNonBlockingRedelivery(boolean nonBlockingRedelivery) {
/* 126 */     this.nonBlockingRedelivery = nonBlockingRedelivery;
/*     */   }
/*     */   
/*     */   public Duration getSendTimeout() {
/* 130 */     return this.sendTimeout;
/*     */   }
/*     */   
/*     */   public void setSendTimeout(Duration sendTimeout) {
/* 134 */     this.sendTimeout = sendTimeout;
/*     */   }
/*     */   
/*     */   public JmsPoolConnectionFactoryProperties getPool() {
/* 138 */     return this.pool;
/*     */   }
/*     */   
/*     */   public Packages getPackages() {
/* 142 */     return this.packages;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Packages
/*     */   {
/*     */     private Boolean trustAll;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 156 */     private List<String> trusted = new ArrayList();
/*     */     
/*     */     public Boolean getTrustAll() {
/* 159 */       return this.trustAll;
/*     */     }
/*     */     
/*     */     public void setTrustAll(Boolean trustAll) {
/* 163 */       this.trustAll = trustAll;
/*     */     }
/*     */     
/*     */     public List<String> getTrusted() {
/* 167 */       return this.trusted;
/*     */     }
/*     */     
/*     */     public void setTrusted(List<String> trusted) {
/* 171 */       this.trusted = trusted;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\jms\activemq\ActiveMQProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */