package org.springframework.boot.autoconfigure.data;

import java.lang.annotation.Annotation;
import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.springframework.context.annotation.Conditional;

@Retention(RetentionPolicy.RUNTIME)
@Target({java.lang.annotation.ElementType.TYPE, java.lang.annotation.ElementType.METHOD})
@Documented
@Conditional({OnRepositoryTypeCondition.class})
public @interface ConditionalOnRepositoryType
{
  String store();
  
  RepositoryType type();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\data\ConditionalOnRepositoryType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */