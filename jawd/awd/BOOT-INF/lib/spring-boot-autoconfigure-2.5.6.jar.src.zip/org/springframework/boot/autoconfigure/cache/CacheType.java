package org.springframework.boot.autoconfigure.cache;

public enum CacheType
{
  GENERIC,  JCACHE,  EHCACHE,  HAZELCAST,  INFINISPAN,  COUCHBASE,  REDIS,  CAFFEINE,  SIMPLE,  NONE;
  
  private CacheType() {}
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\cache\CacheType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */