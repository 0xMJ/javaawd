/*    */ package org.springframework.boot.autoconfigure.mustache;
/*    */ 
/*    */ import com.samskivert.mustache.Mustache.Compiler;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication.Type;
/*    */ import org.springframework.boot.web.reactive.result.view.MustacheViewResolver;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods=false)
/*    */ @ConditionalOnWebApplication(type=ConditionalOnWebApplication.Type.REACTIVE)
/*    */ class MustacheReactiveWebConfiguration
/*    */ {
/*    */   @Bean
/*    */   @ConditionalOnMissingBean
/*    */   MustacheViewResolver mustacheViewResolver(Mustache.Compiler mustacheCompiler, MustacheProperties mustache)
/*    */   {
/* 36 */     MustacheViewResolver resolver = new MustacheViewResolver(mustacheCompiler);
/* 37 */     resolver.setPrefix(mustache.getPrefix());
/* 38 */     resolver.setSuffix(mustache.getSuffix());
/* 39 */     resolver.setViewNames(mustache.getViewNames());
/* 40 */     resolver.setRequestContextAttribute(mustache.getRequestContextAttribute());
/* 41 */     resolver.setCharset(mustache.getCharsetName());
/* 42 */     resolver.setOrder(2147483637);
/* 43 */     return resolver;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\mustache\MustacheReactiveWebConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */