/*    */ package org.springframework.boot.autoconfigure.sendgrid;
/*    */ 
/*    */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @ConfigurationProperties(prefix="spring.sendgrid")
/*    */ public class SendGridProperties
/*    */ {
/*    */   private String apiKey;
/*    */   private Proxy proxy;
/*    */   
/*    */   public String getApiKey()
/*    */   {
/* 42 */     return this.apiKey;
/*    */   }
/*    */   
/*    */   public void setApiKey(String apiKey) {
/* 46 */     this.apiKey = apiKey;
/*    */   }
/*    */   
/*    */   public Proxy getProxy() {
/* 50 */     return this.proxy;
/*    */   }
/*    */   
/*    */   public void setProxy(Proxy proxy) {
/* 54 */     this.proxy = proxy;
/*    */   }
/*    */   
/*    */   public boolean isProxyConfigured() {
/* 58 */     return (this.proxy != null) && (this.proxy.getHost() != null) && (this.proxy.getPort() != null);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public static class Proxy
/*    */   {
/*    */     private String host;
/*    */     
/*    */ 
/*    */     private Integer port;
/*    */     
/*    */ 
/*    */ 
/*    */     public String getHost()
/*    */     {
/* 74 */       return this.host;
/*    */     }
/*    */     
/*    */     public void setHost(String host) {
/* 78 */       this.host = host;
/*    */     }
/*    */     
/*    */     public Integer getPort() {
/* 82 */       return this.port;
/*    */     }
/*    */     
/*    */     public void setPort(Integer port) {
/* 86 */       this.port = port;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\sendgrid\SendGridProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */