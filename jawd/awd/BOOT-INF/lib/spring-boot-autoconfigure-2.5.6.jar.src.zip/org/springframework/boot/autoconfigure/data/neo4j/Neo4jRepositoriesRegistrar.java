/*    */ package org.springframework.boot.autoconfigure.data.neo4j;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import org.springframework.boot.autoconfigure.data.AbstractRepositoryConfigurationSourceSupport;
/*    */ import org.springframework.data.neo4j.repository.config.EnableNeo4jRepositories;
/*    */ import org.springframework.data.neo4j.repository.config.Neo4jRepositoryConfigurationExtension;
/*    */ import org.springframework.data.repository.config.RepositoryConfigurationExtension;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class Neo4jRepositoriesRegistrar
/*    */   extends AbstractRepositoryConfigurationSourceSupport
/*    */ {
/*    */   protected Class<? extends Annotation> getAnnotation()
/*    */   {
/* 37 */     return EnableNeo4jRepositories.class;
/*    */   }
/*    */   
/*    */   protected Class<?> getConfiguration()
/*    */   {
/* 42 */     return EnableNeo4jRepositoriesConfiguration.class;
/*    */   }
/*    */   
/*    */   protected RepositoryConfigurationExtension getRepositoryConfigurationExtension()
/*    */   {
/* 47 */     return new Neo4jRepositoryConfigurationExtension();
/*    */   }
/*    */   
/*    */   @EnableNeo4jRepositories
/*    */   private static class EnableNeo4jRepositoriesConfiguration {}
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\data\neo4j\Neo4jRepositoriesRegistrar.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */