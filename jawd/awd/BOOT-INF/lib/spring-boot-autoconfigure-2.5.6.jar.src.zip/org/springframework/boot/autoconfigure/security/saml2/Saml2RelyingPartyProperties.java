/*     */ package org.springframework.boot.autoconfigure.security.saml2;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.security.saml2.provider.service.registration.Saml2MessageBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties("spring.security.saml2.relyingparty")
/*     */ public class Saml2RelyingPartyProperties
/*     */ {
/*  41 */   private final Map<String, Registration> registration = new LinkedHashMap();
/*     */   
/*     */   public Map<String, Registration> getRegistration() {
/*  44 */     return this.registration;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Registration
/*     */   {
/*  56 */     private String entityId = "{baseUrl}/saml2/service-provider-metadata/{registrationId}";
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  61 */     private final Acs acs = new Acs();
/*     */     
/*  63 */     private final Signing signing = new Signing();
/*     */     
/*  65 */     private final Saml2RelyingPartyProperties.Decryption decryption = new Saml2RelyingPartyProperties.Decryption();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  70 */     private final Saml2RelyingPartyProperties.Identityprovider identityprovider = new Saml2RelyingPartyProperties.Identityprovider();
/*     */     
/*     */     public String getEntityId() {
/*  73 */       return this.entityId;
/*     */     }
/*     */     
/*     */     public void setEntityId(String entityId) {
/*  77 */       this.entityId = entityId;
/*     */     }
/*     */     
/*     */     public Acs getAcs() {
/*  81 */       return this.acs;
/*     */     }
/*     */     
/*     */     public Signing getSigning() {
/*  85 */       return this.signing;
/*     */     }
/*     */     
/*     */     public Saml2RelyingPartyProperties.Decryption getDecryption() {
/*  89 */       return this.decryption;
/*     */     }
/*     */     
/*     */     public Saml2RelyingPartyProperties.Identityprovider getIdentityprovider() {
/*  93 */       return this.identityprovider;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public static class Acs
/*     */     {
/* 103 */       private String location = "{baseUrl}/login/saml2/sso/{registrationId}";
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 108 */       private Saml2MessageBinding binding = Saml2MessageBinding.POST;
/*     */       
/*     */       public String getLocation() {
/* 111 */         return this.location;
/*     */       }
/*     */       
/*     */       public void setLocation(String location) {
/* 115 */         this.location = location;
/*     */       }
/*     */       
/*     */       public Saml2MessageBinding getBinding() {
/* 119 */         return this.binding;
/*     */       }
/*     */       
/*     */       public void setBinding(Saml2MessageBinding binding) {
/* 123 */         this.binding = binding;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public static class Signing
/*     */     {
/* 133 */       private List<Credential> credentials = new ArrayList();
/*     */       
/*     */       public List<Credential> getCredentials() {
/* 136 */         return this.credentials;
/*     */       }
/*     */       
/*     */       public void setCredentials(List<Credential> credentials) {
/* 140 */         this.credentials = credentials;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */       public static class Credential
/*     */       {
/*     */         private Resource privateKeyLocation;
/*     */         
/*     */ 
/*     */         private Resource certificateLocation;
/*     */         
/*     */ 
/*     */ 
/*     */         public Resource getPrivateKeyLocation()
/*     */         {
/* 156 */           return this.privateKeyLocation;
/*     */         }
/*     */         
/*     */         public void setPrivateKeyLocation(Resource privateKey) {
/* 160 */           this.privateKeyLocation = privateKey;
/*     */         }
/*     */         
/*     */         public Resource getCertificateLocation() {
/* 164 */           return this.certificateLocation;
/*     */         }
/*     */         
/*     */         public void setCertificateLocation(Resource certificate) {
/* 168 */           this.certificateLocation = certificate;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Decryption
/*     */   {
/* 182 */     private List<Credential> credentials = new ArrayList();
/*     */     
/*     */     public List<Credential> getCredentials() {
/* 185 */       return this.credentials;
/*     */     }
/*     */     
/*     */     public void setCredentials(List<Credential> credentials) {
/* 189 */       this.credentials = credentials;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public static class Credential
/*     */     {
/*     */       private Resource privateKeyLocation;
/*     */       
/*     */ 
/*     */       private Resource certificateLocation;
/*     */       
/*     */ 
/*     */ 
/*     */       public Resource getPrivateKeyLocation()
/*     */       {
/* 205 */         return this.privateKeyLocation;
/*     */       }
/*     */       
/*     */       public void setPrivateKeyLocation(Resource privateKey) {
/* 209 */         this.privateKeyLocation = privateKey;
/*     */       }
/*     */       
/*     */       public Resource getCertificateLocation() {
/* 213 */         return this.certificateLocation;
/*     */       }
/*     */       
/*     */       public void setCertificateLocation(Resource certificate) {
/* 217 */         this.certificateLocation = certificate;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Identityprovider
/*     */   {
/*     */     private String entityId;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private String metadataUri;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 239 */     private final Singlesignon singlesignon = new Singlesignon();
/*     */     
/* 241 */     private final Verification verification = new Verification();
/*     */     
/*     */     public String getEntityId() {
/* 244 */       return this.entityId;
/*     */     }
/*     */     
/*     */     public void setEntityId(String entityId) {
/* 248 */       this.entityId = entityId;
/*     */     }
/*     */     
/*     */     public String getMetadataUri() {
/* 252 */       return this.metadataUri;
/*     */     }
/*     */     
/*     */     public void setMetadataUri(String metadataUri) {
/* 256 */       this.metadataUri = metadataUri;
/*     */     }
/*     */     
/*     */     public Singlesignon getSinglesignon() {
/* 260 */       return this.singlesignon;
/*     */     }
/*     */     
/*     */     public Verification getVerification() {
/* 264 */       return this.verification;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public static class Singlesignon
/*     */     {
/*     */       private String url;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       private Saml2MessageBinding binding;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 285 */       private boolean signRequest = true;
/*     */       
/*     */       public String getUrl() {
/* 288 */         return this.url;
/*     */       }
/*     */       
/*     */       public void setUrl(String url) {
/* 292 */         this.url = url;
/*     */       }
/*     */       
/*     */       public Saml2MessageBinding getBinding() {
/* 296 */         return this.binding;
/*     */       }
/*     */       
/*     */       public void setBinding(Saml2MessageBinding binding) {
/* 300 */         this.binding = binding;
/*     */       }
/*     */       
/*     */       public boolean isSignRequest() {
/* 304 */         return this.signRequest;
/*     */       }
/*     */       
/*     */       public void setSignRequest(boolean signRequest) {
/* 308 */         this.signRequest = signRequest;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public static class Verification
/*     */     {
/* 321 */       private List<Credential> credentials = new ArrayList();
/*     */       
/*     */       public List<Credential> getCredentials() {
/* 324 */         return this.credentials;
/*     */       }
/*     */       
/*     */       public void setCredentials(List<Credential> credentials) {
/* 328 */         this.credentials = credentials;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */       public static class Credential
/*     */       {
/*     */         private Resource certificate;
/*     */         
/*     */ 
/*     */         public Resource getCertificateLocation()
/*     */         {
/* 340 */           return this.certificate;
/*     */         }
/*     */         
/*     */         public void setCertificateLocation(Resource certificate) {
/* 344 */           this.certificate = certificate;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\security\saml2\Saml2RelyingPartyProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */