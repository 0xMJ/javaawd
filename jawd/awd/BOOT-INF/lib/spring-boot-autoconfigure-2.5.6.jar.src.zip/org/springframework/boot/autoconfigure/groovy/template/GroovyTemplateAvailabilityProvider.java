/*    */ package org.springframework.boot.autoconfigure.groovy.template;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import org.springframework.boot.autoconfigure.template.PathBasedTemplateAvailabilityProvider;
/*    */ import org.springframework.boot.autoconfigure.template.PathBasedTemplateAvailabilityProvider.TemplateAvailabilityProperties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GroovyTemplateAvailabilityProvider
/*    */   extends PathBasedTemplateAvailabilityProvider
/*    */ {
/*    */   public GroovyTemplateAvailabilityProvider()
/*    */   {
/* 36 */     super("groovy.text.TemplateEngine", GroovyTemplateAvailabilityProperties.class, "spring.groovy.template");
/*    */   }
/*    */   
/*    */   protected static final class GroovyTemplateAvailabilityProperties extends PathBasedTemplateAvailabilityProvider.TemplateAvailabilityProperties
/*    */   {
/* 41 */     private List<String> resourceLoaderPath = new ArrayList(
/* 42 */       Arrays.asList(new String[] { "classpath:/templates/" }));
/*    */     
/*    */     GroovyTemplateAvailabilityProperties() {
/* 45 */       super(".tpl");
/*    */     }
/*    */     
/*    */     protected List<String> getLoaderPath()
/*    */     {
/* 50 */       return this.resourceLoaderPath;
/*    */     }
/*    */     
/*    */     public List<String> getResourceLoaderPath() {
/* 54 */       return this.resourceLoaderPath;
/*    */     }
/*    */     
/*    */     public void setResourceLoaderPath(List<String> resourceLoaderPath) {
/* 58 */       this.resourceLoaderPath = resourceLoaderPath;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\groovy\template\GroovyTemplateAvailabilityProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */