package org.springframework.boot.autoconfigure.cache;

import java.util.Properties;

abstract interface JCachePropertiesCustomizer
{
  public abstract void customize(CacheProperties paramCacheProperties, Properties paramProperties);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\cache\JCachePropertiesCustomizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */