package org.springframework.boot.autoconfigure.influx;

import java.util.function.Supplier;
import okhttp3.OkHttpClient.Builder;

@FunctionalInterface
public abstract interface InfluxDbOkHttpClientBuilderProvider
  extends Supplier<OkHttpClient.Builder>
{}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\influx\InfluxDbOkHttpClientBuilderProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */