/*    */ package org.springframework.boot.autoconfigure.hazelcast;
/*    */ 
/*    */ import com.hazelcast.client.HazelcastClient;
/*    */ import com.hazelcast.client.config.ClientConfig;
/*    */ import com.hazelcast.client.config.XmlClientConfigBuilder;
/*    */ import com.hazelcast.client.config.YamlClientConfigBuilder;
/*    */ import com.hazelcast.core.HazelcastInstance;
/*    */ import java.io.IOException;
/*    */ import java.net.URL;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnSingleCandidate;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Conditional;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.core.io.Resource;
/*    */ import org.springframework.core.io.ResourceLoader;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods=false)
/*    */ @ConditionalOnClass({HazelcastClient.class})
/*    */ @ConditionalOnMissingBean({HazelcastInstance.class})
/*    */ class HazelcastClientConfiguration
/*    */ {
/*    */   static final String CONFIG_SYSTEM_PROPERTY = "hazelcast.client.config";
/*    */   
/*    */   private static HazelcastInstance getHazelcastInstance(ClientConfig config)
/*    */   {
/* 52 */     if (StringUtils.hasText(config.getInstanceName())) {
/* 53 */       return HazelcastClient.getOrCreateHazelcastClient(config);
/*    */     }
/* 55 */     return HazelcastClient.newHazelcastClient(config);
/*    */   }
/*    */   
/*    */   @Configuration(proxyBeanMethods=false)
/*    */   @ConditionalOnMissingBean({ClientConfig.class})
/*    */   @Conditional({HazelcastClientConfigAvailableCondition.class})
/*    */   static class HazelcastClientConfigFileConfiguration
/*    */   {
/*    */     @Bean
/*    */     HazelcastInstance hazelcastInstance(HazelcastProperties properties, ResourceLoader resourceLoader) throws IOException
/*    */     {
/* 66 */       Resource configLocation = properties.resolveConfigLocation();
/* 67 */       ClientConfig config = configLocation != null ? loadClientConfig(configLocation) : ClientConfig.load();
/* 68 */       config.setClassLoader(resourceLoader.getClassLoader());
/* 69 */       return HazelcastClientConfiguration.getHazelcastInstance(config);
/*    */     }
/*    */     
/*    */     private ClientConfig loadClientConfig(Resource configLocation) throws IOException {
/* 73 */       URL configUrl = configLocation.getURL();
/* 74 */       String configFileName = configUrl.getPath();
/* 75 */       if (configFileName.endsWith(".yaml")) {
/* 76 */         return new YamlClientConfigBuilder(configUrl).build();
/*    */       }
/* 78 */       return new XmlClientConfigBuilder(configUrl).build();
/*    */     }
/*    */   }
/*    */   
/*    */   @Configuration(proxyBeanMethods=false)
/*    */   @ConditionalOnSingleCandidate(ClientConfig.class)
/*    */   static class HazelcastClientConfigConfiguration
/*    */   {
/*    */     @Bean
/*    */     HazelcastInstance hazelcastInstance(ClientConfig config)
/*    */     {
/* 89 */       return HazelcastClientConfiguration.getHazelcastInstance(config);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\hazelcast\HazelcastClientConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */