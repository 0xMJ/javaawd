/*    */ package org.springframework.boot.autoconfigure.session;
/*    */ 
/*    */ import org.springframework.boot.WebApplicationType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ServletSessionCondition
/*    */   extends AbstractSessionCondition
/*    */ {
/*    */   ServletSessionCondition()
/*    */   {
/* 32 */     super(WebApplicationType.SERVLET);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\session\ServletSessionCondition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */