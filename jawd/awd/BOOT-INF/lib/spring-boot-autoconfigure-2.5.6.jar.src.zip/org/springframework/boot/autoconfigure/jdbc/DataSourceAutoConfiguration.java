/*     */ package org.springframework.boot.autoconfigure.jdbc;
/*     */ 
/*     */ import javax.sql.DataSource;
/*     */ import javax.sql.XADataSource;
/*     */ import org.springframework.boot.autoconfigure.condition.AnyNestedCondition;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionMessage;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionMessage.Builder;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionMessage.ItemsBuilder;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionOutcome;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*     */ import org.springframework.boot.autoconfigure.condition.SpringBootCondition;
/*     */ import org.springframework.boot.autoconfigure.jdbc.metadata.DataSourcePoolMetadataProvidersConfiguration;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.boot.jdbc.DataSourceBuilder;
/*     */ import org.springframework.boot.jdbc.EmbeddedDatabaseConnection;
/*     */ import org.springframework.context.annotation.Condition;
/*     */ import org.springframework.context.annotation.ConditionContext;
/*     */ import org.springframework.context.annotation.Conditional;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.context.annotation.ConfigurationCondition.ConfigurationPhase;
/*     */ import org.springframework.context.annotation.Import;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*     */ import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseType;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods=false)
/*     */ @ConditionalOnClass({DataSource.class, EmbeddedDatabaseType.class})
/*     */ @ConditionalOnMissingBean(type={"io.r2dbc.spi.ConnectionFactory"})
/*     */ @EnableConfigurationProperties({DataSourceProperties.class})
/*     */ @Import({DataSourcePoolMetadataProvidersConfiguration.class, DataSourceInitializationConfiguration.InitializationSpecificCredentialsDataSourceInitializationConfiguration.class, DataSourceInitializationConfiguration.SharedCredentialsDataSourceInitializationConfiguration.class})
/*     */ public class DataSourceAutoConfiguration
/*     */ {
/*     */   @Configuration(proxyBeanMethods=false)
/*     */   @Conditional({DataSourceAutoConfiguration.EmbeddedDatabaseCondition.class})
/*     */   @ConditionalOnMissingBean({DataSource.class, XADataSource.class})
/*     */   @Import({EmbeddedDataSourceConfiguration.class})
/*     */   protected static class EmbeddedDatabaseConfiguration {}
/*     */   
/*     */   @Configuration(proxyBeanMethods=false)
/*     */   @Conditional({DataSourceAutoConfiguration.PooledDataSourceCondition.class})
/*     */   @ConditionalOnMissingBean({DataSource.class, XADataSource.class})
/*     */   @Import({DataSourceConfiguration.Hikari.class, DataSourceConfiguration.Tomcat.class, DataSourceConfiguration.Dbcp2.class, DataSourceConfiguration.OracleUcp.class, DataSourceConfiguration.Generic.class, DataSourceJmxConfiguration.class})
/*     */   protected static class PooledDataSourceConfiguration {}
/*     */   
/*     */   static class PooledDataSourceCondition
/*     */     extends AnyNestedCondition
/*     */   {
/*     */     PooledDataSourceCondition()
/*     */     {
/*  88 */       super();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     @Conditional({DataSourceAutoConfiguration.PooledDataSourceAvailableCondition.class})
/*     */     static class PooledDataSourceAvailable {}
/*     */     
/*     */ 
/*     */ 
/*     */     @ConditionalOnProperty(prefix="spring.datasource", name={"type"})
/*     */     static class ExplicitType {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   static class PooledDataSourceAvailableCondition
/*     */     extends SpringBootCondition
/*     */   {
/*     */     public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata)
/*     */     {
/* 110 */       ConditionMessage.Builder message = ConditionMessage.forCondition("PooledDataSource", new Object[0]);
/* 111 */       if (DataSourceBuilder.findType(context.getClassLoader()) != null) {
/* 112 */         return ConditionOutcome.match(message.foundExactly("supported DataSource"));
/*     */       }
/* 114 */       return ConditionOutcome.noMatch(message.didNotFind("supported DataSource").atAll());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static class EmbeddedDatabaseCondition
/*     */     extends SpringBootCondition
/*     */   {
/*     */     private static final String DATASOURCE_URL_PROPERTY = "spring.datasource.url";
/*     */     
/*     */ 
/*     */ 
/* 128 */     private final SpringBootCondition pooledCondition = new DataSourceAutoConfiguration.PooledDataSourceCondition();
/*     */     
/*     */     public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata)
/*     */     {
/* 132 */       ConditionMessage.Builder message = ConditionMessage.forCondition("EmbeddedDataSource", new Object[0]);
/* 133 */       if (hasDataSourceUrlProperty(context)) {
/* 134 */         return ConditionOutcome.noMatch(message.because("spring.datasource.url is set"));
/*     */       }
/* 136 */       if (anyMatches(context, metadata, new Condition[] { this.pooledCondition })) {
/* 137 */         return ConditionOutcome.noMatch(message.foundExactly("supported pooled data source"));
/*     */       }
/* 139 */       EmbeddedDatabaseType type = EmbeddedDatabaseConnection.get(context.getClassLoader()).getType();
/* 140 */       if (type == null) {
/* 141 */         return ConditionOutcome.noMatch(message.didNotFind("embedded database").atAll());
/*     */       }
/* 143 */       return ConditionOutcome.match(message.found("embedded database").items(new Object[] { type }));
/*     */     }
/*     */     
/*     */     private boolean hasDataSourceUrlProperty(ConditionContext context) {
/* 147 */       Environment environment = context.getEnvironment();
/* 148 */       if (environment.containsProperty("spring.datasource.url")) {
/*     */         try {
/* 150 */           return StringUtils.hasText(environment.getProperty("spring.datasource.url"));
/*     */         }
/*     */         catch (IllegalArgumentException localIllegalArgumentException) {}
/*     */       }
/*     */       
/*     */ 
/* 156 */       return false;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\jdbc\DataSourceAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */