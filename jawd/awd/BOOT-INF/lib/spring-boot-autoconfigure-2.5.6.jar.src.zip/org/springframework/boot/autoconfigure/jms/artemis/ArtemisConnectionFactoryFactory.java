/*     */ package org.springframework.boot.autoconfigure.jms.artemis;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.activemq.artemis.api.core.TransportConfiguration;
/*     */ import org.apache.activemq.artemis.api.core.client.ActiveMQClient;
/*     */ import org.apache.activemq.artemis.api.core.client.ServerLocator;
/*     */ import org.apache.activemq.artemis.core.remoting.impl.invm.InVMConnectorFactory;
/*     */ import org.apache.activemq.artemis.core.remoting.impl.netty.NettyConnectorFactory;
/*     */ import org.apache.activemq.artemis.jms.client.ActiveMQConnectionFactory;
/*     */ import org.springframework.beans.factory.ListableBeanFactory;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ArtemisConnectionFactoryFactory
/*     */ {
/*     */   private static final String DEFAULT_BROKER_URL = "tcp://localhost:61616";
/*  49 */   static final String[] EMBEDDED_JMS_CLASSES = { "org.apache.activemq.artemis.jms.server.embedded.EmbeddedJMS", "org.apache.activemq.artemis.core.server.embedded.EmbeddedActiveMQ" };
/*     */   
/*     */   private final ArtemisProperties properties;
/*     */   
/*     */   private final ListableBeanFactory beanFactory;
/*     */   
/*     */   ArtemisConnectionFactoryFactory(ListableBeanFactory beanFactory, ArtemisProperties properties)
/*     */   {
/*  57 */     Assert.notNull(beanFactory, "BeanFactory must not be null");
/*  58 */     Assert.notNull(properties, "Properties must not be null");
/*  59 */     this.beanFactory = beanFactory;
/*  60 */     this.properties = properties;
/*     */   }
/*     */   
/*     */   <T extends ActiveMQConnectionFactory> T createConnectionFactory(Class<T> factoryClass) {
/*     */     try {
/*  65 */       startEmbeddedJms();
/*  66 */       return doCreateConnectionFactory(factoryClass);
/*     */     }
/*     */     catch (Exception ex) {
/*  69 */       throw new IllegalStateException("Unable to create ActiveMQConnectionFactory", ex);
/*     */     }
/*     */   }
/*     */   
/*     */   private void startEmbeddedJms() {
/*  74 */     for (String embeddedJmsClass : EMBEDDED_JMS_CLASSES) {
/*  75 */       if (ClassUtils.isPresent(embeddedJmsClass, null)) {
/*     */         try {
/*  77 */           this.beanFactory.getBeansOfType(Class.forName(embeddedJmsClass));
/*     */         }
/*     */         catch (Exception localException) {}
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private <T extends ActiveMQConnectionFactory> T doCreateConnectionFactory(Class<T> factoryClass)
/*     */     throws Exception
/*     */   {
/*  87 */     ArtemisMode mode = this.properties.getMode();
/*  88 */     if (mode == null) {
/*  89 */       mode = deduceMode();
/*     */     }
/*  91 */     if (mode == ArtemisMode.EMBEDDED) {
/*  92 */       return createEmbeddedConnectionFactory(factoryClass);
/*     */     }
/*  94 */     return createNativeConnectionFactory(factoryClass);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private ArtemisMode deduceMode()
/*     */   {
/* 102 */     if ((this.properties.getEmbedded().isEnabled()) && (isEmbeddedJmsClassPresent())) {
/* 103 */       return ArtemisMode.EMBEDDED;
/*     */     }
/* 105 */     return ArtemisMode.NATIVE;
/*     */   }
/*     */   
/*     */   private boolean isEmbeddedJmsClassPresent() {
/* 109 */     for (String embeddedJmsClass : EMBEDDED_JMS_CLASSES) {
/* 110 */       if (ClassUtils.isPresent(embeddedJmsClass, null)) {
/* 111 */         return true;
/*     */       }
/*     */     }
/* 114 */     return false;
/*     */   }
/*     */   
/*     */   private <T extends ActiveMQConnectionFactory> T createEmbeddedConnectionFactory(Class<T> factoryClass) throws Exception
/*     */   {
/*     */     try
/*     */     {
/* 121 */       TransportConfiguration transportConfiguration = new TransportConfiguration(InVMConnectorFactory.class.getName(), this.properties.getEmbedded().generateTransportParameters());
/* 122 */       ServerLocator serviceLocator = ActiveMQClient.createServerLocatorWithoutHA(new TransportConfiguration[] { transportConfiguration });
/* 123 */       return (ActiveMQConnectionFactory)factoryClass.getConstructor(new Class[] { ServerLocator.class }).newInstance(new Object[] { serviceLocator });
/*     */     }
/*     */     catch (NoClassDefFoundError ex) {
/* 126 */       throw new IllegalStateException("Unable to create InVM Artemis connection, ensure that artemis-jms-server.jar is in the classpath", ex);
/*     */     }
/*     */   }
/*     */   
/*     */   private <T extends ActiveMQConnectionFactory> T createNativeConnectionFactory(Class<T> factoryClass)
/*     */     throws Exception
/*     */   {
/* 133 */     T connectionFactory = newNativeConnectionFactory(factoryClass);
/* 134 */     String user = this.properties.getUser();
/* 135 */     if (StringUtils.hasText(user)) {
/* 136 */       connectionFactory.setUser(user);
/* 137 */       connectionFactory.setPassword(this.properties.getPassword());
/*     */     }
/* 139 */     return connectionFactory;
/*     */   }
/*     */   
/*     */   private <T extends ActiveMQConnectionFactory> T newNativeConnectionFactory(Class<T> factoryClass)
/*     */     throws Exception
/*     */   {
/* 145 */     if ((!StringUtils.hasText(this.properties.getBrokerUrl())) && (StringUtils.hasText(this.properties.getHost()))) {
/* 146 */       Map<String, Object> params = new HashMap();
/* 147 */       params.put("host", this.properties.getHost());
/* 148 */       params.put("port", Integer.valueOf(this.properties.getPort()));
/*     */       
/* 150 */       TransportConfiguration transportConfiguration = new TransportConfiguration(NettyConnectorFactory.class.getName(), params);
/* 151 */       Constructor<T> constructor = factoryClass.getConstructor(new Class[] { Boolean.TYPE, TransportConfiguration[].class });
/* 152 */       return (ActiveMQConnectionFactory)constructor.newInstance(new Object[] { Boolean.valueOf(false), { transportConfiguration } });
/*     */     }
/* 154 */     String brokerUrl = StringUtils.hasText(this.properties.getBrokerUrl()) ? this.properties.getBrokerUrl() : "tcp://localhost:61616";
/*     */     
/* 156 */     Constructor<T> constructor = factoryClass.getConstructor(new Class[] { String.class });
/* 157 */     return (ActiveMQConnectionFactory)constructor.newInstance(new Object[] { brokerUrl });
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\jms\artemis\ArtemisConnectionFactoryFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */