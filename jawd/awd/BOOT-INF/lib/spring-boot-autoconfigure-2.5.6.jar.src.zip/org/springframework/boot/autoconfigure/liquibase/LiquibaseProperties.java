/*     */ package org.springframework.boot.autoconfigure.liquibase;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.Map;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix="spring.liquibase", ignoreUnknownFields=false)
/*     */ public class LiquibaseProperties
/*     */ {
/*  42 */   private String changeLog = "classpath:/db/changelog/db.changelog-master.yaml";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean clearChecksums;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String contexts;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String defaultSchema;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String liquibaseSchema;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String liquibaseTablespace;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  73 */   private String databaseChangeLogTable = "DATABASECHANGELOG";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  78 */   private String databaseChangeLogLockTable = "DATABASECHANGELOGLOCK";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean dropFirst;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  88 */   private boolean enabled = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String user;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String password;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String driverClassName;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String url;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String labels;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private Map<String, String> parameters;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private File rollbackFile;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean testRollbackOnUpdate;
/*     */   
/*     */ 
/*     */ 
/*     */   private String tag;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getChangeLog()
/*     */   {
/* 139 */     return this.changeLog;
/*     */   }
/*     */   
/*     */   public void setChangeLog(String changeLog) {
/* 143 */     Assert.notNull(changeLog, "ChangeLog must not be null");
/* 144 */     this.changeLog = changeLog;
/*     */   }
/*     */   
/*     */   public String getContexts() {
/* 148 */     return this.contexts;
/*     */   }
/*     */   
/*     */   public void setContexts(String contexts) {
/* 152 */     this.contexts = contexts;
/*     */   }
/*     */   
/*     */   public String getDefaultSchema() {
/* 156 */     return this.defaultSchema;
/*     */   }
/*     */   
/*     */   public void setDefaultSchema(String defaultSchema) {
/* 160 */     this.defaultSchema = defaultSchema;
/*     */   }
/*     */   
/*     */   public String getLiquibaseSchema() {
/* 164 */     return this.liquibaseSchema;
/*     */   }
/*     */   
/*     */   public void setLiquibaseSchema(String liquibaseSchema) {
/* 168 */     this.liquibaseSchema = liquibaseSchema;
/*     */   }
/*     */   
/*     */   public String getLiquibaseTablespace() {
/* 172 */     return this.liquibaseTablespace;
/*     */   }
/*     */   
/*     */   public void setLiquibaseTablespace(String liquibaseTablespace) {
/* 176 */     this.liquibaseTablespace = liquibaseTablespace;
/*     */   }
/*     */   
/*     */   public String getDatabaseChangeLogTable() {
/* 180 */     return this.databaseChangeLogTable;
/*     */   }
/*     */   
/*     */   public void setDatabaseChangeLogTable(String databaseChangeLogTable) {
/* 184 */     this.databaseChangeLogTable = databaseChangeLogTable;
/*     */   }
/*     */   
/*     */   public String getDatabaseChangeLogLockTable() {
/* 188 */     return this.databaseChangeLogLockTable;
/*     */   }
/*     */   
/*     */   public void setDatabaseChangeLogLockTable(String databaseChangeLogLockTable) {
/* 192 */     this.databaseChangeLogLockTable = databaseChangeLogLockTable;
/*     */   }
/*     */   
/*     */   public boolean isDropFirst() {
/* 196 */     return this.dropFirst;
/*     */   }
/*     */   
/*     */   public void setDropFirst(boolean dropFirst) {
/* 200 */     this.dropFirst = dropFirst;
/*     */   }
/*     */   
/*     */   public boolean isClearChecksums() {
/* 204 */     return this.clearChecksums;
/*     */   }
/*     */   
/*     */   public void setClearChecksums(boolean clearChecksums) {
/* 208 */     this.clearChecksums = clearChecksums;
/*     */   }
/*     */   
/*     */   public boolean isEnabled() {
/* 212 */     return this.enabled;
/*     */   }
/*     */   
/*     */   public void setEnabled(boolean enabled) {
/* 216 */     this.enabled = enabled;
/*     */   }
/*     */   
/*     */   public String getUser() {
/* 220 */     return this.user;
/*     */   }
/*     */   
/*     */   public void setUser(String user) {
/* 224 */     this.user = user;
/*     */   }
/*     */   
/*     */   public String getPassword() {
/* 228 */     return this.password;
/*     */   }
/*     */   
/*     */   public void setPassword(String password) {
/* 232 */     this.password = password;
/*     */   }
/*     */   
/*     */   public String getDriverClassName() {
/* 236 */     return this.driverClassName;
/*     */   }
/*     */   
/*     */   public void setDriverClassName(String driverClassName) {
/* 240 */     this.driverClassName = driverClassName;
/*     */   }
/*     */   
/*     */   public String getUrl() {
/* 244 */     return this.url;
/*     */   }
/*     */   
/*     */   public void setUrl(String url) {
/* 248 */     this.url = url;
/*     */   }
/*     */   
/*     */   public String getLabels() {
/* 252 */     return this.labels;
/*     */   }
/*     */   
/*     */   public void setLabels(String labels) {
/* 256 */     this.labels = labels;
/*     */   }
/*     */   
/*     */   public Map<String, String> getParameters() {
/* 260 */     return this.parameters;
/*     */   }
/*     */   
/*     */   public void setParameters(Map<String, String> parameters) {
/* 264 */     this.parameters = parameters;
/*     */   }
/*     */   
/*     */   public File getRollbackFile() {
/* 268 */     return this.rollbackFile;
/*     */   }
/*     */   
/*     */   public void setRollbackFile(File rollbackFile) {
/* 272 */     this.rollbackFile = rollbackFile;
/*     */   }
/*     */   
/*     */   public boolean isTestRollbackOnUpdate() {
/* 276 */     return this.testRollbackOnUpdate;
/*     */   }
/*     */   
/*     */   public void setTestRollbackOnUpdate(boolean testRollbackOnUpdate) {
/* 280 */     this.testRollbackOnUpdate = testRollbackOnUpdate;
/*     */   }
/*     */   
/*     */   public String getTag() {
/* 284 */     return this.tag;
/*     */   }
/*     */   
/*     */   public void setTag(String tag) {
/* 288 */     this.tag = tag;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\liquibase\LiquibaseProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */