/*    */ package org.springframework.boot.autoconfigure.data.redis;
/*    */ 
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnSingleCandidate;
/*    */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.Import;
/*    */ import org.springframework.data.redis.connection.RedisConnectionFactory;
/*    */ import org.springframework.data.redis.core.RedisOperations;
/*    */ import org.springframework.data.redis.core.RedisTemplate;
/*    */ import org.springframework.data.redis.core.StringRedisTemplate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods=false)
/*    */ @ConditionalOnClass({RedisOperations.class})
/*    */ @EnableConfigurationProperties({RedisProperties.class})
/*    */ @Import({LettuceConnectionConfiguration.class, JedisConnectionConfiguration.class})
/*    */ public class RedisAutoConfiguration
/*    */ {
/*    */   @Bean
/*    */   @ConditionalOnMissingBean(name={"redisTemplate"})
/*    */   @ConditionalOnSingleCandidate(RedisConnectionFactory.class)
/*    */   public RedisTemplate<Object, Object> redisTemplate(RedisConnectionFactory redisConnectionFactory)
/*    */   {
/* 56 */     RedisTemplate<Object, Object> template = new RedisTemplate();
/* 57 */     template.setConnectionFactory(redisConnectionFactory);
/* 58 */     return template;
/*    */   }
/*    */   
/*    */   @Bean
/*    */   @ConditionalOnMissingBean
/*    */   @ConditionalOnSingleCandidate(RedisConnectionFactory.class)
/*    */   public StringRedisTemplate stringRedisTemplate(RedisConnectionFactory redisConnectionFactory) {
/* 65 */     StringRedisTemplate template = new StringRedisTemplate();
/* 66 */     template.setConnectionFactory(redisConnectionFactory);
/* 67 */     return template;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\data\redis\RedisAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */