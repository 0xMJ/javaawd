/*    */ package org.springframework.boot.autoconfigure.condition;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.springframework.boot.cloud.CloudPlatform;
/*    */ import org.springframework.context.annotation.ConditionContext;
/*    */ import org.springframework.core.env.Environment;
/*    */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class OnCloudPlatformCondition
/*    */   extends SpringBootCondition
/*    */ {
/*    */   public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata)
/*    */   {
/* 37 */     Map<String, Object> attributes = metadata.getAnnotationAttributes(ConditionalOnCloudPlatform.class.getName());
/* 38 */     CloudPlatform cloudPlatform = (CloudPlatform)attributes.get("value");
/* 39 */     return getMatchOutcome(context.getEnvironment(), cloudPlatform);
/*    */   }
/*    */   
/*    */   private ConditionOutcome getMatchOutcome(Environment environment, CloudPlatform cloudPlatform) {
/* 43 */     String name = cloudPlatform.name();
/* 44 */     ConditionMessage.Builder message = ConditionMessage.forCondition(ConditionalOnCloudPlatform.class, new Object[0]);
/* 45 */     if (cloudPlatform.isActive(environment)) {
/* 46 */       return ConditionOutcome.match(message.foundExactly(name));
/*    */     }
/* 48 */     return ConditionOutcome.noMatch(message.didNotFind(name).atAll());
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\condition\OnCloudPlatformCondition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */