/*     */ package org.springframework.boot.autoconfigure.mongo;
/*     */ 
/*     */ import com.mongodb.MongoClientSettings;
/*     */ import com.mongodb.MongoClientSettings.Builder;
/*     */ import com.mongodb.connection.netty.NettyStreamFactoryFactory;
/*     */ import com.mongodb.connection.netty.NettyStreamFactoryFactory.Builder;
/*     */ import com.mongodb.reactivestreams.client.MongoClient;
/*     */ import io.netty.channel.EventLoopGroup;
/*     */ import io.netty.channel.nio.NioEventLoopGroup;
/*     */ import io.netty.channel.socket.SocketChannel;
/*     */ import io.netty.util.concurrent.Future;
/*     */ import java.util.List;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.Stream;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.ObjectProvider;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.core.annotation.Order;
/*     */ import org.springframework.core.env.Environment;
/*     */ import reactor.core.publisher.Flux;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods=false)
/*     */ @ConditionalOnClass({MongoClient.class, Flux.class})
/*     */ @EnableConfigurationProperties({MongoProperties.class})
/*     */ public class MongoReactiveAutoConfiguration
/*     */ {
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   public MongoClient reactiveStreamsMongoClient(ObjectProvider<MongoClientSettingsBuilderCustomizer> builderCustomizers, MongoClientSettings settings)
/*     */   {
/*  60 */     ReactiveMongoClientFactory factory = new ReactiveMongoClientFactory((List)builderCustomizers.orderedStream().collect(Collectors.toList()));
/*  61 */     return (MongoClient)factory.createMongoClient(settings);
/*     */   }
/*     */   
/*     */   @Configuration(proxyBeanMethods=false)
/*     */   @ConditionalOnMissingBean({MongoClientSettings.class})
/*     */   static class MongoClientSettingsConfiguration
/*     */   {
/*     */     @Bean
/*     */     MongoClientSettings mongoClientSettings() {
/*  70 */       return MongoClientSettings.builder().build();
/*     */     }
/*     */     
/*     */     @Bean
/*     */     MongoPropertiesClientSettingsBuilderCustomizer mongoPropertiesCustomizer(MongoProperties properties, Environment environment)
/*     */     {
/*  76 */       return new MongoPropertiesClientSettingsBuilderCustomizer(properties, environment);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   @Configuration(proxyBeanMethods=false)
/*     */   @ConditionalOnClass({SocketChannel.class, NioEventLoopGroup.class})
/*     */   static class NettyDriverConfiguration
/*     */   {
/*     */     @Bean
/*     */     @Order(Integer.MIN_VALUE)
/*     */     MongoReactiveAutoConfiguration.NettyDriverMongoClientSettingsBuilderCustomizer nettyDriverCustomizer(ObjectProvider<MongoClientSettings> settings)
/*     */     {
/*  89 */       return new MongoReactiveAutoConfiguration.NettyDriverMongoClientSettingsBuilderCustomizer(settings, null);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static final class NettyDriverMongoClientSettingsBuilderCustomizer
/*     */     implements MongoClientSettingsBuilderCustomizer, DisposableBean
/*     */   {
/*     */     private final ObjectProvider<MongoClientSettings> settings;
/*     */     
/*     */     private volatile EventLoopGroup eventLoopGroup;
/*     */     
/*     */ 
/*     */     private NettyDriverMongoClientSettingsBuilderCustomizer(ObjectProvider<MongoClientSettings> settings)
/*     */     {
/* 105 */       this.settings = settings;
/*     */     }
/*     */     
/*     */     public void customize(MongoClientSettings.Builder builder)
/*     */     {
/* 110 */       if (!isStreamFactoryFactoryDefined((MongoClientSettings)this.settings.getIfAvailable())) {
/* 111 */         NioEventLoopGroup eventLoopGroup = new NioEventLoopGroup();
/* 112 */         this.eventLoopGroup = eventLoopGroup;
/* 113 */         builder.streamFactoryFactory(
/* 114 */           NettyStreamFactoryFactory.builder().eventLoopGroup(eventLoopGroup).build());
/*     */       }
/*     */     }
/*     */     
/*     */     public void destroy()
/*     */     {
/* 120 */       EventLoopGroup eventLoopGroup = this.eventLoopGroup;
/* 121 */       if (eventLoopGroup != null) {
/* 122 */         eventLoopGroup.shutdownGracefully().awaitUninterruptibly();
/* 123 */         this.eventLoopGroup = null;
/*     */       }
/*     */     }
/*     */     
/*     */     private boolean isStreamFactoryFactoryDefined(MongoClientSettings settings) {
/* 128 */       return (settings != null) && (settings.getStreamFactoryFactory() != null);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\mongo\MongoReactiveAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */