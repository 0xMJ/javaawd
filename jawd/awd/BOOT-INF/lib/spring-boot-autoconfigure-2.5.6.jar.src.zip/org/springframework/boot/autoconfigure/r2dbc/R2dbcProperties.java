/*     */ package org.springframework.boot.autoconfigure.r2dbc;
/*     */ 
/*     */ import io.r2dbc.spi.ValidationDepth;
/*     */ import java.time.Duration;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.UUID;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix="spring.r2dbc")
/*     */ public class R2dbcProperties
/*     */ {
/*     */   private String name;
/*     */   private boolean generateUniqueName;
/*     */   private String url;
/*     */   private String username;
/*     */   private String password;
/*  71 */   private final Map<String, String> properties = new LinkedHashMap();
/*     */   
/*  73 */   private final Pool pool = new Pool();
/*     */   private String uniqueName;
/*     */   
/*     */   public String getName()
/*     */   {
/*  78 */     return this.name;
/*     */   }
/*     */   
/*     */   public void setName(String name) {
/*  82 */     this.name = name;
/*     */   }
/*     */   
/*     */   public boolean isGenerateUniqueName() {
/*  86 */     return this.generateUniqueName;
/*     */   }
/*     */   
/*     */   public void setGenerateUniqueName(boolean generateUniqueName) {
/*  90 */     this.generateUniqueName = generateUniqueName;
/*     */   }
/*     */   
/*     */   public String getUrl() {
/*  94 */     return this.url;
/*     */   }
/*     */   
/*     */   public void setUrl(String url) {
/*  98 */     this.url = url;
/*     */   }
/*     */   
/*     */   public String getUsername() {
/* 102 */     return this.username;
/*     */   }
/*     */   
/*     */   public void setUsername(String username) {
/* 106 */     this.username = username;
/*     */   }
/*     */   
/*     */   public String getPassword() {
/* 110 */     return this.password;
/*     */   }
/*     */   
/*     */   public void setPassword(String password) {
/* 114 */     this.password = password;
/*     */   }
/*     */   
/*     */   public Map<String, String> getProperties() {
/* 118 */     return this.properties;
/*     */   }
/*     */   
/*     */   public Pool getPool() {
/* 122 */     return this.pool;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String determineUniqueName()
/*     */   {
/* 131 */     if (this.uniqueName == null) {
/* 132 */       this.uniqueName = UUID.randomUUID().toString();
/*     */     }
/* 134 */     return this.uniqueName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Pool
/*     */   {
/* 142 */     private Duration maxIdleTime = Duration.ofMinutes(30L);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private Duration maxLifeTime;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private Duration maxAcquireTime;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private Duration maxCreateConnectionTime;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 164 */     private int initialSize = 10;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 169 */     private int maxSize = 10;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private String validationQuery;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 179 */     private ValidationDepth validationDepth = ValidationDepth.LOCAL;
/*     */     
/*     */     public Duration getMaxIdleTime() {
/* 182 */       return this.maxIdleTime;
/*     */     }
/*     */     
/*     */     public void setMaxIdleTime(Duration maxIdleTime) {
/* 186 */       this.maxIdleTime = maxIdleTime;
/*     */     }
/*     */     
/*     */     public Duration getMaxLifeTime() {
/* 190 */       return this.maxLifeTime;
/*     */     }
/*     */     
/*     */     public void setMaxLifeTime(Duration maxLifeTime) {
/* 194 */       this.maxLifeTime = maxLifeTime;
/*     */     }
/*     */     
/*     */     public Duration getMaxAcquireTime() {
/* 198 */       return this.maxAcquireTime;
/*     */     }
/*     */     
/*     */     public void setMaxAcquireTime(Duration maxAcquireTime) {
/* 202 */       this.maxAcquireTime = maxAcquireTime;
/*     */     }
/*     */     
/*     */     public Duration getMaxCreateConnectionTime() {
/* 206 */       return this.maxCreateConnectionTime;
/*     */     }
/*     */     
/*     */     public void setMaxCreateConnectionTime(Duration maxCreateConnectionTime) {
/* 210 */       this.maxCreateConnectionTime = maxCreateConnectionTime;
/*     */     }
/*     */     
/*     */     public int getInitialSize() {
/* 214 */       return this.initialSize;
/*     */     }
/*     */     
/*     */     public void setInitialSize(int initialSize) {
/* 218 */       this.initialSize = initialSize;
/*     */     }
/*     */     
/*     */     public int getMaxSize() {
/* 222 */       return this.maxSize;
/*     */     }
/*     */     
/*     */     public void setMaxSize(int maxSize) {
/* 226 */       this.maxSize = maxSize;
/*     */     }
/*     */     
/*     */     public String getValidationQuery() {
/* 230 */       return this.validationQuery;
/*     */     }
/*     */     
/*     */     public void setValidationQuery(String validationQuery) {
/* 234 */       this.validationQuery = validationQuery;
/*     */     }
/*     */     
/*     */     public ValidationDepth getValidationDepth() {
/* 238 */       return this.validationDepth;
/*     */     }
/*     */     
/*     */     public void setValidationDepth(ValidationDepth validationDepth) {
/* 242 */       this.validationDepth = validationDepth;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\r2dbc\R2dbcProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */