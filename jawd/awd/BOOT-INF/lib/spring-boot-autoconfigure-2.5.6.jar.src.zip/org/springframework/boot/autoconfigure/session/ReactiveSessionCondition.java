/*    */ package org.springframework.boot.autoconfigure.session;
/*    */ 
/*    */ import org.springframework.boot.WebApplicationType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ReactiveSessionCondition
/*    */   extends AbstractSessionCondition
/*    */ {
/*    */   ReactiveSessionCondition()
/*    */   {
/* 29 */     super(WebApplicationType.REACTIVE);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\session\ReactiveSessionCondition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */