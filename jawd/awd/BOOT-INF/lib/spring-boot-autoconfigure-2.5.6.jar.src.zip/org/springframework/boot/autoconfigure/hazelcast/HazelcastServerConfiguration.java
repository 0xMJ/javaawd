/*     */ package org.springframework.boot.autoconfigure.hazelcast;
/*     */ 
/*     */ import com.hazelcast.config.Config;
/*     */ import com.hazelcast.config.XmlConfigBuilder;
/*     */ import com.hazelcast.config.YamlConfigBuilder;
/*     */ import com.hazelcast.core.Hazelcast;
/*     */ import com.hazelcast.core.HazelcastInstance;
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnSingleCandidate;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Conditional;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.util.ResourceUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods=false)
/*     */ @ConditionalOnMissingBean({HazelcastInstance.class})
/*     */ class HazelcastServerConfiguration
/*     */ {
/*     */   static final String CONFIG_SYSTEM_PROPERTY = "hazelcast.config";
/*     */   
/*     */   private static HazelcastInstance getHazelcastInstance(Config config)
/*     */   {
/*  51 */     if (StringUtils.hasText(config.getInstanceName())) {
/*  52 */       return Hazelcast.getOrCreateHazelcastInstance(config);
/*     */     }
/*  54 */     return Hazelcast.newHazelcastInstance(config);
/*     */   }
/*     */   
/*     */   @Configuration(proxyBeanMethods=false)
/*     */   @ConditionalOnMissingBean({Config.class})
/*     */   @Conditional({HazelcastServerConfiguration.ConfigAvailableCondition.class})
/*     */   static class HazelcastServerConfigFileConfiguration
/*     */   {
/*     */     @Bean
/*     */     HazelcastInstance hazelcastInstance(HazelcastProperties properties, ResourceLoader resourceLoader) throws IOException
/*     */     {
/*  65 */       Resource configLocation = properties.resolveConfigLocation();
/*  66 */       Config config = configLocation != null ? loadConfig(configLocation) : Config.load();
/*  67 */       config.setClassLoader(resourceLoader.getClassLoader());
/*  68 */       return HazelcastServerConfiguration.getHazelcastInstance(config);
/*     */     }
/*     */     
/*     */     private Config loadConfig(Resource configLocation) throws IOException {
/*  72 */       URL configUrl = configLocation.getURL();
/*  73 */       Config config = loadConfig(configUrl);
/*  74 */       if (ResourceUtils.isFileURL(configUrl)) {
/*  75 */         config.setConfigurationFile(configLocation.getFile());
/*     */       }
/*     */       else {
/*  78 */         config.setConfigurationUrl(configUrl);
/*     */       }
/*  80 */       return config;
/*     */     }
/*     */     
/*     */     private static Config loadConfig(URL configUrl) throws IOException {
/*  84 */       String configFileName = configUrl.getPath();
/*  85 */       if (configFileName.endsWith(".yaml")) {
/*  86 */         return new YamlConfigBuilder(configUrl).build();
/*     */       }
/*  88 */       return new XmlConfigBuilder(configUrl).build();
/*     */     }
/*     */   }
/*     */   
/*     */   @Configuration(proxyBeanMethods=false)
/*     */   @ConditionalOnSingleCandidate(Config.class)
/*     */   static class HazelcastServerConfigConfiguration
/*     */   {
/*     */     @Bean
/*     */     HazelcastInstance hazelcastInstance(Config config)
/*     */     {
/*  99 */       return HazelcastServerConfiguration.getHazelcastInstance(config);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static class ConfigAvailableCondition
/*     */     extends HazelcastConfigResourceCondition
/*     */   {
/*     */     ConfigAvailableCondition()
/*     */     {
/* 111 */       super(new String[] { "file:./hazelcast.xml", "classpath:/hazelcast.xml", "file:./hazelcast.yaml", "classpath:/hazelcast.yaml" });
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\hazelcast\HazelcastServerConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */