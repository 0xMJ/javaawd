/*     */ package org.springframework.boot.autoconfigure.cassandra;
/*     */ 
/*     */ import com.datastax.oss.driver.api.core.DefaultConsistencyLevel;
/*     */ import java.time.Duration;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.core.io.Resource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix="spring.data.cassandra")
/*     */ public class CassandraProperties
/*     */ {
/*     */   private Resource config;
/*     */   private String keyspaceName;
/*     */   private String sessionName;
/*  60 */   private final List<String> contactPoints = new ArrayList(Collections.singleton("127.0.0.1:9042"));
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  65 */   private int port = 9042;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String localDatacenter;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String username;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String password;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  86 */   private Compression compression = Compression.NONE;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  91 */   private String schemaAction = "none";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  96 */   private boolean ssl = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 101 */   private final Connection connection = new Connection();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 106 */   private final Pool pool = new Pool();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 111 */   private final Request request = new Request();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 116 */   private final Controlconnection controlconnection = new Controlconnection();
/*     */   
/*     */   public Resource getConfig() {
/* 119 */     return this.config;
/*     */   }
/*     */   
/*     */   public void setConfig(Resource config) {
/* 123 */     this.config = config;
/*     */   }
/*     */   
/*     */   public String getKeyspaceName() {
/* 127 */     return this.keyspaceName;
/*     */   }
/*     */   
/*     */   public void setKeyspaceName(String keyspaceName) {
/* 131 */     this.keyspaceName = keyspaceName;
/*     */   }
/*     */   
/*     */   public String getSessionName() {
/* 135 */     return this.sessionName;
/*     */   }
/*     */   
/*     */   public void setSessionName(String sessionName) {
/* 139 */     this.sessionName = sessionName;
/*     */   }
/*     */   
/*     */   public List<String> getContactPoints() {
/* 143 */     return this.contactPoints;
/*     */   }
/*     */   
/*     */   public int getPort() {
/* 147 */     return this.port;
/*     */   }
/*     */   
/*     */   public void setPort(int port) {
/* 151 */     this.port = port;
/*     */   }
/*     */   
/*     */   public String getLocalDatacenter() {
/* 155 */     return this.localDatacenter;
/*     */   }
/*     */   
/*     */   public void setLocalDatacenter(String localDatacenter) {
/* 159 */     this.localDatacenter = localDatacenter;
/*     */   }
/*     */   
/*     */   public String getUsername() {
/* 163 */     return this.username;
/*     */   }
/*     */   
/*     */   public void setUsername(String username) {
/* 167 */     this.username = username;
/*     */   }
/*     */   
/*     */   public String getPassword() {
/* 171 */     return this.password;
/*     */   }
/*     */   
/*     */   public void setPassword(String password) {
/* 175 */     this.password = password;
/*     */   }
/*     */   
/*     */   public Compression getCompression() {
/* 179 */     return this.compression;
/*     */   }
/*     */   
/*     */   public void setCompression(Compression compression) {
/* 183 */     this.compression = compression;
/*     */   }
/*     */   
/*     */   public boolean isSsl() {
/* 187 */     return this.ssl;
/*     */   }
/*     */   
/*     */   public void setSsl(boolean ssl) {
/* 191 */     this.ssl = ssl;
/*     */   }
/*     */   
/*     */   public String getSchemaAction() {
/* 195 */     return this.schemaAction;
/*     */   }
/*     */   
/*     */   public void setSchemaAction(String schemaAction) {
/* 199 */     this.schemaAction = schemaAction;
/*     */   }
/*     */   
/*     */   public Connection getConnection() {
/* 203 */     return this.connection;
/*     */   }
/*     */   
/*     */   public Pool getPool() {
/* 207 */     return this.pool;
/*     */   }
/*     */   
/*     */   public Request getRequest() {
/* 211 */     return this.request;
/*     */   }
/*     */   
/*     */   public Controlconnection getControlconnection() {
/* 215 */     return this.controlconnection;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Connection
/*     */   {
/*     */     private Duration connectTimeout;
/*     */     
/*     */ 
/*     */     private Duration initQueryTimeout;
/*     */     
/*     */ 
/*     */ 
/*     */     public Duration getConnectTimeout()
/*     */     {
/* 232 */       return this.connectTimeout;
/*     */     }
/*     */     
/*     */     public void setConnectTimeout(Duration connectTimeout) {
/* 236 */       this.connectTimeout = connectTimeout;
/*     */     }
/*     */     
/*     */     public Duration getInitQueryTimeout() {
/* 240 */       return this.initQueryTimeout;
/*     */     }
/*     */     
/*     */     public void setInitQueryTimeout(Duration initQueryTimeout) {
/* 244 */       this.initQueryTimeout = initQueryTimeout;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Request
/*     */   {
/*     */     private Duration timeout;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private DefaultConsistencyLevel consistency;
/*     */     
/*     */ 
/*     */ 
/*     */     private DefaultConsistencyLevel serialConsistency;
/*     */     
/*     */ 
/*     */ 
/*     */     private int pageSize;
/*     */     
/*     */ 
/*     */ 
/* 271 */     private final CassandraProperties.Throttler throttler = new CassandraProperties.Throttler();
/*     */     
/*     */     public Duration getTimeout() {
/* 274 */       return this.timeout;
/*     */     }
/*     */     
/*     */     public void setTimeout(Duration timeout) {
/* 278 */       this.timeout = timeout;
/*     */     }
/*     */     
/*     */     public DefaultConsistencyLevel getConsistency() {
/* 282 */       return this.consistency;
/*     */     }
/*     */     
/*     */     public void setConsistency(DefaultConsistencyLevel consistency) {
/* 286 */       this.consistency = consistency;
/*     */     }
/*     */     
/*     */     public DefaultConsistencyLevel getSerialConsistency() {
/* 290 */       return this.serialConsistency;
/*     */     }
/*     */     
/*     */     public void setSerialConsistency(DefaultConsistencyLevel serialConsistency) {
/* 294 */       this.serialConsistency = serialConsistency;
/*     */     }
/*     */     
/*     */     public int getPageSize() {
/* 298 */       return this.pageSize;
/*     */     }
/*     */     
/*     */     public void setPageSize(int pageSize) {
/* 302 */       this.pageSize = pageSize;
/*     */     }
/*     */     
/*     */     public CassandraProperties.Throttler getThrottler() {
/* 306 */       return this.throttler;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Pool
/*     */   {
/*     */     private Duration idleTimeout;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private Duration heartbeatInterval;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public Duration getIdleTimeout()
/*     */     {
/* 328 */       return this.idleTimeout;
/*     */     }
/*     */     
/*     */     public void setIdleTimeout(Duration idleTimeout) {
/* 332 */       this.idleTimeout = idleTimeout;
/*     */     }
/*     */     
/*     */     public Duration getHeartbeatInterval() {
/* 336 */       return this.heartbeatInterval;
/*     */     }
/*     */     
/*     */     public void setHeartbeatInterval(Duration heartbeatInterval) {
/* 340 */       this.heartbeatInterval = heartbeatInterval;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Controlconnection
/*     */   {
/* 350 */     private Duration timeout = Duration.ofSeconds(5L);
/*     */     
/*     */     public Duration getTimeout() {
/* 353 */       return this.timeout;
/*     */     }
/*     */     
/*     */     public void setTimeout(Duration timeout) {
/* 357 */       this.timeout = timeout;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Throttler
/*     */   {
/*     */     private CassandraProperties.ThrottlerType type;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private int maxQueueSize;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private int maxConcurrentRequests;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private int maxRequestsPerSecond;
/*     */     
/*     */ 
/*     */ 
/*     */     private Duration drainInterval;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public CassandraProperties.ThrottlerType getType()
/*     */     {
/* 393 */       return this.type;
/*     */     }
/*     */     
/*     */     public void setType(CassandraProperties.ThrottlerType type) {
/* 397 */       this.type = type;
/*     */     }
/*     */     
/*     */     public int getMaxQueueSize() {
/* 401 */       return this.maxQueueSize;
/*     */     }
/*     */     
/*     */     public void setMaxQueueSize(int maxQueueSize) {
/* 405 */       this.maxQueueSize = maxQueueSize;
/*     */     }
/*     */     
/*     */     public int getMaxConcurrentRequests() {
/* 409 */       return this.maxConcurrentRequests;
/*     */     }
/*     */     
/*     */     public void setMaxConcurrentRequests(int maxConcurrentRequests) {
/* 413 */       this.maxConcurrentRequests = maxConcurrentRequests;
/*     */     }
/*     */     
/*     */     public int getMaxRequestsPerSecond() {
/* 417 */       return this.maxRequestsPerSecond;
/*     */     }
/*     */     
/*     */     public void setMaxRequestsPerSecond(int maxRequestsPerSecond) {
/* 421 */       this.maxRequestsPerSecond = maxRequestsPerSecond;
/*     */     }
/*     */     
/*     */     public Duration getDrainInterval() {
/* 425 */       return this.drainInterval;
/*     */     }
/*     */     
/*     */     public void setDrainInterval(Duration drainInterval) {
/* 429 */       this.drainInterval = drainInterval;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static enum Compression
/*     */   {
/* 442 */     LZ4, 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 447 */     SNAPPY, 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 452 */     NONE;
/*     */     
/*     */ 
/*     */     private Compression() {}
/*     */   }
/*     */   
/*     */ 
/*     */   public static enum ThrottlerType
/*     */   {
/* 461 */     CONCURRENCY_LIMITING("ConcurrencyLimitingRequestThrottler"), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 466 */     RATE_LIMITING("RateLimitingRequestThrottler"), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 471 */     NONE("PassThroughRequestThrottler");
/*     */     
/*     */     private final String type;
/*     */     
/*     */     private ThrottlerType(String type) {
/* 476 */       this.type = type;
/*     */     }
/*     */     
/*     */     public String type() {
/* 480 */       return this.type;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\cassandra\CassandraProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */