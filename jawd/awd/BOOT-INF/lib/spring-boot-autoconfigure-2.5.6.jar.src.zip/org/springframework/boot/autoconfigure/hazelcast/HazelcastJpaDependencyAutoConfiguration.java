/*    */ package org.springframework.boot.autoconfigure.hazelcast;
/*    */ 
/*    */ import com.hazelcast.core.HazelcastInstance;
/*    */ import org.springframework.boot.autoconfigure.AutoConfigureAfter;
/*    */ import org.springframework.boot.autoconfigure.condition.AllNestedConditions;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.orm.jpa.EntityManagerFactoryDependsOnPostProcessor;
/*    */ import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
/*    */ import org.springframework.context.annotation.Conditional;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.ConfigurationCondition.ConfigurationPhase;
/*    */ import org.springframework.context.annotation.Import;
/*    */ import org.springframework.orm.jpa.AbstractEntityManagerFactoryBean;
/*    */ import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods=false)
/*    */ @ConditionalOnClass({HazelcastInstance.class, LocalContainerEntityManagerFactoryBean.class})
/*    */ @AutoConfigureAfter({HazelcastAutoConfiguration.class, HibernateJpaAutoConfiguration.class})
/*    */ @Import({HazelcastInstanceEntityManagerFactoryDependsOnPostProcessor.class})
/*    */ public class HazelcastJpaDependencyAutoConfiguration
/*    */ {
/*    */   @Conditional({HazelcastJpaDependencyAutoConfiguration.OnHazelcastAndJpaCondition.class})
/*    */   static class HazelcastInstanceEntityManagerFactoryDependsOnPostProcessor
/*    */     extends EntityManagerFactoryDependsOnPostProcessor
/*    */   {
/*    */     HazelcastInstanceEntityManagerFactoryDependsOnPostProcessor()
/*    */     {
/* 54 */       super();
/*    */     }
/*    */   }
/*    */   
/*    */   static class OnHazelcastAndJpaCondition extends AllNestedConditions
/*    */   {
/*    */     OnHazelcastAndJpaCondition()
/*    */     {
/* 62 */       super();
/*    */     }
/*    */     
/*    */     @ConditionalOnBean({AbstractEntityManagerFactoryBean.class})
/*    */     static class HasJpa {}
/*    */     
/*    */     @ConditionalOnBean(name={"hazelcastInstance"})
/*    */     static class HasHazelcastInstance {}
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\hazelcast\HazelcastJpaDependencyAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */