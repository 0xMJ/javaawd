/*    */ package org.springframework.boot.autoconfigure.data.couchbase;
/*    */ 
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnSingleCandidate;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.data.couchbase.CouchbaseClientFactory;
/*    */ import org.springframework.data.couchbase.core.ReactiveCouchbaseTemplate;
/*    */ import org.springframework.data.couchbase.core.convert.MappingCouchbaseConverter;
/*    */ import org.springframework.data.couchbase.repository.config.ReactiveRepositoryOperationsMapping;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods=false)
/*    */ @ConditionalOnSingleCandidate(CouchbaseClientFactory.class)
/*    */ class CouchbaseReactiveDataConfiguration
/*    */ {
/*    */   @Bean(name={"reactiveCouchbaseTemplate"})
/*    */   @ConditionalOnMissingBean(name={"reactiveCouchbaseTemplate"})
/*    */   ReactiveCouchbaseTemplate reactiveCouchbaseTemplate(CouchbaseClientFactory couchbaseClientFactory, MappingCouchbaseConverter mappingCouchbaseConverter)
/*    */   {
/* 42 */     return new ReactiveCouchbaseTemplate(couchbaseClientFactory, mappingCouchbaseConverter);
/*    */   }
/*    */   
/*    */   @Bean(name={"reactiveCouchbaseRepositoryOperationsMapping"})
/*    */   @ConditionalOnMissingBean(name={"reactiveCouchbaseRepositoryOperationsMapping"})
/*    */   ReactiveRepositoryOperationsMapping reactiveCouchbaseRepositoryOperationsMapping(ReactiveCouchbaseTemplate reactiveCouchbaseTemplate)
/*    */   {
/* 49 */     return new ReactiveRepositoryOperationsMapping(reactiveCouchbaseTemplate);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\data\couchbase\CouchbaseReactiveDataConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */