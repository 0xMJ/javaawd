package org.springframework.boot.autoconfigure.orm.jpa;

import java.util.Map;

@FunctionalInterface
public abstract interface HibernatePropertiesCustomizer
{
  public abstract void customize(Map<String, Object> paramMap);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\orm\jpa\HibernatePropertiesCustomizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */