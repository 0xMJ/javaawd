/*    */ package org.springframework.boot.autoconfigure.batch;
/*    */ 
/*    */ import javax.persistence.EntityManagerFactory;
/*    */ import javax.sql.DataSource;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.boot.autoconfigure.transaction.TransactionManagerCustomizers;
/*    */ import org.springframework.orm.jpa.JpaTransactionManager;
/*    */ import org.springframework.transaction.PlatformTransactionManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JpaBatchConfigurer
/*    */   extends BasicBatchConfigurer
/*    */ {
/* 37 */   private static final Log logger = LogFactory.getLog(JpaBatchConfigurer.class);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private final EntityManagerFactory entityManagerFactory;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected JpaBatchConfigurer(BatchProperties properties, DataSource dataSource, TransactionManagerCustomizers transactionManagerCustomizers, EntityManagerFactory entityManagerFactory)
/*    */   {
/* 51 */     super(properties, dataSource, transactionManagerCustomizers);
/* 52 */     this.entityManagerFactory = entityManagerFactory;
/*    */   }
/*    */   
/*    */   protected String determineIsolationLevel()
/*    */   {
/* 57 */     logger.warn("JPA does not support custom isolation levels, so locks may not be taken when launching Jobs");
/* 58 */     return "ISOLATION_DEFAULT";
/*    */   }
/*    */   
/*    */   protected PlatformTransactionManager createTransactionManager()
/*    */   {
/* 63 */     return new JpaTransactionManager(this.entityManagerFactory);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\batch\JpaBatchConfigurer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */