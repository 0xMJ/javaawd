/*    */ package org.springframework.boot.autoconfigure.freemarker;
/*    */ 
/*    */ import java.util.Properties;
/*    */ import org.springframework.ui.freemarker.FreeMarkerConfigurationFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class AbstractFreeMarkerConfiguration
/*    */ {
/*    */   private final FreeMarkerProperties properties;
/*    */   
/*    */   protected AbstractFreeMarkerConfiguration(FreeMarkerProperties properties)
/*    */   {
/* 33 */     this.properties = properties;
/*    */   }
/*    */   
/*    */   protected final FreeMarkerProperties getProperties() {
/* 37 */     return this.properties;
/*    */   }
/*    */   
/*    */   protected void applyProperties(FreeMarkerConfigurationFactory factory) {
/* 41 */     factory.setTemplateLoaderPaths(this.properties.getTemplateLoaderPath());
/* 42 */     factory.setPreferFileSystemAccess(this.properties.isPreferFileSystemAccess());
/* 43 */     factory.setDefaultEncoding(this.properties.getCharsetName());
/* 44 */     Properties settings = new Properties();
/* 45 */     settings.put("recognize_standard_file_extensions", "true");
/* 46 */     settings.putAll(this.properties.getSettings());
/* 47 */     factory.setFreemarkerSettings(settings);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\freemarker\AbstractFreeMarkerConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */