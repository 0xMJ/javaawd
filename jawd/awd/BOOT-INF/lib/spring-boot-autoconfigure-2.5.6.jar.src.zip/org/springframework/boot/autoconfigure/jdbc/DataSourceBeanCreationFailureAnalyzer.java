/*    */ package org.springframework.boot.autoconfigure.jdbc;
/*    */ 
/*    */ import org.springframework.boot.diagnostics.AbstractFailureAnalyzer;
/*    */ import org.springframework.boot.diagnostics.FailureAnalysis;
/*    */ import org.springframework.boot.jdbc.EmbeddedDatabaseConnection;
/*    */ import org.springframework.context.EnvironmentAware;
/*    */ import org.springframework.core.env.Environment;
/*    */ import org.springframework.util.ObjectUtils;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class DataSourceBeanCreationFailureAnalyzer
/*    */   extends AbstractFailureAnalyzer<DataSourceProperties.DataSourceBeanCreationException>
/*    */   implements EnvironmentAware
/*    */ {
/*    */   private Environment environment;
/*    */   
/*    */   public void setEnvironment(Environment environment)
/*    */   {
/* 43 */     this.environment = environment;
/*    */   }
/*    */   
/*    */   protected FailureAnalysis analyze(Throwable rootFailure, DataSourceProperties.DataSourceBeanCreationException cause)
/*    */   {
/* 48 */     return getFailureAnalysis(cause);
/*    */   }
/*    */   
/*    */   private FailureAnalysis getFailureAnalysis(DataSourceProperties.DataSourceBeanCreationException cause) {
/* 52 */     String description = getDescription(cause);
/* 53 */     String action = getAction(cause);
/* 54 */     return new FailureAnalysis(description, action, cause);
/*    */   }
/*    */   
/*    */   private String getDescription(DataSourceProperties.DataSourceBeanCreationException cause) {
/* 58 */     StringBuilder description = new StringBuilder();
/* 59 */     description.append("Failed to configure a DataSource: ");
/* 60 */     if (!StringUtils.hasText(cause.getProperties().getUrl())) {
/* 61 */       description.append("'url' attribute is not specified and ");
/*    */     }
/* 63 */     description.append(String.format("no embedded datasource could be configured.%n", new Object[0]));
/* 64 */     description.append(String.format("%nReason: %s%n", new Object[] { cause.getMessage() }));
/* 65 */     return description.toString();
/*    */   }
/*    */   
/*    */   private String getAction(DataSourceProperties.DataSourceBeanCreationException cause) {
/* 69 */     StringBuilder action = new StringBuilder();
/* 70 */     action.append(String.format("Consider the following:%n", new Object[0]));
/* 71 */     if (EmbeddedDatabaseConnection.NONE == cause.getConnection()) {
/* 72 */       action.append(String.format("\tIf you want an embedded database (H2, HSQL or Derby), please put it on the classpath.%n", new Object[0]));
/*    */     }
/*    */     else
/*    */     {
/* 76 */       action.append(String.format("\tReview the configuration of %s%n.", new Object[] { cause.getConnection() }));
/*    */     }
/*    */     
/* 79 */     action.append("\tIf you have database settings to be loaded from a particular profile you may need to activate it").append(getActiveProfiles());
/* 80 */     return action.toString();
/*    */   }
/*    */   
/*    */   private String getActiveProfiles() {
/* 84 */     StringBuilder message = new StringBuilder();
/* 85 */     String[] profiles = this.environment.getActiveProfiles();
/* 86 */     if (ObjectUtils.isEmpty(profiles)) {
/* 87 */       message.append(" (no profiles are currently active).");
/*    */     }
/*    */     else {
/* 90 */       message.append(" (the profiles ");
/* 91 */       message.append(StringUtils.arrayToCommaDelimitedString(profiles));
/* 92 */       message.append(" are currently active).");
/*    */     }
/* 94 */     return message.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\jdbc\DataSourceBeanCreationFailureAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */