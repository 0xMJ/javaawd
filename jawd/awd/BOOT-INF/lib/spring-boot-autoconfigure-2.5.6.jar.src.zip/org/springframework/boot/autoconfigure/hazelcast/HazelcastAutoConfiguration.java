/*    */ package org.springframework.boot.autoconfigure.hazelcast;
/*    */ 
/*    */ import com.hazelcast.core.HazelcastInstance;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionMessage;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionMessage.Builder;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionOutcome;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.SpringBootCondition;
/*    */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*    */ import org.springframework.context.annotation.ConditionContext;
/*    */ import org.springframework.context.annotation.Conditional;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.Import;
/*    */ import org.springframework.core.io.Resource;
/*    */ import org.springframework.core.io.ResourceLoader;
/*    */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods=false)
/*    */ @Conditional({HazelcastDataGridCondition.class})
/*    */ @ConditionalOnClass({HazelcastInstance.class})
/*    */ @EnableConfigurationProperties({HazelcastProperties.class})
/*    */ @Import({HazelcastClientConfiguration.class, HazelcastServerConfiguration.class})
/*    */ public class HazelcastAutoConfiguration
/*    */ {
/*    */   static class HazelcastDataGridCondition
/*    */     extends SpringBootCondition
/*    */   {
/*    */     private static final String HAZELCAST_JET_CONFIG_FILE = "classpath:/hazelcast-jet-default.yaml";
/*    */     
/*    */     public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata)
/*    */     {
/* 59 */       ConditionMessage.Builder message = ConditionMessage.forCondition(HazelcastDataGridCondition.class.getSimpleName(), new Object[0]);
/* 60 */       Resource resource = context.getResourceLoader().getResource("classpath:/hazelcast-jet-default.yaml");
/* 61 */       if (resource.exists()) {
/* 62 */         return ConditionOutcome.noMatch(message.because("Found Hazelcast Jet on the classpath"));
/*    */       }
/* 64 */       return ConditionOutcome.match(message.because("Hazelcast Jet not found on the classpath"));
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\hazelcast\HazelcastAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */