/*     */ package org.springframework.boot.autoconfigure.integration;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.springframework.boot.SpringApplication;
/*     */ import org.springframework.boot.env.EnvironmentPostProcessor;
/*     */ import org.springframework.boot.env.OriginTrackedMapPropertySource;
/*     */ import org.springframework.boot.env.PropertiesPropertySourceLoader;
/*     */ import org.springframework.boot.origin.Origin;
/*     */ import org.springframework.boot.origin.OriginLookup;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.core.env.MutablePropertySources;
/*     */ import org.springframework.core.env.PropertySource;
/*     */ import org.springframework.core.io.ClassPathResource;
/*     */ import org.springframework.core.io.Resource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class IntegrationPropertiesEnvironmentPostProcessor
/*     */   implements EnvironmentPostProcessor, Ordered
/*     */ {
/*     */   public int getOrder()
/*     */   {
/*  48 */     return Integer.MAX_VALUE;
/*     */   }
/*     */   
/*     */   public void postProcessEnvironment(ConfigurableEnvironment environment, SpringApplication application)
/*     */   {
/*  53 */     Resource resource = new ClassPathResource("META-INF/spring.integration.properties");
/*  54 */     if (resource.exists()) {
/*  55 */       registerIntegrationPropertiesPropertySource(environment, resource);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void registerIntegrationPropertiesPropertySource(ConfigurableEnvironment environment, Resource resource) {
/*  60 */     PropertiesPropertySourceLoader loader = new PropertiesPropertySourceLoader();
/*     */     try
/*     */     {
/*  63 */       OriginTrackedMapPropertySource propertyFileSource = (OriginTrackedMapPropertySource)loader.load("META-INF/spring.integration.properties", resource).get(0);
/*  64 */       environment.getPropertySources().addLast(new IntegrationPropertiesPropertySource(propertyFileSource));
/*     */     }
/*     */     catch (IOException ex) {
/*  67 */       throw new IllegalStateException("Failed to load integration properties from " + resource, ex);
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class IntegrationPropertiesPropertySource extends PropertySource<Map<String, Object>> implements OriginLookup<String>
/*     */   {
/*     */     private static final String PREFIX = "spring.integration.";
/*     */     private static final Map<String, String> KEYS_MAPPING;
/*     */     private final OriginTrackedMapPropertySource delegate;
/*     */     
/*     */     static
/*     */     {
/*  79 */       Map<String, String> mappings = new HashMap();
/*  80 */       mappings.put("spring.integration.channel.auto-create", "spring.integration.channels.autoCreate");
/*  81 */       mappings.put("spring.integration.channel.max-unicast-subscribers", "spring.integration.channels.maxUnicastSubscribers");
/*     */       
/*  83 */       mappings.put("spring.integration.channel.max-broadcast-subscribers", "spring.integration.channels.maxBroadcastSubscribers");
/*     */       
/*  85 */       mappings.put("spring.integration.error.require-subscribers", "spring.integration.channels.error.requireSubscribers");
/*  86 */       mappings.put("spring.integration.error.ignore-failures", "spring.integration.channels.error.ignoreFailures");
/*  87 */       mappings.put("spring.integration.endpoint.throw-exception-on-late-reply", "spring.integration.messagingTemplate.throwExceptionOnLateReply");
/*     */       
/*  89 */       mappings.put("spring.integration.endpoint.read-only-headers", "spring.integration.readOnly.headers");
/*  90 */       mappings.put("spring.integration.endpoint.no-auto-startup", "spring.integration.endpoints.noAutoStartup");
/*  91 */       KEYS_MAPPING = Collections.unmodifiableMap(mappings);
/*     */     }
/*     */     
/*     */ 
/*     */     IntegrationPropertiesPropertySource(OriginTrackedMapPropertySource delegate)
/*     */     {
/*  97 */       super(delegate.getSource());
/*  98 */       this.delegate = delegate;
/*     */     }
/*     */     
/*     */     public Object getProperty(String name)
/*     */     {
/* 103 */       return this.delegate.getProperty((String)KEYS_MAPPING.get(name));
/*     */     }
/*     */     
/*     */     public Origin getOrigin(String key)
/*     */     {
/* 108 */       return this.delegate.getOrigin((String)KEYS_MAPPING.get(key));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\integration\IntegrationPropertiesEnvironmentPostProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */