/*     */ package org.springframework.boot.autoconfigure.security.oauth2.resource;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.boot.context.properties.source.InvalidConfigurationPropertyValueException;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StreamUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix="spring.security.oauth2.resourceserver")
/*     */ public class OAuth2ResourceServerProperties
/*     */ {
/*  39 */   private final Jwt jwt = new Jwt();
/*     */   
/*     */   public Jwt getJwt() {
/*  42 */     return this.jwt;
/*     */   }
/*     */   
/*  45 */   private final Opaquetoken opaqueToken = new Opaquetoken();
/*     */   
/*     */   public Opaquetoken getOpaquetoken() {
/*  48 */     return this.opaqueToken;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Jwt
/*     */   {
/*     */     private String jwkSetUri;
/*     */     
/*     */ 
/*     */ 
/*  61 */     private String jwsAlgorithm = "RS256";
/*     */     
/*     */ 
/*     */ 
/*     */     private String issuerUri;
/*     */     
/*     */ 
/*     */ 
/*     */     private Resource publicKeyLocation;
/*     */     
/*     */ 
/*     */ 
/*     */     public String getJwkSetUri()
/*     */     {
/*  75 */       return this.jwkSetUri;
/*     */     }
/*     */     
/*     */     public void setJwkSetUri(String jwkSetUri) {
/*  79 */       this.jwkSetUri = jwkSetUri;
/*     */     }
/*     */     
/*     */     public String getJwsAlgorithm() {
/*  83 */       return this.jwsAlgorithm;
/*     */     }
/*     */     
/*     */     public void setJwsAlgorithm(String jwsAlgorithm) {
/*  87 */       this.jwsAlgorithm = jwsAlgorithm;
/*     */     }
/*     */     
/*     */     public String getIssuerUri() {
/*  91 */       return this.issuerUri;
/*     */     }
/*     */     
/*     */     public void setIssuerUri(String issuerUri) {
/*  95 */       this.issuerUri = issuerUri;
/*     */     }
/*     */     
/*     */     public Resource getPublicKeyLocation() {
/*  99 */       return this.publicKeyLocation;
/*     */     }
/*     */     
/*     */     public void setPublicKeyLocation(Resource publicKeyLocation) {
/* 103 */       this.publicKeyLocation = publicKeyLocation;
/*     */     }
/*     */     
/*     */     public String readPublicKey() throws IOException {
/* 107 */       String key = "spring.security.oauth2.resourceserver.public-key-location";
/* 108 */       Assert.notNull(this.publicKeyLocation, "PublicKeyLocation must not be null");
/* 109 */       if (!this.publicKeyLocation.exists()) {
/* 110 */         throw new InvalidConfigurationPropertyValueException(key, this.publicKeyLocation, "Public key location does not exist");
/*     */       }
/*     */       
/* 113 */       InputStream inputStream = this.publicKeyLocation.getInputStream();Throwable localThrowable3 = null;
/* 114 */       try { return StreamUtils.copyToString(inputStream, StandardCharsets.UTF_8);
/*     */       }
/*     */       catch (Throwable localThrowable4)
/*     */       {
/* 113 */         localThrowable3 = localThrowable4;throw localThrowable4;
/*     */       } finally {
/* 115 */         if (inputStream != null) { if (localThrowable3 != null) try { inputStream.close(); } catch (Throwable localThrowable2) { localThrowable3.addSuppressed(localThrowable2); } else { inputStream.close();
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static class Opaquetoken
/*     */   {
/*     */     private String clientId;
/*     */     
/*     */ 
/*     */     private String clientSecret;
/*     */     
/*     */ 
/*     */     private String introspectionUri;
/*     */     
/*     */ 
/*     */ 
/*     */     public String getClientId()
/*     */     {
/* 138 */       return this.clientId;
/*     */     }
/*     */     
/*     */     public void setClientId(String clientId) {
/* 142 */       this.clientId = clientId;
/*     */     }
/*     */     
/*     */     public String getClientSecret() {
/* 146 */       return this.clientSecret;
/*     */     }
/*     */     
/*     */     public void setClientSecret(String clientSecret) {
/* 150 */       this.clientSecret = clientSecret;
/*     */     }
/*     */     
/*     */     public String getIntrospectionUri() {
/* 154 */       return this.introspectionUri;
/*     */     }
/*     */     
/*     */     public void setIntrospectionUri(String introspectionUri) {
/* 158 */       this.introspectionUri = introspectionUri;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\security\oauth2\resource\OAuth2ResourceServerProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */