/*    */ package org.springframework.boot.autoconfigure.session;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import org.springframework.util.ObjectUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NonUniqueSessionRepositoryException
/*    */   extends RuntimeException
/*    */ {
/*    */   private final List<Class<?>> availableCandidates;
/*    */   
/*    */   public NonUniqueSessionRepositoryException(List<Class<?>> availableCandidates)
/*    */   {
/* 37 */     super("Multiple session repository candidates are available, set the 'spring.session.store-type' property accordingly");
/*    */     
/* 39 */     this.availableCandidates = (!ObjectUtils.isEmpty(availableCandidates) ? availableCandidates : 
/* 40 */       Collections.emptyList());
/*    */   }
/*    */   
/*    */   public List<Class<?>> getAvailableCandidates() {
/* 44 */     return this.availableCandidates;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\session\NonUniqueSessionRepositoryException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */