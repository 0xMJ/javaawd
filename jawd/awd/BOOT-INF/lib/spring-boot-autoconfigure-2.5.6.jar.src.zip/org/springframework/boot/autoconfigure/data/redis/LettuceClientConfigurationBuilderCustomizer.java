package org.springframework.boot.autoconfigure.data.redis;

import org.springframework.data.redis.connection.lettuce.LettuceClientConfiguration.LettuceClientConfigurationBuilder;

@FunctionalInterface
public abstract interface LettuceClientConfigurationBuilderCustomizer
{
  public abstract void customize(LettuceClientConfiguration.LettuceClientConfigurationBuilder paramLettuceClientConfigurationBuilder);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\data\redis\LettuceClientConfigurationBuilderCustomizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */