/*    */ package org.springframework.boot.autoconfigure.freemarker;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import org.springframework.boot.autoconfigure.template.PathBasedTemplateAvailabilityProvider;
/*    */ import org.springframework.boot.autoconfigure.template.PathBasedTemplateAvailabilityProvider.TemplateAvailabilityProperties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FreeMarkerTemplateAvailabilityProvider
/*    */   extends PathBasedTemplateAvailabilityProvider
/*    */ {
/*    */   public FreeMarkerTemplateAvailabilityProvider()
/*    */   {
/* 36 */     super("freemarker.template.Configuration", FreeMarkerTemplateAvailabilityProperties.class, "spring.freemarker");
/*    */   }
/*    */   
/*    */   protected static final class FreeMarkerTemplateAvailabilityProperties extends PathBasedTemplateAvailabilityProvider.TemplateAvailabilityProperties
/*    */   {
/* 41 */     private List<String> templateLoaderPath = new ArrayList(
/* 42 */       Arrays.asList(new String[] { "classpath:/templates/" }));
/*    */     
/*    */     FreeMarkerTemplateAvailabilityProperties() {
/* 45 */       super(".ftlh");
/*    */     }
/*    */     
/*    */     protected List<String> getLoaderPath()
/*    */     {
/* 50 */       return this.templateLoaderPath;
/*    */     }
/*    */     
/*    */     public List<String> getTemplateLoaderPath() {
/* 54 */       return this.templateLoaderPath;
/*    */     }
/*    */     
/*    */     public void setTemplateLoaderPath(List<String> templateLoaderPath) {
/* 58 */       this.templateLoaderPath = templateLoaderPath;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\freemarker\FreeMarkerTemplateAvailabilityProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */