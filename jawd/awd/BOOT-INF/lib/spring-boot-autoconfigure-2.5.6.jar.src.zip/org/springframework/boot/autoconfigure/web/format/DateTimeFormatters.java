/*     */ package org.springframework.boot.autoconfigure.web.format;
/*     */ 
/*     */ import java.time.format.DateTimeFormatter;
/*     */ import java.time.format.ResolverStyle;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DateTimeFormatters
/*     */ {
/*     */   private DateTimeFormatter dateFormatter;
/*     */   private String datePattern;
/*     */   private DateTimeFormatter timeFormatter;
/*     */   private DateTimeFormatter dateTimeFormatter;
/*     */   
/*     */   public DateTimeFormatters dateFormat(String pattern)
/*     */   {
/*  47 */     if (isIso(pattern)) {
/*  48 */       this.dateFormatter = DateTimeFormatter.ISO_LOCAL_DATE;
/*  49 */       this.datePattern = "yyyy-MM-dd";
/*     */     }
/*     */     else {
/*  52 */       this.dateFormatter = formatter(pattern);
/*  53 */       this.datePattern = pattern;
/*     */     }
/*  55 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DateTimeFormatters timeFormat(String pattern)
/*     */   {
/*  65 */     this.timeFormatter = (isIsoOffset(pattern) ? DateTimeFormatter.ISO_OFFSET_TIME : isIso(pattern) ? DateTimeFormatter.ISO_LOCAL_TIME : formatter(pattern));
/*  66 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DateTimeFormatters dateTimeFormat(String pattern)
/*     */   {
/*  76 */     this.dateTimeFormatter = (isIsoOffset(pattern) ? DateTimeFormatter.ISO_OFFSET_DATE_TIME : isIso(pattern) ? DateTimeFormatter.ISO_LOCAL_DATE_TIME : formatter(pattern));
/*  77 */     return this;
/*     */   }
/*     */   
/*     */   DateTimeFormatter getDateFormatter() {
/*  81 */     return this.dateFormatter;
/*     */   }
/*     */   
/*     */   String getDatePattern() {
/*  85 */     return this.datePattern;
/*     */   }
/*     */   
/*     */   DateTimeFormatter getTimeFormatter() {
/*  89 */     return this.timeFormatter;
/*     */   }
/*     */   
/*     */   DateTimeFormatter getDateTimeFormatter() {
/*  93 */     return this.dateTimeFormatter;
/*     */   }
/*     */   
/*     */   boolean isCustomized() {
/*  97 */     return (this.dateFormatter != null) || (this.timeFormatter != null) || (this.dateTimeFormatter != null);
/*     */   }
/*     */   
/*     */   private static DateTimeFormatter formatter(String pattern) {
/* 101 */     return StringUtils.hasText(pattern) ? 
/* 102 */       DateTimeFormatter.ofPattern(pattern).withResolverStyle(ResolverStyle.SMART) : null;
/*     */   }
/*     */   
/*     */   private static boolean isIso(String pattern) {
/* 106 */     return "iso".equalsIgnoreCase(pattern);
/*     */   }
/*     */   
/*     */   private static boolean isIsoOffset(String pattern) {
/* 110 */     return ("isooffset".equalsIgnoreCase(pattern)) || ("iso-offset".equalsIgnoreCase(pattern));
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\web\format\DateTimeFormatters.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */