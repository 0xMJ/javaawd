/*     */ package org.springframework.boot.autoconfigure.jmx;
/*     */ 
/*     */ import javax.management.MBeanServer;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*     */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*     */ import org.springframework.boot.autoconfigure.condition.SearchStrategy;
/*     */ import org.springframework.context.annotation.Bean;
/*     */ import org.springframework.context.annotation.Configuration;
/*     */ import org.springframework.context.annotation.MBeanExportConfiguration.SpecificPlatform;
/*     */ import org.springframework.context.annotation.Primary;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.jmx.export.MBeanExporter;
/*     */ import org.springframework.jmx.export.annotation.AnnotationJmxAttributeSource;
/*     */ import org.springframework.jmx.export.annotation.AnnotationMBeanExporter;
/*     */ import org.springframework.jmx.export.naming.ObjectNamingStrategy;
/*     */ import org.springframework.jmx.support.MBeanServerFactoryBean;
/*     */ import org.springframework.jmx.support.RegistrationPolicy;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Configuration(proxyBeanMethods=false)
/*     */ @ConditionalOnClass({MBeanExporter.class})
/*     */ @ConditionalOnProperty(prefix="spring.jmx", name={"enabled"}, havingValue="true")
/*     */ public class JmxAutoConfiguration
/*     */ {
/*     */   private final Environment environment;
/*     */   
/*     */   public JmxAutoConfiguration(Environment environment)
/*     */   {
/*  61 */     this.environment = environment;
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @Primary
/*     */   @ConditionalOnMissingBean(value={MBeanExporter.class}, search=SearchStrategy.CURRENT)
/*     */   public AnnotationMBeanExporter mbeanExporter(ObjectNamingStrategy namingStrategy, BeanFactory beanFactory) {
/*  68 */     AnnotationMBeanExporter exporter = new AnnotationMBeanExporter();
/*  69 */     exporter.setRegistrationPolicy(RegistrationPolicy.FAIL_ON_EXISTING);
/*  70 */     exporter.setNamingStrategy(namingStrategy);
/*  71 */     String serverBean = this.environment.getProperty("spring.jmx.server", "mbeanServer");
/*  72 */     if (StringUtils.hasLength(serverBean)) {
/*  73 */       exporter.setServer((MBeanServer)beanFactory.getBean(serverBean, MBeanServer.class));
/*     */     }
/*  75 */     return exporter;
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean(value={ObjectNamingStrategy.class}, search=SearchStrategy.CURRENT)
/*     */   public ParentAwareNamingStrategy objectNamingStrategy() {
/*  81 */     ParentAwareNamingStrategy namingStrategy = new ParentAwareNamingStrategy(new AnnotationJmxAttributeSource());
/*  82 */     String defaultDomain = this.environment.getProperty("spring.jmx.default-domain");
/*  83 */     if (StringUtils.hasLength(defaultDomain)) {
/*  84 */       namingStrategy.setDefaultDomain(defaultDomain);
/*     */     }
/*  86 */     boolean uniqueNames = ((Boolean)this.environment.getProperty("spring.jmx.unique-names", Boolean.class, Boolean.valueOf(false))).booleanValue();
/*  87 */     namingStrategy.setEnsureUniqueRuntimeObjectNames(uniqueNames);
/*  88 */     return namingStrategy;
/*     */   }
/*     */   
/*     */   @Bean
/*     */   @ConditionalOnMissingBean
/*     */   public MBeanServer mbeanServer() {
/*  94 */     MBeanExportConfiguration.SpecificPlatform platform = MBeanExportConfiguration.SpecificPlatform.get();
/*  95 */     if (platform != null) {
/*  96 */       return platform.getMBeanServer();
/*     */     }
/*  98 */     MBeanServerFactoryBean factory = new MBeanServerFactoryBean();
/*  99 */     factory.setLocateExistingServerIfPossible(true);
/* 100 */     factory.afterPropertiesSet();
/* 101 */     return factory.getObject();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\jmx\JmxAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */