/*     */ package org.springframework.boot.autoconfigure.jackson;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
/*     */ import com.fasterxml.jackson.annotation.JsonInclude.Include;
/*     */ import com.fasterxml.jackson.annotation.PropertyAccessor;
/*     */ import com.fasterxml.jackson.core.JsonGenerator.Feature;
/*     */ import com.fasterxml.jackson.core.JsonParser.Feature;
/*     */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*     */ import com.fasterxml.jackson.databind.MapperFeature;
/*     */ import com.fasterxml.jackson.databind.SerializationFeature;
/*     */ import java.util.EnumMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.TimeZone;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix="spring.jackson")
/*     */ public class JacksonProperties
/*     */ {
/*     */   private String dateFormat;
/*     */   private String propertyNamingStrategy;
/*  62 */   private final Map<PropertyAccessor, JsonAutoDetect.Visibility> visibility = new EnumMap(PropertyAccessor.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  67 */   private final Map<SerializationFeature, Boolean> serialization = new EnumMap(SerializationFeature.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  72 */   private final Map<DeserializationFeature, Boolean> deserialization = new EnumMap(DeserializationFeature.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  77 */   private final Map<MapperFeature, Boolean> mapper = new EnumMap(MapperFeature.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  82 */   private final Map<JsonParser.Feature, Boolean> parser = new EnumMap(JsonParser.Feature.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  87 */   private final Map<JsonGenerator.Feature, Boolean> generator = new EnumMap(JsonGenerator.Feature.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private JsonInclude.Include defaultPropertyInclusion;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  99 */   private TimeZone timeZone = null;
/*     */   
/*     */ 
/*     */   private Locale locale;
/*     */   
/*     */ 
/*     */   public String getDateFormat()
/*     */   {
/* 107 */     return this.dateFormat;
/*     */   }
/*     */   
/*     */   public void setDateFormat(String dateFormat) {
/* 111 */     this.dateFormat = dateFormat;
/*     */   }
/*     */   
/*     */   public String getPropertyNamingStrategy() {
/* 115 */     return this.propertyNamingStrategy;
/*     */   }
/*     */   
/*     */   public void setPropertyNamingStrategy(String propertyNamingStrategy) {
/* 119 */     this.propertyNamingStrategy = propertyNamingStrategy;
/*     */   }
/*     */   
/*     */   public Map<PropertyAccessor, JsonAutoDetect.Visibility> getVisibility() {
/* 123 */     return this.visibility;
/*     */   }
/*     */   
/*     */   public Map<SerializationFeature, Boolean> getSerialization() {
/* 127 */     return this.serialization;
/*     */   }
/*     */   
/*     */   public Map<DeserializationFeature, Boolean> getDeserialization() {
/* 131 */     return this.deserialization;
/*     */   }
/*     */   
/*     */   public Map<MapperFeature, Boolean> getMapper() {
/* 135 */     return this.mapper;
/*     */   }
/*     */   
/*     */   public Map<JsonParser.Feature, Boolean> getParser() {
/* 139 */     return this.parser;
/*     */   }
/*     */   
/*     */   public Map<JsonGenerator.Feature, Boolean> getGenerator() {
/* 143 */     return this.generator;
/*     */   }
/*     */   
/*     */   public JsonInclude.Include getDefaultPropertyInclusion() {
/* 147 */     return this.defaultPropertyInclusion;
/*     */   }
/*     */   
/*     */   public void setDefaultPropertyInclusion(JsonInclude.Include defaultPropertyInclusion) {
/* 151 */     this.defaultPropertyInclusion = defaultPropertyInclusion;
/*     */   }
/*     */   
/*     */   public TimeZone getTimeZone() {
/* 155 */     return this.timeZone;
/*     */   }
/*     */   
/*     */   public void setTimeZone(TimeZone timeZone) {
/* 159 */     this.timeZone = timeZone;
/*     */   }
/*     */   
/*     */   public Locale getLocale() {
/* 163 */     return this.locale;
/*     */   }
/*     */   
/*     */   public void setLocale(Locale locale) {
/* 167 */     this.locale = locale;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\jackson\JacksonProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */