/*    */ package org.springframework.boot.autoconfigure.validation;
/*    */ 
/*    */ import org.springframework.beans.BeansException;
/*    */ import org.springframework.beans.factory.BeanFactory;
/*    */ import org.springframework.beans.factory.BeanFactoryAware;
/*    */ import org.springframework.beans.factory.config.BeanDefinition;
/*    */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*    */ import org.springframework.context.annotation.ImportBeanDefinitionRegistrar;
/*    */ import org.springframework.core.type.AnnotationMetadata;
/*    */ import org.springframework.validation.Validator;
/*    */ import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class PrimaryDefaultValidatorPostProcessor
/*    */   implements ImportBeanDefinitionRegistrar, BeanFactoryAware
/*    */ {
/*    */   private static final String VALIDATOR_BEAN_NAME = "defaultValidator";
/*    */   private ConfigurableListableBeanFactory beanFactory;
/*    */   
/*    */   public void setBeanFactory(BeanFactory beanFactory)
/*    */     throws BeansException
/*    */   {
/* 53 */     if ((beanFactory instanceof ConfigurableListableBeanFactory)) {
/* 54 */       this.beanFactory = ((ConfigurableListableBeanFactory)beanFactory);
/*    */     }
/*    */   }
/*    */   
/*    */   public void registerBeanDefinitions(AnnotationMetadata importingClassMetadata, BeanDefinitionRegistry registry)
/*    */   {
/* 60 */     BeanDefinition definition = getAutoConfiguredValidator(registry);
/* 61 */     if (definition != null) {
/* 62 */       definition.setPrimary(!hasPrimarySpringValidator());
/*    */     }
/*    */   }
/*    */   
/*    */   private BeanDefinition getAutoConfiguredValidator(BeanDefinitionRegistry registry) {
/* 67 */     if (registry.containsBeanDefinition("defaultValidator")) {
/* 68 */       BeanDefinition definition = registry.getBeanDefinition("defaultValidator");
/* 69 */       if ((definition.getRole() == 2) && 
/* 70 */         (isTypeMatch("defaultValidator", LocalValidatorFactoryBean.class))) {
/* 71 */         return definition;
/*    */       }
/*    */     }
/* 74 */     return null;
/*    */   }
/*    */   
/*    */   private boolean isTypeMatch(String name, Class<?> type) {
/* 78 */     return (this.beanFactory != null) && (this.beanFactory.isTypeMatch(name, type));
/*    */   }
/*    */   
/*    */   private boolean hasPrimarySpringValidator() {
/* 82 */     String[] validatorBeans = this.beanFactory.getBeanNamesForType(Validator.class, false, false);
/* 83 */     for (String validatorBean : validatorBeans) {
/* 84 */       BeanDefinition definition = this.beanFactory.getBeanDefinition(validatorBean);
/* 85 */       if (definition.isPrimary()) {
/* 86 */         return true;
/*    */       }
/*    */     }
/* 89 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\validation\PrimaryDefaultValidatorPostProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */