package org.springframework.boot.autoconfigure.neo4j;

import org.neo4j.driver.Config.ConfigBuilder;

@FunctionalInterface
public abstract interface ConfigBuilderCustomizer
{
  public abstract void customize(Config.ConfigBuilder paramConfigBuilder);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\neo4j\ConfigBuilderCustomizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */