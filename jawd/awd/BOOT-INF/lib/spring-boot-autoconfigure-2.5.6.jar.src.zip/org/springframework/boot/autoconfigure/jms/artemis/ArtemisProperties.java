/*     */ package org.springframework.boot.autoconfigure.jms.artemis;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.UUID;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import org.springframework.boot.autoconfigure.jms.JmsPoolConnectionFactoryProperties;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.boot.context.properties.DeprecatedConfigurationProperty;
/*     */ import org.springframework.boot.context.properties.NestedConfigurationProperty;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix="spring.artemis")
/*     */ public class ArtemisProperties
/*     */ {
/*     */   private ArtemisMode mode;
/*     */   private String brokerUrl;
/*     */   private String host;
/*  60 */   private int port = 61616;
/*     */   
/*     */ 
/*     */ 
/*     */   private String user;
/*     */   
/*     */ 
/*     */ 
/*     */   private String password;
/*     */   
/*     */ 
/*     */ 
/*  72 */   private final Embedded embedded = new Embedded();
/*     */   @NestedConfigurationProperty
/*  74 */   private final JmsPoolConnectionFactoryProperties pool = new JmsPoolConnectionFactoryProperties();
/*     */   
/*     */   public ArtemisMode getMode()
/*     */   {
/*  78 */     return this.mode;
/*     */   }
/*     */   
/*     */   public void setMode(ArtemisMode mode) {
/*  82 */     this.mode = mode;
/*     */   }
/*     */   
/*     */   public String getBrokerUrl() {
/*  86 */     return this.brokerUrl;
/*     */   }
/*     */   
/*     */   public void setBrokerUrl(String brokerUrl) {
/*  90 */     this.brokerUrl = brokerUrl;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   @DeprecatedConfigurationProperty(replacement="spring.artemis.broker-url")
/*     */   public String getHost()
/*     */   {
/* 101 */     return this.host;
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public void setHost(String host) {
/* 106 */     this.host = host;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   @DeprecatedConfigurationProperty(replacement="spring.artemis.broker-url")
/*     */   public int getPort()
/*     */   {
/* 117 */     return this.port;
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public void setPort(int port) {
/* 122 */     this.port = port;
/*     */   }
/*     */   
/*     */   public String getUser() {
/* 126 */     return this.user;
/*     */   }
/*     */   
/*     */   public void setUser(String user) {
/* 130 */     this.user = user;
/*     */   }
/*     */   
/*     */   public String getPassword() {
/* 134 */     return this.password;
/*     */   }
/*     */   
/*     */   public void setPassword(String password) {
/* 138 */     this.password = password;
/*     */   }
/*     */   
/*     */   public Embedded getEmbedded() {
/* 142 */     return this.embedded;
/*     */   }
/*     */   
/*     */   public JmsPoolConnectionFactoryProperties getPool() {
/* 146 */     return this.pool;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Embedded
/*     */   {
/* 154 */     private static final AtomicInteger serverIdCounter = new AtomicInteger();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 159 */     private int serverId = serverIdCounter.getAndIncrement();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 164 */     private boolean enabled = true;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private boolean persistent;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private String dataDirectory;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 179 */     private String[] queues = new String[0];
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 184 */     private String[] topics = new String[0];
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 189 */     private String clusterPassword = UUID.randomUUID().toString();
/*     */     
/* 191 */     private boolean defaultClusterPassword = true;
/*     */     
/*     */     public int getServerId() {
/* 194 */       return this.serverId;
/*     */     }
/*     */     
/*     */     public void setServerId(int serverId) {
/* 198 */       this.serverId = serverId;
/*     */     }
/*     */     
/*     */     public boolean isEnabled() {
/* 202 */       return this.enabled;
/*     */     }
/*     */     
/*     */     public void setEnabled(boolean enabled) {
/* 206 */       this.enabled = enabled;
/*     */     }
/*     */     
/*     */     public boolean isPersistent() {
/* 210 */       return this.persistent;
/*     */     }
/*     */     
/*     */     public void setPersistent(boolean persistent) {
/* 214 */       this.persistent = persistent;
/*     */     }
/*     */     
/*     */     public String getDataDirectory() {
/* 218 */       return this.dataDirectory;
/*     */     }
/*     */     
/*     */     public void setDataDirectory(String dataDirectory) {
/* 222 */       this.dataDirectory = dataDirectory;
/*     */     }
/*     */     
/*     */     public String[] getQueues() {
/* 226 */       return this.queues;
/*     */     }
/*     */     
/*     */     public void setQueues(String[] queues) {
/* 230 */       this.queues = queues;
/*     */     }
/*     */     
/*     */     public String[] getTopics() {
/* 234 */       return this.topics;
/*     */     }
/*     */     
/*     */     public void setTopics(String[] topics) {
/* 238 */       this.topics = topics;
/*     */     }
/*     */     
/*     */     public String getClusterPassword() {
/* 242 */       return this.clusterPassword;
/*     */     }
/*     */     
/*     */     public void setClusterPassword(String clusterPassword) {
/* 246 */       this.clusterPassword = clusterPassword;
/* 247 */       this.defaultClusterPassword = false;
/*     */     }
/*     */     
/*     */     public boolean isDefaultClusterPassword() {
/* 251 */       return this.defaultClusterPassword;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public Map<String, Object> generateTransportParameters()
/*     */     {
/* 261 */       Map<String, Object> parameters = new HashMap();
/* 262 */       parameters.put("serverId", Integer.valueOf(getServerId()));
/* 263 */       return parameters;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\jms\artemis\ArtemisProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */