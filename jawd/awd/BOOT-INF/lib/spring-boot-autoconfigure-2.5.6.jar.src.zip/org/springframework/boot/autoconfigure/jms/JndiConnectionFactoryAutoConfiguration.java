/*    */ package org.springframework.boot.autoconfigure.jms;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import javax.jms.ConnectionFactory;
/*    */ import javax.naming.NamingException;
/*    */ import org.springframework.boot.autoconfigure.AutoConfigureBefore;
/*    */ import org.springframework.boot.autoconfigure.condition.AnyNestedCondition;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnJndi;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*    */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Conditional;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.ConfigurationCondition.ConfigurationPhase;
/*    */ import org.springframework.jms.core.JmsTemplate;
/*    */ import org.springframework.jndi.JndiLocatorDelegate;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods=false)
/*    */ @AutoConfigureBefore({JmsAutoConfiguration.class})
/*    */ @ConditionalOnClass({JmsTemplate.class})
/*    */ @ConditionalOnMissingBean({ConnectionFactory.class})
/*    */ @Conditional({JndiOrPropertyCondition.class})
/*    */ @EnableConfigurationProperties({JmsProperties.class})
/*    */ public class JndiConnectionFactoryAutoConfiguration
/*    */ {
/* 55 */   private static final String[] JNDI_LOCATIONS = { "java:/JmsXA", "java:/XAConnectionFactory" };
/*    */   
/*    */   @Bean
/*    */   public ConnectionFactory jmsConnectionFactory(JmsProperties properties) throws NamingException {
/* 59 */     JndiLocatorDelegate jndiLocatorDelegate = JndiLocatorDelegate.createDefaultResourceRefLocator();
/* 60 */     if (StringUtils.hasLength(properties.getJndiName())) {
/* 61 */       return (ConnectionFactory)jndiLocatorDelegate.lookup(properties.getJndiName(), ConnectionFactory.class);
/*    */     }
/* 63 */     return findJndiConnectionFactory(jndiLocatorDelegate);
/*    */   }
/*    */   
/*    */   private ConnectionFactory findJndiConnectionFactory(JndiLocatorDelegate jndiLocatorDelegate) {
/* 67 */     for (String name : JNDI_LOCATIONS) {
/*    */       try {
/* 69 */         return (ConnectionFactory)jndiLocatorDelegate.lookup(name, ConnectionFactory.class);
/*    */       }
/*    */       catch (NamingException localNamingException) {}
/*    */     }
/*    */     
/*    */ 
/*    */ 
/* 76 */     throw new IllegalStateException("Unable to find ConnectionFactory in JNDI locations " + Arrays.asList(JNDI_LOCATIONS));
/*    */   }
/*    */   
/*    */ 
/*    */   static class JndiOrPropertyCondition
/*    */     extends AnyNestedCondition
/*    */   {
/*    */     JndiOrPropertyCondition()
/*    */     {
/* 85 */       super();
/*    */     }
/*    */     
/*    */     @ConditionalOnProperty(prefix="spring.jms", name={"jndi-name"})
/*    */     static class Property {}
/*    */     
/*    */     @ConditionalOnJndi({"java:/JmsXA", "java:/XAConnectionFactory"})
/*    */     static class Jndi {}
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\jms\JndiConnectionFactoryAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */