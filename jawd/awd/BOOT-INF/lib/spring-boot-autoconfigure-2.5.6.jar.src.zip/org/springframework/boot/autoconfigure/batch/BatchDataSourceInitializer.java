/*    */ package org.springframework.boot.autoconfigure.batch;
/*    */ 
/*    */ import javax.sql.DataSource;
/*    */ import org.springframework.boot.jdbc.AbstractDataSourceInitializer;
/*    */ import org.springframework.boot.jdbc.DataSourceInitializationMode;
/*    */ import org.springframework.core.io.ResourceLoader;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BatchDataSourceInitializer
/*    */   extends AbstractDataSourceInitializer
/*    */ {
/*    */   private final BatchProperties.Jdbc jdbcProperties;
/*    */   
/*    */   public BatchDataSourceInitializer(DataSource dataSource, ResourceLoader resourceLoader, BatchProperties properties)
/*    */   {
/* 40 */     super(dataSource, resourceLoader);
/* 41 */     Assert.notNull(properties, "BatchProperties must not be null");
/* 42 */     this.jdbcProperties = properties.getJdbc();
/*    */   }
/*    */   
/*    */   protected DataSourceInitializationMode getMode()
/*    */   {
/* 47 */     return this.jdbcProperties.getInitializeSchema();
/*    */   }
/*    */   
/*    */   protected String getSchemaLocation()
/*    */   {
/* 52 */     return this.jdbcProperties.getSchema();
/*    */   }
/*    */   
/*    */   protected String getDatabaseName()
/*    */   {
/* 57 */     String databaseName = super.getDatabaseName();
/* 58 */     if ("oracle".equals(databaseName)) {
/* 59 */       return "oracle10g";
/*    */     }
/* 61 */     if ("mariadb".equals(databaseName)) {
/* 62 */       return "mysql";
/*    */     }
/* 64 */     return databaseName;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\batch\BatchDataSourceInitializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */