/*    */ package org.springframework.boot.autoconfigure.data.rest;
/*    */ 
/*    */ import org.springframework.beans.factory.ObjectProvider;
/*    */ import org.springframework.boot.autoconfigure.AutoConfigureAfter;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication.Type;
/*    */ import org.springframework.boot.autoconfigure.http.HttpMessageConvertersAutoConfiguration;
/*    */ import org.springframework.boot.autoconfigure.jackson.JacksonAutoConfiguration;
/*    */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.Import;
/*    */ import org.springframework.data.rest.webmvc.config.RepositoryRestMvcConfiguration;
/*    */ import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods=false)
/*    */ @ConditionalOnWebApplication(type=ConditionalOnWebApplication.Type.SERVLET)
/*    */ @ConditionalOnMissingBean({RepositoryRestMvcConfiguration.class})
/*    */ @ConditionalOnClass({RepositoryRestMvcConfiguration.class})
/*    */ @AutoConfigureAfter({HttpMessageConvertersAutoConfiguration.class, JacksonAutoConfiguration.class})
/*    */ @EnableConfigurationProperties({RepositoryRestProperties.class})
/*    */ @Import({RepositoryRestMvcConfiguration.class})
/*    */ public class RepositoryRestMvcAutoConfiguration
/*    */ {
/*    */   @Bean
/*    */   public SpringBootRepositoryRestConfigurer springBootRepositoryRestConfigurer(ObjectProvider<Jackson2ObjectMapperBuilder> objectMapperBuilder, RepositoryRestProperties properties)
/*    */   {
/* 63 */     return new SpringBootRepositoryRestConfigurer((Jackson2ObjectMapperBuilder)objectMapperBuilder.getIfAvailable(), properties);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\data\rest\RepositoryRestMvcAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */