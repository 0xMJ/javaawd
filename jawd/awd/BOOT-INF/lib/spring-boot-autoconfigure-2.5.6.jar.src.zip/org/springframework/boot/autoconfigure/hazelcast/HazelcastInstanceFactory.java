/*    */ package org.springframework.boot.autoconfigure.hazelcast;
/*    */ 
/*    */ import com.hazelcast.config.Config;
/*    */ import com.hazelcast.config.XmlConfigBuilder;
/*    */ import com.hazelcast.config.YamlConfigBuilder;
/*    */ import com.hazelcast.core.Hazelcast;
/*    */ import com.hazelcast.core.HazelcastInstance;
/*    */ import java.io.IOException;
/*    */ import java.net.URL;
/*    */ import org.springframework.core.io.Resource;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.ResourceUtils;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class HazelcastInstanceFactory
/*    */ {
/*    */   private final Config config;
/*    */   
/*    */   public HazelcastInstanceFactory(Resource configLocation)
/*    */     throws IOException
/*    */   {
/* 52 */     Assert.notNull(configLocation, "ConfigLocation must not be null");
/* 53 */     this.config = getConfig(configLocation);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public HazelcastInstanceFactory(Config config)
/*    */   {
/* 61 */     Assert.notNull(config, "Config must not be null");
/* 62 */     this.config = config;
/*    */   }
/*    */   
/*    */   private Config getConfig(Resource configLocation) throws IOException {
/* 66 */     URL configUrl = configLocation.getURL();
/* 67 */     Config config = createConfig(configUrl);
/* 68 */     if (ResourceUtils.isFileURL(configUrl)) {
/* 69 */       config.setConfigurationFile(configLocation.getFile());
/*    */     }
/*    */     else {
/* 72 */       config.setConfigurationUrl(configUrl);
/*    */     }
/* 74 */     return config;
/*    */   }
/*    */   
/*    */   private static Config createConfig(URL configUrl) throws IOException {
/* 78 */     String configFileName = configUrl.getPath();
/* 79 */     if (configFileName.endsWith(".yaml")) {
/* 80 */       return new YamlConfigBuilder(configUrl).build();
/*    */     }
/* 82 */     return new XmlConfigBuilder(configUrl).build();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public HazelcastInstance getHazelcastInstance()
/*    */   {
/* 90 */     if (StringUtils.hasText(this.config.getInstanceName())) {
/* 91 */       return Hazelcast.getOrCreateHazelcastInstance(this.config);
/*    */     }
/* 93 */     return Hazelcast.newHazelcastInstance(this.config);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\hazelcast\HazelcastInstanceFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */