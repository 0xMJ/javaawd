/*    */ package org.springframework.boot.autoconfigure.freemarker;
/*    */ 
/*    */ import javax.servlet.DispatcherType;
/*    */ import javax.servlet.Servlet;
/*    */ import org.springframework.boot.autoconfigure.AutoConfigureAfter;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication.Type;
/*    */ import org.springframework.boot.autoconfigure.web.ConditionalOnEnabledResourceChain;
/*    */ import org.springframework.boot.autoconfigure.web.servlet.ConditionalOnMissingFilterBean;
/*    */ import org.springframework.boot.autoconfigure.web.servlet.WebMvcAutoConfiguration;
/*    */ import org.springframework.boot.web.servlet.FilterRegistrationBean;
/*    */ import org.springframework.boot.web.servlet.ServletRegistrationBean;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.web.servlet.resource.ResourceUrlEncodingFilter;
/*    */ import org.springframework.web.servlet.view.freemarker.FreeMarkerConfig;
/*    */ import org.springframework.web.servlet.view.freemarker.FreeMarkerConfigurer;
/*    */ import org.springframework.web.servlet.view.freemarker.FreeMarkerViewResolver;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @org.springframework.context.annotation.Configuration(proxyBeanMethods=false)
/*    */ @ConditionalOnWebApplication(type=ConditionalOnWebApplication.Type.SERVLET)
/*    */ @ConditionalOnClass({Servlet.class, FreeMarkerConfigurer.class})
/*    */ @AutoConfigureAfter({WebMvcAutoConfiguration.class})
/*    */ class FreeMarkerServletWebConfiguration
/*    */   extends AbstractFreeMarkerConfiguration
/*    */ {
/*    */   protected FreeMarkerServletWebConfiguration(FreeMarkerProperties properties)
/*    */   {
/* 51 */     super(properties);
/*    */   }
/*    */   
/*    */   @Bean
/*    */   @ConditionalOnMissingBean({FreeMarkerConfig.class})
/*    */   FreeMarkerConfigurer freeMarkerConfigurer() {
/* 57 */     FreeMarkerConfigurer configurer = new FreeMarkerConfigurer();
/* 58 */     applyProperties(configurer);
/* 59 */     return configurer;
/*    */   }
/*    */   
/*    */   @Bean
/*    */   freemarker.template.Configuration freeMarkerConfiguration(FreeMarkerConfig configurer) {
/* 64 */     return configurer.getConfiguration();
/*    */   }
/*    */   
/*    */   @Bean
/*    */   @ConditionalOnMissingBean(name={"freeMarkerViewResolver"})
/*    */   @ConditionalOnProperty(name={"spring.freemarker.enabled"}, matchIfMissing=true)
/*    */   FreeMarkerViewResolver freeMarkerViewResolver() {
/* 71 */     FreeMarkerViewResolver resolver = new FreeMarkerViewResolver();
/* 72 */     getProperties().applyToMvcViewResolver(resolver);
/* 73 */     return resolver;
/*    */   }
/*    */   
/*    */   @Bean
/*    */   @ConditionalOnEnabledResourceChain
/*    */   @ConditionalOnMissingFilterBean({ResourceUrlEncodingFilter.class})
/*    */   FilterRegistrationBean<ResourceUrlEncodingFilter> resourceUrlEncodingFilter() {
/* 80 */     FilterRegistrationBean<ResourceUrlEncodingFilter> registration = new FilterRegistrationBean(new ResourceUrlEncodingFilter(), new ServletRegistrationBean[0]);
/*    */     
/* 82 */     registration.setDispatcherTypes(DispatcherType.REQUEST, new DispatcherType[] { DispatcherType.ERROR });
/* 83 */     return registration;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\freemarker\FreeMarkerServletWebConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */