/*    */ package org.springframework.boot.autoconfigure.context;
/*    */ 
/*    */ import java.time.Duration;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.SearchStrategy;
/*    */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.support.DefaultLifecycleProcessor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods=false)
/*    */ @EnableConfigurationProperties({LifecycleProperties.class})
/*    */ public class LifecycleAutoConfiguration
/*    */ {
/*    */   @Bean(name={"lifecycleProcessor"})
/*    */   @ConditionalOnMissingBean(name={"lifecycleProcessor"}, search=SearchStrategy.CURRENT)
/*    */   public DefaultLifecycleProcessor defaultLifecycleProcessor(LifecycleProperties properties)
/*    */   {
/* 43 */     DefaultLifecycleProcessor lifecycleProcessor = new DefaultLifecycleProcessor();
/* 44 */     lifecycleProcessor.setTimeoutPerShutdownPhase(properties.getTimeoutPerShutdownPhase().toMillis());
/* 45 */     return lifecycleProcessor;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\context\LifecycleAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */