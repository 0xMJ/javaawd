/*    */ package org.springframework.boot.autoconfigure.netty;
/*    */ 
/*    */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @ConfigurationProperties(prefix="spring.netty")
/*    */ public class NettyProperties
/*    */ {
/* 35 */   private LeakDetection leakDetection = LeakDetection.SIMPLE;
/*    */   
/*    */   public LeakDetection getLeakDetection() {
/* 38 */     return this.leakDetection;
/*    */   }
/*    */   
/*    */   public void setLeakDetection(LeakDetection leakDetection) {
/* 42 */     this.leakDetection = leakDetection;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public static enum LeakDetection
/*    */   {
/* 50 */     DISABLED, 
/*    */     
/*    */ 
/*    */ 
/*    */ 
/* 55 */     SIMPLE, 
/*    */     
/*    */ 
/*    */ 
/*    */ 
/* 60 */     ADVANCED, 
/*    */     
/*    */ 
/*    */ 
/*    */ 
/* 65 */     PARANOID;
/*    */     
/*    */     private LeakDetection() {}
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\netty\NettyProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */