/*    */ package org.springframework.boot.autoconfigure.hazelcast;
/*    */ 
/*    */ import com.hazelcast.client.config.ClientConfigRecognizer;
/*    */ import com.hazelcast.config.ConfigStream;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.net.URL;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionMessage.Builder;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionOutcome;
/*    */ import org.springframework.context.annotation.ConditionContext;
/*    */ import org.springframework.core.env.Environment;
/*    */ import org.springframework.core.io.Resource;
/*    */ import org.springframework.core.io.ResourceLoader;
/*    */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class HazelcastClientConfigAvailableCondition
/*    */   extends HazelcastConfigResourceCondition
/*    */ {
/*    */   HazelcastClientConfigAvailableCondition()
/*    */   {
/* 41 */     super("hazelcast.client.config", new String[] { "file:./hazelcast-client.xml", "classpath:/hazelcast-client.xml", "file:./hazelcast-client.yaml", "classpath:/hazelcast-client.yaml" });
/*    */   }
/*    */   
/*    */ 
/*    */   public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata)
/*    */   {
/* 47 */     if (context.getEnvironment().containsProperty("spring.hazelcast.config")) {
/* 48 */       ConditionOutcome configValidationOutcome = Hazelcast4ClientValidation.clientConfigOutcome(context, "spring.hazelcast.config", 
/* 49 */         startConditionMessage());
/* 50 */       return configValidationOutcome != null ? configValidationOutcome : 
/* 51 */         ConditionOutcome.match(startConditionMessage().foundExactly("property spring.hazelcast.config"));
/*    */     }
/* 53 */     return getResourceOutcome(context, metadata);
/*    */   }
/*    */   
/*    */   static class Hazelcast4ClientValidation
/*    */   {
/*    */     static ConditionOutcome clientConfigOutcome(ConditionContext context, String propertyName, ConditionMessage.Builder builder) {
/* 59 */       String resourcePath = context.getEnvironment().getProperty(propertyName);
/* 60 */       Resource resource = context.getResourceLoader().getResource(resourcePath);
/* 61 */       if (!resource.exists())
/* 62 */         return ConditionOutcome.noMatch(builder.because("Hazelcast configuration does not exist"));
/*    */       try {
/* 64 */         InputStream in = resource.getInputStream();Throwable localThrowable4 = null;
/* 65 */         try { boolean clientConfig = new ClientConfigRecognizer().isRecognized(new ConfigStream(in));
/* 66 */           return new ConditionOutcome(clientConfig, existingConfigurationOutcome(resource, clientConfig));
/*    */         }
/*    */         catch (Throwable localThrowable2)
/*    */         {
/* 64 */           localThrowable4 = localThrowable2;throw localThrowable2;
/*    */         }
/*    */         finally {
/* 67 */           if (in != null) if (localThrowable4 != null) try { in.close(); } catch (Throwable localThrowable3) { localThrowable4.addSuppressed(localThrowable3); } else in.close();
/*    */         }
/* 69 */         return null;
/*    */       } catch (Throwable ex) {}
/*    */     }
/*    */     
/*    */     private static String existingConfigurationOutcome(Resource resource, boolean client) throws IOException {
/* 74 */       URL location = resource.getURL();
/* 75 */       return "Hazelcast server configuration detected  at '" + location + "'";
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\hazelcast\HazelcastClientConfigAvailableCondition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */