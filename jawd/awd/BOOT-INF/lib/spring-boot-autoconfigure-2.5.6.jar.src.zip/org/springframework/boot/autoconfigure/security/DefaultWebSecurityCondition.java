/*    */ package org.springframework.boot.autoconfigure.security;
/*    */ 
/*    */ import org.springframework.boot.autoconfigure.condition.AllNestedConditions;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.context.annotation.ConfigurationCondition.ConfigurationPhase;
/*    */ import org.springframework.security.config.annotation.web.builders.HttpSecurity;
/*    */ import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
/*    */ import org.springframework.security.web.SecurityFilterChain;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class DefaultWebSecurityCondition
/*    */   extends AllNestedConditions
/*    */ {
/*    */   DefaultWebSecurityCondition()
/*    */   {
/* 36 */     super(ConfigurationCondition.ConfigurationPhase.REGISTER_BEAN);
/*    */   }
/*    */   
/*    */   @ConditionalOnMissingBean({WebSecurityConfigurerAdapter.class, SecurityFilterChain.class})
/*    */   static class Beans {}
/*    */   
/*    */   @ConditionalOnClass({SecurityFilterChain.class, HttpSecurity.class})
/*    */   static class Classes {}
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\security\DefaultWebSecurityCondition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */