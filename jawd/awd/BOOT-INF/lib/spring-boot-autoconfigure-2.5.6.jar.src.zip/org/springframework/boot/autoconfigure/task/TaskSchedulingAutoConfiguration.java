/*    */ package org.springframework.boot.autoconfigure.task;
/*    */ 
/*    */ import java.util.concurrent.ScheduledExecutorService;
/*    */ import org.springframework.beans.factory.ObjectProvider;
/*    */ import org.springframework.boot.LazyInitializationExcludeFilter;
/*    */ import org.springframework.boot.autoconfigure.AutoConfigureAfter;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*    */ import org.springframework.boot.task.TaskSchedulerBuilder;
/*    */ import org.springframework.boot.task.TaskSchedulerCustomizer;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.scheduling.TaskScheduler;
/*    */ import org.springframework.scheduling.annotation.SchedulingConfigurer;
/*    */ import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @ConditionalOnClass({ThreadPoolTaskScheduler.class})
/*    */ @Configuration(proxyBeanMethods=false)
/*    */ @EnableConfigurationProperties({TaskSchedulingProperties.class})
/*    */ @AutoConfigureAfter({TaskExecutionAutoConfiguration.class})
/*    */ public class TaskSchedulingAutoConfiguration
/*    */ {
/*    */   @Bean
/*    */   @ConditionalOnBean(name={"org.springframework.context.annotation.internalScheduledAnnotationProcessor"})
/*    */   @ConditionalOnMissingBean({SchedulingConfigurer.class, TaskScheduler.class, ScheduledExecutorService.class})
/*    */   public ThreadPoolTaskScheduler taskScheduler(TaskSchedulerBuilder builder)
/*    */   {
/* 55 */     return builder.build();
/*    */   }
/*    */   
/*    */   @Bean
/*    */   public static LazyInitializationExcludeFilter scheduledBeanLazyInitializationExcludeFilter() {
/* 60 */     return new ScheduledBeanLazyInitializationExcludeFilter();
/*    */   }
/*    */   
/*    */   @Bean
/*    */   @ConditionalOnMissingBean
/*    */   public TaskSchedulerBuilder taskSchedulerBuilder(TaskSchedulingProperties properties, ObjectProvider<TaskSchedulerCustomizer> taskSchedulerCustomizers)
/*    */   {
/* 67 */     TaskSchedulerBuilder builder = new TaskSchedulerBuilder();
/* 68 */     builder = builder.poolSize(properties.getPool().getSize());
/* 69 */     TaskSchedulingProperties.Shutdown shutdown = properties.getShutdown();
/* 70 */     builder = builder.awaitTermination(shutdown.isAwaitTermination());
/* 71 */     builder = builder.awaitTerminationPeriod(shutdown.getAwaitTerminationPeriod());
/* 72 */     builder = builder.threadNamePrefix(properties.getThreadNamePrefix());
/* 73 */     builder = builder.customizers(taskSchedulerCustomizers);
/* 74 */     return builder;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\task\TaskSchedulingAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */