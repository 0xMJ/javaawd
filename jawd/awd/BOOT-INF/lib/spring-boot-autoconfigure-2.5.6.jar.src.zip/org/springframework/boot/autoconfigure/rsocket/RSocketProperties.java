/*     */ package org.springframework.boot.autoconfigure.rsocket;
/*     */ 
/*     */ import java.net.InetAddress;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.boot.context.properties.NestedConfigurationProperty;
/*     */ import org.springframework.boot.rsocket.server.RSocketServer.Transport;
/*     */ import org.springframework.boot.web.server.Ssl;
/*     */ import org.springframework.util.unit.DataSize;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties("spring.rsocket")
/*     */ public class RSocketProperties
/*     */ {
/*     */   @NestedConfigurationProperty
/*  37 */   private final Server server = new Server();
/*     */   
/*     */   public Server getServer()
/*     */   {
/*  41 */     return this.server;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Server
/*     */   {
/*     */     private Integer port;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private InetAddress address;
/*     */     
/*     */ 
/*     */ 
/*  59 */     private RSocketServer.Transport transport = RSocketServer.Transport.TCP;
/*     */     
/*     */ 
/*     */ 
/*     */     private String mappingPath;
/*     */     
/*     */ 
/*     */ 
/*     */     private DataSize fragmentSize;
/*     */     
/*     */ 
/*     */     @NestedConfigurationProperty
/*     */     private Ssl ssl;
/*     */     
/*     */ 
/*     */ 
/*     */     public Integer getPort()
/*     */     {
/*  77 */       return this.port;
/*     */     }
/*     */     
/*     */     public void setPort(Integer port) {
/*  81 */       this.port = port;
/*     */     }
/*     */     
/*     */     public InetAddress getAddress() {
/*  85 */       return this.address;
/*     */     }
/*     */     
/*     */     public void setAddress(InetAddress address) {
/*  89 */       this.address = address;
/*     */     }
/*     */     
/*     */     public RSocketServer.Transport getTransport() {
/*  93 */       return this.transport;
/*     */     }
/*     */     
/*     */     public void setTransport(RSocketServer.Transport transport) {
/*  97 */       this.transport = transport;
/*     */     }
/*     */     
/*     */     public String getMappingPath() {
/* 101 */       return this.mappingPath;
/*     */     }
/*     */     
/*     */     public void setMappingPath(String mappingPath) {
/* 105 */       this.mappingPath = mappingPath;
/*     */     }
/*     */     
/*     */     public DataSize getFragmentSize() {
/* 109 */       return this.fragmentSize;
/*     */     }
/*     */     
/*     */     public void setFragmentSize(DataSize fragmentSize) {
/* 113 */       this.fragmentSize = fragmentSize;
/*     */     }
/*     */     
/*     */     public Ssl getSsl() {
/* 117 */       return this.ssl;
/*     */     }
/*     */     
/*     */     public void setSsl(Ssl ssl) {
/* 121 */       this.ssl = ssl;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\rsocket\RSocketProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */