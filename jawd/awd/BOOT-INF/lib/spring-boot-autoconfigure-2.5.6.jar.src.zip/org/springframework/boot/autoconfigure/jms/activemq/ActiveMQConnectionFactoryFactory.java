/*     */ package org.springframework.boot.autoconfigure.jms.activemq;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.time.Duration;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.apache.activemq.ActiveMQConnectionFactory;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ActiveMQConnectionFactoryFactory
/*     */ {
/*     */   private static final String DEFAULT_EMBEDDED_BROKER_URL = "vm://localhost?broker.persistent=false";
/*     */   private static final String DEFAULT_NETWORK_BROKER_URL = "tcp://localhost:61616";
/*     */   private final ActiveMQProperties properties;
/*     */   private final List<ActiveMQConnectionFactoryCustomizer> factoryCustomizers;
/*     */   
/*     */   ActiveMQConnectionFactoryFactory(ActiveMQProperties properties, List<ActiveMQConnectionFactoryCustomizer> factoryCustomizers)
/*     */   {
/*  48 */     Assert.notNull(properties, "Properties must not be null");
/*  49 */     this.properties = properties;
/*  50 */     this.factoryCustomizers = (factoryCustomizers != null ? factoryCustomizers : Collections.emptyList());
/*     */   }
/*     */   
/*     */   <T extends ActiveMQConnectionFactory> T createConnectionFactory(Class<T> factoryClass) {
/*     */     try {
/*  55 */       return doCreateConnectionFactory(factoryClass);
/*     */     }
/*     */     catch (Exception ex) {
/*  58 */       throw new IllegalStateException("Unable to create ActiveMQConnectionFactory", ex);
/*     */     }
/*     */   }
/*     */   
/*     */   private <T extends ActiveMQConnectionFactory> T doCreateConnectionFactory(Class<T> factoryClass) throws Exception {
/*  63 */     T factory = createConnectionFactoryInstance(factoryClass);
/*  64 */     if (this.properties.getCloseTimeout() != null) {
/*  65 */       factory.setCloseTimeout((int)this.properties.getCloseTimeout().toMillis());
/*     */     }
/*  67 */     factory.setNonBlockingRedelivery(this.properties.isNonBlockingRedelivery());
/*  68 */     if (this.properties.getSendTimeout() != null) {
/*  69 */       factory.setSendTimeout((int)this.properties.getSendTimeout().toMillis());
/*     */     }
/*  71 */     ActiveMQProperties.Packages packages = this.properties.getPackages();
/*  72 */     if (packages.getTrustAll() != null) {
/*  73 */       factory.setTrustAllPackages(packages.getTrustAll().booleanValue());
/*     */     }
/*  75 */     if (!packages.getTrusted().isEmpty()) {
/*  76 */       factory.setTrustedPackages(packages.getTrusted());
/*     */     }
/*  78 */     customize(factory);
/*  79 */     return factory;
/*     */   }
/*     */   
/*     */   private <T extends ActiveMQConnectionFactory> T createConnectionFactoryInstance(Class<T> factoryClass) throws InstantiationException, IllegalAccessException, InvocationTargetException, NoSuchMethodException
/*     */   {
/*  84 */     String brokerUrl = determineBrokerUrl();
/*  85 */     String user = this.properties.getUser();
/*  86 */     String password = this.properties.getPassword();
/*  87 */     if ((StringUtils.hasLength(user)) && (StringUtils.hasLength(password))) {
/*  88 */       return (ActiveMQConnectionFactory)factoryClass.getConstructor(new Class[] { String.class, String.class, String.class }).newInstance(new Object[] { user, password, brokerUrl });
/*     */     }
/*     */     
/*  91 */     return (ActiveMQConnectionFactory)factoryClass.getConstructor(new Class[] { String.class }).newInstance(new Object[] { brokerUrl });
/*     */   }
/*     */   
/*     */   private void customize(ActiveMQConnectionFactory connectionFactory) {
/*  95 */     for (ActiveMQConnectionFactoryCustomizer factoryCustomizer : this.factoryCustomizers) {
/*  96 */       factoryCustomizer.customize(connectionFactory);
/*     */     }
/*     */   }
/*     */   
/*     */   String determineBrokerUrl() {
/* 101 */     if (this.properties.getBrokerUrl() != null) {
/* 102 */       return this.properties.getBrokerUrl();
/*     */     }
/* 104 */     if (this.properties.isInMemory()) {
/* 105 */       return "vm://localhost?broker.persistent=false";
/*     */     }
/* 107 */     return "tcp://localhost:61616";
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\jms\activemq\ActiveMQConnectionFactoryFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */