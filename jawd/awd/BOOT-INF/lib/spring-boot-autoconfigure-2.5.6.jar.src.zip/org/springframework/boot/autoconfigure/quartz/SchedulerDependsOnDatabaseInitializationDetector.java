/*    */ package org.springframework.boot.autoconfigure.quartz;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ import org.quartz.Scheduler;
/*    */ import org.springframework.boot.sql.init.dependency.AbstractBeansOfTypeDependsOnDatabaseInitializationDetector;
/*    */ import org.springframework.scheduling.quartz.SchedulerFactoryBean;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SchedulerDependsOnDatabaseInitializationDetector
/*    */   extends AbstractBeansOfTypeDependsOnDatabaseInitializationDetector
/*    */ {
/*    */   protected Set<Class<?>> getDependsOnDatabaseInitializationBeanTypes()
/*    */   {
/* 40 */     return new HashSet(Arrays.asList(new Class[] { Scheduler.class, SchedulerFactoryBean.class }));
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\quartz\SchedulerDependsOnDatabaseInitializationDetector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */