/*     */ package org.springframework.boot.autoconfigure.batch;
/*     */ 
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.boot.context.properties.DeprecatedConfigurationProperty;
/*     */ import org.springframework.boot.jdbc.DataSourceInitializationMode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix="spring.batch")
/*     */ public class BatchProperties
/*     */ {
/*  35 */   private final Job job = new Job();
/*     */   
/*  37 */   private final Jdbc jdbc = new Jdbc();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   @DeprecatedConfigurationProperty(replacement="spring.batch.jdbc.schema")
/*     */   public String getSchema()
/*     */   {
/*  47 */     return this.jdbc.getSchema();
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public void setSchema(String schema) {
/*  52 */     this.jdbc.setSchema(schema);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   @DeprecatedConfigurationProperty(replacement="spring.batch.jdbc.table-prefix")
/*     */   public String getTablePrefix()
/*     */   {
/*  64 */     return this.jdbc.getTablePrefix();
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public void setTablePrefix(String tablePrefix) {
/*  69 */     this.jdbc.setTablePrefix(tablePrefix);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   @DeprecatedConfigurationProperty(replacement="spring.batch.jdbc.initialize-schema")
/*     */   public DataSourceInitializationMode getInitializeSchema()
/*     */   {
/*  81 */     return this.jdbc.getInitializeSchema();
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public void setInitializeSchema(DataSourceInitializationMode initializeSchema) {
/*  86 */     this.jdbc.setInitializeSchema(initializeSchema);
/*     */   }
/*     */   
/*     */   public Job getJob() {
/*  90 */     return this.job;
/*     */   }
/*     */   
/*     */   public Jdbc getJdbc() {
/*  94 */     return this.jdbc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Job
/*     */   {
/* 103 */     private String names = "";
/*     */     
/*     */     public String getNames() {
/* 106 */       return this.names;
/*     */     }
/*     */     
/*     */     public void setNames(String names) {
/* 110 */       this.names = names;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Jdbc
/*     */   {
/*     */     private static final String DEFAULT_SCHEMA_LOCATION = "classpath:org/springframework/batch/core/schema-@@platform@@.sql";
/*     */     
/*     */ 
/*     */ 
/* 123 */     private String schema = "classpath:org/springframework/batch/core/schema-@@platform@@.sql";
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private String tablePrefix;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 133 */     private DataSourceInitializationMode initializeSchema = DataSourceInitializationMode.EMBEDDED;
/*     */     
/*     */     public String getSchema() {
/* 136 */       return this.schema;
/*     */     }
/*     */     
/*     */     public void setSchema(String schema) {
/* 140 */       this.schema = schema;
/*     */     }
/*     */     
/*     */     public String getTablePrefix() {
/* 144 */       return this.tablePrefix;
/*     */     }
/*     */     
/*     */     public void setTablePrefix(String tablePrefix) {
/* 148 */       this.tablePrefix = tablePrefix;
/*     */     }
/*     */     
/*     */     public DataSourceInitializationMode getInitializeSchema() {
/* 152 */       return this.initializeSchema;
/*     */     }
/*     */     
/*     */     public void setInitializeSchema(DataSourceInitializationMode initializeSchema) {
/* 156 */       this.initializeSchema = initializeSchema;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\batch\BatchProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */