package org.springframework.boot.autoconfigure.data;

public enum RepositoryType
{
  AUTO,  IMPERATIVE,  NONE,  REACTIVE;
  
  private RepositoryType() {}
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\data\RepositoryType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */