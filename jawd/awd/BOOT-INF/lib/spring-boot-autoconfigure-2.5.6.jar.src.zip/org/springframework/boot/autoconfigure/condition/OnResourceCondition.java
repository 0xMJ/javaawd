/*    */ package org.springframework.boot.autoconfigure.condition;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.springframework.context.annotation.ConditionContext;
/*    */ import org.springframework.core.annotation.Order;
/*    */ import org.springframework.core.env.Environment;
/*    */ import org.springframework.core.io.Resource;
/*    */ import org.springframework.core.io.ResourceLoader;
/*    */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.MultiValueMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Order(-2147483628)
/*    */ class OnResourceCondition
/*    */   extends SpringBootCondition
/*    */ {
/*    */   public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata)
/*    */   {
/* 44 */     MultiValueMap<String, Object> attributes = metadata.getAllAnnotationAttributes(ConditionalOnResource.class.getName(), true);
/* 45 */     ResourceLoader loader = context.getResourceLoader();
/* 46 */     List<String> locations = new ArrayList();
/* 47 */     collectValues(locations, (List)attributes.get("resources"));
/* 48 */     Assert.isTrue(!locations.isEmpty(), "@ConditionalOnResource annotations must specify at least one resource location");
/*    */     
/* 50 */     List<String> missing = new ArrayList();
/* 51 */     for (String location : locations) {
/* 52 */       String resource = context.getEnvironment().resolvePlaceholders(location);
/* 53 */       if (!loader.getResource(resource).exists()) {
/* 54 */         missing.add(location);
/*    */       }
/*    */     }
/* 57 */     if (!missing.isEmpty()) {
/* 58 */       return ConditionOutcome.noMatch(ConditionMessage.forCondition(ConditionalOnResource.class, new Object[0])
/* 59 */         .didNotFind("resource", "resources").items(ConditionMessage.Style.QUOTE, missing));
/*    */     }
/* 61 */     return ConditionOutcome.match(ConditionMessage.forCondition(ConditionalOnResource.class, new Object[0])
/* 62 */       .found("location", "locations").items(locations));
/*    */   }
/*    */   
/*    */   private void collectValues(List<String> names, List<Object> values) {
/* 66 */     for (Object value : values) {
/* 67 */       for (Object item : (Object[])value) {
/* 68 */         names.add((String)item);
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\condition\OnResourceCondition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */