package org.springframework.boot.autoconfigure.session;

import org.springframework.session.web.http.DefaultCookieSerializer;

@FunctionalInterface
public abstract interface DefaultCookieSerializerCustomizer
{
  public abstract void customize(DefaultCookieSerializer paramDefaultCookieSerializer);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\session\DefaultCookieSerializerCustomizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */