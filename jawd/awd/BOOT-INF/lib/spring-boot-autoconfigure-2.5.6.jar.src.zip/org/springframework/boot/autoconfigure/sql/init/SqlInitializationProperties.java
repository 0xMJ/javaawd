/*     */ package org.springframework.boot.autoconfigure.sql.init;
/*     */ 
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.List;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.boot.sql.init.DatabaseInitializationMode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties("spring.sql.init")
/*     */ public class SqlInitializationProperties
/*     */ {
/*     */   private List<String> schemaLocations;
/*     */   private List<String> dataLocations;
/*  49 */   private String platform = "all";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String username;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String password;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  66 */   private boolean continueOnError = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  71 */   private String separator = ";";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private Charset encoding;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  81 */   private DatabaseInitializationMode mode = DatabaseInitializationMode.EMBEDDED;
/*     */   
/*     */   public List<String> getSchemaLocations() {
/*  84 */     return this.schemaLocations;
/*     */   }
/*     */   
/*     */   public void setSchemaLocations(List<String> schemaLocations) {
/*  88 */     this.schemaLocations = schemaLocations;
/*     */   }
/*     */   
/*     */   public List<String> getDataLocations() {
/*  92 */     return this.dataLocations;
/*     */   }
/*     */   
/*     */   public void setDataLocations(List<String> dataLocations) {
/*  96 */     this.dataLocations = dataLocations;
/*     */   }
/*     */   
/*     */   public String getPlatform() {
/* 100 */     return this.platform;
/*     */   }
/*     */   
/*     */   public void setPlatform(String platform) {
/* 104 */     this.platform = platform;
/*     */   }
/*     */   
/*     */   public String getUsername() {
/* 108 */     return this.username;
/*     */   }
/*     */   
/*     */   public void setUsername(String username) {
/* 112 */     this.username = username;
/*     */   }
/*     */   
/*     */   public String getPassword() {
/* 116 */     return this.password;
/*     */   }
/*     */   
/*     */   public void setPassword(String password) {
/* 120 */     this.password = password;
/*     */   }
/*     */   
/*     */   public boolean isContinueOnError() {
/* 124 */     return this.continueOnError;
/*     */   }
/*     */   
/*     */   public void setContinueOnError(boolean continueOnError) {
/* 128 */     this.continueOnError = continueOnError;
/*     */   }
/*     */   
/*     */   public String getSeparator() {
/* 132 */     return this.separator;
/*     */   }
/*     */   
/*     */   public void setSeparator(String separator) {
/* 136 */     this.separator = separator;
/*     */   }
/*     */   
/*     */   public Charset getEncoding() {
/* 140 */     return this.encoding;
/*     */   }
/*     */   
/*     */   public void setEncoding(Charset encoding) {
/* 144 */     this.encoding = encoding;
/*     */   }
/*     */   
/*     */   public DatabaseInitializationMode getMode() {
/* 148 */     return this.mode;
/*     */   }
/*     */   
/*     */   public void setMode(DatabaseInitializationMode mode) {
/* 152 */     this.mode = mode;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\sql\init\SqlInitializationProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */