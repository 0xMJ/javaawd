/*    */ package org.springframework.boot.autoconfigure.flyway;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import org.flywaydb.core.Flyway;
/*    */ import org.springframework.beans.factory.InitializingBean;
/*    */ import org.springframework.core.Ordered;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FlywayMigrationInitializer
/*    */   implements InitializingBean, Ordered
/*    */ {
/*    */   private final Flyway flyway;
/*    */   private final FlywayMigrationStrategy migrationStrategy;
/* 38 */   private int order = 0;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public FlywayMigrationInitializer(Flyway flyway)
/*    */   {
/* 45 */     this(flyway, null);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public FlywayMigrationInitializer(Flyway flyway, FlywayMigrationStrategy migrationStrategy)
/*    */   {
/* 54 */     Assert.notNull(flyway, "Flyway must not be null");
/* 55 */     this.flyway = flyway;
/* 56 */     this.migrationStrategy = migrationStrategy;
/*    */   }
/*    */   
/*    */   public void afterPropertiesSet() throws Exception
/*    */   {
/* 61 */     if (this.migrationStrategy != null) {
/* 62 */       this.migrationStrategy.migrate(this.flyway);
/*    */     } else {
/*    */       try
/*    */       {
/* 66 */         this.flyway.migrate();
/*    */       }
/*    */       catch (NoSuchMethodError ex)
/*    */       {
/* 70 */         this.flyway.getClass().getMethod("migrate", new Class[0]).invoke(this.flyway, new Object[0]);
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public int getOrder()
/*    */   {
/* 77 */     return this.order;
/*    */   }
/*    */   
/*    */   public void setOrder(int order) {
/* 81 */     this.order = order;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\flyway\FlywayMigrationInitializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */