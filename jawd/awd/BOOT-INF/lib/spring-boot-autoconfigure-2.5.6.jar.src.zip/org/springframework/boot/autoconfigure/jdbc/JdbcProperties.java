/*    */ package org.springframework.boot.autoconfigure.jdbc;
/*    */ 
/*    */ import java.time.Duration;
/*    */ import java.time.temporal.ChronoUnit;
/*    */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*    */ import org.springframework.boot.convert.DurationUnit;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @ConfigurationProperties(prefix="spring.jdbc")
/*    */ public class JdbcProperties
/*    */ {
/* 35 */   private final Template template = new Template();
/*    */   
/*    */   public Template getTemplate() {
/* 38 */     return this.template;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static class Template
/*    */   {
/* 50 */     private int fetchSize = -1;
/*    */     
/*    */ 
/*    */ 
/*    */ 
/* 55 */     private int maxRows = -1;
/*    */     
/*    */ 
/*    */     @DurationUnit(ChronoUnit.SECONDS)
/*    */     private Duration queryTimeout;
/*    */     
/*    */ 
/*    */ 
/*    */     public int getFetchSize()
/*    */     {
/* 65 */       return this.fetchSize;
/*    */     }
/*    */     
/*    */     public void setFetchSize(int fetchSize) {
/* 69 */       this.fetchSize = fetchSize;
/*    */     }
/*    */     
/*    */     public int getMaxRows() {
/* 73 */       return this.maxRows;
/*    */     }
/*    */     
/*    */     public void setMaxRows(int maxRows) {
/* 77 */       this.maxRows = maxRows;
/*    */     }
/*    */     
/*    */     public Duration getQueryTimeout() {
/* 81 */       return this.queryTimeout;
/*    */     }
/*    */     
/*    */     public void setQueryTimeout(Duration queryTimeout) {
/* 85 */       this.queryTimeout = queryTimeout;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\jdbc\JdbcProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */