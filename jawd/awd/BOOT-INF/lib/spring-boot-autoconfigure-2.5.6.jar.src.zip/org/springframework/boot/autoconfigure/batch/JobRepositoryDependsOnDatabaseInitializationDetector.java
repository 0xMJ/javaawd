/*    */ package org.springframework.boot.autoconfigure.batch;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.Set;
/*    */ import org.springframework.batch.core.repository.JobRepository;
/*    */ import org.springframework.boot.sql.init.dependency.AbstractBeansOfTypeDependsOnDatabaseInitializationDetector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class JobRepositoryDependsOnDatabaseInitializationDetector
/*    */   extends AbstractBeansOfTypeDependsOnDatabaseInitializationDetector
/*    */ {
/*    */   protected Set<Class<?>> getDependsOnDatabaseInitializationBeanTypes()
/*    */   {
/* 37 */     return Collections.singleton(JobRepository.class);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\batch\JobRepositoryDependsOnDatabaseInitializationDetector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */