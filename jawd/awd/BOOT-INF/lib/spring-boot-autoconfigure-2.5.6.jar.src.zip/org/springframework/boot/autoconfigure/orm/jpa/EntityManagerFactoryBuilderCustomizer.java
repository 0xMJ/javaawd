package org.springframework.boot.autoconfigure.orm.jpa;

import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;

@FunctionalInterface
public abstract interface EntityManagerFactoryBuilderCustomizer
{
  public abstract void customize(EntityManagerFactoryBuilder paramEntityManagerFactoryBuilder);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\orm\jpa\EntityManagerFactoryBuilderCustomizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */