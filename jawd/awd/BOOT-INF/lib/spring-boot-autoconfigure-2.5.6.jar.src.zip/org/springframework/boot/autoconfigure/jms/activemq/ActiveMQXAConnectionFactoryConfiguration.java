/*    */ package org.springframework.boot.autoconfigure.jms.activemq;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.stream.Collectors;
/*    */ import java.util.stream.Stream;
/*    */ import javax.jms.ConnectionFactory;
/*    */ import javax.transaction.TransactionManager;
/*    */ import org.apache.activemq.ActiveMQConnectionFactory;
/*    */ import org.apache.activemq.ActiveMQXAConnectionFactory;
/*    */ import org.springframework.beans.factory.ObjectProvider;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
/*    */ import org.springframework.boot.jms.XAConnectionFactoryWrapper;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.Primary;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods=false)
/*    */ @ConditionalOnClass({TransactionManager.class})
/*    */ @ConditionalOnBean({XAConnectionFactoryWrapper.class})
/*    */ @ConditionalOnMissingBean({ConnectionFactory.class})
/*    */ class ActiveMQXAConnectionFactoryConfiguration
/*    */ {
/*    */   @Primary
/*    */   @Bean(name={"jmsConnectionFactory", "xaJmsConnectionFactory"})
/*    */   ConnectionFactory jmsConnectionFactory(ActiveMQProperties properties, ObjectProvider<ActiveMQConnectionFactoryCustomizer> factoryCustomizers, XAConnectionFactoryWrapper wrapper)
/*    */     throws Exception
/*    */   {
/* 56 */     ActiveMQXAConnectionFactory connectionFactory = (ActiveMQXAConnectionFactory)new ActiveMQConnectionFactoryFactory(properties, (List)factoryCustomizers.orderedStream().collect(Collectors.toList())).createConnectionFactory(ActiveMQXAConnectionFactory.class);
/* 57 */     return wrapper.wrapConnectionFactory(connectionFactory);
/*    */   }
/*    */   
/*    */ 
/*    */   @Bean
/*    */   @ConditionalOnProperty(prefix="spring.activemq.pool", name={"enabled"}, havingValue="false", matchIfMissing=true)
/*    */   ActiveMQConnectionFactory nonXaJmsConnectionFactory(ActiveMQProperties properties, ObjectProvider<ActiveMQConnectionFactoryCustomizer> factoryCustomizers)
/*    */   {
/* 65 */     return 
/*    */     
/* 67 */       new ActiveMQConnectionFactoryFactory(properties, (List)factoryCustomizers.orderedStream().collect(Collectors.toList())).createConnectionFactory(ActiveMQConnectionFactory.class);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\jms\activemq\ActiveMQXAConnectionFactoryConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */