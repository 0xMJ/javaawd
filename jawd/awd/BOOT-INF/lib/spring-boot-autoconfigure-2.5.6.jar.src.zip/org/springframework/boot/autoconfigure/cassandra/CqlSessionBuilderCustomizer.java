package org.springframework.boot.autoconfigure.cassandra;

import com.datastax.oss.driver.api.core.CqlSessionBuilder;

@FunctionalInterface
public abstract interface CqlSessionBuilderCustomizer
{
  public abstract void customize(CqlSessionBuilder paramCqlSessionBuilder);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\cassandra\CqlSessionBuilderCustomizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */