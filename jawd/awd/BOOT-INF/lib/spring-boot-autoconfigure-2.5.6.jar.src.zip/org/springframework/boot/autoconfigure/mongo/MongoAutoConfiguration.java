/*    */ package org.springframework.boot.autoconfigure.mongo;
/*    */ 
/*    */ import com.mongodb.MongoClientSettings;
/*    */ import com.mongodb.MongoClientSettings.Builder;
/*    */ import com.mongodb.client.MongoClient;
/*    */ import java.util.List;
/*    */ import java.util.stream.Collectors;
/*    */ import java.util.stream.Stream;
/*    */ import org.springframework.beans.factory.ObjectProvider;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
/*    */ import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
/*    */ import org.springframework.boot.context.properties.EnableConfigurationProperties;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.core.env.Environment;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods=false)
/*    */ @ConditionalOnClass({MongoClient.class})
/*    */ @EnableConfigurationProperties({MongoProperties.class})
/*    */ @ConditionalOnMissingBean(type={"org.springframework.data.mongodb.MongoDatabaseFactory"})
/*    */ public class MongoAutoConfiguration
/*    */ {
/*    */   @Bean
/*    */   @ConditionalOnMissingBean({MongoClient.class})
/*    */   public MongoClient mongo(ObjectProvider<MongoClientSettingsBuilderCustomizer> builderCustomizers, MongoClientSettings settings)
/*    */   {
/* 54 */     return 
/* 55 */       (MongoClient)new MongoClientFactory((List)builderCustomizers.orderedStream().collect(Collectors.toList())).createMongoClient(settings);
/*    */   }
/*    */   
/*    */   @Configuration(proxyBeanMethods=false)
/*    */   @ConditionalOnMissingBean({MongoClientSettings.class})
/*    */   static class MongoClientSettingsConfiguration
/*    */   {
/*    */     @Bean
/*    */     MongoClientSettings mongoClientSettings() {
/* 64 */       return MongoClientSettings.builder().build();
/*    */     }
/*    */     
/*    */     @Bean
/*    */     MongoPropertiesClientSettingsBuilderCustomizer mongoPropertiesCustomizer(MongoProperties properties, Environment environment)
/*    */     {
/* 70 */       return new MongoPropertiesClientSettingsBuilderCustomizer(properties, environment);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\mongo\MongoAutoConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */