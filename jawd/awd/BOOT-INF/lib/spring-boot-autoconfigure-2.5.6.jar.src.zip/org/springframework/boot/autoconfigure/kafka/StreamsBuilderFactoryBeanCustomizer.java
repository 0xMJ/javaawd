package org.springframework.boot.autoconfigure.kafka;

import org.springframework.kafka.config.StreamsBuilderFactoryBean;

@FunctionalInterface
public abstract interface StreamsBuilderFactoryBeanCustomizer
{
  public abstract void customize(StreamsBuilderFactoryBean paramStreamsBuilderFactoryBean);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\kafka\StreamsBuilderFactoryBeanCustomizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */