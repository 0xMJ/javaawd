/*     */ package org.springframework.boot.autoconfigure.ldap;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfigurationProperties(prefix="spring.ldap")
/*     */ public class LdapProperties
/*     */ {
/*     */   private static final int DEFAULT_PORT = 389;
/*     */   private String[] urls;
/*     */   private String base;
/*     */   private String username;
/*     */   private String password;
/*     */   private Boolean anonymousReadOnly;
/*  68 */   private final Map<String, String> baseEnvironment = new HashMap();
/*     */   
/*  70 */   private final Template template = new Template();
/*     */   
/*     */   public String[] getUrls() {
/*  73 */     return this.urls;
/*     */   }
/*     */   
/*     */   public void setUrls(String[] urls) {
/*  77 */     this.urls = urls;
/*     */   }
/*     */   
/*     */   public String getBase() {
/*  81 */     return this.base;
/*     */   }
/*     */   
/*     */   public void setBase(String base) {
/*  85 */     this.base = base;
/*     */   }
/*     */   
/*     */   public String getUsername() {
/*  89 */     return this.username;
/*     */   }
/*     */   
/*     */   public void setUsername(String username) {
/*  93 */     this.username = username;
/*     */   }
/*     */   
/*     */   public String getPassword() {
/*  97 */     return this.password;
/*     */   }
/*     */   
/*     */   public void setPassword(String password) {
/* 101 */     this.password = password;
/*     */   }
/*     */   
/*     */   public Boolean getAnonymousReadOnly() {
/* 105 */     return this.anonymousReadOnly;
/*     */   }
/*     */   
/*     */   public void setAnonymousReadOnly(Boolean anonymousReadOnly) {
/* 109 */     this.anonymousReadOnly = anonymousReadOnly;
/*     */   }
/*     */   
/*     */   public Map<String, String> getBaseEnvironment() {
/* 113 */     return this.baseEnvironment;
/*     */   }
/*     */   
/*     */   public Template getTemplate() {
/* 117 */     return this.template;
/*     */   }
/*     */   
/*     */   public String[] determineUrls(Environment environment) {
/* 121 */     if (ObjectUtils.isEmpty(this.urls)) {
/* 122 */       return new String[] { "ldap://localhost:" + determinePort(environment) };
/*     */     }
/* 124 */     return this.urls;
/*     */   }
/*     */   
/*     */   private int determinePort(Environment environment) {
/* 128 */     Assert.notNull(environment, "Environment must not be null");
/* 129 */     String localPort = environment.getProperty("local.ldap.port");
/* 130 */     if (localPort != null) {
/* 131 */       return Integer.parseInt(localPort);
/*     */     }
/* 133 */     return 389;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Template
/*     */   {
/* 145 */     private boolean ignorePartialResultException = false;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 151 */     private boolean ignoreNameNotFoundException = false;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 157 */     private boolean ignoreSizeLimitExceededException = true;
/*     */     
/*     */     public boolean isIgnorePartialResultException() {
/* 160 */       return this.ignorePartialResultException;
/*     */     }
/*     */     
/*     */     public void setIgnorePartialResultException(boolean ignorePartialResultException) {
/* 164 */       this.ignorePartialResultException = ignorePartialResultException;
/*     */     }
/*     */     
/*     */     public boolean isIgnoreNameNotFoundException() {
/* 168 */       return this.ignoreNameNotFoundException;
/*     */     }
/*     */     
/*     */     public void setIgnoreNameNotFoundException(boolean ignoreNameNotFoundException) {
/* 172 */       this.ignoreNameNotFoundException = ignoreNameNotFoundException;
/*     */     }
/*     */     
/*     */     public boolean isIgnoreSizeLimitExceededException() {
/* 176 */       return this.ignoreSizeLimitExceededException;
/*     */     }
/*     */     
/*     */     public void setIgnoreSizeLimitExceededException(Boolean ignoreSizeLimitExceededException) {
/* 180 */       this.ignoreSizeLimitExceededException = ignoreSizeLimitExceededException.booleanValue();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\ldap\LdapProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */