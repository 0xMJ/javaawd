/*    */ package org.springframework.boot.autoconfigure.condition;
/*    */ 
/*    */ import javax.servlet.ServletContext;
/*    */ import org.springframework.context.annotation.ConditionContext;
/*    */ import org.springframework.core.io.ResourceLoader;
/*    */ import org.springframework.core.type.AnnotatedTypeMetadata;
/*    */ import org.springframework.web.context.WebApplicationContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class OnWarDeploymentCondition
/*    */   extends SpringBootCondition
/*    */ {
/*    */   public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata)
/*    */   {
/* 37 */     ResourceLoader resourceLoader = context.getResourceLoader();
/* 38 */     if ((resourceLoader instanceof WebApplicationContext)) {
/* 39 */       WebApplicationContext applicationContext = (WebApplicationContext)resourceLoader;
/* 40 */       ServletContext servletContext = applicationContext.getServletContext();
/* 41 */       if (servletContext != null) {
/* 42 */         return ConditionOutcome.match("Application is deployed as a WAR file.");
/*    */       }
/*    */     }
/* 45 */     return ConditionOutcome.noMatch(ConditionMessage.forCondition(ConditionalOnWarDeployment.class, new Object[0])
/* 46 */       .because("the application is not deployed as a WAR file."));
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\condition\OnWarDeploymentCondition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */