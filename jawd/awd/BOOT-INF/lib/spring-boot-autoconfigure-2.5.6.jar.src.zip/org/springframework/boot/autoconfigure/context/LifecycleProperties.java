/*    */ package org.springframework.boot.autoconfigure.context;
/*    */ 
/*    */ import java.time.Duration;
/*    */ import org.springframework.boot.context.properties.ConfigurationProperties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @ConfigurationProperties(prefix="spring.lifecycle")
/*    */ public class LifecycleProperties
/*    */ {
/* 36 */   private Duration timeoutPerShutdownPhase = Duration.ofSeconds(30L);
/*    */   
/*    */   public Duration getTimeoutPerShutdownPhase() {
/* 39 */     return this.timeoutPerShutdownPhase;
/*    */   }
/*    */   
/*    */   public void setTimeoutPerShutdownPhase(Duration timeoutPerShutdownPhase) {
/* 43 */     this.timeoutPerShutdownPhase = timeoutPerShutdownPhase;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-autoconfigure-2.5.6.jar!\org\springframework\boot\autoconfigure\context\LifecycleProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */