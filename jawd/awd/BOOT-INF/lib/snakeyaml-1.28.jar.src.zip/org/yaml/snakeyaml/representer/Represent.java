package org.yaml.snakeyaml.representer;

import org.yaml.snakeyaml.nodes.Node;

public abstract interface Represent
{
  public abstract Node representData(Object paramObject);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\snakeyaml-1.28.jar!\org\yaml\snakeyaml\representer\Represent.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */