/*    */ package org.yaml.snakeyaml.error;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MissingEnvironmentVariableException
/*    */   extends YAMLException
/*    */ {
/*    */   public MissingEnvironmentVariableException(String message)
/*    */   {
/* 25 */     super(message);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\snakeyaml-1.28.jar!\org\yaml\snakeyaml\error\MissingEnvironmentVariableException.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */