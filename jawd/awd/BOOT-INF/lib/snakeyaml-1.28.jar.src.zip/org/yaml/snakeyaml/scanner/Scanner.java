package org.yaml.snakeyaml.scanner;

import org.yaml.snakeyaml.tokens.Token;
import org.yaml.snakeyaml.tokens.Token.ID;

public abstract interface Scanner
{
  public abstract boolean checkToken(Token.ID... paramVarArgs);
  
  public abstract Token peekToken();
  
  public abstract Token getToken();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\snakeyaml-1.28.jar!\org\yaml\snakeyaml\scanner\Scanner.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */