package org.yaml.snakeyaml.comments;

public enum CommentType
{
  BLANK_LINE,  BLOCK,  IN_LINE;
  
  private CommentType() {}
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\snakeyaml-1.28.jar!\org\yaml\snakeyaml\comments\CommentType.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */