package org.yaml.snakeyaml.parser;

import org.yaml.snakeyaml.events.Event;
import org.yaml.snakeyaml.events.Event.ID;

public abstract interface Parser
{
  public abstract boolean checkEvent(Event.ID paramID);
  
  public abstract Event peekEvent();
  
  public abstract Event getEvent();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\snakeyaml-1.28.jar!\org\yaml\snakeyaml\parser\Parser.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */