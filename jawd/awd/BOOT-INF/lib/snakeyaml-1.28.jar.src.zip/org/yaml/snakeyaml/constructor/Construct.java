package org.yaml.snakeyaml.constructor;

import org.yaml.snakeyaml.nodes.Node;

public abstract interface Construct
{
  public abstract Object construct(Node paramNode);
  
  public abstract void construct2ndStep(Node paramNode, Object paramObject);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\snakeyaml-1.28.jar!\org\yaml\snakeyaml\constructor\Construct.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */