/*    */ package org.yaml.snakeyaml.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EnumUtils
/*    */ {
/*    */   public static <T extends Enum<T>> T findEnumInsensitiveCase(Class<T> enumType, String name)
/*    */   {
/* 30 */     for (T constant : (Enum[])enumType.getEnumConstants()) {
/* 31 */       if (constant.name().compareToIgnoreCase(name) == 0) {
/* 32 */         return constant;
/*    */       }
/*    */     }
/* 35 */     throw new IllegalArgumentException("No enum constant " + enumType.getCanonicalName() + "." + name);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\snakeyaml-1.28.jar!\org\yaml\snakeyaml\util\EnumUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */