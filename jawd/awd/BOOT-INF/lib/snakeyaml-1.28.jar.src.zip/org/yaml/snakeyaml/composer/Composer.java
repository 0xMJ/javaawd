/*     */ package org.yaml.snakeyaml.composer;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.yaml.snakeyaml.DumperOptions.FlowStyle;
/*     */ import org.yaml.snakeyaml.LoaderOptions;
/*     */ import org.yaml.snakeyaml.comments.CommentEventsCollector;
/*     */ import org.yaml.snakeyaml.comments.CommentLine;
/*     */ import org.yaml.snakeyaml.comments.CommentType;
/*     */ import org.yaml.snakeyaml.error.Mark;
/*     */ import org.yaml.snakeyaml.error.YAMLException;
/*     */ import org.yaml.snakeyaml.events.AliasEvent;
/*     */ import org.yaml.snakeyaml.events.Event;
/*     */ import org.yaml.snakeyaml.events.Event.ID;
/*     */ import org.yaml.snakeyaml.events.ImplicitTuple;
/*     */ import org.yaml.snakeyaml.events.MappingStartEvent;
/*     */ import org.yaml.snakeyaml.events.NodeEvent;
/*     */ import org.yaml.snakeyaml.events.ScalarEvent;
/*     */ import org.yaml.snakeyaml.events.SequenceStartEvent;
/*     */ import org.yaml.snakeyaml.nodes.MappingNode;
/*     */ import org.yaml.snakeyaml.nodes.Node;
/*     */ import org.yaml.snakeyaml.nodes.NodeId;
/*     */ import org.yaml.snakeyaml.nodes.NodeTuple;
/*     */ import org.yaml.snakeyaml.nodes.ScalarNode;
/*     */ import org.yaml.snakeyaml.nodes.SequenceNode;
/*     */ import org.yaml.snakeyaml.nodes.Tag;
/*     */ import org.yaml.snakeyaml.parser.Parser;
/*     */ import org.yaml.snakeyaml.resolver.Resolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Composer
/*     */ {
/*     */   protected final Parser parser;
/*     */   private final Resolver resolver;
/*     */   private final Map<String, Node> anchors;
/*     */   private final Set<Node> recursiveNodes;
/*  61 */   private int nonScalarAliasesCount = 0;
/*     */   private final LoaderOptions loadingConfig;
/*     */   private final CommentEventsCollector blockCommentsCollector;
/*     */   private final CommentEventsCollector inlineCommentsCollector;
/*     */   
/*     */   public Composer(Parser parser, Resolver resolver) {
/*  67 */     this(parser, resolver, new LoaderOptions());
/*     */   }
/*     */   
/*     */   public Composer(Parser parser, Resolver resolver, LoaderOptions loadingConfig) {
/*  71 */     this.parser = parser;
/*  72 */     this.resolver = resolver;
/*  73 */     this.anchors = new HashMap();
/*  74 */     this.recursiveNodes = new HashSet();
/*  75 */     this.loadingConfig = loadingConfig;
/*  76 */     this.blockCommentsCollector = new CommentEventsCollector(parser, new CommentType[] { CommentType.BLANK_LINE, CommentType.BLOCK });
/*     */     
/*  78 */     this.inlineCommentsCollector = new CommentEventsCollector(parser, new CommentType[] { CommentType.IN_LINE });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean checkNode()
/*     */   {
/*  89 */     if (this.parser.checkEvent(Event.ID.StreamStart)) {
/*  90 */       this.parser.getEvent();
/*     */     }
/*     */     
/*  93 */     return !this.parser.checkEvent(Event.ID.StreamEnd);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Node getNode()
/*     */   {
/* 103 */     this.blockCommentsCollector.collectEvents();
/* 104 */     if (this.parser.checkEvent(Event.ID.StreamEnd)) {
/* 105 */       List<CommentLine> commentLines = this.blockCommentsCollector.consume();
/* 106 */       Mark startMark = ((CommentLine)commentLines.get(0)).getStartMark();
/* 107 */       List<NodeTuple> children = Collections.emptyList();
/* 108 */       Node node = new MappingNode(Tag.COMMENT, false, children, startMark, null, DumperOptions.FlowStyle.BLOCK);
/* 109 */       node.setBlockComments(commentLines);
/* 110 */       return node;
/*     */     }
/*     */     
/* 113 */     this.parser.getEvent();
/*     */     
/* 115 */     Node node = composeNode(null, this.blockCommentsCollector.collectEvents().consume());
/*     */     
/* 117 */     this.blockCommentsCollector.collectEvents();
/* 118 */     if (!this.blockCommentsCollector.isEmpty()) {
/* 119 */       node.setEndComments(this.blockCommentsCollector.consume());
/*     */     }
/* 121 */     this.parser.getEvent();
/* 122 */     this.anchors.clear();
/* 123 */     this.recursiveNodes.clear();
/* 124 */     return node;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Node getSingleNode()
/*     */   {
/* 138 */     this.parser.getEvent();
/*     */     
/* 140 */     while (this.parser.checkEvent(Event.ID.Comment)) {
/* 141 */       this.parser.getEvent();
/*     */     }
/*     */     
/* 144 */     Node document = null;
/* 145 */     if (!this.parser.checkEvent(Event.ID.StreamEnd)) {
/* 146 */       document = getNode();
/*     */     }
/*     */     
/* 149 */     while (this.parser.checkEvent(Event.ID.Comment)) {
/* 150 */       this.parser.getEvent();
/*     */     }
/*     */     
/* 153 */     if (!this.parser.checkEvent(Event.ID.StreamEnd)) {
/* 154 */       Event event = this.parser.getEvent();
/* 155 */       Mark contextMark = document != null ? document.getStartMark() : null;
/* 156 */       throw new ComposerException("expected a single document in the stream", contextMark, "but found another document", event.getStartMark());
/*     */     }
/*     */     
/*     */ 
/* 160 */     this.parser.getEvent();
/* 161 */     return document;
/*     */   }
/*     */   
/*     */   private Node composeNode(Node parent, List<CommentLine> blockComments) {
/* 165 */     if (parent != null)
/* 166 */       this.recursiveNodes.add(parent);
/*     */     Node node;
/* 168 */     if (this.parser.checkEvent(Event.ID.Alias)) {
/* 169 */       AliasEvent event = (AliasEvent)this.parser.getEvent();
/* 170 */       String anchor = event.getAnchor();
/* 171 */       if (!this.anchors.containsKey(anchor)) {
/* 172 */         throw new ComposerException(null, null, "found undefined alias " + anchor, event.getStartMark());
/*     */       }
/*     */       
/* 175 */       Node node = (Node)this.anchors.get(anchor);
/* 176 */       if (!(node instanceof ScalarNode)) {
/* 177 */         this.nonScalarAliasesCount += 1;
/* 178 */         if (this.nonScalarAliasesCount > this.loadingConfig.getMaxAliasesForCollections()) {
/* 179 */           throw new YAMLException("Number of aliases for non-scalar nodes exceeds the specified max=" + this.loadingConfig.getMaxAliasesForCollections());
/*     */         }
/*     */       }
/* 182 */       if (this.recursiveNodes.remove(node)) {
/* 183 */         node.setTwoStepsConstruction(true);
/*     */       }
/* 185 */       node.setBlockComments(blockComments);
/*     */     } else {
/* 187 */       NodeEvent event = (NodeEvent)this.parser.peekEvent();
/* 188 */       String anchor = event.getAnchor();
/*     */       Node node;
/* 190 */       if (this.parser.checkEvent(Event.ID.Scalar)) {
/* 191 */         node = composeScalarNode(anchor, blockComments); } else { Node node;
/* 192 */         if (this.parser.checkEvent(Event.ID.SequenceStart)) {
/* 193 */           node = composeSequenceNode(anchor, blockComments);
/*     */         } else
/* 195 */           node = composeMappingNode(anchor, blockComments);
/*     */       }
/*     */     }
/* 198 */     this.recursiveNodes.remove(parent);
/* 199 */     return node;
/*     */   }
/*     */   
/*     */   protected Node composeScalarNode(String anchor, List<CommentLine> blockComments) {
/* 203 */     ScalarEvent ev = (ScalarEvent)this.parser.getEvent();
/* 204 */     String tag = ev.getTag();
/* 205 */     boolean resolved = false;
/*     */     Tag nodeTag;
/* 207 */     if ((tag == null) || (tag.equals("!"))) {
/* 208 */       Tag nodeTag = this.resolver.resolve(NodeId.scalar, ev.getValue(), ev.getImplicit().canOmitTagInPlainScalar());
/*     */       
/* 210 */       resolved = true;
/*     */     } else {
/* 212 */       nodeTag = new Tag(tag);
/*     */     }
/* 214 */     Node node = new ScalarNode(nodeTag, resolved, ev.getValue(), ev.getStartMark(), ev.getEndMark(), ev.getScalarStyle());
/*     */     
/* 216 */     if (anchor != null) {
/* 217 */       node.setAnchor(anchor);
/* 218 */       this.anchors.put(anchor, node);
/*     */     }
/* 220 */     node.setBlockComments(blockComments);
/* 221 */     node.setInLineComments(this.inlineCommentsCollector.collectEvents().consume());
/* 222 */     return node;
/*     */   }
/*     */   
/*     */   protected Node composeSequenceNode(String anchor, List<CommentLine> blockComments) {
/* 226 */     SequenceStartEvent startEvent = (SequenceStartEvent)this.parser.getEvent();
/* 227 */     String tag = startEvent.getTag();
/*     */     
/*     */ 
/* 230 */     boolean resolved = false;
/* 231 */     Tag nodeTag; if ((tag == null) || (tag.equals("!"))) {
/* 232 */       Tag nodeTag = this.resolver.resolve(NodeId.sequence, null, startEvent.getImplicit());
/* 233 */       resolved = true;
/*     */     } else {
/* 235 */       nodeTag = new Tag(tag);
/*     */     }
/* 237 */     ArrayList<Node> children = new ArrayList();
/* 238 */     SequenceNode node = new SequenceNode(nodeTag, resolved, children, startEvent.getStartMark(), null, startEvent.getFlowStyle());
/*     */     
/* 240 */     if (anchor != null) {
/* 241 */       node.setAnchor(anchor);
/* 242 */       this.anchors.put(anchor, node);
/*     */     }
/* 244 */     node.setBlockComments(blockComments);
/* 245 */     node.setInLineComments(this.inlineCommentsCollector.collectEvents().consume());
/* 246 */     while (!this.parser.checkEvent(Event.ID.SequenceEnd)) {
/* 247 */       this.blockCommentsCollector.collectEvents();
/* 248 */       if (this.parser.checkEvent(Event.ID.SequenceEnd)) {
/*     */         break;
/*     */       }
/* 251 */       children.add(composeNode(node, this.blockCommentsCollector.consume()));
/*     */     }
/* 253 */     Event endEvent = this.parser.getEvent();
/* 254 */     node.setEndMark(endEvent.getEndMark());
/* 255 */     this.inlineCommentsCollector.collectEvents();
/* 256 */     if (!this.inlineCommentsCollector.isEmpty()) {
/* 257 */       node.setInLineComments(this.inlineCommentsCollector.consume());
/*     */     }
/* 259 */     return node;
/*     */   }
/*     */   
/*     */   protected Node composeMappingNode(String anchor, List<CommentLine> blockComments) {
/* 263 */     MappingStartEvent startEvent = (MappingStartEvent)this.parser.getEvent();
/* 264 */     String tag = startEvent.getTag();
/*     */     
/* 266 */     boolean resolved = false;
/* 267 */     Tag nodeTag; if ((tag == null) || (tag.equals("!"))) {
/* 268 */       Tag nodeTag = this.resolver.resolve(NodeId.mapping, null, startEvent.getImplicit());
/* 269 */       resolved = true;
/*     */     } else {
/* 271 */       nodeTag = new Tag(tag);
/*     */     }
/*     */     
/* 274 */     List<NodeTuple> children = new ArrayList();
/* 275 */     MappingNode node = new MappingNode(nodeTag, resolved, children, startEvent.getStartMark(), null, startEvent.getFlowStyle());
/*     */     
/* 277 */     if (anchor != null) {
/* 278 */       node.setAnchor(anchor);
/* 279 */       this.anchors.put(anchor, node);
/*     */     }
/* 281 */     node.setBlockComments(blockComments);
/* 282 */     node.setInLineComments(this.inlineCommentsCollector.collectEvents().consume());
/* 283 */     while (!this.parser.checkEvent(Event.ID.MappingEnd)) {
/* 284 */       this.blockCommentsCollector.collectEvents();
/* 285 */       if (this.parser.checkEvent(Event.ID.MappingEnd)) {
/*     */         break;
/*     */       }
/* 288 */       composeMappingChildren(children, node, this.blockCommentsCollector.consume());
/*     */     }
/* 290 */     Event endEvent = this.parser.getEvent();
/* 291 */     node.setEndMark(endEvent.getEndMark());
/* 292 */     this.inlineCommentsCollector.collectEvents();
/* 293 */     if (!this.inlineCommentsCollector.isEmpty()) {
/* 294 */       node.setInLineComments(this.inlineCommentsCollector.consume());
/*     */     }
/* 296 */     return node;
/*     */   }
/*     */   
/*     */   protected void composeMappingChildren(List<NodeTuple> children, MappingNode node, List<CommentLine> keyBlockComments) {
/* 300 */     Node itemKey = composeKeyNode(node, keyBlockComments);
/* 301 */     if (itemKey.getTag().equals(Tag.MERGE)) {
/* 302 */       node.setMerged(true);
/*     */     }
/* 304 */     Node itemValue = composeValueNode(node, this.blockCommentsCollector.collectEvents().consume());
/* 305 */     children.add(new NodeTuple(itemKey, itemValue));
/*     */   }
/*     */   
/*     */   protected Node composeKeyNode(MappingNode node, List<CommentLine> blockComments) {
/* 309 */     return composeNode(node, blockComments);
/*     */   }
/*     */   
/*     */   protected Node composeValueNode(MappingNode node, List<CommentLine> blockComments) {
/* 313 */     return composeNode(node, blockComments);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\snakeyaml-1.28.jar!\org\yaml\snakeyaml\composer\Composer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */