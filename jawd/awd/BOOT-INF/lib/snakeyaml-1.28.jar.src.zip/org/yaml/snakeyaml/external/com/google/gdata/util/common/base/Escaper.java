package org.yaml.snakeyaml.external.com.google.gdata.util.common.base;

public abstract interface Escaper
{
  public abstract String escape(String paramString);
  
  public abstract Appendable escape(Appendable paramAppendable);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\snakeyaml-1.28.jar!\org\yaml\snakeyaml\external\com\google\gdata\util\common\base\Escaper.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */