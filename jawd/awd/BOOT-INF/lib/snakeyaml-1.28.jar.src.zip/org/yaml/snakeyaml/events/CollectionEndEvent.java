/*    */ package org.yaml.snakeyaml.events;
/*    */ 
/*    */ import org.yaml.snakeyaml.error.Mark;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class CollectionEndEvent
/*    */   extends Event
/*    */ {
/*    */   public CollectionEndEvent(Mark startMark, Mark endMark)
/*    */   {
/* 26 */     super(startMark, endMark);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\snakeyaml-1.28.jar!\org\yaml\snakeyaml\events\CollectionEndEvent.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */