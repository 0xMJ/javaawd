package org.yaml.snakeyaml.serializer;

import org.yaml.snakeyaml.nodes.Node;

public abstract interface AnchorGenerator
{
  public abstract String nextAnchor(Node paramNode);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\snakeyaml-1.28.jar!\org\yaml\snakeyaml\serializer\AnchorGenerator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */