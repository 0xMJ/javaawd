/*    */ package org.yaml.snakeyaml.emitter;
/*    */ 
/*    */ import org.yaml.snakeyaml.error.YAMLException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EmitterException
/*    */   extends YAMLException
/*    */ {
/*    */   private static final long serialVersionUID = -8280070025452995908L;
/*    */   
/*    */   public EmitterException(String msg)
/*    */   {
/* 24 */     super(msg);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\snakeyaml-1.28.jar!\org\yaml\snakeyaml\emitter\EmitterException.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */