/*      */ package org.yaml.snakeyaml.emitter;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.Writer;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Queue;
/*      */ import java.util.Set;
/*      */ import java.util.TreeSet;
/*      */ import java.util.concurrent.ArrayBlockingQueue;
/*      */ import java.util.regex.Matcher;
/*      */ import java.util.regex.Pattern;
/*      */ import org.yaml.snakeyaml.DumperOptions;
/*      */ import org.yaml.snakeyaml.DumperOptions.LineBreak;
/*      */ import org.yaml.snakeyaml.DumperOptions.ScalarStyle;
/*      */ import org.yaml.snakeyaml.DumperOptions.Version;
/*      */ import org.yaml.snakeyaml.comments.CommentEventsCollector;
/*      */ import org.yaml.snakeyaml.comments.CommentLine;
/*      */ import org.yaml.snakeyaml.comments.CommentType;
/*      */ import org.yaml.snakeyaml.error.YAMLException;
/*      */ import org.yaml.snakeyaml.events.AliasEvent;
/*      */ import org.yaml.snakeyaml.events.CollectionEndEvent;
/*      */ import org.yaml.snakeyaml.events.CollectionStartEvent;
/*      */ import org.yaml.snakeyaml.events.CommentEvent;
/*      */ import org.yaml.snakeyaml.events.DocumentEndEvent;
/*      */ import org.yaml.snakeyaml.events.DocumentStartEvent;
/*      */ import org.yaml.snakeyaml.events.Event;
/*      */ import org.yaml.snakeyaml.events.Event.ID;
/*      */ import org.yaml.snakeyaml.events.ImplicitTuple;
/*      */ import org.yaml.snakeyaml.events.MappingEndEvent;
/*      */ import org.yaml.snakeyaml.events.MappingStartEvent;
/*      */ import org.yaml.snakeyaml.events.NodeEvent;
/*      */ import org.yaml.snakeyaml.events.ScalarEvent;
/*      */ import org.yaml.snakeyaml.events.SequenceEndEvent;
/*      */ import org.yaml.snakeyaml.events.SequenceStartEvent;
/*      */ import org.yaml.snakeyaml.events.StreamEndEvent;
/*      */ import org.yaml.snakeyaml.events.StreamStartEvent;
/*      */ import org.yaml.snakeyaml.reader.StreamReader;
/*      */ import org.yaml.snakeyaml.scanner.Constant;
/*      */ import org.yaml.snakeyaml.util.ArrayStack;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class Emitter
/*      */   implements Emitable
/*      */ {
/*      */   public static final int MIN_INDENT = 1;
/*      */   public static final int MAX_INDENT = 10;
/*   74 */   private static final char[] SPACE = { ' ' };
/*      */   
/*   76 */   private static final Pattern SPACES_PATTERN = Pattern.compile("\\s");
/*   77 */   private static final Set<Character> INVALID_ANCHOR = new HashSet();
/*      */   
/*   79 */   static { INVALID_ANCHOR.add(Character.valueOf('['));
/*   80 */     INVALID_ANCHOR.add(Character.valueOf(']'));
/*   81 */     INVALID_ANCHOR.add(Character.valueOf('{'));
/*   82 */     INVALID_ANCHOR.add(Character.valueOf('}'));
/*   83 */     INVALID_ANCHOR.add(Character.valueOf(','));
/*   84 */     INVALID_ANCHOR.add(Character.valueOf('*'));
/*   85 */     INVALID_ANCHOR.add(Character.valueOf('&'));
/*      */     
/*      */ 
/*   88 */     ESCAPE_REPLACEMENTS = new HashMap();
/*      */     
/*   90 */     ESCAPE_REPLACEMENTS.put(Character.valueOf('\000'), "0");
/*   91 */     ESCAPE_REPLACEMENTS.put(Character.valueOf('\007'), "a");
/*   92 */     ESCAPE_REPLACEMENTS.put(Character.valueOf('\b'), "b");
/*   93 */     ESCAPE_REPLACEMENTS.put(Character.valueOf('\t'), "t");
/*   94 */     ESCAPE_REPLACEMENTS.put(Character.valueOf('\n'), "n");
/*   95 */     ESCAPE_REPLACEMENTS.put(Character.valueOf('\013'), "v");
/*   96 */     ESCAPE_REPLACEMENTS.put(Character.valueOf('\f'), "f");
/*   97 */     ESCAPE_REPLACEMENTS.put(Character.valueOf('\r'), "r");
/*   98 */     ESCAPE_REPLACEMENTS.put(Character.valueOf('\033'), "e");
/*   99 */     ESCAPE_REPLACEMENTS.put(Character.valueOf('"'), "\"");
/*  100 */     ESCAPE_REPLACEMENTS.put(Character.valueOf('\\'), "\\");
/*  101 */     ESCAPE_REPLACEMENTS.put(Character.valueOf(''), "N");
/*  102 */     ESCAPE_REPLACEMENTS.put(Character.valueOf(' '), "_");
/*  103 */     ESCAPE_REPLACEMENTS.put(Character.valueOf(' '), "L");
/*  104 */     ESCAPE_REPLACEMENTS.put(Character.valueOf(' '), "P");
/*      */     
/*      */ 
/*  107 */     DEFAULT_TAG_PREFIXES = new LinkedHashMap();
/*      */     
/*  109 */     DEFAULT_TAG_PREFIXES.put("!", "!");
/*  110 */     DEFAULT_TAG_PREFIXES.put("tag:yaml.org,2002:", "!!");
/*      */   }
/*      */   
/*      */ 
/*      */   private static final Map<Character, String> ESCAPE_REPLACEMENTS;
/*      */   
/*      */   private static final Map<String, String> DEFAULT_TAG_PREFIXES;
/*      */   
/*      */   private final Writer stream;
/*      */   
/*      */   private final ArrayStack<EmitterState> states;
/*      */   
/*      */   private EmitterState state;
/*      */   
/*      */   private final Queue<Event> events;
/*      */   
/*      */   private Event event;
/*      */   
/*      */   private final ArrayStack<Integer> indents;
/*      */   
/*      */   private Integer indent;
/*      */   
/*      */   private int flowLevel;
/*      */   
/*      */   private boolean rootContext;
/*      */   
/*      */   private boolean mappingContext;
/*      */   
/*      */   private boolean simpleKeyContext;
/*      */   
/*      */   private int column;
/*      */   
/*      */   private boolean whitespace;
/*      */   
/*      */   private boolean indention;
/*      */   
/*      */   private boolean openEnded;
/*      */   
/*      */   private final Boolean canonical;
/*      */   
/*      */   private final Boolean prettyFlow;
/*      */   
/*      */   private final boolean allowUnicode;
/*      */   
/*      */   private int bestIndent;
/*      */   
/*      */   private final int indicatorIndent;
/*      */   
/*      */   private final boolean indentWithIndicator;
/*      */   
/*      */   private int bestWidth;
/*      */   
/*      */   private final char[] bestLineBreak;
/*      */   
/*      */   private final boolean splitLines;
/*      */   
/*      */   private final int maxSimpleKeyLength;
/*      */   
/*      */   private Map<String, String> tagPrefixes;
/*      */   
/*      */   private String preparedAnchor;
/*      */   
/*      */   private String preparedTag;
/*      */   
/*      */   private ScalarAnalysis analysis;
/*      */   
/*      */   private DumperOptions.ScalarStyle style;
/*      */   
/*      */   private final CommentEventsCollector blockCommentsCollector;
/*      */   
/*      */   private final CommentEventsCollector inlineCommentsCollector;
/*      */   public Emitter(Writer stream, DumperOptions opts)
/*      */   {
/*  183 */     this.stream = stream;
/*      */     
/*      */ 
/*  186 */     this.states = new ArrayStack(100);
/*  187 */     this.state = new ExpectStreamStart(null);
/*      */     
/*  189 */     this.events = new ArrayBlockingQueue(100);
/*  190 */     this.event = null;
/*      */     
/*  192 */     this.indents = new ArrayStack(10);
/*  193 */     this.indent = null;
/*      */     
/*  195 */     this.flowLevel = 0;
/*      */     
/*  197 */     this.mappingContext = false;
/*  198 */     this.simpleKeyContext = false;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  206 */     this.column = 0;
/*  207 */     this.whitespace = true;
/*  208 */     this.indention = true;
/*      */     
/*      */ 
/*  211 */     this.openEnded = false;
/*      */     
/*      */ 
/*  214 */     this.canonical = Boolean.valueOf(opts.isCanonical());
/*  215 */     this.prettyFlow = Boolean.valueOf(opts.isPrettyFlow());
/*  216 */     this.allowUnicode = opts.isAllowUnicode();
/*  217 */     this.bestIndent = 2;
/*  218 */     if ((opts.getIndent() > 1) && (opts.getIndent() < 10)) {
/*  219 */       this.bestIndent = opts.getIndent();
/*      */     }
/*  221 */     this.indicatorIndent = opts.getIndicatorIndent();
/*  222 */     this.indentWithIndicator = opts.getIndentWithIndicator();
/*  223 */     this.bestWidth = 80;
/*  224 */     if (opts.getWidth() > this.bestIndent * 2) {
/*  225 */       this.bestWidth = opts.getWidth();
/*      */     }
/*  227 */     this.bestLineBreak = opts.getLineBreak().getString().toCharArray();
/*  228 */     this.splitLines = opts.getSplitLines();
/*  229 */     this.maxSimpleKeyLength = opts.getMaxSimpleKeyLength();
/*      */     
/*      */ 
/*  232 */     this.tagPrefixes = new LinkedHashMap();
/*      */     
/*      */ 
/*  235 */     this.preparedAnchor = null;
/*  236 */     this.preparedTag = null;
/*      */     
/*      */ 
/*  239 */     this.analysis = null;
/*  240 */     this.style = null;
/*      */     
/*      */ 
/*  243 */     this.blockCommentsCollector = new CommentEventsCollector(this.events, new CommentType[] { CommentType.BLANK_LINE, CommentType.BLOCK });
/*      */     
/*  245 */     this.inlineCommentsCollector = new CommentEventsCollector(this.events, new CommentType[] { CommentType.IN_LINE });
/*      */   }
/*      */   
/*      */   public void emit(Event event) throws IOException
/*      */   {
/*  250 */     this.events.add(event);
/*  251 */     while (!needMoreEvents()) {
/*  252 */       this.event = ((Event)this.events.poll());
/*  253 */       this.state.expect();
/*  254 */       this.event = null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private boolean needMoreEvents()
/*      */   {
/*  261 */     if (this.events.isEmpty()) {
/*  262 */       return true;
/*      */     }
/*  264 */     Iterator<Event> iter = this.events.iterator();
/*  265 */     Event event = null;
/*  266 */     while (iter.hasNext()) {
/*  267 */       event = (Event)iter.next();
/*  268 */       if (!(event instanceof CommentEvent))
/*      */       {
/*      */ 
/*  271 */         if ((event instanceof DocumentStartEvent))
/*  272 */           return needEvents(iter, 1);
/*  273 */         if ((event instanceof SequenceStartEvent))
/*  274 */           return needEvents(iter, 2);
/*  275 */         if ((event instanceof MappingStartEvent))
/*  276 */           return needEvents(iter, 3);
/*  277 */         if ((event instanceof StreamStartEvent))
/*  278 */           return needEvents(iter, 2);
/*  279 */         if ((event instanceof StreamEndEvent)) {
/*  280 */           return false;
/*      */         }
/*      */         
/*  283 */         return needEvents(iter, 1);
/*      */       }
/*      */     }
/*  286 */     return true;
/*      */   }
/*      */   
/*      */   private boolean needEvents(Iterator<Event> iter, int count) {
/*  290 */     int level = 0;
/*  291 */     int actualCount = 0;
/*  292 */     while (iter.hasNext()) {
/*  293 */       Event event = (Event)iter.next();
/*  294 */       if (!(event instanceof CommentEvent))
/*      */       {
/*      */ 
/*  297 */         actualCount++;
/*  298 */         if (((event instanceof DocumentStartEvent)) || ((event instanceof CollectionStartEvent))) {
/*  299 */           level++;
/*  300 */         } else if (((event instanceof DocumentEndEvent)) || ((event instanceof CollectionEndEvent))) {
/*  301 */           level--;
/*  302 */         } else if ((event instanceof StreamEndEvent)) {
/*  303 */           level = -1;
/*  304 */         } else if (!(event instanceof CommentEvent)) {}
/*      */         
/*  306 */         if (level < 0)
/*  307 */           return false;
/*      */       }
/*      */     }
/*  310 */     return actualCount < count;
/*      */   }
/*      */   
/*      */   private void increaseIndent(boolean flow, boolean indentless) {
/*  314 */     this.indents.push(this.indent);
/*  315 */     if (this.indent == null) {
/*  316 */       if (flow) {
/*  317 */         this.indent = Integer.valueOf(this.bestIndent);
/*      */       } else {
/*  319 */         this.indent = Integer.valueOf(0);
/*      */       }
/*  321 */     } else if (!indentless) {
/*  322 */       Emitter localEmitter = this;(localEmitter.indent = Integer.valueOf(localEmitter.indent.intValue() + this.bestIndent));
/*      */     }
/*      */   }
/*      */   
/*      */   private class ExpectStreamStart implements EmitterState
/*      */   {
/*      */     private ExpectStreamStart() {}
/*      */     
/*      */     public void expect() throws IOException
/*      */     {
/*  332 */       if ((Emitter.this.event instanceof StreamStartEvent)) {
/*  333 */         Emitter.this.writeStreamStart();
/*  334 */         Emitter.this.state = new Emitter.ExpectFirstDocumentStart(Emitter.this, null);
/*      */       } else {
/*  336 */         throw new EmitterException("expected StreamStartEvent, but got " + Emitter.this.event);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private class ExpectNothing implements EmitterState { private ExpectNothing() {}
/*      */     
/*  343 */     public void expect() throws IOException { throw new EmitterException("expecting nothing, but got " + Emitter.this.event); }
/*      */   }
/*      */   
/*      */   private class ExpectFirstDocumentStart implements EmitterState
/*      */   {
/*      */     private ExpectFirstDocumentStart() {}
/*      */     
/*      */     public void expect() throws IOException {
/*  351 */       new Emitter.ExpectDocumentStart(Emitter.this, true).expect();
/*      */     }
/*      */   }
/*      */   
/*      */   private class ExpectDocumentStart implements EmitterState {
/*      */     private final boolean first;
/*      */     
/*      */     public ExpectDocumentStart(boolean first) {
/*  359 */       this.first = first;
/*      */     }
/*      */     
/*      */     public void expect() throws IOException {
/*  363 */       if ((Emitter.this.event instanceof DocumentStartEvent)) {
/*  364 */         DocumentStartEvent ev = (DocumentStartEvent)Emitter.this.event;
/*  365 */         if (((ev.getVersion() != null) || (ev.getTags() != null)) && (Emitter.this.openEnded)) {
/*  366 */           Emitter.this.writeIndicator("...", true, false, false);
/*  367 */           Emitter.this.writeIndent();
/*      */         }
/*  369 */         if (ev.getVersion() != null) {
/*  370 */           String versionText = Emitter.this.prepareVersion(ev.getVersion());
/*  371 */           Emitter.this.writeVersionDirective(versionText);
/*      */         }
/*  373 */         Emitter.this.tagPrefixes = new LinkedHashMap(Emitter.DEFAULT_TAG_PREFIXES);
/*  374 */         if (ev.getTags() != null) {
/*  375 */           Set<String> handles = new TreeSet(ev.getTags().keySet());
/*  376 */           for (String handle : handles) {
/*  377 */             String prefix = (String)ev.getTags().get(handle);
/*  378 */             Emitter.this.tagPrefixes.put(prefix, handle);
/*  379 */             String handleText = Emitter.this.prepareTagHandle(handle);
/*  380 */             String prefixText = Emitter.this.prepareTagPrefix(prefix);
/*  381 */             Emitter.this.writeTagDirective(handleText, prefixText);
/*      */           }
/*      */         }
/*  384 */         boolean implicit = (this.first) && (!ev.getExplicit()) && (!Emitter.this.canonical.booleanValue()) && (ev.getVersion() == null) && ((ev.getTags() == null) || (ev.getTags().isEmpty())) && (!Emitter.this.checkEmptyDocument());
/*      */         
/*      */ 
/*      */ 
/*  388 */         if (!implicit) {
/*  389 */           Emitter.this.writeIndent();
/*  390 */           Emitter.this.writeIndicator("---", true, false, false);
/*  391 */           if (Emitter.this.canonical.booleanValue()) {
/*  392 */             Emitter.this.writeIndent();
/*      */           }
/*      */         }
/*  395 */         Emitter.this.state = new Emitter.ExpectDocumentRoot(Emitter.this, null);
/*  396 */       } else if ((Emitter.this.event instanceof StreamEndEvent))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  402 */         Emitter.this.writeStreamEnd();
/*  403 */         Emitter.this.state = new Emitter.ExpectNothing(Emitter.this, null);
/*  404 */       } else if ((Emitter.this.event instanceof CommentEvent)) {
/*  405 */         Emitter.this.blockCommentsCollector.collectEvents(Emitter.this.event);
/*  406 */         Emitter.this.writeBlockComment();
/*      */       }
/*      */       else {
/*  409 */         throw new EmitterException("expected DocumentStartEvent, but got " + Emitter.this.event);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private class ExpectDocumentEnd implements EmitterState { private ExpectDocumentEnd() {}
/*      */     
/*  416 */     public void expect() throws IOException { Emitter.this.event = Emitter.this.blockCommentsCollector.collectEventsAndPoll(Emitter.this.event);
/*  417 */       Emitter.this.writeBlockComment();
/*  418 */       if ((Emitter.this.event instanceof DocumentEndEvent)) {
/*  419 */         Emitter.this.writeIndent();
/*  420 */         if (((DocumentEndEvent)Emitter.this.event).getExplicit()) {
/*  421 */           Emitter.this.writeIndicator("...", true, false, false);
/*  422 */           Emitter.this.writeIndent();
/*      */         }
/*  424 */         Emitter.this.flushStream();
/*  425 */         Emitter.this.state = new Emitter.ExpectDocumentStart(Emitter.this, false);
/*      */       } else {
/*  427 */         throw new EmitterException("expected DocumentEndEvent, but got " + Emitter.this.event);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private class ExpectDocumentRoot implements EmitterState { private ExpectDocumentRoot() {}
/*      */     
/*  434 */     public void expect() throws IOException { Emitter.this.event = Emitter.this.blockCommentsCollector.collectEventsAndPoll(Emitter.this.event);
/*  435 */       if (!Emitter.this.blockCommentsCollector.isEmpty()) {
/*  436 */         Emitter.this.writeBlockComment();
/*  437 */         if ((Emitter.this.event instanceof DocumentEndEvent)) {
/*  438 */           new Emitter.ExpectDocumentEnd(Emitter.this, null).expect();
/*  439 */           return;
/*      */         }
/*      */       }
/*  442 */       Emitter.this.states.push(new Emitter.ExpectDocumentEnd(Emitter.this, null));
/*  443 */       Emitter.this.expectNode(true, false, false);
/*      */     }
/*      */   }
/*      */   
/*      */   private void expectNode(boolean root, boolean mapping, boolean simpleKey)
/*      */     throws IOException
/*      */   {
/*  450 */     this.rootContext = root;
/*  451 */     this.mappingContext = mapping;
/*  452 */     this.simpleKeyContext = simpleKey;
/*  453 */     if ((this.event instanceof AliasEvent)) {
/*  454 */       expectAlias();
/*  455 */     } else if (((this.event instanceof ScalarEvent)) || ((this.event instanceof CollectionStartEvent))) {
/*  456 */       processAnchor("&");
/*  457 */       processTag();
/*  458 */       if ((this.event instanceof ScalarEvent)) {
/*  459 */         expectScalar();
/*  460 */       } else if ((this.event instanceof SequenceStartEvent)) {
/*  461 */         if ((this.flowLevel != 0) || (this.canonical.booleanValue()) || (((SequenceStartEvent)this.event).isFlow()) || (checkEmptySequence()))
/*      */         {
/*  463 */           expectFlowSequence();
/*      */         } else {
/*  465 */           expectBlockSequence();
/*      */         }
/*      */       }
/*  468 */       else if ((this.flowLevel != 0) || (this.canonical.booleanValue()) || (((MappingStartEvent)this.event).isFlow()) || (checkEmptyMapping()))
/*      */       {
/*  470 */         expectFlowMapping();
/*      */       } else {
/*  472 */         expectBlockMapping();
/*      */       }
/*      */     }
/*      */     else {
/*  476 */       throw new EmitterException("expected NodeEvent, but got " + this.event);
/*      */     }
/*      */   }
/*      */   
/*      */   private void expectAlias() throws IOException {
/*  481 */     if (!(this.event instanceof AliasEvent)) {
/*  482 */       throw new EmitterException("Alias must be provided");
/*      */     }
/*  484 */     processAnchor("*");
/*  485 */     this.state = ((EmitterState)this.states.pop());
/*      */   }
/*      */   
/*      */   private void expectScalar() throws IOException {
/*  489 */     increaseIndent(true, false);
/*  490 */     processScalar();
/*  491 */     this.indent = ((Integer)this.indents.pop());
/*  492 */     this.state = ((EmitterState)this.states.pop());
/*      */   }
/*      */   
/*      */   private void expectFlowSequence()
/*      */     throws IOException
/*      */   {
/*  498 */     writeIndicator("[", true, true, false);
/*  499 */     this.flowLevel += 1;
/*  500 */     increaseIndent(true, false);
/*  501 */     if (this.prettyFlow.booleanValue()) {
/*  502 */       writeIndent();
/*      */     }
/*  504 */     this.state = new ExpectFirstFlowSequenceItem(null);
/*      */   }
/*      */   
/*      */   private class ExpectFirstFlowSequenceItem implements EmitterState { private ExpectFirstFlowSequenceItem() {}
/*      */     
/*  509 */     public void expect() throws IOException { if ((Emitter.this.event instanceof SequenceEndEvent)) {
/*  510 */         Emitter.this.indent = ((Integer)Emitter.this.indents.pop());
/*  511 */         Emitter.access$2210(Emitter.this);
/*  512 */         Emitter.this.writeIndicator("]", false, false, false);
/*  513 */         Emitter.this.inlineCommentsCollector.collectEvents();
/*  514 */         Emitter.this.writeInlineComments();
/*  515 */         Emitter.this.state = ((EmitterState)Emitter.this.states.pop());
/*  516 */       } else if ((Emitter.this.event instanceof CommentEvent)) {
/*  517 */         Emitter.this.blockCommentsCollector.collectEvents(Emitter.this.event);
/*  518 */         Emitter.this.writeBlockComment();
/*      */       } else {
/*  520 */         if ((Emitter.this.canonical.booleanValue()) || ((Emitter.this.column > Emitter.this.bestWidth) && (Emitter.this.splitLines)) || (Emitter.this.prettyFlow.booleanValue())) {
/*  521 */           Emitter.this.writeIndent();
/*      */         }
/*  523 */         Emitter.this.states.push(new Emitter.ExpectFlowSequenceItem(Emitter.this, null));
/*  524 */         Emitter.this.expectNode(false, false, false);
/*  525 */         Emitter.this.event = Emitter.this.inlineCommentsCollector.collectEvents(Emitter.this.event);
/*  526 */         Emitter.this.writeInlineComments();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private class ExpectFlowSequenceItem implements EmitterState { private ExpectFlowSequenceItem() {}
/*      */     
/*  533 */     public void expect() throws IOException { if ((Emitter.this.event instanceof SequenceEndEvent)) {
/*  534 */         Emitter.this.indent = ((Integer)Emitter.this.indents.pop());
/*  535 */         Emitter.access$2210(Emitter.this);
/*  536 */         if (Emitter.this.canonical.booleanValue()) {
/*  537 */           Emitter.this.writeIndicator(",", false, false, false);
/*  538 */           Emitter.this.writeIndent();
/*      */         }
/*  540 */         Emitter.this.writeIndicator("]", false, false, false);
/*  541 */         Emitter.this.inlineCommentsCollector.collectEvents();
/*  542 */         Emitter.this.writeInlineComments();
/*  543 */         if (Emitter.this.prettyFlow.booleanValue()) {
/*  544 */           Emitter.this.writeIndent();
/*      */         }
/*  546 */         Emitter.this.state = ((EmitterState)Emitter.this.states.pop());
/*  547 */       } else if ((Emitter.this.event instanceof CommentEvent)) {
/*  548 */         Emitter.this.blockCommentsCollector.collectEvents(Emitter.this.event);
/*  549 */         Emitter.this.writeBlockComment();
/*      */       } else {
/*  551 */         Emitter.this.writeIndicator(",", false, false, false);
/*  552 */         if ((Emitter.this.canonical.booleanValue()) || ((Emitter.this.column > Emitter.this.bestWidth) && (Emitter.this.splitLines)) || (Emitter.this.prettyFlow.booleanValue())) {
/*  553 */           Emitter.this.writeIndent();
/*      */         }
/*  555 */         Emitter.this.states.push(new ExpectFlowSequenceItem(Emitter.this));
/*  556 */         Emitter.this.expectNode(false, false, false);
/*  557 */         Emitter.this.inlineCommentsCollector.collectEvents(Emitter.this.event);
/*  558 */         Emitter.this.writeInlineComments();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void expectFlowMapping()
/*      */     throws IOException
/*      */   {
/*  566 */     writeIndicator("{", true, true, false);
/*  567 */     this.flowLevel += 1;
/*  568 */     increaseIndent(true, false);
/*  569 */     if (this.prettyFlow.booleanValue()) {
/*  570 */       writeIndent();
/*      */     }
/*  572 */     this.state = new ExpectFirstFlowMappingKey(null);
/*      */   }
/*      */   
/*      */   private class ExpectFirstFlowMappingKey implements EmitterState { private ExpectFirstFlowMappingKey() {}
/*      */     
/*  577 */     public void expect() throws IOException { if ((Emitter.this.event instanceof MappingEndEvent)) {
/*  578 */         Emitter.this.indent = ((Integer)Emitter.this.indents.pop());
/*  579 */         Emitter.access$2210(Emitter.this);
/*  580 */         Emitter.this.writeIndicator("}", false, false, false);
/*  581 */         Emitter.this.inlineCommentsCollector.collectEvents();
/*  582 */         Emitter.this.writeInlineComments();
/*  583 */         Emitter.this.state = ((EmitterState)Emitter.this.states.pop());
/*      */       } else {
/*  585 */         if ((Emitter.this.canonical.booleanValue()) || ((Emitter.this.column > Emitter.this.bestWidth) && (Emitter.this.splitLines)) || (Emitter.this.prettyFlow.booleanValue())) {
/*  586 */           Emitter.this.writeIndent();
/*      */         }
/*  588 */         if ((!Emitter.this.canonical.booleanValue()) && (Emitter.this.checkSimpleKey())) {
/*  589 */           Emitter.this.states.push(new Emitter.ExpectFlowMappingSimpleValue(Emitter.this, null));
/*  590 */           Emitter.this.expectNode(false, true, true);
/*      */         } else {
/*  592 */           Emitter.this.writeIndicator("?", true, false, false);
/*  593 */           Emitter.this.states.push(new Emitter.ExpectFlowMappingValue(Emitter.this, null));
/*  594 */           Emitter.this.expectNode(false, true, false);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private class ExpectFlowMappingKey implements EmitterState { private ExpectFlowMappingKey() {}
/*      */     
/*  602 */     public void expect() throws IOException { if ((Emitter.this.event instanceof MappingEndEvent)) {
/*  603 */         Emitter.this.indent = ((Integer)Emitter.this.indents.pop());
/*  604 */         Emitter.access$2210(Emitter.this);
/*  605 */         if (Emitter.this.canonical.booleanValue()) {
/*  606 */           Emitter.this.writeIndicator(",", false, false, false);
/*  607 */           Emitter.this.writeIndent();
/*      */         }
/*  609 */         if (Emitter.this.prettyFlow.booleanValue()) {
/*  610 */           Emitter.this.writeIndent();
/*      */         }
/*  612 */         Emitter.this.writeIndicator("}", false, false, false);
/*  613 */         Emitter.this.inlineCommentsCollector.collectEvents();
/*  614 */         Emitter.this.writeInlineComments();
/*  615 */         Emitter.this.state = ((EmitterState)Emitter.this.states.pop());
/*      */       } else {
/*  617 */         Emitter.this.writeIndicator(",", false, false, false);
/*  618 */         if ((Emitter.this.canonical.booleanValue()) || ((Emitter.this.column > Emitter.this.bestWidth) && (Emitter.this.splitLines)) || (Emitter.this.prettyFlow.booleanValue())) {
/*  619 */           Emitter.this.writeIndent();
/*      */         }
/*  621 */         if ((!Emitter.this.canonical.booleanValue()) && (Emitter.this.checkSimpleKey())) {
/*  622 */           Emitter.this.states.push(new Emitter.ExpectFlowMappingSimpleValue(Emitter.this, null));
/*  623 */           Emitter.this.expectNode(false, true, true);
/*      */         } else {
/*  625 */           Emitter.this.writeIndicator("?", true, false, false);
/*  626 */           Emitter.this.states.push(new Emitter.ExpectFlowMappingValue(Emitter.this, null));
/*  627 */           Emitter.this.expectNode(false, true, false);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private class ExpectFlowMappingSimpleValue implements EmitterState { private ExpectFlowMappingSimpleValue() {}
/*      */     
/*  635 */     public void expect() throws IOException { Emitter.this.writeIndicator(":", false, false, false);
/*  636 */       Emitter.this.event = Emitter.this.inlineCommentsCollector.collectEventsAndPoll(Emitter.this.event);
/*  637 */       Emitter.this.writeInlineComments();
/*  638 */       Emitter.this.states.push(new Emitter.ExpectFlowMappingKey(Emitter.this, null));
/*  639 */       Emitter.this.expectNode(false, true, false);
/*  640 */       Emitter.this.inlineCommentsCollector.collectEvents(Emitter.this.event);
/*  641 */       Emitter.this.writeInlineComments();
/*      */     }
/*      */   }
/*      */   
/*      */   private class ExpectFlowMappingValue implements EmitterState { private ExpectFlowMappingValue() {}
/*      */     
/*  647 */     public void expect() throws IOException { if ((Emitter.this.canonical.booleanValue()) || (Emitter.this.column > Emitter.this.bestWidth) || (Emitter.this.prettyFlow.booleanValue())) {
/*  648 */         Emitter.this.writeIndent();
/*      */       }
/*  650 */       Emitter.this.writeIndicator(":", true, false, false);
/*  651 */       Emitter.this.event = Emitter.this.inlineCommentsCollector.collectEventsAndPoll(Emitter.this.event);
/*  652 */       Emitter.this.writeInlineComments();
/*  653 */       Emitter.this.states.push(new Emitter.ExpectFlowMappingKey(Emitter.this, null));
/*  654 */       Emitter.this.expectNode(false, true, false);
/*  655 */       Emitter.this.inlineCommentsCollector.collectEvents(Emitter.this.event);
/*  656 */       Emitter.this.writeInlineComments();
/*      */     }
/*      */   }
/*      */   
/*      */   private void expectBlockSequence()
/*      */     throws IOException
/*      */   {
/*  663 */     boolean indentless = (this.mappingContext) && (!this.indention);
/*  664 */     increaseIndent(false, indentless);
/*  665 */     this.state = new ExpectFirstBlockSequenceItem(null);
/*      */   }
/*      */   
/*      */   private class ExpectFirstBlockSequenceItem implements EmitterState { private ExpectFirstBlockSequenceItem() {}
/*      */     
/*  670 */     public void expect() throws IOException { new Emitter.ExpectBlockSequenceItem(Emitter.this, true).expect(); }
/*      */   }
/*      */   
/*      */   private class ExpectBlockSequenceItem implements EmitterState
/*      */   {
/*      */     private final boolean first;
/*      */     
/*      */     public ExpectBlockSequenceItem(boolean first) {
/*  678 */       this.first = first;
/*      */     }
/*      */     
/*      */     public void expect() throws IOException {
/*  682 */       if ((!this.first) && ((Emitter.this.event instanceof SequenceEndEvent))) {
/*  683 */         Emitter.this.indent = ((Integer)Emitter.this.indents.pop());
/*  684 */         Emitter.this.state = ((EmitterState)Emitter.this.states.pop());
/*  685 */       } else if ((Emitter.this.event instanceof CommentEvent)) {
/*  686 */         Emitter.this.blockCommentsCollector.collectEvents(Emitter.this.event);
/*  687 */         Emitter.this.writeBlockComment();
/*      */       } else {
/*  689 */         Emitter.this.writeIndent();
/*  690 */         if ((!Emitter.this.indentWithIndicator) || (this.first)) {
/*  691 */           Emitter.this.writeWhitespace(Emitter.this.indicatorIndent);
/*      */         }
/*  693 */         Emitter.this.writeIndicator("-", true, false, true);
/*  694 */         if ((Emitter.this.indentWithIndicator) && (this.first)) {
/*  695 */           Emitter.this.indent = Integer.valueOf(Emitter.this.indent.intValue() + Emitter.this.indicatorIndent);
/*      */         }
/*  697 */         Emitter.this.states.push(new ExpectBlockSequenceItem(Emitter.this, false));
/*  698 */         Emitter.this.expectNode(false, false, false);
/*  699 */         Emitter.this.inlineCommentsCollector.collectEvents();
/*  700 */         Emitter.this.writeInlineComments();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void expectBlockMapping() throws IOException
/*      */   {
/*  707 */     increaseIndent(false, false);
/*  708 */     this.state = new ExpectFirstBlockMappingKey(null);
/*      */   }
/*      */   
/*      */   private class ExpectFirstBlockMappingKey implements EmitterState { private ExpectFirstBlockMappingKey() {}
/*      */     
/*  713 */     public void expect() throws IOException { new Emitter.ExpectBlockMappingKey(Emitter.this, true).expect(); }
/*      */   }
/*      */   
/*      */   private class ExpectBlockMappingKey implements EmitterState
/*      */   {
/*      */     private final boolean first;
/*      */     
/*      */     public ExpectBlockMappingKey(boolean first) {
/*  721 */       this.first = first;
/*      */     }
/*      */     
/*      */     public void expect() throws IOException {
/*  725 */       Emitter.this.event = Emitter.this.blockCommentsCollector.collectEventsAndPoll(Emitter.this.event);
/*  726 */       Emitter.this.writeBlockComment();
/*  727 */       if ((!this.first) && ((Emitter.this.event instanceof MappingEndEvent))) {
/*  728 */         Emitter.this.indent = ((Integer)Emitter.this.indents.pop());
/*  729 */         Emitter.this.state = ((EmitterState)Emitter.this.states.pop());
/*      */       } else {
/*  731 */         Emitter.this.writeIndent();
/*  732 */         if (Emitter.this.checkSimpleKey()) {
/*  733 */           Emitter.this.states.push(new Emitter.ExpectBlockMappingSimpleValue(Emitter.this, null));
/*  734 */           Emitter.this.expectNode(false, true, true);
/*      */         } else {
/*  736 */           Emitter.this.writeIndicator("?", true, false, true);
/*  737 */           Emitter.this.states.push(new Emitter.ExpectBlockMappingValue(Emitter.this, null));
/*  738 */           Emitter.this.expectNode(false, true, false);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private boolean isFoldedOrLiteral(Event event) {
/*  745 */     if (!event.is(Event.ID.Scalar)) {
/*  746 */       return false;
/*      */     }
/*  748 */     ScalarEvent scalarEvent = (ScalarEvent)event;
/*  749 */     DumperOptions.ScalarStyle style = scalarEvent.getScalarStyle();
/*  750 */     return (style == DumperOptions.ScalarStyle.FOLDED) || (style == DumperOptions.ScalarStyle.LITERAL);
/*      */   }
/*      */   
/*      */   private class ExpectBlockMappingSimpleValue implements EmitterState { private ExpectBlockMappingSimpleValue() {}
/*      */     
/*  755 */     public void expect() throws IOException { Emitter.this.writeIndicator(":", false, false, false);
/*  756 */       Emitter.this.event = Emitter.this.inlineCommentsCollector.collectEventsAndPoll(Emitter.this.event);
/*  757 */       if ((!Emitter.this.isFoldedOrLiteral(Emitter.this.event)) && 
/*  758 */         (Emitter.this.writeInlineComments())) {
/*  759 */         Emitter.this.increaseIndent(true, false);
/*  760 */         Emitter.this.writeIndent();
/*  761 */         Emitter.this.indent = ((Integer)Emitter.this.indents.pop());
/*      */       }
/*      */       
/*  764 */       Emitter.this.event = Emitter.this.blockCommentsCollector.collectEventsAndPoll(Emitter.this.event);
/*  765 */       if (!Emitter.this.blockCommentsCollector.isEmpty()) {
/*  766 */         Emitter.this.increaseIndent(true, false);
/*  767 */         Emitter.this.writeBlockComment();
/*  768 */         Emitter.this.writeIndent();
/*  769 */         Emitter.this.indent = ((Integer)Emitter.this.indents.pop());
/*      */       }
/*  771 */       Emitter.this.states.push(new Emitter.ExpectBlockMappingKey(Emitter.this, false));
/*  772 */       Emitter.this.expectNode(false, true, false);
/*  773 */       Emitter.this.inlineCommentsCollector.collectEvents();
/*  774 */       Emitter.this.writeInlineComments();
/*      */     }
/*      */   }
/*      */   
/*      */   private class ExpectBlockMappingValue implements EmitterState { private ExpectBlockMappingValue() {}
/*      */     
/*  780 */     public void expect() throws IOException { Emitter.this.writeIndent();
/*  781 */       Emitter.this.writeIndicator(":", true, false, true);
/*  782 */       Emitter.this.event = Emitter.this.inlineCommentsCollector.collectEventsAndPoll(Emitter.this.event);
/*  783 */       Emitter.this.writeInlineComments();
/*  784 */       Emitter.this.event = Emitter.this.blockCommentsCollector.collectEventsAndPoll(Emitter.this.event);
/*  785 */       Emitter.this.writeBlockComment();
/*  786 */       Emitter.this.states.push(new Emitter.ExpectBlockMappingKey(Emitter.this, false));
/*  787 */       Emitter.this.expectNode(false, true, false);
/*  788 */       Emitter.this.inlineCommentsCollector.collectEvents(Emitter.this.event);
/*  789 */       Emitter.this.writeInlineComments();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private boolean checkEmptySequence()
/*      */   {
/*  796 */     return ((this.event instanceof SequenceStartEvent)) && (!this.events.isEmpty()) && ((this.events.peek() instanceof SequenceEndEvent));
/*      */   }
/*      */   
/*      */   private boolean checkEmptyMapping() {
/*  800 */     return ((this.event instanceof MappingStartEvent)) && (!this.events.isEmpty()) && ((this.events.peek() instanceof MappingEndEvent));
/*      */   }
/*      */   
/*      */   private boolean checkEmptyDocument() {
/*  804 */     if ((!(this.event instanceof DocumentStartEvent)) || (this.events.isEmpty())) {
/*  805 */       return false;
/*      */     }
/*  807 */     Event event = (Event)this.events.peek();
/*  808 */     if ((event instanceof ScalarEvent)) {
/*  809 */       ScalarEvent e = (ScalarEvent)event;
/*  810 */       return (e.getAnchor() == null) && (e.getTag() == null) && (e.getImplicit() != null) && (e.getValue().length() == 0);
/*      */     }
/*      */     
/*  813 */     return false;
/*      */   }
/*      */   
/*      */   private boolean checkSimpleKey() {
/*  817 */     int length = 0;
/*  818 */     if (((this.event instanceof NodeEvent)) && (((NodeEvent)this.event).getAnchor() != null)) {
/*  819 */       if (this.preparedAnchor == null) {
/*  820 */         this.preparedAnchor = prepareAnchor(((NodeEvent)this.event).getAnchor());
/*      */       }
/*  822 */       length += this.preparedAnchor.length();
/*      */     }
/*  824 */     String tag = null;
/*  825 */     if ((this.event instanceof ScalarEvent)) {
/*  826 */       tag = ((ScalarEvent)this.event).getTag();
/*  827 */     } else if ((this.event instanceof CollectionStartEvent)) {
/*  828 */       tag = ((CollectionStartEvent)this.event).getTag();
/*      */     }
/*  830 */     if (tag != null) {
/*  831 */       if (this.preparedTag == null) {
/*  832 */         this.preparedTag = prepareTag(tag);
/*      */       }
/*  834 */       length += this.preparedTag.length();
/*      */     }
/*  836 */     if ((this.event instanceof ScalarEvent)) {
/*  837 */       if (this.analysis == null) {
/*  838 */         this.analysis = analyzeScalar(((ScalarEvent)this.event).getValue());
/*      */       }
/*  840 */       length += this.analysis.getScalar().length();
/*      */     }
/*  842 */     return (length < this.maxSimpleKeyLength) && (((this.event instanceof AliasEvent)) || (((this.event instanceof ScalarEvent)) && (!this.analysis.isEmpty()) && (!this.analysis.isMultiline())) || (checkEmptySequence()) || (checkEmptyMapping()));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void processAnchor(String indicator)
/*      */     throws IOException
/*      */   {
/*  850 */     NodeEvent ev = (NodeEvent)this.event;
/*  851 */     if (ev.getAnchor() == null) {
/*  852 */       this.preparedAnchor = null;
/*  853 */       return;
/*      */     }
/*  855 */     if (this.preparedAnchor == null) {
/*  856 */       this.preparedAnchor = prepareAnchor(ev.getAnchor());
/*      */     }
/*  858 */     writeIndicator(indicator + this.preparedAnchor, true, false, false);
/*  859 */     this.preparedAnchor = null;
/*      */   }
/*      */   
/*      */   private void processTag() throws IOException {
/*  863 */     String tag = null;
/*  864 */     if ((this.event instanceof ScalarEvent)) {
/*  865 */       ScalarEvent ev = (ScalarEvent)this.event;
/*  866 */       tag = ev.getTag();
/*  867 */       if (this.style == null) {
/*  868 */         this.style = chooseScalarStyle();
/*      */       }
/*  870 */       if (((!this.canonical.booleanValue()) || (tag == null)) && (((this.style == null) && (ev.getImplicit().canOmitTagInPlainScalar())) || ((this.style != null) && (ev.getImplicit().canOmitTagInNonPlainScalar()))))
/*      */       {
/*      */ 
/*  873 */         this.preparedTag = null;
/*  874 */         return;
/*      */       }
/*  876 */       if ((ev.getImplicit().canOmitTagInPlainScalar()) && (tag == null)) {
/*  877 */         tag = "!";
/*  878 */         this.preparedTag = null;
/*      */       }
/*      */     } else {
/*  881 */       CollectionStartEvent ev = (CollectionStartEvent)this.event;
/*  882 */       tag = ev.getTag();
/*  883 */       if (((!this.canonical.booleanValue()) || (tag == null)) && (ev.getImplicit())) {
/*  884 */         this.preparedTag = null;
/*  885 */         return;
/*      */       }
/*      */     }
/*  888 */     if (tag == null) {
/*  889 */       throw new EmitterException("tag is not specified");
/*      */     }
/*  891 */     if (this.preparedTag == null) {
/*  892 */       this.preparedTag = prepareTag(tag);
/*      */     }
/*  894 */     writeIndicator(this.preparedTag, true, false, false);
/*  895 */     this.preparedTag = null;
/*      */   }
/*      */   
/*      */   private DumperOptions.ScalarStyle chooseScalarStyle() {
/*  899 */     ScalarEvent ev = (ScalarEvent)this.event;
/*  900 */     if (this.analysis == null) {
/*  901 */       this.analysis = analyzeScalar(ev.getValue());
/*      */     }
/*  903 */     if (((!ev.isPlain()) && (ev.getScalarStyle() == DumperOptions.ScalarStyle.DOUBLE_QUOTED)) || (this.canonical.booleanValue())) {
/*  904 */       return DumperOptions.ScalarStyle.DOUBLE_QUOTED;
/*      */     }
/*  906 */     if ((ev.isPlain()) && (ev.getImplicit().canOmitTagInPlainScalar()) && 
/*  907 */       ((!this.simpleKeyContext) || ((!this.analysis.isEmpty()) && (!this.analysis.isMultiline()))) && (((this.flowLevel != 0) && (this.analysis.isAllowFlowPlain())) || ((this.flowLevel == 0) && (this.analysis.isAllowBlockPlain()))))
/*      */     {
/*  909 */       return null;
/*      */     }
/*      */     
/*  912 */     if ((!ev.isPlain()) && ((ev.getScalarStyle() == DumperOptions.ScalarStyle.LITERAL) || (ev.getScalarStyle() == DumperOptions.ScalarStyle.FOLDED)) && 
/*  913 */       (this.flowLevel == 0) && (!this.simpleKeyContext) && (this.analysis.isAllowBlock())) {
/*  914 */       return ev.getScalarStyle();
/*      */     }
/*      */     
/*  917 */     if (((ev.isPlain()) || (ev.getScalarStyle() == DumperOptions.ScalarStyle.SINGLE_QUOTED)) && 
/*  918 */       (this.analysis.isAllowSingleQuoted()) && ((!this.simpleKeyContext) || (!this.analysis.isMultiline()))) {
/*  919 */       return DumperOptions.ScalarStyle.SINGLE_QUOTED;
/*      */     }
/*      */     
/*  922 */     return DumperOptions.ScalarStyle.DOUBLE_QUOTED;
/*      */   }
/*      */   
/*      */   private void processScalar() throws IOException {
/*  926 */     ScalarEvent ev = (ScalarEvent)this.event;
/*  927 */     if (this.analysis == null) {
/*  928 */       this.analysis = analyzeScalar(ev.getValue());
/*      */     }
/*  930 */     if (this.style == null) {
/*  931 */       this.style = chooseScalarStyle();
/*      */     }
/*  933 */     boolean split = (!this.simpleKeyContext) && (this.splitLines);
/*  934 */     if (this.style == null) {
/*  935 */       writePlain(this.analysis.getScalar(), split);
/*      */     } else {
/*  937 */       switch (this.style) {
/*      */       case DOUBLE_QUOTED: 
/*  939 */         writeDoubleQuoted(this.analysis.getScalar(), split);
/*  940 */         break;
/*      */       case SINGLE_QUOTED: 
/*  942 */         writeSingleQuoted(this.analysis.getScalar(), split);
/*  943 */         break;
/*      */       case FOLDED: 
/*  945 */         writeFolded(this.analysis.getScalar(), split);
/*  946 */         break;
/*      */       case LITERAL: 
/*  948 */         writeLiteral(this.analysis.getScalar());
/*  949 */         break;
/*      */       default: 
/*  951 */         throw new YAMLException("Unexpected style: " + this.style);
/*      */       }
/*      */     }
/*  954 */     this.analysis = null;
/*  955 */     this.style = null;
/*      */   }
/*      */   
/*      */ 
/*      */   private String prepareVersion(DumperOptions.Version version)
/*      */   {
/*  961 */     if (version.major() != 1) {
/*  962 */       throw new EmitterException("unsupported YAML version: " + version);
/*      */     }
/*  964 */     return version.getRepresentation();
/*      */   }
/*      */   
/*  967 */   private static final Pattern HANDLE_FORMAT = Pattern.compile("^![-_\\w]*!$");
/*      */   
/*      */   private String prepareTagHandle(String handle) {
/*  970 */     if (handle.length() == 0)
/*  971 */       throw new EmitterException("tag handle must not be empty");
/*  972 */     if ((handle.charAt(0) != '!') || (handle.charAt(handle.length() - 1) != '!'))
/*  973 */       throw new EmitterException("tag handle must start and end with '!': " + handle);
/*  974 */     if ((!"!".equals(handle)) && (!HANDLE_FORMAT.matcher(handle).matches())) {
/*  975 */       throw new EmitterException("invalid character in the tag handle: " + handle);
/*      */     }
/*  977 */     return handle;
/*      */   }
/*      */   
/*      */   private String prepareTagPrefix(String prefix) {
/*  981 */     if (prefix.length() == 0) {
/*  982 */       throw new EmitterException("tag prefix must not be empty");
/*      */     }
/*  984 */     StringBuilder chunks = new StringBuilder();
/*  985 */     int start = 0;
/*  986 */     int end = 0;
/*  987 */     if (prefix.charAt(0) == '!') {
/*  988 */       end = 1;
/*      */     }
/*  990 */     while (end < prefix.length()) {
/*  991 */       end++;
/*      */     }
/*  993 */     if (start < end) {
/*  994 */       chunks.append(prefix, start, end);
/*      */     }
/*  996 */     return chunks.toString();
/*      */   }
/*      */   
/*      */   private String prepareTag(String tag) {
/* 1000 */     if (tag.length() == 0) {
/* 1001 */       throw new EmitterException("tag must not be empty");
/*      */     }
/* 1003 */     if ("!".equals(tag)) {
/* 1004 */       return tag;
/*      */     }
/* 1006 */     String handle = null;
/* 1007 */     String suffix = tag;
/*      */     
/* 1009 */     for (String prefix : this.tagPrefixes.keySet()) {
/* 1010 */       if ((tag.startsWith(prefix)) && (("!".equals(prefix)) || (prefix.length() < tag.length()))) {
/* 1011 */         handle = prefix;
/*      */       }
/*      */     }
/* 1014 */     if (handle != null) {
/* 1015 */       suffix = tag.substring(handle.length());
/* 1016 */       handle = (String)this.tagPrefixes.get(handle);
/*      */     }
/*      */     
/* 1019 */     int end = suffix.length();
/* 1020 */     String suffixText = end > 0 ? suffix.substring(0, end) : "";
/*      */     
/* 1022 */     if (handle != null) {
/* 1023 */       return handle + suffixText;
/*      */     }
/* 1025 */     return "!<" + suffixText + ">";
/*      */   }
/*      */   
/*      */   static String prepareAnchor(String anchor) {
/* 1029 */     if (anchor.length() == 0) {
/* 1030 */       throw new EmitterException("anchor must not be empty");
/*      */     }
/* 1032 */     for (Character invalid : INVALID_ANCHOR) {
/* 1033 */       if (anchor.indexOf(invalid.charValue()) > -1) {
/* 1034 */         throw new EmitterException("Invalid character '" + invalid + "' in the anchor: " + anchor);
/*      */       }
/*      */     }
/* 1037 */     Matcher matcher = SPACES_PATTERN.matcher(anchor);
/* 1038 */     if (matcher.find()) {
/* 1039 */       throw new EmitterException("Anchor may not contain spaces: " + anchor);
/*      */     }
/* 1041 */     return anchor;
/*      */   }
/*      */   
/*      */   private ScalarAnalysis analyzeScalar(String scalar)
/*      */   {
/* 1046 */     if (scalar.length() == 0) {
/* 1047 */       return new ScalarAnalysis(scalar, true, false, false, true, true, false);
/*      */     }
/*      */     
/* 1050 */     boolean blockIndicators = false;
/* 1051 */     boolean flowIndicators = false;
/* 1052 */     boolean lineBreaks = false;
/* 1053 */     boolean specialCharacters = false;
/*      */     
/*      */ 
/* 1056 */     boolean leadingSpace = false;
/* 1057 */     boolean leadingBreak = false;
/* 1058 */     boolean trailingSpace = false;
/* 1059 */     boolean trailingBreak = false;
/* 1060 */     boolean breakSpace = false;
/* 1061 */     boolean spaceBreak = false;
/*      */     
/*      */ 
/* 1064 */     if ((scalar.startsWith("---")) || (scalar.startsWith("..."))) {
/* 1065 */       blockIndicators = true;
/* 1066 */       flowIndicators = true;
/*      */     }
/*      */     
/* 1069 */     boolean preceededByWhitespace = true;
/* 1070 */     boolean followedByWhitespace = (scalar.length() == 1) || (Constant.NULL_BL_T_LINEBR.has(scalar.codePointAt(1)));
/*      */     
/* 1072 */     boolean previousSpace = false;
/*      */     
/*      */ 
/* 1075 */     boolean previousBreak = false;
/*      */     
/* 1077 */     int index = 0;
/*      */     
/* 1079 */     while (index < scalar.length()) {
/* 1080 */       int c = scalar.codePointAt(index);
/*      */       
/* 1082 */       if (index == 0)
/*      */       {
/* 1084 */         if ("#,[]{}&*!|>'\"%@`".indexOf(c) != -1) {
/* 1085 */           flowIndicators = true;
/* 1086 */           blockIndicators = true;
/*      */         }
/* 1088 */         if ((c == 63) || (c == 58)) {
/* 1089 */           flowIndicators = true;
/* 1090 */           if (followedByWhitespace) {
/* 1091 */             blockIndicators = true;
/*      */           }
/*      */         }
/* 1094 */         if ((c == 45) && (followedByWhitespace)) {
/* 1095 */           flowIndicators = true;
/* 1096 */           blockIndicators = true;
/*      */         }
/*      */       }
/*      */       else {
/* 1100 */         if (",?[]{}".indexOf(c) != -1) {
/* 1101 */           flowIndicators = true;
/*      */         }
/* 1103 */         if (c == 58) {
/* 1104 */           flowIndicators = true;
/* 1105 */           if (followedByWhitespace) {
/* 1106 */             blockIndicators = true;
/*      */           }
/*      */         }
/* 1109 */         if ((c == 35) && (preceededByWhitespace)) {
/* 1110 */           flowIndicators = true;
/* 1111 */           blockIndicators = true;
/*      */         }
/*      */       }
/*      */       
/* 1115 */       boolean isLineBreak = Constant.LINEBR.has(c);
/* 1116 */       if (isLineBreak) {
/* 1117 */         lineBreaks = true;
/*      */       }
/* 1119 */       if ((c != 10) && ((32 > c) || (c > 126))) {
/* 1120 */         if ((c == 133) || ((c >= 160) && (c <= 55295)) || ((c >= 57344) && (c <= 65533)) || ((c >= 65536) && (c <= 1114111)))
/*      */         {
/*      */ 
/*      */ 
/* 1124 */           if (!this.allowUnicode) {
/* 1125 */             specialCharacters = true;
/*      */           }
/*      */         } else {
/* 1128 */           specialCharacters = true;
/*      */         }
/*      */       }
/*      */       
/* 1132 */       if (c == 32) {
/* 1133 */         if (index == 0) {
/* 1134 */           leadingSpace = true;
/*      */         }
/* 1136 */         if (index == scalar.length() - 1) {
/* 1137 */           trailingSpace = true;
/*      */         }
/* 1139 */         if (previousBreak) {
/* 1140 */           breakSpace = true;
/*      */         }
/* 1142 */         previousSpace = true;
/* 1143 */         previousBreak = false;
/* 1144 */       } else if (isLineBreak) {
/* 1145 */         if (index == 0) {
/* 1146 */           leadingBreak = true;
/*      */         }
/* 1148 */         if (index == scalar.length() - 1) {
/* 1149 */           trailingBreak = true;
/*      */         }
/* 1151 */         if (previousSpace) {
/* 1152 */           spaceBreak = true;
/*      */         }
/* 1154 */         previousSpace = false;
/* 1155 */         previousBreak = true;
/*      */       } else {
/* 1157 */         previousSpace = false;
/* 1158 */         previousBreak = false;
/*      */       }
/*      */       
/*      */ 
/* 1162 */       index += Character.charCount(c);
/* 1163 */       preceededByWhitespace = (Constant.NULL_BL_T.has(c)) || (isLineBreak);
/* 1164 */       followedByWhitespace = true;
/* 1165 */       if (index + 1 < scalar.length()) {
/* 1166 */         int nextIndex = index + Character.charCount(scalar.codePointAt(index));
/* 1167 */         if (nextIndex < scalar.length()) {
/* 1168 */           followedByWhitespace = (Constant.NULL_BL_T.has(scalar.codePointAt(nextIndex))) || (isLineBreak);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 1173 */     boolean allowFlowPlain = true;
/* 1174 */     boolean allowBlockPlain = true;
/* 1175 */     boolean allowSingleQuoted = true;
/* 1176 */     boolean allowBlock = true;
/*      */     
/* 1178 */     if ((leadingSpace) || (leadingBreak) || (trailingSpace) || (trailingBreak)) {
/* 1179 */       allowFlowPlain = allowBlockPlain = 0;
/*      */     }
/*      */     
/* 1182 */     if (trailingSpace) {
/* 1183 */       allowBlock = false;
/*      */     }
/*      */     
/*      */ 
/* 1187 */     if (breakSpace) {
/* 1188 */       allowFlowPlain = allowBlockPlain = allowSingleQuoted = 0;
/*      */     }
/*      */     
/*      */ 
/* 1192 */     if ((spaceBreak) || (specialCharacters)) {
/* 1193 */       allowFlowPlain = allowBlockPlain = allowSingleQuoted = allowBlock = 0;
/*      */     }
/*      */     
/*      */ 
/* 1197 */     if (lineBreaks) {
/* 1198 */       allowFlowPlain = false;
/*      */     }
/*      */     
/* 1201 */     if (flowIndicators) {
/* 1202 */       allowFlowPlain = false;
/*      */     }
/*      */     
/* 1205 */     if (blockIndicators) {
/* 1206 */       allowBlockPlain = false;
/*      */     }
/*      */     
/* 1209 */     return new ScalarAnalysis(scalar, false, lineBreaks, allowFlowPlain, allowBlockPlain, allowSingleQuoted, allowBlock);
/*      */   }
/*      */   
/*      */ 
/*      */   void flushStream()
/*      */     throws IOException
/*      */   {
/* 1216 */     this.stream.flush();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void writeStreamEnd()
/*      */     throws IOException
/*      */   {
/* 1224 */     flushStream();
/*      */   }
/*      */   
/*      */   void writeIndicator(String indicator, boolean needWhitespace, boolean whitespace, boolean indentation) throws IOException
/*      */   {
/* 1229 */     if ((!this.whitespace) && (needWhitespace)) {
/* 1230 */       this.column += 1;
/* 1231 */       this.stream.write(SPACE);
/*      */     }
/* 1233 */     this.whitespace = whitespace;
/* 1234 */     this.indention = ((this.indention) && (indentation));
/* 1235 */     this.column += indicator.length();
/* 1236 */     this.openEnded = false;
/* 1237 */     this.stream.write(indicator);
/*      */   }
/*      */   
/*      */   void writeIndent() throws IOException { int indent;
/*      */     int indent;
/* 1242 */     if (this.indent != null) {
/* 1243 */       indent = this.indent.intValue();
/*      */     } else {
/* 1245 */       indent = 0;
/*      */     }
/*      */     
/* 1248 */     if ((!this.indention) || (this.column > indent) || ((this.column == indent) && (!this.whitespace))) {
/* 1249 */       writeLineBreak(null);
/*      */     }
/*      */     
/* 1252 */     writeWhitespace(indent - this.column);
/*      */   }
/*      */   
/*      */   private void writeWhitespace(int length) throws IOException {
/* 1256 */     if (length <= 0) {
/* 1257 */       return;
/*      */     }
/* 1259 */     this.whitespace = true;
/* 1260 */     char[] data = new char[length];
/* 1261 */     for (int i = 0; i < data.length; i++) {
/* 1262 */       data[i] = ' ';
/*      */     }
/* 1264 */     this.column += length;
/* 1265 */     this.stream.write(data);
/*      */   }
/*      */   
/*      */   private void writeLineBreak(String data) throws IOException {
/* 1269 */     this.whitespace = true;
/* 1270 */     this.indention = true;
/* 1271 */     this.column = 0;
/* 1272 */     if (data == null) {
/* 1273 */       this.stream.write(this.bestLineBreak);
/*      */     } else {
/* 1275 */       this.stream.write(data);
/*      */     }
/*      */   }
/*      */   
/*      */   void writeVersionDirective(String versionText) throws IOException {
/* 1280 */     this.stream.write("%YAML ");
/* 1281 */     this.stream.write(versionText);
/* 1282 */     writeLineBreak(null);
/*      */   }
/*      */   
/*      */   void writeTagDirective(String handleText, String prefixText)
/*      */     throws IOException
/*      */   {
/* 1288 */     this.stream.write("%TAG ");
/* 1289 */     this.stream.write(handleText);
/* 1290 */     this.stream.write(SPACE);
/* 1291 */     this.stream.write(prefixText);
/* 1292 */     writeLineBreak(null);
/*      */   }
/*      */   
/*      */   private void writeSingleQuoted(String text, boolean split) throws IOException
/*      */   {
/* 1297 */     writeIndicator("'", true, false, false);
/* 1298 */     boolean spaces = false;
/* 1299 */     boolean breaks = false;
/* 1300 */     int start = 0;int end = 0;
/*      */     
/* 1302 */     while (end <= text.length()) {
/* 1303 */       char ch = '\000';
/* 1304 */       if (end < text.length()) {
/* 1305 */         ch = text.charAt(end);
/*      */       }
/* 1307 */       if (spaces) {
/* 1308 */         if ((ch == 0) || (ch != ' ')) {
/* 1309 */           if ((start + 1 == end) && (this.column > this.bestWidth) && (split) && (start != 0) && (end != text.length()))
/*      */           {
/* 1311 */             writeIndent();
/*      */           } else {
/* 1313 */             int len = end - start;
/* 1314 */             this.column += len;
/* 1315 */             this.stream.write(text, start, len);
/*      */           }
/* 1317 */           start = end;
/*      */         }
/* 1319 */       } else if (breaks) {
/* 1320 */         if ((ch == 0) || (Constant.LINEBR.hasNo(ch))) {
/* 1321 */           if (text.charAt(start) == '\n') {
/* 1322 */             writeLineBreak(null);
/*      */           }
/* 1324 */           String data = text.substring(start, end);
/* 1325 */           for (char br : data.toCharArray()) {
/* 1326 */             if (br == '\n') {
/* 1327 */               writeLineBreak(null);
/*      */             } else {
/* 1329 */               writeLineBreak(String.valueOf(br));
/*      */             }
/*      */           }
/* 1332 */           writeIndent();
/* 1333 */           start = end;
/*      */         }
/*      */       }
/* 1336 */       else if ((Constant.LINEBR.has(ch, "\000 '")) && 
/* 1337 */         (start < end)) {
/* 1338 */         int len = end - start;
/* 1339 */         this.column += len;
/* 1340 */         this.stream.write(text, start, len);
/* 1341 */         start = end;
/*      */       }
/*      */       
/*      */ 
/* 1345 */       if (ch == '\'') {
/* 1346 */         this.column += 2;
/* 1347 */         this.stream.write("''");
/* 1348 */         start = end + 1;
/*      */       }
/* 1350 */       if (ch != 0) {
/* 1351 */         spaces = ch == ' ';
/* 1352 */         breaks = Constant.LINEBR.has(ch);
/*      */       }
/* 1354 */       end++;
/*      */     }
/* 1356 */     writeIndicator("'", false, false, false);
/*      */   }
/*      */   
/*      */   private void writeDoubleQuoted(String text, boolean split) throws IOException {
/* 1360 */     writeIndicator("\"", true, false, false);
/* 1361 */     int start = 0;
/* 1362 */     int end = 0;
/* 1363 */     while (end <= text.length()) {
/* 1364 */       Character ch = null;
/* 1365 */       if (end < text.length()) {
/* 1366 */         ch = Character.valueOf(text.charAt(end));
/*      */       }
/* 1368 */       if ((ch == null) || ("\"\\  ﻿".indexOf(ch.charValue()) != -1) || (' ' > ch.charValue()) || (ch.charValue() > '~'))
/*      */       {
/* 1370 */         if (start < end) {
/* 1371 */           int len = end - start;
/* 1372 */           this.column += len;
/* 1373 */           this.stream.write(text, start, len);
/* 1374 */           start = end;
/*      */         }
/* 1376 */         if (ch != null) { String data;
/*      */           String data;
/* 1378 */           if (ESCAPE_REPLACEMENTS.containsKey(ch)) {
/* 1379 */             data = "\\" + (String)ESCAPE_REPLACEMENTS.get(ch); } else { String data;
/* 1380 */             if ((!this.allowUnicode) || (!StreamReader.isPrintable(ch.charValue())))
/*      */             {
/*      */               String data;
/* 1383 */               if (ch.charValue() <= 'ÿ') {
/* 1384 */                 String s = "0" + Integer.toString(ch.charValue(), 16);
/* 1385 */                 data = "\\x" + s.substring(s.length() - 2); } else { String data;
/* 1386 */                 if ((ch.charValue() >= 55296) && (ch.charValue() <= 56319)) { String data;
/* 1387 */                   if (end + 1 < text.length()) {
/* 1388 */                     Character ch2 = Character.valueOf(text.charAt(++end));
/* 1389 */                     String s = "000" + Long.toHexString(Character.toCodePoint(ch.charValue(), ch2.charValue()));
/* 1390 */                     data = "\\U" + s.substring(s.length() - 8);
/*      */                   } else {
/* 1392 */                     String s = "000" + Integer.toString(ch.charValue(), 16);
/* 1393 */                     data = "\\u" + s.substring(s.length() - 4);
/*      */                   }
/*      */                 } else {
/* 1396 */                   String s = "000" + Integer.toString(ch.charValue(), 16);
/* 1397 */                   data = "\\u" + s.substring(s.length() - 4);
/*      */                 }
/*      */               }
/* 1400 */             } else { data = String.valueOf(ch);
/*      */             } }
/* 1402 */           this.column += data.length();
/* 1403 */           this.stream.write(data);
/* 1404 */           start = end + 1;
/*      */         }
/*      */       }
/* 1407 */       if ((0 < end) && (end < text.length() - 1) && ((ch.charValue() == ' ') || (start >= end)) && (this.column + (end - start) > this.bestWidth) && (split)) {
/*      */         String data;
/*      */         String data;
/* 1410 */         if (start >= end) {
/* 1411 */           data = "\\";
/*      */         } else {
/* 1413 */           data = text.substring(start, end) + "\\";
/*      */         }
/* 1415 */         if (start < end) {
/* 1416 */           start = end;
/*      */         }
/* 1418 */         this.column += data.length();
/* 1419 */         this.stream.write(data);
/* 1420 */         writeIndent();
/* 1421 */         this.whitespace = false;
/* 1422 */         this.indention = false;
/* 1423 */         if (text.charAt(start) == ' ') {
/* 1424 */           data = "\\";
/* 1425 */           this.column += data.length();
/* 1426 */           this.stream.write(data);
/*      */         }
/*      */       }
/* 1429 */       end++;
/*      */     }
/* 1431 */     writeIndicator("\"", false, false, false);
/*      */   }
/*      */   
/*      */   private boolean writeCommentLines(List<CommentLine> commentLines) throws IOException {
/* 1435 */     int indentColumns = 0;
/* 1436 */     boolean firstComment = true;
/* 1437 */     boolean wroteComment = false;
/* 1438 */     for (CommentLine commentLine : commentLines) {
/* 1439 */       if (commentLine.getCommentType() != CommentType.BLANK_LINE) {
/* 1440 */         if (firstComment) {
/* 1441 */           firstComment = false;
/* 1442 */           writeIndicator("#", commentLine.getCommentType() == CommentType.IN_LINE, false, false);
/* 1443 */           indentColumns = this.column > 0 ? this.column - 1 : 0;
/*      */         } else {
/* 1445 */           writeWhitespace(indentColumns);
/* 1446 */           writeIndicator("#", false, false, false);
/*      */         }
/* 1448 */         this.stream.write(commentLine.getValue());
/*      */       }
/* 1450 */       writeLineBreak(null);
/* 1451 */       wroteComment = true;
/*      */     }
/* 1453 */     return wroteComment;
/*      */   }
/*      */   
/*      */   private void writeBlockComment() throws IOException {
/* 1457 */     if (!this.blockCommentsCollector.isEmpty()) {
/* 1458 */       writeIndent();
/*      */     }
/* 1460 */     writeCommentLines(this.blockCommentsCollector.consume());
/*      */   }
/*      */   
/*      */   private boolean writeInlineComments() throws IOException {
/* 1464 */     return writeCommentLines(this.inlineCommentsCollector.consume());
/*      */   }
/*      */   
/*      */   private String determineBlockHints(String text) {
/* 1468 */     StringBuilder hints = new StringBuilder();
/* 1469 */     if (Constant.LINEBR.has(text.charAt(0), " ")) {
/* 1470 */       hints.append(this.bestIndent);
/*      */     }
/* 1472 */     char ch1 = text.charAt(text.length() - 1);
/* 1473 */     if (Constant.LINEBR.hasNo(ch1)) {
/* 1474 */       hints.append("-");
/* 1475 */     } else if ((text.length() == 1) || (Constant.LINEBR.has(text.charAt(text.length() - 2)))) {
/* 1476 */       hints.append("+");
/*      */     }
/* 1478 */     return hints.toString();
/*      */   }
/*      */   
/*      */   void writeFolded(String text, boolean split) throws IOException {
/* 1482 */     String hints = determineBlockHints(text);
/* 1483 */     writeIndicator(">" + hints, true, false, false);
/* 1484 */     if ((hints.length() > 0) && (hints.charAt(hints.length() - 1) == '+')) {
/* 1485 */       this.openEnded = true;
/*      */     }
/* 1487 */     if (!writeInlineComments()) {
/* 1488 */       writeLineBreak(null);
/*      */     }
/* 1490 */     boolean leadingSpace = true;
/* 1491 */     boolean spaces = false;
/* 1492 */     boolean breaks = true;
/* 1493 */     int start = 0;int end = 0;
/* 1494 */     while (end <= text.length()) {
/* 1495 */       char ch = '\000';
/* 1496 */       if (end < text.length()) {
/* 1497 */         ch = text.charAt(end);
/*      */       }
/* 1499 */       if (breaks) {
/* 1500 */         if ((ch == 0) || (Constant.LINEBR.hasNo(ch))) {
/* 1501 */           if ((!leadingSpace) && (ch != 0) && (ch != ' ') && (text.charAt(start) == '\n')) {
/* 1502 */             writeLineBreak(null);
/*      */           }
/* 1504 */           leadingSpace = ch == ' ';
/* 1505 */           String data = text.substring(start, end);
/* 1506 */           for (char br : data.toCharArray()) {
/* 1507 */             if (br == '\n') {
/* 1508 */               writeLineBreak(null);
/*      */             } else {
/* 1510 */               writeLineBreak(String.valueOf(br));
/*      */             }
/*      */           }
/* 1513 */           if (ch != 0) {
/* 1514 */             writeIndent();
/*      */           }
/* 1516 */           start = end;
/*      */         }
/* 1518 */       } else if (spaces) {
/* 1519 */         if (ch != ' ') {
/* 1520 */           if ((start + 1 == end) && (this.column > this.bestWidth) && (split)) {
/* 1521 */             writeIndent();
/*      */           } else {
/* 1523 */             int len = end - start;
/* 1524 */             this.column += len;
/* 1525 */             this.stream.write(text, start, len);
/*      */           }
/* 1527 */           start = end;
/*      */         }
/*      */       }
/* 1530 */       else if (Constant.LINEBR.has(ch, "\000 ")) {
/* 1531 */         int len = end - start;
/* 1532 */         this.column += len;
/* 1533 */         this.stream.write(text, start, len);
/* 1534 */         if (ch == 0) {
/* 1535 */           writeLineBreak(null);
/*      */         }
/* 1537 */         start = end;
/*      */       }
/*      */       
/* 1540 */       if (ch != 0) {
/* 1541 */         breaks = Constant.LINEBR.has(ch);
/* 1542 */         spaces = ch == ' ';
/*      */       }
/* 1544 */       end++;
/*      */     }
/*      */   }
/*      */   
/*      */   void writeLiteral(String text) throws IOException {
/* 1549 */     String hints = determineBlockHints(text);
/* 1550 */     writeIndicator("|" + hints, true, false, false);
/* 1551 */     if ((hints.length() > 0) && (hints.charAt(hints.length() - 1) == '+')) {
/* 1552 */       this.openEnded = true;
/*      */     }
/* 1554 */     if (!writeInlineComments()) {
/* 1555 */       writeLineBreak(null);
/*      */     }
/* 1557 */     boolean breaks = true;
/* 1558 */     int start = 0;int end = 0;
/* 1559 */     while (end <= text.length()) {
/* 1560 */       char ch = '\000';
/* 1561 */       if (end < text.length()) {
/* 1562 */         ch = text.charAt(end);
/*      */       }
/* 1564 */       if (breaks) {
/* 1565 */         if ((ch == 0) || (Constant.LINEBR.hasNo(ch))) {
/* 1566 */           String data = text.substring(start, end);
/* 1567 */           for (char br : data.toCharArray()) {
/* 1568 */             if (br == '\n') {
/* 1569 */               writeLineBreak(null);
/*      */             } else {
/* 1571 */               writeLineBreak(String.valueOf(br));
/*      */             }
/*      */           }
/* 1574 */           if (ch != 0) {
/* 1575 */             writeIndent();
/*      */           }
/* 1577 */           start = end;
/*      */         }
/*      */       }
/* 1580 */       else if ((ch == 0) || (Constant.LINEBR.has(ch))) {
/* 1581 */         this.stream.write(text, start, end - start);
/* 1582 */         if (ch == 0) {
/* 1583 */           writeLineBreak(null);
/*      */         }
/* 1585 */         start = end;
/*      */       }
/*      */       
/* 1588 */       if (ch != 0) {
/* 1589 */         breaks = Constant.LINEBR.has(ch);
/*      */       }
/* 1591 */       end++;
/*      */     }
/*      */   }
/*      */   
/*      */   void writePlain(String text, boolean split) throws IOException {
/* 1596 */     if (this.rootContext) {
/* 1597 */       this.openEnded = true;
/*      */     }
/* 1599 */     if (text.length() == 0) {
/* 1600 */       return;
/*      */     }
/* 1602 */     if (!this.whitespace) {
/* 1603 */       this.column += 1;
/* 1604 */       this.stream.write(SPACE);
/*      */     }
/* 1606 */     this.whitespace = false;
/* 1607 */     this.indention = false;
/* 1608 */     boolean spaces = false;
/* 1609 */     boolean breaks = false;
/* 1610 */     int start = 0;int end = 0;
/* 1611 */     while (end <= text.length()) {
/* 1612 */       char ch = '\000';
/* 1613 */       if (end < text.length()) {
/* 1614 */         ch = text.charAt(end);
/*      */       }
/* 1616 */       if (spaces) {
/* 1617 */         if (ch != ' ') {
/* 1618 */           if ((start + 1 == end) && (this.column > this.bestWidth) && (split)) {
/* 1619 */             writeIndent();
/* 1620 */             this.whitespace = false;
/* 1621 */             this.indention = false;
/*      */           } else {
/* 1623 */             int len = end - start;
/* 1624 */             this.column += len;
/* 1625 */             this.stream.write(text, start, len);
/*      */           }
/* 1627 */           start = end;
/*      */         }
/* 1629 */       } else if (breaks) {
/* 1630 */         if (Constant.LINEBR.hasNo(ch)) {
/* 1631 */           if (text.charAt(start) == '\n') {
/* 1632 */             writeLineBreak(null);
/*      */           }
/* 1634 */           String data = text.substring(start, end);
/* 1635 */           for (char br : data.toCharArray()) {
/* 1636 */             if (br == '\n') {
/* 1637 */               writeLineBreak(null);
/*      */             } else {
/* 1639 */               writeLineBreak(String.valueOf(br));
/*      */             }
/*      */           }
/* 1642 */           writeIndent();
/* 1643 */           this.whitespace = false;
/* 1644 */           this.indention = false;
/* 1645 */           start = end;
/*      */         }
/*      */       }
/* 1648 */       else if (Constant.LINEBR.has(ch, "\000 ")) {
/* 1649 */         int len = end - start;
/* 1650 */         this.column += len;
/* 1651 */         this.stream.write(text, start, len);
/* 1652 */         start = end;
/*      */       }
/*      */       
/* 1655 */       if (ch != 0) {
/* 1656 */         spaces = ch == ' ';
/* 1657 */         breaks = Constant.LINEBR.has(ch);
/*      */       }
/* 1659 */       end++;
/*      */     }
/*      */   }
/*      */   
/*      */   void writeStreamStart() {}
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\snakeyaml-1.28.jar!\org\yaml\snakeyaml\emitter\Emitter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */