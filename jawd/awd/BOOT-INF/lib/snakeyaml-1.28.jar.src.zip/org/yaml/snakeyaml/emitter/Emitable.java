package org.yaml.snakeyaml.emitter;

import java.io.IOException;
import org.yaml.snakeyaml.events.Event;

public abstract interface Emitable
{
  public abstract void emit(Event paramEvent)
    throws IOException;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\snakeyaml-1.28.jar!\org\yaml\snakeyaml\emitter\Emitable.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */