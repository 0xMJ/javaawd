/*     */ package org.yaml.snakeyaml.parser;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.yaml.snakeyaml.DumperOptions.FlowStyle;
/*     */ import org.yaml.snakeyaml.DumperOptions.ScalarStyle;
/*     */ import org.yaml.snakeyaml.DumperOptions.Version;
/*     */ import org.yaml.snakeyaml.comments.CommentType;
/*     */ import org.yaml.snakeyaml.error.Mark;
/*     */ import org.yaml.snakeyaml.error.YAMLException;
/*     */ import org.yaml.snakeyaml.events.AliasEvent;
/*     */ import org.yaml.snakeyaml.events.CommentEvent;
/*     */ import org.yaml.snakeyaml.events.DocumentEndEvent;
/*     */ import org.yaml.snakeyaml.events.DocumentStartEvent;
/*     */ import org.yaml.snakeyaml.events.Event;
/*     */ import org.yaml.snakeyaml.events.Event.ID;
/*     */ import org.yaml.snakeyaml.events.ImplicitTuple;
/*     */ import org.yaml.snakeyaml.events.MappingEndEvent;
/*     */ import org.yaml.snakeyaml.events.MappingStartEvent;
/*     */ import org.yaml.snakeyaml.events.ScalarEvent;
/*     */ import org.yaml.snakeyaml.events.SequenceEndEvent;
/*     */ import org.yaml.snakeyaml.events.SequenceStartEvent;
/*     */ import org.yaml.snakeyaml.events.StreamEndEvent;
/*     */ import org.yaml.snakeyaml.events.StreamStartEvent;
/*     */ import org.yaml.snakeyaml.reader.StreamReader;
/*     */ import org.yaml.snakeyaml.scanner.Scanner;
/*     */ import org.yaml.snakeyaml.scanner.ScannerImpl;
/*     */ import org.yaml.snakeyaml.tokens.AliasToken;
/*     */ import org.yaml.snakeyaml.tokens.AnchorToken;
/*     */ import org.yaml.snakeyaml.tokens.BlockEntryToken;
/*     */ import org.yaml.snakeyaml.tokens.CommentToken;
/*     */ import org.yaml.snakeyaml.tokens.DirectiveToken;
/*     */ import org.yaml.snakeyaml.tokens.ScalarToken;
/*     */ import org.yaml.snakeyaml.tokens.StreamEndToken;
/*     */ import org.yaml.snakeyaml.tokens.StreamStartToken;
/*     */ import org.yaml.snakeyaml.tokens.TagToken;
/*     */ import org.yaml.snakeyaml.tokens.TagTuple;
/*     */ import org.yaml.snakeyaml.tokens.Token;
/*     */ import org.yaml.snakeyaml.tokens.Token.ID;
/*     */ import org.yaml.snakeyaml.util.ArrayStack;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ParserImpl
/*     */   implements Parser
/*     */ {
/* 121 */   private static final Map<String, String> DEFAULT_TAGS = new HashMap();
/*     */   
/* 123 */   static { DEFAULT_TAGS.put("!", "!");
/* 124 */     DEFAULT_TAGS.put("!!", "tag:yaml.org,2002:");
/*     */   }
/*     */   
/*     */ 
/*     */   protected final Scanner scanner;
/*     */   
/*     */   private Event currentEvent;
/*     */   
/*     */   private final ArrayStack<Production> states;
/*     */   public ParserImpl(StreamReader reader)
/*     */   {
/* 135 */     this(new ScannerImpl(reader));
/*     */   }
/*     */   
/*     */   public ParserImpl(StreamReader reader, boolean emitComments) {
/* 139 */     this(new ScannerImpl(reader).setEmitComments(emitComments));
/*     */   }
/*     */   
/*     */   public ParserImpl(Scanner scanner) {
/* 143 */     this.scanner = scanner;
/* 144 */     this.currentEvent = null;
/* 145 */     this.directives = new VersionTagsTuple(null, new HashMap(DEFAULT_TAGS));
/* 146 */     this.states = new ArrayStack(100);
/* 147 */     this.marks = new ArrayStack(10);
/* 148 */     this.state = new ParseStreamStart(null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean checkEvent(Event.ID choice)
/*     */   {
/* 155 */     peekEvent();
/* 156 */     return (this.currentEvent != null) && (this.currentEvent.is(choice));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Event peekEvent()
/*     */   {
/* 163 */     if ((this.currentEvent == null) && 
/* 164 */       (this.state != null)) {
/* 165 */       this.currentEvent = this.state.produce();
/*     */     }
/*     */     
/* 168 */     return this.currentEvent;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Event getEvent()
/*     */   {
/* 175 */     peekEvent();
/* 176 */     Event value = this.currentEvent;
/* 177 */     this.currentEvent = null;
/* 178 */     return value;
/*     */   }
/*     */   
/*     */   private CommentEvent produceCommentEvent(CommentToken token) {
/* 182 */     Mark startMark = token.getStartMark();
/* 183 */     Mark endMark = token.getEndMark();
/* 184 */     String value = token.getValue();
/* 185 */     CommentType type = token.getCommentType();
/*     */     
/*     */ 
/*     */ 
/* 189 */     return new CommentEvent(type, value, startMark, endMark);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private class ParseStreamStart
/*     */     implements Production
/*     */   {
/*     */     private ParseStreamStart() {}
/*     */     
/*     */ 
/*     */     public Event produce()
/*     */     {
/* 202 */       StreamStartToken token = (StreamStartToken)ParserImpl.this.scanner.getToken();
/* 203 */       Event event = new StreamStartEvent(token.getStartMark(), token.getEndMark());
/*     */       
/* 205 */       ParserImpl.this.state = new ParserImpl.ParseImplicitDocumentStart(ParserImpl.this, null);
/* 206 */       return event;
/*     */     }
/*     */   }
/*     */   
/*     */   private class ParseImplicitDocumentStart implements Production {
/*     */     private ParseImplicitDocumentStart() {}
/*     */     
/* 213 */     public Event produce() { if (ParserImpl.this.scanner.checkToken(new Token.ID[] { Token.ID.Comment }))
/* 214 */         return ParserImpl.this.produceCommentEvent((CommentToken)ParserImpl.this.scanner.getToken());
/* 215 */       if (!ParserImpl.this.scanner.checkToken(new Token.ID[] { Token.ID.Directive, Token.ID.DocumentStart, Token.ID.StreamEnd })) {
/* 216 */         ParserImpl.this.directives = new VersionTagsTuple(null, ParserImpl.DEFAULT_TAGS);
/* 217 */         Token token = ParserImpl.this.scanner.peekToken();
/* 218 */         Mark startMark = token.getStartMark();
/* 219 */         Mark endMark = startMark;
/* 220 */         Event event = new DocumentStartEvent(startMark, endMark, false, null, null);
/*     */         
/* 222 */         ParserImpl.this.states.push(new ParserImpl.ParseDocumentEnd(ParserImpl.this, null));
/* 223 */         ParserImpl.this.state = new ParserImpl.ParseBlockNode(ParserImpl.this, null);
/* 224 */         return event;
/*     */       }
/* 226 */       Production p = new ParserImpl.ParseDocumentStart(ParserImpl.this, null);
/* 227 */       return p.produce();
/*     */     }
/*     */   }
/*     */   
/*     */   private class ParseDocumentStart implements Production {
/*     */     private ParseDocumentStart() {}
/*     */     
/* 234 */     public Event produce() { if (ParserImpl.this.scanner.checkToken(new Token.ID[] { Token.ID.Comment })) {
/* 235 */         return ParserImpl.this.produceCommentEvent((CommentToken)ParserImpl.this.scanner.getToken());
/*     */       }
/*     */       
/* 238 */       while (ParserImpl.this.scanner.checkToken(new Token.ID[] { Token.ID.DocumentEnd })) {
/* 239 */         ParserImpl.this.scanner.getToken();
/*     */       }
/* 241 */       if (ParserImpl.this.scanner.checkToken(new Token.ID[] { Token.ID.Comment })) {
/* 242 */         return ParserImpl.this.produceCommentEvent((CommentToken)ParserImpl.this.scanner.getToken());
/*     */       }
/*     */       
/*     */ 
/* 246 */       if (!ParserImpl.this.scanner.checkToken(new Token.ID[] { Token.ID.StreamEnd })) {
/* 247 */         Token token = ParserImpl.this.scanner.peekToken();
/* 248 */         Mark startMark = token.getStartMark();
/* 249 */         VersionTagsTuple tuple = ParserImpl.this.processDirectives();
/* 250 */         while (ParserImpl.this.scanner.checkToken(new Token.ID[] { Token.ID.Comment }))
/*     */         {
/* 252 */           ParserImpl.this.scanner.getToken();
/*     */         }
/* 254 */         if (!ParserImpl.this.scanner.checkToken(new Token.ID[] { Token.ID.StreamEnd })) {
/* 255 */           if (!ParserImpl.this.scanner.checkToken(new Token.ID[] { Token.ID.DocumentStart })) {
/* 256 */             throw new ParserException(null, null, "expected '<document start>', but found '" + ParserImpl.this.scanner.peekToken().getTokenId() + "'", ParserImpl.this.scanner.peekToken().getStartMark());
/*     */           }
/*     */           
/* 259 */           token = ParserImpl.this.scanner.getToken();
/* 260 */           Mark endMark = token.getEndMark();
/* 261 */           Event event = new DocumentStartEvent(startMark, endMark, true, tuple.getVersion(), tuple.getTags());
/*     */           
/* 263 */           ParserImpl.this.states.push(new ParserImpl.ParseDocumentEnd(ParserImpl.this, null));
/* 264 */           ParserImpl.this.state = new ParserImpl.ParseDocumentContent(ParserImpl.this, null);
/* 265 */           return event;
/*     */         }
/*     */       }
/*     */       
/* 269 */       StreamEndToken token = (StreamEndToken)ParserImpl.this.scanner.getToken();
/* 270 */       Event event = new StreamEndEvent(token.getStartMark(), token.getEndMark());
/* 271 */       if (!ParserImpl.this.states.isEmpty()) {
/* 272 */         throw new YAMLException("Unexpected end of stream. States left: " + ParserImpl.this.states);
/*     */       }
/* 274 */       if (!ParserImpl.this.marks.isEmpty()) {
/* 275 */         throw new YAMLException("Unexpected end of stream. Marks left: " + ParserImpl.this.marks);
/*     */       }
/* 277 */       ParserImpl.this.state = null;
/*     */       
/* 279 */       return event;
/*     */     }
/*     */   }
/*     */   
/*     */   private class ParseDocumentEnd implements Production {
/*     */     private ParseDocumentEnd() {}
/*     */     
/* 286 */     public Event produce() { Token token = ParserImpl.this.scanner.peekToken();
/* 287 */       Mark startMark = token.getStartMark();
/* 288 */       Mark endMark = startMark;
/* 289 */       boolean explicit = false;
/* 290 */       if (ParserImpl.this.scanner.checkToken(new Token.ID[] { Token.ID.DocumentEnd })) {
/* 291 */         token = ParserImpl.this.scanner.getToken();
/* 292 */         endMark = token.getEndMark();
/* 293 */         explicit = true;
/*     */       }
/* 295 */       Event event = new DocumentEndEvent(startMark, endMark, explicit);
/*     */       
/* 297 */       ParserImpl.this.state = new ParserImpl.ParseDocumentStart(ParserImpl.this, null);
/* 298 */       return event;
/*     */     }
/*     */   }
/*     */   
/*     */   private class ParseDocumentContent implements Production { private ParseDocumentContent() {}
/*     */     
/* 304 */     public Event produce() { if (ParserImpl.this.scanner.checkToken(new Token.ID[] { Token.ID.Comment })) {
/* 305 */         return ParserImpl.this.produceCommentEvent((CommentToken)ParserImpl.this.scanner.getToken());
/*     */       }
/*     */       
/* 308 */       if (ParserImpl.this.scanner.checkToken(new Token.ID[] { Token.ID.Directive, Token.ID.DocumentStart, Token.ID.DocumentEnd, Token.ID.StreamEnd }))
/*     */       {
/* 310 */         Event event = ParserImpl.this.processEmptyScalar(ParserImpl.this.scanner.peekToken().getStartMark());
/* 311 */         ParserImpl.this.state = ((Production)ParserImpl.this.states.pop());
/* 312 */         return event;
/*     */       }
/* 314 */       Production p = new ParserImpl.ParseBlockNode(ParserImpl.this, null);
/* 315 */       return p.produce();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private VersionTagsTuple processDirectives()
/*     */   {
/* 322 */     DumperOptions.Version yamlVersion = null;
/* 323 */     HashMap<String, String> tagHandles = new HashMap();
/* 324 */     while (this.scanner.checkToken(new Token.ID[] { Token.ID.Directive }))
/*     */     {
/* 326 */       DirectiveToken token = (DirectiveToken)this.scanner.getToken();
/* 327 */       if (token.getName().equals("YAML")) {
/* 328 */         if (yamlVersion != null) {
/* 329 */           throw new ParserException(null, null, "found duplicate YAML directive", token.getStartMark());
/*     */         }
/*     */         
/* 332 */         List<Integer> value = token.getValue();
/* 333 */         Integer major = (Integer)value.get(0);
/* 334 */         if (major.intValue() != 1) {
/* 335 */           throw new ParserException(null, null, "found incompatible YAML document (version 1.* is required)", token.getStartMark());
/*     */         }
/*     */         
/*     */ 
/* 339 */         Integer minor = (Integer)value.get(1);
/* 340 */         switch (minor.intValue()) {
/*     */         case 0: 
/* 342 */           yamlVersion = DumperOptions.Version.V1_0;
/* 343 */           break;
/*     */         
/*     */         default: 
/* 346 */           yamlVersion = DumperOptions.Version.V1_1;
/*     */         }
/*     */       }
/* 349 */       else if (token.getName().equals("TAG")) {
/* 350 */         List<String> value = token.getValue();
/* 351 */         String handle = (String)value.get(0);
/* 352 */         String prefix = (String)value.get(1);
/* 353 */         if (tagHandles.containsKey(handle)) {
/* 354 */           throw new ParserException(null, null, "duplicate tag handle " + handle, token.getStartMark());
/*     */         }
/*     */         
/* 357 */         tagHandles.put(handle, prefix);
/*     */       }
/*     */     }
/* 360 */     if ((yamlVersion != null) || (!tagHandles.isEmpty()))
/*     */     {
/* 362 */       for (String key : DEFAULT_TAGS.keySet())
/*     */       {
/* 364 */         if (!tagHandles.containsKey(key)) {
/* 365 */           tagHandles.put(key, DEFAULT_TAGS.get(key));
/*     */         }
/*     */       }
/* 368 */       this.directives = new VersionTagsTuple(yamlVersion, tagHandles);
/*     */     }
/* 370 */     return this.directives;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final ArrayStack<Mark> marks;
/*     */   
/*     */ 
/*     */ 
/*     */   private Production state;
/*     */   
/*     */ 
/*     */   private VersionTagsTuple directives;
/*     */   
/*     */ 
/*     */   private class ParseBlockNode
/*     */     implements Production
/*     */   {
/*     */     private ParseBlockNode() {}
/*     */     
/*     */ 
/*     */ 
/*     */     public Event produce()
/*     */     {
/* 395 */       return ParserImpl.this.parseNode(true, false);
/*     */     }
/*     */   }
/*     */   
/*     */   private Event parseFlowNode() {
/* 400 */     return parseNode(false, false);
/*     */   }
/*     */   
/*     */   private Event parseBlockNodeOrIndentlessSequence() {
/* 404 */     return parseNode(true, true);
/*     */   }
/*     */   
/*     */   private Event parseNode(boolean block, boolean indentlessSequence)
/*     */   {
/* 409 */     Mark startMark = null;
/* 410 */     Mark endMark = null;
/* 411 */     Mark tagMark = null;
/* 412 */     Event event; if (this.scanner.checkToken(new Token.ID[] { Token.ID.Alias })) {
/* 413 */       AliasToken token = (AliasToken)this.scanner.getToken();
/* 414 */       Event event = new AliasEvent(token.getValue(), token.getStartMark(), token.getEndMark());
/* 415 */       this.state = ((Production)this.states.pop());
/*     */     } else {
/* 417 */       String anchor = null;
/* 418 */       TagTuple tagTokenTag = null;
/* 419 */       if (this.scanner.checkToken(new Token.ID[] { Token.ID.Anchor })) {
/* 420 */         AnchorToken token = (AnchorToken)this.scanner.getToken();
/* 421 */         startMark = token.getStartMark();
/* 422 */         endMark = token.getEndMark();
/* 423 */         anchor = token.getValue();
/* 424 */         if (this.scanner.checkToken(new Token.ID[] { Token.ID.Tag })) {
/* 425 */           TagToken tagToken = (TagToken)this.scanner.getToken();
/* 426 */           tagMark = tagToken.getStartMark();
/* 427 */           endMark = tagToken.getEndMark();
/* 428 */           tagTokenTag = tagToken.getValue();
/*     */         }
/* 430 */       } else if (this.scanner.checkToken(new Token.ID[] { Token.ID.Tag })) {
/* 431 */         TagToken tagToken = (TagToken)this.scanner.getToken();
/* 432 */         startMark = tagToken.getStartMark();
/* 433 */         tagMark = startMark;
/* 434 */         endMark = tagToken.getEndMark();
/* 435 */         tagTokenTag = tagToken.getValue();
/* 436 */         if (this.scanner.checkToken(new Token.ID[] { Token.ID.Anchor })) {
/* 437 */           AnchorToken token = (AnchorToken)this.scanner.getToken();
/* 438 */           endMark = token.getEndMark();
/* 439 */           anchor = token.getValue();
/*     */         }
/*     */       }
/* 442 */       String tag = null;
/* 443 */       if (tagTokenTag != null) {
/* 444 */         String handle = tagTokenTag.getHandle();
/* 445 */         String suffix = tagTokenTag.getSuffix();
/* 446 */         if (handle != null) {
/* 447 */           if (!this.directives.getTags().containsKey(handle)) {
/* 448 */             throw new ParserException("while parsing a node", startMark, "found undefined tag handle " + handle, tagMark);
/*     */           }
/*     */           
/* 451 */           tag = (String)this.directives.getTags().get(handle) + suffix;
/*     */         } else {
/* 453 */           tag = suffix;
/*     */         }
/*     */       }
/* 456 */       if (startMark == null) {
/* 457 */         startMark = this.scanner.peekToken().getStartMark();
/* 458 */         endMark = startMark;
/*     */       }
/* 460 */       event = null;
/* 461 */       boolean implicit = (tag == null) || (tag.equals("!"));
/* 462 */       if (indentlessSequence) if (this.scanner.checkToken(new Token.ID[] { Token.ID.BlockEntry })) {
/* 463 */           endMark = this.scanner.peekToken().getEndMark();
/* 464 */           event = new SequenceStartEvent(anchor, tag, implicit, startMark, endMark, DumperOptions.FlowStyle.BLOCK);
/*     */           
/* 466 */           this.state = new ParseIndentlessSequenceEntry(null); return event;
/*     */         }
/* 468 */       if (this.scanner.checkToken(new Token.ID[] { Token.ID.Scalar })) {
/* 469 */         ScalarToken token = (ScalarToken)this.scanner.getToken();
/* 470 */         endMark = token.getEndMark();
/*     */         ImplicitTuple implicitValues;
/* 472 */         ImplicitTuple implicitValues; if (((token.getPlain()) && (tag == null)) || ("!".equals(tag))) {
/* 473 */           implicitValues = new ImplicitTuple(true, false); } else { ImplicitTuple implicitValues;
/* 474 */           if (tag == null) {
/* 475 */             implicitValues = new ImplicitTuple(false, true);
/*     */           } else
/* 477 */             implicitValues = new ImplicitTuple(false, false);
/*     */         }
/* 479 */         event = new ScalarEvent(anchor, tag, implicitValues, token.getValue(), startMark, endMark, token.getStyle());
/*     */         
/* 481 */         this.state = ((Production)this.states.pop());
/* 482 */       } else if (this.scanner.checkToken(new Token.ID[] { Token.ID.Comment })) {
/* 483 */         event = produceCommentEvent((CommentToken)this.scanner.getToken());
/* 484 */       } else if (this.scanner.checkToken(new Token.ID[] { Token.ID.FlowSequenceStart })) {
/* 485 */         endMark = this.scanner.peekToken().getEndMark();
/* 486 */         event = new SequenceStartEvent(anchor, tag, implicit, startMark, endMark, DumperOptions.FlowStyle.FLOW);
/*     */         
/* 488 */         this.state = new ParseFlowSequenceFirstEntry(null);
/* 489 */       } else if (this.scanner.checkToken(new Token.ID[] { Token.ID.FlowMappingStart })) {
/* 490 */         endMark = this.scanner.peekToken().getEndMark();
/* 491 */         event = new MappingStartEvent(anchor, tag, implicit, startMark, endMark, DumperOptions.FlowStyle.FLOW);
/*     */         
/* 493 */         this.state = new ParseFlowMappingFirstKey(null);
/* 494 */       } else { if (block) if (this.scanner.checkToken(new Token.ID[] { Token.ID.BlockSequenceStart })) {
/* 495 */             endMark = this.scanner.peekToken().getStartMark();
/* 496 */             event = new SequenceStartEvent(anchor, tag, implicit, startMark, endMark, DumperOptions.FlowStyle.BLOCK);
/*     */             
/* 498 */             this.state = new ParseBlockSequenceFirstEntry(null); return event; }
/* 499 */         if (block) if (this.scanner.checkToken(new Token.ID[] { Token.ID.BlockMappingStart })) {
/* 500 */             endMark = this.scanner.peekToken().getStartMark();
/* 501 */             event = new MappingStartEvent(anchor, tag, implicit, startMark, endMark, DumperOptions.FlowStyle.BLOCK);
/*     */             
/* 503 */             this.state = new ParseBlockMappingFirstKey(null); return event; }
/* 504 */         if ((anchor != null) || (tag != null))
/*     */         {
/*     */ 
/* 507 */           event = new ScalarEvent(anchor, tag, new ImplicitTuple(implicit, false), "", startMark, endMark, DumperOptions.ScalarStyle.PLAIN);
/*     */           
/* 509 */           this.state = ((Production)this.states.pop());
/*     */         } else { String node;
/*     */           String node;
/* 512 */           if (block) {
/* 513 */             node = "block";
/*     */           } else {
/* 515 */             node = "flow";
/*     */           }
/* 517 */           Token token = this.scanner.peekToken();
/* 518 */           throw new ParserException("while parsing a " + node + " node", startMark, "expected the node content, but found '" + token.getTokenId() + "'", token.getStartMark());
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 524 */     return event;
/*     */   }
/*     */   
/*     */   private class ParseBlockSequenceFirstEntry implements Production
/*     */   {
/*     */     private ParseBlockSequenceFirstEntry() {}
/*     */     
/*     */     public Event produce() {
/* 532 */       Token token = ParserImpl.this.scanner.getToken();
/* 533 */       ParserImpl.this.marks.push(token.getStartMark());
/* 534 */       return new ParserImpl.ParseBlockSequenceEntry(ParserImpl.this, null).produce();
/*     */     }
/*     */   }
/*     */   
/*     */   private class ParseBlockSequenceEntry implements Production { private ParseBlockSequenceEntry() {}
/*     */     
/* 540 */     public Event produce() { if (ParserImpl.this.scanner.checkToken(new Token.ID[] { Token.ID.Comment })) {
/* 541 */         return ParserImpl.this.produceCommentEvent((CommentToken)ParserImpl.this.scanner.getToken());
/*     */       }
/* 543 */       if (ParserImpl.this.scanner.checkToken(new Token.ID[] { Token.ID.BlockEntry })) {
/* 544 */         BlockEntryToken token = (BlockEntryToken)ParserImpl.this.scanner.getToken();
/* 545 */         if (!ParserImpl.this.scanner.checkToken(new Token.ID[] { Token.ID.BlockEntry, Token.ID.BlockEnd })) {
/* 546 */           ParserImpl.this.states.push(new ParseBlockSequenceEntry(ParserImpl.this));
/* 547 */           return new ParserImpl.ParseBlockNode(ParserImpl.this, null).produce();
/*     */         }
/* 549 */         ParserImpl.this.state = new ParseBlockSequenceEntry(ParserImpl.this);
/* 550 */         return ParserImpl.this.processEmptyScalar(token.getEndMark());
/*     */       }
/*     */       
/* 553 */       if (!ParserImpl.this.scanner.checkToken(new Token.ID[] { Token.ID.BlockEnd })) {
/* 554 */         Token token = ParserImpl.this.scanner.peekToken();
/* 555 */         throw new ParserException("while parsing a block collection", (Mark)ParserImpl.this.marks.pop(), "expected <block end>, but found '" + token.getTokenId() + "'", token.getStartMark());
/*     */       }
/*     */       
/*     */ 
/* 559 */       Token token = ParserImpl.this.scanner.getToken();
/* 560 */       Event event = new SequenceEndEvent(token.getStartMark(), token.getEndMark());
/* 561 */       ParserImpl.this.state = ((Production)ParserImpl.this.states.pop());
/* 562 */       ParserImpl.this.marks.pop();
/* 563 */       return event;
/*     */     }
/*     */   }
/*     */   
/*     */   private class ParseIndentlessSequenceEntry implements Production {
/*     */     private ParseIndentlessSequenceEntry() {}
/*     */     
/*     */     public Event produce() {
/* 571 */       if (ParserImpl.this.scanner.checkToken(new Token.ID[] { Token.ID.Comment })) {
/* 572 */         return ParserImpl.this.produceCommentEvent((CommentToken)ParserImpl.this.scanner.getToken());
/*     */       }
/* 574 */       if (ParserImpl.this.scanner.checkToken(new Token.ID[] { Token.ID.BlockEntry })) {
/* 575 */         Token token = ParserImpl.this.scanner.getToken();
/* 576 */         if (!ParserImpl.this.scanner.checkToken(new Token.ID[] { Token.ID.BlockEntry, Token.ID.Key, Token.ID.Value, Token.ID.BlockEnd }))
/*     */         {
/* 578 */           ParserImpl.this.states.push(new ParseIndentlessSequenceEntry(ParserImpl.this));
/* 579 */           return new ParserImpl.ParseBlockNode(ParserImpl.this, null).produce();
/*     */         }
/* 581 */         ParserImpl.this.state = new ParseIndentlessSequenceEntry(ParserImpl.this);
/* 582 */         return ParserImpl.this.processEmptyScalar(token.getEndMark());
/*     */       }
/*     */       
/* 585 */       Token token = ParserImpl.this.scanner.peekToken();
/* 586 */       Event event = new SequenceEndEvent(token.getStartMark(), token.getEndMark());
/* 587 */       ParserImpl.this.state = ((Production)ParserImpl.this.states.pop());
/* 588 */       return event;
/*     */     }
/*     */   }
/*     */   
/*     */   private class ParseBlockMappingFirstKey implements Production { private ParseBlockMappingFirstKey() {}
/*     */     
/* 594 */     public Event produce() { Token token = ParserImpl.this.scanner.getToken();
/* 595 */       ParserImpl.this.marks.push(token.getStartMark());
/* 596 */       return new ParserImpl.ParseBlockMappingKey(ParserImpl.this, null).produce();
/*     */     }
/*     */   }
/*     */   
/*     */   private class ParseBlockMappingKey implements Production { private ParseBlockMappingKey() {}
/*     */     
/* 602 */     public Event produce() { if (ParserImpl.this.scanner.checkToken(new Token.ID[] { Token.ID.Comment })) {
/* 603 */         return ParserImpl.this.produceCommentEvent((CommentToken)ParserImpl.this.scanner.getToken());
/*     */       }
/* 605 */       if (ParserImpl.this.scanner.checkToken(new Token.ID[] { Token.ID.Key })) {
/* 606 */         Token token = ParserImpl.this.scanner.getToken();
/* 607 */         if (!ParserImpl.this.scanner.checkToken(new Token.ID[] { Token.ID.Key, Token.ID.Value, Token.ID.BlockEnd })) {
/* 608 */           ParserImpl.this.states.push(new ParserImpl.ParseBlockMappingValue(ParserImpl.this, null));
/* 609 */           return ParserImpl.this.parseBlockNodeOrIndentlessSequence();
/*     */         }
/* 611 */         ParserImpl.this.state = new ParserImpl.ParseBlockMappingValue(ParserImpl.this, null);
/* 612 */         return ParserImpl.this.processEmptyScalar(token.getEndMark());
/*     */       }
/*     */       
/* 615 */       if (!ParserImpl.this.scanner.checkToken(new Token.ID[] { Token.ID.BlockEnd })) {
/* 616 */         Token token = ParserImpl.this.scanner.peekToken();
/* 617 */         throw new ParserException("while parsing a block mapping", (Mark)ParserImpl.this.marks.pop(), "expected <block end>, but found '" + token.getTokenId() + "'", token.getStartMark());
/*     */       }
/*     */       
/*     */ 
/* 621 */       Token token = ParserImpl.this.scanner.getToken();
/* 622 */       Event event = new MappingEndEvent(token.getStartMark(), token.getEndMark());
/* 623 */       ParserImpl.this.state = ((Production)ParserImpl.this.states.pop());
/* 624 */       ParserImpl.this.marks.pop();
/* 625 */       return event;
/*     */     }
/*     */   }
/*     */   
/*     */   private class ParseBlockMappingValue implements Production { private ParseBlockMappingValue() {}
/*     */     
/* 631 */     public Event produce() { if (ParserImpl.this.scanner.checkToken(new Token.ID[] { Token.ID.Value })) {
/* 632 */         Token token = ParserImpl.this.scanner.getToken();
/* 633 */         if (ParserImpl.this.scanner.checkToken(new Token.ID[] { Token.ID.Comment })) {
/* 634 */           ParserImpl.this.state = new ParserImpl.ParseBlockMappingValueComment(ParserImpl.this, null);
/* 635 */           return ParserImpl.this.state.produce(); }
/* 636 */         if (!ParserImpl.this.scanner.checkToken(new Token.ID[] { Token.ID.Key, Token.ID.Value, Token.ID.BlockEnd })) {
/* 637 */           ParserImpl.this.states.push(new ParserImpl.ParseBlockMappingKey(ParserImpl.this, null));
/* 638 */           return ParserImpl.this.parseBlockNodeOrIndentlessSequence();
/*     */         }
/* 640 */         ParserImpl.this.state = new ParserImpl.ParseBlockMappingKey(ParserImpl.this, null);
/* 641 */         return ParserImpl.this.processEmptyScalar(token.getEndMark());
/*     */       }
/* 643 */       if (ParserImpl.this.scanner.checkToken(new Token.ID[] { Token.ID.Scalar })) {
/* 644 */         ParserImpl.this.states.push(new ParserImpl.ParseBlockMappingKey(ParserImpl.this, null));
/* 645 */         return ParserImpl.this.parseBlockNodeOrIndentlessSequence();
/*     */       }
/* 647 */       ParserImpl.this.state = new ParserImpl.ParseBlockMappingKey(ParserImpl.this, null);
/* 648 */       Token token = ParserImpl.this.scanner.peekToken();
/* 649 */       return ParserImpl.this.processEmptyScalar(token.getStartMark());
/*     */     }
/*     */   }
/*     */   
/*     */   private class ParseBlockMappingValueComment implements Production { private ParseBlockMappingValueComment() {}
/*     */     
/* 655 */     public Event produce() { if (ParserImpl.this.scanner.checkToken(new Token.ID[] { Token.ID.Comment }))
/* 656 */         return ParserImpl.this.parseBlockNodeOrIndentlessSequence();
/* 657 */       if (!ParserImpl.this.scanner.checkToken(new Token.ID[] { Token.ID.Key, Token.ID.Value, Token.ID.BlockEnd })) {
/* 658 */         ParserImpl.this.states.push(new ParserImpl.ParseBlockMappingKey(ParserImpl.this, null));
/* 659 */         return ParserImpl.this.parseBlockNodeOrIndentlessSequence();
/*     */       }
/* 661 */       ParserImpl.this.state = new ParserImpl.ParseBlockMappingKey(ParserImpl.this, null);
/* 662 */       Token token = ParserImpl.this.scanner.getToken();
/* 663 */       return ParserImpl.this.processEmptyScalar(token.getEndMark());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private class ParseFlowSequenceFirstEntry
/*     */     implements Production
/*     */   {
/*     */     private ParseFlowSequenceFirstEntry() {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public Event produce()
/*     */     {
/* 683 */       Token token = ParserImpl.this.scanner.getToken();
/* 684 */       ParserImpl.this.marks.push(token.getStartMark());
/* 685 */       return new ParserImpl.ParseFlowSequenceEntry(ParserImpl.this, true).produce();
/*     */     }
/*     */   }
/*     */   
/*     */   private class ParseFlowSequenceEntry implements Production {
/* 690 */     private boolean first = false;
/*     */     
/*     */     public ParseFlowSequenceEntry(boolean first) {
/* 693 */       this.first = first;
/*     */     }
/*     */     
/*     */     public Event produce() {
/* 697 */       if (!ParserImpl.this.scanner.checkToken(new Token.ID[] { Token.ID.FlowSequenceEnd })) {
/* 698 */         if (!this.first) {
/* 699 */           if (ParserImpl.this.scanner.checkToken(new Token.ID[] { Token.ID.FlowEntry })) {
/* 700 */             ParserImpl.this.scanner.getToken();
/*     */           } else {
/* 702 */             Token token = ParserImpl.this.scanner.peekToken();
/* 703 */             throw new ParserException("while parsing a flow sequence", (Mark)ParserImpl.this.marks.pop(), "expected ',' or ']', but got " + token.getTokenId(), token.getStartMark());
/*     */           }
/*     */         }
/*     */         
/*     */ 
/* 708 */         if (ParserImpl.this.scanner.checkToken(new Token.ID[] { Token.ID.Key })) {
/* 709 */           Token token = ParserImpl.this.scanner.peekToken();
/* 710 */           Event event = new MappingStartEvent(null, null, true, token.getStartMark(), token.getEndMark(), DumperOptions.FlowStyle.FLOW);
/*     */           
/* 712 */           ParserImpl.this.state = new ParserImpl.ParseFlowSequenceEntryMappingKey(ParserImpl.this, null);
/* 713 */           return event; }
/* 714 */         if (!ParserImpl.this.scanner.checkToken(new Token.ID[] { Token.ID.FlowSequenceEnd })) {
/* 715 */           ParserImpl.this.states.push(new ParseFlowSequenceEntry(ParserImpl.this, false));
/* 716 */           return ParserImpl.this.parseFlowNode();
/*     */         }
/*     */       }
/* 719 */       Token token = ParserImpl.this.scanner.getToken();
/* 720 */       Event event = new SequenceEndEvent(token.getStartMark(), token.getEndMark());
/* 721 */       ParserImpl.this.marks.pop();
/* 722 */       if (!ParserImpl.this.scanner.checkToken(new Token.ID[] { Token.ID.Comment })) {
/* 723 */         ParserImpl.this.state = ((Production)ParserImpl.this.states.pop());
/*     */       } else {
/* 725 */         ParserImpl.this.state = new ParserImpl.ParseFlowEndComment(ParserImpl.this, null);
/*     */       }
/* 727 */       return event;
/*     */     }
/*     */   }
/*     */   
/*     */   private class ParseFlowEndComment implements Production { private ParseFlowEndComment() {}
/*     */     
/* 733 */     public Event produce() { Event event = ParserImpl.this.produceCommentEvent((CommentToken)ParserImpl.this.scanner.getToken());
/* 734 */       if (!ParserImpl.this.scanner.checkToken(new Token.ID[] { Token.ID.Comment })) {
/* 735 */         ParserImpl.this.state = ((Production)ParserImpl.this.states.pop());
/*     */       }
/* 737 */       return event;
/*     */     } }
/*     */   
/*     */   private class ParseFlowSequenceEntryMappingKey implements Production { private ParseFlowSequenceEntryMappingKey() {}
/*     */     
/* 742 */     public Event produce() { Token token = ParserImpl.this.scanner.getToken();
/* 743 */       if (!ParserImpl.this.scanner.checkToken(new Token.ID[] { Token.ID.Value, Token.ID.FlowEntry, Token.ID.FlowSequenceEnd })) {
/* 744 */         ParserImpl.this.states.push(new ParserImpl.ParseFlowSequenceEntryMappingValue(ParserImpl.this, null));
/* 745 */         return ParserImpl.this.parseFlowNode();
/*     */       }
/* 747 */       ParserImpl.this.state = new ParserImpl.ParseFlowSequenceEntryMappingValue(ParserImpl.this, null);
/* 748 */       return ParserImpl.this.processEmptyScalar(token.getEndMark());
/*     */     }
/*     */   }
/*     */   
/*     */   private class ParseFlowSequenceEntryMappingValue implements Production {
/*     */     private ParseFlowSequenceEntryMappingValue() {}
/*     */     
/* 755 */     public Event produce() { if (ParserImpl.this.scanner.checkToken(new Token.ID[] { Token.ID.Value })) {
/* 756 */         Token token = ParserImpl.this.scanner.getToken();
/* 757 */         if (!ParserImpl.this.scanner.checkToken(new Token.ID[] { Token.ID.FlowEntry, Token.ID.FlowSequenceEnd })) {
/* 758 */           ParserImpl.this.states.push(new ParserImpl.ParseFlowSequenceEntryMappingEnd(ParserImpl.this, null));
/* 759 */           return ParserImpl.this.parseFlowNode();
/*     */         }
/* 761 */         ParserImpl.this.state = new ParserImpl.ParseFlowSequenceEntryMappingEnd(ParserImpl.this, null);
/* 762 */         return ParserImpl.this.processEmptyScalar(token.getEndMark());
/*     */       }
/*     */       
/* 765 */       ParserImpl.this.state = new ParserImpl.ParseFlowSequenceEntryMappingEnd(ParserImpl.this, null);
/* 766 */       Token token = ParserImpl.this.scanner.peekToken();
/* 767 */       return ParserImpl.this.processEmptyScalar(token.getStartMark());
/*     */     }
/*     */   }
/*     */   
/*     */   private class ParseFlowSequenceEntryMappingEnd implements Production {
/*     */     private ParseFlowSequenceEntryMappingEnd() {}
/*     */     
/* 774 */     public Event produce() { ParserImpl.this.state = new ParserImpl.ParseFlowSequenceEntry(ParserImpl.this, false);
/* 775 */       Token token = ParserImpl.this.scanner.peekToken();
/* 776 */       return new MappingEndEvent(token.getStartMark(), token.getEndMark());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private class ParseFlowMappingFirstKey
/*     */     implements Production
/*     */   {
/*     */     private ParseFlowMappingFirstKey() {}
/*     */     
/*     */ 
/*     */ 
/*     */     public Event produce()
/*     */     {
/* 791 */       Token token = ParserImpl.this.scanner.getToken();
/* 792 */       ParserImpl.this.marks.push(token.getStartMark());
/* 793 */       return new ParserImpl.ParseFlowMappingKey(ParserImpl.this, true).produce();
/*     */     }
/*     */   }
/*     */   
/*     */   private class ParseFlowMappingKey implements Production {
/* 798 */     private boolean first = false;
/*     */     
/*     */     public ParseFlowMappingKey(boolean first) {
/* 801 */       this.first = first;
/*     */     }
/*     */     
/*     */     public Event produce() {
/* 805 */       if (!ParserImpl.this.scanner.checkToken(new Token.ID[] { Token.ID.FlowMappingEnd })) {
/* 806 */         if (!this.first) {
/* 807 */           if (ParserImpl.this.scanner.checkToken(new Token.ID[] { Token.ID.FlowEntry })) {
/* 808 */             ParserImpl.this.scanner.getToken();
/*     */           } else {
/* 810 */             Token token = ParserImpl.this.scanner.peekToken();
/* 811 */             throw new ParserException("while parsing a flow mapping", (Mark)ParserImpl.this.marks.pop(), "expected ',' or '}', but got " + token.getTokenId(), token.getStartMark());
/*     */           }
/*     */         }
/*     */         
/*     */ 
/* 816 */         if (ParserImpl.this.scanner.checkToken(new Token.ID[] { Token.ID.Key })) {
/* 817 */           Token token = ParserImpl.this.scanner.getToken();
/* 818 */           if (!ParserImpl.this.scanner.checkToken(new Token.ID[] { Token.ID.Value, Token.ID.FlowEntry, Token.ID.FlowMappingEnd }))
/*     */           {
/* 820 */             ParserImpl.this.states.push(new ParserImpl.ParseFlowMappingValue(ParserImpl.this, null));
/* 821 */             return ParserImpl.this.parseFlowNode();
/*     */           }
/* 823 */           ParserImpl.this.state = new ParserImpl.ParseFlowMappingValue(ParserImpl.this, null);
/* 824 */           return ParserImpl.this.processEmptyScalar(token.getEndMark());
/*     */         }
/* 826 */         if (!ParserImpl.this.scanner.checkToken(new Token.ID[] { Token.ID.FlowMappingEnd })) {
/* 827 */           ParserImpl.this.states.push(new ParserImpl.ParseFlowMappingEmptyValue(ParserImpl.this, null));
/* 828 */           return ParserImpl.this.parseFlowNode();
/*     */         }
/*     */       }
/* 831 */       Token token = ParserImpl.this.scanner.getToken();
/* 832 */       Event event = new MappingEndEvent(token.getStartMark(), token.getEndMark());
/* 833 */       ParserImpl.this.marks.pop();
/* 834 */       if (!ParserImpl.this.scanner.checkToken(new Token.ID[] { Token.ID.Comment })) {
/* 835 */         ParserImpl.this.state = ((Production)ParserImpl.this.states.pop());
/*     */       } else {
/* 837 */         ParserImpl.this.state = new ParserImpl.ParseFlowEndComment(ParserImpl.this, null);
/*     */       }
/* 839 */       return event;
/*     */     }
/*     */   }
/*     */   
/*     */   private class ParseFlowMappingValue implements Production { private ParseFlowMappingValue() {}
/*     */     
/* 845 */     public Event produce() { if (ParserImpl.this.scanner.checkToken(new Token.ID[] { Token.ID.Value })) {
/* 846 */         Token token = ParserImpl.this.scanner.getToken();
/* 847 */         if (!ParserImpl.this.scanner.checkToken(new Token.ID[] { Token.ID.FlowEntry, Token.ID.FlowMappingEnd })) {
/* 848 */           ParserImpl.this.states.push(new ParserImpl.ParseFlowMappingKey(ParserImpl.this, false));
/* 849 */           return ParserImpl.this.parseFlowNode();
/*     */         }
/* 851 */         ParserImpl.this.state = new ParserImpl.ParseFlowMappingKey(ParserImpl.this, false);
/* 852 */         return ParserImpl.this.processEmptyScalar(token.getEndMark());
/*     */       }
/*     */       
/* 855 */       ParserImpl.this.state = new ParserImpl.ParseFlowMappingKey(ParserImpl.this, false);
/* 856 */       Token token = ParserImpl.this.scanner.peekToken();
/* 857 */       return ParserImpl.this.processEmptyScalar(token.getStartMark());
/*     */     }
/*     */   }
/*     */   
/*     */   private class ParseFlowMappingEmptyValue implements Production {
/*     */     private ParseFlowMappingEmptyValue() {}
/*     */     
/* 864 */     public Event produce() { ParserImpl.this.state = new ParserImpl.ParseFlowMappingKey(ParserImpl.this, false);
/* 865 */       return ParserImpl.this.processEmptyScalar(ParserImpl.this.scanner.peekToken().getStartMark());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Event processEmptyScalar(Mark mark)
/*     */   {
/* 878 */     return new ScalarEvent(null, null, new ImplicitTuple(true, false), "", mark, mark, DumperOptions.ScalarStyle.PLAIN);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\snakeyaml-1.28.jar!\org\yaml\snakeyaml\parser\ParserImpl.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */