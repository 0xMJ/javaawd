/*    */ package org.yaml.snakeyaml.extensions.compactnotation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PackageCompactConstructor
/*    */   extends CompactConstructor
/*    */ {
/*    */   private String packageName;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public PackageCompactConstructor(String packageName)
/*    */   {
/* 22 */     this.packageName = packageName;
/*    */   }
/*    */   
/*    */   protected Class<?> getClassForName(String name) throws ClassNotFoundException
/*    */   {
/* 27 */     if (name.indexOf('.') < 0) {
/*    */       try {
/* 29 */         return Class.forName(this.packageName + "." + name);
/*    */       }
/*    */       catch (ClassNotFoundException e) {}
/*    */     }
/*    */     
/*    */ 
/* 35 */     return super.getClassForName(name);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\snakeyaml-1.28.jar!\org\yaml\snakeyaml\extensions\compactnotation\PackageCompactConstructor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */