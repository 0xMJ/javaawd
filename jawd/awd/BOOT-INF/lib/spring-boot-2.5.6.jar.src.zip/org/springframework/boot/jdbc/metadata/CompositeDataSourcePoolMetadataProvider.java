/*    */ package org.springframework.boot.jdbc.metadata;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import javax.sql.DataSource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompositeDataSourcePoolMetadataProvider
/*    */   implements DataSourcePoolMetadataProvider
/*    */ {
/*    */   private final List<DataSourcePoolMetadataProvider> providers;
/*    */   
/*    */   public CompositeDataSourcePoolMetadataProvider(Collection<? extends DataSourcePoolMetadataProvider> providers)
/*    */   {
/* 44 */     this.providers = (providers != null ? Collections.unmodifiableList(new ArrayList(providers)) : Collections.emptyList());
/*    */   }
/*    */   
/*    */   public DataSourcePoolMetadata getDataSourcePoolMetadata(DataSource dataSource)
/*    */   {
/* 49 */     for (DataSourcePoolMetadataProvider provider : this.providers) {
/* 50 */       DataSourcePoolMetadata metadata = provider.getDataSourcePoolMetadata(dataSource);
/* 51 */       if (metadata != null) {
/* 52 */         return metadata;
/*    */       }
/*    */     }
/* 55 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\jdbc\metadata\CompositeDataSourcePoolMetadataProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */