/*    */ package org.springframework.boot.logging.logback;
/*    */ 
/*    */ import ch.qos.logback.classic.Level;
/*    */ import ch.qos.logback.classic.LoggerContext;
/*    */ import ch.qos.logback.classic.spi.ILoggingEvent;
/*    */ import ch.qos.logback.core.Appender;
/*    */ import ch.qos.logback.core.pattern.Converter;
/*    */ import ch.qos.logback.core.spi.LifeCycle;
/*    */ import ch.qos.logback.core.status.InfoStatus;
/*    */ import ch.qos.logback.core.status.StatusManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class DebugLogbackConfigurator
/*    */   extends LogbackConfigurator
/*    */ {
/*    */   DebugLogbackConfigurator(LoggerContext context)
/*    */   {
/* 37 */     super(context);
/*    */   }
/*    */   
/*    */ 
/*    */   public void conversionRule(String conversionWord, Class<? extends Converter> converterClass)
/*    */   {
/* 43 */     info("Adding conversion rule of type '" + converterClass.getName() + "' for word '" + conversionWord + "'");
/* 44 */     super.conversionRule(conversionWord, converterClass);
/*    */   }
/*    */   
/*    */   public void appender(String name, Appender<?> appender)
/*    */   {
/* 49 */     info("Adding appender '" + appender + "' named '" + name + "'");
/* 50 */     super.appender(name, appender);
/*    */   }
/*    */   
/*    */   public void logger(String name, Level level, boolean additive, Appender<ILoggingEvent> appender)
/*    */   {
/* 55 */     info("Configuring logger '" + name + "' with level '" + level + "'. Additive: " + additive);
/* 56 */     if (appender != null) {
/* 57 */       info("Adding appender '" + appender + "' to logger '" + name + "'");
/*    */     }
/* 59 */     super.logger(name, level, additive, appender);
/*    */   }
/*    */   
/*    */   public void start(LifeCycle lifeCycle)
/*    */   {
/* 64 */     info("Starting '" + lifeCycle + "'");
/* 65 */     super.start(lifeCycle);
/*    */   }
/*    */   
/*    */   private void info(String message) {
/* 69 */     getContext().getStatusManager().add(new InfoStatus(message, this));
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\logging\logback\DebugLogbackConfigurator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */