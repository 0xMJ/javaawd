/*    */ package org.springframework.boot.env;
/*    */ 
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.springframework.boot.SpringApplication;
/*    */ import org.springframework.core.Ordered;
/*    */ import org.springframework.core.env.ConfigurableEnvironment;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RandomValuePropertySourceEnvironmentPostProcessor
/*    */   implements EnvironmentPostProcessor, Ordered
/*    */ {
/*    */   public static final int ORDER = -2147483647;
/*    */   private final Log logger;
/*    */   
/*    */   public RandomValuePropertySourceEnvironmentPostProcessor(Log logger)
/*    */   {
/* 45 */     this.logger = logger;
/*    */   }
/*    */   
/*    */   public int getOrder()
/*    */   {
/* 50 */     return -2147483647;
/*    */   }
/*    */   
/*    */   public void postProcessEnvironment(ConfigurableEnvironment environment, SpringApplication application)
/*    */   {
/* 55 */     RandomValuePropertySource.addToEnvironment(environment, this.logger);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\env\RandomValuePropertySourceEnvironmentPostProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */