/*     */ package org.springframework.boot.builder;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import org.springframework.beans.factory.support.BeanNameGenerator;
/*     */ import org.springframework.boot.ApplicationContextFactory;
/*     */ import org.springframework.boot.Banner;
/*     */ import org.springframework.boot.Banner.Mode;
/*     */ import org.springframework.boot.BootstrapRegistryInitializer;
/*     */ import org.springframework.boot.Bootstrapper;
/*     */ import org.springframework.boot.SpringApplication;
/*     */ import org.springframework.boot.WebApplicationType;
/*     */ import org.springframework.context.ApplicationContextInitializer;
/*     */ import org.springframework.context.ApplicationListener;
/*     */ import org.springframework.context.ConfigurableApplicationContext;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.metrics.ApplicationStartup;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpringApplicationBuilder
/*     */ {
/*     */   private final SpringApplication application;
/*     */   private ConfigurableApplicationContext context;
/*     */   private SpringApplicationBuilder parent;
/*  82 */   private final AtomicBoolean running = new AtomicBoolean();
/*     */   
/*  84 */   private final Set<Class<?>> sources = new LinkedHashSet();
/*     */   
/*  86 */   private final Map<String, Object> defaultProperties = new LinkedHashMap();
/*     */   
/*     */   private ConfigurableEnvironment environment;
/*     */   
/*  90 */   private Set<String> additionalProfiles = new LinkedHashSet();
/*     */   
/*     */   private boolean registerShutdownHookApplied;
/*     */   
/*  94 */   private boolean configuredAsChild = false;
/*     */   
/*     */   public SpringApplicationBuilder(Class<?>... sources) {
/*  97 */     this.application = createSpringApplication(sources);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected SpringApplication createSpringApplication(Class<?>... sources)
/*     */   {
/* 108 */     return new SpringApplication(sources);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ConfigurableApplicationContext context()
/*     */   {
/* 116 */     return this.context;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public SpringApplication application()
/*     */   {
/* 124 */     return this.application;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ConfigurableApplicationContext run(String... args)
/*     */   {
/* 135 */     if (this.running.get())
/*     */     {
/* 137 */       return this.context;
/*     */     }
/* 139 */     configureAsChildIfNecessary(args);
/* 140 */     if (this.running.compareAndSet(false, true)) {
/* 141 */       synchronized (this.running)
/*     */       {
/* 143 */         this.context = build().run(args);
/*     */       }
/*     */     }
/* 146 */     return this.context;
/*     */   }
/*     */   
/*     */   private void configureAsChildIfNecessary(String... args) {
/* 150 */     if ((this.parent != null) && (!this.configuredAsChild)) {
/* 151 */       this.configuredAsChild = true;
/* 152 */       if (!this.registerShutdownHookApplied) {
/* 153 */         this.application.setRegisterShutdownHook(false);
/*     */       }
/* 155 */       initializers(new ApplicationContextInitializer[] { new ParentContextApplicationContextInitializer(this.parent.run(args)) });
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public SpringApplication build()
/*     */   {
/* 164 */     return build(new String[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SpringApplication build(String... args)
/*     */   {
/* 174 */     configureAsChildIfNecessary(args);
/* 175 */     this.application.addPrimarySources(this.sources);
/* 176 */     return this.application;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SpringApplicationBuilder child(Class<?>... sources)
/*     */   {
/* 186 */     SpringApplicationBuilder child = new SpringApplicationBuilder(new Class[0]);
/* 187 */     child.sources(sources);
/*     */     
/*     */ 
/* 190 */     child.properties(this.defaultProperties).environment(this.environment)
/* 191 */       .additionalProfiles(this.additionalProfiles);
/* 192 */     child.parent = this;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 197 */     web(WebApplicationType.NONE);
/*     */     
/*     */ 
/* 200 */     bannerMode(Banner.Mode.OFF);
/*     */     
/*     */ 
/* 203 */     this.application.addPrimarySources(this.sources);
/*     */     
/* 205 */     return child;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SpringApplicationBuilder parent(Class<?>... sources)
/*     */   {
/* 215 */     if (this.parent == null)
/*     */     {
/* 217 */       this.parent = new SpringApplicationBuilder(sources).web(WebApplicationType.NONE).properties(this.defaultProperties).environment(this.environment);
/*     */     }
/*     */     else {
/* 220 */       this.parent.sources(sources);
/*     */     }
/* 222 */     return this.parent;
/*     */   }
/*     */   
/*     */   private SpringApplicationBuilder runAndExtractParent(String... args) {
/* 226 */     if (this.context == null) {
/* 227 */       run(args);
/*     */     }
/* 229 */     if (this.parent != null) {
/* 230 */       return this.parent;
/*     */     }
/* 232 */     throw new IllegalStateException("No parent defined yet (please use the other overloaded parent methods to set one)");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SpringApplicationBuilder parent(ConfigurableApplicationContext parent)
/*     */   {
/* 242 */     this.parent = new SpringApplicationBuilder(new Class[0]);
/* 243 */     this.parent.context = parent;
/* 244 */     this.parent.running.set(true);
/* 245 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SpringApplicationBuilder sibling(Class<?>... sources)
/*     */   {
/* 258 */     return runAndExtractParent(new String[0]).child(sources);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SpringApplicationBuilder sibling(Class<?>[] sources, String... args)
/*     */   {
/* 271 */     return runAndExtractParent(args).child(sources);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public SpringApplicationBuilder contextClass(Class<? extends ConfigurableApplicationContext> cls)
/*     */   {
/* 283 */     this.application.setApplicationContextClass(cls);
/* 284 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SpringApplicationBuilder contextFactory(ApplicationContextFactory factory)
/*     */   {
/* 294 */     this.application.setApplicationContextFactory(factory);
/* 295 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SpringApplicationBuilder sources(Class<?>... sources)
/*     */   {
/* 304 */     this.sources.addAll(new LinkedHashSet(Arrays.asList(sources)));
/* 305 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SpringApplicationBuilder web(WebApplicationType webApplicationType)
/*     */   {
/* 316 */     this.application.setWebApplicationType(webApplicationType);
/* 317 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SpringApplicationBuilder logStartupInfo(boolean logStartupInfo)
/*     */   {
/* 326 */     this.application.setLogStartupInfo(logStartupInfo);
/* 327 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SpringApplicationBuilder banner(Banner banner)
/*     */   {
/* 337 */     this.application.setBanner(banner);
/* 338 */     return this;
/*     */   }
/*     */   
/*     */   public SpringApplicationBuilder bannerMode(Banner.Mode bannerMode) {
/* 342 */     this.application.setBannerMode(bannerMode);
/* 343 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SpringApplicationBuilder headless(boolean headless)
/*     */   {
/* 353 */     this.application.setHeadless(headless);
/* 354 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SpringApplicationBuilder registerShutdownHook(boolean registerShutdownHook)
/*     */   {
/* 364 */     this.registerShutdownHookApplied = true;
/* 365 */     this.application.setRegisterShutdownHook(registerShutdownHook);
/* 366 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SpringApplicationBuilder main(Class<?> mainApplicationClass)
/*     */   {
/* 375 */     this.application.setMainApplicationClass(mainApplicationClass);
/* 376 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SpringApplicationBuilder addCommandLineProperties(boolean addCommandLineProperties)
/*     */   {
/* 385 */     this.application.setAddCommandLineProperties(addCommandLineProperties);
/* 386 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SpringApplicationBuilder setAddConversionService(boolean addConversionService)
/*     */   {
/* 397 */     this.application.setAddConversionService(addConversionService);
/* 398 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public SpringApplicationBuilder addBootstrapper(Bootstrapper bootstrapper)
/*     */   {
/* 412 */     this.application.addBootstrapper(bootstrapper);
/* 413 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SpringApplicationBuilder addBootstrapRegistryInitializer(BootstrapRegistryInitializer bootstrapRegistryInitializer)
/*     */   {
/* 425 */     this.application.addBootstrapRegistryInitializer(bootstrapRegistryInitializer);
/* 426 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SpringApplicationBuilder lazyInitialization(boolean lazyInitialization)
/*     */   {
/* 436 */     this.application.setLazyInitialization(lazyInitialization);
/* 437 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SpringApplicationBuilder properties(String... defaultProperties)
/*     */   {
/* 450 */     return properties(getMapFromKeyValuePairs(defaultProperties));
/*     */   }
/*     */   
/*     */   private Map<String, Object> getMapFromKeyValuePairs(String[] properties) {
/* 454 */     Map<String, Object> map = new HashMap();
/* 455 */     for (String property : properties) {
/* 456 */       int index = lowestIndexOf(property, new String[] { ":", "=" });
/* 457 */       String key = index > 0 ? property.substring(0, index) : property;
/* 458 */       String value = index > 0 ? property.substring(index + 1) : "";
/* 459 */       map.put(key, value);
/*     */     }
/* 461 */     return map;
/*     */   }
/*     */   
/*     */   private int lowestIndexOf(String property, String... candidates) {
/* 465 */     int index = -1;
/* 466 */     for (String candidate : candidates) {
/* 467 */       int candidateIndex = property.indexOf(candidate);
/* 468 */       if (candidateIndex > 0) {
/* 469 */         index = index != -1 ? Math.min(index, candidateIndex) : candidateIndex;
/*     */       }
/*     */     }
/* 472 */     return index;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SpringApplicationBuilder properties(Properties defaultProperties)
/*     */   {
/* 484 */     return properties(getMapFromProperties(defaultProperties));
/*     */   }
/*     */   
/*     */   private Map<String, Object> getMapFromProperties(Properties properties) {
/* 488 */     Map<String, Object> map = new HashMap();
/* 489 */     for (Object key : Collections.list(properties.propertyNames())) {
/* 490 */       map.put((String)key, properties.get(key));
/*     */     }
/* 492 */     return map;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SpringApplicationBuilder properties(Map<String, Object> defaults)
/*     */   {
/* 504 */     this.defaultProperties.putAll(defaults);
/* 505 */     this.application.setDefaultProperties(this.defaultProperties);
/* 506 */     if (this.parent != null) {
/* 507 */       this.parent.properties(this.defaultProperties);
/* 508 */       this.parent.environment(this.environment);
/*     */     }
/* 510 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SpringApplicationBuilder profiles(String... profiles)
/*     */   {
/* 519 */     this.additionalProfiles.addAll(Arrays.asList(profiles));
/* 520 */     this.application.setAdditionalProfiles(StringUtils.toStringArray(this.additionalProfiles));
/* 521 */     return this;
/*     */   }
/*     */   
/*     */   private SpringApplicationBuilder additionalProfiles(Collection<String> additionalProfiles) {
/* 525 */     this.additionalProfiles = new LinkedHashSet(additionalProfiles);
/* 526 */     this.application.setAdditionalProfiles(StringUtils.toStringArray(this.additionalProfiles));
/* 527 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SpringApplicationBuilder beanNameGenerator(BeanNameGenerator beanNameGenerator)
/*     */   {
/* 537 */     this.application.setBeanNameGenerator(beanNameGenerator);
/* 538 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SpringApplicationBuilder environment(ConfigurableEnvironment environment)
/*     */   {
/* 547 */     this.application.setEnvironment(environment);
/* 548 */     this.environment = environment;
/* 549 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SpringApplicationBuilder environmentPrefix(String environmentPrefix)
/*     */   {
/* 560 */     this.application.setEnvironmentPrefix(environmentPrefix);
/* 561 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SpringApplicationBuilder resourceLoader(ResourceLoader resourceLoader)
/*     */   {
/* 571 */     this.application.setResourceLoader(resourceLoader);
/* 572 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SpringApplicationBuilder initializers(ApplicationContextInitializer<?>... initializers)
/*     */   {
/* 582 */     this.application.addInitializers(initializers);
/* 583 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SpringApplicationBuilder listeners(ApplicationListener<?>... listeners)
/*     */   {
/* 595 */     this.application.addListeners(listeners);
/* 596 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SpringApplicationBuilder applicationStartup(ApplicationStartup applicationStartup)
/*     */   {
/* 607 */     this.application.setApplicationStartup(applicationStartup);
/* 608 */     return this;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\builder\SpringApplicationBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */