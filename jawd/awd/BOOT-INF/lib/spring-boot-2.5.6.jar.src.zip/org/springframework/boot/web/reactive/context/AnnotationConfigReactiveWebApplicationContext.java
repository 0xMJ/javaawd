/*    */ package org.springframework.boot.web.reactive.context;
/*    */ 
/*    */ import org.springframework.beans.factory.support.DefaultListableBeanFactory;
/*    */ import org.springframework.context.annotation.AnnotationConfigApplicationContext;
/*    */ import org.springframework.core.env.ConfigurableEnvironment;
/*    */ import org.springframework.core.io.Resource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AnnotationConfigReactiveWebApplicationContext
/*    */   extends AnnotationConfigApplicationContext
/*    */   implements ConfigurableReactiveWebApplicationContext
/*    */ {
/*    */   public AnnotationConfigReactiveWebApplicationContext() {}
/*    */   
/*    */   public AnnotationConfigReactiveWebApplicationContext(DefaultListableBeanFactory beanFactory)
/*    */   {
/* 61 */     super(beanFactory);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public AnnotationConfigReactiveWebApplicationContext(Class<?>... annotatedClasses)
/*    */   {
/* 72 */     super(annotatedClasses);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public AnnotationConfigReactiveWebApplicationContext(String... basePackages)
/*    */   {
/* 82 */     super(basePackages);
/*    */   }
/*    */   
/*    */   protected ConfigurableEnvironment createEnvironment()
/*    */   {
/* 87 */     return new StandardReactiveWebEnvironment();
/*    */   }
/*    */   
/*    */ 
/*    */   protected Resource getResourceByPath(String path)
/*    */   {
/* 93 */     return new FilteredReactiveWebContextResource(path);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\web\reactive\context\AnnotationConfigReactiveWebApplicationContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */