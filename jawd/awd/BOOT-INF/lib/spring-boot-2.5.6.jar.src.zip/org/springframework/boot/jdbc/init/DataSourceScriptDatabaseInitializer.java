/*    */ package org.springframework.boot.jdbc.init;
/*    */ 
/*    */ import java.nio.charset.Charset;
/*    */ import java.util.List;
/*    */ import javax.sql.DataSource;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.boot.jdbc.EmbeddedDatabaseConnection;
/*    */ import org.springframework.boot.sql.init.AbstractScriptDatabaseInitializer;
/*    */ import org.springframework.boot.sql.init.DatabaseInitializationSettings;
/*    */ import org.springframework.core.io.Resource;
/*    */ import org.springframework.jdbc.datasource.init.DatabasePopulatorUtils;
/*    */ import org.springframework.jdbc.datasource.init.ResourceDatabasePopulator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DataSourceScriptDatabaseInitializer
/*    */   extends AbstractScriptDatabaseInitializer
/*    */ {
/* 44 */   private static final Log logger = LogFactory.getLog(DataSourceScriptDatabaseInitializer.class);
/*    */   
/*    */ 
/*    */ 
/*    */   private final DataSource dataSource;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public DataSourceScriptDatabaseInitializer(DataSource dataSource, DatabaseInitializationSettings settings)
/*    */   {
/* 55 */     super(settings);
/* 56 */     this.dataSource = dataSource;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   protected final DataSource getDataSource()
/*    */   {
/* 64 */     return this.dataSource;
/*    */   }
/*    */   
/*    */   protected boolean isEmbeddedDatabase()
/*    */   {
/*    */     try {
/* 70 */       return EmbeddedDatabaseConnection.isEmbedded(this.dataSource);
/*    */     }
/*    */     catch (Exception ex) {
/* 73 */       logger.debug("Could not determine if datasource is embedded", ex); }
/* 74 */     return false;
/*    */   }
/*    */   
/*    */ 
/*    */   protected void runScripts(List<Resource> resources, boolean continueOnError, String separator, Charset encoding)
/*    */   {
/* 80 */     ResourceDatabasePopulator populator = new ResourceDatabasePopulator();
/* 81 */     populator.setContinueOnError(continueOnError);
/* 82 */     populator.setSeparator(separator);
/* 83 */     if (encoding != null) {
/* 84 */       populator.setSqlScriptEncoding(encoding.name());
/*    */     }
/* 86 */     for (Resource resource : resources) {
/* 87 */       populator.addScript(resource);
/*    */     }
/* 89 */     DatabasePopulatorUtils.execute(populator, this.dataSource);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\jdbc\init\DataSourceScriptDatabaseInitializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */