/*     */ package org.springframework.boot.context.properties.bind;
/*     */ 
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationPropertyName;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationPropertySource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class AggregateBinder<T>
/*     */ {
/*     */   private final Binder.Context context;
/*     */   
/*     */   AggregateBinder(Binder.Context context)
/*     */   {
/*  37 */     this.context = context;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract boolean isAllowRecursiveBinding(ConfigurationPropertySource paramConfigurationPropertySource);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   final Object bind(ConfigurationPropertyName name, Bindable<?> target, AggregateElementBinder elementBinder)
/*     */   {
/*  56 */     Object result = bindAggregate(name, target, elementBinder);
/*  57 */     Supplier<?> value = target.getValue();
/*  58 */     if ((result == null) || (value == null)) {
/*  59 */       return result;
/*     */     }
/*  61 */     return merge(value, result);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract Object bindAggregate(ConfigurationPropertyName paramConfigurationPropertyName, Bindable<?> paramBindable, AggregateElementBinder paramAggregateElementBinder);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract T merge(Supplier<T> paramSupplier, T paramT);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final Binder.Context getContext()
/*     */   {
/*  87 */     return this.context;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected static class AggregateSupplier<T>
/*     */   {
/*     */     private final Supplier<T> supplier;
/*     */     
/*     */ 
/*     */     private T supplied;
/*     */     
/*     */ 
/*     */     public AggregateSupplier(Supplier<T> supplier)
/*     */     {
/* 102 */       this.supplier = supplier;
/*     */     }
/*     */     
/*     */     public T get() {
/* 106 */       if (this.supplied == null) {
/* 107 */         this.supplied = this.supplier.get();
/*     */       }
/* 109 */       return (T)this.supplied;
/*     */     }
/*     */     
/*     */     public boolean wasSupplied() {
/* 113 */       return this.supplied != null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\context\properties\bind\AggregateBinder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */