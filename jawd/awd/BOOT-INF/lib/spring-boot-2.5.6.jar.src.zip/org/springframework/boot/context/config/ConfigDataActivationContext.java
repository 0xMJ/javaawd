/*    */ package org.springframework.boot.context.config;
/*    */ 
/*    */ import org.springframework.boot.cloud.CloudPlatform;
/*    */ import org.springframework.boot.context.properties.bind.Binder;
/*    */ import org.springframework.core.env.Environment;
/*    */ import org.springframework.core.style.ToStringCreator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ConfigDataActivationContext
/*    */ {
/*    */   private final CloudPlatform cloudPlatform;
/*    */   private final Profiles profiles;
/*    */   
/*    */   ConfigDataActivationContext(Environment environment, Binder binder)
/*    */   {
/* 43 */     this.cloudPlatform = deduceCloudPlatform(environment, binder);
/* 44 */     this.profiles = null;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   ConfigDataActivationContext(CloudPlatform cloudPlatform, Profiles profiles)
/*    */   {
/* 54 */     this.cloudPlatform = cloudPlatform;
/* 55 */     this.profiles = profiles;
/*    */   }
/*    */   
/*    */   private CloudPlatform deduceCloudPlatform(Environment environment, Binder binder) {
/* 59 */     for (CloudPlatform candidate : ) {
/* 60 */       if (candidate.isEnforced(binder)) {
/* 61 */         return candidate;
/*    */       }
/*    */     }
/* 64 */     return CloudPlatform.getActive(environment);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   ConfigDataActivationContext withProfiles(Profiles profiles)
/*    */   {
/* 73 */     return new ConfigDataActivationContext(this.cloudPlatform, profiles);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   CloudPlatform getCloudPlatform()
/*    */   {
/* 81 */     return this.cloudPlatform;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   Profiles getProfiles()
/*    */   {
/* 89 */     return this.profiles;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 94 */     ToStringCreator creator = new ToStringCreator(this);
/* 95 */     creator.append("cloudPlatform", this.cloudPlatform);
/* 96 */     creator.append("profiles", this.profiles);
/* 97 */     return creator.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\context\config\ConfigDataActivationContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */