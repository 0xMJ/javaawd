/*     */ package org.springframework.boot.logging;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.Properties;
/*     */ import org.springframework.core.env.PropertyResolver;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LogFile
/*     */ {
/*     */   public static final String FILE_NAME_PROPERTY = "logging.file.name";
/*     */   public static final String FILE_PATH_PROPERTY = "logging.file.path";
/*     */   private final String file;
/*     */   private final String path;
/*     */   
/*     */   LogFile(String file)
/*     */   {
/*  63 */     this(file, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   LogFile(String file, String path)
/*     */   {
/*  72 */     Assert.isTrue((StringUtils.hasLength(file)) || (StringUtils.hasLength(path)), "File or Path must not be empty");
/*  73 */     this.file = file;
/*  74 */     this.path = path;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void applyToSystemProperties()
/*     */   {
/*  81 */     applyTo(System.getProperties());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void applyTo(Properties properties)
/*     */   {
/*  89 */     put(properties, "LOG_PATH", this.path);
/*  90 */     put(properties, "LOG_FILE", toString());
/*     */   }
/*     */   
/*     */   private void put(Properties properties, String key, String value) {
/*  94 */     if (StringUtils.hasLength(value)) {
/*  95 */       properties.put(key, value);
/*     */     }
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 101 */     if (StringUtils.hasLength(this.file)) {
/* 102 */       return this.file;
/*     */     }
/* 104 */     return new File(this.path, "spring.log").getPath();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static LogFile get(PropertyResolver propertyResolver)
/*     */   {
/* 115 */     String file = propertyResolver.getProperty("logging.file.name");
/* 116 */     String path = propertyResolver.getProperty("logging.file.path");
/* 117 */     if ((StringUtils.hasLength(file)) || (StringUtils.hasLength(path))) {
/* 118 */       return new LogFile(file, path);
/*     */     }
/* 120 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\logging\LogFile.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */