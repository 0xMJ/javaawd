/*    */ package org.springframework.boot.context.config;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UnsupportedConfigDataLocationException
/*    */   extends ConfigDataException
/*    */ {
/*    */   private final ConfigDataLocation location;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   UnsupportedConfigDataLocationException(ConfigDataLocation location)
/*    */   {
/* 35 */     super("Unsupported config data location '" + location + "'", null);
/* 36 */     this.location = location;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public ConfigDataLocation getLocation()
/*    */   {
/* 44 */     return this.location;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\context\config\UnsupportedConfigDataLocationException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */