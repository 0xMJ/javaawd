/*     */ package org.springframework.boot.context.config;
/*     */ 
/*     */ import org.springframework.boot.context.properties.source.ConfigurationProperty;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationPropertyName;
/*     */ import org.springframework.boot.context.properties.source.ConfigurationPropertySource;
/*     */ import org.springframework.boot.origin.Origin;
/*     */ import org.springframework.core.env.PropertySource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InactiveConfigDataAccessException
/*     */   extends ConfigDataException
/*     */ {
/*     */   private final PropertySource<?> propertySource;
/*     */   private final ConfigDataResource location;
/*     */   private final String propertyName;
/*     */   private final Origin origin;
/*     */   
/*     */   InactiveConfigDataAccessException(PropertySource<?> propertySource, ConfigDataResource location, String propertyName, Origin origin)
/*     */   {
/*  54 */     super(getMessage(propertySource, location, propertyName, origin), null);
/*  55 */     this.propertySource = propertySource;
/*  56 */     this.location = location;
/*  57 */     this.propertyName = propertyName;
/*  58 */     this.origin = origin;
/*     */   }
/*     */   
/*     */   private static String getMessage(PropertySource<?> propertySource, ConfigDataResource location, String propertyName, Origin origin)
/*     */   {
/*  63 */     StringBuilder message = new StringBuilder("Inactive property source '");
/*  64 */     message.append(propertySource.getName());
/*  65 */     if (location != null) {
/*  66 */       message.append("' imported from location '");
/*  67 */       message.append(location);
/*     */     }
/*  69 */     message.append("' cannot contain property '");
/*  70 */     message.append(propertyName);
/*  71 */     message.append("'");
/*  72 */     if (origin != null) {
/*  73 */       message.append(" [origin: ");
/*  74 */       message.append(origin);
/*  75 */       message.append("]");
/*     */     }
/*  77 */     return message.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public PropertySource<?> getPropertySource()
/*     */   {
/*  85 */     return this.propertySource;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ConfigDataResource getLocation()
/*     */   {
/*  94 */     return this.location;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getPropertyName()
/*     */   {
/* 102 */     return this.propertyName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Origin getOrigin()
/*     */   {
/* 110 */     return this.origin;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static void throwIfPropertyFound(ConfigDataEnvironmentContributor contributor, ConfigurationPropertyName name)
/*     */   {
/* 120 */     ConfigurationPropertySource source = contributor.getConfigurationPropertySource();
/* 121 */     ConfigurationProperty property = source != null ? source.getConfigurationProperty(name) : null;
/* 122 */     if (property != null) {
/* 123 */       PropertySource<?> propertySource = contributor.getPropertySource();
/* 124 */       ConfigDataResource location = contributor.getResource();
/*     */       
/* 126 */       throw new InactiveConfigDataAccessException(propertySource, location, name.toString(), property.getOrigin());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\context\config\InactiveConfigDataAccessException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */