package org.springframework.boot.context.properties.bind;

import org.springframework.boot.context.properties.source.ConfigurationPropertyName;

abstract interface DataObjectBinder
{
  public abstract <T> T bind(ConfigurationPropertyName paramConfigurationPropertyName, Bindable<T> paramBindable, Binder.Context paramContext, DataObjectPropertyBinder paramDataObjectPropertyBinder);
  
  public abstract <T> T create(Bindable<T> paramBindable, Binder.Context paramContext);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\context\properties\bind\DataObjectBinder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */