/*    */ package org.springframework.boot.context.properties.bind.validation;
/*    */ 
/*    */ import org.springframework.boot.origin.Origin;
/*    */ import org.springframework.boot.origin.OriginProvider;
/*    */ import org.springframework.validation.FieldError;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class OriginTrackedFieldError
/*    */   extends FieldError
/*    */   implements OriginProvider
/*    */ {
/*    */   private final Origin origin;
/*    */   
/*    */   private OriginTrackedFieldError(FieldError fieldError, Origin origin)
/*    */   {
/* 34 */     super(fieldError.getObjectName(), fieldError.getField(), fieldError.getRejectedValue(), fieldError
/* 35 */       .isBindingFailure(), fieldError.getCodes(), fieldError.getArguments(), fieldError
/* 36 */       .getDefaultMessage());
/* 37 */     this.origin = origin;
/*    */   }
/*    */   
/*    */   public Origin getOrigin()
/*    */   {
/* 42 */     return this.origin;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 47 */     if (this.origin == null) {
/* 48 */       return super.toString();
/*    */     }
/* 50 */     return super.toString() + "; origin " + this.origin;
/*    */   }
/*    */   
/*    */   static FieldError of(FieldError fieldError, Origin origin) {
/* 54 */     if ((fieldError == null) || (origin == null)) {
/* 55 */       return fieldError;
/*    */     }
/* 57 */     return new OriginTrackedFieldError(fieldError, origin);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\context\properties\bind\validation\OriginTrackedFieldError.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */