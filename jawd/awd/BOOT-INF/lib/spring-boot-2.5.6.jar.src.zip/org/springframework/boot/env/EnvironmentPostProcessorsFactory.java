/*    */ package org.springframework.boot.env;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.springframework.boot.ConfigurableBootstrapContext;
/*    */ import org.springframework.boot.logging.DeferredLogFactory;
/*    */ import org.springframework.core.io.support.SpringFactoriesLoader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @FunctionalInterface
/*    */ public abstract interface EnvironmentPostProcessorsFactory
/*    */ {
/*    */   public abstract List<EnvironmentPostProcessor> getEnvironmentPostProcessors(DeferredLogFactory paramDeferredLogFactory, ConfigurableBootstrapContext paramConfigurableBootstrapContext);
/*    */   
/*    */   public static EnvironmentPostProcessorsFactory fromSpringFactories(ClassLoader classLoader)
/*    */   {
/* 51 */     return new ReflectionEnvironmentPostProcessorsFactory(classLoader, 
/* 52 */       SpringFactoriesLoader.loadFactoryNames(EnvironmentPostProcessor.class, classLoader));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static EnvironmentPostProcessorsFactory of(Class<?>... classes)
/*    */   {
/* 62 */     return new ReflectionEnvironmentPostProcessorsFactory(classes);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static EnvironmentPostProcessorsFactory of(String... classNames)
/*    */   {
/* 72 */     return of(null, classNames);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static EnvironmentPostProcessorsFactory of(ClassLoader classLoader, String... classNames)
/*    */   {
/* 84 */     return new ReflectionEnvironmentPostProcessorsFactory(classLoader, classNames);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\env\EnvironmentPostProcessorsFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */