/*    */ package org.springframework.boot.context.properties.bind;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import java.lang.reflect.Modifier;
/*    */ import org.springframework.beans.BeanUtils;
/*    */ import org.springframework.core.KotlinDetector;
/*    */ import org.springframework.core.ResolvableType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class DefaultBindConstructorProvider
/*    */   implements BindConstructorProvider
/*    */ {
/*    */   public Constructor<?> getBindConstructor(Bindable<?> bindable, boolean isNestedConstructorBinding)
/*    */   {
/* 35 */     Class<?> type = bindable.getType().resolve();
/* 36 */     if ((bindable.getValue() != null) || (type == null)) {
/* 37 */       return null;
/*    */     }
/* 39 */     if ((KotlinDetector.isKotlinPresent()) && (KotlinDetector.isKotlinType(type))) {
/* 40 */       return getDeducedKotlinConstructor(type);
/*    */     }
/* 42 */     Constructor<?>[] constructors = type.getDeclaredConstructors();
/* 43 */     if ((constructors.length == 1) && (constructors[0].getParameterCount() > 0)) {
/* 44 */       return constructors[0];
/*    */     }
/* 46 */     Constructor<?> constructor = null;
/* 47 */     for (Constructor<?> candidate : constructors) {
/* 48 */       if (!Modifier.isPrivate(candidate.getModifiers())) {
/* 49 */         if (constructor != null) {
/* 50 */           return null;
/*    */         }
/* 52 */         constructor = candidate;
/*    */       }
/*    */     }
/* 55 */     if ((constructor != null) && (constructor.getParameterCount() > 0)) {
/* 56 */       return constructor;
/*    */     }
/* 58 */     return null;
/*    */   }
/*    */   
/*    */   private Constructor<?> getDeducedKotlinConstructor(Class<?> type) {
/* 62 */     Constructor<?> primaryConstructor = BeanUtils.findPrimaryConstructor(type);
/* 63 */     if ((primaryConstructor != null) && (primaryConstructor.getParameterCount() > 0)) {
/* 64 */       return primaryConstructor;
/*    */     }
/* 66 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\context\properties\bind\DefaultBindConstructorProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */