/*    */ package org.springframework.boot.jdbc;
/*    */ 
/*    */ import java.util.function.Supplier;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UnsupportedDataSourcePropertyException
/*    */   extends RuntimeException
/*    */ {
/*    */   UnsupportedDataSourcePropertyException(String message)
/*    */   {
/* 31 */     super(message);
/*    */   }
/*    */   
/*    */   static void throwIf(boolean test, Supplier<String> message) {
/* 35 */     if (test) {
/* 36 */       throw new UnsupportedDataSourcePropertyException((String)message.get());
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\jdbc\UnsupportedDataSourcePropertyException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */