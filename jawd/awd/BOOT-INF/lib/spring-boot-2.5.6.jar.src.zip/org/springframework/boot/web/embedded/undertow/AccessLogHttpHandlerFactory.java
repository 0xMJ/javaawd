/*     */ package org.springframework.boot.web.embedded.undertow;
/*     */ 
/*     */ import io.undertow.Undertow;
/*     */ import io.undertow.server.HttpHandler;
/*     */ import io.undertow.server.handlers.accesslog.AccessLogHandler;
/*     */ import io.undertow.server.handlers.accesslog.DefaultAccessLogReceiver;
/*     */ import java.io.Closeable;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import org.springframework.util.Assert;
/*     */ import org.xnio.OptionMap;
/*     */ import org.xnio.OptionMap.Builder;
/*     */ import org.xnio.Options;
/*     */ import org.xnio.Xnio;
/*     */ import org.xnio.XnioWorker;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class AccessLogHttpHandlerFactory
/*     */   implements HttpHandlerFactory
/*     */ {
/*     */   private final File directory;
/*     */   private final String pattern;
/*     */   private final String prefix;
/*     */   private final String suffix;
/*     */   private final boolean rotate;
/*     */   
/*     */   AccessLogHttpHandlerFactory(File directory, String pattern, String prefix, String suffix, boolean rotate)
/*     */   {
/*  53 */     this.directory = directory;
/*  54 */     this.pattern = pattern;
/*  55 */     this.prefix = prefix;
/*  56 */     this.suffix = suffix;
/*  57 */     this.rotate = rotate;
/*     */   }
/*     */   
/*     */   public HttpHandler getHandler(HttpHandler next)
/*     */   {
/*     */     try {
/*  63 */       createAccessLogDirectoryIfNecessary();
/*  64 */       XnioWorker worker = createWorker();
/*  65 */       String baseName = this.prefix != null ? this.prefix : "access_log.";
/*  66 */       String formatString = this.pattern != null ? this.pattern : "common";
/*  67 */       return new ClosableAccessLogHandler(next, worker, new DefaultAccessLogReceiver(worker, this.directory, baseName, this.suffix, this.rotate), formatString);
/*     */ 
/*     */     }
/*     */     catch (IOException ex)
/*     */     {
/*  72 */       throw new IllegalStateException("Failed to create AccessLogHandler", ex);
/*     */     }
/*     */   }
/*     */   
/*     */   private void createAccessLogDirectoryIfNecessary() {
/*  77 */     Assert.state(this.directory != null, "Access log directory is not set");
/*  78 */     if ((!this.directory.isDirectory()) && (!this.directory.mkdirs())) {
/*  79 */       throw new IllegalStateException("Failed to create access log directory '" + this.directory + "'");
/*     */     }
/*     */   }
/*     */   
/*     */   private XnioWorker createWorker() throws IOException {
/*  84 */     Xnio xnio = Xnio.getInstance(Undertow.class.getClassLoader());
/*  85 */     return xnio.createWorker(OptionMap.builder().set(Options.THREAD_DAEMON, true).getMap());
/*     */   }
/*     */   
/*     */ 
/*     */   private static class ClosableAccessLogHandler
/*     */     extends AccessLogHandler
/*     */     implements Closeable
/*     */   {
/*     */     private final DefaultAccessLogReceiver accessLogReceiver;
/*     */     
/*     */     private final XnioWorker worker;
/*     */     
/*     */     ClosableAccessLogHandler(HttpHandler next, XnioWorker worker, DefaultAccessLogReceiver accessLogReceiver, String formatString)
/*     */     {
/*  99 */       super(accessLogReceiver, formatString, Undertow.class.getClassLoader());
/* 100 */       this.worker = worker;
/* 101 */       this.accessLogReceiver = accessLogReceiver;
/*     */     }
/*     */     
/*     */     public void close() throws IOException
/*     */     {
/*     */       try {
/* 107 */         this.accessLogReceiver.close();
/* 108 */         this.worker.shutdown();
/* 109 */         this.worker.awaitTermination(30L, TimeUnit.SECONDS);
/*     */       }
/*     */       catch (IOException ex) {
/* 112 */         throw new RuntimeException(ex);
/*     */       }
/*     */       catch (InterruptedException ex) {
/* 115 */         Thread.currentThread().interrupt();
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\web\embedded\undertow\AccessLogHttpHandlerFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */