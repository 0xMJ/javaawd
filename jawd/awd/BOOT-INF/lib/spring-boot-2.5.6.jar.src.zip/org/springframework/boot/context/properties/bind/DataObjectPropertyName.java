/*    */ package org.springframework.boot.context.properties.bind;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class DataObjectPropertyName
/*    */ {
/*    */   public static String toDashedForm(String name)
/*    */   {
/* 38 */     StringBuilder result = new StringBuilder(name.length());
/* 39 */     boolean inIndex = false;
/* 40 */     for (int i = 0; i < name.length(); i++) {
/* 41 */       char ch = name.charAt(i);
/* 42 */       if (inIndex) {
/* 43 */         result.append(ch);
/* 44 */         if (ch == ']') {
/* 45 */           inIndex = false;
/*    */         }
/*    */         
/*    */       }
/* 49 */       else if (ch == '[') {
/* 50 */         inIndex = true;
/* 51 */         result.append(ch);
/*    */       }
/*    */       else {
/* 54 */         ch = ch != '_' ? ch : '-';
/* 55 */         if ((Character.isUpperCase(ch)) && (result.length() > 0) && (result.charAt(result.length() - 1) != '-')) {
/* 56 */           result.append('-');
/*    */         }
/* 58 */         result.append(Character.toLowerCase(ch));
/*    */       }
/*    */     }
/*    */     
/* 62 */     return result.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\context\properties\bind\DataObjectPropertyName.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */