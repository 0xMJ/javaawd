/*     */ package org.springframework.boot.context;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.boot.context.event.ApplicationEnvironmentPreparedEvent;
/*     */ import org.springframework.boot.context.event.ApplicationPreparedEvent;
/*     */ import org.springframework.boot.context.event.ApplicationReadyEvent;
/*     */ import org.springframework.boot.context.event.SpringApplicationEvent;
/*     */ import org.springframework.boot.system.ApplicationPid;
/*     */ import org.springframework.boot.system.SystemProperties;
/*     */ import org.springframework.context.ApplicationListener;
/*     */ import org.springframework.context.ConfigurableApplicationContext;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ApplicationPidFileWriter
/*     */   implements ApplicationListener<SpringApplicationEvent>, Ordered
/*     */ {
/*  66 */   private static final Log logger = LogFactory.getLog(ApplicationPidFileWriter.class);
/*     */   private static final String DEFAULT_FILE_NAME = "application.pid";
/*     */   private static final List<Property> FILE_PROPERTIES;
/*     */   private static final List<Property> FAIL_ON_WRITE_ERROR_PROPERTIES;
/*     */   
/*     */   static
/*     */   {
/*  73 */     List<Property> properties = new ArrayList();
/*  74 */     properties.add(new SpringProperty("spring.pid.", "file"));
/*  75 */     properties.add(new SpringProperty("spring.", "pidfile"));
/*  76 */     properties.add(new SystemProperty("PIDFILE"));
/*  77 */     FILE_PROPERTIES = Collections.unmodifiableList(properties);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  83 */     List<Property> properties = new ArrayList();
/*  84 */     properties.add(new SpringProperty("spring.pid.", "fail-on-write-error"));
/*  85 */     properties.add(new SystemProperty("PID_FAIL_ON_WRITE_ERROR"));
/*  86 */     FAIL_ON_WRITE_ERROR_PROPERTIES = Collections.unmodifiableList(properties);
/*     */   }
/*     */   
/*  89 */   private static final AtomicBoolean created = new AtomicBoolean();
/*     */   
/*  91 */   private int order = -2147483635;
/*     */   
/*     */   private final File file;
/*     */   
/*  95 */   private Class<? extends SpringApplicationEvent> triggerEventType = ApplicationPreparedEvent.class;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ApplicationPidFileWriter()
/*     */   {
/* 102 */     this(new File("application.pid"));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ApplicationPidFileWriter(String filename)
/*     */   {
/* 110 */     this(new File(filename));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ApplicationPidFileWriter(File file)
/*     */   {
/* 118 */     Assert.notNull(file, "File must not be null");
/* 119 */     this.file = file;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTriggerEventType(Class<? extends SpringApplicationEvent> triggerEventType)
/*     */   {
/* 131 */     Assert.notNull(triggerEventType, "Trigger event type must not be null");
/* 132 */     this.triggerEventType = triggerEventType;
/*     */   }
/*     */   
/*     */   public void onApplicationEvent(SpringApplicationEvent event)
/*     */   {
/* 137 */     if ((this.triggerEventType.isInstance(event)) && (created.compareAndSet(false, true))) {
/*     */       try {
/* 139 */         writePidFile(event);
/*     */       }
/*     */       catch (Exception ex) {
/* 142 */         String message = String.format("Cannot create pid file %s", new Object[] { this.file });
/* 143 */         if (failOnWriteError(event)) {
/* 144 */           throw new IllegalStateException(message, ex);
/*     */         }
/* 146 */         logger.warn(message, ex);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void writePidFile(SpringApplicationEvent event) throws IOException {
/* 152 */     File pidFile = this.file;
/* 153 */     String override = getProperty(event, FILE_PROPERTIES);
/* 154 */     if (override != null) {
/* 155 */       pidFile = new File(override);
/*     */     }
/* 157 */     new ApplicationPid().write(pidFile);
/* 158 */     pidFile.deleteOnExit();
/*     */   }
/*     */   
/*     */   private boolean failOnWriteError(SpringApplicationEvent event) {
/* 162 */     String value = getProperty(event, FAIL_ON_WRITE_ERROR_PROPERTIES);
/* 163 */     return Boolean.parseBoolean(value);
/*     */   }
/*     */   
/*     */   private String getProperty(SpringApplicationEvent event, List<Property> candidates) {
/* 167 */     for (Property candidate : candidates) {
/* 168 */       String value = candidate.getValue(event);
/* 169 */       if (value != null) {
/* 170 */         return value;
/*     */       }
/*     */     }
/* 173 */     return null;
/*     */   }
/*     */   
/*     */   public void setOrder(int order) {
/* 177 */     this.order = order;
/*     */   }
/*     */   
/*     */   public int getOrder()
/*     */   {
/* 182 */     return this.order;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected static void reset()
/*     */   {
/* 189 */     created.set(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static abstract interface Property
/*     */   {
/*     */     public abstract String getValue(SpringApplicationEvent paramSpringApplicationEvent);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static class SpringProperty
/*     */     implements ApplicationPidFileWriter.Property
/*     */   {
/*     */     private final String prefix;
/*     */     
/*     */     private final String key;
/*     */     
/*     */ 
/*     */     SpringProperty(String prefix, String key)
/*     */     {
/* 211 */       this.prefix = prefix;
/* 212 */       this.key = key;
/*     */     }
/*     */     
/*     */     public String getValue(SpringApplicationEvent event)
/*     */     {
/* 217 */       Environment environment = getEnvironment(event);
/* 218 */       if (environment == null) {
/* 219 */         return null;
/*     */       }
/* 221 */       return environment.getProperty(this.prefix + this.key);
/*     */     }
/*     */     
/*     */     private Environment getEnvironment(SpringApplicationEvent event) {
/* 225 */       if ((event instanceof ApplicationEnvironmentPreparedEvent)) {
/* 226 */         return ((ApplicationEnvironmentPreparedEvent)event).getEnvironment();
/*     */       }
/* 228 */       if ((event instanceof ApplicationPreparedEvent)) {
/* 229 */         return ((ApplicationPreparedEvent)event).getApplicationContext().getEnvironment();
/*     */       }
/* 231 */       if ((event instanceof ApplicationReadyEvent)) {
/* 232 */         return ((ApplicationReadyEvent)event).getApplicationContext().getEnvironment();
/*     */       }
/* 234 */       return null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static class SystemProperty
/*     */     implements ApplicationPidFileWriter.Property
/*     */   {
/*     */     private final String[] properties;
/*     */     
/*     */ 
/*     */     SystemProperty(String name)
/*     */     {
/* 247 */       this.properties = new String[] { name.toUpperCase(Locale.ENGLISH), name.toLowerCase(Locale.ENGLISH) };
/*     */     }
/*     */     
/*     */     public String getValue(SpringApplicationEvent event)
/*     */     {
/* 252 */       return SystemProperties.get(this.properties);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\context\ApplicationPidFileWriter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */