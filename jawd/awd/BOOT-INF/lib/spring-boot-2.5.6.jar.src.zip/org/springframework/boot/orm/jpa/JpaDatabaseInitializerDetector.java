/*    */ package org.springframework.boot.orm.jpa;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.HashSet;
/*    */ import java.util.Iterator;
/*    */ import java.util.Set;
/*    */ import javax.persistence.EntityManagerFactory;
/*    */ import org.springframework.beans.factory.config.BeanDefinition;
/*    */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*    */ import org.springframework.boot.sql.init.dependency.AbstractBeansOfTypeDatabaseInitializerDetector;
/*    */ import org.springframework.boot.sql.init.dependency.DatabaseInitializerDetector;
/*    */ import org.springframework.core.env.Environment;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class JpaDatabaseInitializerDetector
/*    */   extends AbstractBeansOfTypeDatabaseInitializerDetector
/*    */ {
/*    */   private final Environment environment;
/*    */   
/*    */   JpaDatabaseInitializerDetector(Environment environment)
/*    */   {
/* 43 */     this.environment = environment;
/*    */   }
/*    */   
/*    */   protected Set<Class<?>> getDatabaseInitializerBeanTypes()
/*    */   {
/* 48 */     boolean deferred = ((Boolean)this.environment.getProperty("spring.jpa.defer-datasource-initialization", Boolean.TYPE, 
/* 49 */       Boolean.valueOf(false))).booleanValue();
/* 50 */     return deferred ? Collections.singleton(EntityManagerFactory.class) : Collections.emptySet();
/*    */   }
/*    */   
/*    */   public void detectionComplete(ConfigurableListableBeanFactory beanFactory, Set<String> dataSourceInitializerNames)
/*    */   {
/* 55 */     configureOtherInitializersToDependOnJpaInitializers(beanFactory, dataSourceInitializerNames);
/*    */   }
/*    */   
/*    */   private void configureOtherInitializersToDependOnJpaInitializers(ConfigurableListableBeanFactory beanFactory, Set<String> dataSourceInitializerNames)
/*    */   {
/* 60 */     Set<String> jpaInitializers = new HashSet();
/* 61 */     Set<String> otherInitializers = new HashSet(dataSourceInitializerNames);
/* 62 */     Iterator<String> iterator = otherInitializers.iterator();
/* 63 */     String initializerName; while (iterator.hasNext()) {
/* 64 */       initializerName = (String)iterator.next();
/* 65 */       BeanDefinition initializerDefinition = beanFactory.getBeanDefinition(initializerName);
/*    */       
/* 67 */       if (JpaDatabaseInitializerDetector.class.getName().equals(initializerDefinition.getAttribute(DatabaseInitializerDetector.class.getName()))) {
/* 68 */         iterator.remove();
/* 69 */         jpaInitializers.add(initializerName);
/*    */       }
/*    */     }
/* 72 */     for (String otherInitializerName : otherInitializers) {
/* 73 */       BeanDefinition definition = beanFactory.getBeanDefinition(otherInitializerName);
/* 74 */       String[] dependencies = definition.getDependsOn();
/* 75 */       for (String dependencyName : jpaInitializers) {
/* 76 */         dependencies = StringUtils.addStringToArray(dependencies, dependencyName);
/*    */       }
/* 78 */       definition.setDependsOn(dependencies);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\orm\jpa\JpaDatabaseInitializerDetector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */