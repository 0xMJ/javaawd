/*    */ package org.springframework.boot.context.config;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ConfigDataResource
/*    */ {
/*    */   private final boolean optional;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ConfigDataResource()
/*    */   {
/* 36 */     this(false);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected ConfigDataResource(boolean optional)
/*    */   {
/* 45 */     this.optional = optional;
/*    */   }
/*    */   
/*    */   boolean isOptional() {
/* 49 */     return this.optional;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\context\config\ConfigDataResource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */