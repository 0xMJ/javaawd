package org.springframework.boot.context.properties.bind;

abstract interface DataObjectPropertyBinder
{
  public abstract Object bindProperty(String paramString, Bindable<?> paramBindable);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\context\properties\bind\DataObjectPropertyBinder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */