/*    */ package org.springframework.boot.web.reactive.context;
/*    */ 
/*    */ import org.springframework.core.env.MutablePropertySources;
/*    */ import org.springframework.core.env.StandardEnvironment;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StandardReactiveWebEnvironment
/*    */   extends StandardEnvironment
/*    */   implements ConfigurableReactiveWebEnvironment
/*    */ {
/*    */   public StandardReactiveWebEnvironment() {}
/*    */   
/*    */   protected StandardReactiveWebEnvironment(MutablePropertySources propertySources)
/*    */   {
/* 38 */     super(propertySources);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\web\reactive\context\StandardReactiveWebEnvironment.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */