/*    */ package org.springframework.boot.convert;
/*    */ 
/*    */ import java.time.Period;
/*    */ import java.time.temporal.ChronoUnit;
/*    */ import java.util.Collections;
/*    */ import java.util.Set;
/*    */ import org.springframework.core.convert.TypeDescriptor;
/*    */ import org.springframework.core.convert.converter.GenericConverter;
/*    */ import org.springframework.core.convert.converter.GenericConverter.ConvertiblePair;
/*    */ import org.springframework.util.ObjectUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class PeriodToStringConverter
/*    */   implements GenericConverter
/*    */ {
/*    */   public Set<GenericConverter.ConvertiblePair> getConvertibleTypes()
/*    */   {
/* 41 */     return Collections.singleton(new GenericConverter.ConvertiblePair(Period.class, String.class));
/*    */   }
/*    */   
/*    */   public Object convert(Object source, TypeDescriptor sourceType, TypeDescriptor targetType)
/*    */   {
/* 46 */     if (ObjectUtils.isEmpty(source)) {
/* 47 */       return null;
/*    */     }
/* 49 */     return convert((Period)source, getPeriodStyle(sourceType), getPeriodUnit(sourceType));
/*    */   }
/*    */   
/*    */   private PeriodStyle getPeriodStyle(TypeDescriptor sourceType) {
/* 53 */     PeriodFormat annotation = (PeriodFormat)sourceType.getAnnotation(PeriodFormat.class);
/* 54 */     return annotation != null ? annotation.value() : null;
/*    */   }
/*    */   
/*    */   private String convert(Period source, PeriodStyle style, ChronoUnit unit) {
/* 58 */     style = style != null ? style : PeriodStyle.ISO8601;
/* 59 */     return style.print(source, unit);
/*    */   }
/*    */   
/*    */   private ChronoUnit getPeriodUnit(TypeDescriptor sourceType) {
/* 63 */     PeriodUnit annotation = (PeriodUnit)sourceType.getAnnotation(PeriodUnit.class);
/* 64 */     return annotation != null ? annotation.value() : null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\convert\PeriodToStringConverter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */