/*     */ package org.springframework.boot.origin;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import java.nio.channels.ReadableByteChannel;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.WritableResource;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OriginTrackedResource
/*     */   implements Resource, OriginProvider
/*     */ {
/*     */   private final Resource resource;
/*     */   private final Origin origin;
/*     */   
/*     */   OriginTrackedResource(Resource resource, Origin origin)
/*     */   {
/*  54 */     Assert.notNull(resource, "Resource must not be null");
/*  55 */     this.resource = resource;
/*  56 */     this.origin = origin;
/*     */   }
/*     */   
/*     */   public InputStream getInputStream() throws IOException
/*     */   {
/*  61 */     return getResource().getInputStream();
/*     */   }
/*     */   
/*     */   public boolean exists()
/*     */   {
/*  66 */     return getResource().exists();
/*     */   }
/*     */   
/*     */   public boolean isReadable()
/*     */   {
/*  71 */     return getResource().isReadable();
/*     */   }
/*     */   
/*     */   public boolean isOpen()
/*     */   {
/*  76 */     return getResource().isOpen();
/*     */   }
/*     */   
/*     */   public boolean isFile()
/*     */   {
/*  81 */     return getResource().isFile();
/*     */   }
/*     */   
/*     */   public URL getURL() throws IOException
/*     */   {
/*  86 */     return getResource().getURL();
/*     */   }
/*     */   
/*     */   public URI getURI() throws IOException
/*     */   {
/*  91 */     return getResource().getURI();
/*     */   }
/*     */   
/*     */   public File getFile() throws IOException
/*     */   {
/*  96 */     return getResource().getFile();
/*     */   }
/*     */   
/*     */   public ReadableByteChannel readableChannel() throws IOException
/*     */   {
/* 101 */     return getResource().readableChannel();
/*     */   }
/*     */   
/*     */   public long contentLength() throws IOException
/*     */   {
/* 106 */     return getResource().contentLength();
/*     */   }
/*     */   
/*     */   public long lastModified() throws IOException
/*     */   {
/* 111 */     return getResource().lastModified();
/*     */   }
/*     */   
/*     */   public Resource createRelative(String relativePath) throws IOException
/*     */   {
/* 116 */     return getResource().createRelative(relativePath);
/*     */   }
/*     */   
/*     */   public String getFilename()
/*     */   {
/* 121 */     return getResource().getFilename();
/*     */   }
/*     */   
/*     */   public String getDescription()
/*     */   {
/* 126 */     return getResource().getDescription();
/*     */   }
/*     */   
/*     */   public Resource getResource() {
/* 130 */     return this.resource;
/*     */   }
/*     */   
/*     */   public Origin getOrigin()
/*     */   {
/* 135 */     return this.origin;
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/* 140 */     if (this == obj) {
/* 141 */       return true;
/*     */     }
/* 143 */     if ((obj == null) || (getClass() != obj.getClass())) {
/* 144 */       return false;
/*     */     }
/* 146 */     OriginTrackedResource other = (OriginTrackedResource)obj;
/* 147 */     return (this.resource.equals(other)) && (ObjectUtils.nullSafeEquals(this.origin, other.origin));
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 152 */     int prime = 31;
/* 153 */     int result = this.resource.hashCode();
/* 154 */     result = 31 * result + ObjectUtils.nullSafeHashCode(this.origin);
/* 155 */     return result;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 160 */     return this.resource.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static OriginTrackedWritableResource of(WritableResource resource, Origin origin)
/*     */   {
/* 171 */     return (OriginTrackedWritableResource)of(resource, origin);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static OriginTrackedResource of(Resource resource, Origin origin)
/*     */   {
/* 182 */     if ((resource instanceof WritableResource)) {
/* 183 */       return new OriginTrackedWritableResource((WritableResource)resource, origin);
/*     */     }
/* 185 */     return new OriginTrackedResource(resource, origin);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class OriginTrackedWritableResource
/*     */     extends OriginTrackedResource
/*     */     implements WritableResource
/*     */   {
/*     */     OriginTrackedWritableResource(WritableResource resource, Origin origin)
/*     */     {
/* 199 */       super(origin);
/*     */     }
/*     */     
/*     */     public WritableResource getResource()
/*     */     {
/* 204 */       return (WritableResource)super.getResource();
/*     */     }
/*     */     
/*     */     public OutputStream getOutputStream() throws IOException
/*     */     {
/* 209 */       return getResource().getOutputStream();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\origin\OriginTrackedResource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */