/*     */ package org.springframework.boot.logging.logback;
/*     */ 
/*     */ import ch.qos.logback.classic.Level;
/*     */ import ch.qos.logback.classic.LoggerContext;
/*     */ import ch.qos.logback.classic.encoder.PatternLayoutEncoder;
/*     */ import ch.qos.logback.classic.spi.ILoggingEvent;
/*     */ import ch.qos.logback.core.Appender;
/*     */ import ch.qos.logback.core.ConsoleAppender;
/*     */ import ch.qos.logback.core.rolling.RollingFileAppender;
/*     */ import ch.qos.logback.core.rolling.SizeAndTimeBasedRollingPolicy;
/*     */ import ch.qos.logback.core.util.FileSize;
/*     */ import ch.qos.logback.core.util.OptionHelper;
/*     */ import java.nio.charset.Charset;
/*     */ import org.springframework.boot.logging.LogFile;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DefaultLogbackConfiguration
/*     */ {
/*     */   private final LogFile logFile;
/*     */   
/*     */   DefaultLogbackConfiguration(LogFile logFile)
/*     */   {
/*  49 */     this.logFile = logFile;
/*     */   }
/*     */   
/*     */   void apply(LogbackConfigurator config) {
/*  53 */     synchronized (config.getConfigurationLock()) {
/*  54 */       defaults(config);
/*  55 */       Appender<ILoggingEvent> consoleAppender = consoleAppender(config);
/*  56 */       if (this.logFile != null) {
/*  57 */         Appender<ILoggingEvent> fileAppender = fileAppender(config, this.logFile.toString());
/*  58 */         config.root(Level.INFO, new Appender[] { consoleAppender, fileAppender });
/*     */       }
/*     */       else {
/*  61 */         config.root(Level.INFO, new Appender[] { consoleAppender });
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void defaults(LogbackConfigurator config) {
/*  67 */     config.conversionRule("clr", ColorConverter.class);
/*  68 */     config.conversionRule("wex", WhitespaceThrowableProxyConverter.class);
/*  69 */     config.conversionRule("wEx", ExtendedWhitespaceThrowableProxyConverter.class);
/*  70 */     config.getContext().putProperty("CONSOLE_LOG_PATTERN", resolve(config, "${CONSOLE_LOG_PATTERN:-%clr(%d{${LOG_DATEFORMAT_PATTERN:-yyyy-MM-dd HH:mm:ss.SSS}}){faint} %clr(${LOG_LEVEL_PATTERN:-%5p}) %clr(${PID:- }){magenta} %clr(---){faint} %clr([%15.15t]){faint} %clr(%-40.40logger{39}){cyan} %clr(:){faint} %m%n${LOG_EXCEPTION_CONVERSION_WORD:-%wEx}}"));
/*     */     
/*     */ 
/*     */ 
/*  74 */     config.getContext().putProperty("CONSOLE_LOG_CHARSET", resolve(config, "${CONSOLE_LOG_CHARSET:-default}"));
/*  75 */     config.getContext().putProperty("FILE_LOG_PATTERN", resolve(config, "${FILE_LOG_PATTERN:-%d{${LOG_DATEFORMAT_PATTERN:-yyyy-MM-dd HH:mm:ss.SSS}} ${LOG_LEVEL_PATTERN:-%5p} ${PID:- } --- [%t] %-40.40logger{39} : %m%n${LOG_EXCEPTION_CONVERSION_WORD:-%wEx}}"));
/*     */     
/*     */ 
/*  78 */     config.getContext().putProperty("FILE_LOG_CHARSET", resolve(config, "${FILE_LOG_CHARSET:-default}"));
/*  79 */     config.logger("org.apache.catalina.startup.DigesterFactory", Level.ERROR);
/*  80 */     config.logger("org.apache.catalina.util.LifecycleBase", Level.ERROR);
/*  81 */     config.logger("org.apache.coyote.http11.Http11NioProtocol", Level.WARN);
/*  82 */     config.logger("org.apache.sshd.common.util.SecurityUtils", Level.WARN);
/*  83 */     config.logger("org.apache.tomcat.util.net.NioSelectorPool", Level.WARN);
/*  84 */     config.logger("org.eclipse.jetty.util.component.AbstractLifeCycle", Level.ERROR);
/*  85 */     config.logger("org.hibernate.validator.internal.util.Version", Level.WARN);
/*  86 */     config.logger("org.springframework.boot.actuate.endpoint.jmx", Level.WARN);
/*     */   }
/*     */   
/*     */   private Appender<ILoggingEvent> consoleAppender(LogbackConfigurator config) {
/*  90 */     ConsoleAppender<ILoggingEvent> appender = new ConsoleAppender();
/*  91 */     PatternLayoutEncoder encoder = new PatternLayoutEncoder();
/*  92 */     encoder.setPattern(resolve(config, "${CONSOLE_LOG_PATTERN}"));
/*  93 */     encoder.setCharset(resolveCharset(config, "${CONSOLE_LOG_CHARSET}"));
/*  94 */     config.start(encoder);
/*  95 */     appender.setEncoder(encoder);
/*  96 */     config.appender("CONSOLE", appender);
/*  97 */     return appender;
/*     */   }
/*     */   
/*     */   private Appender<ILoggingEvent> fileAppender(LogbackConfigurator config, String logFile) {
/* 101 */     RollingFileAppender<ILoggingEvent> appender = new RollingFileAppender();
/* 102 */     PatternLayoutEncoder encoder = new PatternLayoutEncoder();
/* 103 */     encoder.setPattern(resolve(config, "${FILE_LOG_PATTERN}"));
/* 104 */     encoder.setCharset(resolveCharset(config, "${FILE_LOG_CHARSET}"));
/* 105 */     appender.setEncoder(encoder);
/* 106 */     config.start(encoder);
/* 107 */     appender.setFile(logFile);
/* 108 */     setRollingPolicy(appender, config);
/* 109 */     config.appender("FILE", appender);
/* 110 */     return appender;
/*     */   }
/*     */   
/*     */   private void setRollingPolicy(RollingFileAppender<ILoggingEvent> appender, LogbackConfigurator config) {
/* 114 */     SizeAndTimeBasedRollingPolicy<ILoggingEvent> rollingPolicy = new SizeAndTimeBasedRollingPolicy();
/* 115 */     rollingPolicy.setContext(config.getContext());
/* 116 */     rollingPolicy.setFileNamePattern(
/* 117 */       resolve(config, "${LOGBACK_ROLLINGPOLICY_FILE_NAME_PATTERN:-${LOG_FILE}.%d{yyyy-MM-dd}.%i.gz}"));
/* 118 */     rollingPolicy.setCleanHistoryOnStart(
/* 119 */       resolveBoolean(config, "${LOGBACK_ROLLINGPOLICY_CLEAN_HISTORY_ON_START:-false}"));
/* 120 */     rollingPolicy.setMaxFileSize(resolveFileSize(config, "${LOGBACK_ROLLINGPOLICY_MAX_FILE_SIZE:-10MB}"));
/* 121 */     rollingPolicy.setTotalSizeCap(resolveFileSize(config, "${LOGBACK_ROLLINGPOLICY_TOTAL_SIZE_CAP:-0}"));
/* 122 */     rollingPolicy.setMaxHistory(resolveInt(config, "${LOGBACK_ROLLINGPOLICY_MAX_HISTORY:-7}"));
/* 123 */     appender.setRollingPolicy(rollingPolicy);
/* 124 */     rollingPolicy.setParent(appender);
/* 125 */     config.start(rollingPolicy);
/*     */   }
/*     */   
/*     */   private boolean resolveBoolean(LogbackConfigurator config, String val) {
/* 129 */     return Boolean.parseBoolean(resolve(config, val));
/*     */   }
/*     */   
/*     */   private int resolveInt(LogbackConfigurator config, String val) {
/* 133 */     return Integer.parseInt(resolve(config, val));
/*     */   }
/*     */   
/*     */   private FileSize resolveFileSize(LogbackConfigurator config, String val) {
/* 137 */     return FileSize.valueOf(resolve(config, val));
/*     */   }
/*     */   
/*     */   private Charset resolveCharset(LogbackConfigurator config, String val) {
/* 141 */     return Charset.forName(resolve(config, val));
/*     */   }
/*     */   
/*     */   private String resolve(LogbackConfigurator config, String val) {
/* 145 */     return OptionHelper.substVars(val, config.getContext());
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\logging\logback\DefaultLogbackConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */