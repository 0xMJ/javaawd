/*    */ package org.springframework.boot.context.properties;
/*    */ 
/*    */ import org.springframework.boot.validation.MessageInterpolatorFactory;
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.util.ClassUtils;
/*    */ import org.springframework.validation.Errors;
/*    */ import org.springframework.validation.Validator;
/*    */ import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class ConfigurationPropertiesJsr303Validator
/*    */   implements Validator
/*    */ {
/* 35 */   private static final String[] VALIDATOR_CLASSES = { "javax.validation.Validator", "javax.validation.ValidatorFactory", "javax.validation.bootstrap.GenericBootstrap" };
/*    */   
/*    */   private final Delegate delegate;
/*    */   
/*    */   ConfigurationPropertiesJsr303Validator(ApplicationContext applicationContext)
/*    */   {
/* 41 */     this.delegate = new Delegate(applicationContext);
/*    */   }
/*    */   
/*    */   public boolean supports(Class<?> type)
/*    */   {
/* 46 */     return this.delegate.supports(type);
/*    */   }
/*    */   
/*    */   public void validate(Object target, Errors errors)
/*    */   {
/* 51 */     this.delegate.validate(target, errors);
/*    */   }
/*    */   
/*    */   static boolean isJsr303Present(ApplicationContext applicationContext) {
/* 55 */     ClassLoader classLoader = applicationContext.getClassLoader();
/* 56 */     for (String validatorClass : VALIDATOR_CLASSES) {
/* 57 */       if (!ClassUtils.isPresent(validatorClass, classLoader)) {
/* 58 */         return false;
/*    */       }
/*    */     }
/* 61 */     return true;
/*    */   }
/*    */   
/*    */   private static class Delegate extends LocalValidatorFactoryBean
/*    */   {
/*    */     Delegate(ApplicationContext applicationContext) {
/* 67 */       setApplicationContext(applicationContext);
/* 68 */       setMessageInterpolator(new MessageInterpolatorFactory().getObject());
/* 69 */       afterPropertiesSet();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\context\properties\ConfigurationPropertiesJsr303Validator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */