/*    */ package org.springframework.boot.ansi;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum AnsiStyle
/*    */   implements AnsiElement
/*    */ {
/* 27 */   NORMAL("0"), 
/*    */   
/* 29 */   BOLD("1"), 
/*    */   
/* 31 */   FAINT("2"), 
/*    */   
/* 33 */   ITALIC("3"), 
/*    */   
/* 35 */   UNDERLINE("4");
/*    */   
/*    */   private final String code;
/*    */   
/*    */   private AnsiStyle(String code) {
/* 40 */     this.code = code;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 45 */     return this.code;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\ansi\AnsiStyle.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */