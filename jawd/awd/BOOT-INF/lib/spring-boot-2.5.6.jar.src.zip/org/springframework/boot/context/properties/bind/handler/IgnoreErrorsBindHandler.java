/*    */ package org.springframework.boot.context.properties.bind.handler;
/*    */ 
/*    */ import java.util.function.Supplier;
/*    */ import org.springframework.boot.context.properties.bind.AbstractBindHandler;
/*    */ import org.springframework.boot.context.properties.bind.BindContext;
/*    */ import org.springframework.boot.context.properties.bind.BindHandler;
/*    */ import org.springframework.boot.context.properties.bind.Bindable;
/*    */ import org.springframework.boot.context.properties.source.ConfigurationPropertyName;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IgnoreErrorsBindHandler
/*    */   extends AbstractBindHandler
/*    */ {
/*    */   public IgnoreErrorsBindHandler() {}
/*    */   
/*    */   public IgnoreErrorsBindHandler(BindHandler parent)
/*    */   {
/* 38 */     super(parent);
/*    */   }
/*    */   
/*    */   public Object onFailure(ConfigurationPropertyName name, Bindable<?> target, BindContext context, Exception error)
/*    */     throws Exception
/*    */   {
/* 44 */     return target.getValue() != null ? target.getValue().get() : null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\context\properties\bind\handler\IgnoreErrorsBindHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */