/*     */ package org.springframework.boot.web.embedded.tomcat;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class TldPatterns
/*     */ {
/*     */   static final Set<String> TOMCAT_SKIP;
/*     */   private static final Set<String> ADDITIONAL_SKIP;
/*     */   static final Set<String> DEFAULT_SKIP;
/*     */   static final Set<String> TOMCAT_SCAN;
/*     */   static final Set<String> DEFAULT_SCAN;
/*     */   
/*     */   static
/*     */   {
/*  35 */     Set<String> skipPatterns = new LinkedHashSet();
/*  36 */     skipPatterns.add("annotations-api.jar");
/*  37 */     skipPatterns.add("ant-junit*.jar");
/*  38 */     skipPatterns.add("ant-launcher.jar");
/*  39 */     skipPatterns.add("ant.jar");
/*  40 */     skipPatterns.add("asm-*.jar");
/*  41 */     skipPatterns.add("aspectj*.jar");
/*  42 */     skipPatterns.add("bootstrap.jar");
/*  43 */     skipPatterns.add("catalina-ant.jar");
/*  44 */     skipPatterns.add("catalina-ha.jar");
/*  45 */     skipPatterns.add("catalina-ssi.jar");
/*  46 */     skipPatterns.add("catalina-storeconfig.jar");
/*  47 */     skipPatterns.add("catalina-tribes.jar");
/*  48 */     skipPatterns.add("catalina.jar");
/*  49 */     skipPatterns.add("cglib-*.jar");
/*  50 */     skipPatterns.add("cobertura-*.jar");
/*  51 */     skipPatterns.add("commons-beanutils*.jar");
/*  52 */     skipPatterns.add("commons-codec*.jar");
/*  53 */     skipPatterns.add("commons-collections*.jar");
/*  54 */     skipPatterns.add("commons-daemon.jar");
/*  55 */     skipPatterns.add("commons-dbcp*.jar");
/*  56 */     skipPatterns.add("commons-digester*.jar");
/*  57 */     skipPatterns.add("commons-fileupload*.jar");
/*  58 */     skipPatterns.add("commons-httpclient*.jar");
/*  59 */     skipPatterns.add("commons-io*.jar");
/*  60 */     skipPatterns.add("commons-lang*.jar");
/*  61 */     skipPatterns.add("commons-logging*.jar");
/*  62 */     skipPatterns.add("commons-math*.jar");
/*  63 */     skipPatterns.add("commons-pool*.jar");
/*  64 */     skipPatterns.add("derby-*.jar");
/*  65 */     skipPatterns.add("dom4j-*.jar");
/*  66 */     skipPatterns.add("easymock-*.jar");
/*  67 */     skipPatterns.add("ecj-*.jar");
/*  68 */     skipPatterns.add("el-api.jar");
/*  69 */     skipPatterns.add("geronimo-spec-jaxrpc*.jar");
/*  70 */     skipPatterns.add("h2*.jar");
/*  71 */     skipPatterns.add("hamcrest-*.jar");
/*  72 */     skipPatterns.add("hibernate*.jar");
/*  73 */     skipPatterns.add("httpclient*.jar");
/*  74 */     skipPatterns.add("icu4j-*.jar");
/*  75 */     skipPatterns.add("jasper-el.jar");
/*  76 */     skipPatterns.add("jasper.jar");
/*  77 */     skipPatterns.add("jaspic-api.jar");
/*  78 */     skipPatterns.add("jaxb-*.jar");
/*  79 */     skipPatterns.add("jaxen-*.jar");
/*  80 */     skipPatterns.add("jdom-*.jar");
/*  81 */     skipPatterns.add("jetty-*.jar");
/*  82 */     skipPatterns.add("jmx-tools.jar");
/*  83 */     skipPatterns.add("jmx.jar");
/*  84 */     skipPatterns.add("jsp-api.jar");
/*  85 */     skipPatterns.add("jstl.jar");
/*  86 */     skipPatterns.add("jta*.jar");
/*  87 */     skipPatterns.add("junit-*.jar");
/*  88 */     skipPatterns.add("junit.jar");
/*  89 */     skipPatterns.add("log4j*.jar");
/*  90 */     skipPatterns.add("mail*.jar");
/*  91 */     skipPatterns.add("objenesis-*.jar");
/*  92 */     skipPatterns.add("oraclepki.jar");
/*  93 */     skipPatterns.add("oro-*.jar");
/*  94 */     skipPatterns.add("servlet-api-*.jar");
/*  95 */     skipPatterns.add("servlet-api.jar");
/*  96 */     skipPatterns.add("slf4j*.jar");
/*  97 */     skipPatterns.add("taglibs-standard-spec-*.jar");
/*  98 */     skipPatterns.add("tagsoup-*.jar");
/*  99 */     skipPatterns.add("tomcat-api.jar");
/* 100 */     skipPatterns.add("tomcat-coyote.jar");
/* 101 */     skipPatterns.add("tomcat-dbcp.jar");
/* 102 */     skipPatterns.add("tomcat-i18n-*.jar");
/* 103 */     skipPatterns.add("tomcat-jdbc.jar");
/* 104 */     skipPatterns.add("tomcat-jni.jar");
/* 105 */     skipPatterns.add("tomcat-juli-adapters.jar");
/* 106 */     skipPatterns.add("tomcat-juli.jar");
/* 107 */     skipPatterns.add("tomcat-util-scan.jar");
/* 108 */     skipPatterns.add("tomcat-util.jar");
/* 109 */     skipPatterns.add("tomcat-websocket.jar");
/* 110 */     skipPatterns.add("tools.jar");
/* 111 */     skipPatterns.add("websocket-api.jar");
/* 112 */     skipPatterns.add("wsdl4j*.jar");
/* 113 */     skipPatterns.add("xercesImpl.jar");
/* 114 */     skipPatterns.add("xml-apis.jar");
/* 115 */     skipPatterns.add("xmlParserAPIs-*.jar");
/* 116 */     skipPatterns.add("xmlParserAPIs.jar");
/* 117 */     skipPatterns.add("xom-*.jar");
/* 118 */     TOMCAT_SKIP = Collections.unmodifiableSet(skipPatterns);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 125 */     Set<String> skipPatterns = new LinkedHashSet();
/* 126 */     skipPatterns.add("antlr-*.jar");
/* 127 */     skipPatterns.add("aopalliance-*.jar");
/* 128 */     skipPatterns.add("aspectjweaver-*.jar");
/* 129 */     skipPatterns.add("classmate-*.jar");
/* 130 */     skipPatterns.add("ehcache-core-*.jar");
/* 131 */     skipPatterns.add("hsqldb-*.jar");
/* 132 */     skipPatterns.add("jackson-annotations-*.jar");
/* 133 */     skipPatterns.add("jackson-core-*.jar");
/* 134 */     skipPatterns.add("jackson-databind-*.jar");
/* 135 */     skipPatterns.add("jandex-*.jar");
/* 136 */     skipPatterns.add("javassist-*.jar");
/* 137 */     skipPatterns.add("jboss-logging-*.jar");
/* 138 */     skipPatterns.add("jboss-transaction-api_*.jar");
/* 139 */     skipPatterns.add("jcl-over-slf4j-*.jar");
/* 140 */     skipPatterns.add("jdom-*.jar");
/* 141 */     skipPatterns.add("jul-to-slf4j-*.jar");
/* 142 */     skipPatterns.add("logback-classic-*.jar");
/* 143 */     skipPatterns.add("logback-core-*.jar");
/* 144 */     skipPatterns.add("rome-*.jar");
/* 145 */     skipPatterns.add("spring-aop-*.jar");
/* 146 */     skipPatterns.add("spring-aspects-*.jar");
/* 147 */     skipPatterns.add("spring-beans-*.jar");
/* 148 */     skipPatterns.add("spring-boot-*.jar");
/* 149 */     skipPatterns.add("spring-core-*.jar");
/* 150 */     skipPatterns.add("spring-context-*.jar");
/* 151 */     skipPatterns.add("spring-data-*.jar");
/* 152 */     skipPatterns.add("spring-expression-*.jar");
/* 153 */     skipPatterns.add("spring-jdbc-*.jar,");
/* 154 */     skipPatterns.add("spring-orm-*.jar");
/* 155 */     skipPatterns.add("spring-oxm-*.jar");
/* 156 */     skipPatterns.add("spring-tx-*.jar");
/* 157 */     skipPatterns.add("snakeyaml-*.jar");
/* 158 */     skipPatterns.add("tomcat-embed-core-*.jar");
/* 159 */     skipPatterns.add("tomcat-embed-logging-*.jar");
/* 160 */     skipPatterns.add("tomcat-embed-el-*.jar");
/* 161 */     skipPatterns.add("validation-api-*.jar");
/* 162 */     ADDITIONAL_SKIP = Collections.unmodifiableSet(skipPatterns);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 168 */     Set<String> skipPatterns = new LinkedHashSet();
/* 169 */     skipPatterns.addAll(TOMCAT_SKIP);
/* 170 */     skipPatterns.addAll(ADDITIONAL_SKIP);
/* 171 */     DEFAULT_SKIP = Collections.unmodifiableSet(skipPatterns);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 177 */     Set<String> scanPatterns = new LinkedHashSet();
/* 178 */     scanPatterns.add("log4j-taglib*.jar");
/* 179 */     scanPatterns.add("log4j-web*.jar");
/* 180 */     scanPatterns.add("log4javascript*.jar");
/* 181 */     scanPatterns.add("slf4j-taglib*.jar");
/* 182 */     TOMCAT_SCAN = Collections.unmodifiableSet(scanPatterns);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 188 */     Set<String> scanPatterns = new LinkedHashSet();
/* 189 */     scanPatterns.addAll(TOMCAT_SCAN);
/* 190 */     DEFAULT_SCAN = Collections.unmodifiableSet(scanPatterns);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\web\embedded\tomcat\TldPatterns.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */