/*    */ package org.springframework.boot.web.embedded.undertow;
/*    */ 
/*    */ import io.undertow.Handlers;
/*    */ import io.undertow.Undertow.Builder;
/*    */ import io.undertow.server.HttpHandler;
/*    */ import io.undertow.server.handlers.PathHandler;
/*    */ import io.undertow.servlet.api.DeploymentManager;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UndertowServletWebServer
/*    */   extends UndertowWebServer
/*    */ {
/*    */   private final String contextPath;
/*    */   private final DeploymentManager manager;
/*    */   
/*    */   public UndertowServletWebServer(Undertow.Builder builder, Iterable<HttpHandlerFactory> httpHandlerFactories, String contextPath, boolean autoStart)
/*    */   {
/* 56 */     super(builder, httpHandlerFactories, autoStart);
/* 57 */     this.contextPath = contextPath;
/* 58 */     this.manager = findManager(httpHandlerFactories);
/*    */   }
/*    */   
/*    */   private DeploymentManager findManager(Iterable<HttpHandlerFactory> httpHandlerFactories) {
/* 62 */     for (HttpHandlerFactory httpHandlerFactory : httpHandlerFactories) {
/* 63 */       if ((httpHandlerFactory instanceof DeploymentManagerHttpHandlerFactory)) {
/* 64 */         return ((DeploymentManagerHttpHandlerFactory)httpHandlerFactory).getDeploymentManager();
/*    */       }
/*    */     }
/* 67 */     return null;
/*    */   }
/*    */   
/*    */   protected HttpHandler createHttpHandler()
/*    */   {
/* 72 */     HttpHandler handler = super.createHttpHandler();
/* 73 */     if (StringUtils.hasLength(this.contextPath)) {
/* 74 */       handler = Handlers.path().addPrefixPath(this.contextPath, handler);
/*    */     }
/* 76 */     return handler;
/*    */   }
/*    */   
/*    */   protected String getStartLogMessage()
/*    */   {
/* 81 */     String message = super.getStartLogMessage();
/* 82 */     if (StringUtils.hasText(this.contextPath)) {
/* 83 */       message = message + " with context path '" + this.contextPath + "'";
/*    */     }
/* 85 */     return message;
/*    */   }
/*    */   
/*    */   public DeploymentManager getDeploymentManager() {
/* 89 */     return this.manager;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\web\embedded\undertow\UndertowServletWebServer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */