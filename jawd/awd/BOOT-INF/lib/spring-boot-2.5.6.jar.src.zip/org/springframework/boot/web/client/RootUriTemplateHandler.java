/*     */ package org.springframework.boot.web.client;
/*     */ 
/*     */ import java.net.URI;
/*     */ import java.util.Map;
/*     */ import java.util.function.Function;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.client.RestTemplate;
/*     */ import org.springframework.web.util.DefaultUriBuilderFactory;
/*     */ import org.springframework.web.util.UriTemplateHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RootUriTemplateHandler
/*     */   implements UriTemplateHandler
/*     */ {
/*     */   private final String rootUri;
/*     */   private final UriTemplateHandler handler;
/*     */   
/*     */   protected RootUriTemplateHandler(UriTemplateHandler handler)
/*     */   {
/*  42 */     Assert.notNull(handler, "Handler must not be null");
/*  43 */     this.rootUri = null;
/*  44 */     this.handler = handler;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public RootUriTemplateHandler(String rootUri)
/*     */   {
/*  52 */     this(rootUri, new DefaultUriBuilderFactory());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RootUriTemplateHandler(String rootUri, UriTemplateHandler handler)
/*     */   {
/*  61 */     Assert.notNull(rootUri, "RootUri must not be null");
/*  62 */     Assert.notNull(handler, "Handler must not be null");
/*  63 */     this.rootUri = rootUri;
/*  64 */     this.handler = handler;
/*     */   }
/*     */   
/*     */   public URI expand(String uriTemplate, Map<String, ?> uriVariables)
/*     */   {
/*  69 */     return this.handler.expand(apply(uriTemplate), uriVariables);
/*     */   }
/*     */   
/*     */   public URI expand(String uriTemplate, Object... uriVariables)
/*     */   {
/*  74 */     return this.handler.expand(apply(uriTemplate), uriVariables);
/*     */   }
/*     */   
/*     */   private String apply(String uriTemplate) {
/*  78 */     if (StringUtils.startsWithIgnoreCase(uriTemplate, "/")) {
/*  79 */       return getRootUri() + uriTemplate;
/*     */     }
/*  81 */     return uriTemplate;
/*     */   }
/*     */   
/*     */   public String getRootUri() {
/*  85 */     return this.rootUri;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RootUriTemplateHandler withHandlerWrapper(Function<UriTemplateHandler, UriTemplateHandler> wrapper)
/*     */   {
/*  96 */     return new RootUriTemplateHandler(getRootUri(), (UriTemplateHandler)wrapper.apply(this.handler));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static RootUriTemplateHandler addTo(RestTemplate restTemplate, String rootUri)
/*     */   {
/* 106 */     Assert.notNull(restTemplate, "RestTemplate must not be null");
/* 107 */     RootUriTemplateHandler handler = new RootUriTemplateHandler(rootUri, restTemplate.getUriTemplateHandler());
/* 108 */     restTemplate.setUriTemplateHandler(handler);
/* 109 */     return handler;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\web\client\RootUriTemplateHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */