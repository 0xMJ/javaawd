/*    */ package org.springframework.boot.context.properties;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IncompatibleConfigurationException
/*    */   extends RuntimeException
/*    */ {
/*    */   private final List<String> incompatibleKeys;
/*    */   
/*    */   public IncompatibleConfigurationException(String... incompatibleKeys)
/*    */   {
/* 35 */     super("The following configuration properties have incompatible values: " + Arrays.toString(incompatibleKeys));
/* 36 */     this.incompatibleKeys = Arrays.asList(incompatibleKeys);
/*    */   }
/*    */   
/*    */   public Collection<String> getIncompatibleKeys() {
/* 40 */     return this.incompatibleKeys;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\context\properties\IncompatibleConfigurationException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */