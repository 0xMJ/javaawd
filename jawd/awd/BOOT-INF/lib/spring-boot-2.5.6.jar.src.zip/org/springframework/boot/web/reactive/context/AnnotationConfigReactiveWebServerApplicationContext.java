/*     */ package org.springframework.boot.web.reactive.context;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.support.BeanNameGenerator;
/*     */ import org.springframework.beans.factory.support.DefaultListableBeanFactory;
/*     */ import org.springframework.context.annotation.AnnotatedBeanDefinitionReader;
/*     */ import org.springframework.context.annotation.AnnotationConfigRegistry;
/*     */ import org.springframework.context.annotation.ClassPathBeanDefinitionScanner;
/*     */ import org.springframework.context.annotation.ScopeMetadataResolver;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnnotationConfigReactiveWebServerApplicationContext
/*     */   extends ReactiveWebServerApplicationContext
/*     */   implements AnnotationConfigRegistry
/*     */ {
/*     */   private final AnnotatedBeanDefinitionReader reader;
/*     */   private final ClassPathBeanDefinitionScanner scanner;
/*  66 */   private final Set<Class<?>> annotatedClasses = new LinkedHashSet();
/*     */   
/*     */ 
/*     */ 
/*     */   private String[] basePackages;
/*     */   
/*     */ 
/*     */ 
/*     */   public AnnotationConfigReactiveWebServerApplicationContext()
/*     */   {
/*  76 */     this.reader = new AnnotatedBeanDefinitionReader(this);
/*  77 */     this.scanner = new ClassPathBeanDefinitionScanner(this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AnnotationConfigReactiveWebServerApplicationContext(DefaultListableBeanFactory beanFactory)
/*     */   {
/*  87 */     super(beanFactory);
/*  88 */     this.reader = new AnnotatedBeanDefinitionReader(this);
/*  89 */     this.scanner = new ClassPathBeanDefinitionScanner(this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AnnotationConfigReactiveWebServerApplicationContext(Class<?>... annotatedClasses)
/*     */   {
/* 100 */     this();
/* 101 */     register(annotatedClasses);
/* 102 */     refresh();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AnnotationConfigReactiveWebServerApplicationContext(String... basePackages)
/*     */   {
/* 112 */     this();
/* 113 */     scan(basePackages);
/* 114 */     refresh();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEnvironment(ConfigurableEnvironment environment)
/*     */   {
/* 125 */     super.setEnvironment(environment);
/* 126 */     this.reader.setEnvironment(environment);
/* 127 */     this.scanner.setEnvironment(environment);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBeanNameGenerator(BeanNameGenerator beanNameGenerator)
/*     */   {
/* 145 */     this.reader.setBeanNameGenerator(beanNameGenerator);
/* 146 */     this.scanner.setBeanNameGenerator(beanNameGenerator);
/* 147 */     getBeanFactory().registerSingleton("org.springframework.context.annotation.internalConfigurationBeanNameGenerator", beanNameGenerator);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setScopeMetadataResolver(ScopeMetadataResolver scopeMetadataResolver)
/*     */   {
/* 160 */     this.reader.setScopeMetadataResolver(scopeMetadataResolver);
/* 161 */     this.scanner.setScopeMetadataResolver(scopeMetadataResolver);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void register(Class<?>... annotatedClasses)
/*     */   {
/* 178 */     Assert.notEmpty(annotatedClasses, "At least one annotated class must be specified");
/* 179 */     this.annotatedClasses.addAll(Arrays.asList(annotatedClasses));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void scan(String... basePackages)
/*     */   {
/* 191 */     Assert.notEmpty(basePackages, "At least one base package must be specified");
/* 192 */     this.basePackages = basePackages;
/*     */   }
/*     */   
/*     */   protected void prepareRefresh()
/*     */   {
/* 197 */     this.scanner.clearCache();
/* 198 */     super.prepareRefresh();
/*     */   }
/*     */   
/*     */   protected void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory)
/*     */   {
/* 203 */     super.postProcessBeanFactory(beanFactory);
/* 204 */     if (!ObjectUtils.isEmpty(this.basePackages)) {
/* 205 */       this.scanner.scan(this.basePackages);
/*     */     }
/* 207 */     if (!this.annotatedClasses.isEmpty()) {
/* 208 */       this.reader.register(ClassUtils.toClassArray(this.annotatedClasses));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\web\reactive\context\AnnotationConfigReactiveWebServerApplicationContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */