package org.springframework.boot.env;

import org.springframework.boot.SpringApplication;
import org.springframework.core.env.ConfigurableEnvironment;

@FunctionalInterface
public abstract interface EnvironmentPostProcessor
{
  public abstract void postProcessEnvironment(ConfigurableEnvironment paramConfigurableEnvironment, SpringApplication paramSpringApplication);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\env\EnvironmentPostProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */