/*    */ package org.springframework.boot.context.event;
/*    */ 
/*    */ import org.springframework.boot.ConfigurableBootstrapContext;
/*    */ import org.springframework.boot.SpringApplication;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ApplicationStartingEvent
/*    */   extends SpringApplicationEvent
/*    */ {
/*    */   private final ConfigurableBootstrapContext bootstrapContext;
/*    */   
/*    */   @Deprecated
/*    */   public ApplicationStartingEvent(SpringApplication application, String[] args)
/*    */   {
/* 50 */     this(null, application, args);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ApplicationStartingEvent(ConfigurableBootstrapContext bootstrapContext, SpringApplication application, String[] args)
/*    */   {
/* 61 */     super(application, args);
/* 62 */     this.bootstrapContext = bootstrapContext;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ConfigurableBootstrapContext getBootstrapContext()
/*    */   {
/* 71 */     return this.bootstrapContext;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\context\event\ApplicationStartingEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */