/*    */ package org.springframework.boot.diagnostics.analyzer;
/*    */ 
/*    */ import org.springframework.beans.BeansException;
/*    */ import org.springframework.beans.factory.BeanFactory;
/*    */ import org.springframework.beans.factory.BeanFactoryAware;
/*    */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*    */ import org.springframework.beans.factory.NoUniqueBeanDefinitionException;
/*    */ import org.springframework.beans.factory.config.BeanDefinition;
/*    */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*    */ import org.springframework.boot.diagnostics.FailureAnalysis;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class NoUniqueBeanDefinitionFailureAnalyzer
/*    */   extends AbstractInjectionFailureAnalyzer<NoUniqueBeanDefinitionException>
/*    */   implements BeanFactoryAware
/*    */ {
/*    */   private ConfigurableBeanFactory beanFactory;
/*    */   
/*    */   public void setBeanFactory(BeanFactory beanFactory)
/*    */     throws BeansException
/*    */   {
/* 43 */     Assert.isInstanceOf(ConfigurableBeanFactory.class, beanFactory);
/* 44 */     this.beanFactory = ((ConfigurableBeanFactory)beanFactory);
/*    */   }
/*    */   
/*    */ 
/*    */   protected FailureAnalysis analyze(Throwable rootFailure, NoUniqueBeanDefinitionException cause, String description)
/*    */   {
/* 50 */     if (description == null) {
/* 51 */       return null;
/*    */     }
/* 53 */     String[] beanNames = extractBeanNames(cause);
/* 54 */     if (beanNames == null) {
/* 55 */       return null;
/*    */     }
/* 57 */     StringBuilder message = new StringBuilder();
/* 58 */     message.append(String.format("%s required a single bean, but %d were found:%n", new Object[] { description, Integer.valueOf(beanNames.length) }));
/* 59 */     for (String beanName : beanNames) {
/* 60 */       buildMessage(message, beanName);
/*    */     }
/* 62 */     return new FailureAnalysis(message.toString(), "Consider marking one of the beans as @Primary, updating the consumer to accept multiple beans, or using @Qualifier to identify the bean that should be consumed", cause);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   private void buildMessage(StringBuilder message, String beanName)
/*    */   {
/*    */     try
/*    */     {
/* 71 */       BeanDefinition definition = this.beanFactory.getMergedBeanDefinition(beanName);
/* 72 */       message.append(getDefinitionDescription(beanName, definition));
/*    */     }
/*    */     catch (NoSuchBeanDefinitionException ex) {
/* 75 */       message.append(String.format("\t- %s: a programmatically registered singleton", new Object[] { beanName }));
/*    */     }
/*    */   }
/*    */   
/*    */   private String getDefinitionDescription(String beanName, BeanDefinition definition) {
/* 80 */     if (StringUtils.hasText(definition.getFactoryMethodName())) {
/* 81 */       return String.format("\t- %s: defined by method '%s' in %s%n", new Object[] { beanName, definition.getFactoryMethodName(), definition
/* 82 */         .getResourceDescription() });
/*    */     }
/* 84 */     return String.format("\t- %s: defined in %s%n", new Object[] { beanName, definition.getResourceDescription() });
/*    */   }
/*    */   
/*    */   private String[] extractBeanNames(NoUniqueBeanDefinitionException cause) {
/* 88 */     if (cause.getMessage().contains("but found")) {
/* 89 */       return StringUtils.commaDelimitedListToStringArray(cause
/* 90 */         .getMessage().substring(cause.getMessage().lastIndexOf(':') + 1).trim());
/*    */     }
/* 92 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\diagnostics\analyzer\NoUniqueBeanDefinitionFailureAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */