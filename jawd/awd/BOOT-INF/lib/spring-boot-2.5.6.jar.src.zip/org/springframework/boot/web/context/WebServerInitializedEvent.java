/*    */ package org.springframework.boot.web.context;
/*    */ 
/*    */ import org.springframework.boot.web.server.WebServer;
/*    */ import org.springframework.context.ApplicationEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class WebServerInitializedEvent
/*    */   extends ApplicationEvent
/*    */ {
/*    */   protected WebServerInitializedEvent(WebServer webServer)
/*    */   {
/* 34 */     super(webServer);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public WebServer getWebServer()
/*    */   {
/* 42 */     return getSource();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public abstract WebServerApplicationContext getApplicationContext();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public WebServer getSource()
/*    */   {
/* 59 */     return (WebServer)super.getSource();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\web\context\WebServerInitializedEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */