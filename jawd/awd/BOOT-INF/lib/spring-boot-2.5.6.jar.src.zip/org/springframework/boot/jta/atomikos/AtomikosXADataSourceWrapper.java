/*    */ package org.springframework.boot.jta.atomikos;
/*    */ 
/*    */ import javax.sql.XADataSource;
/*    */ import org.springframework.boot.jdbc.XADataSourceWrapper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AtomikosXADataSourceWrapper
/*    */   implements XADataSourceWrapper
/*    */ {
/*    */   public AtomikosDataSourceBean wrapDataSource(XADataSource dataSource)
/*    */     throws Exception
/*    */   {
/* 34 */     AtomikosDataSourceBean bean = new AtomikosDataSourceBean();
/* 35 */     bean.setXaDataSource(dataSource);
/* 36 */     return bean;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\jta\atomikos\AtomikosXADataSourceWrapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */