package org.springframework.boot.web.reactive.context;

import org.springframework.core.env.ConfigurableEnvironment;

public abstract interface ConfigurableReactiveWebEnvironment
  extends ConfigurableEnvironment
{}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\web\reactive\context\ConfigurableReactiveWebEnvironment.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */