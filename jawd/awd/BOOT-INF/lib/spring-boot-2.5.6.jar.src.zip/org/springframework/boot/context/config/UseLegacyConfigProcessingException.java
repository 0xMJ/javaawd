/*    */ package org.springframework.boot.context.config;
/*    */ 
/*    */ import org.springframework.boot.context.properties.bind.BindContext;
/*    */ import org.springframework.boot.context.properties.bind.BindException;
/*    */ import org.springframework.boot.context.properties.bind.BindHandler;
/*    */ import org.springframework.boot.context.properties.bind.Bindable;
/*    */ import org.springframework.boot.context.properties.bind.Binder;
/*    */ import org.springframework.boot.context.properties.source.ConfigurationProperty;
/*    */ import org.springframework.boot.context.properties.source.ConfigurationPropertyName;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class UseLegacyConfigProcessingException
/*    */   extends ConfigDataException
/*    */ {
/* 39 */   static final ConfigurationPropertyName PROPERTY_NAME = ConfigurationPropertyName.of("spring.config.use-legacy-processing");
/*    */   
/* 41 */   private static final Bindable<Boolean> BOOLEAN = Bindable.of(Boolean.class);
/*    */   
/* 43 */   private static final UseLegacyProcessingBindHandler BIND_HANDLER = new UseLegacyProcessingBindHandler(null);
/*    */   private final ConfigurationProperty configurationProperty;
/*    */   
/*    */   UseLegacyConfigProcessingException(ConfigurationProperty configurationProperty)
/*    */   {
/* 48 */     super("Legacy processing requested from " + configurationProperty, null);
/* 49 */     this.configurationProperty = configurationProperty;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   ConfigurationProperty getConfigurationProperty()
/*    */   {
/* 58 */     return this.configurationProperty;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   static void throwIfRequested(Binder binder)
/*    */   {
/*    */     try
/*    */     {
/* 68 */       binder.bind(PROPERTY_NAME, BOOLEAN, BIND_HANDLER);
/*    */     }
/*    */     catch (BindException ex) {
/* 71 */       if ((ex.getCause() instanceof UseLegacyConfigProcessingException)) {
/* 72 */         throw ((UseLegacyConfigProcessingException)ex.getCause());
/*    */       }
/* 74 */       throw ex;
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   private static class UseLegacyProcessingBindHandler
/*    */     implements BindHandler
/*    */   {
/*    */     public Object onSuccess(ConfigurationPropertyName name, Bindable<?> target, BindContext context, Object result)
/*    */     {
/* 86 */       if (Boolean.TRUE.equals(result)) {
/* 87 */         throw new UseLegacyConfigProcessingException(context.getConfigurationProperty());
/*    */       }
/* 89 */       return result;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\context\config\UseLegacyConfigProcessingException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */