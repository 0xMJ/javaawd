/*    */ package org.springframework.boot.context.properties.bind.handler;
/*    */ 
/*    */ import org.springframework.boot.context.properties.bind.AbstractBindHandler;
/*    */ import org.springframework.boot.context.properties.bind.BindContext;
/*    */ import org.springframework.boot.context.properties.bind.BindHandler;
/*    */ import org.springframework.boot.context.properties.bind.Bindable;
/*    */ import org.springframework.boot.context.properties.source.ConfigurationPropertyName;
/*    */ import org.springframework.core.convert.ConverterNotFoundException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IgnoreTopLevelConverterNotFoundBindHandler
/*    */   extends AbstractBindHandler
/*    */ {
/*    */   public IgnoreTopLevelConverterNotFoundBindHandler() {}
/*    */   
/*    */   public IgnoreTopLevelConverterNotFoundBindHandler(BindHandler parent)
/*    */   {
/* 47 */     super(parent);
/*    */   }
/*    */   
/*    */   public Object onFailure(ConfigurationPropertyName name, Bindable<?> target, BindContext context, Exception error)
/*    */     throws Exception
/*    */   {
/* 53 */     if ((context.getDepth() == 0) && ((error instanceof ConverterNotFoundException))) {
/* 54 */       return null;
/*    */     }
/* 56 */     throw error;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\context\properties\bind\handler\IgnoreTopLevelConverterNotFoundBindHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */