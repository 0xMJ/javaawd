/*    */ package org.springframework.boot.context.properties.bind;
/*    */ 
/*    */ import org.springframework.boot.context.properties.source.ConfigurationPropertyName;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract interface BindHandler
/*    */ {
/* 34 */   public static final BindHandler DEFAULT = new BindHandler() {};
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public <T> Bindable<T> onStart(ConfigurationPropertyName name, Bindable<T> target, BindContext context)
/*    */   {
/* 47 */     return target;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Object onSuccess(ConfigurationPropertyName name, Bindable<?> target, BindContext context, Object result)
/*    */   {
/* 60 */     return result;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Object onCreate(ConfigurationPropertyName name, Bindable<?> target, BindContext context, Object result)
/*    */   {
/* 75 */     return result;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Object onFailure(ConfigurationPropertyName name, Bindable<?> target, BindContext context, Exception error)
/*    */     throws Exception
/*    */   {
/* 91 */     throw error;
/*    */   }
/*    */   
/*    */   public void onFinish(ConfigurationPropertyName name, Bindable<?> target, BindContext context, Object result)
/*    */     throws Exception
/*    */   {}
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\context\properties\bind\BindHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */