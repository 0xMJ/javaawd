package org.springframework.boot.admin;

public abstract interface SpringApplicationAdminMXBean
{
  public abstract boolean isReady();
  
  public abstract boolean isEmbeddedWebApplication();
  
  public abstract String getProperty(String paramString);
  
  public abstract void shutdown();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\admin\SpringApplicationAdminMXBean.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */