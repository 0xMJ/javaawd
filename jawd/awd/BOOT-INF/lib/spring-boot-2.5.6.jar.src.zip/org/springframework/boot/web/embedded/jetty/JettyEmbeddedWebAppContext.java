/*    */ package org.springframework.boot.web.embedded.jetty;
/*    */ 
/*    */ import org.eclipse.jetty.servlet.ServletHandler;
/*    */ import org.eclipse.jetty.webapp.WebAppContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class JettyEmbeddedWebAppContext
/*    */   extends WebAppContext
/*    */ {
/*    */   protected ServletHandler newServletHandler()
/*    */   {
/* 32 */     return new JettyEmbeddedServletHandler(null);
/*    */   }
/*    */   
/*    */   void deferredInitialize() throws Exception {
/* 36 */     ((JettyEmbeddedServletHandler)getServletHandler()).deferredInitialize();
/*    */   }
/*    */   
/*    */   private static class JettyEmbeddedServletHandler extends ServletHandler
/*    */   {
/*    */     public void initialize() throws Exception
/*    */     {}
/*    */     
/*    */     void deferredInitialize() throws Exception
/*    */     {
/* 46 */       super.initialize();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\web\embedded\jetty\JettyEmbeddedWebAppContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */