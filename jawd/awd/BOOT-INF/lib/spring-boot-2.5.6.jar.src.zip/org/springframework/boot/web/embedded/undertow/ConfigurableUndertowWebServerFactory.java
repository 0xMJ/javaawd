package org.springframework.boot.web.embedded.undertow;

import java.io.File;
import java.util.Collection;
import org.springframework.boot.web.server.ConfigurableWebServerFactory;

public abstract interface ConfigurableUndertowWebServerFactory
  extends ConfigurableWebServerFactory
{
  public abstract void setBuilderCustomizers(Collection<? extends UndertowBuilderCustomizer> paramCollection);
  
  public abstract void addBuilderCustomizers(UndertowBuilderCustomizer... paramVarArgs);
  
  public abstract void setBufferSize(Integer paramInteger);
  
  public abstract void setIoThreads(Integer paramInteger);
  
  public abstract void setWorkerThreads(Integer paramInteger);
  
  public abstract void setUseDirectBuffers(Boolean paramBoolean);
  
  public abstract void setAccessLogDirectory(File paramFile);
  
  public abstract void setAccessLogPattern(String paramString);
  
  public abstract void setAccessLogPrefix(String paramString);
  
  public abstract void setAccessLogSuffix(String paramString);
  
  public abstract void setAccessLogEnabled(boolean paramBoolean);
  
  public abstract void setAccessLogRotate(boolean paramBoolean);
  
  public abstract void setUseForwardHeaders(boolean paramBoolean);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\web\embedded\undertow\ConfigurableUndertowWebServerFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */