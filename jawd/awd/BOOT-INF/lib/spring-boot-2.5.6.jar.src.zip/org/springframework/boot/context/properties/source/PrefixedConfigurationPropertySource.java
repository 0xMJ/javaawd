/*    */ package org.springframework.boot.context.properties.source;
/*    */ 
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class PrefixedConfigurationPropertySource
/*    */   implements ConfigurationPropertySource
/*    */ {
/*    */   private final ConfigurationPropertySource source;
/*    */   private final ConfigurationPropertyName prefix;
/*    */   
/*    */   PrefixedConfigurationPropertySource(ConfigurationPropertySource source, String prefix)
/*    */   {
/* 33 */     Assert.notNull(source, "Source must not be null");
/* 34 */     Assert.hasText(prefix, "Prefix must not be empty");
/* 35 */     this.source = source;
/* 36 */     this.prefix = ConfigurationPropertyName.of(prefix);
/*    */   }
/*    */   
/*    */   protected final ConfigurationPropertyName getPrefix() {
/* 40 */     return this.prefix;
/*    */   }
/*    */   
/*    */   public ConfigurationProperty getConfigurationProperty(ConfigurationPropertyName name)
/*    */   {
/* 45 */     ConfigurationProperty configurationProperty = this.source.getConfigurationProperty(getPrefixedName(name));
/* 46 */     if (configurationProperty == null) {
/* 47 */       return null;
/*    */     }
/* 49 */     return ConfigurationProperty.of(name, configurationProperty.getValue(), configurationProperty.getOrigin());
/*    */   }
/*    */   
/*    */   private ConfigurationPropertyName getPrefixedName(ConfigurationPropertyName name) {
/* 53 */     return this.prefix.append(name);
/*    */   }
/*    */   
/*    */   public ConfigurationPropertyState containsDescendantOf(ConfigurationPropertyName name)
/*    */   {
/* 58 */     return this.source.containsDescendantOf(getPrefixedName(name));
/*    */   }
/*    */   
/*    */   public Object getUnderlyingSource()
/*    */   {
/* 63 */     return this.source.getUnderlyingSource();
/*    */   }
/*    */   
/*    */   protected ConfigurationPropertySource getSource() {
/* 67 */     return this.source;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\context\properties\source\PrefixedConfigurationPropertySource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */