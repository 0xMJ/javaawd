/*     */ package org.springframework.boot.web.embedded.undertow;
/*     */ 
/*     */ import io.undertow.Undertow.Builder;
/*     */ import java.io.InputStream;
/*     */ import java.net.InetAddress;
/*     */ import java.net.Socket;
/*     */ import java.net.URL;
/*     */ import java.security.GeneralSecurityException;
/*     */ import java.security.KeyManagementException;
/*     */ import java.security.KeyStore;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.Principal;
/*     */ import java.security.PrivateKey;
/*     */ import java.security.cert.X509Certificate;
/*     */ import javax.net.ssl.KeyManager;
/*     */ import javax.net.ssl.KeyManagerFactory;
/*     */ import javax.net.ssl.SSLContext;
/*     */ import javax.net.ssl.SSLEngine;
/*     */ import javax.net.ssl.TrustManager;
/*     */ import javax.net.ssl.TrustManagerFactory;
/*     */ import javax.net.ssl.X509ExtendedKeyManager;
/*     */ import org.springframework.boot.web.server.Ssl;
/*     */ import org.springframework.boot.web.server.Ssl.ClientAuth;
/*     */ import org.springframework.boot.web.server.SslConfigurationValidator;
/*     */ import org.springframework.boot.web.server.SslStoreProvider;
/*     */ import org.springframework.boot.web.server.WebServerException;
/*     */ import org.springframework.util.ResourceUtils;
/*     */ import org.xnio.Options;
/*     */ import org.xnio.Sequence;
/*     */ import org.xnio.SslClientAuthMode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SslBuilderCustomizer
/*     */   implements UndertowBuilderCustomizer
/*     */ {
/*     */   private final int port;
/*     */   private final InetAddress address;
/*     */   private final Ssl ssl;
/*     */   private final SslStoreProvider sslStoreProvider;
/*     */   
/*     */   SslBuilderCustomizer(int port, InetAddress address, Ssl ssl, SslStoreProvider sslStoreProvider)
/*     */   {
/*  66 */     this.port = port;
/*  67 */     this.address = address;
/*  68 */     this.ssl = ssl;
/*  69 */     this.sslStoreProvider = sslStoreProvider;
/*     */   }
/*     */   
/*     */   public void customize(Undertow.Builder builder)
/*     */   {
/*     */     try {
/*  75 */       SSLContext sslContext = SSLContext.getInstance(this.ssl.getProtocol());
/*  76 */       sslContext.init(getKeyManagers(this.ssl, this.sslStoreProvider), 
/*  77 */         getTrustManagers(this.ssl, this.sslStoreProvider), null);
/*  78 */       builder.addHttpsListener(this.port, getListenAddress(), sslContext);
/*  79 */       builder.setSocketOption(Options.SSL_CLIENT_AUTH_MODE, getSslClientAuthMode(this.ssl));
/*  80 */       if (this.ssl.getEnabledProtocols() != null) {
/*  81 */         builder.setSocketOption(Options.SSL_ENABLED_PROTOCOLS, Sequence.of(this.ssl.getEnabledProtocols()));
/*     */       }
/*  83 */       if (this.ssl.getCiphers() != null) {
/*  84 */         builder.setSocketOption(Options.SSL_ENABLED_CIPHER_SUITES, Sequence.of(this.ssl.getCiphers()));
/*     */       }
/*     */     }
/*     */     catch (NoSuchAlgorithmException|KeyManagementException ex) {
/*  88 */       throw new IllegalStateException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */   private String getListenAddress() {
/*  93 */     if (this.address == null) {
/*  94 */       return "0.0.0.0";
/*     */     }
/*  96 */     return this.address.getHostAddress();
/*     */   }
/*     */   
/*     */   private SslClientAuthMode getSslClientAuthMode(Ssl ssl) {
/* 100 */     if (ssl.getClientAuth() == Ssl.ClientAuth.NEED) {
/* 101 */       return SslClientAuthMode.REQUIRED;
/*     */     }
/* 103 */     if (ssl.getClientAuth() == Ssl.ClientAuth.WANT) {
/* 104 */       return SslClientAuthMode.REQUESTED;
/*     */     }
/* 106 */     return SslClientAuthMode.NOT_REQUESTED;
/*     */   }
/*     */   
/*     */   private KeyManager[] getKeyManagers(Ssl ssl, SslStoreProvider sslStoreProvider) {
/*     */     try {
/* 111 */       KeyStore keyStore = getKeyStore(ssl, sslStoreProvider);
/* 112 */       SslConfigurationValidator.validateKeyAlias(keyStore, ssl.getKeyAlias());
/*     */       
/* 114 */       KeyManagerFactory keyManagerFactory = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
/* 115 */       char[] keyPassword = ssl.getKeyPassword() != null ? ssl.getKeyPassword().toCharArray() : null;
/* 116 */       if ((keyPassword == null) && (ssl.getKeyStorePassword() != null)) {
/* 117 */         keyPassword = ssl.getKeyStorePassword().toCharArray();
/*     */       }
/* 119 */       keyManagerFactory.init(keyStore, keyPassword);
/* 120 */       if (ssl.getKeyAlias() != null) {
/* 121 */         return getConfigurableAliasKeyManagers(ssl, keyManagerFactory.getKeyManagers());
/*     */       }
/* 123 */       return keyManagerFactory.getKeyManagers();
/*     */     }
/*     */     catch (Exception ex) {
/* 126 */       throw new IllegalStateException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */   private KeyManager[] getConfigurableAliasKeyManagers(Ssl ssl, KeyManager[] keyManagers) {
/* 131 */     for (int i = 0; i < keyManagers.length; i++) {
/* 132 */       if ((keyManagers[i] instanceof X509ExtendedKeyManager))
/*     */       {
/* 134 */         keyManagers[i] = new ConfigurableAliasKeyManager((X509ExtendedKeyManager)keyManagers[i], ssl.getKeyAlias());
/*     */       }
/*     */     }
/* 137 */     return keyManagers;
/*     */   }
/*     */   
/*     */   private KeyStore getKeyStore(Ssl ssl, SslStoreProvider sslStoreProvider) throws Exception {
/* 141 */     if (sslStoreProvider != null) {
/* 142 */       return sslStoreProvider.getKeyStore();
/*     */     }
/* 144 */     return loadKeyStore(ssl.getKeyStoreType(), ssl.getKeyStoreProvider(), ssl.getKeyStore(), ssl
/* 145 */       .getKeyStorePassword());
/*     */   }
/*     */   
/*     */   private TrustManager[] getTrustManagers(Ssl ssl, SslStoreProvider sslStoreProvider) {
/*     */     try {
/* 150 */       KeyStore store = getTrustStore(ssl, sslStoreProvider);
/*     */       
/* 152 */       TrustManagerFactory trustManagerFactory = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
/* 153 */       trustManagerFactory.init(store);
/* 154 */       return trustManagerFactory.getTrustManagers();
/*     */     }
/*     */     catch (Exception ex) {
/* 157 */       throw new IllegalStateException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */   private KeyStore getTrustStore(Ssl ssl, SslStoreProvider sslStoreProvider) throws Exception {
/* 162 */     if (sslStoreProvider != null) {
/* 163 */       return sslStoreProvider.getTrustStore();
/*     */     }
/* 165 */     return loadTrustStore(ssl.getTrustStoreType(), ssl.getTrustStoreProvider(), ssl.getTrustStore(), ssl
/* 166 */       .getTrustStorePassword());
/*     */   }
/*     */   
/*     */   private KeyStore loadKeyStore(String type, String provider, String resource, String password) throws Exception {
/* 170 */     return loadStore(type, provider, resource, password);
/*     */   }
/*     */   
/*     */   private KeyStore loadTrustStore(String type, String provider, String resource, String password) throws Exception {
/* 174 */     if (resource == null) {
/* 175 */       return null;
/*     */     }
/* 177 */     return loadStore(type, provider, resource, password);
/*     */   }
/*     */   
/*     */   private KeyStore loadStore(String type, String provider, String resource, String password) throws Exception {
/* 181 */     type = type != null ? type : "JKS";
/* 182 */     KeyStore store = provider != null ? KeyStore.getInstance(type, provider) : KeyStore.getInstance(type);
/*     */     try {
/* 184 */       URL url = ResourceUtils.getURL(resource);
/* 185 */       InputStream stream = url.openStream();Throwable localThrowable3 = null;
/* 186 */       try { store.load(stream, password != null ? password.toCharArray() : null);
/*     */       }
/*     */       catch (Throwable localThrowable1)
/*     */       {
/* 185 */         localThrowable3 = localThrowable1;throw localThrowable1;
/*     */       } finally {
/* 187 */         if (stream != null) if (localThrowable3 != null) try { stream.close(); } catch (Throwable localThrowable2) { localThrowable3.addSuppressed(localThrowable2); } else stream.close(); }
/* 188 */       return store;
/*     */     }
/*     */     catch (Exception ex) {
/* 191 */       throw new WebServerException("Could not load key store '" + resource + "'", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static class ConfigurableAliasKeyManager
/*     */     extends X509ExtendedKeyManager
/*     */   {
/*     */     private final X509ExtendedKeyManager keyManager;
/*     */     
/*     */     private final String alias;
/*     */     
/*     */     ConfigurableAliasKeyManager(X509ExtendedKeyManager keyManager, String alias)
/*     */     {
/* 205 */       this.keyManager = keyManager;
/* 206 */       this.alias = alias;
/*     */     }
/*     */     
/*     */     public String chooseEngineClientAlias(String[] strings, Principal[] principals, SSLEngine sslEngine)
/*     */     {
/* 211 */       return this.keyManager.chooseEngineClientAlias(strings, principals, sslEngine);
/*     */     }
/*     */     
/*     */     public String chooseEngineServerAlias(String s, Principal[] principals, SSLEngine sslEngine)
/*     */     {
/* 216 */       if (this.alias == null) {
/* 217 */         return this.keyManager.chooseEngineServerAlias(s, principals, sslEngine);
/*     */       }
/* 219 */       return this.alias;
/*     */     }
/*     */     
/*     */     public String chooseClientAlias(String[] keyType, Principal[] issuers, Socket socket)
/*     */     {
/* 224 */       return this.keyManager.chooseClientAlias(keyType, issuers, socket);
/*     */     }
/*     */     
/*     */     public String chooseServerAlias(String keyType, Principal[] issuers, Socket socket)
/*     */     {
/* 229 */       return this.keyManager.chooseServerAlias(keyType, issuers, socket);
/*     */     }
/*     */     
/*     */     public X509Certificate[] getCertificateChain(String alias)
/*     */     {
/* 234 */       return this.keyManager.getCertificateChain(alias);
/*     */     }
/*     */     
/*     */     public String[] getClientAliases(String keyType, Principal[] issuers)
/*     */     {
/* 239 */       return this.keyManager.getClientAliases(keyType, issuers);
/*     */     }
/*     */     
/*     */     public PrivateKey getPrivateKey(String alias)
/*     */     {
/* 244 */       return this.keyManager.getPrivateKey(alias);
/*     */     }
/*     */     
/*     */     public String[] getServerAliases(String keyType, Principal[] issuers)
/*     */     {
/* 249 */       return this.keyManager.getServerAliases(keyType, issuers);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\web\embedded\undertow\SslBuilderCustomizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */