/*     */ package org.springframework.boot.diagnostics.analyzer;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.net.URL;
/*     */ import java.security.CodeSource;
/*     */ import java.security.ProtectionDomain;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.springframework.boot.diagnostics.AbstractFailureAnalyzer;
/*     */ import org.springframework.boot.diagnostics.FailureAnalysis;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class NoSuchMethodFailureAnalyzer
/*     */   extends AbstractFailureAnalyzer<NoSuchMethodError>
/*     */ {
/*     */   protected FailureAnalysis analyze(Throwable rootFailure, NoSuchMethodError cause)
/*     */   {
/*  41 */     NoSuchMethodDescriptor descriptor = getNoSuchMethodDescriptor(cause.getMessage());
/*  42 */     if (descriptor == null) {
/*  43 */       return null;
/*     */     }
/*  45 */     String description = getDescription(cause, descriptor);
/*  46 */     return new FailureAnalysis(description, "Correct the classpath of your application so that it contains a single, compatible version of " + descriptor
/*     */     
/*  48 */       .getClassName(), cause);
/*     */   }
/*     */   
/*     */   protected NoSuchMethodDescriptor getNoSuchMethodDescriptor(String cause)
/*     */   {
/*  53 */     String message = cleanMessage(cause);
/*  54 */     String className = extractClassName(message);
/*  55 */     if (className == null) {
/*  56 */       return null;
/*     */     }
/*  58 */     List<URL> candidates = findCandidates(className);
/*  59 */     if (candidates == null) {
/*  60 */       return null;
/*     */     }
/*  62 */     Class<?> type = load(className);
/*  63 */     if (type == null) {
/*  64 */       return null;
/*     */     }
/*  66 */     List<ClassDescriptor> typeHierarchy = getTypeHierarchy(type);
/*  67 */     if (typeHierarchy == null) {
/*  68 */       return null;
/*     */     }
/*  70 */     return new NoSuchMethodDescriptor(message, className, candidates, typeHierarchy);
/*     */   }
/*     */   
/*     */   private String cleanMessage(String message) {
/*  74 */     int loadedFromIndex = message.indexOf(" (loaded from");
/*  75 */     if (loadedFromIndex == -1) {
/*  76 */       return message;
/*     */     }
/*  78 */     return message.substring(0, loadedFromIndex);
/*     */   }
/*     */   
/*     */   private String extractClassName(String message) {
/*  82 */     if ((message.startsWith("'")) && (message.endsWith("'"))) {
/*  83 */       int splitIndex = message.indexOf(' ');
/*  84 */       if (splitIndex == -1) {
/*  85 */         return null;
/*     */       }
/*  87 */       message = message.substring(splitIndex + 1);
/*     */     }
/*  89 */     int descriptorIndex = message.indexOf('(');
/*  90 */     if (descriptorIndex == -1) {
/*  91 */       return null;
/*     */     }
/*  93 */     String classAndMethodName = message.substring(0, descriptorIndex);
/*  94 */     int methodNameIndex = classAndMethodName.lastIndexOf('.');
/*  95 */     if (methodNameIndex == -1) {
/*  96 */       return null;
/*     */     }
/*  98 */     String className = classAndMethodName.substring(0, methodNameIndex);
/*  99 */     return className.replace('/', '.');
/*     */   }
/*     */   
/*     */   private List<URL> findCandidates(String className) {
/*     */     try {
/* 104 */       return Collections.list(NoSuchMethodFailureAnalyzer.class.getClassLoader()
/* 105 */         .getResources(ClassUtils.convertClassNameToResourcePath(className) + ".class"));
/*     */     }
/*     */     catch (Throwable ex) {}
/* 108 */     return null;
/*     */   }
/*     */   
/*     */   private Class<?> load(String className)
/*     */   {
/*     */     try {
/* 114 */       return Class.forName(className, false, getClass().getClassLoader());
/*     */     }
/*     */     catch (Throwable ex) {}
/* 117 */     return null;
/*     */   }
/*     */   
/*     */   private List<ClassDescriptor> getTypeHierarchy(Class<?> type)
/*     */   {
/*     */     try {
/* 123 */       List<ClassDescriptor> typeHierarchy = new ArrayList();
/* 124 */       while ((type != null) && (!type.equals(Object.class))) {
/* 125 */         typeHierarchy.add(new ClassDescriptor(type.getCanonicalName(), type
/* 126 */           .getProtectionDomain().getCodeSource().getLocation()));
/* 127 */         type = type.getSuperclass();
/*     */       }
/* 129 */       return typeHierarchy;
/*     */     }
/*     */     catch (Throwable ex) {}
/* 132 */     return null;
/*     */   }
/*     */   
/*     */   private String getDescription(NoSuchMethodError cause, NoSuchMethodDescriptor descriptor)
/*     */   {
/* 137 */     StringWriter description = new StringWriter();
/* 138 */     PrintWriter writer = new PrintWriter(description);
/* 139 */     writer.println("An attempt was made to call a method that does not exist. The attempt was made from the following location:");
/*     */     
/* 141 */     writer.println();
/* 142 */     writer.print("    ");
/* 143 */     writer.println(cause.getStackTrace()[0]);
/* 144 */     writer.println();
/* 145 */     writer.println("The following method did not exist:");
/* 146 */     writer.println();
/* 147 */     writer.print("    ");
/* 148 */     writer.println(descriptor.getErrorMessage());
/* 149 */     writer.println();
/* 150 */     writer.println("The method's class, " + descriptor
/* 151 */       .getClassName() + ", is available from the following locations:");
/* 152 */     writer.println();
/* 153 */     for (URL candidate : descriptor.getCandidateLocations()) {
/* 154 */       writer.print("    ");
/* 155 */       writer.println(candidate);
/*     */     }
/* 157 */     writer.println();
/* 158 */     writer.println("The class hierarchy was loaded from the following locations:");
/* 159 */     writer.println();
/* 160 */     for (ClassDescriptor type : descriptor.getTypeHierarchy()) {
/* 161 */       writer.print("    ");
/* 162 */       writer.print(type.getName());
/* 163 */       writer.print(": ");
/* 164 */       writer.println(type.getLocation());
/*     */     }
/*     */     
/* 167 */     return description.toString();
/*     */   }
/*     */   
/*     */ 
/*     */   protected static class NoSuchMethodDescriptor
/*     */   {
/*     */     private final String errorMessage;
/*     */     
/*     */     private final String className;
/*     */     
/*     */     private final List<URL> candidateLocations;
/*     */     private final List<NoSuchMethodFailureAnalyzer.ClassDescriptor> typeHierarchy;
/*     */     
/*     */     public NoSuchMethodDescriptor(String errorMessage, String className, List<URL> candidateLocations, List<NoSuchMethodFailureAnalyzer.ClassDescriptor> typeHierarchy)
/*     */     {
/* 182 */       this.errorMessage = errorMessage;
/* 183 */       this.className = className;
/* 184 */       this.candidateLocations = candidateLocations;
/* 185 */       this.typeHierarchy = typeHierarchy;
/*     */     }
/*     */     
/*     */     public String getErrorMessage() {
/* 189 */       return this.errorMessage;
/*     */     }
/*     */     
/*     */     public String getClassName() {
/* 193 */       return this.className;
/*     */     }
/*     */     
/*     */     public List<URL> getCandidateLocations() {
/* 197 */       return this.candidateLocations;
/*     */     }
/*     */     
/*     */     public List<NoSuchMethodFailureAnalyzer.ClassDescriptor> getTypeHierarchy() {
/* 201 */       return this.typeHierarchy;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected static class ClassDescriptor
/*     */   {
/*     */     private final String name;
/*     */     private final URL location;
/*     */     
/*     */     public ClassDescriptor(String name, URL location)
/*     */     {
/* 213 */       this.name = name;
/* 214 */       this.location = location;
/*     */     }
/*     */     
/*     */     public String getName() {
/* 218 */       return this.name;
/*     */     }
/*     */     
/*     */     public URL getLocation() {
/* 222 */       return this.location;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\diagnostics\analyzer\NoSuchMethodFailureAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */