/*    */ package org.springframework.boot.convert;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import org.springframework.core.convert.converter.Converter;
/*    */ import org.springframework.core.io.DefaultResourceLoader;
/*    */ import org.springframework.core.io.Resource;
/*    */ import org.springframework.core.io.ResourceLoader;
/*    */ import org.springframework.util.ResourceUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class StringToFileConverter
/*    */   implements Converter<String, File>
/*    */ {
/* 36 */   private static final ResourceLoader resourceLoader = new DefaultResourceLoader(null);
/*    */   
/*    */   public File convert(String source)
/*    */   {
/* 40 */     if (ResourceUtils.isUrl(source)) {
/* 41 */       return getFile(resourceLoader.getResource(source));
/*    */     }
/* 43 */     File file = new File(source);
/* 44 */     if (file.exists()) {
/* 45 */       return file;
/*    */     }
/* 47 */     Resource resource = resourceLoader.getResource(source);
/* 48 */     if (resource.exists()) {
/* 49 */       return getFile(resource);
/*    */     }
/* 51 */     return file;
/*    */   }
/*    */   
/*    */   private File getFile(Resource resource) {
/*    */     try {
/* 56 */       return resource.getFile();
/*    */     }
/*    */     catch (IOException ex) {
/* 59 */       throw new IllegalStateException("Could not retrieve file for " + resource + ": " + ex.getMessage());
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\convert\StringToFileConverter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */