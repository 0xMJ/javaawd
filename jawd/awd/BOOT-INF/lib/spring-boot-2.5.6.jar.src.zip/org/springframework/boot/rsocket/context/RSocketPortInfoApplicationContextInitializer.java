/*    */ package org.springframework.boot.rsocket.context;
/*    */ 
/*    */ import java.net.InetSocketAddress;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.springframework.boot.rsocket.server.RSocketServer;
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.context.ApplicationContextInitializer;
/*    */ import org.springframework.context.ApplicationListener;
/*    */ import org.springframework.context.ConfigurableApplicationContext;
/*    */ import org.springframework.core.env.ConfigurableEnvironment;
/*    */ import org.springframework.core.env.MapPropertySource;
/*    */ import org.springframework.core.env.MutablePropertySources;
/*    */ import org.springframework.core.env.PropertySource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RSocketPortInfoApplicationContextInitializer
/*    */   implements ApplicationContextInitializer<ConfigurableApplicationContext>
/*    */ {
/*    */   public void initialize(ConfigurableApplicationContext applicationContext)
/*    */   {
/* 51 */     applicationContext.addApplicationListener(new Listener(applicationContext));
/*    */   }
/*    */   
/*    */   private static class Listener implements ApplicationListener<RSocketServerInitializedEvent>
/*    */   {
/*    */     private static final String PROPERTY_NAME = "local.rsocket.server.port";
/*    */     private final ConfigurableApplicationContext applicationContext;
/*    */     
/*    */     Listener(ConfigurableApplicationContext applicationContext)
/*    */     {
/* 61 */       this.applicationContext = applicationContext;
/*    */     }
/*    */     
/*    */     public void onApplicationEvent(RSocketServerInitializedEvent event)
/*    */     {
/* 66 */       if (event.getServer().address() != null) {
/* 67 */         setPortProperty(this.applicationContext, event.getServer().address().getPort());
/*    */       }
/*    */     }
/*    */     
/*    */     private void setPortProperty(ApplicationContext context, int port) {
/* 72 */       if ((context instanceof ConfigurableApplicationContext)) {
/* 73 */         setPortProperty(((ConfigurableApplicationContext)context).getEnvironment(), port);
/*    */       }
/* 75 */       if (context.getParent() != null) {
/* 76 */         setPortProperty(context.getParent(), port);
/*    */       }
/*    */     }
/*    */     
/*    */     private void setPortProperty(ConfigurableEnvironment environment, int port) {
/* 81 */       MutablePropertySources sources = environment.getPropertySources();
/* 82 */       PropertySource<?> source = sources.get("server.ports");
/* 83 */       if (source == null) {
/* 84 */         source = new MapPropertySource("server.ports", new HashMap());
/* 85 */         sources.addFirst(source);
/*    */       }
/* 87 */       setPortProperty(port, source);
/*    */     }
/*    */     
/*    */     private void setPortProperty(int port, PropertySource<?> source)
/*    */     {
/* 92 */       ((Map)source.getSource()).put("local.rsocket.server.port", Integer.valueOf(port));
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\rsocket\context\RSocketPortInfoApplicationContextInitializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */