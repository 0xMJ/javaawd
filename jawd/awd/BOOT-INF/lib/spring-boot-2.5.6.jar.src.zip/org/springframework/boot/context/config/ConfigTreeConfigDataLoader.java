/*    */ package org.springframework.boot.context.config;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.nio.file.Path;
/*    */ import java.util.Collections;
/*    */ import org.springframework.boot.env.ConfigTreePropertySource;
/*    */ import org.springframework.boot.env.ConfigTreePropertySource.Option;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConfigTreeConfigDataLoader
/*    */   implements ConfigDataLoader<ConfigTreeConfigDataResource>
/*    */ {
/*    */   public ConfigData load(ConfigDataLoaderContext context, ConfigTreeConfigDataResource resource)
/*    */     throws IOException, ConfigDataResourceNotFoundException
/*    */   {
/* 38 */     Path path = resource.getPath();
/* 39 */     ConfigDataResourceNotFoundException.throwIfDoesNotExist(resource, path);
/* 40 */     String name = "Config tree '" + path + "'";
/* 41 */     ConfigTreePropertySource source = new ConfigTreePropertySource(name, path, new ConfigTreePropertySource.Option[] { ConfigTreePropertySource.Option.AUTO_TRIM_TRAILING_NEW_LINE });
/* 42 */     return new ConfigData(Collections.singletonList(source), new ConfigData.Option[0]);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\context\config\ConfigTreeConfigDataLoader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */