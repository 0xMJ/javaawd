package org.springframework.boot.context.properties.bind;

import org.springframework.boot.context.properties.source.ConfigurationProperty;
import org.springframework.boot.context.properties.source.ConfigurationPropertySource;

public abstract interface BindContext
{
  public abstract Binder getBinder();
  
  public abstract int getDepth();
  
  public abstract Iterable<ConfigurationPropertySource> getSources();
  
  public abstract ConfigurationProperty getConfigurationProperty();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\context\properties\bind\BindContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */