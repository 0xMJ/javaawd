package org.springframework.boot.diagnostics;

@FunctionalInterface
public abstract interface FailureAnalysisReporter
{
  public abstract void report(FailureAnalysis paramFailureAnalysis);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\diagnostics\FailureAnalysisReporter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */