/*     */ package org.springframework.boot.context.properties.source;
/*     */ 
/*     */ import java.lang.ref.SoftReference;
/*     */ import java.time.Duration;
/*     */ import java.time.Instant;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.function.UnaryOperator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SoftReferenceConfigurationPropertyCache<T>
/*     */   implements ConfigurationPropertyCaching
/*     */ {
/*  34 */   private static final Duration UNLIMITED = Duration.ZERO;
/*     */   
/*     */   private final boolean neverExpire;
/*     */   
/*     */   private volatile Duration timeToLive;
/*     */   
/*  40 */   private volatile SoftReference<T> value = new SoftReference(null);
/*     */   
/*  42 */   private volatile Instant lastAccessed = now();
/*     */   
/*     */   SoftReferenceConfigurationPropertyCache(boolean neverExpire) {
/*  45 */     this.neverExpire = neverExpire;
/*     */   }
/*     */   
/*     */   public void enable()
/*     */   {
/*  50 */     this.timeToLive = UNLIMITED;
/*     */   }
/*     */   
/*     */   public void disable()
/*     */   {
/*  55 */     this.timeToLive = null;
/*     */   }
/*     */   
/*     */   public void setTimeToLive(Duration timeToLive)
/*     */   {
/*  60 */     this.timeToLive = ((timeToLive == null) || (timeToLive.isZero()) ? null : timeToLive);
/*     */   }
/*     */   
/*     */   public void clear()
/*     */   {
/*  65 */     this.lastAccessed = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   T get(Supplier<T> factory, UnaryOperator<T> refreshAction)
/*     */   {
/*  75 */     T value = getValue();
/*  76 */     if (value == null) {
/*  77 */       value = refreshAction.apply(factory.get());
/*  78 */       setValue(value);
/*     */     }
/*  80 */     else if (hasExpired()) {
/*  81 */       value = refreshAction.apply(value);
/*  82 */       setValue(value);
/*     */     }
/*  84 */     if (!this.neverExpire) {
/*  85 */       this.lastAccessed = now();
/*     */     }
/*  87 */     return value;
/*     */   }
/*     */   
/*     */   private boolean hasExpired() {
/*  91 */     if (this.neverExpire) {
/*  92 */       return false;
/*     */     }
/*  94 */     Duration timeToLive = this.timeToLive;
/*  95 */     Instant lastAccessed = this.lastAccessed;
/*  96 */     if ((timeToLive == null) || (lastAccessed == null)) {
/*  97 */       return true;
/*     */     }
/*  99 */     return (!UNLIMITED.equals(timeToLive)) && (now().isAfter(lastAccessed.plus(timeToLive)));
/*     */   }
/*     */   
/*     */   protected Instant now() {
/* 103 */     return Instant.now();
/*     */   }
/*     */   
/*     */   protected T getValue() {
/* 107 */     return (T)this.value.get();
/*     */   }
/*     */   
/*     */   protected void setValue(T value) {
/* 111 */     this.value = new SoftReference(value);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\context\properties\source\SoftReferenceConfigurationPropertyCache.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */