/*     */ package org.springframework.boot.convert;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.springframework.beans.factory.ListableBeanFactory;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.core.convert.converter.Converter;
/*     */ import org.springframework.core.convert.converter.ConverterFactory;
/*     */ import org.springframework.core.convert.converter.ConverterRegistry;
/*     */ import org.springframework.core.convert.converter.GenericConverter;
/*     */ import org.springframework.core.convert.converter.GenericConverter.ConvertiblePair;
/*     */ import org.springframework.core.convert.support.DefaultConversionService;
/*     */ import org.springframework.format.AnnotationFormatterFactory;
/*     */ import org.springframework.format.Formatter;
/*     */ import org.springframework.format.FormatterRegistry;
/*     */ import org.springframework.format.Parser;
/*     */ import org.springframework.format.Printer;
/*     */ import org.springframework.format.support.DefaultFormattingConversionService;
/*     */ import org.springframework.format.support.FormattingConversionService;
/*     */ import org.springframework.util.StringValueResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ApplicationConversionService
/*     */   extends FormattingConversionService
/*     */ {
/*     */   private static volatile ApplicationConversionService sharedInstance;
/*     */   private final boolean unmodifiable;
/*     */   
/*     */   public ApplicationConversionService()
/*     */   {
/*  61 */     this(null);
/*     */   }
/*     */   
/*     */   public ApplicationConversionService(StringValueResolver embeddedValueResolver) {
/*  65 */     this(embeddedValueResolver, false);
/*     */   }
/*     */   
/*     */   private ApplicationConversionService(StringValueResolver embeddedValueResolver, boolean unmodifiable) {
/*  69 */     if (embeddedValueResolver != null) {
/*  70 */       setEmbeddedValueResolver(embeddedValueResolver);
/*     */     }
/*  72 */     configure(this);
/*  73 */     this.unmodifiable = unmodifiable;
/*     */   }
/*     */   
/*     */   public void addPrinter(Printer<?> printer)
/*     */   {
/*  78 */     assertModifiable();
/*  79 */     super.addPrinter(printer);
/*     */   }
/*     */   
/*     */   public void addParser(Parser<?> parser)
/*     */   {
/*  84 */     assertModifiable();
/*  85 */     super.addParser(parser);
/*     */   }
/*     */   
/*     */   public void addFormatter(Formatter<?> formatter)
/*     */   {
/*  90 */     assertModifiable();
/*  91 */     super.addFormatter(formatter);
/*     */   }
/*     */   
/*     */   public void addFormatterForFieldType(Class<?> fieldType, Formatter<?> formatter)
/*     */   {
/*  96 */     assertModifiable();
/*  97 */     super.addFormatterForFieldType(fieldType, formatter);
/*     */   }
/*     */   
/*     */   public void addConverter(Converter<?, ?> converter)
/*     */   {
/* 102 */     assertModifiable();
/* 103 */     super.addConverter(converter);
/*     */   }
/*     */   
/*     */   public void addFormatterForFieldType(Class<?> fieldType, Printer<?> printer, Parser<?> parser)
/*     */   {
/* 108 */     assertModifiable();
/* 109 */     super.addFormatterForFieldType(fieldType, printer, parser);
/*     */   }
/*     */   
/*     */ 
/*     */   public void addFormatterForFieldAnnotation(AnnotationFormatterFactory<? extends Annotation> annotationFormatterFactory)
/*     */   {
/* 115 */     assertModifiable();
/* 116 */     super.addFormatterForFieldAnnotation(annotationFormatterFactory);
/*     */   }
/*     */   
/*     */ 
/*     */   public <S, T> void addConverter(Class<S> sourceType, Class<T> targetType, Converter<? super S, ? extends T> converter)
/*     */   {
/* 122 */     assertModifiable();
/* 123 */     super.addConverter(sourceType, targetType, converter);
/*     */   }
/*     */   
/*     */   public void addConverter(GenericConverter converter)
/*     */   {
/* 128 */     assertModifiable();
/* 129 */     super.addConverter(converter);
/*     */   }
/*     */   
/*     */   public void addConverterFactory(ConverterFactory<?, ?> factory)
/*     */   {
/* 134 */     assertModifiable();
/* 135 */     super.addConverterFactory(factory);
/*     */   }
/*     */   
/*     */   public void removeConvertible(Class<?> sourceType, Class<?> targetType)
/*     */   {
/* 140 */     assertModifiable();
/* 141 */     super.removeConvertible(sourceType, targetType);
/*     */   }
/*     */   
/*     */   private void assertModifiable() {
/* 145 */     if (this.unmodifiable) {
/* 146 */       throw new UnsupportedOperationException("This ApplicationConversionService cannot be modified");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isConvertViaObjectSourceType(TypeDescriptor sourceType, TypeDescriptor targetType)
/*     */   {
/* 160 */     GenericConverter converter = getConverter(sourceType, targetType);
/* 161 */     Set<GenericConverter.ConvertiblePair> pairs = converter != null ? converter.getConvertibleTypes() : null;
/* 162 */     if (pairs != null) {
/* 163 */       for (GenericConverter.ConvertiblePair pair : pairs) {
/* 164 */         if (Object.class.equals(pair.getSourceType())) {
/* 165 */           return true;
/*     */         }
/*     */       }
/*     */     }
/* 169 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ConversionService getSharedInstance()
/*     */   {
/* 183 */     ApplicationConversionService sharedInstance = sharedInstance;
/* 184 */     if (sharedInstance == null) {
/* 185 */       synchronized (ApplicationConversionService.class) {
/* 186 */         sharedInstance = sharedInstance;
/* 187 */         if (sharedInstance == null) {
/* 188 */           sharedInstance = new ApplicationConversionService(null, true);
/* 189 */           sharedInstance = sharedInstance;
/*     */         }
/*     */       }
/*     */     }
/* 193 */     return sharedInstance;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void configure(FormatterRegistry registry)
/*     */   {
/* 205 */     DefaultConversionService.addDefaultConverters(registry);
/* 206 */     DefaultFormattingConversionService.addDefaultFormatters(registry);
/* 207 */     addApplicationFormatters(registry);
/* 208 */     addApplicationConverters(registry);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void addApplicationConverters(ConverterRegistry registry)
/*     */   {
/* 219 */     addDelimitedStringConverters(registry);
/* 220 */     registry.addConverter(new StringToDurationConverter());
/* 221 */     registry.addConverter(new DurationToStringConverter());
/* 222 */     registry.addConverter(new NumberToDurationConverter());
/* 223 */     registry.addConverter(new DurationToNumberConverter());
/* 224 */     registry.addConverter(new StringToPeriodConverter());
/* 225 */     registry.addConverter(new PeriodToStringConverter());
/* 226 */     registry.addConverter(new NumberToPeriodConverter());
/* 227 */     registry.addConverter(new StringToDataSizeConverter());
/* 228 */     registry.addConverter(new NumberToDataSizeConverter());
/* 229 */     registry.addConverter(new StringToFileConverter());
/* 230 */     registry.addConverter(new InputStreamSourceToByteArrayConverter());
/* 231 */     registry.addConverterFactory(new LenientStringToEnumConverterFactory());
/* 232 */     registry.addConverterFactory(new LenientBooleanToEnumConverterFactory());
/* 233 */     if ((registry instanceof ConversionService)) {
/* 234 */       addApplicationConverters(registry, (ConversionService)registry);
/*     */     }
/*     */   }
/*     */   
/*     */   private static void addApplicationConverters(ConverterRegistry registry, ConversionService conversionService) {
/* 239 */     registry.addConverter(new CharSequenceToObjectConverter(conversionService));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void addDelimitedStringConverters(ConverterRegistry registry)
/*     */   {
/* 250 */     ConversionService service = (ConversionService)registry;
/* 251 */     registry.addConverter(new ArrayToDelimitedStringConverter(service));
/* 252 */     registry.addConverter(new CollectionToDelimitedStringConverter(service));
/* 253 */     registry.addConverter(new DelimitedStringToArrayConverter(service));
/* 254 */     registry.addConverter(new DelimitedStringToCollectionConverter(service));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void addApplicationFormatters(FormatterRegistry registry)
/*     */   {
/* 262 */     registry.addFormatter(new CharArrayFormatter());
/* 263 */     registry.addFormatter(new InetAddressFormatter());
/* 264 */     registry.addFormatter(new IsoOffsetFormatter());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void addBeans(FormatterRegistry registry, ListableBeanFactory beanFactory)
/*     */   {
/* 275 */     Set<Object> beans = new LinkedHashSet();
/* 276 */     beans.addAll(beanFactory.getBeansOfType(GenericConverter.class).values());
/* 277 */     beans.addAll(beanFactory.getBeansOfType(Converter.class).values());
/* 278 */     beans.addAll(beanFactory.getBeansOfType(Printer.class).values());
/* 279 */     beans.addAll(beanFactory.getBeansOfType(Parser.class).values());
/* 280 */     for (Object bean : beans) {
/* 281 */       if ((bean instanceof GenericConverter)) {
/* 282 */         registry.addConverter((GenericConverter)bean);
/*     */       }
/* 284 */       else if ((bean instanceof Converter)) {
/* 285 */         registry.addConverter((Converter)bean);
/*     */       }
/* 287 */       else if ((bean instanceof Formatter)) {
/* 288 */         registry.addFormatter((Formatter)bean);
/*     */       }
/* 290 */       else if ((bean instanceof Printer)) {
/* 291 */         registry.addPrinter((Printer)bean);
/*     */       }
/* 293 */       else if ((bean instanceof Parser)) {
/* 294 */         registry.addParser((Parser)bean);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\convert\ApplicationConversionService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */