/*    */ package org.springframework.boot.json;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JsonParseException
/*    */   extends IllegalArgumentException
/*    */ {
/*    */   public JsonParseException()
/*    */   {
/* 29 */     this(null);
/*    */   }
/*    */   
/*    */   public JsonParseException(Throwable cause) {
/* 33 */     super("Cannot parse JSON", cause);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\json\JsonParseException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */