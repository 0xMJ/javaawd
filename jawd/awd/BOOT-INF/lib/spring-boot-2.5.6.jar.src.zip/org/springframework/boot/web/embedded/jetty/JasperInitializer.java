/*     */ package org.springframework.boot.web.embedded.jetty;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.net.URLStreamHandler;
/*     */ import java.net.URLStreamHandlerFactory;
/*     */ import javax.servlet.ServletContainerInitializer;
/*     */ import org.eclipse.jetty.server.handler.ContextHandler.Context;
/*     */ import org.eclipse.jetty.util.component.AbstractLifeCycle;
/*     */ import org.eclipse.jetty.webapp.WebAppContext;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class JasperInitializer
/*     */   extends AbstractLifeCycle
/*     */ {
/*  42 */   private static final String[] INITIALIZER_CLASSES = { "org.eclipse.jetty.apache.jsp.JettyJasperInitializer", "org.apache.jasper.servlet.JasperInitializer" };
/*     */   
/*     */   private final WebAppContext context;
/*     */   
/*     */   private final ServletContainerInitializer initializer;
/*     */   
/*     */   JasperInitializer(WebAppContext context)
/*     */   {
/*  50 */     this.context = context;
/*  51 */     this.initializer = newInitializer();
/*     */   }
/*     */   
/*     */   private ServletContainerInitializer newInitializer() {
/*  55 */     for (String className : INITIALIZER_CLASSES) {
/*     */       try {
/*  57 */         Class<?> initializerClass = ClassUtils.forName(className, null);
/*  58 */         return (ServletContainerInitializer)initializerClass.getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
/*     */       }
/*     */       catch (Exception localException) {}
/*     */     }
/*     */     
/*     */ 
/*  64 */     return null;
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   protected void doStart()
/*     */     throws Exception
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 4	org/springframework/boot/web/embedded/jetty/JasperInitializer:initializer	Ljavax/servlet/ServletContainerInitializer;
/*     */     //   4: ifnonnull +4 -> 8
/*     */     //   7: return
/*     */     //   8: ldc 13
/*     */     //   10: aload_0
/*     */     //   11: invokevirtual 14	java/lang/Object:getClass	()Ljava/lang/Class;
/*     */     //   14: invokevirtual 15	java/lang/Class:getClassLoader	()Ljava/lang/ClassLoader;
/*     */     //   17: invokestatic 16	org/springframework/util/ClassUtils:isPresent	(Ljava/lang/String;Ljava/lang/ClassLoader;)Z
/*     */     //   20: ifeq +10 -> 30
/*     */     //   23: invokestatic 17	org/apache/catalina/webresources/TomcatURLStreamHandlerFactory:register	()Z
/*     */     //   26: pop
/*     */     //   27: goto +18 -> 45
/*     */     //   30: new 18	org/springframework/boot/web/embedded/jetty/JasperInitializer$WarUrlStreamHandlerFactory
/*     */     //   33: dup
/*     */     //   34: aconst_null
/*     */     //   35: invokespecial 19	org/springframework/boot/web/embedded/jetty/JasperInitializer$WarUrlStreamHandlerFactory:<init>	(Lorg/springframework/boot/web/embedded/jetty/JasperInitializer$1;)V
/*     */     //   38: invokestatic 20	java/net/URL:setURLStreamHandlerFactory	(Ljava/net/URLStreamHandlerFactory;)V
/*     */     //   41: goto +4 -> 45
/*     */     //   44: astore_1
/*     */     //   45: invokestatic 22	java/lang/Thread:currentThread	()Ljava/lang/Thread;
/*     */     //   48: invokevirtual 23	java/lang/Thread:getContextClassLoader	()Ljava/lang/ClassLoader;
/*     */     //   51: astore_1
/*     */     //   52: invokestatic 22	java/lang/Thread:currentThread	()Ljava/lang/Thread;
/*     */     //   55: aload_0
/*     */     //   56: getfield 2	org/springframework/boot/web/embedded/jetty/JasperInitializer:context	Lorg/eclipse/jetty/webapp/WebAppContext;
/*     */     //   59: invokevirtual 24	org/eclipse/jetty/webapp/WebAppContext:getClassLoader	()Ljava/lang/ClassLoader;
/*     */     //   62: invokevirtual 25	java/lang/Thread:setContextClassLoader	(Ljava/lang/ClassLoader;)V
/*     */     //   65: aload_0
/*     */     //   66: iconst_1
/*     */     //   67: invokespecial 26	org/springframework/boot/web/embedded/jetty/JasperInitializer:setExtendedListenerTypes	(Z)V
/*     */     //   70: aload_0
/*     */     //   71: getfield 4	org/springframework/boot/web/embedded/jetty/JasperInitializer:initializer	Ljavax/servlet/ServletContainerInitializer;
/*     */     //   74: aconst_null
/*     */     //   75: aload_0
/*     */     //   76: getfield 2	org/springframework/boot/web/embedded/jetty/JasperInitializer:context	Lorg/eclipse/jetty/webapp/WebAppContext;
/*     */     //   79: invokevirtual 27	org/eclipse/jetty/webapp/WebAppContext:getServletContext	()Lorg/eclipse/jetty/server/handler/ContextHandler$Context;
/*     */     //   82: invokeinterface 28 3 0
/*     */     //   87: aload_0
/*     */     //   88: iconst_0
/*     */     //   89: invokespecial 26	org/springframework/boot/web/embedded/jetty/JasperInitializer:setExtendedListenerTypes	(Z)V
/*     */     //   92: goto +11 -> 103
/*     */     //   95: astore_2
/*     */     //   96: aload_0
/*     */     //   97: iconst_0
/*     */     //   98: invokespecial 26	org/springframework/boot/web/embedded/jetty/JasperInitializer:setExtendedListenerTypes	(Z)V
/*     */     //   101: aload_2
/*     */     //   102: athrow
/*     */     //   103: invokestatic 22	java/lang/Thread:currentThread	()Ljava/lang/Thread;
/*     */     //   106: aload_1
/*     */     //   107: invokevirtual 25	java/lang/Thread:setContextClassLoader	(Ljava/lang/ClassLoader;)V
/*     */     //   110: goto +13 -> 123
/*     */     //   113: astore_3
/*     */     //   114: invokestatic 22	java/lang/Thread:currentThread	()Ljava/lang/Thread;
/*     */     //   117: aload_1
/*     */     //   118: invokevirtual 25	java/lang/Thread:setContextClassLoader	(Ljava/lang/ClassLoader;)V
/*     */     //   121: aload_3
/*     */     //   122: athrow
/*     */     //   123: return
/*     */     // Line number table:
/*     */     //   Java source line #69	-> byte code offset #0
/*     */     //   Java source line #70	-> byte code offset #7
/*     */     //   Java source line #72	-> byte code offset #8
/*     */     //   Java source line #73	-> byte code offset #11
/*     */     //   Java source line #72	-> byte code offset #17
/*     */     //   Java source line #74	-> byte code offset #23
/*     */     //   Java source line #78	-> byte code offset #30
/*     */     //   Java source line #82	-> byte code offset #41
/*     */     //   Java source line #80	-> byte code offset #44
/*     */     //   Java source line #84	-> byte code offset #45
/*     */     //   Java source line #86	-> byte code offset #52
/*     */     //   Java source line #88	-> byte code offset #65
/*     */     //   Java source line #89	-> byte code offset #70
/*     */     //   Java source line #92	-> byte code offset #87
/*     */     //   Java source line #93	-> byte code offset #92
/*     */     //   Java source line #92	-> byte code offset #95
/*     */     //   Java source line #93	-> byte code offset #101
/*     */     //   Java source line #96	-> byte code offset #103
/*     */     //   Java source line #97	-> byte code offset #110
/*     */     //   Java source line #96	-> byte code offset #113
/*     */     //   Java source line #97	-> byte code offset #121
/*     */     //   Java source line #98	-> byte code offset #123
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	124	0	this	JasperInitializer
/*     */     //   44	1	1	localError	Error
/*     */     //   51	67	1	classLoader	ClassLoader
/*     */     //   95	7	2	localObject1	Object
/*     */     //   113	9	3	localObject2	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   30	41	44	java/lang/Error
/*     */     //   65	87	95	finally
/*     */     //   52	103	113	finally
/*     */   }
/*     */   
/*     */   private void setExtendedListenerTypes(boolean extended)
/*     */   {
/*     */     try
/*     */     {
/* 102 */       this.context.getServletContext().setExtendedListenerTypes(extended);
/*     */     }
/*     */     catch (NoSuchMethodError localNoSuchMethodError) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class WarUrlStreamHandlerFactory
/*     */     implements URLStreamHandlerFactory
/*     */   {
/*     */     public URLStreamHandler createURLStreamHandler(String protocol)
/*     */     {
/* 116 */       if ("war".equals(protocol)) {
/* 117 */         return new JasperInitializer.WarUrlStreamHandler(null);
/*     */       }
/* 119 */       return null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class WarUrlStreamHandler
/*     */     extends URLStreamHandler
/*     */   {
/*     */     protected void parseURL(URL u, String spec, int start, int limit)
/*     */     {
/* 133 */       String path = "jar:" + spec.substring("war:".length());
/* 134 */       int separator = path.indexOf("*/");
/* 135 */       if (separator >= 0) {
/* 136 */         path = path.substring(0, separator) + "!/" + path.substring(separator + 2);
/*     */       }
/* 138 */       setURL(u, u.getProtocol(), "", -1, null, null, path, null, null);
/*     */     }
/*     */     
/*     */     protected URLConnection openConnection(URL u) throws IOException
/*     */     {
/* 143 */       return new JasperInitializer.WarURLConnection(u);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static class WarURLConnection
/*     */     extends URLConnection
/*     */   {
/*     */     private final URLConnection connection;
/*     */     
/*     */     protected WarURLConnection(URL url)
/*     */       throws IOException
/*     */     {
/* 156 */       super();
/* 157 */       this.connection = new URL(url.getFile()).openConnection();
/*     */     }
/*     */     
/*     */     public void connect() throws IOException
/*     */     {
/* 162 */       if (!this.connected) {
/* 163 */         this.connection.connect();
/* 164 */         this.connected = true;
/*     */       }
/*     */     }
/*     */     
/*     */     public InputStream getInputStream() throws IOException
/*     */     {
/* 170 */       connect();
/* 171 */       return this.connection.getInputStream();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\web\embedded\jetty\JasperInitializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */