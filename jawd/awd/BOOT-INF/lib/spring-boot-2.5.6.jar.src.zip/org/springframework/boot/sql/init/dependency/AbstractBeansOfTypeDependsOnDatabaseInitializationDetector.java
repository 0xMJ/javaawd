/*    */ package org.springframework.boot.sql.init.dependency;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.Set;
/*    */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractBeansOfTypeDependsOnDatabaseInitializationDetector
/*    */   implements DependsOnDatabaseInitializationDetector
/*    */ {
/*    */   public Set<String> detect(ConfigurableListableBeanFactory beanFactory)
/*    */   {
/*    */     try
/*    */     {
/* 38 */       Set<Class<?>> types = getDependsOnDatabaseInitializationBeanTypes();
/* 39 */       return new BeansOfTypeDetector(types).detect(beanFactory);
/*    */     }
/*    */     catch (Throwable ex) {}
/* 42 */     return Collections.emptySet();
/*    */   }
/*    */   
/*    */   protected abstract Set<Class<?>> getDependsOnDatabaseInitializationBeanTypes();
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\sql\init\dependency\AbstractBeansOfTypeDependsOnDatabaseInitializationDetector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */