/*    */ package org.springframework.boot.jdbc.metadata;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract interface DataSourcePoolMetadata
/*    */ {
/*    */   public abstract Float getUsage();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public abstract Integer getActive();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Integer getIdle()
/*    */   {
/* 61 */     return null;
/*    */   }
/*    */   
/*    */   public abstract Integer getMax();
/*    */   
/*    */   public abstract Integer getMin();
/*    */   
/*    */   public abstract String getValidationQuery();
/*    */   
/*    */   public abstract Boolean getDefaultAutoCommit();
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\jdbc\metadata\DataSourcePoolMetadata.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */