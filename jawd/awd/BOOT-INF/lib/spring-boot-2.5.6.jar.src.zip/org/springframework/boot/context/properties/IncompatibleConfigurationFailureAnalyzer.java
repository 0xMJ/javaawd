/*    */ package org.springframework.boot.context.properties;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.stream.Collectors;
/*    */ import java.util.stream.Stream;
/*    */ import org.springframework.boot.diagnostics.AbstractFailureAnalyzer;
/*    */ import org.springframework.boot.diagnostics.FailureAnalysis;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class IncompatibleConfigurationFailureAnalyzer
/*    */   extends AbstractFailureAnalyzer<IncompatibleConfigurationException>
/*    */ {
/*    */   protected FailureAnalysis analyze(Throwable rootFailure, IncompatibleConfigurationException cause)
/*    */   {
/* 34 */     String action = String.format("Review the docs for %s and change the configured values.", new Object[] {cause
/* 35 */       .getIncompatibleKeys().stream().collect(Collectors.joining(", ")) });
/* 36 */     return new FailureAnalysis(cause.getMessage(), action, cause);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\context\properties\IncompatibleConfigurationFailureAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */