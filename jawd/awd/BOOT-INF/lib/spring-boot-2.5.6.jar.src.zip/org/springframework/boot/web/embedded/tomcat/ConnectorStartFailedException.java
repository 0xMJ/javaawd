/*    */ package org.springframework.boot.web.embedded.tomcat;
/*    */ 
/*    */ import org.springframework.boot.web.server.WebServerException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConnectorStartFailedException
/*    */   extends WebServerException
/*    */ {
/*    */   private final int port;
/*    */   
/*    */   public ConnectorStartFailedException(int port)
/*    */   {
/* 40 */     super("Connector configured to listen on port " + port + " failed to start", null);
/* 41 */     this.port = port;
/*    */   }
/*    */   
/*    */   public int getPort() {
/* 45 */     return this.port;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\web\embedded\tomcat\ConnectorStartFailedException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */