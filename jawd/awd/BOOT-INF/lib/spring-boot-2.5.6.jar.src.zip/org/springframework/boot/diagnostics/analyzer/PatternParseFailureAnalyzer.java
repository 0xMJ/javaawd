/*    */ package org.springframework.boot.diagnostics.analyzer;
/*    */ 
/*    */ import org.springframework.boot.diagnostics.AbstractFailureAnalyzer;
/*    */ import org.springframework.boot.diagnostics.FailureAnalysis;
/*    */ import org.springframework.web.util.pattern.PatternParseException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class PatternParseFailureAnalyzer
/*    */   extends AbstractFailureAnalyzer<PatternParseException>
/*    */ {
/*    */   protected FailureAnalysis analyze(Throwable rootFailure, PatternParseException cause)
/*    */   {
/* 33 */     return new FailureAnalysis("Invalid mapping pattern detected: " + cause.toDetailedString(), "Fix this pattern in your application or switch to the legacy parser implementation with `spring.mvc.pathpattern.matching-strategy=ant_path_matcher`.", cause);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\diagnostics\analyzer\PatternParseFailureAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */