package org.springframework.boot.jdbc;

import javax.sql.DataSource;
import javax.sql.XADataSource;

@FunctionalInterface
public abstract interface XADataSourceWrapper
{
  public abstract DataSource wrapDataSource(XADataSource paramXADataSource)
    throws Exception;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\jdbc\XADataSourceWrapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */