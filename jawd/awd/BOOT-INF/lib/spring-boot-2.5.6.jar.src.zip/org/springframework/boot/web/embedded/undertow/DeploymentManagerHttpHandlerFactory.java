/*    */ package org.springframework.boot.web.embedded.undertow;
/*    */ 
/*    */ import io.undertow.server.HttpHandler;
/*    */ import io.undertow.server.HttpServerExchange;
/*    */ import io.undertow.servlet.api.DeploymentManager;
/*    */ import java.io.Closeable;
/*    */ import java.io.IOException;
/*    */ import javax.servlet.ServletException;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class DeploymentManagerHttpHandlerFactory
/*    */   implements HttpHandlerFactory
/*    */ {
/*    */   private final DeploymentManager deploymentManager;
/*    */   
/*    */   DeploymentManagerHttpHandlerFactory(DeploymentManager deploymentManager)
/*    */   {
/* 41 */     this.deploymentManager = deploymentManager;
/*    */   }
/*    */   
/*    */   public HttpHandler getHandler(HttpHandler next)
/*    */   {
/* 46 */     Assert.state(next == null, "DeploymentManagerHttpHandlerFactory must be first");
/* 47 */     return new DeploymentManagerHandler(this.deploymentManager);
/*    */   }
/*    */   
/*    */   DeploymentManager getDeploymentManager() {
/* 51 */     return this.deploymentManager;
/*    */   }
/*    */   
/*    */ 
/*    */   static class DeploymentManagerHandler
/*    */     implements HttpHandler, Closeable
/*    */   {
/*    */     private final DeploymentManager deploymentManager;
/*    */     
/*    */     private final HttpHandler handler;
/*    */     
/*    */     DeploymentManagerHandler(DeploymentManager deploymentManager)
/*    */     {
/* 64 */       this.deploymentManager = deploymentManager;
/*    */       try {
/* 66 */         this.handler = deploymentManager.start();
/*    */       }
/*    */       catch (ServletException ex) {
/* 69 */         throw new RuntimeException(ex);
/*    */       }
/*    */     }
/*    */     
/*    */     public void handleRequest(HttpServerExchange exchange) throws Exception
/*    */     {
/* 75 */       this.handler.handleRequest(exchange);
/*    */     }
/*    */     
/*    */     public void close() throws IOException
/*    */     {
/*    */       try {
/* 81 */         this.deploymentManager.stop();
/* 82 */         this.deploymentManager.undeploy();
/*    */       }
/*    */       catch (ServletException ex) {
/* 85 */         throw new RuntimeException(ex);
/*    */       }
/*    */     }
/*    */     
/*    */     DeploymentManager getDeploymentManager() {
/* 90 */       return this.deploymentManager;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\web\embedded\undertow\DeploymentManagerHttpHandlerFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */