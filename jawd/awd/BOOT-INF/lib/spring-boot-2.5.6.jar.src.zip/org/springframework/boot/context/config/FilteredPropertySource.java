/*    */ package org.springframework.boot.context.config;
/*    */ 
/*    */ import java.util.Set;
/*    */ import java.util.function.Consumer;
/*    */ import org.springframework.core.env.ConfigurableEnvironment;
/*    */ import org.springframework.core.env.MutablePropertySources;
/*    */ import org.springframework.core.env.PropertySource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ class FilteredPropertySource
/*    */   extends PropertySource<PropertySource<?>>
/*    */ {
/*    */   private final Set<String> filteredProperties;
/*    */   
/*    */   FilteredPropertySource(PropertySource<?> original, Set<String> filteredProperties)
/*    */   {
/* 40 */     super(original.getName(), original);
/* 41 */     this.filteredProperties = filteredProperties;
/*    */   }
/*    */   
/*    */   public Object getProperty(String name)
/*    */   {
/* 46 */     if (this.filteredProperties.contains(name)) {
/* 47 */       return null;
/*    */     }
/* 49 */     return ((PropertySource)getSource()).getProperty(name);
/*    */   }
/*    */   
/*    */   static void apply(ConfigurableEnvironment environment, String propertySourceName, Set<String> filteredProperties, Consumer<PropertySource<?>> operation)
/*    */   {
/* 54 */     MutablePropertySources propertySources = environment.getPropertySources();
/* 55 */     PropertySource<?> original = propertySources.get(propertySourceName);
/* 56 */     if (original == null) {
/* 57 */       operation.accept(null);
/* 58 */       return;
/*    */     }
/* 60 */     propertySources.replace(propertySourceName, new FilteredPropertySource(original, filteredProperties));
/*    */     try {
/* 62 */       operation.accept(original);
/*    */     }
/*    */     finally {
/* 65 */       propertySources.replace(propertySourceName, original);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\context\config\FilteredPropertySource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */