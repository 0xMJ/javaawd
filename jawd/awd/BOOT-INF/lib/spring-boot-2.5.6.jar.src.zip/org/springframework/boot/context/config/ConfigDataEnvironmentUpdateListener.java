/*    */ package org.springframework.boot.context.config;
/*    */ 
/*    */ import java.util.EventListener;
/*    */ import org.springframework.core.env.PropertySource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract interface ConfigDataEnvironmentUpdateListener
/*    */   extends EventListener
/*    */ {
/* 36 */   public static final ConfigDataEnvironmentUpdateListener NONE = new ConfigDataEnvironmentUpdateListener() {};
/*    */   
/*    */   public void onPropertySourceAdded(PropertySource<?> propertySource, ConfigDataLocation location, ConfigDataResource resource) {}
/*    */   
/*    */   public void onSetProfiles(Profiles profiles) {}
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\context\config\ConfigDataEnvironmentUpdateListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */