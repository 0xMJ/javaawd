/*     */ package org.springframework.boot.web.server;
/*     */ 
/*     */ import org.springframework.http.HttpStatus;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ErrorPage
/*     */ {
/*     */   private final HttpStatus status;
/*     */   private final Class<? extends Throwable> exception;
/*     */   private final String path;
/*     */   
/*     */   public ErrorPage(String path)
/*     */   {
/*  38 */     this.status = null;
/*  39 */     this.exception = null;
/*  40 */     this.path = path;
/*     */   }
/*     */   
/*     */   public ErrorPage(HttpStatus status, String path) {
/*  44 */     this.status = status;
/*  45 */     this.exception = null;
/*  46 */     this.path = path;
/*     */   }
/*     */   
/*     */   public ErrorPage(Class<? extends Throwable> exception, String path) {
/*  50 */     this.status = null;
/*  51 */     this.exception = exception;
/*  52 */     this.path = path;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getPath()
/*     */   {
/*  62 */     return this.path;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Class<? extends Throwable> getException()
/*     */   {
/*  70 */     return this.exception;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HttpStatus getStatus()
/*     */   {
/*  79 */     return this.status;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getStatusCode()
/*     */   {
/*  87 */     return this.status != null ? this.status.value() : 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getExceptionName()
/*     */   {
/*  95 */     return this.exception != null ? this.exception.getName() : null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isGlobal()
/*     */   {
/* 104 */     return (this.status == null) && (this.exception == null);
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/* 109 */     if (this == obj) {
/* 110 */       return true;
/*     */     }
/* 112 */     if (obj == null) {
/* 113 */       return false;
/*     */     }
/* 115 */     if ((obj instanceof ErrorPage)) {
/* 116 */       ErrorPage other = (ErrorPage)obj;
/* 117 */       return (ObjectUtils.nullSafeEquals(getExceptionName(), other.getExceptionName())) && 
/* 118 */         (ObjectUtils.nullSafeEquals(this.path, other.path)) && (this.status == other.status);
/*     */     }
/* 120 */     return false;
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 125 */     int prime = 31;
/* 126 */     int result = 1;
/* 127 */     result = 31 * result + ObjectUtils.nullSafeHashCode(getExceptionName());
/* 128 */     result = 31 * result + ObjectUtils.nullSafeHashCode(this.path);
/* 129 */     result = 31 * result + getStatusCode();
/* 130 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\web\server\ErrorPage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */