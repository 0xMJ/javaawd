/*    */ package org.springframework.boot.web.embedded.jetty;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Arrays;
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.eclipse.jetty.server.Request;
/*    */ import org.eclipse.jetty.servlet.ErrorPageErrorHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class JettyEmbeddedErrorHandler
/*    */   extends ErrorPageErrorHandler
/*    */ {
/* 44 */   private static final Set<String> HANDLED_HTTP_METHODS = new HashSet(Arrays.asList(new String[] { "GET", "POST", "HEAD" }));
/*    */   
/*    */   public boolean errorPageForMethod(String method)
/*    */   {
/* 48 */     return true;
/*    */   }
/*    */   
/*    */   public void handle(String target, Request baseRequest, HttpServletRequest request, HttpServletResponse response)
/*    */     throws IOException, ServletException
/*    */   {
/* 54 */     if (!HANDLED_HTTP_METHODS.contains(baseRequest.getMethod())) {
/* 55 */       baseRequest.setMethod("GET");
/*    */     }
/* 57 */     super.handle(target, baseRequest, request, response);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\web\embedded\jetty\JettyEmbeddedErrorHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */