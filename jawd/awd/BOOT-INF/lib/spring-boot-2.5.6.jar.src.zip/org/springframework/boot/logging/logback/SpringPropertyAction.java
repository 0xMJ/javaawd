/*    */ package org.springframework.boot.logging.logback;
/*    */ 
/*    */ import ch.qos.logback.core.joran.action.Action;
/*    */ import ch.qos.logback.core.joran.action.ActionUtil;
/*    */ import ch.qos.logback.core.joran.action.ActionUtil.Scope;
/*    */ import ch.qos.logback.core.joran.spi.ActionException;
/*    */ import ch.qos.logback.core.joran.spi.InterpretationContext;
/*    */ import ch.qos.logback.core.util.OptionHelper;
/*    */ import org.springframework.core.env.Environment;
/*    */ import org.xml.sax.Attributes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SpringPropertyAction
/*    */   extends Action
/*    */ {
/*    */   private static final String SOURCE_ATTRIBUTE = "source";
/*    */   private static final String DEFAULT_VALUE_ATTRIBUTE = "defaultValue";
/*    */   private final Environment environment;
/*    */   
/*    */   SpringPropertyAction(Environment environment)
/*    */   {
/* 46 */     this.environment = environment;
/*    */   }
/*    */   
/*    */   public void begin(InterpretationContext context, String elementName, Attributes attributes) throws ActionException
/*    */   {
/* 51 */     String name = attributes.getValue("name");
/* 52 */     String source = attributes.getValue("source");
/* 53 */     ActionUtil.Scope scope = ActionUtil.stringToScope(attributes.getValue("scope"));
/* 54 */     String defaultValue = attributes.getValue("defaultValue");
/* 55 */     if ((OptionHelper.isEmpty(name)) || (OptionHelper.isEmpty(source))) {
/* 56 */       addError("The \"name\" and \"source\" attributes of <springProperty> must be set");
/*    */     }
/* 58 */     ActionUtil.setProperty(context, name, getValue(source, defaultValue), scope);
/*    */   }
/*    */   
/*    */   private String getValue(String source, String defaultValue) {
/* 62 */     if (this.environment == null) {
/* 63 */       addWarn("No Spring Environment available to resolve " + source);
/* 64 */       return defaultValue;
/*    */     }
/* 66 */     return this.environment.getProperty(source, defaultValue);
/*    */   }
/*    */   
/*    */   public void end(InterpretationContext context, String name)
/*    */     throws ActionException
/*    */   {}
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\logging\logback\SpringPropertyAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */