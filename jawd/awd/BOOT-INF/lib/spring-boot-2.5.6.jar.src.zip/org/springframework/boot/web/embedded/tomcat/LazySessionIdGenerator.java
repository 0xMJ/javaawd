/*    */ package org.springframework.boot.web.embedded.tomcat;
/*    */ 
/*    */ import org.apache.catalina.LifecycleException;
/*    */ import org.apache.catalina.LifecycleState;
/*    */ import org.apache.catalina.util.StandardSessionIdGenerator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class LazySessionIdGenerator
/*    */   extends StandardSessionIdGenerator
/*    */ {
/*    */   protected void startInternal()
/*    */     throws LifecycleException
/*    */   {
/* 33 */     setState(LifecycleState.STARTING);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\web\embedded\tomcat\LazySessionIdGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */