package org.springframework.boot.rsocket.messaging;

import org.springframework.messaging.rsocket.RSocketStrategies.Builder;

@FunctionalInterface
public abstract interface RSocketStrategiesCustomizer
{
  public abstract void customize(RSocketStrategies.Builder paramBuilder);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\rsocket\messaging\RSocketStrategiesCustomizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */