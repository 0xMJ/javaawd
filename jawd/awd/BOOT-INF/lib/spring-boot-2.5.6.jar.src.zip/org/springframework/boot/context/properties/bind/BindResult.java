/*     */ package org.springframework.boot.context.properties.bind;
/*     */ 
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class BindResult<T>
/*     */ {
/*  38 */   private static final BindResult<?> UNBOUND = new BindResult(null);
/*     */   private final T value;
/*     */   
/*     */   private BindResult(T value)
/*     */   {
/*  43 */     this.value = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public T get()
/*     */     throws NoSuchElementException
/*     */   {
/*  54 */     if (this.value == null) {
/*  55 */       throw new NoSuchElementException("No value bound");
/*     */     }
/*  57 */     return (T)this.value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isBound()
/*     */   {
/*  65 */     return this.value != null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void ifBound(Consumer<? super T> consumer)
/*     */   {
/*  74 */     Assert.notNull(consumer, "Consumer must not be null");
/*  75 */     if (this.value != null) {
/*  76 */       consumer.accept(this.value);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public <U> BindResult<U> map(Function<? super T, ? extends U> mapper)
/*     */   {
/*  90 */     Assert.notNull(mapper, "Mapper must not be null");
/*  91 */     return of(this.value != null ? mapper.apply(this.value) : null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public T orElse(T other)
/*     */   {
/* 101 */     return (T)(this.value != null ? this.value : other);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public T orElseGet(Supplier<? extends T> other)
/*     */   {
/* 112 */     return (T)(this.value != null ? this.value : other.get());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public <X extends Throwable> T orElseThrow(Supplier<? extends X> exceptionSupplier)
/*     */     throws Throwable
/*     */   {
/* 124 */     if (this.value == null) {
/* 125 */       throw ((Throwable)exceptionSupplier.get());
/*     */     }
/* 127 */     return (T)this.value;
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/* 132 */     if (this == obj) {
/* 133 */       return true;
/*     */     }
/* 135 */     if ((obj == null) || (getClass() != obj.getClass())) {
/* 136 */       return false;
/*     */     }
/* 138 */     return ObjectUtils.nullSafeEquals(this.value, ((BindResult)obj).value);
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 143 */     return ObjectUtils.nullSafeHashCode(this.value);
/*     */   }
/*     */   
/*     */   static <T> BindResult<T> of(T value)
/*     */   {
/* 148 */     if (value == null) {
/* 149 */       return UNBOUND;
/*     */     }
/* 151 */     return new BindResult(value);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\context\properties\bind\BindResult.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */