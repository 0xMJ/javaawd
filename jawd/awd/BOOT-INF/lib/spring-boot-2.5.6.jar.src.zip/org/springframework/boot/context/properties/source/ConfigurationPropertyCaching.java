/*     */ package org.springframework.boot.context.properties.source;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract interface ConfigurationPropertyCaching
/*     */ {
/*     */   public abstract void enable();
/*     */   
/*     */   public abstract void disable();
/*     */   
/*     */   public abstract void setTimeToLive(Duration paramDuration);
/*     */   
/*     */   public abstract void clear();
/*     */   
/*     */   public static ConfigurationPropertyCaching get(Environment environment)
/*     */   {
/*  60 */     return get(environment, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ConfigurationPropertyCaching get(Environment environment, Object underlyingSource)
/*     */   {
/*  72 */     Iterable<ConfigurationPropertySource> sources = ConfigurationPropertySources.get(environment);
/*  73 */     return get(sources, underlyingSource);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ConfigurationPropertyCaching get(Iterable<ConfigurationPropertySource> sources)
/*     */   {
/*  82 */     return get(sources, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ConfigurationPropertyCaching get(Iterable<ConfigurationPropertySource> sources, Object underlyingSource)
/*     */   {
/*  95 */     Assert.notNull(sources, "Sources must not be null");
/*  96 */     if (underlyingSource == null) {
/*  97 */       return new ConfigurationPropertySourcesCaching(sources);
/*     */     }
/*  99 */     for (ConfigurationPropertySource source : sources) {
/* 100 */       if (source.getUnderlyingSource() == underlyingSource) {
/* 101 */         ConfigurationPropertyCaching caching = CachingConfigurationPropertySource.find(source);
/* 102 */         if (caching != null) {
/* 103 */           return caching;
/*     */         }
/*     */       }
/*     */     }
/* 107 */     throw new IllegalStateException("Unable to find cache from configuration property sources");
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\context\properties\source\ConfigurationPropertyCaching.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */