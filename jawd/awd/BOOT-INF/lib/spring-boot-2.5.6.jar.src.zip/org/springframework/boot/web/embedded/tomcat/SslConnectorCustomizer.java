/*     */ package org.springframework.boot.web.embedded.tomcat;
/*     */ 
/*     */ import java.io.FileNotFoundException;
/*     */ import java.net.URL;
/*     */ import org.apache.catalina.connector.Connector;
/*     */ import org.apache.catalina.webresources.TomcatURLStreamHandlerFactory;
/*     */ import org.apache.coyote.ProtocolHandler;
/*     */ import org.apache.coyote.http11.AbstractHttp11JsseProtocol;
/*     */ import org.apache.coyote.http11.Http11NioProtocol;
/*     */ import org.apache.tomcat.util.net.SSLHostConfig;
/*     */ import org.springframework.boot.web.server.Ssl;
/*     */ import org.springframework.boot.web.server.Ssl.ClientAuth;
/*     */ import org.springframework.boot.web.server.SslStoreProvider;
/*     */ import org.springframework.boot.web.server.WebServerException;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ResourceUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SslConnectorCustomizer
/*     */   implements TomcatConnectorCustomizer
/*     */ {
/*     */   private final Ssl ssl;
/*     */   private final SslStoreProvider sslStoreProvider;
/*     */   
/*     */   SslConnectorCustomizer(Ssl ssl, SslStoreProvider sslStoreProvider)
/*     */   {
/*  47 */     Assert.notNull(ssl, "Ssl configuration should not be null");
/*  48 */     this.ssl = ssl;
/*  49 */     this.sslStoreProvider = sslStoreProvider;
/*     */   }
/*     */   
/*     */   public void customize(Connector connector)
/*     */   {
/*  54 */     ProtocolHandler handler = connector.getProtocolHandler();
/*  55 */     Assert.state(handler instanceof AbstractHttp11JsseProtocol, "To use SSL, the connector's protocol handler must be an AbstractHttp11JsseProtocol subclass");
/*     */     
/*  57 */     configureSsl((AbstractHttp11JsseProtocol)handler, this.ssl, this.sslStoreProvider);
/*  58 */     connector.setScheme("https");
/*  59 */     connector.setSecure(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void configureSsl(AbstractHttp11JsseProtocol<?> protocol, Ssl ssl, SslStoreProvider sslStoreProvider)
/*     */   {
/*  69 */     protocol.setSSLEnabled(true);
/*  70 */     protocol.setSslProtocol(ssl.getProtocol());
/*  71 */     configureSslClientAuth(protocol, ssl);
/*  72 */     if (ssl.getKeyStorePassword() != null) {
/*  73 */       protocol.setKeystorePass(ssl.getKeyStorePassword());
/*     */     }
/*  75 */     if (ssl.getKeyPassword() != null) {
/*  76 */       protocol.setKeyPass(ssl.getKeyPassword());
/*     */     }
/*  78 */     protocol.setKeyAlias(ssl.getKeyAlias());
/*  79 */     String ciphers = StringUtils.arrayToCommaDelimitedString(ssl.getCiphers());
/*  80 */     if (StringUtils.hasText(ciphers)) {
/*  81 */       protocol.setCiphers(ciphers);
/*     */     }
/*  83 */     if (ssl.getEnabledProtocols() != null) {
/*  84 */       for (SSLHostConfig sslHostConfig : protocol.findSslHostConfigs()) {
/*  85 */         sslHostConfig.setProtocols(StringUtils.arrayToCommaDelimitedString(ssl.getEnabledProtocols()));
/*     */       }
/*     */     }
/*  88 */     if (sslStoreProvider != null) {
/*  89 */       configureSslStoreProvider(protocol, sslStoreProvider);
/*     */     }
/*     */     else {
/*  92 */       configureSslKeyStore(protocol, ssl);
/*  93 */       configureSslTrustStore(protocol, ssl);
/*     */     }
/*     */   }
/*     */   
/*     */   private void configureSslClientAuth(AbstractHttp11JsseProtocol<?> protocol, Ssl ssl) {
/*  98 */     if (ssl.getClientAuth() == Ssl.ClientAuth.NEED) {
/*  99 */       protocol.setClientAuth(Boolean.TRUE.toString());
/*     */     }
/* 101 */     else if (ssl.getClientAuth() == Ssl.ClientAuth.WANT) {
/* 102 */       protocol.setClientAuth("want");
/*     */     }
/*     */   }
/*     */   
/*     */   protected void configureSslStoreProvider(AbstractHttp11JsseProtocol<?> protocol, SslStoreProvider sslStoreProvider)
/*     */   {
/* 108 */     Assert.isInstanceOf(Http11NioProtocol.class, protocol, "SslStoreProvider can only be used with Http11NioProtocol");
/*     */     
/* 110 */     TomcatURLStreamHandlerFactory instance = TomcatURLStreamHandlerFactory.getInstance();
/* 111 */     instance.addUserFactory(new SslStoreProviderUrlStreamHandlerFactory(sslStoreProvider));
/*     */     try {
/* 113 */       if (sslStoreProvider.getKeyStore() != null) {
/* 114 */         protocol.setKeystorePass("");
/* 115 */         protocol.setKeystoreFile("springbootssl:keyStore");
/*     */       }
/* 117 */       if (sslStoreProvider.getTrustStore() != null) {
/* 118 */         protocol.setTruststorePass("");
/* 119 */         protocol.setTruststoreFile("springbootssl:trustStore");
/*     */       }
/*     */     }
/*     */     catch (Exception ex) {
/* 123 */       throw new WebServerException("Could not load store: " + ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */   
/*     */   private void configureSslKeyStore(AbstractHttp11JsseProtocol<?> protocol, Ssl ssl) {
/*     */     try {
/* 129 */       protocol.setKeystoreFile(ResourceUtils.getURL(ssl.getKeyStore()).toString());
/*     */     }
/*     */     catch (Exception ex) {
/* 132 */       throw new WebServerException("Could not load key store '" + ssl.getKeyStore() + "'", ex);
/*     */     }
/* 134 */     if (ssl.getKeyStoreType() != null) {
/* 135 */       protocol.setKeystoreType(ssl.getKeyStoreType());
/*     */     }
/* 137 */     if (ssl.getKeyStoreProvider() != null) {
/* 138 */       protocol.setKeystoreProvider(ssl.getKeyStoreProvider());
/*     */     }
/*     */   }
/*     */   
/*     */   private void configureSslTrustStore(AbstractHttp11JsseProtocol<?> protocol, Ssl ssl) {
/* 143 */     if (ssl.getTrustStore() != null) {
/*     */       try {
/* 145 */         protocol.setTruststoreFile(ResourceUtils.getURL(ssl.getTrustStore()).toString());
/*     */       }
/*     */       catch (FileNotFoundException ex) {
/* 148 */         throw new WebServerException("Could not load trust store: " + ex.getMessage(), ex);
/*     */       }
/*     */     }
/* 151 */     if (ssl.getTrustStorePassword() != null) {
/* 152 */       protocol.setTruststorePass(ssl.getTrustStorePassword());
/*     */     }
/* 154 */     if (ssl.getTrustStoreType() != null) {
/* 155 */       protocol.setTruststoreType(ssl.getTrustStoreType());
/*     */     }
/* 157 */     if (ssl.getTrustStoreProvider() != null) {
/* 158 */       protocol.setTruststoreProvider(ssl.getTrustStoreProvider());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\web\embedded\tomcat\SslConnectorCustomizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */