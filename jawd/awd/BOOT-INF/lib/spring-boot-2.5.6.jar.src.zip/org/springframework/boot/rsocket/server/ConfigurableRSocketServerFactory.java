package org.springframework.boot.rsocket.server;

import java.net.InetAddress;
import org.springframework.boot.web.server.Ssl;
import org.springframework.boot.web.server.SslStoreProvider;
import org.springframework.util.unit.DataSize;

public abstract interface ConfigurableRSocketServerFactory
{
  public abstract void setPort(int paramInt);
  
  public abstract void setFragmentSize(DataSize paramDataSize);
  
  public abstract void setAddress(InetAddress paramInetAddress);
  
  public abstract void setTransport(RSocketServer.Transport paramTransport);
  
  public abstract void setSsl(Ssl paramSsl);
  
  public abstract void setSslStoreProvider(SslStoreProvider paramSslStoreProvider);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\rsocket\server\ConfigurableRSocketServerFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */