/*    */ package org.springframework.boot.r2dbc.init;
/*    */ 
/*    */ import io.r2dbc.spi.ConnectionFactory;
/*    */ import java.nio.charset.Charset;
/*    */ import java.util.List;
/*    */ import org.springframework.boot.r2dbc.EmbeddedDatabaseConnection;
/*    */ import org.springframework.boot.sql.init.AbstractScriptDatabaseInitializer;
/*    */ import org.springframework.boot.sql.init.DatabaseInitializationSettings;
/*    */ import org.springframework.core.io.Resource;
/*    */ import org.springframework.r2dbc.connection.init.ResourceDatabasePopulator;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class R2dbcScriptDatabaseInitializer
/*    */   extends AbstractScriptDatabaseInitializer
/*    */ {
/*    */   private final ConnectionFactory connectionFactory;
/*    */   
/*    */   public R2dbcScriptDatabaseInitializer(ConnectionFactory connectionFactory, DatabaseInitializationSettings settings)
/*    */   {
/* 51 */     super(settings);
/* 52 */     this.connectionFactory = connectionFactory;
/*    */   }
/*    */   
/*    */   protected boolean isEmbeddedDatabase()
/*    */   {
/* 57 */     return EmbeddedDatabaseConnection.isEmbedded(this.connectionFactory);
/*    */   }
/*    */   
/*    */   protected void runScripts(List<Resource> scripts, boolean continueOnError, String separator, Charset encoding)
/*    */   {
/* 62 */     ResourceDatabasePopulator populator = new ResourceDatabasePopulator();
/* 63 */     populator.setContinueOnError(continueOnError);
/* 64 */     populator.setSeparator(separator);
/* 65 */     if (encoding != null) {
/* 66 */       populator.setSqlScriptEncoding(encoding.name());
/*    */     }
/* 68 */     for (Resource script : scripts) {
/* 69 */       populator.addScript(script);
/*    */     }
/* 71 */     populator.populate(this.connectionFactory).block();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\r2dbc\init\R2dbcScriptDatabaseInitializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */