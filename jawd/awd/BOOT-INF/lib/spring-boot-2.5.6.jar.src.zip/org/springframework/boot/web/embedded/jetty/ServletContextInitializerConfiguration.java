/*    */ package org.springframework.boot.web.embedded.jetty;
/*    */ 
/*    */ import javax.servlet.ServletException;
/*    */ import org.eclipse.jetty.server.handler.ContextHandler.Context;
/*    */ import org.eclipse.jetty.webapp.AbstractConfiguration;
/*    */ import org.eclipse.jetty.webapp.WebAppContext;
/*    */ import org.springframework.boot.web.servlet.ServletContextInitializer;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ServletContextInitializerConfiguration
/*    */   extends AbstractConfiguration
/*    */ {
/*    */   private final ServletContextInitializer[] initializers;
/*    */   
/*    */   public ServletContextInitializerConfiguration(ServletContextInitializer... initializers)
/*    */   {
/* 45 */     Assert.notNull(initializers, "Initializers must not be null");
/* 46 */     this.initializers = initializers;
/*    */   }
/*    */   
/*    */   /* Error */
/*    */   public void configure(WebAppContext context)
/*    */     throws java.lang.Exception
/*    */   {
/*    */     // Byte code:
/*    */     //   0: invokestatic 5	java/lang/Thread:currentThread	()Ljava/lang/Thread;
/*    */     //   3: invokevirtual 6	java/lang/Thread:getContextClassLoader	()Ljava/lang/ClassLoader;
/*    */     //   6: astore_2
/*    */     //   7: invokestatic 5	java/lang/Thread:currentThread	()Ljava/lang/Thread;
/*    */     //   10: aload_1
/*    */     //   11: invokevirtual 7	org/eclipse/jetty/webapp/WebAppContext:getClassLoader	()Ljava/lang/ClassLoader;
/*    */     //   14: invokevirtual 8	java/lang/Thread:setContextClassLoader	(Ljava/lang/ClassLoader;)V
/*    */     //   17: aload_0
/*    */     //   18: aload_1
/*    */     //   19: invokespecial 9	org/springframework/boot/web/embedded/jetty/ServletContextInitializerConfiguration:callInitializers	(Lorg/eclipse/jetty/webapp/WebAppContext;)V
/*    */     //   22: invokestatic 5	java/lang/Thread:currentThread	()Ljava/lang/Thread;
/*    */     //   25: aload_2
/*    */     //   26: invokevirtual 8	java/lang/Thread:setContextClassLoader	(Ljava/lang/ClassLoader;)V
/*    */     //   29: goto +13 -> 42
/*    */     //   32: astore_3
/*    */     //   33: invokestatic 5	java/lang/Thread:currentThread	()Ljava/lang/Thread;
/*    */     //   36: aload_2
/*    */     //   37: invokevirtual 8	java/lang/Thread:setContextClassLoader	(Ljava/lang/ClassLoader;)V
/*    */     //   40: aload_3
/*    */     //   41: athrow
/*    */     //   42: return
/*    */     // Line number table:
/*    */     //   Java source line #51	-> byte code offset #0
/*    */     //   Java source line #52	-> byte code offset #7
/*    */     //   Java source line #54	-> byte code offset #17
/*    */     //   Java source line #57	-> byte code offset #22
/*    */     //   Java source line #58	-> byte code offset #29
/*    */     //   Java source line #57	-> byte code offset #32
/*    */     //   Java source line #58	-> byte code offset #40
/*    */     //   Java source line #59	-> byte code offset #42
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	signature
/*    */     //   0	43	0	this	ServletContextInitializerConfiguration
/*    */     //   0	43	1	context	WebAppContext
/*    */     //   6	31	2	classLoader	ClassLoader
/*    */     //   32	9	3	localObject	Object
/*    */     // Exception table:
/*    */     //   from	to	target	type
/*    */     //   17	22	32	finally
/*    */   }
/*    */   
/*    */   private void callInitializers(WebAppContext context)
/*    */     throws ServletException
/*    */   {
/*    */     try
/*    */     {
/* 63 */       setExtendedListenerTypes(context, true);
/* 64 */       for (ServletContextInitializer initializer : this.initializers) {
/* 65 */         initializer.onStartup(context.getServletContext());
/*    */       }
/*    */     }
/*    */     finally {
/* 69 */       setExtendedListenerTypes(context, false);
/*    */     }
/*    */   }
/*    */   
/*    */   private void setExtendedListenerTypes(WebAppContext context, boolean extended) {
/*    */     try {
/* 75 */       context.getServletContext().setExtendedListenerTypes(extended);
/*    */     }
/*    */     catch (NoSuchMethodError localNoSuchMethodError) {}
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\web\embedded\jetty\ServletContextInitializerConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */