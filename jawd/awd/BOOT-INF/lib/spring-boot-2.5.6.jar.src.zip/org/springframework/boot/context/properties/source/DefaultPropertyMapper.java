/*    */ package org.springframework.boot.context.properties.source;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import org.springframework.util.ObjectUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class DefaultPropertyMapper
/*    */   implements PropertyMapper
/*    */ {
/* 36 */   public static final PropertyMapper INSTANCE = new DefaultPropertyMapper();
/*    */   
/*    */ 
/*    */   private LastMapping<ConfigurationPropertyName, List<String>> lastMappedConfigurationPropertyName;
/*    */   
/*    */ 
/*    */   private LastMapping<String, ConfigurationPropertyName> lastMappedPropertyName;
/*    */   
/*    */ 
/*    */ 
/*    */   public List<String> map(ConfigurationPropertyName configurationPropertyName)
/*    */   {
/* 48 */     LastMapping<ConfigurationPropertyName, List<String>> last = this.lastMappedConfigurationPropertyName;
/* 49 */     if ((last != null) && (last.isFrom(configurationPropertyName))) {
/* 50 */       return (List)last.getMapping();
/*    */     }
/* 52 */     String convertedName = configurationPropertyName.toString();
/* 53 */     List<String> mapping = Collections.singletonList(convertedName);
/* 54 */     this.lastMappedConfigurationPropertyName = new LastMapping(configurationPropertyName, mapping);
/* 55 */     return mapping;
/*    */   }
/*    */   
/*    */ 
/*    */   public ConfigurationPropertyName map(String propertySourceName)
/*    */   {
/* 61 */     LastMapping<String, ConfigurationPropertyName> last = this.lastMappedPropertyName;
/* 62 */     if ((last != null) && (last.isFrom(propertySourceName))) {
/* 63 */       return (ConfigurationPropertyName)last.getMapping();
/*    */     }
/* 65 */     ConfigurationPropertyName mapping = tryMap(propertySourceName);
/* 66 */     this.lastMappedPropertyName = new LastMapping(propertySourceName, mapping);
/* 67 */     return mapping;
/*    */   }
/*    */   
/*    */   private ConfigurationPropertyName tryMap(String propertySourceName) {
/*    */     try {
/* 72 */       ConfigurationPropertyName convertedName = ConfigurationPropertyName.adapt(propertySourceName, '.');
/* 73 */       if (!convertedName.isEmpty()) {
/* 74 */         return convertedName;
/*    */       }
/*    */     }
/*    */     catch (Exception localException) {}
/*    */     
/* 79 */     return ConfigurationPropertyName.EMPTY;
/*    */   }
/*    */   
/*    */   private static class LastMapping<T, M>
/*    */   {
/*    */     private final T from;
/*    */     private final M mapping;
/*    */     
/*    */     LastMapping(T from, M mapping)
/*    */     {
/* 89 */       this.from = from;
/* 90 */       this.mapping = mapping;
/*    */     }
/*    */     
/*    */     boolean isFrom(T from) {
/* 94 */       return ObjectUtils.nullSafeEquals(from, this.from);
/*    */     }
/*    */     
/*    */     M getMapping() {
/* 98 */       return (M)this.mapping;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\context\properties\source\DefaultPropertyMapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */