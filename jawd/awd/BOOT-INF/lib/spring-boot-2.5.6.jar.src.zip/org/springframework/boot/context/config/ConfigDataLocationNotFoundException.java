/*    */ package org.springframework.boot.context.config;
/*    */ 
/*    */ import org.springframework.boot.origin.Origin;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConfigDataLocationNotFoundException
/*    */   extends ConfigDataNotFoundException
/*    */ {
/*    */   private final ConfigDataLocation location;
/*    */   
/*    */   public ConfigDataLocationNotFoundException(ConfigDataLocation location)
/*    */   {
/* 38 */     this(location, null);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ConfigDataLocationNotFoundException(ConfigDataLocation location, Throwable cause)
/*    */   {
/* 47 */     this(location, getMessage(location), cause);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ConfigDataLocationNotFoundException(ConfigDataLocation location, String message, Throwable cause)
/*    */   {
/* 58 */     super(message, cause);
/* 59 */     Assert.notNull(location, "Location must not be null");
/* 60 */     this.location = location;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public ConfigDataLocation getLocation()
/*    */   {
/* 68 */     return this.location;
/*    */   }
/*    */   
/*    */   public Origin getOrigin()
/*    */   {
/* 73 */     return Origin.from(this.location);
/*    */   }
/*    */   
/*    */   public String getReferenceDescription()
/*    */   {
/* 78 */     return getReferenceDescription(this.location);
/*    */   }
/*    */   
/*    */   private static String getMessage(ConfigDataLocation location) {
/* 82 */     return String.format("Config data %s cannot be found", new Object[] { getReferenceDescription(location) });
/*    */   }
/*    */   
/*    */   private static String getReferenceDescription(ConfigDataLocation location) {
/* 86 */     return String.format("location '%s'", new Object[] { location });
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\context\config\ConfigDataLocationNotFoundException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */