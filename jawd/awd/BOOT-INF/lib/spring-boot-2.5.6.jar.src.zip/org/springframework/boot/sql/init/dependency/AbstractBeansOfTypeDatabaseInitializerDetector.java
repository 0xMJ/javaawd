/*    */ package org.springframework.boot.sql.init.dependency;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.Set;
/*    */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractBeansOfTypeDatabaseInitializerDetector
/*    */   implements DatabaseInitializerDetector
/*    */ {
/*    */   public Set<String> detect(ConfigurableListableBeanFactory beanFactory)
/*    */   {
/*    */     try
/*    */     {
/* 36 */       Set<Class<?>> types = getDatabaseInitializerBeanTypes();
/* 37 */       return new BeansOfTypeDetector(types).detect(beanFactory);
/*    */     }
/*    */     catch (Throwable ex) {}
/* 40 */     return Collections.emptySet();
/*    */   }
/*    */   
/*    */   protected abstract Set<Class<?>> getDatabaseInitializerBeanTypes();
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\sql\init\dependency\AbstractBeansOfTypeDatabaseInitializerDetector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */