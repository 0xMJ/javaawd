/*    */ package org.springframework.boot.context.properties.source;
/*    */ 
/*    */ import org.springframework.boot.origin.Origin;
/*    */ import org.springframework.boot.origin.OriginLookup;
/*    */ import org.springframework.core.env.PropertySource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ConfigurationPropertySourcesPropertySource
/*    */   extends PropertySource<Iterable<ConfigurationPropertySource>>
/*    */   implements OriginLookup<String>
/*    */ {
/*    */   ConfigurationPropertySourcesPropertySource(String name, Iterable<ConfigurationPropertySource> source)
/*    */   {
/* 37 */     super(name, source);
/*    */   }
/*    */   
/*    */   public boolean containsProperty(String name)
/*    */   {
/* 42 */     return findConfigurationProperty(name) != null;
/*    */   }
/*    */   
/*    */   public Object getProperty(String name)
/*    */   {
/* 47 */     ConfigurationProperty configurationProperty = findConfigurationProperty(name);
/* 48 */     return configurationProperty != null ? configurationProperty.getValue() : null;
/*    */   }
/*    */   
/*    */   public Origin getOrigin(String name)
/*    */   {
/* 53 */     return Origin.from(findConfigurationProperty(name));
/*    */   }
/*    */   
/*    */   private ConfigurationProperty findConfigurationProperty(String name) {
/*    */     try {
/* 58 */       return findConfigurationProperty(ConfigurationPropertyName.of(name, true));
/*    */     }
/*    */     catch (Exception ex) {}
/* 61 */     return null;
/*    */   }
/*    */   
/*    */   ConfigurationProperty findConfigurationProperty(ConfigurationPropertyName name)
/*    */   {
/* 66 */     if (name == null) {
/* 67 */       return null;
/*    */     }
/* 69 */     for (ConfigurationPropertySource configurationPropertySource : (Iterable)getSource()) {
/* 70 */       ConfigurationProperty configurationProperty = configurationPropertySource.getConfigurationProperty(name);
/* 71 */       if (configurationProperty != null) {
/* 72 */         return configurationProperty;
/*    */       }
/*    */     }
/* 75 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\context\properties\source\ConfigurationPropertySourcesPropertySource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */