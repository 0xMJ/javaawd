/*    */ package org.springframework.boot.context.properties.source;
/*    */ 
/*    */ import java.util.function.Predicate;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum ConfigurationPropertyState
/*    */ {
/* 35 */   PRESENT, 
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 41 */   ABSENT, 
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 47 */   UNKNOWN;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   private ConfigurationPropertyState() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   static <T> ConfigurationPropertyState search(Iterable<T> source, Predicate<T> predicate)
/*    */   {
/* 59 */     Assert.notNull(source, "Source must not be null");
/* 60 */     Assert.notNull(predicate, "Predicate must not be null");
/* 61 */     for (T item : source) {
/* 62 */       if (predicate.test(item)) {
/* 63 */         return PRESENT;
/*    */       }
/*    */     }
/* 66 */     return ABSENT;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\context\properties\source\ConfigurationPropertyState.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */