/*    */ package org.springframework.boot.context.properties.bind;
/*    */ 
/*    */ import org.springframework.boot.context.properties.source.ConfigurationProperty;
/*    */ import org.springframework.boot.context.properties.source.ConfigurationPropertyName;
/*    */ import org.springframework.boot.origin.Origin;
/*    */ import org.springframework.boot.origin.OriginProvider;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BindException
/*    */   extends RuntimeException
/*    */   implements OriginProvider
/*    */ {
/*    */   private final Bindable<?> target;
/*    */   private final ConfigurationProperty property;
/*    */   private final ConfigurationPropertyName name;
/*    */   
/*    */   BindException(ConfigurationPropertyName name, Bindable<?> target, ConfigurationProperty property, Throwable cause)
/*    */   {
/* 40 */     super(buildMessage(name, target), cause);
/* 41 */     this.name = name;
/* 42 */     this.target = target;
/* 43 */     this.property = property;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public ConfigurationPropertyName getName()
/*    */   {
/* 51 */     return this.name;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public Bindable<?> getTarget()
/*    */   {
/* 59 */     return this.target;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public ConfigurationProperty getProperty()
/*    */   {
/* 67 */     return this.property;
/*    */   }
/*    */   
/*    */   public Origin getOrigin()
/*    */   {
/* 72 */     return Origin.from(this.name);
/*    */   }
/*    */   
/*    */   private static String buildMessage(ConfigurationPropertyName name, Bindable<?> target) {
/* 76 */     StringBuilder message = new StringBuilder();
/* 77 */     message.append("Failed to bind properties");
/* 78 */     message.append(name != null ? " under '" + name + "'" : "");
/* 79 */     message.append(" to ").append(target.getType());
/* 80 */     return message.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\context\properties\bind\BindException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */