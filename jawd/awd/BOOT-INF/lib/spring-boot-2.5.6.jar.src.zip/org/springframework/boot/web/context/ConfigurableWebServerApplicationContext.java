package org.springframework.boot.web.context;

import org.springframework.context.ConfigurableApplicationContext;

public abstract interface ConfigurableWebServerApplicationContext
  extends ConfigurableApplicationContext, WebServerApplicationContext
{
  public abstract void setServerNamespace(String paramString);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\web\context\ConfigurableWebServerApplicationContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */