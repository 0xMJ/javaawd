/*    */ package org.springframework.boot.context.properties;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import java.lang.reflect.Member;
/*    */ import org.springframework.beans.factory.InjectionPoint;
/*    */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*    */ import org.springframework.beans.factory.UnsatisfiedDependencyException;
/*    */ import org.springframework.boot.diagnostics.FailureAnalysis;
/*    */ import org.springframework.boot.diagnostics.analyzer.AbstractInjectionFailureAnalyzer;
/*    */ import org.springframework.core.Ordered;
/*    */ import org.springframework.core.annotation.MergedAnnotation;
/*    */ import org.springframework.core.annotation.MergedAnnotations;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class NotConstructorBoundInjectionFailureAnalyzer
/*    */   extends AbstractInjectionFailureAnalyzer<NoSuchBeanDefinitionException>
/*    */   implements Ordered
/*    */ {
/*    */   public int getOrder()
/*    */   {
/* 43 */     return 0;
/*    */   }
/*    */   
/*    */   protected FailureAnalysis analyze(Throwable rootFailure, NoSuchBeanDefinitionException cause, String description)
/*    */   {
/* 48 */     InjectionPoint injectionPoint = findInjectionPoint(rootFailure);
/* 49 */     if (isConstructorBindingConfigurationProperties(injectionPoint)) {
/* 50 */       String simpleName = injectionPoint.getMember().getDeclaringClass().getSimpleName();
/* 51 */       String action = String.format("Update your configuration so that " + simpleName + " is defined via @" + ConfigurationPropertiesScan.class
/* 52 */         .getSimpleName() + " or @" + EnableConfigurationProperties.class
/* 53 */         .getSimpleName() + ".", new Object[] { simpleName });
/* 54 */       return new FailureAnalysis(simpleName + " is annotated with @" + ConstructorBinding.class
/* 55 */         .getSimpleName() + " but it is defined as a regular bean which caused dependency injection to fail.", action, cause);
/*    */     }
/*    */     
/*    */ 
/* 59 */     return null;
/*    */   }
/*    */   
/*    */   private boolean isConstructorBindingConfigurationProperties(InjectionPoint injectionPoint) {
/* 63 */     if ((injectionPoint != null) && ((injectionPoint.getMember() instanceof Constructor))) {
/* 64 */       Constructor<?> constructor = (Constructor)injectionPoint.getMember();
/* 65 */       Class<?> declaringClass = constructor.getDeclaringClass();
/*    */       
/* 67 */       MergedAnnotation<ConfigurationProperties> configurationProperties = MergedAnnotations.from(declaringClass).get(ConfigurationProperties.class);
/* 68 */       return (configurationProperties.isPresent()) && 
/* 69 */         (ConfigurationPropertiesBean.BindMethod.forType(constructor.getDeclaringClass()) == ConfigurationPropertiesBean.BindMethod.VALUE_OBJECT);
/*    */     }
/* 71 */     return false;
/*    */   }
/*    */   
/*    */   private InjectionPoint findInjectionPoint(Throwable failure) {
/* 75 */     UnsatisfiedDependencyException unsatisfiedDependencyException = (UnsatisfiedDependencyException)findCause(failure, UnsatisfiedDependencyException.class);
/*    */     
/* 77 */     if (unsatisfiedDependencyException == null) {
/* 78 */       return null;
/*    */     }
/* 80 */     return unsatisfiedDependencyException.getInjectionPoint();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\context\properties\NotConstructorBoundInjectionFailureAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */