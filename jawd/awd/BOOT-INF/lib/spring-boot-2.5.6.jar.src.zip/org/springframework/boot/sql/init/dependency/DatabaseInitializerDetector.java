/*    */ package org.springframework.boot.sql.init.dependency;
/*    */ 
/*    */ import java.util.Set;
/*    */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*    */ import org.springframework.core.Ordered;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract interface DatabaseInitializerDetector
/*    */   extends Ordered
/*    */ {
/*    */   public abstract Set<String> detect(ConfigurableListableBeanFactory paramConfigurableListableBeanFactory);
/*    */   
/*    */   public void detectionComplete(ConfigurableListableBeanFactory beanFactory, Set<String> dataSourceInitializerNames) {}
/*    */   
/*    */   public int getOrder()
/*    */   {
/* 58 */     return 0;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\sql\init\dependency\DatabaseInitializerDetector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */