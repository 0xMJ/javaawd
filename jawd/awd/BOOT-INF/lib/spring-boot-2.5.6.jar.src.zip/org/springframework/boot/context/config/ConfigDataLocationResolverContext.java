package org.springframework.boot.context.config;

import org.springframework.boot.ConfigurableBootstrapContext;
import org.springframework.boot.context.properties.bind.Binder;

public abstract interface ConfigDataLocationResolverContext
{
  public abstract Binder getBinder();
  
  public abstract ConfigDataResource getParent();
  
  public abstract ConfigurableBootstrapContext getBootstrapContext();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\context\config\ConfigDataLocationResolverContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */