/*    */ package org.springframework.boot.diagnostics;
/*    */ 
/*    */ import org.springframework.core.ResolvableType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractFailureAnalyzer<T extends Throwable>
/*    */   implements FailureAnalyzer
/*    */ {
/*    */   public FailureAnalysis analyze(Throwable failure)
/*    */   {
/* 33 */     T cause = findCause(failure, getCauseType());
/* 34 */     if (cause != null) {
/* 35 */       return analyze(failure, cause);
/*    */     }
/* 37 */     return null;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected abstract FailureAnalysis analyze(Throwable paramThrowable, T paramT);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected Class<? extends T> getCauseType()
/*    */   {
/* 56 */     return ResolvableType.forClass(AbstractFailureAnalyzer.class, getClass()).resolveGeneric(new int[0]);
/*    */   }
/*    */   
/*    */   protected final <E extends Throwable> E findCause(Throwable failure, Class<E> type)
/*    */   {
/* 61 */     while (failure != null) {
/* 62 */       if (type.isInstance(failure)) {
/* 63 */         return failure;
/*    */       }
/* 65 */       failure = failure.getCause();
/*    */     }
/* 67 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\diagnostics\AbstractFailureAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */