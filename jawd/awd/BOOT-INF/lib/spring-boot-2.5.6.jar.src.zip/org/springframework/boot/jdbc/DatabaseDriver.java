/*     */ package org.springframework.boot.jdbc;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Locale;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum DatabaseDriver
/*     */ {
/*  41 */   UNKNOWN(null, null), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  46 */   DERBY("Apache Derby", "org.apache.derby.jdbc.EmbeddedDriver", "org.apache.derby.jdbc.EmbeddedXADataSource", "SELECT 1 FROM SYSIBM.SYSDUMMY1"), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  52 */   H2("H2", "org.h2.Driver", "org.h2.jdbcx.JdbcDataSource", "SELECT 1"), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  57 */   HSQLDB("HSQL Database Engine", "org.hsqldb.jdbc.JDBCDriver", "org.hsqldb.jdbc.pool.JDBCXADataSource", "SELECT COUNT(*) FROM INFORMATION_SCHEMA.SYSTEM_USERS"), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  63 */   SQLITE("SQLite", "org.sqlite.JDBC"), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  68 */   MYSQL("MySQL", "com.mysql.cj.jdbc.Driver", "com.mysql.cj.jdbc.MysqlXADataSource", "/* ping */ SELECT 1"), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  73 */   MARIADB("MariaDB", "org.mariadb.jdbc.Driver", "org.mariadb.jdbc.MariaDbDataSource", "SELECT 1"), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  84 */   GAE(null, "com.google.appengine.api.rdbms.AppEngineDriver"), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  89 */   ORACLE("Oracle", "oracle.jdbc.OracleDriver", "oracle.jdbc.xa.client.OracleXADataSource", "SELECT 'Hello' from DUAL"), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  95 */   POSTGRESQL("PostgreSQL", "org.postgresql.Driver", "org.postgresql.xa.PGXADataSource", "SELECT 1"), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 101 */   REDSHIFT("Redshift", "com.amazon.redshift.jdbc.Driver", null, "SELECT 1"), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 107 */   HANA("HDB", "com.sap.db.jdbc.Driver", "com.sap.db.jdbcext.XADataSourceSAP", "SELECT 1 FROM SYS.DUMMY"), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 118 */   JTDS(null, "net.sourceforge.jtds.jdbc.Driver"), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 123 */   SQLSERVER("Microsoft SQL Server", "com.microsoft.sqlserver.jdbc.SQLServerDriver", "com.microsoft.sqlserver.jdbc.SQLServerXADataSource", "SELECT 1"), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 136 */   FIREBIRD("Firebird", "org.firebirdsql.jdbc.FBDriver", "org.firebirdsql.ds.FBXADataSource", "SELECT 1 FROM RDB$DATABASE"), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 154 */   DB2("DB2", "com.ibm.db2.jcc.DB2Driver", "com.ibm.db2.jcc.DB2XADataSource", "SELECT 1 FROM SYSIBM.SYSDUMMY1"), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 165 */   DB2_AS400("DB2 UDB for AS/400", "com.ibm.as400.access.AS400JDBCDriver", "com.ibm.as400.access.AS400JDBCXADataSource", "SELECT 1 FROM SYSIBM.SYSDUMMY1"), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 187 */   TERADATA("Teradata", "com.teradata.jdbc.TeraDriver"), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 192 */   INFORMIX("Informix Dynamic Server", "com.informix.jdbc.IfxDriver", null, "select count(*) from systables"), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 205 */   PHOENIX("Apache Phoenix", "org.apache.phoenix.jdbc.PhoenixDriver", null, "SELECT 1 FROM SYSTEM.CATALOG LIMIT 1"), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 210 */   TESTCONTAINERS(null, "org.testcontainers.jdbc.ContainerDatabaseDriver");
/*     */   
/*     */ 
/*     */ 
/*     */   private final String productName;
/*     */   
/*     */ 
/*     */   private final String driverClassName;
/*     */   
/*     */ 
/*     */   private final String xaDataSourceClassName;
/*     */   
/*     */ 
/*     */   private final String validationQuery;
/*     */   
/*     */ 
/*     */   private DatabaseDriver(String productName, String driverClassName)
/*     */   {
/* 228 */     this(productName, driverClassName, null);
/*     */   }
/*     */   
/*     */   private DatabaseDriver(String productName, String driverClassName, String xaDataSourceClassName) {
/* 232 */     this(productName, driverClassName, xaDataSourceClassName, null);
/*     */   }
/*     */   
/*     */   private DatabaseDriver(String productName, String driverClassName, String xaDataSourceClassName, String validationQuery) {
/* 236 */     this.productName = productName;
/* 237 */     this.driverClassName = driverClassName;
/* 238 */     this.xaDataSourceClassName = xaDataSourceClassName;
/* 239 */     this.validationQuery = validationQuery;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getId()
/*     */   {
/* 247 */     return name().toLowerCase(Locale.ENGLISH);
/*     */   }
/*     */   
/*     */   protected boolean matchProductName(String productName) {
/* 251 */     return (this.productName != null) && (this.productName.equalsIgnoreCase(productName));
/*     */   }
/*     */   
/*     */   protected Collection<String> getUrlPrefixes() {
/* 255 */     return Collections.singleton(name().toLowerCase(Locale.ENGLISH));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getDriverClassName()
/*     */   {
/* 263 */     return this.driverClassName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getXaDataSourceClassName()
/*     */   {
/* 271 */     return this.xaDataSourceClassName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getValidationQuery()
/*     */   {
/* 279 */     return this.validationQuery;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static DatabaseDriver fromJdbcUrl(String url)
/*     */   {
/* 288 */     if (StringUtils.hasLength(url)) {
/* 289 */       Assert.isTrue(url.startsWith("jdbc"), "URL must start with 'jdbc'");
/* 290 */       String urlWithoutPrefix = url.substring("jdbc".length()).toLowerCase(Locale.ENGLISH);
/* 291 */       DatabaseDriver driver; for (driver : values()) {
/* 292 */         for (String urlPrefix : driver.getUrlPrefixes()) {
/* 293 */           String prefix = ":" + urlPrefix + ":";
/* 294 */           if ((driver != UNKNOWN) && (urlWithoutPrefix.startsWith(prefix))) {
/* 295 */             return driver;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 300 */     return UNKNOWN;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static DatabaseDriver fromProductName(String productName)
/*     */   {
/* 309 */     if (StringUtils.hasLength(productName)) {
/* 310 */       for (DatabaseDriver candidate : values()) {
/* 311 */         if (candidate.matchProductName(productName)) {
/* 312 */           return candidate;
/*     */         }
/*     */       }
/*     */     }
/* 316 */     return UNKNOWN;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\jdbc\DatabaseDriver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */