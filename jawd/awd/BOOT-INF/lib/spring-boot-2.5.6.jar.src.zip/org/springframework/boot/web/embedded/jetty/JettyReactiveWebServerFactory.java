/*     */ package org.springframework.boot.web.embedded.jetty;
/*     */ 
/*     */ import java.net.InetSocketAddress;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.eclipse.jetty.http2.server.HTTP2CServerConnectionFactory;
/*     */ import org.eclipse.jetty.server.AbstractConnector;
/*     */ import org.eclipse.jetty.server.ConnectionFactory;
/*     */ import org.eclipse.jetty.server.Handler;
/*     */ import org.eclipse.jetty.server.HttpConfiguration;
/*     */ import org.eclipse.jetty.server.HttpConnectionFactory;
/*     */ import org.eclipse.jetty.server.Server;
/*     */ import org.eclipse.jetty.server.ServerConnector;
/*     */ import org.eclipse.jetty.server.handler.HandlerWrapper;
/*     */ import org.eclipse.jetty.server.handler.StatisticsHandler;
/*     */ import org.eclipse.jetty.servlet.ServletContextHandler;
/*     */ import org.eclipse.jetty.servlet.ServletHolder;
/*     */ import org.eclipse.jetty.util.thread.ThreadPool;
/*     */ import org.springframework.boot.web.reactive.server.AbstractReactiveWebServerFactory;
/*     */ import org.springframework.boot.web.server.Compression;
/*     */ import org.springframework.boot.web.server.Http2;
/*     */ import org.springframework.boot.web.server.Shutdown;
/*     */ import org.springframework.boot.web.server.Ssl;
/*     */ import org.springframework.boot.web.server.WebServer;
/*     */ import org.springframework.http.client.reactive.JettyResourceFactory;
/*     */ import org.springframework.http.server.reactive.HttpHandler;
/*     */ import org.springframework.http.server.reactive.JettyHttpHandlerAdapter;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JettyReactiveWebServerFactory
/*     */   extends AbstractReactiveWebServerFactory
/*     */   implements ConfigurableJettyWebServerFactory
/*     */ {
/*  62 */   private static final Log logger = LogFactory.getLog(JettyReactiveWebServerFactory.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  67 */   private int acceptors = -1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  72 */   private int selectors = -1;
/*     */   
/*     */   private boolean useForwardHeaders;
/*     */   
/*  76 */   private Set<JettyServerCustomizer> jettyServerCustomizers = new LinkedHashSet();
/*     */   
/*     */ 
/*     */ 
/*     */   private JettyResourceFactory resourceFactory;
/*     */   
/*     */ 
/*     */ 
/*     */   private ThreadPool threadPool;
/*     */   
/*     */ 
/*     */ 
/*     */   public JettyReactiveWebServerFactory() {}
/*     */   
/*     */ 
/*     */ 
/*     */   public JettyReactiveWebServerFactory(int port)
/*     */   {
/*  94 */     super(port);
/*     */   }
/*     */   
/*     */   public void setUseForwardHeaders(boolean useForwardHeaders)
/*     */   {
/*  99 */     this.useForwardHeaders = useForwardHeaders;
/*     */   }
/*     */   
/*     */   public void setAcceptors(int acceptors)
/*     */   {
/* 104 */     this.acceptors = acceptors;
/*     */   }
/*     */   
/*     */   public WebServer getWebServer(HttpHandler httpHandler)
/*     */   {
/* 109 */     JettyHttpHandlerAdapter servlet = new JettyHttpHandlerAdapter(httpHandler);
/* 110 */     Server server = createJettyServer(servlet);
/* 111 */     return new JettyWebServer(server, getPort() >= 0);
/*     */   }
/*     */   
/*     */   public void addServerCustomizers(JettyServerCustomizer... customizers)
/*     */   {
/* 116 */     Assert.notNull(customizers, "Customizers must not be null");
/* 117 */     this.jettyServerCustomizers.addAll(Arrays.asList(customizers));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setServerCustomizers(Collection<? extends JettyServerCustomizer> customizers)
/*     */   {
/* 126 */     Assert.notNull(customizers, "Customizers must not be null");
/* 127 */     this.jettyServerCustomizers = new LinkedHashSet(customizers);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Collection<JettyServerCustomizer> getServerCustomizers()
/*     */   {
/* 136 */     return this.jettyServerCustomizers;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ThreadPool getThreadPool()
/*     */   {
/* 144 */     return this.threadPool;
/*     */   }
/*     */   
/*     */   public void setThreadPool(ThreadPool threadPool)
/*     */   {
/* 149 */     this.threadPool = threadPool;
/*     */   }
/*     */   
/*     */   public void setSelectors(int selectors)
/*     */   {
/* 154 */     this.selectors = selectors;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setResourceFactory(JettyResourceFactory resourceFactory)
/*     */   {
/* 163 */     this.resourceFactory = resourceFactory;
/*     */   }
/*     */   
/*     */   protected JettyResourceFactory getResourceFactory() {
/* 167 */     return this.resourceFactory;
/*     */   }
/*     */   
/*     */   protected Server createJettyServer(JettyHttpHandlerAdapter servlet) {
/* 171 */     int port = Math.max(getPort(), 0);
/* 172 */     InetSocketAddress address = new InetSocketAddress(getAddress(), port);
/* 173 */     Server server = new Server(getThreadPool());
/* 174 */     server.addConnector(createConnector(address, server));
/* 175 */     server.setStopTimeout(0L);
/* 176 */     ServletHolder servletHolder = new ServletHolder(servlet);
/* 177 */     servletHolder.setAsyncSupported(true);
/* 178 */     ServletContextHandler contextHandler = new ServletContextHandler(server, "/", false, false);
/* 179 */     contextHandler.addServlet(servletHolder, "/");
/* 180 */     server.setHandler(addHandlerWrappers(contextHandler));
/* 181 */     logger.info("Server initialized with port: " + port);
/* 182 */     if ((getSsl() != null) && (getSsl().isEnabled())) {
/* 183 */       customizeSsl(server, address);
/*     */     }
/* 185 */     for (JettyServerCustomizer customizer : getServerCustomizers()) {
/* 186 */       customizer.customize(server);
/*     */     }
/* 188 */     if (this.useForwardHeaders) {
/* 189 */       new ForwardHeadersCustomizer().customize(server);
/*     */     }
/* 191 */     if (getShutdown() == Shutdown.GRACEFUL) {
/* 192 */       StatisticsHandler statisticsHandler = new StatisticsHandler();
/* 193 */       statisticsHandler.setHandler(server.getHandler());
/* 194 */       server.setHandler(statisticsHandler);
/*     */     }
/* 196 */     return server;
/*     */   }
/*     */   
/*     */   private AbstractConnector createConnector(InetSocketAddress address, Server server) {
/* 200 */     HttpConfiguration httpConfiguration = new HttpConfiguration();
/* 201 */     httpConfiguration.setSendServerVersion(false);
/* 202 */     List<ConnectionFactory> connectionFactories = new ArrayList();
/* 203 */     connectionFactories.add(new HttpConnectionFactory(httpConfiguration));
/* 204 */     if ((getHttp2() != null) && (getHttp2().isEnabled())) {
/* 205 */       connectionFactories.add(new HTTP2CServerConnectionFactory(httpConfiguration));
/*     */     }
/* 207 */     JettyResourceFactory resourceFactory = getResourceFactory();
/*     */     ServerConnector connector;
/* 209 */     ServerConnector connector; if (resourceFactory != null)
/*     */     {
/*     */ 
/* 212 */       connector = new ServerConnector(server, resourceFactory.getExecutor(), resourceFactory.getScheduler(), resourceFactory.getByteBufferPool(), this.acceptors, this.selectors, (ConnectionFactory[])connectionFactories.toArray(new ConnectionFactory[0]));
/*     */     }
/*     */     else
/*     */     {
/* 216 */       connector = new ServerConnector(server, this.acceptors, this.selectors, (ConnectionFactory[])connectionFactories.toArray(new ConnectionFactory[0]));
/*     */     }
/* 218 */     connector.setHost(address.getHostString());
/* 219 */     connector.setPort(address.getPort());
/* 220 */     return connector;
/*     */   }
/*     */   
/*     */   private Handler addHandlerWrappers(Handler handler) {
/* 224 */     if ((getCompression() != null) && (getCompression().getEnabled())) {
/* 225 */       handler = applyWrapper(handler, JettyHandlerWrappers.createGzipHandlerWrapper(getCompression()));
/*     */     }
/* 227 */     if (StringUtils.hasText(getServerHeader())) {
/* 228 */       handler = applyWrapper(handler, JettyHandlerWrappers.createServerHeaderHandlerWrapper(getServerHeader()));
/*     */     }
/* 230 */     return handler;
/*     */   }
/*     */   
/*     */   private Handler applyWrapper(Handler handler, HandlerWrapper wrapper) {
/* 234 */     wrapper.setHandler(handler);
/* 235 */     return wrapper;
/*     */   }
/*     */   
/*     */   private void customizeSsl(Server server, InetSocketAddress address) {
/* 239 */     new SslServerCustomizer(address, getSsl(), getSslStoreProvider(), getHttp2()).customize(server);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\web\embedded\jetty\JettyReactiveWebServerFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */