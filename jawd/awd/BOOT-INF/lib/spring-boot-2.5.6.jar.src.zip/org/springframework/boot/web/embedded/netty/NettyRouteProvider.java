package org.springframework.boot.web.embedded.netty;

import java.util.function.Function;
import reactor.netty.http.server.HttpServerRoutes;

@FunctionalInterface
public abstract interface NettyRouteProvider
  extends Function<HttpServerRoutes, HttpServerRoutes>
{}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\web\embedded\netty\NettyRouteProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */