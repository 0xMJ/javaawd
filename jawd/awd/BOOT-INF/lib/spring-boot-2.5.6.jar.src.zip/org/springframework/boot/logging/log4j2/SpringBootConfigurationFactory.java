/*    */ package org.springframework.boot.logging.log4j2;
/*    */ 
/*    */ import org.apache.logging.log4j.core.LoggerContext;
/*    */ import org.apache.logging.log4j.core.config.Configuration;
/*    */ import org.apache.logging.log4j.core.config.ConfigurationFactory;
/*    */ import org.apache.logging.log4j.core.config.ConfigurationSource;
/*    */ import org.apache.logging.log4j.core.config.DefaultConfiguration;
/*    */ import org.apache.logging.log4j.core.config.Order;
/*    */ import org.apache.logging.log4j.core.config.plugins.Plugin;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Plugin(name="SpringBootConfigurationFactory", category="ConfigurationFactory")
/*    */ @Order(0)
/*    */ public class SpringBootConfigurationFactory
/*    */   extends ConfigurationFactory
/*    */ {
/* 47 */   private static final String[] TYPES = { ".springboot" };
/*    */   
/*    */   protected String[] getSupportedTypes()
/*    */   {
/* 51 */     return TYPES;
/*    */   }
/*    */   
/*    */   public Configuration getConfiguration(LoggerContext loggerContext, ConfigurationSource source)
/*    */   {
/* 56 */     if ((source == null) || (source == ConfigurationSource.NULL_SOURCE)) {
/* 57 */       return null;
/*    */     }
/* 59 */     return new DefaultConfiguration();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\logging\log4j2\SpringBootConfigurationFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */