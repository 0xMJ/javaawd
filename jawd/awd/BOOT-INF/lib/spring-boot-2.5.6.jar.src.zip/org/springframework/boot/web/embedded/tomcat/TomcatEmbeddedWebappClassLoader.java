/*     */ package org.springframework.boot.web.embedded.tomcat;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import org.apache.catalina.loader.ParallelWebappClassLoader;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.tomcat.util.compat.JreCompat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TomcatEmbeddedWebappClassLoader
/*     */   extends ParallelWebappClassLoader
/*     */ {
/*  41 */   private static final Log logger = LogFactory.getLog(TomcatEmbeddedWebappClassLoader.class);
/*     */   
/*     */   static {
/*  44 */     if (!JreCompat.isGraalAvailable()) {
/*  45 */       ClassLoader.registerAsParallelCapable();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public TomcatEmbeddedWebappClassLoader(ClassLoader parent)
/*     */   {
/*  53 */     super(parent);
/*     */   }
/*     */   
/*     */   public URL findResource(String name)
/*     */   {
/*  58 */     return null;
/*     */   }
/*     */   
/*     */   public Enumeration<URL> findResources(String name) throws IOException
/*     */   {
/*  63 */     return Collections.emptyEnumeration();
/*     */   }
/*     */   
/*     */   public Class<?> loadClass(String name, boolean resolve) throws ClassNotFoundException
/*     */   {
/*  68 */     synchronized (JreCompat.isGraalAvailable() ? this : getClassLoadingLock(name)) {
/*  69 */       Class<?> result = findExistingLoadedClass(name);
/*  70 */       result = result != null ? result : doLoadClass(name);
/*  71 */       if (result == null) {
/*  72 */         throw new ClassNotFoundException(name);
/*     */       }
/*  74 */       return resolveIfNecessary(result, resolve);
/*     */     }
/*     */   }
/*     */   
/*     */   private Class<?> findExistingLoadedClass(String name) {
/*  79 */     Class<?> resultClass = findLoadedClass0(name);
/*  80 */     resultClass = (resultClass != null) || (JreCompat.isGraalAvailable()) ? resultClass : findLoadedClass(name);
/*  81 */     return resultClass;
/*     */   }
/*     */   
/*     */   private Class<?> doLoadClass(String name) throws ClassNotFoundException {
/*  85 */     checkPackageAccess(name);
/*  86 */     if ((this.delegate) || (filter(name, true))) {
/*  87 */       Class<?> result = loadFromParent(name);
/*  88 */       return result != null ? result : findClassIgnoringNotFound(name);
/*     */     }
/*  90 */     Class<?> result = findClassIgnoringNotFound(name);
/*  91 */     return result != null ? result : loadFromParent(name);
/*     */   }
/*     */   
/*     */   private Class<?> resolveIfNecessary(Class<?> resultClass, boolean resolve) {
/*  95 */     if (resolve) {
/*  96 */       resolveClass(resultClass);
/*     */     }
/*  98 */     return resultClass;
/*     */   }
/*     */   
/*     */ 
/*     */   protected void addURL(URL url)
/*     */   {
/* 104 */     if (logger.isTraceEnabled()) {
/* 105 */       logger.trace("Ignoring request to add " + url + " to the tomcat classloader");
/*     */     }
/*     */   }
/*     */   
/*     */   private Class<?> loadFromParent(String name) {
/* 110 */     if (this.parent == null) {
/* 111 */       return null;
/*     */     }
/*     */     try {
/* 114 */       return Class.forName(name, false, this.parent);
/*     */     }
/*     */     catch (ClassNotFoundException ex) {}
/* 117 */     return null;
/*     */   }
/*     */   
/*     */   private Class<?> findClassIgnoringNotFound(String name)
/*     */   {
/*     */     try {
/* 123 */       return findClass(name);
/*     */     }
/*     */     catch (ClassNotFoundException ex) {}
/* 126 */     return null;
/*     */   }
/*     */   
/*     */   private void checkPackageAccess(String name) throws ClassNotFoundException
/*     */   {
/* 131 */     if ((this.securityManager != null) && (name.lastIndexOf('.') >= 0)) {
/*     */       try {
/* 133 */         this.securityManager.checkPackageAccess(name.substring(0, name.lastIndexOf('.')));
/*     */       }
/*     */       catch (SecurityException ex) {
/* 136 */         throw new ClassNotFoundException("Security Violation, attempt to use Restricted Class: " + name, ex);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public TomcatEmbeddedWebappClassLoader() {}
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\web\embedded\tomcat\TomcatEmbeddedWebappClassLoader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */