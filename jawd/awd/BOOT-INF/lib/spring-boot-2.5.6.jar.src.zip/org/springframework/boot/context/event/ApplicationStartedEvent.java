/*    */ package org.springframework.boot.context.event;
/*    */ 
/*    */ import org.springframework.boot.SpringApplication;
/*    */ import org.springframework.context.ConfigurableApplicationContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ApplicationStartedEvent
/*    */   extends SpringApplicationEvent
/*    */ {
/*    */   private final ConfigurableApplicationContext context;
/*    */   
/*    */   public ApplicationStartedEvent(SpringApplication application, String[] args, ConfigurableApplicationContext context)
/*    */   {
/* 45 */     super(application, args);
/* 46 */     this.context = context;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public ConfigurableApplicationContext getApplicationContext()
/*    */   {
/* 54 */     return this.context;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\context\event\ApplicationStartedEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */