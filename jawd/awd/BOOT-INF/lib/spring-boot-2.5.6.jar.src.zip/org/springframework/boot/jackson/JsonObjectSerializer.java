/*    */ package org.springframework.boot.jackson;
/*    */ 
/*    */ import com.fasterxml.jackson.core.JsonGenerator;
/*    */ import com.fasterxml.jackson.databind.JsonMappingException;
/*    */ import com.fasterxml.jackson.databind.JsonSerializer;
/*    */ import com.fasterxml.jackson.databind.SerializerProvider;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class JsonObjectSerializer<T>
/*    */   extends JsonSerializer<T>
/*    */ {
/*    */   public final void serialize(T value, JsonGenerator jgen, SerializerProvider provider)
/*    */     throws IOException
/*    */   {
/*    */     try
/*    */     {
/* 39 */       jgen.writeStartObject();
/* 40 */       serializeObject(value, jgen, provider);
/* 41 */       jgen.writeEndObject();
/*    */     }
/*    */     catch (Exception ex) {
/* 44 */       if ((ex instanceof IOException)) {
/* 45 */         throw ((IOException)ex);
/*    */       }
/* 47 */       throw new JsonMappingException(jgen, "Object serialize error", ex);
/*    */     }
/*    */   }
/*    */   
/*    */   protected abstract void serializeObject(T paramT, JsonGenerator paramJsonGenerator, SerializerProvider paramSerializerProvider)
/*    */     throws IOException;
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\jackson\JsonObjectSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */