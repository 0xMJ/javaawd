/*     */ package org.springframework.boot.context.properties;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.springframework.beans.factory.ListableBeanFactory;
/*     */ import org.springframework.beans.factory.annotation.BeanFactoryAnnotationUtils;
/*     */ import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.boot.convert.ApplicationConversionService;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ConfigurableApplicationContext;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.core.convert.converter.Converter;
/*     */ import org.springframework.core.convert.converter.GenericConverter;
/*     */ import org.springframework.format.Formatter;
/*     */ import org.springframework.format.FormatterRegistry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ConversionServiceDeducer
/*     */ {
/*     */   private final ApplicationContext applicationContext;
/*     */   
/*     */   ConversionServiceDeducer(ApplicationContext applicationContext)
/*     */   {
/*  46 */     this.applicationContext = applicationContext;
/*     */   }
/*     */   
/*     */   List<ConversionService> getConversionServices() {
/*  50 */     if (hasUserDefinedConfigurationServiceBean()) {
/*  51 */       return Collections.singletonList(this.applicationContext
/*  52 */         .getBean("conversionService", ConversionService.class));
/*     */     }
/*  54 */     if ((this.applicationContext instanceof ConfigurableApplicationContext)) {
/*  55 */       return getConversionServices((ConfigurableApplicationContext)this.applicationContext);
/*     */     }
/*  57 */     return null;
/*     */   }
/*     */   
/*     */   private List<ConversionService> getConversionServices(ConfigurableApplicationContext applicationContext) {
/*  61 */     List<ConversionService> conversionServices = new ArrayList();
/*  62 */     if (applicationContext.getBeanFactory().getConversionService() != null) {
/*  63 */       conversionServices.add(applicationContext.getBeanFactory().getConversionService());
/*     */     }
/*  65 */     ConverterBeans converterBeans = new ConverterBeans(applicationContext);
/*  66 */     if (!converterBeans.isEmpty()) {
/*  67 */       ApplicationConversionService beansConverterService = new ApplicationConversionService();
/*  68 */       converterBeans.addTo(beansConverterService);
/*  69 */       conversionServices.add(beansConverterService);
/*     */     }
/*  71 */     return conversionServices;
/*     */   }
/*     */   
/*     */   private boolean hasUserDefinedConfigurationServiceBean() {
/*  75 */     String beanName = "conversionService";
/*  76 */     return (this.applicationContext.containsBean(beanName)) && 
/*  77 */       (this.applicationContext.getAutowireCapableBeanFactory().isTypeMatch(beanName, ConversionService.class));
/*     */   }
/*     */   
/*     */ 
/*     */   private static class ConverterBeans
/*     */   {
/*     */     private final List<Converter> converters;
/*     */     
/*     */     private final List<GenericConverter> genericConverters;
/*     */     
/*     */     private final List<Formatter> formatters;
/*     */     
/*     */     ConverterBeans(ConfigurableApplicationContext applicationContext)
/*     */     {
/*  91 */       ConfigurableListableBeanFactory beanFactory = applicationContext.getBeanFactory();
/*  92 */       this.converters = beans(Converter.class, "org.springframework.boot.context.properties.ConfigurationPropertiesBinding", beanFactory);
/*  93 */       this.genericConverters = beans(GenericConverter.class, "org.springframework.boot.context.properties.ConfigurationPropertiesBinding", beanFactory);
/*  94 */       this.formatters = beans(Formatter.class, "org.springframework.boot.context.properties.ConfigurationPropertiesBinding", beanFactory);
/*     */     }
/*     */     
/*     */     private <T> List<T> beans(Class<T> type, String qualifier, ListableBeanFactory beanFactory) {
/*  98 */       return new ArrayList(
/*  99 */         BeanFactoryAnnotationUtils.qualifiedBeansOfType(beanFactory, type, qualifier).values());
/*     */     }
/*     */     
/*     */     boolean isEmpty() {
/* 103 */       return (this.converters.isEmpty()) && (this.genericConverters.isEmpty()) && (this.formatters.isEmpty());
/*     */     }
/*     */     
/*     */     void addTo(FormatterRegistry registry) {
/* 107 */       for (Converter<?, ?> converter : this.converters) {
/* 108 */         registry.addConverter(converter);
/*     */       }
/* 110 */       for (GenericConverter genericConverter : this.genericConverters) {
/* 111 */         registry.addConverter(genericConverter);
/*     */       }
/* 113 */       for (Formatter<?> formatter : this.formatters) {
/* 114 */         registry.addFormatter(formatter);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\context\properties\ConversionServiceDeducer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */