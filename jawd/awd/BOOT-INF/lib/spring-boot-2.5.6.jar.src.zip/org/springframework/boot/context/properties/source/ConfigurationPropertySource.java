/*     */ package org.springframework.boot.context.properties.source;
/*     */ 
/*     */ import java.util.function.Predicate;
/*     */ import org.springframework.core.env.PropertySource;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @FunctionalInterface
/*     */ public abstract interface ConfigurationPropertySource
/*     */ {
/*     */   public abstract ConfigurationProperty getConfigurationProperty(ConfigurationPropertyName paramConfigurationPropertyName);
/*     */   
/*     */   public ConfigurationPropertyState containsDescendantOf(ConfigurationPropertyName name)
/*     */   {
/*  56 */     return ConfigurationPropertyState.UNKNOWN;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ConfigurationPropertySource filter(Predicate<ConfigurationPropertyName> filter)
/*     */   {
/*  66 */     return new FilteredConfigurationPropertiesSource(this, filter);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ConfigurationPropertySource withAliases(ConfigurationPropertyNameAliases aliases)
/*     */   {
/*  75 */     return new AliasedConfigurationPropertySource(this, aliases);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ConfigurationPropertySource withPrefix(String prefix)
/*     */   {
/*  85 */     return StringUtils.hasText(prefix) ? new PrefixedConfigurationPropertySource(this, prefix) : this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getUnderlyingSource()
/*     */   {
/*  93 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ConfigurationPropertySource from(PropertySource<?> source)
/*     */   {
/* 104 */     if ((source instanceof ConfigurationPropertySourcesPropertySource)) {
/* 105 */       return null;
/*     */     }
/* 107 */     return SpringConfigurationPropertySource.from(source);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\context\properties\source\ConfigurationPropertySource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */