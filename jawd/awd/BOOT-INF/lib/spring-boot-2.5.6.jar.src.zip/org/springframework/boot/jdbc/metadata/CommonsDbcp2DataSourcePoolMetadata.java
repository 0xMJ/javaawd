/*    */ package org.springframework.boot.jdbc.metadata;
/*    */ 
/*    */ import org.apache.commons.dbcp2.BasicDataSource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CommonsDbcp2DataSourcePoolMetadata
/*    */   extends AbstractDataSourcePoolMetadata<BasicDataSource>
/*    */ {
/*    */   public CommonsDbcp2DataSourcePoolMetadata(BasicDataSource dataSource)
/*    */   {
/* 32 */     super(dataSource);
/*    */   }
/*    */   
/*    */   public Integer getActive()
/*    */   {
/* 37 */     return Integer.valueOf(((BasicDataSource)getDataSource()).getNumActive());
/*    */   }
/*    */   
/*    */   public Integer getIdle()
/*    */   {
/* 42 */     return Integer.valueOf(((BasicDataSource)getDataSource()).getNumIdle());
/*    */   }
/*    */   
/*    */   public Integer getMax()
/*    */   {
/* 47 */     return Integer.valueOf(((BasicDataSource)getDataSource()).getMaxTotal());
/*    */   }
/*    */   
/*    */   public Integer getMin()
/*    */   {
/* 52 */     return Integer.valueOf(((BasicDataSource)getDataSource()).getMinIdle());
/*    */   }
/*    */   
/*    */   public String getValidationQuery()
/*    */   {
/* 57 */     return ((BasicDataSource)getDataSource()).getValidationQuery();
/*    */   }
/*    */   
/*    */   public Boolean getDefaultAutoCommit()
/*    */   {
/* 62 */     return ((BasicDataSource)getDataSource()).getDefaultAutoCommit();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\jdbc\metadata\CommonsDbcp2DataSourcePoolMetadata.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */