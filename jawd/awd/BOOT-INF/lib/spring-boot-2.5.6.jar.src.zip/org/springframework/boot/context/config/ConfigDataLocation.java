/*     */ package org.springframework.boot.context.config;
/*     */ 
/*     */ import org.springframework.boot.origin.Origin;
/*     */ import org.springframework.boot.origin.OriginProvider;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ConfigDataLocation
/*     */   implements OriginProvider
/*     */ {
/*     */   public static final String OPTIONAL_PREFIX = "optional:";
/*     */   private final boolean optional;
/*     */   private final String value;
/*     */   private final Origin origin;
/*     */   
/*     */   private ConfigDataLocation(boolean optional, String value, Origin origin)
/*     */   {
/*  50 */     this.value = value;
/*  51 */     this.optional = optional;
/*  52 */     this.origin = origin;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isOptional()
/*     */   {
/*  61 */     return this.optional;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getValue()
/*     */   {
/*  70 */     return this.value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasPrefix(String prefix)
/*     */   {
/*  79 */     return this.value.startsWith(prefix);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getNonPrefixedValue(String prefix)
/*     */   {
/*  89 */     if (hasPrefix(prefix)) {
/*  90 */       return this.value.substring(prefix.length());
/*     */     }
/*  92 */     return this.value;
/*     */   }
/*     */   
/*     */   public Origin getOrigin()
/*     */   {
/*  97 */     return this.origin;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ConfigDataLocation[] split()
/*     */   {
/* 107 */     return split(";");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ConfigDataLocation[] split(String delimiter)
/*     */   {
/* 118 */     String[] values = StringUtils.delimitedListToStringArray(toString(), delimiter);
/* 119 */     ConfigDataLocation[] result = new ConfigDataLocation[values.length];
/* 120 */     for (int i = 0; i < values.length; i++) {
/* 121 */       result[i] = of(values[i]).withOrigin(getOrigin());
/*     */     }
/* 123 */     return result;
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/* 128 */     if (this == obj) {
/* 129 */       return true;
/*     */     }
/* 131 */     if ((obj == null) || (getClass() != obj.getClass())) {
/* 132 */       return false;
/*     */     }
/* 134 */     ConfigDataLocation other = (ConfigDataLocation)obj;
/* 135 */     return this.value.equals(other.value);
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 140 */     return this.value.hashCode();
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 145 */     return "optional:" + this.value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   ConfigDataLocation withOrigin(Origin origin)
/*     */   {
/* 154 */     return new ConfigDataLocation(this.optional, this.value, origin);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ConfigDataLocation of(String location)
/*     */   {
/* 164 */     boolean optional = (location != null) && (location.startsWith("optional:"));
/* 165 */     String value = !optional ? location : location.substring("optional:".length());
/* 166 */     if (!StringUtils.hasText(value)) {
/* 167 */       return null;
/*     */     }
/* 169 */     return new ConfigDataLocation(optional, value, null);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\context\config\ConfigDataLocation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */