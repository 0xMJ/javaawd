/*     */ package org.springframework.boot.convert;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.Set;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.core.convert.converter.ConditionalGenericConverter;
/*     */ import org.springframework.core.convert.converter.GenericConverter.ConvertiblePair;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class CharSequenceToObjectConverter
/*     */   implements ConditionalGenericConverter
/*     */ {
/*  34 */   private static final TypeDescriptor STRING = TypeDescriptor.valueOf(String.class);
/*     */   
/*  36 */   private static final TypeDescriptor BYTE_ARRAY = TypeDescriptor.valueOf(byte[].class);
/*     */   
/*     */ 
/*     */ 
/*  40 */   private final ThreadLocal<Boolean> disable = new ThreadLocal();
/*     */   
/*     */ 
/*  43 */   private static final Set<GenericConverter.ConvertiblePair> TYPES = Collections.singleton(new GenericConverter.ConvertiblePair(CharSequence.class, Object.class));
/*     */   
/*     */   private final ConversionService conversionService;
/*     */   
/*     */   CharSequenceToObjectConverter(ConversionService conversionService)
/*     */   {
/*  49 */     this.conversionService = conversionService;
/*     */   }
/*     */   
/*     */   public Set<GenericConverter.ConvertiblePair> getConvertibleTypes()
/*     */   {
/*  54 */     return TYPES;
/*     */   }
/*     */   
/*     */   public boolean matches(TypeDescriptor sourceType, TypeDescriptor targetType)
/*     */   {
/*  59 */     if ((sourceType.getType() == String.class) || (this.disable.get() == Boolean.TRUE)) {
/*  60 */       return false;
/*     */     }
/*  62 */     this.disable.set(Boolean.TRUE);
/*     */     try {
/*  64 */       boolean canDirectlyConvertCharSequence = this.conversionService.canConvert(sourceType, targetType);
/*  65 */       boolean bool1; if ((canDirectlyConvertCharSequence) && (!isStringConversionBetter(sourceType, targetType))) {
/*  66 */         return false;
/*     */       }
/*  68 */       return this.conversionService.canConvert(STRING, targetType);
/*     */     }
/*     */     finally {
/*  71 */       this.disable.set(null);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean isStringConversionBetter(TypeDescriptor sourceType, TypeDescriptor targetType)
/*     */   {
/*  83 */     if ((this.conversionService instanceof ApplicationConversionService)) {
/*  84 */       ApplicationConversionService applicationConversionService = (ApplicationConversionService)this.conversionService;
/*  85 */       if (applicationConversionService.isConvertViaObjectSourceType(sourceType, targetType))
/*     */       {
/*     */ 
/*  88 */         return true;
/*     */       }
/*     */     }
/*  91 */     if (((targetType.isArray()) || (targetType.isCollection())) && (!targetType.equals(BYTE_ARRAY)))
/*     */     {
/*     */ 
/*  94 */       return true;
/*     */     }
/*  96 */     return false;
/*     */   }
/*     */   
/*     */   public Object convert(Object source, TypeDescriptor sourceType, TypeDescriptor targetType)
/*     */   {
/* 101 */     return this.conversionService.convert(source.toString(), STRING, targetType);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\convert\CharSequenceToObjectConverter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */