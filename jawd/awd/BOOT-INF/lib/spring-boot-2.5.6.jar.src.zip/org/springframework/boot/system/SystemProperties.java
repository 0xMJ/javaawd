/*    */ package org.springframework.boot.system;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SystemProperties
/*    */ {
/*    */   public static String get(String... properties)
/*    */   {
/* 31 */     for (String property : properties) {
/*    */       try {
/* 33 */         String override = System.getProperty(property);
/* 34 */         override = override != null ? override : System.getenv(property);
/* 35 */         if (override != null) {
/* 36 */           return override;
/*    */         }
/*    */       }
/*    */       catch (Throwable ex) {
/* 40 */         System.err.println("Could not resolve '" + property + "' as system property: " + ex);
/*    */       }
/*    */     }
/* 43 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\system\SystemProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */