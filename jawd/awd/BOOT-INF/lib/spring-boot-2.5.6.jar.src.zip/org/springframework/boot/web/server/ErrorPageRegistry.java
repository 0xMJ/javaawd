package org.springframework.boot.web.server;

@FunctionalInterface
public abstract interface ErrorPageRegistry
{
  public abstract void addErrorPages(ErrorPage... paramVarArgs);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\web\server\ErrorPageRegistry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */