/*    */ package org.springframework.boot.web.reactive.context;
/*    */ 
/*    */ import org.springframework.context.SmartLifecycle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class WebServerStartStopLifecycle
/*    */   implements SmartLifecycle
/*    */ {
/*    */   private final WebServerManager weServerManager;
/*    */   private volatile boolean running;
/*    */   
/*    */   WebServerStartStopLifecycle(WebServerManager weServerManager)
/*    */   {
/* 35 */     this.weServerManager = weServerManager;
/*    */   }
/*    */   
/*    */   public void start()
/*    */   {
/* 40 */     this.weServerManager.start();
/* 41 */     this.running = true;
/*    */   }
/*    */   
/*    */   public void stop()
/*    */   {
/* 46 */     this.running = false;
/* 47 */     this.weServerManager.stop();
/*    */   }
/*    */   
/*    */   public boolean isRunning()
/*    */   {
/* 52 */     return this.running;
/*    */   }
/*    */   
/*    */   public int getPhase()
/*    */   {
/* 57 */     return 2147483646;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\web\reactive\context\WebServerStartStopLifecycle.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */