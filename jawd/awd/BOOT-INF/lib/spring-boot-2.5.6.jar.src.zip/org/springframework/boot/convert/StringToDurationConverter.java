/*    */ package org.springframework.boot.convert;
/*    */ 
/*    */ import java.time.Duration;
/*    */ import java.time.temporal.ChronoUnit;
/*    */ import java.util.Collections;
/*    */ import java.util.Set;
/*    */ import org.springframework.core.convert.TypeDescriptor;
/*    */ import org.springframework.core.convert.converter.GenericConverter;
/*    */ import org.springframework.core.convert.converter.GenericConverter.ConvertiblePair;
/*    */ import org.springframework.util.ObjectUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class StringToDurationConverter
/*    */   implements GenericConverter
/*    */ {
/*    */   public Set<GenericConverter.ConvertiblePair> getConvertibleTypes()
/*    */   {
/* 41 */     return Collections.singleton(new GenericConverter.ConvertiblePair(String.class, Duration.class));
/*    */   }
/*    */   
/*    */   public Object convert(Object source, TypeDescriptor sourceType, TypeDescriptor targetType)
/*    */   {
/* 46 */     if (ObjectUtils.isEmpty(source)) {
/* 47 */       return null;
/*    */     }
/* 49 */     return convert(source.toString(), getStyle(targetType), getDurationUnit(targetType));
/*    */   }
/*    */   
/*    */   private DurationStyle getStyle(TypeDescriptor targetType) {
/* 53 */     DurationFormat annotation = (DurationFormat)targetType.getAnnotation(DurationFormat.class);
/* 54 */     return annotation != null ? annotation.value() : null;
/*    */   }
/*    */   
/*    */   private ChronoUnit getDurationUnit(TypeDescriptor targetType) {
/* 58 */     DurationUnit annotation = (DurationUnit)targetType.getAnnotation(DurationUnit.class);
/* 59 */     return annotation != null ? annotation.value() : null;
/*    */   }
/*    */   
/*    */   private Duration convert(String source, DurationStyle style, ChronoUnit unit) {
/* 63 */     style = style != null ? style : DurationStyle.detect(source);
/* 64 */     return style.parse(source, unit);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\convert\StringToDurationConverter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */