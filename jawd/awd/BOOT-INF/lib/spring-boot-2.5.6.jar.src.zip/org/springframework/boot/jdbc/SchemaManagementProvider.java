package org.springframework.boot.jdbc;

import javax.sql.DataSource;

@FunctionalInterface
public abstract interface SchemaManagementProvider
{
  public abstract SchemaManagement getSchemaManagement(DataSource paramDataSource);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\jdbc\SchemaManagementProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */