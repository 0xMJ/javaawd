/*    */ package org.springframework.boot.rsocket.context;
/*    */ 
/*    */ import org.springframework.boot.rsocket.server.RSocketServer;
/*    */ import org.springframework.context.ApplicationEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RSocketServerInitializedEvent
/*    */   extends ApplicationEvent
/*    */ {
/*    */   public RSocketServerInitializedEvent(RSocketServer server)
/*    */   {
/* 33 */     super(server);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public RSocketServer getServer()
/*    */   {
/* 41 */     return getSource();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public RSocketServer getSource()
/*    */   {
/* 50 */     return (RSocketServer)super.getSource();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\rsocket\context\RSocketServerInitializedEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */