/*    */ package org.springframework.boot.diagnostics.analyzer;
/*    */ 
/*    */ import java.io.PrintWriter;
/*    */ import java.io.StringWriter;
/*    */ import java.lang.reflect.Proxy;
/*    */ import org.springframework.beans.factory.BeanNotOfRequiredTypeException;
/*    */ import org.springframework.boot.diagnostics.AbstractFailureAnalyzer;
/*    */ import org.springframework.boot.diagnostics.FailureAnalysis;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BeanNotOfRequiredTypeFailureAnalyzer
/*    */   extends AbstractFailureAnalyzer<BeanNotOfRequiredTypeException>
/*    */ {
/*    */   private static final String ACTION = "Consider injecting the bean as one of its interfaces or forcing the use of CGLib-based proxies by setting proxyTargetClass=true on @EnableAsync and/or @EnableCaching.";
/*    */   
/*    */   protected FailureAnalysis analyze(Throwable rootFailure, BeanNotOfRequiredTypeException cause)
/*    */   {
/* 43 */     if (!Proxy.isProxyClass(cause.getActualType())) {
/* 44 */       return null;
/*    */     }
/* 46 */     return new FailureAnalysis(getDescription(cause), "Consider injecting the bean as one of its interfaces or forcing the use of CGLib-based proxies by setting proxyTargetClass=true on @EnableAsync and/or @EnableCaching.", cause);
/*    */   }
/*    */   
/*    */   private String getDescription(BeanNotOfRequiredTypeException ex) {
/* 50 */     StringWriter description = new StringWriter();
/* 51 */     PrintWriter printer = new PrintWriter(description);
/* 52 */     printer.printf("The bean '%s' could not be injected because it is a JDK dynamic proxy%n%n", new Object[] { ex.getBeanName() });
/* 53 */     printer.printf("The bean is of type '%s' and implements:%n", new Object[] { ex.getActualType().getName() });
/* 54 */     for (Class<?> actualTypeInterface : ex.getActualType().getInterfaces()) {
/* 55 */       printer.println("\t" + actualTypeInterface.getName());
/*    */     }
/* 57 */     printer.printf("%nExpected a bean of type '%s' which implements:%n", new Object[] { ex.getRequiredType().getName() });
/* 58 */     for (Class<?> requiredTypeInterface : ex.getRequiredType().getInterfaces()) {
/* 59 */       printer.println("\t" + requiredTypeInterface.getName());
/*    */     }
/* 61 */     return description.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\diagnostics\analyzer\BeanNotOfRequiredTypeFailureAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */