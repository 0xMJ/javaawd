/*    */ package org.springframework.boot.context.properties.source;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.Collections;
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ import java.util.function.Function;
/*    */ import org.springframework.core.env.PropertySource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UnboundElementsSourceFilter
/*    */   implements Function<ConfigurationPropertySource, Boolean>
/*    */ {
/* 40 */   private static final Set<String> BENIGN_PROPERTY_SOURCE_NAMES = Collections.unmodifiableSet(new HashSet(Arrays.asList(new String[] { "systemEnvironment", "systemProperties" })));
/*    */   
/*    */ 
/*    */   public Boolean apply(ConfigurationPropertySource configurationPropertySource)
/*    */   {
/* 45 */     Object underlyingSource = configurationPropertySource.getUnderlyingSource();
/* 46 */     if ((underlyingSource instanceof PropertySource)) {
/* 47 */       String name = ((PropertySource)underlyingSource).getName();
/* 48 */       return Boolean.valueOf(!BENIGN_PROPERTY_SOURCE_NAMES.contains(name));
/*    */     }
/* 50 */     return Boolean.valueOf(true);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\context\properties\source\UnboundElementsSourceFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */