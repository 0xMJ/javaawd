package org.springframework.boot.jms;

import javax.jms.ConnectionFactory;
import javax.jms.XAConnectionFactory;

@FunctionalInterface
public abstract interface XAConnectionFactoryWrapper
{
  public abstract ConnectionFactory wrapConnectionFactory(XAConnectionFactory paramXAConnectionFactory)
    throws Exception;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\jms\XAConnectionFactoryWrapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */