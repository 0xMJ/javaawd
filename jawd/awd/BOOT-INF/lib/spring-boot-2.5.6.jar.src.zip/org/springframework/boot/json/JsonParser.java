package org.springframework.boot.json;

import java.util.List;
import java.util.Map;

public abstract interface JsonParser
{
  public abstract Map<String, Object> parseMap(String paramString)
    throws JsonParseException;
  
  public abstract List<Object> parseList(String paramString)
    throws JsonParseException;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\json\JsonParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */