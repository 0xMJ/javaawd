/*     */ package org.springframework.boot.context.metrics.buffering;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.time.Instant;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.springframework.core.metrics.StartupStep;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StartupTimeline
/*     */ {
/*     */   private final Instant startTime;
/*     */   private final List<TimelineEvent> events;
/*     */   
/*     */   StartupTimeline(Instant startTime, List<TimelineEvent> events)
/*     */   {
/*  41 */     this.startTime = startTime;
/*  42 */     this.events = Collections.unmodifiableList(events);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Instant getStartTime()
/*     */   {
/*  50 */     return this.startTime;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<TimelineEvent> getEvents()
/*     */   {
/*  58 */     return this.events;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static class TimelineEvent
/*     */   {
/*     */     private final BufferedStartupStep step;
/*     */     
/*     */ 
/*     */     private final Instant endTime;
/*     */     
/*     */     private final Duration duration;
/*     */     
/*     */ 
/*     */     TimelineEvent(BufferedStartupStep step, Instant endTime)
/*     */     {
/*  75 */       this.step = step;
/*  76 */       this.endTime = endTime;
/*  77 */       this.duration = Duration.between(step.getStartTime(), endTime);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public Instant getStartTime()
/*     */     {
/*  85 */       return this.step.getStartTime();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public Instant getEndTime()
/*     */     {
/*  93 */       return this.endTime;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public Duration getDuration()
/*     */     {
/* 102 */       return this.duration;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public StartupStep getStartupStep()
/*     */     {
/* 110 */       return this.step;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\context\metrics\buffering\StartupTimeline.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */