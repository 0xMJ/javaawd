/*     */ package org.springframework.boot.diagnostics.analyzer;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import org.springframework.beans.BeanInstantiationException;
/*     */ import org.springframework.beans.factory.InjectionPoint;
/*     */ import org.springframework.beans.factory.UnsatisfiedDependencyException;
/*     */ import org.springframework.boot.diagnostics.AbstractFailureAnalyzer;
/*     */ import org.springframework.boot.diagnostics.FailureAnalysis;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractInjectionFailureAnalyzer<T extends Throwable>
/*     */   extends AbstractFailureAnalyzer<T>
/*     */ {
/*     */   protected final FailureAnalysis analyze(Throwable rootFailure, T cause)
/*     */   {
/*  40 */     return analyze(rootFailure, cause, getDescription(rootFailure));
/*     */   }
/*     */   
/*     */   private String getDescription(Throwable rootFailure) {
/*  44 */     UnsatisfiedDependencyException unsatisfiedDependency = (UnsatisfiedDependencyException)findMostNestedCause(rootFailure, UnsatisfiedDependencyException.class);
/*     */     
/*  46 */     if (unsatisfiedDependency != null) {
/*  47 */       return getDescription(unsatisfiedDependency);
/*     */     }
/*  49 */     BeanInstantiationException beanInstantiationException = (BeanInstantiationException)findMostNestedCause(rootFailure, BeanInstantiationException.class);
/*     */     
/*  51 */     if (beanInstantiationException != null) {
/*  52 */       return getDescription(beanInstantiationException);
/*     */     }
/*  54 */     return null;
/*     */   }
/*     */   
/*     */   private <C extends Exception> C findMostNestedCause(Throwable root, Class<C> type)
/*     */   {
/*  59 */     Throwable candidate = root;
/*  60 */     C result = null;
/*  61 */     while (candidate != null) {
/*  62 */       if (type.isAssignableFrom(candidate.getClass())) {
/*  63 */         result = (Exception)candidate;
/*     */       }
/*  65 */       candidate = candidate.getCause();
/*     */     }
/*  67 */     return result;
/*     */   }
/*     */   
/*     */   private String getDescription(UnsatisfiedDependencyException ex) {
/*  71 */     InjectionPoint injectionPoint = ex.getInjectionPoint();
/*  72 */     if (injectionPoint != null) {
/*  73 */       if (injectionPoint.getField() != null) {
/*  74 */         return String.format("Field %s in %s", new Object[] { injectionPoint.getField().getName(), injectionPoint
/*  75 */           .getField().getDeclaringClass().getName() });
/*     */       }
/*  77 */       if (injectionPoint.getMethodParameter() != null) {
/*  78 */         if (injectionPoint.getMethodParameter().getConstructor() != null) {
/*  79 */           return String.format("Parameter %d of constructor in %s", new Object[] {
/*  80 */             Integer.valueOf(injectionPoint.getMethodParameter().getParameterIndex()), injectionPoint
/*  81 */             .getMethodParameter().getDeclaringClass().getName() });
/*     */         }
/*  83 */         return String.format("Parameter %d of method %s in %s", new Object[] {
/*  84 */           Integer.valueOf(injectionPoint.getMethodParameter().getParameterIndex()), injectionPoint
/*  85 */           .getMethodParameter().getMethod().getName(), injectionPoint
/*  86 */           .getMethodParameter().getDeclaringClass().getName() });
/*     */       }
/*     */     }
/*  89 */     return ex.getResourceDescription();
/*     */   }
/*     */   
/*     */   private String getDescription(BeanInstantiationException ex) {
/*  93 */     if (ex.getConstructingMethod() != null) {
/*  94 */       return String.format("Method %s in %s", new Object[] { ex.getConstructingMethod().getName(), ex
/*  95 */         .getConstructingMethod().getDeclaringClass().getName() });
/*     */     }
/*  97 */     if (ex.getConstructor() != null) {
/*  98 */       return String.format("Constructor in %s", new Object[] {
/*  99 */         ClassUtils.getUserClass(ex.getConstructor().getDeclaringClass()).getName() });
/*     */     }
/* 101 */     return ex.getBeanClass().getName();
/*     */   }
/*     */   
/*     */   protected abstract FailureAnalysis analyze(Throwable paramThrowable, T paramT, String paramString);
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\diagnostics\analyzer\AbstractInjectionFailureAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */