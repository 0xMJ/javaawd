/*    */ package org.springframework.boot.jdbc.metadata;
/*    */ 
/*    */ import org.apache.tomcat.jdbc.pool.ConnectionPool;
/*    */ import org.apache.tomcat.jdbc.pool.DataSource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TomcatDataSourcePoolMetadata
/*    */   extends AbstractDataSourcePoolMetadata<DataSource>
/*    */ {
/*    */   public TomcatDataSourcePoolMetadata(DataSource dataSource)
/*    */   {
/* 31 */     super(dataSource);
/*    */   }
/*    */   
/*    */   public Integer getActive()
/*    */   {
/* 36 */     ConnectionPool pool = ((DataSource)getDataSource()).getPool();
/* 37 */     return Integer.valueOf(pool != null ? pool.getActive() : 0);
/*    */   }
/*    */   
/*    */   public Integer getIdle()
/*    */   {
/* 42 */     return Integer.valueOf(((DataSource)getDataSource()).getNumIdle());
/*    */   }
/*    */   
/*    */   public Integer getMax()
/*    */   {
/* 47 */     return Integer.valueOf(((DataSource)getDataSource()).getMaxActive());
/*    */   }
/*    */   
/*    */   public Integer getMin()
/*    */   {
/* 52 */     return Integer.valueOf(((DataSource)getDataSource()).getMinIdle());
/*    */   }
/*    */   
/*    */   public String getValidationQuery()
/*    */   {
/* 57 */     return ((DataSource)getDataSource()).getValidationQuery();
/*    */   }
/*    */   
/*    */   public Boolean getDefaultAutoCommit()
/*    */   {
/* 62 */     return ((DataSource)getDataSource()).isDefaultAutoCommit();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\jdbc\metadata\TomcatDataSourcePoolMetadata.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */