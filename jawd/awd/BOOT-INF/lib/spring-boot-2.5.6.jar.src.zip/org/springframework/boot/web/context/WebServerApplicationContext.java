/*    */ package org.springframework.boot.web.context;
/*    */ 
/*    */ import org.springframework.boot.web.server.WebServer;
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.util.ObjectUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract interface WebServerApplicationContext
/*    */   extends ApplicationContext
/*    */ {
/*    */   public abstract WebServer getWebServer();
/*    */   
/*    */   public abstract String getServerNamespace();
/*    */   
/*    */   public static boolean hasServerNamespace(ApplicationContext context, String serverNamespace)
/*    */   {
/* 57 */     return ((context instanceof WebServerApplicationContext)) && 
/* 58 */       (ObjectUtils.nullSafeEquals(((WebServerApplicationContext)context).getServerNamespace(), serverNamespace));
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\web\context\WebServerApplicationContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */