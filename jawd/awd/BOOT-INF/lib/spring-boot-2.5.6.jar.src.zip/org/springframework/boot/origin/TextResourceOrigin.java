/*     */ package org.springframework.boot.origin;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.springframework.core.io.ClassPathResource;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TextResourceOrigin
/*     */   implements Origin
/*     */ {
/*     */   private final Resource resource;
/*     */   private final Location location;
/*     */   
/*     */   public TextResourceOrigin(Resource resource, Location location)
/*     */   {
/*  43 */     this.resource = resource;
/*  44 */     this.location = location;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Resource getResource()
/*     */   {
/*  52 */     return this.resource;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Location getLocation()
/*     */   {
/*  60 */     return this.location;
/*     */   }
/*     */   
/*     */   public Origin getParent()
/*     */   {
/*  65 */     return Origin.from(this.resource);
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/*  70 */     if (this == obj) {
/*  71 */       return true;
/*     */     }
/*  73 */     if (obj == null) {
/*  74 */       return false;
/*     */     }
/*  76 */     if ((obj instanceof TextResourceOrigin)) {
/*  77 */       TextResourceOrigin other = (TextResourceOrigin)obj;
/*  78 */       boolean result = true;
/*  79 */       result = (result) && (ObjectUtils.nullSafeEquals(this.resource, other.resource));
/*  80 */       result = (result) && (ObjectUtils.nullSafeEquals(this.location, other.location));
/*  81 */       return result;
/*     */     }
/*  83 */     return super.equals(obj);
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/*  88 */     int result = 1;
/*  89 */     result = 31 * result + ObjectUtils.nullSafeHashCode(this.resource);
/*  90 */     result = 31 * result + ObjectUtils.nullSafeHashCode(this.location);
/*  91 */     return result;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/*  96 */     StringBuilder result = new StringBuilder();
/*  97 */     result.append(getResourceDescription(this.resource));
/*  98 */     if (this.location != null) {
/*  99 */       result.append(" - ").append(this.location);
/*     */     }
/* 101 */     return result.toString();
/*     */   }
/*     */   
/*     */   private String getResourceDescription(Resource resource) {
/* 105 */     if ((resource instanceof OriginTrackedResource)) {
/* 106 */       return getResourceDescription(((OriginTrackedResource)resource).getResource());
/*     */     }
/* 108 */     if (resource == null) {
/* 109 */       return "unknown resource [?]";
/*     */     }
/* 111 */     if ((resource instanceof ClassPathResource)) {
/* 112 */       return getResourceDescription((ClassPathResource)resource);
/*     */     }
/* 114 */     return resource.getDescription();
/*     */   }
/*     */   
/*     */   private String getResourceDescription(ClassPathResource resource) {
/*     */     try {
/* 119 */       JarUri jarUri = JarUri.from(resource.getURI());
/* 120 */       if (jarUri != null) {
/* 121 */         return jarUri.getDescription(resource.getDescription());
/*     */       }
/*     */     }
/*     */     catch (IOException localIOException) {}
/*     */     
/* 126 */     return resource.getDescription();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final class Location
/*     */   {
/*     */     private final int line;
/*     */     
/*     */ 
/*     */ 
/*     */     private final int column;
/*     */     
/*     */ 
/*     */ 
/*     */     public Location(int line, int column)
/*     */     {
/* 144 */       this.line = line;
/* 145 */       this.column = column;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getLine()
/*     */     {
/* 153 */       return this.line;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getColumn()
/*     */     {
/* 161 */       return this.column;
/*     */     }
/*     */     
/*     */     public boolean equals(Object obj)
/*     */     {
/* 166 */       if (this == obj) {
/* 167 */         return true;
/*     */       }
/* 169 */       if ((obj == null) || (getClass() != obj.getClass())) {
/* 170 */         return false;
/*     */       }
/* 172 */       Location other = (Location)obj;
/* 173 */       boolean result = true;
/* 174 */       result = (result) && (this.line == other.line);
/* 175 */       result = (result) && (this.column == other.column);
/* 176 */       return result;
/*     */     }
/*     */     
/*     */     public int hashCode()
/*     */     {
/* 181 */       return 31 * this.line + this.column;
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/* 186 */       return this.line + 1 + ":" + (this.column + 1);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\origin\TextResourceOrigin.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */