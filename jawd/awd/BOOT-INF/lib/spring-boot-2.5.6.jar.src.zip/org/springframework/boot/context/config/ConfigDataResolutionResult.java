/*    */ package org.springframework.boot.context.config;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ConfigDataResolutionResult
/*    */ {
/*    */   private final ConfigDataLocation location;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private final ConfigDataResource resource;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private final boolean profileSpecific;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   ConfigDataResolutionResult(ConfigDataLocation location, ConfigDataResource resource, boolean profileSpecific)
/*    */   {
/* 34 */     this.location = location;
/* 35 */     this.resource = resource;
/* 36 */     this.profileSpecific = profileSpecific;
/*    */   }
/*    */   
/*    */   ConfigDataLocation getLocation() {
/* 40 */     return this.location;
/*    */   }
/*    */   
/*    */   ConfigDataResource getResource() {
/* 44 */     return this.resource;
/*    */   }
/*    */   
/*    */   boolean isProfileSpecific() {
/* 48 */     return this.profileSpecific;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\context\config\ConfigDataResolutionResult.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */