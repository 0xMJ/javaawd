/*     */ package org.springframework.boot.jdbc;
/*     */ 
/*     */ import java.sql.Wrapper;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.aop.framework.AopProxyUtils;
/*     */ import org.springframework.aop.support.AopUtils;
/*     */ import org.springframework.jdbc.datasource.DelegatingDataSource;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DataSourceUnwrapper
/*     */ {
/*  38 */   private static final boolean DELEGATING_DATA_SOURCE_PRESENT = ClassUtils.isPresent("org.springframework.jdbc.datasource.DelegatingDataSource", DataSourceUnwrapper.class
/*  39 */     .getClassLoader());
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static <I, T extends I> T unwrap(DataSource dataSource, Class<I> unwrapInterface, Class<T> target)
/*     */   {
/*  57 */     if (target.isInstance(dataSource)) {
/*  58 */       return (T)target.cast(dataSource);
/*     */     }
/*  60 */     I unwrapped = safeUnwrap(dataSource, unwrapInterface);
/*  61 */     if ((unwrapped != null) && (unwrapInterface.isAssignableFrom(target))) {
/*  62 */       return (T)target.cast(unwrapped);
/*     */     }
/*  64 */     if (DELEGATING_DATA_SOURCE_PRESENT) {
/*  65 */       DataSource targetDataSource = DelegatingDataSourceUnwrapper.getTargetDataSource(dataSource);
/*  66 */       if (targetDataSource != null) {
/*  67 */         return (T)unwrap(targetDataSource, unwrapInterface, target);
/*     */       }
/*     */     }
/*  70 */     if (AopUtils.isAopProxy(dataSource)) {
/*  71 */       Object proxyTarget = AopProxyUtils.getSingletonTarget(dataSource);
/*  72 */       if ((proxyTarget instanceof DataSource)) {
/*  73 */         return (T)unwrap((DataSource)proxyTarget, unwrapInterface, target);
/*     */       }
/*     */     }
/*  76 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static <T> T unwrap(DataSource dataSource, Class<T> target)
/*     */   {
/*  90 */     return (T)unwrap(dataSource, target, target);
/*     */   }
/*     */   
/*     */   private static <S> S safeUnwrap(Wrapper wrapper, Class<S> target) {
/*     */     try {
/*  95 */       if ((target.isInterface()) && (wrapper.isWrapperFor(target))) {
/*  96 */         return (S)wrapper.unwrap(target);
/*     */       }
/*     */     }
/*     */     catch (Exception localException) {}
/*     */     
/*     */ 
/* 102 */     return null;
/*     */   }
/*     */   
/*     */   private static class DelegatingDataSourceUnwrapper
/*     */   {
/*     */     private static DataSource getTargetDataSource(DataSource dataSource) {
/* 108 */       if ((dataSource instanceof DelegatingDataSource)) {
/* 109 */         return ((DelegatingDataSource)dataSource).getTargetDataSource();
/*     */       }
/* 111 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\jdbc\DataSourceUnwrapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */