/*     */ package org.springframework.boot.diagnostics;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.boot.SpringBootExceptionReporter;
/*     */ import org.springframework.context.ConfigurableApplicationContext;
/*     */ import org.springframework.context.EnvironmentAware;
/*     */ import org.springframework.core.annotation.AnnotationAwareOrderComparator;
/*     */ import org.springframework.core.io.support.SpringFactoriesLoader;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FailureAnalyzers
/*     */   implements SpringBootExceptionReporter
/*     */ {
/*  52 */   private static final Log logger = LogFactory.getLog(FailureAnalyzers.class);
/*     */   
/*     */   private final ClassLoader classLoader;
/*     */   private final List<FailureAnalyzer> analyzers;
/*     */   
/*     */   FailureAnalyzers(ConfigurableApplicationContext context)
/*     */   {
/*  59 */     this(context, null);
/*     */   }
/*     */   
/*     */   FailureAnalyzers(ConfigurableApplicationContext context, ClassLoader classLoader) {
/*  63 */     this.classLoader = (classLoader != null ? classLoader : getClassLoader(context));
/*  64 */     this.analyzers = loadFailureAnalyzers(context, this.classLoader);
/*     */   }
/*     */   
/*     */   private ClassLoader getClassLoader(ConfigurableApplicationContext context) {
/*  68 */     return context != null ? context.getClassLoader() : null;
/*     */   }
/*     */   
/*     */   private List<FailureAnalyzer> loadFailureAnalyzers(ConfigurableApplicationContext context, ClassLoader classLoader)
/*     */   {
/*  73 */     List<String> classNames = SpringFactoriesLoader.loadFactoryNames(FailureAnalyzer.class, classLoader);
/*  74 */     List<FailureAnalyzer> analyzers = new ArrayList();
/*  75 */     for (String className : classNames) {
/*     */       try {
/*  77 */         FailureAnalyzer analyzer = createAnalyzer(context, className);
/*  78 */         if (analyzer != null) {
/*  79 */           analyzers.add(analyzer);
/*     */         }
/*     */       }
/*     */       catch (Throwable ex) {
/*  83 */         logger.trace(LogMessage.format("Failed to load %s", className), ex);
/*     */       }
/*     */     }
/*  86 */     AnnotationAwareOrderComparator.sort(analyzers);
/*  87 */     return analyzers;
/*     */   }
/*     */   
/*     */   private FailureAnalyzer createAnalyzer(ConfigurableApplicationContext context, String className) throws Exception {
/*  91 */     Constructor<?> constructor = ClassUtils.forName(className, this.classLoader).getDeclaredConstructor(new Class[0]);
/*  92 */     ReflectionUtils.makeAccessible(constructor);
/*  93 */     FailureAnalyzer analyzer = (FailureAnalyzer)constructor.newInstance(new Object[0]);
/*  94 */     if (((analyzer instanceof BeanFactoryAware)) || ((analyzer instanceof EnvironmentAware))) {
/*  95 */       if (context == null) {
/*  96 */         logger.trace(LogMessage.format("Skipping %s due to missing context", className));
/*  97 */         return null;
/*     */       }
/*  99 */       if ((analyzer instanceof BeanFactoryAware)) {
/* 100 */         ((BeanFactoryAware)analyzer).setBeanFactory(context.getBeanFactory());
/*     */       }
/* 102 */       if ((analyzer instanceof EnvironmentAware)) {
/* 103 */         ((EnvironmentAware)analyzer).setEnvironment(context.getEnvironment());
/*     */       }
/*     */     }
/* 106 */     return analyzer;
/*     */   }
/*     */   
/*     */   public boolean reportException(Throwable failure)
/*     */   {
/* 111 */     FailureAnalysis analysis = analyze(failure, this.analyzers);
/* 112 */     return report(analysis, this.classLoader);
/*     */   }
/*     */   
/*     */   private FailureAnalysis analyze(Throwable failure, List<FailureAnalyzer> analyzers) {
/* 116 */     for (FailureAnalyzer analyzer : analyzers) {
/*     */       try {
/* 118 */         FailureAnalysis analysis = analyzer.analyze(failure);
/* 119 */         if (analysis != null) {
/* 120 */           return analysis;
/*     */         }
/*     */       }
/*     */       catch (Throwable ex) {
/* 124 */         logger.trace(LogMessage.format("FailureAnalyzer %s failed", analyzer), ex);
/*     */       }
/*     */     }
/* 127 */     return null;
/*     */   }
/*     */   
/*     */   private boolean report(FailureAnalysis analysis, ClassLoader classLoader) {
/* 131 */     List<FailureAnalysisReporter> reporters = SpringFactoriesLoader.loadFactories(FailureAnalysisReporter.class, classLoader);
/*     */     
/* 133 */     if ((analysis == null) || (reporters.isEmpty())) {
/* 134 */       return false;
/*     */     }
/* 136 */     for (FailureAnalysisReporter reporter : reporters) {
/* 137 */       reporter.report(analysis);
/*     */     }
/* 139 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\diagnostics\FailureAnalyzers.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */