/*    */ package org.springframework.boot.origin;
/*    */ 
/*    */ import java.net.URI;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class JarUri
/*    */ {
/*    */   private static final String JAR_SCHEME = "jar:";
/*    */   private static final String JAR_EXTENSION = ".jar";
/*    */   private final String uri;
/*    */   private final String description;
/*    */   
/*    */   private JarUri(String uri)
/*    */   {
/* 37 */     this.uri = uri;
/* 38 */     this.description = extractDescription(uri);
/*    */   }
/*    */   
/*    */   private String extractDescription(String uri) {
/* 42 */     uri = uri.substring("jar:".length());
/* 43 */     int firstDotJar = uri.indexOf(".jar");
/* 44 */     String firstJar = getFilename(uri.substring(0, firstDotJar + ".jar".length()));
/* 45 */     uri = uri.substring(firstDotJar + ".jar".length());
/* 46 */     int lastDotJar = uri.lastIndexOf(".jar");
/* 47 */     if (lastDotJar == -1) {
/* 48 */       return firstJar;
/*    */     }
/* 50 */     return firstJar + uri.substring(0, lastDotJar + ".jar".length());
/*    */   }
/*    */   
/*    */   private String getFilename(String string) {
/* 54 */     int lastSlash = string.lastIndexOf('/');
/* 55 */     return lastSlash == -1 ? string : string.substring(lastSlash + 1);
/*    */   }
/*    */   
/*    */   String getDescription() {
/* 59 */     return this.description;
/*    */   }
/*    */   
/*    */   String getDescription(String existing) {
/* 63 */     return existing + " from " + this.description;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 68 */     return this.uri;
/*    */   }
/*    */   
/*    */   static JarUri from(URI uri) {
/* 72 */     return from(uri.toString());
/*    */   }
/*    */   
/*    */   static JarUri from(String uri) {
/* 76 */     if ((uri.startsWith("jar:")) && (uri.contains(".jar"))) {
/* 77 */       return new JarUri(uri);
/*    */     }
/* 79 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\origin\JarUri.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */