/*    */ package org.springframework.boot.context.properties.bind;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @FunctionalInterface
/*    */ public abstract interface BindConstructorProvider
/*    */ {
/* 34 */   public static final BindConstructorProvider DEFAULT = new DefaultBindConstructorProvider();
/*    */   
/*    */   public abstract Constructor<?> getBindConstructor(Bindable<?> paramBindable, boolean paramBoolean);
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\context\properties\bind\BindConstructorProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */