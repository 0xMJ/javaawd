/*    */ package org.springframework.boot.context;
/*    */ 
/*    */ import java.util.concurrent.atomic.AtomicLong;
/*    */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.context.ApplicationContextInitializer;
/*    */ import org.springframework.context.ConfigurableApplicationContext;
/*    */ import org.springframework.core.Ordered;
/*    */ import org.springframework.core.env.ConfigurableEnvironment;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ContextIdApplicationContextInitializer
/*    */   implements ApplicationContextInitializer<ConfigurableApplicationContext>, Ordered
/*    */ {
/* 41 */   private int order = 2147483637;
/*    */   
/*    */   public void setOrder(int order) {
/* 44 */     this.order = order;
/*    */   }
/*    */   
/*    */   public int getOrder()
/*    */   {
/* 49 */     return this.order;
/*    */   }
/*    */   
/*    */   public void initialize(ConfigurableApplicationContext applicationContext)
/*    */   {
/* 54 */     ContextId contextId = getContextId(applicationContext);
/* 55 */     applicationContext.setId(contextId.getId());
/* 56 */     applicationContext.getBeanFactory().registerSingleton(ContextId.class.getName(), contextId);
/*    */   }
/*    */   
/*    */   private ContextId getContextId(ConfigurableApplicationContext applicationContext) {
/* 60 */     ApplicationContext parent = applicationContext.getParent();
/* 61 */     if ((parent != null) && (parent.containsBean(ContextId.class.getName()))) {
/* 62 */       return ((ContextId)parent.getBean(ContextId.class)).createChildId();
/*    */     }
/* 64 */     return new ContextId(getApplicationId(applicationContext.getEnvironment()));
/*    */   }
/*    */   
/*    */   private String getApplicationId(ConfigurableEnvironment environment) {
/* 68 */     String name = environment.getProperty("spring.application.name");
/* 69 */     return StringUtils.hasText(name) ? name : "application";
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   static class ContextId
/*    */   {
/* 77 */     private final AtomicLong children = new AtomicLong();
/*    */     private final String id;
/*    */     
/*    */     ContextId(String id)
/*    */     {
/* 82 */       this.id = id;
/*    */     }
/*    */     
/*    */     ContextId createChildId() {
/* 86 */       return new ContextId(this.id + "-" + this.children.incrementAndGet());
/*    */     }
/*    */     
/*    */     String getId() {
/* 90 */       return this.id;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\context\ContextIdApplicationContextInitializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */