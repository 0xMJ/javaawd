/*     */ package org.springframework.boot.context.config;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import org.springframework.core.io.FileSystemResource;
/*     */ import org.springframework.core.io.FileUrlResource;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardConfigDataResource
/*     */   extends ConfigDataResource
/*     */ {
/*     */   private final StandardConfigDataReference reference;
/*     */   private final Resource resource;
/*     */   private final boolean emptyDirectory;
/*     */   
/*     */   StandardConfigDataResource(StandardConfigDataReference reference, Resource resource)
/*     */   {
/*  47 */     this(reference, resource, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   StandardConfigDataResource(StandardConfigDataReference reference, Resource resource, boolean emptyDirectory)
/*     */   {
/*  57 */     Assert.notNull(reference, "Reference must not be null");
/*  58 */     Assert.notNull(resource, "Resource must not be null");
/*  59 */     this.reference = reference;
/*  60 */     this.resource = resource;
/*  61 */     this.emptyDirectory = emptyDirectory;
/*     */   }
/*     */   
/*     */   StandardConfigDataReference getReference() {
/*  65 */     return this.reference;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Resource getResource()
/*     */   {
/*  74 */     return this.resource;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getProfile()
/*     */   {
/*  83 */     return this.reference.getProfile();
/*     */   }
/*     */   
/*     */   boolean isEmptyDirectory() {
/*  87 */     return this.emptyDirectory;
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/*  92 */     if (this == obj) {
/*  93 */       return true;
/*     */     }
/*  95 */     if ((obj == null) || (getClass() != obj.getClass())) {
/*  96 */       return false;
/*     */     }
/*  98 */     StandardConfigDataResource other = (StandardConfigDataResource)obj;
/*  99 */     return (this.resource.equals(other.resource)) && (this.emptyDirectory == other.emptyDirectory);
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 104 */     return this.resource.hashCode();
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 109 */     if (((this.resource instanceof FileSystemResource)) || ((this.resource instanceof FileUrlResource))) {
/*     */       try {
/* 111 */         return "file [" + this.resource.getFile().toString() + "]";
/*     */       }
/*     */       catch (IOException localIOException) {}
/*     */     }
/*     */     
/* 116 */     return this.resource.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\context\config\StandardConfigDataResource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */