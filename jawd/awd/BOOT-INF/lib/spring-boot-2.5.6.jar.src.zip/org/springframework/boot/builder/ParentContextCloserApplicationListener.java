/*     */ package org.springframework.boot.builder;
/*     */ 
/*     */ import java.lang.ref.WeakReference;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextAware;
/*     */ import org.springframework.context.ApplicationListener;
/*     */ import org.springframework.context.ConfigurableApplicationContext;
/*     */ import org.springframework.context.event.ContextClosedEvent;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ParentContextCloserApplicationListener
/*     */   implements ApplicationListener<ParentContextApplicationContextInitializer.ParentContextAvailableEvent>, ApplicationContextAware, Ordered
/*     */ {
/*  43 */   private int order = 2147483637;
/*     */   
/*     */   private ApplicationContext context;
/*     */   
/*     */   public int getOrder()
/*     */   {
/*  49 */     return this.order;
/*     */   }
/*     */   
/*     */   public void setApplicationContext(ApplicationContext context) throws BeansException
/*     */   {
/*  54 */     this.context = context;
/*     */   }
/*     */   
/*     */   public void onApplicationEvent(ParentContextApplicationContextInitializer.ParentContextAvailableEvent event)
/*     */   {
/*  59 */     maybeInstallListenerInParent(event.getApplicationContext());
/*     */   }
/*     */   
/*     */   private void maybeInstallListenerInParent(ConfigurableApplicationContext child) {
/*  63 */     if ((child == this.context) && ((child.getParent() instanceof ConfigurableApplicationContext))) {
/*  64 */       ConfigurableApplicationContext parent = (ConfigurableApplicationContext)child.getParent();
/*  65 */       parent.addApplicationListener(createContextCloserListener(child));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ContextCloserListener createContextCloserListener(ConfigurableApplicationContext child)
/*     */   {
/*  76 */     return new ContextCloserListener(child);
/*     */   }
/*     */   
/*     */ 
/*     */   protected static class ContextCloserListener
/*     */     implements ApplicationListener<ContextClosedEvent>
/*     */   {
/*     */     private WeakReference<ConfigurableApplicationContext> childContext;
/*     */     
/*     */     public ContextCloserListener(ConfigurableApplicationContext childContext)
/*     */     {
/*  87 */       this.childContext = new WeakReference(childContext);
/*     */     }
/*     */     
/*     */     public void onApplicationEvent(ContextClosedEvent event)
/*     */     {
/*  92 */       ConfigurableApplicationContext context = (ConfigurableApplicationContext)this.childContext.get();
/*  93 */       if ((context != null) && (event.getApplicationContext() == context.getParent()) && (context.isActive())) {
/*  94 */         context.close();
/*     */       }
/*     */     }
/*     */     
/*     */     public boolean equals(Object obj)
/*     */     {
/* 100 */       if (this == obj) {
/* 101 */         return true;
/*     */       }
/* 103 */       if (obj == null) {
/* 104 */         return false;
/*     */       }
/* 106 */       if ((obj instanceof ContextCloserListener)) {
/* 107 */         ContextCloserListener other = (ContextCloserListener)obj;
/* 108 */         return ObjectUtils.nullSafeEquals(this.childContext.get(), other.childContext.get());
/*     */       }
/* 110 */       return super.equals(obj);
/*     */     }
/*     */     
/*     */     public int hashCode()
/*     */     {
/* 115 */       return ObjectUtils.nullSafeHashCode(this.childContext.get());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\builder\ParentContextCloserApplicationListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */