/*    */ package org.springframework.boot.jta.atomikos;
/*    */ 
/*    */ import javax.jms.ConnectionFactory;
/*    */ import javax.jms.XAConnectionFactory;
/*    */ import org.springframework.boot.jms.XAConnectionFactoryWrapper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AtomikosXAConnectionFactoryWrapper
/*    */   implements XAConnectionFactoryWrapper
/*    */ {
/*    */   public ConnectionFactory wrapConnectionFactory(XAConnectionFactory connectionFactory)
/*    */   {
/* 35 */     AtomikosConnectionFactoryBean bean = new AtomikosConnectionFactoryBean();
/* 36 */     bean.setXaConnectionFactory(connectionFactory);
/* 37 */     return bean;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\jta\atomikos\AtomikosXAConnectionFactoryWrapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */