/*    */ package org.springframework.boot.rsocket.server;
/*    */ 
/*    */ import java.net.InetSocketAddress;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract interface RSocketServer
/*    */ {
/*    */   public abstract void start()
/*    */     throws RSocketServerException;
/*    */   
/*    */   public abstract void stop()
/*    */     throws RSocketServerException;
/*    */   
/*    */   public abstract InetSocketAddress address();
/*    */   
/*    */   public static enum Transport
/*    */   {
/* 58 */     TCP, 
/*    */     
/*    */ 
/*    */ 
/*    */ 
/* 63 */     WEBSOCKET;
/*    */     
/*    */     private Transport() {}
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\rsocket\server\RSocketServer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */