/*     */ package org.springframework.boot.context.config;
/*     */ 
/*     */ import org.springframework.boot.env.PropertySourceLoader;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class StandardConfigDataReference
/*     */ {
/*     */   private final ConfigDataLocation configDataLocation;
/*     */   private final String resourceLocation;
/*     */   private final String directory;
/*     */   private final String profile;
/*     */   private final PropertySourceLoader propertySourceLoader;
/*     */   
/*     */   StandardConfigDataReference(ConfigDataLocation configDataLocation, String directory, String root, String profile, String extension, PropertySourceLoader propertySourceLoader)
/*     */   {
/*  53 */     this.configDataLocation = configDataLocation;
/*  54 */     String profileSuffix = StringUtils.hasText(profile) ? "-" + profile : "";
/*  55 */     this.resourceLocation = (root + profileSuffix + (extension != null ? "." + extension : ""));
/*  56 */     this.directory = directory;
/*  57 */     this.profile = profile;
/*  58 */     this.propertySourceLoader = propertySourceLoader;
/*     */   }
/*     */   
/*     */   ConfigDataLocation getConfigDataLocation() {
/*  62 */     return this.configDataLocation;
/*     */   }
/*     */   
/*     */   String getResourceLocation() {
/*  66 */     return this.resourceLocation;
/*     */   }
/*     */   
/*     */   boolean isMandatoryDirectory() {
/*  70 */     return (!this.configDataLocation.isOptional()) && (this.directory != null);
/*     */   }
/*     */   
/*     */   String getDirectory() {
/*  74 */     return this.directory;
/*     */   }
/*     */   
/*     */   String getProfile() {
/*  78 */     return this.profile;
/*     */   }
/*     */   
/*     */   boolean isSkippable() {
/*  82 */     return (this.configDataLocation.isOptional()) || (this.directory != null) || (this.profile != null);
/*     */   }
/*     */   
/*     */   PropertySourceLoader getPropertySourceLoader() {
/*  86 */     return this.propertySourceLoader;
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/*  91 */     if (this == obj) {
/*  92 */       return true;
/*     */     }
/*  94 */     if ((obj == null) || (getClass() != obj.getClass())) {
/*  95 */       return false;
/*     */     }
/*  97 */     StandardConfigDataReference other = (StandardConfigDataReference)obj;
/*  98 */     return this.resourceLocation.equals(other.resourceLocation);
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 103 */     return this.resourceLocation.hashCode();
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 108 */     return this.resourceLocation;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\context\config\StandardConfigDataReference.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */