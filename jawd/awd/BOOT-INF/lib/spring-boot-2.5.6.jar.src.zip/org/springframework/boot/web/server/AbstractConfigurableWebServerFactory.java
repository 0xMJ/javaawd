/*     */ package org.springframework.boot.web.server;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.net.InetAddress;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Path;
/*     */ import java.nio.file.attribute.FileAttribute;
/*     */ import java.util.Arrays;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractConfigurableWebServerFactory
/*     */   implements ConfigurableWebServerFactory
/*     */ {
/*  43 */   private int port = 8080;
/*     */   
/*     */   private InetAddress address;
/*     */   
/*  47 */   private Set<ErrorPage> errorPages = new LinkedHashSet();
/*     */   
/*     */   private Ssl ssl;
/*     */   
/*     */   private SslStoreProvider sslStoreProvider;
/*     */   
/*     */   private Http2 http2;
/*     */   
/*     */   private Compression compression;
/*     */   
/*     */   private String serverHeader;
/*     */   
/*  59 */   private Shutdown shutdown = Shutdown.IMMEDIATE;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractConfigurableWebServerFactory() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractConfigurableWebServerFactory(int port)
/*     */   {
/*  73 */     this.port = port;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getPort()
/*     */   {
/*  81 */     return this.port;
/*     */   }
/*     */   
/*     */   public void setPort(int port)
/*     */   {
/*  86 */     this.port = port;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public InetAddress getAddress()
/*     */   {
/*  94 */     return this.address;
/*     */   }
/*     */   
/*     */   public void setAddress(InetAddress address)
/*     */   {
/*  99 */     this.address = address;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Set<ErrorPage> getErrorPages()
/*     */   {
/* 108 */     return this.errorPages;
/*     */   }
/*     */   
/*     */   public void setErrorPages(Set<? extends ErrorPage> errorPages)
/*     */   {
/* 113 */     Assert.notNull(errorPages, "ErrorPages must not be null");
/* 114 */     this.errorPages = new LinkedHashSet(errorPages);
/*     */   }
/*     */   
/*     */   public void addErrorPages(ErrorPage... errorPages)
/*     */   {
/* 119 */     Assert.notNull(errorPages, "ErrorPages must not be null");
/* 120 */     this.errorPages.addAll(Arrays.asList(errorPages));
/*     */   }
/*     */   
/*     */   public Ssl getSsl() {
/* 124 */     return this.ssl;
/*     */   }
/*     */   
/*     */   public void setSsl(Ssl ssl)
/*     */   {
/* 129 */     this.ssl = ssl;
/*     */   }
/*     */   
/*     */   public SslStoreProvider getSslStoreProvider() {
/* 133 */     return this.sslStoreProvider;
/*     */   }
/*     */   
/*     */   public void setSslStoreProvider(SslStoreProvider sslStoreProvider)
/*     */   {
/* 138 */     this.sslStoreProvider = sslStoreProvider;
/*     */   }
/*     */   
/*     */   public Http2 getHttp2() {
/* 142 */     return this.http2;
/*     */   }
/*     */   
/*     */   public void setHttp2(Http2 http2)
/*     */   {
/* 147 */     this.http2 = http2;
/*     */   }
/*     */   
/*     */   public Compression getCompression() {
/* 151 */     return this.compression;
/*     */   }
/*     */   
/*     */   public void setCompression(Compression compression)
/*     */   {
/* 156 */     this.compression = compression;
/*     */   }
/*     */   
/*     */   public String getServerHeader() {
/* 160 */     return this.serverHeader;
/*     */   }
/*     */   
/*     */   public void setServerHeader(String serverHeader)
/*     */   {
/* 165 */     this.serverHeader = serverHeader;
/*     */   }
/*     */   
/*     */   public void setShutdown(Shutdown shutdown)
/*     */   {
/* 170 */     this.shutdown = shutdown;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Shutdown getShutdown()
/*     */   {
/* 179 */     return this.shutdown;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final File createTempDir(String prefix)
/*     */   {
/*     */     try
/*     */     {
/* 189 */       File tempDir = Files.createTempDirectory(prefix + "." + getPort() + ".", new FileAttribute[0]).toFile();
/* 190 */       tempDir.deleteOnExit();
/* 191 */       return tempDir;
/*     */     }
/*     */     catch (IOException ex)
/*     */     {
/* 195 */       throw new WebServerException("Unable to create tempDir. java.io.tmpdir is set to " + System.getProperty("java.io.tmpdir"), ex);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\web\server\AbstractConfigurableWebServerFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */