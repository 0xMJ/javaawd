/*    */ package org.springframework.boot.context.config;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract interface ConfigDataLocationResolver<R extends ConfigDataResource>
/*    */ {
/*    */   public abstract boolean isResolvable(ConfigDataLocationResolverContext paramConfigDataLocationResolverContext, ConfigDataLocation paramConfigDataLocation);
/*    */   
/*    */   public abstract List<R> resolve(ConfigDataLocationResolverContext paramConfigDataLocationResolverContext, ConfigDataLocation paramConfigDataLocation)
/*    */     throws ConfigDataLocationNotFoundException, ConfigDataResourceNotFoundException;
/*    */   
/*    */   public List<R> resolveProfileSpecific(ConfigDataLocationResolverContext context, ConfigDataLocation location, Profiles profiles)
/*    */     throws ConfigDataLocationNotFoundException
/*    */   {
/* 95 */     return Collections.emptyList();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\context\config\ConfigDataLocationResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */