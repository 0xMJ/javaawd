/*     */ package org.springframework.boot.context.properties.source;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.Random;
/*     */ import org.springframework.boot.origin.Origin;
/*     */ import org.springframework.boot.origin.PropertySourceOrigin;
/*     */ import org.springframework.core.env.EnumerablePropertySource;
/*     */ import org.springframework.core.env.PropertySource;
/*     */ import org.springframework.core.env.SystemEnvironmentPropertySource;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SpringConfigurationPropertySource
/*     */   implements ConfigurationPropertySource
/*     */ {
/*  55 */   private static final PropertyMapper[] DEFAULT_MAPPERS = { DefaultPropertyMapper.INSTANCE };
/*     */   
/*  57 */   private static final PropertyMapper[] SYSTEM_ENVIRONMENT_MAPPERS = { SystemEnvironmentPropertyMapper.INSTANCE, DefaultPropertyMapper.INSTANCE };
/*     */   
/*     */ 
/*     */ 
/*     */   private final PropertySource<?> propertySource;
/*     */   
/*     */ 
/*     */   private final PropertyMapper[] mappers;
/*     */   
/*     */ 
/*     */ 
/*     */   SpringConfigurationPropertySource(PropertySource<?> propertySource, PropertyMapper... mappers)
/*     */   {
/*  70 */     Assert.notNull(propertySource, "PropertySource must not be null");
/*  71 */     Assert.isTrue(mappers.length > 0, "Mappers must contain at least one item");
/*  72 */     this.propertySource = propertySource;
/*  73 */     this.mappers = mappers;
/*     */   }
/*     */   
/*     */   public ConfigurationProperty getConfigurationProperty(ConfigurationPropertyName name)
/*     */   {
/*  78 */     if (name == null) {
/*  79 */       return null;
/*     */     }
/*  81 */     for (PropertyMapper mapper : this.mappers) {
/*     */       try {
/*  83 */         for (String candidate : mapper.map(name)) {
/*  84 */           Object value = getPropertySource().getProperty(candidate);
/*  85 */           if (value != null) {
/*  86 */             Origin origin = PropertySourceOrigin.get(getPropertySource(), candidate);
/*  87 */             return ConfigurationProperty.of(name, value, origin);
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (Exception localException1) {}
/*     */     }
/*     */     
/*  94 */     return null;
/*     */   }
/*     */   
/*     */   public ConfigurationPropertyState containsDescendantOf(ConfigurationPropertyName name)
/*     */   {
/*  99 */     PropertySource<?> source = getPropertySource();
/* 100 */     if ((source.getSource() instanceof Random)) {
/* 101 */       return containsDescendantOfForRandom("random", name);
/*     */     }
/* 103 */     if (((source.getSource() instanceof PropertySource)) && 
/* 104 */       ((((PropertySource)source.getSource()).getSource() instanceof Random)))
/*     */     {
/* 106 */       return containsDescendantOfForRandom(source.getName(), name);
/*     */     }
/* 108 */     return ConfigurationPropertyState.UNKNOWN;
/*     */   }
/*     */   
/*     */   private static ConfigurationPropertyState containsDescendantOfForRandom(String prefix, ConfigurationPropertyName name)
/*     */   {
/* 113 */     if ((name.getNumberOfElements() > 1) && (name.getElement(0, ConfigurationPropertyName.Form.DASHED).equals(prefix))) {
/* 114 */       return ConfigurationPropertyState.PRESENT;
/*     */     }
/* 116 */     return ConfigurationPropertyState.ABSENT;
/*     */   }
/*     */   
/*     */   public Object getUnderlyingSource()
/*     */   {
/* 121 */     return this.propertySource;
/*     */   }
/*     */   
/*     */   protected PropertySource<?> getPropertySource() {
/* 125 */     return this.propertySource;
/*     */   }
/*     */   
/*     */   protected final PropertyMapper[] getMappers() {
/* 129 */     return this.mappers;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 134 */     return this.propertySource.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static SpringConfigurationPropertySource from(PropertySource<?> source)
/*     */   {
/* 145 */     Assert.notNull(source, "Source must not be null");
/* 146 */     PropertyMapper[] mappers = getPropertyMappers(source);
/* 147 */     if (isFullEnumerable(source)) {
/* 148 */       return new SpringIterableConfigurationPropertySource((EnumerablePropertySource)source, mappers);
/*     */     }
/* 150 */     return new SpringConfigurationPropertySource(source, mappers);
/*     */   }
/*     */   
/*     */   private static PropertyMapper[] getPropertyMappers(PropertySource<?> source) {
/* 154 */     if (((source instanceof SystemEnvironmentPropertySource)) && (hasSystemEnvironmentName(source))) {
/* 155 */       return SYSTEM_ENVIRONMENT_MAPPERS;
/*     */     }
/* 157 */     return DEFAULT_MAPPERS;
/*     */   }
/*     */   
/*     */   private static boolean hasSystemEnvironmentName(PropertySource<?> source) {
/* 161 */     String name = source.getName();
/* 162 */     return ("systemEnvironment".equals(name)) || 
/* 163 */       (name.endsWith("-systemEnvironment"));
/*     */   }
/*     */   
/*     */   private static boolean isFullEnumerable(PropertySource<?> source) {
/* 167 */     PropertySource<?> rootSource = getRootSource(source);
/* 168 */     if ((rootSource.getSource() instanceof Map)) {
/*     */       try
/*     */       {
/* 171 */         ((Map)rootSource.getSource()).size();
/*     */       }
/*     */       catch (UnsupportedOperationException ex) {
/* 174 */         return false;
/*     */       }
/*     */     }
/* 177 */     return source instanceof EnumerablePropertySource;
/*     */   }
/*     */   
/*     */   private static PropertySource<?> getRootSource(PropertySource<?> source) {
/* 181 */     while ((source.getSource() != null) && ((source.getSource() instanceof PropertySource))) {
/* 182 */       source = (PropertySource)source.getSource();
/*     */     }
/* 184 */     return source;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\context\properties\source\SpringConfigurationPropertySource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */