package org.springframework.boot.web.reactive.server;

import org.springframework.boot.web.server.WebServer;
import org.springframework.http.server.reactive.HttpHandler;

@FunctionalInterface
public abstract interface ReactiveWebServerFactory
{
  public abstract WebServer getWebServer(HttpHandler paramHttpHandler);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\web\reactive\server\ReactiveWebServerFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */