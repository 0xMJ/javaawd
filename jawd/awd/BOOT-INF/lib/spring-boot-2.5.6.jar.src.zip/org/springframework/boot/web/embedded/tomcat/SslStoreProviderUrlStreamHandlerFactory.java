/*     */ package org.springframework.boot.web.embedded.tomcat;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.net.URLStreamHandler;
/*     */ import java.net.URLStreamHandlerFactory;
/*     */ import java.security.KeyStore;
/*     */ import org.springframework.boot.web.server.SslStoreProvider;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SslStoreProviderUrlStreamHandlerFactory
/*     */   implements URLStreamHandlerFactory
/*     */ {
/*     */   private static final String PROTOCOL = "springbootssl";
/*     */   private static final String KEY_STORE_PATH = "keyStore";
/*     */   static final String KEY_STORE_URL = "springbootssl:keyStore";
/*     */   private static final String TRUST_STORE_PATH = "trustStore";
/*     */   static final String TRUST_STORE_URL = "springbootssl:trustStore";
/*     */   private final SslStoreProvider sslStoreProvider;
/*     */   
/*     */   SslStoreProviderUrlStreamHandlerFactory(SslStoreProvider sslStoreProvider)
/*     */   {
/*  52 */     this.sslStoreProvider = sslStoreProvider;
/*     */   }
/*     */   
/*     */   public URLStreamHandler createURLStreamHandler(String protocol)
/*     */   {
/*  57 */     if ("springbootssl".equals(protocol)) {
/*  58 */       new URLStreamHandler()
/*     */       {
/*     */         protected URLConnection openConnection(URL url) throws IOException
/*     */         {
/*     */           try {
/*  63 */             if ("keyStore".equals(url.getPath())) {
/*  64 */               return new SslStoreProviderUrlStreamHandlerFactory.KeyStoreUrlConnection(url, 
/*  65 */                 SslStoreProviderUrlStreamHandlerFactory.this.sslStoreProvider.getKeyStore(), null);
/*     */             }
/*  67 */             if ("trustStore".equals(url.getPath())) {
/*  68 */               return new SslStoreProviderUrlStreamHandlerFactory.KeyStoreUrlConnection(url, 
/*  69 */                 SslStoreProviderUrlStreamHandlerFactory.this.sslStoreProvider.getTrustStore(), null);
/*     */             }
/*     */           }
/*     */           catch (Exception ex) {
/*  73 */             throw new IOException(ex);
/*     */           }
/*  75 */           throw new IOException("Invalid path: " + url.getPath());
/*     */         }
/*     */       };
/*     */     }
/*  79 */     return null;
/*     */   }
/*     */   
/*     */   private static final class KeyStoreUrlConnection extends URLConnection
/*     */   {
/*     */     private final KeyStore keyStore;
/*     */     
/*     */     private KeyStoreUrlConnection(URL url, KeyStore keyStore) {
/*  87 */       super();
/*  88 */       this.keyStore = keyStore;
/*     */     }
/*     */     
/*     */     public void connect()
/*     */       throws IOException
/*     */     {}
/*     */     
/*     */     public InputStream getInputStream()
/*     */       throws IOException
/*     */     {
/*     */       try
/*     */       {
/* 100 */         ByteArrayOutputStream stream = new ByteArrayOutputStream();
/* 101 */         this.keyStore.store(stream, new char[0]);
/* 102 */         return new ByteArrayInputStream(stream.toByteArray());
/*     */       }
/*     */       catch (Exception ex) {
/* 105 */         throw new IOException(ex);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\web\embedded\tomcat\SslStoreProviderUrlStreamHandlerFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */