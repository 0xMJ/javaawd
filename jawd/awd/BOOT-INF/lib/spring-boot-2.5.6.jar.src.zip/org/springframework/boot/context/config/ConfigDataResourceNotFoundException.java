/*     */ package org.springframework.boot.context.config;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.LinkOption;
/*     */ import java.nio.file.Path;
/*     */ import org.springframework.boot.origin.Origin;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConfigDataResourceNotFoundException
/*     */   extends ConfigDataNotFoundException
/*     */ {
/*     */   private final ConfigDataResource resource;
/*     */   private final ConfigDataLocation location;
/*     */   
/*     */   public ConfigDataResourceNotFoundException(ConfigDataResource resource)
/*     */   {
/*  45 */     this(resource, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ConfigDataResourceNotFoundException(ConfigDataResource resource, Throwable cause)
/*     */   {
/*  54 */     this(resource, null, cause);
/*     */   }
/*     */   
/*     */   private ConfigDataResourceNotFoundException(ConfigDataResource resource, ConfigDataLocation location, Throwable cause)
/*     */   {
/*  59 */     super(getMessage(resource, location), cause);
/*  60 */     Assert.notNull(resource, "Resource must not be null");
/*  61 */     this.resource = resource;
/*  62 */     this.location = location;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ConfigDataResource getResource()
/*     */   {
/*  70 */     return this.resource;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ConfigDataLocation getLocation()
/*     */   {
/*  78 */     return this.location;
/*     */   }
/*     */   
/*     */   public Origin getOrigin()
/*     */   {
/*  83 */     return Origin.from(this.location);
/*     */   }
/*     */   
/*     */   public String getReferenceDescription()
/*     */   {
/*  88 */     return getReferenceDescription(this.resource, this.location);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   ConfigDataResourceNotFoundException withLocation(ConfigDataLocation location)
/*     */   {
/*  97 */     return new ConfigDataResourceNotFoundException(this.resource, location, getCause());
/*     */   }
/*     */   
/*     */   private static String getMessage(ConfigDataResource resource, ConfigDataLocation location) {
/* 101 */     return String.format("Config data %s cannot be found", new Object[] { getReferenceDescription(resource, location) });
/*     */   }
/*     */   
/*     */   private static String getReferenceDescription(ConfigDataResource resource, ConfigDataLocation location) {
/* 105 */     String description = String.format("resource '%s'", new Object[] { resource });
/* 106 */     if (location != null) {
/* 107 */       description = description + String.format(" via location '%s'", new Object[] { location });
/*     */     }
/* 109 */     return description;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void throwIfDoesNotExist(ConfigDataResource resource, Path pathToCheck)
/*     */   {
/* 119 */     throwIfDoesNotExist(resource, Files.exists(pathToCheck, new LinkOption[0]));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void throwIfDoesNotExist(ConfigDataResource resource, File fileToCheck)
/*     */   {
/* 129 */     throwIfDoesNotExist(resource, fileToCheck.exists());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void throwIfDoesNotExist(ConfigDataResource resource, Resource resourceToCheck)
/*     */   {
/* 139 */     throwIfDoesNotExist(resource, resourceToCheck.exists());
/*     */   }
/*     */   
/*     */   private static void throwIfDoesNotExist(ConfigDataResource resource, boolean exists) {
/* 143 */     if (!exists) {
/* 144 */       throw new ConfigDataResourceNotFoundException(resource);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\context\config\ConfigDataResourceNotFoundException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */