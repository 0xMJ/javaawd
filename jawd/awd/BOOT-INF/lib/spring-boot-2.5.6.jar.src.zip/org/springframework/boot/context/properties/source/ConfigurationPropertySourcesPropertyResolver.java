/*     */ package org.springframework.boot.context.properties.source;
/*     */ 
/*     */ import org.springframework.core.env.AbstractPropertyResolver;
/*     */ import org.springframework.core.env.MutablePropertySources;
/*     */ import org.springframework.core.env.PropertySources;
/*     */ import org.springframework.core.env.PropertySourcesPropertyResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ConfigurationPropertySourcesPropertyResolver
/*     */   extends AbstractPropertyResolver
/*     */ {
/*     */   private final MutablePropertySources propertySources;
/*     */   private final DefaultResolver defaultResolver;
/*     */   
/*     */   ConfigurationPropertySourcesPropertyResolver(MutablePropertySources propertySources)
/*     */   {
/*  38 */     this.propertySources = propertySources;
/*  39 */     this.defaultResolver = new DefaultResolver(propertySources);
/*     */   }
/*     */   
/*     */   public boolean containsProperty(String key)
/*     */   {
/*  44 */     ConfigurationPropertySourcesPropertySource attached = getAttached();
/*  45 */     if (attached != null) {
/*  46 */       ConfigurationPropertyName name = ConfigurationPropertyName.of(key, true);
/*  47 */       if (name != null) {
/*     */         try {
/*  49 */           return attached.findConfigurationProperty(name) != null;
/*     */         }
/*     */         catch (Exception localException) {}
/*     */       }
/*     */     }
/*     */     
/*  55 */     return this.defaultResolver.containsProperty(key);
/*     */   }
/*     */   
/*     */   public String getProperty(String key)
/*     */   {
/*  60 */     return (String)getProperty(key, String.class, true);
/*     */   }
/*     */   
/*     */   public <T> T getProperty(String key, Class<T> targetValueType)
/*     */   {
/*  65 */     return (T)getProperty(key, targetValueType, true);
/*     */   }
/*     */   
/*     */   protected String getPropertyAsRawString(String key)
/*     */   {
/*  70 */     return (String)getProperty(key, String.class, false);
/*     */   }
/*     */   
/*     */   private <T> T getProperty(String key, Class<T> targetValueType, boolean resolveNestedPlaceholders) {
/*  74 */     Object value = findPropertyValue(key);
/*  75 */     if (value == null) {
/*  76 */       return null;
/*     */     }
/*  78 */     if ((resolveNestedPlaceholders) && ((value instanceof String))) {
/*  79 */       value = resolveNestedPlaceholders((String)value);
/*     */     }
/*  81 */     return (T)convertValueIfNecessary(value, targetValueType);
/*     */   }
/*     */   
/*     */   private Object findPropertyValue(String key) {
/*  85 */     ConfigurationPropertySourcesPropertySource attached = getAttached();
/*  86 */     if (attached != null) {
/*  87 */       ConfigurationPropertyName name = ConfigurationPropertyName.of(key, true);
/*  88 */       if (name != null) {
/*     */         try {
/*  90 */           ConfigurationProperty configurationProperty = attached.findConfigurationProperty(name);
/*  91 */           return configurationProperty != null ? configurationProperty.getValue() : null;
/*     */         }
/*     */         catch (Exception localException) {}
/*     */       }
/*     */     }
/*     */     
/*  97 */     return this.defaultResolver.getProperty(key, Object.class, false);
/*     */   }
/*     */   
/*     */   private ConfigurationPropertySourcesPropertySource getAttached()
/*     */   {
/* 102 */     ConfigurationPropertySourcesPropertySource attached = (ConfigurationPropertySourcesPropertySource)ConfigurationPropertySources.getAttached(this.propertySources);
/* 103 */     Iterable<ConfigurationPropertySource> attachedSource = attached != null ? (Iterable)attached.getSource() : null;
/* 104 */     if (((attachedSource instanceof SpringConfigurationPropertySources)) && 
/* 105 */       (((SpringConfigurationPropertySources)attachedSource).isUsingSources(this.propertySources))) {
/* 106 */       return attached;
/*     */     }
/* 108 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   static class DefaultResolver
/*     */     extends PropertySourcesPropertyResolver
/*     */   {
/*     */     DefaultResolver(PropertySources propertySources)
/*     */     {
/* 118 */       super();
/*     */     }
/*     */     
/*     */     public <T> T getProperty(String key, Class<T> targetValueType, boolean resolveNestedPlaceholders)
/*     */     {
/* 123 */       return (T)super.getProperty(key, targetValueType, resolveNestedPlaceholders);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\context\properties\source\ConfigurationPropertySourcesPropertyResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */