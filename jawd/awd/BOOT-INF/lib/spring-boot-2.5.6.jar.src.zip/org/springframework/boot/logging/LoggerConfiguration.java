/*     */ package org.springframework.boot.logging;
/*     */ 
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class LoggerConfiguration
/*     */ {
/*     */   private final String name;
/*     */   private final LogLevel configuredLevel;
/*     */   private final LogLevel effectiveLevel;
/*     */   
/*     */   public LoggerConfiguration(String name, LogLevel configuredLevel, LogLevel effectiveLevel)
/*     */   {
/*  43 */     Assert.notNull(name, "Name must not be null");
/*  44 */     Assert.notNull(effectiveLevel, "EffectiveLevel must not be null");
/*  45 */     this.name = name;
/*  46 */     this.configuredLevel = configuredLevel;
/*  47 */     this.effectiveLevel = effectiveLevel;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public LogLevel getConfiguredLevel()
/*     */   {
/*  55 */     return this.configuredLevel;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public LogLevel getEffectiveLevel()
/*     */   {
/*  63 */     return this.effectiveLevel;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/*  71 */     return this.name;
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/*  76 */     if (this == obj) {
/*  77 */       return true;
/*     */     }
/*  79 */     if (obj == null) {
/*  80 */       return false;
/*     */     }
/*  82 */     if ((obj instanceof LoggerConfiguration)) {
/*  83 */       LoggerConfiguration other = (LoggerConfiguration)obj;
/*  84 */       boolean rtn = true;
/*  85 */       rtn = (rtn) && (ObjectUtils.nullSafeEquals(this.name, other.name));
/*  86 */       rtn = (rtn) && (ObjectUtils.nullSafeEquals(this.configuredLevel, other.configuredLevel));
/*  87 */       rtn = (rtn) && (ObjectUtils.nullSafeEquals(this.effectiveLevel, other.effectiveLevel));
/*  88 */       return rtn;
/*     */     }
/*  90 */     return super.equals(obj);
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/*  95 */     int prime = 31;
/*  96 */     int result = 1;
/*  97 */     result = 31 * result + ObjectUtils.nullSafeHashCode(this.name);
/*  98 */     result = 31 * result + ObjectUtils.nullSafeHashCode(this.configuredLevel);
/*  99 */     result = 31 * result + ObjectUtils.nullSafeHashCode(this.effectiveLevel);
/* 100 */     return result;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 105 */     return "LoggerConfiguration [name=" + this.name + ", configuredLevel=" + this.configuredLevel + ", effectiveLevel=" + this.effectiveLevel + "]";
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\logging\LoggerConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */