/*    */ package org.springframework.boot.convert;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import java.util.Set;
/*    */ import org.springframework.core.convert.ConversionService;
/*    */ import org.springframework.core.convert.TypeDescriptor;
/*    */ import org.springframework.core.convert.converter.ConditionalGenericConverter;
/*    */ import org.springframework.core.convert.converter.GenericConverter.ConvertiblePair;
/*    */ import org.springframework.util.ObjectUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class ArrayToDelimitedStringConverter
/*    */   implements ConditionalGenericConverter
/*    */ {
/*    */   private final CollectionToDelimitedStringConverter delegate;
/*    */   
/*    */   ArrayToDelimitedStringConverter(ConversionService conversionService)
/*    */   {
/* 39 */     this.delegate = new CollectionToDelimitedStringConverter(conversionService);
/*    */   }
/*    */   
/*    */   public Set<GenericConverter.ConvertiblePair> getConvertibleTypes()
/*    */   {
/* 44 */     return Collections.singleton(new GenericConverter.ConvertiblePair(Object[].class, String.class));
/*    */   }
/*    */   
/*    */   public boolean matches(TypeDescriptor sourceType, TypeDescriptor targetType)
/*    */   {
/* 49 */     return this.delegate.matches(sourceType, targetType);
/*    */   }
/*    */   
/*    */   public Object convert(Object source, TypeDescriptor sourceType, TypeDescriptor targetType)
/*    */   {
/* 54 */     List<Object> list = Arrays.asList(ObjectUtils.toObjectArray(source));
/* 55 */     return this.delegate.convert(list, sourceType, targetType);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\convert\ArrayToDelimitedStringConverter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */