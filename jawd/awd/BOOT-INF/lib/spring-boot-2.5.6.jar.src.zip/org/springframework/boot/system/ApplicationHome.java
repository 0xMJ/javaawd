/*     */ package org.springframework.boot.system;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.JarURLConnection;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.security.CodeSource;
/*     */ import java.security.ProtectionDomain;
/*     */ import java.util.Enumeration;
/*     */ import java.util.jar.Attributes;
/*     */ import java.util.jar.JarFile;
/*     */ import java.util.jar.Manifest;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ApplicationHome
/*     */ {
/*     */   private final File source;
/*     */   private final File dir;
/*     */   
/*     */   public ApplicationHome()
/*     */   {
/*  53 */     this(null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ApplicationHome(Class<?> sourceClass)
/*     */   {
/*  61 */     this.source = findSource(sourceClass != null ? sourceClass : getStartClass());
/*  62 */     this.dir = findHomeDir(this.source);
/*     */   }
/*     */   
/*     */   private Class<?> getStartClass() {
/*     */     try {
/*  67 */       ClassLoader classLoader = getClass().getClassLoader();
/*  68 */       return getStartClass(classLoader.getResources("META-INF/MANIFEST.MF"));
/*     */     }
/*     */     catch (Exception ex) {}
/*  71 */     return null;
/*     */   }
/*     */   
/*     */   private Class<?> getStartClass(Enumeration<URL> manifestResources)
/*     */   {
/*  76 */     while (manifestResources.hasMoreElements()) {
/*  77 */       try { InputStream inputStream = ((URL)manifestResources.nextElement()).openStream();Throwable localThrowable4 = null;
/*  78 */         try { Manifest manifest = new Manifest(inputStream);
/*  79 */           String startClass = manifest.getMainAttributes().getValue("Start-Class");
/*  80 */           if (startClass != null) {
/*  81 */             return ClassUtils.forName(startClass, getClass().getClassLoader());
/*     */           }
/*     */         }
/*     */         catch (Throwable localThrowable2)
/*     */         {
/*  77 */           localThrowable4 = localThrowable2;throw localThrowable2;
/*     */ 
/*     */         }
/*     */         finally
/*     */         {
/*     */ 
/*  83 */           if (inputStream != null) if (localThrowable4 != null) try { inputStream.close(); } catch (Throwable localThrowable3) { localThrowable4.addSuppressed(localThrowable3); } else inputStream.close();
/*     */         }
/*     */       } catch (Exception localException) {}
/*     */     }
/*  87 */     return null;
/*     */   }
/*     */   
/*     */   private File findSource(Class<?> sourceClass) {
/*     */     try {
/*  92 */       ProtectionDomain domain = sourceClass != null ? sourceClass.getProtectionDomain() : null;
/*  93 */       CodeSource codeSource = domain != null ? domain.getCodeSource() : null;
/*  94 */       URL location = codeSource != null ? codeSource.getLocation() : null;
/*  95 */       File source = location != null ? findSource(location) : null;
/*  96 */       if ((source != null) && (source.exists()) && (!isUnitTest())) {
/*  97 */         return source.getAbsoluteFile();
/*     */       }
/*     */     }
/*     */     catch (Exception localException) {}
/*     */     
/* 102 */     return null;
/*     */   }
/*     */   
/*     */   private boolean isUnitTest() {
/*     */     try {
/* 107 */       StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
/* 108 */       for (int i = stackTrace.length - 1; i >= 0; i--) {
/* 109 */         if (stackTrace[i].getClassName().startsWith("org.junit.")) {
/* 110 */           return true;
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception localException) {}
/*     */     
/* 116 */     return false;
/*     */   }
/*     */   
/*     */   private File findSource(URL location) throws IOException, URISyntaxException {
/* 120 */     URLConnection connection = location.openConnection();
/* 121 */     if ((connection instanceof JarURLConnection)) {
/* 122 */       return getRootJarFile(((JarURLConnection)connection).getJarFile());
/*     */     }
/* 124 */     return new File(location.toURI());
/*     */   }
/*     */   
/*     */   private File getRootJarFile(JarFile jarFile) {
/* 128 */     String name = jarFile.getName();
/* 129 */     int separator = name.indexOf("!/");
/* 130 */     if (separator > 0) {
/* 131 */       name = name.substring(0, separator);
/*     */     }
/* 133 */     return new File(name);
/*     */   }
/*     */   
/*     */   private File findHomeDir(File source) {
/* 137 */     File homeDir = source;
/* 138 */     homeDir = homeDir != null ? homeDir : findDefaultHomeDir();
/* 139 */     if (homeDir.isFile()) {
/* 140 */       homeDir = homeDir.getParentFile();
/*     */     }
/* 142 */     homeDir = homeDir.exists() ? homeDir : new File(".");
/* 143 */     return homeDir.getAbsoluteFile();
/*     */   }
/*     */   
/*     */   private File findDefaultHomeDir() {
/* 147 */     String userDir = System.getProperty("user.dir");
/* 148 */     return new File(StringUtils.hasLength(userDir) ? userDir : ".");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public File getSource()
/*     */   {
/* 158 */     return this.source;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public File getDir()
/*     */   {
/* 166 */     return this.dir;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 171 */     return getDir().toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\system\ApplicationHome.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */