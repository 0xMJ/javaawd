/*    */ package org.springframework.boot.env;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.springframework.boot.origin.Origin;
/*    */ import org.springframework.boot.origin.OriginLookup;
/*    */ import org.springframework.boot.origin.OriginTrackedValue;
/*    */ import org.springframework.core.env.MapPropertySource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class OriginTrackedMapPropertySource
/*    */   extends MapPropertySource
/*    */   implements OriginLookup<String>
/*    */ {
/*    */   private final boolean immutable;
/*    */   
/*    */   public OriginTrackedMapPropertySource(String name, Map source)
/*    */   {
/* 46 */     this(name, source, false);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public OriginTrackedMapPropertySource(String name, Map source, boolean immutable)
/*    */   {
/* 58 */     super(name, source);
/* 59 */     this.immutable = immutable;
/*    */   }
/*    */   
/*    */   public Object getProperty(String name)
/*    */   {
/* 64 */     Object value = super.getProperty(name);
/* 65 */     if ((value instanceof OriginTrackedValue)) {
/* 66 */       return ((OriginTrackedValue)value).getValue();
/*    */     }
/* 68 */     return value;
/*    */   }
/*    */   
/*    */   public Origin getOrigin(String name)
/*    */   {
/* 73 */     Object value = super.getProperty(name);
/* 74 */     if ((value instanceof OriginTrackedValue)) {
/* 75 */       return ((OriginTrackedValue)value).getOrigin();
/*    */     }
/* 77 */     return null;
/*    */   }
/*    */   
/*    */   public boolean isImmutable()
/*    */   {
/* 82 */     return this.immutable;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\env\OriginTrackedMapPropertySource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */