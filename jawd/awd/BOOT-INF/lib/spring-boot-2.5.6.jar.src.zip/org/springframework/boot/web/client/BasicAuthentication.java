/*    */ package org.springframework.boot.web.client;
/*    */ 
/*    */ import java.nio.charset.Charset;
/*    */ import org.springframework.http.HttpHeaders;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class BasicAuthentication
/*    */ {
/*    */   private final String username;
/*    */   private final String password;
/*    */   private final Charset charset;
/*    */   
/*    */   BasicAuthentication(String username, String password, Charset charset)
/*    */   {
/* 39 */     Assert.notNull(username, "Username must not be null");
/* 40 */     Assert.notNull(password, "Password must not be null");
/* 41 */     this.username = username;
/* 42 */     this.password = password;
/* 43 */     this.charset = charset;
/*    */   }
/*    */   
/*    */   void applyTo(HttpHeaders headers) {
/* 47 */     if (!headers.containsKey("Authorization")) {
/* 48 */       headers.setBasicAuth(this.username, this.password, this.charset);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\web\client\BasicAuthentication.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */