/*     */ package org.springframework.boot.logging;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.function.Supplier;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DeferredLog
/*     */   implements Log
/*     */ {
/*     */   private volatile Log destination;
/*     */   private final Supplier<Log> destinationSupplier;
/*     */   private final Lines lines;
/*     */   
/*     */   public DeferredLog()
/*     */   {
/*  48 */     this.destinationSupplier = null;
/*  49 */     this.lines = new Lines();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   DeferredLog(Supplier<Log> destination, Lines lines)
/*     */   {
/*  59 */     Assert.notNull(destination, "Destination must not be null");
/*  60 */     this.destinationSupplier = destination;
/*  61 */     this.lines = lines;
/*     */   }
/*     */   
/*     */   public boolean isTraceEnabled()
/*     */   {
/*  66 */     synchronized (this.lines) {
/*  67 */       return (this.destination == null) || (this.destination.isTraceEnabled());
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isDebugEnabled()
/*     */   {
/*  73 */     synchronized (this.lines) {
/*  74 */       return (this.destination == null) || (this.destination.isDebugEnabled());
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isInfoEnabled()
/*     */   {
/*  80 */     synchronized (this.lines) {
/*  81 */       return (this.destination == null) || (this.destination.isInfoEnabled());
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isWarnEnabled()
/*     */   {
/*  87 */     synchronized (this.lines) {
/*  88 */       return (this.destination == null) || (this.destination.isWarnEnabled());
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isErrorEnabled()
/*     */   {
/*  94 */     synchronized (this.lines) {
/*  95 */       return (this.destination == null) || (this.destination.isErrorEnabled());
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isFatalEnabled()
/*     */   {
/* 101 */     synchronized (this.lines) {
/* 102 */       return (this.destination == null) || (this.destination.isFatalEnabled());
/*     */     }
/*     */   }
/*     */   
/*     */   public void trace(Object message)
/*     */   {
/* 108 */     log(LogLevel.TRACE, message, null);
/*     */   }
/*     */   
/*     */   public void trace(Object message, Throwable t)
/*     */   {
/* 113 */     log(LogLevel.TRACE, message, t);
/*     */   }
/*     */   
/*     */   public void debug(Object message)
/*     */   {
/* 118 */     log(LogLevel.DEBUG, message, null);
/*     */   }
/*     */   
/*     */   public void debug(Object message, Throwable t)
/*     */   {
/* 123 */     log(LogLevel.DEBUG, message, t);
/*     */   }
/*     */   
/*     */   public void info(Object message)
/*     */   {
/* 128 */     log(LogLevel.INFO, message, null);
/*     */   }
/*     */   
/*     */   public void info(Object message, Throwable t)
/*     */   {
/* 133 */     log(LogLevel.INFO, message, t);
/*     */   }
/*     */   
/*     */   public void warn(Object message)
/*     */   {
/* 138 */     log(LogLevel.WARN, message, null);
/*     */   }
/*     */   
/*     */   public void warn(Object message, Throwable t)
/*     */   {
/* 143 */     log(LogLevel.WARN, message, t);
/*     */   }
/*     */   
/*     */   public void error(Object message)
/*     */   {
/* 148 */     log(LogLevel.ERROR, message, null);
/*     */   }
/*     */   
/*     */   public void error(Object message, Throwable t)
/*     */   {
/* 153 */     log(LogLevel.ERROR, message, t);
/*     */   }
/*     */   
/*     */   public void fatal(Object message)
/*     */   {
/* 158 */     log(LogLevel.FATAL, message, null);
/*     */   }
/*     */   
/*     */   public void fatal(Object message, Throwable t)
/*     */   {
/* 163 */     log(LogLevel.FATAL, message, t);
/*     */   }
/*     */   
/*     */   private void log(LogLevel level, Object message, Throwable t) {
/* 167 */     synchronized (this.lines) {
/* 168 */       if (this.destination != null) {
/* 169 */         logTo(this.destination, level, message, t);
/*     */       }
/*     */       else {
/* 172 */         this.lines.add(this.destinationSupplier, level, message, t);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   void switchOver() {
/* 178 */     this.destination = ((Log)this.destinationSupplier.get());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void switchTo(Class<?> destination)
/*     */   {
/* 187 */     switchTo(LogFactory.getLog(destination));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void switchTo(Log destination)
/*     */   {
/* 196 */     synchronized (this.lines) {
/* 197 */       replayTo(destination);
/* 198 */       this.destination = destination;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void replayTo(Class<?> destination)
/*     */   {
/* 207 */     replayTo(LogFactory.getLog(destination));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void replayTo(Log destination)
/*     */   {
/* 215 */     synchronized (this.lines) {
/* 216 */       for (Line line : this.lines) {
/* 217 */         logTo(destination, line.getLevel(), line.getMessage(), line.getThrowable());
/*     */       }
/* 219 */       this.lines.clear();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Log replay(Log source, Class<?> destination)
/*     */   {
/* 230 */     return replay(source, LogFactory.getLog(destination));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Log replay(Log source, Log destination)
/*     */   {
/* 240 */     if ((source instanceof DeferredLog)) {
/* 241 */       ((DeferredLog)source).replayTo(destination);
/*     */     }
/* 243 */     return destination;
/*     */   }
/*     */   
/*     */   static void logTo(Log log, LogLevel level, Object message, Throwable throwable) {
/* 247 */     switch (level) {
/*     */     case TRACE: 
/* 249 */       log.trace(message, throwable);
/* 250 */       return;
/*     */     case DEBUG: 
/* 252 */       log.debug(message, throwable);
/* 253 */       return;
/*     */     case INFO: 
/* 255 */       log.info(message, throwable);
/* 256 */       return;
/*     */     case WARN: 
/* 258 */       log.warn(message, throwable);
/* 259 */       return;
/*     */     case ERROR: 
/* 261 */       log.error(message, throwable);
/* 262 */       return;
/*     */     case FATAL: 
/* 264 */       log.fatal(message, throwable);
/*     */     }
/*     */   }
/*     */   
/*     */   static class Lines implements Iterable<DeferredLog.Line>
/*     */   {
/* 270 */     private final List<DeferredLog.Line> lines = new ArrayList();
/*     */     
/*     */     void add(Supplier<Log> destinationSupplier, LogLevel level, Object message, Throwable throwable) {
/* 273 */       this.lines.add(new DeferredLog.Line(destinationSupplier, level, message, throwable));
/*     */     }
/*     */     
/*     */     void clear() {
/* 277 */       this.lines.clear();
/*     */     }
/*     */     
/*     */     public Iterator<DeferredLog.Line> iterator()
/*     */     {
/* 282 */       return this.lines.iterator();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   static class Line
/*     */   {
/*     */     private final Supplier<Log> destinationSupplier;
/*     */     
/*     */     private final LogLevel level;
/*     */     
/*     */     private final Object message;
/*     */     private final Throwable throwable;
/*     */     
/*     */     Line(Supplier<Log> destinationSupplier, LogLevel level, Object message, Throwable throwable)
/*     */     {
/* 298 */       this.destinationSupplier = destinationSupplier;
/* 299 */       this.level = level;
/* 300 */       this.message = message;
/* 301 */       this.throwable = throwable;
/*     */     }
/*     */     
/*     */     Log getDestination() {
/* 305 */       return (Log)this.destinationSupplier.get();
/*     */     }
/*     */     
/*     */     LogLevel getLevel() {
/* 309 */       return this.level;
/*     */     }
/*     */     
/*     */     Object getMessage() {
/* 313 */       return this.message;
/*     */     }
/*     */     
/*     */     Throwable getThrowable() {
/* 317 */       return this.throwable;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\logging\DeferredLog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */