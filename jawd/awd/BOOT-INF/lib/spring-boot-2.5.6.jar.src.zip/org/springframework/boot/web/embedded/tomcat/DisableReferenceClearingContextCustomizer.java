/*    */ package org.springframework.boot.web.embedded.tomcat;
/*    */ 
/*    */ import org.apache.catalina.Context;
/*    */ import org.apache.catalina.core.StandardContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class DisableReferenceClearingContextCustomizer
/*    */   implements TomcatContextCustomizer
/*    */ {
/*    */   public void customize(Context context)
/*    */   {
/* 32 */     if (!(context instanceof StandardContext)) {
/* 33 */       return;
/*    */     }
/* 35 */     StandardContext standardContext = (StandardContext)context;
/*    */     try {
/* 37 */       standardContext.setClearReferencesObjectStreamClassCaches(false);
/* 38 */       standardContext.setClearReferencesRmiTargets(false);
/* 39 */       standardContext.setClearReferencesThreadLocals(false);
/*    */     }
/*    */     catch (NoSuchMethodError localNoSuchMethodError) {}
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\web\embedded\tomcat\DisableReferenceClearingContextCustomizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */