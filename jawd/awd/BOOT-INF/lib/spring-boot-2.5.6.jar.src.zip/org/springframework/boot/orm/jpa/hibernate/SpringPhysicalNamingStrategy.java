/*    */ package org.springframework.boot.orm.jpa.hibernate;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import org.hibernate.boot.model.naming.Identifier;
/*    */ import org.hibernate.boot.model.naming.PhysicalNamingStrategy;
/*    */ import org.hibernate.engine.jdbc.env.spi.JdbcEnvironment;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SpringPhysicalNamingStrategy
/*    */   implements PhysicalNamingStrategy
/*    */ {
/*    */   public Identifier toPhysicalCatalogName(Identifier name, JdbcEnvironment jdbcEnvironment)
/*    */   {
/* 37 */     return apply(name, jdbcEnvironment);
/*    */   }
/*    */   
/*    */   public Identifier toPhysicalSchemaName(Identifier name, JdbcEnvironment jdbcEnvironment)
/*    */   {
/* 42 */     return apply(name, jdbcEnvironment);
/*    */   }
/*    */   
/*    */   public Identifier toPhysicalTableName(Identifier name, JdbcEnvironment jdbcEnvironment)
/*    */   {
/* 47 */     return apply(name, jdbcEnvironment);
/*    */   }
/*    */   
/*    */   public Identifier toPhysicalSequenceName(Identifier name, JdbcEnvironment jdbcEnvironment)
/*    */   {
/* 52 */     return apply(name, jdbcEnvironment);
/*    */   }
/*    */   
/*    */   public Identifier toPhysicalColumnName(Identifier name, JdbcEnvironment jdbcEnvironment)
/*    */   {
/* 57 */     return apply(name, jdbcEnvironment);
/*    */   }
/*    */   
/*    */   private Identifier apply(Identifier name, JdbcEnvironment jdbcEnvironment) {
/* 61 */     if (name == null) {
/* 62 */       return null;
/*    */     }
/* 64 */     StringBuilder builder = new StringBuilder(name.getText().replace('.', '_'));
/* 65 */     for (int i = 1; i < builder.length() - 1; i++) {
/* 66 */       if (isUnderscoreRequired(builder.charAt(i - 1), builder.charAt(i), builder.charAt(i + 1))) {
/* 67 */         builder.insert(i++, '_');
/*    */       }
/*    */     }
/* 70 */     return getIdentifier(builder.toString(), name.isQuoted(), jdbcEnvironment);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected Identifier getIdentifier(String name, boolean quoted, JdbcEnvironment jdbcEnvironment)
/*    */   {
/* 83 */     if (isCaseInsensitive(jdbcEnvironment)) {
/* 84 */       name = name.toLowerCase(Locale.ROOT);
/*    */     }
/* 86 */     return new Identifier(name, quoted);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected boolean isCaseInsensitive(JdbcEnvironment jdbcEnvironment)
/*    */   {
/* 95 */     return true;
/*    */   }
/*    */   
/*    */   private boolean isUnderscoreRequired(char before, char current, char after) {
/* 99 */     return (Character.isLowerCase(before)) && (Character.isUpperCase(current)) && (Character.isLowerCase(after));
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\orm\jpa\hibernate\SpringPhysicalNamingStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */