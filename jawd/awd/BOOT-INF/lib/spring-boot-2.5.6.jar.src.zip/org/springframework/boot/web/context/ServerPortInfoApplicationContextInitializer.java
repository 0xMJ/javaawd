/*    */ package org.springframework.boot.web.context;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.springframework.boot.web.server.WebServer;
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.context.ApplicationContextInitializer;
/*    */ import org.springframework.context.ApplicationListener;
/*    */ import org.springframework.context.ConfigurableApplicationContext;
/*    */ import org.springframework.core.env.ConfigurableEnvironment;
/*    */ import org.springframework.core.env.MapPropertySource;
/*    */ import org.springframework.core.env.MutablePropertySources;
/*    */ import org.springframework.core.env.PropertySource;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ServerPortInfoApplicationContextInitializer
/*    */   implements ApplicationContextInitializer<ConfigurableApplicationContext>, ApplicationListener<WebServerInitializedEvent>
/*    */ {
/*    */   public void initialize(ConfigurableApplicationContext applicationContext)
/*    */   {
/* 57 */     applicationContext.addApplicationListener(this);
/*    */   }
/*    */   
/*    */   public void onApplicationEvent(WebServerInitializedEvent event)
/*    */   {
/* 62 */     String propertyName = "local." + getName(event.getApplicationContext()) + ".port";
/* 63 */     setPortProperty(event.getApplicationContext(), propertyName, event.getWebServer().getPort());
/*    */   }
/*    */   
/*    */   private String getName(WebServerApplicationContext context) {
/* 67 */     String name = context.getServerNamespace();
/* 68 */     return StringUtils.hasText(name) ? name : "server";
/*    */   }
/*    */   
/*    */   private void setPortProperty(ApplicationContext context, String propertyName, int port) {
/* 72 */     if ((context instanceof ConfigurableApplicationContext)) {
/* 73 */       setPortProperty(((ConfigurableApplicationContext)context).getEnvironment(), propertyName, port);
/*    */     }
/* 75 */     if (context.getParent() != null) {
/* 76 */       setPortProperty(context.getParent(), propertyName, port);
/*    */     }
/*    */   }
/*    */   
/*    */   private void setPortProperty(ConfigurableEnvironment environment, String propertyName, int port)
/*    */   {
/* 82 */     MutablePropertySources sources = environment.getPropertySources();
/* 83 */     PropertySource<?> source = sources.get("server.ports");
/* 84 */     if (source == null) {
/* 85 */       source = new MapPropertySource("server.ports", new HashMap());
/* 86 */       sources.addFirst(source);
/*    */     }
/* 88 */     ((Map)source.getSource()).put(propertyName, Integer.valueOf(port));
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\web\context\ServerPortInfoApplicationContextInitializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */