/*    */ package org.springframework.boot.convert;
/*    */ 
/*    */ import java.time.Period;
/*    */ import java.time.temporal.ChronoUnit;
/*    */ import java.util.Collections;
/*    */ import java.util.Set;
/*    */ import org.springframework.core.convert.TypeDescriptor;
/*    */ import org.springframework.core.convert.converter.GenericConverter;
/*    */ import org.springframework.core.convert.converter.GenericConverter.ConvertiblePair;
/*    */ import org.springframework.util.ObjectUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class StringToPeriodConverter
/*    */   implements GenericConverter
/*    */ {
/*    */   public Set<GenericConverter.ConvertiblePair> getConvertibleTypes()
/*    */   {
/* 42 */     return Collections.singleton(new GenericConverter.ConvertiblePair(String.class, Period.class));
/*    */   }
/*    */   
/*    */   public Object convert(Object source, TypeDescriptor sourceType, TypeDescriptor targetType)
/*    */   {
/* 47 */     if (ObjectUtils.isEmpty(source)) {
/* 48 */       return null;
/*    */     }
/* 50 */     return convert(source.toString(), getStyle(targetType), getPeriodUnit(targetType));
/*    */   }
/*    */   
/*    */   private PeriodStyle getStyle(TypeDescriptor targetType) {
/* 54 */     PeriodFormat annotation = (PeriodFormat)targetType.getAnnotation(PeriodFormat.class);
/* 55 */     return annotation != null ? annotation.value() : null;
/*    */   }
/*    */   
/*    */   private ChronoUnit getPeriodUnit(TypeDescriptor targetType) {
/* 59 */     PeriodUnit annotation = (PeriodUnit)targetType.getAnnotation(PeriodUnit.class);
/* 60 */     return annotation != null ? annotation.value() : null;
/*    */   }
/*    */   
/*    */   private Period convert(String source, PeriodStyle style, ChronoUnit unit) {
/* 64 */     style = style != null ? style : PeriodStyle.detect(source);
/* 65 */     return style.parse(source, unit);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\convert\StringToPeriodConverter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */