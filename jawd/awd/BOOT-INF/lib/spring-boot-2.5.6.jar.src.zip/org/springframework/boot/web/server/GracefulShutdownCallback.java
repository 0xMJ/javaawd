package org.springframework.boot.web.server;

@FunctionalInterface
public abstract interface GracefulShutdownCallback
{
  public abstract void shutdownComplete(GracefulShutdownResult paramGracefulShutdownResult);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\web\server\GracefulShutdownCallback.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */