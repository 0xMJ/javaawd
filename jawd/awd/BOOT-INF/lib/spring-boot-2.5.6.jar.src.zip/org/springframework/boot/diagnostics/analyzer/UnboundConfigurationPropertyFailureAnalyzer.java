/*    */ package org.springframework.boot.diagnostics.analyzer;
/*    */ 
/*    */ import org.springframework.boot.context.properties.bind.BindException;
/*    */ import org.springframework.boot.context.properties.bind.UnboundConfigurationPropertiesException;
/*    */ import org.springframework.boot.context.properties.source.ConfigurationProperty;
/*    */ import org.springframework.boot.diagnostics.AbstractFailureAnalyzer;
/*    */ import org.springframework.boot.diagnostics.FailureAnalysis;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class UnboundConfigurationPropertyFailureAnalyzer
/*    */   extends AbstractFailureAnalyzer<UnboundConfigurationPropertiesException>
/*    */ {
/*    */   protected FailureAnalysis analyze(Throwable rootFailure, UnboundConfigurationPropertiesException cause)
/*    */   {
/* 36 */     BindException exception = (BindException)findCause(rootFailure, BindException.class);
/* 37 */     return analyzeUnboundConfigurationPropertiesException(exception, cause);
/*    */   }
/*    */   
/*    */ 
/*    */   private FailureAnalysis analyzeUnboundConfigurationPropertiesException(BindException cause, UnboundConfigurationPropertiesException exception)
/*    */   {
/* 43 */     StringBuilder description = new StringBuilder(String.format("Binding to target %s failed:%n", new Object[] { cause.getTarget() }));
/* 44 */     for (ConfigurationProperty property : exception.getUnboundProperties()) {
/* 45 */       buildDescription(description, property);
/* 46 */       description.append(String.format("%n    Reason: %s", new Object[] { exception.getMessage() }));
/*    */     }
/* 48 */     return getFailureAnalysis(description, cause);
/*    */   }
/*    */   
/*    */   private void buildDescription(StringBuilder description, ConfigurationProperty property) {
/* 52 */     if (property != null) {
/* 53 */       description.append(String.format("%n    Property: %s", new Object[] { property.getName() }));
/* 54 */       description.append(String.format("%n    Value: %s", new Object[] { property.getValue() }));
/* 55 */       description.append(String.format("%n    Origin: %s", new Object[] { property.getOrigin() }));
/*    */     }
/*    */   }
/*    */   
/*    */   private FailureAnalysis getFailureAnalysis(Object description, BindException cause) {
/* 60 */     return new FailureAnalysis(description.toString(), "Update your application's configuration", cause);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\diagnostics\analyzer\UnboundConfigurationPropertyFailureAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */