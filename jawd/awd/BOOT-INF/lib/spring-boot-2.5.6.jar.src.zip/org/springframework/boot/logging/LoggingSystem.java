/*     */ package org.springframework.boot.logging;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.Collections;
/*     */ import java.util.EnumSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class LoggingSystem
/*     */ {
/*  44 */   public static final String SYSTEM_PROPERTY = LoggingSystem.class.getName();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String NONE = "none";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String ROOT_LOGGER_NAME = "ROOT";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  59 */   private static final LoggingSystemFactory SYSTEM_FACTORY = LoggingSystemFactory.fromSpringFactories();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public LoggingSystemProperties getSystemProperties(ConfigurableEnvironment environment)
/*     */   {
/*  68 */     return new LoggingSystemProperties(environment);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void beforeInitialize();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void initialize(LoggingInitializationContext initializationContext, String configLocation, LogFile logFile) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void cleanUp() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Runnable getShutdownHandler()
/*     */   {
/* 103 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Set<LogLevel> getSupportedLogLevels()
/*     */   {
/* 112 */     return EnumSet.allOf(LogLevel.class);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLogLevel(String loggerName, LogLevel level)
/*     */   {
/* 123 */     throw new UnsupportedOperationException("Unable to set log level");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<LoggerConfiguration> getLoggerConfigurations()
/*     */   {
/* 133 */     throw new UnsupportedOperationException("Unable to get logger configurations");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public LoggerConfiguration getLoggerConfiguration(String loggerName)
/*     */   {
/* 143 */     throw new UnsupportedOperationException("Unable to get logger configuration");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static LoggingSystem get(ClassLoader classLoader)
/*     */   {
/* 152 */     String loggingSystemClassName = System.getProperty(SYSTEM_PROPERTY);
/* 153 */     if (StringUtils.hasLength(loggingSystemClassName)) {
/* 154 */       if ("none".equals(loggingSystemClassName)) {
/* 155 */         return new NoOpLoggingSystem();
/*     */       }
/* 157 */       return get(classLoader, loggingSystemClassName);
/*     */     }
/* 159 */     LoggingSystem loggingSystem = SYSTEM_FACTORY.getLoggingSystem(classLoader);
/* 160 */     Assert.state(loggingSystem != null, "No suitable logging system located");
/* 161 */     return loggingSystem;
/*     */   }
/*     */   
/*     */   private static LoggingSystem get(ClassLoader classLoader, String loggingSystemClassName) {
/*     */     try {
/* 166 */       Class<?> systemClass = ClassUtils.forName(loggingSystemClassName, classLoader);
/* 167 */       Constructor<?> constructor = systemClass.getDeclaredConstructor(new Class[] { ClassLoader.class });
/* 168 */       constructor.setAccessible(true);
/* 169 */       return (LoggingSystem)constructor.newInstance(new Object[] { classLoader });
/*     */     }
/*     */     catch (Exception ex) {
/* 172 */       throw new IllegalStateException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static class NoOpLoggingSystem
/*     */     extends LoggingSystem
/*     */   {
/*     */     public void beforeInitialize() {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public void setLogLevel(String loggerName, LogLevel level) {}
/*     */     
/*     */ 
/*     */ 
/*     */     public List<LoggerConfiguration> getLoggerConfigurations()
/*     */     {
/* 193 */       return Collections.emptyList();
/*     */     }
/*     */     
/*     */     public LoggerConfiguration getLoggerConfiguration(String loggerName)
/*     */     {
/* 198 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\logging\LoggingSystem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */