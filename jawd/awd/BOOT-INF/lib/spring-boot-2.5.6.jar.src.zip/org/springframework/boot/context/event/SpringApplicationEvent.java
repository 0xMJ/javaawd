/*    */ package org.springframework.boot.context.event;
/*    */ 
/*    */ import org.springframework.boot.SpringApplication;
/*    */ import org.springframework.context.ApplicationEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class SpringApplicationEvent
/*    */   extends ApplicationEvent
/*    */ {
/*    */   private final String[] args;
/*    */   
/*    */   public SpringApplicationEvent(SpringApplication application, String[] args)
/*    */   {
/* 34 */     super(application);
/* 35 */     this.args = args;
/*    */   }
/*    */   
/*    */   public SpringApplication getSpringApplication() {
/* 39 */     return (SpringApplication)getSource();
/*    */   }
/*    */   
/*    */   public final String[] getArgs() {
/* 43 */     return this.args;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\context\event\SpringApplicationEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */