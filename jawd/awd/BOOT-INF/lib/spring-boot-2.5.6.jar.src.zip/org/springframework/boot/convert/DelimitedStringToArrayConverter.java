/*    */ package org.springframework.boot.convert;
/*    */ 
/*    */ import java.lang.reflect.Array;
/*    */ import java.util.Collections;
/*    */ import java.util.Set;
/*    */ import org.springframework.core.convert.ConversionService;
/*    */ import org.springframework.core.convert.TypeDescriptor;
/*    */ import org.springframework.core.convert.converter.ConditionalGenericConverter;
/*    */ import org.springframework.core.convert.converter.GenericConverter.ConvertiblePair;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class DelimitedStringToArrayConverter
/*    */   implements ConditionalGenericConverter
/*    */ {
/*    */   private final ConversionService conversionService;
/*    */   
/*    */   DelimitedStringToArrayConverter(ConversionService conversionService)
/*    */   {
/* 39 */     Assert.notNull(conversionService, "ConversionService must not be null");
/* 40 */     this.conversionService = conversionService;
/*    */   }
/*    */   
/*    */   public Set<GenericConverter.ConvertiblePair> getConvertibleTypes()
/*    */   {
/* 45 */     return Collections.singleton(new GenericConverter.ConvertiblePair(String.class, Object[].class));
/*    */   }
/*    */   
/*    */   public boolean matches(TypeDescriptor sourceType, TypeDescriptor targetType)
/*    */   {
/* 50 */     return (targetType.getElementTypeDescriptor() == null) || 
/* 51 */       (this.conversionService.canConvert(sourceType, targetType.getElementTypeDescriptor()));
/*    */   }
/*    */   
/*    */   public Object convert(Object source, TypeDescriptor sourceType, TypeDescriptor targetType)
/*    */   {
/* 56 */     if (source == null) {
/* 57 */       return null;
/*    */     }
/* 59 */     return convert((String)source, sourceType, targetType);
/*    */   }
/*    */   
/*    */   private Object convert(String source, TypeDescriptor sourceType, TypeDescriptor targetType) {
/* 63 */     Delimiter delimiter = (Delimiter)targetType.getAnnotation(Delimiter.class);
/* 64 */     String[] elements = getElements(source, delimiter != null ? delimiter.value() : ",");
/* 65 */     TypeDescriptor elementDescriptor = targetType.getElementTypeDescriptor();
/* 66 */     Object target = Array.newInstance(elementDescriptor.getType(), elements.length);
/* 67 */     for (int i = 0; i < elements.length; i++) {
/* 68 */       String sourceElement = elements[i];
/* 69 */       Object targetElement = this.conversionService.convert(sourceElement.trim(), sourceType, elementDescriptor);
/* 70 */       Array.set(target, i, targetElement);
/*    */     }
/* 72 */     return target;
/*    */   }
/*    */   
/*    */   private String[] getElements(String source, String delimiter) {
/* 76 */     return StringUtils.delimitedListToStringArray(source, "".equals(delimiter) ? null : delimiter);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\convert\DelimitedStringToArrayConverter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */