/*    */ package org.springframework.boot.origin;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import java.util.LinkedHashSet;
/*    */ import java.util.List;
/*    */ import java.util.Set;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract interface Origin
/*    */ {
/*    */   public Origin getParent()
/*    */   {
/* 50 */     return null;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static Origin from(Object source)
/*    */   {
/* 60 */     if ((source instanceof Origin)) {
/* 61 */       return (Origin)source;
/*    */     }
/* 63 */     Origin origin = null;
/* 64 */     if ((source instanceof OriginProvider)) {
/* 65 */       origin = ((OriginProvider)source).getOrigin();
/*    */     }
/* 67 */     if ((origin == null) && ((source instanceof Throwable))) {
/* 68 */       return from(((Throwable)source).getCause());
/*    */     }
/* 70 */     return origin;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static List<Origin> parentsFrom(Object source)
/*    */   {
/* 84 */     Origin origin = from(source);
/* 85 */     if (origin == null) {
/* 86 */       return Collections.emptyList();
/*    */     }
/* 88 */     Set<Origin> parents = new LinkedHashSet();
/* 89 */     origin = origin.getParent();
/* 90 */     while ((origin != null) && (!parents.contains(origin))) {
/* 91 */       parents.add(origin);
/* 92 */       origin = origin.getParent();
/*    */     }
/* 94 */     return Collections.unmodifiableList(new ArrayList(parents));
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\origin\Origin.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */