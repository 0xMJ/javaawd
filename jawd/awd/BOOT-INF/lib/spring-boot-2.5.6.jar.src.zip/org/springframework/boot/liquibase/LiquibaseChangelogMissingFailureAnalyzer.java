/*    */ package org.springframework.boot.liquibase;
/*    */ 
/*    */ import liquibase.exception.ChangeLogParseException;
/*    */ import org.springframework.boot.diagnostics.AbstractFailureAnalyzer;
/*    */ import org.springframework.boot.diagnostics.FailureAnalysis;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class LiquibaseChangelogMissingFailureAnalyzer
/*    */   extends AbstractFailureAnalyzer<ChangeLogParseException>
/*    */ {
/*    */   private static final String MESSAGE_SUFFIX = " does not exist";
/*    */   
/*    */   protected FailureAnalysis analyze(Throwable rootFailure, ChangeLogParseException cause)
/*    */   {
/* 36 */     if (cause.getMessage().endsWith(" does not exist")) {
/* 37 */       String changelogPath = extractChangelogPath(cause);
/* 38 */       return new FailureAnalysis(getDescription(changelogPath), "Make sure a Liquibase changelog is present at the configured path.", cause);
/*    */     }
/*    */     
/* 41 */     return null;
/*    */   }
/*    */   
/*    */   private String extractChangelogPath(ChangeLogParseException cause) {
/* 45 */     return cause.getMessage().substring(0, cause.getMessage().length() - " does not exist".length());
/*    */   }
/*    */   
/*    */   private String getDescription(String changelogPath) {
/* 49 */     return "Liquibase failed to start because no changelog could be found at '" + changelogPath + "'.";
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\liquibase\LiquibaseChangelogMissingFailureAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */