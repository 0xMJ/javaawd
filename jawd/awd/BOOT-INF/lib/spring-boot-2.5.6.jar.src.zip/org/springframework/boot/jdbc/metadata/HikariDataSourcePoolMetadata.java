/*    */ package org.springframework.boot.jdbc.metadata;
/*    */ 
/*    */ import com.zaxxer.hikari.HikariDataSource;
/*    */ import com.zaxxer.hikari.pool.HikariPool;
/*    */ import org.springframework.beans.DirectFieldAccessor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HikariDataSourcePoolMetadata
/*    */   extends AbstractDataSourcePoolMetadata<HikariDataSource>
/*    */ {
/*    */   public HikariDataSourcePoolMetadata(HikariDataSource dataSource)
/*    */   {
/* 35 */     super(dataSource);
/*    */   }
/*    */   
/*    */   public Integer getActive()
/*    */   {
/*    */     try {
/* 41 */       return Integer.valueOf(getHikariPool().getActiveConnections());
/*    */     }
/*    */     catch (Exception ex) {}
/* 44 */     return null;
/*    */   }
/*    */   
/*    */   public Integer getIdle()
/*    */   {
/*    */     try
/*    */     {
/* 51 */       return Integer.valueOf(getHikariPool().getIdleConnections());
/*    */     }
/*    */     catch (Exception ex) {}
/* 54 */     return null;
/*    */   }
/*    */   
/*    */   private HikariPool getHikariPool()
/*    */   {
/* 59 */     return (HikariPool)new DirectFieldAccessor(getDataSource()).getPropertyValue("pool");
/*    */   }
/*    */   
/*    */   public Integer getMax()
/*    */   {
/* 64 */     return Integer.valueOf(((HikariDataSource)getDataSource()).getMaximumPoolSize());
/*    */   }
/*    */   
/*    */   public Integer getMin()
/*    */   {
/* 69 */     return Integer.valueOf(((HikariDataSource)getDataSource()).getMinimumIdle());
/*    */   }
/*    */   
/*    */   public String getValidationQuery()
/*    */   {
/* 74 */     return ((HikariDataSource)getDataSource()).getConnectionTestQuery();
/*    */   }
/*    */   
/*    */   public Boolean getDefaultAutoCommit()
/*    */   {
/* 79 */     return Boolean.valueOf(((HikariDataSource)getDataSource()).isAutoCommit());
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\jdbc\metadata\HikariDataSourcePoolMetadata.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */