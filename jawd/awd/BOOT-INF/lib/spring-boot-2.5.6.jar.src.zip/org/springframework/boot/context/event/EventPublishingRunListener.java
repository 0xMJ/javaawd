/*     */ package org.springframework.boot.context.event;
/*     */ 
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.boot.ConfigurableBootstrapContext;
/*     */ import org.springframework.boot.SpringApplication;
/*     */ import org.springframework.boot.SpringApplicationRunListener;
/*     */ import org.springframework.boot.availability.AvailabilityChangeEvent;
/*     */ import org.springframework.boot.availability.LivenessState;
/*     */ import org.springframework.boot.availability.ReadinessState;
/*     */ import org.springframework.context.ApplicationContextAware;
/*     */ import org.springframework.context.ApplicationListener;
/*     */ import org.springframework.context.ConfigurableApplicationContext;
/*     */ import org.springframework.context.event.SimpleApplicationEventMulticaster;
/*     */ import org.springframework.context.support.AbstractApplicationContext;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.util.ErrorHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EventPublishingRunListener
/*     */   implements SpringApplicationRunListener, Ordered
/*     */ {
/*     */   private final SpringApplication application;
/*     */   private final String[] args;
/*     */   private final SimpleApplicationEventMulticaster initialMulticaster;
/*     */   
/*     */   public EventPublishingRunListener(SpringApplication application, String[] args)
/*     */   {
/*  60 */     this.application = application;
/*  61 */     this.args = args;
/*  62 */     this.initialMulticaster = new SimpleApplicationEventMulticaster();
/*  63 */     for (ApplicationListener<?> listener : application.getListeners()) {
/*  64 */       this.initialMulticaster.addApplicationListener(listener);
/*     */     }
/*     */   }
/*     */   
/*     */   public int getOrder()
/*     */   {
/*  70 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */   public void starting(ConfigurableBootstrapContext bootstrapContext)
/*     */   {
/*  76 */     this.initialMulticaster.multicastEvent(new ApplicationStartingEvent(bootstrapContext, this.application, this.args));
/*     */   }
/*     */   
/*     */ 
/*     */   public void environmentPrepared(ConfigurableBootstrapContext bootstrapContext, ConfigurableEnvironment environment)
/*     */   {
/*  82 */     this.initialMulticaster.multicastEvent(new ApplicationEnvironmentPreparedEvent(bootstrapContext, this.application, this.args, environment));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void contextPrepared(ConfigurableApplicationContext context)
/*     */   {
/*  89 */     this.initialMulticaster.multicastEvent(new ApplicationContextInitializedEvent(this.application, this.args, context));
/*     */   }
/*     */   
/*     */   public void contextLoaded(ConfigurableApplicationContext context)
/*     */   {
/*  94 */     for (ApplicationListener<?> listener : this.application.getListeners()) {
/*  95 */       if ((listener instanceof ApplicationContextAware)) {
/*  96 */         ((ApplicationContextAware)listener).setApplicationContext(context);
/*     */       }
/*  98 */       context.addApplicationListener(listener);
/*     */     }
/* 100 */     this.initialMulticaster.multicastEvent(new ApplicationPreparedEvent(this.application, this.args, context));
/*     */   }
/*     */   
/*     */   public void started(ConfigurableApplicationContext context)
/*     */   {
/* 105 */     context.publishEvent(new ApplicationStartedEvent(this.application, this.args, context));
/* 106 */     AvailabilityChangeEvent.publish(context, LivenessState.CORRECT);
/*     */   }
/*     */   
/*     */   public void running(ConfigurableApplicationContext context)
/*     */   {
/* 111 */     context.publishEvent(new ApplicationReadyEvent(this.application, this.args, context));
/* 112 */     AvailabilityChangeEvent.publish(context, ReadinessState.ACCEPTING_TRAFFIC);
/*     */   }
/*     */   
/*     */   public void failed(ConfigurableApplicationContext context, Throwable exception)
/*     */   {
/* 117 */     ApplicationFailedEvent event = new ApplicationFailedEvent(this.application, this.args, context, exception);
/* 118 */     if ((context != null) && (context.isActive()))
/*     */     {
/*     */ 
/* 121 */       context.publishEvent(event);
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 126 */       if ((context instanceof AbstractApplicationContext)) {
/* 127 */         for (ApplicationListener<?> listener : ((AbstractApplicationContext)context)
/* 128 */           .getApplicationListeners()) {
/* 129 */           this.initialMulticaster.addApplicationListener(listener);
/*     */         }
/*     */       }
/* 132 */       this.initialMulticaster.setErrorHandler(new LoggingErrorHandler(null));
/* 133 */       this.initialMulticaster.multicastEvent(event);
/*     */     }
/*     */   }
/*     */   
/*     */   private static class LoggingErrorHandler implements ErrorHandler
/*     */   {
/* 139 */     private static final Log logger = LogFactory.getLog(EventPublishingRunListener.class);
/*     */     
/*     */     public void handleError(Throwable throwable)
/*     */     {
/* 143 */       logger.warn("Error calling ApplicationEventListener", throwable);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\context\event\EventPublishingRunListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */