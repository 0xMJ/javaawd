package org.springframework.boot.web.server;

import java.net.InetAddress;
import java.util.Set;

public abstract interface ConfigurableWebServerFactory
  extends WebServerFactory, ErrorPageRegistry
{
  public abstract void setPort(int paramInt);
  
  public abstract void setAddress(InetAddress paramInetAddress);
  
  public abstract void setErrorPages(Set<? extends ErrorPage> paramSet);
  
  public abstract void setSsl(Ssl paramSsl);
  
  public abstract void setSslStoreProvider(SslStoreProvider paramSslStoreProvider);
  
  public abstract void setHttp2(Http2 paramHttp2);
  
  public abstract void setCompression(Compression paramCompression);
  
  public abstract void setServerHeader(String paramString);
  
  public void setShutdown(Shutdown shutdown) {}
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\web\server\ConfigurableWebServerFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */