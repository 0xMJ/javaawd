/*     */ package org.springframework.boot.env;
/*     */ 
/*     */ import java.util.Map;
/*     */ import org.springframework.boot.SpringApplication;
/*     */ import org.springframework.boot.origin.Origin;
/*     */ import org.springframework.boot.origin.OriginLookup;
/*     */ import org.springframework.boot.origin.SystemEnvironmentOrigin;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.core.env.MutablePropertySources;
/*     */ import org.springframework.core.env.PropertySource;
/*     */ import org.springframework.core.env.SystemEnvironmentPropertySource;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SystemEnvironmentPropertySourceEnvironmentPostProcessor
/*     */   implements EnvironmentPostProcessor, Ordered
/*     */ {
/*     */   public static final int DEFAULT_ORDER = -2147483644;
/*  48 */   private int order = -2147483644;
/*     */   
/*     */   public void postProcessEnvironment(ConfigurableEnvironment environment, SpringApplication application)
/*     */   {
/*  52 */     String sourceName = "systemEnvironment";
/*  53 */     PropertySource<?> propertySource = environment.getPropertySources().get(sourceName);
/*  54 */     if (propertySource != null) {
/*  55 */       replacePropertySource(environment, sourceName, propertySource, application.getEnvironmentPrefix());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void replacePropertySource(ConfigurableEnvironment environment, String sourceName, PropertySource<?> propertySource, String environmentPrefix)
/*     */   {
/*  62 */     Map<String, Object> originalSource = (Map)propertySource.getSource();
/*  63 */     SystemEnvironmentPropertySource source = new OriginAwareSystemEnvironmentPropertySource(sourceName, originalSource, environmentPrefix);
/*     */     
/*  65 */     environment.getPropertySources().replace(sourceName, source);
/*     */   }
/*     */   
/*     */   public int getOrder()
/*     */   {
/*  70 */     return this.order;
/*     */   }
/*     */   
/*     */   public void setOrder(int order) {
/*  74 */     this.order = order;
/*     */   }
/*     */   
/*     */ 
/*     */   protected static class OriginAwareSystemEnvironmentPropertySource
/*     */     extends SystemEnvironmentPropertySource
/*     */     implements OriginLookup<String>
/*     */   {
/*     */     private final String prefix;
/*     */     
/*     */     OriginAwareSystemEnvironmentPropertySource(String name, Map<String, Object> source, String environmentPrefix)
/*     */     {
/*  86 */       super(source);
/*  87 */       this.prefix = determinePrefix(environmentPrefix);
/*     */     }
/*     */     
/*     */     private String determinePrefix(String environmentPrefix) {
/*  91 */       if (!StringUtils.hasText(environmentPrefix)) {
/*  92 */         return null;
/*     */       }
/*  94 */       if ((environmentPrefix.endsWith(".")) || (environmentPrefix.endsWith("_")) || (environmentPrefix.endsWith("-"))) {
/*  95 */         return environmentPrefix.substring(0, environmentPrefix.length() - 1);
/*     */       }
/*  97 */       return environmentPrefix;
/*     */     }
/*     */     
/*     */     public boolean containsProperty(String name)
/*     */     {
/* 102 */       return super.containsProperty(name);
/*     */     }
/*     */     
/*     */     public Object getProperty(String name)
/*     */     {
/* 107 */       return super.getProperty(name);
/*     */     }
/*     */     
/*     */     public Origin getOrigin(String key)
/*     */     {
/* 112 */       String property = resolvePropertyName(key);
/* 113 */       if (super.containsProperty(property)) {
/* 114 */         return new SystemEnvironmentOrigin(property);
/*     */       }
/* 116 */       return null;
/*     */     }
/*     */     
/*     */     public String getPrefix()
/*     */     {
/* 121 */       return this.prefix;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\env\SystemEnvironmentPropertySourceEnvironmentPostProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */