/*    */ package org.springframework.boot.web.reactive.error;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.Map;
/*    */ import org.springframework.boot.web.error.ErrorAttributeOptions;
/*    */ import org.springframework.web.reactive.function.server.ServerRequest;
/*    */ import org.springframework.web.server.ServerWebExchange;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract interface ErrorAttributes
/*    */ {
/* 42 */   public static final String ERROR_ATTRIBUTE = ErrorAttributes.class.getName() + ".error";
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Map<String, Object> getErrorAttributes(ServerRequest request, ErrorAttributeOptions options)
/*    */   {
/* 52 */     return Collections.emptyMap();
/*    */   }
/*    */   
/*    */   public abstract Throwable getError(ServerRequest paramServerRequest);
/*    */   
/*    */   public abstract void storeErrorInformation(Throwable paramThrowable, ServerWebExchange paramServerWebExchange);
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\web\reactive\error\ErrorAttributes.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */