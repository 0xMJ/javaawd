/*    */ package org.springframework.boot.convert;
/*    */ 
/*    */ import java.time.Duration;
/*    */ import java.time.temporal.ChronoUnit;
/*    */ import java.util.Collections;
/*    */ import java.util.Set;
/*    */ import org.springframework.core.convert.TypeDescriptor;
/*    */ import org.springframework.core.convert.converter.GenericConverter;
/*    */ import org.springframework.core.convert.converter.GenericConverter.ConvertiblePair;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class DurationToStringConverter
/*    */   implements GenericConverter
/*    */ {
/*    */   public Set<GenericConverter.ConvertiblePair> getConvertibleTypes()
/*    */   {
/* 39 */     return Collections.singleton(new GenericConverter.ConvertiblePair(Duration.class, String.class));
/*    */   }
/*    */   
/*    */   public Object convert(Object source, TypeDescriptor sourceType, TypeDescriptor targetType)
/*    */   {
/* 44 */     if (source == null) {
/* 45 */       return null;
/*    */     }
/* 47 */     return convert((Duration)source, getDurationStyle(sourceType), getDurationUnit(sourceType));
/*    */   }
/*    */   
/*    */   private ChronoUnit getDurationUnit(TypeDescriptor sourceType) {
/* 51 */     DurationUnit annotation = (DurationUnit)sourceType.getAnnotation(DurationUnit.class);
/* 52 */     return annotation != null ? annotation.value() : null;
/*    */   }
/*    */   
/*    */   private DurationStyle getDurationStyle(TypeDescriptor sourceType) {
/* 56 */     DurationFormat annotation = (DurationFormat)sourceType.getAnnotation(DurationFormat.class);
/* 57 */     return annotation != null ? annotation.value() : null;
/*    */   }
/*    */   
/*    */   private String convert(Duration source, DurationStyle style, ChronoUnit unit) {
/* 61 */     style = style != null ? style : DurationStyle.ISO8601;
/* 62 */     return style.print(source, unit);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\convert\DurationToStringConverter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */