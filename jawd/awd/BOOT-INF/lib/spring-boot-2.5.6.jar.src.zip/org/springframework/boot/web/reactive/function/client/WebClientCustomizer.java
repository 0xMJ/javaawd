package org.springframework.boot.web.reactive.function.client;

import org.springframework.web.reactive.function.client.WebClient.Builder;

@FunctionalInterface
public abstract interface WebClientCustomizer
{
  public abstract void customize(WebClient.Builder paramBuilder);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\web\reactive\function\client\WebClientCustomizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */