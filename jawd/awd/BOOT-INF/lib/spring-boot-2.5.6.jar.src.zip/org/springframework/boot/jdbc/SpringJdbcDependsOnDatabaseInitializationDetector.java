/*    */ package org.springframework.boot.jdbc;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ import org.springframework.boot.sql.init.dependency.AbstractBeansOfTypeDependsOnDatabaseInitializationDetector;
/*    */ import org.springframework.jdbc.core.JdbcOperations;
/*    */ import org.springframework.jdbc.core.namedparam.NamedParameterJdbcOperations;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SpringJdbcDependsOnDatabaseInitializationDetector
/*    */   extends AbstractBeansOfTypeDependsOnDatabaseInitializationDetector
/*    */ {
/*    */   protected Set<Class<?>> getDependsOnDatabaseInitializationBeanTypes()
/*    */   {
/* 38 */     return new HashSet(Arrays.asList(new Class[] { JdbcOperations.class, NamedParameterJdbcOperations.class }));
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\jdbc\SpringJdbcDependsOnDatabaseInitializationDetector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */