/*    */ package org.springframework.boot.web.embedded.undertow;
/*    */ 
/*    */ import io.undertow.UndertowMessages;
/*    */ import io.undertow.server.handlers.resource.Resource;
/*    */ import io.undertow.server.handlers.resource.ResourceChangeListener;
/*    */ import io.undertow.server.handlers.resource.ResourceManager;
/*    */ import io.undertow.server.handlers.resource.URLResource;
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import java.net.MalformedURLException;
/*    */ import java.net.URI;
/*    */ import java.net.URL;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class JarResourceManager
/*    */   implements ResourceManager
/*    */ {
/*    */   private final String jarPath;
/*    */   
/*    */   JarResourceManager(File jarFile)
/*    */   {
/*    */     try
/*    */     {
/* 44 */       this.jarPath = jarFile.getAbsoluteFile().toURI().toURL().toString();
/*    */     }
/*    */     catch (MalformedURLException ex) {
/* 47 */       throw new IllegalArgumentException(ex);
/*    */     }
/*    */   }
/*    */   
/*    */   public Resource getResource(String path) throws IOException
/*    */   {
/* 53 */     URL url = new URL("jar:" + this.jarPath + "!" + (path.startsWith("/") ? path : new StringBuilder().append("/").append(path).toString()));
/* 54 */     URLResource resource = new URLResource(url, path);
/* 55 */     if ((StringUtils.hasText(path)) && (!"/".equals(path)) && (resource.getContentLength().longValue() < 0L)) {
/* 56 */       return null;
/*    */     }
/* 58 */     return resource;
/*    */   }
/*    */   
/*    */   public boolean isResourceChangeListenerSupported()
/*    */   {
/* 63 */     return false;
/*    */   }
/*    */   
/*    */   public void registerResourceChangeListener(ResourceChangeListener listener)
/*    */   {
/* 68 */     throw UndertowMessages.MESSAGES.resourceChangeListenerNotSupported();
/*    */   }
/*    */   
/*    */ 
/*    */   public void removeResourceChangeListener(ResourceChangeListener listener)
/*    */   {
/* 74 */     throw UndertowMessages.MESSAGES.resourceChangeListenerNotSupported();
/*    */   }
/*    */   
/*    */   public void close()
/*    */     throws IOException
/*    */   {}
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\web\embedded\undertow\JarResourceManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */