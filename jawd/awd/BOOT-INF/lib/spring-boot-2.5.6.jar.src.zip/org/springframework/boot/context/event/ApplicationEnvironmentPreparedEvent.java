/*    */ package org.springframework.boot.context.event;
/*    */ 
/*    */ import org.springframework.boot.ConfigurableBootstrapContext;
/*    */ import org.springframework.boot.SpringApplication;
/*    */ import org.springframework.core.env.ConfigurableEnvironment;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ApplicationEnvironmentPreparedEvent
/*    */   extends SpringApplicationEvent
/*    */ {
/*    */   private final ConfigurableBootstrapContext bootstrapContext;
/*    */   private final ConfigurableEnvironment environment;
/*    */   
/*    */   @Deprecated
/*    */   public ApplicationEnvironmentPreparedEvent(SpringApplication application, String[] args, ConfigurableEnvironment environment)
/*    */   {
/* 49 */     this(null, application, args, environment);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ApplicationEnvironmentPreparedEvent(ConfigurableBootstrapContext bootstrapContext, SpringApplication application, String[] args, ConfigurableEnvironment environment)
/*    */   {
/* 61 */     super(application, args);
/* 62 */     this.bootstrapContext = bootstrapContext;
/* 63 */     this.environment = environment;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ConfigurableBootstrapContext getBootstrapContext()
/*    */   {
/* 72 */     return this.bootstrapContext;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public ConfigurableEnvironment getEnvironment()
/*    */   {
/* 80 */     return this.environment;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\context\event\ApplicationEnvironmentPreparedEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */