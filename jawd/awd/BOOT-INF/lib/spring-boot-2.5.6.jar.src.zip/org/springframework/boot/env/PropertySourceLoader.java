package org.springframework.boot.env;

import java.io.IOException;
import java.util.List;
import org.springframework.core.env.PropertySource;
import org.springframework.core.io.Resource;

public abstract interface PropertySourceLoader
{
  public abstract String[] getFileExtensions();
  
  public abstract List<PropertySource<?>> load(String paramString, Resource paramResource)
    throws IOException;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\env\PropertySourceLoader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */