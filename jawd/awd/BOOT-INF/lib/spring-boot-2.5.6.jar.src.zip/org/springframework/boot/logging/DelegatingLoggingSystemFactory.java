/*    */ package org.springframework.boot.logging;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.function.Function;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class DelegatingLoggingSystemFactory
/*    */   implements LoggingSystemFactory
/*    */ {
/*    */   private final Function<ClassLoader, List<LoggingSystemFactory>> delegates;
/*    */   
/*    */   DelegatingLoggingSystemFactory(Function<ClassLoader, List<LoggingSystemFactory>> delegates)
/*    */   {
/* 36 */     this.delegates = delegates;
/*    */   }
/*    */   
/*    */   public LoggingSystem getLoggingSystem(ClassLoader classLoader)
/*    */   {
/* 41 */     List<LoggingSystemFactory> delegates = this.delegates != null ? (List)this.delegates.apply(classLoader) : null;
/* 42 */     if (delegates != null) {
/* 43 */       for (LoggingSystemFactory delegate : delegates) {
/* 44 */         LoggingSystem loggingSystem = delegate.getLoggingSystem(classLoader);
/* 45 */         if (loggingSystem != null) {
/* 46 */           return loggingSystem;
/*    */         }
/*    */       }
/*    */     }
/* 50 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\logging\DelegatingLoggingSystemFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */