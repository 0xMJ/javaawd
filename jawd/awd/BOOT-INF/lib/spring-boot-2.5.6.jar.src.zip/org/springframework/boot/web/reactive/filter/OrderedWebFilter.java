package org.springframework.boot.web.reactive.filter;

import org.springframework.core.Ordered;
import org.springframework.web.server.WebFilter;

public abstract interface OrderedWebFilter
  extends WebFilter, Ordered
{
  public static final int REQUEST_WRAPPER_FILTER_MAX_ORDER = 0;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\web\reactive\filter\OrderedWebFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */