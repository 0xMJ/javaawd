/*     */ package org.springframework.boot.diagnostics.analyzer;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.springframework.beans.factory.BeanCreationException;
/*     */ import org.springframework.beans.factory.BeanCurrentlyInCreationException;
/*     */ import org.springframework.beans.factory.InjectionPoint;
/*     */ import org.springframework.beans.factory.UnsatisfiedDependencyException;
/*     */ import org.springframework.boot.diagnostics.AbstractFailureAnalyzer;
/*     */ import org.springframework.boot.diagnostics.FailureAnalysis;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BeanCurrentlyInCreationFailureAnalyzer
/*     */   extends AbstractFailureAnalyzer<BeanCurrentlyInCreationException>
/*     */ {
/*     */   protected FailureAnalysis analyze(Throwable rootFailure, BeanCurrentlyInCreationException cause)
/*     */   {
/*  40 */     DependencyCycle dependencyCycle = findCycle(rootFailure);
/*  41 */     if (dependencyCycle == null) {
/*  42 */       return null;
/*     */     }
/*  44 */     return new FailureAnalysis(buildMessage(dependencyCycle), null, cause);
/*     */   }
/*     */   
/*     */   private DependencyCycle findCycle(Throwable rootFailure) {
/*  48 */     List<BeanInCycle> beansInCycle = new ArrayList();
/*  49 */     Throwable candidate = rootFailure;
/*  50 */     int cycleStart = -1;
/*  51 */     while (candidate != null) {
/*  52 */       BeanInCycle beanInCycle = BeanInCycle.get(candidate);
/*  53 */       if (beanInCycle != null) {
/*  54 */         int index = beansInCycle.indexOf(beanInCycle);
/*  55 */         if (index == -1) {
/*  56 */           beansInCycle.add(beanInCycle);
/*     */         }
/*  58 */         cycleStart = cycleStart != -1 ? cycleStart : index;
/*     */       }
/*  60 */       candidate = candidate.getCause();
/*     */     }
/*  62 */     if (cycleStart == -1) {
/*  63 */       return null;
/*     */     }
/*  65 */     return new DependencyCycle(beansInCycle, cycleStart, null);
/*     */   }
/*     */   
/*     */   private String buildMessage(DependencyCycle dependencyCycle) {
/*  69 */     StringBuilder message = new StringBuilder();
/*  70 */     message.append(
/*  71 */       String.format("The dependencies of some of the beans in the application context form a cycle:%n%n", new Object[0]));
/*  72 */     List<BeanInCycle> beansInCycle = dependencyCycle.getBeansInCycle();
/*  73 */     boolean singleBean = beansInCycle.size() == 1;
/*  74 */     int cycleStart = dependencyCycle.getCycleStart();
/*  75 */     for (int i = 0; i < beansInCycle.size(); i++) {
/*  76 */       BeanInCycle beanInCycle = (BeanInCycle)beansInCycle.get(i);
/*  77 */       if (i == cycleStart) {
/*  78 */         message.append(String.format(singleBean ? "┌──->──┐%n" : "┌─────┐%n", new Object[0]));
/*     */       }
/*  80 */       else if (i > 0) {
/*  81 */         String leftSide = i < cycleStart ? " " : "↑";
/*  82 */         message.append(String.format("%s     ↓%n", new Object[] { leftSide }));
/*     */       }
/*  84 */       String leftSide = i < cycleStart ? " " : "|";
/*  85 */       message.append(String.format("%s  %s%n", new Object[] { leftSide, beanInCycle }));
/*     */     }
/*  87 */     message.append(String.format(singleBean ? "└──<-──┘%n" : "└─────┘%n", new Object[0]));
/*  88 */     return message.toString();
/*     */   }
/*     */   
/*     */   private static final class DependencyCycle
/*     */   {
/*     */     private final List<BeanCurrentlyInCreationFailureAnalyzer.BeanInCycle> beansInCycle;
/*     */     private final int cycleStart;
/*     */     
/*     */     private DependencyCycle(List<BeanCurrentlyInCreationFailureAnalyzer.BeanInCycle> beansInCycle, int cycleStart)
/*     */     {
/*  98 */       this.beansInCycle = beansInCycle;
/*  99 */       this.cycleStart = cycleStart;
/*     */     }
/*     */     
/*     */     List<BeanCurrentlyInCreationFailureAnalyzer.BeanInCycle> getBeansInCycle() {
/* 103 */       return this.beansInCycle;
/*     */     }
/*     */     
/*     */     int getCycleStart() {
/* 107 */       return this.cycleStart;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static final class BeanInCycle
/*     */   {
/*     */     private final String name;
/*     */     private final String description;
/*     */     
/*     */     private BeanInCycle(BeanCreationException ex)
/*     */     {
/* 119 */       this.name = ex.getBeanName();
/* 120 */       this.description = determineDescription(ex);
/*     */     }
/*     */     
/*     */     private String determineDescription(BeanCreationException ex) {
/* 124 */       if (StringUtils.hasText(ex.getResourceDescription())) {
/* 125 */         return String.format(" defined in %s", new Object[] { ex.getResourceDescription() });
/*     */       }
/* 127 */       InjectionPoint failedInjectionPoint = findFailedInjectionPoint(ex);
/* 128 */       if ((failedInjectionPoint != null) && (failedInjectionPoint.getField() != null)) {
/* 129 */         return String.format(" (field %s)", new Object[] { failedInjectionPoint.getField() });
/*     */       }
/* 131 */       return "";
/*     */     }
/*     */     
/*     */     private InjectionPoint findFailedInjectionPoint(BeanCreationException ex) {
/* 135 */       if (!(ex instanceof UnsatisfiedDependencyException)) {
/* 136 */         return null;
/*     */       }
/* 138 */       return ((UnsatisfiedDependencyException)ex).getInjectionPoint();
/*     */     }
/*     */     
/*     */     public boolean equals(Object obj)
/*     */     {
/* 143 */       if (this == obj) {
/* 144 */         return true;
/*     */       }
/* 146 */       if ((obj == null) || (getClass() != obj.getClass())) {
/* 147 */         return false;
/*     */       }
/* 149 */       return this.name.equals(((BeanInCycle)obj).name);
/*     */     }
/*     */     
/*     */     public int hashCode()
/*     */     {
/* 154 */       return this.name.hashCode();
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/* 159 */       return this.name + this.description;
/*     */     }
/*     */     
/*     */     static BeanInCycle get(Throwable ex) {
/* 163 */       if ((ex instanceof BeanCreationException)) {
/* 164 */         return get((BeanCreationException)ex);
/*     */       }
/* 166 */       return null;
/*     */     }
/*     */     
/*     */     private static BeanInCycle get(BeanCreationException ex) {
/* 170 */       if (StringUtils.hasText(ex.getBeanName())) {
/* 171 */         return new BeanInCycle(ex);
/*     */       }
/* 173 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\diagnostics\analyzer\BeanCurrentlyInCreationFailureAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */