/*     */ package org.springframework.boot.web.error;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.EnumSet;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ErrorAttributeOptions
/*     */ {
/*     */   private final Set<Include> includes;
/*     */   
/*     */   private ErrorAttributeOptions(Set<Include> includes)
/*     */   {
/*  37 */     this.includes = includes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isIncluded(Include include)
/*     */   {
/*  47 */     return this.includes.contains(include);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Set<Include> getIncludes()
/*     */   {
/*  55 */     return this.includes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ErrorAttributeOptions including(Include... includes)
/*     */   {
/*  65 */     EnumSet<Include> updated = copyIncludes();
/*  66 */     updated.addAll(Arrays.asList(includes));
/*  67 */     return new ErrorAttributeOptions(Collections.unmodifiableSet(updated));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ErrorAttributeOptions excluding(Include... excludes)
/*     */   {
/*  77 */     EnumSet<Include> updated = copyIncludes();
/*  78 */     updated.removeAll(Arrays.asList(excludes));
/*  79 */     return new ErrorAttributeOptions(Collections.unmodifiableSet(updated));
/*     */   }
/*     */   
/*     */   private EnumSet<Include> copyIncludes() {
/*  83 */     return this.includes.isEmpty() ? EnumSet.noneOf(Include.class) : EnumSet.copyOf(this.includes);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ErrorAttributeOptions defaults()
/*     */   {
/*  91 */     return of(new Include[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ErrorAttributeOptions of(Include... includes)
/*     */   {
/* 101 */     return of(Arrays.asList(includes));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ErrorAttributeOptions of(Collection<Include> includes)
/*     */   {
/* 111 */     return new ErrorAttributeOptions(includes
/* 112 */       .isEmpty() ? Collections.emptySet() : Collections.unmodifiableSet(EnumSet.copyOf(includes)));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static enum Include
/*     */   {
/* 123 */     EXCEPTION, 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 128 */     STACK_TRACE, 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 133 */     MESSAGE, 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 138 */     BINDING_ERRORS;
/*     */     
/*     */     private Include() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\web\error\ErrorAttributeOptions.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */