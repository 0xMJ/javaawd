/*    */ package org.springframework.boot.availability;
/*    */ 
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.context.ApplicationEventPublisher;
/*    */ import org.springframework.context.PayloadApplicationEvent;
/*    */ import org.springframework.core.ResolvableType;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AvailabilityChangeEvent<S extends AvailabilityState>
/*    */   extends PayloadApplicationEvent<S>
/*    */ {
/*    */   public AvailabilityChangeEvent(Object source, S state)
/*    */   {
/* 45 */     super(source, state);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public S getState()
/*    */   {
/* 53 */     return (AvailabilityState)getPayload();
/*    */   }
/*    */   
/*    */   public ResolvableType getResolvableType()
/*    */   {
/* 58 */     return ResolvableType.forClassWithGenerics(getClass(), new Class[] { getStateType() });
/*    */   }
/*    */   
/*    */   private Class<?> getStateType() {
/* 62 */     S state = getState();
/* 63 */     if ((state instanceof Enum)) {
/* 64 */       return ((Enum)state).getDeclaringClass();
/*    */     }
/* 66 */     return state.getClass();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static <S extends AvailabilityState> void publish(ApplicationContext context, S state)
/*    */   {
/* 77 */     Assert.notNull(context, "Context must not be null");
/* 78 */     publish(context, context, state);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static <S extends AvailabilityState> void publish(ApplicationEventPublisher publisher, Object source, S state)
/*    */   {
/* 91 */     Assert.notNull(publisher, "Publisher must not be null");
/* 92 */     publisher.publishEvent(new AvailabilityChangeEvent(source, state));
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\availability\AvailabilityChangeEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */