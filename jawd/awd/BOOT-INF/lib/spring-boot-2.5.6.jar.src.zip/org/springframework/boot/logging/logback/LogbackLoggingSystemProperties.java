/*     */ package org.springframework.boot.logging.logback;
/*     */ 
/*     */ import ch.qos.logback.core.util.FileSize;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.function.BiConsumer;
/*     */ import org.springframework.boot.logging.LogFile;
/*     */ import org.springframework.boot.logging.LoggingSystemProperties;
/*     */ import org.springframework.core.convert.ConversionException;
/*     */ import org.springframework.core.convert.ConversionFailedException;
/*     */ import org.springframework.core.convert.ConverterNotFoundException;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.env.PropertyResolver;
/*     */ import org.springframework.util.unit.DataSize;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LogbackLoggingSystemProperties
/*     */   extends LoggingSystemProperties
/*     */ {
/*     */   public static final String ROLLINGPOLICY_FILE_NAME_PATTERN = "LOGBACK_ROLLINGPOLICY_FILE_NAME_PATTERN";
/*     */   public static final String ROLLINGPOLICY_CLEAN_HISTORY_ON_START = "LOGBACK_ROLLINGPOLICY_CLEAN_HISTORY_ON_START";
/*     */   public static final String ROLLINGPOLICY_MAX_FILE_SIZE = "LOGBACK_ROLLINGPOLICY_MAX_FILE_SIZE";
/*     */   public static final String ROLLINGPOLICY_TOTAL_SIZE_CAP = "LOGBACK_ROLLINGPOLICY_TOTAL_SIZE_CAP";
/*     */   public static final String ROLLINGPOLICY_MAX_HISTORY = "LOGBACK_ROLLINGPOLICY_MAX_HISTORY";
/*     */   
/*     */   public LogbackLoggingSystemProperties(Environment environment)
/*     */   {
/*  67 */     super(environment);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public LogbackLoggingSystemProperties(Environment environment, BiConsumer<String, String> setter)
/*     */   {
/*  77 */     super(environment, setter);
/*     */   }
/*     */   
/*     */   protected Charset getDefaultCharset()
/*     */   {
/*  82 */     return Charset.defaultCharset();
/*     */   }
/*     */   
/*     */   protected void apply(LogFile logFile, PropertyResolver resolver)
/*     */   {
/*  87 */     super.apply(logFile, resolver);
/*  88 */     applyRollingPolicy(resolver, "LOGBACK_ROLLINGPOLICY_FILE_NAME_PATTERN", "logging.logback.rollingpolicy.file-name-pattern", "logging.pattern.rolling-file-name");
/*     */     
/*  90 */     applyRollingPolicy(resolver, "LOGBACK_ROLLINGPOLICY_CLEAN_HISTORY_ON_START", "logging.logback.rollingpolicy.clean-history-on-start", "logging.file.clean-history-on-start");
/*     */     
/*  92 */     applyRollingPolicy(resolver, "LOGBACK_ROLLINGPOLICY_MAX_FILE_SIZE", "logging.logback.rollingpolicy.max-file-size", "logging.file.max-size", DataSize.class);
/*     */     
/*  94 */     applyRollingPolicy(resolver, "LOGBACK_ROLLINGPOLICY_TOTAL_SIZE_CAP", "logging.logback.rollingpolicy.total-size-cap", "logging.file.total-size-cap", DataSize.class);
/*     */     
/*  96 */     applyRollingPolicy(resolver, "LOGBACK_ROLLINGPOLICY_MAX_HISTORY", "logging.logback.rollingpolicy.max-history", "logging.file.max-history");
/*     */   }
/*     */   
/*     */ 
/*     */   private void applyRollingPolicy(PropertyResolver resolver, String systemPropertyName, String propertyName, String deprecatedPropertyName)
/*     */   {
/* 102 */     applyRollingPolicy(resolver, systemPropertyName, propertyName, deprecatedPropertyName, String.class);
/*     */   }
/*     */   
/*     */   private <T> void applyRollingPolicy(PropertyResolver resolver, String systemPropertyName, String propertyName, String deprecatedPropertyName, Class<T> type)
/*     */   {
/* 107 */     T value = getProperty(resolver, propertyName, type);
/* 108 */     if (value == null) {
/* 109 */       value = getProperty(resolver, deprecatedPropertyName, type);
/*     */     }
/* 111 */     if (value != null) {
/* 112 */       String stringValue = String.valueOf((value instanceof DataSize) ? Long.valueOf(((DataSize)value).toBytes()) : value);
/* 113 */       setSystemProperty(systemPropertyName, stringValue);
/*     */     }
/*     */   }
/*     */   
/*     */   private <T> T getProperty(PropertyResolver resolver, String key, Class<T> type)
/*     */   {
/*     */     try {
/* 120 */       return (T)resolver.getProperty(key, type);
/*     */     }
/*     */     catch (ConversionFailedException|ConverterNotFoundException ex) {
/* 123 */       if (type != DataSize.class) {
/* 124 */         throw ex;
/*     */       }
/* 126 */       String value = resolver.getProperty(key);
/* 127 */       return DataSize.ofBytes(FileSize.valueOf(value).getSize());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\logging\logback\LogbackLoggingSystemProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */