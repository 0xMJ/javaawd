/*     */ package org.springframework.boot.orm.jpa;
/*     */ 
/*     */ import java.net.URL;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.core.task.AsyncTaskExecutor;
/*     */ import org.springframework.orm.jpa.JpaVendorAdapter;
/*     */ import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
/*     */ import org.springframework.orm.jpa.persistenceunit.PersistenceUnitManager;
/*     */ import org.springframework.orm.jpa.persistenceunit.PersistenceUnitPostProcessor;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EntityManagerFactoryBuilder
/*     */ {
/*     */   private final JpaVendorAdapter jpaVendorAdapter;
/*     */   private final PersistenceUnitManager persistenceUnitManager;
/*     */   private final Map<String, Object> jpaProperties;
/*     */   private final URL persistenceUnitRootLocation;
/*     */   private AsyncTaskExecutor bootstrapExecutor;
/*     */   private PersistenceUnitPostProcessor[] persistenceUnitPostProcessors;
/*     */   
/*     */   public EntityManagerFactoryBuilder(JpaVendorAdapter jpaVendorAdapter, Map<String, ?> jpaProperties, PersistenceUnitManager persistenceUnitManager)
/*     */   {
/*  74 */     this(jpaVendorAdapter, jpaProperties, persistenceUnitManager, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EntityManagerFactoryBuilder(JpaVendorAdapter jpaVendorAdapter, Map<String, ?> jpaProperties, PersistenceUnitManager persistenceUnitManager, URL persistenceUnitRootLocation)
/*     */   {
/*  90 */     this.jpaVendorAdapter = jpaVendorAdapter;
/*  91 */     this.persistenceUnitManager = persistenceUnitManager;
/*  92 */     this.jpaProperties = new LinkedHashMap(jpaProperties);
/*  93 */     this.persistenceUnitRootLocation = persistenceUnitRootLocation;
/*     */   }
/*     */   
/*     */   public Builder dataSource(DataSource dataSource) {
/*  97 */     return new Builder(dataSource, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBootstrapExecutor(AsyncTaskExecutor bootstrapExecutor)
/*     */   {
/* 107 */     this.bootstrapExecutor = bootstrapExecutor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPersistenceUnitPostProcessors(PersistenceUnitPostProcessor... persistenceUnitPostProcessors)
/*     */   {
/* 118 */     this.persistenceUnitPostProcessors = persistenceUnitPostProcessors;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final class Builder
/*     */   {
/*     */     private DataSource dataSource;
/*     */     
/*     */ 
/*     */     private String[] packagesToScan;
/*     */     
/*     */     private String persistenceUnit;
/*     */     
/* 132 */     private Map<String, Object> properties = new HashMap();
/*     */     
/*     */     private String[] mappingResources;
/*     */     private boolean jta;
/*     */     
/*     */     private Builder(DataSource dataSource)
/*     */     {
/* 139 */       this.dataSource = dataSource;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public Builder packages(String... packagesToScan)
/*     */     {
/* 148 */       this.packagesToScan = packagesToScan;
/* 149 */       return this;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public Builder packages(Class<?>... basePackageClasses)
/*     */     {
/* 158 */       Set<String> packages = new HashSet();
/* 159 */       for (Class<?> type : basePackageClasses) {
/* 160 */         packages.add(ClassUtils.getPackageName(type));
/*     */       }
/* 162 */       this.packagesToScan = StringUtils.toStringArray(packages);
/* 163 */       return this;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public Builder persistenceUnit(String persistenceUnit)
/*     */     {
/* 174 */       this.persistenceUnit = persistenceUnit;
/* 175 */       return this;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public Builder properties(Map<String, ?> properties)
/*     */     {
/* 185 */       this.properties.putAll(properties);
/* 186 */       return this;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public Builder mappingResources(String... mappingResources)
/*     */     {
/* 200 */       this.mappingResources = mappingResources;
/* 201 */       return this;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public Builder jta(boolean jta)
/*     */     {
/* 215 */       this.jta = jta;
/* 216 */       return this;
/*     */     }
/*     */     
/*     */     public LocalContainerEntityManagerFactoryBean build() {
/* 220 */       LocalContainerEntityManagerFactoryBean entityManagerFactoryBean = new LocalContainerEntityManagerFactoryBean();
/* 221 */       if (EntityManagerFactoryBuilder.this.persistenceUnitManager != null)
/*     */       {
/* 223 */         entityManagerFactoryBean.setPersistenceUnitManager(EntityManagerFactoryBuilder.this.persistenceUnitManager);
/*     */       }
/* 225 */       if (this.persistenceUnit != null) {
/* 226 */         entityManagerFactoryBean.setPersistenceUnitName(this.persistenceUnit);
/*     */       }
/* 228 */       entityManagerFactoryBean.setJpaVendorAdapter(EntityManagerFactoryBuilder.this.jpaVendorAdapter);
/*     */       
/* 230 */       if (this.jta) {
/* 231 */         entityManagerFactoryBean.setJtaDataSource(this.dataSource);
/*     */       }
/*     */       else {
/* 234 */         entityManagerFactoryBean.setDataSource(this.dataSource);
/*     */       }
/* 236 */       entityManagerFactoryBean.setPackagesToScan(this.packagesToScan);
/* 237 */       entityManagerFactoryBean.getJpaPropertyMap().putAll(EntityManagerFactoryBuilder.this.jpaProperties);
/* 238 */       entityManagerFactoryBean.getJpaPropertyMap().putAll(this.properties);
/* 239 */       if (!ObjectUtils.isEmpty(this.mappingResources)) {
/* 240 */         entityManagerFactoryBean.setMappingResources(this.mappingResources);
/*     */       }
/* 242 */       URL rootLocation = EntityManagerFactoryBuilder.this.persistenceUnitRootLocation;
/* 243 */       if (rootLocation != null) {
/* 244 */         entityManagerFactoryBean.setPersistenceUnitRootLocation(rootLocation.toString());
/*     */       }
/* 246 */       if (EntityManagerFactoryBuilder.this.bootstrapExecutor != null) {
/* 247 */         entityManagerFactoryBean.setBootstrapExecutor(EntityManagerFactoryBuilder.this.bootstrapExecutor);
/*     */       }
/* 249 */       if (EntityManagerFactoryBuilder.this.persistenceUnitPostProcessors != null) {
/* 250 */         entityManagerFactoryBean.setPersistenceUnitPostProcessors(
/* 251 */           EntityManagerFactoryBuilder.this.persistenceUnitPostProcessors);
/*     */       }
/* 253 */       return entityManagerFactoryBean;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\orm\jpa\EntityManagerFactoryBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */