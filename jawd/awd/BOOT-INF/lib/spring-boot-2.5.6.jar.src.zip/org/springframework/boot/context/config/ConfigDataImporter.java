/*     */ package org.springframework.boot.context.config;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.boot.logging.DeferredLogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ConfigDataImporter
/*     */ {
/*     */   private final Log logger;
/*     */   private final ConfigDataLocationResolvers resolvers;
/*     */   private final ConfigDataLoaders loaders;
/*     */   private final ConfigDataNotFoundAction notFoundAction;
/*  50 */   private final Set<ConfigDataResource> loaded = new HashSet();
/*     */   
/*  52 */   private final Set<ConfigDataLocation> loadedLocations = new HashSet();
/*     */   
/*  54 */   private final Set<ConfigDataLocation> optionalLocations = new HashSet();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   ConfigDataImporter(DeferredLogFactory logFactory, ConfigDataNotFoundAction notFoundAction, ConfigDataLocationResolvers resolvers, ConfigDataLoaders loaders)
/*     */   {
/*  65 */     this.logger = logFactory.getLog(getClass());
/*  66 */     this.resolvers = resolvers;
/*  67 */     this.loaders = loaders;
/*  68 */     this.notFoundAction = notFoundAction;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Map<ConfigDataResolutionResult, ConfigData> resolveAndLoad(ConfigDataActivationContext activationContext, ConfigDataLocationResolverContext locationResolverContext, ConfigDataLoaderContext loaderContext, List<ConfigDataLocation> locations)
/*     */   {
/*     */     try
/*     */     {
/*  84 */       Profiles profiles = activationContext != null ? activationContext.getProfiles() : null;
/*  85 */       List<ConfigDataResolutionResult> resolved = resolve(locationResolverContext, profiles, locations);
/*  86 */       return load(loaderContext, resolved);
/*     */     }
/*     */     catch (IOException ex) {
/*  89 */       throw new IllegalStateException("IO error on loading imports from " + locations, ex);
/*     */     }
/*     */   }
/*     */   
/*     */   private List<ConfigDataResolutionResult> resolve(ConfigDataLocationResolverContext locationResolverContext, Profiles profiles, List<ConfigDataLocation> locations)
/*     */   {
/*  95 */     List<ConfigDataResolutionResult> resolved = new ArrayList(locations.size());
/*  96 */     for (ConfigDataLocation location : locations) {
/*  97 */       resolved.addAll(resolve(locationResolverContext, profiles, location));
/*     */     }
/*  99 */     return Collections.unmodifiableList(resolved);
/*     */   }
/*     */   
/*     */   private List<ConfigDataResolutionResult> resolve(ConfigDataLocationResolverContext locationResolverContext, Profiles profiles, ConfigDataLocation location)
/*     */   {
/*     */     try {
/* 105 */       return this.resolvers.resolve(locationResolverContext, location, profiles);
/*     */     }
/*     */     catch (ConfigDataNotFoundException ex) {
/* 108 */       handle(ex, location, null); }
/* 109 */     return Collections.emptyList();
/*     */   }
/*     */   
/*     */   private Map<ConfigDataResolutionResult, ConfigData> load(ConfigDataLoaderContext loaderContext, List<ConfigDataResolutionResult> candidates)
/*     */     throws IOException
/*     */   {
/* 115 */     Map<ConfigDataResolutionResult, ConfigData> result = new LinkedHashMap();
/* 116 */     for (int i = candidates.size() - 1; i >= 0; i--) {
/* 117 */       ConfigDataResolutionResult candidate = (ConfigDataResolutionResult)candidates.get(i);
/* 118 */       ConfigDataLocation location = candidate.getLocation();
/* 119 */       ConfigDataResource resource = candidate.getResource();
/* 120 */       if (resource.isOptional()) {
/* 121 */         this.optionalLocations.add(location);
/*     */       }
/* 123 */       if (this.loaded.contains(resource)) {
/* 124 */         this.loadedLocations.add(location);
/*     */       } else {
/*     */         try
/*     */         {
/* 128 */           ConfigData loaded = this.loaders.load(loaderContext, resource);
/* 129 */           if (loaded != null) {
/* 130 */             this.loaded.add(resource);
/* 131 */             this.loadedLocations.add(location);
/* 132 */             result.put(candidate, loaded);
/*     */           }
/*     */         }
/*     */         catch (ConfigDataNotFoundException ex) {
/* 136 */           handle(ex, location, resource);
/*     */         }
/*     */       }
/*     */     }
/* 140 */     return Collections.unmodifiableMap(result);
/*     */   }
/*     */   
/*     */   private void handle(ConfigDataNotFoundException ex, ConfigDataLocation location, ConfigDataResource resource) {
/* 144 */     if ((ex instanceof ConfigDataResourceNotFoundException)) {
/* 145 */       ex = ((ConfigDataResourceNotFoundException)ex).withLocation(location);
/*     */     }
/* 147 */     getNotFoundAction(location, resource).handle(this.logger, ex);
/*     */   }
/*     */   
/*     */   private ConfigDataNotFoundAction getNotFoundAction(ConfigDataLocation location, ConfigDataResource resource) {
/* 151 */     if ((location.isOptional()) || ((resource != null) && (resource.isOptional()))) {
/* 152 */       return ConfigDataNotFoundAction.IGNORE;
/*     */     }
/* 154 */     return this.notFoundAction;
/*     */   }
/*     */   
/*     */   Set<ConfigDataLocation> getLoadedLocations() {
/* 158 */     return this.loadedLocations;
/*     */   }
/*     */   
/*     */   Set<ConfigDataLocation> getOptionalLocations() {
/* 162 */     return this.optionalLocations;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\context\config\ConfigDataImporter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */