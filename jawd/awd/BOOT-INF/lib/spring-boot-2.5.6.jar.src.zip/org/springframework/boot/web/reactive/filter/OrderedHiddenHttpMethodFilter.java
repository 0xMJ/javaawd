/*    */ package org.springframework.boot.web.reactive.filter;
/*    */ 
/*    */ import org.springframework.web.filter.reactive.HiddenHttpMethodFilter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OrderedHiddenHttpMethodFilter
/*    */   extends HiddenHttpMethodFilter
/*    */   implements OrderedWebFilter
/*    */ {
/*    */   public static final int DEFAULT_ORDER = -10000;
/* 35 */   private int order = 55536;
/*    */   
/*    */   public int getOrder()
/*    */   {
/* 39 */     return this.order;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setOrder(int order)
/*    */   {
/* 47 */     this.order = order;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\web\reactive\filter\OrderedHiddenHttpMethodFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */