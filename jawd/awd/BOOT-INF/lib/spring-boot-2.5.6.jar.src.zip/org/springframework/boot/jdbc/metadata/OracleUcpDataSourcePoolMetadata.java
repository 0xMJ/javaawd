/*    */ package org.springframework.boot.jdbc.metadata;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ import oracle.ucp.jdbc.PoolDataSource;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OracleUcpDataSourcePoolMetadata
/*    */   extends AbstractDataSourcePoolMetadata<PoolDataSource>
/*    */ {
/*    */   public OracleUcpDataSourcePoolMetadata(PoolDataSource dataSource)
/*    */   {
/* 36 */     super(dataSource);
/*    */   }
/*    */   
/*    */   public Integer getActive()
/*    */   {
/*    */     try {
/* 42 */       return Integer.valueOf(((PoolDataSource)getDataSource()).getBorrowedConnectionsCount());
/*    */     }
/*    */     catch (SQLException ex) {}
/* 45 */     return null;
/*    */   }
/*    */   
/*    */   public Integer getIdle()
/*    */   {
/*    */     try
/*    */     {
/* 52 */       return Integer.valueOf(((PoolDataSource)getDataSource()).getAvailableConnectionsCount());
/*    */     }
/*    */     catch (SQLException ex) {}
/* 55 */     return null;
/*    */   }
/*    */   
/*    */ 
/*    */   public Integer getMax()
/*    */   {
/* 61 */     return Integer.valueOf(((PoolDataSource)getDataSource()).getMaxPoolSize());
/*    */   }
/*    */   
/*    */   public Integer getMin()
/*    */   {
/* 66 */     return Integer.valueOf(((PoolDataSource)getDataSource()).getMinPoolSize());
/*    */   }
/*    */   
/*    */   public String getValidationQuery()
/*    */   {
/* 71 */     return ((PoolDataSource)getDataSource()).getSQLForValidateConnection();
/*    */   }
/*    */   
/*    */   public Boolean getDefaultAutoCommit()
/*    */   {
/* 76 */     String autoCommit = ((PoolDataSource)getDataSource()).getConnectionProperty("autoCommit");
/* 77 */     return StringUtils.hasText(autoCommit) ? Boolean.valueOf(autoCommit) : null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\jdbc\metadata\OracleUcpDataSourcePoolMetadata.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */