/*     */ package org.springframework.boot.system;
/*     */ 
/*     */ import java.io.Console;
/*     */ import java.lang.invoke.MethodHandles.Lookup;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import java.util.stream.Stream;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum JavaVersion
/*     */ {
/*  41 */   EIGHT("1.8", Optional.class, "empty"), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  46 */   NINE("9", Optional.class, "stream"), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  51 */   TEN("10", Optional.class, "orElseThrow"), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  56 */   ELEVEN("11", String.class, "strip"), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  61 */   TWELVE("12", String.class, "describeConstable"), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  66 */   THIRTEEN("13", String.class, "stripIndent"), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  71 */   FOURTEEN("14", MethodHandles.Lookup.class, "hasFullPrivilegeAccess"), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  76 */   FIFTEEN("15", CharSequence.class, "isEmpty"), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  81 */   SIXTEEN("16", Stream.class, "toList"), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  86 */   SEVENTEEN("17", Console.class, "charset");
/*     */   
/*     */   private final String name;
/*     */   private final boolean available;
/*     */   
/*     */   private JavaVersion(String name, Class<?> clazz, String methodName)
/*     */   {
/*  93 */     this.name = name;
/*  94 */     this.available = ClassUtils.hasMethod(clazz, methodName, new Class[0]);
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/*  99 */     return this.name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static JavaVersion getJavaVersion()
/*     */   {
/* 107 */     List<JavaVersion> candidates = Arrays.asList(values());
/* 108 */     Collections.reverse(candidates);
/* 109 */     for (JavaVersion candidate : candidates) {
/* 110 */       if (candidate.available) {
/* 111 */         return candidate;
/*     */       }
/*     */     }
/* 114 */     return EIGHT;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isEqualOrNewerThan(JavaVersion version)
/*     */   {
/* 123 */     return compareTo(version) >= 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isOlderThan(JavaVersion version)
/*     */   {
/* 132 */     return compareTo(version) < 0;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\system\JavaVersion.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */