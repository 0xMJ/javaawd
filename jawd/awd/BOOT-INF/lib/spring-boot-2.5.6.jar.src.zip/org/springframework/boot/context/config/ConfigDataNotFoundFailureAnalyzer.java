/*    */ package org.springframework.boot.context.config;
/*    */ 
/*    */ import org.springframework.boot.diagnostics.AbstractFailureAnalyzer;
/*    */ import org.springframework.boot.diagnostics.FailureAnalysis;
/*    */ import org.springframework.boot.origin.Origin;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ConfigDataNotFoundFailureAnalyzer
/*    */   extends AbstractFailureAnalyzer<ConfigDataNotFoundException>
/*    */ {
/*    */   protected FailureAnalysis analyze(Throwable rootFailure, ConfigDataNotFoundException cause)
/*    */   {
/* 34 */     ConfigDataLocation location = getLocation(cause);
/* 35 */     Origin origin = Origin.from(location);
/* 36 */     String message = String.format("Config data %s does not exist", new Object[] { cause.getReferenceDescription() });
/* 37 */     StringBuilder action = new StringBuilder("Check that the value ");
/* 38 */     if (location != null) {
/* 39 */       action.append(String.format("'%s' ", new Object[] { location }));
/*    */     }
/* 41 */     if (origin != null) {
/* 42 */       action.append(String.format("at %s ", new Object[] { origin }));
/*    */     }
/* 44 */     action.append("is correct");
/* 45 */     if ((location != null) && (!location.isOptional())) {
/* 46 */       action.append(String.format(", or prefix it with '%s'", new Object[] { "optional:" }));
/*    */     }
/* 48 */     return new FailureAnalysis(message, action.toString(), cause);
/*    */   }
/*    */   
/*    */   private ConfigDataLocation getLocation(ConfigDataNotFoundException cause) {
/* 52 */     if ((cause instanceof ConfigDataLocationNotFoundException)) {
/* 53 */       return ((ConfigDataLocationNotFoundException)cause).getLocation();
/*    */     }
/* 55 */     if ((cause instanceof ConfigDataResourceNotFoundException)) {
/* 56 */       return ((ConfigDataResourceNotFoundException)cause).getLocation();
/*    */     }
/* 58 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\context\config\ConfigDataNotFoundFailureAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */