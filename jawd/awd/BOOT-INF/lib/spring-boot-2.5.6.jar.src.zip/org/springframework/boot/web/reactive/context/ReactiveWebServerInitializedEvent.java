/*    */ package org.springframework.boot.web.reactive.context;
/*    */ 
/*    */ import org.springframework.boot.web.context.WebServerInitializedEvent;
/*    */ import org.springframework.boot.web.server.WebServer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReactiveWebServerInitializedEvent
/*    */   extends WebServerInitializedEvent
/*    */ {
/*    */   private final ReactiveWebServerApplicationContext applicationContext;
/*    */   
/*    */   public ReactiveWebServerInitializedEvent(WebServer webServer, ReactiveWebServerApplicationContext applicationContext)
/*    */   {
/* 36 */     super(webServer);
/* 37 */     this.applicationContext = applicationContext;
/*    */   }
/*    */   
/*    */   public ReactiveWebServerApplicationContext getApplicationContext()
/*    */   {
/* 42 */     return this.applicationContext;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\web\reactive\context\ReactiveWebServerInitializedEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */