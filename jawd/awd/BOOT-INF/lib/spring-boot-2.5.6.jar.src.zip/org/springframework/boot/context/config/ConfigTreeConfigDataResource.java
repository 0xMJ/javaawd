/*    */ package org.springframework.boot.context.config;
/*    */ 
/*    */ import java.nio.file.Path;
/*    */ import java.nio.file.Paths;
/*    */ import java.util.Objects;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConfigTreeConfigDataResource
/*    */   extends ConfigDataResource
/*    */ {
/*    */   private final Path path;
/*    */   
/*    */   ConfigTreeConfigDataResource(String path)
/*    */   {
/* 39 */     Assert.notNull(path, "Path must not be null");
/* 40 */     this.path = Paths.get(path, new String[0]).toAbsolutePath();
/*    */   }
/*    */   
/*    */   ConfigTreeConfigDataResource(Path path) {
/* 44 */     Assert.notNull(path, "Path must not be null");
/* 45 */     this.path = path.toAbsolutePath();
/*    */   }
/*    */   
/*    */   Path getPath() {
/* 49 */     return this.path;
/*    */   }
/*    */   
/*    */   public boolean equals(Object obj)
/*    */   {
/* 54 */     if (this == obj) {
/* 55 */       return true;
/*    */     }
/* 57 */     if ((obj == null) || (getClass() != obj.getClass())) {
/* 58 */       return false;
/*    */     }
/* 60 */     ConfigTreeConfigDataResource other = (ConfigTreeConfigDataResource)obj;
/* 61 */     return Objects.equals(this.path, other.path);
/*    */   }
/*    */   
/*    */   public int hashCode()
/*    */   {
/* 66 */     return this.path.hashCode();
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 71 */     return "config tree [" + this.path + "]";
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\context\config\ConfigTreeConfigDataResource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */