package org.springframework.boot.web.embedded.tomcat;

import java.io.File;
import java.nio.charset.Charset;
import org.apache.catalina.Valve;
import org.springframework.boot.web.server.ConfigurableWebServerFactory;

public abstract interface ConfigurableTomcatWebServerFactory
  extends ConfigurableWebServerFactory
{
  public abstract void setBaseDirectory(File paramFile);
  
  public abstract void setBackgroundProcessorDelay(int paramInt);
  
  public abstract void addEngineValves(Valve... paramVarArgs);
  
  public abstract void addConnectorCustomizers(TomcatConnectorCustomizer... paramVarArgs);
  
  public abstract void addContextCustomizers(TomcatContextCustomizer... paramVarArgs);
  
  public abstract void addProtocolHandlerCustomizers(TomcatProtocolHandlerCustomizer<?>... paramVarArgs);
  
  public abstract void setUriEncoding(Charset paramCharset);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\web\embedded\tomcat\ConfigurableTomcatWebServerFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */