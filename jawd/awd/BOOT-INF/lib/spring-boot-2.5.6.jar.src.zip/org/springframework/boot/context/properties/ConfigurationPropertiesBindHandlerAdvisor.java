package org.springframework.boot.context.properties;

import org.springframework.boot.context.properties.bind.BindHandler;

@FunctionalInterface
public abstract interface ConfigurationPropertiesBindHandlerAdvisor
{
  public abstract BindHandler apply(BindHandler paramBindHandler);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\context\properties\ConfigurationPropertiesBindHandlerAdvisor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */