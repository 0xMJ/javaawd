package org.springframework.boot.context.config;

import org.apache.commons.logging.Log;
import org.springframework.core.log.LogMessage;

public enum ConfigDataNotFoundAction
{
  FAIL,  IGNORE;
  
  private ConfigDataNotFoundAction() {}
  
  abstract void handle(Log paramLog, ConfigDataNotFoundException paramConfigDataNotFoundException);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\context\config\ConfigDataNotFoundAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */