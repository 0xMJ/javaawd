/*    */ package org.springframework.boot.origin;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @FunctionalInterface
/*    */ public abstract interface OriginLookup<K>
/*    */ {
/*    */   public abstract Origin getOrigin(K paramK);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean isImmutable()
/*    */   {
/* 45 */     return false;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getPrefix()
/*    */   {
/* 58 */     return null;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static <K> Origin getOrigin(Object source, K key)
/*    */   {
/* 72 */     if (!(source instanceof OriginLookup)) {
/* 73 */       return null;
/*    */     }
/*    */     try {
/* 76 */       return ((OriginLookup)source).getOrigin(key);
/*    */     }
/*    */     catch (Throwable ex) {}
/* 79 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\origin\OriginLookup.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */