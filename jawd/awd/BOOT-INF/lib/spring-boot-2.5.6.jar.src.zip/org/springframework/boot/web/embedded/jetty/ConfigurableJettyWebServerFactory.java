package org.springframework.boot.web.embedded.jetty;

import org.eclipse.jetty.util.thread.ThreadPool;
import org.springframework.boot.web.server.ConfigurableWebServerFactory;

public abstract interface ConfigurableJettyWebServerFactory
  extends ConfigurableWebServerFactory
{
  public abstract void setAcceptors(int paramInt);
  
  public abstract void setThreadPool(ThreadPool paramThreadPool);
  
  public abstract void setSelectors(int paramInt);
  
  public abstract void setUseForwardHeaders(boolean paramBoolean);
  
  public abstract void addServerCustomizers(JettyServerCustomizer... paramVarArgs);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\web\embedded\jetty\ConfigurableJettyWebServerFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */