/*    */ package org.springframework.boot.availability;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract interface ApplicationAvailability
/*    */ {
/*    */   public LivenessState getLivenessState()
/*    */   {
/* 40 */     return (LivenessState)getState(LivenessState.class, LivenessState.BROKEN);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public ReadinessState getReadinessState()
/*    */   {
/* 48 */     return (ReadinessState)getState(ReadinessState.class, ReadinessState.REFUSING_TRAFFIC);
/*    */   }
/*    */   
/*    */   public abstract <S extends AvailabilityState> S getState(Class<S> paramClass, S paramS);
/*    */   
/*    */   public abstract <S extends AvailabilityState> S getState(Class<S> paramClass);
/*    */   
/*    */   public abstract <S extends AvailabilityState> AvailabilityChangeEvent<S> getLastChangeEvent(Class<S> paramClass);
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\availability\ApplicationAvailability.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */