/*    */ package org.springframework.boot.context.logging;
/*    */ 
/*    */ import java.net.URLClassLoader;
/*    */ import java.util.Arrays;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.boot.context.event.ApplicationEnvironmentPreparedEvent;
/*    */ import org.springframework.boot.context.event.ApplicationFailedEvent;
/*    */ import org.springframework.context.ApplicationEvent;
/*    */ import org.springframework.context.event.GenericApplicationListener;
/*    */ import org.springframework.core.ResolvableType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public final class ClasspathLoggingApplicationListener
/*    */   implements GenericApplicationListener
/*    */ {
/*    */   private static final int ORDER = -2147483627;
/* 50 */   private static final Log logger = LogFactory.getLog(ClasspathLoggingApplicationListener.class);
/*    */   
/*    */   public void onApplicationEvent(ApplicationEvent event)
/*    */   {
/* 54 */     if (logger.isDebugEnabled()) {
/* 55 */       if ((event instanceof ApplicationEnvironmentPreparedEvent)) {
/* 56 */         logger.debug("Application started with classpath: " + getClasspath());
/*    */       }
/* 58 */       else if ((event instanceof ApplicationFailedEvent)) {
/* 59 */         logger.debug("Application failed to start with classpath: " + getClasspath());
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public int getOrder()
/*    */   {
/* 66 */     return -2147483627;
/*    */   }
/*    */   
/*    */   public boolean supportsEventType(ResolvableType resolvableType)
/*    */   {
/* 71 */     Class<?> type = resolvableType.getRawClass();
/* 72 */     if (type == null) {
/* 73 */       return false;
/*    */     }
/* 75 */     return (ApplicationEnvironmentPreparedEvent.class.isAssignableFrom(type)) || 
/* 76 */       (ApplicationFailedEvent.class.isAssignableFrom(type));
/*    */   }
/*    */   
/*    */   private String getClasspath() {
/* 80 */     ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
/* 81 */     if ((classLoader instanceof URLClassLoader)) {
/* 82 */       return Arrays.toString(((URLClassLoader)classLoader).getURLs());
/*    */     }
/* 84 */     return "unknown";
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\context\logging\ClasspathLoggingApplicationListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */