/*     */ package org.springframework.boot.web.embedded.undertow;
/*     */ 
/*     */ import io.undertow.attribute.RequestHeaderAttribute;
/*     */ import io.undertow.predicate.Predicate;
/*     */ import io.undertow.predicate.Predicates;
/*     */ import io.undertow.server.HttpHandler;
/*     */ import io.undertow.server.HttpServerExchange;
/*     */ import io.undertow.server.handlers.encoding.ContentEncodingRepository;
/*     */ import io.undertow.server.handlers.encoding.EncodingHandler;
/*     */ import io.undertow.server.handlers.encoding.GzipEncodingProvider;
/*     */ import io.undertow.util.HeaderMap;
/*     */ import io.undertow.util.Headers;
/*     */ import io.undertow.util.HttpString;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.springframework.boot.web.server.Compression;
/*     */ import org.springframework.util.InvalidMimeTypeException;
/*     */ import org.springframework.util.MimeType;
/*     */ import org.springframework.util.MimeTypeUtils;
/*     */ import org.springframework.util.unit.DataSize;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class CompressionHttpHandlerFactory
/*     */   implements HttpHandlerFactory
/*     */ {
/*     */   private final Compression compression;
/*     */   
/*     */   CompressionHttpHandlerFactory(Compression compression)
/*     */   {
/*  50 */     this.compression = compression;
/*     */   }
/*     */   
/*     */   public HttpHandler getHandler(HttpHandler next)
/*     */   {
/*  55 */     if (!this.compression.getEnabled()) {
/*  56 */       return next;
/*     */     }
/*  58 */     ContentEncodingRepository repository = new ContentEncodingRepository();
/*  59 */     repository.addEncodingHandler("gzip", new GzipEncodingProvider(), 50, 
/*  60 */       Predicates.and(getCompressionPredicates(this.compression)));
/*  61 */     return new EncodingHandler(repository).setNext(next);
/*     */   }
/*     */   
/*     */   private static Predicate[] getCompressionPredicates(Compression compression) {
/*  65 */     List<Predicate> predicates = new ArrayList();
/*  66 */     predicates.add(new MaxSizePredicate((int)compression.getMinResponseSize().toBytes()));
/*  67 */     predicates.add(new CompressibleMimeTypePredicate(compression.getMimeTypes()));
/*  68 */     if (compression.getExcludedUserAgents() != null) {
/*  69 */       for (String agent : compression.getExcludedUserAgents()) {
/*  70 */         RequestHeaderAttribute agentHeader = new RequestHeaderAttribute(new HttpString("User-Agent"));
/*  71 */         predicates.add(Predicates.not(Predicates.regex(agentHeader, agent)));
/*     */       }
/*     */     }
/*  74 */     return (Predicate[])predicates.toArray(new Predicate[0]);
/*     */   }
/*     */   
/*     */ 
/*     */   private static class CompressibleMimeTypePredicate
/*     */     implements Predicate
/*     */   {
/*     */     private final List<MimeType> mimeTypes;
/*     */     
/*     */     CompressibleMimeTypePredicate(String[] mimeTypes)
/*     */     {
/*  85 */       this.mimeTypes = new ArrayList(mimeTypes.length);
/*  86 */       for (String mimeTypeString : mimeTypes) {
/*  87 */         this.mimeTypes.add(MimeTypeUtils.parseMimeType(mimeTypeString));
/*     */       }
/*     */     }
/*     */     
/*     */     public boolean resolve(HttpServerExchange value)
/*     */     {
/*  93 */       String contentType = value.getResponseHeaders().getFirst("Content-Type");
/*  94 */       if (contentType != null) {
/*     */         try {
/*  96 */           parsed = MimeTypeUtils.parseMimeType(contentType);
/*  97 */           for (MimeType mimeType : this.mimeTypes) {
/*  98 */             if (mimeType.isCompatibleWith(parsed)) {
/*  99 */               return true;
/*     */             }
/*     */           }
/*     */         } catch (InvalidMimeTypeException ex) {
/*     */           MimeType parsed;
/* 104 */           return false;
/*     */         }
/*     */       }
/* 107 */       return false;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static class MaxSizePredicate
/*     */     implements Predicate
/*     */   {
/*     */     private final Predicate maxContentSize;
/*     */     
/*     */ 
/*     */     MaxSizePredicate(int size)
/*     */     {
/* 121 */       this.maxContentSize = Predicates.requestLargerThan(size);
/*     */     }
/*     */     
/*     */     public boolean resolve(HttpServerExchange value)
/*     */     {
/* 126 */       if (value.getResponseHeaders().contains(Headers.CONTENT_LENGTH)) {
/* 127 */         return this.maxContentSize.resolve(value);
/*     */       }
/* 129 */       return true;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\web\embedded\undertow\CompressionHttpHandlerFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */