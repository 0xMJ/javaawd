/*    */ package org.springframework.boot.context;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Collection;
/*    */ import java.util.Map;
/*    */ import org.springframework.beans.BeansException;
/*    */ import org.springframework.beans.factory.BeanFactory;
/*    */ import org.springframework.beans.factory.BeanFactoryAware;
/*    */ import org.springframework.beans.factory.ListableBeanFactory;
/*    */ import org.springframework.core.type.classreading.MetadataReader;
/*    */ import org.springframework.core.type.classreading.MetadataReaderFactory;
/*    */ import org.springframework.core.type.filter.TypeFilter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TypeExcludeFilter
/*    */   implements TypeFilter, BeanFactoryAware
/*    */ {
/*    */   private BeanFactory beanFactory;
/*    */   private Collection<TypeExcludeFilter> delegates;
/*    */   
/*    */   public void setBeanFactory(BeanFactory beanFactory)
/*    */     throws BeansException
/*    */   {
/* 58 */     this.beanFactory = beanFactory;
/*    */   }
/*    */   
/*    */   public boolean match(MetadataReader metadataReader, MetadataReaderFactory metadataReaderFactory)
/*    */     throws IOException
/*    */   {
/* 64 */     if (((this.beanFactory instanceof ListableBeanFactory)) && (getClass() == TypeExcludeFilter.class)) {
/* 65 */       for (TypeExcludeFilter delegate : getDelegates()) {
/* 66 */         if (delegate.match(metadataReader, metadataReaderFactory)) {
/* 67 */           return true;
/*    */         }
/*    */       }
/*    */     }
/* 71 */     return false;
/*    */   }
/*    */   
/*    */   private Collection<TypeExcludeFilter> getDelegates() {
/* 75 */     Collection<TypeExcludeFilter> delegates = this.delegates;
/* 76 */     if (delegates == null) {
/* 77 */       delegates = ((ListableBeanFactory)this.beanFactory).getBeansOfType(TypeExcludeFilter.class).values();
/* 78 */       this.delegates = delegates;
/*    */     }
/* 80 */     return delegates;
/*    */   }
/*    */   
/*    */   public boolean equals(Object obj)
/*    */   {
/* 85 */     throw new IllegalStateException("TypeExcludeFilter " + getClass() + " has not implemented equals");
/*    */   }
/*    */   
/*    */   public int hashCode()
/*    */   {
/* 90 */     throw new IllegalStateException("TypeExcludeFilter " + getClass() + " has not implemented hashCode");
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\context\TypeExcludeFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */