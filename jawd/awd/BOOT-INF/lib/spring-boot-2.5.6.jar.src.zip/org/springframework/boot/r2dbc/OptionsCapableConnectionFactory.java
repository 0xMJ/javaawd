/*    */ package org.springframework.boot.r2dbc;
/*    */ 
/*    */ import io.r2dbc.spi.Connection;
/*    */ import io.r2dbc.spi.ConnectionFactory;
/*    */ import io.r2dbc.spi.ConnectionFactoryMetadata;
/*    */ import io.r2dbc.spi.ConnectionFactoryOptions;
/*    */ import io.r2dbc.spi.Wrapped;
/*    */ import org.reactivestreams.Publisher;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OptionsCapableConnectionFactory
/*    */   implements Wrapped<ConnectionFactory>, ConnectionFactory
/*    */ {
/*    */   private final ConnectionFactoryOptions options;
/*    */   private final ConnectionFactory delegate;
/*    */   
/*    */   public OptionsCapableConnectionFactory(ConnectionFactoryOptions options, ConnectionFactory delegate)
/*    */   {
/* 47 */     this.options = options;
/* 48 */     this.delegate = delegate;
/*    */   }
/*    */   
/*    */   public ConnectionFactoryOptions getOptions() {
/* 52 */     return this.options;
/*    */   }
/*    */   
/*    */   public Publisher<? extends Connection> create()
/*    */   {
/* 57 */     return this.delegate.create();
/*    */   }
/*    */   
/*    */   public ConnectionFactoryMetadata getMetadata()
/*    */   {
/* 62 */     return this.delegate.getMetadata();
/*    */   }
/*    */   
/*    */   public ConnectionFactory unwrap()
/*    */   {
/* 67 */     return this.delegate;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static OptionsCapableConnectionFactory unwrapFrom(ConnectionFactory connectionFactory)
/*    */   {
/* 81 */     if ((connectionFactory instanceof OptionsCapableConnectionFactory)) {
/* 82 */       return (OptionsCapableConnectionFactory)connectionFactory;
/*    */     }
/* 84 */     if ((connectionFactory instanceof Wrapped)) {
/* 85 */       Object unwrapped = ((Wrapped)connectionFactory).unwrap();
/* 86 */       if ((unwrapped instanceof ConnectionFactory)) {
/* 87 */         return unwrapFrom((ConnectionFactory)unwrapped);
/*    */       }
/*    */     }
/* 90 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\r2dbc\OptionsCapableConnectionFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */