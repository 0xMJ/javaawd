/*    */ package org.springframework.boot.web.server;
/*    */ 
/*    */ import org.springframework.util.unit.DataSize;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Compression
/*    */ {
/* 31 */   private boolean enabled = false;
/*    */   
/* 33 */   private String[] mimeTypes = { "text/html", "text/xml", "text/plain", "text/css", "text/javascript", "application/javascript", "application/json", "application/xml" };
/*    */   
/*    */ 
/* 36 */   private String[] excludedUserAgents = null;
/*    */   
/* 38 */   private DataSize minResponseSize = DataSize.ofKilobytes(2L);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean getEnabled()
/*    */   {
/* 45 */     return this.enabled;
/*    */   }
/*    */   
/*    */   public void setEnabled(boolean enabled) {
/* 49 */     this.enabled = enabled;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String[] getMimeTypes()
/*    */   {
/* 57 */     return this.mimeTypes;
/*    */   }
/*    */   
/*    */   public void setMimeTypes(String[] mimeTypes) {
/* 61 */     this.mimeTypes = mimeTypes;
/*    */   }
/*    */   
/*    */   public String[] getExcludedUserAgents() {
/* 65 */     return this.excludedUserAgents;
/*    */   }
/*    */   
/*    */   public void setExcludedUserAgents(String[] excludedUserAgents) {
/* 69 */     this.excludedUserAgents = excludedUserAgents;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public DataSize getMinResponseSize()
/*    */   {
/* 78 */     return this.minResponseSize;
/*    */   }
/*    */   
/*    */   public void setMinResponseSize(DataSize minSize) {
/* 82 */     this.minResponseSize = minSize;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\web\server\Compression.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */