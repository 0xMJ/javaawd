/*    */ package org.springframework.boot.json;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.concurrent.Callable;
/*    */ import java.util.function.Function;
/*    */ import org.springframework.util.ReflectionUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractJsonParser
/*    */   implements JsonParser
/*    */ {
/*    */   protected final Map<String, Object> parseMap(String json, Function<String, Map<String, Object>> parser)
/*    */   {
/* 36 */     return (Map)trimParse(json, "{", parser);
/*    */   }
/*    */   
/*    */   protected final List<Object> parseList(String json, Function<String, List<Object>> parser) {
/* 40 */     return (List)trimParse(json, "[", parser);
/*    */   }
/*    */   
/*    */   protected final <T> T trimParse(String json, String prefix, Function<String, T> parser) {
/* 44 */     String trimmed = json != null ? json.trim() : "";
/* 45 */     if (trimmed.startsWith(prefix)) {
/* 46 */       return (T)parser.apply(trimmed);
/*    */     }
/* 48 */     throw new JsonParseException();
/*    */   }
/*    */   
/*    */   protected final <T> T tryParse(Callable<T> parser, Class<? extends Exception> check) {
/*    */     try {
/* 53 */       return (T)parser.call();
/*    */     }
/*    */     catch (Exception ex) {
/* 56 */       if (check.isAssignableFrom(ex.getClass())) {
/* 57 */         throw new JsonParseException(ex);
/*    */       }
/* 59 */       ReflectionUtils.rethrowRuntimeException(ex);
/* 60 */       throw new IllegalStateException(ex);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\json\AbstractJsonParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */