/*     */ package org.springframework.boot.info;
/*     */ 
/*     */ import java.time.Instant;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import org.springframework.core.env.PropertiesPropertySource;
/*     */ import org.springframework.core.env.PropertySource;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InfoProperties
/*     */   implements Iterable<Entry>
/*     */ {
/*     */   private final Properties entries;
/*     */   
/*     */   public InfoProperties(Properties entries)
/*     */   {
/*  44 */     Assert.notNull(entries, "Entries must not be null");
/*  45 */     this.entries = copy(entries);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String get(String key)
/*     */   {
/*  54 */     return this.entries.getProperty(key);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Instant getInstant(String key)
/*     */   {
/*  64 */     String s = get(key);
/*  65 */     if (s != null) {
/*     */       try {
/*  67 */         return Instant.ofEpochMilli(Long.parseLong(s));
/*     */       }
/*     */       catch (NumberFormatException localNumberFormatException) {}
/*     */     }
/*     */     
/*     */ 
/*  73 */     return null;
/*     */   }
/*     */   
/*     */   public Iterator<Entry> iterator()
/*     */   {
/*  78 */     return new PropertiesIterator(this.entries, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public PropertySource<?> toPropertySource()
/*     */   {
/*  86 */     return new PropertiesPropertySource(getClass().getSimpleName(), copy(this.entries));
/*     */   }
/*     */   
/*     */   private Properties copy(Properties properties) {
/*  90 */     Properties copy = new Properties();
/*  91 */     copy.putAll(properties);
/*  92 */     return copy;
/*     */   }
/*     */   
/*     */   private static final class PropertiesIterator implements Iterator<InfoProperties.Entry>
/*     */   {
/*     */     private final Iterator<Map.Entry<Object, Object>> iterator;
/*     */     
/*     */     private PropertiesIterator(Properties properties) {
/* 100 */       this.iterator = properties.entrySet().iterator();
/*     */     }
/*     */     
/*     */     public boolean hasNext()
/*     */     {
/* 105 */       return this.iterator.hasNext();
/*     */     }
/*     */     
/*     */     public InfoProperties.Entry next()
/*     */     {
/* 110 */       Map.Entry<Object, Object> entry = (Map.Entry)this.iterator.next();
/* 111 */       return new InfoProperties.Entry((String)entry.getKey(), (String)entry.getValue(), null);
/*     */     }
/*     */     
/*     */     public void remove()
/*     */     {
/* 116 */       throw new UnsupportedOperationException("InfoProperties are immutable.");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static final class Entry
/*     */   {
/*     */     private final String key;
/*     */     
/*     */     private final String value;
/*     */     
/*     */ 
/*     */     private Entry(String key, String value)
/*     */     {
/* 131 */       this.key = key;
/* 132 */       this.value = value;
/*     */     }
/*     */     
/*     */     public String getKey() {
/* 136 */       return this.key;
/*     */     }
/*     */     
/*     */     public String getValue() {
/* 140 */       return this.value;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\info\InfoProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */