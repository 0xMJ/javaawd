/*    */ package org.springframework.boot.diagnostics.analyzer;
/*    */ 
/*    */ import javax.validation.ValidationException;
/*    */ import org.springframework.boot.diagnostics.AbstractFailureAnalyzer;
/*    */ import org.springframework.boot.diagnostics.FailureAnalysis;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ValidationExceptionFailureAnalyzer
/*    */   extends AbstractFailureAnalyzer<ValidationException>
/*    */ {
/*    */   private static final String JAVAX_MISSING_IMPLEMENTATION_MESSAGE = "Unable to create a Configuration, because no Bean Validation provider could be found";
/*    */   private static final String JAKARTA_MISSING_IMPLEMENTATION_MESSAGE = "Unable to create a Configuration, because no Jakarta Bean Validation provider could be found";
/*    */   
/*    */   protected FailureAnalysis analyze(Throwable rootFailure, ValidationException cause)
/*    */   {
/* 41 */     if ((cause.getMessage().startsWith("Unable to create a Configuration, because no Bean Validation provider could be found")) || 
/* 42 */       (cause.getMessage().startsWith("Unable to create a Configuration, because no Jakarta Bean Validation provider could be found"))) {
/* 43 */       return new FailureAnalysis("The Bean Validation API is on the classpath but no implementation could be found", "Add an implementation, such as Hibernate Validator, to the classpath", cause);
/*    */     }
/*    */     
/*    */ 
/* 47 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\diagnostics\analyzer\ValidationExceptionFailureAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */