/*    */ package org.springframework.boot.convert;
/*    */ 
/*    */ import java.net.InetAddress;
/*    */ import java.net.UnknownHostException;
/*    */ import java.text.ParseException;
/*    */ import java.util.Locale;
/*    */ import org.springframework.format.Formatter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class InetAddressFormatter
/*    */   implements Formatter<InetAddress>
/*    */ {
/*    */   public String print(InetAddress object, Locale locale)
/*    */   {
/* 35 */     return object.getHostAddress();
/*    */   }
/*    */   
/*    */   public InetAddress parse(String text, Locale locale) throws ParseException
/*    */   {
/*    */     try {
/* 41 */       return InetAddress.getByName(text);
/*    */     }
/*    */     catch (UnknownHostException ex) {
/* 44 */       throw new IllegalStateException("Unknown host " + text, ex);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\convert\InetAddressFormatter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */