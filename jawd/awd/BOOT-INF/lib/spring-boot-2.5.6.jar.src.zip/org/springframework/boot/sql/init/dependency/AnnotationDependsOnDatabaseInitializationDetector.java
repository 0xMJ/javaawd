/*    */ package org.springframework.boot.sql.init.dependency;
/*    */ 
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class AnnotationDependsOnDatabaseInitializationDetector
/*    */   implements DependsOnDatabaseInitializationDetector
/*    */ {
/*    */   public Set<String> detect(ConfigurableListableBeanFactory beanFactory)
/*    */   {
/* 34 */     Set<String> dependentBeans = new HashSet();
/* 35 */     for (String beanName : beanFactory.getBeanDefinitionNames()) {
/* 36 */       if (beanFactory.findAnnotationOnBean(beanName, DependsOnDatabaseInitialization.class) != null) {
/* 37 */         dependentBeans.add(beanName);
/*    */       }
/*    */     }
/* 40 */     return dependentBeans;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\sql\init\dependency\AnnotationDependsOnDatabaseInitializationDetector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */