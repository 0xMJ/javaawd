/*     */ package org.springframework.boot.sql.init;
/*     */ 
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DatabaseInitializationSettings
/*     */ {
/*     */   private List<String> schemaLocations;
/*     */   private List<String> dataLocations;
/*  34 */   private boolean continueOnError = false;
/*     */   
/*  36 */   private String separator = ";";
/*     */   
/*     */   private Charset encoding;
/*     */   
/*  40 */   private DatabaseInitializationMode mode = DatabaseInitializationMode.EMBEDDED;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<String> getSchemaLocations()
/*     */   {
/*  47 */     return this.schemaLocations;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSchemaLocations(List<String> schemaLocations)
/*     */   {
/*  57 */     this.schemaLocations = schemaLocations;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<String> getDataLocations()
/*     */   {
/*  65 */     return this.dataLocations;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDataLocations(List<String> dataLocations)
/*     */   {
/*  75 */     this.dataLocations = dataLocations;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isContinueOnError()
/*     */   {
/*  84 */     return this.continueOnError;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setContinueOnError(boolean continueOnError)
/*     */   {
/*  93 */     this.continueOnError = continueOnError;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getSeparator()
/*     */   {
/* 101 */     return this.separator;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSeparator(String separator)
/*     */   {
/* 109 */     this.separator = separator;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Charset getEncoding()
/*     */   {
/* 117 */     return this.encoding;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEncoding(Charset encoding)
/*     */   {
/* 125 */     this.encoding = encoding;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DatabaseInitializationMode getMode()
/*     */   {
/* 135 */     return this.mode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMode(DatabaseInitializationMode mode)
/*     */   {
/* 145 */     this.mode = mode;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\sql\init\DatabaseInitializationSettings.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */