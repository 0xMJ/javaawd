/*     */ package org.springframework.boot.context.properties.bind;
/*     */ 
/*     */ import java.beans.PropertyEditor;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.function.Consumer;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.PropertyEditorRegistry;
/*     */ import org.springframework.beans.SimpleTypeConverter;
/*     */ import org.springframework.beans.propertyeditors.FileEditor;
/*     */ import org.springframework.boot.convert.ApplicationConversionService;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.convert.ConversionException;
/*     */ import org.springframework.core.convert.ConversionFailedException;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.core.convert.ConverterNotFoundException;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.core.convert.converter.ConditionalGenericConverter;
/*     */ import org.springframework.core.convert.converter.GenericConverter.ConvertiblePair;
/*     */ import org.springframework.core.convert.support.GenericConversionService;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class BindConverter
/*     */ {
/*     */   private static BindConverter sharedInstance;
/*     */   private final List<ConversionService> delegates;
/*     */   
/*     */   private BindConverter(List<ConversionService> conversionServices, Consumer<PropertyEditorRegistry> propertyEditorInitializer)
/*     */   {
/*  60 */     List<ConversionService> delegates = new ArrayList();
/*  61 */     delegates.add(new TypeConverterConversionService(propertyEditorInitializer));
/*  62 */     boolean hasApplication = false;
/*  63 */     if (!CollectionUtils.isEmpty(conversionServices)) {
/*  64 */       for (ConversionService conversionService : conversionServices) {
/*  65 */         delegates.add(conversionService);
/*  66 */         hasApplication = (hasApplication) || ((conversionService instanceof ApplicationConversionService));
/*     */       }
/*     */     }
/*  69 */     if (!hasApplication) {
/*  70 */       delegates.add(ApplicationConversionService.getSharedInstance());
/*     */     }
/*  72 */     this.delegates = Collections.unmodifiableList(delegates);
/*     */   }
/*     */   
/*     */   boolean canConvert(Object source, ResolvableType targetType, Annotation... targetAnnotations) {
/*  76 */     return canConvert(TypeDescriptor.forObject(source), new ResolvableTypeDescriptor(targetType, targetAnnotations));
/*     */   }
/*     */   
/*     */   private boolean canConvert(TypeDescriptor sourceType, TypeDescriptor targetType)
/*     */   {
/*  81 */     for (ConversionService service : this.delegates) {
/*  82 */       if (service.canConvert(sourceType, targetType)) {
/*  83 */         return true;
/*     */       }
/*     */     }
/*  86 */     return false;
/*     */   }
/*     */   
/*     */   <T> T convert(Object source, Bindable<T> target) {
/*  90 */     return (T)convert(source, target.getType(), target.getAnnotations());
/*     */   }
/*     */   
/*     */   <T> T convert(Object source, ResolvableType targetType, Annotation... targetAnnotations)
/*     */   {
/*  95 */     if (source == null) {
/*  96 */       return null;
/*     */     }
/*  98 */     return (T)convert(source, TypeDescriptor.forObject(source), new ResolvableTypeDescriptor(targetType, targetAnnotations));
/*     */   }
/*     */   
/*     */   private Object convert(Object source, TypeDescriptor sourceType, TypeDescriptor targetType)
/*     */   {
/* 103 */     ConversionException failure = null;
/* 104 */     for (ConversionService delegate : this.delegates) {
/*     */       try {
/* 106 */         if (delegate.canConvert(sourceType, targetType)) {
/* 107 */           return delegate.convert(source, sourceType, targetType);
/*     */         }
/*     */       }
/*     */       catch (ConversionException ex) {
/* 111 */         if ((failure == null) && ((ex instanceof ConversionFailedException))) {
/* 112 */           failure = ex;
/*     */         }
/*     */       }
/*     */     }
/* 116 */     throw (failure != null ? failure : new ConverterNotFoundException(sourceType, targetType));
/*     */   }
/*     */   
/*     */ 
/*     */   static BindConverter get(List<ConversionService> conversionServices, Consumer<PropertyEditorRegistry> propertyEditorInitializer)
/*     */   {
/* 122 */     boolean sharedApplicationConversionService = (conversionServices == null) || ((conversionServices.size() == 1) && (conversionServices.get(0) == ApplicationConversionService.getSharedInstance()));
/* 123 */     if ((propertyEditorInitializer == null) && (sharedApplicationConversionService)) {
/* 124 */       return getSharedInstance();
/*     */     }
/* 126 */     return new BindConverter(conversionServices, propertyEditorInitializer);
/*     */   }
/*     */   
/*     */   private static BindConverter getSharedInstance() {
/* 130 */     if (sharedInstance == null) {
/* 131 */       sharedInstance = new BindConverter(null, null);
/*     */     }
/* 133 */     return sharedInstance;
/*     */   }
/*     */   
/*     */ 
/*     */   private static class ResolvableTypeDescriptor
/*     */     extends TypeDescriptor
/*     */   {
/*     */     ResolvableTypeDescriptor(ResolvableType resolvableType, Annotation[] annotations)
/*     */     {
/* 142 */       super(null, annotations);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class TypeConverterConversionService
/*     */     extends GenericConversionService
/*     */   {
/*     */     TypeConverterConversionService(Consumer<PropertyEditorRegistry> initializer)
/*     */     {
/* 155 */       addConverter(new BindConverter.TypeConverterConverter(initializer));
/* 156 */       ApplicationConversionService.addDelimitedStringConverters(this);
/*     */     }
/*     */     
/*     */ 
/*     */     public boolean canConvert(TypeDescriptor sourceType, TypeDescriptor targetType)
/*     */     {
/* 162 */       if ((targetType.isArray()) && (targetType.getElementTypeDescriptor().isPrimitive())) {
/* 163 */         return false;
/*     */       }
/* 165 */       return super.canConvert(sourceType, targetType);
/*     */     }
/*     */   }
/*     */   
/*     */   private static class TypeConverterConverter implements ConditionalGenericConverter
/*     */   {
/*     */     private static final Set<Class<?>> EXCLUDED_EDITORS;
/*     */     private final Consumer<PropertyEditorRegistry> initializer;
/*     */     private final SimpleTypeConverter matchesOnlyTypeConverter;
/*     */     
/*     */     static
/*     */     {
/* 177 */       Set<Class<?>> excluded = new HashSet();
/* 178 */       excluded.add(FileEditor.class);
/* 179 */       EXCLUDED_EDITORS = Collections.unmodifiableSet(excluded);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     TypeConverterConverter(Consumer<PropertyEditorRegistry> initializer)
/*     */     {
/* 189 */       this.initializer = initializer;
/* 190 */       this.matchesOnlyTypeConverter = createTypeConverter();
/*     */     }
/*     */     
/*     */     public Set<GenericConverter.ConvertiblePair> getConvertibleTypes()
/*     */     {
/* 195 */       return Collections.singleton(new GenericConverter.ConvertiblePair(String.class, Object.class));
/*     */     }
/*     */     
/*     */     public boolean matches(TypeDescriptor sourceType, TypeDescriptor targetType)
/*     */     {
/* 200 */       Class<?> type = targetType.getType();
/* 201 */       if ((type == null) || (type == Object.class) || (Collection.class.isAssignableFrom(type)) || 
/* 202 */         (Map.class.isAssignableFrom(type))) {
/* 203 */         return false;
/*     */       }
/* 205 */       PropertyEditor editor = this.matchesOnlyTypeConverter.getDefaultEditor(type);
/* 206 */       if (editor == null) {
/* 207 */         editor = this.matchesOnlyTypeConverter.findCustomEditor(type, null);
/*     */       }
/* 209 */       if ((editor == null) && (String.class != type)) {
/* 210 */         editor = BeanUtils.findEditorByConvention(type);
/*     */       }
/* 212 */       return (editor != null) && (!EXCLUDED_EDITORS.contains(editor.getClass()));
/*     */     }
/*     */     
/*     */     public Object convert(Object source, TypeDescriptor sourceType, TypeDescriptor targetType)
/*     */     {
/* 217 */       return createTypeConverter().convertIfNecessary(source, targetType.getType());
/*     */     }
/*     */     
/*     */     private SimpleTypeConverter createTypeConverter() {
/* 221 */       SimpleTypeConverter typeConverter = new SimpleTypeConverter();
/* 222 */       if (this.initializer != null) {
/* 223 */         this.initializer.accept(typeConverter);
/*     */       }
/* 225 */       return typeConverter;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\context\properties\bind\BindConverter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */