/*    */ package org.springframework.boot.orm.jpa;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.Collections;
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ import javax.persistence.EntityManagerFactory;
/*    */ import org.springframework.boot.sql.init.dependency.AbstractBeansOfTypeDependsOnDatabaseInitializationDetector;
/*    */ import org.springframework.core.env.Environment;
/*    */ import org.springframework.orm.jpa.AbstractEntityManagerFactoryBean;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class JpaDependsOnDatabaseInitializationDetector
/*    */   extends AbstractBeansOfTypeDependsOnDatabaseInitializationDetector
/*    */ {
/*    */   private final Environment environment;
/*    */   
/*    */   JpaDependsOnDatabaseInitializationDetector(Environment environment)
/*    */   {
/* 41 */     this.environment = environment;
/*    */   }
/*    */   
/*    */   protected Set<Class<?>> getDependsOnDatabaseInitializationBeanTypes()
/*    */   {
/* 46 */     boolean postpone = ((Boolean)this.environment.getProperty("spring.jpa.defer-datasource-initialization", Boolean.TYPE, 
/* 47 */       Boolean.valueOf(false))).booleanValue();
/* 48 */     return postpone ? Collections.emptySet() : new HashSet(
/* 49 */       Arrays.asList(new Class[] { EntityManagerFactory.class, AbstractEntityManagerFactoryBean.class }));
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\orm\jpa\JpaDependsOnDatabaseInitializationDetector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */