/*    */ package org.springframework.boot.origin;
/*    */ 
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.ObjectUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SystemEnvironmentOrigin
/*    */   implements Origin
/*    */ {
/*    */   private final String property;
/*    */   
/*    */   public SystemEnvironmentOrigin(String property)
/*    */   {
/* 34 */     Assert.notNull(property, "Property name must not be null");
/* 35 */     Assert.hasText(property, "Property name must not be empty");
/* 36 */     this.property = property;
/*    */   }
/*    */   
/*    */   public String getProperty() {
/* 40 */     return this.property;
/*    */   }
/*    */   
/*    */   public boolean equals(Object obj)
/*    */   {
/* 45 */     if (this == obj) {
/* 46 */       return true;
/*    */     }
/* 48 */     if ((obj == null) || (getClass() != obj.getClass())) {
/* 49 */       return false;
/*    */     }
/* 51 */     SystemEnvironmentOrigin other = (SystemEnvironmentOrigin)obj;
/* 52 */     return ObjectUtils.nullSafeEquals(this.property, other.property);
/*    */   }
/*    */   
/*    */   public int hashCode()
/*    */   {
/* 57 */     return ObjectUtils.nullSafeHashCode(this.property);
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 62 */     return "System Environment Property \"" + this.property + "\"";
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\origin\SystemEnvironmentOrigin.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */