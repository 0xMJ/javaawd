/*    */ package org.springframework.boot.context.properties.source;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract interface CachingConfigurationPropertySource
/*    */ {
/*    */   public abstract ConfigurationPropertyCaching getCaching();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static ConfigurationPropertyCaching find(ConfigurationPropertySource source)
/*    */   {
/* 40 */     if ((source instanceof CachingConfigurationPropertySource)) {
/* 41 */       return ((CachingConfigurationPropertySource)source).getCaching();
/*    */     }
/* 43 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\context\properties\source\CachingConfigurationPropertySource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */