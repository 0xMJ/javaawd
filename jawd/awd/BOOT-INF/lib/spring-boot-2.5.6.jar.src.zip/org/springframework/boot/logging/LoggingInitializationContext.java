/*    */ package org.springframework.boot.logging;
/*    */ 
/*    */ import org.springframework.core.env.ConfigurableEnvironment;
/*    */ import org.springframework.core.env.Environment;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LoggingInitializationContext
/*    */ {
/*    */   private final ConfigurableEnvironment environment;
/*    */   
/*    */   public LoggingInitializationContext(ConfigurableEnvironment environment)
/*    */   {
/* 37 */     this.environment = environment;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public Environment getEnvironment()
/*    */   {
/* 45 */     return this.environment;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\logging\LoggingInitializationContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */