package org.springframework.boot.web.embedded.undertow;

import io.undertow.Undertow.Builder;

@FunctionalInterface
public abstract interface UndertowBuilderCustomizer
{
  public abstract void customize(Undertow.Builder paramBuilder);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-boot-2.5.6.jar!\org\springframework\boot\web\embedded\undertow\UndertowBuilderCustomizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */