/*    */ package javax.el;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.Objects;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LambdaExpression
/*    */ {
/*    */   private final List<String> formalParameters;
/*    */   private final ValueExpression expression;
/* 28 */   private final Map<String, Object> nestedArguments = new HashMap();
/* 29 */   private ELContext context = null;
/*    */   
/*    */   public LambdaExpression(List<String> formalParameters, ValueExpression expression)
/*    */   {
/* 33 */     this.formalParameters = formalParameters;
/* 34 */     this.expression = expression;
/*    */   }
/*    */   
/*    */   public void setELContext(ELContext context)
/*    */   {
/* 39 */     this.context = context;
/*    */   }
/*    */   
/*    */ 
/*    */   public Object invoke(ELContext context, Object... args)
/*    */     throws ELException
/*    */   {
/* 46 */     Objects.requireNonNull(context);
/*    */     
/* 48 */     int formalParamCount = 0;
/* 49 */     if (this.formalParameters != null) {
/* 50 */       formalParamCount = this.formalParameters.size();
/*    */     }
/*    */     
/* 53 */     int argCount = 0;
/* 54 */     if (args != null) {
/* 55 */       argCount = args.length;
/*    */     }
/*    */     
/* 58 */     if (formalParamCount > argCount) {
/* 59 */       throw new ELException(Util.message(context, "lambdaExpression.tooFewArgs", new Object[] {
/*    */       
/* 61 */         Integer.valueOf(argCount), 
/* 62 */         Integer.valueOf(formalParamCount) }));
/*    */     }
/*    */     
/*    */ 
/*    */ 
/*    */ 
/* 68 */     Map<String, Object> lambdaArguments = new HashMap(this.nestedArguments);
/* 69 */     for (int i = 0; i < formalParamCount; i++) {
/* 70 */       lambdaArguments.put(this.formalParameters.get(i), args[i]);
/*    */     }
/*    */     
/* 73 */     context.enterLambdaScope(lambdaArguments);
/*    */     try
/*    */     {
/* 76 */       Object result = this.expression.getValue(context);
/*    */       
/*    */ 
/* 79 */       if ((result instanceof LambdaExpression)) {
/* 80 */         ((LambdaExpression)result).nestedArguments.putAll(lambdaArguments);
/*    */       }
/*    */       
/* 83 */       return result;
/*    */     } finally {
/* 85 */       context.exitLambdaScope();
/*    */     }
/*    */   }
/*    */   
/*    */   public Object invoke(Object... args) {
/* 90 */     return invoke(this.context, args);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-el-9.0.54.jar!\javax\el\LambdaExpression.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */