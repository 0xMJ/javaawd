/*    */ package javax.el;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ValueReference
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private final Object base;
/*    */   private final Object property;
/*    */   
/*    */   public ValueReference(Object base, Object property)
/*    */   {
/* 32 */     this.base = base;
/* 33 */     this.property = property;
/*    */   }
/*    */   
/*    */   public Object getBase() {
/* 37 */     return this.base;
/*    */   }
/*    */   
/*    */   public Object getProperty() {
/* 41 */     return this.property;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-el-9.0.54.jar!\javax\el\ValueReference.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */