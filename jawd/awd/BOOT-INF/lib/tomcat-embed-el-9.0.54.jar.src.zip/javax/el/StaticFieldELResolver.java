/*     */ package javax.el;
/*     */ 
/*     */ import java.beans.FeatureDescriptor;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Iterator;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StaticFieldELResolver
/*     */   extends ELResolver
/*     */ {
/*     */   public Object getValue(ELContext context, Object base, Object property)
/*     */   {
/*  35 */     Objects.requireNonNull(context);
/*     */     
/*  37 */     if (((base instanceof ELClass)) && ((property instanceof String))) {
/*  38 */       context.setPropertyResolved(base, property);
/*     */       
/*  40 */       Class<?> clazz = ((ELClass)base).getKlass();
/*  41 */       String name = (String)property;
/*  42 */       Exception exception = null;
/*     */       try {
/*  44 */         Field field = clazz.getField(name);
/*  45 */         int modifiers = field.getModifiers();
/*  46 */         JreCompat jreCompat = JreCompat.getInstance();
/*  47 */         if ((Modifier.isStatic(modifiers)) && 
/*  48 */           (Modifier.isPublic(modifiers)) && 
/*  49 */           (jreCompat.canAccess(null, field))) {
/*  50 */           return field.get(null);
/*     */         }
/*     */       }
/*     */       catch (IllegalArgumentException|IllegalAccessException|NoSuchFieldException|SecurityException e) {
/*  54 */         exception = e;
/*     */       }
/*  56 */       String msg = Util.message(context, "staticFieldELResolver.notFound", new Object[] { name, clazz
/*  57 */         .getName() });
/*  58 */       if (exception == null) {
/*  59 */         throw new PropertyNotFoundException(msg);
/*     */       }
/*  61 */       throw new PropertyNotFoundException(msg, exception);
/*     */     }
/*     */     
/*  64 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setValue(ELContext context, Object base, Object property, Object value)
/*     */   {
/*  71 */     Objects.requireNonNull(context);
/*     */     
/*  73 */     if (((base instanceof ELClass)) && ((property instanceof String))) {
/*  74 */       Class<?> clazz = ((ELClass)base).getKlass();
/*  75 */       String name = (String)property;
/*     */       
/*  77 */       throw new PropertyNotWritableException(Util.message(context, "staticFieldELResolver.notWriteable", new Object[] { name, clazz
/*     */       
/*  79 */         .getName() }));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object invoke(ELContext context, Object base, Object method, Class<?>[] paramTypes, Object[] params)
/*     */   {
/*  87 */     Objects.requireNonNull(context);
/*     */     
/*  89 */     if (((base instanceof ELClass)) && ((method instanceof String))) {
/*  90 */       context.setPropertyResolved(base, method);
/*     */       
/*  92 */       Class<?> clazz = ((ELClass)base).getKlass();
/*  93 */       String methodName = (String)method;
/*     */       
/*  95 */       if ("<init>".equals(methodName))
/*     */       {
/*  97 */         Constructor<?> match = Util.findConstructor(clazz, paramTypes, params);
/*     */         
/*  99 */         Object[] parameters = Util.buildParameters(match
/* 100 */           .getParameterTypes(), match.isVarArgs(), params);
/*     */         
/* 102 */         Object result = null;
/*     */         try
/*     */         {
/* 105 */           result = match.newInstance(parameters);
/*     */         } catch (InvocationTargetException e) {
/* 107 */           Throwable cause = e.getCause();
/* 108 */           Util.handleThrowable(cause);
/* 109 */           throw new ELException(cause);
/*     */         } catch (ReflectiveOperationException e) {
/* 111 */           throw new ELException(e);
/*     */         }
/* 113 */         return result;
/*     */       }
/*     */       
/*     */ 
/* 117 */       Method match = Util.findMethod(clazz, null, methodName, paramTypes, params);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 122 */       if ((match == null) || (!Modifier.isStatic(match.getModifiers()))) {
/* 123 */         throw new MethodNotFoundException(Util.message(context, "staticFieldELResolver.methodNotFound", new Object[] { methodName, clazz
/*     */         
/* 125 */           .getName() }));
/*     */       }
/*     */       
/* 128 */       Object[] parameters = Util.buildParameters(match
/* 129 */         .getParameterTypes(), match.isVarArgs(), params);
/*     */       
/* 131 */       Object result = null;
/*     */       try {
/* 133 */         result = match.invoke(null, parameters);
/*     */       } catch (IllegalArgumentException|IllegalAccessException e) {
/* 135 */         throw new ELException(e);
/*     */       } catch (InvocationTargetException e) {
/* 137 */         Throwable cause = e.getCause();
/* 138 */         Util.handleThrowable(cause);
/* 139 */         throw new ELException(cause);
/*     */       }
/* 141 */       return result;
/*     */     }
/*     */     
/* 144 */     return null;
/*     */   }
/*     */   
/*     */   public Class<?> getType(ELContext context, Object base, Object property)
/*     */   {
/* 149 */     Objects.requireNonNull(context);
/*     */     
/* 151 */     if (((base instanceof ELClass)) && ((property instanceof String))) {
/* 152 */       context.setPropertyResolved(base, property);
/*     */       
/* 154 */       Class<?> clazz = ((ELClass)base).getKlass();
/* 155 */       String name = (String)property;
/* 156 */       Exception exception = null;
/*     */       try {
/* 158 */         Field field = clazz.getField(name);
/* 159 */         int modifiers = field.getModifiers();
/* 160 */         JreCompat jreCompat = JreCompat.getInstance();
/* 161 */         if ((Modifier.isStatic(modifiers)) && 
/* 162 */           (Modifier.isPublic(modifiers)) && 
/* 163 */           (jreCompat.canAccess(null, field))) {
/* 164 */           return field.getType();
/*     */         }
/*     */       }
/*     */       catch (IllegalArgumentException|NoSuchFieldException|SecurityException e) {
/* 168 */         exception = e;
/*     */       }
/* 170 */       String msg = Util.message(context, "staticFieldELResolver.notFound", new Object[] { name, clazz
/* 171 */         .getName() });
/* 172 */       if (exception == null) {
/* 173 */         throw new PropertyNotFoundException(msg);
/*     */       }
/* 175 */       throw new PropertyNotFoundException(msg, exception);
/*     */     }
/*     */     
/* 178 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isReadOnly(ELContext context, Object base, Object property)
/*     */   {
/* 184 */     Objects.requireNonNull(context);
/*     */     
/* 186 */     if (((base instanceof ELClass)) && ((property instanceof String))) {
/* 187 */       context.setPropertyResolved(base, property);
/*     */     }
/* 189 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Iterator<FeatureDescriptor> getFeatureDescriptors(ELContext context, Object base)
/*     */   {
/* 199 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Class<?> getCommonPropertyType(ELContext context, Object base)
/*     */   {
/* 207 */     return String.class;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-el-9.0.54.jar!\javax\el\StaticFieldELResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */