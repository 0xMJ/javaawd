/*     */ package javax.el;
/*     */ 
/*     */ import java.beans.FeatureDescriptor;
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.Iterator;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ArrayELResolver
/*     */   extends ELResolver
/*     */ {
/*     */   private final boolean readOnly;
/*     */   
/*     */   public ArrayELResolver()
/*     */   {
/*  29 */     this.readOnly = false;
/*     */   }
/*     */   
/*     */   public ArrayELResolver(boolean readOnly) {
/*  33 */     this.readOnly = readOnly;
/*     */   }
/*     */   
/*     */   public Class<?> getType(ELContext context, Object base, Object property)
/*     */   {
/*  38 */     Objects.requireNonNull(context);
/*     */     
/*  40 */     if ((base != null) && (base.getClass().isArray())) {
/*  41 */       context.setPropertyResolved(base, property);
/*     */       try {
/*  43 */         int idx = coerce(property);
/*  44 */         checkBounds(base, idx);
/*     */       }
/*     */       catch (IllegalArgumentException localIllegalArgumentException) {}
/*     */       
/*  48 */       return base.getClass().getComponentType();
/*     */     }
/*     */     
/*  51 */     return null;
/*     */   }
/*     */   
/*     */   public Object getValue(ELContext context, Object base, Object property)
/*     */   {
/*  56 */     Objects.requireNonNull(context);
/*     */     
/*  58 */     if ((base != null) && (base.getClass().isArray())) {
/*  59 */       context.setPropertyResolved(base, property);
/*  60 */       int idx = coerce(property);
/*  61 */       if ((idx < 0) || (idx >= Array.getLength(base))) {
/*  62 */         return null;
/*     */       }
/*  64 */       return Array.get(base, idx);
/*     */     }
/*     */     
/*  67 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setValue(ELContext context, Object base, Object property, Object value)
/*     */   {
/*  73 */     Objects.requireNonNull(context);
/*     */     
/*  75 */     if ((base != null) && (base.getClass().isArray())) {
/*  76 */       context.setPropertyResolved(base, property);
/*     */       
/*  78 */       if (this.readOnly) {
/*  79 */         throw new PropertyNotWritableException(Util.message(context, "resolverNotWriteable", new Object[] {base
/*  80 */           .getClass().getName() }));
/*     */       }
/*     */       
/*  83 */       int idx = coerce(property);
/*  84 */       checkBounds(base, idx);
/*  85 */       if ((value != null) && (!Util.isAssignableFrom(value.getClass(), base
/*  86 */         .getClass().getComponentType()))) {
/*  87 */         throw new ClassCastException(Util.message(context, "objectNotAssignable", new Object[] {value
/*  88 */           .getClass().getName(), base
/*  89 */           .getClass().getComponentType().getName() }));
/*     */       }
/*  91 */       Array.set(base, idx, value);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isReadOnly(ELContext context, Object base, Object property)
/*     */   {
/*  97 */     Objects.requireNonNull(context);
/*     */     
/*  99 */     if ((base != null) && (base.getClass().isArray())) {
/* 100 */       context.setPropertyResolved(base, property);
/*     */       try {
/* 102 */         int idx = coerce(property);
/* 103 */         checkBounds(base, idx);
/*     */       }
/*     */       catch (IllegalArgumentException localIllegalArgumentException) {}
/*     */     }
/*     */     
/*     */ 
/* 109 */     return this.readOnly;
/*     */   }
/*     */   
/*     */   public Iterator<FeatureDescriptor> getFeatureDescriptors(ELContext context, Object base)
/*     */   {
/* 114 */     return null;
/*     */   }
/*     */   
/*     */   public Class<?> getCommonPropertyType(ELContext context, Object base)
/*     */   {
/* 119 */     if ((base != null) && (base.getClass().isArray())) {
/* 120 */       return Integer.class;
/*     */     }
/* 122 */     return null;
/*     */   }
/*     */   
/*     */   private static final void checkBounds(Object base, int idx) {
/* 126 */     if ((idx < 0) || (idx >= Array.getLength(base)))
/*     */     {
/* 128 */       throw new PropertyNotFoundException(new ArrayIndexOutOfBoundsException(idx).getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */   private static final int coerce(Object property) {
/* 133 */     if ((property instanceof Number)) {
/* 134 */       return ((Number)property).intValue();
/*     */     }
/* 136 */     if ((property instanceof Character)) {
/* 137 */       return ((Character)property).charValue();
/*     */     }
/* 139 */     if ((property instanceof Boolean)) {
/* 140 */       return ((Boolean)property).booleanValue() ? 1 : 0;
/*     */     }
/* 142 */     if ((property instanceof String)) {
/* 143 */       return Integer.parseInt((String)property);
/*     */     }
/*     */     
/* 146 */     throw new IllegalArgumentException(property != null ? property.toString() : "null");
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-el-9.0.54.jar!\javax\el\ArrayELResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */