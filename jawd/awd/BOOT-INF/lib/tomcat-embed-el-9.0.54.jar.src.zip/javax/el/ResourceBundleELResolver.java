/*     */ package javax.el;
/*     */ 
/*     */ import java.beans.FeatureDescriptor;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.MissingResourceException;
/*     */ import java.util.Objects;
/*     */ import java.util.ResourceBundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourceBundleELResolver
/*     */   extends ELResolver
/*     */ {
/*     */   public Object getValue(ELContext context, Object base, Object property)
/*     */   {
/*  36 */     Objects.requireNonNull(context);
/*     */     
/*  38 */     if ((base instanceof ResourceBundle)) {
/*  39 */       context.setPropertyResolved(base, property);
/*     */       
/*  41 */       if (property != null) {
/*     */         try {
/*  43 */           return ((ResourceBundle)base).getObject(property
/*  44 */             .toString());
/*     */         } catch (MissingResourceException mre) {
/*  46 */           return "???" + property.toString() + "???";
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*  51 */     return null;
/*     */   }
/*     */   
/*     */   public Class<?> getType(ELContext context, Object base, Object property)
/*     */   {
/*  56 */     Objects.requireNonNull(context);
/*     */     
/*  58 */     if ((base instanceof ResourceBundle)) {
/*  59 */       context.setPropertyResolved(base, property);
/*     */     }
/*     */     
/*  62 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setValue(ELContext context, Object base, Object property, Object value)
/*     */   {
/*  68 */     Objects.requireNonNull(context);
/*     */     
/*  70 */     if ((base instanceof ResourceBundle)) {
/*  71 */       context.setPropertyResolved(base, property);
/*  72 */       throw new PropertyNotWritableException(Util.message(context, "resolverNotWriteable", new Object[] {base
/*  73 */         .getClass().getName() }));
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isReadOnly(ELContext context, Object base, Object property)
/*     */   {
/*  79 */     Objects.requireNonNull(context);
/*     */     
/*  81 */     if ((base instanceof ResourceBundle)) {
/*  82 */       context.setPropertyResolved(base, property);
/*  83 */       return true;
/*     */     }
/*     */     
/*  86 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public Iterator<FeatureDescriptor> getFeatureDescriptors(ELContext context, Object base)
/*     */   {
/*  92 */     if ((base instanceof ResourceBundle)) {
/*  93 */       List<FeatureDescriptor> feats = new ArrayList();
/*  94 */       Enumeration<String> e = ((ResourceBundle)base).getKeys();
/*     */       
/*     */ 
/*  97 */       while (e.hasMoreElements()) {
/*  98 */         String key = (String)e.nextElement();
/*  99 */         FeatureDescriptor feat = new FeatureDescriptor();
/* 100 */         feat.setDisplayName(key);
/* 101 */         feat.setShortDescription("");
/* 102 */         feat.setExpert(false);
/* 103 */         feat.setHidden(false);
/* 104 */         feat.setName(key);
/* 105 */         feat.setPreferred(true);
/* 106 */         feat.setValue("resolvableAtDesignTime", Boolean.TRUE);
/* 107 */         feat.setValue("type", String.class);
/* 108 */         feats.add(feat);
/*     */       }
/* 110 */       return feats.iterator();
/*     */     }
/* 112 */     return null;
/*     */   }
/*     */   
/*     */   public Class<?> getCommonPropertyType(ELContext context, Object base)
/*     */   {
/* 117 */     if ((base instanceof ResourceBundle)) {
/* 118 */       return String.class;
/*     */     }
/* 120 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-el-9.0.54.jar!\javax\el\ResourceBundleELResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */