/*     */ package javax.el;
/*     */ 
/*     */ import java.beans.FeatureDescriptor;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ListELResolver
/*     */   extends ELResolver
/*     */ {
/*     */   private final boolean readOnly;
/*  30 */   private static final Class<?> UNMODIFIABLE = Collections.unmodifiableList(new ArrayList()).getClass();
/*     */   
/*     */   public ListELResolver() {
/*  33 */     this.readOnly = false;
/*     */   }
/*     */   
/*     */   public ListELResolver(boolean readOnly) {
/*  37 */     this.readOnly = readOnly;
/*     */   }
/*     */   
/*     */   public Class<?> getType(ELContext context, Object base, Object property)
/*     */   {
/*  42 */     Objects.requireNonNull(context);
/*     */     
/*  44 */     if ((base instanceof List)) {
/*  45 */       context.setPropertyResolved(base, property);
/*  46 */       List<?> list = (List)base;
/*  47 */       int idx = coerce(property);
/*  48 */       if ((idx < 0) || (idx >= list.size()))
/*     */       {
/*  50 */         throw new PropertyNotFoundException(new ArrayIndexOutOfBoundsException(idx).getMessage());
/*     */       }
/*  52 */       return Object.class;
/*     */     }
/*     */     
/*  55 */     return null;
/*     */   }
/*     */   
/*     */   public Object getValue(ELContext context, Object base, Object property)
/*     */   {
/*  60 */     Objects.requireNonNull(context);
/*     */     
/*  62 */     if ((base instanceof List)) {
/*  63 */       context.setPropertyResolved(base, property);
/*  64 */       List<?> list = (List)base;
/*  65 */       int idx = coerce(property);
/*  66 */       if ((idx < 0) || (idx >= list.size())) {
/*  67 */         return null;
/*     */       }
/*  69 */       return list.get(idx);
/*     */     }
/*     */     
/*  72 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setValue(ELContext context, Object base, Object property, Object value)
/*     */   {
/*  78 */     Objects.requireNonNull(context);
/*     */     
/*  80 */     if ((base instanceof List)) {
/*  81 */       context.setPropertyResolved(base, property);
/*     */       
/*  83 */       List<Object> list = (List)base;
/*     */       
/*  85 */       if (this.readOnly) {
/*  86 */         throw new PropertyNotWritableException(Util.message(context, "resolverNotWriteable", new Object[] {base
/*  87 */           .getClass().getName() }));
/*     */       }
/*     */       
/*  90 */       int idx = coerce(property);
/*     */       try {
/*  92 */         list.set(idx, value);
/*     */       } catch (UnsupportedOperationException e) {
/*  94 */         throw new PropertyNotWritableException(e);
/*     */       } catch (IndexOutOfBoundsException e) {
/*  96 */         throw new PropertyNotFoundException(e);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isReadOnly(ELContext context, Object base, Object property)
/*     */   {
/* 103 */     Objects.requireNonNull(context);
/*     */     
/* 105 */     if ((base instanceof List)) {
/* 106 */       context.setPropertyResolved(base, property);
/* 107 */       List<?> list = (List)base;
/*     */       try {
/* 109 */         int idx = coerce(property);
/* 110 */         if ((idx < 0) || (idx >= list.size()))
/*     */         {
/*     */ 
/* 113 */           throw new PropertyNotFoundException(new ArrayIndexOutOfBoundsException(idx).getMessage());
/*     */         }
/*     */       }
/*     */       catch (IllegalArgumentException localIllegalArgumentException) {}
/*     */       
/* 118 */       return (this.readOnly) || (UNMODIFIABLE.equals(list.getClass()));
/*     */     }
/*     */     
/* 121 */     return this.readOnly;
/*     */   }
/*     */   
/*     */   public Iterator<FeatureDescriptor> getFeatureDescriptors(ELContext context, Object base)
/*     */   {
/* 126 */     return null;
/*     */   }
/*     */   
/*     */   public Class<?> getCommonPropertyType(ELContext context, Object base)
/*     */   {
/* 131 */     if ((base instanceof List)) {
/* 132 */       return Integer.class;
/*     */     }
/* 134 */     return null;
/*     */   }
/*     */   
/*     */   private static final int coerce(Object property) {
/* 138 */     if ((property instanceof Number)) {
/* 139 */       return ((Number)property).intValue();
/*     */     }
/* 141 */     if ((property instanceof Character)) {
/* 142 */       return ((Character)property).charValue();
/*     */     }
/* 144 */     if ((property instanceof Boolean)) {
/* 145 */       return ((Boolean)property).booleanValue() ? 1 : 0;
/*     */     }
/* 147 */     if ((property instanceof String)) {
/* 148 */       return Integer.parseInt((String)property);
/*     */     }
/*     */     
/* 151 */     throw new IllegalArgumentException(property != null ? property.toString() : "null");
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-el-9.0.54.jar!\javax\el\ListELResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */