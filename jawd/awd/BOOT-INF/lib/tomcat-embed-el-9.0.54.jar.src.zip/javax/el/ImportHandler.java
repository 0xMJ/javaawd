/*     */ package javax.el;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ImportHandler
/*     */ {
/*  36 */   private static final boolean IS_SECURITY_ENABLED = System.getSecurityManager() != null;
/*     */   
/*  38 */   private static final Map<String, Set<String>> standardPackages = new HashMap();
/*     */   
/*     */   static
/*     */   {
/*  42 */     Set<String> servletClassNames = new HashSet();
/*     */     
/*  44 */     servletClassNames.add("AsyncContext");
/*  45 */     servletClassNames.add("AsyncListener");
/*  46 */     servletClassNames.add("Filter");
/*  47 */     servletClassNames.add("FilterChain");
/*  48 */     servletClassNames.add("FilterConfig");
/*  49 */     servletClassNames.add("FilterRegistration");
/*  50 */     servletClassNames.add("FilterRegistration.Dynamic");
/*  51 */     servletClassNames.add("ReadListener");
/*  52 */     servletClassNames.add("Registration");
/*  53 */     servletClassNames.add("Registration.Dynamic");
/*  54 */     servletClassNames.add("RequestDispatcher");
/*  55 */     servletClassNames.add("Servlet");
/*  56 */     servletClassNames.add("ServletConfig");
/*  57 */     servletClassNames.add("ServletContainerInitializer");
/*  58 */     servletClassNames.add("ServletContext");
/*  59 */     servletClassNames.add("ServletContextAttributeListener");
/*  60 */     servletClassNames.add("ServletContextListener");
/*  61 */     servletClassNames.add("ServletRegistration");
/*  62 */     servletClassNames.add("ServletRegistration.Dynamic");
/*  63 */     servletClassNames.add("ServletRequest");
/*  64 */     servletClassNames.add("ServletRequestAttributeListener");
/*  65 */     servletClassNames.add("ServletRequestListener");
/*  66 */     servletClassNames.add("ServletResponse");
/*  67 */     servletClassNames.add("SessionCookieConfig");
/*  68 */     servletClassNames.add("SingleThreadModel");
/*  69 */     servletClassNames.add("WriteListener");
/*     */     
/*  71 */     servletClassNames.add("AsyncEvent");
/*  72 */     servletClassNames.add("GenericFilter");
/*  73 */     servletClassNames.add("GenericServlet");
/*  74 */     servletClassNames.add("HttpConstraintElement");
/*  75 */     servletClassNames.add("HttpMethodConstraintElement");
/*  76 */     servletClassNames.add("MultipartConfigElement");
/*  77 */     servletClassNames.add("ServletContextAttributeEvent");
/*  78 */     servletClassNames.add("ServletContextEvent");
/*  79 */     servletClassNames.add("ServletInputStream");
/*  80 */     servletClassNames.add("ServletOutputStream");
/*  81 */     servletClassNames.add("ServletRequestAttributeEvent");
/*  82 */     servletClassNames.add("ServletRequestEvent");
/*  83 */     servletClassNames.add("ServletRequestWrapper");
/*  84 */     servletClassNames.add("ServletResponseWrapper");
/*  85 */     servletClassNames.add("ServletSecurityElement");
/*     */     
/*  87 */     servletClassNames.add("DispatcherType");
/*  88 */     servletClassNames.add("SessionTrackingMode");
/*     */     
/*  90 */     servletClassNames.add("ServletException");
/*  91 */     servletClassNames.add("UnavailableException");
/*  92 */     standardPackages.put("javax.servlet", servletClassNames);
/*     */     
/*     */ 
/*  95 */     Set<String> servletHttpClassNames = new HashSet();
/*     */     
/*  97 */     servletHttpClassNames.add("HttpServletMapping");
/*  98 */     servletHttpClassNames.add("HttpServletRequest");
/*  99 */     servletHttpClassNames.add("HttpServletResponse");
/* 100 */     servletHttpClassNames.add("HttpSession");
/* 101 */     servletHttpClassNames.add("HttpSessionActivationListener");
/* 102 */     servletHttpClassNames.add("HttpSessionAttributeListener");
/* 103 */     servletHttpClassNames.add("HttpSessionBindingListener");
/* 104 */     servletHttpClassNames.add("HttpSessionContext");
/* 105 */     servletHttpClassNames.add("HttpSessionIdListener");
/* 106 */     servletHttpClassNames.add("HttpSessionListener");
/* 107 */     servletHttpClassNames.add("HttpUpgradeHandler");
/* 108 */     servletHttpClassNames.add("Part");
/* 109 */     servletHttpClassNames.add("PushBuilder");
/* 110 */     servletHttpClassNames.add("WebConnection");
/*     */     
/* 112 */     servletHttpClassNames.add("Cookie");
/* 113 */     servletHttpClassNames.add("HttpFilter");
/* 114 */     servletHttpClassNames.add("HttpServlet");
/* 115 */     servletHttpClassNames.add("HttpServletRequestWrapper");
/* 116 */     servletHttpClassNames.add("HttpServletResponseWrapper");
/* 117 */     servletHttpClassNames.add("HttpSessionBindingEvent");
/* 118 */     servletHttpClassNames.add("HttpSessionEvent");
/* 119 */     servletHttpClassNames.add("HttpUtils");
/*     */     
/* 121 */     servletHttpClassNames.add("MappingMatch");
/* 122 */     standardPackages.put("javax.servlet.http", servletHttpClassNames);
/*     */     
/*     */ 
/* 125 */     Set<String> servletJspClassNames = new HashSet();
/*     */     
/* 127 */     servletJspClassNames.add("HttpJspPage");
/* 128 */     servletJspClassNames.add("JspApplicationContext");
/* 129 */     servletJspClassNames.add("JspPage");
/*     */     
/* 131 */     servletJspClassNames.add("ErrorData");
/* 132 */     servletJspClassNames.add("JspContext");
/* 133 */     servletJspClassNames.add("JspEngineInfo");
/* 134 */     servletJspClassNames.add("JspFactory");
/* 135 */     servletJspClassNames.add("JspWriter");
/* 136 */     servletJspClassNames.add("PageContext");
/* 137 */     servletJspClassNames.add("Exceptions");
/* 138 */     servletJspClassNames.add("JspException");
/* 139 */     servletJspClassNames.add("JspTagException");
/* 140 */     servletJspClassNames.add("SkipPageException");
/* 141 */     standardPackages.put("javax.servlet.jsp", servletJspClassNames);
/*     */     
/* 143 */     Set<String> javaLangClassNames = new HashSet();
/*     */     
/*     */ 
/* 146 */     javaLangClassNames.add("Appendable");
/* 147 */     javaLangClassNames.add("AutoCloseable");
/* 148 */     javaLangClassNames.add("CharSequence");
/* 149 */     javaLangClassNames.add("Cloneable");
/* 150 */     javaLangClassNames.add("Comparable");
/* 151 */     javaLangClassNames.add("Iterable");
/* 152 */     javaLangClassNames.add("ProcessHandle");
/* 153 */     javaLangClassNames.add("ProcessHandle.Info");
/* 154 */     javaLangClassNames.add("Readable");
/* 155 */     javaLangClassNames.add("Runnable");
/* 156 */     javaLangClassNames.add("StackWalker.StackFrame");
/* 157 */     javaLangClassNames.add("System.Logger");
/* 158 */     javaLangClassNames.add("Thread.UncaughtExceptionHandler");
/*     */     
/* 160 */     javaLangClassNames.add("Boolean");
/* 161 */     javaLangClassNames.add("Byte");
/* 162 */     javaLangClassNames.add("Character");
/* 163 */     javaLangClassNames.add("Character.Subset");
/* 164 */     javaLangClassNames.add("Character.UnicodeBlock");
/* 165 */     javaLangClassNames.add("Class");
/* 166 */     javaLangClassNames.add("ClassLoader");
/* 167 */     javaLangClassNames.add("ClassValue");
/* 168 */     javaLangClassNames.add("Compiler");
/* 169 */     javaLangClassNames.add("Double");
/* 170 */     javaLangClassNames.add("Enum");
/* 171 */     javaLangClassNames.add("Enum.EnumDesc");
/* 172 */     javaLangClassNames.add("Float");
/* 173 */     javaLangClassNames.add("InheritableThreadLocal");
/* 174 */     javaLangClassNames.add("Integer");
/* 175 */     javaLangClassNames.add("Long");
/* 176 */     javaLangClassNames.add("Math");
/* 177 */     javaLangClassNames.add("Module");
/* 178 */     javaLangClassNames.add("ModuleLayer");
/* 179 */     javaLangClassNames.add("ModuleLayer.Controller");
/* 180 */     javaLangClassNames.add("Number");
/* 181 */     javaLangClassNames.add("Object");
/* 182 */     javaLangClassNames.add("Package");
/* 183 */     javaLangClassNames.add("Process");
/* 184 */     javaLangClassNames.add("ProcessBuilder");
/* 185 */     javaLangClassNames.add("ProcessBuilder.Redirect");
/* 186 */     javaLangClassNames.add("Record");
/* 187 */     javaLangClassNames.add("Runtime");
/* 188 */     javaLangClassNames.add("Runtime.Version");
/* 189 */     javaLangClassNames.add("RuntimePermission");
/* 190 */     javaLangClassNames.add("SecurityManager");
/* 191 */     javaLangClassNames.add("Short");
/* 192 */     javaLangClassNames.add("StackTraceElement");
/* 193 */     javaLangClassNames.add("StackWalker");
/* 194 */     javaLangClassNames.add("StrictMath");
/* 195 */     javaLangClassNames.add("String");
/* 196 */     javaLangClassNames.add("StringBuffer");
/* 197 */     javaLangClassNames.add("StringBuilder");
/* 198 */     javaLangClassNames.add("System");
/* 199 */     javaLangClassNames.add("System.LoggerFinder");
/* 200 */     javaLangClassNames.add("Thread");
/* 201 */     javaLangClassNames.add("ThreadGroup");
/* 202 */     javaLangClassNames.add("ThreadLocal");
/* 203 */     javaLangClassNames.add("Throwable");
/* 204 */     javaLangClassNames.add("Void");
/*     */     
/* 206 */     javaLangClassNames.add("Character.UnicodeScript");
/* 207 */     javaLangClassNames.add("ProcessBuilder.Redirect.Type");
/* 208 */     javaLangClassNames.add("StackWalker.Option");
/* 209 */     javaLangClassNames.add("System.Logger.Level");
/* 210 */     javaLangClassNames.add("Thread.State");
/*     */     
/* 212 */     javaLangClassNames.add("ArithmeticException");
/* 213 */     javaLangClassNames.add("ArrayIndexOutOfBoundsException");
/* 214 */     javaLangClassNames.add("ArrayStoreException");
/* 215 */     javaLangClassNames.add("ClassCastException");
/* 216 */     javaLangClassNames.add("ClassNotFoundException");
/* 217 */     javaLangClassNames.add("CloneNotSupportedException");
/* 218 */     javaLangClassNames.add("EnumConstantNotPresentException");
/* 219 */     javaLangClassNames.add("Exception");
/* 220 */     javaLangClassNames.add("IllegalAccessException");
/* 221 */     javaLangClassNames.add("IllegalArgumentException");
/* 222 */     javaLangClassNames.add("IllegalCallerException");
/* 223 */     javaLangClassNames.add("IllegalMonitorStateException");
/* 224 */     javaLangClassNames.add("IllegalStateException");
/* 225 */     javaLangClassNames.add("IllegalThreadStateException");
/* 226 */     javaLangClassNames.add("IndexOutOfBoundsException");
/* 227 */     javaLangClassNames.add("InstantiationException");
/* 228 */     javaLangClassNames.add("InterruptedException");
/* 229 */     javaLangClassNames.add("LayerInstantiationException");
/* 230 */     javaLangClassNames.add("NegativeArraySizeException");
/* 231 */     javaLangClassNames.add("NoSuchFieldException");
/* 232 */     javaLangClassNames.add("NoSuchMethodException");
/* 233 */     javaLangClassNames.add("NullPointerException");
/* 234 */     javaLangClassNames.add("NumberFormatException");
/* 235 */     javaLangClassNames.add("ReflectiveOperationException");
/* 236 */     javaLangClassNames.add("RuntimeException");
/* 237 */     javaLangClassNames.add("SecurityException");
/* 238 */     javaLangClassNames.add("StringIndexOutOfBoundsException");
/* 239 */     javaLangClassNames.add("TypeNotPresentException");
/* 240 */     javaLangClassNames.add("UnsupportedOperationException");
/*     */     
/* 242 */     javaLangClassNames.add("AbstractMethodError");
/* 243 */     javaLangClassNames.add("AssertionError");
/* 244 */     javaLangClassNames.add("BootstrapMethodError");
/* 245 */     javaLangClassNames.add("ClassCircularityError");
/* 246 */     javaLangClassNames.add("ClassFormatError");
/* 247 */     javaLangClassNames.add("Error");
/* 248 */     javaLangClassNames.add("ExceptionInInitializerError");
/* 249 */     javaLangClassNames.add("IllegalAccessError");
/* 250 */     javaLangClassNames.add("IncompatibleClassChangeError");
/* 251 */     javaLangClassNames.add("InstantiationError");
/* 252 */     javaLangClassNames.add("InternalError");
/* 253 */     javaLangClassNames.add("LinkageError");
/* 254 */     javaLangClassNames.add("NoClassDefFoundError");
/* 255 */     javaLangClassNames.add("NoSuchFieldError");
/* 256 */     javaLangClassNames.add("NoSuchMethodError");
/* 257 */     javaLangClassNames.add("OutOfMemoryError");
/* 258 */     javaLangClassNames.add("StackOverflowError");
/* 259 */     javaLangClassNames.add("ThreadDeath");
/* 260 */     javaLangClassNames.add("UnknownError");
/* 261 */     javaLangClassNames.add("UnsatisfiedLinkError");
/* 262 */     javaLangClassNames.add("UnsupportedClassVersionError");
/* 263 */     javaLangClassNames.add("VerifyError");
/* 264 */     javaLangClassNames.add("VirtualMachineError");
/*     */     
/* 266 */     javaLangClassNames.add("Deprecated");
/* 267 */     javaLangClassNames.add("FunctionalInterface");
/* 268 */     javaLangClassNames.add("Override");
/* 269 */     javaLangClassNames.add("SafeVarargs");
/* 270 */     javaLangClassNames.add("SuppressWarnings");
/* 271 */     standardPackages.put("java.lang", javaLangClassNames);
/*     */   }
/*     */   
/*     */ 
/* 275 */   private Map<String, Set<String>> packageNames = new ConcurrentHashMap();
/* 276 */   private Map<String, String> classNames = new ConcurrentHashMap();
/* 277 */   private Map<String, Class<?>> clazzes = new ConcurrentHashMap();
/* 278 */   private Map<String, Class<?>> statics = new ConcurrentHashMap();
/*     */   
/*     */   public ImportHandler()
/*     */   {
/* 282 */     importPackage("java.lang");
/*     */   }
/*     */   
/*     */   public void importStatic(String name) throws ELException
/*     */   {
/* 287 */     int lastPeriod = name.lastIndexOf('.');
/*     */     
/* 289 */     if (lastPeriod < 0) {
/* 290 */       throw new ELException(Util.message(null, "importHandler.invalidStaticName", new Object[] { name }));
/*     */     }
/*     */     
/*     */ 
/* 294 */     String className = name.substring(0, lastPeriod);
/* 295 */     String fieldOrMethodName = name.substring(lastPeriod + 1);
/*     */     
/* 297 */     Class<?> clazz = findClass(className, true);
/*     */     
/* 299 */     if (clazz == null) {
/* 300 */       throw new ELException(Util.message(null, "importHandler.invalidClassNameForStatic", new Object[] { className, name }));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 305 */     boolean found = false;
/*     */     
/* 307 */     for (Field field : clazz.getFields()) {
/* 308 */       if (field.getName().equals(fieldOrMethodName)) {
/* 309 */         int modifiers = field.getModifiers();
/* 310 */         if ((Modifier.isStatic(modifiers)) && 
/* 311 */           (Modifier.isPublic(modifiers))) {
/* 312 */           found = true;
/* 313 */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 318 */     if (!found) {
/* 319 */       for (Method method : clazz.getMethods()) {
/* 320 */         if (method.getName().equals(fieldOrMethodName)) {
/* 321 */           int modifiers = method.getModifiers();
/* 322 */           if ((Modifier.isStatic(modifiers)) && 
/* 323 */             (Modifier.isPublic(modifiers))) {
/* 324 */             found = true;
/* 325 */             break;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 331 */     if (!found) {
/* 332 */       throw new ELException(Util.message(null, "importHandler.staticNotFound", new Object[] { fieldOrMethodName, className, name }));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 337 */     Object conflict = (Class)this.statics.get(fieldOrMethodName);
/* 338 */     if (conflict != null) {
/* 339 */       throw new ELException(Util.message(null, "importHandler.ambiguousStaticImport", new Object[] { name, ((Class)conflict)
/*     */       
/* 341 */         .getName() + '.' + fieldOrMethodName }));
/*     */     }
/*     */     
/* 344 */     this.statics.put(fieldOrMethodName, clazz);
/*     */   }
/*     */   
/*     */   public void importClass(String name) throws ELException
/*     */   {
/* 349 */     int lastPeriodIndex = name.lastIndexOf('.');
/*     */     
/* 351 */     if (lastPeriodIndex < 0) {
/* 352 */       throw new ELException(Util.message(null, "importHandler.invalidClassName", new Object[] { name }));
/*     */     }
/*     */     
/*     */ 
/* 356 */     String unqualifiedName = name.substring(lastPeriodIndex + 1);
/* 357 */     String currentName = (String)this.classNames.putIfAbsent(unqualifiedName, name);
/*     */     
/* 359 */     if ((currentName != null) && (!currentName.equals(name)))
/*     */     {
/* 361 */       throw new ELException(Util.message(null, "importHandler.ambiguousImport", new Object[] { name, currentName }));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void importPackage(String name)
/*     */   {
/* 373 */     Set<String> preloaded = (Set)standardPackages.get(name);
/* 374 */     if (preloaded == null) {
/* 375 */       this.packageNames.put(name, Collections.emptySet());
/*     */     } else {
/* 377 */       this.packageNames.put(name, preloaded);
/*     */     }
/*     */   }
/*     */   
/*     */   public Class<?> resolveClass(String name)
/*     */   {
/* 383 */     if ((name == null) || (name.contains("."))) {
/* 384 */       return null;
/*     */     }
/*     */     
/*     */ 
/* 388 */     Class<?> result = (Class)this.clazzes.get(name);
/*     */     
/* 390 */     if (result != null) {
/* 391 */       if (NotFound.class.equals(result)) {
/* 392 */         return null;
/*     */       }
/* 394 */       return result;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 399 */     String className = (String)this.classNames.get(name);
/* 400 */     Class<?> clazz; if (className != null) {
/* 401 */       clazz = findClass(className, true);
/* 402 */       if (clazz != null) {
/* 403 */         this.clazzes.put(name, clazz);
/* 404 */         return clazz;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 410 */     for (Map.Entry<String, Set<String>> entry : this.packageNames.entrySet())
/* 411 */       if ((((Set)entry.getValue()).isEmpty()) || 
/*     */       
/* 413 */         (((Set)entry.getValue()).contains(name)))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 420 */         className = (String)entry.getKey() + '.' + name;
/* 421 */         Class<?> clazz = findClass(className, false);
/* 422 */         if (clazz != null) {
/* 423 */           if (result != null) {
/* 424 */             throw new ELException(Util.message(null, "importHandler.ambiguousImport", new Object[] { className, result
/*     */             
/* 426 */               .getName() }));
/*     */           }
/* 428 */           result = clazz;
/*     */         }
/*     */       }
/* 431 */     if (result == null)
/*     */     {
/*     */ 
/* 434 */       this.clazzes.put(name, NotFound.class);
/*     */     } else {
/* 436 */       this.clazzes.put(name, result);
/*     */     }
/*     */     
/* 439 */     return result;
/*     */   }
/*     */   
/*     */   public Class<?> resolveStatic(String name)
/*     */   {
/* 444 */     return (Class)this.statics.get(name);
/*     */   }
/*     */   
/*     */ 
/*     */   private Class<?> findClass(String name, boolean throwException)
/*     */   {
/* 450 */     ClassLoader cl = Util.getContextClassLoader();
/* 451 */     String path = name.replace('.', '/') + ".class";
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 459 */       if (IS_SECURITY_ENABLED)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 464 */         if (!((Boolean)AccessController.doPrivileged(new PrivilegedResourceExists(cl, path))).booleanValue()) {
/* 465 */           return null;
/*     */         }
/*     */       }
/* 468 */       else if (cl.getResource(path) == null) {
/* 469 */         return null;
/*     */       }
/*     */     }
/*     */     catch (ClassCircularityError localClassCircularityError) {}
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 477 */       clazz = cl.loadClass(name);
/*     */     } catch (ClassNotFoundException e) { Class<?> clazz;
/* 479 */       return null;
/*     */     }
/*     */     
/*     */     Class<?> clazz;
/*     */     
/* 484 */     JreCompat jreCompat = JreCompat.getInstance();
/* 485 */     int modifiers = clazz.getModifiers();
/* 486 */     if ((!Modifier.isPublic(modifiers)) || (Modifier.isAbstract(modifiers)) || 
/* 487 */       (Modifier.isInterface(modifiers)) || (!jreCompat.isExported(clazz))) {
/* 488 */       if (throwException) {
/* 489 */         throw new ELException(Util.message(null, "importHandler.invalidClass", new Object[] { name }));
/*     */       }
/*     */       
/* 492 */       return null;
/*     */     }
/*     */     
/*     */ 
/* 496 */     return clazz;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class PrivilegedResourceExists
/*     */     implements PrivilegedAction<Boolean>
/*     */   {
/*     */     private final ClassLoader cl;
/*     */     
/*     */ 
/*     */     private final String name;
/*     */     
/*     */ 
/*     */ 
/*     */     public PrivilegedResourceExists(ClassLoader cl, String name)
/*     */     {
/* 514 */       this.cl = cl;
/* 515 */       this.name = name;
/*     */     }
/*     */     
/*     */     public Boolean run()
/*     */     {
/* 520 */       if (this.cl.getResource(this.name) == null) {
/* 521 */         return Boolean.FALSE;
/*     */       }
/* 523 */       return Boolean.TRUE;
/*     */     }
/*     */   }
/*     */   
/*     */   private static class NotFound {}
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-el-9.0.54.jar!\javax\el\ImportHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */