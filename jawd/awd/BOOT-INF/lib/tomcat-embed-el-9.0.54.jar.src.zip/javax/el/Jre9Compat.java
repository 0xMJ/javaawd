/*    */ package javax.el;
/*    */ 
/*    */ import java.lang.reflect.AccessibleObject;
/*    */ import java.lang.reflect.Method;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class Jre9Compat
/*    */   extends JreCompat
/*    */ {
/*    */   private static final Method canAccessMethod;
/*    */   private static final Method getModuleMethod;
/*    */   private static final Method isExportedMethod;
/*    */   
/*    */   static
/*    */   {
/* 36 */     Method m1 = null;
/* 37 */     Method m2 = null;
/* 38 */     Method m3 = null;
/*    */     try
/*    */     {
/* 41 */       m1 = AccessibleObject.class.getMethod("canAccess", new Class[] { Object.class });
/* 42 */       m2 = Class.class.getMethod("getModule", new Class[0]);
/* 43 */       Class<?> moduleClass = Class.forName("java.lang.Module");
/* 44 */       m3 = moduleClass.getMethod("isExported", new Class[] { String.class });
/*    */ 
/*    */     }
/*    */     catch (NoSuchMethodException localNoSuchMethodException) {}catch (ClassNotFoundException e)
/*    */     {
/* 49 */       throw new RuntimeException(e);
/*    */     }
/*    */     
/* 52 */     canAccessMethod = m1;
/* 53 */     getModuleMethod = m2;
/* 54 */     isExportedMethod = m3;
/*    */   }
/*    */   
/*    */   public static boolean isSupported()
/*    */   {
/* 59 */     return canAccessMethod != null;
/*    */   }
/*    */   
/*    */   public boolean canAccess(Object base, AccessibleObject accessibleObject)
/*    */   {
/*    */     try
/*    */     {
/* 66 */       return ((Boolean)canAccessMethod.invoke(accessibleObject, new Object[] { base })).booleanValue();
/*    */     } catch (ReflectiveOperationException|IllegalArgumentException e) {}
/* 68 */     return false;
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean isExported(Class<?> type)
/*    */   {
/*    */     try
/*    */     {
/* 76 */       String packageName = type.getPackage().getName();
/* 77 */       Object module = getModuleMethod.invoke(type, new Object[0]);
/* 78 */       return ((Boolean)isExportedMethod.invoke(module, new Object[] { packageName })).booleanValue();
/*    */     } catch (ReflectiveOperationException e) {}
/* 80 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-el-9.0.54.jar!\javax\el\Jre9Compat.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */