/*    */ package javax.el;
/*    */ 
/*    */ import java.util.EventObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ELContextEvent
/*    */   extends EventObject
/*    */ {
/*    */   private static final long serialVersionUID = 1255131906285426769L;
/*    */   
/*    */   public ELContextEvent(ELContext source)
/*    */   {
/* 29 */     super(source);
/*    */   }
/*    */   
/*    */   public ELContext getELContext() {
/* 33 */     return (ELContext)getSource();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-el-9.0.54.jar!\javax\el\ELContextEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */