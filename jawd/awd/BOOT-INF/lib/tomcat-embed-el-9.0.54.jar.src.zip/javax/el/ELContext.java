/*     */ package javax.el;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Deque;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ELContext
/*     */ {
/*     */   private Locale locale;
/*     */   private Map<Class<?>, Object> map;
/*     */   private boolean resolved;
/*  37 */   private ImportHandler importHandler = null;
/*     */   
/*     */   private List<EvaluationListener> listeners;
/*     */   
/*  41 */   private Deque<Map<String, Object>> lambdaArguments = new LinkedList();
/*     */   
/*     */   public ELContext() {
/*  44 */     this.resolved = false;
/*     */   }
/*     */   
/*     */   public void setPropertyResolved(boolean resolved) {
/*  48 */     this.resolved = resolved;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPropertyResolved(Object base, Object property)
/*     */   {
/*  60 */     setPropertyResolved(true);
/*  61 */     notifyPropertyResolved(base, property);
/*     */   }
/*     */   
/*     */   public boolean isPropertyResolved() {
/*  65 */     return this.resolved;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void putContext(Class key, Object contextObject)
/*     */   {
/*  80 */     Objects.requireNonNull(key);
/*  81 */     Objects.requireNonNull(contextObject);
/*     */     
/*  83 */     if (this.map == null) {
/*  84 */       this.map = new HashMap();
/*     */     }
/*     */     
/*  87 */     this.map.put(key, contextObject);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getContext(Class key)
/*     */   {
/* 102 */     Objects.requireNonNull(key);
/* 103 */     if (this.map == null) {
/* 104 */       return null;
/*     */     }
/* 106 */     return this.map.get(key);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract ELResolver getELResolver();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ImportHandler getImportHandler()
/*     */   {
/* 120 */     if (this.importHandler == null) {
/* 121 */       this.importHandler = new ImportHandler();
/*     */     }
/* 123 */     return this.importHandler;
/*     */   }
/*     */   
/*     */   public abstract FunctionMapper getFunctionMapper();
/*     */   
/*     */   public Locale getLocale() {
/* 129 */     return this.locale;
/*     */   }
/*     */   
/*     */   public void setLocale(Locale locale) {
/* 133 */     this.locale = locale;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract VariableMapper getVariableMapper();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addEvaluationListener(EvaluationListener listener)
/*     */   {
/* 146 */     if (this.listeners == null) {
/* 147 */       this.listeners = new ArrayList();
/*     */     }
/*     */     
/* 150 */     this.listeners.add(listener);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<EvaluationListener> getEvaluationListeners()
/*     */   {
/* 161 */     return this.listeners == null ? Collections.emptyList() : this.listeners;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void notifyBeforeEvaluation(String expression)
/*     */   {
/* 172 */     if (this.listeners == null) {
/* 173 */       return;
/*     */     }
/*     */     
/* 176 */     for (EvaluationListener listener : this.listeners) {
/*     */       try {
/* 178 */         listener.beforeEvaluation(this, expression);
/*     */       } catch (Throwable t) {
/* 180 */         Util.handleThrowable(t);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void notifyAfterEvaluation(String expression)
/*     */   {
/* 194 */     if (this.listeners == null) {
/* 195 */       return;
/*     */     }
/*     */     
/* 198 */     for (EvaluationListener listener : this.listeners) {
/*     */       try {
/* 200 */         listener.afterEvaluation(this, expression);
/*     */       } catch (Throwable t) {
/* 202 */         Util.handleThrowable(t);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void notifyPropertyResolved(Object base, Object property)
/*     */   {
/* 217 */     if (this.listeners == null) {
/* 218 */       return;
/*     */     }
/*     */     
/* 221 */     for (EvaluationListener listener : this.listeners) {
/*     */       try {
/* 223 */         listener.propertyResolved(this, base, property);
/*     */       } catch (Throwable t) {
/* 225 */         Util.handleThrowable(t);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isLambdaArgument(String name)
/*     */   {
/* 243 */     for (Map<String, Object> arguments : this.lambdaArguments) {
/* 244 */       if (arguments.containsKey(name)) {
/* 245 */         return true;
/*     */       }
/*     */     }
/* 248 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getLambdaArgument(String name)
/*     */   {
/* 261 */     for (Map<String, Object> arguments : this.lambdaArguments) {
/* 262 */       Object result = arguments.get(name);
/* 263 */       if (result != null) {
/* 264 */         return result;
/*     */       }
/*     */     }
/* 267 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void enterLambdaScope(Map<String, Object> arguments)
/*     */   {
/* 279 */     this.lambdaArguments.push(arguments);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void exitLambdaScope()
/*     */   {
/* 289 */     this.lambdaArguments.pop();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object convertToType(Object obj, Class<?> type)
/*     */   {
/* 307 */     boolean originalResolved = isPropertyResolved();
/* 308 */     setPropertyResolved(false);
/*     */     try {
/* 310 */       ELResolver resolver = getELResolver();
/* 311 */       if (resolver != null) {
/* 312 */         Object result = resolver.convertToType(this, obj, type);
/* 313 */         if (isPropertyResolved()) {
/* 314 */           return result;
/*     */         }
/*     */       }
/*     */     } finally {
/* 318 */       setPropertyResolved(originalResolved);
/*     */     }
/*     */     
/* 321 */     return ELManager.getExpressionFactory().coerceToType(obj, type);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-el-9.0.54.jar!\javax\el\ELContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */