/*     */ package javax.el;
/*     */ 
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.MissingResourceException;
/*     */ import java.util.ResourceBundle;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReadWriteLock;
/*     */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Util
/*     */ {
/*  42 */   private static final Class<?>[] EMPTY_CLASS_ARRAY = new Class[0];
/*  43 */   private static final Object[] EMPTY_OBJECT_ARRAY = new Object[0];
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static void handleThrowable(Throwable t)
/*     */   {
/*  51 */     if ((t instanceof ThreadDeath)) {
/*  52 */       throw ((ThreadDeath)t);
/*     */     }
/*  54 */     if ((t instanceof VirtualMachineError)) {
/*  55 */       throw ((VirtualMachineError)t);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   static String message(ELContext context, String name, Object... props)
/*     */   {
/*  62 */     Locale locale = null;
/*  63 */     if (context != null) {
/*  64 */       locale = context.getLocale();
/*     */     }
/*  66 */     if (locale == null) {
/*  67 */       locale = Locale.getDefault();
/*  68 */       if (locale == null) {
/*  69 */         return "";
/*     */       }
/*     */     }
/*  72 */     ResourceBundle bundle = ResourceBundle.getBundle("javax.el.LocalStrings", locale);
/*     */     try
/*     */     {
/*  75 */       String template = bundle.getString(name);
/*  76 */       if (props != null) {}
/*  77 */       return MessageFormat.format(template, props);
/*     */     }
/*     */     catch (MissingResourceException e) {}
/*     */     
/*  81 */     return "Missing Resource: '" + name + "' for Locale " + locale.getDisplayName();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*  86 */   private static final CacheValue nullTcclFactory = new CacheValue();
/*  87 */   private static final Map<CacheKey, CacheValue> factoryCache = new ConcurrentHashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static ExpressionFactory getExpressionFactory()
/*     */   {
/*  95 */     ClassLoader tccl = getContextClassLoader();
/*     */     
/*  97 */     CacheValue cacheValue = null;
/*  98 */     ExpressionFactory factory = null;
/*     */     
/* 100 */     if (tccl == null) {
/* 101 */       cacheValue = nullTcclFactory;
/*     */     } else {
/* 103 */       CacheKey key = new CacheKey(tccl);
/* 104 */       cacheValue = (CacheValue)factoryCache.get(key);
/* 105 */       if (cacheValue == null) {
/* 106 */         CacheValue newCacheValue = new CacheValue();
/* 107 */         cacheValue = (CacheValue)factoryCache.putIfAbsent(key, newCacheValue);
/* 108 */         if (cacheValue == null) {
/* 109 */           cacheValue = newCacheValue;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 114 */     Lock readLock = cacheValue.getLock().readLock();
/* 115 */     readLock.lock();
/*     */     try {
/* 117 */       factory = cacheValue.getExpressionFactory();
/*     */     } finally {
/* 119 */       readLock.unlock();
/*     */     }
/*     */     
/* 122 */     if (factory == null) {
/* 123 */       Lock writeLock = cacheValue.getLock().writeLock();
/* 124 */       writeLock.lock();
/*     */       try {
/* 126 */         factory = cacheValue.getExpressionFactory();
/* 127 */         if (factory == null) {
/* 128 */           factory = ExpressionFactory.newInstance();
/* 129 */           cacheValue.setExpressionFactory(factory);
/*     */         }
/*     */       } finally {
/* 132 */         writeLock.unlock();
/*     */       }
/*     */     }
/*     */     
/* 136 */     return factory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static class CacheKey
/*     */   {
/*     */     private final int hash;
/*     */     
/*     */     private final WeakReference<ClassLoader> ref;
/*     */     
/*     */ 
/*     */     public CacheKey(ClassLoader key)
/*     */     {
/* 150 */       this.hash = key.hashCode();
/* 151 */       this.ref = new WeakReference(key);
/*     */     }
/*     */     
/*     */     public int hashCode()
/*     */     {
/* 156 */       return this.hash;
/*     */     }
/*     */     
/*     */     public boolean equals(Object obj)
/*     */     {
/* 161 */       if (obj == this) {
/* 162 */         return true;
/*     */       }
/* 164 */       if (!(obj instanceof CacheKey)) {
/* 165 */         return false;
/*     */       }
/* 167 */       ClassLoader thisKey = (ClassLoader)this.ref.get();
/* 168 */       if (thisKey == null) {
/* 169 */         return false;
/*     */       }
/* 171 */       return thisKey == ((CacheKey)obj).ref.get();
/*     */     }
/*     */   }
/*     */   
/*     */   private static class CacheValue {
/* 176 */     private final ReadWriteLock lock = new ReentrantReadWriteLock();
/*     */     
/*     */     private WeakReference<ExpressionFactory> ref;
/*     */     
/*     */ 
/*     */     public ReadWriteLock getLock()
/*     */     {
/* 183 */       return this.lock;
/*     */     }
/*     */     
/*     */     public ExpressionFactory getExpressionFactory() {
/* 187 */       return this.ref != null ? (ExpressionFactory)this.ref.get() : null;
/*     */     }
/*     */     
/*     */     public void setExpressionFactory(ExpressionFactory factory) {
/* 191 */       this.ref = new WeakReference(factory);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static Method findMethod(Class<?> clazz, Object base, String methodName, Class<?>[] paramTypes, Object[] paramValues)
/*     */   {
/* 203 */     if ((clazz == null) || (methodName == null))
/*     */     {
/* 205 */       throw new MethodNotFoundException(message(null, "util.method.notfound", new Object[] { clazz, methodName, 
/* 206 */         paramString(paramTypes) }));
/*     */     }
/*     */     
/* 209 */     if (paramTypes == null) {
/* 210 */       paramTypes = getTypesFromValues(paramValues);
/*     */     }
/*     */     
/* 213 */     Method[] methods = clazz.getMethods();
/*     */     
/* 215 */     List<Wrapper<Method>> wrappers = Wrapper.wrap(methods, methodName);
/*     */     
/* 217 */     Wrapper<Method> result = findWrapper(clazz, wrappers, methodName, paramTypes, paramValues);
/*     */     
/* 219 */     return getMethod(clazz, base, (Method)result.unWrap());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static <T> Wrapper<T> findWrapper(Class<?> clazz, List<Wrapper<T>> wrappers, String name, Class<?>[] paramTypes, Object[] paramValues)
/*     */   {
/* 230 */     Map<Wrapper<T>, MatchResult> candidates = new HashMap();
/*     */     
/* 232 */     int paramCount = paramTypes.length;
/*     */     
/* 234 */     for (Wrapper<T> w : wrappers) {
/* 235 */       Class<?>[] mParamTypes = w.getParameterTypes();
/*     */       int mParamCount;
/* 237 */       if (mParamTypes == null) {
/* 238 */         mParamCount = 0;
/*     */       } else {
/* 240 */         mParamCount = mParamTypes.length;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 245 */       if (((w.isVarArgs()) || (paramCount == mParamCount)) && 
/*     */       
/*     */ 
/*     */ 
/* 249 */         ((!w.isVarArgs()) || (paramCount >= mParamCount - 1)) && 
/*     */         
/*     */ 
/*     */ 
/* 253 */         ((!w.isVarArgs()) || (paramCount != mParamCount) || (paramValues == null) || (paramValues.length <= paramCount) || 
/* 254 */         (paramTypes[(mParamCount - 1)].isArray())) && 
/*     */         
/*     */ 
/*     */ 
/* 258 */         ((!w.isVarArgs()) || (paramCount <= mParamCount) || (paramValues == null) || (paramValues.length == paramCount)) && (
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 263 */         (w.isVarArgs()) || (paramValues == null) || (paramCount == paramValues.length)))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 269 */         int exactMatch = 0;
/* 270 */         int assignableMatch = 0;
/* 271 */         int coercibleMatch = 0;
/* 272 */         int varArgsMatch = 0;
/* 273 */         boolean noMatch = false;
/* 274 */         for (int i = 0; i < mParamCount; i++)
/*     */         {
/* 276 */           if ((w.isVarArgs()) && (i == mParamCount - 1)) {
/* 277 */             if ((i == paramCount) || ((paramValues != null) && (paramValues.length == i)))
/*     */             {
/*     */ 
/* 280 */               varArgsMatch = Integer.MAX_VALUE;
/* 281 */               break;
/*     */             }
/* 283 */             Class<?> varType = mParamTypes[i].getComponentType();
/* 284 */             for (int j = i; j < paramCount; j++) {
/* 285 */               if (isAssignableFrom(paramTypes[j], varType)) {
/* 286 */                 assignableMatch++;
/* 287 */                 varArgsMatch++;
/*     */               } else {
/* 289 */                 if (paramValues == null) {
/* 290 */                   noMatch = true;
/* 291 */                   break;
/*     */                 }
/* 293 */                 if (isCoercibleFrom(paramValues[j], varType)) {
/* 294 */                   coercibleMatch++;
/* 295 */                   varArgsMatch++;
/*     */                 } else {
/* 297 */                   noMatch = true;
/* 298 */                   break;
/*     */                 }
/*     */                 
/*     */               }
/*     */               
/*     */             }
/*     */             
/*     */ 
/*     */           }
/* 307 */           else if (mParamTypes[i].equals(paramTypes[i])) {
/* 308 */             exactMatch++;
/* 309 */           } else if ((paramTypes[i] != null) && (isAssignableFrom(paramTypes[i], mParamTypes[i]))) {
/* 310 */             assignableMatch++;
/*     */           } else {
/* 312 */             if (paramValues == null) {
/* 313 */               noMatch = true;
/* 314 */               break;
/*     */             }
/* 316 */             if (isCoercibleFrom(paramValues[i], mParamTypes[i])) {
/* 317 */               coercibleMatch++;
/*     */             } else {
/* 319 */               noMatch = true;
/* 320 */               break;
/*     */             }
/*     */           }
/*     */         }
/*     */         
/*     */ 
/* 326 */         if (!noMatch)
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 332 */           if ((exactMatch == paramCount) && (varArgsMatch == 0)) {
/* 333 */             return w;
/*     */           }
/*     */           
/* 336 */           candidates.put(w, new MatchResult(w
/* 337 */             .isVarArgs(), exactMatch, assignableMatch, coercibleMatch, varArgsMatch, w.isBridge()));
/*     */         }
/*     */       }
/*     */     }
/*     */     int mParamCount;
/* 342 */     MatchResult bestMatch = new MatchResult(true, 0, 0, 0, 0, true);
/* 343 */     Wrapper<T> match = null;
/* 344 */     boolean multiple = false;
/* 345 */     for (Map.Entry<Wrapper<T>, MatchResult> entry : candidates.entrySet()) {
/* 346 */       int cmp = ((MatchResult)entry.getValue()).compareTo(bestMatch);
/* 347 */       if ((cmp > 0) || (match == null)) {
/* 348 */         bestMatch = (MatchResult)entry.getValue();
/* 349 */         match = (Wrapper)entry.getKey();
/* 350 */         multiple = false;
/* 351 */       } else if (cmp == 0) {
/* 352 */         multiple = true;
/*     */       }
/*     */     }
/* 355 */     if (multiple) {
/* 356 */       if (bestMatch.getExactCount() == paramCount - 1)
/*     */       {
/*     */ 
/* 359 */         match = resolveAmbiguousWrapper(candidates.keySet(), paramTypes);
/*     */       } else {
/* 361 */         match = null;
/*     */       }
/*     */       
/* 364 */       if (match == null)
/*     */       {
/*     */ 
/* 367 */         throw new MethodNotFoundException(message(null, "util.method.ambiguous", new Object[] { clazz, name, 
/*     */         
/* 369 */           paramString(paramTypes) }));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 374 */     if (match == null) {
/* 375 */       throw new MethodNotFoundException(message(null, "util.method.notfound", new Object[] { clazz, name, 
/*     */       
/* 377 */         paramString(paramTypes) }));
/*     */     }
/*     */     
/* 380 */     return match;
/*     */   }
/*     */   
/*     */   private static final String paramString(Class<?>[] types)
/*     */   {
/* 385 */     if (types != null) {
/* 386 */       StringBuilder sb = new StringBuilder();
/* 387 */       for (Class<?> type : types) {
/* 388 */         if (type == null) {
/* 389 */           sb.append("null, ");
/*     */         } else {
/* 391 */           sb.append(type.getName()).append(", ");
/*     */         }
/*     */       }
/* 394 */       if (sb.length() > 2) {
/* 395 */         sb.setLength(sb.length() - 2);
/*     */       }
/* 397 */       return sb.toString();
/*     */     }
/* 399 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static <T> Wrapper<T> resolveAmbiguousWrapper(Set<Wrapper<T>> candidates, Class<?>[] paramTypes)
/*     */   {
/* 410 */     Wrapper<T> w = (Wrapper)candidates.iterator().next();
/*     */     
/* 412 */     int nonMatchIndex = 0;
/* 413 */     Class<?> nonMatchClass = null;
/*     */     
/* 415 */     for (int i = 0; i < paramTypes.length; i++) {
/* 416 */       if (w.getParameterTypes()[i] != paramTypes[i]) {
/* 417 */         nonMatchIndex = i;
/* 418 */         nonMatchClass = paramTypes[i];
/* 419 */         break;
/*     */       }
/*     */     }
/*     */     
/* 423 */     if (nonMatchClass == null)
/*     */     {
/* 425 */       return null;
/*     */     }
/*     */     
/* 428 */     for (i = candidates.iterator(); i.hasNext();) { c = (Wrapper)i.next();
/* 429 */       if (c.getParameterTypes()[nonMatchIndex] == paramTypes[nonMatchIndex])
/*     */       {
/*     */ 
/* 432 */         return null;
/*     */       }
/*     */     }
/*     */     
/*     */     Wrapper<T> c;
/* 437 */     Class<?> superClass = nonMatchClass.getSuperclass();
/* 438 */     Wrapper<T> c; while (superClass != null) {
/* 439 */       for (c = candidates.iterator(); c.hasNext();) { c = (Wrapper)c.next();
/* 440 */         if (c.getParameterTypes()[nonMatchIndex].equals(superClass))
/*     */         {
/* 442 */           return c;
/*     */         }
/*     */       }
/* 445 */       superClass = superClass.getSuperclass();
/*     */     }
/*     */     
/*     */ 
/* 449 */     Wrapper<T> match = null;
/* 450 */     if (Number.class.isAssignableFrom(nonMatchClass)) {
/* 451 */       for (Wrapper<T> c : candidates) {
/* 452 */         Class<?> candidateType = c.getParameterTypes()[nonMatchIndex];
/* 453 */         if ((Number.class.isAssignableFrom(candidateType)) || 
/* 454 */           (candidateType.isPrimitive())) {
/* 455 */           if (match == null) {
/* 456 */             match = c;
/*     */           }
/*     */           else {
/* 459 */             match = null;
/* 460 */             break;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 466 */     return match;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static boolean isAssignableFrom(Class<?> src, Class<?> target)
/*     */   {
/* 478 */     if (src == null) {
/* 479 */       return true;
/*     */     }
/*     */     Class<?> targetClass;
/*     */     Class<?> targetClass;
/* 483 */     if (target.isPrimitive()) { Class<?> targetClass;
/* 484 */       if (target == Boolean.TYPE) {
/* 485 */         targetClass = Boolean.class; } else { Class<?> targetClass;
/* 486 */         if (target == Character.TYPE) {
/* 487 */           targetClass = Character.class; } else { Class<?> targetClass;
/* 488 */           if (target == Byte.TYPE) {
/* 489 */             targetClass = Byte.class; } else { Class<?> targetClass;
/* 490 */             if (target == Short.TYPE) {
/* 491 */               targetClass = Short.class; } else { Class<?> targetClass;
/* 492 */               if (target == Integer.TYPE) {
/* 493 */                 targetClass = Integer.class; } else { Class<?> targetClass;
/* 494 */                 if (target == Long.TYPE) {
/* 495 */                   targetClass = Long.class; } else { Class<?> targetClass;
/* 496 */                   if (target == Float.TYPE) {
/* 497 */                     targetClass = Float.class;
/*     */                   } else
/* 499 */                     targetClass = Double.class;
/*     */                 }
/*     */               }
/* 502 */             } } } } } else { targetClass = target;
/*     */     }
/* 504 */     return targetClass.isAssignableFrom(src);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean isCoercibleFrom(Object src, Class<?> target)
/*     */   {
/*     */     try
/*     */     {
/* 516 */       getExpressionFactory().coerceToType(src, target);
/*     */     } catch (ELException e) {
/* 518 */       return false;
/*     */     }
/* 520 */     return true;
/*     */   }
/*     */   
/*     */   private static Class<?>[] getTypesFromValues(Object[] values)
/*     */   {
/* 525 */     if (values == null) {
/* 526 */       return EMPTY_CLASS_ARRAY;
/*     */     }
/*     */     
/* 529 */     Class<?>[] result = new Class[values.length];
/* 530 */     for (int i = 0; i < values.length; i++) {
/* 531 */       if (values[i] == null) {
/* 532 */         result[i] = null;
/*     */       } else {
/* 534 */         result[i] = values[i].getClass();
/*     */       }
/*     */     }
/* 537 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static Method getMethod(Class<?> type, Object base, Method m)
/*     */   {
/* 546 */     JreCompat jreCompat = JreCompat.getInstance();
/*     */     
/*     */ 
/* 549 */     if ((m == null) || (
/* 550 */       (Modifier.isPublic(type.getModifiers())) && (
/* 551 */       (jreCompat.canAccess(base, m)) || ((base != null) && (jreCompat.canAccess(null, m)))))) {
/* 552 */       return m;
/*     */     }
/* 554 */     Class<?>[] interfaces = type.getInterfaces();
/* 555 */     Method mp = null;
/* 556 */     for (Class<?> iface : interfaces) {
/*     */       try {
/* 558 */         mp = iface.getMethod(m.getName(), m.getParameterTypes());
/* 559 */         mp = getMethod(mp.getDeclaringClass(), base, mp);
/* 560 */         if (mp != null) {
/* 561 */           return mp;
/*     */         }
/*     */       }
/*     */       catch (NoSuchMethodException localNoSuchMethodException) {}
/*     */     }
/*     */     
/* 567 */     Object sup = type.getSuperclass();
/* 568 */     if (sup != null) {
/*     */       try {
/* 570 */         mp = ((Class)sup).getMethod(m.getName(), m.getParameterTypes());
/* 571 */         mp = getMethod(mp.getDeclaringClass(), base, mp);
/* 572 */         if (mp != null) {
/* 573 */           return mp;
/*     */         }
/*     */       }
/*     */       catch (NoSuchMethodException localNoSuchMethodException2) {}
/*     */     }
/*     */     
/* 579 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   static Constructor<?> findConstructor(Class<?> clazz, Class<?>[] paramTypes, Object[] paramValues)
/*     */   {
/* 586 */     String methodName = "<init>";
/*     */     
/* 588 */     if (clazz == null)
/*     */     {
/* 590 */       throw new MethodNotFoundException(message(null, "util.method.notfound", new Object[] { null, methodName, 
/* 591 */         paramString(paramTypes) }));
/*     */     }
/*     */     
/* 594 */     if (paramTypes == null) {
/* 595 */       paramTypes = getTypesFromValues(paramValues);
/*     */     }
/*     */     
/* 598 */     Constructor<?>[] constructors = clazz.getConstructors();
/*     */     
/* 600 */     List<Wrapper<Constructor<?>>> wrappers = Wrapper.wrap(constructors);
/*     */     
/* 602 */     Wrapper<Constructor<?>> wrapper = findWrapper(clazz, wrappers, methodName, paramTypes, paramValues);
/*     */     
/* 604 */     Constructor<?> constructor = (Constructor)wrapper.unWrap();
/*     */     
/* 606 */     JreCompat jreCompat = JreCompat.getInstance();
/* 607 */     if ((!Modifier.isPublic(clazz.getModifiers())) || (!jreCompat.canAccess(null, constructor))) {
/* 608 */       throw new MethodNotFoundException(message(null, "util.method.notfound", new Object[] { clazz, methodName, 
/*     */       
/* 610 */         paramString(paramTypes) }));
/*     */     }
/*     */     
/* 613 */     return constructor;
/*     */   }
/*     */   
/*     */ 
/*     */   static Object[] buildParameters(Class<?>[] parameterTypes, boolean isVarArgs, Object[] params)
/*     */   {
/* 619 */     ExpressionFactory factory = getExpressionFactory();
/* 620 */     Object[] parameters = null;
/* 621 */     if (parameterTypes.length > 0) {
/* 622 */       parameters = new Object[parameterTypes.length];
/*     */       
/* 624 */       if (params == null) {
/* 625 */         params = EMPTY_OBJECT_ARRAY;
/*     */       }
/* 627 */       int paramCount = params.length;
/* 628 */       if (isVarArgs) {
/* 629 */         int varArgIndex = parameterTypes.length - 1;
/*     */         
/* 631 */         for (int i = 0; i < varArgIndex; i++) {
/* 632 */           parameters[i] = factory.coerceToType(params[i], parameterTypes[i]);
/*     */         }
/*     */         
/*     */ 
/* 636 */         Class<?> varArgClass = parameterTypes[varArgIndex].getComponentType();
/* 637 */         Object varargs = Array.newInstance(varArgClass, paramCount - varArgIndex);
/* 638 */         for (int i = varArgIndex; i < paramCount; i++) {
/* 639 */           Array.set(varargs, i - varArgIndex, factory
/* 640 */             .coerceToType(params[i], varArgClass));
/*     */         }
/* 642 */         parameters[varArgIndex] = varargs;
/*     */       } else {
/* 644 */         parameters = new Object[parameterTypes.length];
/* 645 */         for (int i = 0; i < parameterTypes.length; i++) {
/* 646 */           parameters[i] = factory.coerceToType(params[i], parameterTypes[i]);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 651 */     return parameters;
/*     */   }
/*     */   
/*     */   static ClassLoader getContextClassLoader() {
/*     */     ClassLoader tccl;
/*     */     ClassLoader tccl;
/* 657 */     if (System.getSecurityManager() != null) {
/* 658 */       PrivilegedAction<ClassLoader> pa = new PrivilegedGetTccl(null);
/* 659 */       tccl = (ClassLoader)AccessController.doPrivileged(pa);
/*     */     } else {
/* 661 */       tccl = Thread.currentThread().getContextClassLoader();
/*     */     }
/*     */     
/* 664 */     return tccl;
/*     */   }
/*     */   
/*     */   private static abstract class Wrapper<T>
/*     */   {
/*     */     public static List<Wrapper<Method>> wrap(Method[] methods, String name)
/*     */     {
/* 671 */       List<Wrapper<Method>> result = new ArrayList();
/* 672 */       for (Method method : methods) {
/* 673 */         if (method.getName().equals(name)) {
/* 674 */           result.add(new Util.MethodWrapper(method));
/*     */         }
/*     */       }
/* 677 */       return result;
/*     */     }
/*     */     
/*     */     public static List<Wrapper<Constructor<?>>> wrap(Constructor<?>[] constructors) {
/* 681 */       List<Wrapper<Constructor<?>>> result = new ArrayList();
/* 682 */       for (Constructor<?> constructor : constructors) {
/* 683 */         result.add(new Util.ConstructorWrapper(constructor));
/*     */       }
/* 685 */       return result;
/*     */     }
/*     */     
/*     */     public abstract T unWrap();
/*     */     
/*     */     public abstract Class<?>[] getParameterTypes();
/*     */     
/*     */     public abstract boolean isVarArgs();
/*     */     
/*     */     public abstract boolean isBridge(); }
/*     */   
/*     */   private static class MethodWrapper extends Util.Wrapper<Method> { private final Method m;
/*     */     
/* 698 */     public MethodWrapper(Method m) { super();
/* 699 */       this.m = m;
/*     */     }
/*     */     
/*     */     public Method unWrap()
/*     */     {
/* 704 */       return this.m;
/*     */     }
/*     */     
/*     */     public Class<?>[] getParameterTypes()
/*     */     {
/* 709 */       return this.m.getParameterTypes();
/*     */     }
/*     */     
/*     */     public boolean isVarArgs()
/*     */     {
/* 714 */       return this.m.isVarArgs();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 719 */     public boolean isBridge() { return this.m.isBridge(); }
/*     */   }
/*     */   
/*     */   private static class ConstructorWrapper extends Util.Wrapper<Constructor<?>> {
/*     */     private final Constructor<?> c;
/*     */     
/*     */     public ConstructorWrapper(Constructor<?> c) {
/* 726 */       super();
/* 727 */       this.c = c;
/*     */     }
/*     */     
/*     */     public Constructor<?> unWrap()
/*     */     {
/* 732 */       return this.c;
/*     */     }
/*     */     
/*     */     public Class<?>[] getParameterTypes()
/*     */     {
/* 737 */       return this.c.getParameterTypes();
/*     */     }
/*     */     
/*     */     public boolean isVarArgs()
/*     */     {
/* 742 */       return this.c.isVarArgs();
/*     */     }
/*     */     
/*     */     public boolean isBridge()
/*     */     {
/* 747 */       return false;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static class MatchResult
/*     */     implements Comparable<MatchResult>
/*     */   {
/*     */     private final boolean varArgs;
/*     */     
/*     */     private final int exactCount;
/*     */     
/*     */     private final int assignableCount;
/*     */     private final int coercibleCount;
/*     */     private final int varArgsCount;
/*     */     private final boolean bridge;
/*     */     
/*     */     public MatchResult(boolean varArgs, int exactCount, int assignableCount, int coercibleCount, int varArgsCount, boolean bridge)
/*     */     {
/* 766 */       this.varArgs = varArgs;
/* 767 */       this.exactCount = exactCount;
/* 768 */       this.assignableCount = assignableCount;
/* 769 */       this.coercibleCount = coercibleCount;
/* 770 */       this.varArgsCount = varArgsCount;
/* 771 */       this.bridge = bridge;
/*     */     }
/*     */     
/*     */     public boolean isVarArgs() {
/* 775 */       return this.varArgs;
/*     */     }
/*     */     
/*     */     public int getExactCount() {
/* 779 */       return this.exactCount;
/*     */     }
/*     */     
/*     */     public int getAssignableCount() {
/* 783 */       return this.assignableCount;
/*     */     }
/*     */     
/*     */     public int getCoercibleCount() {
/* 787 */       return this.coercibleCount;
/*     */     }
/*     */     
/*     */     public int getVarArgsCount() {
/* 791 */       return this.varArgsCount;
/*     */     }
/*     */     
/*     */     public boolean isBridge() {
/* 795 */       return this.bridge;
/*     */     }
/*     */     
/*     */ 
/*     */     public int compareTo(MatchResult o)
/*     */     {
/* 801 */       int cmp = Boolean.compare(o.isVarArgs(), isVarArgs());
/* 802 */       if (cmp == 0) {
/* 803 */         cmp = Integer.compare(getExactCount(), o.getExactCount());
/* 804 */         if (cmp == 0) {
/* 805 */           cmp = Integer.compare(getAssignableCount(), o.getAssignableCount());
/* 806 */           if (cmp == 0) {
/* 807 */             cmp = Integer.compare(getCoercibleCount(), o.getCoercibleCount());
/* 808 */             if (cmp == 0)
/*     */             {
/* 810 */               cmp = Integer.compare(o.getVarArgsCount(), getVarArgsCount());
/* 811 */               if (cmp == 0)
/*     */               {
/*     */ 
/*     */ 
/*     */ 
/* 816 */                 cmp = Boolean.compare(o.isBridge(), isBridge());
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/* 822 */       return cmp;
/*     */     }
/*     */     
/*     */     public boolean equals(Object o)
/*     */     {
/* 827 */       return (o == this) || ((null != o) && 
/* 828 */         (getClass().equals(o.getClass())) && 
/* 829 */         (((MatchResult)o).getExactCount() == getExactCount()) && 
/* 830 */         (((MatchResult)o).getAssignableCount() == getAssignableCount()) && 
/* 831 */         (((MatchResult)o).getCoercibleCount() == getCoercibleCount()) && 
/* 832 */         (((MatchResult)o).getVarArgsCount() == getVarArgsCount()) && 
/* 833 */         (((MatchResult)o).isVarArgs() == isVarArgs()) && 
/* 834 */         (((MatchResult)o).isBridge() == isBridge()));
/*     */     }
/*     */     
/*     */     public int hashCode()
/*     */     {
/* 839 */       int prime = 31;
/* 840 */       int result = 1;
/* 841 */       result = 31 * result + this.assignableCount;
/* 842 */       result = 31 * result + (this.bridge ? 1231 : 1237);
/* 843 */       result = 31 * result + this.coercibleCount;
/* 844 */       result = 31 * result + this.exactCount;
/* 845 */       result = 31 * result + (this.varArgs ? 1231 : 1237);
/* 846 */       result = 31 * result + this.varArgsCount;
/* 847 */       return result;
/*     */     }
/*     */   }
/*     */   
/*     */   private static class PrivilegedGetTccl implements PrivilegedAction<ClassLoader>
/*     */   {
/*     */     public ClassLoader run()
/*     */     {
/* 855 */       return Thread.currentThread().getContextClassLoader();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-el-9.0.54.jar!\javax\el\Util.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */