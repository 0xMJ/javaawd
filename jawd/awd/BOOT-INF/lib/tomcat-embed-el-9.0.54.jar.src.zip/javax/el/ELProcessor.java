/*     */ package javax.el;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ELProcessor
/*     */ {
/*  29 */   private static final Set<String> PRIMITIVES = new HashSet();
/*     */   
/*  31 */   static { PRIMITIVES.add("boolean");
/*  32 */     PRIMITIVES.add("byte");
/*  33 */     PRIMITIVES.add("char");
/*  34 */     PRIMITIVES.add("double");
/*  35 */     PRIMITIVES.add("float");
/*  36 */     PRIMITIVES.add("int");
/*  37 */     PRIMITIVES.add("long");
/*  38 */     PRIMITIVES.add("short");
/*     */   }
/*     */   
/*  41 */   private static final String[] EMPTY_STRING_ARRAY = new String[0];
/*     */   
/*  43 */   private final ELManager manager = new ELManager();
/*  44 */   private final ELContext context = this.manager.getELContext();
/*  45 */   private final ExpressionFactory factory = ELManager.getExpressionFactory();
/*     */   
/*     */   public ELManager getELManager()
/*     */   {
/*  49 */     return this.manager;
/*     */   }
/*     */   
/*     */   public Object eval(String expression)
/*     */   {
/*  54 */     return getValue(expression, Object.class);
/*     */   }
/*     */   
/*     */   public Object getValue(String expression, Class<?> expectedType)
/*     */   {
/*  59 */     ValueExpression ve = this.factory.createValueExpression(this.context, 
/*  60 */       bracket(expression), expectedType);
/*  61 */     return ve.getValue(this.context);
/*     */   }
/*     */   
/*     */   public void setValue(String expression, Object value)
/*     */   {
/*  66 */     ValueExpression ve = this.factory.createValueExpression(this.context, 
/*  67 */       bracket(expression), Object.class);
/*  68 */     ve.setValue(this.context, value);
/*     */   }
/*     */   
/*     */   public void setVariable(String variable, String expression)
/*     */   {
/*  73 */     if (expression == null) {
/*  74 */       this.manager.setVariable(variable, null);
/*     */     } else {
/*  76 */       ValueExpression ve = this.factory.createValueExpression(this.context, 
/*  77 */         bracket(expression), Object.class);
/*  78 */       this.manager.setVariable(variable, ve);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void defineFunction(String prefix, String function, String className, String methodName)
/*     */     throws ClassNotFoundException, NoSuchMethodException
/*     */   {
/*  87 */     if ((prefix == null) || (function == null) || (className == null) || (methodName == null))
/*     */     {
/*  89 */       throw new NullPointerException(Util.message(this.context, "elProcessor.defineFunctionNullParams", new Object[0]));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  94 */     Class<?> clazz = this.context.getImportHandler().resolveClass(className);
/*     */     
/*  96 */     if (clazz == null) {
/*  97 */       clazz = Class.forName(className, true, Util.getContextClassLoader());
/*     */     }
/*     */     
/* 100 */     if (!Modifier.isPublic(clazz.getModifiers())) {
/* 101 */       throw new ClassNotFoundException(Util.message(this.context, "elProcessor.defineFunctionInvalidClass", new Object[] { className }));
/*     */     }
/*     */     
/*     */ 
/* 105 */     MethodSignature sig = new MethodSignature(this.context, methodName, className);
/*     */     
/*     */ 
/* 108 */     if (function.length() == 0) {
/* 109 */       function = sig.getName();
/*     */     }
/*     */     
/*     */ 
/* 113 */     Method[] methods = clazz.getMethods();
/* 114 */     JreCompat jreCompat = JreCompat.getInstance();
/*     */     
/* 116 */     for (Method method : methods) {
/* 117 */       if (Modifier.isStatic(method.getModifiers()))
/*     */       {
/*     */ 
/* 120 */         if (jreCompat.canAccess(null, method))
/*     */         {
/*     */ 
/* 123 */           if (method.getName().equals(sig.getName())) {
/* 124 */             if (sig.getParamTypeNames() == null)
/*     */             {
/*     */ 
/* 127 */               this.manager.mapFunction(prefix, function, method);
/* 128 */               return;
/*     */             }
/* 130 */             if (sig.getParamTypeNames().length == method.getParameterTypes().length)
/*     */             {
/*     */ 
/* 133 */               if (sig.getParamTypeNames().length == 0) {
/* 134 */                 this.manager.mapFunction(prefix, function, method);
/* 135 */                 return;
/*     */               }
/* 137 */               Class<?>[] types = method.getParameterTypes();
/* 138 */               String[] typeNames = sig.getParamTypeNames();
/* 139 */               if (types.length == typeNames.length) {
/* 140 */                 boolean match = true;
/* 141 */                 for (int i = 0; i < types.length; i++) {
/* 142 */                   if ((i == types.length - 1) && (method.isVarArgs())) {
/* 143 */                     String typeName = typeNames[i];
/* 144 */                     if (typeName.endsWith("...")) {
/* 145 */                       typeName = typeName.substring(0, typeName.length() - 3);
/* 146 */                       if (!typeName.equals(types[i].getName())) {
/* 147 */                         match = false;
/*     */                       }
/*     */                     } else {
/* 150 */                       match = false;
/*     */                     }
/* 152 */                   } else if (!types[i].getName().equals(typeNames[i])) {
/* 153 */                     match = false;
/* 154 */                     break;
/*     */                   }
/*     */                 }
/* 157 */                 if (match) {
/* 158 */                   this.manager.mapFunction(prefix, function, method);
/* 159 */                   return;
/*     */                 }
/*     */               }
/*     */             }
/*     */           } }
/*     */       }
/*     */     }
/* 166 */     throw new NoSuchMethodException(Util.message(this.context, "elProcessor.defineFunctionNoMethod", new Object[] { methodName, className }));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void defineFunction(String prefix, String function, Method method)
/*     */     throws NoSuchMethodException
/*     */   {
/* 186 */     if ((prefix == null) || (function == null) || (method == null)) {
/* 187 */       throw new NullPointerException(Util.message(this.context, "elProcessor.defineFunctionNullParams", new Object[0]));
/*     */     }
/*     */     
/*     */ 
/* 191 */     int modifiers = method.getModifiers();
/*     */     
/*     */ 
/* 194 */     JreCompat jreCompat = JreCompat.getInstance();
/* 195 */     if ((!Modifier.isStatic(modifiers)) || (!jreCompat.canAccess(null, method))) {
/* 196 */       throw new NoSuchMethodException(Util.message(this.context, "elProcessor.defineFunctionInvalidMethod", new Object[] {method
/* 197 */         .getName(), method
/* 198 */         .getDeclaringClass().getName() }));
/*     */     }
/*     */     
/* 201 */     this.manager.mapFunction(prefix, function, method);
/*     */   }
/*     */   
/*     */   public void defineBean(String name, Object bean)
/*     */   {
/* 206 */     this.manager.defineBean(name, bean);
/*     */   }
/*     */   
/*     */   private static String bracket(String expression)
/*     */   {
/* 211 */     return "${" + expression + "}";
/*     */   }
/*     */   
/*     */   private static class MethodSignature
/*     */   {
/*     */     private final String name;
/*     */     private final String[] parameterTypeNames;
/*     */     
/*     */     public MethodSignature(ELContext context, String methodName, String className)
/*     */       throws NoSuchMethodException
/*     */     {
/* 222 */       int paramIndex = methodName.indexOf('(');
/*     */       
/* 224 */       if (paramIndex == -1) {
/* 225 */         this.name = methodName.trim();
/* 226 */         this.parameterTypeNames = null;
/*     */       } else {
/* 228 */         String returnTypeAndName = methodName.substring(0, paramIndex).trim();
/*     */         
/*     */ 
/*     */ 
/* 232 */         int wsPos = -1;
/* 233 */         for (int i = 0; i < returnTypeAndName.length(); i++) {
/* 234 */           if (Character.isWhitespace(returnTypeAndName.charAt(i))) {
/* 235 */             wsPos = i;
/* 236 */             break;
/*     */           }
/*     */         }
/* 239 */         if (wsPos == -1) {
/* 240 */           throw new NoSuchMethodException();
/*     */         }
/* 242 */         this.name = returnTypeAndName.substring(wsPos).trim();
/*     */         
/* 244 */         String paramString = methodName.substring(paramIndex).trim();
/*     */         
/* 246 */         if (!paramString.endsWith(")")) {
/* 247 */           throw new NoSuchMethodException(Util.message(context, "elProcessor.defineFunctionInvalidParameterList", new Object[] { paramString, methodName, className }));
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 252 */         paramString = paramString.substring(1, paramString.length() - 1).trim();
/* 253 */         if (paramString.length() == 0) {
/* 254 */           this.parameterTypeNames = ELProcessor.EMPTY_STRING_ARRAY;
/*     */         } else {
/* 256 */           this.parameterTypeNames = paramString.split(",");
/* 257 */           ImportHandler importHandler = context.getImportHandler();
/* 258 */           for (int i = 0; i < this.parameterTypeNames.length; i++) {
/* 259 */             String parameterTypeName = this.parameterTypeNames[i].trim();
/* 260 */             int dimension = 0;
/* 261 */             int bracketPos = parameterTypeName.indexOf('[');
/* 262 */             if (bracketPos > -1)
/*     */             {
/* 264 */               String parameterTypeNameOnly = parameterTypeName.substring(0, bracketPos).trim();
/* 265 */               while (bracketPos > -1) {
/* 266 */                 dimension++;
/* 267 */                 bracketPos = parameterTypeName.indexOf('[', bracketPos + 1);
/*     */               }
/* 269 */               parameterTypeName = parameterTypeNameOnly;
/*     */             }
/* 271 */             boolean varArgs = false;
/* 272 */             if (parameterTypeName.endsWith("...")) {
/* 273 */               varArgs = true;
/* 274 */               dimension = 1;
/*     */               
/* 276 */               parameterTypeName = parameterTypeName.substring(0, parameterTypeName.length() - 3).trim();
/*     */             }
/* 278 */             boolean isPrimitive = ELProcessor.PRIMITIVES.contains(parameterTypeName);
/* 279 */             if ((isPrimitive) && (dimension > 0))
/*     */             {
/* 281 */               switch (parameterTypeName)
/*     */               {
/*     */               case "boolean": 
/* 284 */                 parameterTypeName = "Z";
/* 285 */                 break;
/*     */               case "byte": 
/* 287 */                 parameterTypeName = "B";
/* 288 */                 break;
/*     */               case "char": 
/* 290 */                 parameterTypeName = "C";
/* 291 */                 break;
/*     */               case "double": 
/* 293 */                 parameterTypeName = "D";
/* 294 */                 break;
/*     */               case "float": 
/* 296 */                 parameterTypeName = "F";
/* 297 */                 break;
/*     */               case "int": 
/* 299 */                 parameterTypeName = "I";
/* 300 */                 break;
/*     */               case "long": 
/* 302 */                 parameterTypeName = "J";
/* 303 */                 break;
/*     */               case "short": 
/* 305 */                 parameterTypeName = "S";
/* 306 */                 break;
/*     */               
/*     */               }
/*     */               
/*     */             }
/* 311 */             else if ((!isPrimitive) && 
/* 312 */               (!parameterTypeName.contains("."))) {
/* 313 */               Object clazz = importHandler.resolveClass(parameterTypeName);
/*     */               
/* 315 */               if (clazz == null) {
/* 316 */                 throw new NoSuchMethodException(Util.message(context, "elProcessor.defineFunctionInvalidParameterTypeName", new Object[] { this.parameterTypeNames[i], methodName, className }));
/*     */               }
/*     */               
/*     */ 
/*     */ 
/*     */ 
/* 322 */               parameterTypeName = ((Class)clazz).getName();
/*     */             }
/* 324 */             if (dimension > 0)
/*     */             {
/* 326 */               StringBuilder sb = new StringBuilder();
/* 327 */               for (int j = 0; j < dimension; j++) {
/* 328 */                 sb.append('[');
/*     */               }
/* 330 */               if (!isPrimitive) {
/* 331 */                 sb.append('L');
/*     */               }
/* 333 */               sb.append(parameterTypeName);
/* 334 */               if (!isPrimitive) {
/* 335 */                 sb.append(';');
/*     */               }
/* 337 */               parameterTypeName = sb.toString();
/*     */             }
/* 339 */             if (varArgs) {
/* 340 */               parameterTypeName = parameterTypeName + "...";
/*     */             }
/* 342 */             this.parameterTypeNames[i] = parameterTypeName;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     public String getName()
/*     */     {
/* 350 */       return this.name;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String[] getParamTypeNames()
/*     */     {
/* 359 */       return this.parameterTypeNames;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-el-9.0.54.jar!\javax\el\ELProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */