/*     */ package javax.el;
/*     */ 
/*     */ import java.beans.FeatureDescriptor;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MapELResolver
/*     */   extends ELResolver
/*     */ {
/*  31 */   private static final Class<?> UNMODIFIABLE = Collections.unmodifiableMap(new HashMap()).getClass();
/*     */   private final boolean readOnly;
/*     */   
/*     */   public MapELResolver()
/*     */   {
/*  36 */     this.readOnly = false;
/*     */   }
/*     */   
/*     */   public MapELResolver(boolean readOnly) {
/*  40 */     this.readOnly = readOnly;
/*     */   }
/*     */   
/*     */   public Class<?> getType(ELContext context, Object base, Object property)
/*     */   {
/*  45 */     Objects.requireNonNull(context);
/*     */     
/*  47 */     if ((base instanceof Map)) {
/*  48 */       context.setPropertyResolved(base, property);
/*  49 */       return Object.class;
/*     */     }
/*     */     
/*  52 */     return null;
/*     */   }
/*     */   
/*     */   public Object getValue(ELContext context, Object base, Object property)
/*     */   {
/*  57 */     Objects.requireNonNull(context);
/*     */     
/*  59 */     if ((base instanceof Map)) {
/*  60 */       context.setPropertyResolved(base, property);
/*  61 */       return ((Map)base).get(property);
/*     */     }
/*     */     
/*  64 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setValue(ELContext context, Object base, Object property, Object value)
/*     */   {
/*  70 */     Objects.requireNonNull(context);
/*     */     
/*  72 */     if ((base instanceof Map)) {
/*  73 */       context.setPropertyResolved(base, property);
/*     */       
/*  75 */       if (this.readOnly) {
/*  76 */         throw new PropertyNotWritableException(Util.message(context, "resolverNotWriteable", new Object[] {base
/*  77 */           .getClass().getName() }));
/*     */       }
/*     */       
/*     */       try
/*     */       {
/*  82 */         Map<Object, Object> map = (Map)base;
/*  83 */         map.put(property, value);
/*     */       } catch (UnsupportedOperationException e) {
/*  85 */         throw new PropertyNotWritableException(e);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isReadOnly(ELContext context, Object base, Object property)
/*     */   {
/*  92 */     Objects.requireNonNull(context);
/*     */     
/*  94 */     if ((base instanceof Map)) {
/*  95 */       context.setPropertyResolved(base, property);
/*  96 */       return (this.readOnly) || (UNMODIFIABLE.equals(base.getClass()));
/*     */     }
/*     */     
/*  99 */     return this.readOnly;
/*     */   }
/*     */   
/*     */   public Iterator<FeatureDescriptor> getFeatureDescriptors(ELContext context, Object base)
/*     */   {
/* 104 */     if ((base instanceof Map)) {
/* 105 */       Iterator<?> itr = ((Map)base).keySet().iterator();
/* 106 */       List<FeatureDescriptor> feats = new ArrayList();
/*     */       
/*     */ 
/* 109 */       while (itr.hasNext()) {
/* 110 */         Object key = itr.next();
/* 111 */         FeatureDescriptor desc = new FeatureDescriptor();
/* 112 */         desc.setDisplayName(key.toString());
/* 113 */         desc.setShortDescription("");
/* 114 */         desc.setExpert(false);
/* 115 */         desc.setHidden(false);
/* 116 */         desc.setName(key.toString());
/* 117 */         desc.setPreferred(true);
/* 118 */         desc.setValue("resolvableAtDesignTime", Boolean.TRUE);
/* 119 */         desc.setValue("type", key.getClass());
/* 120 */         feats.add(desc);
/*     */       }
/* 122 */       return feats.iterator();
/*     */     }
/* 124 */     return null;
/*     */   }
/*     */   
/*     */   public Class<?> getCommonPropertyType(ELContext context, Object base)
/*     */   {
/* 129 */     if ((base instanceof Map)) {
/* 130 */       return Object.class;
/*     */     }
/* 132 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-el-9.0.54.jar!\javax\el\MapELResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */