/*    */ package org.apache.el;
/*    */ 
/*    */ import aQute.bnd.annotation.spi.ServiceProvider;
/*    */ import javax.el.ELContext;
/*    */ import javax.el.ELResolver;
/*    */ import javax.el.ExpressionFactory;
/*    */ import javax.el.MethodExpression;
/*    */ import javax.el.ValueExpression;
/*    */ import org.apache.el.lang.ELSupport;
/*    */ import org.apache.el.lang.ExpressionBuilder;
/*    */ import org.apache.el.stream.StreamELResolverImpl;
/*    */ import org.apache.el.util.MessageFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @ServiceProvider(ExpressionFactory.class)
/*    */ public class ExpressionFactoryImpl
/*    */   extends ExpressionFactory
/*    */ {
/*    */   public Object coerceToType(Object obj, Class<?> type)
/*    */   {
/* 41 */     return ELSupport.coerceToType(null, obj, type);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public MethodExpression createMethodExpression(ELContext context, String expression, Class<?> expectedReturnType, Class<?>[] expectedParamTypes)
/*    */   {
/* 48 */     ExpressionBuilder builder = new ExpressionBuilder(expression, context);
/* 49 */     return builder.createMethodExpression(expectedReturnType, expectedParamTypes);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public ValueExpression createValueExpression(ELContext context, String expression, Class<?> expectedType)
/*    */   {
/* 56 */     if (expectedType == null)
/*    */     {
/* 58 */       throw new NullPointerException(MessageFactory.get("error.value.expectedType"));
/*    */     }
/* 60 */     ExpressionBuilder builder = new ExpressionBuilder(expression, context);
/* 61 */     return builder.createValueExpression(expectedType);
/*    */   }
/*    */   
/*    */ 
/*    */   public ValueExpression createValueExpression(Object instance, Class<?> expectedType)
/*    */   {
/* 67 */     if (expectedType == null)
/*    */     {
/* 69 */       throw new NullPointerException(MessageFactory.get("error.value.expectedType"));
/*    */     }
/* 71 */     return new ValueExpressionLiteral(instance, expectedType);
/*    */   }
/*    */   
/*    */   public ELResolver getStreamELResolver()
/*    */   {
/* 76 */     return new StreamELResolverImpl();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-el-9.0.54.jar!\org\apache\el\ExpressionFactoryImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */