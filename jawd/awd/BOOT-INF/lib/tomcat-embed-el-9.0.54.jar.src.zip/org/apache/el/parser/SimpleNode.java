/*     */ package org.apache.el.parser;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import javax.el.ELException;
/*     */ import javax.el.MethodInfo;
/*     */ import javax.el.PropertyNotWritableException;
/*     */ import javax.el.ValueReference;
/*     */ import org.apache.el.lang.ELSupport;
/*     */ import org.apache.el.lang.EvaluationContext;
/*     */ import org.apache.el.util.MessageFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SimpleNode
/*     */   extends ELSupport
/*     */   implements Node
/*     */ {
/*     */   protected Node parent;
/*     */   protected Node[] children;
/*     */   protected final int id;
/*     */   protected String image;
/*     */   
/*     */   public SimpleNode(int i)
/*     */   {
/*  45 */     this.id = i;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void jjtOpen() {}
/*     */   
/*     */ 
/*     */ 
/*     */   public void jjtClose() {}
/*     */   
/*     */ 
/*     */ 
/*     */   public void jjtSetParent(Node n)
/*     */   {
/*  60 */     this.parent = n;
/*     */   }
/*     */   
/*     */   public Node jjtGetParent()
/*     */   {
/*  65 */     return this.parent;
/*     */   }
/*     */   
/*     */   public void jjtAddChild(Node n, int i)
/*     */   {
/*  70 */     if (this.children == null) {
/*  71 */       this.children = new Node[i + 1];
/*  72 */     } else if (i >= this.children.length) {
/*  73 */       Node[] c = new Node[i + 1];
/*  74 */       System.arraycopy(this.children, 0, c, 0, this.children.length);
/*  75 */       this.children = c;
/*     */     }
/*  77 */     this.children[i] = n;
/*     */   }
/*     */   
/*     */   public Node jjtGetChild(int i)
/*     */   {
/*  82 */     return this.children[i];
/*     */   }
/*     */   
/*     */   public int jjtGetNumChildren()
/*     */   {
/*  87 */     return this.children == null ? 0 : this.children.length;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/*  99 */     if (this.image != null) {
/* 100 */       return ELParserTreeConstants.jjtNodeName[this.id] + "[" + this.image + "]";
/*     */     }
/*     */     
/* 103 */     return ELParserTreeConstants.jjtNodeName[this.id];
/*     */   }
/*     */   
/*     */   public String getImage()
/*     */   {
/* 108 */     return this.image;
/*     */   }
/*     */   
/*     */   public void setImage(String image) {
/* 112 */     this.image = image;
/*     */   }
/*     */   
/*     */   public Class<?> getType(EvaluationContext ctx)
/*     */     throws ELException
/*     */   {
/* 118 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public Object getValue(EvaluationContext ctx)
/*     */     throws ELException
/*     */   {
/* 124 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public boolean isReadOnly(EvaluationContext ctx)
/*     */     throws ELException
/*     */   {
/* 130 */     return true;
/*     */   }
/*     */   
/*     */   public void setValue(EvaluationContext ctx, Object value)
/*     */     throws ELException
/*     */   {
/* 136 */     throw new PropertyNotWritableException(MessageFactory.get("error.syntax.set"));
/*     */   }
/*     */   
/*     */   public void accept(NodeVisitor visitor) throws Exception
/*     */   {
/* 141 */     visitor.visit(this);
/* 142 */     if ((this.children != null) && (this.children.length > 0)) {
/* 143 */       for (Node child : this.children) {
/* 144 */         child.accept(visitor);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public Object invoke(EvaluationContext ctx, Class<?>[] paramTypes, Object[] paramValues)
/*     */     throws ELException
/*     */   {
/* 152 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public MethodInfo getMethodInfo(EvaluationContext ctx, Class<?>[] paramTypes)
/*     */     throws ELException
/*     */   {
/* 158 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 164 */     int prime = 31;
/* 165 */     int result = 1;
/* 166 */     result = 31 * result + Arrays.hashCode(this.children);
/* 167 */     result = 31 * result + this.id;
/* 168 */     result = 31 * result + (this.image == null ? 0 : this.image.hashCode());
/* 169 */     return result;
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/* 174 */     if (this == obj) {
/* 175 */       return true;
/*     */     }
/* 177 */     if (!(obj instanceof SimpleNode)) {
/* 178 */       return false;
/*     */     }
/* 180 */     SimpleNode other = (SimpleNode)obj;
/* 181 */     if (this.id != other.id) {
/* 182 */       return false;
/*     */     }
/* 184 */     if (this.image == null) {
/* 185 */       if (other.image != null) {
/* 186 */         return false;
/*     */       }
/* 188 */     } else if (!this.image.equals(other.image)) {
/* 189 */       return false;
/*     */     }
/* 191 */     if (!Arrays.equals(this.children, other.children)) {
/* 192 */       return false;
/*     */     }
/* 194 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ValueReference getValueReference(EvaluationContext ctx)
/*     */   {
/* 202 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isParametersProvided()
/*     */   {
/* 210 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-el-9.0.54.jar!\org\apache\el\parser\SimpleNode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */