/*    */ package org.apache.el.util;
/*    */ 
/*    */ import java.lang.reflect.AccessibleObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JreCompat
/*    */ {
/*    */   private static final JreCompat instance;
/*    */   
/*    */   static
/*    */   {
/* 33 */     if (Jre9Compat.isSupported()) {
/* 34 */       instance = new Jre9Compat();
/*    */     } else {
/* 36 */       instance = new JreCompat();
/*    */     }
/*    */   }
/*    */   
/*    */   public static JreCompat getInstance()
/*    */   {
/* 42 */     return instance;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean canAccess(Object base, AccessibleObject accessibleObject)
/*    */   {
/* 58 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-el-9.0.54.jar!\org\apache\el\util\JreCompat.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */