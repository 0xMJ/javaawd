/*    */ package org.apache.el.parser;
/*    */ 
/*    */ import javax.el.ELException;
/*    */ import org.apache.el.lang.EvaluationContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AstGreaterThan
/*    */   extends BooleanNode
/*    */ {
/*    */   public AstGreaterThan(int id)
/*    */   {
/* 30 */     super(id);
/*    */   }
/*    */   
/*    */   public Object getValue(EvaluationContext ctx)
/*    */     throws ELException
/*    */   {
/* 36 */     Object obj0 = this.children[0].getValue(ctx);
/* 37 */     if (obj0 == null) {
/* 38 */       return Boolean.FALSE;
/*    */     }
/* 40 */     Object obj1 = this.children[1].getValue(ctx);
/* 41 */     if (obj1 == null) {
/* 42 */       return Boolean.FALSE;
/*    */     }
/* 44 */     return compare(ctx, obj0, obj1) > 0 ? Boolean.TRUE : Boolean.FALSE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-el-9.0.54.jar!\org\apache\el\parser\AstGreaterThan.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */