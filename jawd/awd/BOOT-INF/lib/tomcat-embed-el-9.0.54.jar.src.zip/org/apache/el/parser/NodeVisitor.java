package org.apache.el.parser;

public abstract interface NodeVisitor
{
  public abstract void visit(Node paramNode)
    throws Exception;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-el-9.0.54.jar!\org\apache\el\parser\NodeVisitor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */