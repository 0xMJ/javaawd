/*    */ package org.apache.el.parser;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.Map;
/*    */ import javax.el.ELException;
/*    */ import org.apache.el.lang.EvaluationContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AstEmpty
/*    */   extends SimpleNode
/*    */ {
/*    */   public AstEmpty(int id)
/*    */   {
/* 33 */     super(id);
/*    */   }
/*    */   
/*    */   public Class<?> getType(EvaluationContext ctx)
/*    */     throws ELException
/*    */   {
/* 39 */     return Boolean.class;
/*    */   }
/*    */   
/*    */   public Object getValue(EvaluationContext ctx)
/*    */     throws ELException
/*    */   {
/* 45 */     Object obj = this.children[0].getValue(ctx);
/* 46 */     if (obj == null)
/* 47 */       return Boolean.TRUE;
/* 48 */     if ((obj instanceof String))
/* 49 */       return Boolean.valueOf(((String)obj).length() == 0);
/* 50 */     if ((obj instanceof Object[]))
/* 51 */       return Boolean.valueOf(((Object[])obj).length == 0);
/* 52 */     if ((obj instanceof Collection))
/* 53 */       return Boolean.valueOf(((Collection)obj).isEmpty());
/* 54 */     if ((obj instanceof Map)) {
/* 55 */       return Boolean.valueOf(((Map)obj).isEmpty());
/*    */     }
/* 57 */     return Boolean.FALSE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-el-9.0.54.jar!\org\apache\el\parser\AstEmpty.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */