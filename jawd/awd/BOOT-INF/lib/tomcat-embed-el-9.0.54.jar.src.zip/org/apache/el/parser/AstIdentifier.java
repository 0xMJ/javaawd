/*     */ package org.apache.el.parser;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ import javax.el.ELClass;
/*     */ import javax.el.ELException;
/*     */ import javax.el.ELResolver;
/*     */ import javax.el.ImportHandler;
/*     */ import javax.el.MethodExpression;
/*     */ import javax.el.MethodInfo;
/*     */ import javax.el.MethodNotFoundException;
/*     */ import javax.el.PropertyNotFoundException;
/*     */ import javax.el.ValueExpression;
/*     */ import javax.el.ValueReference;
/*     */ import javax.el.VariableMapper;
/*     */ import org.apache.el.lang.EvaluationContext;
/*     */ import org.apache.el.util.MessageFactory;
/*     */ import org.apache.el.util.Validation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AstIdentifier
/*     */   extends SimpleNode
/*     */ {
/*     */   public AstIdentifier(int id)
/*     */   {
/*  40 */     super(id);
/*     */   }
/*     */   
/*     */   public Class<?> getType(EvaluationContext ctx) throws ELException
/*     */   {
/*  45 */     VariableMapper varMapper = ctx.getVariableMapper();
/*  46 */     if (varMapper != null) {
/*  47 */       ValueExpression expr = varMapper.resolveVariable(this.image);
/*  48 */       if (expr != null) {
/*  49 */         return expr.getType(ctx.getELContext());
/*     */       }
/*     */     }
/*  52 */     ctx.setPropertyResolved(false);
/*  53 */     Class<?> result = ctx.getELResolver().getType(ctx, null, this.image);
/*  54 */     if (!ctx.isPropertyResolved()) {
/*  55 */       throw new PropertyNotFoundException(MessageFactory.get("error.resolver.unhandled.null", new Object[] { this.image }));
/*     */     }
/*     */     
/*  58 */     return result;
/*     */   }
/*     */   
/*     */   public Object getValue(EvaluationContext ctx)
/*     */     throws ELException
/*     */   {
/*  64 */     if (ctx.isLambdaArgument(this.image)) {
/*  65 */       return ctx.getLambdaArgument(this.image);
/*     */     }
/*     */     
/*     */ 
/*  69 */     VariableMapper varMapper = ctx.getVariableMapper();
/*  70 */     if (varMapper != null) {
/*  71 */       ValueExpression expr = varMapper.resolveVariable(this.image);
/*  72 */       if (expr != null) {
/*  73 */         return expr.getValue(ctx.getELContext());
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*  78 */     ctx.setPropertyResolved(false);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  87 */     if ((this.parent instanceof AstValue)) {
/*  88 */       ctx.putContext(getClass(), Boolean.FALSE);
/*     */     } else {
/*  90 */       ctx.putContext(getClass(), Boolean.TRUE);
/*     */     }
/*     */     try {
/*  93 */       result = ctx.getELResolver().getValue(ctx, null, this.image);
/*     */     }
/*     */     finally {
/*     */       Object result;
/*  97 */       ctx.putContext(getClass(), Boolean.FALSE);
/*     */     }
/*     */     
/* 100 */     if (ctx.isPropertyResolved()) {
/* 101 */       return result;
/*     */     }
/*     */     
/*     */ 
/* 105 */     Object result = ctx.getImportHandler().resolveClass(this.image);
/* 106 */     if (result != null) {
/* 107 */       return new ELClass((Class)result);
/*     */     }
/* 109 */     result = ctx.getImportHandler().resolveStatic(this.image);
/* 110 */     if (result != null) {
/*     */       try {
/* 112 */         return ((Class)result).getField(this.image).get(null);
/*     */       }
/*     */       catch (IllegalArgumentException|IllegalAccessException|NoSuchFieldException|SecurityException e) {
/* 115 */         throw new ELException(e);
/*     */       }
/*     */     }
/*     */     
/* 119 */     throw new PropertyNotFoundException(MessageFactory.get("error.resolver.unhandled.null", new Object[] { this.image }));
/*     */   }
/*     */   
/*     */   public boolean isReadOnly(EvaluationContext ctx)
/*     */     throws ELException
/*     */   {
/* 125 */     VariableMapper varMapper = ctx.getVariableMapper();
/* 126 */     if (varMapper != null) {
/* 127 */       ValueExpression expr = varMapper.resolveVariable(this.image);
/* 128 */       if (expr != null) {
/* 129 */         return expr.isReadOnly(ctx.getELContext());
/*     */       }
/*     */     }
/* 132 */     ctx.setPropertyResolved(false);
/* 133 */     boolean result = ctx.getELResolver().isReadOnly(ctx, null, this.image);
/* 134 */     if (!ctx.isPropertyResolved()) {
/* 135 */       throw new PropertyNotFoundException(MessageFactory.get("error.resolver.unhandled.null", new Object[] { this.image }));
/*     */     }
/*     */     
/* 138 */     return result;
/*     */   }
/*     */   
/*     */   public void setValue(EvaluationContext ctx, Object value)
/*     */     throws ELException
/*     */   {
/* 144 */     VariableMapper varMapper = ctx.getVariableMapper();
/* 145 */     if (varMapper != null) {
/* 146 */       ValueExpression expr = varMapper.resolveVariable(this.image);
/* 147 */       if (expr != null) {
/* 148 */         expr.setValue(ctx.getELContext(), value);
/* 149 */         return;
/*     */       }
/*     */     }
/* 152 */     ctx.setPropertyResolved(false);
/* 153 */     ctx.getELResolver().setValue(ctx, null, this.image, value);
/* 154 */     if (!ctx.isPropertyResolved()) {
/* 155 */       throw new PropertyNotFoundException(MessageFactory.get("error.resolver.unhandled.null", new Object[] { this.image }));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public Object invoke(EvaluationContext ctx, Class<?>[] paramTypes, Object[] paramValues)
/*     */     throws ELException
/*     */   {
/* 163 */     return getMethodExpression(ctx).invoke(ctx.getELContext(), paramValues);
/*     */   }
/*     */   
/*     */ 
/*     */   public MethodInfo getMethodInfo(EvaluationContext ctx, Class<?>[] paramTypes)
/*     */     throws ELException
/*     */   {
/* 170 */     return getMethodExpression(ctx).getMethodInfo(ctx.getELContext());
/*     */   }
/*     */   
/*     */   public void setImage(String image)
/*     */   {
/* 175 */     if (!Validation.isIdentifier(image)) {
/* 176 */       throw new ELException(MessageFactory.get("error.identifier.notjava", new Object[] { image }));
/*     */     }
/*     */     
/* 179 */     this.image = image;
/*     */   }
/*     */   
/*     */ 
/*     */   public ValueReference getValueReference(EvaluationContext ctx)
/*     */   {
/* 185 */     VariableMapper varMapper = ctx.getVariableMapper();
/*     */     
/* 187 */     if (varMapper == null) {
/* 188 */       return null;
/*     */     }
/*     */     
/* 191 */     ValueExpression expr = varMapper.resolveVariable(this.image);
/*     */     
/* 193 */     if (expr == null) {
/* 194 */       return null;
/*     */     }
/*     */     
/* 197 */     return expr.getValueReference(ctx);
/*     */   }
/*     */   
/*     */   private final MethodExpression getMethodExpression(EvaluationContext ctx)
/*     */     throws ELException
/*     */   {
/* 203 */     Object obj = null;
/*     */     
/*     */ 
/*     */ 
/* 207 */     VariableMapper varMapper = ctx.getVariableMapper();
/* 208 */     ValueExpression ve = null;
/* 209 */     if (varMapper != null) {
/* 210 */       ve = varMapper.resolveVariable(this.image);
/* 211 */       if (ve != null) {
/* 212 */         obj = ve.getValue(ctx);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 218 */     if (ve == null) {
/* 219 */       ctx.setPropertyResolved(false);
/* 220 */       obj = ctx.getELResolver().getValue(ctx, null, this.image);
/*     */     }
/*     */     
/*     */ 
/* 224 */     if ((obj instanceof MethodExpression))
/* 225 */       return (MethodExpression)obj;
/* 226 */     if (obj == null) {
/* 227 */       throw new MethodNotFoundException(MessageFactory.get("error.identifier.noMethod", new Object[] { this.image }));
/*     */     }
/* 229 */     throw new ELException(MessageFactory.get("error.identifier.notMethodExpression", new Object[] { this.image, obj.getClass().getName() }));
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-el-9.0.54.jar!\org\apache\el\parser\AstIdentifier.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */