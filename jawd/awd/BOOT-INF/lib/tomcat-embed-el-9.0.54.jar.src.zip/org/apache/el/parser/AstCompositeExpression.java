/*    */ package org.apache.el.parser;
/*    */ 
/*    */ import javax.el.ELException;
/*    */ import org.apache.el.lang.ELSupport;
/*    */ import org.apache.el.lang.EvaluationContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AstCompositeExpression
/*    */   extends SimpleNode
/*    */ {
/*    */   public AstCompositeExpression(int id)
/*    */   {
/* 32 */     super(id);
/*    */   }
/*    */   
/*    */   public Class<?> getType(EvaluationContext ctx)
/*    */     throws ELException
/*    */   {
/* 38 */     return String.class;
/*    */   }
/*    */   
/*    */   public Object getValue(EvaluationContext ctx)
/*    */     throws ELException
/*    */   {
/* 44 */     StringBuilder sb = new StringBuilder(16);
/* 45 */     Object obj = null;
/* 46 */     if (this.children != null) {
/* 47 */       for (Node child : this.children) {
/* 48 */         obj = child.getValue(ctx);
/* 49 */         if (obj != null) {
/* 50 */           sb.append(ELSupport.coerceToString(ctx, obj));
/*    */         }
/*    */       }
/*    */     }
/* 54 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-el-9.0.54.jar!\org\apache\el\parser\AstCompositeExpression.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */