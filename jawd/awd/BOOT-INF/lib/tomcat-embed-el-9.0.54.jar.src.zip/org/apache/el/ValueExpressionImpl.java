/*     */ package org.apache.el;
/*     */ 
/*     */ import java.io.Externalizable;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInput;
/*     */ import java.io.ObjectOutput;
/*     */ import javax.el.ELContext;
/*     */ import javax.el.ELException;
/*     */ import javax.el.FunctionMapper;
/*     */ import javax.el.PropertyNotFoundException;
/*     */ import javax.el.PropertyNotWritableException;
/*     */ import javax.el.ValueExpression;
/*     */ import javax.el.ValueReference;
/*     */ import javax.el.VariableMapper;
/*     */ import org.apache.el.lang.EvaluationContext;
/*     */ import org.apache.el.lang.ExpressionBuilder;
/*     */ import org.apache.el.parser.AstLiteralExpression;
/*     */ import org.apache.el.parser.Node;
/*     */ import org.apache.el.util.ReflectionUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ValueExpressionImpl
/*     */   extends ValueExpression
/*     */   implements Externalizable
/*     */ {
/*     */   private Class<?> expectedType;
/*     */   private String expr;
/*     */   private FunctionMapper fnMapper;
/*     */   private VariableMapper varMapper;
/*     */   private transient Node node;
/*     */   
/*     */   public ValueExpressionImpl() {}
/*     */   
/*     */   public ValueExpressionImpl(String expr, Node node, FunctionMapper fnMapper, VariableMapper varMapper, Class<?> expectedType)
/*     */   {
/* 106 */     this.expr = expr;
/* 107 */     this.node = node;
/* 108 */     this.fnMapper = fnMapper;
/* 109 */     this.varMapper = varMapper;
/* 110 */     this.expectedType = expectedType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 120 */     if (!(obj instanceof ValueExpressionImpl)) {
/* 121 */       return false;
/*     */     }
/* 123 */     if (obj.hashCode() != hashCode()) {
/* 124 */       return false;
/*     */     }
/*     */     
/* 127 */     return getNode().equals(((ValueExpressionImpl)obj).getNode());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Class<?> getExpectedType()
/*     */   {
/* 137 */     return this.expectedType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getExpressionString()
/*     */   {
/* 152 */     return this.expr;
/*     */   }
/*     */   
/*     */   private Node getNode() throws ELException {
/* 156 */     if (this.node == null) {
/* 157 */       this.node = ExpressionBuilder.createNode(this.expr);
/*     */     }
/* 159 */     return this.node;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Class<?> getType(ELContext context)
/*     */     throws PropertyNotFoundException, ELException
/*     */   {
/* 170 */     EvaluationContext ctx = new EvaluationContext(context, this.fnMapper, this.varMapper);
/*     */     
/* 172 */     context.notifyBeforeEvaluation(getExpressionString());
/* 173 */     Class<?> result = getNode().getType(ctx);
/* 174 */     context.notifyAfterEvaluation(getExpressionString());
/* 175 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getValue(ELContext context)
/*     */     throws PropertyNotFoundException, ELException
/*     */   {
/* 186 */     EvaluationContext ctx = new EvaluationContext(context, this.fnMapper, this.varMapper);
/*     */     
/* 188 */     context.notifyBeforeEvaluation(getExpressionString());
/* 189 */     Object value = getNode().getValue(ctx);
/* 190 */     if (this.expectedType != null) {
/* 191 */       value = context.convertToType(value, this.expectedType);
/*     */     }
/* 193 */     context.notifyAfterEvaluation(getExpressionString());
/* 194 */     return value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 204 */     return getNode().hashCode();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isLiteralText()
/*     */   {
/*     */     try
/*     */     {
/* 215 */       return getNode() instanceof AstLiteralExpression;
/*     */     } catch (ELException ele) {}
/* 217 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isReadOnly(ELContext context)
/*     */     throws PropertyNotFoundException, ELException
/*     */   {
/* 229 */     EvaluationContext ctx = new EvaluationContext(context, this.fnMapper, this.varMapper);
/*     */     
/* 231 */     context.notifyBeforeEvaluation(getExpressionString());
/* 232 */     boolean result = getNode().isReadOnly(ctx);
/* 233 */     context.notifyAfterEvaluation(getExpressionString());
/* 234 */     return result;
/*     */   }
/*     */   
/*     */   public void readExternal(ObjectInput in)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 240 */     this.expr = in.readUTF();
/* 241 */     String type = in.readUTF();
/* 242 */     if (!type.isEmpty()) {
/* 243 */       this.expectedType = ReflectionUtil.forName(type);
/*     */     }
/* 245 */     this.fnMapper = ((FunctionMapper)in.readObject());
/* 246 */     this.varMapper = ((VariableMapper)in.readObject());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setValue(ELContext context, Object value)
/*     */     throws PropertyNotFoundException, PropertyNotWritableException, ELException
/*     */   {
/* 259 */     EvaluationContext ctx = new EvaluationContext(context, this.fnMapper, this.varMapper);
/*     */     
/* 261 */     context.notifyBeforeEvaluation(getExpressionString());
/* 262 */     getNode().setValue(ctx, value);
/* 263 */     context.notifyAfterEvaluation(getExpressionString());
/*     */   }
/*     */   
/*     */   public void writeExternal(ObjectOutput out) throws IOException
/*     */   {
/* 268 */     out.writeUTF(this.expr);
/* 269 */     out.writeUTF(this.expectedType != null ? this.expectedType.getName() : "");
/*     */     
/* 271 */     out.writeObject(this.fnMapper);
/* 272 */     out.writeObject(this.varMapper);
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 277 */     return "ValueExpression[" + this.expr + "]";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ValueReference getValueReference(ELContext context)
/*     */   {
/* 285 */     EvaluationContext ctx = new EvaluationContext(context, this.fnMapper, this.varMapper);
/*     */     
/* 287 */     context.notifyBeforeEvaluation(getExpressionString());
/* 288 */     ValueReference result = getNode().getValueReference(ctx);
/* 289 */     context.notifyAfterEvaluation(getExpressionString());
/* 290 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-el-9.0.54.jar!\org\apache\el\ValueExpressionImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */