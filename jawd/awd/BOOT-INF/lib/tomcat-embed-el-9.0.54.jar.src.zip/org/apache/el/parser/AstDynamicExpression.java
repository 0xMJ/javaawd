/*    */ package org.apache.el.parser;
/*    */ 
/*    */ import javax.el.ELException;
/*    */ import org.apache.el.lang.EvaluationContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AstDynamicExpression
/*    */   extends SimpleNode
/*    */ {
/*    */   public AstDynamicExpression(int id)
/*    */   {
/* 30 */     super(id);
/*    */   }
/*    */   
/*    */   public Class<?> getType(EvaluationContext ctx)
/*    */     throws ELException
/*    */   {
/* 36 */     return this.children[0].getType(ctx);
/*    */   }
/*    */   
/*    */   public Object getValue(EvaluationContext ctx)
/*    */     throws ELException
/*    */   {
/* 42 */     return this.children[0].getValue(ctx);
/*    */   }
/*    */   
/*    */   public boolean isReadOnly(EvaluationContext ctx)
/*    */     throws ELException
/*    */   {
/* 48 */     return this.children[0].isReadOnly(ctx);
/*    */   }
/*    */   
/*    */   public void setValue(EvaluationContext ctx, Object value)
/*    */     throws ELException
/*    */   {
/* 54 */     this.children[0].setValue(ctx, value);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-el-9.0.54.jar!\org\apache\el\parser\AstDynamicExpression.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */