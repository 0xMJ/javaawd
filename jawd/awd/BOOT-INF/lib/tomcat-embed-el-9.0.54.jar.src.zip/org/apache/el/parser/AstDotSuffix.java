/*    */ package org.apache.el.parser;
/*    */ 
/*    */ import javax.el.ELException;
/*    */ import org.apache.el.lang.EvaluationContext;
/*    */ import org.apache.el.util.MessageFactory;
/*    */ import org.apache.el.util.Validation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AstDotSuffix
/*    */   extends SimpleNode
/*    */ {
/*    */   public AstDotSuffix(int id)
/*    */   {
/* 32 */     super(id);
/*    */   }
/*    */   
/*    */   public Object getValue(EvaluationContext ctx)
/*    */     throws ELException
/*    */   {
/* 38 */     return this.image;
/*    */   }
/*    */   
/*    */   public void setImage(String image)
/*    */   {
/* 43 */     if (!Validation.isIdentifier(image)) {
/* 44 */       throw new ELException(MessageFactory.get("error.identifier.notjava", new Object[] { image }));
/*    */     }
/*    */     
/* 47 */     this.image = image;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-el-9.0.54.jar!\org\apache\el\parser\AstDotSuffix.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */