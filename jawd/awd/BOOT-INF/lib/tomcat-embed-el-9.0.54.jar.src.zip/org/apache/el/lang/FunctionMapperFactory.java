/*    */ package org.apache.el.lang;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import javax.el.FunctionMapper;
/*    */ import org.apache.el.util.MessageFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FunctionMapperFactory
/*    */   extends FunctionMapper
/*    */ {
/* 30 */   protected FunctionMapperImpl memento = null;
/*    */   protected final FunctionMapper target;
/*    */   
/*    */   public FunctionMapperFactory(FunctionMapper mapper) {
/* 34 */     if (mapper == null) {
/* 35 */       throw new NullPointerException(MessageFactory.get("error.noFunctionMapperTarget"));
/*    */     }
/* 37 */     this.target = mapper;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Method resolveFunction(String prefix, String localName)
/*    */   {
/* 46 */     if (this.memento == null) {
/* 47 */       this.memento = new FunctionMapperImpl();
/*    */     }
/* 49 */     Method m = this.target.resolveFunction(prefix, localName);
/* 50 */     if (m != null) {
/* 51 */       this.memento.mapFunction(prefix, localName, m);
/*    */     }
/* 53 */     return m;
/*    */   }
/*    */   
/*    */ 
/*    */   public void mapFunction(String prefix, String localName, Method method)
/*    */   {
/* 59 */     if (this.memento == null) {
/* 60 */       this.memento = new FunctionMapperImpl();
/*    */     }
/* 62 */     this.memento.mapFunction(prefix, localName, method);
/*    */   }
/*    */   
/*    */   public FunctionMapper create()
/*    */   {
/* 67 */     return this.memento;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-el-9.0.54.jar!\org\apache\el\lang\FunctionMapperFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */