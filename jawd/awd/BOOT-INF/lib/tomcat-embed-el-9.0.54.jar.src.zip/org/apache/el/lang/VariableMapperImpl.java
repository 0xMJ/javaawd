/*    */ package org.apache.el.lang;
/*    */ 
/*    */ import java.io.Externalizable;
/*    */ import java.io.IOException;
/*    */ import java.io.ObjectInput;
/*    */ import java.io.ObjectOutput;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import javax.el.ValueExpression;
/*    */ import javax.el.VariableMapper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VariableMapperImpl
/*    */   extends VariableMapper
/*    */   implements Externalizable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/* 33 */   private Map<String, ValueExpression> vars = new HashMap();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ValueExpression resolveVariable(String variable)
/*    */   {
/* 41 */     return (ValueExpression)this.vars.get(variable);
/*    */   }
/*    */   
/*    */ 
/*    */   public ValueExpression setVariable(String variable, ValueExpression expression)
/*    */   {
/* 47 */     if (expression == null) {
/* 48 */       return (ValueExpression)this.vars.remove(variable);
/*    */     }
/* 50 */     return (ValueExpression)this.vars.put(variable, expression);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void readExternal(ObjectInput in)
/*    */     throws IOException, ClassNotFoundException
/*    */   {
/* 58 */     this.vars = ((Map)in.readObject());
/*    */   }
/*    */   
/*    */   public void writeExternal(ObjectOutput out) throws IOException
/*    */   {
/* 63 */     out.writeObject(this.vars);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-el-9.0.54.jar!\org\apache\el\lang\VariableMapperImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */