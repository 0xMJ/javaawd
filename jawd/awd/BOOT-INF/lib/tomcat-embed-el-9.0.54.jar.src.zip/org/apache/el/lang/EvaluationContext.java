/*     */ package org.apache.el.lang;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import javax.el.ELContext;
/*     */ import javax.el.ELResolver;
/*     */ import javax.el.EvaluationListener;
/*     */ import javax.el.FunctionMapper;
/*     */ import javax.el.ImportHandler;
/*     */ import javax.el.VariableMapper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class EvaluationContext
/*     */   extends ELContext
/*     */ {
/*     */   private final ELContext elContext;
/*     */   private final FunctionMapper fnMapper;
/*     */   private final VariableMapper varMapper;
/*     */   
/*     */   public EvaluationContext(ELContext elContext, FunctionMapper fnMapper, VariableMapper varMapper)
/*     */   {
/*  40 */     this.elContext = elContext;
/*  41 */     this.fnMapper = fnMapper;
/*  42 */     this.varMapper = varMapper;
/*     */   }
/*     */   
/*     */   public ELContext getELContext() {
/*  46 */     return this.elContext;
/*     */   }
/*     */   
/*     */   public FunctionMapper getFunctionMapper()
/*     */   {
/*  51 */     return this.fnMapper;
/*     */   }
/*     */   
/*     */   public VariableMapper getVariableMapper()
/*     */   {
/*  56 */     return this.varMapper;
/*     */   }
/*     */   
/*     */ 
/*     */   public Object getContext(Class key)
/*     */   {
/*  62 */     return this.elContext.getContext(key);
/*     */   }
/*     */   
/*     */   public ELResolver getELResolver()
/*     */   {
/*  67 */     return this.elContext.getELResolver();
/*     */   }
/*     */   
/*     */   public boolean isPropertyResolved()
/*     */   {
/*  72 */     return this.elContext.isPropertyResolved();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void putContext(Class key, Object contextObject)
/*     */   {
/*  79 */     this.elContext.putContext(key, contextObject);
/*     */   }
/*     */   
/*     */   public void setPropertyResolved(boolean resolved)
/*     */   {
/*  84 */     this.elContext.setPropertyResolved(resolved);
/*     */   }
/*     */   
/*     */   public Locale getLocale()
/*     */   {
/*  89 */     return this.elContext.getLocale();
/*     */   }
/*     */   
/*     */   public void setLocale(Locale locale)
/*     */   {
/*  94 */     this.elContext.setLocale(locale);
/*     */   }
/*     */   
/*     */   public void setPropertyResolved(Object base, Object property)
/*     */   {
/*  99 */     this.elContext.setPropertyResolved(base, property);
/*     */   }
/*     */   
/*     */   public ImportHandler getImportHandler()
/*     */   {
/* 104 */     return this.elContext.getImportHandler();
/*     */   }
/*     */   
/*     */   public void addEvaluationListener(EvaluationListener listener)
/*     */   {
/* 109 */     this.elContext.addEvaluationListener(listener);
/*     */   }
/*     */   
/*     */   public List<EvaluationListener> getEvaluationListeners()
/*     */   {
/* 114 */     return this.elContext.getEvaluationListeners();
/*     */   }
/*     */   
/*     */   public void notifyBeforeEvaluation(String expression)
/*     */   {
/* 119 */     this.elContext.notifyBeforeEvaluation(expression);
/*     */   }
/*     */   
/*     */   public void notifyAfterEvaluation(String expression)
/*     */   {
/* 124 */     this.elContext.notifyAfterEvaluation(expression);
/*     */   }
/*     */   
/*     */   public void notifyPropertyResolved(Object base, Object property)
/*     */   {
/* 129 */     this.elContext.notifyPropertyResolved(base, property);
/*     */   }
/*     */   
/*     */   public boolean isLambdaArgument(String name)
/*     */   {
/* 134 */     return this.elContext.isLambdaArgument(name);
/*     */   }
/*     */   
/*     */   public Object getLambdaArgument(String name)
/*     */   {
/* 139 */     return this.elContext.getLambdaArgument(name);
/*     */   }
/*     */   
/*     */   public void enterLambdaScope(Map<String, Object> arguments)
/*     */   {
/* 144 */     this.elContext.enterLambdaScope(arguments);
/*     */   }
/*     */   
/*     */   public void exitLambdaScope()
/*     */   {
/* 149 */     this.elContext.exitLambdaScope();
/*     */   }
/*     */   
/*     */   public Object convertToType(Object obj, Class<?> type)
/*     */   {
/* 154 */     return this.elContext.convertToType(obj, type);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-el-9.0.54.jar!\org\apache\el\lang\EvaluationContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */