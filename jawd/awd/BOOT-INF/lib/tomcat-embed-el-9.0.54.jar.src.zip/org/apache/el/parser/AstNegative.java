/*    */ package org.apache.el.parser;
/*    */ 
/*    */ import java.math.BigDecimal;
/*    */ import java.math.BigInteger;
/*    */ import javax.el.ELException;
/*    */ import org.apache.el.lang.EvaluationContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AstNegative
/*    */   extends SimpleNode
/*    */ {
/*    */   public AstNegative(int id)
/*    */   {
/* 33 */     super(id);
/*    */   }
/*    */   
/*    */   public Class<?> getType(EvaluationContext ctx)
/*    */     throws ELException
/*    */   {
/* 39 */     return Number.class;
/*    */   }
/*    */   
/*    */   public Object getValue(EvaluationContext ctx)
/*    */     throws ELException
/*    */   {
/* 45 */     Object obj = this.children[0].getValue(ctx);
/*    */     
/* 47 */     if (obj == null) {
/* 48 */       return Long.valueOf(0L);
/*    */     }
/* 50 */     if ((obj instanceof BigDecimal)) {
/* 51 */       return ((BigDecimal)obj).negate();
/*    */     }
/* 53 */     if ((obj instanceof BigInteger)) {
/* 54 */       return ((BigInteger)obj).negate();
/*    */     }
/* 56 */     if ((obj instanceof String)) {
/* 57 */       if (isStringFloat((String)obj)) {
/* 58 */         return Double.valueOf(-Double.parseDouble((String)obj));
/*    */       }
/* 60 */       return Long.valueOf(-Long.parseLong((String)obj));
/*    */     }
/* 62 */     if ((obj instanceof Long)) {
/* 63 */       return Long.valueOf(-((Long)obj).longValue());
/*    */     }
/* 65 */     if ((obj instanceof Double)) {
/* 66 */       return Double.valueOf(-((Double)obj).doubleValue());
/*    */     }
/* 68 */     if ((obj instanceof Integer)) {
/* 69 */       return Integer.valueOf(-((Integer)obj).intValue());
/*    */     }
/* 71 */     if ((obj instanceof Float)) {
/* 72 */       return Float.valueOf(-((Float)obj).floatValue());
/*    */     }
/* 74 */     if ((obj instanceof Short)) {
/* 75 */       return Short.valueOf((short)-((Short)obj).shortValue());
/*    */     }
/* 77 */     if ((obj instanceof Byte)) {
/* 78 */       return Byte.valueOf((byte)-((Byte)obj).byteValue());
/*    */     }
/* 80 */     Long num = (Long)coerceToNumber(ctx, obj, Long.class);
/* 81 */     return Long.valueOf(-num.longValue());
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-el-9.0.54.jar!\org\apache\el\parser\AstNegative.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */