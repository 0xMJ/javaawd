/*      */ package org.apache.el.parser;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.util.Deque;
/*      */ 
/*      */ public class ELParserTokenManager implements ELParserConstants
/*      */ {
/*    8 */   Deque<Integer> deque = new java.util.ArrayDeque();
/*      */   
/*      */ 
/*   11 */   public java.io.PrintStream debugStream = System.out;
/*      */   
/*   13 */   public void setDebugStream(java.io.PrintStream ds) { this.debugStream = ds; }
/*      */   
/*      */   private final int jjStopStringLiteralDfa_0(int pos, long active0) {
/*   16 */     switch (pos)
/*      */     {
/*      */     case 0: 
/*   19 */       if ((active0 & 0xC) != 0L)
/*      */       {
/*   21 */         this.jjmatchedKind = 1;
/*   22 */         return 5;
/*      */       }
/*   24 */       return -1;
/*      */     }
/*   26 */     return -1;
/*      */   }
/*      */   
/*      */   private final int jjStartNfa_0(int pos, long active0)
/*      */   {
/*   31 */     return jjMoveNfa_0(jjStopStringLiteralDfa_0(pos, active0), pos + 1);
/*      */   }
/*      */   
/*      */   private int jjStopAtPos(int pos, int kind) {
/*   35 */     this.jjmatchedKind = kind;
/*   36 */     this.jjmatchedPos = pos;
/*   37 */     return pos + 1;
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa0_0() {
/*   41 */     switch (this.curChar)
/*      */     {
/*      */     case '#': 
/*   44 */       return jjMoveStringLiteralDfa1_0(8L);
/*      */     case '$': 
/*   46 */       return jjMoveStringLiteralDfa1_0(4L);
/*      */     }
/*   48 */     return jjMoveNfa_0(7, 0);
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa1_0(long active0) {
/*      */     try {
/*   53 */       this.curChar = this.input_stream.readChar();
/*      */     } catch (IOException e) {
/*   55 */       jjStopStringLiteralDfa_0(0, active0);
/*   56 */       return 1;
/*      */     }
/*   58 */     switch (this.curChar)
/*      */     {
/*      */     case '{': 
/*   61 */       if ((active0 & 0x4) != 0L)
/*   62 */         return jjStopAtPos(1, 2);
/*   63 */       if ((active0 & 0x8) != 0L) {
/*   64 */         return jjStopAtPos(1, 3);
/*      */       }
/*      */       
/*      */       break;
/*      */     }
/*      */     
/*   70 */     return jjStartNfa_0(0, active0); }
/*      */   
/*   72 */   static final long[] jjbitVec0 = { -2L, -1L, -1L, -1L };
/*      */   
/*      */ 
/*   75 */   static final long[] jjbitVec2 = { 0L, 0L, -1L, -1L };
/*      */   
/*      */ 
/*      */   private int jjMoveNfa_0(int startState, int curPos)
/*      */   {
/*   80 */     int startsAt = 0;
/*   81 */     this.jjnewStateCnt = 8;
/*   82 */     int i = 1;
/*   83 */     this.jjstateSet[0] = startState;
/*   84 */     int kind = Integer.MAX_VALUE;
/*      */     for (;;)
/*      */     {
/*   87 */       if (++this.jjround == Integer.MAX_VALUE) {
/*   88 */         ReInitRounds();
/*      */       }
/*   90 */       if (this.curChar < '@')
/*      */       {
/*   92 */         long l = 1L << this.curChar;
/*      */         do
/*      */         {
/*   95 */           switch (this.jjstateSet[(--i)])
/*      */           {
/*      */           case 7: 
/*   98 */             if ((0xFFFFFFE7FFFFFFFF & l) != 0L)
/*      */             {
/*  100 */               if (kind > 1) {
/*  101 */                 kind = 1;
/*      */               }
/*  103 */               jjCheckNAddStates(0, 4);
/*      */             }
/*  105 */             else if ((0x1800000000 & l) != 0L)
/*      */             {
/*  107 */               if (kind > 1) {
/*  108 */                 kind = 1;
/*      */               }
/*  110 */               jjCheckNAdd(5);
/*      */             }
/*  112 */             if ((0xFFFFFFE7FFFFFFFF & l) != 0L) {
/*  113 */               jjCheckNAddTwoStates(0, 1);
/*      */             }
/*      */             break;
/*      */           case 0: 
/*  117 */             if ((0xFFFFFFE7FFFFFFFF & l) != 0L) {
/*  118 */               jjCheckNAddTwoStates(0, 1);
/*      */             }
/*      */             break;
/*      */           case 2: 
/*  122 */             if ((0xFFFFFFE7FFFFFFFF & l) != 0L)
/*      */             {
/*      */ 
/*  125 */               if (kind > 1) {
/*  126 */                 kind = 1;
/*      */               }
/*  128 */               jjCheckNAddStates(0, 4); }
/*  129 */             break;
/*      */           case 3: 
/*  131 */             if ((0xFFFFFFE7FFFFFFFF & l) != 0L) {
/*  132 */               jjCheckNAddTwoStates(3, 4);
/*      */             }
/*      */             break;
/*      */           case 4: 
/*  136 */             if ((0x1800000000 & l) != 0L) {
/*  137 */               jjCheckNAdd(5);
/*      */             }
/*      */             break;
/*      */           case 5: 
/*  141 */             if ((0xFFFFFFE7FFFFFFFF & l) != 0L)
/*      */             {
/*      */ 
/*  144 */               if (kind > 1) {
/*  145 */                 kind = 1;
/*      */               }
/*  147 */               jjCheckNAddStates(5, 8); }
/*  148 */             break;
/*      */           case 6: 
/*  150 */             if ((0x1800000000 & l) != 0L)
/*      */             {
/*      */ 
/*  153 */               if (kind > 1) {
/*  154 */                 kind = 1;
/*      */               }
/*  156 */               jjCheckNAddStates(9, 13);
/*      */             }
/*      */             break;
/*      */           }
/*  160 */         } while (i != startsAt);
/*      */       }
/*  162 */       else if (this.curChar < '')
/*      */       {
/*  164 */         long l = 1L << (this.curChar & 0x3F);
/*      */         do
/*      */         {
/*  167 */           switch (this.jjstateSet[(--i)])
/*      */           {
/*      */           case 7: 
/*  170 */             if (kind > 1) {
/*  171 */               kind = 1;
/*      */             }
/*  173 */             jjCheckNAddStates(0, 4);
/*  174 */             if ((0xFFFFFFFFEFFFFFFF & l) != 0L) {
/*  175 */               jjCheckNAddTwoStates(0, 1);
/*  176 */             } else if (this.curChar == '\\')
/*      */             {
/*  178 */               if (kind > 1) {
/*  179 */                 kind = 1;
/*      */               }
/*  181 */               jjCheckNAddStates(14, 17);
/*      */             }
/*      */             break;
/*      */           case 0: 
/*  185 */             if ((0xFFFFFFFFEFFFFFFF & l) != 0L) {
/*  186 */               jjCheckNAddTwoStates(0, 1);
/*      */             }
/*      */             break;
/*      */           case 1: 
/*  190 */             if (this.curChar == '\\')
/*      */             {
/*      */ 
/*  193 */               if (kind > 1) {
/*  194 */                 kind = 1;
/*      */               }
/*  196 */               jjCheckNAddStates(14, 17); }
/*  197 */             break;
/*      */           case 2: 
/*  199 */             if (kind > 1) {
/*  200 */               kind = 1;
/*      */             }
/*  202 */             jjCheckNAddStates(0, 4);
/*  203 */             break;
/*      */           case 3: 
/*  205 */             jjCheckNAddTwoStates(3, 4);
/*  206 */             break;
/*      */           case 5: 
/*  208 */             if ((0xF7FFFFFFEFFFFFFF & l) != 0L)
/*      */             {
/*      */ 
/*  211 */               if (kind > 1) {
/*  212 */                 kind = 1;
/*      */               }
/*  214 */               jjCheckNAddStates(5, 8);
/*      */             }
/*      */             break;
/*      */           }
/*  218 */         } while (i != startsAt);
/*      */       } else {
/*  220 */         int hiByte = this.curChar >> '\b';
/*  221 */         int i1 = hiByte >> 6;
/*  222 */         long l1 = 1L << (hiByte & 0x3F);
/*  223 */         int i2 = (this.curChar & 0xFF) >> '\006';
/*  224 */         long l2 = 1L << (this.curChar & 0x3F);
/*      */         do
/*      */         {
/*  227 */           switch (this.jjstateSet[(--i)])
/*      */           {
/*      */           case 7: 
/*  230 */             if (jjCanMove_0(hiByte, i1, i2, l1, l2)) {
/*  231 */               jjCheckNAddTwoStates(0, 1);
/*      */             }
/*  233 */             if (jjCanMove_0(hiByte, i1, i2, l1, l2))
/*      */             {
/*  235 */               if (kind > 1) {
/*  236 */                 kind = 1;
/*      */               }
/*  238 */               jjCheckNAddStates(0, 4);
/*      */             }
/*      */             break;
/*      */           case 0: 
/*  242 */             if (jjCanMove_0(hiByte, i1, i2, l1, l2)) {
/*  243 */               jjCheckNAddTwoStates(0, 1);
/*      */             }
/*      */             break;
/*      */           case 2: 
/*  247 */             if (jjCanMove_0(hiByte, i1, i2, l1, l2))
/*      */             {
/*      */ 
/*  250 */               if (kind > 1) {
/*  251 */                 kind = 1;
/*      */               }
/*  253 */               jjCheckNAddStates(0, 4); }
/*  254 */             break;
/*      */           case 3: 
/*  256 */             if (jjCanMove_0(hiByte, i1, i2, l1, l2)) {
/*  257 */               jjCheckNAddTwoStates(3, 4);
/*      */             }
/*      */             break;
/*      */           case 5: 
/*  261 */             if (jjCanMove_0(hiByte, i1, i2, l1, l2))
/*      */             {
/*      */ 
/*  264 */               if (kind > 1) {
/*  265 */                 kind = 1;
/*      */               }
/*  267 */               jjCheckNAddStates(5, 8);
/*      */             }
/*      */             break;
/*      */           }
/*  271 */         } while (i != startsAt);
/*      */       }
/*  273 */       if (kind != Integer.MAX_VALUE)
/*      */       {
/*  275 */         this.jjmatchedKind = kind;
/*  276 */         this.jjmatchedPos = curPos;
/*  277 */         kind = Integer.MAX_VALUE;
/*      */       }
/*  279 */       curPos++;
/*  280 */       if ((i = this.jjnewStateCnt) == (startsAt = 8 - (this.jjnewStateCnt = startsAt)))
/*  281 */         return curPos;
/*      */       try {
/*  283 */         this.curChar = this.input_stream.readChar(); } catch (IOException e) {} }
/*  284 */     return curPos;
/*      */   }
/*      */   
/*      */   private final int jjStopStringLiteralDfa_2(int pos, long active0)
/*      */   {
/*  289 */     switch (pos)
/*      */     {
/*      */     case 0: 
/*  292 */       if ((active0 & 0x20000) != 0L) {
/*  293 */         return 1;
/*      */       }
/*  295 */       if ((active0 & 0x141D555401C000) != 0L)
/*      */       {
/*  297 */         this.jjmatchedKind = 56;
/*  298 */         return 30;
/*      */       }
/*  300 */       return -1;
/*      */     case 1: 
/*  302 */       if ((active0 & 0x41554000000) != 0L) {
/*  303 */         return 30;
/*      */       }
/*  305 */       if ((active0 & 0x1419400001C000) != 0L)
/*      */       {
/*  307 */         this.jjmatchedKind = 56;
/*  308 */         this.jjmatchedPos = 1;
/*  309 */         return 30;
/*      */       }
/*  311 */       return -1;
/*      */     case 2: 
/*  313 */       if ((active0 & 0x14014000000000) != 0L) {
/*  314 */         return 30;
/*      */       }
/*  316 */       if ((active0 & 0x18000001C000) != 0L)
/*      */       {
/*  318 */         this.jjmatchedKind = 56;
/*  319 */         this.jjmatchedPos = 2;
/*  320 */         return 30;
/*      */       }
/*  322 */       return -1;
/*      */     case 3: 
/*  324 */       if ((active0 & 0x14000) != 0L) {
/*  325 */         return 30;
/*      */       }
/*  327 */       if ((active0 & 0x180000008000) != 0L)
/*      */       {
/*  329 */         this.jjmatchedKind = 56;
/*  330 */         this.jjmatchedPos = 3;
/*  331 */         return 30;
/*      */       }
/*  333 */       return -1;
/*      */     case 4: 
/*  335 */       if ((active0 & 0x80000008000) != 0L) {
/*  336 */         return 30;
/*      */       }
/*  338 */       if ((active0 & 0x100000000000) != 0L)
/*      */       {
/*  340 */         this.jjmatchedKind = 56;
/*  341 */         this.jjmatchedPos = 4;
/*  342 */         return 30;
/*      */       }
/*  344 */       return -1;
/*      */     case 5: 
/*  346 */       if ((active0 & 0x100000000000) != 0L)
/*      */       {
/*  348 */         this.jjmatchedKind = 56;
/*  349 */         this.jjmatchedPos = 5;
/*  350 */         return 30;
/*      */       }
/*  352 */       return -1;
/*      */     case 6: 
/*  354 */       if ((active0 & 0x100000000000) != 0L)
/*      */       {
/*  356 */         this.jjmatchedKind = 56;
/*  357 */         this.jjmatchedPos = 6;
/*  358 */         return 30;
/*      */       }
/*  360 */       return -1;
/*      */     case 7: 
/*  362 */       if ((active0 & 0x100000000000) != 0L)
/*      */       {
/*  364 */         this.jjmatchedKind = 56;
/*  365 */         this.jjmatchedPos = 7;
/*  366 */         return 30;
/*      */       }
/*  368 */       return -1;
/*      */     case 8: 
/*  370 */       if ((active0 & 0x100000000000) != 0L)
/*      */       {
/*  372 */         this.jjmatchedKind = 56;
/*  373 */         this.jjmatchedPos = 8;
/*  374 */         return 30;
/*      */       }
/*  376 */       return -1;
/*      */     }
/*  378 */     return -1;
/*      */   }
/*      */   
/*      */   private final int jjStartNfa_2(int pos, long active0)
/*      */   {
/*  383 */     return jjMoveNfa_2(jjStopStringLiteralDfa_2(pos, active0), pos + 1);
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa0_2() {
/*  387 */     switch (this.curChar)
/*      */     {
/*      */     case '!': 
/*  390 */       this.jjmatchedKind = 37;
/*  391 */       return jjMoveStringLiteralDfa1_2(34359738368L);
/*      */     case '%': 
/*  393 */       return jjStopAtPos(0, 51);
/*      */     case '&': 
/*  395 */       return jjMoveStringLiteralDfa1_2(549755813888L);
/*      */     case '(': 
/*  397 */       return jjStopAtPos(0, 18);
/*      */     case ')': 
/*  399 */       return jjStopAtPos(0, 19);
/*      */     case '*': 
/*  401 */       return jjStopAtPos(0, 45);
/*      */     case '+': 
/*  403 */       this.jjmatchedKind = 46;
/*  404 */       return jjMoveStringLiteralDfa1_2(9007199254740992L);
/*      */     case ',': 
/*  406 */       return jjStopAtPos(0, 24);
/*      */     case '-': 
/*  408 */       this.jjmatchedKind = 47;
/*  409 */       return jjMoveStringLiteralDfa1_2(36028797018963968L);
/*      */     case '.': 
/*  411 */       return jjStartNfaWithStates_2(0, 17, 1);
/*      */     case '/': 
/*  413 */       return jjStopAtPos(0, 49);
/*      */     case ':': 
/*  415 */       return jjStopAtPos(0, 22);
/*      */     case ';': 
/*  417 */       return jjStopAtPos(0, 23);
/*      */     case '<': 
/*  419 */       this.jjmatchedKind = 27;
/*  420 */       return jjMoveStringLiteralDfa1_2(2147483648L);
/*      */     case '=': 
/*  422 */       this.jjmatchedKind = 54;
/*  423 */       return jjMoveStringLiteralDfa1_2(8589934592L);
/*      */     case '>': 
/*  425 */       this.jjmatchedKind = 25;
/*  426 */       return jjMoveStringLiteralDfa1_2(536870912L);
/*      */     case '?': 
/*  428 */       return jjStopAtPos(0, 48);
/*      */     case '[': 
/*  430 */       return jjStopAtPos(0, 20);
/*      */     case ']': 
/*  432 */       return jjStopAtPos(0, 21);
/*      */     case 'a': 
/*  434 */       return jjMoveStringLiteralDfa1_2(1099511627776L);
/*      */     case 'd': 
/*  436 */       return jjMoveStringLiteralDfa1_2(1125899906842624L);
/*      */     case 'e': 
/*  438 */       return jjMoveStringLiteralDfa1_2(8813272891392L);
/*      */     case 'f': 
/*  440 */       return jjMoveStringLiteralDfa1_2(32768L);
/*      */     case 'g': 
/*  442 */       return jjMoveStringLiteralDfa1_2(1140850688L);
/*      */     case 'i': 
/*  444 */       return jjMoveStringLiteralDfa1_2(17592186044416L);
/*      */     case 'l': 
/*  446 */       return jjMoveStringLiteralDfa1_2(4563402752L);
/*      */     case 'm': 
/*  448 */       return jjMoveStringLiteralDfa1_2(4503599627370496L);
/*      */     case 'n': 
/*  450 */       return jjMoveStringLiteralDfa1_2(343597449216L);
/*      */     case 'o': 
/*  452 */       return jjMoveStringLiteralDfa1_2(4398046511104L);
/*      */     case 't': 
/*  454 */       return jjMoveStringLiteralDfa1_2(16384L);
/*      */     case '{': 
/*  456 */       return jjStopAtPos(0, 8);
/*      */     case '|': 
/*  458 */       return jjMoveStringLiteralDfa1_2(2199023255552L);
/*      */     case '}': 
/*  460 */       return jjStopAtPos(0, 9);
/*      */     }
/*  462 */     return jjMoveNfa_2(0, 0);
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa1_2(long active0) {
/*      */     try {
/*  467 */       this.curChar = this.input_stream.readChar();
/*      */     } catch (IOException e) {
/*  469 */       jjStopStringLiteralDfa_2(0, active0);
/*  470 */       return 1;
/*      */     }
/*  472 */     switch (this.curChar)
/*      */     {
/*      */     case '&': 
/*  475 */       if ((active0 & 0x8000000000) != 0L) {
/*  476 */         return jjStopAtPos(1, 39);
/*      */       }
/*      */       break;
/*      */     case '=': 
/*  480 */       if ((active0 & 0x20000000) != 0L)
/*  481 */         return jjStopAtPos(1, 29);
/*  482 */       if ((active0 & 0x80000000) != 0L)
/*  483 */         return jjStopAtPos(1, 31);
/*  484 */       if ((active0 & 0x200000000) != 0L)
/*  485 */         return jjStopAtPos(1, 33);
/*  486 */       if ((active0 & 0x800000000) != 0L)
/*  487 */         return jjStopAtPos(1, 35);
/*  488 */       if ((active0 & 0x20000000000000) != 0L) {
/*  489 */         return jjStopAtPos(1, 53);
/*      */       }
/*      */       break;
/*      */     case '>': 
/*  493 */       if ((active0 & 0x80000000000000) != 0L) {
/*  494 */         return jjStopAtPos(1, 55);
/*      */       }
/*      */       break;
/*      */     case 'a': 
/*  498 */       return jjMoveStringLiteralDfa2_2(active0, 32768L);
/*      */     case 'e': 
/*  500 */       if ((active0 & 0x40000000) != 0L)
/*  501 */         return jjStartNfaWithStates_2(1, 30, 30);
/*  502 */       if ((active0 & 0x100000000) != 0L)
/*  503 */         return jjStartNfaWithStates_2(1, 32, 30);
/*  504 */       if ((active0 & 0x1000000000) != 0L) {
/*  505 */         return jjStartNfaWithStates_2(1, 36, 30);
/*      */       }
/*      */       break;
/*      */     case 'i': 
/*  509 */       return jjMoveStringLiteralDfa2_2(active0, 1125899906842624L);
/*      */     case 'm': 
/*  511 */       return jjMoveStringLiteralDfa2_2(active0, 8796093022208L);
/*      */     case 'n': 
/*  513 */       return jjMoveStringLiteralDfa2_2(active0, 18691697672192L);
/*      */     case 'o': 
/*  515 */       return jjMoveStringLiteralDfa2_2(active0, 4503874505277440L);
/*      */     case 'q': 
/*  517 */       if ((active0 & 0x400000000) != 0L) {
/*  518 */         return jjStartNfaWithStates_2(1, 34, 30);
/*      */       }
/*      */       break;
/*      */     case 'r': 
/*  522 */       if ((active0 & 0x40000000000) != 0L) {
/*  523 */         return jjStartNfaWithStates_2(1, 42, 30);
/*      */       }
/*  525 */       return jjMoveStringLiteralDfa2_2(active0, 16384L);
/*      */     case 't': 
/*  527 */       if ((active0 & 0x4000000) != 0L)
/*  528 */         return jjStartNfaWithStates_2(1, 26, 30);
/*  529 */       if ((active0 & 0x10000000) != 0L) {
/*  530 */         return jjStartNfaWithStates_2(1, 28, 30);
/*      */       }
/*      */       break;
/*      */     case 'u': 
/*  534 */       return jjMoveStringLiteralDfa2_2(active0, 65536L);
/*      */     case '|': 
/*  536 */       if ((active0 & 0x20000000000) != 0L) {
/*  537 */         return jjStopAtPos(1, 41);
/*      */       }
/*      */       
/*      */       break;
/*      */     }
/*      */     
/*  543 */     return jjStartNfa_2(0, active0);
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa2_2(long old0, long active0) {
/*  547 */     if ((active0 &= old0) == 0L)
/*  548 */       return jjStartNfa_2(0, old0);
/*      */     try {
/*  550 */       this.curChar = this.input_stream.readChar();
/*      */     } catch (IOException e) {
/*  552 */       jjStopStringLiteralDfa_2(1, active0);
/*  553 */       return 2;
/*      */     }
/*  555 */     switch (this.curChar)
/*      */     {
/*      */     case 'd': 
/*  558 */       if ((active0 & 0x10000000000) != 0L)
/*  559 */         return jjStartNfaWithStates_2(2, 40, 30);
/*  560 */       if ((active0 & 0x10000000000000) != 0L) {
/*  561 */         return jjStartNfaWithStates_2(2, 52, 30);
/*      */       }
/*      */       break;
/*      */     case 'l': 
/*  565 */       return jjMoveStringLiteralDfa3_2(active0, 98304L);
/*      */     case 'p': 
/*  567 */       return jjMoveStringLiteralDfa3_2(active0, 8796093022208L);
/*      */     case 's': 
/*  569 */       return jjMoveStringLiteralDfa3_2(active0, 17592186044416L);
/*      */     case 't': 
/*  571 */       if ((active0 & 0x4000000000) != 0L) {
/*  572 */         return jjStartNfaWithStates_2(2, 38, 30);
/*      */       }
/*      */       break;
/*      */     case 'u': 
/*  576 */       return jjMoveStringLiteralDfa3_2(active0, 16384L);
/*      */     case 'v': 
/*  578 */       if ((active0 & 0x4000000000000) != 0L) {
/*  579 */         return jjStartNfaWithStates_2(2, 50, 30);
/*      */       }
/*      */       
/*      */       break;
/*      */     }
/*      */     
/*  585 */     return jjStartNfa_2(1, active0);
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa3_2(long old0, long active0) {
/*  589 */     if ((active0 &= old0) == 0L)
/*  590 */       return jjStartNfa_2(1, old0);
/*      */     try {
/*  592 */       this.curChar = this.input_stream.readChar();
/*      */     } catch (IOException e) {
/*  594 */       jjStopStringLiteralDfa_2(2, active0);
/*  595 */       return 3;
/*      */     }
/*  597 */     switch (this.curChar)
/*      */     {
/*      */     case 'e': 
/*  600 */       if ((active0 & 0x4000) != 0L) {
/*  601 */         return jjStartNfaWithStates_2(3, 14, 30);
/*      */       }
/*      */       break;
/*      */     case 'l': 
/*  605 */       if ((active0 & 0x10000) != 0L) {
/*  606 */         return jjStartNfaWithStates_2(3, 16, 30);
/*      */       }
/*      */       break;
/*      */     case 's': 
/*  610 */       return jjMoveStringLiteralDfa4_2(active0, 32768L);
/*      */     case 't': 
/*  612 */       return jjMoveStringLiteralDfa4_2(active0, 26388279066624L);
/*      */     }
/*      */     
/*      */     
/*  616 */     return jjStartNfa_2(2, active0);
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa4_2(long old0, long active0) {
/*  620 */     if ((active0 &= old0) == 0L)
/*  621 */       return jjStartNfa_2(2, old0);
/*      */     try {
/*  623 */       this.curChar = this.input_stream.readChar();
/*      */     } catch (IOException e) {
/*  625 */       jjStopStringLiteralDfa_2(3, active0);
/*  626 */       return 4;
/*      */     }
/*  628 */     switch (this.curChar)
/*      */     {
/*      */     case 'a': 
/*  631 */       return jjMoveStringLiteralDfa5_2(active0, 17592186044416L);
/*      */     case 'e': 
/*  633 */       if ((active0 & 0x8000) != 0L) {
/*  634 */         return jjStartNfaWithStates_2(4, 15, 30);
/*      */       }
/*      */       break;
/*      */     case 'y': 
/*  638 */       if ((active0 & 0x80000000000) != 0L) {
/*  639 */         return jjStartNfaWithStates_2(4, 43, 30);
/*      */       }
/*      */       
/*      */       break;
/*      */     }
/*      */     
/*  645 */     return jjStartNfa_2(3, active0);
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa5_2(long old0, long active0) {
/*  649 */     if ((active0 &= old0) == 0L)
/*  650 */       return jjStartNfa_2(3, old0);
/*      */     try {
/*  652 */       this.curChar = this.input_stream.readChar();
/*      */     } catch (IOException e) {
/*  654 */       jjStopStringLiteralDfa_2(4, active0);
/*  655 */       return 5;
/*      */     }
/*  657 */     switch (this.curChar)
/*      */     {
/*      */     case 'n': 
/*  660 */       return jjMoveStringLiteralDfa6_2(active0, 17592186044416L);
/*      */     }
/*      */     
/*      */     
/*  664 */     return jjStartNfa_2(4, active0);
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa6_2(long old0, long active0) {
/*  668 */     if ((active0 &= old0) == 0L)
/*  669 */       return jjStartNfa_2(4, old0);
/*      */     try {
/*  671 */       this.curChar = this.input_stream.readChar();
/*      */     } catch (IOException e) {
/*  673 */       jjStopStringLiteralDfa_2(5, active0);
/*  674 */       return 6;
/*      */     }
/*  676 */     switch (this.curChar)
/*      */     {
/*      */     case 'c': 
/*  679 */       return jjMoveStringLiteralDfa7_2(active0, 17592186044416L);
/*      */     }
/*      */     
/*      */     
/*  683 */     return jjStartNfa_2(5, active0);
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa7_2(long old0, long active0) {
/*  687 */     if ((active0 &= old0) == 0L)
/*  688 */       return jjStartNfa_2(5, old0);
/*      */     try {
/*  690 */       this.curChar = this.input_stream.readChar();
/*      */     } catch (IOException e) {
/*  692 */       jjStopStringLiteralDfa_2(6, active0);
/*  693 */       return 7;
/*      */     }
/*  695 */     switch (this.curChar)
/*      */     {
/*      */     case 'e': 
/*  698 */       return jjMoveStringLiteralDfa8_2(active0, 17592186044416L);
/*      */     }
/*      */     
/*      */     
/*  702 */     return jjStartNfa_2(6, active0);
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa8_2(long old0, long active0) {
/*  706 */     if ((active0 &= old0) == 0L)
/*  707 */       return jjStartNfa_2(6, old0);
/*      */     try {
/*  709 */       this.curChar = this.input_stream.readChar();
/*      */     } catch (IOException e) {
/*  711 */       jjStopStringLiteralDfa_2(7, active0);
/*  712 */       return 8;
/*      */     }
/*  714 */     switch (this.curChar)
/*      */     {
/*      */     case 'o': 
/*  717 */       return jjMoveStringLiteralDfa9_2(active0, 17592186044416L);
/*      */     }
/*      */     
/*      */     
/*  721 */     return jjStartNfa_2(7, active0);
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa9_2(long old0, long active0) {
/*  725 */     if ((active0 &= old0) == 0L)
/*  726 */       return jjStartNfa_2(7, old0);
/*      */     try {
/*  728 */       this.curChar = this.input_stream.readChar();
/*      */     } catch (IOException e) {
/*  730 */       jjStopStringLiteralDfa_2(8, active0);
/*  731 */       return 9;
/*      */     }
/*  733 */     switch (this.curChar)
/*      */     {
/*      */     case 'f': 
/*  736 */       if ((active0 & 0x100000000000) != 0L) {
/*  737 */         return jjStartNfaWithStates_2(9, 44, 30);
/*      */       }
/*      */       
/*      */       break;
/*      */     }
/*      */     
/*  743 */     return jjStartNfa_2(8, active0);
/*      */   }
/*      */   
/*      */   private int jjStartNfaWithStates_2(int pos, int kind, int state) {
/*  747 */     this.jjmatchedKind = kind;
/*  748 */     this.jjmatchedPos = pos;
/*  749 */     try { this.curChar = this.input_stream.readChar();
/*  750 */     } catch (IOException e) { return pos + 1; }
/*  751 */     return jjMoveNfa_2(state, pos + 1); }
/*      */   
/*  753 */   static final long[] jjbitVec3 = { 2301339413881290750L, -16384L, 4294967295L, 432345564227567616L };
/*      */   
/*      */ 
/*  756 */   static final long[] jjbitVec4 = { 0L, 0L, 0L, -36028797027352577L };
/*      */   
/*      */ 
/*  759 */   static final long[] jjbitVec5 = { 0L, -1L, -1L, -1L };
/*      */   
/*      */ 
/*  762 */   static final long[] jjbitVec6 = { -1L, -1L, 65535L, 0L };
/*      */   
/*      */ 
/*  765 */   static final long[] jjbitVec7 = { -1L, -1L, 0L, 0L };
/*      */   
/*      */ 
/*  768 */   static final long[] jjbitVec8 = { 70368744177663L, 0L, 0L, 0L };
/*      */   
/*      */ 
/*      */   private int jjMoveNfa_2(int startState, int curPos)
/*      */   {
/*  773 */     int startsAt = 0;
/*  774 */     this.jjnewStateCnt = 30;
/*  775 */     int i = 1;
/*  776 */     this.jjstateSet[0] = startState;
/*  777 */     int kind = Integer.MAX_VALUE;
/*      */     for (;;)
/*      */     {
/*  780 */       if (++this.jjround == Integer.MAX_VALUE) {
/*  781 */         ReInitRounds();
/*      */       }
/*  783 */       if (this.curChar < '@')
/*      */       {
/*  785 */         long l = 1L << this.curChar;
/*      */         do
/*      */         {
/*  788 */           switch (this.jjstateSet[(--i)])
/*      */           {
/*      */           case 0: 
/*  791 */             if ((0x3FF000000000000 & l) != 0L)
/*      */             {
/*  793 */               if (kind > 10) {
/*  794 */                 kind = 10;
/*      */               }
/*  796 */               jjCheckNAddStates(18, 22);
/*      */             }
/*  798 */             else if ((0x1800000000 & l) != 0L)
/*      */             {
/*  800 */               if (kind > 56) {
/*  801 */                 kind = 56;
/*      */               }
/*  803 */               jjCheckNAddTwoStates(28, 29);
/*      */             }
/*  805 */             else if (this.curChar == '\'') {
/*  806 */               jjCheckNAddStates(23, 25);
/*  807 */             } else if (this.curChar == '"') {
/*  808 */               jjCheckNAddStates(26, 28);
/*  809 */             } else if (this.curChar == '.') {
/*  810 */               jjCheckNAdd(1);
/*      */             }
/*      */             break;
/*      */           case 30: 
/*  814 */             if ((0x3FF001000000000 & l) != 0L)
/*      */             {
/*  816 */               if (kind > 57) {
/*  817 */                 kind = 57;
/*      */               }
/*  819 */               jjCheckNAdd(29);
/*      */             }
/*  821 */             if ((0x3FF001000000000 & l) != 0L)
/*      */             {
/*  823 */               if (kind > 56) {
/*  824 */                 kind = 56;
/*      */               }
/*  826 */               jjCheckNAdd(28);
/*      */             }
/*      */             break;
/*      */           case 1: 
/*  830 */             if ((0x3FF000000000000 & l) != 0L)
/*      */             {
/*      */ 
/*  833 */               if (kind > 11) {
/*  834 */                 kind = 11;
/*      */               }
/*  836 */               jjCheckNAddTwoStates(1, 2); }
/*  837 */             break;
/*      */           case 3: 
/*  839 */             if ((0x280000000000 & l) != 0L) {
/*  840 */               jjCheckNAdd(4);
/*      */             }
/*      */             break;
/*      */           case 4: 
/*  844 */             if ((0x3FF000000000000 & l) != 0L)
/*      */             {
/*      */ 
/*  847 */               if (kind > 11) {
/*  848 */                 kind = 11;
/*      */               }
/*  850 */               jjCheckNAdd(4); }
/*  851 */             break;
/*      */           case 5: 
/*  853 */             if (this.curChar == '"') {
/*  854 */               jjCheckNAddStates(26, 28);
/*      */             }
/*      */             break;
/*      */           case 6: 
/*  858 */             if ((0xFFFFFFFBFFFFFFFF & l) != 0L) {
/*  859 */               jjCheckNAddStates(26, 28);
/*      */             }
/*      */             break;
/*      */           case 8: 
/*  863 */             if ((0x8400000000 & l) != 0L) {
/*  864 */               jjCheckNAddStates(26, 28);
/*      */             }
/*      */             break;
/*      */           case 9: 
/*  868 */             if ((this.curChar == '"') && (kind > 13)) {
/*  869 */               kind = 13;
/*      */             }
/*      */             break;
/*      */           case 10: 
/*  873 */             if (this.curChar == '\'') {
/*  874 */               jjCheckNAddStates(23, 25);
/*      */             }
/*      */             break;
/*      */           case 11: 
/*  878 */             if ((0xFFFFFF7FFFFFFFFF & l) != 0L) {
/*  879 */               jjCheckNAddStates(23, 25);
/*      */             }
/*      */             break;
/*      */           case 13: 
/*  883 */             if ((0x8400000000 & l) != 0L) {
/*  884 */               jjCheckNAddStates(23, 25);
/*      */             }
/*      */             break;
/*      */           case 14: 
/*  888 */             if ((this.curChar == '\'') && (kind > 13)) {
/*  889 */               kind = 13;
/*      */             }
/*      */             break;
/*      */           case 15: 
/*  893 */             if ((0x3FF000000000000 & l) != 0L)
/*      */             {
/*      */ 
/*  896 */               if (kind > 10) {
/*  897 */                 kind = 10;
/*      */               }
/*  899 */               jjCheckNAddStates(18, 22); }
/*  900 */             break;
/*      */           case 16: 
/*  902 */             if ((0x3FF000000000000 & l) != 0L)
/*      */             {
/*      */ 
/*  905 */               if (kind > 10) {
/*  906 */                 kind = 10;
/*      */               }
/*  908 */               jjCheckNAdd(16); }
/*  909 */             break;
/*      */           case 17: 
/*  911 */             if ((0x3FF000000000000 & l) != 0L) {
/*  912 */               jjCheckNAddTwoStates(17, 18);
/*      */             }
/*      */             break;
/*      */           case 18: 
/*  916 */             if (this.curChar == '.')
/*      */             {
/*      */ 
/*  919 */               if (kind > 11) {
/*  920 */                 kind = 11;
/*      */               }
/*  922 */               jjCheckNAddTwoStates(19, 20); }
/*  923 */             break;
/*      */           case 19: 
/*  925 */             if ((0x3FF000000000000 & l) != 0L)
/*      */             {
/*      */ 
/*  928 */               if (kind > 11) {
/*  929 */                 kind = 11;
/*      */               }
/*  931 */               jjCheckNAddTwoStates(19, 20); }
/*  932 */             break;
/*      */           case 21: 
/*  934 */             if ((0x280000000000 & l) != 0L) {
/*  935 */               jjCheckNAdd(22);
/*      */             }
/*      */             break;
/*      */           case 22: 
/*  939 */             if ((0x3FF000000000000 & l) != 0L)
/*      */             {
/*      */ 
/*  942 */               if (kind > 11) {
/*  943 */                 kind = 11;
/*      */               }
/*  945 */               jjCheckNAdd(22); }
/*  946 */             break;
/*      */           case 23: 
/*  948 */             if ((0x3FF000000000000 & l) != 0L) {
/*  949 */               jjCheckNAddTwoStates(23, 24);
/*      */             }
/*      */             break;
/*      */           case 25: 
/*  953 */             if ((0x280000000000 & l) != 0L) {
/*  954 */               jjCheckNAdd(26);
/*      */             }
/*      */             break;
/*      */           case 26: 
/*  958 */             if ((0x3FF000000000000 & l) != 0L)
/*      */             {
/*      */ 
/*  961 */               if (kind > 11) {
/*  962 */                 kind = 11;
/*      */               }
/*  964 */               jjCheckNAdd(26); }
/*  965 */             break;
/*      */           case 27: 
/*  967 */             if ((0x1800000000 & l) != 0L)
/*      */             {
/*      */ 
/*  970 */               if (kind > 56) {
/*  971 */                 kind = 56;
/*      */               }
/*  973 */               jjCheckNAddTwoStates(28, 29); }
/*  974 */             break;
/*      */           case 28: 
/*  976 */             if ((0x3FF001000000000 & l) != 0L)
/*      */             {
/*      */ 
/*  979 */               if (kind > 56) {
/*  980 */                 kind = 56;
/*      */               }
/*  982 */               jjCheckNAdd(28); }
/*  983 */             break;
/*      */           case 29: 
/*  985 */             if ((0x3FF001000000000 & l) != 0L)
/*      */             {
/*      */ 
/*  988 */               if (kind > 57) {
/*  989 */                 kind = 57;
/*      */               }
/*  991 */               jjCheckNAdd(29);
/*      */             }
/*      */             break;
/*      */           }
/*  995 */         } while (i != startsAt);
/*      */       }
/*  997 */       else if (this.curChar < '')
/*      */       {
/*  999 */         long l = 1L << (this.curChar & 0x3F);
/*      */         do
/*      */         {
/* 1002 */           switch (this.jjstateSet[(--i)])
/*      */           {
/*      */           case 0: 
/* 1005 */             if ((0x7FFFFFE87FFFFFE & l) != 0L)
/*      */             {
/*      */ 
/* 1008 */               if (kind > 56) {
/* 1009 */                 kind = 56;
/*      */               }
/* 1011 */               jjCheckNAddTwoStates(28, 29); }
/* 1012 */             break;
/*      */           case 30: 
/* 1014 */             if ((0x7FFFFFE87FFFFFE & l) != 0L)
/*      */             {
/* 1016 */               if (kind > 57) {
/* 1017 */                 kind = 57;
/*      */               }
/* 1019 */               jjCheckNAdd(29);
/*      */             }
/* 1021 */             if ((0x7FFFFFE87FFFFFE & l) != 0L)
/*      */             {
/* 1023 */               if (kind > 56) {
/* 1024 */                 kind = 56;
/*      */               }
/* 1026 */               jjCheckNAdd(28);
/*      */             }
/*      */             break;
/*      */           case 2: 
/* 1030 */             if ((0x2000000020 & l) != 0L) {
/* 1031 */               jjAddStates(29, 30);
/*      */             }
/*      */             break;
/*      */           case 6: 
/* 1035 */             if ((0xFFFFFFFFEFFFFFFF & l) != 0L) {
/* 1036 */               jjCheckNAddStates(26, 28);
/*      */             }
/*      */             break;
/*      */           case 7: 
/* 1040 */             if (this.curChar == '\\') {
/* 1041 */               this.jjstateSet[(this.jjnewStateCnt++)] = 8;
/*      */             }
/*      */             break;
/*      */           case 8: 
/* 1045 */             if (this.curChar == '\\') {
/* 1046 */               jjCheckNAddStates(26, 28);
/*      */             }
/*      */             break;
/*      */           case 11: 
/* 1050 */             if ((0xFFFFFFFFEFFFFFFF & l) != 0L) {
/* 1051 */               jjCheckNAddStates(23, 25);
/*      */             }
/*      */             break;
/*      */           case 12: 
/* 1055 */             if (this.curChar == '\\') {
/* 1056 */               this.jjstateSet[(this.jjnewStateCnt++)] = 13;
/*      */             }
/*      */             break;
/*      */           case 13: 
/* 1060 */             if (this.curChar == '\\') {
/* 1061 */               jjCheckNAddStates(23, 25);
/*      */             }
/*      */             break;
/*      */           case 20: 
/* 1065 */             if ((0x2000000020 & l) != 0L) {
/* 1066 */               jjAddStates(31, 32);
/*      */             }
/*      */             break;
/*      */           case 24: 
/* 1070 */             if ((0x2000000020 & l) != 0L) {
/* 1071 */               jjAddStates(33, 34);
/*      */             }
/*      */             break;
/*      */           case 28: 
/* 1075 */             if ((0x7FFFFFE87FFFFFE & l) != 0L)
/*      */             {
/*      */ 
/* 1078 */               if (kind > 56) {
/* 1079 */                 kind = 56;
/*      */               }
/* 1081 */               jjCheckNAdd(28); }
/* 1082 */             break;
/*      */           case 29: 
/* 1084 */             if ((0x7FFFFFE87FFFFFE & l) != 0L)
/*      */             {
/*      */ 
/* 1087 */               if (kind > 57) {
/* 1088 */                 kind = 57;
/*      */               }
/* 1090 */               jjCheckNAdd(29);
/*      */             }
/*      */             break;
/*      */           }
/* 1094 */         } while (i != startsAt);
/*      */       } else {
/* 1096 */         int hiByte = this.curChar >> '\b';
/* 1097 */         int i1 = hiByte >> 6;
/* 1098 */         long l1 = 1L << (hiByte & 0x3F);
/* 1099 */         int i2 = (this.curChar & 0xFF) >> '\006';
/* 1100 */         long l2 = 1L << (this.curChar & 0x3F);
/*      */         do
/*      */         {
/* 1103 */           switch (this.jjstateSet[(--i)])
/*      */           {
/*      */           case 0: 
/* 1106 */             if (jjCanMove_1(hiByte, i1, i2, l1, l2))
/*      */             {
/*      */ 
/* 1109 */               if (kind > 56) {
/* 1110 */                 kind = 56;
/*      */               }
/* 1112 */               jjCheckNAddTwoStates(28, 29); }
/* 1113 */             break;
/*      */           case 30: 
/* 1115 */             if (jjCanMove_1(hiByte, i1, i2, l1, l2))
/*      */             {
/* 1117 */               if (kind > 56) {
/* 1118 */                 kind = 56;
/*      */               }
/* 1120 */               jjCheckNAdd(28);
/*      */             }
/* 1122 */             if (jjCanMove_1(hiByte, i1, i2, l1, l2))
/*      */             {
/* 1124 */               if (kind > 57) {
/* 1125 */                 kind = 57;
/*      */               }
/* 1127 */               jjCheckNAdd(29);
/*      */             }
/*      */             break;
/*      */           case 6: 
/* 1131 */             if (jjCanMove_0(hiByte, i1, i2, l1, l2)) {
/* 1132 */               jjAddStates(26, 28);
/*      */             }
/*      */             break;
/*      */           case 11: 
/* 1136 */             if (jjCanMove_0(hiByte, i1, i2, l1, l2)) {
/* 1137 */               jjAddStates(23, 25);
/*      */             }
/*      */             break;
/*      */           case 28: 
/* 1141 */             if (jjCanMove_1(hiByte, i1, i2, l1, l2))
/*      */             {
/*      */ 
/* 1144 */               if (kind > 56) {
/* 1145 */                 kind = 56;
/*      */               }
/* 1147 */               jjCheckNAdd(28); }
/* 1148 */             break;
/*      */           case 29: 
/* 1150 */             if (jjCanMove_1(hiByte, i1, i2, l1, l2))
/*      */             {
/*      */ 
/* 1153 */               if (kind > 57) {
/* 1154 */                 kind = 57;
/*      */               }
/* 1156 */               jjCheckNAdd(29);
/*      */             }
/*      */             break;
/*      */           }
/* 1160 */         } while (i != startsAt);
/*      */       }
/* 1162 */       if (kind != Integer.MAX_VALUE)
/*      */       {
/* 1164 */         this.jjmatchedKind = kind;
/* 1165 */         this.jjmatchedPos = curPos;
/* 1166 */         kind = Integer.MAX_VALUE;
/*      */       }
/* 1168 */       curPos++;
/* 1169 */       if ((i = this.jjnewStateCnt) == (startsAt = 30 - (this.jjnewStateCnt = startsAt)))
/* 1170 */         return curPos;
/*      */       try {
/* 1172 */         this.curChar = this.input_stream.readChar(); } catch (IOException e) {} }
/* 1173 */     return curPos;
/*      */   }
/*      */   
/*      */   private final int jjStopStringLiteralDfa_1(int pos, long active0)
/*      */   {
/* 1178 */     switch (pos)
/*      */     {
/*      */     case 0: 
/* 1181 */       if ((active0 & 0x20000) != 0L) {
/* 1182 */         return 1;
/*      */       }
/* 1184 */       if ((active0 & 0x141D555401C000) != 0L)
/*      */       {
/* 1186 */         this.jjmatchedKind = 56;
/* 1187 */         return 30;
/*      */       }
/* 1189 */       return -1;
/*      */     case 1: 
/* 1191 */       if ((active0 & 0x41554000000) != 0L) {
/* 1192 */         return 30;
/*      */       }
/* 1194 */       if ((active0 & 0x1419400001C000) != 0L)
/*      */       {
/* 1196 */         this.jjmatchedKind = 56;
/* 1197 */         this.jjmatchedPos = 1;
/* 1198 */         return 30;
/*      */       }
/* 1200 */       return -1;
/*      */     case 2: 
/* 1202 */       if ((active0 & 0x14014000000000) != 0L) {
/* 1203 */         return 30;
/*      */       }
/* 1205 */       if ((active0 & 0x18000001C000) != 0L)
/*      */       {
/* 1207 */         this.jjmatchedKind = 56;
/* 1208 */         this.jjmatchedPos = 2;
/* 1209 */         return 30;
/*      */       }
/* 1211 */       return -1;
/*      */     case 3: 
/* 1213 */       if ((active0 & 0x14000) != 0L) {
/* 1214 */         return 30;
/*      */       }
/* 1216 */       if ((active0 & 0x180000008000) != 0L)
/*      */       {
/* 1218 */         this.jjmatchedKind = 56;
/* 1219 */         this.jjmatchedPos = 3;
/* 1220 */         return 30;
/*      */       }
/* 1222 */       return -1;
/*      */     case 4: 
/* 1224 */       if ((active0 & 0x80000008000) != 0L) {
/* 1225 */         return 30;
/*      */       }
/* 1227 */       if ((active0 & 0x100000000000) != 0L)
/*      */       {
/* 1229 */         this.jjmatchedKind = 56;
/* 1230 */         this.jjmatchedPos = 4;
/* 1231 */         return 30;
/*      */       }
/* 1233 */       return -1;
/*      */     case 5: 
/* 1235 */       if ((active0 & 0x100000000000) != 0L)
/*      */       {
/* 1237 */         this.jjmatchedKind = 56;
/* 1238 */         this.jjmatchedPos = 5;
/* 1239 */         return 30;
/*      */       }
/* 1241 */       return -1;
/*      */     case 6: 
/* 1243 */       if ((active0 & 0x100000000000) != 0L)
/*      */       {
/* 1245 */         this.jjmatchedKind = 56;
/* 1246 */         this.jjmatchedPos = 6;
/* 1247 */         return 30;
/*      */       }
/* 1249 */       return -1;
/*      */     case 7: 
/* 1251 */       if ((active0 & 0x100000000000) != 0L)
/*      */       {
/* 1253 */         this.jjmatchedKind = 56;
/* 1254 */         this.jjmatchedPos = 7;
/* 1255 */         return 30;
/*      */       }
/* 1257 */       return -1;
/*      */     case 8: 
/* 1259 */       if ((active0 & 0x100000000000) != 0L)
/*      */       {
/* 1261 */         this.jjmatchedKind = 56;
/* 1262 */         this.jjmatchedPos = 8;
/* 1263 */         return 30;
/*      */       }
/* 1265 */       return -1;
/*      */     }
/* 1267 */     return -1;
/*      */   }
/*      */   
/*      */   private final int jjStartNfa_1(int pos, long active0)
/*      */   {
/* 1272 */     return jjMoveNfa_1(jjStopStringLiteralDfa_1(pos, active0), pos + 1);
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa0_1() {
/* 1276 */     switch (this.curChar)
/*      */     {
/*      */     case '!': 
/* 1279 */       this.jjmatchedKind = 37;
/* 1280 */       return jjMoveStringLiteralDfa1_1(34359738368L);
/*      */     case '%': 
/* 1282 */       return jjStopAtPos(0, 51);
/*      */     case '&': 
/* 1284 */       return jjMoveStringLiteralDfa1_1(549755813888L);
/*      */     case '(': 
/* 1286 */       return jjStopAtPos(0, 18);
/*      */     case ')': 
/* 1288 */       return jjStopAtPos(0, 19);
/*      */     case '*': 
/* 1290 */       return jjStopAtPos(0, 45);
/*      */     case '+': 
/* 1292 */       this.jjmatchedKind = 46;
/* 1293 */       return jjMoveStringLiteralDfa1_1(9007199254740992L);
/*      */     case ',': 
/* 1295 */       return jjStopAtPos(0, 24);
/*      */     case '-': 
/* 1297 */       this.jjmatchedKind = 47;
/* 1298 */       return jjMoveStringLiteralDfa1_1(36028797018963968L);
/*      */     case '.': 
/* 1300 */       return jjStartNfaWithStates_1(0, 17, 1);
/*      */     case '/': 
/* 1302 */       return jjStopAtPos(0, 49);
/*      */     case ':': 
/* 1304 */       return jjStopAtPos(0, 22);
/*      */     case ';': 
/* 1306 */       return jjStopAtPos(0, 23);
/*      */     case '<': 
/* 1308 */       this.jjmatchedKind = 27;
/* 1309 */       return jjMoveStringLiteralDfa1_1(2147483648L);
/*      */     case '=': 
/* 1311 */       this.jjmatchedKind = 54;
/* 1312 */       return jjMoveStringLiteralDfa1_1(8589934592L);
/*      */     case '>': 
/* 1314 */       this.jjmatchedKind = 25;
/* 1315 */       return jjMoveStringLiteralDfa1_1(536870912L);
/*      */     case '?': 
/* 1317 */       return jjStopAtPos(0, 48);
/*      */     case '[': 
/* 1319 */       return jjStopAtPos(0, 20);
/*      */     case ']': 
/* 1321 */       return jjStopAtPos(0, 21);
/*      */     case 'a': 
/* 1323 */       return jjMoveStringLiteralDfa1_1(1099511627776L);
/*      */     case 'd': 
/* 1325 */       return jjMoveStringLiteralDfa1_1(1125899906842624L);
/*      */     case 'e': 
/* 1327 */       return jjMoveStringLiteralDfa1_1(8813272891392L);
/*      */     case 'f': 
/* 1329 */       return jjMoveStringLiteralDfa1_1(32768L);
/*      */     case 'g': 
/* 1331 */       return jjMoveStringLiteralDfa1_1(1140850688L);
/*      */     case 'i': 
/* 1333 */       return jjMoveStringLiteralDfa1_1(17592186044416L);
/*      */     case 'l': 
/* 1335 */       return jjMoveStringLiteralDfa1_1(4563402752L);
/*      */     case 'm': 
/* 1337 */       return jjMoveStringLiteralDfa1_1(4503599627370496L);
/*      */     case 'n': 
/* 1339 */       return jjMoveStringLiteralDfa1_1(343597449216L);
/*      */     case 'o': 
/* 1341 */       return jjMoveStringLiteralDfa1_1(4398046511104L);
/*      */     case 't': 
/* 1343 */       return jjMoveStringLiteralDfa1_1(16384L);
/*      */     case '{': 
/* 1345 */       return jjStopAtPos(0, 8);
/*      */     case '|': 
/* 1347 */       return jjMoveStringLiteralDfa1_1(2199023255552L);
/*      */     case '}': 
/* 1349 */       return jjStopAtPos(0, 9);
/*      */     }
/* 1351 */     return jjMoveNfa_1(0, 0);
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa1_1(long active0) {
/*      */     try {
/* 1356 */       this.curChar = this.input_stream.readChar();
/*      */     } catch (IOException e) {
/* 1358 */       jjStopStringLiteralDfa_1(0, active0);
/* 1359 */       return 1;
/*      */     }
/* 1361 */     switch (this.curChar)
/*      */     {
/*      */     case '&': 
/* 1364 */       if ((active0 & 0x8000000000) != 0L) {
/* 1365 */         return jjStopAtPos(1, 39);
/*      */       }
/*      */       break;
/*      */     case '=': 
/* 1369 */       if ((active0 & 0x20000000) != 0L)
/* 1370 */         return jjStopAtPos(1, 29);
/* 1371 */       if ((active0 & 0x80000000) != 0L)
/* 1372 */         return jjStopAtPos(1, 31);
/* 1373 */       if ((active0 & 0x200000000) != 0L)
/* 1374 */         return jjStopAtPos(1, 33);
/* 1375 */       if ((active0 & 0x800000000) != 0L)
/* 1376 */         return jjStopAtPos(1, 35);
/* 1377 */       if ((active0 & 0x20000000000000) != 0L) {
/* 1378 */         return jjStopAtPos(1, 53);
/*      */       }
/*      */       break;
/*      */     case '>': 
/* 1382 */       if ((active0 & 0x80000000000000) != 0L) {
/* 1383 */         return jjStopAtPos(1, 55);
/*      */       }
/*      */       break;
/*      */     case 'a': 
/* 1387 */       return jjMoveStringLiteralDfa2_1(active0, 32768L);
/*      */     case 'e': 
/* 1389 */       if ((active0 & 0x40000000) != 0L)
/* 1390 */         return jjStartNfaWithStates_1(1, 30, 30);
/* 1391 */       if ((active0 & 0x100000000) != 0L)
/* 1392 */         return jjStartNfaWithStates_1(1, 32, 30);
/* 1393 */       if ((active0 & 0x1000000000) != 0L) {
/* 1394 */         return jjStartNfaWithStates_1(1, 36, 30);
/*      */       }
/*      */       break;
/*      */     case 'i': 
/* 1398 */       return jjMoveStringLiteralDfa2_1(active0, 1125899906842624L);
/*      */     case 'm': 
/* 1400 */       return jjMoveStringLiteralDfa2_1(active0, 8796093022208L);
/*      */     case 'n': 
/* 1402 */       return jjMoveStringLiteralDfa2_1(active0, 18691697672192L);
/*      */     case 'o': 
/* 1404 */       return jjMoveStringLiteralDfa2_1(active0, 4503874505277440L);
/*      */     case 'q': 
/* 1406 */       if ((active0 & 0x400000000) != 0L) {
/* 1407 */         return jjStartNfaWithStates_1(1, 34, 30);
/*      */       }
/*      */       break;
/*      */     case 'r': 
/* 1411 */       if ((active0 & 0x40000000000) != 0L) {
/* 1412 */         return jjStartNfaWithStates_1(1, 42, 30);
/*      */       }
/* 1414 */       return jjMoveStringLiteralDfa2_1(active0, 16384L);
/*      */     case 't': 
/* 1416 */       if ((active0 & 0x4000000) != 0L)
/* 1417 */         return jjStartNfaWithStates_1(1, 26, 30);
/* 1418 */       if ((active0 & 0x10000000) != 0L) {
/* 1419 */         return jjStartNfaWithStates_1(1, 28, 30);
/*      */       }
/*      */       break;
/*      */     case 'u': 
/* 1423 */       return jjMoveStringLiteralDfa2_1(active0, 65536L);
/*      */     case '|': 
/* 1425 */       if ((active0 & 0x20000000000) != 0L) {
/* 1426 */         return jjStopAtPos(1, 41);
/*      */       }
/*      */       
/*      */       break;
/*      */     }
/*      */     
/* 1432 */     return jjStartNfa_1(0, active0);
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa2_1(long old0, long active0) {
/* 1436 */     if ((active0 &= old0) == 0L)
/* 1437 */       return jjStartNfa_1(0, old0);
/*      */     try {
/* 1439 */       this.curChar = this.input_stream.readChar();
/*      */     } catch (IOException e) {
/* 1441 */       jjStopStringLiteralDfa_1(1, active0);
/* 1442 */       return 2;
/*      */     }
/* 1444 */     switch (this.curChar)
/*      */     {
/*      */     case 'd': 
/* 1447 */       if ((active0 & 0x10000000000) != 0L)
/* 1448 */         return jjStartNfaWithStates_1(2, 40, 30);
/* 1449 */       if ((active0 & 0x10000000000000) != 0L) {
/* 1450 */         return jjStartNfaWithStates_1(2, 52, 30);
/*      */       }
/*      */       break;
/*      */     case 'l': 
/* 1454 */       return jjMoveStringLiteralDfa3_1(active0, 98304L);
/*      */     case 'p': 
/* 1456 */       return jjMoveStringLiteralDfa3_1(active0, 8796093022208L);
/*      */     case 's': 
/* 1458 */       return jjMoveStringLiteralDfa3_1(active0, 17592186044416L);
/*      */     case 't': 
/* 1460 */       if ((active0 & 0x4000000000) != 0L) {
/* 1461 */         return jjStartNfaWithStates_1(2, 38, 30);
/*      */       }
/*      */       break;
/*      */     case 'u': 
/* 1465 */       return jjMoveStringLiteralDfa3_1(active0, 16384L);
/*      */     case 'v': 
/* 1467 */       if ((active0 & 0x4000000000000) != 0L) {
/* 1468 */         return jjStartNfaWithStates_1(2, 50, 30);
/*      */       }
/*      */       
/*      */       break;
/*      */     }
/*      */     
/* 1474 */     return jjStartNfa_1(1, active0);
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa3_1(long old0, long active0) {
/* 1478 */     if ((active0 &= old0) == 0L)
/* 1479 */       return jjStartNfa_1(1, old0);
/*      */     try {
/* 1481 */       this.curChar = this.input_stream.readChar();
/*      */     } catch (IOException e) {
/* 1483 */       jjStopStringLiteralDfa_1(2, active0);
/* 1484 */       return 3;
/*      */     }
/* 1486 */     switch (this.curChar)
/*      */     {
/*      */     case 'e': 
/* 1489 */       if ((active0 & 0x4000) != 0L) {
/* 1490 */         return jjStartNfaWithStates_1(3, 14, 30);
/*      */       }
/*      */       break;
/*      */     case 'l': 
/* 1494 */       if ((active0 & 0x10000) != 0L) {
/* 1495 */         return jjStartNfaWithStates_1(3, 16, 30);
/*      */       }
/*      */       break;
/*      */     case 's': 
/* 1499 */       return jjMoveStringLiteralDfa4_1(active0, 32768L);
/*      */     case 't': 
/* 1501 */       return jjMoveStringLiteralDfa4_1(active0, 26388279066624L);
/*      */     }
/*      */     
/*      */     
/* 1505 */     return jjStartNfa_1(2, active0);
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa4_1(long old0, long active0) {
/* 1509 */     if ((active0 &= old0) == 0L)
/* 1510 */       return jjStartNfa_1(2, old0);
/*      */     try {
/* 1512 */       this.curChar = this.input_stream.readChar();
/*      */     } catch (IOException e) {
/* 1514 */       jjStopStringLiteralDfa_1(3, active0);
/* 1515 */       return 4;
/*      */     }
/* 1517 */     switch (this.curChar)
/*      */     {
/*      */     case 'a': 
/* 1520 */       return jjMoveStringLiteralDfa5_1(active0, 17592186044416L);
/*      */     case 'e': 
/* 1522 */       if ((active0 & 0x8000) != 0L) {
/* 1523 */         return jjStartNfaWithStates_1(4, 15, 30);
/*      */       }
/*      */       break;
/*      */     case 'y': 
/* 1527 */       if ((active0 & 0x80000000000) != 0L) {
/* 1528 */         return jjStartNfaWithStates_1(4, 43, 30);
/*      */       }
/*      */       
/*      */       break;
/*      */     }
/*      */     
/* 1534 */     return jjStartNfa_1(3, active0);
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa5_1(long old0, long active0) {
/* 1538 */     if ((active0 &= old0) == 0L)
/* 1539 */       return jjStartNfa_1(3, old0);
/*      */     try {
/* 1541 */       this.curChar = this.input_stream.readChar();
/*      */     } catch (IOException e) {
/* 1543 */       jjStopStringLiteralDfa_1(4, active0);
/* 1544 */       return 5;
/*      */     }
/* 1546 */     switch (this.curChar)
/*      */     {
/*      */     case 'n': 
/* 1549 */       return jjMoveStringLiteralDfa6_1(active0, 17592186044416L);
/*      */     }
/*      */     
/*      */     
/* 1553 */     return jjStartNfa_1(4, active0);
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa6_1(long old0, long active0) {
/* 1557 */     if ((active0 &= old0) == 0L)
/* 1558 */       return jjStartNfa_1(4, old0);
/*      */     try {
/* 1560 */       this.curChar = this.input_stream.readChar();
/*      */     } catch (IOException e) {
/* 1562 */       jjStopStringLiteralDfa_1(5, active0);
/* 1563 */       return 6;
/*      */     }
/* 1565 */     switch (this.curChar)
/*      */     {
/*      */     case 'c': 
/* 1568 */       return jjMoveStringLiteralDfa7_1(active0, 17592186044416L);
/*      */     }
/*      */     
/*      */     
/* 1572 */     return jjStartNfa_1(5, active0);
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa7_1(long old0, long active0) {
/* 1576 */     if ((active0 &= old0) == 0L)
/* 1577 */       return jjStartNfa_1(5, old0);
/*      */     try {
/* 1579 */       this.curChar = this.input_stream.readChar();
/*      */     } catch (IOException e) {
/* 1581 */       jjStopStringLiteralDfa_1(6, active0);
/* 1582 */       return 7;
/*      */     }
/* 1584 */     switch (this.curChar)
/*      */     {
/*      */     case 'e': 
/* 1587 */       return jjMoveStringLiteralDfa8_1(active0, 17592186044416L);
/*      */     }
/*      */     
/*      */     
/* 1591 */     return jjStartNfa_1(6, active0);
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa8_1(long old0, long active0) {
/* 1595 */     if ((active0 &= old0) == 0L)
/* 1596 */       return jjStartNfa_1(6, old0);
/*      */     try {
/* 1598 */       this.curChar = this.input_stream.readChar();
/*      */     } catch (IOException e) {
/* 1600 */       jjStopStringLiteralDfa_1(7, active0);
/* 1601 */       return 8;
/*      */     }
/* 1603 */     switch (this.curChar)
/*      */     {
/*      */     case 'o': 
/* 1606 */       return jjMoveStringLiteralDfa9_1(active0, 17592186044416L);
/*      */     }
/*      */     
/*      */     
/* 1610 */     return jjStartNfa_1(7, active0);
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa9_1(long old0, long active0) {
/* 1614 */     if ((active0 &= old0) == 0L)
/* 1615 */       return jjStartNfa_1(7, old0);
/*      */     try {
/* 1617 */       this.curChar = this.input_stream.readChar();
/*      */     } catch (IOException e) {
/* 1619 */       jjStopStringLiteralDfa_1(8, active0);
/* 1620 */       return 9;
/*      */     }
/* 1622 */     switch (this.curChar)
/*      */     {
/*      */     case 'f': 
/* 1625 */       if ((active0 & 0x100000000000) != 0L) {
/* 1626 */         return jjStartNfaWithStates_1(9, 44, 30);
/*      */       }
/*      */       
/*      */       break;
/*      */     }
/*      */     
/* 1632 */     return jjStartNfa_1(8, active0);
/*      */   }
/*      */   
/*      */   private int jjStartNfaWithStates_1(int pos, int kind, int state) {
/* 1636 */     this.jjmatchedKind = kind;
/* 1637 */     this.jjmatchedPos = pos;
/* 1638 */     try { this.curChar = this.input_stream.readChar();
/* 1639 */     } catch (IOException e) { return pos + 1; }
/* 1640 */     return jjMoveNfa_1(state, pos + 1);
/*      */   }
/*      */   
/*      */   private int jjMoveNfa_1(int startState, int curPos) {
/* 1644 */     int startsAt = 0;
/* 1645 */     this.jjnewStateCnt = 30;
/* 1646 */     int i = 1;
/* 1647 */     this.jjstateSet[0] = startState;
/* 1648 */     int kind = Integer.MAX_VALUE;
/*      */     for (;;)
/*      */     {
/* 1651 */       if (++this.jjround == Integer.MAX_VALUE) {
/* 1652 */         ReInitRounds();
/*      */       }
/* 1654 */       if (this.curChar < '@')
/*      */       {
/* 1656 */         long l = 1L << this.curChar;
/*      */         do
/*      */         {
/* 1659 */           switch (this.jjstateSet[(--i)])
/*      */           {
/*      */           case 0: 
/* 1662 */             if ((0x3FF000000000000 & l) != 0L)
/*      */             {
/* 1664 */               if (kind > 10) {
/* 1665 */                 kind = 10;
/*      */               }
/* 1667 */               jjCheckNAddStates(18, 22);
/*      */             }
/* 1669 */             else if ((0x1800000000 & l) != 0L)
/*      */             {
/* 1671 */               if (kind > 56) {
/* 1672 */                 kind = 56;
/*      */               }
/* 1674 */               jjCheckNAddTwoStates(28, 29);
/*      */             }
/* 1676 */             else if (this.curChar == '\'') {
/* 1677 */               jjCheckNAddStates(23, 25);
/* 1678 */             } else if (this.curChar == '"') {
/* 1679 */               jjCheckNAddStates(26, 28);
/* 1680 */             } else if (this.curChar == '.') {
/* 1681 */               jjCheckNAdd(1);
/*      */             }
/*      */             break;
/*      */           case 30: 
/* 1685 */             if ((0x3FF001000000000 & l) != 0L)
/*      */             {
/* 1687 */               if (kind > 57) {
/* 1688 */                 kind = 57;
/*      */               }
/* 1690 */               jjCheckNAdd(29);
/*      */             }
/* 1692 */             if ((0x3FF001000000000 & l) != 0L)
/*      */             {
/* 1694 */               if (kind > 56) {
/* 1695 */                 kind = 56;
/*      */               }
/* 1697 */               jjCheckNAdd(28);
/*      */             }
/*      */             break;
/*      */           case 1: 
/* 1701 */             if ((0x3FF000000000000 & l) != 0L)
/*      */             {
/*      */ 
/* 1704 */               if (kind > 11) {
/* 1705 */                 kind = 11;
/*      */               }
/* 1707 */               jjCheckNAddTwoStates(1, 2); }
/* 1708 */             break;
/*      */           case 3: 
/* 1710 */             if ((0x280000000000 & l) != 0L) {
/* 1711 */               jjCheckNAdd(4);
/*      */             }
/*      */             break;
/*      */           case 4: 
/* 1715 */             if ((0x3FF000000000000 & l) != 0L)
/*      */             {
/*      */ 
/* 1718 */               if (kind > 11) {
/* 1719 */                 kind = 11;
/*      */               }
/* 1721 */               jjCheckNAdd(4); }
/* 1722 */             break;
/*      */           case 5: 
/* 1724 */             if (this.curChar == '"') {
/* 1725 */               jjCheckNAddStates(26, 28);
/*      */             }
/*      */             break;
/*      */           case 6: 
/* 1729 */             if ((0xFFFFFFFBFFFFFFFF & l) != 0L) {
/* 1730 */               jjCheckNAddStates(26, 28);
/*      */             }
/*      */             break;
/*      */           case 8: 
/* 1734 */             if ((0x8400000000 & l) != 0L) {
/* 1735 */               jjCheckNAddStates(26, 28);
/*      */             }
/*      */             break;
/*      */           case 9: 
/* 1739 */             if ((this.curChar == '"') && (kind > 13)) {
/* 1740 */               kind = 13;
/*      */             }
/*      */             break;
/*      */           case 10: 
/* 1744 */             if (this.curChar == '\'') {
/* 1745 */               jjCheckNAddStates(23, 25);
/*      */             }
/*      */             break;
/*      */           case 11: 
/* 1749 */             if ((0xFFFFFF7FFFFFFFFF & l) != 0L) {
/* 1750 */               jjCheckNAddStates(23, 25);
/*      */             }
/*      */             break;
/*      */           case 13: 
/* 1754 */             if ((0x8400000000 & l) != 0L) {
/* 1755 */               jjCheckNAddStates(23, 25);
/*      */             }
/*      */             break;
/*      */           case 14: 
/* 1759 */             if ((this.curChar == '\'') && (kind > 13)) {
/* 1760 */               kind = 13;
/*      */             }
/*      */             break;
/*      */           case 15: 
/* 1764 */             if ((0x3FF000000000000 & l) != 0L)
/*      */             {
/*      */ 
/* 1767 */               if (kind > 10) {
/* 1768 */                 kind = 10;
/*      */               }
/* 1770 */               jjCheckNAddStates(18, 22); }
/* 1771 */             break;
/*      */           case 16: 
/* 1773 */             if ((0x3FF000000000000 & l) != 0L)
/*      */             {
/*      */ 
/* 1776 */               if (kind > 10) {
/* 1777 */                 kind = 10;
/*      */               }
/* 1779 */               jjCheckNAdd(16); }
/* 1780 */             break;
/*      */           case 17: 
/* 1782 */             if ((0x3FF000000000000 & l) != 0L) {
/* 1783 */               jjCheckNAddTwoStates(17, 18);
/*      */             }
/*      */             break;
/*      */           case 18: 
/* 1787 */             if (this.curChar == '.')
/*      */             {
/*      */ 
/* 1790 */               if (kind > 11) {
/* 1791 */                 kind = 11;
/*      */               }
/* 1793 */               jjCheckNAddTwoStates(19, 20); }
/* 1794 */             break;
/*      */           case 19: 
/* 1796 */             if ((0x3FF000000000000 & l) != 0L)
/*      */             {
/*      */ 
/* 1799 */               if (kind > 11) {
/* 1800 */                 kind = 11;
/*      */               }
/* 1802 */               jjCheckNAddTwoStates(19, 20); }
/* 1803 */             break;
/*      */           case 21: 
/* 1805 */             if ((0x280000000000 & l) != 0L) {
/* 1806 */               jjCheckNAdd(22);
/*      */             }
/*      */             break;
/*      */           case 22: 
/* 1810 */             if ((0x3FF000000000000 & l) != 0L)
/*      */             {
/*      */ 
/* 1813 */               if (kind > 11) {
/* 1814 */                 kind = 11;
/*      */               }
/* 1816 */               jjCheckNAdd(22); }
/* 1817 */             break;
/*      */           case 23: 
/* 1819 */             if ((0x3FF000000000000 & l) != 0L) {
/* 1820 */               jjCheckNAddTwoStates(23, 24);
/*      */             }
/*      */             break;
/*      */           case 25: 
/* 1824 */             if ((0x280000000000 & l) != 0L) {
/* 1825 */               jjCheckNAdd(26);
/*      */             }
/*      */             break;
/*      */           case 26: 
/* 1829 */             if ((0x3FF000000000000 & l) != 0L)
/*      */             {
/*      */ 
/* 1832 */               if (kind > 11) {
/* 1833 */                 kind = 11;
/*      */               }
/* 1835 */               jjCheckNAdd(26); }
/* 1836 */             break;
/*      */           case 27: 
/* 1838 */             if ((0x1800000000 & l) != 0L)
/*      */             {
/*      */ 
/* 1841 */               if (kind > 56) {
/* 1842 */                 kind = 56;
/*      */               }
/* 1844 */               jjCheckNAddTwoStates(28, 29); }
/* 1845 */             break;
/*      */           case 28: 
/* 1847 */             if ((0x3FF001000000000 & l) != 0L)
/*      */             {
/*      */ 
/* 1850 */               if (kind > 56) {
/* 1851 */                 kind = 56;
/*      */               }
/* 1853 */               jjCheckNAdd(28); }
/* 1854 */             break;
/*      */           case 29: 
/* 1856 */             if ((0x3FF001000000000 & l) != 0L)
/*      */             {
/*      */ 
/* 1859 */               if (kind > 57) {
/* 1860 */                 kind = 57;
/*      */               }
/* 1862 */               jjCheckNAdd(29);
/*      */             }
/*      */             break;
/*      */           }
/* 1866 */         } while (i != startsAt);
/*      */       }
/* 1868 */       else if (this.curChar < '')
/*      */       {
/* 1870 */         long l = 1L << (this.curChar & 0x3F);
/*      */         do
/*      */         {
/* 1873 */           switch (this.jjstateSet[(--i)])
/*      */           {
/*      */           case 0: 
/* 1876 */             if ((0x7FFFFFE87FFFFFE & l) != 0L)
/*      */             {
/*      */ 
/* 1879 */               if (kind > 56) {
/* 1880 */                 kind = 56;
/*      */               }
/* 1882 */               jjCheckNAddTwoStates(28, 29); }
/* 1883 */             break;
/*      */           case 30: 
/* 1885 */             if ((0x7FFFFFE87FFFFFE & l) != 0L)
/*      */             {
/* 1887 */               if (kind > 57) {
/* 1888 */                 kind = 57;
/*      */               }
/* 1890 */               jjCheckNAdd(29);
/*      */             }
/* 1892 */             if ((0x7FFFFFE87FFFFFE & l) != 0L)
/*      */             {
/* 1894 */               if (kind > 56) {
/* 1895 */                 kind = 56;
/*      */               }
/* 1897 */               jjCheckNAdd(28);
/*      */             }
/*      */             break;
/*      */           case 2: 
/* 1901 */             if ((0x2000000020 & l) != 0L) {
/* 1902 */               jjAddStates(29, 30);
/*      */             }
/*      */             break;
/*      */           case 6: 
/* 1906 */             if ((0xFFFFFFFFEFFFFFFF & l) != 0L) {
/* 1907 */               jjCheckNAddStates(26, 28);
/*      */             }
/*      */             break;
/*      */           case 7: 
/* 1911 */             if (this.curChar == '\\') {
/* 1912 */               this.jjstateSet[(this.jjnewStateCnt++)] = 8;
/*      */             }
/*      */             break;
/*      */           case 8: 
/* 1916 */             if (this.curChar == '\\') {
/* 1917 */               jjCheckNAddStates(26, 28);
/*      */             }
/*      */             break;
/*      */           case 11: 
/* 1921 */             if ((0xFFFFFFFFEFFFFFFF & l) != 0L) {
/* 1922 */               jjCheckNAddStates(23, 25);
/*      */             }
/*      */             break;
/*      */           case 12: 
/* 1926 */             if (this.curChar == '\\') {
/* 1927 */               this.jjstateSet[(this.jjnewStateCnt++)] = 13;
/*      */             }
/*      */             break;
/*      */           case 13: 
/* 1931 */             if (this.curChar == '\\') {
/* 1932 */               jjCheckNAddStates(23, 25);
/*      */             }
/*      */             break;
/*      */           case 20: 
/* 1936 */             if ((0x2000000020 & l) != 0L) {
/* 1937 */               jjAddStates(31, 32);
/*      */             }
/*      */             break;
/*      */           case 24: 
/* 1941 */             if ((0x2000000020 & l) != 0L) {
/* 1942 */               jjAddStates(33, 34);
/*      */             }
/*      */             break;
/*      */           case 28: 
/* 1946 */             if ((0x7FFFFFE87FFFFFE & l) != 0L)
/*      */             {
/*      */ 
/* 1949 */               if (kind > 56) {
/* 1950 */                 kind = 56;
/*      */               }
/* 1952 */               jjCheckNAdd(28); }
/* 1953 */             break;
/*      */           case 29: 
/* 1955 */             if ((0x7FFFFFE87FFFFFE & l) != 0L)
/*      */             {
/*      */ 
/* 1958 */               if (kind > 57) {
/* 1959 */                 kind = 57;
/*      */               }
/* 1961 */               jjCheckNAdd(29);
/*      */             }
/*      */             break;
/*      */           }
/* 1965 */         } while (i != startsAt);
/*      */       } else {
/* 1967 */         int hiByte = this.curChar >> '\b';
/* 1968 */         int i1 = hiByte >> 6;
/* 1969 */         long l1 = 1L << (hiByte & 0x3F);
/* 1970 */         int i2 = (this.curChar & 0xFF) >> '\006';
/* 1971 */         long l2 = 1L << (this.curChar & 0x3F);
/*      */         do
/*      */         {
/* 1974 */           switch (this.jjstateSet[(--i)])
/*      */           {
/*      */           case 0: 
/* 1977 */             if (jjCanMove_1(hiByte, i1, i2, l1, l2))
/*      */             {
/*      */ 
/* 1980 */               if (kind > 56) {
/* 1981 */                 kind = 56;
/*      */               }
/* 1983 */               jjCheckNAddTwoStates(28, 29); }
/* 1984 */             break;
/*      */           case 30: 
/* 1986 */             if (jjCanMove_1(hiByte, i1, i2, l1, l2))
/*      */             {
/* 1988 */               if (kind > 56) {
/* 1989 */                 kind = 56;
/*      */               }
/* 1991 */               jjCheckNAdd(28);
/*      */             }
/* 1993 */             if (jjCanMove_1(hiByte, i1, i2, l1, l2))
/*      */             {
/* 1995 */               if (kind > 57) {
/* 1996 */                 kind = 57;
/*      */               }
/* 1998 */               jjCheckNAdd(29);
/*      */             }
/*      */             break;
/*      */           case 6: 
/* 2002 */             if (jjCanMove_0(hiByte, i1, i2, l1, l2)) {
/* 2003 */               jjAddStates(26, 28);
/*      */             }
/*      */             break;
/*      */           case 11: 
/* 2007 */             if (jjCanMove_0(hiByte, i1, i2, l1, l2)) {
/* 2008 */               jjAddStates(23, 25);
/*      */             }
/*      */             break;
/*      */           case 28: 
/* 2012 */             if (jjCanMove_1(hiByte, i1, i2, l1, l2))
/*      */             {
/*      */ 
/* 2015 */               if (kind > 56) {
/* 2016 */                 kind = 56;
/*      */               }
/* 2018 */               jjCheckNAdd(28); }
/* 2019 */             break;
/*      */           case 29: 
/* 2021 */             if (jjCanMove_1(hiByte, i1, i2, l1, l2))
/*      */             {
/*      */ 
/* 2024 */               if (kind > 57) {
/* 2025 */                 kind = 57;
/*      */               }
/* 2027 */               jjCheckNAdd(29);
/*      */             }
/*      */             break;
/*      */           }
/* 2031 */         } while (i != startsAt);
/*      */       }
/* 2033 */       if (kind != Integer.MAX_VALUE)
/*      */       {
/* 2035 */         this.jjmatchedKind = kind;
/* 2036 */         this.jjmatchedPos = curPos;
/* 2037 */         kind = Integer.MAX_VALUE;
/*      */       }
/* 2039 */       curPos++;
/* 2040 */       if ((i = this.jjnewStateCnt) == (startsAt = 30 - (this.jjnewStateCnt = startsAt)))
/* 2041 */         return curPos;
/*      */       try {
/* 2043 */         this.curChar = this.input_stream.readChar(); } catch (IOException e) {} }
/* 2044 */     return curPos;
/*      */   }
/*      */   
/* 2047 */   static final int[] jjnextStates = { 0, 1, 3, 4, 2, 0, 1, 4, 2, 0, 1, 4, 5, 2, 0, 1, 2, 6, 16, 17, 18, 23, 24, 11, 12, 14, 6, 7, 9, 3, 4, 21, 22, 25, 26 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final boolean jjCanMove_0(int hiByte, int i1, int i2, long l1, long l2)
/*      */   {
/* 2054 */     switch (hiByte)
/*      */     {
/*      */     case 0: 
/* 2057 */       return (jjbitVec2[i2] & l2) != 0L;
/*      */     }
/* 2059 */     if ((jjbitVec0[i1] & l1) != 0L) {
/* 2060 */       return true;
/*      */     }
/* 2062 */     return false;
/*      */   }
/*      */   
/*      */   private static final boolean jjCanMove_1(int hiByte, int i1, int i2, long l1, long l2)
/*      */   {
/* 2067 */     switch (hiByte)
/*      */     {
/*      */     case 0: 
/* 2070 */       return (jjbitVec4[i2] & l2) != 0L;
/*      */     case 48: 
/* 2072 */       return (jjbitVec5[i2] & l2) != 0L;
/*      */     case 49: 
/* 2074 */       return (jjbitVec6[i2] & l2) != 0L;
/*      */     case 51: 
/* 2076 */       return (jjbitVec7[i2] & l2) != 0L;
/*      */     case 61: 
/* 2078 */       return (jjbitVec8[i2] & l2) != 0L;
/*      */     }
/* 2080 */     if ((jjbitVec3[i1] & l1) != 0L) {
/* 2081 */       return true;
/*      */     }
/* 2083 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/* 2088 */   public static final String[] jjstrLiteralImages = { "", null, "${", "#{", null, null, null, null, "{", "}", null, null, null, null, "true", "false", "null", ".", "(", ")", "[", "]", ":", ";", ",", ">", "gt", "<", "lt", ">=", "ge", "<=", "le", "==", "eq", "!=", "ne", "!", "not", "&&", "and", "||", "or", "empty", "instanceof", "*", "+", "-", "?", "/", "div", "%", "mod", "+=", "=", "->", null, null, null, null, null, null };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2099 */   public static final String[] lexStateNames = { "DEFAULT", "IN_EXPRESSION", "IN_SET_OR_MAP" };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2106 */   public static final int[] jjnewLexState = { -1, -1, 1, 1, -1, -1, -1, -1, 2, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/* 2111 */   static final long[] jjtoToken = { 2594073385365401359L };
/*      */   
/*      */ 
/* 2114 */   static final long[] jjtoSkip = { 240L };
/*      */   
/*      */   protected SimpleCharStream input_stream;
/*      */   
/* 2118 */   private final int[] jjrounds = new int[30];
/* 2119 */   private final int[] jjstateSet = new int[60];
/* 2120 */   private final StringBuilder jjimage = new StringBuilder();
/* 2121 */   private StringBuilder image = this.jjimage;
/*      */   
/*      */   private int jjimageLen;
/*      */   
/*      */   private int lengthOfMatch;
/*      */   protected char curChar;
/*      */   
/*      */   public ELParserTokenManager(SimpleCharStream stream)
/*      */   {
/* 2130 */     this.input_stream = stream;
/*      */   }
/*      */   
/*      */   public ELParserTokenManager(SimpleCharStream stream, int lexState)
/*      */   {
/* 2135 */     this(stream);
/* 2136 */     SwitchTo(lexState);
/*      */   }
/*      */   
/*      */ 
/*      */   public void ReInit(SimpleCharStream stream)
/*      */   {
/* 2142 */     this.jjmatchedPos = (this.jjnewStateCnt = 0);
/* 2143 */     this.curLexState = this.defaultLexState;
/* 2144 */     this.input_stream = stream;
/* 2145 */     ReInitRounds();
/*      */   }
/*      */   
/*      */   private void ReInitRounds()
/*      */   {
/* 2150 */     this.jjround = -2147483647;
/* 2151 */     for (int i = 30; i-- > 0;) {
/* 2152 */       this.jjrounds[i] = Integer.MIN_VALUE;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void ReInit(SimpleCharStream stream, int lexState)
/*      */   {
/* 2159 */     ReInit(stream);
/* 2160 */     SwitchTo(lexState);
/*      */   }
/*      */   
/*      */ 
/*      */   public void SwitchTo(int lexState)
/*      */   {
/* 2166 */     if ((lexState >= 3) || (lexState < 0)) {
/* 2167 */       throw new TokenMgrError("Error: Ignoring invalid lexical state : " + lexState + ". State unchanged.", 2);
/*      */     }
/* 2169 */     this.curLexState = lexState;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Token jjFillToken()
/*      */   {
/* 2181 */     String im = jjstrLiteralImages[this.jjmatchedKind];
/* 2182 */     String curTokenImage = im == null ? this.input_stream.GetImage() : im;
/* 2183 */     int beginLine = this.input_stream.getBeginLine();
/* 2184 */     int beginColumn = this.input_stream.getBeginColumn();
/* 2185 */     int endLine = this.input_stream.getEndLine();
/* 2186 */     int endColumn = this.input_stream.getEndColumn();
/* 2187 */     Token t = Token.newToken(this.jjmatchedKind, curTokenImage);
/*      */     
/* 2189 */     t.beginLine = beginLine;
/* 2190 */     t.endLine = endLine;
/* 2191 */     t.beginColumn = beginColumn;
/* 2192 */     t.endColumn = endColumn;
/*      */     
/* 2194 */     return t;
/*      */   }
/*      */   
/* 2197 */   int curLexState = 0;
/* 2198 */   int defaultLexState = 0;
/*      */   
/*      */   int jjnewStateCnt;
/*      */   
/*      */   int jjround;
/*      */   int jjmatchedPos;
/*      */   int jjmatchedKind;
/*      */   
/*      */   public Token getNextToken()
/*      */   {
/* 2208 */     int curPos = 0;
/*      */     
/*      */ 
/*      */     for (;;)
/*      */     {
/*      */       try
/*      */       {
/* 2215 */         this.curChar = this.input_stream.BeginToken();
/*      */       }
/*      */       catch (IOException e)
/*      */       {
/* 2219 */         this.jjmatchedKind = 0;
/* 2220 */         return jjFillToken();
/*      */       }
/*      */       
/* 2223 */       this.image = this.jjimage;
/* 2224 */       this.image.setLength(0);
/* 2225 */       this.jjimageLen = 0;
/*      */       
/* 2227 */       switch (this.curLexState)
/*      */       {
/*      */       case 0: 
/* 2230 */         this.jjmatchedKind = Integer.MAX_VALUE;
/* 2231 */         this.jjmatchedPos = 0;
/* 2232 */         curPos = jjMoveStringLiteralDfa0_0();
/* 2233 */         break;
/*      */       case 1:  try {
/* 2235 */           this.input_stream.backup(0);
/* 2236 */           while ((this.curChar <= ' ') && ((0x100002600 & 1L << this.curChar) != 0L)) {
/* 2237 */             this.curChar = this.input_stream.BeginToken();
/*      */           }
/*      */         } catch (IOException e1) {}
/* 2240 */         continue;
/* 2241 */         this.jjmatchedKind = Integer.MAX_VALUE;
/* 2242 */         this.jjmatchedPos = 0;
/* 2243 */         curPos = jjMoveStringLiteralDfa0_1();
/* 2244 */         if ((this.jjmatchedPos == 0) && (this.jjmatchedKind > 61))
/*      */         {
/* 2246 */           this.jjmatchedKind = 61; }
/*      */         break;
/*      */       case 2: 
/*      */         try {
/* 2250 */           this.input_stream.backup(0);
/* 2251 */           while ((this.curChar <= ' ') && ((0x100002600 & 1L << this.curChar) != 0L)) {
/* 2252 */             this.curChar = this.input_stream.BeginToken();
/*      */           }
/*      */         } catch (IOException e1) {}
/* 2255 */         continue;
/* 2256 */         this.jjmatchedKind = Integer.MAX_VALUE;
/* 2257 */         this.jjmatchedPos = 0;
/* 2258 */         curPos = jjMoveStringLiteralDfa0_2();
/* 2259 */         if ((this.jjmatchedPos == 0) && (this.jjmatchedKind > 61))
/*      */         {
/* 2261 */           this.jjmatchedKind = 61;
/*      */         }
/*      */       
/*      */       default: 
/* 2265 */         if (this.jjmatchedKind == Integer.MAX_VALUE)
/*      */           break label407;
/* 2267 */         if (this.jjmatchedPos + 1 < curPos) {
/* 2268 */           this.input_stream.backup(curPos - this.jjmatchedPos - 1);
/*      */         }
/* 2270 */         if ((jjtoToken[(this.jjmatchedKind >> 6)] & 1L << (this.jjmatchedKind & 0x3F)) != 0L)
/*      */         {
/* 2272 */           Token matchedToken = jjFillToken();
/* 2273 */           TokenLexicalActions(matchedToken);
/* 2274 */           if (jjnewLexState[this.jjmatchedKind] != -1) {
/* 2275 */             this.curLexState = jjnewLexState[this.jjmatchedKind];
/*      */           }
/* 2277 */           return matchedToken;
/*      */         }
/* 2279 */         if (jjnewLexState[this.jjmatchedKind] != -1)
/* 2280 */           this.curLexState = jjnewLexState[this.jjmatchedKind];
/*      */         break;
/*      */       }
/*      */     }
/*      */     label407:
/* 2285 */     int error_line = this.input_stream.getEndLine();
/* 2286 */     int error_column = this.input_stream.getEndColumn();
/* 2287 */     String error_after = null;
/* 2288 */     boolean EOFSeen = false;
/* 2289 */     try { this.input_stream.readChar();this.input_stream.backup(1);
/*      */     } catch (IOException e1) {
/* 2291 */       EOFSeen = true;
/* 2292 */       error_after = curPos <= 1 ? "" : this.input_stream.GetImage();
/* 2293 */       if ((this.curChar == '\n') || (this.curChar == '\r')) {
/* 2294 */         error_line++;
/* 2295 */         error_column = 0;
/*      */       } else {
/* 2297 */         error_column++;
/*      */       }
/*      */     }
/* 2300 */     if (!EOFSeen) {
/* 2301 */       this.input_stream.backup(1);
/* 2302 */       error_after = curPos <= 1 ? "" : this.input_stream.GetImage();
/*      */     }
/* 2304 */     throw new TokenMgrError(EOFSeen, this.curLexState, error_line, error_column, error_after, this.curChar, 0);
/*      */   }
/*      */   
/*      */ 
/*      */   void TokenLexicalActions(Token matchedToken)
/*      */   {
/* 2310 */     switch (this.jjmatchedKind)
/*      */     {
/*      */     case 2: 
/* 2313 */       this.image.append(jjstrLiteralImages[2]);
/* 2314 */       this.lengthOfMatch = jjstrLiteralImages[2].length();
/* 2315 */       this.deque.push(Integer.valueOf(0));
/* 2316 */       break;
/*      */     case 3: 
/* 2318 */       this.image.append(jjstrLiteralImages[3]);
/* 2319 */       this.lengthOfMatch = jjstrLiteralImages[3].length();
/* 2320 */       this.deque.push(Integer.valueOf(0));
/* 2321 */       break;
/*      */     case 8: 
/* 2323 */       this.image.append(jjstrLiteralImages[8]);
/* 2324 */       this.lengthOfMatch = jjstrLiteralImages[8].length();
/* 2325 */       this.deque.push(Integer.valueOf(this.curLexState));
/* 2326 */       break;
/*      */     case 9: 
/* 2328 */       this.image.append(jjstrLiteralImages[9]);
/* 2329 */       this.lengthOfMatch = jjstrLiteralImages[9].length();
/* 2330 */       SwitchTo(((Integer)this.deque.pop()).intValue());
/* 2331 */       break;
/*      */     }
/*      */     
/*      */   }
/*      */   
/*      */   private void jjCheckNAdd(int state)
/*      */   {
/* 2338 */     if (this.jjrounds[state] != this.jjround)
/*      */     {
/* 2340 */       this.jjstateSet[(this.jjnewStateCnt++)] = state;
/* 2341 */       this.jjrounds[state] = this.jjround;
/*      */     }
/*      */   }
/*      */   
/*      */   private void jjAddStates(int start, int end) {
/*      */     do {
/* 2347 */       this.jjstateSet[(this.jjnewStateCnt++)] = jjnextStates[start];
/* 2348 */     } while (start++ != end);
/*      */   }
/*      */   
/*      */   private void jjCheckNAddTwoStates(int state1, int state2) {
/* 2352 */     jjCheckNAdd(state1);
/* 2353 */     jjCheckNAdd(state2);
/*      */   }
/*      */   
/*      */   private void jjCheckNAddStates(int start, int end)
/*      */   {
/*      */     do {
/* 2359 */       jjCheckNAdd(jjnextStates[start]);
/* 2360 */     } while (start++ != end);
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-el-9.0.54.jar!\org\apache\el\parser\ELParserTokenManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */