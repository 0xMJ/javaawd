/*     */ package org.apache.el.lang;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.math.RoundingMode;
/*     */ import org.apache.el.util.MessageFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ELArithmetic
/*     */ {
/*     */   public static final class BigDecimalDelegate
/*     */     extends ELArithmetic
/*     */   {
/*     */     protected Number add(Number num0, Number num1)
/*     */     {
/*  36 */       return ((BigDecimal)num0).add((BigDecimal)num1);
/*     */     }
/*     */     
/*     */     protected Number coerce(Number num)
/*     */     {
/*  41 */       if ((num instanceof BigDecimal)) {
/*  42 */         return num;
/*     */       }
/*  44 */       if ((num instanceof BigInteger)) {
/*  45 */         return new BigDecimal((BigInteger)num);
/*     */       }
/*  47 */       return new BigDecimal(num.doubleValue());
/*     */     }
/*     */     
/*     */     protected Number coerce(String str)
/*     */     {
/*  52 */       return new BigDecimal(str);
/*     */     }
/*     */     
/*     */     protected Number divide(Number num0, Number num1)
/*     */     {
/*  57 */       return ((BigDecimal)num0).divide((BigDecimal)num1, RoundingMode.HALF_UP);
/*     */     }
/*     */     
/*     */ 
/*     */     protected Number subtract(Number num0, Number num1)
/*     */     {
/*  63 */       return ((BigDecimal)num0).subtract((BigDecimal)num1);
/*     */     }
/*     */     
/*     */     protected Number mod(Number num0, Number num1)
/*     */     {
/*  68 */       return Double.valueOf(num0.doubleValue() % num1.doubleValue());
/*     */     }
/*     */     
/*     */     protected Number multiply(Number num0, Number num1)
/*     */     {
/*  73 */       return ((BigDecimal)num0).multiply((BigDecimal)num1);
/*     */     }
/*     */     
/*     */     public boolean matches(Object obj0, Object obj1)
/*     */     {
/*  78 */       return ((obj0 instanceof BigDecimal)) || ((obj1 instanceof BigDecimal));
/*     */     }
/*     */   }
/*     */   
/*     */   public static final class BigIntegerDelegate extends ELArithmetic
/*     */   {
/*     */     protected Number add(Number num0, Number num1)
/*     */     {
/*  86 */       return ((BigInteger)num0).add((BigInteger)num1);
/*     */     }
/*     */     
/*     */     protected Number coerce(Number num)
/*     */     {
/*  91 */       if ((num instanceof BigInteger)) {
/*  92 */         return num;
/*     */       }
/*  94 */       return new BigInteger(num.toString());
/*     */     }
/*     */     
/*     */     protected Number coerce(String str)
/*     */     {
/*  99 */       return new BigInteger(str);
/*     */     }
/*     */     
/*     */     protected Number divide(Number num0, Number num1)
/*     */     {
/* 104 */       return new BigDecimal((BigInteger)num0).divide(new BigDecimal((BigInteger)num1), RoundingMode.HALF_UP);
/*     */     }
/*     */     
/*     */     protected Number multiply(Number num0, Number num1)
/*     */     {
/* 109 */       return ((BigInteger)num0).multiply((BigInteger)num1);
/*     */     }
/*     */     
/*     */     protected Number mod(Number num0, Number num1)
/*     */     {
/* 114 */       return ((BigInteger)num0).mod((BigInteger)num1);
/*     */     }
/*     */     
/*     */     protected Number subtract(Number num0, Number num1)
/*     */     {
/* 119 */       return ((BigInteger)num0).subtract((BigInteger)num1);
/*     */     }
/*     */     
/*     */     public boolean matches(Object obj0, Object obj1)
/*     */     {
/* 124 */       return ((obj0 instanceof BigInteger)) || ((obj1 instanceof BigInteger));
/*     */     }
/*     */   }
/*     */   
/*     */   public static final class DoubleDelegate
/*     */     extends ELArithmetic
/*     */   {
/*     */     protected Number add(Number num0, Number num1)
/*     */     {
/* 133 */       if ((num0 instanceof BigDecimal))
/* 134 */         return ((BigDecimal)num0).add(new BigDecimal(num1.doubleValue()));
/* 135 */       if ((num1 instanceof BigDecimal)) {
/* 136 */         return new BigDecimal(num0.doubleValue()).add((BigDecimal)num1);
/*     */       }
/* 138 */       return Double.valueOf(num0.doubleValue() + num1.doubleValue());
/*     */     }
/*     */     
/*     */     protected Number coerce(Number num)
/*     */     {
/* 143 */       if ((num instanceof Double)) {
/* 144 */         return num;
/*     */       }
/* 146 */       if ((num instanceof BigInteger)) {
/* 147 */         return new BigDecimal((BigInteger)num);
/*     */       }
/* 149 */       return Double.valueOf(num.doubleValue());
/*     */     }
/*     */     
/*     */     protected Number coerce(String str)
/*     */     {
/* 154 */       return Double.valueOf(str);
/*     */     }
/*     */     
/*     */     protected Number divide(Number num0, Number num1)
/*     */     {
/* 159 */       return Double.valueOf(num0.doubleValue() / num1.doubleValue());
/*     */     }
/*     */     
/*     */     protected Number mod(Number num0, Number num1)
/*     */     {
/* 164 */       return Double.valueOf(num0.doubleValue() % num1.doubleValue());
/*     */     }
/*     */     
/*     */ 
/*     */     protected Number subtract(Number num0, Number num1)
/*     */     {
/* 170 */       if ((num0 instanceof BigDecimal))
/* 171 */         return ((BigDecimal)num0).subtract(new BigDecimal(num1.doubleValue()));
/* 172 */       if ((num1 instanceof BigDecimal)) {
/* 173 */         return new BigDecimal(num0.doubleValue()).subtract((BigDecimal)num1);
/*     */       }
/* 175 */       return Double.valueOf(num0.doubleValue() - num1.doubleValue());
/*     */     }
/*     */     
/*     */ 
/*     */     protected Number multiply(Number num0, Number num1)
/*     */     {
/* 181 */       if ((num0 instanceof BigDecimal))
/* 182 */         return ((BigDecimal)num0).multiply(new BigDecimal(num1.doubleValue()));
/* 183 */       if ((num1 instanceof BigDecimal)) {
/* 184 */         return new BigDecimal(num0.doubleValue()).multiply((BigDecimal)num1);
/*     */       }
/* 186 */       return Double.valueOf(num0.doubleValue() * num1.doubleValue());
/*     */     }
/*     */     
/*     */     public boolean matches(Object obj0, Object obj1)
/*     */     {
/* 191 */       return ((obj0 instanceof Double)) || ((obj1 instanceof Double)) || ((obj0 instanceof Float)) || ((obj1 instanceof Float)) || (((obj0 instanceof String)) && 
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 196 */         (ELSupport.isStringFloat((String)obj0))) || (((obj1 instanceof String)) && 
/* 197 */         (ELSupport.isStringFloat((String)obj1)));
/*     */     }
/*     */   }
/*     */   
/*     */   public static final class LongDelegate extends ELArithmetic
/*     */   {
/*     */     protected Number add(Number num0, Number num1)
/*     */     {
/* 205 */       return Long.valueOf(num0.longValue() + num1.longValue());
/*     */     }
/*     */     
/*     */     protected Number coerce(Number num)
/*     */     {
/* 210 */       if ((num instanceof Long)) {
/* 211 */         return num;
/*     */       }
/* 213 */       return Long.valueOf(num.longValue());
/*     */     }
/*     */     
/*     */     protected Number coerce(String str)
/*     */     {
/* 218 */       return Long.valueOf(str);
/*     */     }
/*     */     
/*     */     protected Number divide(Number num0, Number num1)
/*     */     {
/* 223 */       return Long.valueOf(num0.longValue() / num1.longValue());
/*     */     }
/*     */     
/*     */     protected Number mod(Number num0, Number num1)
/*     */     {
/* 228 */       return Long.valueOf(num0.longValue() % num1.longValue());
/*     */     }
/*     */     
/*     */     protected Number subtract(Number num0, Number num1)
/*     */     {
/* 233 */       return Long.valueOf(num0.longValue() - num1.longValue());
/*     */     }
/*     */     
/*     */     protected Number multiply(Number num0, Number num1)
/*     */     {
/* 238 */       return Long.valueOf(num0.longValue() * num1.longValue());
/*     */     }
/*     */     
/*     */     public boolean matches(Object obj0, Object obj1)
/*     */     {
/* 243 */       return ((obj0 instanceof Long)) || ((obj1 instanceof Long));
/*     */     }
/*     */   }
/*     */   
/* 247 */   public static final BigDecimalDelegate BIGDECIMAL = new BigDecimalDelegate();
/*     */   
/* 249 */   public static final BigIntegerDelegate BIGINTEGER = new BigIntegerDelegate();
/*     */   
/* 251 */   public static final DoubleDelegate DOUBLE = new DoubleDelegate();
/*     */   
/* 253 */   public static final LongDelegate LONG = new LongDelegate();
/*     */   
/* 255 */   private static final Long ZERO = Long.valueOf(0L);
/*     */   
/*     */   public static final Number add(Object obj0, Object obj1) {
/* 258 */     ELArithmetic delegate = findDelegate(obj0, obj1);
/* 259 */     if (delegate == null) {
/* 260 */       return Long.valueOf(0L);
/*     */     }
/*     */     
/* 263 */     Number num0 = delegate.coerce(obj0);
/* 264 */     Number num1 = delegate.coerce(obj1);
/*     */     
/* 266 */     return delegate.add(num0, num1);
/*     */   }
/*     */   
/*     */   public static final Number mod(Object obj0, Object obj1) {
/* 270 */     if ((obj0 == null) && (obj1 == null)) {
/* 271 */       return Long.valueOf(0L);
/*     */     }
/*     */     ELArithmetic delegate;
/*     */     ELArithmetic delegate;
/* 275 */     if (BIGDECIMAL.matches(obj0, obj1)) {
/* 276 */       delegate = DOUBLE; } else { ELArithmetic delegate;
/* 277 */       if (DOUBLE.matches(obj0, obj1)) {
/* 278 */         delegate = DOUBLE; } else { ELArithmetic delegate;
/* 279 */         if (BIGINTEGER.matches(obj0, obj1)) {
/* 280 */           delegate = BIGINTEGER;
/*     */         } else
/* 282 */           delegate = LONG;
/*     */       }
/*     */     }
/* 285 */     Number num0 = delegate.coerce(obj0);
/* 286 */     Number num1 = delegate.coerce(obj1);
/*     */     
/* 288 */     return delegate.mod(num0, num1);
/*     */   }
/*     */   
/*     */   public static final Number subtract(Object obj0, Object obj1) {
/* 292 */     ELArithmetic delegate = findDelegate(obj0, obj1);
/* 293 */     if (delegate == null) {
/* 294 */       return Long.valueOf(0L);
/*     */     }
/*     */     
/* 297 */     Number num0 = delegate.coerce(obj0);
/* 298 */     Number num1 = delegate.coerce(obj1);
/*     */     
/* 300 */     return delegate.subtract(num0, num1);
/*     */   }
/*     */   
/*     */   public static final Number divide(Object obj0, Object obj1) {
/* 304 */     if ((obj0 == null) && (obj1 == null)) {
/* 305 */       return ZERO;
/*     */     }
/*     */     ELArithmetic delegate;
/*     */     ELArithmetic delegate;
/* 309 */     if (BIGDECIMAL.matches(obj0, obj1)) {
/* 310 */       delegate = BIGDECIMAL; } else { ELArithmetic delegate;
/* 311 */       if (BIGINTEGER.matches(obj0, obj1)) {
/* 312 */         delegate = BIGDECIMAL;
/*     */       } else {
/* 314 */         delegate = DOUBLE;
/*     */       }
/*     */     }
/* 317 */     Number num0 = delegate.coerce(obj0);
/* 318 */     Number num1 = delegate.coerce(obj1);
/*     */     
/* 320 */     return delegate.divide(num0, num1);
/*     */   }
/*     */   
/*     */   public static final Number multiply(Object obj0, Object obj1) {
/* 324 */     ELArithmetic delegate = findDelegate(obj0, obj1);
/* 325 */     if (delegate == null) {
/* 326 */       return Long.valueOf(0L);
/*     */     }
/*     */     
/* 329 */     Number num0 = delegate.coerce(obj0);
/* 330 */     Number num1 = delegate.coerce(obj1);
/*     */     
/* 332 */     return delegate.multiply(num0, num1);
/*     */   }
/*     */   
/*     */   private static ELArithmetic findDelegate(Object obj0, Object obj1) {
/* 336 */     if ((obj0 == null) && (obj1 == null)) {
/* 337 */       return null;
/*     */     }
/*     */     
/* 340 */     if (BIGDECIMAL.matches(obj0, obj1))
/* 341 */       return BIGDECIMAL;
/* 342 */     if (DOUBLE.matches(obj0, obj1)) {
/* 343 */       if (BIGINTEGER.matches(obj0, obj1)) {
/* 344 */         return BIGDECIMAL;
/*     */       }
/* 346 */       return DOUBLE;
/*     */     }
/* 348 */     if (BIGINTEGER.matches(obj0, obj1)) {
/* 349 */       return BIGINTEGER;
/*     */     }
/* 351 */     return LONG;
/*     */   }
/*     */   
/*     */   public static final boolean isNumber(Object obj)
/*     */   {
/* 356 */     return (obj != null) && (isNumberType(obj.getClass()));
/*     */   }
/*     */   
/*     */   public static final boolean isNumberType(Class<?> type) {
/* 360 */     return (type == Long.TYPE) || (type == Double.TYPE) || (type == Byte.TYPE) || (type == Short.TYPE) || (type == Integer.TYPE) || (type == Float.TYPE) || 
/*     */     
/*     */ 
/* 363 */       (Number.class.isAssignableFrom(type));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected abstract Number add(Number paramNumber1, Number paramNumber2);
/*     */   
/*     */ 
/*     */   protected abstract Number multiply(Number paramNumber1, Number paramNumber2);
/*     */   
/*     */ 
/*     */   protected abstract Number subtract(Number paramNumber1, Number paramNumber2);
/*     */   
/*     */ 
/*     */   protected abstract Number mod(Number paramNumber1, Number paramNumber2);
/*     */   
/*     */ 
/*     */   protected abstract Number coerce(Number paramNumber);
/*     */   
/*     */ 
/*     */   protected final Number coerce(Object obj)
/*     */   {
/* 385 */     if (isNumber(obj)) {
/* 386 */       return coerce((Number)obj);
/*     */     }
/* 388 */     if ((obj == null) || ("".equals(obj))) {
/* 389 */       return coerce(ZERO);
/*     */     }
/* 391 */     if ((obj instanceof String)) {
/* 392 */       return coerce((String)obj);
/*     */     }
/* 394 */     if ((obj instanceof Character)) {
/* 395 */       return coerce(Short.valueOf((short)((Character)obj).charValue()));
/*     */     }
/*     */     
/* 398 */     throw new IllegalArgumentException(MessageFactory.get("error.convert", new Object[] { obj, obj
/* 399 */       .getClass(), "Number" }));
/*     */   }
/*     */   
/*     */   protected abstract Number coerce(String paramString);
/*     */   
/*     */   protected abstract Number divide(Number paramNumber1, Number paramNumber2);
/*     */   
/*     */   protected abstract boolean matches(Object paramObject1, Object paramObject2);
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-el-9.0.54.jar!\org\apache\el\lang\ELArithmetic.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */