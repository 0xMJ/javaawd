/*    */ package org.apache.el.util;
/*    */ 
/*    */ import java.lang.reflect.AccessibleObject;
/*    */ import java.lang.reflect.Method;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class Jre9Compat
/*    */   extends JreCompat
/*    */ {
/*    */   private static final Method canAccessMethod;
/*    */   
/*    */   static
/*    */   {
/* 35 */     Method m1 = null;
/*    */     try {
/* 37 */       m1 = AccessibleObject.class.getMethod("canAccess", new Class[] { Object.class });
/*    */     }
/*    */     catch (NoSuchMethodException localNoSuchMethodException) {}
/*    */     
/* 41 */     canAccessMethod = m1;
/*    */   }
/*    */   
/*    */   public static boolean isSupported()
/*    */   {
/* 46 */     return canAccessMethod != null;
/*    */   }
/*    */   
/*    */   public boolean canAccess(Object base, AccessibleObject accessibleObject)
/*    */   {
/*    */     try
/*    */     {
/* 53 */       return ((Boolean)canAccessMethod.invoke(accessibleObject, new Object[] { base })).booleanValue();
/*    */     } catch (ReflectiveOperationException|IllegalArgumentException e) {}
/* 55 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-el-9.0.54.jar!\org\apache\el\util\Jre9Compat.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */