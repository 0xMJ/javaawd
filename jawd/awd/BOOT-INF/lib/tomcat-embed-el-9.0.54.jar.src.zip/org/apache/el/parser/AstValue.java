/*     */ package org.apache.el.parser;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import javax.el.ELException;
/*     */ import javax.el.ELResolver;
/*     */ import javax.el.LambdaExpression;
/*     */ import javax.el.MethodInfo;
/*     */ import javax.el.PropertyNotFoundException;
/*     */ import javax.el.ValueReference;
/*     */ import org.apache.el.lang.ELSupport;
/*     */ import org.apache.el.lang.EvaluationContext;
/*     */ import org.apache.el.stream.Optional;
/*     */ import org.apache.el.util.MessageFactory;
/*     */ import org.apache.el.util.ReflectionUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AstValue
/*     */   extends SimpleNode
/*     */ {
/*  43 */   private static final Object[] EMPTY_ARRAY = new Object[0];
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AstValue(int id)
/*     */   {
/*  52 */     super(id);
/*     */   }
/*     */   
/*     */   public Class<?> getType(EvaluationContext ctx) throws ELException
/*     */   {
/*  57 */     Target t = getTarget(ctx);
/*  58 */     ctx.setPropertyResolved(false);
/*  59 */     Class<?> result = ctx.getELResolver().getType(ctx, t.base, t.property);
/*  60 */     if (!ctx.isPropertyResolved()) {
/*  61 */       throw new PropertyNotFoundException(MessageFactory.get("error.resolver.unhandled", new Object[] { t.base, t.property }));
/*     */     }
/*     */     
/*  64 */     return result;
/*     */   }
/*     */   
/*     */   private final Target getTarget(EvaluationContext ctx) throws ELException
/*     */   {
/*  69 */     Object base = this.children[0].getValue(ctx);
/*     */     
/*     */ 
/*  72 */     if (base == null) {
/*  73 */       throw new PropertyNotFoundException(MessageFactory.get("error.unreachable.base", new Object[] {this.children[0]
/*  74 */         .getImage() }));
/*     */     }
/*     */     
/*     */ 
/*  78 */     Object property = null;
/*  79 */     int propCount = jjtGetNumChildren();
/*     */     
/*  81 */     int i = 1;
/*     */     
/*  83 */     ELResolver resolver = ctx.getELResolver();
/*  84 */     while (i < propCount) {
/*  85 */       if ((i + 2 < propCount) && ((this.children[(i + 1)] instanceof AstMethodParameters)))
/*     */       {
/*     */ 
/*  88 */         base = resolver.invoke(ctx, base, this.children[i]
/*  89 */           .getValue(ctx), null, ((AstMethodParameters)this.children[(i + 1)])
/*     */           
/*  91 */           .getParameters(ctx));
/*  92 */         i += 2;
/*  93 */       } else if ((i + 2 == propCount) && ((this.children[(i + 1)] instanceof AstMethodParameters)))
/*     */       {
/*     */ 
/*  96 */         ctx.setPropertyResolved(false);
/*  97 */         property = this.children[i].getValue(ctx);
/*  98 */         i += 2;
/*     */         
/* 100 */         if (property == null) {
/* 101 */           throw new PropertyNotFoundException(MessageFactory.get("error.unreachable.property", new Object[] { property }));
/*     */         }
/*     */       }
/* 104 */       else if (i + 1 < propCount)
/*     */       {
/* 106 */         property = this.children[i].getValue(ctx);
/* 107 */         ctx.setPropertyResolved(false);
/* 108 */         base = resolver.getValue(ctx, base, property);
/* 109 */         i++;
/*     */       }
/*     */       else
/*     */       {
/* 113 */         ctx.setPropertyResolved(false);
/* 114 */         property = this.children[i].getValue(ctx);
/* 115 */         i++;
/*     */         
/* 117 */         if (property == null) {
/* 118 */           throw new PropertyNotFoundException(MessageFactory.get("error.unreachable.property", new Object[] { property }));
/*     */         }
/*     */       }
/*     */       
/* 122 */       if (base == null) {
/* 123 */         throw new PropertyNotFoundException(MessageFactory.get("error.unreachable.property", new Object[] { property }));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 128 */     Target t = new Target();
/* 129 */     t.base = base;
/* 130 */     t.property = property;
/* 131 */     return t;
/*     */   }
/*     */   
/*     */   public Object getValue(EvaluationContext ctx) throws ELException
/*     */   {
/* 136 */     Object base = this.children[0].getValue(ctx);
/* 137 */     int propCount = jjtGetNumChildren();
/* 138 */     int i = 1;
/* 139 */     Object suffix = null;
/* 140 */     ELResolver resolver = ctx.getELResolver();
/* 141 */     while ((base != null) && (i < propCount)) {
/* 142 */       suffix = this.children[i].getValue(ctx);
/* 143 */       if ((i + 1 < propCount) && ((this.children[(i + 1)] instanceof AstMethodParameters)))
/*     */       {
/* 145 */         AstMethodParameters mps = (AstMethodParameters)this.children[(i + 1)];
/*     */         
/* 147 */         if (((base instanceof Optional)) && ("orElseGet".equals(suffix)) && 
/* 148 */           (mps.jjtGetNumChildren() == 1)) {
/* 149 */           Node paramFoOptional = mps.jjtGetChild(0);
/* 150 */           if ((!(paramFoOptional instanceof AstLambdaExpression)) && (!(paramFoOptional instanceof LambdaExpression)))
/*     */           {
/* 152 */             throw new ELException(MessageFactory.get("stream.optional.paramNotLambda", new Object[] { suffix }));
/*     */           }
/*     */         }
/*     */         
/*     */ 
/* 157 */         Object[] paramValues = mps.getParameters(ctx);
/* 158 */         base = resolver.invoke(ctx, base, suffix, 
/* 159 */           getTypesFromValues(paramValues), paramValues);
/* 160 */         i += 2;
/*     */       }
/*     */       else {
/* 163 */         if (suffix == null) {
/* 164 */           return null;
/*     */         }
/*     */         
/* 167 */         ctx.setPropertyResolved(false);
/* 168 */         base = resolver.getValue(ctx, base, suffix);
/* 169 */         i++;
/*     */       }
/*     */     }
/* 172 */     if (!ctx.isPropertyResolved()) {
/* 173 */       throw new PropertyNotFoundException(MessageFactory.get("error.resolver.unhandled", new Object[] { base, suffix }));
/*     */     }
/*     */     
/* 176 */     return base;
/*     */   }
/*     */   
/*     */   public boolean isReadOnly(EvaluationContext ctx) throws ELException
/*     */   {
/* 181 */     Target t = getTarget(ctx);
/* 182 */     ctx.setPropertyResolved(false);
/*     */     
/* 184 */     boolean result = ctx.getELResolver().isReadOnly(ctx, t.base, t.property);
/* 185 */     if (!ctx.isPropertyResolved()) {
/* 186 */       throw new PropertyNotFoundException(MessageFactory.get("error.resolver.unhandled", new Object[] { t.base, t.property }));
/*     */     }
/*     */     
/* 189 */     return result;
/*     */   }
/*     */   
/*     */   public void setValue(EvaluationContext ctx, Object value)
/*     */     throws ELException
/*     */   {
/* 195 */     Target t = getTarget(ctx);
/* 196 */     ctx.setPropertyResolved(false);
/* 197 */     ELResolver resolver = ctx.getELResolver();
/*     */     
/*     */ 
/* 200 */     Class<?> targetClass = resolver.getType(ctx, t.base, t.property);
/* 201 */     resolver.setValue(ctx, t.base, t.property, 
/* 202 */       ELSupport.coerceToType(ctx, value, targetClass));
/* 203 */     if (!ctx.isPropertyResolved()) {
/* 204 */       throw new PropertyNotFoundException(MessageFactory.get("error.resolver.unhandled", new Object[] { t.base, t.property }));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public MethodInfo getMethodInfo(EvaluationContext ctx, Class[] paramTypes)
/*     */     throws ELException
/*     */   {
/* 214 */     Target t = getTarget(ctx);
/* 215 */     Class<?>[] types = null;
/* 216 */     if (isParametersProvided())
/*     */     {
/* 218 */       Object[] values = ((AstMethodParameters)jjtGetChild(jjtGetNumChildren() - 1)).getParameters(ctx);
/* 219 */       types = getTypesFromValues(values);
/*     */     } else {
/* 221 */       types = paramTypes;
/*     */     }
/* 223 */     Method m = ReflectionUtil.getMethod(ctx, t.base, t.property, types, null);
/* 224 */     return new MethodInfo(m.getName(), m.getReturnType(), m.getParameterTypes());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object invoke(EvaluationContext ctx, Class[] paramTypes, Object[] paramValues)
/*     */     throws ELException
/*     */   {
/* 233 */     Target t = getTarget(ctx);
/* 234 */     Method m = null;
/* 235 */     Object[] values = null;
/* 236 */     Class<?>[] types = null;
/* 237 */     if (isParametersProvided())
/*     */     {
/* 239 */       values = ((AstMethodParameters)jjtGetChild(jjtGetNumChildren() - 1)).getParameters(ctx);
/* 240 */       types = getTypesFromValues(values);
/*     */     } else {
/* 242 */       values = paramValues;
/* 243 */       types = paramTypes;
/*     */     }
/* 245 */     m = ReflectionUtil.getMethod(ctx, t.base, t.property, types, values);
/*     */     
/*     */ 
/* 248 */     values = convertArgs(ctx, values, m);
/*     */     
/* 250 */     Object result = null;
/*     */     try {
/* 252 */       result = m.invoke(t.base, values);
/*     */     } catch (IllegalAccessException|IllegalArgumentException e) {
/* 254 */       throw new ELException(e);
/*     */     } catch (InvocationTargetException ite) {
/* 256 */       Throwable cause = ite.getCause();
/* 257 */       if ((cause instanceof ThreadDeath)) {
/* 258 */         throw ((ThreadDeath)cause);
/*     */       }
/* 260 */       if ((cause instanceof VirtualMachineError)) {
/* 261 */         throw ((VirtualMachineError)cause);
/*     */       }
/* 263 */       throw new ELException(cause);
/*     */     }
/* 265 */     return result;
/*     */   }
/*     */   
/*     */   private Object[] convertArgs(EvaluationContext ctx, Object[] src, Method m) {
/* 269 */     Class<?>[] types = m.getParameterTypes();
/* 270 */     if (types.length == 0)
/*     */     {
/* 272 */       return EMPTY_ARRAY;
/*     */     }
/*     */     
/* 275 */     int paramCount = types.length;
/*     */     
/* 277 */     if (((m.isVarArgs()) && (paramCount > 1) && ((src == null) || (paramCount > src.length))) || (
/* 278 */       (!m.isVarArgs()) && (((paramCount > 0) && (src == null)) || ((src != null) && (src.length != paramCount)))))
/*     */     {
/* 280 */       String srcCount = null;
/* 281 */       if (src != null)
/* 282 */         srcCount = Integer.toString(src.length);
/*     */       String msg;
/*     */       String msg;
/* 285 */       if (m.isVarArgs()) {
/* 286 */         msg = MessageFactory.get("error.invoke.tooFewParams", new Object[] {m
/* 287 */           .getName(), srcCount, Integer.toString(paramCount) });
/*     */       } else {
/* 289 */         msg = MessageFactory.get("error.invoke.wrongParams", new Object[] {m
/* 290 */           .getName(), srcCount, Integer.toString(paramCount) });
/*     */       }
/* 292 */       throw new IllegalArgumentException(msg);
/*     */     }
/*     */     
/* 295 */     if (src == null)
/*     */     {
/*     */ 
/*     */ 
/* 299 */       return new Object[1];
/*     */     }
/*     */     
/* 302 */     Object[] dest = new Object[paramCount];
/*     */     
/* 304 */     for (int i = 0; i < paramCount - 1; i++) {
/* 305 */       dest[i] = ELSupport.coerceToType(ctx, src[i], types[i]);
/*     */     }
/*     */     
/* 308 */     if (m.isVarArgs()) {
/* 309 */       Class<?> varArgType = m.getParameterTypes()[(paramCount - 1)].getComponentType();
/*     */       
/* 311 */       Object[] varArgs = (Object[])Array.newInstance(varArgType, src.length - (paramCount - 1));
/* 312 */       for (int i = 0; i < src.length - (paramCount - 1); i++) {
/* 313 */         varArgs[i] = ELSupport.coerceToType(ctx, src[(paramCount - 1 + i)], varArgType);
/*     */       }
/* 315 */       dest[(paramCount - 1)] = varArgs;
/*     */     } else {
/* 317 */       dest[(paramCount - 1)] = ELSupport.coerceToType(ctx, src[(paramCount - 1)], types[(paramCount - 1)]);
/*     */     }
/*     */     
/*     */ 
/* 321 */     return dest;
/*     */   }
/*     */   
/*     */   private Class<?>[] getTypesFromValues(Object[] values) {
/* 325 */     if (values == null) {
/* 326 */       return null;
/*     */     }
/*     */     
/* 329 */     Class<?>[] result = new Class[values.length];
/* 330 */     for (int i = 0; i < values.length; i++) {
/* 331 */       if (values[i] == null) {
/* 332 */         result[i] = null;
/*     */       } else {
/* 334 */         result[i] = values[i].getClass();
/*     */       }
/*     */     }
/* 337 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ValueReference getValueReference(EvaluationContext ctx)
/*     */   {
/* 347 */     if ((this.children.length > 2) && 
/* 348 */       ((jjtGetChild(2) instanceof AstMethodParameters)))
/*     */     {
/* 350 */       return null;
/*     */     }
/* 352 */     Target t = getTarget(ctx);
/* 353 */     return new ValueReference(t.base, t.property);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isParametersProvided()
/*     */   {
/* 364 */     int len = this.children.length;
/* 365 */     if ((len > 2) && 
/* 366 */       ((jjtGetChild(len - 1) instanceof AstMethodParameters))) {
/* 367 */       return true;
/*     */     }
/*     */     
/* 370 */     return false;
/*     */   }
/*     */   
/*     */   protected static class Target
/*     */   {
/*     */     protected Object base;
/*     */     protected Object property;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-el-9.0.54.jar!\org\apache\el\parser\AstValue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */