/*     */ package org.apache.el.lang;
/*     */ 
/*     */ import java.io.Externalizable;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInput;
/*     */ import java.io.ObjectOutput;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import javax.el.FunctionMapper;
/*     */ import org.apache.el.util.MessageFactory;
/*     */ import org.apache.el.util.ReflectionUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FunctionMapperImpl
/*     */   extends FunctionMapper
/*     */   implements Externalizable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  41 */   protected ConcurrentMap<String, Function> functions = new ConcurrentHashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Method resolveFunction(String prefix, String localName)
/*     */   {
/*  51 */     Function f = (Function)this.functions.get(prefix + ":" + localName);
/*  52 */     if (f == null) {
/*  53 */       return null;
/*     */     }
/*  55 */     return f.getMethod();
/*     */   }
/*     */   
/*     */   public void mapFunction(String prefix, String localName, Method m)
/*     */   {
/*  60 */     String key = prefix + ":" + localName;
/*  61 */     if (m == null) {
/*  62 */       this.functions.remove(key);
/*     */     } else {
/*  64 */       Function f = new Function(prefix, localName, m);
/*  65 */       this.functions.put(key, f);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeExternal(ObjectOutput out)
/*     */     throws IOException
/*     */   {
/*  76 */     out.writeObject(this.functions);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void readExternal(ObjectInput in)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/*  88 */     this.functions = ((ConcurrentMap)in.readObject());
/*     */   }
/*     */   
/*     */   public static class Function implements Externalizable
/*     */   {
/*     */     protected transient Method m;
/*     */     protected String owner;
/*     */     protected String name;
/*     */     protected String[] types;
/*     */     protected String prefix;
/*     */     protected String localName;
/*     */     
/*     */     public Function(String prefix, String localName, Method m) {
/* 101 */       if (localName == null) {
/* 102 */         throw new NullPointerException(MessageFactory.get("error.nullLocalName"));
/*     */       }
/* 104 */       if (m == null) {
/* 105 */         throw new NullPointerException(MessageFactory.get("error.nullMethod"));
/*     */       }
/* 107 */       this.prefix = prefix;
/* 108 */       this.localName = localName;
/* 109 */       this.m = m;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public Function() {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public void writeExternal(ObjectOutput out)
/*     */       throws IOException
/*     */     {
/* 123 */       out.writeUTF(this.prefix != null ? this.prefix : "");
/* 124 */       out.writeUTF(this.localName);
/*     */       
/* 126 */       getMethod();
/* 127 */       out.writeUTF(this.owner != null ? this.owner : this.m
/*     */       
/* 129 */         .getDeclaringClass().getName());
/* 130 */       out.writeUTF(this.name != null ? this.name : this.m
/*     */       
/* 132 */         .getName());
/* 133 */       out.writeObject(this.types != null ? this.types : 
/*     */       
/* 135 */         ReflectionUtil.toTypeNameArray(this.m.getParameterTypes()));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void readExternal(ObjectInput in)
/*     */       throws IOException, ClassNotFoundException
/*     */     {
/* 148 */       this.prefix = in.readUTF();
/* 149 */       if (this.prefix.isEmpty()) {
/* 150 */         this.prefix = null;
/*     */       }
/* 152 */       this.localName = in.readUTF();
/* 153 */       this.owner = in.readUTF();
/* 154 */       this.name = in.readUTF();
/* 155 */       this.types = ((String[])in.readObject());
/*     */     }
/*     */     
/*     */     public Method getMethod() {
/* 159 */       if (this.m == null) {
/*     */         try {
/* 161 */           Class<?> t = ReflectionUtil.forName(this.owner);
/* 162 */           Class<?>[] p = ReflectionUtil.toTypeArray(this.types);
/* 163 */           this.m = t.getMethod(this.name, p);
/*     */         } catch (Exception e) {
/* 165 */           e.printStackTrace();
/*     */         }
/*     */       }
/* 168 */       return this.m;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public boolean equals(Object obj)
/*     */     {
/* 176 */       if ((obj instanceof Function)) {
/* 177 */         return hashCode() == obj.hashCode();
/*     */       }
/* 179 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 187 */       return (this.prefix + this.localName).hashCode();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-el-9.0.54.jar!\org\apache\el\lang\FunctionMapperImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */