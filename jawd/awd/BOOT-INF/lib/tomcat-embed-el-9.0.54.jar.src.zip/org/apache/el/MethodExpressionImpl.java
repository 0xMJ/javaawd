/*     */ package org.apache.el;
/*     */ 
/*     */ import java.io.Externalizable;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInput;
/*     */ import java.io.ObjectOutput;
/*     */ import javax.el.ELContext;
/*     */ import javax.el.ELException;
/*     */ import javax.el.FunctionMapper;
/*     */ import javax.el.MethodExpression;
/*     */ import javax.el.MethodInfo;
/*     */ import javax.el.MethodNotFoundException;
/*     */ import javax.el.PropertyNotFoundException;
/*     */ import javax.el.VariableMapper;
/*     */ import org.apache.el.lang.EvaluationContext;
/*     */ import org.apache.el.lang.ExpressionBuilder;
/*     */ import org.apache.el.parser.Node;
/*     */ import org.apache.el.util.ReflectionUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MethodExpressionImpl
/*     */   extends MethodExpression
/*     */   implements Externalizable
/*     */ {
/*     */   private Class<?> expectedType;
/*     */   private String expr;
/*     */   private FunctionMapper fnMapper;
/*     */   private VariableMapper varMapper;
/*     */   private transient Node node;
/*     */   private Class<?>[] paramTypes;
/*     */   
/*     */   public MethodExpressionImpl() {}
/*     */   
/*     */   public MethodExpressionImpl(String expr, Node node, FunctionMapper fnMapper, VariableMapper varMapper, Class<?> expectedType, Class<?>[] paramTypes)
/*     */   {
/*  98 */     this.expr = expr;
/*  99 */     this.node = node;
/* 100 */     this.fnMapper = fnMapper;
/* 101 */     this.varMapper = varMapper;
/* 102 */     this.expectedType = expectedType;
/* 103 */     this.paramTypes = paramTypes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 135 */     return ((obj instanceof MethodExpressionImpl)) && 
/* 136 */       (obj.hashCode() == hashCode());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getExpressionString()
/*     */   {
/* 162 */     return this.expr;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MethodInfo getMethodInfo(ELContext context)
/*     */     throws PropertyNotFoundException, MethodNotFoundException, ELException
/*     */   {
/* 191 */     Node n = getNode();
/* 192 */     EvaluationContext ctx = new EvaluationContext(context, this.fnMapper, this.varMapper);
/*     */     
/* 194 */     ctx.notifyBeforeEvaluation(getExpressionString());
/* 195 */     MethodInfo result = n.getMethodInfo(ctx, this.paramTypes);
/* 196 */     ctx.notifyAfterEvaluation(getExpressionString());
/* 197 */     return result;
/*     */   }
/*     */   
/*     */   private Node getNode() throws ELException {
/* 201 */     if (this.node == null) {
/* 202 */       this.node = ExpressionBuilder.createNode(this.expr);
/*     */     }
/* 204 */     return this.node;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 226 */     return this.expr.hashCode();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object invoke(ELContext context, Object[] params)
/*     */     throws PropertyNotFoundException, MethodNotFoundException, ELException
/*     */   {
/* 263 */     EvaluationContext ctx = new EvaluationContext(context, this.fnMapper, this.varMapper);
/*     */     
/* 265 */     ctx.notifyBeforeEvaluation(getExpressionString());
/* 266 */     Object result = getNode().invoke(ctx, this.paramTypes, params);
/* 267 */     ctx.notifyAfterEvaluation(getExpressionString());
/* 268 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void readExternal(ObjectInput in)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 279 */     this.expr = in.readUTF();
/* 280 */     String type = in.readUTF();
/* 281 */     if (!type.isEmpty()) {
/* 282 */       this.expectedType = ReflectionUtil.forName(type);
/*     */     }
/* 284 */     this.paramTypes = ReflectionUtil.toTypeArray(
/* 285 */       (String[])in.readObject());
/* 286 */     this.fnMapper = ((FunctionMapper)in.readObject());
/* 287 */     this.varMapper = ((VariableMapper)in.readObject());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeExternal(ObjectOutput out)
/*     */     throws IOException
/*     */   {
/* 297 */     out.writeUTF(this.expr);
/* 298 */     out.writeUTF(this.expectedType != null ? this.expectedType.getName() : "");
/*     */     
/* 300 */     out.writeObject(ReflectionUtil.toTypeNameArray(this.paramTypes));
/* 301 */     out.writeObject(this.fnMapper);
/* 302 */     out.writeObject(this.varMapper);
/*     */   }
/*     */   
/*     */   public boolean isLiteralText()
/*     */   {
/* 307 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isParametersProvided()
/*     */   {
/* 316 */     return getNode().isParametersProvided();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isParmetersProvided()
/*     */   {
/* 327 */     return getNode().isParametersProvided();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-el-9.0.54.jar!\org\apache\el\MethodExpressionImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */