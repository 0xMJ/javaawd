/*     */ package org.apache.el.parser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ParseException
/*     */   extends Exception
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Token currentToken;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int[][] expectedTokenSequences;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] tokenImage;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ParseException(Token currentTokenVal, int[][] expectedTokenSequencesVal, String[] tokenImageVal)
/*     */   {
/*  35 */     super(initialise(currentTokenVal, expectedTokenSequencesVal, tokenImageVal));
/*  36 */     this.currentToken = currentTokenVal;
/*  37 */     this.expectedTokenSequences = expectedTokenSequencesVal;
/*  38 */     this.tokenImage = tokenImageVal;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ParseException() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ParseException(String message)
/*     */   {
/*  57 */     super(message);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static String initialise(Token currentToken, int[][] expectedTokenSequences, String[] tokenImage)
/*     */   {
/*  92 */     StringBuffer expected = new StringBuffer();
/*  93 */     int maxSize = 0;
/*  94 */     for (int i = 0; i < expectedTokenSequences.length; i++) {
/*  95 */       if (maxSize < expectedTokenSequences[i].length) {
/*  96 */         maxSize = expectedTokenSequences[i].length;
/*     */       }
/*  98 */       for (int j = 0; j < expectedTokenSequences[i].length; j++) {
/*  99 */         expected.append(tokenImage[expectedTokenSequences[i][j]]).append(' ');
/*     */       }
/* 101 */       if (expectedTokenSequences[i][(expectedTokenSequences[i].length - 1)] != 0) {
/* 102 */         expected.append("...");
/*     */       }
/* 104 */       expected.append(System.lineSeparator()).append("    ");
/*     */     }
/* 106 */     String retval = "Encountered \"";
/* 107 */     Token tok = currentToken.next;
/* 108 */     for (int i = 0; i < maxSize; i++) {
/* 109 */       if (i != 0) {
/* 110 */         retval = retval + " ";
/*     */       }
/* 112 */       if (tok.kind == 0) {
/* 113 */         retval = retval + tokenImage[0];
/* 114 */         break;
/*     */       }
/* 116 */       retval = retval + " " + tokenImage[tok.kind];
/* 117 */       retval = retval + " \"";
/* 118 */       retval = retval + add_escapes(tok.image);
/* 119 */       retval = retval + " \"";
/* 120 */       tok = tok.next;
/*     */     }
/* 122 */     retval = retval + "\" at line " + currentToken.next.beginLine + ", column " + currentToken.next.beginColumn;
/* 123 */     retval = retval + "." + System.lineSeparator();
/* 124 */     if (expectedTokenSequences.length == 1) {
/* 125 */       retval = retval + "Was expecting:" + System.lineSeparator() + "    ";
/*     */     } else {
/* 127 */       retval = retval + "Was expecting one of:" + System.lineSeparator() + "    ";
/*     */     }
/* 129 */     retval = retval + expected.toString();
/* 130 */     return retval;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static String add_escapes(String str)
/*     */   {
/* 139 */     StringBuffer retval = new StringBuffer();
/*     */     
/* 141 */     for (int i = 0; i < str.length(); i++) {
/* 142 */       switch (str.charAt(i))
/*     */       {
/*     */       case '\000': 
/*     */         break;
/*     */       case '\b': 
/* 147 */         retval.append("\\b");
/* 148 */         break;
/*     */       case '\t': 
/* 150 */         retval.append("\\t");
/* 151 */         break;
/*     */       case '\n': 
/* 153 */         retval.append("\\n");
/* 154 */         break;
/*     */       case '\f': 
/* 156 */         retval.append("\\f");
/* 157 */         break;
/*     */       case '\r': 
/* 159 */         retval.append("\\r");
/* 160 */         break;
/*     */       case '"': 
/* 162 */         retval.append("\\\"");
/* 163 */         break;
/*     */       case '\'': 
/* 165 */         retval.append("\\'");
/* 166 */         break;
/*     */       case '\\': 
/* 168 */         retval.append("\\\\");
/* 169 */         break;
/*     */       default:  char ch;
/* 171 */         if (((ch = str.charAt(i)) < ' ') || (ch > '~')) {
/* 172 */           String s = "0000" + Integer.toString(ch, 16);
/* 173 */           retval.append("\\u" + s.substring(s.length() - 4, s.length()));
/*     */         } else {
/* 175 */           retval.append(ch);
/*     */         }
/*     */         break;
/*     */       }
/*     */     }
/* 180 */     return retval.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-el-9.0.54.jar!\org\apache\el\parser\ParseException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */