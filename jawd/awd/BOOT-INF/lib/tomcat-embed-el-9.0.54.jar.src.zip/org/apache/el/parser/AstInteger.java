/*    */ package org.apache.el.parser;
/*    */ 
/*    */ import java.math.BigInteger;
/*    */ import javax.el.ELException;
/*    */ import org.apache.el.lang.EvaluationContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AstInteger
/*    */   extends SimpleNode
/*    */ {
/*    */   private volatile Number number;
/*    */   
/*    */   public AstInteger(int id)
/*    */   {
/* 32 */     super(id);
/*    */   }
/*    */   
/*    */ 
/*    */   protected Number getInteger()
/*    */   {
/* 38 */     if (this.number == null) {
/*    */       try {
/* 40 */         this.number = Long.valueOf(this.image);
/*    */       } catch (ArithmeticException e1) {
/* 42 */         this.number = new BigInteger(this.image);
/*    */       }
/*    */     }
/* 45 */     return this.number;
/*    */   }
/*    */   
/*    */   public Class<?> getType(EvaluationContext ctx)
/*    */     throws ELException
/*    */   {
/* 51 */     return getInteger().getClass();
/*    */   }
/*    */   
/*    */   public Object getValue(EvaluationContext ctx)
/*    */     throws ELException
/*    */   {
/* 57 */     return getInteger();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-el-9.0.54.jar!\org\apache\el\parser\AstInteger.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */