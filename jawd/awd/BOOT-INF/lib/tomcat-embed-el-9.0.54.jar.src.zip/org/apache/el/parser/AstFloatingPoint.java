/*    */ package org.apache.el.parser;
/*    */ 
/*    */ import java.math.BigDecimal;
/*    */ import javax.el.ELException;
/*    */ import org.apache.el.lang.EvaluationContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AstFloatingPoint
/*    */   extends SimpleNode
/*    */ {
/*    */   private volatile Number number;
/*    */   
/*    */   public AstFloatingPoint(int id)
/*    */   {
/* 32 */     super(id);
/*    */   }
/*    */   
/*    */ 
/*    */   public Number getFloatingPoint()
/*    */   {
/* 38 */     if (this.number == null) {
/*    */       try {
/* 40 */         this.number = Double.valueOf(this.image);
/*    */       } catch (ArithmeticException e0) {
/* 42 */         this.number = new BigDecimal(this.image);
/*    */       }
/*    */     }
/* 45 */     return this.number;
/*    */   }
/*    */   
/*    */   public Object getValue(EvaluationContext ctx)
/*    */     throws ELException
/*    */   {
/* 51 */     return getFloatingPoint();
/*    */   }
/*    */   
/*    */   public Class<?> getType(EvaluationContext ctx)
/*    */     throws ELException
/*    */   {
/* 57 */     return getFloatingPoint().getClass();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-el-9.0.54.jar!\org\apache\el\parser\AstFloatingPoint.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */