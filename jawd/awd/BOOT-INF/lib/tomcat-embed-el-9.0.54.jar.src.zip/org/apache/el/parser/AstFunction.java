/*     */ package org.apache.el.parser;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import javax.el.ELClass;
/*     */ import javax.el.ELException;
/*     */ import javax.el.ELResolver;
/*     */ import javax.el.FunctionMapper;
/*     */ import javax.el.ImportHandler;
/*     */ import javax.el.LambdaExpression;
/*     */ import javax.el.ValueExpression;
/*     */ import javax.el.VariableMapper;
/*     */ import org.apache.el.lang.EvaluationContext;
/*     */ import org.apache.el.util.MessageFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AstFunction
/*     */   extends SimpleNode
/*     */ {
/*  39 */   protected String localName = "";
/*     */   
/*  41 */   protected String prefix = "";
/*     */   
/*     */   public AstFunction(int id) {
/*  44 */     super(id);
/*     */   }
/*     */   
/*     */   public String getLocalName() {
/*  48 */     return this.localName;
/*     */   }
/*     */   
/*     */   public String getOutputName() {
/*  52 */     if (this.prefix == null) {
/*  53 */       return this.localName;
/*     */     }
/*  55 */     return this.prefix + ":" + this.localName;
/*     */   }
/*     */   
/*     */   public String getPrefix()
/*     */   {
/*  60 */     return this.prefix;
/*     */   }
/*     */   
/*     */ 
/*     */   public Class<?> getType(EvaluationContext ctx)
/*     */     throws ELException
/*     */   {
/*  67 */     FunctionMapper fnMapper = ctx.getFunctionMapper();
/*     */     
/*     */ 
/*  70 */     if (fnMapper == null) {
/*  71 */       throw new ELException(MessageFactory.get("error.fnMapper.null"));
/*     */     }
/*  73 */     Method m = fnMapper.resolveFunction(this.prefix, this.localName);
/*  74 */     if (m == null) {
/*  75 */       throw new ELException(MessageFactory.get("error.fnMapper.method", new Object[] {
/*  76 */         getOutputName() }));
/*     */     }
/*  78 */     return m.getReturnType();
/*     */   }
/*     */   
/*     */ 
/*     */   public Object getValue(EvaluationContext ctx)
/*     */     throws ELException
/*     */   {
/*  85 */     FunctionMapper fnMapper = ctx.getFunctionMapper();
/*     */     
/*     */ 
/*  88 */     if (fnMapper == null) {
/*  89 */       throw new ELException(MessageFactory.get("error.fnMapper.null"));
/*     */     }
/*  91 */     Method m = fnMapper.resolveFunction(this.prefix, this.localName);
/*     */     
/*  93 */     if ((m == null) && (this.prefix.length() == 0))
/*     */     {
/*     */ 
/*     */ 
/*  97 */       Object obj = null;
/*  98 */       if (ctx.isLambdaArgument(this.localName)) {
/*  99 */         obj = ctx.getLambdaArgument(this.localName);
/*     */       }
/* 101 */       if (obj == null) {
/* 102 */         VariableMapper varMapper = ctx.getVariableMapper();
/* 103 */         if (varMapper != null) {
/* 104 */           obj = varMapper.resolveVariable(this.localName);
/* 105 */           if ((obj instanceof ValueExpression))
/*     */           {
/* 107 */             obj = ((ValueExpression)obj).getValue(ctx);
/*     */           }
/*     */         }
/*     */       }
/* 111 */       if (obj == null) {
/* 112 */         obj = ctx.getELResolver().getValue(ctx, null, this.localName);
/*     */       }
/* 114 */       if ((obj instanceof LambdaExpression))
/*     */       {
/* 116 */         int i = 0;
/* 117 */         while (((obj instanceof LambdaExpression)) && 
/* 118 */           (i < jjtGetNumChildren())) {
/* 119 */           Node args = jjtGetChild(i);
/* 120 */           obj = ((LambdaExpression)obj).invoke(((AstMethodParameters)args)
/* 121 */             .getParameters(ctx));
/* 122 */           i++;
/*     */         }
/* 124 */         if (i < jjtGetNumChildren())
/*     */         {
/*     */ 
/* 127 */           throw new ELException(MessageFactory.get("error.lambda.tooManyMethodParameterSets"));
/*     */         }
/*     */         
/* 130 */         return obj;
/*     */       }
/*     */       
/*     */ 
/* 134 */       obj = ctx.getImportHandler().resolveClass(this.localName);
/* 135 */       if (obj != null) {
/* 136 */         return ctx.getELResolver().invoke(ctx, new ELClass((Class)obj), "<init>", null, ((AstMethodParameters)this.children[0])
/* 137 */           .getParameters(ctx));
/*     */       }
/* 139 */       obj = ctx.getImportHandler().resolveStatic(this.localName);
/* 140 */       if (obj != null) {
/* 141 */         return ctx.getELResolver().invoke(ctx, new ELClass((Class)obj), this.localName, null, ((AstMethodParameters)this.children[0])
/* 142 */           .getParameters(ctx));
/*     */       }
/*     */     }
/*     */     
/* 146 */     if (m == null) {
/* 147 */       throw new ELException(MessageFactory.get("error.fnMapper.method", new Object[] {
/* 148 */         getOutputName() }));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 153 */     if (jjtGetNumChildren() != 1) {
/* 154 */       throw new ELException(MessageFactory.get("error.function.tooManyMethodParameterSets", new Object[] {
/*     */       
/* 156 */         getOutputName() }));
/*     */     }
/*     */     
/* 159 */     Node parameters = jjtGetChild(0);
/* 160 */     Class<?>[] paramTypes = m.getParameterTypes();
/* 161 */     Object[] params = null;
/* 162 */     Object result = null;
/* 163 */     int inputParameterCount = parameters.jjtGetNumChildren();
/* 164 */     int methodParameterCount = paramTypes.length;
/* 165 */     if ((inputParameterCount == 0) && (methodParameterCount == 1) && (m.isVarArgs())) {
/* 166 */       params = new Object[] { null };
/* 167 */     } else if (inputParameterCount > 0) {
/* 168 */       params = new Object[methodParameterCount];
/*     */       try {
/* 170 */         for (int i = 0; i < methodParameterCount; i++) {
/* 171 */           if ((m.isVarArgs()) && (i == methodParameterCount - 1)) {
/* 172 */             if (inputParameterCount < methodParameterCount) {
/* 173 */               params[i] = { null };
/* 174 */             } else if ((inputParameterCount == methodParameterCount) && 
/* 175 */               (paramTypes[i].isArray())) {
/* 176 */               params[i] = parameters.jjtGetChild(i).getValue(ctx);
/*     */             } else {
/* 178 */               Object[] varargs = new Object[inputParameterCount - methodParameterCount + 1];
/*     */               
/* 180 */               Class<?> target = paramTypes[i].getComponentType();
/* 181 */               for (int j = i; j < inputParameterCount; j++) {
/* 182 */                 varargs[(j - i)] = parameters.jjtGetChild(j).getValue(ctx);
/* 183 */                 varargs[(j - i)] = coerceToType(ctx, varargs[(j - i)], target);
/*     */               }
/* 185 */               params[i] = varargs;
/*     */             }
/*     */           } else {
/* 188 */             params[i] = parameters.jjtGetChild(i).getValue(ctx);
/*     */           }
/* 190 */           params[i] = coerceToType(ctx, params[i], paramTypes[i]);
/*     */         }
/*     */       } catch (ELException ele) {
/* 193 */         throw new ELException(MessageFactory.get("error.function", new Object[] {
/* 194 */           getOutputName() }), ele);
/*     */       }
/*     */     }
/*     */     try {
/* 198 */       result = m.invoke(null, params);
/*     */     } catch (IllegalAccessException iae) {
/* 200 */       throw new ELException(MessageFactory.get("error.function", new Object[] {
/* 201 */         getOutputName() }), iae);
/*     */     } catch (InvocationTargetException ite) {
/* 203 */       Throwable cause = ite.getCause();
/* 204 */       if ((cause instanceof ThreadDeath)) {
/* 205 */         throw ((ThreadDeath)cause);
/*     */       }
/* 207 */       if ((cause instanceof VirtualMachineError)) {
/* 208 */         throw ((VirtualMachineError)cause);
/*     */       }
/* 210 */       throw new ELException(MessageFactory.get("error.function", new Object[] {
/* 211 */         getOutputName() }), cause);
/*     */     }
/* 213 */     return result;
/*     */   }
/*     */   
/*     */   public void setLocalName(String localName) {
/* 217 */     this.localName = localName;
/*     */   }
/*     */   
/*     */   public void setPrefix(String prefix) {
/* 221 */     this.prefix = prefix;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 228 */     return ELParserTreeConstants.jjtNodeName[this.id] + "[" + getOutputName() + "]";
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-el-9.0.54.jar!\org\apache\el\parser\AstFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */