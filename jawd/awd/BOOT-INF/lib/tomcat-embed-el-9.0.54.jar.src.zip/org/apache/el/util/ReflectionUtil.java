/*     */ package org.apache.el.util;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.el.ELException;
/*     */ import javax.el.MethodNotFoundException;
/*     */ import org.apache.el.lang.ELSupport;
/*     */ import org.apache.el.lang.EvaluationContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReflectionUtil
/*     */ {
/*  43 */   protected static final String[] PRIMITIVE_NAMES = { "boolean", "byte", "char", "double", "float", "int", "long", "short", "void" };
/*     */   
/*     */ 
/*  46 */   protected static final Class<?>[] PRIMITIVES = { Boolean.TYPE, Byte.TYPE, Character.TYPE, Double.TYPE, Float.TYPE, Integer.TYPE, Long.TYPE, Short.TYPE, Void.TYPE };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Class<?> forName(String name)
/*     */     throws ClassNotFoundException
/*     */   {
/*  55 */     if ((null == name) || (name.isEmpty())) {
/*  56 */       return null;
/*     */     }
/*  58 */     Class<?> c = forNamePrimitive(name);
/*  59 */     if (c == null) {
/*  60 */       if (name.endsWith("[]")) {
/*  61 */         String nc = name.substring(0, name.length() - 2);
/*  62 */         c = Class.forName(nc, true, getContextClassLoader());
/*  63 */         c = Array.newInstance(c, 0).getClass();
/*     */       } else {
/*  65 */         c = Class.forName(name, true, getContextClassLoader());
/*     */       }
/*     */     }
/*  68 */     return c;
/*     */   }
/*     */   
/*     */   protected static Class<?> forNamePrimitive(String name) {
/*  72 */     if (name.length() <= 8) {
/*  73 */       int p = Arrays.binarySearch(PRIMITIVE_NAMES, name);
/*  74 */       if (p >= 0) {
/*  75 */         return PRIMITIVES[p];
/*     */       }
/*     */     }
/*  78 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Class<?>[] toTypeArray(String[] s)
/*     */     throws ClassNotFoundException
/*     */   {
/*  90 */     if (s == null) {
/*  91 */       return null;
/*     */     }
/*  93 */     Class<?>[] c = new Class[s.length];
/*  94 */     for (int i = 0; i < s.length; i++) {
/*  95 */       c[i] = forName(s[i]);
/*     */     }
/*  97 */     return c;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String[] toTypeNameArray(Class<?>[] c)
/*     */   {
/* 107 */     if (c == null) {
/* 108 */       return null;
/*     */     }
/* 110 */     String[] s = new String[c.length];
/* 111 */     for (int i = 0; i < c.length; i++) {
/* 112 */       s[i] = c[i].getName();
/*     */     }
/* 114 */     return s;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Method getMethod(EvaluationContext ctx, Object base, Object property, Class<?>[] paramTypes, Object[] paramValues)
/*     */     throws MethodNotFoundException
/*     */   {
/* 137 */     if ((base == null) || (property == null)) {
/* 138 */       throw new MethodNotFoundException(MessageFactory.get("error.method.notfound", new Object[] { base, property, 
/*     */       
/* 140 */         paramString(paramTypes) }));
/*     */     }
/*     */     
/*     */ 
/* 144 */     String methodName = (property instanceof String) ? (String)property : property.toString();
/*     */     int paramCount;
/*     */     int paramCount;
/* 147 */     if (paramTypes == null) {
/* 148 */       paramCount = 0;
/*     */     } else {
/* 150 */       paramCount = paramTypes.length;
/*     */     }
/*     */     
/* 153 */     Method[] methods = base.getClass().getMethods();
/* 154 */     Map<Method, MatchResult> candidates = new HashMap();
/*     */     Method m;
/* 156 */     for (m : methods) {
/* 157 */       if (m.getName().equals(methodName))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 162 */         Class<?>[] mParamTypes = m.getParameterTypes();
/* 163 */         int mParamCount = mParamTypes.length;
/*     */         
/*     */ 
/*     */ 
/* 167 */         if ((m.isVarArgs()) || (paramCount == mParamCount))
/*     */         {
/*     */ 
/*     */ 
/* 171 */           if ((!m.isVarArgs()) || (paramCount >= mParamCount - 1))
/*     */           {
/*     */ 
/*     */ 
/* 175 */             if ((!m.isVarArgs()) || (paramCount != mParamCount) || (paramValues == null) || (paramValues.length <= paramCount) || 
/* 176 */               (paramTypes[(mParamCount - 1)].isArray()))
/*     */             {
/*     */ 
/*     */ 
/* 180 */               if ((!m.isVarArgs()) || (paramCount <= mParamCount) || (paramValues == null) || (paramValues.length == paramCount))
/*     */               {
/*     */ 
/*     */ 
/*     */ 
/* 185 */                 if ((m.isVarArgs()) || (paramValues == null) || (paramCount == paramValues.length))
/*     */                 {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 191 */                   int exactMatch = 0;
/* 192 */                   int assignableMatch = 0;
/* 193 */                   int coercibleMatch = 0;
/* 194 */                   int varArgsMatch = 0;
/* 195 */                   boolean noMatch = false;
/* 196 */                   for (int i = 0; i < mParamCount; i++)
/*     */                   {
/* 198 */                     if ((m.isVarArgs()) && (i == mParamCount - 1)) {
/* 199 */                       if ((i == paramCount) || ((paramValues != null) && (paramValues.length == i)))
/*     */                       {
/*     */ 
/* 202 */                         varArgsMatch = Integer.MAX_VALUE;
/* 203 */                         break;
/*     */                       }
/* 205 */                       Class<?> varType = mParamTypes[i].getComponentType();
/* 206 */                       for (int j = i; j < paramCount; j++) {
/* 207 */                         if (isAssignableFrom(paramTypes[j], varType)) {
/* 208 */                           assignableMatch++;
/* 209 */                           varArgsMatch++;
/*     */                         } else {
/* 211 */                           if (paramValues == null) {
/* 212 */                             noMatch = true;
/* 213 */                             break;
/*     */                           }
/* 215 */                           if (isCoercibleFrom(ctx, paramValues[j], varType)) {
/* 216 */                             coercibleMatch++;
/* 217 */                             varArgsMatch++;
/*     */                           } else {
/* 219 */                             noMatch = true;
/* 220 */                             break;
/*     */                           }
/*     */                           
/*     */                         }
/*     */                         
/*     */                       }
/*     */                       
/*     */ 
/*     */                     }
/* 229 */                     else if (mParamTypes[i].equals(paramTypes[i])) {
/* 230 */                       exactMatch++;
/* 231 */                     } else if ((paramTypes[i] != null) && (isAssignableFrom(paramTypes[i], mParamTypes[i]))) {
/* 232 */                       assignableMatch++;
/*     */                     } else {
/* 234 */                       if (paramValues == null) {
/* 235 */                         noMatch = true;
/* 236 */                         break;
/*     */                       }
/* 238 */                       if (isCoercibleFrom(ctx, paramValues[i], mParamTypes[i])) {
/* 239 */                         coercibleMatch++;
/*     */                       } else {
/* 241 */                         noMatch = true;
/* 242 */                         break;
/*     */                       }
/*     */                     }
/*     */                   }
/*     */                   
/*     */ 
/* 248 */                   if (!noMatch)
/*     */                   {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 254 */                     if ((exactMatch == paramCount) && (varArgsMatch == 0)) {
/* 255 */                       return getMethod(base.getClass(), base, m);
/*     */                     }
/*     */                     
/* 258 */                     candidates.put(m, new MatchResult(m
/* 259 */                       .isVarArgs(), exactMatch, assignableMatch, coercibleMatch, varArgsMatch, m.isBridge()));
/*     */                   }
/*     */                 } } } } }
/*     */       }
/*     */     }
/* 264 */     MatchResult bestMatch = new MatchResult(true, 0, 0, 0, 0, true);
/* 265 */     Method match = null;
/* 266 */     boolean multiple = false;
/* 267 */     for (Map.Entry<Method, MatchResult> entry : candidates.entrySet()) {
/* 268 */       int cmp = ((MatchResult)entry.getValue()).compareTo(bestMatch);
/* 269 */       if ((cmp > 0) || (match == null)) {
/* 270 */         bestMatch = (MatchResult)entry.getValue();
/* 271 */         match = (Method)entry.getKey();
/* 272 */         multiple = false;
/* 273 */       } else if (cmp == 0) {
/* 274 */         multiple = true;
/*     */       }
/*     */     }
/* 277 */     if (multiple) {
/* 278 */       if (bestMatch.getExactCount() == paramCount - 1)
/*     */       {
/*     */ 
/* 281 */         match = resolveAmbiguousMethod(candidates.keySet(), paramTypes);
/*     */       } else {
/* 283 */         match = null;
/*     */       }
/*     */       
/* 286 */       if (match == null)
/*     */       {
/*     */ 
/* 289 */         throw new MethodNotFoundException(MessageFactory.get("error.method.ambiguous", new Object[] { base, property, 
/*     */         
/* 291 */           paramString(paramTypes) }));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 296 */     if (match == null) {
/* 297 */       throw new MethodNotFoundException(MessageFactory.get("error.method.notfound", new Object[] { base, property, 
/*     */       
/* 299 */         paramString(paramTypes) }));
/*     */     }
/*     */     
/* 302 */     return getMethod(base.getClass(), base, match);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Method resolveAmbiguousMethod(Set<Method> candidates, Class<?>[] paramTypes)
/*     */   {
/* 312 */     Method m = (Method)candidates.iterator().next();
/*     */     
/* 314 */     int nonMatchIndex = 0;
/* 315 */     Class<?> nonMatchClass = null;
/*     */     
/* 317 */     for (int i = 0; i < paramTypes.length; i++) {
/* 318 */       if (m.getParameterTypes()[i] != paramTypes[i]) {
/* 319 */         nonMatchIndex = i;
/* 320 */         nonMatchClass = paramTypes[i];
/* 321 */         break;
/*     */       }
/*     */     }
/*     */     
/* 325 */     if (nonMatchClass == null)
/*     */     {
/* 327 */       return null;
/*     */     }
/*     */     
/* 330 */     for (i = candidates.iterator(); i.hasNext();) { c = (Method)i.next();
/* 331 */       if (c.getParameterTypes()[nonMatchIndex] == paramTypes[nonMatchIndex])
/*     */       {
/*     */ 
/*     */ 
/* 335 */         return null;
/*     */       }
/*     */     }
/*     */     
/*     */     Method c;
/* 340 */     Class<?> superClass = nonMatchClass.getSuperclass();
/* 341 */     Method c; while (superClass != null) {
/* 342 */       for (c = candidates.iterator(); c.hasNext();) { c = (Method)c.next();
/* 343 */         if (c.getParameterTypes()[nonMatchIndex].equals(superClass))
/*     */         {
/* 345 */           return c;
/*     */         }
/*     */       }
/* 348 */       superClass = superClass.getSuperclass();
/*     */     }
/*     */     
/*     */ 
/* 352 */     Method match = null;
/* 353 */     if (Number.class.isAssignableFrom(nonMatchClass)) {
/* 354 */       for (Method c : candidates) {
/* 355 */         Class<?> candidateType = c.getParameterTypes()[nonMatchIndex];
/* 356 */         if ((Number.class.isAssignableFrom(candidateType)) || 
/* 357 */           (candidateType.isPrimitive())) {
/* 358 */           if (match == null) {
/* 359 */             match = c;
/*     */           }
/*     */           else {
/* 362 */             match = null;
/* 363 */             break;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 369 */     return match;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean isAssignableFrom(Class<?> src, Class<?> target)
/*     */   {
/* 381 */     if (src == null) {
/* 382 */       return true;
/*     */     }
/*     */     Class<?> targetClass;
/*     */     Class<?> targetClass;
/* 386 */     if (target.isPrimitive()) { Class<?> targetClass;
/* 387 */       if (target == Boolean.TYPE) {
/* 388 */         targetClass = Boolean.class; } else { Class<?> targetClass;
/* 389 */         if (target == Character.TYPE) {
/* 390 */           targetClass = Character.class; } else { Class<?> targetClass;
/* 391 */           if (target == Byte.TYPE) {
/* 392 */             targetClass = Byte.class; } else { Class<?> targetClass;
/* 393 */             if (target == Short.TYPE) {
/* 394 */               targetClass = Short.class; } else { Class<?> targetClass;
/* 395 */               if (target == Integer.TYPE) {
/* 396 */                 targetClass = Integer.class; } else { Class<?> targetClass;
/* 397 */                 if (target == Long.TYPE) {
/* 398 */                   targetClass = Long.class; } else { Class<?> targetClass;
/* 399 */                   if (target == Float.TYPE) {
/* 400 */                     targetClass = Float.class;
/*     */                   } else
/* 402 */                     targetClass = Double.class;
/*     */                 }
/*     */               }
/* 405 */             } } } } } else { targetClass = target;
/*     */     }
/* 407 */     return targetClass.isAssignableFrom(src);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean isCoercibleFrom(EvaluationContext ctx, Object src, Class<?> target)
/*     */   {
/*     */     try
/*     */     {
/* 419 */       ELSupport.coerceToType(ctx, src, target);
/*     */     } catch (ELException e) {
/* 421 */       return false;
/*     */     }
/* 423 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Method getMethod(Class<?> type, Object base, Method m)
/*     */   {
/* 432 */     JreCompat jreCompat = JreCompat.getInstance();
/*     */     
/*     */ 
/* 435 */     if ((m == null) || (
/* 436 */       (Modifier.isPublic(type.getModifiers())) && (
/* 437 */       (jreCompat.canAccess(base, m)) || ((base != null) && (jreCompat.canAccess(null, m)))))) {
/* 438 */       return m;
/*     */     }
/* 440 */     Class<?>[] interfaces = type.getInterfaces();
/* 441 */     Method mp = null;
/* 442 */     for (Class<?> iface : interfaces) {
/*     */       try {
/* 444 */         mp = iface.getMethod(m.getName(), m.getParameterTypes());
/* 445 */         mp = getMethod(mp.getDeclaringClass(), base, mp);
/* 446 */         if (mp != null) {
/* 447 */           return mp;
/*     */         }
/*     */       }
/*     */       catch (NoSuchMethodException localNoSuchMethodException) {}
/*     */     }
/*     */     
/* 453 */     Object sup = type.getSuperclass();
/* 454 */     if (sup != null) {
/*     */       try {
/* 456 */         mp = ((Class)sup).getMethod(m.getName(), m.getParameterTypes());
/* 457 */         mp = getMethod(mp.getDeclaringClass(), base, mp);
/* 458 */         if (mp != null) {
/* 459 */           return mp;
/*     */         }
/*     */       }
/*     */       catch (NoSuchMethodException localNoSuchMethodException2) {}
/*     */     }
/*     */     
/* 465 */     return null;
/*     */   }
/*     */   
/*     */   private static final String paramString(Class<?>[] types)
/*     */   {
/* 470 */     if (types != null) {
/* 471 */       StringBuilder sb = new StringBuilder();
/* 472 */       for (Class<?> type : types) {
/* 473 */         if (type == null) {
/* 474 */           sb.append("null, ");
/*     */         } else {
/* 476 */           sb.append(type.getName()).append(", ");
/*     */         }
/*     */       }
/* 479 */       if (sb.length() > 2) {
/* 480 */         sb.setLength(sb.length() - 2);
/*     */       }
/* 482 */       return sb.toString();
/*     */     }
/* 484 */     return null;
/*     */   }
/*     */   
/*     */   private static ClassLoader getContextClassLoader() {
/*     */     ClassLoader tccl;
/*     */     ClassLoader tccl;
/* 490 */     if (System.getSecurityManager() != null) {
/* 491 */       PrivilegedAction<ClassLoader> pa = new PrivilegedGetTccl(null);
/* 492 */       tccl = (ClassLoader)AccessController.doPrivileged(pa);
/*     */     } else {
/* 494 */       tccl = Thread.currentThread().getContextClassLoader();
/*     */     }
/*     */     
/* 497 */     return tccl;
/*     */   }
/*     */   
/*     */   private static class PrivilegedGetTccl implements PrivilegedAction<ClassLoader>
/*     */   {
/*     */     public ClassLoader run()
/*     */     {
/* 504 */       return Thread.currentThread().getContextClassLoader();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static class MatchResult
/*     */     implements Comparable<MatchResult>
/*     */   {
/*     */     private final boolean varArgs;
/*     */     
/*     */     private final int exactCount;
/*     */     
/*     */     private final int assignableCount;
/*     */     
/*     */     private final int coercibleCount;
/*     */     private final int varArgsCount;
/*     */     private final boolean bridge;
/*     */     
/*     */     public MatchResult(boolean varArgs, int exactCount, int assignableCount, int coercibleCount, int varArgsCount, boolean bridge)
/*     */     {
/* 524 */       this.varArgs = varArgs;
/* 525 */       this.exactCount = exactCount;
/* 526 */       this.assignableCount = assignableCount;
/* 527 */       this.coercibleCount = coercibleCount;
/* 528 */       this.varArgsCount = varArgsCount;
/* 529 */       this.bridge = bridge;
/*     */     }
/*     */     
/*     */     public boolean isVarArgs() {
/* 533 */       return this.varArgs;
/*     */     }
/*     */     
/*     */     public int getExactCount() {
/* 537 */       return this.exactCount;
/*     */     }
/*     */     
/*     */     public int getAssignableCount() {
/* 541 */       return this.assignableCount;
/*     */     }
/*     */     
/*     */     public int getCoercible() {
/* 545 */       return this.coercibleCount;
/*     */     }
/*     */     
/*     */     public int getVarArgsCount() {
/* 549 */       return this.varArgsCount;
/*     */     }
/*     */     
/*     */     public boolean isBridge() {
/* 553 */       return this.bridge;
/*     */     }
/*     */     
/*     */ 
/*     */     public int compareTo(MatchResult o)
/*     */     {
/* 559 */       int cmp = Boolean.compare(o.isVarArgs(), isVarArgs());
/* 560 */       if (cmp == 0) {
/* 561 */         cmp = Integer.compare(getExactCount(), o.getExactCount());
/* 562 */         if (cmp == 0) {
/* 563 */           cmp = Integer.compare(getAssignableCount(), o.getAssignableCount());
/* 564 */           if (cmp == 0) {
/* 565 */             cmp = Integer.compare(getCoercible(), o.getCoercible());
/* 566 */             if (cmp == 0)
/*     */             {
/* 568 */               cmp = Integer.compare(o.getVarArgsCount(), getVarArgsCount());
/* 569 */               if (cmp == 0)
/*     */               {
/*     */ 
/*     */ 
/*     */ 
/* 574 */                 cmp = Boolean.compare(o.isBridge(), isBridge());
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/* 580 */       return cmp;
/*     */     }
/*     */     
/*     */     public boolean equals(Object o)
/*     */     {
/* 585 */       return (o == this) || ((null != o) && 
/* 586 */         (getClass().equals(o.getClass())) && 
/* 587 */         (((MatchResult)o).getExactCount() == getExactCount()) && 
/* 588 */         (((MatchResult)o).getAssignableCount() == getAssignableCount()) && 
/* 589 */         (((MatchResult)o).getCoercible() == getCoercible()) && 
/* 590 */         (((MatchResult)o).getVarArgsCount() == getVarArgsCount()) && 
/* 591 */         (((MatchResult)o).isVarArgs() == isVarArgs()) && 
/* 592 */         (((MatchResult)o).isBridge() == isBridge()));
/*     */     }
/*     */     
/*     */     public int hashCode()
/*     */     {
/* 597 */       int prime = 31;
/* 598 */       int result = 1;
/* 599 */       result = 31 * result + this.assignableCount;
/* 600 */       result = 31 * result + (this.bridge ? 1231 : 1237);
/* 601 */       result = 31 * result + this.coercibleCount;
/* 602 */       result = 31 * result + this.exactCount;
/* 603 */       result = 31 * result + (this.varArgs ? 1231 : 1237);
/* 604 */       result = 31 * result + this.varArgsCount;
/* 605 */       return result;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-el-9.0.54.jar!\org\apache\el\util\ReflectionUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */