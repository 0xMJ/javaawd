/*     */ package org.apache.el.stream;
/*     */ 
/*     */ import java.beans.FeatureDescriptor;
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.NoSuchElementException;
/*     */ import javax.el.ELContext;
/*     */ import javax.el.ELResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StreamELResolverImpl
/*     */   extends ELResolver
/*     */ {
/*     */   public Object getValue(ELContext context, Object base, Object property)
/*     */   {
/*  32 */     return null;
/*     */   }
/*     */   
/*     */   public Class<?> getType(ELContext context, Object base, Object property)
/*     */   {
/*  37 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setValue(ELContext context, Object base, Object property, Object value) {}
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isReadOnly(ELContext context, Object base, Object property)
/*     */   {
/*  48 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public Iterator<FeatureDescriptor> getFeatureDescriptors(ELContext context, Object base)
/*     */   {
/*  54 */     return null;
/*     */   }
/*     */   
/*     */   public Class<?> getCommonPropertyType(ELContext context, Object base)
/*     */   {
/*  59 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object invoke(ELContext context, Object base, Object method, Class<?>[] paramTypes, Object[] params)
/*     */   {
/*  66 */     if (("stream".equals(method)) && (params.length == 0)) {
/*  67 */       if (base.getClass().isArray()) {
/*  68 */         context.setPropertyResolved(true);
/*  69 */         return new Stream(new ArrayIterator(base)); }
/*  70 */       if ((base instanceof Collection)) {
/*  71 */         context.setPropertyResolved(true);
/*     */         
/*  73 */         Collection<Object> collection = (Collection)base;
/*  74 */         return new Stream(collection.iterator());
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*  79 */     return null;
/*     */   }
/*     */   
/*     */   private static class ArrayIterator
/*     */     implements Iterator<Object>
/*     */   {
/*     */     private final Object base;
/*     */     private final int size;
/*  87 */     private int index = 0;
/*     */     
/*     */     public ArrayIterator(Object base) {
/*  90 */       this.base = base;
/*  91 */       this.size = Array.getLength(base);
/*     */     }
/*     */     
/*     */     public boolean hasNext()
/*     */     {
/*  96 */       return this.size > this.index;
/*     */     }
/*     */     
/*     */     public Object next()
/*     */     {
/*     */       try {
/* 102 */         return Array.get(this.base, this.index++);
/*     */       } catch (ArrayIndexOutOfBoundsException e) {
/* 104 */         throw new NoSuchElementException();
/*     */       }
/*     */     }
/*     */     
/*     */     public void remove()
/*     */     {
/* 110 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-el-9.0.54.jar!\org\apache\el\stream\StreamELResolverImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */