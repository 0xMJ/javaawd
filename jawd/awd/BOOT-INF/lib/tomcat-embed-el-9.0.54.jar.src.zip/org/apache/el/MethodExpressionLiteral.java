/*     */ package org.apache.el;
/*     */ 
/*     */ import java.io.Externalizable;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInput;
/*     */ import java.io.ObjectOutput;
/*     */ import javax.el.ELContext;
/*     */ import javax.el.ELException;
/*     */ import javax.el.MethodExpression;
/*     */ import javax.el.MethodInfo;
/*     */ import org.apache.el.util.ReflectionUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MethodExpressionLiteral
/*     */   extends MethodExpression
/*     */   implements Externalizable
/*     */ {
/*     */   private Class<?> expectedType;
/*     */   private String expr;
/*     */   private Class<?>[] paramTypes;
/*     */   
/*     */   public MethodExpressionLiteral() {}
/*     */   
/*     */   public MethodExpressionLiteral(String expr, Class<?> expectedType, Class<?>[] paramTypes)
/*     */   {
/*  46 */     this.expr = expr;
/*  47 */     this.expectedType = expectedType;
/*  48 */     this.paramTypes = paramTypes;
/*     */   }
/*     */   
/*     */   public MethodInfo getMethodInfo(ELContext context) throws ELException
/*     */   {
/*  53 */     context.notifyBeforeEvaluation(getExpressionString());
/*  54 */     MethodInfo result = new MethodInfo(this.expr, this.expectedType, this.paramTypes);
/*     */     
/*  56 */     context.notifyAfterEvaluation(getExpressionString());
/*  57 */     return result;
/*     */   }
/*     */   
/*     */   public Object invoke(ELContext context, Object[] params) throws ELException
/*     */   {
/*  62 */     context.notifyBeforeEvaluation(getExpressionString());
/*     */     Object result;
/*  64 */     Object result; if (this.expectedType != null) {
/*  65 */       result = context.convertToType(this.expr, this.expectedType);
/*     */     } else {
/*  67 */       result = this.expr;
/*     */     }
/*  69 */     context.notifyAfterEvaluation(getExpressionString());
/*  70 */     return result;
/*     */   }
/*     */   
/*     */   public String getExpressionString()
/*     */   {
/*  75 */     return this.expr;
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/*  80 */     return ((obj instanceof MethodExpressionLiteral)) && (hashCode() == obj.hashCode());
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/*  85 */     return this.expr.hashCode();
/*     */   }
/*     */   
/*     */   public boolean isLiteralText()
/*     */   {
/*  90 */     return true;
/*     */   }
/*     */   
/*     */   public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException
/*     */   {
/*  95 */     this.expr = in.readUTF();
/*  96 */     String type = in.readUTF();
/*  97 */     if (!type.isEmpty()) {
/*  98 */       this.expectedType = ReflectionUtil.forName(type);
/*     */     }
/* 100 */     this.paramTypes = ReflectionUtil.toTypeArray(
/* 101 */       (String[])in.readObject());
/*     */   }
/*     */   
/*     */   public void writeExternal(ObjectOutput out) throws IOException
/*     */   {
/* 106 */     out.writeUTF(this.expr);
/* 107 */     out.writeUTF(this.expectedType != null ? this.expectedType.getName() : "");
/*     */     
/* 109 */     out.writeObject(ReflectionUtil.toTypeNameArray(this.paramTypes));
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-el-9.0.54.jar!\org\apache\el\MethodExpressionLiteral.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */