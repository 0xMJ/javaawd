/*    */ package org.apache.el.parser;
/*    */ 
/*    */ import javax.el.ELException;
/*    */ import org.apache.el.lang.EvaluationContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AstString
/*    */   extends SimpleNode
/*    */ {
/*    */   private volatile String string;
/*    */   
/*    */   public AstString(int id)
/*    */   {
/* 30 */     super(id);
/*    */   }
/*    */   
/*    */ 
/*    */   public String getString()
/*    */   {
/* 36 */     if (this.string == null) {
/* 37 */       this.string = this.image.substring(1, this.image.length() - 1);
/*    */     }
/* 39 */     return this.string;
/*    */   }
/*    */   
/*    */   public Class<?> getType(EvaluationContext ctx)
/*    */     throws ELException
/*    */   {
/* 45 */     return String.class;
/*    */   }
/*    */   
/*    */   public Object getValue(EvaluationContext ctx)
/*    */     throws ELException
/*    */   {
/* 51 */     return getString();
/*    */   }
/*    */   
/*    */   public void setImage(String image)
/*    */   {
/* 56 */     if (image.indexOf('\\') == -1) {
/* 57 */       this.image = image;
/* 58 */       return;
/*    */     }
/* 60 */     int size = image.length();
/* 61 */     StringBuilder buf = new StringBuilder(size);
/* 62 */     for (int i = 0; i < size; i++) {
/* 63 */       char c = image.charAt(i);
/* 64 */       if ((c == '\\') && (i + 1 < size)) {
/* 65 */         char c1 = image.charAt(i + 1);
/* 66 */         if ((c1 == '\\') || (c1 == '"') || (c1 == '\'')) {
/* 67 */           c = c1;
/* 68 */           i++;
/*    */         }
/*    */       }
/* 71 */       buf.append(c);
/*    */     }
/* 73 */     this.image = buf.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-el-9.0.54.jar!\org\apache\el\parser\AstString.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */