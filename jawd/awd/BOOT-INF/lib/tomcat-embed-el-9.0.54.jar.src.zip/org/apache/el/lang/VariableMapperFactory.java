/*    */ package org.apache.el.lang;
/*    */ 
/*    */ import javax.el.ValueExpression;
/*    */ import javax.el.VariableMapper;
/*    */ import org.apache.el.util.MessageFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VariableMapperFactory
/*    */   extends VariableMapper
/*    */ {
/*    */   private final VariableMapper target;
/*    */   private VariableMapper momento;
/*    */   
/*    */   public VariableMapperFactory(VariableMapper target)
/*    */   {
/* 30 */     if (target == null) {
/* 31 */       throw new NullPointerException(MessageFactory.get("error.noVariableMapperTarget"));
/*    */     }
/* 33 */     this.target = target;
/*    */   }
/*    */   
/*    */   public VariableMapper create() {
/* 37 */     return this.momento;
/*    */   }
/*    */   
/*    */   public ValueExpression resolveVariable(String variable)
/*    */   {
/* 42 */     ValueExpression expr = this.target.resolveVariable(variable);
/* 43 */     if (expr != null) {
/* 44 */       if (this.momento == null) {
/* 45 */         this.momento = new VariableMapperImpl();
/*    */       }
/* 47 */       this.momento.setVariable(variable, expr);
/*    */     }
/* 49 */     return expr;
/*    */   }
/*    */   
/*    */   public ValueExpression setVariable(String variable, ValueExpression expression)
/*    */   {
/* 54 */     throw new UnsupportedOperationException(MessageFactory.get("error.cannotSetVariables"));
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\tomcat-embed-el-9.0.54.jar!\org\apache\el\lang\VariableMapperFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */