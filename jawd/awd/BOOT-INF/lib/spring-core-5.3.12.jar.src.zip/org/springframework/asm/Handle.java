/*     */ package org.springframework.asm;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Handle
/*     */ {
/*     */   private final int tag;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final String owner;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final String name;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final String descriptor;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final boolean isInterface;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public Handle(int tag, String owner, String name, String descriptor)
/*     */   {
/*  76 */     this(tag, owner, name, descriptor, tag == 9);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Handle(int tag, String owner, String name, String descriptor, boolean isInterface)
/*     */   {
/*  99 */     this.tag = tag;
/* 100 */     this.owner = owner;
/* 101 */     this.name = name;
/* 102 */     this.descriptor = descriptor;
/* 103 */     this.isInterface = isInterface;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getTag()
/*     */   {
/* 115 */     return this.tag;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getOwner()
/*     */   {
/* 124 */     return this.owner;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/* 133 */     return this.name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getDesc()
/*     */   {
/* 142 */     return this.descriptor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isInterface()
/*     */   {
/* 151 */     return this.isInterface;
/*     */   }
/*     */   
/*     */   public boolean equals(Object object)
/*     */   {
/* 156 */     if (object == this) {
/* 157 */       return true;
/*     */     }
/* 159 */     if (!(object instanceof Handle)) {
/* 160 */       return false;
/*     */     }
/* 162 */     Handle handle = (Handle)object;
/* 163 */     if ((this.tag == handle.tag) && (this.isInterface == handle.isInterface)) {} return 
/*     */     
/* 165 */       (this.owner.equals(handle.owner)) && 
/* 166 */       (this.name.equals(handle.name)) && 
/* 167 */       (this.descriptor.equals(handle.descriptor));
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 172 */     return 
/*     */     
/* 174 */       this.tag + (this.isInterface ? 64 : 0) + this.owner.hashCode() * this.name.hashCode() * this.descriptor.hashCode();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 187 */     return this.owner + '.' + this.name + this.descriptor + " (" + this.tag + (this.isInterface ? " itf" : "") + ')';
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-core-5.3.12.jar!\org\springframework\asm\Handle.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */