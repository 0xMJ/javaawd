/*     */ package org.springframework.asm;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AnnotationVisitor
/*     */ {
/*     */   protected final int api;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected AnnotationVisitor av;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AnnotationVisitor(int api)
/*     */   {
/*  59 */     this(api, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AnnotationVisitor(int api, AnnotationVisitor annotationVisitor)
/*     */   {
/*  71 */     if ((api != 589824) && (api != 524288) && (api != 458752) && (api != 393216) && (api != 327680) && (api != 262144) && (api != 17432576))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  78 */       throw new IllegalArgumentException("Unsupported api " + api);
/*     */     }
/*     */     
/*  81 */     this.api = api;
/*  82 */     this.av = annotationVisitor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void visit(String name, Object value)
/*     */   {
/*  97 */     if (this.av != null) {
/*  98 */       this.av.visit(name, value);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void visitEnum(String name, String descriptor, String value)
/*     */   {
/* 110 */     if (this.av != null) {
/* 111 */       this.av.visitEnum(name, descriptor, value);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AnnotationVisitor visitAnnotation(String name, String descriptor)
/*     */   {
/* 125 */     if (this.av != null) {
/* 126 */       return this.av.visitAnnotation(name, descriptor);
/*     */     }
/* 128 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AnnotationVisitor visitArray(String name)
/*     */   {
/* 143 */     if (this.av != null) {
/* 144 */       return this.av.visitArray(name);
/*     */     }
/* 146 */     return null;
/*     */   }
/*     */   
/*     */   public void visitEnd()
/*     */   {
/* 151 */     if (this.av != null) {
/* 152 */       this.av.visitEnd();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-core-5.3.12.jar!\org\springframework\asm\AnnotationVisitor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */