/*     */ package org.springframework.asm;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class TypePath
/*     */ {
/*     */   public static final int ARRAY_ELEMENT = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int INNER_TYPE = 1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int WILDCARD_BOUND = 2;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int TYPE_ARGUMENT = 3;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final byte[] typePathContainer;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final int typePathOffset;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   TypePath(byte[] typePathContainer, int typePathOffset)
/*     */   {
/*  73 */     this.typePathContainer = typePathContainer;
/*  74 */     this.typePathOffset = typePathOffset;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getLength()
/*     */   {
/*  84 */     return this.typePathContainer[this.typePathOffset];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getStep(int index)
/*     */   {
/*  96 */     return this.typePathContainer[(this.typePathOffset + 2 * index + 1)];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getStepArgument(int index)
/*     */   {
/* 108 */     return this.typePathContainer[(this.typePathOffset + 2 * index + 2)];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static TypePath fromString(String typePath)
/*     */   {
/* 120 */     if ((typePath == null) || (typePath.length() == 0)) {
/* 121 */       return null;
/*     */     }
/* 123 */     int typePathLength = typePath.length();
/* 124 */     ByteVector output = new ByteVector(typePathLength);
/* 125 */     output.putByte(0);
/* 126 */     int typePathIndex = 0;
/* 127 */     while (typePathIndex < typePathLength) {
/* 128 */       char c = typePath.charAt(typePathIndex++);
/* 129 */       if (c == '[') {
/* 130 */         output.put11(0, 0);
/* 131 */       } else if (c == '.') {
/* 132 */         output.put11(1, 0);
/* 133 */       } else if (c == '*') {
/* 134 */         output.put11(2, 0);
/* 135 */       } else if ((c >= '0') && (c <= '9')) {
/* 136 */         int typeArg = c - '0';
/* 137 */         while (typePathIndex < typePathLength) {
/* 138 */           c = typePath.charAt(typePathIndex++);
/* 139 */           if ((c >= '0') && (c <= '9')) {
/* 140 */             typeArg = typeArg * 10 + c - 48;
/* 141 */           } else if (c != ';')
/*     */           {
/*     */ 
/* 144 */             throw new IllegalArgumentException();
/*     */           }
/*     */         }
/* 147 */         output.put11(3, typeArg);
/*     */       } else {
/* 149 */         throw new IllegalArgumentException();
/*     */       }
/*     */     }
/* 152 */     output.data[0] = ((byte)(output.length / 2));
/* 153 */     return new TypePath(output.data, 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 163 */     int length = getLength();
/* 164 */     StringBuilder result = new StringBuilder(length * 2);
/* 165 */     for (int i = 0; i < length; i++) {
/* 166 */       switch (getStep(i)) {
/*     */       case 0: 
/* 168 */         result.append('[');
/* 169 */         break;
/*     */       case 1: 
/* 171 */         result.append('.');
/* 172 */         break;
/*     */       case 2: 
/* 174 */         result.append('*');
/* 175 */         break;
/*     */       case 3: 
/* 177 */         result.append(getStepArgument(i)).append(';');
/* 178 */         break;
/*     */       default: 
/* 180 */         throw new AssertionError();
/*     */       }
/*     */     }
/* 183 */     return result.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static void put(TypePath typePath, ByteVector output)
/*     */   {
/* 194 */     if (typePath == null) {
/* 195 */       output.putByte(0);
/*     */     } else {
/* 197 */       int length = typePath.typePathContainer[typePath.typePathOffset] * 2 + 1;
/* 198 */       output.putByteArray(typePath.typePathContainer, typePath.typePathOffset, length);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-core-5.3.12.jar!\org\springframework\asm\TypePath.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */