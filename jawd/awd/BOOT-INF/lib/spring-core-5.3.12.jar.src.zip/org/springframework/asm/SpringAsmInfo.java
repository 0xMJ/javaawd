package org.springframework.asm;

public final class SpringAsmInfo
{
  public static final int ASM_VERSION = 17432576;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-core-5.3.12.jar!\org\springframework\asm\SpringAsmInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */