package org.springframework.core.convert.converter;

public abstract interface ConverterFactory<S, R>
{
  public abstract <T extends R> Converter<S, T> getConverter(Class<T> paramClass);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-core-5.3.12.jar!\org\springframework\core\convert\converter\ConverterFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */