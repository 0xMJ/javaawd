package org.springframework.core.convert.converter;

import org.springframework.core.convert.TypeDescriptor;

public abstract interface ConditionalConverter
{
  public abstract boolean matches(TypeDescriptor paramTypeDescriptor1, TypeDescriptor paramTypeDescriptor2);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-core-5.3.12.jar!\org\springframework\core\convert\converter\ConditionalConverter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */