package org.springframework.core.metrics;

import java.util.function.Supplier;
import org.springframework.lang.Nullable;

public abstract interface StartupStep
{
  public abstract String getName();
  
  public abstract long getId();
  
  @Nullable
  public abstract Long getParentId();
  
  public abstract StartupStep tag(String paramString1, String paramString2);
  
  public abstract StartupStep tag(String paramString, Supplier<String> paramSupplier);
  
  public abstract Tags getTags();
  
  public abstract void end();
  
  public static abstract interface Tag
  {
    public abstract String getKey();
    
    public abstract String getValue();
  }
  
  public static abstract interface Tags
    extends Iterable<StartupStep.Tag>
  {}
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-core-5.3.12.jar!\org\springframework\core\metrics\StartupStep.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */