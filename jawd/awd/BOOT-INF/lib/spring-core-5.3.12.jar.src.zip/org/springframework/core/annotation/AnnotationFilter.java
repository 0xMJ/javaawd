/*     */ package org.springframework.core.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @FunctionalInterface
/*     */ public abstract interface AnnotationFilter
/*     */ {
/*  43 */   public static final AnnotationFilter PLAIN = packages(new String[] { "java.lang", "org.springframework.lang" });
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  49 */   public static final AnnotationFilter JAVA = packages(new String[] { "java", "javax" });
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  55 */   public static final AnnotationFilter ALL = new AnnotationFilter()
/*     */   {
/*     */     public boolean matches(Annotation annotation) {
/*  58 */       return true;
/*     */     }
/*     */     
/*     */     public boolean matches(Class<?> type) {
/*  62 */       return true;
/*     */     }
/*     */     
/*     */     public boolean matches(String typeName) {
/*  66 */       return true;
/*     */     }
/*     */     
/*     */     public String toString() {
/*  70 */       return "All annotations filtered";
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*  83 */   public static final AnnotationFilter NONE = new AnnotationFilter()
/*     */   {
/*     */     public boolean matches(Annotation annotation) {
/*  86 */       return false;
/*     */     }
/*     */     
/*     */     public boolean matches(Class<?> type) {
/*  90 */       return false;
/*     */     }
/*     */     
/*     */     public boolean matches(String typeName) {
/*  94 */       return false;
/*     */     }
/*     */     
/*     */     public String toString() {
/*  98 */       return "No annotation filtering";
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean matches(Annotation annotation)
/*     */   {
/* 109 */     return matches(annotation.annotationType());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean matches(Class<?> type)
/*     */   {
/* 118 */     return matches(type.getName());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract boolean matches(String paramString);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static AnnotationFilter packages(String... packages)
/*     */   {
/* 136 */     return new PackagesAnnotationFilter(packages);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-core-5.3.12.jar!\org\springframework\core\annotation\AnnotationFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */