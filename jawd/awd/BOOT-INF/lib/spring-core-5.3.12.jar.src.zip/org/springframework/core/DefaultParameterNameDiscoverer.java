/*    */ package org.springframework.core;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultParameterNameDiscoverer
/*    */   extends PrioritizedParameterNameDiscoverer
/*    */ {
/*    */   public DefaultParameterNameDiscoverer()
/*    */   {
/* 44 */     if ((KotlinDetector.isKotlinReflectPresent()) && (!NativeDetector.inNativeImage())) {
/* 45 */       addDiscoverer(new KotlinReflectionParameterNameDiscoverer());
/*    */     }
/* 47 */     addDiscoverer(new StandardReflectionParameterNameDiscoverer());
/* 48 */     addDiscoverer(new LocalVariableTableParameterNameDiscoverer());
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-core-5.3.12.jar!\org\springframework\core\DefaultParameterNameDiscoverer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */