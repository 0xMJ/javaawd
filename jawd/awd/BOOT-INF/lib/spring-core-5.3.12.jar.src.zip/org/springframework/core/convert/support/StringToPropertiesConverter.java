/*    */ package org.springframework.core.convert.support;
/*    */ 
/*    */ import java.io.ByteArrayInputStream;
/*    */ import java.nio.charset.StandardCharsets;
/*    */ import java.util.Properties;
/*    */ import org.springframework.core.convert.converter.Converter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class StringToPropertiesConverter
/*    */   implements Converter<String, Properties>
/*    */ {
/*    */   public Properties convert(String source)
/*    */   {
/*    */     try
/*    */     {
/* 37 */       Properties props = new Properties();
/*    */       
/* 39 */       props.load(new ByteArrayInputStream(source.getBytes(StandardCharsets.ISO_8859_1)));
/* 40 */       return props;
/*    */     }
/*    */     catch (Exception ex)
/*    */     {
/* 44 */       throw new IllegalArgumentException("Failed to parse [" + source + "] into Properties", ex);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-core-5.3.12.jar!\org\springframework\core\convert\support\StringToPropertiesConverter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */