package org.springframework.core.env;

public abstract interface EnvironmentCapable
{
  public abstract Environment getEnvironment();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-core-5.3.12.jar!\org\springframework\core\env\EnvironmentCapable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */