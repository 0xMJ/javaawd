/*    */ package org.springframework.core.io;
/*    */ 
/*    */ import java.io.FileNotFoundException;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DescriptiveResource
/*    */   extends AbstractResource
/*    */ {
/*    */   private final String description;
/*    */   
/*    */   public DescriptiveResource(@Nullable String description)
/*    */   {
/* 45 */     this.description = (description != null ? description : "");
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean exists()
/*    */   {
/* 51 */     return false;
/*    */   }
/*    */   
/*    */   public boolean isReadable()
/*    */   {
/* 56 */     return false;
/*    */   }
/*    */   
/*    */   public InputStream getInputStream()
/*    */     throws IOException
/*    */   {
/* 62 */     throw new FileNotFoundException(getDescription() + " cannot be opened because it does not point to a readable resource");
/*    */   }
/*    */   
/*    */   public String getDescription()
/*    */   {
/* 67 */     return this.description;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean equals(@Nullable Object other)
/*    */   {
/* 76 */     return (this == other) || (((other instanceof DescriptiveResource)) && 
/* 77 */       (((DescriptiveResource)other).description.equals(this.description)));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 85 */     return this.description.hashCode();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-core-5.3.12.jar!\org\springframework\core\io\DescriptiveResource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */