/*    */ package org.springframework.core.annotation;
/*    */ 
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */  enum IntrospectionFailureLogger
/*    */ {
/* 35 */   DEBUG, 
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 46 */   INFO;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   @Nullable
/*    */   private static Log logger;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   private IntrospectionFailureLogger() {}
/*    */   
/*    */ 
/*    */ 
/*    */   void log(String message, @Nullable Object source, Exception ex)
/*    */   {
/* 63 */     String on = source != null ? " on " + source : "";
/* 64 */     log(message + on + ": " + ex);
/*    */   }
/*    */   
/*    */   abstract boolean isEnabled();
/*    */   
/*    */   abstract void log(String paramString);
/*    */   
/*    */   private static Log getLogger()
/*    */   {
/* 73 */     Log logger = logger;
/* 74 */     if (logger == null) {
/* 75 */       logger = LogFactory.getLog(MergedAnnotation.class);
/* 76 */       logger = logger;
/*    */     }
/* 78 */     return logger;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-core-5.3.12.jar!\org\springframework\core\annotation\IntrospectionFailureLogger.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */