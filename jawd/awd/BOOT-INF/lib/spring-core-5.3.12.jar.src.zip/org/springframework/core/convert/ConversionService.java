package org.springframework.core.convert;

import org.springframework.lang.Nullable;

public abstract interface ConversionService
{
  public abstract boolean canConvert(@Nullable Class<?> paramClass1, Class<?> paramClass2);
  
  public abstract boolean canConvert(@Nullable TypeDescriptor paramTypeDescriptor1, TypeDescriptor paramTypeDescriptor2);
  
  @Nullable
  public abstract <T> T convert(@Nullable Object paramObject, Class<T> paramClass);
  
  @Nullable
  public abstract Object convert(@Nullable Object paramObject, @Nullable TypeDescriptor paramTypeDescriptor1, TypeDescriptor paramTypeDescriptor2);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-core-5.3.12.jar!\org\springframework\core\convert\ConversionService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */