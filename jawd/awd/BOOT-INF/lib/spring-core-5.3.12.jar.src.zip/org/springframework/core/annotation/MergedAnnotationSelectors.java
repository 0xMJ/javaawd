/*     */ package org.springframework.core.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MergedAnnotationSelectors
/*     */ {
/*  33 */   private static final MergedAnnotationSelector<?> NEAREST = new Nearest(null);
/*     */   
/*  35 */   private static final MergedAnnotationSelector<?> FIRST_DIRECTLY_DECLARED = new FirstDirectlyDeclared(null);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static <A extends Annotation> MergedAnnotationSelector<A> nearest()
/*     */   {
/*  48 */     return NEAREST;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static <A extends Annotation> MergedAnnotationSelector<A> firstDirectlyDeclared()
/*     */   {
/*  58 */     return FIRST_DIRECTLY_DECLARED;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class Nearest
/*     */     implements MergedAnnotationSelector<Annotation>
/*     */   {
/*     */     public boolean isBestCandidate(MergedAnnotation<Annotation> annotation)
/*     */     {
/*  69 */       return annotation.getDistance() == 0;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public MergedAnnotation<Annotation> select(MergedAnnotation<Annotation> existing, MergedAnnotation<Annotation> candidate)
/*     */     {
/*  76 */       if (candidate.getDistance() < existing.getDistance()) {
/*  77 */         return candidate;
/*     */       }
/*  79 */       return existing;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class FirstDirectlyDeclared
/*     */     implements MergedAnnotationSelector<Annotation>
/*     */   {
/*     */     public boolean isBestCandidate(MergedAnnotation<Annotation> annotation)
/*     */     {
/*  93 */       return annotation.getDistance() == 0;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public MergedAnnotation<Annotation> select(MergedAnnotation<Annotation> existing, MergedAnnotation<Annotation> candidate)
/*     */     {
/* 100 */       if ((existing.getDistance() > 0) && (candidate.getDistance() == 0)) {
/* 101 */         return candidate;
/*     */       }
/* 103 */       return existing;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-core-5.3.12.jar!\org\springframework\core\annotation\MergedAnnotationSelectors.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */