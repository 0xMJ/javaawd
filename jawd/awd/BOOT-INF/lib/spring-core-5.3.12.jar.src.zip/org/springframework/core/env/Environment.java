package org.springframework.core.env;

public abstract interface Environment
  extends PropertyResolver
{
  public abstract String[] getActiveProfiles();
  
  public abstract String[] getDefaultProfiles();
  
  @Deprecated
  public abstract boolean acceptsProfiles(String... paramVarArgs);
  
  public abstract boolean acceptsProfiles(Profiles paramProfiles);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-core-5.3.12.jar!\org\springframework\core\env\Environment.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */