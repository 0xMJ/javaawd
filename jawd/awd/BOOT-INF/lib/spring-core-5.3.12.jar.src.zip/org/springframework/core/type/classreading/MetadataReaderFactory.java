package org.springframework.core.type.classreading;

import java.io.IOException;
import org.springframework.core.io.Resource;

public abstract interface MetadataReaderFactory
{
  public abstract MetadataReader getMetadataReader(String paramString)
    throws IOException;
  
  public abstract MetadataReader getMetadataReader(Resource paramResource)
    throws IOException;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-core-5.3.12.jar!\org\springframework\core\type\classreading\MetadataReaderFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */