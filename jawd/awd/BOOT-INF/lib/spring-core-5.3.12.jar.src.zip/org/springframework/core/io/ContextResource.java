package org.springframework.core.io;

public abstract interface ContextResource
  extends Resource
{
  public abstract String getPathWithinContext();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-core-5.3.12.jar!\org\springframework\core\io\ContextResource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */