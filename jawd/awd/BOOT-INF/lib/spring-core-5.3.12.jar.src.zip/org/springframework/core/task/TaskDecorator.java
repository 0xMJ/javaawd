package org.springframework.core.task;

@FunctionalInterface
public abstract interface TaskDecorator
{
  public abstract Runnable decorate(Runnable paramRunnable);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-core-5.3.12.jar!\org\springframework\core\task\TaskDecorator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */