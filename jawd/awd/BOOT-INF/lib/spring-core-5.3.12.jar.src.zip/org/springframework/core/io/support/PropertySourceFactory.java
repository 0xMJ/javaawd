package org.springframework.core.io.support;

import java.io.IOException;
import org.springframework.core.env.PropertySource;
import org.springframework.lang.Nullable;

public abstract interface PropertySourceFactory
{
  public abstract PropertySource<?> createPropertySource(@Nullable String paramString, EncodedResource paramEncodedResource)
    throws IOException;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-core-5.3.12.jar!\org\springframework\core\io\support\PropertySourceFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */