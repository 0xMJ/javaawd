package org.springframework.core.env;

import org.springframework.lang.Nullable;

public abstract interface PropertyResolver
{
  public abstract boolean containsProperty(String paramString);
  
  @Nullable
  public abstract String getProperty(String paramString);
  
  public abstract String getProperty(String paramString1, String paramString2);
  
  @Nullable
  public abstract <T> T getProperty(String paramString, Class<T> paramClass);
  
  public abstract <T> T getProperty(String paramString, Class<T> paramClass, T paramT);
  
  public abstract String getRequiredProperty(String paramString)
    throws IllegalStateException;
  
  public abstract <T> T getRequiredProperty(String paramString, Class<T> paramClass)
    throws IllegalStateException;
  
  public abstract String resolvePlaceholders(String paramString);
  
  public abstract String resolveRequiredPlaceholders(String paramString)
    throws IllegalArgumentException;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-core-5.3.12.jar!\org\springframework\core\env\PropertyResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */