/*    */ package org.springframework.core.convert.support;
/*    */ 
/*    */ import org.springframework.core.convert.ConversionService;
/*    */ import org.springframework.core.convert.converter.Converter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class EnumToIntegerConverter
/*    */   extends AbstractConditionalEnumConverter
/*    */   implements Converter<Enum<?>, Integer>
/*    */ {
/*    */   public EnumToIntegerConverter(ConversionService conversionService)
/*    */   {
/* 32 */     super(conversionService);
/*    */   }
/*    */   
/*    */   public Integer convert(Enum<?> source)
/*    */   {
/* 37 */     return Integer.valueOf(source.ordinal());
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-core-5.3.12.jar!\org\springframework\core\convert\support\EnumToIntegerConverter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */