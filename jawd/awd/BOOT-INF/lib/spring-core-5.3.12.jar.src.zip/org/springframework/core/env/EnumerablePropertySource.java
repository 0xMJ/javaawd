/*    */ package org.springframework.core.env;
/*    */ 
/*    */ import org.springframework.util.ObjectUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class EnumerablePropertySource<T>
/*    */   extends PropertySource<T>
/*    */ {
/*    */   public EnumerablePropertySource(String name, T source)
/*    */   {
/* 53 */     super(name, source);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected EnumerablePropertySource(String name)
/*    */   {
/* 62 */     super(name);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean containsProperty(String name)
/*    */   {
/* 74 */     return ObjectUtils.containsElement(getPropertyNames(), name);
/*    */   }
/*    */   
/*    */   public abstract String[] getPropertyNames();
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-core-5.3.12.jar!\org\springframework\core\env\EnumerablePropertySource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */