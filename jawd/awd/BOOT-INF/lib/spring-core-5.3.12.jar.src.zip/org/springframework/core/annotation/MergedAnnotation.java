/*     */ package org.springframework.core.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.AnnotatedElement;
/*     */ import java.util.EnumSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Optional;
/*     */ import java.util.Set;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Predicate;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract interface MergedAnnotation<A extends Annotation>
/*     */ {
/*     */   public static final String VALUE = "value";
/*     */   
/*     */   public abstract Class<A> getType();
/*     */   
/*     */   public abstract boolean isPresent();
/*     */   
/*     */   public abstract boolean isDirectlyPresent();
/*     */   
/*     */   public abstract boolean isMetaPresent();
/*     */   
/*     */   public abstract int getDistance();
/*     */   
/*     */   public abstract int getAggregateIndex();
/*     */   
/*     */   @Nullable
/*     */   public abstract Object getSource();
/*     */   
/*     */   @Nullable
/*     */   public abstract MergedAnnotation<?> getMetaSource();
/*     */   
/*     */   public abstract MergedAnnotation<?> getRoot();
/*     */   
/*     */   public abstract List<Class<? extends Annotation>> getMetaTypes();
/*     */   
/*     */   public abstract boolean hasNonDefaultValue(String paramString);
/*     */   
/*     */   public abstract boolean hasDefaultValue(String paramString)
/*     */     throws NoSuchElementException;
/*     */   
/*     */   public abstract byte getByte(String paramString)
/*     */     throws NoSuchElementException;
/*     */   
/*     */   public abstract byte[] getByteArray(String paramString)
/*     */     throws NoSuchElementException;
/*     */   
/*     */   public abstract boolean getBoolean(String paramString)
/*     */     throws NoSuchElementException;
/*     */   
/*     */   public abstract boolean[] getBooleanArray(String paramString)
/*     */     throws NoSuchElementException;
/*     */   
/*     */   public abstract char getChar(String paramString)
/*     */     throws NoSuchElementException;
/*     */   
/*     */   public abstract char[] getCharArray(String paramString)
/*     */     throws NoSuchElementException;
/*     */   
/*     */   public abstract short getShort(String paramString)
/*     */     throws NoSuchElementException;
/*     */   
/*     */   public abstract short[] getShortArray(String paramString)
/*     */     throws NoSuchElementException;
/*     */   
/*     */   public abstract int getInt(String paramString)
/*     */     throws NoSuchElementException;
/*     */   
/*     */   public abstract int[] getIntArray(String paramString)
/*     */     throws NoSuchElementException;
/*     */   
/*     */   public abstract long getLong(String paramString)
/*     */     throws NoSuchElementException;
/*     */   
/*     */   public abstract long[] getLongArray(String paramString)
/*     */     throws NoSuchElementException;
/*     */   
/*     */   public abstract double getDouble(String paramString)
/*     */     throws NoSuchElementException;
/*     */   
/*     */   public abstract double[] getDoubleArray(String paramString)
/*     */     throws NoSuchElementException;
/*     */   
/*     */   public abstract float getFloat(String paramString)
/*     */     throws NoSuchElementException;
/*     */   
/*     */   public abstract float[] getFloatArray(String paramString)
/*     */     throws NoSuchElementException;
/*     */   
/*     */   public abstract String getString(String paramString)
/*     */     throws NoSuchElementException;
/*     */   
/*     */   public abstract String[] getStringArray(String paramString)
/*     */     throws NoSuchElementException;
/*     */   
/*     */   public abstract Class<?> getClass(String paramString)
/*     */     throws NoSuchElementException;
/*     */   
/*     */   public abstract Class<?>[] getClassArray(String paramString)
/*     */     throws NoSuchElementException;
/*     */   
/*     */   public abstract <E extends Enum<E>> E getEnum(String paramString, Class<E> paramClass)
/*     */     throws NoSuchElementException;
/*     */   
/*     */   public abstract <E extends Enum<E>> E[] getEnumArray(String paramString, Class<E> paramClass)
/*     */     throws NoSuchElementException;
/*     */   
/*     */   public abstract <T extends Annotation> MergedAnnotation<T> getAnnotation(String paramString, Class<T> paramClass)
/*     */     throws NoSuchElementException;
/*     */   
/*     */   public abstract <T extends Annotation> MergedAnnotation<T>[] getAnnotationArray(String paramString, Class<T> paramClass)
/*     */     throws NoSuchElementException;
/*     */   
/*     */   public abstract Optional<Object> getValue(String paramString);
/*     */   
/*     */   public abstract <T> Optional<T> getValue(String paramString, Class<T> paramClass);
/*     */   
/*     */   public abstract Optional<Object> getDefaultValue(String paramString);
/*     */   
/*     */   public abstract <T> Optional<T> getDefaultValue(String paramString, Class<T> paramClass);
/*     */   
/*     */   public abstract MergedAnnotation<A> filterDefaultValues();
/*     */   
/*     */   public abstract MergedAnnotation<A> filterAttributes(Predicate<String> paramPredicate);
/*     */   
/*     */   public abstract MergedAnnotation<A> withNonMergedAttributes();
/*     */   
/*     */   public abstract AnnotationAttributes asAnnotationAttributes(Adapt... paramVarArgs);
/*     */   
/*     */   public abstract Map<String, Object> asMap(Adapt... paramVarArgs);
/*     */   
/*     */   public abstract <T extends Map<String, Object>> T asMap(Function<MergedAnnotation<?>, T> paramFunction, Adapt... paramVarArgs);
/*     */   
/*     */   public abstract A synthesize()
/*     */     throws NoSuchElementException;
/*     */   
/*     */   public abstract Optional<A> synthesize(Predicate<? super MergedAnnotation<A>> paramPredicate)
/*     */     throws NoSuchElementException;
/*     */   
/*     */   public static <A extends Annotation> MergedAnnotation<A> missing()
/*     */   {
/* 525 */     return MissingMergedAnnotation.getInstance();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static <A extends Annotation> MergedAnnotation<A> from(A annotation)
/*     */   {
/* 535 */     return from(null, annotation);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static <A extends Annotation> MergedAnnotation<A> from(@Nullable Object source, A annotation)
/*     */   {
/* 548 */     return TypeMappedAnnotation.from(source, annotation);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static <A extends Annotation> MergedAnnotation<A> of(Class<A> annotationType)
/*     */   {
/* 559 */     return of(null, annotationType, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static <A extends Annotation> MergedAnnotation<A> of(Class<A> annotationType, @Nullable Map<String, ?> attributes)
/*     */   {
/* 574 */     return of(null, annotationType, attributes);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static <A extends Annotation> MergedAnnotation<A> of(@Nullable AnnotatedElement source, Class<A> annotationType, @Nullable Map<String, ?> attributes)
/*     */   {
/* 591 */     return of(null, source, annotationType, attributes);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static <A extends Annotation> MergedAnnotation<A> of(@Nullable ClassLoader classLoader, @Nullable Object source, Class<A> annotationType, @Nullable Map<String, ?> attributes)
/*     */   {
/* 610 */     return TypeMappedAnnotation.of(classLoader, source, annotationType, attributes);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static enum Adapt
/*     */   {
/* 624 */     CLASS_TO_STRING, 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 630 */     ANNOTATION_TO_MAP;
/*     */     
/*     */     private Adapt() {}
/* 633 */     protected final boolean isIn(Adapt... adaptations) { for (Adapt candidate : adaptations) {
/* 634 */         if (candidate == this) {
/* 635 */           return true;
/*     */         }
/*     */       }
/* 638 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public static Adapt[] values(boolean classToString, boolean annotationsToMap)
/*     */     {
/* 648 */       EnumSet<Adapt> result = EnumSet.noneOf(Adapt.class);
/* 649 */       addIfTrue(result, CLASS_TO_STRING, classToString);
/* 650 */       addIfTrue(result, ANNOTATION_TO_MAP, annotationsToMap);
/* 651 */       return (Adapt[])result.toArray(new Adapt[0]);
/*     */     }
/*     */     
/*     */     private static <T> void addIfTrue(Set<T> result, T value, boolean test) {
/* 655 */       if (test) {
/* 656 */         result.add(value);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-core-5.3.12.jar!\org\springframework\core\annotation\MergedAnnotation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */