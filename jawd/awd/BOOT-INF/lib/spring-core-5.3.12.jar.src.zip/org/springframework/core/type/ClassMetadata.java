/*    */ package org.springframework.core.type;
/*    */ 
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract interface ClassMetadata
/*    */ {
/*    */   public abstract String getClassName();
/*    */   
/*    */   public abstract boolean isInterface();
/*    */   
/*    */   public abstract boolean isAnnotation();
/*    */   
/*    */   public abstract boolean isAbstract();
/*    */   
/*    */   public boolean isConcrete()
/*    */   {
/* 59 */     return (!isInterface()) && (!isAbstract());
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public abstract boolean isFinal();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public abstract boolean isIndependent();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean hasEnclosingClass()
/*    */   {
/* 82 */     return getEnclosingClassName() != null;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   @Nullable
/*    */   public abstract String getEnclosingClassName();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean hasSuperClass()
/*    */   {
/* 96 */     return getSuperClassName() != null;
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   public abstract String getSuperClassName();
/*    */   
/*    */   public abstract String[] getInterfaceNames();
/*    */   
/*    */   public abstract String[] getMemberClassNames();
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-core-5.3.12.jar!\org\springframework\core\type\ClassMetadata.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */