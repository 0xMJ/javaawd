package org.springframework.core.type.classreading;

import org.springframework.core.io.Resource;
import org.springframework.core.type.AnnotationMetadata;
import org.springframework.core.type.ClassMetadata;

public abstract interface MetadataReader
{
  public abstract Resource getResource();
  
  public abstract ClassMetadata getClassMetadata();
  
  public abstract AnnotationMetadata getAnnotationMetadata();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-core-5.3.12.jar!\org\springframework\core\type\classreading\MetadataReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */