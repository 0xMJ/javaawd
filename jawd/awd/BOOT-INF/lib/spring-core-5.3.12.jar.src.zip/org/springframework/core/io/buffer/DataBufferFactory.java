package org.springframework.core.io.buffer;

import java.nio.ByteBuffer;
import java.util.List;

public abstract interface DataBufferFactory
{
  public abstract DataBuffer allocateBuffer();
  
  public abstract DataBuffer allocateBuffer(int paramInt);
  
  public abstract DataBuffer wrap(ByteBuffer paramByteBuffer);
  
  public abstract DataBuffer wrap(byte[] paramArrayOfByte);
  
  public abstract DataBuffer join(List<? extends DataBuffer> paramList);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-core-5.3.12.jar!\org\springframework\core\io\buffer\DataBufferFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */