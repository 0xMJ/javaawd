package org.springframework.core.style;

import org.springframework.lang.Nullable;

public abstract interface ValueStyler
{
  public abstract String style(@Nullable Object paramObject);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-core-5.3.12.jar!\org\springframework\core\style\ValueStyler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */