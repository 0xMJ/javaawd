package org.springframework.core.task;

import java.util.concurrent.Callable;
import org.springframework.util.concurrent.ListenableFuture;

public abstract interface AsyncListenableTaskExecutor
  extends AsyncTaskExecutor
{
  public abstract ListenableFuture<?> submitListenable(Runnable paramRunnable);
  
  public abstract <T> ListenableFuture<T> submitListenable(Callable<T> paramCallable);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-core-5.3.12.jar!\org\springframework\core\task\AsyncListenableTaskExecutor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */