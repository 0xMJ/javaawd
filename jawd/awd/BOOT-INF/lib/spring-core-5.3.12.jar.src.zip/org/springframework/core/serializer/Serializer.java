/*    */ package org.springframework.core.serializer;
/*    */ 
/*    */ import java.io.ByteArrayOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @FunctionalInterface
/*    */ public abstract interface Serializer<T>
/*    */ {
/*    */   public abstract void serialize(T paramT, OutputStream paramOutputStream)
/*    */     throws IOException;
/*    */   
/*    */   public byte[] serializeToByteArray(T object)
/*    */     throws IOException
/*    */   {
/* 55 */     ByteArrayOutputStream out = new ByteArrayOutputStream(1024);
/* 56 */     serialize(object, out);
/* 57 */     return out.toByteArray();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-core-5.3.12.jar!\org\springframework\core\serializer\Serializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */