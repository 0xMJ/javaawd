package org.springframework.core.convert.converter;

public abstract interface ConverterRegistry
{
  public abstract void addConverter(Converter<?, ?> paramConverter);
  
  public abstract <S, T> void addConverter(Class<S> paramClass, Class<T> paramClass1, Converter<? super S, ? extends T> paramConverter);
  
  public abstract void addConverter(GenericConverter paramGenericConverter);
  
  public abstract void addConverterFactory(ConverterFactory<?, ?> paramConverterFactory);
  
  public abstract void removeConvertible(Class<?> paramClass1, Class<?> paramClass2);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-core-5.3.12.jar!\org\springframework\core\convert\converter\ConverterRegistry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */