/*    */ package org.springframework.core.convert.support;
/*    */ 
/*    */ import java.util.Set;
/*    */ import org.springframework.core.convert.converter.Converter;
/*    */ import org.springframework.core.convert.converter.ConverterFactory;
/*    */ import org.springframework.core.convert.converter.ConverterRegistry;
/*    */ import org.springframework.core.convert.converter.GenericConverter;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ConversionServiceFactory
/*    */ {
/*    */   public static void registerConverters(@Nullable Set<?> converters, ConverterRegistry registry)
/*    */   {
/* 49 */     if (converters != null) {
/* 50 */       for (Object converter : converters) {
/* 51 */         if ((converter instanceof GenericConverter)) {
/* 52 */           registry.addConverter((GenericConverter)converter);
/*    */         }
/* 54 */         else if ((converter instanceof Converter)) {
/* 55 */           registry.addConverter((Converter)converter);
/*    */         }
/* 57 */         else if ((converter instanceof ConverterFactory)) {
/* 58 */           registry.addConverterFactory((ConverterFactory)converter);
/*    */         }
/*    */         else {
/* 61 */           throw new IllegalArgumentException("Each converter object must implement one of the Converter, ConverterFactory, or GenericConverter interfaces");
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-core-5.3.12.jar!\org\springframework\core\convert\support\ConversionServiceFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */