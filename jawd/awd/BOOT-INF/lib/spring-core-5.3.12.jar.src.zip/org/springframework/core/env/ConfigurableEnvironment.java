package org.springframework.core.env;

import java.util.Map;

public abstract interface ConfigurableEnvironment
  extends Environment, ConfigurablePropertyResolver
{
  public abstract void setActiveProfiles(String... paramVarArgs);
  
  public abstract void addActiveProfile(String paramString);
  
  public abstract void setDefaultProfiles(String... paramVarArgs);
  
  public abstract MutablePropertySources getPropertySources();
  
  public abstract Map<String, Object> getSystemProperties();
  
  public abstract Map<String, Object> getSystemEnvironment();
  
  public abstract void merge(ConfigurableEnvironment paramConfigurableEnvironment);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-core-5.3.12.jar!\org\springframework\core\env\ConfigurableEnvironment.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */