package org.springframework.core.io.buffer;

public abstract interface PooledDataBuffer
  extends DataBuffer
{
  public abstract boolean isAllocated();
  
  public abstract PooledDataBuffer retain();
  
  public abstract PooledDataBuffer touch(Object paramObject);
  
  public abstract boolean release();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-core-5.3.12.jar!\org\springframework\core\io\buffer\PooledDataBuffer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */