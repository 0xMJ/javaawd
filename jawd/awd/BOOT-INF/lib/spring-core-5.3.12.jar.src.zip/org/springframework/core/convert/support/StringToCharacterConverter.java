/*    */ package org.springframework.core.convert.support;
/*    */ 
/*    */ import org.springframework.core.convert.converter.Converter;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class StringToCharacterConverter
/*    */   implements Converter<String, Character>
/*    */ {
/*    */   @Nullable
/*    */   public Character convert(String source)
/*    */   {
/* 33 */     if (source.isEmpty()) {
/* 34 */       return null;
/*    */     }
/* 36 */     if (source.length() > 1)
/*    */     {
/* 38 */       throw new IllegalArgumentException("Can only convert a [String] with length of 1 to a [Character]; string value '" + source + "'  has length of " + source.length());
/*    */     }
/* 40 */     return Character.valueOf(source.charAt(0));
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-core-5.3.12.jar!\org\springframework\core\convert\support\StringToCharacterConverter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */