/*    */ package org.springframework.core.env;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MapPropertySource
/*    */   extends EnumerablePropertySource<Map<String, Object>>
/*    */ {
/*    */   public MapPropertySource(String name, Map<String, Object> source)
/*    */   {
/* 43 */     super(name, source);
/*    */   }
/*    */   
/*    */ 
/*    */   @Nullable
/*    */   public Object getProperty(String name)
/*    */   {
/* 50 */     return ((Map)this.source).get(name);
/*    */   }
/*    */   
/*    */   public boolean containsProperty(String name)
/*    */   {
/* 55 */     return ((Map)this.source).containsKey(name);
/*    */   }
/*    */   
/*    */   public String[] getPropertyNames()
/*    */   {
/* 60 */     return StringUtils.toStringArray(((Map)this.source).keySet());
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-core-5.3.12.jar!\org\springframework\core\env\MapPropertySource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */