/*    */ package org.springframework.core.serializer;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.ObjectInputStream;
/*    */ import org.springframework.core.ConfigurableObjectInputStream;
/*    */ import org.springframework.core.NestedIOException;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultDeserializer
/*    */   implements Deserializer<Object>
/*    */ {
/*    */   @Nullable
/*    */   private final ClassLoader classLoader;
/*    */   
/*    */   public DefaultDeserializer()
/*    */   {
/* 48 */     this.classLoader = null;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public DefaultDeserializer(@Nullable ClassLoader classLoader)
/*    */   {
/* 58 */     this.classLoader = classLoader;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Object deserialize(InputStream inputStream)
/*    */     throws IOException
/*    */   {
/* 70 */     ObjectInputStream objectInputStream = new ConfigurableObjectInputStream(inputStream, this.classLoader);
/*    */     try {
/* 72 */       return objectInputStream.readObject();
/*    */     }
/*    */     catch (ClassNotFoundException ex) {
/* 75 */       throw new NestedIOException("Failed to deserialize object type", ex);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-core-5.3.12.jar!\org\springframework\core\serializer\DefaultDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */