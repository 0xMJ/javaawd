/*    */ package org.springframework.core.env;
/*    */ 
/*    */ import java.util.Map;
/*    */ import java.util.Properties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PropertiesPropertySource
/*    */   extends MapPropertySource
/*    */ {
/*    */   public PropertiesPropertySource(String name, Properties source)
/*    */   {
/* 40 */     super(name, source);
/*    */   }
/*    */   
/*    */   protected PropertiesPropertySource(String name, Map<String, Object> source) {
/* 44 */     super(name, source);
/*    */   }
/*    */   
/*    */   /* Error */
/*    */   public String[] getPropertyNames()
/*    */   {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: getfield 2	org/springframework/core/env/PropertiesPropertySource:source	Ljava/lang/Object;
/*    */     //   4: checkcast 3	java/util/Map
/*    */     //   7: dup
/*    */     //   8: astore_1
/*    */     //   9: monitorenter
/*    */     //   10: aload_0
/*    */     //   11: invokespecial 4	org/springframework/core/env/MapPropertySource:getPropertyNames	()[Ljava/lang/String;
/*    */     //   14: aload_1
/*    */     //   15: monitorexit
/*    */     //   16: areturn
/*    */     //   17: astore_2
/*    */     //   18: aload_1
/*    */     //   19: monitorexit
/*    */     //   20: aload_2
/*    */     //   21: athrow
/*    */     // Line number table:
/*    */     //   Java source line #50	-> byte code offset #0
/*    */     //   Java source line #51	-> byte code offset #10
/*    */     //   Java source line #52	-> byte code offset #17
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	signature
/*    */     //   0	22	0	this	PropertiesPropertySource
/*    */     //   8	11	1	Ljava/lang/Object;	Object
/*    */     //   17	4	2	localObject1	Object
/*    */     // Exception table:
/*    */     //   from	to	target	type
/*    */     //   10	16	17	finally
/*    */     //   17	20	17	finally
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-core-5.3.12.jar!\org\springframework\core\env\PropertiesPropertySource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */