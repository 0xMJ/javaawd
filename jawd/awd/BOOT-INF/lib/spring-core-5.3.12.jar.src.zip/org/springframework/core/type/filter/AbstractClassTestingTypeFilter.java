/*    */ package org.springframework.core.type.filter;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.springframework.core.type.ClassMetadata;
/*    */ import org.springframework.core.type.classreading.MetadataReader;
/*    */ import org.springframework.core.type.classreading.MetadataReaderFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractClassTestingTypeFilter
/*    */   implements TypeFilter
/*    */ {
/*    */   public final boolean match(MetadataReader metadataReader, MetadataReaderFactory metadataReaderFactory)
/*    */     throws IOException
/*    */   {
/* 42 */     return match(metadataReader.getClassMetadata());
/*    */   }
/*    */   
/*    */   protected abstract boolean match(ClassMetadata paramClassMetadata);
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-core-5.3.12.jar!\org\springframework\core\type\filter\AbstractClassTestingTypeFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */