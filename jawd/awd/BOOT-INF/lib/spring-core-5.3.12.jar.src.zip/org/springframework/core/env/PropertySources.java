/*    */ package org.springframework.core.env;
/*    */ 
/*    */ import java.util.stream.Stream;
/*    */ import java.util.stream.StreamSupport;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract interface PropertySources
/*    */   extends Iterable<PropertySource<?>>
/*    */ {
/*    */   public Stream<PropertySource<?>> stream()
/*    */   {
/* 39 */     return StreamSupport.stream(spliterator(), false);
/*    */   }
/*    */   
/*    */   public abstract boolean contains(String paramString);
/*    */   
/*    */   @Nullable
/*    */   public abstract PropertySource<?> get(String paramString);
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-core-5.3.12.jar!\org\springframework\core\env\PropertySources.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */