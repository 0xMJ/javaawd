/*    */ package org.springframework.core.serializer;
/*    */ 
/*    */ import java.io.ByteArrayInputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @FunctionalInterface
/*    */ public abstract interface Deserializer<T>
/*    */ {
/*    */   public abstract T deserialize(InputStream paramInputStream)
/*    */     throws IOException;
/*    */   
/*    */   public T deserializeFromByteArray(byte[] serialized)
/*    */     throws IOException
/*    */   {
/* 55 */     return (T)deserialize(new ByteArrayInputStream(serialized));
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-core-5.3.12.jar!\org\springframework\core\serializer\Deserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */