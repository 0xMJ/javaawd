/*     */ package org.springframework.core.io.buffer;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.CharBuffer;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.CharsetEncoder;
/*     */ import java.nio.charset.CoderResult;
/*     */ import java.nio.charset.CodingErrorAction;
/*     */ import java.util.function.IntPredicate;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract interface DataBuffer
/*     */ {
/*     */   public abstract DataBufferFactory factory();
/*     */   
/*     */   public abstract int indexOf(IntPredicate paramIntPredicate, int paramInt);
/*     */   
/*     */   public abstract int lastIndexOf(IntPredicate paramIntPredicate, int paramInt);
/*     */   
/*     */   public abstract int readableByteCount();
/*     */   
/*     */   public abstract int writableByteCount();
/*     */   
/*     */   public abstract int capacity();
/*     */   
/*     */   public abstract DataBuffer capacity(int paramInt);
/*     */   
/*     */   public DataBuffer ensureCapacity(int capacity)
/*     */   {
/* 126 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract int readPosition();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract DataBuffer readPosition(int paramInt);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract int writePosition();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract DataBuffer writePosition(int paramInt);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract byte getByte(int paramInt);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract byte read();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract DataBuffer read(byte[] paramArrayOfByte);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract DataBuffer read(byte[] paramArrayOfByte, int paramInt1, int paramInt2);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract DataBuffer write(byte paramByte);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract DataBuffer write(byte[] paramArrayOfByte);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract DataBuffer write(byte[] paramArrayOfByte, int paramInt1, int paramInt2);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract DataBuffer write(DataBuffer... paramVarArgs);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract DataBuffer write(ByteBuffer... paramVarArgs);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DataBuffer write(CharSequence charSequence, Charset charset)
/*     */   {
/* 247 */     Assert.notNull(charSequence, "CharSequence must not be null");
/* 248 */     Assert.notNull(charset, "Charset must not be null");
/* 249 */     if (charSequence.length() != 0)
/*     */     {
/*     */ 
/* 252 */       CharsetEncoder charsetEncoder = charset.newEncoder().onMalformedInput(CodingErrorAction.REPLACE).onUnmappableCharacter(CodingErrorAction.REPLACE);
/* 253 */       CharBuffer inBuffer = CharBuffer.wrap(charSequence);
/* 254 */       int estimatedSize = (int)(inBuffer.remaining() * charsetEncoder.averageBytesPerChar());
/*     */       
/* 256 */       ByteBuffer outBuffer = ensureCapacity(estimatedSize).asByteBuffer(writePosition(), writableByteCount());
/*     */       for (;;)
/*     */       {
/* 259 */         CoderResult cr = inBuffer.hasRemaining() ? charsetEncoder.encode(inBuffer, outBuffer, true) : CoderResult.UNDERFLOW;
/* 260 */         if (cr.isUnderflow()) {
/* 261 */           cr = charsetEncoder.flush(outBuffer);
/*     */         }
/* 263 */         if (cr.isUnderflow()) {
/*     */           break;
/*     */         }
/* 266 */         if (cr.isOverflow()) {
/* 267 */           writePosition(writePosition() + outBuffer.position());
/* 268 */           int maximumSize = (int)(inBuffer.remaining() * charsetEncoder.maxBytesPerChar());
/* 269 */           ensureCapacity(maximumSize);
/* 270 */           outBuffer = asByteBuffer(writePosition(), writableByteCount());
/*     */         }
/*     */       }
/* 273 */       writePosition(writePosition() + outBuffer.position());
/*     */     }
/* 275 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract DataBuffer slice(int paramInt1, int paramInt2);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DataBuffer retainedSlice(int index, int length)
/*     */   {
/* 306 */     return DataBufferUtils.retain(slice(index, length));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract ByteBuffer asByteBuffer();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract ByteBuffer asByteBuffer(int paramInt1, int paramInt2);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract InputStream asInputStream();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract InputStream asInputStream(boolean paramBoolean);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract OutputStream asOutputStream();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString(Charset charset)
/*     */   {
/* 366 */     Assert.notNull(charset, "Charset must not be null");
/* 367 */     return toString(readPosition(), readableByteCount(), charset);
/*     */   }
/*     */   
/*     */   public abstract String toString(int paramInt1, int paramInt2, Charset paramCharset);
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-core-5.3.12.jar!\org\springframework\core\io\buffer\DataBuffer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */