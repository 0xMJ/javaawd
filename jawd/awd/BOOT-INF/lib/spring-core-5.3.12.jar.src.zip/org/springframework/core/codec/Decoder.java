/*     */ package org.springframework.core.codec;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.CompletableFuture;
/*     */ import java.util.concurrent.ExecutionException;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.MimeType;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract interface Decoder<T>
/*     */ {
/*     */   public abstract boolean canDecode(ResolvableType paramResolvableType, @Nullable MimeType paramMimeType);
/*     */   
/*     */   public abstract Flux<T> decode(Publisher<DataBuffer> paramPublisher, ResolvableType paramResolvableType, @Nullable MimeType paramMimeType, @Nullable Map<String, Object> paramMap);
/*     */   
/*     */   public abstract Mono<T> decodeToMono(Publisher<DataBuffer> paramPublisher, ResolvableType paramResolvableType, @Nullable MimeType paramMimeType, @Nullable Map<String, Object> paramMap);
/*     */   
/*     */   @Nullable
/*     */   public T decode(DataBuffer buffer, ResolvableType targetType, @Nullable MimeType mimeType, @Nullable Map<String, Object> hints)
/*     */     throws DecodingException
/*     */   {
/*  97 */     CompletableFuture<T> future = decodeToMono(Mono.just(buffer), targetType, mimeType, hints).toFuture();
/*  98 */     Assert.state(future.isDone(), "DataBuffer decoding should have completed.");
/*     */     Throwable failure;
/*     */     try
/*     */     {
/* 102 */       return (T)future.get();
/*     */     }
/*     */     catch (ExecutionException ex) {
/* 105 */       failure = ex.getCause();
/*     */     } catch (InterruptedException ex) {
/*     */       Throwable failure;
/* 108 */       failure = ex;
/*     */     }
/*     */     
/* 111 */     throw ((failure instanceof CodecException) ? (CodecException)failure : new DecodingException("Failed to decode: " + failure.getMessage(), failure));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract List<MimeType> getDecodableMimeTypes();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<MimeType> getDecodableMimeTypes(ResolvableType targetType)
/*     */   {
/* 135 */     return canDecode(targetType, null) ? getDecodableMimeTypes() : Collections.emptyList();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-core-5.3.12.jar!\org\springframework\core\codec\Decoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */