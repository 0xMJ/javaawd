package org.springframework.core;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import org.springframework.lang.Nullable;

public abstract interface ParameterNameDiscoverer
{
  @Nullable
  public abstract String[] getParameterNames(Method paramMethod);
  
  @Nullable
  public abstract String[] getParameterNames(Constructor<?> paramConstructor);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-core-5.3.12.jar!\org\springframework\core\ParameterNameDiscoverer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */