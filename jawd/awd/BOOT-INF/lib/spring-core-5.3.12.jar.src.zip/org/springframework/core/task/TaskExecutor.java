package org.springframework.core.task;

import java.util.concurrent.Executor;

@FunctionalInterface
public abstract interface TaskExecutor
  extends Executor
{
  public abstract void execute(Runnable paramRunnable);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-core-5.3.12.jar!\org\springframework\core\task\TaskExecutor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */