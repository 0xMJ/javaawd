/*    */ package org.springframework.core.annotation;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @FunctionalInterface
/*    */ public abstract interface MergedAnnotationSelector<A extends Annotation>
/*    */ {
/*    */   public boolean isBestCandidate(MergedAnnotation<A> annotation)
/*    */   {
/* 40 */     return false;
/*    */   }
/*    */   
/*    */   public abstract MergedAnnotation<A> select(MergedAnnotation<A> paramMergedAnnotation1, MergedAnnotation<A> paramMergedAnnotation2);
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-core-5.3.12.jar!\org\springframework\core\annotation\MergedAnnotationSelector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */