package org.springframework.core;

public abstract interface Ordered
{
  public static final int HIGHEST_PRECEDENCE = Integer.MIN_VALUE;
  public static final int LOWEST_PRECEDENCE = Integer.MAX_VALUE;
  
  public abstract int getOrder();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-core-5.3.12.jar!\org\springframework\core\Ordered.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */