package org.springframework.core.io;

import org.springframework.lang.Nullable;

public abstract interface ResourceLoader
{
  public static final String CLASSPATH_URL_PREFIX = "classpath:";
  
  public abstract Resource getResource(String paramString);
  
  @Nullable
  public abstract ClassLoader getClassLoader();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-core-5.3.12.jar!\org\springframework\core\io\ResourceLoader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */