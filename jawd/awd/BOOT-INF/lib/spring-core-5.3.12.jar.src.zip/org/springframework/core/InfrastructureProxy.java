package org.springframework.core;

public abstract interface InfrastructureProxy
{
  public abstract Object getWrappedObject();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-core-5.3.12.jar!\org\springframework\core\InfrastructureProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */