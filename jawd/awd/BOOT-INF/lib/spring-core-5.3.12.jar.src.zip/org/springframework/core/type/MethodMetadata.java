package org.springframework.core.type;

public abstract interface MethodMetadata
  extends AnnotatedTypeMetadata
{
  public abstract String getMethodName();
  
  public abstract String getDeclaringClassName();
  
  public abstract String getReturnTypeName();
  
  public abstract boolean isAbstract();
  
  public abstract boolean isStatic();
  
  public abstract boolean isFinal();
  
  public abstract boolean isOverridable();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-core-5.3.12.jar!\org\springframework\core\type\MethodMetadata.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */