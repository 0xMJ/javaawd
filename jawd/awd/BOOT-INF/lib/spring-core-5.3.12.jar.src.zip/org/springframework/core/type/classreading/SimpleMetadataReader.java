/*    */ package org.springframework.core.type.classreading;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import org.springframework.asm.ClassReader;
/*    */ import org.springframework.core.NestedIOException;
/*    */ import org.springframework.core.io.Resource;
/*    */ import org.springframework.core.type.AnnotationMetadata;
/*    */ import org.springframework.core.type.ClassMetadata;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class SimpleMetadataReader
/*    */   implements MetadataReader
/*    */ {
/*    */   private static final int PARSING_OPTIONS = 7;
/*    */   private final Resource resource;
/*    */   private final AnnotationMetadata annotationMetadata;
/*    */   
/*    */   SimpleMetadataReader(Resource resource, @Nullable ClassLoader classLoader)
/*    */     throws IOException
/*    */   {
/* 48 */     SimpleAnnotationMetadataReadingVisitor visitor = new SimpleAnnotationMetadataReadingVisitor(classLoader);
/* 49 */     getClassReader(resource).accept(visitor, 7);
/* 50 */     this.resource = resource;
/* 51 */     this.annotationMetadata = visitor.getMetadata();
/*    */   }
/*    */   
/*    */   private static ClassReader getClassReader(Resource resource) throws IOException {
/* 55 */     InputStream is = resource.getInputStream();Throwable localThrowable3 = null;
/*    */     try {
/* 57 */       return new ClassReader(is);
/*    */     }
/*    */     catch (IllegalArgumentException ex) {
/* 60 */       throw new NestedIOException("ASM ClassReader failed to parse class file - probably due to a new Java class file version that isn't supported yet: " + resource, ex);
/*    */     }
/*    */     catch (Throwable localThrowable4)
/*    */     {
/* 55 */       localThrowable3 = localThrowable4;throw localThrowable4;
/*    */ 
/*    */ 
/*    */     }
/*    */     finally
/*    */     {
/*    */ 
/*    */ 
/* 63 */       if (is != null) if (localThrowable3 != null) try { is.close(); } catch (Throwable localThrowable2) { localThrowable3.addSuppressed(localThrowable2); } else is.close();
/*    */     }
/*    */   }
/*    */   
/*    */   public Resource getResource()
/*    */   {
/* 69 */     return this.resource;
/*    */   }
/*    */   
/*    */   public ClassMetadata getClassMetadata()
/*    */   {
/* 74 */     return this.annotationMetadata;
/*    */   }
/*    */   
/*    */   public AnnotationMetadata getAnnotationMetadata()
/*    */   {
/* 79 */     return this.annotationMetadata;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-core-5.3.12.jar!\org\springframework\core\type\classreading\SimpleMetadataReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */