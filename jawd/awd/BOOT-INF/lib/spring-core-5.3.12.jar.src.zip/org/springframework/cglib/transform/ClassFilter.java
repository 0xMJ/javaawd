package org.springframework.cglib.transform;

public abstract interface ClassFilter
{
  public abstract boolean accept(String paramString);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-core-5.3.12.jar!\org\springframework\cglib\transform\ClassFilter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */