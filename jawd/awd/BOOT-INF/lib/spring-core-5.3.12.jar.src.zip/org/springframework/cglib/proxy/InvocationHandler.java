package org.springframework.cglib.proxy;

import java.lang.reflect.Method;

public abstract interface InvocationHandler
  extends Callback
{
  public abstract Object invoke(Object paramObject, Method paramMethod, Object[] paramArrayOfObject)
    throws Throwable;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-core-5.3.12.jar!\org\springframework\cglib\proxy\InvocationHandler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */