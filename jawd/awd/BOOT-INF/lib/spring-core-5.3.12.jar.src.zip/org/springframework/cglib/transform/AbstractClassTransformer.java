/*    */ package org.springframework.cglib.transform;
/*    */ 
/*    */ import org.springframework.asm.ClassVisitor;
/*    */ import org.springframework.cglib.core.Constants;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractClassTransformer
/*    */   extends ClassTransformer
/*    */ {
/*    */   protected AbstractClassTransformer()
/*    */   {
/* 23 */     super(Constants.ASM_API);
/*    */   }
/*    */   
/*    */   public void setTarget(ClassVisitor target) {
/* 27 */     this.cv = target;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-core-5.3.12.jar!\org\springframework\cglib\transform\AbstractClassTransformer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */