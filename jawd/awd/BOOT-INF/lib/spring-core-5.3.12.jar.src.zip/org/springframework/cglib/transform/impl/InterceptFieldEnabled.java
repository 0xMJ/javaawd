package org.springframework.cglib.transform.impl;

public abstract interface InterceptFieldEnabled
{
  public abstract void setInterceptFieldCallback(InterceptFieldCallback paramInterceptFieldCallback);
  
  public abstract InterceptFieldCallback getInterceptFieldCallback();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-core-5.3.12.jar!\org\springframework\cglib\transform\impl\InterceptFieldEnabled.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */