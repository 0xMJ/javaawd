package org.springframework.cglib.transform;

public abstract interface MethodFilter
{
  public abstract boolean accept(int paramInt, String paramString1, String paramString2, String paramString3, String[] paramArrayOfString);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-core-5.3.12.jar!\org\springframework\cglib\transform\MethodFilter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */