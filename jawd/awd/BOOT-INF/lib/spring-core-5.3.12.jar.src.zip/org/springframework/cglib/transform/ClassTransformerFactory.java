package org.springframework.cglib.transform;

public abstract interface ClassTransformerFactory
{
  public abstract ClassTransformer newInstance();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-core-5.3.12.jar!\org\springframework\cglib\transform\ClassTransformerFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */