/*    */ package org.springframework.cglib.core;
/*    */ 
/*    */ import org.springframework.asm.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Local
/*    */ {
/*    */   private Type type;
/*    */   private int index;
/*    */   
/*    */   public Local(int index, Type type)
/*    */   {
/* 26 */     this.type = type;
/* 27 */     this.index = index;
/*    */   }
/*    */   
/*    */   public int getIndex() {
/* 31 */     return this.index;
/*    */   }
/*    */   
/*    */   public Type getType() {
/* 35 */     return this.type;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-core-5.3.12.jar!\org\springframework\cglib\core\Local.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */