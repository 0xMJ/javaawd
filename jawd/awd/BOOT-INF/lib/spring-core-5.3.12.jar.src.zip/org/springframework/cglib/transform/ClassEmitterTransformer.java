package org.springframework.cglib.transform;

import org.springframework.cglib.core.ClassEmitter;

public abstract class ClassEmitterTransformer
  extends ClassEmitter
{}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-core-5.3.12.jar!\org\springframework\cglib\transform\ClassEmitterTransformer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */