package org.springframework.cglib.proxy;

import java.lang.reflect.Method;

public abstract interface CallbackFilter
{
  public abstract int accept(Method paramMethod);
  
  public abstract boolean equals(Object paramObject);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-core-5.3.12.jar!\org\springframework\cglib\proxy\CallbackFilter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */