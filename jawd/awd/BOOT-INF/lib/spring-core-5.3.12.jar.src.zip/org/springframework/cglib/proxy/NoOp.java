/*    */ package org.springframework.cglib.proxy;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract interface NoOp
/*    */   extends Callback
/*    */ {
/* 27 */   public static final NoOp INSTANCE = new NoOp() {};
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-core-5.3.12.jar!\org\springframework\cglib\proxy\NoOp.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */