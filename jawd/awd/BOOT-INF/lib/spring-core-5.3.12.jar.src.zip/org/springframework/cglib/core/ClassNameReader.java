/*    */ package org.springframework.cglib.core;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.springframework.asm.ClassReader;
/*    */ import org.springframework.asm.ClassVisitor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClassNameReader
/*    */ {
/* 28 */   private static final EarlyExitException EARLY_EXIT = new EarlyExitException(null);
/*    */   
/*    */ 
/*    */   public static String getClassName(ClassReader r)
/*    */   {
/* 33 */     return getClassInfo(r)[0];
/*    */   }
/*    */   
/*    */   public static String[] getClassInfo(ClassReader r)
/*    */   {
/* 38 */     final List array = new ArrayList();
/*    */     try {
/* 40 */       r.accept(new ClassVisitor(Constants.ASM_API, null)
/*    */       {
/*    */ 
/*    */ 
/*    */         public void visit(int version, int access, String name, String signature, String superName, String[] interfaces)
/*    */         {
/*    */ 
/* 47 */           array.add(name.replace('/', '.'));
/* 48 */           if (superName != null) {
/* 49 */             array.add(superName.replace('/', '.'));
/*    */           }
/* 51 */           for (int i = 0; i < interfaces.length; i++) {
/* 52 */             array.add(interfaces[i].replace('/', '.'));
/*    */           }
/*    */           
/* 55 */           throw ClassNameReader.EARLY_EXIT; } }, 6);
/*    */     }
/*    */     catch (EarlyExitException localEarlyExitException) {}
/*    */     
/*    */ 
/* 60 */     return (String[])array.toArray(new String[0]);
/*    */   }
/*    */   
/*    */   private static class EarlyExitException
/*    */     extends RuntimeException
/*    */   {}
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-core-5.3.12.jar!\org\springframework\cglib\core\ClassNameReader.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */