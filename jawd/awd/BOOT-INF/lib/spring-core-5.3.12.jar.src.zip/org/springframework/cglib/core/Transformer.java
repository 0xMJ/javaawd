package org.springframework.cglib.core;

public abstract interface Transformer
{
  public abstract Object transform(Object paramObject);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-core-5.3.12.jar!\org\springframework\cglib\core\Transformer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */