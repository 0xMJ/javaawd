package org.springframework.cglib.proxy;

public abstract interface Factory
{
  public abstract Object newInstance(Callback paramCallback);
  
  public abstract Object newInstance(Callback[] paramArrayOfCallback);
  
  public abstract Object newInstance(Class[] paramArrayOfClass, Object[] paramArrayOfObject, Callback[] paramArrayOfCallback);
  
  public abstract Callback getCallback(int paramInt);
  
  public abstract void setCallback(int paramInt, Callback paramCallback);
  
  public abstract void setCallbacks(Callback[] paramArrayOfCallback);
  
  public abstract Callback[] getCallbacks();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-core-5.3.12.jar!\org\springframework\cglib\proxy\Factory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */