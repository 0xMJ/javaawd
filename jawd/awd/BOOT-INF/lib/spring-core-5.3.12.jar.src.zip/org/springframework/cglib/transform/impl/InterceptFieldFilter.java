package org.springframework.cglib.transform.impl;

import org.springframework.asm.Type;

public abstract interface InterceptFieldFilter
{
  public abstract boolean acceptRead(Type paramType, String paramString);
  
  public abstract boolean acceptWrite(Type paramType, String paramString);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-core-5.3.12.jar!\org\springframework\cglib\transform\impl\InterceptFieldFilter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */