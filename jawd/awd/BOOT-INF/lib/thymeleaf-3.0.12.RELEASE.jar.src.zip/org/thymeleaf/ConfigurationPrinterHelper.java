/*     */ package org.thymeleaf;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.thymeleaf.cache.ICacheManager;
/*     */ import org.thymeleaf.dialect.IDialect;
/*     */ import org.thymeleaf.dialect.IExecutionAttributeDialect;
/*     */ import org.thymeleaf.dialect.IExpressionObjectDialect;
/*     */ import org.thymeleaf.dialect.IPostProcessorDialect;
/*     */ import org.thymeleaf.dialect.IPreProcessorDialect;
/*     */ import org.thymeleaf.dialect.IProcessorDialect;
/*     */ import org.thymeleaf.expression.IExpressionObjectFactory;
/*     */ import org.thymeleaf.linkbuilder.ILinkBuilder;
/*     */ import org.thymeleaf.messageresolver.IMessageResolver;
/*     */ import org.thymeleaf.postprocessor.IPostProcessor;
/*     */ import org.thymeleaf.preprocessor.IPreProcessor;
/*     */ import org.thymeleaf.processor.IProcessor;
/*     */ import org.thymeleaf.processor.cdatasection.ICDATASectionProcessor;
/*     */ import org.thymeleaf.processor.comment.ICommentProcessor;
/*     */ import org.thymeleaf.processor.doctype.IDocTypeProcessor;
/*     */ import org.thymeleaf.processor.element.IElementModelProcessor;
/*     */ import org.thymeleaf.processor.element.IElementTagProcessor;
/*     */ import org.thymeleaf.processor.element.MatchingAttributeName;
/*     */ import org.thymeleaf.processor.element.MatchingElementName;
/*     */ import org.thymeleaf.processor.processinginstruction.IProcessingInstructionProcessor;
/*     */ import org.thymeleaf.processor.text.ITextProcessor;
/*     */ import org.thymeleaf.processor.xmldeclaration.IXMLDeclarationProcessor;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ import org.thymeleaf.templateresolver.ITemplateResolver;
/*     */ import org.thymeleaf.util.ProcessorComparators;
/*     */ import org.thymeleaf.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ConfigurationPrinterHelper
/*     */ {
/*  67 */   public static final String CONFIGURATION_LOGGER_NAME = TemplateEngine.class.getName() + ".CONFIG";
/*     */   
/*  69 */   private static final Logger configLogger = LoggerFactory.getLogger(CONFIGURATION_LOGGER_NAME);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static void printConfiguration(IEngineConfiguration configuration)
/*     */   {
/*  79 */     ConfigLogBuilder logBuilder = new ConfigLogBuilder();
/*     */     
/*  81 */     ICacheManager cacheManager = configuration.getCacheManager();
/*  82 */     Set<ITemplateResolver> templateResolvers = configuration.getTemplateResolvers();
/*  83 */     Set<IMessageResolver> messageResolvers = configuration.getMessageResolvers();
/*  84 */     Set<ILinkBuilder> linkBuilders = configuration.getLinkBuilders();
/*     */     
/*  86 */     logBuilder.line("Initializing Thymeleaf Template engine configuration...");
/*  87 */     logBuilder.line("[THYMELEAF] TEMPLATE ENGINE CONFIGURATION:");
/*  88 */     if (!StringUtils.isEmptyOrWhitespace(Thymeleaf.VERSION)) {
/*  89 */       if (!StringUtils.isEmptyOrWhitespace(Thymeleaf.BUILD_TIMESTAMP)) {
/*  90 */         logBuilder.line("[THYMELEAF] * Thymeleaf version: {} (built {})", Thymeleaf.VERSION, Thymeleaf.BUILD_TIMESTAMP);
/*     */       } else {
/*  92 */         logBuilder.line("[THYMELEAF] * Thymeleaf version: {}", Thymeleaf.VERSION);
/*     */       }
/*     */     }
/*  95 */     logBuilder.line("[THYMELEAF] * Cache Manager implementation: {}", cacheManager == null ? "[no caches]" : cacheManager.getClass().getName());
/*  96 */     logBuilder.line("[THYMELEAF] * Template resolvers:");
/*  97 */     for (ITemplateResolver templateResolver : templateResolvers) {
/*  98 */       if (templateResolver.getOrder() != null) {
/*  99 */         logBuilder.line("[THYMELEAF]     * [{}] {}", templateResolver.getOrder(), templateResolver.getName());
/*     */       } else {
/* 101 */         logBuilder.line("[THYMELEAF]     * {}", templateResolver.getName());
/*     */       }
/*     */     }
/* 104 */     logBuilder.line("[THYMELEAF] * Message resolvers:");
/* 105 */     for (IMessageResolver messageResolver : messageResolvers) {
/* 106 */       if (messageResolver.getOrder() != null) {
/* 107 */         logBuilder.line("[THYMELEAF]     * [{}] {}", messageResolver.getOrder(), messageResolver.getName());
/*     */       } else {
/* 109 */         logBuilder.line("[THYMELEAF]     * {}", messageResolver.getName());
/*     */       }
/*     */     }
/* 112 */     logBuilder.line("[THYMELEAF] * Link builders:");
/* 113 */     for (ILinkBuilder linkBuilder : linkBuilders) {
/* 114 */       if (linkBuilder.getOrder() != null) {
/* 115 */         logBuilder.line("[THYMELEAF]     * [{}] {}", linkBuilder.getOrder(), linkBuilder.getName());
/*     */       } else {
/* 117 */         logBuilder.line("[THYMELEAF]     * {}", linkBuilder.getName());
/*     */       }
/*     */     }
/*     */     
/* 121 */     Object dialectConfigurations = configuration.getDialectConfigurations();
/*     */     
/* 123 */     int dialectIndex = 1;
/* 124 */     Integer totalDialects = Integer.valueOf(((Set)dialectConfigurations).size());
/*     */     
/* 126 */     for (DialectConfiguration dialectConfiguration : (Set)dialectConfigurations)
/*     */     {
/* 128 */       IDialect dialect = dialectConfiguration.getDialect();
/*     */       
/* 130 */       if (totalDialects.intValue() > 1) {
/* 131 */         logBuilder.line("[THYMELEAF] * Dialect [{} of {}]: {} ({})", new Object[] { Integer.valueOf(dialectIndex), totalDialects, dialect.getName(), dialect.getClass().getName() });
/*     */       } else {
/* 133 */         logBuilder.line("[THYMELEAF] * Dialect: {} ({})", dialect.getName(), dialect.getClass().getName());
/*     */       }
/*     */       
/* 136 */       String dialectPrefix = null;
/* 137 */       if ((dialect instanceof IProcessorDialect)) {
/* 138 */         dialectPrefix = dialectConfiguration.isPrefixSpecified() ? dialectConfiguration.getPrefix() : ((IProcessorDialect)dialect).getPrefix();
/* 139 */         logBuilder.line("[THYMELEAF]     * Prefix: \"{}\"", dialectPrefix != null ? dialectPrefix : "(none)");
/*     */       }
/*     */       
/* 142 */       if (configLogger.isDebugEnabled()) {
/* 143 */         printDebugConfiguration(logBuilder, dialect, dialectPrefix);
/*     */       }
/*     */       
/* 146 */       dialectIndex++;
/*     */     }
/*     */     
/*     */ 
/* 150 */     logBuilder.end("[THYMELEAF] TEMPLATE ENGINE CONFIGURED OK");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 155 */     if (configLogger.isTraceEnabled()) {
/* 156 */       configLogger.trace(logBuilder.toString());
/* 157 */     } else if (configLogger.isDebugEnabled()) {
/* 158 */       configLogger.debug(logBuilder.toString());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void printDebugConfiguration(ConfigLogBuilder logBuilder, IDialect idialect, String dialectPrefix)
/*     */   {
/* 168 */     if ((idialect instanceof IProcessorDialect))
/*     */     {
/* 170 */       IProcessorDialect dialect = (IProcessorDialect)idialect;
/*     */       
/* 172 */       Set<IProcessor> processors = dialect.getProcessors(dialectPrefix);
/* 173 */       printProcessorsForTemplateMode(logBuilder, processors, TemplateMode.HTML);
/* 174 */       printProcessorsForTemplateMode(logBuilder, processors, TemplateMode.XML);
/* 175 */       printProcessorsForTemplateMode(logBuilder, processors, TemplateMode.TEXT);
/* 176 */       printProcessorsForTemplateMode(logBuilder, processors, TemplateMode.JAVASCRIPT);
/* 177 */       printProcessorsForTemplateMode(logBuilder, processors, TemplateMode.CSS);
/* 178 */       printProcessorsForTemplateMode(logBuilder, processors, TemplateMode.RAW);
/*     */     }
/*     */     
/*     */ 
/* 182 */     if ((idialect instanceof IPreProcessorDialect))
/*     */     {
/* 184 */       IPreProcessorDialect dialect = (IPreProcessorDialect)idialect;
/*     */       
/* 186 */       Set<IPreProcessor> preProcessors = dialect.getPreProcessors();
/* 187 */       printPreProcessorsForTemplateMode(logBuilder, preProcessors, TemplateMode.HTML);
/* 188 */       printPreProcessorsForTemplateMode(logBuilder, preProcessors, TemplateMode.XML);
/* 189 */       printPreProcessorsForTemplateMode(logBuilder, preProcessors, TemplateMode.TEXT);
/* 190 */       printPreProcessorsForTemplateMode(logBuilder, preProcessors, TemplateMode.JAVASCRIPT);
/* 191 */       printPreProcessorsForTemplateMode(logBuilder, preProcessors, TemplateMode.CSS);
/* 192 */       printPreProcessorsForTemplateMode(logBuilder, preProcessors, TemplateMode.RAW);
/*     */     }
/*     */     
/*     */ 
/* 196 */     if ((idialect instanceof IPostProcessorDialect))
/*     */     {
/* 198 */       IPostProcessorDialect dialect = (IPostProcessorDialect)idialect;
/*     */       
/* 200 */       Set<IPostProcessor> postProcessors = dialect.getPostProcessors();
/* 201 */       printPostProcessorsForTemplateMode(logBuilder, postProcessors, TemplateMode.HTML);
/* 202 */       printPostProcessorsForTemplateMode(logBuilder, postProcessors, TemplateMode.XML);
/* 203 */       printPostProcessorsForTemplateMode(logBuilder, postProcessors, TemplateMode.TEXT);
/* 204 */       printPostProcessorsForTemplateMode(logBuilder, postProcessors, TemplateMode.JAVASCRIPT);
/* 205 */       printPostProcessorsForTemplateMode(logBuilder, postProcessors, TemplateMode.CSS);
/* 206 */       printPostProcessorsForTemplateMode(logBuilder, postProcessors, TemplateMode.RAW);
/*     */     }
/*     */     
/*     */     Set<String> expressionObjectNames;
/* 210 */     if ((idialect instanceof IExpressionObjectDialect))
/*     */     {
/* 212 */       IExpressionObjectDialect dialect = (IExpressionObjectDialect)idialect;
/*     */       
/* 214 */       IExpressionObjectFactory expressionObjectFactory = dialect.getExpressionObjectFactory();
/* 215 */       if (expressionObjectFactory != null)
/*     */       {
/* 217 */         expressionObjectNames = expressionObjectFactory.getAllExpressionObjectNames();
/* 218 */         if ((expressionObjectNames != null) && (!expressionObjectNames.isEmpty())) {
/* 219 */           logBuilder.line("[THYMELEAF]     * Expression Objects:");
/* 220 */           for (String expressionObjectName : expressionObjectNames) {
/* 221 */             logBuilder.line("[THYMELEAF]         * #{}", new Object[] { expressionObjectName });
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 229 */     if ((idialect instanceof IExecutionAttributeDialect))
/*     */     {
/* 231 */       IExecutionAttributeDialect dialect = (IExecutionAttributeDialect)idialect;
/*     */       
/* 233 */       Map<String, Object> executionAttributes = dialect.getExecutionAttributes();
/* 234 */       if ((executionAttributes != null) && (!executionAttributes.isEmpty())) {
/* 235 */         logBuilder.line("[THYMELEAF]     * Execution Attributes:");
/* 236 */         for (Object executionAttributesEntry : executionAttributes.entrySet()) {
/* 237 */           String attrName = (String)((Map.Entry)executionAttributesEntry).getKey();
/*     */           
/* 239 */           String attrValue = ((Map.Entry)executionAttributesEntry).getValue() == null ? null : ((Map.Entry)executionAttributesEntry).getValue().toString();
/* 240 */           logBuilder.line("[THYMELEAF]         * \"{}\": {}", new Object[] { attrName, attrValue });
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void printProcessorsForTemplateMode(ConfigLogBuilder logBuilder, Set<IProcessor> processors, TemplateMode templateMode)
/*     */   {
/* 256 */     if ((processors == null) || (processors.isEmpty())) {
/* 257 */       return;
/*     */     }
/*     */     
/* 260 */     List<ICDATASectionProcessor> cdataSectionProcessors = new ArrayList();
/* 261 */     List<ICommentProcessor> commentProcessors = new ArrayList();
/* 262 */     List<IDocTypeProcessor> docTypeProcessors = new ArrayList();
/* 263 */     List<IElementTagProcessor> elementTagProcessors = new ArrayList();
/* 264 */     List<IElementModelProcessor> elementModelProcessors = new ArrayList();
/* 265 */     List<IProcessingInstructionProcessor> processingInstructionProcessors = new ArrayList();
/* 266 */     List<ITextProcessor> textProcessors = new ArrayList();
/* 267 */     List<IXMLDeclarationProcessor> xmlDeclarationProcessors = new ArrayList();
/*     */     
/* 269 */     boolean processorsForTemplateModeExist = false;
/* 270 */     for (IProcessor processor : processors)
/*     */     {
/* 272 */       if (templateMode.equals(processor.getTemplateMode()))
/*     */       {
/*     */ 
/* 275 */         processorsForTemplateModeExist = true;
/*     */         
/* 277 */         if ((processor instanceof ICDATASectionProcessor)) {
/* 278 */           cdataSectionProcessors.add((ICDATASectionProcessor)processor);
/* 279 */         } else if ((processor instanceof ICommentProcessor)) {
/* 280 */           commentProcessors.add((ICommentProcessor)processor);
/* 281 */         } else if ((processor instanceof IDocTypeProcessor)) {
/* 282 */           docTypeProcessors.add((IDocTypeProcessor)processor);
/* 283 */         } else if ((processor instanceof IElementTagProcessor)) {
/* 284 */           elementTagProcessors.add((IElementTagProcessor)processor);
/* 285 */         } else if ((processor instanceof IElementModelProcessor)) {
/* 286 */           elementModelProcessors.add((IElementModelProcessor)processor);
/* 287 */         } else if ((processor instanceof IProcessingInstructionProcessor)) {
/* 288 */           processingInstructionProcessors.add((IProcessingInstructionProcessor)processor);
/* 289 */         } else if ((processor instanceof ITextProcessor)) {
/* 290 */           textProcessors.add((ITextProcessor)processor);
/* 291 */         } else if ((processor instanceof IXMLDeclarationProcessor)) {
/* 292 */           xmlDeclarationProcessors.add((IXMLDeclarationProcessor)processor);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 297 */     if (!processorsForTemplateModeExist)
/*     */     {
/* 299 */       return;
/*     */     }
/*     */     
/* 302 */     logBuilder.line("[THYMELEAF]     * Processors for Template Mode: {}", templateMode);
/*     */     
/* 304 */     Collections.sort(cdataSectionProcessors, ProcessorComparators.PROCESSOR_COMPARATOR);
/* 305 */     Collections.sort(commentProcessors, ProcessorComparators.PROCESSOR_COMPARATOR);
/* 306 */     Collections.sort(docTypeProcessors, ProcessorComparators.PROCESSOR_COMPARATOR);
/* 307 */     Collections.sort(elementTagProcessors, ProcessorComparators.PROCESSOR_COMPARATOR);
/* 308 */     Collections.sort(elementModelProcessors, ProcessorComparators.PROCESSOR_COMPARATOR);
/* 309 */     Collections.sort(processingInstructionProcessors, ProcessorComparators.PROCESSOR_COMPARATOR);
/* 310 */     Collections.sort(textProcessors, ProcessorComparators.PROCESSOR_COMPARATOR);
/* 311 */     Collections.sort(xmlDeclarationProcessors, ProcessorComparators.PROCESSOR_COMPARATOR);
/*     */     
/* 313 */     if (!elementTagProcessors.isEmpty()) {
/* 314 */       logBuilder.line("[THYMELEAF]         * Element Tag Processors by [matching element and attribute name] [precedence]:");
/* 315 */       for (IElementTagProcessor processor : elementTagProcessors) {
/* 316 */         MatchingElementName matchingElementName = processor.getMatchingElementName();
/* 317 */         MatchingAttributeName matchingAttributeName = processor.getMatchingAttributeName();
/* 318 */         String elementName = matchingElementName == null ? "*" : matchingElementName.toString();
/* 319 */         String attributeName = matchingAttributeName == null ? "*" : matchingAttributeName.toString();
/* 320 */         logBuilder.line("[THYMELEAF]             * [{} {}] [{}]: {}", new Object[] { elementName, attributeName, 
/* 321 */           Integer.valueOf(processor.getPrecedence()), processor.getClass().getName() });
/*     */       }
/*     */     }
/* 324 */     if (!elementModelProcessors.isEmpty()) {
/* 325 */       logBuilder.line("[THYMELEAF]         * Element Model Processors by [matching element and attribute name] [precedence]:");
/* 326 */       for (IElementModelProcessor processor : elementModelProcessors) {
/* 327 */         MatchingElementName matchingElementName = processor.getMatchingElementName();
/* 328 */         MatchingAttributeName matchingAttributeName = processor.getMatchingAttributeName();
/* 329 */         String elementName = matchingElementName == null ? "*" : matchingElementName.toString();
/* 330 */         String attributeName = matchingAttributeName == null ? "*" : matchingAttributeName.toString();
/* 331 */         logBuilder.line("[THYMELEAF]             * [{} {}] [{}]: {}", new Object[] { elementName, attributeName, 
/* 332 */           Integer.valueOf(processor.getPrecedence()), processor.getClass().getName() });
/*     */       }
/*     */     }
/* 335 */     if (!textProcessors.isEmpty()) {
/* 336 */       logBuilder.line("[THYMELEAF]         * Text Processors by [precedence]:");
/* 337 */       for (ITextProcessor processor : textProcessors) {
/* 338 */         logBuilder.line("[THYMELEAF]             * [{}]: {}", new Object[] {
/* 339 */           Integer.valueOf(processor.getPrecedence()), processor.getClass().getName() });
/*     */       }
/*     */     }
/* 342 */     if (!docTypeProcessors.isEmpty()) {
/* 343 */       logBuilder.line("[THYMELEAF]         * DOCTYPE Processors by [precedence]:");
/* 344 */       for (IDocTypeProcessor processor : docTypeProcessors) {
/* 345 */         logBuilder.line("[THYMELEAF]             * [{}]: {}", new Object[] {
/* 346 */           Integer.valueOf(processor.getPrecedence()), processor.getClass().getName() });
/*     */       }
/*     */     }
/* 349 */     if (!cdataSectionProcessors.isEmpty()) {
/* 350 */       logBuilder.line("[THYMELEAF]         * CDATA Section Processors by [precedence]:");
/* 351 */       for (ICDATASectionProcessor processor : cdataSectionProcessors) {
/* 352 */         logBuilder.line("[THYMELEAF]             * [{}]: {}", new Object[] {
/* 353 */           Integer.valueOf(processor.getPrecedence()), processor.getClass().getName() });
/*     */       }
/*     */     }
/* 356 */     if (!commentProcessors.isEmpty()) {
/* 357 */       logBuilder.line("[THYMELEAF]         * Comment Processors by [precedence]:");
/* 358 */       for (ICommentProcessor processor : commentProcessors) {
/* 359 */         logBuilder.line("[THYMELEAF]             * [{}]: {}", new Object[] {
/* 360 */           Integer.valueOf(processor.getPrecedence()), processor.getClass().getName() });
/*     */       }
/*     */     }
/* 363 */     if (!xmlDeclarationProcessors.isEmpty()) {
/* 364 */       logBuilder.line("[THYMELEAF]         * XML Declaration Processors by [precedence]:");
/* 365 */       for (IXMLDeclarationProcessor processor : xmlDeclarationProcessors) {
/* 366 */         logBuilder.line("[THYMELEAF]             * [{}]: {}", new Object[] {
/* 367 */           Integer.valueOf(processor.getPrecedence()), processor.getClass().getName() });
/*     */       }
/*     */     }
/* 370 */     if (!processingInstructionProcessors.isEmpty()) {
/* 371 */       logBuilder.line("[THYMELEAF]         * Processing Instruction Processors by [precedence]:");
/* 372 */       for (IProcessingInstructionProcessor processor : processingInstructionProcessors) {
/* 373 */         logBuilder.line("[THYMELEAF]             * [{}]: {}", new Object[] {
/* 374 */           Integer.valueOf(processor.getPrecedence()), processor.getClass().getName() });
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void printPreProcessorsForTemplateMode(ConfigLogBuilder logBuilder, Set<IPreProcessor> preProcessors, TemplateMode templateMode)
/*     */   {
/* 385 */     if ((preProcessors == null) || (preProcessors.isEmpty())) {
/* 386 */       return;
/*     */     }
/*     */     
/* 389 */     List<IPreProcessor> preProcessorsForTemplateMode = new ArrayList();
/*     */     
/* 391 */     for (IPreProcessor preProcessor : preProcessors) {
/* 392 */       if (templateMode.equals(preProcessor.getTemplateMode()))
/*     */       {
/*     */ 
/* 395 */         preProcessorsForTemplateMode.add(preProcessor);
/*     */       }
/*     */     }
/* 398 */     if (preProcessorsForTemplateMode.isEmpty())
/*     */     {
/* 400 */       return;
/*     */     }
/*     */     
/* 403 */     Collections.sort(preProcessorsForTemplateMode, ProcessorComparators.PRE_PROCESSOR_COMPARATOR);
/*     */     
/* 405 */     logBuilder.line("[THYMELEAF]     * Pre-Processors for Template Mode: {} by [precedence]", templateMode);
/* 406 */     for (IPreProcessor preProcessor : preProcessorsForTemplateMode) {
/* 407 */       logBuilder.line("[THYMELEAF]             * [{}]: {}", new Object[] {
/* 408 */         Integer.valueOf(preProcessor.getPrecedence()), preProcessor.getClass().getName() });
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void printPostProcessorsForTemplateMode(ConfigLogBuilder logBuilder, Set<IPostProcessor> postProcessors, TemplateMode templateMode)
/*     */   {
/* 418 */     if ((postProcessors == null) || (postProcessors.isEmpty())) {
/* 419 */       return;
/*     */     }
/*     */     
/* 422 */     List<IPostProcessor> postProcessorsForTemplateMode = new ArrayList();
/*     */     
/* 424 */     for (IPostProcessor postProcessor : postProcessors) {
/* 425 */       if (templateMode.equals(postProcessor.getTemplateMode()))
/*     */       {
/*     */ 
/* 428 */         postProcessorsForTemplateMode.add(postProcessor);
/*     */       }
/*     */     }
/* 431 */     if (postProcessorsForTemplateMode.isEmpty())
/*     */     {
/* 433 */       return;
/*     */     }
/*     */     
/* 436 */     Collections.sort(postProcessorsForTemplateMode, ProcessorComparators.POST_PROCESSOR_COMPARATOR);
/*     */     
/* 438 */     logBuilder.line("[THYMELEAF]     * Post-Processors for Template Mode: {} by [precedence]", templateMode);
/* 439 */     for (IPostProcessor postProcessor : postProcessorsForTemplateMode) {
/* 440 */       logBuilder.line("[THYMELEAF]             * [{}]: {}", new Object[] {
/* 441 */         Integer.valueOf(postProcessor.getPrecedence()), postProcessor.getClass().getName() });
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static final class ConfigLogBuilder
/*     */   {
/*     */     private static final String PLACEHOLDER = "\\{\\}";
/*     */     
/*     */ 
/*     */     private final StringBuilder strBuilder;
/*     */     
/*     */ 
/*     */     protected ConfigLogBuilder()
/*     */     {
/* 457 */       this.strBuilder = new StringBuilder();
/*     */     }
/*     */     
/*     */     protected void end(String line) {
/* 461 */       this.strBuilder.append(line);
/*     */     }
/*     */     
/*     */     protected void line(String line) {
/* 465 */       this.strBuilder.append(line).append("\n");
/*     */     }
/*     */     
/*     */     protected void line(String line, Object p1) {
/* 469 */       this.strBuilder.append(replace(line, p1)).append("\n");
/*     */     }
/*     */     
/*     */     protected void line(String line, Object p1, Object p2) {
/* 473 */       this.strBuilder.append(replace(replace(line, p1), p2)).append("\n");
/*     */     }
/*     */     
/*     */     protected void line(String line, Object[] pArr) {
/* 477 */       String newLine = line;
/* 478 */       for (Object aPArr : pArr) {
/* 479 */         newLine = replace(newLine, aPArr);
/*     */       }
/* 481 */       this.strBuilder.append(newLine).append("\n");
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/* 486 */       return this.strBuilder.toString();
/*     */     }
/*     */     
/*     */     private String replace(String str, Object replacement) {
/* 490 */       return str.replaceFirst("\\{\\}", replacement == null ? "" : param(replacement));
/*     */     }
/*     */     
/*     */     private String param(Object p) {
/* 494 */       if (p == null) {
/* 495 */         return null;
/*     */       }
/* 497 */       return p.toString().replaceAll("\\$", "\\.");
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\ConfigurationPrinterHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */