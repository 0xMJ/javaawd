/*     */ package org.thymeleaf.messageresolver;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.thymeleaf.cache.ICacheEntryValidity;
/*     */ import org.thymeleaf.context.ITemplateContext;
/*     */ import org.thymeleaf.engine.TemplateData;
/*     */ import org.thymeleaf.templateresource.ITemplateResource;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardMessageResolver
/*     */   extends AbstractMessageResolver
/*     */ {
/* 152 */   private final ConcurrentHashMap<String, ConcurrentHashMap<Locale, Map<String, String>>> messagesByLocaleByTemplate = new ConcurrentHashMap(20, 0.9F, 2);
/*     */   
/* 154 */   private final ConcurrentHashMap<Class<?>, ConcurrentHashMap<Locale, Map<String, String>>> messagesByLocaleByOrigin = new ConcurrentHashMap(20, 0.9F, 2);
/*     */   
/*     */   private final Properties defaultMessages;
/*     */   
/*     */ 
/*     */   public StandardMessageResolver()
/*     */   {
/* 161 */     this.defaultMessages = new Properties();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final Properties getDefaultMessages()
/*     */   {
/* 176 */     return this.defaultMessages;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setDefaultMessages(Properties defaultMessages)
/*     */   {
/* 189 */     if (defaultMessages != null) {
/* 190 */       this.defaultMessages.putAll(defaultMessages);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void addDefaultMessage(String key, String value)
/*     */   {
/* 204 */     Validate.notNull(key, "Key for default message cannot be null");
/* 205 */     Validate.notNull(value, "Value for default message cannot be null");
/* 206 */     this.defaultMessages.put(key, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void clearDefaultMessages()
/*     */   {
/* 216 */     this.defaultMessages.clear();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final String resolveMessage(ITemplateContext context, Class<?> origin, String key, Object[] messageParameters)
/*     */   {
/* 227 */     return resolveMessage(context, origin, key, messageParameters, true, true, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final String resolveMessage(ITemplateContext context, Class<?> origin, String key, Object[] messageParameters, boolean performTemplateBasedResolution, boolean performOriginBasedResolution, boolean performDefaultBasedResolution)
/*     */   {
/* 236 */     Validate.notNull(context, "Context cannot be null");
/* 237 */     Validate.notNull(context.getLocale(), "Locale in context cannot be null");
/* 238 */     Validate.notNull(key, "Message key cannot be null");
/*     */     
/* 240 */     Locale locale = context.getLocale();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 250 */     if (performTemplateBasedResolution)
/*     */     {
/* 252 */       for (TemplateData templateData : context.getTemplateStack())
/*     */       {
/* 254 */         String template = templateData.getTemplate();
/* 255 */         ITemplateResource templateResource = templateData.getTemplateResource();
/* 256 */         boolean templateCacheable = templateData.getValidity().isCacheable();
/*     */         
/*     */ 
/*     */         Map<String, String> messagesForLocaleForTemplate;
/*     */         
/* 261 */         if (templateCacheable)
/*     */         {
/* 263 */           ConcurrentHashMap<Locale, Map<String, String>> messagesByLocaleForTemplate = (ConcurrentHashMap)this.messagesByLocaleByTemplate.get(template);
/* 264 */           if (messagesByLocaleForTemplate == null) {
/* 265 */             this.messagesByLocaleByTemplate.putIfAbsent(template, new ConcurrentHashMap(4));
/* 266 */             messagesByLocaleForTemplate = (ConcurrentHashMap)this.messagesByLocaleByTemplate.get(template);
/*     */           }
/*     */           
/* 269 */           Map<String, String> messagesForLocaleForTemplate = (Map)messagesByLocaleForTemplate.get(locale);
/* 270 */           if (messagesForLocaleForTemplate == null) {
/* 271 */             messagesForLocaleForTemplate = resolveMessagesForTemplate(template, templateResource, locale);
/* 272 */             if (messagesForLocaleForTemplate == null) {
/* 273 */               messagesForLocaleForTemplate = Collections.emptyMap();
/*     */             }
/* 275 */             messagesByLocaleForTemplate.putIfAbsent(locale, messagesForLocaleForTemplate);
/*     */             
/* 277 */             messagesForLocaleForTemplate = (Map)messagesByLocaleForTemplate.get(locale);
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/* 282 */           messagesForLocaleForTemplate = resolveMessagesForTemplate(template, templateResource, locale);
/* 283 */           if (messagesForLocaleForTemplate == null) {
/* 284 */             messagesForLocaleForTemplate = Collections.emptyMap();
/*     */           }
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 290 */         String message = (String)messagesForLocaleForTemplate.get(key);
/* 291 */         if (message != null) {
/* 292 */           return formatMessage(locale, message, messageParameters);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 305 */     if ((performOriginBasedResolution) && (origin != null))
/*     */     {
/* 307 */       Object messagesByLocaleForOrigin = (ConcurrentHashMap)this.messagesByLocaleByOrigin.get(origin);
/* 308 */       if (messagesByLocaleForOrigin == null) {
/* 309 */         this.messagesByLocaleByOrigin.putIfAbsent(origin, new ConcurrentHashMap(4));
/* 310 */         messagesByLocaleForOrigin = (ConcurrentHashMap)this.messagesByLocaleByOrigin.get(origin);
/*     */       }
/*     */       
/* 313 */       Map<String, String> messagesForLocaleForOrigin = (Map)((ConcurrentHashMap)messagesByLocaleForOrigin).get(locale);
/* 314 */       if (messagesForLocaleForOrigin == null) {
/* 315 */         messagesForLocaleForOrigin = resolveMessagesForOrigin(origin, locale);
/* 316 */         if (messagesForLocaleForOrigin == null) {
/* 317 */           messagesForLocaleForOrigin = Collections.emptyMap();
/*     */         }
/* 319 */         ((ConcurrentHashMap)messagesByLocaleForOrigin).putIfAbsent(locale, messagesForLocaleForOrigin);
/*     */         
/* 321 */         messagesForLocaleForOrigin = (Map)((ConcurrentHashMap)messagesByLocaleForOrigin).get(locale);
/*     */       }
/*     */       
/*     */ 
/* 325 */       String message = (String)messagesForLocaleForOrigin.get(key);
/* 326 */       if (message != null) {
/* 327 */         return formatMessage(locale, message, messageParameters);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 337 */     if ((performDefaultBasedResolution) && (this.defaultMessages != null))
/*     */     {
/* 339 */       String message = this.defaultMessages.getProperty(key);
/* 340 */       if (message != null) {
/* 341 */         return formatMessage(locale, message, messageParameters);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 350 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Map<String, String> resolveMessagesForTemplate(String template, ITemplateResource templateResource, Locale locale)
/*     */   {
/* 380 */     return StandardMessageResolutionUtils.resolveMessagesForTemplate(templateResource, locale);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Map<String, String> resolveMessagesForOrigin(Class<?> origin, Locale locale)
/*     */   {
/* 406 */     return StandardMessageResolutionUtils.resolveMessagesForOrigin(origin, locale);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String formatMessage(Locale locale, String message, Object[] messageParameters)
/*     */   {
/* 428 */     return StandardMessageResolutionUtils.formatMessage(locale, message, messageParameters);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String createAbsentMessageRepresentation(ITemplateContext context, Class<?> origin, String key, Object[] messageParameters)
/*     */   {
/* 436 */     Validate.notNull(key, "Message key cannot be null");
/* 437 */     if (context.getLocale() != null) {
/* 438 */       return "??" + key + "_" + context.getLocale().toString() + "??";
/*     */     }
/* 440 */     return "??" + key + "_??";
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\messageresolver\StandardMessageResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */