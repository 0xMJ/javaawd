/*     */ package org.thymeleaf.messageresolver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Properties;
/*     */ import org.thymeleaf.exceptions.TemplateInputException;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.templateresource.ITemplateResource;
/*     */ import org.thymeleaf.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class StandardMessageResolutionUtils
/*     */ {
/*  50 */   private static final Map<String, String> EMPTY_MESSAGES = ;
/*     */   private static final String PROPERTIES_FILE_EXTENSION = ".properties";
/*  52 */   private static final Object[] EMPTY_MESSAGE_PARAMETERS = new Object[0];
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static Map<String, String> resolveMessagesForTemplate(ITemplateResource templateResource, Locale locale)
/*     */   {
/*  59 */     String resourceBaseName = templateResource.getBaseName();
/*  60 */     if ((resourceBaseName == null) || (resourceBaseName.length() == 0))
/*     */     {
/*  62 */       return EMPTY_MESSAGES;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  69 */     List<String> messageResourceNames = computeMessageResourceNamesFromBase(resourceBaseName, locale);
/*     */     
/*     */ 
/*  72 */     Map<String, String> combinedMessages = null;
/*  73 */     for (String messageResourceName : messageResourceNames)
/*     */     {
/*     */       try
/*     */       {
/*  77 */         ITemplateResource messageResource = templateResource.relative(messageResourceName);
/*  78 */         Reader messageResourceReader = messageResource.reader();
/*  79 */         if (messageResourceReader != null)
/*     */         {
/*  81 */           Properties messageProperties = readMessagesResource(messageResourceReader);
/*  82 */           if ((messageProperties != null) && (!messageProperties.isEmpty()))
/*     */           {
/*  84 */             if (combinedMessages == null) {
/*  85 */               combinedMessages = new HashMap(20);
/*     */             }
/*     */             
/*  88 */             for (Map.Entry<Object, Object> propertyEntry : messageProperties.entrySet()) {
/*  89 */               combinedMessages.put((String)propertyEntry.getKey(), (String)propertyEntry.getValue());
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (IOException localIOException) {}
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 102 */     if (combinedMessages == null) {
/* 103 */       return EMPTY_MESSAGES;
/*     */     }
/*     */     
/* 106 */     return Collections.unmodifiableMap(combinedMessages);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static Map<String, String> resolveMessagesForOrigin(Class<?> origin, Locale locale)
/*     */   {
/* 117 */     Map<String, String> combinedMessages = new HashMap(20);
/*     */     
/* 119 */     Class<?> currentClass = origin;
/* 120 */     combinedMessages.putAll(resolveMessagesForSpecificClass(currentClass, locale));
/*     */     Map<String, String> messagesForCurrentClass;
/* 122 */     while (!currentClass.getSuperclass().equals(Object.class))
/*     */     {
/* 124 */       currentClass = currentClass.getSuperclass();
/* 125 */       messagesForCurrentClass = resolveMessagesForSpecificClass(currentClass, locale);
/* 126 */       for (String messageKey : messagesForCurrentClass.keySet()) {
/* 127 */         if (!combinedMessages.containsKey(messageKey)) {
/* 128 */           combinedMessages.put(messageKey, messagesForCurrentClass.get(messageKey));
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 134 */     return Collections.unmodifiableMap(combinedMessages);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Map<String, String> resolveMessagesForSpecificClass(Class<?> originClass, Locale locale)
/*     */   {
/* 144 */     ClassLoader originClassLoader = originClass.getClassLoader();
/* 145 */     String originClassName = originClass.getName();
/*     */     
/* 147 */     String resourceBaseName = StringUtils.replace(originClassName, ".", "/");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 153 */     List<String> messageResourceNames = computeMessageResourceNamesFromBase(resourceBaseName, locale);
/*     */     
/*     */ 
/* 156 */     Map<String, String> combinedMessages = null;
/* 157 */     for (String messageResourceName : messageResourceNames)
/*     */     {
/* 159 */       InputStream inputStream = originClassLoader.getResourceAsStream(messageResourceName);
/* 160 */       if (inputStream != null)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 165 */         InputStreamReader messageResourceReader = new InputStreamReader(inputStream);
/*     */         
/* 167 */         Properties messageProperties = readMessagesResource(messageResourceReader);
/* 168 */         if ((messageProperties != null) && (!messageProperties.isEmpty()))
/*     */         {
/* 170 */           if (combinedMessages == null) {
/* 171 */             combinedMessages = new HashMap(20);
/*     */           }
/*     */           
/* 174 */           for (Map.Entry<Object, Object> propertyEntry : messageProperties.entrySet()) {
/* 175 */             combinedMessages.put((String)propertyEntry.getKey(), (String)propertyEntry.getValue());
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 184 */     if (combinedMessages == null) {
/* 185 */       return EMPTY_MESSAGES;
/*     */     }
/*     */     
/* 188 */     return Collections.unmodifiableMap(combinedMessages);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static List<String> computeMessageResourceNamesFromBase(String resourceBaseName, Locale locale)
/*     */   {
/* 198 */     List<String> resourceNames = new ArrayList(5);
/*     */     
/* 200 */     if (StringUtils.isEmptyOrWhitespace(locale.getLanguage()))
/*     */     {
/* 202 */       throw new TemplateProcessingException("Locale \"" + locale.toString() + "\" cannot be used as it does not specify a language.");
/*     */     }
/*     */     
/*     */ 
/* 206 */     resourceNames.add(resourceBaseName + ".properties");
/* 207 */     resourceNames.add(resourceBaseName + "_" + locale.getLanguage() + ".properties");
/*     */     
/* 209 */     if (!StringUtils.isEmptyOrWhitespace(locale.getCountry())) {
/* 210 */       resourceNames.add(resourceBaseName + "_" + locale
/* 211 */         .getLanguage() + "_" + locale.getCountry() + ".properties");
/*     */     }
/*     */     
/* 214 */     if (!StringUtils.isEmptyOrWhitespace(locale.getVariant())) {
/* 215 */       resourceNames.add(resourceBaseName + "_" + locale
/* 216 */         .getLanguage() + "_" + locale.getCountry() + "-" + locale.getVariant() + ".properties");
/*     */     }
/*     */     
/* 219 */     return resourceNames;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Properties readMessagesResource(Reader propertiesReader)
/*     */   {
/* 227 */     if (propertiesReader == null) {
/* 228 */       return null;
/*     */     }
/* 230 */     properties = new Properties();
/*     */     
/*     */     try
/*     */     {
/* 234 */       properties.load(propertiesReader);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 244 */       return properties;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 236 */       throw new TemplateInputException("Exception loading messages file", e);
/*     */     } finally {
/*     */       try {
/* 239 */         propertiesReader.close();
/*     */       }
/*     */       catch (Throwable localThrowable1) {}
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static String formatMessage(Locale locale, String message, Object[] messageParameters)
/*     */   {
/* 250 */     if (message == null) {
/* 251 */       return null;
/*     */     }
/* 253 */     if (!isFormatCandidate(message)) {
/* 254 */       return message;
/*     */     }
/* 256 */     MessageFormat messageFormat = new MessageFormat(message, locale);
/* 257 */     return messageFormat.format(messageParameters != null ? messageParameters : EMPTY_MESSAGE_PARAMETERS);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean isFormatCandidate(String message)
/*     */   {
/* 267 */     int n = message.length();
/* 268 */     while (n-- != 0) {
/* 269 */       char c = message.charAt(n);
/* 270 */       if ((c == '}') || (c == '\'')) {
/* 271 */         return true;
/*     */       }
/*     */     }
/* 274 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\messageresolver\StandardMessageResolutionUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */