package org.thymeleaf.messageresolver;

import org.thymeleaf.context.ITemplateContext;

public abstract interface IMessageResolver
{
  public abstract String getName();
  
  public abstract Integer getOrder();
  
  public abstract String resolveMessage(ITemplateContext paramITemplateContext, Class<?> paramClass, String paramString, Object[] paramArrayOfObject);
  
  public abstract String createAbsentMessageRepresentation(ITemplateContext paramITemplateContext, Class<?> paramClass, String paramString, Object[] paramArrayOfObject);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\messageresolver\IMessageResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */