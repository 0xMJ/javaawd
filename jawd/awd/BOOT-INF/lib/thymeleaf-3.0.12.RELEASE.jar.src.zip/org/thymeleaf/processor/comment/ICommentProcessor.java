package org.thymeleaf.processor.comment;

import org.thymeleaf.context.ITemplateContext;
import org.thymeleaf.model.IComment;
import org.thymeleaf.processor.IProcessor;

public abstract interface ICommentProcessor
  extends IProcessor
{
  public abstract void process(ITemplateContext paramITemplateContext, IComment paramIComment, ICommentStructureHandler paramICommentStructureHandler);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\processor\comment\ICommentProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */