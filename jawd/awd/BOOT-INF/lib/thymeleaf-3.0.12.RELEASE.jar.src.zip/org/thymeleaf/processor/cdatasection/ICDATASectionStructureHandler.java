package org.thymeleaf.processor.cdatasection;

import org.thymeleaf.model.IModel;

public abstract interface ICDATASectionStructureHandler
{
  public abstract void reset();
  
  public abstract void setContent(CharSequence paramCharSequence);
  
  public abstract void replaceWith(IModel paramIModel, boolean paramBoolean);
  
  public abstract void removeCDATASection();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\processor\cdatasection\ICDATASectionStructureHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */