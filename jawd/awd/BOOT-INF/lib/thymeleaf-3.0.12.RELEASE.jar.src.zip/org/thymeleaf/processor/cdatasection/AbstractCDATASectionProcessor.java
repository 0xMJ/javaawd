/*    */ package org.thymeleaf.processor.cdatasection;
/*    */ 
/*    */ import org.thymeleaf.context.ITemplateContext;
/*    */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*    */ import org.thymeleaf.model.ICDATASection;
/*    */ import org.thymeleaf.processor.AbstractProcessor;
/*    */ import org.thymeleaf.templatemode.TemplateMode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractCDATASectionProcessor
/*    */   extends AbstractProcessor
/*    */   implements ICDATASectionProcessor
/*    */ {
/*    */   public AbstractCDATASectionProcessor(TemplateMode templateMode, int precedence)
/*    */   {
/* 47 */     super(templateMode, precedence);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public final void process(ITemplateContext context, ICDATASection cdataSection, ICDATASectionStructureHandler structureHandler)
/*    */   {
/*    */     try
/*    */     {
/* 57 */       doProcess(context, cdataSection, structureHandler);
/*    */     }
/*    */     catch (TemplateProcessingException e) {
/* 60 */       if (cdataSection.hasLocation()) {
/* 61 */         if (!e.hasTemplateName()) {
/* 62 */           e.setTemplateName(cdataSection.getTemplateName());
/*    */         }
/* 64 */         if (!e.hasLineAndCol()) {
/* 65 */           e.setLineAndCol(cdataSection.getLine(), cdataSection.getCol());
/*    */         }
/*    */       }
/* 68 */       throw e;
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/* 72 */       throw new TemplateProcessingException("Error during execution of processor '" + getClass().getName() + "'", cdataSection.getTemplateName(), cdataSection.getLine(), cdataSection.getCol(), e);
/*    */     }
/*    */   }
/*    */   
/*    */   protected abstract void doProcess(ITemplateContext paramITemplateContext, ICDATASection paramICDATASection, ICDATASectionStructureHandler paramICDATASectionStructureHandler);
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\processor\cdatasection\AbstractCDATASectionProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */