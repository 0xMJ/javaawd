package org.thymeleaf.processor.element;

import org.thymeleaf.engine.TemplateData;
import org.thymeleaf.inline.IInliner;

public abstract interface IElementModelStructureHandler
{
  public abstract void reset();
  
  public abstract void setLocalVariable(String paramString, Object paramObject);
  
  public abstract void removeLocalVariable(String paramString);
  
  public abstract void setSelectionTarget(Object paramObject);
  
  public abstract void setInliner(IInliner paramIInliner);
  
  public abstract void setTemplateData(TemplateData paramTemplateData);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\processor\element\IElementModelStructureHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */