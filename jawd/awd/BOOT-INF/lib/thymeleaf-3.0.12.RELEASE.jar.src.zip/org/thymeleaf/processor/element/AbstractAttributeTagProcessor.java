/*     */ package org.thymeleaf.processor.element;
/*     */ 
/*     */ import org.thymeleaf.context.ITemplateContext;
/*     */ import org.thymeleaf.engine.AttributeName;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.model.IAttribute;
/*     */ import org.thymeleaf.model.IProcessableElementTag;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ import org.thymeleaf.util.EscapedAttributeUtils;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractAttributeTagProcessor
/*     */   extends AbstractElementTagProcessor
/*     */ {
/*     */   private final boolean removeAttribute;
/*     */   
/*     */   protected AbstractAttributeTagProcessor(TemplateMode templateMode, String dialectPrefix, String elementName, boolean prefixElementName, String attributeName, boolean prefixAttributeName, int precedence, boolean removeAttribute)
/*     */   {
/*  53 */     super(templateMode, dialectPrefix, elementName, prefixElementName, attributeName, prefixAttributeName, precedence);
/*  54 */     Validate.notEmpty(attributeName, "Attribute name cannot be null or empty in Attribute Tag Processor");
/*  55 */     this.removeAttribute = removeAttribute;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final void doProcess(ITemplateContext context, IProcessableElementTag tag, IElementTagStructureHandler structureHandler)
/*     */   {
/*  66 */     AttributeName attributeName = null;
/*     */     try
/*     */     {
/*  69 */       attributeName = getMatchingAttributeName().getMatchingAttributeName();
/*     */       
/*     */ 
/*  72 */       String attributeValue = EscapedAttributeUtils.unescapeAttribute(context.getTemplateMode(), tag.getAttributeValue(attributeName));
/*     */       
/*  74 */       doProcess(context, tag, attributeName, attributeValue, structureHandler);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*  79 */       if (this.removeAttribute) {
/*  80 */         structureHandler.removeAttribute(attributeName);
/*     */       }
/*     */       
/*     */ 
/*     */     }
/*     */     catch (TemplateProcessingException e)
/*     */     {
/*  87 */       if (tag.hasLocation()) {
/*  88 */         if (!e.hasTemplateName()) {
/*  89 */           e.setTemplateName(tag.getTemplateName());
/*     */         }
/*  91 */         if (!e.hasLineAndCol()) {
/*  92 */           if (attributeName == null)
/*     */           {
/*  94 */             e.setLineAndCol(tag.getLine(), tag.getCol());
/*     */           } else {
/*  96 */             IAttribute attribute = tag.getAttribute(attributeName);
/*  97 */             if (attribute != null) {
/*  98 */               e.setLineAndCol(attribute.getLine(), attribute.getCol());
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/* 103 */       throw e;
/*     */     } catch (Exception e) {
/* 105 */       int line = tag.getLine();
/* 106 */       int col = tag.getCol();
/* 107 */       if (attributeName != null)
/*     */       {
/* 109 */         IAttribute attribute = tag.getAttribute(attributeName);
/* 110 */         if (attribute != null) {
/* 111 */           line = attribute.getLine();
/* 112 */           col = attribute.getCol();
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 117 */       throw new TemplateProcessingException("Error during execution of processor '" + getClass().getName() + "'", tag.getTemplateName(), line, col, e);
/*     */     }
/*     */   }
/*     */   
/*     */   protected abstract void doProcess(ITemplateContext paramITemplateContext, IProcessableElementTag paramIProcessableElementTag, AttributeName paramAttributeName, String paramString, IElementTagStructureHandler paramIElementTagStructureHandler);
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\processor\element\AbstractAttributeTagProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */