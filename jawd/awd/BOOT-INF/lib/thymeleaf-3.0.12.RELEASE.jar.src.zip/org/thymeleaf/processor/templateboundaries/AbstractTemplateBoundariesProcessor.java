/*     */ package org.thymeleaf.processor.templateboundaries;
/*     */ 
/*     */ import org.thymeleaf.context.ITemplateContext;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.model.ITemplateEnd;
/*     */ import org.thymeleaf.model.ITemplateStart;
/*     */ import org.thymeleaf.processor.AbstractProcessor;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractTemplateBoundariesProcessor
/*     */   extends AbstractProcessor
/*     */   implements ITemplateBoundariesProcessor
/*     */ {
/*     */   public AbstractTemplateBoundariesProcessor(TemplateMode templateMode, int precedence)
/*     */   {
/*  48 */     super(templateMode, precedence);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void processTemplateStart(ITemplateContext context, ITemplateStart templateStart, ITemplateBoundariesStructureHandler structureHandler)
/*     */   {
/*     */     try
/*     */     {
/*  61 */       doProcessTemplateStart(context, templateStart, structureHandler);
/*     */     }
/*     */     catch (TemplateProcessingException e) {
/*  64 */       if (templateStart.hasLocation()) {
/*  65 */         if (!e.hasTemplateName()) {
/*  66 */           e.setTemplateName(templateStart.getTemplateName());
/*     */         }
/*  68 */         if (!e.hasLineAndCol()) {
/*  69 */           e.setLineAndCol(templateStart.getLine(), templateStart.getCol());
/*     */         }
/*     */       }
/*  72 */       throw e;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*  76 */       throw new TemplateProcessingException("Error during execution of processor '" + getClass().getName() + "'", templateStart.getTemplateName(), templateStart.getLine(), templateStart.getCol(), e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void processTemplateEnd(ITemplateContext context, ITemplateEnd templateEnd, ITemplateBoundariesStructureHandler structureHandler)
/*     */   {
/*     */     try
/*     */     {
/*  89 */       doProcessTemplateEnd(context, templateEnd, structureHandler);
/*     */     }
/*     */     catch (TemplateProcessingException e) {
/*  92 */       if (templateEnd.hasLocation()) {
/*  93 */         if (!e.hasTemplateName()) {
/*  94 */           e.setTemplateName(templateEnd.getTemplateName());
/*     */         }
/*  96 */         if (!e.hasLineAndCol()) {
/*  97 */           e.setLineAndCol(templateEnd.getLine(), templateEnd.getCol());
/*     */         }
/*     */       }
/* 100 */       throw e;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 104 */       throw new TemplateProcessingException("Error during execution of processor '" + getClass().getName() + "'", templateEnd.getTemplateName(), templateEnd.getLine(), templateEnd.getCol(), e);
/*     */     }
/*     */   }
/*     */   
/*     */   public abstract void doProcessTemplateStart(ITemplateContext paramITemplateContext, ITemplateStart paramITemplateStart, ITemplateBoundariesStructureHandler paramITemplateBoundariesStructureHandler);
/*     */   
/*     */   public abstract void doProcessTemplateEnd(ITemplateContext paramITemplateContext, ITemplateEnd paramITemplateEnd, ITemplateBoundariesStructureHandler paramITemplateBoundariesStructureHandler);
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\processor\templateboundaries\AbstractTemplateBoundariesProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */