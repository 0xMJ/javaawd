package org.thymeleaf.processor.doctype;

import org.thymeleaf.context.ITemplateContext;
import org.thymeleaf.model.IDocType;
import org.thymeleaf.processor.IProcessor;

public abstract interface IDocTypeProcessor
  extends IProcessor
{
  public abstract void process(ITemplateContext paramITemplateContext, IDocType paramIDocType, IDocTypeStructureHandler paramIDocTypeStructureHandler);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\processor\doctype\IDocTypeProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */