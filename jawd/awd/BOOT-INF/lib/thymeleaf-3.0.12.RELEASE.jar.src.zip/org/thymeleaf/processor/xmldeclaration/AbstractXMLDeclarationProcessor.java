/*    */ package org.thymeleaf.processor.xmldeclaration;
/*    */ 
/*    */ import org.thymeleaf.context.ITemplateContext;
/*    */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*    */ import org.thymeleaf.model.IXMLDeclaration;
/*    */ import org.thymeleaf.processor.AbstractProcessor;
/*    */ import org.thymeleaf.templatemode.TemplateMode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractXMLDeclarationProcessor
/*    */   extends AbstractProcessor
/*    */   implements IXMLDeclarationProcessor
/*    */ {
/*    */   public AbstractXMLDeclarationProcessor(TemplateMode templateMode, int precedence)
/*    */   {
/* 47 */     super(templateMode, precedence);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public final void process(ITemplateContext context, IXMLDeclaration xmlDeclaration, IXMLDeclarationStructureHandler structureHandler)
/*    */   {
/*    */     try
/*    */     {
/* 57 */       doProcess(context, xmlDeclaration, structureHandler);
/*    */     }
/*    */     catch (TemplateProcessingException e) {
/* 60 */       if (xmlDeclaration.hasLocation()) {
/* 61 */         if (!e.hasTemplateName()) {
/* 62 */           e.setTemplateName(xmlDeclaration.getTemplateName());
/*    */         }
/* 64 */         if (!e.hasLineAndCol()) {
/* 65 */           e.setLineAndCol(xmlDeclaration.getLine(), xmlDeclaration.getCol());
/*    */         }
/*    */       }
/* 68 */       throw e;
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/* 72 */       throw new TemplateProcessingException("Error during execution of processor '" + getClass().getName() + "'", xmlDeclaration.getTemplateName(), xmlDeclaration.getLine(), xmlDeclaration.getCol(), e);
/*    */     }
/*    */   }
/*    */   
/*    */   protected abstract void doProcess(ITemplateContext paramITemplateContext, IXMLDeclaration paramIXMLDeclaration, IXMLDeclarationStructureHandler paramIXMLDeclarationStructureHandler);
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\processor\xmldeclaration\AbstractXMLDeclarationProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */