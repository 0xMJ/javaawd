package org.thymeleaf.processor.xmldeclaration;

import org.thymeleaf.context.ITemplateContext;
import org.thymeleaf.model.IXMLDeclaration;
import org.thymeleaf.processor.IProcessor;

public abstract interface IXMLDeclarationProcessor
  extends IProcessor
{
  public abstract void process(ITemplateContext paramITemplateContext, IXMLDeclaration paramIXMLDeclaration, IXMLDeclarationStructureHandler paramIXMLDeclarationStructureHandler);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\processor\xmldeclaration\IXMLDeclarationProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */