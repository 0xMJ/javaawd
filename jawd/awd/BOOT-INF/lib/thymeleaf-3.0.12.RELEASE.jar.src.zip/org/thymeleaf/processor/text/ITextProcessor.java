package org.thymeleaf.processor.text;

import org.thymeleaf.context.ITemplateContext;
import org.thymeleaf.model.IText;
import org.thymeleaf.processor.IProcessor;

public abstract interface ITextProcessor
  extends IProcessor
{
  public abstract void process(ITemplateContext paramITemplateContext, IText paramIText, ITextStructureHandler paramITextStructureHandler);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\processor\text\ITextProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */