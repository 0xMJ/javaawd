package org.thymeleaf.processor.element;

import org.thymeleaf.engine.AttributeName;
import org.thymeleaf.engine.TemplateData;
import org.thymeleaf.inline.IInliner;
import org.thymeleaf.model.AttributeValueQuotes;
import org.thymeleaf.model.IModel;

public abstract interface IElementTagStructureHandler
{
  public abstract void reset();
  
  public abstract void setLocalVariable(String paramString, Object paramObject);
  
  public abstract void removeLocalVariable(String paramString);
  
  public abstract void setAttribute(String paramString1, String paramString2);
  
  public abstract void setAttribute(String paramString1, String paramString2, AttributeValueQuotes paramAttributeValueQuotes);
  
  public abstract void replaceAttribute(AttributeName paramAttributeName, String paramString1, String paramString2);
  
  public abstract void replaceAttribute(AttributeName paramAttributeName, String paramString1, String paramString2, AttributeValueQuotes paramAttributeValueQuotes);
  
  public abstract void removeAttribute(String paramString);
  
  public abstract void removeAttribute(String paramString1, String paramString2);
  
  public abstract void removeAttribute(AttributeName paramAttributeName);
  
  public abstract void setSelectionTarget(Object paramObject);
  
  public abstract void setInliner(IInliner paramIInliner);
  
  public abstract void setTemplateData(TemplateData paramTemplateData);
  
  public abstract void setBody(CharSequence paramCharSequence, boolean paramBoolean);
  
  public abstract void setBody(IModel paramIModel, boolean paramBoolean);
  
  public abstract void insertBefore(IModel paramIModel);
  
  public abstract void insertImmediatelyAfter(IModel paramIModel, boolean paramBoolean);
  
  public abstract void replaceWith(CharSequence paramCharSequence, boolean paramBoolean);
  
  public abstract void replaceWith(IModel paramIModel, boolean paramBoolean);
  
  public abstract void removeElement();
  
  public abstract void removeTags();
  
  public abstract void removeBody();
  
  public abstract void removeAllButFirstChild();
  
  public abstract void iterateElement(String paramString1, String paramString2, Object paramObject);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\processor\element\IElementTagStructureHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */