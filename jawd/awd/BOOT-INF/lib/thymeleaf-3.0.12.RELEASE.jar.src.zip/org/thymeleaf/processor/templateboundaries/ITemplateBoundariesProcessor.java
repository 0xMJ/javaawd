package org.thymeleaf.processor.templateboundaries;

import org.thymeleaf.context.ITemplateContext;
import org.thymeleaf.model.ITemplateEnd;
import org.thymeleaf.model.ITemplateStart;
import org.thymeleaf.processor.IProcessor;

public abstract interface ITemplateBoundariesProcessor
  extends IProcessor
{
  public abstract void processTemplateStart(ITemplateContext paramITemplateContext, ITemplateStart paramITemplateStart, ITemplateBoundariesStructureHandler paramITemplateBoundariesStructureHandler);
  
  public abstract void processTemplateEnd(ITemplateContext paramITemplateContext, ITemplateEnd paramITemplateEnd, ITemplateBoundariesStructureHandler paramITemplateBoundariesStructureHandler);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\processor\templateboundaries\ITemplateBoundariesProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */