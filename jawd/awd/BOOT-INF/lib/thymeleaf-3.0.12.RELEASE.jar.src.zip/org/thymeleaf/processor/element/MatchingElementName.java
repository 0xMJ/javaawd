/*     */ package org.thymeleaf.processor.element;
/*     */ 
/*     */ import org.thymeleaf.engine.ElementName;
/*     */ import org.thymeleaf.engine.HTMLElementName;
/*     */ import org.thymeleaf.engine.TextElementName;
/*     */ import org.thymeleaf.engine.XMLElementName;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ import org.thymeleaf.util.TextUtils;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MatchingElementName
/*     */ {
/*     */   private final TemplateMode templateMode;
/*     */   private final ElementName matchingElementName;
/*     */   private final String matchingAllElementsWithPrefix;
/*     */   private final boolean matchingAllElements;
/*     */   
/*     */   public static MatchingElementName forElementName(TemplateMode templateMode, ElementName matchingElementName)
/*     */   {
/*  58 */     Validate.notNull(templateMode, "Template mode cannot be null");
/*  59 */     Validate.notNull(matchingElementName, "Matching element name cannot be null");
/*  60 */     if ((templateMode == TemplateMode.HTML) && (!(matchingElementName instanceof HTMLElementName)))
/*  61 */       throw new IllegalArgumentException("Element names for HTML template mode must be of class " + HTMLElementName.class.getName());
/*  62 */     if ((templateMode == TemplateMode.XML) && (!(matchingElementName instanceof XMLElementName)))
/*  63 */       throw new IllegalArgumentException("Element names for XML template mode must be of class " + XMLElementName.class.getName());
/*  64 */     if ((templateMode.isText()) && (!(matchingElementName instanceof TextElementName))) {
/*  65 */       throw new IllegalArgumentException("Element names for any text template modes must be of class " + TextElementName.class.getName());
/*     */     }
/*  67 */     return new MatchingElementName(templateMode, matchingElementName, null, false);
/*     */   }
/*     */   
/*     */   public static MatchingElementName forAllElementsWithPrefix(TemplateMode templateMode, String matchingAllElementsWithPrefix)
/*     */   {
/*  72 */     Validate.notNull(templateMode, "Template mode cannot be null");
/*     */     
/*  74 */     return new MatchingElementName(templateMode, null, matchingAllElementsWithPrefix, false);
/*     */   }
/*     */   
/*     */   public static MatchingElementName forAllElements(TemplateMode templateMode)
/*     */   {
/*  79 */     Validate.notNull(templateMode, "Template mode cannot be null");
/*  80 */     return new MatchingElementName(templateMode, null, null, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private MatchingElementName(TemplateMode templateMode, ElementName matchingElementName, String matchingAllElementsWithPrefix, boolean matchingAllElements)
/*     */   {
/*  89 */     this.templateMode = templateMode;
/*  90 */     this.matchingElementName = matchingElementName;
/*  91 */     this.matchingAllElementsWithPrefix = matchingAllElementsWithPrefix;
/*  92 */     this.matchingAllElements = matchingAllElements;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public TemplateMode getTemplateMode()
/*     */   {
/*  99 */     return this.templateMode;
/*     */   }
/*     */   
/*     */   public ElementName getMatchingElementName()
/*     */   {
/* 104 */     return this.matchingElementName;
/*     */   }
/*     */   
/*     */   public String getMatchingAllElementsWithPrefix()
/*     */   {
/* 109 */     return this.matchingAllElementsWithPrefix;
/*     */   }
/*     */   
/*     */   public boolean isMatchingAllElements()
/*     */   {
/* 114 */     return this.matchingAllElements;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean matches(ElementName elementName)
/*     */   {
/* 122 */     Validate.notNull(elementName, "Element name cannot be null");
/*     */     
/* 124 */     if (this.matchingElementName == null)
/*     */     {
/* 126 */       if ((this.templateMode == TemplateMode.HTML) && (!(elementName instanceof HTMLElementName)))
/* 127 */         return false;
/* 128 */       if ((this.templateMode == TemplateMode.XML) && (!(elementName instanceof XMLElementName)))
/* 129 */         return false;
/* 130 */       if ((this.templateMode.isText()) && (!(elementName instanceof TextElementName))) {
/* 131 */         return false;
/*     */       }
/*     */       
/* 134 */       if (this.matchingAllElements) {
/* 135 */         return true;
/*     */       }
/*     */       
/* 138 */       if (this.matchingAllElementsWithPrefix == null) {
/* 139 */         return elementName.getPrefix() == null;
/*     */       }
/*     */       
/* 142 */       String elementNamePrefix = elementName.getPrefix();
/* 143 */       if (elementNamePrefix == null) {
/* 144 */         return false;
/*     */       }
/*     */       
/* 147 */       return TextUtils.equals(this.templateMode.isCaseSensitive(), this.matchingAllElementsWithPrefix, elementNamePrefix);
/*     */     }
/*     */     
/*     */ 
/* 151 */     return this.matchingElementName.equals(elementName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 160 */     if (this.matchingElementName == null) {
/* 161 */       if (this.matchingAllElements) {
/* 162 */         return "*";
/*     */       }
/* 164 */       if (this.matchingAllElementsWithPrefix == null) {
/* 165 */         return "[^:]*";
/*     */       }
/* 167 */       return this.matchingAllElementsWithPrefix + ":*";
/*     */     }
/* 169 */     return this.matchingElementName.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\processor\element\MatchingElementName.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */