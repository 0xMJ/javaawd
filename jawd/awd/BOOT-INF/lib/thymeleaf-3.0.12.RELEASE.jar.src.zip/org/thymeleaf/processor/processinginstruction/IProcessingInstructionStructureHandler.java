package org.thymeleaf.processor.processinginstruction;

import org.thymeleaf.model.IModel;

public abstract interface IProcessingInstructionStructureHandler
{
  public abstract void reset();
  
  public abstract void setProcessingInstruction(String paramString1, String paramString2);
  
  public abstract void replaceWith(IModel paramIModel, boolean paramBoolean);
  
  public abstract void removeProcessingInstruction();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\processor\processinginstruction\IProcessingInstructionStructureHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */