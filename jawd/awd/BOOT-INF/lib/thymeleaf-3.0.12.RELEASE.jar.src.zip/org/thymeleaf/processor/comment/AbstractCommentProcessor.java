/*    */ package org.thymeleaf.processor.comment;
/*    */ 
/*    */ import org.thymeleaf.context.ITemplateContext;
/*    */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*    */ import org.thymeleaf.model.IComment;
/*    */ import org.thymeleaf.processor.AbstractProcessor;
/*    */ import org.thymeleaf.templatemode.TemplateMode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractCommentProcessor
/*    */   extends AbstractProcessor
/*    */   implements ICommentProcessor
/*    */ {
/*    */   public AbstractCommentProcessor(TemplateMode templateMode, int precedence)
/*    */   {
/* 47 */     super(templateMode, precedence);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public final void process(ITemplateContext context, IComment comment, ICommentStructureHandler structureHandler)
/*    */   {
/*    */     try
/*    */     {
/* 57 */       doProcess(context, comment, structureHandler);
/*    */     }
/*    */     catch (TemplateProcessingException e) {
/* 60 */       if (comment.hasLocation()) {
/* 61 */         if (!e.hasTemplateName()) {
/* 62 */           e.setTemplateName(comment.getTemplateName());
/*    */         }
/* 64 */         if (!e.hasLineAndCol()) {
/* 65 */           e.setLineAndCol(comment.getLine(), comment.getCol());
/*    */         }
/*    */       }
/* 68 */       throw e;
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/* 72 */       throw new TemplateProcessingException("Error during execution of processor '" + getClass().getName() + "'", comment.getTemplateName(), comment.getLine(), comment.getCol(), e);
/*    */     }
/*    */   }
/*    */   
/*    */   protected abstract void doProcess(ITemplateContext paramITemplateContext, IComment paramIComment, ICommentStructureHandler paramICommentStructureHandler);
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\processor\comment\AbstractCommentProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */