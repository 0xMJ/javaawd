/*    */ package org.thymeleaf.processor.processinginstruction;
/*    */ 
/*    */ import org.thymeleaf.context.ITemplateContext;
/*    */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*    */ import org.thymeleaf.model.IProcessingInstruction;
/*    */ import org.thymeleaf.processor.AbstractProcessor;
/*    */ import org.thymeleaf.templatemode.TemplateMode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractProcessingInstructionProcessor
/*    */   extends AbstractProcessor
/*    */   implements IProcessingInstructionProcessor
/*    */ {
/*    */   public AbstractProcessingInstructionProcessor(TemplateMode templateMode, int precedence)
/*    */   {
/* 47 */     super(templateMode, precedence);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public final void process(ITemplateContext context, IProcessingInstruction processingInstruction, IProcessingInstructionStructureHandler structureHandler)
/*    */   {
/*    */     try
/*    */     {
/* 57 */       doProcess(context, processingInstruction, structureHandler);
/*    */     }
/*    */     catch (TemplateProcessingException e) {
/* 60 */       if (processingInstruction.hasLocation()) {
/* 61 */         if (!e.hasTemplateName()) {
/* 62 */           e.setTemplateName(processingInstruction.getTemplateName());
/*    */         }
/* 64 */         if (!e.hasLineAndCol()) {
/* 65 */           e.setLineAndCol(processingInstruction.getLine(), processingInstruction.getCol());
/*    */         }
/*    */       }
/* 68 */       throw e;
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/* 72 */       throw new TemplateProcessingException("Error during execution of processor '" + getClass().getName() + "'", processingInstruction.getTemplateName(), processingInstruction.getLine(), processingInstruction.getCol(), e);
/*    */     }
/*    */   }
/*    */   
/*    */   protected abstract void doProcess(ITemplateContext paramITemplateContext, IProcessingInstruction paramIProcessingInstruction, IProcessingInstructionStructureHandler paramIProcessingInstructionStructureHandler);
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\processor\processinginstruction\AbstractProcessingInstructionProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */