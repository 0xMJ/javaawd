package org.thymeleaf.processor.xmldeclaration;

import org.thymeleaf.model.IModel;

public abstract interface IXMLDeclarationStructureHandler
{
  public abstract void reset();
  
  public abstract void setXMLDeclaration(String paramString1, String paramString2, String paramString3, String paramString4);
  
  public abstract void replaceWith(IModel paramIModel, boolean paramBoolean);
  
  public abstract void removeXMLDeclaration();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\processor\xmldeclaration\IXMLDeclarationStructureHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */