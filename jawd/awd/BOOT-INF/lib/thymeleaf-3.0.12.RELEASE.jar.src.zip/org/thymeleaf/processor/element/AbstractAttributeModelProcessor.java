/*     */ package org.thymeleaf.processor.element;
/*     */ 
/*     */ import org.thymeleaf.context.ITemplateContext;
/*     */ import org.thymeleaf.engine.AttributeName;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.model.IAttribute;
/*     */ import org.thymeleaf.model.IModel;
/*     */ import org.thymeleaf.model.IModelFactory;
/*     */ import org.thymeleaf.model.IProcessableElementTag;
/*     */ import org.thymeleaf.model.ITemplateEvent;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ import org.thymeleaf.util.EscapedAttributeUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractAttributeModelProcessor
/*     */   extends AbstractElementModelProcessor
/*     */ {
/*     */   private final boolean removeAttribute;
/*     */   
/*     */   protected AbstractAttributeModelProcessor(TemplateMode templateMode, String dialectPrefix, String elementName, boolean prefixElementName, String attributeName, boolean prefixAttributeName, int precedence, boolean removeAttribute)
/*     */   {
/*  55 */     super(templateMode, dialectPrefix, elementName, prefixElementName, attributeName, prefixAttributeName, precedence);
/*  56 */     this.removeAttribute = removeAttribute;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final void doProcess(ITemplateContext context, IModel model, IElementModelStructureHandler structureHandler)
/*     */   {
/*  67 */     AttributeName attributeName = null;
/*  68 */     IProcessableElementTag firstEvent = null;
/*     */     try
/*     */     {
/*  71 */       attributeName = getMatchingAttributeName().getMatchingAttributeName();
/*  72 */       firstEvent = (IProcessableElementTag)model.get(0);
/*     */       
/*     */ 
/*  75 */       String attributeValue = EscapedAttributeUtils.unescapeAttribute(context.getTemplateMode(), firstEvent.getAttributeValue(attributeName));
/*     */       
/*  77 */       doProcess(context, model, attributeName, attributeValue, structureHandler);
/*     */       
/*  79 */       if (this.removeAttribute) {
/*  80 */         int firstEventLocation = locateFirstEventInModel(model, firstEvent);
/*  81 */         if (firstEventLocation >= 0) {
/*  82 */           firstEvent = (IProcessableElementTag)model.get(firstEventLocation);
/*  83 */           IModelFactory modelFactory = context.getModelFactory();
/*  84 */           IProcessableElementTag newFirstEvent = modelFactory.removeAttribute(firstEvent, attributeName);
/*  85 */           if (newFirstEvent != firstEvent) {
/*  86 */             model.replace(firstEventLocation, newFirstEvent);
/*     */           }
/*     */           
/*     */         }
/*     */         
/*     */       }
/*     */     }
/*     */     catch (TemplateProcessingException e)
/*     */     {
/*  95 */       if (firstEvent != null)
/*     */       {
/*  97 */         String attributeTemplateName = firstEvent.getTemplateName();
/*  98 */         IAttribute attribute = firstEvent.getAttribute(attributeName);
/*  99 */         int attributeLine = attribute != null ? attribute.getLine() : -1;
/* 100 */         int attributeCol = attribute != null ? attribute.getCol() : -1;
/*     */         
/* 102 */         if ((attributeTemplateName != null) && 
/* 103 */           (!e.hasTemplateName())) {
/* 104 */           e.setTemplateName(attributeTemplateName);
/*     */         }
/*     */         
/* 107 */         if ((attributeLine != -1) && (attributeCol != -1) && 
/* 108 */           (!e.hasLineAndCol())) {
/* 109 */           e.setLineAndCol(attributeLine, attributeCol);
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 115 */       throw e;
/*     */ 
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */ 
/* 121 */       String attributeTemplateName = null;
/* 122 */       int attributeLine = -1;
/* 123 */       int attributeCol = -1;
/*     */       
/* 125 */       if (firstEvent != null)
/*     */       {
/* 127 */         attributeTemplateName = firstEvent.getTemplateName();
/* 128 */         IAttribute attribute = firstEvent.getAttribute(attributeName);
/* 129 */         attributeLine = attribute != null ? attribute.getLine() : -1;
/* 130 */         attributeCol = attribute != null ? attribute.getCol() : -1;
/*     */       }
/*     */       
/*     */ 
/* 134 */       throw new TemplateProcessingException("Error during execution of processor '" + getClass().getName() + "'", attributeTemplateName, attributeLine, attributeCol, e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract void doProcess(ITemplateContext paramITemplateContext, IModel paramIModel, AttributeName paramAttributeName, String paramString, IElementModelStructureHandler paramIElementModelStructureHandler);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static int locateFirstEventInModel(IModel model, ITemplateEvent firstEvent)
/*     */   {
/* 151 */     int modelSize = model.size();
/*     */     
/* 153 */     for (int i = 0; i < modelSize; i++)
/*     */     {
/* 155 */       if (firstEvent == model.get(i)) {
/* 156 */         return i;
/*     */       }
/*     */     }
/*     */     
/* 160 */     if ((modelSize > 0) && ((model.get(0) instanceof IProcessableElementTag))) {
/* 161 */       return 0;
/*     */     }
/* 163 */     return -1;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\processor\element\AbstractAttributeModelProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */