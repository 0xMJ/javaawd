package org.thymeleaf.processor.cdatasection;

import org.thymeleaf.context.ITemplateContext;
import org.thymeleaf.model.ICDATASection;
import org.thymeleaf.processor.IProcessor;

public abstract interface ICDATASectionProcessor
  extends IProcessor
{
  public abstract void process(ITemplateContext paramITemplateContext, ICDATASection paramICDATASection, ICDATASectionStructureHandler paramICDATASectionStructureHandler);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\processor\cdatasection\ICDATASectionProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */