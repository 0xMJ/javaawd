/*     */ package org.thymeleaf.processor.element;
/*     */ 
/*     */ import org.thymeleaf.context.ITemplateContext;
/*     */ import org.thymeleaf.engine.AttributeNames;
/*     */ import org.thymeleaf.engine.ElementNames;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.model.IProcessableElementTag;
/*     */ import org.thymeleaf.processor.AbstractProcessor;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractElementTagProcessor
/*     */   extends AbstractProcessor
/*     */   implements IElementTagProcessor
/*     */ {
/*     */   private final String dialectPrefix;
/*     */   private final MatchingElementName matchingElementName;
/*     */   private final MatchingAttributeName matchingAttributeName;
/*     */   
/*     */   public AbstractElementTagProcessor(TemplateMode templateMode, String dialectPrefix, String elementName, boolean prefixElementName, String attributeName, boolean prefixAttributeName, int precedence)
/*     */   {
/*  56 */     super(templateMode, precedence);
/*     */     
/*  58 */     this.dialectPrefix = dialectPrefix;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  63 */     this.matchingElementName = (elementName == null ? null : MatchingElementName.forElementName(templateMode, 
/*  64 */       ElementNames.forName(templateMode, prefixElementName ? this.dialectPrefix : null, elementName)));
/*     */     
/*     */ 
/*     */ 
/*  68 */     this.matchingAttributeName = (attributeName == null ? null : MatchingAttributeName.forAttributeName(templateMode, 
/*  69 */       AttributeNames.forName(templateMode, prefixAttributeName ? this.dialectPrefix : null, attributeName)));
/*     */   }
/*     */   
/*     */   protected final String getDialectPrefix()
/*     */   {
/*  74 */     return this.dialectPrefix;
/*     */   }
/*     */   
/*     */   public final MatchingElementName getMatchingElementName() {
/*  78 */     return this.matchingElementName;
/*     */   }
/*     */   
/*     */   public final MatchingAttributeName getMatchingAttributeName()
/*     */   {
/*  83 */     return this.matchingAttributeName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void process(ITemplateContext context, IProcessableElementTag tag, IElementTagStructureHandler structureHandler)
/*     */   {
/*     */     try
/*     */     {
/*  95 */       doProcess(context, tag, structureHandler);
/*     */     }
/*     */     catch (TemplateProcessingException e)
/*     */     {
/*  99 */       if (tag.hasLocation()) {
/* 100 */         if (!e.hasTemplateName()) {
/* 101 */           e.setTemplateName(tag.getTemplateName());
/*     */         }
/* 103 */         if (!e.hasLineAndCol()) {
/* 104 */           e.setLineAndCol(tag.getLine(), tag.getCol());
/*     */         }
/*     */       }
/* 107 */       throw e;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 111 */       throw new TemplateProcessingException("Error during execution of processor '" + getClass().getName() + "'", tag.getTemplateName(), tag.getLine(), tag.getCol(), e);
/*     */     }
/*     */   }
/*     */   
/*     */   protected abstract void doProcess(ITemplateContext paramITemplateContext, IProcessableElementTag paramIProcessableElementTag, IElementTagStructureHandler paramIElementTagStructureHandler);
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\processor\element\AbstractElementTagProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */