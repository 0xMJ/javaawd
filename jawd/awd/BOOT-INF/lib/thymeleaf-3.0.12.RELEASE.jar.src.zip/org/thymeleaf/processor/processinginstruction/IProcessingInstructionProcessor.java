package org.thymeleaf.processor.processinginstruction;

import org.thymeleaf.context.ITemplateContext;
import org.thymeleaf.model.IProcessingInstruction;
import org.thymeleaf.processor.IProcessor;

public abstract interface IProcessingInstructionProcessor
  extends IProcessor
{
  public abstract void process(ITemplateContext paramITemplateContext, IProcessingInstruction paramIProcessingInstruction, IProcessingInstructionStructureHandler paramIProcessingInstructionStructureHandler);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\processor\processinginstruction\IProcessingInstructionProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */