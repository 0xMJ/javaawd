/*     */ package org.thymeleaf.processor.element;
/*     */ 
/*     */ import org.thymeleaf.engine.AttributeName;
/*     */ import org.thymeleaf.engine.HTMLAttributeName;
/*     */ import org.thymeleaf.engine.TextAttributeName;
/*     */ import org.thymeleaf.engine.XMLAttributeName;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ import org.thymeleaf.util.TextUtils;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MatchingAttributeName
/*     */ {
/*     */   private final TemplateMode templateMode;
/*     */   private final AttributeName matchingAttributeName;
/*     */   private final String matchingAllAttributesWithPrefix;
/*     */   private final boolean matchingAllAttributes;
/*     */   
/*     */   public static MatchingAttributeName forAttributeName(TemplateMode templateMode, AttributeName matchingAttributeName)
/*     */   {
/*  59 */     Validate.notNull(templateMode, "Template mode cannot be null");
/*  60 */     Validate.notNull(matchingAttributeName, "Matching attribute name cannot be null");
/*  61 */     if ((templateMode == TemplateMode.HTML) && (!(matchingAttributeName instanceof HTMLAttributeName)))
/*  62 */       throw new IllegalArgumentException("Attribute names for HTML template mode must be of class " + HTMLAttributeName.class.getName());
/*  63 */     if ((templateMode == TemplateMode.XML) && (!(matchingAttributeName instanceof XMLAttributeName)))
/*  64 */       throw new IllegalArgumentException("Attribute names for XML template mode must be of class " + XMLAttributeName.class.getName());
/*  65 */     if ((templateMode.isText()) && (!(matchingAttributeName instanceof TextAttributeName))) {
/*  66 */       throw new IllegalArgumentException("Attribute names for any text template modes must be of class " + TextAttributeName.class.getName());
/*     */     }
/*  68 */     return new MatchingAttributeName(templateMode, matchingAttributeName, null, false);
/*     */   }
/*     */   
/*     */   public static MatchingAttributeName forAllAttributesWithPrefix(TemplateMode templateMode, String matchingAllAttributesWithPrefix)
/*     */   {
/*  73 */     Validate.notNull(templateMode, "Template mode cannot be null");
/*     */     
/*  75 */     return new MatchingAttributeName(templateMode, null, matchingAllAttributesWithPrefix, false);
/*     */   }
/*     */   
/*     */   public static MatchingAttributeName forAllAttributes(TemplateMode templateMode)
/*     */   {
/*  80 */     Validate.notNull(templateMode, "Template mode cannot be null");
/*  81 */     return new MatchingAttributeName(templateMode, null, null, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private MatchingAttributeName(TemplateMode templateMode, AttributeName matchingAttributeName, String matchingAllAttributesWithPrefix, boolean matchingAllAttributes)
/*     */   {
/*  90 */     this.templateMode = templateMode;
/*  91 */     this.matchingAttributeName = matchingAttributeName;
/*  92 */     this.matchingAllAttributesWithPrefix = matchingAllAttributesWithPrefix;
/*  93 */     this.matchingAllAttributes = matchingAllAttributes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public TemplateMode getTemplateMode()
/*     */   {
/* 100 */     return this.templateMode;
/*     */   }
/*     */   
/*     */   public AttributeName getMatchingAttributeName()
/*     */   {
/* 105 */     return this.matchingAttributeName;
/*     */   }
/*     */   
/*     */   public String getMatchingAllAttributesWithPrefix()
/*     */   {
/* 110 */     return this.matchingAllAttributesWithPrefix;
/*     */   }
/*     */   
/*     */   public boolean isMatchingAllAttributes()
/*     */   {
/* 115 */     return this.matchingAllAttributes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean matches(AttributeName attributeName)
/*     */   {
/* 123 */     Validate.notNull(attributeName, "Attributes name cannot be null");
/*     */     
/* 125 */     if (this.matchingAttributeName == null)
/*     */     {
/* 127 */       if ((this.templateMode == TemplateMode.HTML) && (!(attributeName instanceof HTMLAttributeName)))
/* 128 */         return false;
/* 129 */       if ((this.templateMode == TemplateMode.XML) && (!(attributeName instanceof XMLAttributeName)))
/* 130 */         return false;
/* 131 */       if ((this.templateMode.isText()) && (!(attributeName instanceof TextAttributeName))) {
/* 132 */         return false;
/*     */       }
/*     */       
/* 135 */       if (this.matchingAllAttributes) {
/* 136 */         return true;
/*     */       }
/*     */       
/* 139 */       if (this.matchingAllAttributesWithPrefix == null) {
/* 140 */         return attributeName.getPrefix() == null;
/*     */       }
/*     */       
/* 143 */       String attributeNamePrefix = attributeName.getPrefix();
/* 144 */       if (attributeNamePrefix == null) {
/* 145 */         return false;
/*     */       }
/*     */       
/* 148 */       return TextUtils.equals(this.templateMode.isCaseSensitive(), this.matchingAllAttributesWithPrefix, attributeNamePrefix);
/*     */     }
/*     */     
/*     */ 
/* 152 */     return this.matchingAttributeName.equals(attributeName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 160 */     if (this.matchingAttributeName == null) {
/* 161 */       if (this.matchingAllAttributes) {
/* 162 */         return "*";
/*     */       }
/* 164 */       if (this.matchingAllAttributesWithPrefix == null) {
/* 165 */         return "[^:]*";
/*     */       }
/* 167 */       return this.matchingAllAttributesWithPrefix + ":*";
/*     */     }
/* 169 */     return this.matchingAttributeName.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\processor\element\MatchingAttributeName.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */