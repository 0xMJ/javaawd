/*    */ package org.thymeleaf.processor;
/*    */ 
/*    */ import org.thymeleaf.templatemode.TemplateMode;
/*    */ import org.thymeleaf.util.Validate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractProcessor
/*    */   implements IProcessor
/*    */ {
/*    */   private final int precedence;
/*    */   private final TemplateMode templateMode;
/*    */   
/*    */   public AbstractProcessor(TemplateMode templateMode, int precedence)
/*    */   {
/* 50 */     Validate.notNull(templateMode, "Template mode cannot be null");
/*    */     
/* 52 */     this.templateMode = templateMode;
/* 53 */     this.precedence = precedence;
/*    */   }
/*    */   
/*    */ 
/*    */   public final TemplateMode getTemplateMode()
/*    */   {
/* 59 */     return this.templateMode;
/*    */   }
/*    */   
/*    */   public final int getPrecedence()
/*    */   {
/* 64 */     return this.precedence;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\processor\AbstractProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */