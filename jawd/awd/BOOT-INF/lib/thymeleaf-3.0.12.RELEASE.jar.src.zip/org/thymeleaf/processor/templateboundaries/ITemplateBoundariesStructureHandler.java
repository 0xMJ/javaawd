package org.thymeleaf.processor.templateboundaries;

import org.thymeleaf.inline.IInliner;
import org.thymeleaf.model.IModel;

public abstract interface ITemplateBoundariesStructureHandler
{
  public abstract void reset();
  
  public abstract void setLocalVariable(String paramString, Object paramObject);
  
  public abstract void removeLocalVariable(String paramString);
  
  public abstract void setSelectionTarget(Object paramObject);
  
  public abstract void setInliner(IInliner paramIInliner);
  
  public abstract void insert(String paramString, boolean paramBoolean);
  
  public abstract void insert(IModel paramIModel, boolean paramBoolean);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\processor\templateboundaries\ITemplateBoundariesStructureHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */