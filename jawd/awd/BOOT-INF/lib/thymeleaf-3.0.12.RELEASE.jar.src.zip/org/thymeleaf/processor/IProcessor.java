package org.thymeleaf.processor;

import org.thymeleaf.templatemode.TemplateMode;

public abstract interface IProcessor
{
  public abstract TemplateMode getTemplateMode();
  
  public abstract int getPrecedence();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\processor\IProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */