/*    */ package org.thymeleaf.inline;
/*    */ 
/*    */ import org.thymeleaf.context.ITemplateContext;
/*    */ import org.thymeleaf.model.ICDATASection;
/*    */ import org.thymeleaf.model.IComment;
/*    */ import org.thymeleaf.model.IText;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class NoOpInliner
/*    */   implements IInliner
/*    */ {
/* 35 */   public static final NoOpInliner INSTANCE = new NoOpInliner();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getName()
/*    */   {
/* 43 */     return "NOOP";
/*    */   }
/*    */   
/*    */   public CharSequence inline(ITemplateContext context, IText text)
/*    */   {
/* 48 */     return null;
/*    */   }
/*    */   
/*    */   public CharSequence inline(ITemplateContext context, ICDATASection cdataSection)
/*    */   {
/* 53 */     return null;
/*    */   }
/*    */   
/*    */   public CharSequence inline(ITemplateContext context, IComment comment)
/*    */   {
/* 58 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\inline\NoOpInliner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */