package org.thymeleaf;

import java.util.Map;
import java.util.Set;
import org.thymeleaf.cache.ICacheManager;
import org.thymeleaf.context.IEngineContextFactory;
import org.thymeleaf.dialect.IDialect;
import org.thymeleaf.engine.AttributeDefinitions;
import org.thymeleaf.engine.ElementDefinitions;
import org.thymeleaf.engine.TemplateManager;
import org.thymeleaf.expression.IExpressionObjectFactory;
import org.thymeleaf.linkbuilder.ILinkBuilder;
import org.thymeleaf.messageresolver.IMessageResolver;
import org.thymeleaf.model.IModelFactory;
import org.thymeleaf.postprocessor.IPostProcessor;
import org.thymeleaf.preprocessor.IPreProcessor;
import org.thymeleaf.processor.cdatasection.ICDATASectionProcessor;
import org.thymeleaf.processor.comment.ICommentProcessor;
import org.thymeleaf.processor.doctype.IDocTypeProcessor;
import org.thymeleaf.processor.element.IElementProcessor;
import org.thymeleaf.processor.processinginstruction.IProcessingInstructionProcessor;
import org.thymeleaf.processor.templateboundaries.ITemplateBoundariesProcessor;
import org.thymeleaf.processor.text.ITextProcessor;
import org.thymeleaf.processor.xmldeclaration.IXMLDeclarationProcessor;
import org.thymeleaf.templatemode.TemplateMode;
import org.thymeleaf.templateparser.markup.decoupled.IDecoupledTemplateLogicResolver;
import org.thymeleaf.templateresolver.ITemplateResolver;

public abstract interface IEngineConfiguration
{
  public abstract Set<ITemplateResolver> getTemplateResolvers();
  
  public abstract Set<IMessageResolver> getMessageResolvers();
  
  public abstract Set<ILinkBuilder> getLinkBuilders();
  
  public abstract ICacheManager getCacheManager();
  
  public abstract IEngineContextFactory getEngineContextFactory();
  
  public abstract IDecoupledTemplateLogicResolver getDecoupledTemplateLogicResolver();
  
  public abstract Set<DialectConfiguration> getDialectConfigurations();
  
  public abstract Set<IDialect> getDialects();
  
  public abstract boolean isStandardDialectPresent();
  
  public abstract String getStandardDialectPrefix();
  
  public abstract ElementDefinitions getElementDefinitions();
  
  public abstract AttributeDefinitions getAttributeDefinitions();
  
  public abstract Set<ITemplateBoundariesProcessor> getTemplateBoundariesProcessors(TemplateMode paramTemplateMode);
  
  public abstract Set<ICDATASectionProcessor> getCDATASectionProcessors(TemplateMode paramTemplateMode);
  
  public abstract Set<ICommentProcessor> getCommentProcessors(TemplateMode paramTemplateMode);
  
  public abstract Set<IDocTypeProcessor> getDocTypeProcessors(TemplateMode paramTemplateMode);
  
  public abstract Set<IElementProcessor> getElementProcessors(TemplateMode paramTemplateMode);
  
  public abstract Set<ITextProcessor> getTextProcessors(TemplateMode paramTemplateMode);
  
  public abstract Set<IProcessingInstructionProcessor> getProcessingInstructionProcessors(TemplateMode paramTemplateMode);
  
  public abstract Set<IXMLDeclarationProcessor> getXMLDeclarationProcessors(TemplateMode paramTemplateMode);
  
  public abstract Set<IPreProcessor> getPreProcessors(TemplateMode paramTemplateMode);
  
  public abstract Set<IPostProcessor> getPostProcessors(TemplateMode paramTemplateMode);
  
  public abstract Map<String, Object> getExecutionAttributes();
  
  public abstract IExpressionObjectFactory getExpressionObjectFactory();
  
  public abstract TemplateManager getTemplateManager();
  
  public abstract IModelFactory getModelFactory(TemplateMode paramTemplateMode);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\IEngineConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */