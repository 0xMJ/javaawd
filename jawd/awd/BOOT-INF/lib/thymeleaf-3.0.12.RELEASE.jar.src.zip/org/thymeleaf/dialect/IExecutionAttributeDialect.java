package org.thymeleaf.dialect;

import java.util.Map;

public abstract interface IExecutionAttributeDialect
  extends IDialect
{
  public abstract Map<String, Object> getExecutionAttributes();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\dialect\IExecutionAttributeDialect.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */