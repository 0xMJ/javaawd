/*    */ package org.thymeleaf.dialect;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractProcessorDialect
/*    */   extends AbstractDialect
/*    */   implements IProcessorDialect
/*    */ {
/*    */   private final String prefix;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private final int processorPrecedence;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected AbstractProcessorDialect(String name, String prefix, int processorPrecedence)
/*    */   {
/* 37 */     super(name);
/* 38 */     this.prefix = prefix;
/* 39 */     this.processorPrecedence = processorPrecedence;
/*    */   }
/*    */   
/*    */   public final String getPrefix()
/*    */   {
/* 44 */     return this.prefix;
/*    */   }
/*    */   
/*    */   public final int getDialectProcessorPrecedence()
/*    */   {
/* 49 */     return this.processorPrecedence;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\dialect\AbstractProcessorDialect.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */