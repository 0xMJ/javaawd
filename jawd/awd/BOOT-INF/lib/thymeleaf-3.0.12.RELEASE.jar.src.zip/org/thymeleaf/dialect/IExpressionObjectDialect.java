package org.thymeleaf.dialect;

import org.thymeleaf.expression.IExpressionObjectFactory;

public abstract interface IExpressionObjectDialect
  extends IDialect
{
  public abstract IExpressionObjectFactory getExpressionObjectFactory();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\dialect\IExpressionObjectDialect.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */