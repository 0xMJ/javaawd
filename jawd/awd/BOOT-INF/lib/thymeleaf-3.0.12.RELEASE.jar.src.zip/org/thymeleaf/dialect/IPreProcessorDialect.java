package org.thymeleaf.dialect;

import java.util.Set;
import org.thymeleaf.preprocessor.IPreProcessor;

public abstract interface IPreProcessorDialect
  extends IDialect
{
  public abstract int getDialectPreProcessorPrecedence();
  
  public abstract Set<IPreProcessor> getPreProcessors();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\dialect\IPreProcessorDialect.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */