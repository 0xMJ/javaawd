package org.thymeleaf.dialect;

import java.util.Set;
import org.thymeleaf.processor.IProcessor;

public abstract interface IProcessorDialect
  extends IDialect
{
  public abstract String getPrefix();
  
  public abstract int getDialectProcessorPrecedence();
  
  public abstract Set<IProcessor> getProcessors(String paramString);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\dialect\IProcessorDialect.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */