/*    */ package org.thymeleaf.dialect;
/*    */ 
/*    */ import org.thymeleaf.util.Validate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AbstractDialect
/*    */   implements IDialect
/*    */ {
/*    */   private final String name;
/*    */   
/*    */   protected AbstractDialect(String name)
/*    */   {
/* 47 */     Validate.notNull(name, "Dialect name cannot be null");
/* 48 */     this.name = name;
/*    */   }
/*    */   
/*    */   public final String getName() {
/* 52 */     return this.name;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\dialect\AbstractDialect.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */