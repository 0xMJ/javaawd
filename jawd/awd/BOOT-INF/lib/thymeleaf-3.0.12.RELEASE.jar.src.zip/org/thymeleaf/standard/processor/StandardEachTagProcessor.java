/*    */ package org.thymeleaf.standard.processor;
/*    */ 
/*    */ import org.thymeleaf.context.ITemplateContext;
/*    */ import org.thymeleaf.engine.AttributeName;
/*    */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*    */ import org.thymeleaf.model.IProcessableElementTag;
/*    */ import org.thymeleaf.processor.element.AbstractAttributeTagProcessor;
/*    */ import org.thymeleaf.processor.element.IElementTagStructureHandler;
/*    */ import org.thymeleaf.standard.expression.Each;
/*    */ import org.thymeleaf.standard.expression.EachUtils;
/*    */ import org.thymeleaf.standard.expression.IStandardExpression;
/*    */ import org.thymeleaf.templatemode.TemplateMode;
/*    */ import org.thymeleaf.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class StandardEachTagProcessor
/*    */   extends AbstractAttributeTagProcessor
/*    */ {
/*    */   public static final int PRECEDENCE = 200;
/*    */   public static final String ATTR_NAME = "each";
/*    */   
/*    */   public StandardEachTagProcessor(TemplateMode templateMode, String dialectPrefix)
/*    */   {
/* 47 */     super(templateMode, dialectPrefix, null, false, "each", true, 200, true);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected void doProcess(ITemplateContext context, IProcessableElementTag tag, AttributeName attributeName, String attributeValue, IElementTagStructureHandler structureHandler)
/*    */   {
/* 59 */     Each each = EachUtils.parseEach(context, attributeValue);
/*    */     
/* 61 */     IStandardExpression iterVarExpr = each.getIterVar();
/* 62 */     Object iterVarValue = iterVarExpr.execute(context);
/*    */     
/* 64 */     IStandardExpression statusVarExpr = each.getStatusVar();
/*    */     Object statusVarValue;
/* 66 */     Object statusVarValue; if (statusVarExpr != null) {
/* 67 */       statusVarValue = statusVarExpr.execute(context);
/*    */     } else {
/* 69 */       statusVarValue = null;
/*    */     }
/*    */     
/* 72 */     IStandardExpression iterableExpr = each.getIterable();
/* 73 */     Object iteratedValue = iterableExpr.execute(context);
/*    */     
/* 75 */     String iterVarName = iterVarValue == null ? null : iterVarValue.toString();
/* 76 */     if (StringUtils.isEmptyOrWhitespace(iterVarName)) {
/* 77 */       throw new TemplateProcessingException("Iteration variable name expression evaluated as null: \"" + iterVarExpr + "\"");
/*    */     }
/*    */     
/*    */ 
/* 81 */     String statusVarName = statusVarValue == null ? null : statusVarValue.toString();
/* 82 */     if ((statusVarExpr != null) && (StringUtils.isEmptyOrWhitespace(statusVarName))) {
/* 83 */       throw new TemplateProcessingException("Status variable name expression evaluated as null or empty: \"" + statusVarExpr + "\"");
/*    */     }
/*    */     
/*    */ 
/* 87 */     structureHandler.iterateElement(iterVarName, statusVarName, iteratedValue);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\processor\StandardEachTagProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */