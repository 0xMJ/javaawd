/*    */ package org.thymeleaf.standard.inline;
/*    */ 
/*    */ import org.thymeleaf.IEngineConfiguration;
/*    */ import org.thymeleaf.templatemode.TemplateMode;
/*    */ import org.unbescape.html.HtmlEscape;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class StandardTextInliner
/*    */   extends AbstractStandardInliner
/*    */ {
/*    */   public StandardTextInliner(IEngineConfiguration configuration)
/*    */   {
/* 36 */     super(configuration, TemplateMode.TEXT);
/*    */   }
/*    */   
/*    */ 
/*    */   protected String produceEscapedOutput(Object input)
/*    */   {
/* 42 */     if (input == null) {
/* 43 */       return "";
/*    */     }
/* 45 */     return HtmlEscape.escapeHtml4Xml(input.toString());
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\inline\StandardTextInliner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */