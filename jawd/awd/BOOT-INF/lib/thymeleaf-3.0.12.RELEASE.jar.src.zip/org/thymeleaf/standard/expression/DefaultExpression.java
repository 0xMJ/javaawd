/*     */ package org.thymeleaf.standard.expression;
/*     */ 
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.thymeleaf.TemplateEngine;
/*     */ import org.thymeleaf.context.IExpressionContext;
/*     */ import org.thymeleaf.util.StringUtils;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DefaultExpression
/*     */   extends ComplexExpression
/*     */ {
/*  47 */   private static final Logger logger = LoggerFactory.getLogger(DefaultExpression.class);
/*     */   
/*     */ 
/*     */   private static final long serialVersionUID = 1830867943963082362L;
/*     */   
/*     */ 
/*     */   private static final String OPERATOR = "?:";
/*     */   
/*  55 */   static final String[] OPERATORS = { String.valueOf("?:") };
/*     */   
/*     */   private final Expression queriedExpression;
/*     */   
/*     */   private final Expression defaultExpression;
/*     */   
/*     */ 
/*     */   public DefaultExpression(Expression queriedExpression, Expression defaultExpression)
/*     */   {
/*  64 */     Validate.notNull(queriedExpression, "Queried expression cannot be null");
/*  65 */     Validate.notNull(defaultExpression, "Default expression cannot be null");
/*  66 */     this.queriedExpression = queriedExpression;
/*  67 */     this.defaultExpression = defaultExpression;
/*     */   }
/*     */   
/*     */   public Expression getQueriedExpression() {
/*  71 */     return this.queriedExpression;
/*     */   }
/*     */   
/*     */   public Expression getDefaultExpression() {
/*  75 */     return this.defaultExpression;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getStringRepresentation()
/*     */   {
/*  81 */     StringBuilder sb = new StringBuilder();
/*  82 */     if ((this.queriedExpression instanceof ComplexExpression)) {
/*  83 */       sb.append('(');
/*  84 */       sb.append(this.queriedExpression);
/*  85 */       sb.append(')');
/*     */     } else {
/*  87 */       sb.append(this.queriedExpression);
/*     */     }
/*  89 */     sb.append(' ');
/*  90 */     sb.append("?:");
/*  91 */     sb.append(' ');
/*  92 */     if ((this.defaultExpression instanceof ComplexExpression)) {
/*  93 */       sb.append('(');
/*  94 */       sb.append(this.defaultExpression);
/*  95 */       sb.append(')');
/*     */     } else {
/*  97 */       sb.append(this.defaultExpression);
/*     */     }
/*  99 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static ExpressionParsingState composeDefaultExpression(ExpressionParsingState state, int nodeIndex)
/*     */   {
/* 111 */     String input = ((ExpressionParsingNode)state.get(nodeIndex)).getInput();
/*     */     
/* 113 */     if (StringUtils.isEmptyOrWhitespace(input)) {
/* 114 */       return null;
/*     */     }
/*     */     
/*     */ 
/* 118 */     int defaultOperatorPos = input.indexOf("?:");
/* 119 */     if (defaultOperatorPos == -1) {
/* 120 */       return state;
/*     */     }
/*     */     
/* 123 */     String queriedStr = input.substring(0, defaultOperatorPos);
/* 124 */     String defaultStr = input.substring(defaultOperatorPos + 2);
/*     */     
/* 126 */     if (defaultStr.contains("?:"))
/*     */     {
/* 128 */       return null;
/*     */     }
/*     */     
/*     */ 
/* 132 */     Expression queriedExpr = ExpressionParsingUtil.parseAndCompose(state, queriedStr);
/* 133 */     if (queriedExpr == null) {
/* 134 */       return null;
/*     */     }
/*     */     
/* 137 */     Expression defaultExpr = ExpressionParsingUtil.parseAndCompose(state, defaultStr);
/* 138 */     if (defaultExpr == null) {
/* 139 */       return null;
/*     */     }
/*     */     
/*     */ 
/* 143 */     DefaultExpression defaultExpressionResult = new DefaultExpression(queriedExpr, defaultExpr);
/* 144 */     state.setNode(nodeIndex, defaultExpressionResult);
/*     */     
/* 146 */     return state;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static Object executeDefault(IExpressionContext context, DefaultExpression expression, StandardExpressionExecutionContext expContext)
/*     */   {
/* 157 */     if (logger.isTraceEnabled()) {
/* 158 */       logger.trace("[THYMELEAF][{}] Evaluating default expression: \"{}\"", TemplateEngine.threadIndex(), expression.getStringRepresentation());
/*     */     }
/*     */     
/*     */ 
/* 162 */     Object queriedValue = expression.getQueriedExpression().execute(context, expContext);
/*     */     
/* 164 */     if (queriedValue == null) {
/* 165 */       return expression.getDefaultExpression().execute(context, expContext);
/*     */     }
/* 167 */     return queriedValue;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\expression\DefaultExpression.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */