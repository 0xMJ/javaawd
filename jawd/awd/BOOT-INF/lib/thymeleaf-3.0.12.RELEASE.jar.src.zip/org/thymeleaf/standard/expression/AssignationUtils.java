/*     */ package org.thymeleaf.standard.expression;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.thymeleaf.IEngineConfiguration;
/*     */ import org.thymeleaf.context.IExpressionContext;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.util.StringUtils;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AssignationUtils
/*     */ {
/*     */   public static AssignationSequence parseAssignationSequence(IExpressionContext context, String input, boolean allowParametersWithoutValue)
/*     */   {
/*  48 */     Validate.notNull(context, "Context cannot be null");
/*  49 */     Validate.notNull(input, "Input cannot be null");
/*     */     
/*     */ 
/*  52 */     String preprocessedInput = StandardExpressionPreprocessor.preprocess(context, input);
/*     */     
/*  54 */     IEngineConfiguration configuration = context.getConfiguration();
/*     */     
/*  56 */     if (configuration != null)
/*     */     {
/*  58 */       AssignationSequence cachedAssignationSequence = ExpressionCache.getAssignationSequenceFromCache(configuration, preprocessedInput);
/*  59 */       if (cachedAssignationSequence != null) {
/*  60 */         return cachedAssignationSequence;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*  65 */     AssignationSequence assignationSequence = internalParseAssignationSequence(preprocessedInput.trim(), allowParametersWithoutValue);
/*     */     
/*  67 */     if (assignationSequence == null) {
/*  68 */       throw new TemplateProcessingException("Could not parse as assignation sequence: \"" + input + "\"");
/*     */     }
/*     */     
/*  71 */     if (configuration != null) {
/*  72 */       ExpressionCache.putAssignationSequenceIntoCache(configuration, preprocessedInput, assignationSequence);
/*     */     }
/*     */     
/*  75 */     return assignationSequence;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   static AssignationSequence internalParseAssignationSequence(String input, boolean allowParametersWithoutValue)
/*     */   {
/*  82 */     if (StringUtils.isEmptyOrWhitespace(input)) {
/*  83 */       return null;
/*     */     }
/*     */     
/*  86 */     ExpressionParsingState decomposition = ExpressionParsingUtil.decompose(input);
/*     */     
/*  88 */     if (decomposition == null) {
/*  89 */       return null;
/*     */     }
/*     */     
/*  92 */     return composeSequence(decomposition, 0, allowParametersWithoutValue);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static AssignationSequence composeSequence(ExpressionParsingState state, int nodeIndex, boolean allowParametersWithoutValue)
/*     */   {
/* 104 */     if ((state == null) || (nodeIndex >= state.size())) {
/* 105 */       return null;
/*     */     }
/*     */     
/* 108 */     if (state.hasExpressionAt(nodeIndex)) {
/* 109 */       if (!allowParametersWithoutValue) {
/* 110 */         return null;
/*     */       }
/*     */       
/*     */ 
/* 114 */       Assignation assignation = composeAssignation(state, nodeIndex, allowParametersWithoutValue);
/* 115 */       if (assignation == null) {
/* 116 */         return null;
/*     */       }
/* 118 */       List<Assignation> assignations = new ArrayList(2);
/* 119 */       assignations.add(assignation);
/* 120 */       return new AssignationSequence(assignations);
/*     */     }
/*     */     
/* 123 */     String input = ((ExpressionParsingNode)state.get(nodeIndex)).getInput();
/*     */     
/* 125 */     if (StringUtils.isEmptyOrWhitespace(input)) {
/* 126 */       return null;
/*     */     }
/*     */     
/*     */ 
/* 130 */     int pointer = ExpressionParsingUtil.parseAsSimpleIndexPlaceholder(input);
/* 131 */     if (pointer != -1) {
/* 132 */       return composeSequence(state, pointer, allowParametersWithoutValue);
/*     */     }
/*     */     
/* 135 */     String[] inputParts = StringUtils.split(input, ",");
/*     */     
/* 137 */     for (String inputPart : inputParts)
/*     */     {
/*     */ 
/*     */ 
/* 141 */       state.addNode(inputPart.trim());
/*     */     }
/*     */     
/* 144 */     Object assignations = new ArrayList(4);
/* 145 */     int startIndex = state.size() - inputParts.length;
/* 146 */     int endIndex = state.size();
/* 147 */     for (int i = startIndex; i < endIndex; i++)
/*     */     {
/* 149 */       Assignation assignation = composeAssignation(state, i, allowParametersWithoutValue);
/* 150 */       if (assignation == null) {
/* 151 */         return null;
/*     */       }
/* 153 */       ((List)assignations).add(assignation);
/*     */     }
/*     */     
/* 156 */     return new AssignationSequence((List)assignations);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static Assignation composeAssignation(ExpressionParsingState state, int nodeIndex, boolean allowParametersWithoutValue)
/*     */   {
/* 166 */     if ((state == null) || (nodeIndex >= state.size())) {
/* 167 */       return null;
/*     */     }
/*     */     
/* 170 */     if (state.hasExpressionAt(nodeIndex)) {
/* 171 */       if (!allowParametersWithoutValue) {
/* 172 */         return null;
/*     */       }
/*     */       
/* 175 */       return new Assignation(((ExpressionParsingNode)state.get(nodeIndex)).getExpression(), null);
/*     */     }
/*     */     
/* 178 */     String input = ((ExpressionParsingNode)state.get(nodeIndex)).getInput();
/*     */     
/* 180 */     if (StringUtils.isEmptyOrWhitespace(input)) {
/* 181 */       return null;
/*     */     }
/*     */     
/*     */ 
/* 185 */     int pointer = ExpressionParsingUtil.parseAsSimpleIndexPlaceholder(input);
/* 186 */     if (pointer != -1) {
/* 187 */       return composeAssignation(state, pointer, allowParametersWithoutValue);
/*     */     }
/*     */     
/* 190 */     int inputLen = input.length();
/* 191 */     int operatorPos = input.indexOf('=');
/*     */     
/*     */ 
/* 194 */     String leftInput = operatorPos == -1 ? input.trim() : input.substring(0, operatorPos).trim();
/*     */     
/* 196 */     String rightInput = (operatorPos == -1) || (operatorPos == inputLen - 1) ? null : input.substring(operatorPos + 1).trim();
/*     */     
/* 198 */     if (StringUtils.isEmptyOrWhitespace(leftInput)) {
/* 199 */       return null;
/*     */     }
/*     */     
/* 202 */     Expression leftExpr = ExpressionParsingUtil.parseAndCompose(state, leftInput);
/* 203 */     if (leftExpr == null) {
/* 204 */       return null;
/*     */     }
/*     */     
/*     */     Expression rightExpr;
/* 208 */     if (!StringUtils.isEmptyOrWhitespace(rightInput)) {
/* 209 */       Expression rightExpr = ExpressionParsingUtil.parseAndCompose(state, rightInput);
/* 210 */       if (rightExpr == null)
/* 211 */         return null;
/*     */     } else {
/* 213 */       if (!allowParametersWithoutValue) {
/* 214 */         return null;
/*     */       }
/* 216 */       rightExpr = null;
/*     */     }
/*     */     
/* 219 */     return new Assignation(leftExpr, rightExpr);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\expression\AssignationUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */