/*    */ package org.thymeleaf.standard.expression;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class GreaterLesserExpression
/*    */   extends BinaryOperationExpression
/*    */ {
/*    */   private static final long serialVersionUID = 3488922833645278122L;
/*    */   protected static final String GREATER_THAN_OPERATOR = ">";
/*    */   protected static final String GREATER_OR_EQUAL_TO_OPERATOR = ">=";
/*    */   protected static final String LESS_THAN_OPERATOR = "<";
/*    */   protected static final String LESS_OR_EQUAL_TO_OPERATOR = "<=";
/*    */   protected static final String GREATER_THAN_OPERATOR_2 = "gt";
/*    */   protected static final String GREATER_OR_EQUAL_TO_OPERATOR_2 = "ge";
/*    */   protected static final String LESS_THAN_OPERATOR_2 = "lt";
/*    */   protected static final String LESS_OR_EQUAL_TO_OPERATOR_2 = "le";
/* 48 */   static final String[] OPERATORS = { ">", ">=", "<", "<=", "gt", "ge", "lt", "le" };
/*    */   
/*    */ 
/* 51 */   private static final boolean[] LENIENCIES = { false, false, false, false, false, false, false, false };
/*    */   
/*    */ 
/* 54 */   private static final Class<? extends BinaryOperationExpression>[] OPERATOR_CLASSES = { GreaterThanExpression.class, GreaterOrEqualToExpression.class, LessThanExpression.class, LessOrEqualToExpression.class, GreaterThanExpression.class, GreaterOrEqualToExpression.class, LessThanExpression.class, LessOrEqualToExpression.class };
/*    */   
/*    */ 
/*    */   private static final Method LEFT_ALLOWED_METHOD;
/*    */   
/*    */ 
/*    */   private static final Method RIGHT_ALLOWED_METHOD;
/*    */   
/*    */ 
/*    */   static
/*    */   {
/*    */     try
/*    */     {
/* 67 */       LEFT_ALLOWED_METHOD = GreaterLesserExpression.class.getDeclaredMethod("isLeftAllowed", new Class[] { IStandardExpression.class });
/* 68 */       RIGHT_ALLOWED_METHOD = GreaterLesserExpression.class.getDeclaredMethod("isRightAllowed", new Class[] { IStandardExpression.class });
/*    */     } catch (NoSuchMethodException e) {
/* 70 */       throw new ExceptionInInitializerError(e);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   protected GreaterLesserExpression(IStandardExpression left, IStandardExpression right)
/*    */   {
/* 77 */     super(left, right);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   static boolean isRightAllowed(IStandardExpression right)
/*    */   {
/* 84 */     return (right != null) && ((!(right instanceof Token)) || ((right instanceof NumberTokenExpression)) || ((right instanceof GenericTokenExpression)));
/*    */   }
/*    */   
/*    */   static boolean isLeftAllowed(IStandardExpression left) {
/* 88 */     return (left != null) && ((!(left instanceof Token)) || ((left instanceof NumberTokenExpression)) || ((left instanceof GenericTokenExpression)));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   protected static ExpressionParsingState composeGreaterLesserExpression(ExpressionParsingState state, int nodeIndex)
/*    */   {
/* 95 */     return composeBinaryOperationExpression(state, nodeIndex, OPERATORS, LENIENCIES, OPERATOR_CLASSES, LEFT_ALLOWED_METHOD, RIGHT_ALLOWED_METHOD);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\expression\GreaterLesserExpression.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */