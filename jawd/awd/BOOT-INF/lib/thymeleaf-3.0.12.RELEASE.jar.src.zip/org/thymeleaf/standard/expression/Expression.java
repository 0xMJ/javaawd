/*     */ package org.thymeleaf.standard.expression;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import org.thymeleaf.context.IExpressionContext;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Expression
/*     */   implements IStandardExpression, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1608378943284014151L;
/*     */   public static final char PARSING_PLACEHOLDER_CHAR = '§';
/*     */   public static final char NESTING_START_CHAR = '(';
/*     */   public static final char NESTING_END_CHAR = ')';
/*     */   
/*     */   public abstract String getStringRepresentation();
/*     */   
/*     */   public String toString()
/*     */   {
/*  66 */     return getStringRepresentation();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   static Expression parse(String input)
/*     */   {
/*  73 */     Validate.notNull(input, "Input cannot be null");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  78 */     ExpressionParsingState decomposition = ExpressionParsingUtil.decompose(input);
/*  79 */     if (decomposition == null) {
/*  80 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  86 */     ExpressionParsingState result = ExpressionParsingUtil.compose(decomposition);
/*  87 */     if ((result == null) || (!result.hasExpressionAt(0))) {
/*  88 */       return null;
/*     */     }
/*     */     
/*  91 */     return ((ExpressionParsingNode)result.get(0)).getExpression();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static Object execute(IExpressionContext context, Expression expression, IStandardVariableExpressionEvaluator expressionEvaluator, StandardExpressionExecutionContext expContext)
/*     */   {
/* 108 */     if ((expression instanceof SimpleExpression)) {
/* 109 */       return SimpleExpression.executeSimple(context, (SimpleExpression)expression, expressionEvaluator, expContext);
/*     */     }
/* 111 */     if ((expression instanceof ComplexExpression)) {
/* 112 */       return ComplexExpression.executeComplex(context, (ComplexExpression)expression, expContext);
/*     */     }
/*     */     
/* 115 */     throw new TemplateProcessingException("Unrecognized expression: " + expression.getClass().getName());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object execute(IExpressionContext context)
/*     */   {
/* 125 */     return execute(context, StandardExpressionExecutionContext.NORMAL);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object execute(IExpressionContext context, StandardExpressionExecutionContext expContext)
/*     */   {
/* 133 */     Validate.notNull(context, "Context cannot be null");
/*     */     
/*     */ 
/* 136 */     IStandardVariableExpressionEvaluator variableExpressionEvaluator = StandardExpressions.getVariableExpressionEvaluator(context.getConfiguration());
/*     */     
/* 138 */     Object result = execute(context, this, variableExpressionEvaluator, expContext);
/* 139 */     return LiteralValue.unwrap(result);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\expression\Expression.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */