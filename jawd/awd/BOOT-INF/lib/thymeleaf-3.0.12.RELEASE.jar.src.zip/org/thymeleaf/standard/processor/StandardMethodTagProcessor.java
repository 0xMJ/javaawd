/*    */ package org.thymeleaf.standard.processor;
/*    */ 
/*    */ import org.thymeleaf.templatemode.TemplateMode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class StandardMethodTagProcessor
/*    */   extends AbstractStandardAttributeModifierTagProcessor
/*    */ {
/*    */   public static final int PRECEDENCE = 1000;
/*    */   public static final String ATTR_NAME = "method";
/*    */   
/*    */   public StandardMethodTagProcessor(String dialectPrefix)
/*    */   {
/* 38 */     super(TemplateMode.HTML, dialectPrefix, "method", 1000, true, false);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\processor\StandardMethodTagProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */