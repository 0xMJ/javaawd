/*    */ package org.thymeleaf.standard.expression;
/*    */ 
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ import org.thymeleaf.TemplateEngine;
/*    */ import org.thymeleaf.context.IExpressionContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class BooleanTokenExpression
/*    */   extends Token
/*    */ {
/* 44 */   private static final Logger logger = LoggerFactory.getLogger(BooleanTokenExpression.class);
/*    */   
/*    */   private static final long serialVersionUID = 7003426193298054476L;
/*    */   
/*    */   public BooleanTokenExpression(String value)
/*    */   {
/* 50 */     super(Boolean.valueOf(value));
/*    */   }
/*    */   
/*    */   public BooleanTokenExpression(Boolean value) {
/* 54 */     super(value);
/*    */   }
/*    */   
/*    */ 
/*    */   static BooleanTokenExpression parseBooleanTokenExpression(String input)
/*    */   {
/* 60 */     if (("true".equalsIgnoreCase(input)) || ("false".equalsIgnoreCase(input))) {
/* 61 */       return new BooleanTokenExpression(input);
/*    */     }
/* 63 */     return null;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   static Object executeBooleanTokenExpression(IExpressionContext context, BooleanTokenExpression expression, StandardExpressionExecutionContext expContext)
/*    */   {
/* 73 */     if (logger.isTraceEnabled()) {
/* 74 */       logger.trace("[THYMELEAF][{}] Evaluating boolean token: \"{}\"", TemplateEngine.threadIndex(), expression.getStringRepresentation());
/*    */     }
/*    */     
/* 77 */     return expression.getValue();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\expression\BooleanTokenExpression.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */