/*     */ package org.thymeleaf.standard.expression;
/*     */ 
/*     */ import java.util.Map;
/*     */ import ognl.OgnlContext;
/*     */ import ognl.OgnlException;
/*     */ import ognl.PropertyAccessor;
/*     */ import ognl.enhance.UnsupportedCompilationException;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.thymeleaf.TemplateEngine;
/*     */ import org.thymeleaf.context.IContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class OGNLContextPropertyAccessor
/*     */   implements PropertyAccessor
/*     */ {
/*  55 */   private static final Logger LOGGER = LoggerFactory.getLogger(OGNLContextPropertyAccessor.class);
/*     */   
/*     */ 
/*     */ 
/*     */   public static final String RESTRICT_REQUEST_PARAMETERS = "%RESTRICT_REQUEST_PARAMETERS%";
/*     */   
/*     */ 
/*     */ 
/*     */   static final String REQUEST_PARAMETERS_RESTRICTED_VARIABLE_NAME = "param";
/*     */   
/*     */ 
/*     */ 
/*     */   public Object getProperty(Map ognlContext, Object target, Object name)
/*     */     throws OgnlException
/*     */   {
/*  70 */     if (!(target instanceof IContext))
/*     */     {
/*     */ 
/*  73 */       throw new IllegalStateException("Wrong target type. This property accessor is only usable for " + IContext.class.getName() + " implementations, and in this case the target object is " + (target == null ? "null" : new StringBuilder().append("of class ").append(target.getClass().getName()).toString()));
/*     */     }
/*     */     
/*  76 */     if (("param".equals(name)) && (ognlContext != null) && (ognlContext.containsKey("%RESTRICT_REQUEST_PARAMETERS%"))) {
/*  77 */       throw new OgnlException("Access to variable \"" + name + "\" is forbidden in this context. Note some restrictions apply to variable access. For example, direct access to request parameters is forbidden in preprocessing and unescaped expressions, in TEXT template mode, in fragment insertion specifications and in some specific attribute processors.");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  84 */     String propertyName = name == null ? null : name.toString();
/*     */     
/*     */ 
/*  87 */     Object execInfoResult = checkExecInfo(propertyName, ognlContext);
/*  88 */     if (execInfoResult != null) {
/*  89 */       return execInfoResult;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  98 */     IContext context = (IContext)target;
/*  99 */     return context.getVariable(propertyName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   private static Object checkExecInfo(String propertyName, Map<String, Object> context)
/*     */   {
/* 121 */     if ("execInfo".equals(propertyName)) {
/* 122 */       LOGGER.warn("[THYMELEAF][{}] Found Thymeleaf Standard Expression containing a call to the context variable \"execInfo\" (e.g. \"${execInfo.templateName}\"), which has been deprecated. The Execution Info should be now accessed as an expression object instead (e.g. \"${#execInfo.templateName}\"). Deprecated use is still allowed, but will be removed in future versions of Thymeleaf.", 
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 128 */         TemplateEngine.threadIndex());
/* 129 */       return context.get("execInfo");
/*     */     }
/* 131 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setProperty(Map context, Object target, Object name, Object value)
/*     */     throws OgnlException
/*     */   {
/* 139 */     throw new UnsupportedOperationException("Cannot set values into VariablesMap instances from OGNL Expressions");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getSourceAccessor(OgnlContext context, Object target, Object index)
/*     */   {
/* 151 */     context.setCurrentAccessor(IContext.class);
/* 152 */     context.setCurrentType(Object.class);
/*     */     
/* 154 */     return ".getVariable(" + index + ")";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getSourceSetter(OgnlContext context, Object target, Object index)
/*     */   {
/* 166 */     throw new UnsupportedCompilationException("Setting expression for " + context.getCurrentObject() + " with index of " + index + " cannot be computed. IVariablesMap implementations are considered read-only by OGNL.");
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\expression\OGNLContextPropertyAccessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */