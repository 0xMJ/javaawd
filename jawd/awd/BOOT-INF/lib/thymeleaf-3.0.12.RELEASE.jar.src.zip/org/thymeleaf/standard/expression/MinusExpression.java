/*     */ package org.thymeleaf.standard.expression;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.thymeleaf.TemplateEngine;
/*     */ import org.thymeleaf.context.IExpressionContext;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.util.EvaluationUtils;
/*     */ import org.thymeleaf.util.StringUtils;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MinusExpression
/*     */   extends ComplexExpression
/*     */ {
/*     */   private static final long serialVersionUID = -9056215047277857192L;
/*  55 */   private static final Logger logger = LoggerFactory.getLogger(MinusExpression.class);
/*     */   
/*     */ 
/*     */   private static final char OPERATOR = '-';
/*     */   
/*  60 */   static final String[] OPERATORS = { String.valueOf('-') };
/*     */   
/*     */ 
/*     */   private final Expression operand;
/*     */   
/*     */ 
/*     */   public MinusExpression(Expression operand)
/*     */   {
/*  68 */     Validate.notNull(operand, "Operand cannot be null");
/*  69 */     this.operand = operand;
/*     */   }
/*     */   
/*     */   public Expression getOperand() {
/*  73 */     return this.operand;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getStringRepresentation()
/*     */   {
/*  80 */     StringBuilder sb = new StringBuilder();
/*  81 */     sb.append('-');
/*  82 */     if ((this.operand instanceof ComplexExpression)) {
/*  83 */       sb.append('(');
/*  84 */       sb.append(this.operand);
/*  85 */       sb.append(')');
/*     */     } else {
/*  87 */       sb.append(this.operand);
/*     */     }
/*  89 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ExpressionParsingState composeMinusExpression(ExpressionParsingState state, int nodeIndex)
/*     */   {
/* 101 */     String input = ((ExpressionParsingNode)state.get(nodeIndex)).getInput();
/*     */     
/* 103 */     if (StringUtils.isEmptyOrWhitespace(input)) {
/* 104 */       return null;
/*     */     }
/*     */     
/* 107 */     String trimmedInput = input.trim();
/*     */     
/*     */ 
/* 110 */     int operatorPos = trimmedInput.lastIndexOf('-');
/* 111 */     if (operatorPos == -1) {
/* 112 */       return state;
/*     */     }
/* 114 */     if (operatorPos != 0)
/*     */     {
/* 116 */       return state;
/*     */     }
/*     */     
/* 119 */     String operandStr = trimmedInput.substring(1);
/*     */     
/* 121 */     Expression operandExpr = ExpressionParsingUtil.parseAndCompose(state, operandStr);
/* 122 */     if (operandExpr == null) {
/* 123 */       return null;
/*     */     }
/*     */     
/* 126 */     MinusExpression minusExpression = new MinusExpression(operandExpr);
/* 127 */     state.setNode(nodeIndex, minusExpression);
/*     */     
/* 129 */     return state;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static Object executeMinus(IExpressionContext context, MinusExpression expression, StandardExpressionExecutionContext expContext)
/*     */   {
/* 139 */     if (logger.isTraceEnabled()) {
/* 140 */       logger.trace("[THYMELEAF][{}] Evaluating minus expression: \"{}\"", TemplateEngine.threadIndex(), expression.getStringRepresentation());
/*     */     }
/*     */     
/* 143 */     Object operandValue = expression.getOperand().execute(context, expContext);
/*     */     
/* 145 */     if (operandValue == null) {
/* 146 */       operandValue = "null";
/*     */     }
/*     */     
/* 149 */     BigDecimal operandNumberValue = EvaluationUtils.evaluateAsNumber(operandValue);
/* 150 */     if (operandNumberValue != null)
/*     */     {
/* 152 */       return operandNumberValue.multiply(BigDecimal.valueOf(-1L));
/*     */     }
/*     */     
/*     */ 
/* 156 */     throw new TemplateProcessingException("Cannot execute minus: operand is \"" + LiteralValue.unwrap(operandValue) + "\"");
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\expression\MinusExpression.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */