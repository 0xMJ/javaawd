/*    */ package org.thymeleaf.standard.expression;
/*    */ 
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ import org.thymeleaf.TemplateEngine;
/*    */ import org.thymeleaf.context.IExpressionContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class GenericTokenExpression
/*    */   extends Token
/*    */ {
/* 45 */   private static final Logger logger = LoggerFactory.getLogger(GenericTokenExpression.class);
/*    */   
/*    */   private static final long serialVersionUID = 7913229642187691263L;
/*    */   
/*    */   GenericTokenExpression(String value)
/*    */   {
/* 51 */     super(value);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public String toString()
/*    */   {
/* 58 */     return getStringRepresentation();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public static GenericTokenExpression parseGenericTokenExpression(String input)
/*    */   {
/* 65 */     if (input == null) {
/* 66 */       return null;
/*    */     }
/* 68 */     int inputLen = input.length();
/* 69 */     for (int i = 0; i < inputLen; i++) {
/* 70 */       if (!isTokenChar(input, i)) {
/* 71 */         return null;
/*    */       }
/*    */     }
/* 74 */     return new GenericTokenExpression(input);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   static Object executeGenericTokenExpression(IExpressionContext context, GenericTokenExpression expression, StandardExpressionExecutionContext expContext)
/*    */   {
/* 84 */     if (logger.isTraceEnabled()) {
/* 85 */       logger.trace("[THYMELEAF][{}] Evaluating generic token: \"{}\"", TemplateEngine.threadIndex(), expression.getStringRepresentation());
/*    */     }
/*    */     
/* 88 */     return expression.getValue();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\expression\GenericTokenExpression.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */