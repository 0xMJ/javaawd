/*     */ package org.thymeleaf.standard.serializer;
/*     */ 
/*     */ import java.util.Map;
/*     */ import org.thymeleaf.IEngineConfiguration;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class StandardSerializers
/*     */ {
/*     */   public static final String STANDARD_JAVASCRIPT_SERIALIZER_ATTRIBUTE_NAME = "StandardJavaScriptSerializer";
/*     */   public static final String STANDARD_CSS_SERIALIZER_ATTRIBUTE_NAME = "StandardCSSSerializer";
/*     */   
/*     */   public static IStandardJavaScriptSerializer getJavaScriptSerializer(IEngineConfiguration configuration)
/*     */   {
/*  71 */     Object serializer = configuration.getExecutionAttributes().get("StandardJavaScriptSerializer");
/*  72 */     if ((serializer == null) || (!(serializer instanceof IStandardJavaScriptSerializer)))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  78 */       throw new TemplateProcessingException("No JavaScript Serializer has been registered as an execution argument. This is a requirement for using Standard serialization, and might happen if neither the Standard or the SpringStandard dialects have been added to the Template Engine and none of the specified dialects registers an attribute of type " + IStandardJavaScriptSerializer.class.getName() + " with name \"" + "StandardJavaScriptSerializer" + "\"");
/*     */     }
/*     */     
/*  81 */     return (IStandardJavaScriptSerializer)serializer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static IStandardCSSSerializer getCSSSerializer(IEngineConfiguration configuration)
/*     */   {
/*  97 */     Object serializer = configuration.getExecutionAttributes().get("StandardCSSSerializer");
/*  98 */     if ((serializer == null) || (!(serializer instanceof IStandardCSSSerializer)))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 104 */       throw new TemplateProcessingException("No CSS Serializer has been registered as an execution argument. This is a requirement for using Standard serialization, and might happen if neither the Standard or the SpringStandard dialects have been added to the Template Engine and none of the specified dialects registers an attribute of type " + IStandardCSSSerializer.class.getName() + " with name \"" + "StandardCSSSerializer" + "\"");
/*     */     }
/*     */     
/* 107 */     return (IStandardCSSSerializer)serializer;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\serializer\StandardSerializers.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */