/*     */ package org.thymeleaf.standard.expression;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.thymeleaf.TemplateEngine;
/*     */ import org.thymeleaf.context.IExpressionContext;
/*     */ import org.thymeleaf.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class NumberTokenExpression
/*     */   extends Token
/*     */ {
/*  48 */   private static final Logger logger = LoggerFactory.getLogger(NumberTokenExpression.class);
/*     */   
/*     */ 
/*     */   private static final long serialVersionUID = -3729844055243242571L;
/*     */   
/*     */   public static final char DECIMAL_POINT = '.';
/*     */   
/*     */ 
/*     */   static Number computeValue(String value)
/*     */   {
/*  58 */     BigDecimal bigDecimalValue = new BigDecimal(value);
/*  59 */     if (bigDecimalValue.scale() > 0) {
/*  60 */       return bigDecimalValue;
/*     */     }
/*  62 */     return bigDecimalValue.toBigInteger();
/*     */   }
/*     */   
/*     */   public NumberTokenExpression(String value)
/*     */   {
/*  67 */     super(computeValue(value));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getStringRepresentation()
/*     */   {
/*  74 */     Object value = getValue();
/*  75 */     if ((value instanceof BigDecimal)) {
/*  76 */       return ((BigDecimal)getValue()).toPlainString();
/*     */     }
/*  78 */     return value.toString();
/*     */   }
/*     */   
/*     */ 
/*     */   static NumberTokenExpression parseNumberTokenExpression(String input)
/*     */   {
/*  84 */     if (StringUtils.isEmptyOrWhitespace(input)) {
/*  85 */       return null;
/*     */     }
/*  87 */     boolean decimalFound = false;
/*  88 */     int inputLen = input.length();
/*  89 */     for (int i = 0; i < inputLen; i++) {
/*  90 */       char c = input.charAt(i);
/*  91 */       if (!Character.isDigit(c))
/*     */       {
/*  93 */         if (c == '.') {
/*  94 */           if (decimalFound) {
/*  95 */             return null;
/*     */           }
/*  97 */           decimalFound = true;
/*     */         }
/*     */         else {
/* 100 */           return null;
/*     */         } }
/*     */     }
/*     */     try {
/* 104 */       return new NumberTokenExpression(input);
/*     */     }
/*     */     catch (NumberFormatException e) {}
/* 107 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static Object executeNumberTokenExpression(IExpressionContext context, NumberTokenExpression expression, StandardExpressionExecutionContext expContext)
/*     */   {
/* 118 */     if (logger.isTraceEnabled()) {
/* 119 */       logger.trace("[THYMELEAF][{}] Evaluating number token: \"{}\"", TemplateEngine.threadIndex(), expression.getStringRepresentation());
/*     */     }
/*     */     
/* 122 */     return expression.getValue();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\expression\NumberTokenExpression.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */