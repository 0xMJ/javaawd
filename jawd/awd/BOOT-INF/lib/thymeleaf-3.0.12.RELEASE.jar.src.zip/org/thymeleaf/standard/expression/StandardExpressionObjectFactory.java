/*     */ package org.thymeleaf.standard.expression;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import org.thymeleaf.context.IExpressionContext;
/*     */ import org.thymeleaf.context.ITemplateContext;
/*     */ import org.thymeleaf.context.IWebContext;
/*     */ import org.thymeleaf.expression.Aggregates;
/*     */ import org.thymeleaf.expression.Bools;
/*     */ import org.thymeleaf.expression.Calendars;
/*     */ import org.thymeleaf.expression.Conversions;
/*     */ import org.thymeleaf.expression.Dates;
/*     */ import org.thymeleaf.expression.ExecutionInfo;
/*     */ import org.thymeleaf.expression.IExpressionObjectFactory;
/*     */ import org.thymeleaf.expression.Ids;
/*     */ import org.thymeleaf.expression.Lists;
/*     */ import org.thymeleaf.expression.Maps;
/*     */ import org.thymeleaf.expression.Messages;
/*     */ import org.thymeleaf.expression.Numbers;
/*     */ import org.thymeleaf.expression.Objects;
/*     */ import org.thymeleaf.expression.Sets;
/*     */ import org.thymeleaf.expression.Strings;
/*     */ import org.thymeleaf.expression.Uris;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardExpressionObjectFactory
/*     */   implements IExpressionObjectFactory
/*     */ {
/*     */   public static final String CONTEXT_EXPRESSION_OBJECT_NAME = "ctx";
/*     */   public static final String ROOT_EXPRESSION_OBJECT_NAME = "root";
/*     */   public static final String VARIABLES_EXPRESSION_OBJECT_NAME = "vars";
/*     */   public static final String SELECTION_TARGET_EXPRESSION_OBJECT_NAME = "object";
/*     */   public static final String LOCALE_EXPRESSION_OBJECT_NAME = "locale";
/*     */   public static final String REQUEST_EXPRESSION_OBJECT_NAME = "request";
/*     */   public static final String RESPONSE_EXPRESSION_OBJECT_NAME = "response";
/*     */   public static final String SESSION_EXPRESSION_OBJECT_NAME = "session";
/*     */   public static final String SERVLET_CONTEXT_EXPRESSION_OBJECT_NAME = "servletContext";
/*     */   public static final String CONVERSIONS_EXPRESSION_OBJECT_NAME = "conversions";
/*     */   public static final String URIS_EXPRESSION_OBJECT_NAME = "uris";
/*     */   public static final String CALENDARS_EXPRESSION_OBJECT_NAME = "calendars";
/*     */   public static final String DATES_EXPRESSION_OBJECT_NAME = "dates";
/*     */   public static final String BOOLS_EXPRESSION_OBJECT_NAME = "bools";
/*     */   public static final String NUMBERS_EXPRESSION_OBJECT_NAME = "numbers";
/*     */   public static final String OBJECTS_EXPRESSION_OBJECT_NAME = "objects";
/*     */   public static final String STRINGS_EXPRESSION_OBJECT_NAME = "strings";
/*     */   public static final String ARRAYS_EXPRESSION_OBJECT_NAME = "arrays";
/*     */   public static final String LISTS_EXPRESSION_OBJECT_NAME = "lists";
/*     */   public static final String SETS_EXPRESSION_OBJECT_NAME = "sets";
/*     */   public static final String MAPS_EXPRESSION_OBJECT_NAME = "maps";
/*     */   public static final String AGGREGATES_EXPRESSION_OBJECT_NAME = "aggregates";
/*     */   public static final String MESSAGES_EXPRESSION_OBJECT_NAME = "messages";
/*     */   public static final String IDS_EXPRESSION_OBJECT_NAME = "ids";
/*     */   public static final String EXECUTION_INFO_OBJECT_NAME = "execInfo";
/*     */   public static final String HTTP_SERVLET_REQUEST_EXPRESSION_OBJECT_NAME = "httpServletRequest";
/*     */   public static final String HTTP_SESSION_EXPRESSION_OBJECT_NAME = "httpSession";
/* 107 */   protected static final Set<String> ALL_EXPRESSION_OBJECT_NAMES = Collections.unmodifiableSet(new LinkedHashSet(java.util.Arrays.asList(new String[] { "ctx", "root", "vars", "object", "locale", "request", "response", "session", "servletContext", "conversions", "uris", "calendars", "dates", "bools", "numbers", "objects", "strings", "arrays", "lists", "sets", "maps", "aggregates", "messages", "ids", "execInfo", "httpServletRequest", "httpSession" })));
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 141 */   private static final Uris URIS_EXPRESSION_OBJECT = new Uris();
/* 142 */   private static final Bools BOOLS_EXPRESSION_OBJECT = new Bools();
/* 143 */   private static final Objects OBJECTS_EXPRESSION_OBJECT = new Objects();
/* 144 */   private static final org.thymeleaf.expression.Arrays ARRAYS_EXPRESSION_OBJECT = new org.thymeleaf.expression.Arrays();
/* 145 */   private static final Lists LISTS_EXPRESSION_OBJECT = new Lists();
/* 146 */   private static final Sets SETS_EXPRESSION_OBJECT = new Sets();
/* 147 */   private static final Maps MAPS_EXPRESSION_OBJECT = new Maps();
/* 148 */   private static final Aggregates AGGREGATES_EXPRESSION_OBJECT = new Aggregates();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Set<String> getAllExpressionObjectNames()
/*     */   {
/* 163 */     return ALL_EXPRESSION_OBJECT_NAMES;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isCacheable(String expressionObjectName)
/*     */   {
/* 170 */     return (expressionObjectName != null) && (!expressionObjectName.equals("object"));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object buildObject(IExpressionContext context, String expressionObjectName)
/*     */   {
/* 179 */     if ("object".equals(expressionObjectName)) {
/* 180 */       if ((context instanceof ITemplateContext)) {
/* 181 */         ITemplateContext templateContext = (ITemplateContext)context;
/* 182 */         if (templateContext.hasSelectionTarget()) {
/* 183 */           return templateContext.getSelectionTarget();
/*     */         }
/*     */       }
/* 186 */       return context;
/*     */     }
/*     */     
/* 189 */     if ("root".equals(expressionObjectName)) {
/* 190 */       return context;
/*     */     }
/* 192 */     if ("vars".equals(expressionObjectName)) {
/* 193 */       return context;
/*     */     }
/* 195 */     if ("ctx".equals(expressionObjectName)) {
/* 196 */       return context;
/*     */     }
/* 198 */     if ("locale".equals(expressionObjectName)) {
/* 199 */       return context.getLocale();
/*     */     }
/* 201 */     if ("request".equals(expressionObjectName)) {
/* 202 */       if ((context instanceof IWebContext)) {
/* 203 */         return ((IWebContext)context).getRequest();
/*     */       }
/* 205 */       return null;
/*     */     }
/* 207 */     if ("response".equals(expressionObjectName)) {
/* 208 */       if ((context instanceof IWebContext)) {
/* 209 */         return ((IWebContext)context).getResponse();
/*     */       }
/* 211 */       return null;
/*     */     }
/* 213 */     if ("session".equals(expressionObjectName)) {
/* 214 */       if ((context instanceof IWebContext)) {
/* 215 */         return ((IWebContext)context).getSession();
/*     */       }
/* 217 */       return null;
/*     */     }
/* 219 */     if ("servletContext".equals(expressionObjectName)) {
/* 220 */       if ((context instanceof IWebContext)) {
/* 221 */         return ((IWebContext)context).getServletContext();
/*     */       }
/* 223 */       return null;
/*     */     }
/* 225 */     if ("httpServletRequest".equals(expressionObjectName))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 230 */       if ((context instanceof IWebContext)) {
/* 231 */         return ((IWebContext)context).getRequest();
/*     */       }
/* 233 */       return null;
/*     */     }
/* 235 */     if ("httpSession".equals(expressionObjectName))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 240 */       if ((context instanceof IWebContext)) {
/* 241 */         return ((IWebContext)context).getSession();
/*     */       }
/* 243 */       return null;
/*     */     }
/* 245 */     if ("conversions".equals(expressionObjectName)) {
/* 246 */       return new Conversions(context);
/*     */     }
/* 248 */     if ("uris".equals(expressionObjectName)) {
/* 249 */       return URIS_EXPRESSION_OBJECT;
/*     */     }
/* 251 */     if ("calendars".equals(expressionObjectName)) {
/* 252 */       return new Calendars(context.getLocale());
/*     */     }
/* 254 */     if ("dates".equals(expressionObjectName)) {
/* 255 */       return new Dates(context.getLocale());
/*     */     }
/* 257 */     if ("bools".equals(expressionObjectName)) {
/* 258 */       return BOOLS_EXPRESSION_OBJECT;
/*     */     }
/* 260 */     if ("numbers".equals(expressionObjectName)) {
/* 261 */       return new Numbers(context.getLocale());
/*     */     }
/* 263 */     if ("objects".equals(expressionObjectName)) {
/* 264 */       return OBJECTS_EXPRESSION_OBJECT;
/*     */     }
/* 266 */     if ("strings".equals(expressionObjectName)) {
/* 267 */       return new Strings(context.getLocale());
/*     */     }
/* 269 */     if ("arrays".equals(expressionObjectName)) {
/* 270 */       return ARRAYS_EXPRESSION_OBJECT;
/*     */     }
/* 272 */     if ("lists".equals(expressionObjectName)) {
/* 273 */       return LISTS_EXPRESSION_OBJECT;
/*     */     }
/* 275 */     if ("sets".equals(expressionObjectName)) {
/* 276 */       return SETS_EXPRESSION_OBJECT;
/*     */     }
/* 278 */     if ("maps".equals(expressionObjectName)) {
/* 279 */       return MAPS_EXPRESSION_OBJECT;
/*     */     }
/* 281 */     if ("aggregates".equals(expressionObjectName)) {
/* 282 */       return AGGREGATES_EXPRESSION_OBJECT;
/*     */     }
/* 284 */     if ("messages".equals(expressionObjectName)) {
/* 285 */       if ((context instanceof ITemplateContext)) {
/* 286 */         return new Messages((ITemplateContext)context);
/*     */       }
/* 288 */       return null;
/*     */     }
/* 290 */     if ("ids".equals(expressionObjectName)) {
/* 291 */       if ((context instanceof ITemplateContext)) {
/* 292 */         return new Ids((ITemplateContext)context);
/*     */       }
/* 294 */       return null;
/*     */     }
/* 296 */     if ("execInfo".equals(expressionObjectName)) {
/* 297 */       if ((context instanceof ITemplateContext)) {
/* 298 */         return new ExecutionInfo((ITemplateContext)context);
/*     */       }
/* 300 */       return null;
/*     */     }
/*     */     
/* 303 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\expression\StandardExpressionObjectFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */