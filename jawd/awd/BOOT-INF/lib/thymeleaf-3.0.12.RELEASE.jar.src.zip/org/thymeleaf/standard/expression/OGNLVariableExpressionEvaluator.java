/*     */ package org.thymeleaf.standard.expression;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import ognl.Ognl;
/*     */ import ognl.OgnlContext;
/*     */ import ognl.OgnlException;
/*     */ import ognl.OgnlRuntime;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.thymeleaf.IEngineConfiguration;
/*     */ import org.thymeleaf.TemplateEngine;
/*     */ import org.thymeleaf.context.IContext;
/*     */ import org.thymeleaf.context.IExpressionContext;
/*     */ import org.thymeleaf.context.ITemplateContext;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.expression.IExpressionObjects;
/*     */ import org.thymeleaf.standard.util.StandardExpressionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class OGNLVariableExpressionEvaluator
/*     */   implements IStandardVariableExpressionEvaluator
/*     */ {
/*  58 */   private static final Logger logger = LoggerFactory.getLogger(OGNLVariableExpressionEvaluator.class);
/*     */   
/*     */ 
/*     */   private static final String EXPRESSION_CACHE_TYPE_OGNL = "ognl";
/*     */   
/*     */ 
/*  64 */   private static Map<String, Object> CONTEXT_VARIABLES_MAP_NOEXPOBJECTS_RESTRICTIONS = Collections.singletonMap("%RESTRICT_REQUEST_PARAMETERS%", "%RESTRICT_REQUEST_PARAMETERS%");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final boolean applyOGNLShortcuts;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public OGNLVariableExpressionEvaluator(boolean applyOGNLShortcuts)
/*     */   {
/*  78 */     this.applyOGNLShortcuts = applyOGNLShortcuts;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  83 */     OGNLContextPropertyAccessor accessor = new OGNLContextPropertyAccessor();
/*  84 */     OgnlRuntime.setPropertyAccessor(IContext.class, accessor);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final Object evaluate(IExpressionContext context, IStandardVariableExpression expression, StandardExpressionExecutionContext expContext)
/*     */   {
/*  95 */     return evaluate(context, expression, expContext, this.applyOGNLShortcuts);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Object evaluate(IExpressionContext context, IStandardVariableExpression expression, StandardExpressionExecutionContext expContext, boolean applyOGNLShortcuts)
/*     */   {
/*     */     try
/*     */     {
/* 109 */       if (logger.isTraceEnabled()) {
/* 110 */         logger.trace("[THYMELEAF][{}] OGNL expression: evaluating expression \"{}\" on target", TemplateEngine.threadIndex(), expression.getExpression());
/*     */       }
/*     */       
/* 113 */       IEngineConfiguration configuration = context.getConfiguration();
/*     */       
/* 115 */       String exp = expression.getExpression();
/* 116 */       boolean useSelectionAsRoot = expression.getUseSelectionAsRoot();
/*     */       
/* 118 */       if (exp == null) {
/* 119 */         throw new TemplateProcessingException("Expression content is null, which is not allowed");
/*     */       }
/*     */       
/*     */ 
/* 123 */       ComputedOGNLExpression parsedExpression = obtainComputedOGNLExpression(configuration, expression, exp, expContext, applyOGNLShortcuts);
/*     */       
/*     */       Map<String, Object> contextVariablesMap;
/* 126 */       if (parsedExpression.mightNeedExpressionObjects)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 137 */         IExpressionObjects expressionObjects = context.getExpressionObjects();
/* 138 */         Map<String, Object> contextVariablesMap = new OGNLExpressionObjectsWrapper(expressionObjects, expContext.getRestrictVariableAccess());
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 144 */         if (expContext.getRestrictVariableAccess()) {
/* 145 */           contextVariablesMap.put("%RESTRICT_REQUEST_PARAMETERS%", "%RESTRICT_REQUEST_PARAMETERS%");
/*     */         } else {
/* 147 */           contextVariablesMap.remove("%RESTRICT_REQUEST_PARAMETERS%");
/*     */         }
/*     */       }
/*     */       else {
/*     */         Map<String, Object> contextVariablesMap;
/* 152 */         if (expContext.getRestrictVariableAccess()) {
/* 153 */           contextVariablesMap = CONTEXT_VARIABLES_MAP_NOEXPOBJECTS_RESTRICTIONS;
/*     */         } else {
/* 155 */           contextVariablesMap = Collections.EMPTY_MAP;
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 163 */       ITemplateContext templateContext = (context instanceof ITemplateContext) ? (ITemplateContext)context : null;
/*     */       
/* 165 */       Object evaluationRoot = (useSelectionAsRoot) && (templateContext != null) && (templateContext.hasSelectionTarget()) ? templateContext.getSelectionTarget() : templateContext;
/*     */       
/*     */ 
/*     */       try
/*     */       {
/* 170 */         result = executeExpression(configuration, parsedExpression.expression, contextVariablesMap, evaluationRoot);
/*     */       }
/*     */       catch (OGNLShortcutExpression.OGNLShortcutExpressionNotApplicableException notApplicable)
/*     */       {
/*     */         Object result;
/*     */         
/* 176 */         invalidateComputedOGNLExpression(configuration, expression, exp);
/* 177 */         return evaluate(context, expression, expContext, false);
/*     */       }
/*     */       Object result;
/* 180 */       if (!expContext.getPerformTypeConversion()) {
/* 181 */         return result;
/*     */       }
/*     */       
/*     */ 
/* 185 */       IStandardConversionService conversionService = StandardExpressions.getConversionService(configuration);
/*     */       
/* 187 */       return conversionService.convert(context, result, String.class);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 191 */       throw new TemplateProcessingException("Exception evaluating OGNL expression: \"" + expression.getExpression() + "\"", e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static ComputedOGNLExpression obtainComputedOGNLExpression(IEngineConfiguration configuration, IStandardVariableExpression expression, String exp, StandardExpressionExecutionContext expContext, boolean applyOGNLShortcuts)
/*     */     throws OgnlException
/*     */   {
/* 205 */     if ((expression instanceof VariableExpression))
/*     */     {
/* 207 */       VariableExpression vexpression = (VariableExpression)expression;
/*     */       
/* 209 */       Object cachedExpression = vexpression.getCachedExpression();
/* 210 */       if ((cachedExpression != null) && ((cachedExpression instanceof ComputedOGNLExpression))) {
/* 211 */         return (ComputedOGNLExpression)cachedExpression;
/*     */       }
/* 213 */       cachedExpression = parseComputedOGNLExpression(configuration, exp, expContext, applyOGNLShortcuts);
/* 214 */       if (cachedExpression != null) {
/* 215 */         vexpression.setCachedExpression(cachedExpression);
/*     */       }
/* 217 */       return (ComputedOGNLExpression)cachedExpression;
/*     */     }
/*     */     
/*     */ 
/* 221 */     if ((expression instanceof SelectionVariableExpression))
/*     */     {
/* 223 */       SelectionVariableExpression vexpression = (SelectionVariableExpression)expression;
/*     */       
/* 225 */       Object cachedExpression = vexpression.getCachedExpression();
/* 226 */       if ((cachedExpression != null) && ((cachedExpression instanceof ComputedOGNLExpression))) {
/* 227 */         return (ComputedOGNLExpression)cachedExpression;
/*     */       }
/* 229 */       cachedExpression = parseComputedOGNLExpression(configuration, exp, expContext, applyOGNLShortcuts);
/* 230 */       if (cachedExpression != null) {
/* 231 */         vexpression.setCachedExpression(cachedExpression);
/*     */       }
/* 233 */       return (ComputedOGNLExpression)cachedExpression;
/*     */     }
/*     */     
/*     */ 
/* 237 */     return parseComputedOGNLExpression(configuration, exp, expContext, applyOGNLShortcuts);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static ComputedOGNLExpression parseComputedOGNLExpression(IEngineConfiguration configuration, String exp, StandardExpressionExecutionContext expContext, boolean applyOGNLShortcuts)
/*     */     throws OgnlException
/*     */   {
/* 249 */     ComputedOGNLExpression parsedExpression = (ComputedOGNLExpression)ExpressionCache.getFromCache(configuration, exp, "ognl");
/* 250 */     if (parsedExpression != null) {
/* 251 */       return parsedExpression;
/*     */     }
/*     */     
/* 254 */     parsedExpression = parseExpression(exp, expContext, applyOGNLShortcuts);
/* 255 */     ExpressionCache.putIntoCache(configuration, exp, parsedExpression, "ognl");
/* 256 */     return parsedExpression;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void invalidateComputedOGNLExpression(IEngineConfiguration configuration, IStandardVariableExpression expression, String exp)
/*     */   {
/* 264 */     if ((expression instanceof VariableExpression)) {
/* 265 */       VariableExpression vexpression = (VariableExpression)expression;
/* 266 */       vexpression.setCachedExpression(null);
/* 267 */     } else if ((expression instanceof SelectionVariableExpression)) {
/* 268 */       SelectionVariableExpression vexpression = (SelectionVariableExpression)expression;
/* 269 */       vexpression.setCachedExpression(null);
/*     */     }
/* 271 */     ExpressionCache.removeFromCache(configuration, exp, "ognl");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 280 */     return "OGNL";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static ComputedOGNLExpression parseExpression(String expression, StandardExpressionExecutionContext expContext, boolean applyOGNLShortcuts)
/*     */     throws OgnlException
/*     */   {
/* 295 */     if ((expContext.getRestrictInstantiationAndStatic()) && 
/* 296 */       (StandardExpressionUtils.containsOGNLInstantiationOrStatic(expression))) {
/* 297 */       throw new TemplateProcessingException("Instantiation of new objects and access to static classes is forbidden in this context");
/*     */     }
/*     */     
/*     */ 
/* 301 */     boolean mightNeedExpressionObjects = StandardExpressionUtils.mightNeedExpressionObjects(expression);
/*     */     
/* 303 */     if (applyOGNLShortcuts) {
/* 304 */       String[] parsedExpression = OGNLShortcutExpression.parse(expression);
/* 305 */       if (parsedExpression != null) {
/* 306 */         return new ComputedOGNLExpression(new OGNLShortcutExpression(parsedExpression), mightNeedExpressionObjects);
/*     */       }
/*     */     }
/*     */     
/* 310 */     return new ComputedOGNLExpression(Ognl.parseExpression(expression), mightNeedExpressionObjects);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Object executeExpression(IEngineConfiguration configuration, Object parsedExpression, Map<String, Object> context, Object root)
/*     */     throws Exception
/*     */   {
/* 321 */     if ((parsedExpression instanceof OGNLShortcutExpression)) {
/* 322 */       return ((OGNLShortcutExpression)parsedExpression).evaluate(configuration, context, root);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 327 */     OgnlContext ognlContext = new OgnlContext(context);
/* 328 */     return Ognl.getValue(parsedExpression, ognlContext, root);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static final class ComputedOGNLExpression
/*     */   {
/*     */     final Object expression;
/*     */     
/*     */     final boolean mightNeedExpressionObjects;
/*     */     
/*     */ 
/*     */     ComputedOGNLExpression(Object expression, boolean mightNeedExpressionObjects)
/*     */     {
/* 342 */       this.expression = expression;
/* 343 */       this.mightNeedExpressionObjects = mightNeedExpressionObjects;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\expression\OGNLVariableExpressionEvaluator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */