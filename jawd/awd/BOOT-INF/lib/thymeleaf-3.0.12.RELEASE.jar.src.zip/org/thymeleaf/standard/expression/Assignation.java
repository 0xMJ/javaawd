/*    */ package org.thymeleaf.standard.expression;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.thymeleaf.util.Validate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Assignation
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = -20278893925937213L;
/*    */   private final IStandardExpression left;
/*    */   private final IStandardExpression right;
/*    */   
/*    */   Assignation(IStandardExpression left, IStandardExpression right)
/*    */   {
/* 46 */     Validate.notNull(left, "Assignation left side cannot be null");
/* 47 */     this.left = left;
/* 48 */     this.right = right;
/*    */   }
/*    */   
/*    */ 
/*    */   public IStandardExpression getLeft()
/*    */   {
/* 54 */     return this.left;
/*    */   }
/*    */   
/*    */   public IStandardExpression getRight() {
/* 58 */     return this.right;
/*    */   }
/*    */   
/*    */   public String getStringRepresentation() {
/* 62 */     StringBuilder strBuilder = new StringBuilder();
/* 63 */     strBuilder.append(this.left.getStringRepresentation());
/* 64 */     if (this.right != null) {
/* 65 */       strBuilder.append('=');
/* 66 */       if ((this.right instanceof ComplexExpression)) {
/* 67 */         strBuilder.append('(');
/* 68 */         strBuilder.append(this.right.getStringRepresentation());
/* 69 */         strBuilder.append(')');
/*    */       } else {
/* 71 */         strBuilder.append(this.right.getStringRepresentation());
/*    */       }
/*    */     }
/* 74 */     return strBuilder.toString();
/*    */   }
/*    */   
/*    */ 
/*    */   public String toString()
/*    */   {
/* 80 */     return getStringRepresentation();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\expression\Assignation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */