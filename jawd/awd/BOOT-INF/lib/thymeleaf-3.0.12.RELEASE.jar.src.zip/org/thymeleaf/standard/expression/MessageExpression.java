/*     */ package org.thymeleaf.standard.expression;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.thymeleaf.TemplateEngine;
/*     */ import org.thymeleaf.context.IExpressionContext;
/*     */ import org.thymeleaf.context.ITemplateContext;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.util.StringUtils;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MessageExpression
/*     */   extends SimpleExpression
/*     */ {
/*  53 */   private static final Logger logger = LoggerFactory.getLogger(MessageExpression.class);
/*     */   
/*     */   private static final long serialVersionUID = 8394399541792390735L;
/*     */   
/*  57 */   private static final Object[] NO_PARAMETERS = new Object[0];
/*     */   
/*     */   static final char SELECTOR = '#';
/*     */   
/*     */   private static final char PARAMS_START_CHAR = '(';
/*     */   
/*     */   private static final char PARAMS_END_CHAR = ')';
/*     */   
/*  65 */   private static final Pattern MSG_PATTERN = Pattern.compile("^\\s*\\#\\{(.+?)\\}\\s*$", 32);
/*     */   
/*     */ 
/*     */   private final IStandardExpression base;
/*     */   
/*     */ 
/*     */   private final ExpressionSequence parameters;
/*     */   
/*     */ 
/*     */   public MessageExpression(IStandardExpression base, ExpressionSequence parameters)
/*     */   {
/*  76 */     Validate.notNull(base, "Base cannot be null");
/*  77 */     this.base = base;
/*  78 */     this.parameters = parameters;
/*     */   }
/*     */   
/*     */ 
/*     */   public IStandardExpression getBase()
/*     */   {
/*  84 */     return this.base;
/*     */   }
/*     */   
/*     */   public ExpressionSequence getParameters() {
/*  88 */     return this.parameters;
/*     */   }
/*     */   
/*     */   public boolean hasParameters() {
/*  92 */     return (this.parameters != null) && (this.parameters.size() > 0);
/*     */   }
/*     */   
/*     */   public String getStringRepresentation()
/*     */   {
/*  97 */     StringBuilder sb = new StringBuilder();
/*  98 */     sb.append('#');
/*  99 */     sb.append('{');
/* 100 */     sb.append(this.base);
/* 101 */     if (hasParameters()) {
/* 102 */       sb.append('(');
/* 103 */       sb.append(this.parameters.getStringRepresentation());
/* 104 */       sb.append(')');
/*     */     }
/* 106 */     sb.append('}');
/* 107 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   static MessageExpression parseMessageExpression(String input)
/*     */   {
/* 114 */     Matcher matcher = MSG_PATTERN.matcher(input);
/*     */     
/* 116 */     if (!matcher.matches()) {
/* 117 */       return null;
/*     */     }
/*     */     
/* 120 */     String content = matcher.group(1);
/*     */     
/* 122 */     if (StringUtils.isEmptyOrWhitespace(content)) {
/* 123 */       return null;
/*     */     }
/*     */     
/* 126 */     String trimmedInput = content.trim();
/*     */     
/* 128 */     if (trimmedInput.endsWith(String.valueOf(')')))
/*     */     {
/* 130 */       boolean inLiteral = false;
/* 131 */       int nestParLevel = 0;
/*     */       
/* 133 */       for (int i = trimmedInput.length() - 1; i >= 0; i--)
/*     */       {
/* 135 */         char c = trimmedInput.charAt(i);
/*     */         
/* 137 */         if (c == '\'')
/*     */         {
/* 139 */           if ((i == 0) || (content.charAt(i - 1) != '\\')) {
/* 140 */             inLiteral = !inLiteral;
/*     */           }
/*     */         }
/* 143 */         else if (c == ')')
/*     */         {
/* 145 */           nestParLevel++;
/*     */         }
/* 147 */         else if (c == '(')
/*     */         {
/* 149 */           nestParLevel--;
/*     */           
/* 151 */           if (nestParLevel < 0) {
/* 152 */             return null;
/*     */           }
/*     */           
/* 155 */           if (nestParLevel == 0)
/*     */           {
/* 157 */             if (i == 0) {
/* 158 */               return null;
/*     */             }
/*     */             
/* 161 */             String base = trimmedInput.substring(0, i);
/* 162 */             String parameters = trimmedInput.substring(i + 1, trimmedInput.length() - 1);
/*     */             
/* 164 */             Expression baseExpr = parseDefaultAsLiteral(base);
/* 165 */             if (baseExpr == null) {
/* 166 */               return null;
/*     */             }
/*     */             
/*     */ 
/* 170 */             ExpressionSequence parametersExprSeq = ExpressionSequenceUtils.internalParseExpressionSequence(parameters);
/* 171 */             if (parametersExprSeq == null) {
/* 172 */               return null;
/*     */             }
/*     */             
/* 175 */             return new MessageExpression(baseExpr, parametersExprSeq);
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 182 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 187 */     Expression baseExpr = parseDefaultAsLiteral(trimmedInput);
/* 188 */     if (baseExpr == null) {
/* 189 */       return null;
/*     */     }
/*     */     
/* 192 */     return new MessageExpression(baseExpr, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Expression parseDefaultAsLiteral(String input)
/*     */   {
/* 201 */     if (StringUtils.isEmptyOrWhitespace(input)) {
/* 202 */       return null;
/*     */     }
/*     */     
/* 205 */     Expression expr = Expression.parse(input);
/* 206 */     if (expr == null) {
/* 207 */       return Expression.parse(TextLiteralExpression.wrapStringIntoLiteral(input));
/*     */     }
/* 209 */     return expr;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static Object executeMessageExpression(IExpressionContext context, MessageExpression expression, StandardExpressionExecutionContext expContext)
/*     */   {
/* 220 */     if (logger.isTraceEnabled()) {
/* 221 */       logger.trace("[THYMELEAF][{}] Evaluating message: \"{}\"", TemplateEngine.threadIndex(), expression.getStringRepresentation());
/*     */     }
/*     */     
/* 224 */     if (!(context instanceof ITemplateContext))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 229 */       throw new TemplateProcessingException("Cannot evaluate expression \"" + expression + "\". Message externalization expressions can only be evaluated in a template-processing environment (as a part of an in-template expression) where processing context is an implementation of " + ITemplateContext.class.getClass() + ", which it isn't (" + context.getClass().getName() + ")");
/*     */     }
/*     */     
/* 232 */     ITemplateContext templateContext = (ITemplateContext)context;
/*     */     
/* 234 */     IStandardExpression baseExpression = expression.getBase();
/* 235 */     Object messageKey = baseExpression.execute(templateContext, expContext);
/* 236 */     messageKey = LiteralValue.unwrap(messageKey);
/* 237 */     if ((messageKey != null) && (!(messageKey instanceof String))) {
/* 238 */       messageKey = messageKey.toString();
/*     */     }
/* 240 */     if (StringUtils.isEmptyOrWhitespace((String)messageKey)) {
/* 241 */       throw new TemplateProcessingException("Message key for message resolution must be a non-null and non-empty String");
/*     */     }
/*     */     
/*     */ 
/*     */     Object[] messageParameters;
/*     */     
/* 247 */     if (expression.hasParameters())
/*     */     {
/* 249 */       ExpressionSequence parameterExpressionSequence = expression.getParameters();
/* 250 */       List<IStandardExpression> parameterExpressionValues = parameterExpressionSequence.getExpressions();
/* 251 */       int parameterExpressionValuesLen = parameterExpressionValues.size();
/*     */       
/* 253 */       Object[] messageParameters = new Object[parameterExpressionValuesLen];
/* 254 */       for (int i = 0; i < parameterExpressionValuesLen; i++) {
/* 255 */         IStandardExpression parameterExpression = (IStandardExpression)parameterExpressionValues.get(i);
/* 256 */         Object result = parameterExpression.execute(templateContext, expContext);
/* 257 */         messageParameters[i] = LiteralValue.unwrap(result);
/*     */       }
/*     */     }
/*     */     else {
/* 261 */       messageParameters = NO_PARAMETERS;
/*     */     }
/*     */     
/*     */ 
/* 265 */     return templateContext.getMessage(null, (String)messageKey, messageParameters, true);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\expression\MessageExpression.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */