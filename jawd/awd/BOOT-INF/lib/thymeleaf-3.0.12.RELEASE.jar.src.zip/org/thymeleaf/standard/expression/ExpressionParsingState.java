/*    */ package org.thymeleaf.standard.expression;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import org.thymeleaf.util.Validate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class ExpressionParsingState
/*    */   extends ArrayList<ExpressionParsingNode>
/*    */ {
/*    */   private static final long serialVersionUID = 3972191269638891028L;
/*    */   
/*    */   public void addNode(String semiParsedString)
/*    */   {
/* 46 */     Validate.notNull(semiParsedString, "String cannot be null");
/* 47 */     add(new ExpressionParsingNode(semiParsedString));
/*    */   }
/*    */   
/*    */   public void addNode(Expression parsedExpression) {
/* 51 */     Validate.notNull(parsedExpression, "Expression cannot be null");
/* 52 */     add(new ExpressionParsingNode(parsedExpression));
/*    */   }
/*    */   
/*    */   public void insertNode(int pos, String semiParsedString)
/*    */   {
/* 57 */     Validate.notNull(semiParsedString, "String cannot be null");
/* 58 */     add(pos, new ExpressionParsingNode(semiParsedString));
/*    */   }
/*    */   
/*    */   public void insertNode(int pos, Expression parsedExpression) {
/* 62 */     Validate.notNull(parsedExpression, "Expression cannot be null");
/* 63 */     add(pos, new ExpressionParsingNode(parsedExpression));
/*    */   }
/*    */   
/*    */   public void setNode(int pos, String semiParsedString) {
/* 67 */     Validate.notNull(semiParsedString, "String cannot be null");
/* 68 */     set(pos, new ExpressionParsingNode(semiParsedString));
/*    */   }
/*    */   
/*    */   public void setNode(int pos, Expression parsedExpression) {
/* 72 */     Validate.notNull(parsedExpression, "Expression cannot be null");
/* 73 */     set(pos, new ExpressionParsingNode(parsedExpression));
/*    */   }
/*    */   
/*    */   public boolean hasStringRoot()
/*    */   {
/* 78 */     return hasStringAt(0);
/*    */   }
/*    */   
/*    */   public boolean hasExpressionRoot() {
/* 82 */     return hasExpressionAt(0);
/*    */   }
/*    */   
/*    */   public boolean hasStringAt(int pos) {
/* 86 */     return (size() > pos) && (((ExpressionParsingNode)get(pos)).isInput());
/*    */   }
/*    */   
/*    */   public boolean hasExpressionAt(int pos) {
/* 90 */     return (size() > pos) && (((ExpressionParsingNode)get(pos)).isExpression());
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\expression\ExpressionParsingState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */