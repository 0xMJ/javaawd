/*     */ package org.thymeleaf.standard.expression;
/*     */ 
/*     */ import java.beans.BeanInfo;
/*     */ import java.beans.IntrospectionException;
/*     */ import java.beans.Introspector;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import ognl.ArrayPropertyAccessor;
/*     */ import ognl.EnumerationPropertyAccessor;
/*     */ import ognl.IteratorPropertyAccessor;
/*     */ import ognl.ListPropertyAccessor;
/*     */ import ognl.MapPropertyAccessor;
/*     */ import ognl.ObjectPropertyAccessor;
/*     */ import ognl.OgnlException;
/*     */ import ognl.OgnlRuntime;
/*     */ import ognl.PropertyAccessor;
/*     */ import ognl.SetPropertyAccessor;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.thymeleaf.IEngineConfiguration;
/*     */ import org.thymeleaf.TemplateEngine;
/*     */ import org.thymeleaf.cache.ExpressionCacheKey;
/*     */ import org.thymeleaf.cache.ICache;
/*     */ import org.thymeleaf.cache.ICacheManager;
/*     */ import org.thymeleaf.context.IContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class OGNLShortcutExpression
/*     */ {
/*  63 */   private static final Logger LOGGER = LoggerFactory.getLogger(OGNLShortcutExpression.class);
/*     */   
/*     */   private static final String EXPRESSION_CACHE_TYPE_OGNL_SHORTCUT = "ognlsc";
/*  66 */   private static final Object[] NO_PARAMS = new Object[0];
/*     */   
/*     */   private final String[] expressionLevels;
/*     */   
/*     */ 
/*     */   OGNLShortcutExpression(String[] expressionLevels)
/*     */   {
/*  73 */     this.expressionLevels = expressionLevels;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   Object evaluate(IEngineConfiguration configuration, Map<String, Object> context, Object root)
/*     */     throws Exception
/*     */   {
/*  81 */     ICacheManager cacheManager = configuration.getCacheManager();
/*  82 */     ICache<ExpressionCacheKey, Object> expressionCache = cacheManager == null ? null : cacheManager.getExpressionCache();
/*     */     
/*  84 */     Object target = root;
/*  85 */     for (String propertyName : this.expressionLevels)
/*     */     {
/*     */ 
/*  88 */       if (target == null) {
/*  89 */         throw new OgnlException("source is null for getProperty(null, \"" + propertyName + "\")");
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*  95 */       Class<?> targetClass = OgnlRuntime.getTargetClass(target);
/*  96 */       PropertyAccessor ognlPropertyAccessor = OgnlRuntime.getPropertyAccessor(targetClass);
/*     */       
/*     */ 
/*  99 */       if ((target instanceof Class))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 104 */         target = getObjectProperty(expressionCache, propertyName, target);
/*     */       }
/* 106 */       else if (OGNLContextPropertyAccessor.class.equals(ognlPropertyAccessor.getClass()))
/*     */       {
/* 108 */         target = getContextProperty(propertyName, context, target);
/*     */       }
/* 110 */       else if (ObjectPropertyAccessor.class.equals(ognlPropertyAccessor.getClass()))
/*     */       {
/* 112 */         target = getObjectProperty(expressionCache, propertyName, target);
/*     */       }
/* 114 */       else if (MapPropertyAccessor.class.equals(ognlPropertyAccessor.getClass()))
/*     */       {
/* 116 */         target = getMapProperty(propertyName, (Map)target);
/*     */       }
/* 118 */       else if (ListPropertyAccessor.class.equals(ognlPropertyAccessor.getClass()))
/*     */       {
/* 120 */         target = getListProperty(expressionCache, propertyName, (List)target);
/*     */       }
/* 122 */       else if (SetPropertyAccessor.class.equals(ognlPropertyAccessor.getClass()))
/*     */       {
/* 124 */         target = getSetProperty(expressionCache, propertyName, (Set)target);
/*     */       }
/* 126 */       else if (IteratorPropertyAccessor.class.equals(ognlPropertyAccessor.getClass()))
/*     */       {
/* 128 */         target = getIteratorProperty(expressionCache, propertyName, (Iterator)target);
/*     */       }
/* 130 */       else if (EnumerationPropertyAccessor.class.equals(ognlPropertyAccessor.getClass()))
/*     */       {
/* 132 */         target = getEnumerationProperty(expressionCache, propertyName, (Enumeration)target);
/*     */       }
/* 134 */       else if (ArrayPropertyAccessor.class.equals(ognlPropertyAccessor.getClass()))
/*     */       {
/* 136 */         target = getArrayProperty(expressionCache, propertyName, (Object[])target);
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/*     */ 
/* 142 */         throw new OGNLShortcutExpressionNotApplicableException();
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 147 */     return target;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Object getContextProperty(String propertyName, Map<String, Object> context, Object target)
/*     */     throws OgnlException
/*     */   {
/* 160 */     if (("param".equals(propertyName)) && (context != null) && 
/* 161 */       (context.containsKey("%RESTRICT_REQUEST_PARAMETERS%"))) {
/* 162 */       throw new OgnlException("Access to variable \"" + propertyName + "\" is forbidden in this context. Note some restrictions apply to variable access. For example, accessing request parameters is forbidden in preprocessing and unescaped expressions, and also in fragment inclusion specifications.");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 169 */     if ("execInfo".equals(propertyName)) {
/* 170 */       Object execInfoResult = checkExecInfo(propertyName, context);
/* 171 */       if (execInfoResult != null) {
/* 172 */         return execInfoResult;
/*     */       }
/*     */     }
/*     */     
/* 176 */     return ((IContext)target).getVariable(propertyName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   private static Object checkExecInfo(String propertyName, Map<String, Object> context)
/*     */   {
/* 196 */     if ("execInfo".equals(propertyName)) {
/* 197 */       LOGGER.warn("[THYMELEAF][{}] Found Thymeleaf Standard Expression containing a call to the context variable \"execInfo\" (e.g. \"${execInfo.templateName}\"), which has been deprecated. The Execution Info should be now accessed as an expression object instead (e.g. \"${#execInfo.templateName}\"). Deprecated use is still allowed, but will be removed in future versions of Thymeleaf.", 
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 203 */         TemplateEngine.threadIndex());
/* 204 */       return context.get("execInfo");
/*     */     }
/* 206 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Object getObjectProperty(ICache<ExpressionCacheKey, Object> expressionCache, String propertyName, Object target)
/*     */   {
/* 214 */     Class<?> currClass = OgnlRuntime.getTargetClass(target);
/* 215 */     ExpressionCacheKey cacheKey = computeMethodCacheKey(currClass, propertyName);
/*     */     
/* 217 */     Method readMethod = null;
/*     */     
/* 219 */     if (expressionCache != null) {
/* 220 */       readMethod = (Method)expressionCache.get(cacheKey);
/*     */     }
/*     */     
/* 223 */     if (readMethod == null)
/*     */     {
/*     */       try
/*     */       {
/* 227 */         beanInfo = Introspector.getBeanInfo(currClass);
/*     */       } catch (IntrospectionException e) {
/*     */         BeanInfo beanInfo;
/* 230 */         throw new OGNLShortcutExpressionNotApplicableException();
/*     */       }
/*     */       BeanInfo beanInfo;
/* 233 */       PropertyDescriptor[] propertyDescriptors = beanInfo.getPropertyDescriptors();
/* 234 */       if (propertyDescriptors != null) {
/* 235 */         for (PropertyDescriptor propertyDescriptor : propertyDescriptors) {
/* 236 */           if (propertyDescriptor.getName().equals(propertyName)) {
/* 237 */             readMethod = propertyDescriptor.getReadMethod();
/* 238 */             if ((readMethod == null) || (expressionCache == null)) break;
/* 239 */             expressionCache.put(cacheKey, readMethod); break;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 248 */     if (readMethod == null)
/*     */     {
/* 250 */       throw new OGNLShortcutExpressionNotApplicableException();
/*     */     }
/*     */     try
/*     */     {
/* 254 */       return readMethod.invoke(target, NO_PARAMS);
/*     */     }
/*     */     catch (IllegalAccessException e) {
/* 257 */       throw new OGNLShortcutExpressionNotApplicableException();
/*     */     }
/*     */     catch (InvocationTargetException e) {
/* 260 */       throw new OGNLShortcutExpressionNotApplicableException();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Object getMapProperty(String propertyName, Map<?, ?> map)
/*     */   {
/* 282 */     if (propertyName.equals("size")) {
/* 283 */       return Integer.valueOf(map.size());
/*     */     }
/* 285 */     if ((propertyName.equals("keys")) || (propertyName.equals("keySet"))) {
/* 286 */       return map.keySet();
/*     */     }
/* 288 */     if (propertyName.equals("values")) {
/* 289 */       return map.values();
/*     */     }
/* 291 */     if (propertyName.equals("isEmpty")) {
/* 292 */       return map.isEmpty() ? Boolean.TRUE : Boolean.FALSE;
/*     */     }
/* 294 */     return map.get(propertyName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Object getListProperty(ICache<ExpressionCacheKey, Object> expressionCache, String propertyName, List<?> list)
/*     */   {
/* 313 */     if (propertyName.equals("size")) {
/* 314 */       return Integer.valueOf(list.size());
/*     */     }
/* 316 */     if (propertyName.equals("iterator")) {
/* 317 */       return list.iterator();
/*     */     }
/* 319 */     if ((propertyName.equals("isEmpty")) || (propertyName.equals("empty"))) {
/* 320 */       return list.isEmpty() ? Boolean.TRUE : Boolean.FALSE;
/*     */     }
/*     */     
/*     */ 
/* 324 */     return getObjectProperty(expressionCache, propertyName, list);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Object getArrayProperty(ICache<ExpressionCacheKey, Object> expressionCache, String propertyName, Object[] array)
/*     */   {
/* 343 */     if (propertyName.equals("length")) {
/* 344 */       return Integer.valueOf(Array.getLength(array));
/*     */     }
/*     */     
/*     */ 
/* 348 */     return getObjectProperty(expressionCache, propertyName, array);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Object getEnumerationProperty(ICache<ExpressionCacheKey, Object> expressionCache, String propertyName, Enumeration enumeration)
/*     */   {
/* 363 */     if ((propertyName.equals("next")) || (propertyName.equals("nextElement"))) {
/* 364 */       return enumeration.nextElement();
/*     */     }
/* 366 */     if ((propertyName.equals("hasNext")) || (propertyName.equals("hasMoreElements"))) {
/* 367 */       return enumeration.hasMoreElements() ? Boolean.TRUE : Boolean.FALSE;
/*     */     }
/*     */     
/*     */ 
/* 371 */     return getObjectProperty(expressionCache, propertyName, enumeration);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Object getIteratorProperty(ICache<ExpressionCacheKey, Object> expressionCache, String propertyName, Iterator<?> iterator)
/*     */   {
/* 386 */     if (propertyName.equals("next")) {
/* 387 */       return iterator.next();
/*     */     }
/* 389 */     if (propertyName.equals("hasNext")) {
/* 390 */       return iterator.hasNext() ? Boolean.TRUE : Boolean.FALSE;
/*     */     }
/*     */     
/*     */ 
/* 394 */     return getObjectProperty(expressionCache, propertyName, iterator);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Object getSetProperty(ICache<ExpressionCacheKey, Object> expressionCache, String propertyName, Set<?> set)
/*     */   {
/* 409 */     if (propertyName.equals("size")) {
/* 410 */       return Integer.valueOf(set.size());
/*     */     }
/* 412 */     if (propertyName.equals("iterator")) {
/* 413 */       return set.iterator();
/*     */     }
/* 415 */     if (propertyName.equals("isEmpty")) {
/* 416 */       return set.isEmpty() ? Boolean.TRUE : Boolean.FALSE;
/*     */     }
/*     */     
/*     */ 
/* 420 */     return getObjectProperty(expressionCache, propertyName, set);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static String[] parse(String expression)
/*     */   {
/* 430 */     return doParseExpr(expression, 0, 0, expression.length());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static String[] doParseExpr(String expression, int level, int offset, int len)
/*     */   {
/* 437 */     int i = offset;
/* 438 */     boolean firstChar = true;
/*     */     
/* 440 */     while (i < len)
/*     */     {
/* 442 */       int codepoint = Character.codePointAt(expression, i);
/*     */       
/* 444 */       if (codepoint == 46) {
/*     */         break;
/*     */       }
/*     */       
/* 448 */       if (firstChar) {
/* 449 */         if (!Character.isJavaIdentifierStart(codepoint)) {
/* 450 */           return null;
/*     */         }
/* 452 */         firstChar = false;
/*     */       }
/* 454 */       else if (!Character.isJavaIdentifierPart(codepoint)) {
/* 455 */         return null;
/*     */       }
/*     */       
/*     */ 
/* 459 */       i++;
/*     */     }
/*     */     
/*     */     String[] result;
/*     */     
/* 464 */     if (i < len) {
/* 465 */       String[] result = doParseExpr(expression, level + 1, i + 1, len);
/* 466 */       if (result == null) {
/* 467 */         return null;
/*     */       }
/*     */     } else {
/* 470 */       result = new String[level + 1];
/*     */     }
/*     */     
/* 473 */     result[level] = expression.substring(offset, i);
/*     */     
/* 475 */     if (("true".equalsIgnoreCase(result[level])) || ("false".equalsIgnoreCase(result[level])) || ("null".equalsIgnoreCase(result[level]))) {
/* 476 */       return null;
/*     */     }
/*     */     
/* 479 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static ExpressionCacheKey computeMethodCacheKey(Class<?> targetClass, String propertyName)
/*     */   {
/* 486 */     return new ExpressionCacheKey("ognlsc", targetClass.getName(), propertyName);
/*     */   }
/*     */   
/*     */   static class OGNLShortcutExpressionNotApplicableException
/*     */     extends RuntimeException
/*     */   {}
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\expression\OGNLShortcutExpression.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */