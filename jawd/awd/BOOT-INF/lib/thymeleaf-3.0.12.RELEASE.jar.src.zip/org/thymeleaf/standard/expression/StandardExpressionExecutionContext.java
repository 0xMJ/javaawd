/*     */ package org.thymeleaf.standard.expression;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class StandardExpressionExecutionContext
/*     */ {
/*  42 */   public static final StandardExpressionExecutionContext RESTRICTED = new StandardExpressionExecutionContext(true, true, false, false);
/*     */   
/*  44 */   public static final StandardExpressionExecutionContext RESTRICTED_FORBID_UNSAFE_EXP_RESULTS = new StandardExpressionExecutionContext(true, true, true, false);
/*     */   
/*  46 */   public static final StandardExpressionExecutionContext NORMAL = new StandardExpressionExecutionContext(false, false, false, false);
/*     */   
/*     */ 
/*  49 */   private static final StandardExpressionExecutionContext RESTRICTED_WITH_TYPE_CONVERSION = new StandardExpressionExecutionContext(true, true, false, true);
/*     */   
/*  51 */   private static final StandardExpressionExecutionContext RESTRICTED_FORBID_UNSAFE_EXP_RESULTS_WITH_TYPE_CONVERSION = new StandardExpressionExecutionContext(true, true, true, true);
/*     */   
/*  53 */   private static final StandardExpressionExecutionContext NORMAL_WITH_TYPE_CONVERSION = new StandardExpressionExecutionContext(false, false, false, true);
/*     */   
/*     */ 
/*     */   private final boolean restrictVariableAccess;
/*     */   
/*     */ 
/*     */   private final boolean restrictInstantiationAndStatic;
/*     */   
/*     */   private final boolean forbidUnsafeExpressionResults;
/*     */   
/*     */   private final boolean performTypeConversion;
/*     */   
/*     */ 
/*     */   private StandardExpressionExecutionContext(boolean restrictVariableAccess, boolean restrictInstantiationAndStatic, boolean forbidUnsafeExpressionResults, boolean performTypeConversion)
/*     */   {
/*  68 */     this.restrictVariableAccess = restrictVariableAccess;
/*  69 */     this.restrictInstantiationAndStatic = restrictInstantiationAndStatic;
/*  70 */     this.forbidUnsafeExpressionResults = forbidUnsafeExpressionResults;
/*  71 */     this.performTypeConversion = performTypeConversion;
/*     */   }
/*     */   
/*     */   public boolean getRestrictVariableAccess() {
/*  75 */     return this.restrictVariableAccess;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getRestrictInstantiationAndStatic()
/*     */   {
/*  86 */     return this.restrictInstantiationAndStatic;
/*     */   }
/*     */   
/*     */   public boolean getForbidUnsafeExpressionResults() {
/*  90 */     return this.forbidUnsafeExpressionResults;
/*     */   }
/*     */   
/*     */   public boolean getPerformTypeConversion() {
/*  94 */     return this.performTypeConversion;
/*     */   }
/*     */   
/*     */   public StandardExpressionExecutionContext withoutTypeConversion() {
/*  98 */     if (!getPerformTypeConversion()) {
/*  99 */       return this;
/*     */     }
/* 101 */     if (this == NORMAL_WITH_TYPE_CONVERSION) {
/* 102 */       return NORMAL;
/*     */     }
/* 104 */     if (this == RESTRICTED_WITH_TYPE_CONVERSION) {
/* 105 */       return RESTRICTED;
/*     */     }
/* 107 */     if (this == RESTRICTED_FORBID_UNSAFE_EXP_RESULTS_WITH_TYPE_CONVERSION) {
/* 108 */       return RESTRICTED_FORBID_UNSAFE_EXP_RESULTS;
/*     */     }
/* 110 */     return new StandardExpressionExecutionContext(
/* 111 */       getRestrictVariableAccess(), getRestrictInstantiationAndStatic(), getForbidUnsafeExpressionResults(), false);
/*     */   }
/*     */   
/*     */   public StandardExpressionExecutionContext withTypeConversion() {
/* 115 */     if (getPerformTypeConversion()) {
/* 116 */       return this;
/*     */     }
/* 118 */     if (this == NORMAL) {
/* 119 */       return NORMAL_WITH_TYPE_CONVERSION;
/*     */     }
/* 121 */     if (this == RESTRICTED) {
/* 122 */       return RESTRICTED_WITH_TYPE_CONVERSION;
/*     */     }
/* 124 */     if (this == RESTRICTED_FORBID_UNSAFE_EXP_RESULTS) {
/* 125 */       return RESTRICTED_FORBID_UNSAFE_EXP_RESULTS_WITH_TYPE_CONVERSION;
/*     */     }
/* 127 */     return new StandardExpressionExecutionContext(
/* 128 */       getRestrictVariableAccess(), getRestrictInstantiationAndStatic(), getForbidUnsafeExpressionResults(), true);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\expression\StandardExpressionExecutionContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */