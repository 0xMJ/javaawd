/*    */ package org.thymeleaf.standard.processor;
/*    */ 
/*    */ import org.thymeleaf.context.ITemplateContext;
/*    */ import org.thymeleaf.engine.AttributeName;
/*    */ import org.thymeleaf.model.IProcessableElementTag;
/*    */ import org.thymeleaf.standard.expression.IStandardExpression;
/*    */ import org.thymeleaf.standard.expression.IStandardExpressionParser;
/*    */ import org.thymeleaf.standard.expression.StandardExpressions;
/*    */ import org.thymeleaf.templatemode.TemplateMode;
/*    */ import org.thymeleaf.util.EvaluationUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class StandardUnlessTagProcessor
/*    */   extends AbstractStandardConditionalVisibilityTagProcessor
/*    */ {
/*    */   public static final int PRECEDENCE = 400;
/*    */   public static final String ATTR_NAME = "unless";
/*    */   
/*    */   public StandardUnlessTagProcessor(TemplateMode templateMode, String dialectPrefix)
/*    */   {
/* 44 */     super(templateMode, dialectPrefix, "unless", 400);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected boolean isVisible(ITemplateContext context, IProcessableElementTag tag, AttributeName attributeName, String attributeValue)
/*    */   {
/* 55 */     IStandardExpressionParser expressionParser = StandardExpressions.getExpressionParser(context.getConfiguration());
/*    */     
/* 57 */     IStandardExpression expression = expressionParser.parseExpression(context, attributeValue);
/* 58 */     Object value = expression.execute(context);
/*    */     
/* 60 */     return !EvaluationUtils.evaluateAsBoolean(value);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\processor\StandardUnlessTagProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */