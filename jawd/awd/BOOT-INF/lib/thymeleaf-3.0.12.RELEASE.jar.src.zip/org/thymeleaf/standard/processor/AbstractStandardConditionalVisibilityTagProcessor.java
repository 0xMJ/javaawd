/*    */ package org.thymeleaf.standard.processor;
/*    */ 
/*    */ import org.thymeleaf.context.ITemplateContext;
/*    */ import org.thymeleaf.engine.AttributeName;
/*    */ import org.thymeleaf.model.IProcessableElementTag;
/*    */ import org.thymeleaf.processor.element.AbstractAttributeTagProcessor;
/*    */ import org.thymeleaf.processor.element.IElementTagStructureHandler;
/*    */ import org.thymeleaf.templatemode.TemplateMode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractStandardConditionalVisibilityTagProcessor
/*    */   extends AbstractAttributeTagProcessor
/*    */ {
/*    */   protected AbstractStandardConditionalVisibilityTagProcessor(TemplateMode templateMode, String dialectPrefix, String attrName, int precedence)
/*    */   {
/* 49 */     super(templateMode, dialectPrefix, null, false, attrName, true, precedence, true);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected final void doProcess(ITemplateContext context, IProcessableElementTag tag, AttributeName attributeName, String attributeValue, IElementTagStructureHandler structureHandler)
/*    */   {
/* 61 */     boolean visible = isVisible(context, tag, attributeName, attributeValue);
/*    */     
/* 63 */     if (!visible) {
/* 64 */       structureHandler.removeElement();
/*    */     }
/*    */   }
/*    */   
/*    */   protected abstract boolean isVisible(ITemplateContext paramITemplateContext, IProcessableElementTag paramIProcessableElementTag, AttributeName paramAttributeName, String paramString);
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\processor\AbstractStandardConditionalVisibilityTagProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */