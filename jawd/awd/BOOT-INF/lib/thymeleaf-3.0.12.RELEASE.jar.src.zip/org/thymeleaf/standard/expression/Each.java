/*    */ package org.thymeleaf.standard.expression;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.thymeleaf.util.Validate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Each
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = -4085690403057997591L;
/*    */   private final IStandardExpression iterVar;
/*    */   private final IStandardExpression statusVar;
/*    */   private final IStandardExpression iterable;
/*    */   
/*    */   public Each(IStandardExpression iterVar, IStandardExpression statusVar, IStandardExpression iterable)
/*    */   {
/* 49 */     Validate.notNull(iterVar, "Iteration variable cannot be null");
/* 50 */     Validate.notNull(iterable, "Iterable cannot be null");
/* 51 */     this.iterVar = iterVar;
/* 52 */     this.statusVar = statusVar;
/* 53 */     this.iterable = iterable;
/*    */   }
/*    */   
/*    */   public IStandardExpression getIterVar()
/*    */   {
/* 58 */     return this.iterVar;
/*    */   }
/*    */   
/*    */   public boolean hasStatusVar() {
/* 62 */     return this.statusVar != null;
/*    */   }
/*    */   
/*    */   public IStandardExpression getStatusVar() {
/* 66 */     return this.statusVar;
/*    */   }
/*    */   
/*    */   public IStandardExpression getIterable() {
/* 70 */     return this.iterable;
/*    */   }
/*    */   
/*    */   public String getStringRepresentation()
/*    */   {
/* 75 */     StringBuilder sb = new StringBuilder();
/* 76 */     sb.append(this.iterVar);
/* 77 */     if (hasStatusVar()) {
/* 78 */       sb.append(',');
/* 79 */       sb.append(this.statusVar);
/*    */     }
/* 81 */     sb.append(" : ");
/* 82 */     sb.append(this.iterable);
/* 83 */     return sb.toString();
/*    */   }
/*    */   
/*    */ 
/*    */   public String toString()
/*    */   {
/* 89 */     return getStringRepresentation();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\expression\Each.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */