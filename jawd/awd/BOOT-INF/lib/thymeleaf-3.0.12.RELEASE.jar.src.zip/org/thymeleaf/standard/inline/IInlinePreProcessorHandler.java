package org.thymeleaf.standard.inline;

public abstract interface IInlinePreProcessorHandler
{
  public abstract void handleText(char[] paramArrayOfChar, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public abstract void handleStandaloneElementStart(char[] paramArrayOfChar, int paramInt1, int paramInt2, boolean paramBoolean, int paramInt3, int paramInt4);
  
  public abstract void handleStandaloneElementEnd(char[] paramArrayOfChar, int paramInt1, int paramInt2, boolean paramBoolean, int paramInt3, int paramInt4);
  
  public abstract void handleOpenElementStart(char[] paramArrayOfChar, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public abstract void handleOpenElementEnd(char[] paramArrayOfChar, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public abstract void handleAutoOpenElementStart(char[] paramArrayOfChar, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public abstract void handleAutoOpenElementEnd(char[] paramArrayOfChar, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public abstract void handleCloseElementStart(char[] paramArrayOfChar, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public abstract void handleCloseElementEnd(char[] paramArrayOfChar, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public abstract void handleAutoCloseElementStart(char[] paramArrayOfChar, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public abstract void handleAutoCloseElementEnd(char[] paramArrayOfChar, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public abstract void handleAttribute(char[] paramArrayOfChar, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10, int paramInt11, int paramInt12, int paramInt13, int paramInt14);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\inline\IInlinePreProcessorHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */