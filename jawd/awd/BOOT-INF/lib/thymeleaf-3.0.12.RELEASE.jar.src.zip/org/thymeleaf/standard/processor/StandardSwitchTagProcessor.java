/*    */ package org.thymeleaf.standard.processor;
/*    */ 
/*    */ import org.thymeleaf.context.ITemplateContext;
/*    */ import org.thymeleaf.engine.AttributeName;
/*    */ import org.thymeleaf.model.IProcessableElementTag;
/*    */ import org.thymeleaf.processor.element.AbstractAttributeTagProcessor;
/*    */ import org.thymeleaf.processor.element.IElementTagStructureHandler;
/*    */ import org.thymeleaf.standard.expression.IStandardExpression;
/*    */ import org.thymeleaf.standard.expression.IStandardExpressionParser;
/*    */ import org.thymeleaf.standard.expression.StandardExpressions;
/*    */ import org.thymeleaf.templatemode.TemplateMode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class StandardSwitchTagProcessor
/*    */   extends AbstractAttributeTagProcessor
/*    */ {
/*    */   public static final int PRECEDENCE = 250;
/*    */   public static final String ATTR_NAME = "switch";
/*    */   public static final String SWITCH_VARIABLE_NAME = "%%SWITCH_EXPR%%";
/*    */   
/*    */   public StandardSwitchTagProcessor(TemplateMode templateMode, String dialectPrefix)
/*    */   {
/* 48 */     super(templateMode, dialectPrefix, null, false, "switch", true, 250, true);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected void doProcess(ITemplateContext context, IProcessableElementTag tag, AttributeName attributeName, String attributeValue, IElementTagStructureHandler structureHandler)
/*    */   {
/* 58 */     IStandardExpressionParser expressionParser = StandardExpressions.getExpressionParser(context.getConfiguration());
/*    */     
/*    */ 
/* 61 */     IStandardExpression switchExpression = expressionParser.parseExpression(context, attributeValue);
/*    */     
/* 63 */     structureHandler.setLocalVariable("%%SWITCH_EXPR%%", new SwitchStructure(switchExpression));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public static final class SwitchStructure
/*    */   {
/*    */     private final IStandardExpression expression;
/*    */     
/*    */     private boolean executed;
/*    */     
/*    */ 
/*    */     public SwitchStructure(IStandardExpression expression)
/*    */     {
/* 77 */       this.expression = expression;
/* 78 */       this.executed = false;
/*    */     }
/*    */     
/*    */     public IStandardExpression getExpression() {
/* 82 */       return this.expression;
/*    */     }
/*    */     
/*    */     public boolean isExecuted() {
/* 86 */       return this.executed;
/*    */     }
/*    */     
/*    */     public void setExecuted(boolean executed) {
/* 90 */       this.executed = executed;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\processor\StandardSwitchTagProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */