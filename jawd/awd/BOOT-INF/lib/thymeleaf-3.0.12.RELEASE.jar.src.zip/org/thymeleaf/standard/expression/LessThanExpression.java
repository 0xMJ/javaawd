/*     */ package org.thymeleaf.standard.expression;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.thymeleaf.TemplateEngine;
/*     */ import org.thymeleaf.context.IExpressionContext;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.util.EvaluationUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class LessThanExpression
/*     */   extends GreaterLesserExpression
/*     */ {
/*     */   private static final long serialVersionUID = 6097188129113613164L;
/*  51 */   private static final Logger logger = LoggerFactory.getLogger(LessThanExpression.class);
/*     */   
/*     */   public LessThanExpression(IStandardExpression left, IStandardExpression right)
/*     */   {
/*  55 */     super(left, right);
/*     */   }
/*     */   
/*     */ 
/*     */   public String getStringRepresentation()
/*     */   {
/*  61 */     return getStringRepresentation("<");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static Object executeLessThan(IExpressionContext context, LessThanExpression expression, StandardExpressionExecutionContext expContext)
/*     */   {
/*  74 */     if (logger.isTraceEnabled()) {
/*  75 */       logger.trace("[THYMELEAF][{}] Evaluating LESS THAN expression: \"{}\"", TemplateEngine.threadIndex(), expression.getStringRepresentation());
/*     */     }
/*     */     
/*  78 */     Object leftValue = expression.getLeft().execute(context, expContext);
/*  79 */     Object rightValue = expression.getRight().execute(context, expContext);
/*     */     
/*  81 */     if ((leftValue == null) || (rightValue == null))
/*     */     {
/*  83 */       throw new TemplateProcessingException("Cannot execute LESS THAN comparison: operands are \"" + LiteralValue.unwrap(leftValue) + "\" and \"" + LiteralValue.unwrap(rightValue) + "\"");
/*     */     }
/*     */     
/*  86 */     leftValue = LiteralValue.unwrap(leftValue);
/*  87 */     rightValue = LiteralValue.unwrap(rightValue);
/*     */     
/*  89 */     Boolean result = null;
/*     */     
/*  91 */     BigDecimal leftNumberValue = EvaluationUtils.evaluateAsNumber(leftValue);
/*  92 */     BigDecimal rightNumberValue = EvaluationUtils.evaluateAsNumber(rightValue);
/*     */     
/*  94 */     if ((leftNumberValue != null) && (rightNumberValue != null)) {
/*  95 */       result = Boolean.valueOf(leftNumberValue.compareTo(rightNumberValue) == -1);
/*     */     }
/*  97 */     else if ((leftValue != null) && (rightValue != null) && 
/*  98 */       (leftValue.getClass().equals(rightValue.getClass())) && 
/*  99 */       (Comparable.class.isAssignableFrom(leftValue.getClass()))) {
/* 100 */       result = Boolean.valueOf(((Comparable)leftValue).compareTo(rightValue) < 0);
/*     */     }
/*     */     else
/*     */     {
/* 104 */       throw new TemplateProcessingException("Cannot execute LESS THAN from Expression \"" + expression.getStringRepresentation() + "\". Left is \"" + leftValue + "\", right is \"" + rightValue + "\"");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 109 */     if (logger.isTraceEnabled()) {
/* 110 */       logger.trace("[THYMELEAF][{}] Evaluating LESS THAN expression: \"{}\". Left is \"{}\", right is \"{}\". Result is \"{}\"", new Object[] {
/* 111 */         TemplateEngine.threadIndex(), expression.getStringRepresentation(), leftValue, rightValue, result });
/*     */     }
/*     */     
/* 114 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\expression\LessThanExpression.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */