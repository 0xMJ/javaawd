/*    */ package org.thymeleaf.standard.processor;
/*    */ 
/*    */ import org.thymeleaf.context.ITemplateContext;
/*    */ import org.thymeleaf.engine.AttributeDefinition;
/*    */ import org.thymeleaf.engine.AttributeDefinitions;
/*    */ import org.thymeleaf.engine.AttributeName;
/*    */ import org.thymeleaf.engine.IAttributeDefinitionsAware;
/*    */ import org.thymeleaf.model.IProcessableElementTag;
/*    */ import org.thymeleaf.processor.element.IElementTagStructureHandler;
/*    */ import org.thymeleaf.standard.util.StandardProcessorUtils;
/*    */ import org.thymeleaf.templatemode.TemplateMode;
/*    */ import org.thymeleaf.util.EvaluationUtils;
/*    */ import org.thymeleaf.util.Validate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class StandardConditionalFixedValueTagProcessor
/*    */   extends AbstractStandardExpressionAttributeTagProcessor
/*    */   implements IAttributeDefinitionsAware
/*    */ {
/*    */   public static final int PRECEDENCE = 1000;
/* 48 */   public static final String[] ATTR_NAMES = { "async", "autofocus", "autoplay", "checked", "controls", "declare", "default", "defer", "disabled", "formnovalidate", "hidden", "ismap", "loop", "multiple", "novalidate", "nowrap", "open", "pubdate", "readonly", "required", "reversed", "selected", "scoped", "seamless" };
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 57 */   private static final TemplateMode TEMPLATE_MODE = TemplateMode.HTML;
/*    */   
/*    */ 
/*    */   private final String targetAttributeCompleteName;
/*    */   
/*    */ 
/*    */   private AttributeDefinition targetAttributeDefinition;
/*    */   
/*    */ 
/*    */   public StandardConditionalFixedValueTagProcessor(String dialectPrefix, String attrName)
/*    */   {
/* 68 */     super(TEMPLATE_MODE, dialectPrefix, attrName, 1000, true, false);
/*    */     
/*    */ 
/* 71 */     this.targetAttributeCompleteName = attrName;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setAttributeDefinitions(AttributeDefinitions attributeDefinitions)
/*    */   {
/* 79 */     Validate.notNull(attributeDefinitions, "Attribute Definitions cannot be null");
/*    */     
/*    */ 
/* 82 */     this.targetAttributeDefinition = attributeDefinitions.forName(TEMPLATE_MODE, this.targetAttributeCompleteName);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected final void doProcess(ITemplateContext context, IProcessableElementTag tag, AttributeName attributeName, String attributeValue, Object expressionResult, IElementTagStructureHandler structureHandler)
/*    */   {
/* 96 */     if (EvaluationUtils.evaluateAsBoolean(expressionResult)) {
/* 97 */       StandardProcessorUtils.setAttribute(structureHandler, this.targetAttributeDefinition, this.targetAttributeCompleteName, this.targetAttributeCompleteName);
/*    */     } else {
/* 99 */       structureHandler.removeAttribute(this.targetAttributeDefinition.getAttributeName());
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\processor\StandardConditionalFixedValueTagProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */