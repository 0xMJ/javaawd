/*     */ package org.thymeleaf.standard.serializer;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonFactory;
/*     */ import com.fasterxml.jackson.core.JsonGenerator.Feature;
/*     */ import com.fasterxml.jackson.core.SerializableString;
/*     */ import com.fasterxml.jackson.core.io.CharacterEscapes;
/*     */ import com.fasterxml.jackson.core.io.SerializedString;
/*     */ import com.fasterxml.jackson.databind.Module;
/*     */ import com.fasterxml.jackson.databind.ObjectMapper;
/*     */ import com.fasterxml.jackson.databind.SerializationFeature;
/*     */ import java.beans.BeanInfo;
/*     */ import java.beans.IntrospectionException;
/*     */ import java.beans.Introspector;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.text.DateFormat;
/*     */ import java.text.FieldPosition;
/*     */ import java.text.ParsePosition;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Calendar;
/*     */ import java.util.Collection;
/*     */ import java.util.Date;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.thymeleaf.exceptions.ConfigurationException;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.util.ClassLoaderUtils;
/*     */ import org.thymeleaf.util.DateUtils;
/*     */ import org.unbescape.json.JsonEscape;
/*     */ import org.unbescape.json.JsonEscapeLevel;
/*     */ import org.unbescape.json.JsonEscapeType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class StandardJavaScriptSerializer
/*     */   implements IStandardJavaScriptSerializer
/*     */ {
/*  83 */   private static final Logger logger = LoggerFactory.getLogger(StandardJavaScriptSerializer.class);
/*     */   
/*     */ 
/*     */   private final IStandardJavaScriptSerializer delegate;
/*     */   
/*     */ 
/*     */ 
/*     */   private String computeJacksonPackageNameIfPresent()
/*     */   {
/*     */     try
/*     */     {
/*  94 */       Class<?> objectMapperClass = ObjectMapper.class;
/*  95 */       String objectMapperPackageName = objectMapperClass.getPackage().getName();
/*  96 */       return objectMapperPackageName.substring(0, objectMapperPackageName.length() - ".databind".length());
/*     */     }
/*     */     catch (Throwable ignored) {}
/*  99 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public StandardJavaScriptSerializer(boolean useJacksonIfAvailable)
/*     */   {
/* 109 */     IStandardJavaScriptSerializer newDelegate = null;
/*     */     
/* 111 */     String jacksonPrefix = useJacksonIfAvailable ? computeJacksonPackageNameIfPresent() : null;
/*     */     
/* 113 */     if (jacksonPrefix != null)
/*     */     {
/*     */       try
/*     */       {
/* 117 */         newDelegate = new JacksonStandardJavaScriptSerializer(jacksonPrefix);
/*     */       }
/*     */       catch (Exception e) {
/* 120 */         handleErrorLoggingOnJacksonInitialization(e);
/*     */       } catch (NoSuchMethodError e) {
/* 122 */         handleErrorLoggingOnJacksonInitialization(e);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 127 */     if (newDelegate == null)
/*     */     {
/* 129 */       newDelegate = new DefaultStandardJavaScriptSerializer(null);
/*     */     }
/*     */     
/* 132 */     this.delegate = newDelegate;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void serializeValue(Object object, Writer writer)
/*     */   {
/* 139 */     this.delegate.serializeValue(object, writer);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final class JacksonStandardJavaScriptSerializer
/*     */     implements IStandardJavaScriptSerializer
/*     */   {
/*     */     private final ObjectMapper mapper;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     JacksonStandardJavaScriptSerializer(String jacksonPrefix)
/*     */     {
/* 157 */       this.mapper = new ObjectMapper();
/* 158 */       this.mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
/* 159 */       this.mapper.disable(new JsonGenerator.Feature[] { JsonGenerator.Feature.AUTO_CLOSE_TARGET });
/* 160 */       this.mapper.enable(new JsonGenerator.Feature[] { JsonGenerator.Feature.ESCAPE_NON_ASCII });
/* 161 */       this.mapper.getFactory().setCharacterEscapes(new StandardJavaScriptSerializer.JacksonThymeleafCharacterEscapes());
/* 162 */       this.mapper.setDateFormat(new StandardJavaScriptSerializer.JacksonThymeleafISO8601DateFormat());
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 169 */       Class<?> javaTimeModuleClass = ClassLoaderUtils.findClass(jacksonPrefix + ".datatype.jsr310.JavaTimeModule");
/* 170 */       if (javaTimeModuleClass != null) {
/*     */         try
/*     */         {
/* 173 */           this.mapper.registerModule((Module)javaTimeModuleClass.newInstance());
/* 174 */           this.mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
/*     */         } catch (InstantiationException e) {
/* 176 */           throw new ConfigurationException("Exception while trying to initialize JSR310 support for Jackson", e);
/*     */         } catch (IllegalAccessException e) {
/* 178 */           throw new ConfigurationException("Exception while trying to initialize JSR310 support for Jackson", e);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     public void serializeValue(Object object, Writer writer)
/*     */     {
/*     */       try
/*     */       {
/* 187 */         this.mapper.writeValue(writer, object);
/*     */       } catch (IOException e) {
/* 189 */         throw new TemplateProcessingException("An exception was raised while trying to serialize object to JavaScript using Jackson", e);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final class JacksonThymeleafISO8601DateFormat
/*     */     extends DateFormat
/*     */   {
/*     */     private static final long serialVersionUID = 1354081220093875129L;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private SimpleDateFormat dateFormat;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     JacksonThymeleafISO8601DateFormat()
/*     */     {
/* 230 */       this.dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZZZ");
/* 231 */       setCalendar(this.dateFormat.getCalendar());
/* 232 */       setNumberFormat(this.dateFormat.getNumberFormat());
/*     */     }
/*     */     
/*     */ 
/*     */     public StringBuffer format(Date date, StringBuffer toAppendTo, FieldPosition fieldPosition)
/*     */     {
/* 238 */       StringBuffer formatted = this.dateFormat.format(date, toAppendTo, fieldPosition);
/* 239 */       formatted.insert(26, ':');
/* 240 */       return formatted;
/*     */     }
/*     */     
/*     */ 
/*     */     public Date parse(String source, ParsePosition pos)
/*     */     {
/* 246 */       throw new UnsupportedOperationException("JacksonThymeleafISO8601DateFormat should never be asked for a 'parse' operation");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public Object clone()
/*     */     {
/* 253 */       JacksonThymeleafISO8601DateFormat other = (JacksonThymeleafISO8601DateFormat)super.clone();
/* 254 */       other.dateFormat = ((SimpleDateFormat)this.dateFormat.clone());
/* 255 */       return other;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final class JacksonThymeleafCharacterEscapes
/*     */     extends CharacterEscapes
/*     */   {
/* 286 */     private static final int[] CHARACTER_ESCAPES = ;
/* 287 */     static { CHARACTER_ESCAPES[47] = -2;
/* 288 */       CHARACTER_ESCAPES[38] = -2; }
/*     */     
/* 290 */     private static final SerializableString SLASH_ESCAPE = new SerializedString("\\/");
/* 291 */     private static final SerializableString AMPERSAND_ESCAPE = new SerializedString("\\u0026");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public int[] getEscapeCodesForAscii()
/*     */     {
/* 301 */       return CHARACTER_ESCAPES;
/*     */     }
/*     */     
/*     */     public SerializableString getEscapeSequence(int ch)
/*     */     {
/* 306 */       if (ch == 47) {
/* 307 */         return SLASH_ESCAPE;
/*     */       }
/* 309 */       if (ch == 38) {
/* 310 */         return AMPERSAND_ESCAPE;
/*     */       }
/* 312 */       return null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static final class DefaultStandardJavaScriptSerializer
/*     */     implements IStandardJavaScriptSerializer
/*     */   {
/*     */     public void serializeValue(Object object, Writer writer)
/*     */     {
/*     */       try
/*     */       {
/* 325 */         writeValue(writer, object);
/*     */       } catch (IOException e) {
/* 327 */         throw new TemplateProcessingException("An exception was raised while trying to serialize object to JavaScript using the default serializer", e);
/*     */       }
/*     */     }
/*     */     
/*     */     private static void writeValue(Writer writer, Object object)
/*     */       throws IOException
/*     */     {
/* 334 */       if (object == null) {
/* 335 */         writeNull(writer);
/* 336 */         return;
/*     */       }
/* 338 */       if ((object instanceof CharSequence)) {
/* 339 */         writeString(writer, object.toString());
/* 340 */         return;
/*     */       }
/* 342 */       if ((object instanceof Character)) {
/* 343 */         writeString(writer, object.toString());
/* 344 */         return;
/*     */       }
/* 346 */       if ((object instanceof Number)) {
/* 347 */         writeNumber(writer, (Number)object);
/* 348 */         return;
/*     */       }
/* 350 */       if ((object instanceof Boolean)) {
/* 351 */         writeBoolean(writer, (Boolean)object);
/* 352 */         return;
/*     */       }
/* 354 */       if ((object instanceof Date)) {
/* 355 */         writeDate(writer, (Date)object);
/* 356 */         return;
/*     */       }
/* 358 */       if ((object instanceof Calendar)) {
/* 359 */         writeDate(writer, ((Calendar)object).getTime());
/* 360 */         return;
/*     */       }
/* 362 */       if (object.getClass().isArray()) {
/* 363 */         writeArray(writer, object);
/* 364 */         return;
/*     */       }
/* 366 */       if ((object instanceof Collection)) {
/* 367 */         writeCollection(writer, (Collection)object);
/* 368 */         return;
/*     */       }
/* 370 */       if ((object instanceof Map)) {
/* 371 */         writeMap(writer, (Map)object);
/* 372 */         return;
/*     */       }
/* 374 */       if ((object instanceof Enum)) {
/* 375 */         writeEnum(writer, object);
/* 376 */         return;
/*     */       }
/* 378 */       writeObject(writer, object);
/*     */     }
/*     */     
/*     */     private static void writeNull(Writer writer) throws IOException
/*     */     {
/* 383 */       writer.write("null");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private static void writeString(Writer writer, String str)
/*     */       throws IOException
/*     */     {
/* 394 */       writer.write(34);
/* 395 */       writer.write(JsonEscape.escapeJson(str, JsonEscapeType.SINGLE_ESCAPE_CHARS_DEFAULT_TO_UHEXA, JsonEscapeLevel.LEVEL_2_ALL_NON_ASCII_PLUS_BASIC_ESCAPE_SET));
/* 396 */       writer.write(34);
/*     */     }
/*     */     
/*     */     private static void writeNumber(Writer writer, Number number) throws IOException
/*     */     {
/* 401 */       writer.write(number.toString());
/*     */     }
/*     */     
/*     */     private static void writeBoolean(Writer writer, Boolean bool) throws IOException
/*     */     {
/* 406 */       writer.write(bool.toString());
/*     */     }
/*     */     
/*     */     private static void writeDate(Writer writer, Date date) throws IOException
/*     */     {
/* 411 */       writer.write(34);
/* 412 */       writer.write(DateUtils.formatISO(date));
/* 413 */       writer.write(34);
/*     */     }
/*     */     
/*     */     private static void writeArray(Writer writer, Object arrayObj) throws IOException
/*     */     {
/* 418 */       writer.write(91);
/* 419 */       if ((arrayObj instanceof Object[])) {
/* 420 */         Object[] array = (Object[])arrayObj;
/* 421 */         boolean first = true;
/* 422 */         for (Object element : array) {
/* 423 */           if (first) {
/* 424 */             first = false;
/*     */           } else {
/* 426 */             writer.write(44);
/*     */           }
/* 428 */           writeValue(writer, element);
/*     */         }
/* 430 */       } else if ((arrayObj instanceof boolean[])) {
/* 431 */         boolean[] array = (boolean[])arrayObj;
/* 432 */         boolean first = true;
/* 433 */         for (boolean element : array) {
/* 434 */           if (first) {
/* 435 */             first = false;
/*     */           } else {
/* 437 */             writer.write(44);
/*     */           }
/* 439 */           writeValue(writer, Boolean.valueOf(element));
/*     */         }
/* 441 */       } else if ((arrayObj instanceof byte[])) {
/* 442 */         byte[] array = (byte[])arrayObj;
/* 443 */         boolean first = true;
/* 444 */         for (byte element : array) {
/* 445 */           if (first) {
/* 446 */             first = false;
/*     */           } else {
/* 448 */             writer.write(44);
/*     */           }
/* 450 */           writeValue(writer, Byte.valueOf(element));
/*     */         }
/* 452 */       } else if ((arrayObj instanceof short[])) {
/* 453 */         short[] array = (short[])arrayObj;
/* 454 */         boolean first = true;
/* 455 */         for (short element : array) {
/* 456 */           if (first) {
/* 457 */             first = false;
/*     */           } else {
/* 459 */             writer.write(44);
/*     */           }
/* 461 */           writeValue(writer, Short.valueOf(element));
/*     */         }
/* 463 */       } else if ((arrayObj instanceof int[])) {
/* 464 */         int[] array = (int[])arrayObj;
/* 465 */         boolean first = true;
/* 466 */         for (int element : array) {
/* 467 */           if (first) {
/* 468 */             first = false;
/*     */           } else {
/* 470 */             writer.write(44);
/*     */           }
/* 472 */           writeValue(writer, Integer.valueOf(element));
/*     */         }
/* 474 */       } else if ((arrayObj instanceof long[])) {
/* 475 */         long[] array = (long[])arrayObj;
/* 476 */         boolean first = true;
/* 477 */         for (long element : array) {
/* 478 */           if (first) {
/* 479 */             first = false;
/*     */           } else {
/* 481 */             writer.write(44);
/*     */           }
/* 483 */           writeValue(writer, Long.valueOf(element));
/*     */         }
/* 485 */       } else if ((arrayObj instanceof float[])) {
/* 486 */         float[] array = (float[])arrayObj;
/* 487 */         boolean first = true;
/* 488 */         for (float element : array) {
/* 489 */           if (first) {
/* 490 */             first = false;
/*     */           } else {
/* 492 */             writer.write(44);
/*     */           }
/* 494 */           writeValue(writer, Float.valueOf(element));
/*     */         }
/* 496 */       } else if ((arrayObj instanceof double[])) {
/* 497 */         double[] array = (double[])arrayObj;
/* 498 */         boolean first = true;
/* 499 */         for (double element : array) {
/* 500 */           if (first) {
/* 501 */             first = false;
/*     */           } else {
/* 503 */             writer.write(44);
/*     */           }
/* 505 */           writeValue(writer, Double.valueOf(element));
/*     */         }
/*     */       } else {
/* 508 */         throw new IllegalArgumentException("Cannot write value \"" + arrayObj + "\" of class " + arrayObj.getClass().getName() + " as an array");
/*     */       }
/* 510 */       writer.write(93);
/*     */     }
/*     */     
/*     */     private static void writeCollection(Writer writer, Collection<?> collection) throws IOException
/*     */     {
/* 515 */       writer.write(91);
/* 516 */       boolean first = true;
/* 517 */       for (Object element : collection) {
/* 518 */         if (first) {
/* 519 */           first = false;
/*     */         } else {
/* 521 */           writer.write(44);
/*     */         }
/* 523 */         writeValue(writer, element);
/*     */       }
/* 525 */       writer.write(93);
/*     */     }
/*     */     
/*     */     private static void writeMap(Writer writer, Map<?, ?> map) throws IOException
/*     */     {
/* 530 */       writer.write(123);
/* 531 */       boolean first = true;
/* 532 */       for (Map.Entry<?, ?> entry : map.entrySet()) {
/* 533 */         if (first) {
/* 534 */           first = false;
/*     */         } else {
/* 536 */           writer.write(44);
/*     */         }
/* 538 */         writeKeyValue(writer, entry.getKey(), entry.getValue());
/*     */       }
/* 540 */       writer.write(125);
/*     */     }
/*     */     
/*     */     private static void writeKeyValue(Writer writer, Object key, Object value) throws IOException
/*     */     {
/* 545 */       writeValue(writer, key);
/* 546 */       writer.write(58);
/* 547 */       writeValue(writer, value);
/*     */     }
/*     */     
/*     */     private static void writeObject(Writer writer, Object object) throws IOException
/*     */     {
/*     */       try
/*     */       {
/* 554 */         PropertyDescriptor[] descriptors = Introspector.getBeanInfo(object.getClass()).getPropertyDescriptors();
/* 555 */         Map<String, Object> properties = new LinkedHashMap(descriptors.length + 1, 1.0F);
/* 556 */         for (PropertyDescriptor descriptor : descriptors) {
/* 557 */           Method readMethod = descriptor.getReadMethod();
/* 558 */           if (readMethod != null) {
/* 559 */             String name = descriptor.getName();
/* 560 */             if (!"class".equals(name.toLowerCase())) {
/* 561 */               Object value = readMethod.invoke(object, new Object[0]);
/* 562 */               properties.put(name, value);
/*     */             }
/*     */           }
/*     */         }
/* 566 */         writeMap(writer, properties);
/*     */       } catch (IllegalAccessException e) {
/* 568 */         throw new IllegalArgumentException("Could not perform introspection on object of class " + object.getClass().getName(), e);
/*     */       } catch (InvocationTargetException e) {
/* 570 */         throw new IllegalArgumentException("Could not perform introspection on object of class " + object.getClass().getName(), e);
/*     */       } catch (IntrospectionException e) {
/* 572 */         throw new IllegalArgumentException("Could not perform introspection on object of class " + object.getClass().getName(), e);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */     private static void writeEnum(Writer writer, Object object)
/*     */       throws IOException
/*     */     {
/* 580 */       Enum<?> enumObject = (Enum)object;
/* 581 */       writeString(writer, enumObject.toString());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void handleErrorLoggingOnJacksonInitialization(Throwable e)
/*     */   {
/* 589 */     String warningMessage = "[THYMELEAF] Could not initialize Jackson-based serializer even if the Jackson library was detected to be present at the classpath. Please make sure you are adding the jackson-databind module to your classpath, and that version is >= 2.5.0. THYMELEAF INITIALIZATION WILL CONTINUE, but Jackson will not be used for JavaScript serialization.";
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 596 */     if (logger.isDebugEnabled()) {
/* 597 */       logger.warn("[THYMELEAF] Could not initialize Jackson-based serializer even if the Jackson library was detected to be present at the classpath. Please make sure you are adding the jackson-databind module to your classpath, and that version is >= 2.5.0. THYMELEAF INITIALIZATION WILL CONTINUE, but Jackson will not be used for JavaScript serialization.", e);
/*     */     }
/*     */     else {
/* 600 */       logger.warn("[THYMELEAF] Could not initialize Jackson-based serializer even if the Jackson library was detected to be present at the classpath. Please make sure you are adding the jackson-databind module to your classpath, and that version is >= 2.5.0. THYMELEAF INITIALIZATION WILL CONTINUE, but Jackson will not be used for JavaScript serialization. Set the log to DEBUG to see a complete exception trace. Exception message is: " + e
/*     */       
/* 602 */         .getMessage());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\serializer\StandardJavaScriptSerializer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */