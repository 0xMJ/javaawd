/*     */ package org.thymeleaf.standard.inline;
/*     */ 
/*     */ import java.io.Writer;
/*     */ import java.util.Set;
/*     */ import org.thymeleaf.IEngineConfiguration;
/*     */ import org.thymeleaf.context.ITemplateContext;
/*     */ import org.thymeleaf.engine.EngineEventUtils;
/*     */ import org.thymeleaf.engine.TemplateManager;
/*     */ import org.thymeleaf.engine.TemplateModel;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.inline.IInliner;
/*     */ import org.thymeleaf.model.ICDATASection;
/*     */ import org.thymeleaf.model.IComment;
/*     */ import org.thymeleaf.model.IText;
/*     */ import org.thymeleaf.postprocessor.IPostProcessor;
/*     */ import org.thymeleaf.processor.text.ITextProcessor;
/*     */ import org.thymeleaf.standard.expression.IStandardExpression;
/*     */ import org.thymeleaf.standard.expression.IStandardExpressionParser;
/*     */ import org.thymeleaf.standard.expression.StandardExpressions;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ import org.thymeleaf.util.EscapedAttributeUtils;
/*     */ import org.thymeleaf.util.FastStringWriter;
/*     */ import org.thymeleaf.util.LazyProcessingCharSequence;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractStandardInliner
/*     */   implements IInliner
/*     */ {
/*     */   private final TemplateMode templateMode;
/*     */   private final boolean writeTextsToOutput;
/*     */   
/*     */   protected AbstractStandardInliner(IEngineConfiguration configuration, TemplateMode templateMode)
/*     */   {
/*  64 */     Validate.notNull(configuration, "Engine configuration cannot be null");
/*  65 */     Validate.notNull(templateMode, "Template Mode cannot be null");
/*     */     
/*  67 */     this.templateMode = templateMode;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  89 */     Set<IPostProcessor> postProcessors = configuration.getPostProcessors(this.templateMode);
/*  90 */     Set<ITextProcessor> textProcessors = configuration.getTextProcessors(this.templateMode);
/*  91 */     this.writeTextsToOutput = ((postProcessors.isEmpty()) && (textProcessors.size() <= 1));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final String getName()
/*     */   {
/*  98 */     return getClass().getSimpleName();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final CharSequence inline(ITemplateContext context, IText text)
/*     */   {
/* 106 */     Validate.notNull(context, "Context cannot be null");
/* 107 */     Validate.notNull(text, "Text cannot be null");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 113 */     if (context.getTemplateMode() != this.templateMode) {
/* 114 */       return inlineSwitchTemplateMode(context, text);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 121 */     if (!EngineEventUtils.isInlineable(text)) {
/* 122 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 138 */     int textLen = text.length();
/* 139 */     StringBuilder strBuilder = new StringBuilder(textLen + textLen / 2);
/*     */     
/* 141 */     performInlining(context, text, 0, textLen, text.getTemplateName(), text.getLine(), text.getCol(), strBuilder);
/*     */     
/* 143 */     return strBuilder.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private CharSequence inlineSwitchTemplateMode(ITemplateContext context, IText text)
/*     */   {
/* 150 */     TemplateManager templateManager = context.getConfiguration().getTemplateManager();
/*     */     
/*     */ 
/* 153 */     TemplateModel templateModel = templateManager.parseString(context
/* 154 */       .getTemplateData(), text.getText(), text
/* 155 */       .getLine(), text.getCol(), this.templateMode, true);
/*     */     
/*     */ 
/* 158 */     if (!this.writeTextsToOutput) {
/* 159 */       Writer stringWriter = new FastStringWriter(50);
/* 160 */       templateManager.process(templateModel, context, stringWriter);
/* 161 */       return stringWriter.toString();
/*     */     }
/*     */     
/*     */ 
/* 165 */     return new LazyProcessingCharSequence(context, templateModel);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final CharSequence inline(ITemplateContext context, ICDATASection cdataSection)
/*     */   {
/* 175 */     Validate.notNull(context, "Context cannot be null");
/* 176 */     Validate.notNull(cdataSection, "CDATA Section cannot be null");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 182 */     if (context.getTemplateMode() != this.templateMode) {
/* 183 */       return inlineSwitchTemplateMode(context, cdataSection);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 190 */     if (!EngineEventUtils.isInlineable(cdataSection)) {
/* 191 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 207 */     int cdataSectionLen = cdataSection.length();
/* 208 */     StringBuilder strBuilder = new StringBuilder(cdataSectionLen + cdataSectionLen / 2);
/*     */     
/* 210 */     performInlining(context, cdataSection, 9, cdataSectionLen - 12, cdataSection.getTemplateName(), cdataSection.getLine(), cdataSection.getCol(), strBuilder);
/*     */     
/* 212 */     return strBuilder.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private CharSequence inlineSwitchTemplateMode(ITemplateContext context, ICDATASection cdataSection)
/*     */   {
/* 219 */     TemplateManager templateManager = context.getConfiguration().getTemplateManager();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 231 */     TemplateModel templateModel = templateManager.parseString(context
/* 232 */       .getTemplateData(), cdataSection.getContent(), cdataSection
/* 233 */       .getLine(), cdataSection.getCol() + 9, this.templateMode, true);
/*     */     
/*     */ 
/* 236 */     Writer stringWriter = new FastStringWriter(50);
/* 237 */     templateManager.process(templateModel, context, stringWriter);
/*     */     
/* 239 */     return stringWriter.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final CharSequence inline(ITemplateContext context, IComment comment)
/*     */   {
/* 248 */     Validate.notNull(context, "Context cannot be null");
/* 249 */     Validate.notNull(comment, "Comment cannot be null");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 255 */     if (context.getTemplateMode() != this.templateMode) {
/* 256 */       return inlineSwitchTemplateMode(context, comment);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 263 */     if (!EngineEventUtils.isInlineable(comment)) {
/* 264 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 280 */     int commentLen = comment.length();
/* 281 */     StringBuilder strBuilder = new StringBuilder(commentLen + commentLen / 2);
/*     */     
/* 283 */     performInlining(context, comment, 4, commentLen - 7, comment.getTemplateName(), comment.getLine(), comment.getCol(), strBuilder);
/*     */     
/* 285 */     return strBuilder.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private CharSequence inlineSwitchTemplateMode(ITemplateContext context, IComment comment)
/*     */   {
/* 292 */     TemplateManager templateManager = context.getConfiguration().getTemplateManager();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 304 */     TemplateModel templateModel = templateManager.parseString(context
/* 305 */       .getTemplateData(), comment.getContent(), comment
/* 306 */       .getLine(), comment.getCol() + 4, this.templateMode, true);
/*     */     
/*     */ 
/* 309 */     Writer stringWriter = new FastStringWriter(50);
/* 310 */     templateManager.process(templateModel, context, stringWriter);
/*     */     
/* 312 */     return stringWriter.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void performInlining(ITemplateContext context, CharSequence text, int offset, int len, String templateName, int line, int col, StringBuilder strBuilder)
/*     */   {
/* 335 */     IStandardExpressionParser expressionParser = StandardExpressions.getExpressionParser(context.getConfiguration());
/*     */     
/* 337 */     int[] locator = { line, col };
/*     */     
/* 339 */     int i = offset;
/* 340 */     int current = i;
/* 341 */     int maxi = offset + len;
/*     */     
/*     */ 
/* 344 */     int currentLine = -1;
/* 345 */     int currentCol = -1;
/* 346 */     char innerClosingChar = '\000';
/*     */     
/* 348 */     boolean inExpression = false;
/*     */     
/* 350 */     while (i < maxi)
/*     */     {
/* 352 */       currentLine = locator[0];
/* 353 */       currentCol = locator[1];
/*     */       
/* 355 */       if (!inExpression)
/*     */       {
/* 357 */         int expStart = findNextStructureStart(text, i, maxi, locator);
/*     */         
/* 359 */         if (expStart == -1) {
/* 360 */           strBuilder.append(text, current, maxi);
/* 361 */           return;
/*     */         }
/*     */         
/* 364 */         inExpression = true;
/*     */         
/* 366 */         if (expStart > current)
/*     */         {
/* 368 */           strBuilder.append(text, current, expStart);
/*     */         }
/*     */         
/* 371 */         innerClosingChar = text.charAt(expStart + 1) == '[' ? ']' : ')';
/* 372 */         current = expStart;
/* 373 */         i = current + 2;
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/*     */ 
/* 379 */         int expEnd = findNextStructureEndAvoidQuotes(text, i, maxi, innerClosingChar, locator);
/*     */         
/* 381 */         if (expEnd < 0) {
/* 382 */           strBuilder.append(text, current, maxi);
/* 383 */           return;
/*     */         }
/*     */         
/* 386 */         String expression = text.subSequence(current + 2, expEnd).toString();
/* 387 */         boolean escape = innerClosingChar == ']';
/* 388 */         strBuilder.append(
/* 389 */           processExpression(context, expressionParser, expression, escape, templateName, currentLine, currentCol + 2));
/*     */         
/*     */ 
/* 392 */         countChar(locator, text.charAt(expEnd));
/* 393 */         countChar(locator, text.charAt(expEnd + 1));
/*     */         
/* 395 */         inExpression = false;
/*     */         
/* 397 */         current = expEnd + 2;
/* 398 */         i = current;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 405 */     if (inExpression) {
/* 406 */       strBuilder.append(text, current, maxi);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void countChar(int[] locator, char c)
/*     */   {
/* 418 */     if (c == '\n') {
/* 419 */       locator[0] += 1;
/* 420 */       locator[1] = 1;
/* 421 */       return;
/*     */     }
/* 423 */     locator[1] += 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static int findNextStructureStart(CharSequence text, int offset, int maxi, int[] locator)
/*     */   {
/* 433 */     int colIndex = offset;
/*     */     
/* 435 */     int i = offset;
/* 436 */     int n = maxi - offset;
/*     */     
/* 438 */     while (n-- != 0)
/*     */     {
/* 440 */       char c = text.charAt(i);
/*     */       
/* 442 */       if (c == '\n') {
/* 443 */         colIndex = i;
/* 444 */         locator[1] = 0;
/* 445 */         locator[0] += 1;
/* 446 */       } else if ((c == '[') && (n > 0)) {
/* 447 */         c = text.charAt(i + 1);
/* 448 */         if ((c == '[') || (c == '(')) {
/* 449 */           locator[1] += i - colIndex;
/* 450 */           return i;
/*     */         }
/*     */       }
/*     */       
/* 454 */       i++;
/*     */     }
/*     */     
/*     */ 
/* 458 */     locator[1] += maxi - colIndex;
/* 459 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static int findNextStructureEndAvoidQuotes(CharSequence text, int offset, int maxi, char innerClosingChar, int[] locator)
/*     */   {
/* 470 */     boolean inQuotes = false;
/* 471 */     boolean inApos = false;
/*     */     
/*     */ 
/*     */ 
/* 475 */     int colIndex = offset;
/*     */     
/* 477 */     int i = offset;
/* 478 */     int n = maxi - offset;
/*     */     
/* 480 */     while (n-- != 0)
/*     */     {
/* 482 */       char c = text.charAt(i);
/*     */       
/* 484 */       if (c == '\n') {
/* 485 */         colIndex = i;
/* 486 */         locator[1] = 0;
/* 487 */         locator[0] += 1;
/* 488 */       } else if ((c == '"') && (!inApos)) {
/* 489 */         inQuotes = !inQuotes;
/* 490 */       } else if ((c == '\'') && (!inQuotes)) {
/* 491 */         inApos = !inApos;
/* 492 */       } else if ((c == innerClosingChar) && (!inQuotes) && (!inApos) && (n > 0)) {
/* 493 */         c = text.charAt(i + 1);
/* 494 */         if (c == ']') {
/* 495 */           locator[1] += i - colIndex;
/* 496 */           return i;
/*     */         }
/*     */       }
/*     */       
/* 500 */       i++;
/*     */     }
/*     */     
/*     */ 
/* 504 */     locator[1] += maxi - colIndex;
/* 505 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String processExpression(ITemplateContext context, IStandardExpressionParser expressionParser, String expression, boolean escape, String templateName, int line, int col)
/*     */   {
/*     */     try
/*     */     {
/* 523 */       String unescapedExpression = EscapedAttributeUtils.unescapeAttribute(context.getTemplateMode(), expression);
/*     */       Object expressionResult;
/*     */       Object expressionResult;
/* 526 */       if (unescapedExpression != null) {
/* 527 */         IStandardExpression expressionObj = expressionParser.parseExpression(context, unescapedExpression);
/* 528 */         expressionResult = expressionObj.execute(context);
/*     */       } else {
/* 530 */         expressionResult = null;
/*     */       }
/*     */       
/* 533 */       if (escape) {
/* 534 */         return produceEscapedOutput(expressionResult);
/*     */       }
/* 536 */       return expressionResult == null ? "" : expressionResult.toString();
/*     */ 
/*     */     }
/*     */     catch (TemplateProcessingException e)
/*     */     {
/* 541 */       if (!e.hasTemplateName()) {
/* 542 */         e.setTemplateName(templateName);
/*     */       }
/* 544 */       if (!e.hasLineAndCol()) {
/* 545 */         e.setLineAndCol(line, col);
/*     */       }
/* 547 */       throw e;
/*     */     } catch (Exception e) {
/* 549 */       throw new TemplateProcessingException("Error during execution of inlined expression '" + expression + "'", templateName, line, col, e);
/*     */     }
/*     */   }
/*     */   
/*     */   protected abstract String produceEscapedOutput(Object paramObject);
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\inline\AbstractStandardInliner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */