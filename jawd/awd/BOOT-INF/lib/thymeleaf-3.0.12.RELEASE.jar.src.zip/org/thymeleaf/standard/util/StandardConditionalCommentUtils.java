/*     */ package org.thymeleaf.standard.util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class StandardConditionalCommentUtils
/*     */ {
/*     */   public static ConditionalCommentParsingResult parseConditionalComment(CharSequence text)
/*     */   {
/*  60 */     int len = text.length();
/*  61 */     int i = 4;
/*     */     
/*     */ 
/*     */ 
/*  65 */     while ((i < len) && (Character.isWhitespace(text.charAt(i)))) { i++;
/*     */     }
/*     */     
/*  68 */     if ((i >= len) || (text.charAt(i++) != '[')) {
/*  69 */       return null;
/*     */     }
/*     */     
/*  72 */     int startExpressionOffset = i;
/*     */     
/*     */ 
/*  75 */     while ((i < len) && (text.charAt(i) != ']')) { i++;
/*     */     }
/*  77 */     if (i >= len) {
/*  78 */       return null;
/*     */     }
/*     */     
/*  81 */     int startExpressionLen = i - startExpressionOffset;
/*     */     
/*     */ 
/*  84 */     i++;
/*     */     
/*     */ 
/*  87 */     while ((i < len) && (Character.isWhitespace(text.charAt(i)))) { i++;
/*     */     }
/*     */     
/*  90 */     if ((i >= len) || (text.charAt(i++) != '>')) {
/*  91 */       return null;
/*     */     }
/*     */     
/*  94 */     int contentOffset = i;
/*     */     
/*     */ 
/*     */ 
/*  98 */     i = len - 3 - 1;
/*     */     
/*     */ 
/* 101 */     while ((i > contentOffset) && (Character.isWhitespace(text.charAt(i)))) { i--;
/*     */     }
/*     */     
/* 104 */     if ((i <= contentOffset) || (text.charAt(i--) != ']')) {
/* 105 */       return null;
/*     */     }
/*     */     
/* 108 */     int endExpressionLastPos = i + 1;
/*     */     
/*     */ 
/* 111 */     while ((i > contentOffset) && (text.charAt(i) != '[')) { i--;
/*     */     }
/* 113 */     if (i <= contentOffset) {
/* 114 */       return null;
/*     */     }
/*     */     
/* 117 */     int endExpressionOffset = i + 1;
/* 118 */     int endExpressionLen = endExpressionLastPos - endExpressionOffset;
/*     */     
/*     */ 
/* 121 */     i--;
/*     */     
/*     */ 
/* 124 */     while ((i >= contentOffset) && (Character.isWhitespace(text.charAt(i)))) { i--;
/*     */     }
/*     */     
/* 127 */     if ((i <= contentOffset) || (text.charAt(i--) != '!')) {
/* 128 */       return null;
/*     */     }
/*     */     
/*     */ 
/* 132 */     if ((i <= contentOffset) || (text.charAt(i--) != '<')) {
/* 133 */       return null;
/*     */     }
/*     */     
/* 136 */     int contentLen = i + 1 - contentOffset;
/*     */     
/* 138 */     if ((contentLen <= 0) || (startExpressionLen <= 0) || (endExpressionLen <= 0)) {
/* 139 */       return null;
/*     */     }
/*     */     
/* 142 */     return new ConditionalCommentParsingResult(startExpressionOffset, startExpressionLen, contentOffset, contentLen, endExpressionOffset, endExpressionLen);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final class ConditionalCommentParsingResult
/*     */   {
/*     */     private final int startExpressionOffset;
/*     */     
/*     */ 
/*     */ 
/*     */     private final int startExpressionLen;
/*     */     
/*     */ 
/*     */ 
/*     */     private final int contentOffset;
/*     */     
/*     */ 
/*     */ 
/*     */     private final int contentLen;
/*     */     
/*     */ 
/*     */ 
/*     */     private final int endExpressionOffset;
/*     */     
/*     */ 
/*     */ 
/*     */     private final int endExpressionLen;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public ConditionalCommentParsingResult(int startExpressionOffset, int startExpressionLen, int contentOffset, int contentLen, int endExpressionOffset, int endExpressionLen)
/*     */     {
/* 177 */       this.startExpressionOffset = startExpressionOffset;
/* 178 */       this.startExpressionLen = startExpressionLen;
/* 179 */       this.contentOffset = contentOffset;
/* 180 */       this.contentLen = contentLen;
/* 181 */       this.endExpressionOffset = endExpressionOffset;
/* 182 */       this.endExpressionLen = endExpressionLen;
/*     */     }
/*     */     
/*     */ 
/*     */     public int getStartExpressionOffset()
/*     */     {
/* 188 */       return this.startExpressionOffset;
/*     */     }
/*     */     
/*     */     public int getStartExpressionLen() {
/* 192 */       return this.startExpressionLen;
/*     */     }
/*     */     
/*     */     public int getContentOffset() {
/* 196 */       return this.contentOffset;
/*     */     }
/*     */     
/*     */     public int getContentLen() {
/* 200 */       return this.contentLen;
/*     */     }
/*     */     
/*     */     public int getEndExpressionOffset() {
/* 204 */       return this.endExpressionOffset;
/*     */     }
/*     */     
/*     */     public int getEndExpressionLen() {
/* 208 */       return this.endExpressionLen;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\util\StandardConditionalCommentUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */