/*     */ package org.thymeleaf.standard.expression;
/*     */ 
/*     */ import org.thymeleaf.context.IExpressionContext;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SimpleExpression
/*     */   extends Expression
/*     */ {
/*     */   private static final long serialVersionUID = 9145380484247069725L;
/*     */   static final char EXPRESSION_START_CHAR = '{';
/*     */   static final char EXPRESSION_END_CHAR = '}';
/*     */   
/*     */   static Object executeSimple(IExpressionContext context, SimpleExpression expression, IStandardVariableExpressionEvaluator expressionEvaluator, StandardExpressionExecutionContext expContext)
/*     */   {
/*  65 */     if ((expression instanceof VariableExpression)) {
/*  66 */       return VariableExpression.executeVariableExpression(context, (VariableExpression)expression, expressionEvaluator, expContext);
/*     */     }
/*  68 */     if ((expression instanceof MessageExpression)) {
/*  69 */       return MessageExpression.executeMessageExpression(context, (MessageExpression)expression, expContext);
/*     */     }
/*  71 */     if ((expression instanceof TextLiteralExpression)) {
/*  72 */       return TextLiteralExpression.executeTextLiteralExpression(context, (TextLiteralExpression)expression, expContext);
/*     */     }
/*  74 */     if ((expression instanceof NumberTokenExpression)) {
/*  75 */       return NumberTokenExpression.executeNumberTokenExpression(context, (NumberTokenExpression)expression, expContext);
/*     */     }
/*  77 */     if ((expression instanceof BooleanTokenExpression)) {
/*  78 */       return BooleanTokenExpression.executeBooleanTokenExpression(context, (BooleanTokenExpression)expression, expContext);
/*     */     }
/*  80 */     if ((expression instanceof NullTokenExpression)) {
/*  81 */       return NullTokenExpression.executeNullTokenExpression(context, (NullTokenExpression)expression, expContext);
/*     */     }
/*  83 */     if ((expression instanceof LinkExpression))
/*     */     {
/*  85 */       return LinkExpression.executeLinkExpression(context, (LinkExpression)expression);
/*     */     }
/*  87 */     if ((expression instanceof FragmentExpression))
/*     */     {
/*  89 */       return FragmentExpression.executeFragmentExpression(context, (FragmentExpression)expression);
/*     */     }
/*  91 */     if ((expression instanceof SelectionVariableExpression)) {
/*  92 */       return SelectionVariableExpression.executeSelectionVariableExpression(context, (SelectionVariableExpression)expression, expressionEvaluator, expContext);
/*     */     }
/*  94 */     if ((expression instanceof NoOpTokenExpression)) {
/*  95 */       return NoOpTokenExpression.executeNoOpTokenExpression(context, (NoOpTokenExpression)expression, expContext);
/*     */     }
/*  97 */     if ((expression instanceof GenericTokenExpression)) {
/*  98 */       return GenericTokenExpression.executeGenericTokenExpression(context, (GenericTokenExpression)expression, expContext);
/*     */     }
/*     */     
/* 101 */     throw new TemplateProcessingException("Unrecognized simple expression: " + expression.getClass().getName());
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\expression\SimpleExpression.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */