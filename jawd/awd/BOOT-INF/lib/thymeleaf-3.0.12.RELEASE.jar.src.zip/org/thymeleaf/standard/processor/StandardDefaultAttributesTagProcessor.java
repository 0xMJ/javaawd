/*     */ package org.thymeleaf.standard.processor;
/*     */ 
/*     */ import org.attoparser.util.TextUtil;
/*     */ import org.thymeleaf.context.ITemplateContext;
/*     */ import org.thymeleaf.engine.AttributeDefinition;
/*     */ import org.thymeleaf.engine.AttributeName;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.model.IAttribute;
/*     */ import org.thymeleaf.model.IProcessableElementTag;
/*     */ import org.thymeleaf.processor.AbstractProcessor;
/*     */ import org.thymeleaf.processor.element.IElementTagProcessor;
/*     */ import org.thymeleaf.processor.element.IElementTagStructureHandler;
/*     */ import org.thymeleaf.processor.element.MatchingAttributeName;
/*     */ import org.thymeleaf.processor.element.MatchingElementName;
/*     */ import org.thymeleaf.standard.expression.FragmentExpression;
/*     */ import org.thymeleaf.standard.expression.FragmentExpression.ExecutedFragmentExpression;
/*     */ import org.thymeleaf.standard.expression.IStandardExpression;
/*     */ import org.thymeleaf.standard.expression.IStandardExpressionParser;
/*     */ import org.thymeleaf.standard.expression.NoOpToken;
/*     */ import org.thymeleaf.standard.expression.StandardExpressionExecutionContext;
/*     */ import org.thymeleaf.standard.expression.StandardExpressions;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ import org.thymeleaf.util.EscapedAttributeUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class StandardDefaultAttributesTagProcessor
/*     */   extends AbstractProcessor
/*     */   implements IElementTagProcessor
/*     */ {
/*     */   public static final int PRECEDENCE = Integer.MAX_VALUE;
/*     */   private final String dialectPrefix;
/*     */   private final MatchingAttributeName matchingAttributeName;
/*     */   
/*     */   public StandardDefaultAttributesTagProcessor(TemplateMode templateMode, String dialectPrefix)
/*     */   {
/*  63 */     super(templateMode, Integer.MAX_VALUE);
/*  64 */     this.dialectPrefix = dialectPrefix;
/*  65 */     this.matchingAttributeName = MatchingAttributeName.forAllAttributesWithPrefix(getTemplateMode(), dialectPrefix);
/*     */   }
/*     */   
/*     */   public final MatchingElementName getMatchingElementName()
/*     */   {
/*  70 */     return null;
/*     */   }
/*     */   
/*     */   public final MatchingAttributeName getMatchingAttributeName()
/*     */   {
/*  75 */     return this.matchingAttributeName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void process(ITemplateContext context, IProcessableElementTag tag, IElementTagStructureHandler structureHandler)
/*     */   {
/*  86 */     TemplateMode templateMode = getTemplateMode();
/*  87 */     IAttribute[] attributes = tag.getAllAttributes();
/*     */     
/*     */ 
/*     */ 
/*  91 */     for (IAttribute attribute : attributes)
/*     */     {
/*  93 */       AttributeName attributeName = attribute.getAttributeDefinition().getAttributeName();
/*  94 */       if ((attributeName.isPrefixed()) && 
/*  95 */         (TextUtil.equals(templateMode.isCaseSensitive(), attributeName.getPrefix(), this.dialectPrefix)))
/*     */       {
/*     */ 
/*  98 */         processDefaultAttribute(getTemplateMode(), context, tag, attribute, structureHandler);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void processDefaultAttribute(TemplateMode templateMode, ITemplateContext context, IProcessableElementTag tag, IAttribute attribute, IElementTagStructureHandler structureHandler)
/*     */   {
/*     */     try
/*     */     {
/* 117 */       AttributeName attributeName = attribute.getAttributeDefinition().getAttributeName();
/*     */       
/* 119 */       String attributeValue = EscapedAttributeUtils.unescapeAttribute(context.getTemplateMode(), attribute.getValue());
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 125 */       String originalCompleteAttributeName = attribute.getAttributeCompleteName();
/* 126 */       String canonicalAttributeName = attributeName.getAttributeName();
/*     */       String newAttributeName;
/*     */       String newAttributeName;
/* 129 */       if (TextUtil.endsWith(true, originalCompleteAttributeName, canonicalAttributeName)) {
/* 130 */         newAttributeName = canonicalAttributeName;
/*     */       }
/*     */       else {
/* 133 */         newAttributeName = originalCompleteAttributeName.substring(originalCompleteAttributeName.length() - canonicalAttributeName.length());
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 140 */       IStandardExpressionParser expressionParser = StandardExpressions.getExpressionParser(context.getConfiguration());
/*     */       
/*     */       Object expressionResult;
/*     */       
/*     */       Object expressionResult;
/*     */       
/* 146 */       if (attributeValue != null)
/*     */       {
/* 148 */         IStandardExpression expression = expressionParser.parseExpression(context, attributeValue);
/*     */         Object expressionResult;
/* 150 */         if ((expression != null) && ((expression instanceof FragmentExpression)))
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 156 */           FragmentExpression.ExecutedFragmentExpression executedFragmentExpression = FragmentExpression.createExecutedFragmentExpression(context, (FragmentExpression)expression);
/*     */           
/*     */ 
/* 159 */           expressionResult = FragmentExpression.resolveExecutedFragmentExpression(context, executedFragmentExpression, true);
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/*     */ 
/* 165 */           expressionResult = expression.execute(context, StandardExpressionExecutionContext.RESTRICTED);
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 170 */         expressionResult = null;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 176 */       if (expressionResult == NoOpToken.VALUE) {
/* 177 */         structureHandler.removeAttribute(attributeName);
/* 178 */         return;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 185 */       String newAttributeValue = EscapedAttributeUtils.escapeAttribute(templateMode, expressionResult == null ? null : expressionResult.toString());
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 190 */       if ((newAttributeValue == null) || (newAttributeValue.length() == 0))
/*     */       {
/* 192 */         structureHandler.removeAttribute(newAttributeName);
/* 193 */         structureHandler.removeAttribute(attributeName);
/*     */       }
/*     */       else {
/* 196 */         structureHandler.replaceAttribute(attributeName, newAttributeName, newAttributeValue == null ? "" : newAttributeValue);
/*     */       }
/*     */       
/*     */ 
/*     */     }
/*     */     catch (TemplateProcessingException e)
/*     */     {
/* 203 */       if (!e.hasTemplateName()) {
/* 204 */         e.setTemplateName(tag.getTemplateName());
/*     */       }
/* 206 */       if (!e.hasLineAndCol()) {
/* 207 */         e.setLineAndCol(attribute.getLine(), attribute.getCol());
/*     */       }
/* 209 */       throw e;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 213 */       throw new TemplateProcessingException("Error during execution of processor '" + StandardDefaultAttributesTagProcessor.class.getName() + "'", tag.getTemplateName(), attribute.getLine(), attribute.getCol(), e);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\processor\StandardDefaultAttributesTagProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */