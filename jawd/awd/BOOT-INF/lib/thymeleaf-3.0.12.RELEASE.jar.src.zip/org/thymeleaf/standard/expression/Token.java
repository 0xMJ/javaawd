/*     */ package org.thymeleaf.standard.expression;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Token
/*     */   extends SimpleExpression
/*     */ {
/*     */   private static final long serialVersionUID = 4357087922344497120L;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final Object value;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Token(Object value)
/*     */   {
/*  40 */     this.value = value;
/*     */   }
/*     */   
/*     */   public Object getValue()
/*     */   {
/*  45 */     return this.value;
/*     */   }
/*     */   
/*     */   public String getStringRepresentation() {
/*  49 */     return this.value.toString();
/*     */   }
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/*  55 */     return getStringRepresentation();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isTokenChar(String context, int pos)
/*     */   {
/*  73 */     char c = context.charAt(pos);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  78 */     if ((c >= 'a') && (c <= 'z')) {
/*  79 */       return true;
/*     */     }
/*  81 */     if ((c >= 'A') && (c <= 'Z')) {
/*  82 */       return true;
/*     */     }
/*  84 */     if ((c >= '0') && (c <= '9')) {
/*  85 */       return true;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  90 */     if ((c == ' ') || (c == '\n') || (c == '(') || (c == ')') || (c == '\'') || (c == '"') || (c == '<') || (c == '>') || (c == '{') || (c == '}') || (c == '=') || (c == ',') || (c == ';') || (c == ':') || (c == '+') || (c == '*') || (c == '$') || (c == '%') || (c == '&') || (c == '#'))
/*     */     {
/*     */ 
/*     */ 
/*  94 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  99 */     if ((c == '[') || (c == ']') || (c == '.') || (c == '_')) {
/* 100 */       return true;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 105 */     if (c == '-')
/*     */     {
/* 107 */       if (pos > 0)
/*     */       {
/*     */ 
/* 110 */         for (int i = pos - 1; i >= 0; i--) {
/* 111 */           if (!isTokenChar(context, i)) {
/*     */             break;
/*     */           }
/* 114 */           char cc = context.charAt(i);
/* 115 */           if (((cc < '0') || (cc > '9')) && (cc != '.'))
/*     */           {
/* 117 */             return true;
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 123 */       int contextLen = context.length();
/* 124 */       if (pos + 1 < contextLen)
/*     */       {
/*     */ 
/* 127 */         for (int i = pos + 1; i < contextLen; i++) {
/* 128 */           char cc = context.charAt(i);
/* 129 */           if (cc == '-')
/*     */           {
/* 131 */             return true;
/*     */           }
/* 133 */           if (!isTokenChar(context, i)) {
/*     */             break;
/*     */           }
/* 136 */           if (((cc < '0') || (cc > '9')) && (cc != '.'))
/*     */           {
/* 138 */             return true;
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 144 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 150 */     if (c == '·') {
/* 151 */       return true;
/*     */     }
/* 153 */     if ((c >= 'À') && (c <= 'Ö')) {
/* 154 */       return true;
/*     */     }
/* 156 */     if ((c >= 'Ø') && (c <= 'ö')) {
/* 157 */       return true;
/*     */     }
/* 159 */     if ((c >= 'ø') && (c <= '˿')) {
/* 160 */       return true;
/*     */     }
/* 162 */     if ((c >= '̀') && (c <= 'ͯ')) {
/* 163 */       return true;
/*     */     }
/* 165 */     if ((c >= 'Ͱ') && (c <= 'ͽ')) {
/* 166 */       return true;
/*     */     }
/* 168 */     if ((c >= 'Ϳ') && (c <= '῿')) {
/* 169 */       return true;
/*     */     }
/* 171 */     if ((c >= '‌') && (c <= '‍')) {
/* 172 */       return true;
/*     */     }
/* 174 */     if ((c >= '‿') && (c <= '⁀')) {
/* 175 */       return true;
/*     */     }
/* 177 */     if ((c >= '⁰') && (c <= '↏')) {
/* 178 */       return true;
/*     */     }
/* 180 */     if ((c >= 'Ⰰ') && (c <= '⿯')) {
/* 181 */       return true;
/*     */     }
/* 183 */     if ((c >= '、') && (c <= 55295)) {
/* 184 */       return true;
/*     */     }
/* 186 */     if ((c >= 63744) && (c <= 64975)) {
/* 187 */       return true;
/*     */     }
/* 189 */     if ((c >= 65008) && (c <= 65533)) {
/* 190 */       return true;
/*     */     }
/* 192 */     return (c >= 65008) && (c <= 65533);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final class TokenParsingTracer
/*     */   {
/*     */     public static final char TOKEN_SUBSTITUTE = '#';
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public static String trace(String input)
/*     */     {
/* 209 */       int inputLen = input.length();
/*     */       
/* 211 */       StringBuilder strBuilder = new StringBuilder(inputLen + 1);
/*     */       
/* 213 */       for (int i = 0; i < inputLen; i++) {
/* 214 */         if (Token.isTokenChar(input, i)) {
/* 215 */           strBuilder.append('#');
/*     */         } else {
/* 217 */           strBuilder.append(input.charAt(i));
/*     */         }
/*     */       }
/*     */       
/* 221 */       return strBuilder.toString();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\expression\Token.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */