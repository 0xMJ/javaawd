/*     */ package org.thymeleaf.standard.expression;
/*     */ 
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.thymeleaf.TemplateEngine;
/*     */ import org.thymeleaf.context.IExpressionContext;
/*     */ import org.thymeleaf.util.EvaluationUtils;
/*     */ import org.thymeleaf.util.StringUtils;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ConditionalExpression
/*     */   extends ComplexExpression
/*     */ {
/*  48 */   private static final Logger logger = LoggerFactory.getLogger(ConditionalExpression.class);
/*     */   
/*     */ 
/*     */   private static final long serialVersionUID = -6966177717462316363L;
/*     */   
/*     */   private static final char CONDITION_SUFFIX_CHAR = '?';
/*     */   
/*     */   private static final char CONDITION_THENELSE_SEPARATOR_CHAR = ':';
/*     */   
/*  57 */   static final String[] OPERATORS = {
/*  58 */     String.valueOf('?'), String.valueOf(':') };
/*     */   
/*     */   private final Expression conditionExpression;
/*     */   
/*     */   private final Expression thenExpression;
/*     */   
/*     */   private final Expression elseExpression;
/*     */   
/*     */ 
/*     */   public ConditionalExpression(Expression conditionExpression, Expression thenExpression, Expression elseExpression)
/*     */   {
/*  69 */     Validate.notNull(conditionExpression, "Condition expression cannot be null");
/*  70 */     Validate.notNull(thenExpression, "Then expression cannot be null");
/*  71 */     Validate.notNull(elseExpression, "Else expression cannot be null");
/*  72 */     this.conditionExpression = conditionExpression;
/*  73 */     this.thenExpression = thenExpression;
/*  74 */     this.elseExpression = elseExpression;
/*     */   }
/*     */   
/*     */   public Expression getConditionExpression() {
/*  78 */     return this.conditionExpression;
/*     */   }
/*     */   
/*     */   public Expression getThenExpression() {
/*  82 */     return this.thenExpression;
/*     */   }
/*     */   
/*     */   public Expression getElseExpression() {
/*  86 */     return this.elseExpression;
/*     */   }
/*     */   
/*     */   public String getStringRepresentation()
/*     */   {
/*  91 */     StringBuilder sb = new StringBuilder();
/*  92 */     if ((this.conditionExpression instanceof ComplexExpression)) {
/*  93 */       sb.append('(');
/*  94 */       sb.append(this.conditionExpression);
/*  95 */       sb.append(')');
/*     */     } else {
/*  97 */       sb.append(this.conditionExpression);
/*     */     }
/*  99 */     sb.append('?');
/* 100 */     sb.append(' ');
/* 101 */     if ((this.thenExpression instanceof ComplexExpression)) {
/* 102 */       sb.append('(');
/* 103 */       sb.append(this.thenExpression);
/* 104 */       sb.append(')');
/*     */     } else {
/* 106 */       sb.append(this.thenExpression);
/*     */     }
/* 108 */     sb.append(' ');
/* 109 */     sb.append(':');
/* 110 */     sb.append(' ');
/* 111 */     if ((this.elseExpression instanceof ComplexExpression)) {
/* 112 */       sb.append('(');
/* 113 */       sb.append(this.elseExpression);
/* 114 */       sb.append(')');
/*     */     } else {
/* 116 */       sb.append(this.elseExpression);
/*     */     }
/* 118 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static ExpressionParsingState composeConditionalExpression(ExpressionParsingState state, int nodeIndex)
/*     */   {
/* 130 */     String input = ((ExpressionParsingNode)state.get(nodeIndex)).getInput();
/*     */     
/* 132 */     if (StringUtils.isEmptyOrWhitespace(input)) {
/* 133 */       return null;
/*     */     }
/*     */     
/*     */ 
/* 137 */     int condSuffixPos = input.indexOf('?');
/* 138 */     if (condSuffixPos == -1) {
/* 139 */       return state;
/*     */     }
/*     */     
/* 142 */     String condStr = input.substring(0, condSuffixPos);
/* 143 */     String remainder = input.substring(condSuffixPos + 1);
/*     */     
/* 145 */     if (remainder.indexOf('?') != -1)
/*     */     {
/* 147 */       return null;
/*     */     }
/*     */     
/* 150 */     int thenElseSepPos = remainder.indexOf(':');
/* 151 */     if (remainder.lastIndexOf(':') != thenElseSepPos)
/*     */     {
/* 153 */       return null;
/*     */     }
/*     */     
/* 156 */     String thenStr = null;
/* 157 */     String elseStr = null;
/* 158 */     if (thenElseSepPos != -1) {
/* 159 */       if (thenElseSepPos == 0)
/*     */       {
/* 161 */         return state;
/*     */       }
/* 163 */       thenStr = remainder.substring(0, thenElseSepPos);
/* 164 */       elseStr = remainder.substring(thenElseSepPos + 1);
/*     */     } else {
/* 166 */       thenStr = remainder;
/*     */     }
/*     */     
/*     */ 
/* 170 */     Expression condExpr = ExpressionParsingUtil.parseAndCompose(state, condStr);
/* 171 */     if (condExpr == null) {
/* 172 */       return null;
/*     */     }
/*     */     
/* 175 */     Expression thenExpr = ExpressionParsingUtil.parseAndCompose(state, thenStr);
/* 176 */     if (thenExpr == null) {
/* 177 */       return null;
/*     */     }
/*     */     
/* 180 */     Expression elseExpr = VariableExpression.NULL_VALUE;
/* 181 */     if (elseStr != null) {
/* 182 */       elseExpr = ExpressionParsingUtil.parseAndCompose(state, elseStr);
/* 183 */       if (elseExpr == null) {
/* 184 */         return null;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 189 */     ConditionalExpression conditionalExpressionResult = new ConditionalExpression(condExpr, thenExpr, elseExpr);
/*     */     
/* 191 */     state.setNode(nodeIndex, conditionalExpressionResult);
/*     */     
/* 193 */     return state;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static Object executeConditional(IExpressionContext context, ConditionalExpression expression, StandardExpressionExecutionContext expContext)
/*     */   {
/* 205 */     if (logger.isTraceEnabled()) {
/* 206 */       logger.trace("[THYMELEAF][{}] Evaluating conditional expression: \"{}\"", TemplateEngine.threadIndex(), expression.getStringRepresentation());
/*     */     }
/*     */     
/* 209 */     Object condObj = expression.getConditionExpression().execute(context, expContext);
/* 210 */     boolean cond = EvaluationUtils.evaluateAsBoolean(condObj);
/*     */     
/* 212 */     if (cond) {
/* 213 */       return expression.getThenExpression().execute(context, expContext);
/*     */     }
/* 215 */     return expression.getElseExpression().execute(context, expContext);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\expression\ConditionalExpression.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */