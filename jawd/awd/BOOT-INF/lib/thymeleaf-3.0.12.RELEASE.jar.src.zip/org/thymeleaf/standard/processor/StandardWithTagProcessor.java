/*     */ package org.thymeleaf.standard.processor;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.thymeleaf.context.IEngineContext;
/*     */ import org.thymeleaf.context.ITemplateContext;
/*     */ import org.thymeleaf.engine.AttributeName;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.model.IProcessableElementTag;
/*     */ import org.thymeleaf.processor.element.AbstractAttributeTagProcessor;
/*     */ import org.thymeleaf.processor.element.IElementTagStructureHandler;
/*     */ import org.thymeleaf.standard.expression.Assignation;
/*     */ import org.thymeleaf.standard.expression.AssignationSequence;
/*     */ import org.thymeleaf.standard.expression.AssignationUtils;
/*     */ import org.thymeleaf.standard.expression.IStandardExpression;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ import org.thymeleaf.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class StandardWithTagProcessor
/*     */   extends AbstractAttributeTagProcessor
/*     */ {
/*     */   public static final int PRECEDENCE = 600;
/*     */   public static final String ATTR_NAME = "with";
/*     */   
/*     */   public StandardWithTagProcessor(TemplateMode templateMode, String dialectPrefix)
/*     */   {
/*  51 */     super(templateMode, dialectPrefix, null, false, "with", true, 600, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void doProcess(ITemplateContext context, IProcessableElementTag tag, AttributeName attributeName, String attributeValue, IElementTagStructureHandler structureHandler)
/*     */   {
/*  64 */     AssignationSequence assignations = AssignationUtils.parseAssignationSequence(context, attributeValue, false);
/*     */     
/*  66 */     if (assignations == null) {
/*  67 */       throw new TemplateProcessingException("Could not parse value as attribute assignations: \"" + attributeValue + "\"");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  76 */     IEngineContext engineContext = null;
/*  77 */     if ((context instanceof IEngineContext))
/*     */     {
/*  79 */       engineContext = (IEngineContext)context;
/*     */     }
/*     */     
/*  82 */     List<Assignation> assignationValues = assignations.getAssignations();
/*  83 */     int assignationValuesLen = assignationValues.size();
/*     */     
/*  85 */     for (int i = 0; i < assignationValuesLen; i++)
/*     */     {
/*  87 */       Assignation assignation = (Assignation)assignationValues.get(i);
/*     */       
/*  89 */       IStandardExpression leftExpr = assignation.getLeft();
/*  90 */       Object leftValue = leftExpr.execute(context);
/*     */       
/*  92 */       IStandardExpression rightExpr = assignation.getRight();
/*  93 */       Object rightValue = rightExpr.execute(context);
/*     */       
/*  95 */       String newVariableName = leftValue == null ? null : leftValue.toString();
/*  96 */       if (StringUtils.isEmptyOrWhitespace(newVariableName)) {
/*  97 */         throw new TemplateProcessingException("Variable name expression evaluated as null or empty: \"" + leftExpr + "\"");
/*     */       }
/*     */       
/*     */ 
/* 101 */       if (engineContext != null)
/*     */       {
/*     */ 
/* 104 */         engineContext.setVariable(newVariableName, rightValue);
/*     */       }
/*     */       else {
/* 107 */         structureHandler.setLocalVariable(newVariableName, rightValue);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\processor\StandardWithTagProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */