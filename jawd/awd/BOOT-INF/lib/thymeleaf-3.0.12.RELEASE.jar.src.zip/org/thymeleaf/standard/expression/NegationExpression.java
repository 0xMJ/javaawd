/*     */ package org.thymeleaf.standard.expression;
/*     */ 
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.thymeleaf.TemplateEngine;
/*     */ import org.thymeleaf.context.IExpressionContext;
/*     */ import org.thymeleaf.util.EvaluationUtils;
/*     */ import org.thymeleaf.util.StringUtils;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class NegationExpression
/*     */   extends ComplexExpression
/*     */ {
/*     */   private static final long serialVersionUID = -7131967162611145337L;
/*  52 */   private static final Logger logger = LoggerFactory.getLogger(NegationExpression.class);
/*     */   
/*     */   private static final String OPERATOR_1 = "!";
/*     */   
/*     */   private static final String OPERATOR_2 = "not";
/*     */   
/*  58 */   static final String[] OPERATORS = { "!", "not" };
/*     */   
/*     */ 
/*     */   private final Expression operand;
/*     */   
/*     */ 
/*     */   public NegationExpression(Expression operand)
/*     */   {
/*  66 */     Validate.notNull(operand, "Operand cannot be null");
/*  67 */     this.operand = operand;
/*     */   }
/*     */   
/*     */   public Expression getOperand() {
/*  71 */     return this.operand;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getStringRepresentation()
/*     */   {
/*  78 */     StringBuilder sb = new StringBuilder();
/*  79 */     sb.append("!");
/*  80 */     if ((this.operand instanceof ComplexExpression)) {
/*  81 */       sb.append('(');
/*  82 */       sb.append(this.operand);
/*  83 */       sb.append(')');
/*     */     } else {
/*  85 */       sb.append(this.operand);
/*     */     }
/*  87 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ExpressionParsingState composeNegationExpression(ExpressionParsingState state, int nodeIndex)
/*     */   {
/*  99 */     String input = ((ExpressionParsingNode)state.get(nodeIndex)).getInput();
/*     */     
/* 101 */     if (StringUtils.isEmptyOrWhitespace(input)) {
/* 102 */       return null;
/*     */     }
/*     */     
/* 105 */     String trimmedInput = input.trim();
/*     */     
/*     */ 
/* 108 */     String operatorFound = null;
/* 109 */     int operatorPos = trimmedInput.lastIndexOf("!");
/* 110 */     if (operatorPos == -1) {
/* 111 */       operatorPos = trimmedInput.lastIndexOf("not");
/* 112 */       if (operatorPos == -1) {
/* 113 */         return state;
/*     */       }
/* 115 */       operatorFound = "not";
/*     */     } else {
/* 117 */       operatorFound = "!";
/*     */     }
/*     */     
/* 120 */     if (operatorPos != 0)
/*     */     {
/* 122 */       return state;
/*     */     }
/*     */     
/* 125 */     String operandStr = trimmedInput.substring(operatorFound.length());
/*     */     
/* 127 */     Expression operandExpr = ExpressionParsingUtil.parseAndCompose(state, operandStr);
/* 128 */     if (operandExpr == null) {
/* 129 */       return null;
/*     */     }
/*     */     
/* 132 */     NegationExpression minusExpression = new NegationExpression(operandExpr);
/* 133 */     state.setNode(nodeIndex, minusExpression);
/*     */     
/* 135 */     return state;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static Object executeNegation(IExpressionContext context, NegationExpression expression, StandardExpressionExecutionContext expContext)
/*     */   {
/* 145 */     if (logger.isTraceEnabled()) {
/* 146 */       logger.trace("[THYMELEAF][{}] Evaluating negation expression: \"{}\"", TemplateEngine.threadIndex(), expression.getStringRepresentation());
/*     */     }
/*     */     
/* 149 */     Object operandValue = expression.getOperand().execute(context, expContext);
/*     */     
/* 151 */     boolean operandBooleanValue = EvaluationUtils.evaluateAsBoolean(operandValue);
/*     */     
/* 153 */     return Boolean.valueOf(!operandBooleanValue);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\expression\NegationExpression.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */