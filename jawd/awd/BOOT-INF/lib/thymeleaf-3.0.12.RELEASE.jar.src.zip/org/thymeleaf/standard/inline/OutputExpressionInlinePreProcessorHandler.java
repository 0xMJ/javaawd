/*     */ package org.thymeleaf.standard.inline;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import org.thymeleaf.IEngineConfiguration;
/*     */ import org.thymeleaf.engine.AttributeName;
/*     */ import org.thymeleaf.engine.AttributeNames;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ import org.thymeleaf.util.EscapedAttributeUtils;
/*     */ import org.thymeleaf.util.TextUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class OutputExpressionInlinePreProcessorHandler
/*     */   implements IInlinePreProcessorHandler
/*     */ {
/*     */   private static final int DEFAULT_LEVELS_SIZE = 2;
/*     */   private final IInlinePreProcessorHandler next;
/*     */   private final String standardDialectPrefix;
/*     */   private final String[] inlineAttributeNames;
/*     */   private final char[] blockElementName;
/*     */   private final String escapedTextAttributeName;
/*     */   private final String unescapedTextAttributeName;
/*     */   private int execLevel;
/*     */   private TemplateMode[] inlineTemplateModes;
/*     */   private int[] inlineExecLevels;
/*     */   private int inlineIndex;
/*     */   private char[] attributeBuffer;
/*     */   
/*     */   public OutputExpressionInlinePreProcessorHandler(IEngineConfiguration configuration, TemplateMode templateMode, String standardDialectPrefix, IInlinePreProcessorHandler handler)
/*     */   {
/*  92 */     this.next = handler;
/*     */     
/*  94 */     this.standardDialectPrefix = standardDialectPrefix;
/*     */     
/*     */ 
/*  97 */     this.inlineAttributeNames = AttributeNames.forName(templateMode, this.standardDialectPrefix, "inline").getCompleteAttributeNames();
/*     */     
/*     */ 
/* 100 */     this.blockElementName = org.thymeleaf.engine.ElementNames.forName(templateMode, this.standardDialectPrefix, "block").getCompleteElementNames()[0].toCharArray();
/*     */     
/*     */ 
/* 103 */     this.escapedTextAttributeName = AttributeNames.forName(templateMode, this.standardDialectPrefix, "text").getCompleteAttributeNames()[0];
/*     */     
/* 105 */     this.unescapedTextAttributeName = AttributeNames.forName(templateMode, this.standardDialectPrefix, "utext").getCompleteAttributeNames()[0];
/*     */     
/* 107 */     this.inlineTemplateModes = new TemplateMode[2];
/* 108 */     this.inlineExecLevels = new int[2];
/* 109 */     Arrays.fill(this.inlineTemplateModes, null);
/* 110 */     Arrays.fill(this.inlineExecLevels, -1);
/* 111 */     this.inlineIndex = 0;
/*     */     
/* 113 */     this.execLevel = 0;
/*     */     
/* 115 */     this.inlineTemplateModes[this.inlineIndex] = templateMode;
/* 116 */     this.inlineExecLevels[this.inlineIndex] = this.execLevel;
/*     */     
/* 118 */     this.attributeBuffer = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleText(char[] buffer, int offset, int len, int line, int col)
/*     */   {
/* 132 */     if (this.inlineTemplateModes[this.inlineIndex] != this.inlineTemplateModes[0])
/*     */     {
/*     */ 
/*     */ 
/* 136 */       this.next.handleText(buffer, offset, len, line, col);
/* 137 */       return;
/*     */     }
/*     */     
/* 140 */     if (!mightNeedInlining(buffer, offset, len))
/*     */     {
/* 142 */       this.next.handleText(buffer, offset, len, line, col);
/* 143 */       return;
/*     */     }
/*     */     
/* 146 */     performInlining(buffer, offset, len, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleStandaloneElementStart(char[] buffer, int nameOffset, int nameLen, boolean minimized, int line, int col)
/*     */   {
/* 158 */     increaseExecLevel();
/* 159 */     this.next.handleStandaloneElementStart(buffer, nameOffset, nameLen, minimized, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleStandaloneElementEnd(char[] buffer, int nameOffset, int nameLen, boolean minimized, int line, int col)
/*     */   {
/* 168 */     decreaseExecLevel();
/* 169 */     this.next.handleStandaloneElementEnd(buffer, nameOffset, nameLen, minimized, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleOpenElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */   {
/* 177 */     increaseExecLevel();
/* 178 */     this.next.handleOpenElementStart(buffer, nameOffset, nameLen, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleOpenElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */   {
/* 186 */     this.next.handleOpenElementEnd(buffer, nameOffset, nameLen, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleAutoOpenElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */   {
/* 194 */     increaseExecLevel();
/* 195 */     this.next.handleAutoOpenElementStart(buffer, nameOffset, nameLen, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleAutoOpenElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */   {
/* 203 */     this.next.handleAutoOpenElementEnd(buffer, nameOffset, nameLen, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleCloseElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */   {
/* 211 */     this.next.handleCloseElementStart(buffer, nameOffset, nameLen, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleCloseElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */   {
/* 219 */     decreaseExecLevel();
/* 220 */     this.next.handleCloseElementEnd(buffer, nameOffset, nameLen, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleAutoCloseElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */   {
/* 228 */     this.next.handleAutoCloseElementStart(buffer, nameOffset, nameLen, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleAutoCloseElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */   {
/* 236 */     decreaseExecLevel();
/* 237 */     this.next.handleAutoCloseElementEnd(buffer, nameOffset, nameLen, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleAttribute(char[] buffer, int nameOffset, int nameLen, int nameLine, int nameCol, int operatorOffset, int operatorLen, int operatorLine, int operatorCol, int valueContentOffset, int valueContentLen, int valueOuterOffset, int valueOuterLen, int valueLine, int valueCol)
/*     */   {
/* 252 */     if (isInlineAttribute(buffer, nameOffset, nameLen))
/*     */     {
/* 254 */       String inlineModeAttributeValue = EscapedAttributeUtils.unescapeAttribute(this.inlineTemplateModes[0], new String(buffer, valueContentOffset, valueContentLen));
/*     */       
/* 256 */       TemplateMode inlineTemplateMode = computeAssociatedTemplateMode(inlineModeAttributeValue);
/* 257 */       setInlineTemplateMode(inlineTemplateMode);
/*     */     }
/*     */     
/* 260 */     this.next.handleAttribute(buffer, nameOffset, nameLen, nameLine, nameCol, operatorOffset, operatorLen, operatorLine, operatorCol, valueContentOffset, valueContentLen, valueOuterOffset, valueOuterLen, valueLine, valueCol);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void increaseExecLevel()
/*     */   {
/* 271 */     this.execLevel += 1;
/*     */   }
/*     */   
/*     */   private void decreaseExecLevel() {
/* 275 */     if (this.inlineExecLevels[this.inlineIndex] == this.execLevel) {
/* 276 */       this.inlineTemplateModes[this.inlineIndex] = null;
/* 277 */       this.inlineExecLevels[this.inlineIndex] = -1;
/* 278 */       this.inlineIndex -= 1;
/*     */     }
/* 280 */     this.execLevel -= 1;
/*     */   }
/*     */   
/*     */ 
/*     */   private boolean isInlineAttribute(char[] buffer, int nameOffset, int nameLen)
/*     */   {
/* 286 */     boolean caseSensitive = this.inlineTemplateModes[0].isCaseSensitive();
/* 287 */     for (String inlineAttributeName : this.inlineAttributeNames) {
/* 288 */       if (TextUtils.equals(caseSensitive, inlineAttributeName, 0, inlineAttributeName.length(), buffer, nameOffset, nameLen)) {
/* 289 */         return true;
/*     */       }
/*     */     }
/* 292 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setInlineTemplateMode(TemplateMode templateMode)
/*     */   {
/* 301 */     if (this.inlineExecLevels[this.inlineIndex] != this.execLevel) {
/* 302 */       this.inlineIndex += 1;
/*     */     }
/*     */     
/* 305 */     if (this.inlineIndex >= this.inlineTemplateModes.length) {
/* 306 */       this.inlineTemplateModes = ((TemplateMode[])Arrays.copyOf(this.inlineTemplateModes, this.inlineTemplateModes.length + 2));
/* 307 */       int oldInlineExecLevelsLen = this.inlineExecLevels.length;
/* 308 */       this.inlineExecLevels = Arrays.copyOf(this.inlineExecLevels, this.inlineExecLevels.length + 2);
/* 309 */       Arrays.fill(this.inlineExecLevels, oldInlineExecLevelsLen, this.inlineExecLevels.length, -1);
/*     */     }
/*     */     
/* 312 */     this.inlineTemplateModes[this.inlineIndex] = templateMode;
/* 313 */     this.inlineExecLevels[this.inlineIndex] = this.execLevel;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static TemplateMode computeAssociatedTemplateMode(String inlineModeAttributeValue)
/*     */   {
/* 320 */     StandardInlineMode inlineMode = StandardInlineMode.parse(inlineModeAttributeValue);
/* 321 */     if (inlineMode == null) {
/* 322 */       return null;
/*     */     }
/* 324 */     switch (inlineMode) {
/*     */     case NONE: 
/* 326 */       return null;
/*     */     case HTML: 
/* 328 */       return TemplateMode.HTML;
/*     */     case XML: 
/* 330 */       return TemplateMode.XML;
/*     */     case TEXT: 
/* 332 */       return TemplateMode.TEXT;
/*     */     case JAVASCRIPT: 
/* 334 */       return TemplateMode.JAVASCRIPT;
/*     */     case CSS: 
/* 336 */       return TemplateMode.CSS;
/*     */     }
/* 338 */     throw new IllegalArgumentException("Unrecognized inline mode: " + inlineMode);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean mightNeedInlining(char[] buffer, int offset, int len)
/*     */   {
/* 347 */     int n = len;
/* 348 */     int i = offset;
/*     */     
/* 350 */     while (n-- != 0) {
/* 351 */       char c = buffer[i];
/* 352 */       if ((c == '[') && (n > 0)) {
/* 353 */         c = buffer[(i + 1)];
/* 354 */         if ((c == '[') || (c == '('))
/*     */         {
/* 356 */           return true;
/*     */         }
/*     */       }
/* 359 */       i++;
/*     */     }
/* 361 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void performInlining(char[] text, int offset, int len, int line, int col)
/*     */   {
/* 374 */     int[] locator = { line, col };
/*     */     
/* 376 */     int i = offset;
/* 377 */     int current = i;
/* 378 */     int maxi = offset + len;
/*     */     
/*     */ 
/* 381 */     int currentLine = -1;
/* 382 */     int currentCol = -1;
/* 383 */     char innerClosingChar = '\000';
/*     */     
/* 385 */     boolean inExpression = false;
/*     */     
/* 387 */     while (i < maxi)
/*     */     {
/* 389 */       currentLine = locator[0];
/* 390 */       currentCol = locator[1];
/*     */       
/* 392 */       if (!inExpression)
/*     */       {
/* 394 */         int expStart = findNextStructureStart(text, i, maxi, locator);
/*     */         
/* 396 */         if (expStart == -1) {
/* 397 */           this.next.handleText(text, current, maxi - current, currentLine, currentCol);
/* 398 */           return;
/*     */         }
/*     */         
/* 401 */         inExpression = true;
/*     */         
/* 403 */         if (expStart > current)
/*     */         {
/* 405 */           this.next.handleText(text, current, expStart - current, currentLine, currentCol);
/*     */         }
/*     */         
/* 408 */         innerClosingChar = text[(expStart + 1)] == '[' ? ']' : ')';
/* 409 */         current = expStart;
/* 410 */         i = current + 2;
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/*     */ 
/* 416 */         int expEnd = findNextStructureEndAvoidQuotes(text, i, maxi, innerClosingChar, locator);
/*     */         
/* 418 */         if (expEnd < 0) {
/* 419 */           this.next.handleText(text, current, maxi - current, currentLine, currentCol);
/* 420 */           return;
/*     */         }
/*     */         
/* 423 */         String textAttributeName = text[(current + 1)] == '[' ? this.escapedTextAttributeName : this.unescapedTextAttributeName;
/* 424 */         int textAttributeNameLen = textAttributeName.length();
/* 425 */         int textAttributeValueLen = expEnd - (current + 2);
/*     */         
/* 427 */         prepareAttributeBuffer(textAttributeName, text, current + 2, textAttributeValueLen);
/*     */         
/*     */ 
/* 430 */         this.next.handleOpenElementStart(this.blockElementName, 0, this.blockElementName.length, currentLine, currentCol + 2);
/* 431 */         this.next.handleAttribute(this.attributeBuffer, 0, textAttributeNameLen, currentLine, currentCol + 2, textAttributeNameLen, 1, currentLine, currentCol + 2, textAttributeNameLen + 2, textAttributeValueLen, textAttributeNameLen + 1, textAttributeValueLen + 2, currentLine, currentCol + 2);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 440 */         this.next.handleOpenElementEnd(this.blockElementName, 0, this.blockElementName.length, currentLine, currentCol + 2);
/*     */         
/* 442 */         this.next.handleCloseElementStart(this.blockElementName, 0, this.blockElementName.length, currentLine, currentCol + 2);
/* 443 */         this.next.handleCloseElementEnd(this.blockElementName, 0, this.blockElementName.length, currentLine, currentCol + 2);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 448 */         countChar(locator, text[expEnd]);
/* 449 */         countChar(locator, text[(expEnd + 1)]);
/*     */         
/* 451 */         inExpression = false;
/*     */         
/* 453 */         current = expEnd + 2;
/* 454 */         i = current;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 461 */     if (inExpression) {
/* 462 */       this.next.handleText(text, current, maxi - current, currentLine, currentCol);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void countChar(int[] locator, char c)
/*     */   {
/* 474 */     if (c == '\n') {
/* 475 */       locator[0] += 1;
/* 476 */       locator[1] = 1;
/* 477 */       return;
/*     */     }
/* 479 */     locator[1] += 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static int findNextStructureStart(char[] text, int offset, int maxi, int[] locator)
/*     */   {
/* 489 */     int colIndex = offset;
/*     */     
/* 491 */     int i = offset;
/* 492 */     int n = maxi - offset;
/*     */     
/* 494 */     while (n-- != 0)
/*     */     {
/* 496 */       char c = text[i];
/*     */       
/* 498 */       if (c == '\n') {
/* 499 */         colIndex = i;
/* 500 */         locator[1] = 0;
/* 501 */         locator[0] += 1;
/* 502 */       } else if ((c == '[') && (n > 0)) {
/* 503 */         c = text[(i + 1)];
/* 504 */         if ((c == '[') || (c == '(')) {
/* 505 */           locator[1] += i - colIndex;
/* 506 */           return i;
/*     */         }
/*     */       }
/*     */       
/* 510 */       i++;
/*     */     }
/*     */     
/*     */ 
/* 514 */     locator[1] += maxi - colIndex;
/* 515 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static int findNextStructureEndAvoidQuotes(char[] text, int offset, int maxi, char innerClosingChar, int[] locator)
/*     */   {
/* 526 */     boolean inQuotes = false;
/* 527 */     boolean inApos = false;
/*     */     
/*     */ 
/*     */ 
/* 531 */     int colIndex = offset;
/*     */     
/* 533 */     int i = offset;
/* 534 */     int n = maxi - offset;
/*     */     
/* 536 */     while (n-- != 0)
/*     */     {
/* 538 */       char c = text[i];
/*     */       
/* 540 */       if (c == '\n') {
/* 541 */         colIndex = i;
/* 542 */         locator[1] = 0;
/* 543 */         locator[0] += 1;
/* 544 */       } else if ((c == '"') && (!inApos)) {
/* 545 */         inQuotes = !inQuotes;
/* 546 */       } else if ((c == '\'') && (!inQuotes)) {
/* 547 */         inApos = !inApos;
/* 548 */       } else if ((c == innerClosingChar) && (!inQuotes) && (!inApos) && (n > 0)) {
/* 549 */         c = text[(i + 1)];
/* 550 */         if (c == ']') {
/* 551 */           locator[1] += i - colIndex;
/* 552 */           return i;
/*     */         }
/*     */       }
/*     */       
/* 556 */       i++;
/*     */     }
/*     */     
/*     */ 
/* 560 */     locator[1] += maxi - colIndex;
/* 561 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void prepareAttributeBuffer(String attributeName, char[] valueText, int valueOffset, int valueLen)
/*     */   {
/* 569 */     int attributeNameLen = attributeName.length();
/* 570 */     int requiredLen = attributeNameLen + 2 + valueLen + 1;
/*     */     
/* 572 */     if ((this.attributeBuffer == null) || (this.attributeBuffer.length < requiredLen)) {
/* 573 */       this.attributeBuffer = new char[Math.max(requiredLen, 30)];
/*     */     }
/*     */     
/* 576 */     attributeName.getChars(0, attributeNameLen, this.attributeBuffer, 0);
/* 577 */     this.attributeBuffer[attributeNameLen] = '=';
/* 578 */     this.attributeBuffer[(attributeNameLen + 1)] = '"';
/* 579 */     System.arraycopy(valueText, valueOffset, this.attributeBuffer, attributeNameLen + 2, valueLen);
/* 580 */     this.attributeBuffer[(requiredLen - 1)] = '"';
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\inline\OutputExpressionInlinePreProcessorHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */