/*    */ package org.thymeleaf.standard.inline;
/*    */ 
/*    */ import java.io.Writer;
/*    */ import org.thymeleaf.IEngineConfiguration;
/*    */ import org.thymeleaf.standard.serializer.IStandardJavaScriptSerializer;
/*    */ import org.thymeleaf.standard.serializer.StandardSerializers;
/*    */ import org.thymeleaf.templatemode.TemplateMode;
/*    */ import org.thymeleaf.util.FastStringWriter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class StandardJavaScriptInliner
/*    */   extends AbstractStandardInliner
/*    */ {
/*    */   private final IStandardJavaScriptSerializer serializer;
/*    */   
/*    */   public StandardJavaScriptInliner(IEngineConfiguration configuration)
/*    */   {
/* 42 */     super(configuration, TemplateMode.JAVASCRIPT);
/* 43 */     this.serializer = StandardSerializers.getJavaScriptSerializer(configuration);
/*    */   }
/*    */   
/*    */ 
/*    */   protected String produceEscapedOutput(Object input)
/*    */   {
/* 49 */     Writer jsWriter = new FastStringWriter((input instanceof String) ? ((String)input).length() * 2 : 20);
/* 50 */     this.serializer.serializeValue(input, jsWriter);
/* 51 */     return jsWriter.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\inline\StandardJavaScriptInliner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */