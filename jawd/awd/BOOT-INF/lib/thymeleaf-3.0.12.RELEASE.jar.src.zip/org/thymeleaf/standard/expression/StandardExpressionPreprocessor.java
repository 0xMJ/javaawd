/*     */ package org.thymeleaf.standard.expression;
/*     */ 
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.thymeleaf.context.IExpressionContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class StandardExpressionPreprocessor
/*     */ {
/*     */   private static final char PREPROCESS_DELIMITER = '_';
/*     */   private static final String PREPROCESS_EVAL = "\\_\\_(.*?)\\_\\_";
/*  47 */   private static final Pattern PREPROCESS_EVAL_PATTERN = Pattern.compile("\\_\\_(.*?)\\_\\_", 32);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static String preprocess(IExpressionContext context, String input)
/*     */   {
/*  57 */     if (input.indexOf('_') == -1)
/*     */     {
/*  59 */       return input;
/*     */     }
/*     */     
/*  62 */     IStandardExpressionParser expressionParser = StandardExpressions.getExpressionParser(context.getConfiguration());
/*  63 */     if (!(expressionParser instanceof StandardExpressionParser))
/*     */     {
/*     */ 
/*  66 */       return input;
/*     */     }
/*     */     
/*  69 */     Matcher matcher = PREPROCESS_EVAL_PATTERN.matcher(input);
/*     */     
/*  71 */     if (matcher.find())
/*     */     {
/*  73 */       StringBuilder strBuilder = new StringBuilder(input.length() + 24);
/*  74 */       int curr = 0;
/*     */       
/*     */ 
/*     */       do
/*     */       {
/*  79 */         String previousText = checkPreprocessingMarkUnescaping(input.substring(curr, matcher.start(0)));
/*     */         
/*  81 */         String expressionText = checkPreprocessingMarkUnescaping(matcher.group(1));
/*     */         
/*  83 */         strBuilder.append(previousText);
/*     */         
/*     */ 
/*  86 */         IStandardExpression expression = StandardExpressionParser.parseExpression(context, expressionText, false);
/*  87 */         if (expression == null) {
/*  88 */           return null;
/*     */         }
/*     */         
/*  91 */         Object result = expression.execute(context, StandardExpressionExecutionContext.RESTRICTED);
/*     */         
/*  93 */         strBuilder.append(result);
/*     */         
/*  95 */         curr = matcher.end(0);
/*     */       }
/*  97 */       while (matcher.find());
/*     */       
/*  99 */       String remaining = checkPreprocessingMarkUnescaping(input.substring(curr));
/*     */       
/* 101 */       strBuilder.append(remaining);
/*     */       
/* 103 */       return strBuilder.toString().trim();
/*     */     }
/*     */     
/*     */ 
/* 107 */     return checkPreprocessingMarkUnescaping(input);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static String checkPreprocessingMarkUnescaping(String input)
/*     */   {
/* 115 */     boolean structureFound = false;
/*     */     
/* 117 */     byte state = 0;
/* 118 */     int inputLen = input.length();
/* 119 */     for (int i = 0; i < inputLen; i++) {
/* 120 */       char c = input.charAt(i);
/* 121 */       if ((c == '\\') && ((state == 0) || (state == 2))) {
/* 122 */         state = (byte)(state + 1);
/*     */ 
/*     */       }
/* 125 */       else if ((c == '_') && (state == 1)) {
/* 126 */         state = (byte)(state + 1);
/*     */       }
/*     */       else {
/* 129 */         if ((c == '_') && (state == 3)) {
/* 130 */           structureFound = true;
/* 131 */           break;
/*     */         }
/* 133 */         state = 0;
/*     */       }
/*     */     }
/* 136 */     if (!structureFound)
/*     */     {
/* 138 */       return input;
/*     */     }
/*     */     
/*     */ 
/* 142 */     state = 0;
/* 143 */     StringBuilder strBuilder = new StringBuilder(inputLen + 6);
/* 144 */     for (int i = 0; i < inputLen; i++) {
/* 145 */       char c = input.charAt(i);
/* 146 */       if ((c == '\\') && ((state == 0) || (state == 2))) {
/* 147 */         state = (byte)(state + 1);
/* 148 */         strBuilder.append('\\');
/* 149 */       } else if ((c == '_') && (state == 1)) {
/* 150 */         state = (byte)(state + 1);
/* 151 */         strBuilder.append('_');
/* 152 */       } else if ((c == '_') && (state == 3)) {
/* 153 */         state = 0;
/* 154 */         int builderLen = strBuilder.length();
/* 155 */         strBuilder.delete(builderLen - 3, builderLen);
/* 156 */         strBuilder.append("__");
/*     */       } else {
/* 158 */         state = 0;
/* 159 */         strBuilder.append(c);
/*     */       }
/*     */     }
/*     */     
/* 163 */     return strBuilder.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\expression\StandardExpressionPreprocessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */