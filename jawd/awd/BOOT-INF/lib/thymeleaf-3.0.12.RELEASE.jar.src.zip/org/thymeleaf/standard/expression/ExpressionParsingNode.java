/*    */ package org.thymeleaf.standard.expression;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class ExpressionParsingNode
/*    */ {
/*    */   private final String input;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private final Expression expression;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   ExpressionParsingNode(String input)
/*    */   {
/* 40 */     this.input = input.trim();
/* 41 */     this.expression = null;
/*    */   }
/*    */   
/*    */   ExpressionParsingNode(Expression expression)
/*    */   {
/* 46 */     this.expression = expression;
/* 47 */     this.input = null;
/*    */   }
/*    */   
/*    */   boolean isInput() {
/* 51 */     return this.input != null;
/*    */   }
/*    */   
/*    */   boolean isExpression() {
/* 55 */     return this.expression != null;
/*    */   }
/*    */   
/*    */   boolean isSimpleExpression() {
/* 59 */     return (this.expression != null) && ((this.expression instanceof SimpleExpression));
/*    */   }
/*    */   
/*    */   boolean ComplexExpression() {
/* 63 */     return (this.expression != null) && ((this.expression instanceof ComplexExpression));
/*    */   }
/*    */   
/*    */   String getInput() {
/* 67 */     return this.input;
/*    */   }
/*    */   
/*    */   Expression getExpression() {
/* 71 */     return this.expression;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 76 */     return isExpression() ? 
/* 77 */       "[" + this.expression.getStringRepresentation() + "]" : this.input;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\expression\ExpressionParsingNode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */