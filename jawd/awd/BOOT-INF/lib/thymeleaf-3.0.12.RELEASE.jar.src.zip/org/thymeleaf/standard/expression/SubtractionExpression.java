/*    */ package org.thymeleaf.standard.expression;
/*    */ 
/*    */ import java.math.BigDecimal;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ import org.thymeleaf.TemplateEngine;
/*    */ import org.thymeleaf.context.IExpressionContext;
/*    */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*    */ import org.thymeleaf.util.EvaluationUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SubtractionExpression
/*    */   extends AdditionSubtractionExpression
/*    */ {
/*    */   private static final long serialVersionUID = 4125686854902098944L;
/* 55 */   private static final Logger logger = LoggerFactory.getLogger(SubtractionExpression.class);
/*    */   
/*    */ 
/*    */   public SubtractionExpression(IStandardExpression left, IStandardExpression right)
/*    */   {
/* 60 */     super(left, right);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public String getStringRepresentation()
/*    */   {
/* 67 */     return getStringRepresentation("-");
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   static Object executeSubtraction(IExpressionContext context, SubtractionExpression expression, StandardExpressionExecutionContext expContext)
/*    */   {
/* 77 */     if (logger.isTraceEnabled()) {
/* 78 */       logger.trace("[THYMELEAF][{}] Evaluating subtraction expression: \"{}\"", TemplateEngine.threadIndex(), expression.getStringRepresentation());
/*    */     }
/*    */     
/* 81 */     Object leftValue = expression.getLeft().execute(context, expContext);
/* 82 */     Object rightValue = expression.getRight().execute(context, expContext);
/*    */     
/* 84 */     if (leftValue == null) {
/* 85 */       leftValue = "null";
/*    */     }
/* 87 */     if (rightValue == null) {
/* 88 */       rightValue = "null";
/*    */     }
/*    */     
/* 91 */     BigDecimal leftNumberValue = EvaluationUtils.evaluateAsNumber(leftValue);
/* 92 */     BigDecimal rightNumberValue = EvaluationUtils.evaluateAsNumber(rightValue);
/* 93 */     if ((leftNumberValue != null) && (rightNumberValue != null))
/*    */     {
/* 95 */       return leftNumberValue.subtract(rightNumberValue);
/*    */     }
/*    */     
/*    */ 
/* 99 */     throw new TemplateProcessingException("Cannot execute subtraction: operands are \"" + LiteralValue.unwrap(leftValue) + "\" and \"" + LiteralValue.unwrap(rightValue) + "\"");
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\expression\SubtractionExpression.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */