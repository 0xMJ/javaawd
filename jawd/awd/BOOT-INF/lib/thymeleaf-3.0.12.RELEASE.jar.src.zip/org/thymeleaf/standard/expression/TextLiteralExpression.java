/*     */ package org.thymeleaf.standard.expression;
/*     */ 
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.thymeleaf.TemplateEngine;
/*     */ import org.thymeleaf.context.IExpressionContext;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class TextLiteralExpression
/*     */   extends SimpleExpression
/*     */ {
/*  46 */   private static final Logger logger = LoggerFactory.getLogger(TextLiteralExpression.class);
/*     */   
/*     */ 
/*     */   private static final long serialVersionUID = 6511847028638506552L;
/*     */   
/*     */   static final char ESCAPE_PREFIX = '\\';
/*     */   
/*     */   static final char DELIMITER = '\'';
/*     */   
/*     */   private final LiteralValue value;
/*     */   
/*     */ 
/*     */   public TextLiteralExpression(String value)
/*     */   {
/*  60 */     Validate.notNull(value, "Value cannot be null");
/*  61 */     this.value = new LiteralValue(unwrapLiteral(value));
/*     */   }
/*     */   
/*     */ 
/*     */   public LiteralValue getValue()
/*     */   {
/*  67 */     return this.value;
/*     */   }
/*     */   
/*     */ 
/*     */   private static String unwrapLiteral(String input)
/*     */   {
/*  73 */     int inputLen = input.length();
/*  74 */     if ((inputLen > 1) && (input.charAt(0) == '\'') && (input.charAt(inputLen - 1) == '\'')) {
/*  75 */       return unescapeLiteral(input.substring(1, inputLen - 1));
/*     */     }
/*  77 */     return input;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getStringRepresentation()
/*     */   {
/*  83 */     return 
/*     */     
/*  85 */       String.valueOf('\'') + this.value.getValue().replace(String.valueOf('\''), "\\'") + String.valueOf('\'');
/*     */   }
/*     */   
/*     */ 
/*     */   static TextLiteralExpression parseTextLiteralExpression(String input)
/*     */   {
/*  91 */     return new TextLiteralExpression(input);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static Object executeTextLiteralExpression(IExpressionContext context, TextLiteralExpression expression, StandardExpressionExecutionContext expContext)
/*     */   {
/* 102 */     if (logger.isTraceEnabled()) {
/* 103 */       logger.trace("[THYMELEAF][{}] Evaluating text literal: \"{}\"", TemplateEngine.threadIndex(), expression.getStringRepresentation());
/*     */     }
/*     */     
/* 106 */     return expression.getValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String wrapStringIntoLiteral(String str)
/*     */   {
/* 114 */     if (str == null) {
/* 115 */       return null;
/*     */     }
/*     */     
/* 118 */     int n = str.length();
/* 119 */     while (n-- != 0)
/*     */     {
/* 121 */       if (str.charAt(n) == '\'')
/*     */       {
/* 123 */         StringBuilder strBuilder = new StringBuilder(str.length() + 5);
/*     */         
/* 125 */         strBuilder.append('\'');
/* 126 */         int strLen = str.length();
/* 127 */         for (int i = 0; i < strLen; i++) {
/* 128 */           char c = str.charAt(i);
/* 129 */           if (c == '\'') {
/* 130 */             strBuilder.append('\\');
/*     */           }
/* 132 */           strBuilder.append(c);
/*     */         }
/* 134 */         strBuilder.append('\'');
/*     */         
/* 136 */         return strBuilder.toString();
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 142 */     return '\'' + str + '\'';
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static boolean isDelimiterEscaped(String input, int pos)
/*     */   {
/* 150 */     if ((pos == 0) || (input.charAt(pos - 1) != '\\')) {
/* 151 */       return false;
/*     */     }
/* 153 */     int i = pos - 1;
/* 154 */     boolean odd = false;
/* 155 */     while (i >= 0) {
/* 156 */       if (input.charAt(i) == '\\') {
/* 157 */         odd = !odd;
/*     */       } else {
/* 159 */         return odd;
/*     */       }
/* 161 */       i--;
/*     */     }
/* 163 */     return odd;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static String unescapeLiteral(String text)
/*     */   {
/* 176 */     if (text == null) {
/* 177 */       return null;
/*     */     }
/*     */     
/* 180 */     StringBuilder strBuilder = null;
/*     */     
/* 182 */     int max = text.length();
/*     */     
/* 184 */     int readOffset = 0;
/* 185 */     int referenceOffset = 0;
/*     */     
/*     */ 
/*     */ 
/* 189 */     for (int i = 0; i < max; i++)
/*     */     {
/* 191 */       char c = text.charAt(i);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 197 */       if ((c == '\\') && (i + 1 < max))
/*     */       {
/*     */ 
/*     */ 
/* 201 */         if (c == '\\')
/*     */         {
/* 203 */           switch (text.charAt(i + 1)) {
/* 204 */           case '\'':  c = '\'';referenceOffset = i + 1; break;
/* 205 */           case '\\':  c = '\\';referenceOffset = i + 1; break;
/*     */           default: 
/* 207 */             referenceOffset = i;
/*     */           }
/*     */           
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 219 */         if (strBuilder == null) {
/* 220 */           strBuilder = new StringBuilder(max + 5);
/*     */         }
/*     */         
/* 223 */         if (i - readOffset > 0) {
/* 224 */           strBuilder.append(text, readOffset, i);
/*     */         }
/*     */         
/* 227 */         i = referenceOffset;
/* 228 */         readOffset = i + 1;
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 233 */         strBuilder.append(c);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 245 */     if (strBuilder == null) {
/* 246 */       return text;
/*     */     }
/*     */     
/* 249 */     if (max - readOffset > 0) {
/* 250 */       strBuilder.append(text, readOffset, max);
/*     */     }
/*     */     
/* 253 */     return strBuilder.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\expression\TextLiteralExpression.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */