/*    */ package org.thymeleaf.standard.processor;
/*    */ 
/*    */ import org.thymeleaf.context.ITemplateContext;
/*    */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*    */ import org.thymeleaf.inline.IInliner;
/*    */ import org.thymeleaf.inline.NoOpInliner;
/*    */ import org.thymeleaf.standard.inline.StandardInlineMode;
/*    */ import org.thymeleaf.standard.inline.StandardTextInliner;
/*    */ import org.thymeleaf.standard.inline.StandardXMLInliner;
/*    */ import org.thymeleaf.templatemode.TemplateMode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class StandardInlineXMLTagProcessor
/*    */   extends AbstractStandardTextInlineSettingTagProcessor
/*    */ {
/*    */   public static final int PRECEDENCE = 1000;
/*    */   public static final String ATTR_NAME = "inline";
/*    */   
/*    */   public StandardInlineXMLTagProcessor(String dialectPrefix)
/*    */   {
/* 47 */     super(TemplateMode.XML, dialectPrefix, "inline", 1000);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   protected IInliner getInliner(ITemplateContext context, StandardInlineMode inlineMode)
/*    */   {
/* 55 */     switch (inlineMode) {
/*    */     case NONE: 
/* 57 */       return NoOpInliner.INSTANCE;
/*    */     case XML: 
/* 59 */       return new StandardXMLInliner(context.getConfiguration());
/*    */     case TEXT: 
/* 61 */       return new StandardTextInliner(context.getConfiguration());
/*    */     }
/*    */     
/*    */     
/* 65 */     throw new TemplateProcessingException("Invalid inline mode selected: " + inlineMode + ". Allowed inline modes in template mode " + getTemplateMode() + " are: \"" + StandardInlineMode.XML + "\", \"" + StandardInlineMode.TEXT + "\", \"" + StandardInlineMode.NONE + "\"");
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\processor\StandardInlineXMLTagProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */