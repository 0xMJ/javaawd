/*     */ package org.thymeleaf.standard.processor;
/*     */ 
/*     */ import org.thymeleaf.context.ITemplateContext;
/*     */ import org.thymeleaf.engine.AttributeDefinition;
/*     */ import org.thymeleaf.engine.AttributeDefinitions;
/*     */ import org.thymeleaf.engine.AttributeName;
/*     */ import org.thymeleaf.engine.IAttributeDefinitionsAware;
/*     */ import org.thymeleaf.model.IProcessableElementTag;
/*     */ import org.thymeleaf.processor.element.IElementTagStructureHandler;
/*     */ import org.thymeleaf.standard.util.StandardProcessorUtils;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ import org.thymeleaf.util.EscapedAttributeUtils;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractStandardDoubleAttributeModifierTagProcessor
/*     */   extends AbstractStandardExpressionAttributeTagProcessor
/*     */   implements IAttributeDefinitionsAware
/*     */ {
/*     */   private final boolean removeIfEmpty;
/*     */   private final String attributeOneCompleteName;
/*     */   private final String attributeTwoCompleteName;
/*     */   private AttributeDefinition attributeOneDefinition;
/*     */   private AttributeDefinition attributeTwoDefinition;
/*     */   
/*     */   protected AbstractStandardDoubleAttributeModifierTagProcessor(TemplateMode templateMode, String dialectPrefix, String attrName, int precedence, String attributeOneCompleteName, String attributeTwoCompleteName, boolean removeIfEmpty)
/*     */   {
/*  62 */     super(templateMode, dialectPrefix, attrName, precedence, true, false);
/*     */     
/*  64 */     Validate.notNull(attributeOneCompleteName, "Complete name of attribute one cannot be null");
/*  65 */     Validate.notNull(attributeTwoCompleteName, "Complete name of attribute one cannot be null");
/*     */     
/*  67 */     this.removeIfEmpty = removeIfEmpty;
/*     */     
/*  69 */     this.attributeOneCompleteName = attributeOneCompleteName;
/*  70 */     this.attributeTwoCompleteName = attributeTwoCompleteName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAttributeDefinitions(AttributeDefinitions attributeDefinitions)
/*     */   {
/*  78 */     Validate.notNull(attributeDefinitions, "Attribute Definitions cannot be null");
/*     */     
/*     */ 
/*  81 */     this.attributeOneDefinition = attributeDefinitions.forName(getTemplateMode(), this.attributeOneCompleteName);
/*  82 */     this.attributeTwoDefinition = attributeDefinitions.forName(getTemplateMode(), this.attributeTwoCompleteName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final void doProcess(ITemplateContext context, IProcessableElementTag tag, AttributeName attributeName, String attributeValue, Object expressionResult, IElementTagStructureHandler structureHandler)
/*     */   {
/*  97 */     String newAttributeValue = EscapedAttributeUtils.escapeAttribute(getTemplateMode(), expressionResult == null ? null : expressionResult.toString());
/*     */     
/*     */ 
/* 100 */     if ((this.removeIfEmpty) && ((newAttributeValue == null) || (newAttributeValue.length() == 0)))
/*     */     {
/* 102 */       structureHandler.removeAttribute(this.attributeOneDefinition.getAttributeName());
/* 103 */       structureHandler.removeAttribute(this.attributeTwoDefinition.getAttributeName());
/*     */     }
/*     */     else {
/* 106 */       StandardProcessorUtils.setAttribute(structureHandler, this.attributeOneDefinition, this.attributeOneCompleteName, newAttributeValue);
/* 107 */       StandardProcessorUtils.setAttribute(structureHandler, this.attributeTwoDefinition, this.attributeTwoCompleteName, newAttributeValue);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\processor\AbstractStandardDoubleAttributeModifierTagProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */