/*    */ package org.thymeleaf.standard.expression;
/*    */ 
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ import org.thymeleaf.TemplateEngine;
/*    */ import org.thymeleaf.context.IExpressionContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class NullTokenExpression
/*    */   extends Token
/*    */ {
/* 44 */   private static final Logger logger = LoggerFactory.getLogger(NullTokenExpression.class);
/*    */   
/*    */   private static final long serialVersionUID = -927282151625647619L;
/*    */   
/* 48 */   private static final NullTokenExpression SINGLETON = new NullTokenExpression();
/*    */   
/*    */   public NullTokenExpression()
/*    */   {
/* 52 */     super(null);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public String getStringRepresentation()
/*    */   {
/* 59 */     return "null";
/*    */   }
/*    */   
/*    */ 
/*    */   static NullTokenExpression parseNullTokenExpression(String input)
/*    */   {
/* 65 */     if ("null".equalsIgnoreCase(input)) {
/* 66 */       return SINGLETON;
/*    */     }
/* 68 */     return null;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   static Object executeNullTokenExpression(IExpressionContext context, NullTokenExpression expression, StandardExpressionExecutionContext expContext)
/*    */   {
/* 78 */     if (logger.isTraceEnabled()) {
/* 79 */       logger.trace("[THYMELEAF][{}] Evaluating null token: \"{}\"", TemplateEngine.threadIndex(), expression.getStringRepresentation());
/*    */     }
/*    */     
/* 82 */     return expression.getValue();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\expression\NullTokenExpression.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */