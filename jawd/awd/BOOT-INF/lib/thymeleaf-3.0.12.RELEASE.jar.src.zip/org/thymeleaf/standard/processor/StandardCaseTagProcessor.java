/*     */ package org.thymeleaf.standard.processor;
/*     */ 
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.thymeleaf.TemplateEngine;
/*     */ import org.thymeleaf.context.ITemplateContext;
/*     */ import org.thymeleaf.engine.AttributeName;
/*     */ import org.thymeleaf.engine.TemplateData;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.model.IProcessableElementTag;
/*     */ import org.thymeleaf.standard.expression.EqualsExpression;
/*     */ import org.thymeleaf.standard.expression.IStandardExpression;
/*     */ import org.thymeleaf.standard.expression.IStandardExpressionParser;
/*     */ import org.thymeleaf.standard.expression.StandardExpressions;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ import org.thymeleaf.util.EvaluationUtils;
/*     */ import org.thymeleaf.util.LoggingUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class StandardCaseTagProcessor
/*     */   extends AbstractStandardConditionalVisibilityTagProcessor
/*     */ {
/*  46 */   private final Logger logger = LoggerFactory.getLogger(getClass());
/*     */   
/*     */ 
/*     */   public static final int PRECEDENCE = 275;
/*     */   
/*     */   public static final String ATTR_NAME = "case";
/*     */   
/*     */   public static final String CASE_DEFAULT_ATTRIBUTE_VALUE = "*";
/*     */   
/*     */ 
/*     */   public StandardCaseTagProcessor(TemplateMode templateMode, String dialectPrefix)
/*     */   {
/*  58 */     super(templateMode, dialectPrefix, "case", 275);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isVisible(ITemplateContext context, IProcessableElementTag tag, AttributeName attributeName, String attributeValue)
/*     */   {
/*  75 */     StandardSwitchTagProcessor.SwitchStructure switchStructure = (StandardSwitchTagProcessor.SwitchStructure)context.getVariable("%%SWITCH_EXPR%%");
/*     */     
/*  77 */     if (switchStructure == null) {
/*  78 */       throw new TemplateProcessingException("Cannot specify a \"" + attributeName + "\" attribute in an environment where no switch operator has been defined before.");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  83 */     if (switchStructure.isExecuted()) {
/*  84 */       return false;
/*     */     }
/*     */     
/*  87 */     if ((attributeValue != null) && (attributeValue.trim().equals("*")))
/*     */     {
/*  89 */       if (this.logger.isTraceEnabled()) {
/*  90 */         this.logger.trace("[THYMELEAF][{}][{}] Case expression \"{}\" in attribute \"{}\" has been evaluated as: \"{}\"", new Object[] {
/*  91 */           TemplateEngine.threadIndex(), LoggingUtils.loggifyTemplateName(context.getTemplateData().getTemplate()), attributeValue, attributeName, attributeValue, Boolean.TRUE });
/*     */       }
/*     */       
/*  94 */       switchStructure.setExecuted(true);
/*  95 */       return true;
/*     */     }
/*     */     
/*     */ 
/*  99 */     IStandardExpressionParser expressionParser = StandardExpressions.getExpressionParser(context.getConfiguration());
/*     */     
/*     */ 
/* 102 */     IStandardExpression caseExpression = expressionParser.parseExpression(context, attributeValue);
/*     */     
/* 104 */     EqualsExpression equalsExpression = new EqualsExpression(switchStructure.getExpression(), caseExpression);
/*     */     
/* 106 */     Object value = equalsExpression.execute(context);
/*     */     
/* 108 */     boolean visible = EvaluationUtils.evaluateAsBoolean(value);
/*     */     
/* 110 */     if (this.logger.isTraceEnabled()) {
/* 111 */       this.logger.trace("[THYMELEAF][{}][{}] Case expression \"{}\" in attribute \"{}\" has been evaluated as: \"{}\"", new Object[] {
/* 112 */         TemplateEngine.threadIndex(), LoggingUtils.loggifyTemplateName(context.getTemplateData().getTemplate()), attributeValue, attributeName, attributeValue, Boolean.valueOf(visible) });
/*     */     }
/*     */     
/* 115 */     if (visible) {
/* 116 */       switchStructure.setExecuted(true);
/*     */     }
/*     */     
/* 119 */     return visible;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\processor\StandardCaseTagProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */