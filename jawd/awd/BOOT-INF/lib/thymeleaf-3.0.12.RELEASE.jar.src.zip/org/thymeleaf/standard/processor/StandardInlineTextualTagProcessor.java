/*    */ package org.thymeleaf.standard.processor;
/*    */ 
/*    */ import org.thymeleaf.context.ITemplateContext;
/*    */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*    */ import org.thymeleaf.inline.IInliner;
/*    */ import org.thymeleaf.inline.NoOpInliner;
/*    */ import org.thymeleaf.standard.inline.StandardCSSInliner;
/*    */ import org.thymeleaf.standard.inline.StandardInlineMode;
/*    */ import org.thymeleaf.standard.inline.StandardJavaScriptInliner;
/*    */ import org.thymeleaf.standard.inline.StandardTextInliner;
/*    */ import org.thymeleaf.templatemode.TemplateMode;
/*    */ import org.thymeleaf.util.Validate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class StandardInlineTextualTagProcessor
/*    */   extends AbstractStandardTextInlineSettingTagProcessor
/*    */ {
/*    */   public static final int PRECEDENCE = 1000;
/*    */   public static final String ATTR_NAME = "inline";
/*    */   
/*    */   public StandardInlineTextualTagProcessor(TemplateMode templateMode, String dialectPrefix)
/*    */   {
/* 49 */     super(templateMode, dialectPrefix, "inline", 1000);
/* 50 */     Validate.isTrue(templateMode.isText(), "Template mode must be a textual one");
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   protected IInliner getInliner(ITemplateContext context, StandardInlineMode inlineMode)
/*    */   {
/* 58 */     TemplateMode templateMode = getTemplateMode();
/*    */     
/* 60 */     switch (inlineMode) {
/*    */     case NONE: 
/* 62 */       return NoOpInliner.INSTANCE;
/*    */     case TEXT: 
/* 64 */       if (templateMode == TemplateMode.TEXT) {
/* 65 */         return new StandardTextInliner(context.getConfiguration());
/*    */       }
/*    */       break;
/*    */     case JAVASCRIPT: 
/* 69 */       if (templateMode == TemplateMode.JAVASCRIPT) {
/* 70 */         return new StandardJavaScriptInliner(context.getConfiguration());
/*    */       }
/*    */       break;
/*    */     case CSS: 
/* 74 */       if (templateMode == TemplateMode.CSS) {
/* 75 */         return new StandardCSSInliner(context.getConfiguration());
/*    */       }
/*    */       
/*    */       break;
/*    */     }
/*    */     
/*    */     
/* 82 */     throw new TemplateProcessingException("Invalid inline mode selected: " + inlineMode + ". Allowed inline modes in template mode " + getTemplateMode() + " are: \"" + getTemplateMode() + "\" and \"" + StandardInlineMode.NONE + "\"");
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\processor\StandardInlineTextualTagProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */