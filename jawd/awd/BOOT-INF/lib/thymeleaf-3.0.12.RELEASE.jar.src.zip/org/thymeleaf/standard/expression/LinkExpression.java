/*     */ package org.thymeleaf.standard.expression;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.thymeleaf.TemplateEngine;
/*     */ import org.thymeleaf.context.IExpressionContext;
/*     */ import org.thymeleaf.context.ITemplateContext;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.util.StringUtils;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class LinkExpression
/*     */   extends SimpleExpression
/*     */ {
/*  58 */   private static final Logger logger = LoggerFactory.getLogger(LinkExpression.class);
/*     */   
/*     */   private static final long serialVersionUID = -564516592085017252L;
/*     */   
/*     */   static final char SELECTOR = '@';
/*     */   
/*     */   private static final char PARAMS_START_CHAR = '(';
/*     */   
/*     */   private static final char PARAMS_END_CHAR = ')';
/*  67 */   private static final Pattern LINK_PATTERN = Pattern.compile("^\\s*\\@\\{(.+?)\\}\\s*$", 32);
/*     */   
/*     */ 
/*     */ 
/*     */   private final IStandardExpression base;
/*     */   
/*     */ 
/*     */   private final AssignationSequence parameters;
/*     */   
/*     */ 
/*     */ 
/*     */   public LinkExpression(IStandardExpression base, AssignationSequence parameters)
/*     */   {
/*  80 */     Validate.notNull(base, "Base cannot be null");
/*  81 */     this.base = base;
/*  82 */     this.parameters = parameters;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public IStandardExpression getBase()
/*     */   {
/*  89 */     return this.base;
/*     */   }
/*     */   
/*     */   public AssignationSequence getParameters() {
/*  93 */     return this.parameters;
/*     */   }
/*     */   
/*     */   public boolean hasParameters() {
/*  97 */     return (this.parameters != null) && (this.parameters.size() > 0);
/*     */   }
/*     */   
/*     */   public String getStringRepresentation()
/*     */   {
/* 102 */     StringBuilder sb = new StringBuilder();
/* 103 */     sb.append('@');
/* 104 */     sb.append('{');
/* 105 */     sb.append(this.base);
/* 106 */     if (hasParameters()) {
/* 107 */       sb.append('(');
/* 108 */       sb.append(this.parameters.getStringRepresentation());
/* 109 */       sb.append(')');
/*     */     }
/* 111 */     sb.append('}');
/* 112 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static LinkExpression parseLinkExpression(String input)
/*     */   {
/* 120 */     Matcher matcher = LINK_PATTERN.matcher(input);
/* 121 */     if (!matcher.matches()) {
/* 122 */       return null;
/*     */     }
/*     */     
/* 125 */     String content = matcher.group(1);
/*     */     
/* 127 */     if (StringUtils.isEmptyOrWhitespace(content)) {
/* 128 */       return null;
/*     */     }
/*     */     
/* 131 */     String trimmedInput = content.trim();
/*     */     
/* 133 */     if (trimmedInput.endsWith(String.valueOf(')')))
/*     */     {
/* 135 */       boolean inLiteral = false;
/* 136 */       int nestParLevel = 0;
/*     */       
/* 138 */       for (int i = trimmedInput.length() - 1; i >= 0; i--)
/*     */       {
/* 140 */         char c = trimmedInput.charAt(i);
/*     */         
/* 142 */         if (c == '\'')
/*     */         {
/* 144 */           if ((i == 0) || (content.charAt(i - 1) != '\\')) {
/* 145 */             inLiteral = !inLiteral;
/*     */           }
/*     */         }
/* 148 */         else if ((!inLiteral) && (c == ')'))
/*     */         {
/* 150 */           nestParLevel++;
/*     */         }
/* 152 */         else if ((!inLiteral) && (c == '('))
/*     */         {
/* 154 */           nestParLevel--;
/*     */           
/* 156 */           if (nestParLevel < 0) {
/* 157 */             return null;
/*     */           }
/*     */           
/* 160 */           if (nestParLevel == 0)
/*     */           {
/* 162 */             if (i == 0)
/*     */             {
/* 164 */               Expression baseExpr = parseBaseDefaultAsLiteral(trimmedInput);
/* 165 */               if (baseExpr == null) {
/* 166 */                 return null;
/*     */               }
/* 168 */               return new LinkExpression(baseExpr, null);
/*     */             }
/*     */             
/* 171 */             String base = trimmedInput.substring(0, i).trim();
/* 172 */             String parameters = trimmedInput.substring(i + 1, trimmedInput.length() - 1).trim();
/*     */             
/* 174 */             Expression baseExpr = parseBaseDefaultAsLiteral(base);
/* 175 */             if (baseExpr == null) {
/* 176 */               return null;
/*     */             }
/*     */             
/*     */ 
/* 180 */             AssignationSequence parametersAssigSeq = AssignationUtils.internalParseAssignationSequence(parameters, true);
/*     */             
/* 182 */             if (parametersAssigSeq == null) {
/* 183 */               return null;
/*     */             }
/*     */             
/* 186 */             return new LinkExpression(baseExpr, parametersAssigSeq);
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 193 */       return null;
/*     */     }
/*     */     
/*     */ 
/* 197 */     Expression baseExpr = parseBaseDefaultAsLiteral(trimmedInput);
/* 198 */     if (baseExpr == null) {
/* 199 */       return null;
/*     */     }
/*     */     
/* 202 */     return new LinkExpression(baseExpr, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Expression parseBaseDefaultAsLiteral(String base)
/*     */   {
/* 212 */     if (StringUtils.isEmptyOrWhitespace(base)) {
/* 213 */       return null;
/*     */     }
/*     */     
/* 216 */     Expression expr = Expression.parse(base);
/* 217 */     if (expr == null) {
/* 218 */       return Expression.parse(TextLiteralExpression.wrapStringIntoLiteral(base));
/*     */     }
/* 220 */     return expr;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static Object executeLinkExpression(IExpressionContext context, LinkExpression expression)
/*     */   {
/* 245 */     if (logger.isTraceEnabled()) {
/* 246 */       logger.trace("[THYMELEAF][{}] Evaluating link: \"{}\"", TemplateEngine.threadIndex(), expression.getStringRepresentation());
/*     */     }
/*     */     
/* 249 */     if (!(context instanceof ITemplateContext))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 254 */       throw new TemplateProcessingException("Cannot evaluate expression \"" + expression + "\". Link expressions can only be evaluated in a template-processing environment (as a part of an in-template expression) where processing context is an implementation of " + ITemplateContext.class.getClass() + ", which it isn't (" + context.getClass().getName() + ")");
/*     */     }
/*     */     
/* 257 */     ITemplateContext templateContext = (ITemplateContext)context;
/*     */     
/* 259 */     IStandardExpression baseExpression = expression.getBase();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 264 */     Object base = baseExpression.execute(templateContext, StandardExpressionExecutionContext.RESTRICTED);
/*     */     
/* 266 */     base = LiteralValue.unwrap(base);
/* 267 */     if ((base != null) && (!(base instanceof String))) {
/* 268 */       base = base.toString();
/*     */     }
/* 270 */     if ((base == null) || (StringUtils.isEmptyOrWhitespace((String)base))) {
/* 271 */       base = "";
/*     */     } else {
/* 273 */       base = ((String)base).trim();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 285 */     Map<String, Object> parameters = resolveParameters(templateContext, expression, StandardExpressionExecutionContext.NORMAL);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 292 */     return templateContext.buildLink((String)base, parameters);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Map<String, Object> resolveParameters(IExpressionContext context, LinkExpression expression, StandardExpressionExecutionContext expContext)
/*     */   {
/* 304 */     if (!expression.hasParameters()) {
/* 305 */       return null;
/*     */     }
/*     */     
/*     */ 
/* 309 */     List<Assignation> assignationValues = expression.getParameters().getAssignations();
/* 310 */     int assignationValuesLen = assignationValues.size();
/*     */     
/* 312 */     Map<String, Object> parameters = new LinkedHashMap(assignationValuesLen);
/* 313 */     HashMap<String, String> normalizedParameterNames = new LinkedHashMap(assignationValuesLen + 1, 1.0F);
/*     */     
/* 315 */     for (int i = 0; i < assignationValuesLen; i++)
/*     */     {
/* 317 */       Assignation assignationValue = (Assignation)assignationValues.get(i);
/*     */       
/* 319 */       IStandardExpression parameterNameExpr = assignationValue.getLeft();
/* 320 */       IStandardExpression parameterValueExpr = assignationValue.getRight();
/*     */       
/*     */ 
/* 323 */       Object parameterNameValue = parameterNameExpr.execute(context, expContext);
/* 324 */       String parameterName = parameterNameValue == null ? null : parameterNameValue.toString();
/*     */       
/* 326 */       if (StringUtils.isEmptyOrWhitespace(parameterName))
/*     */       {
/*     */ 
/* 329 */         throw new TemplateProcessingException("Parameters in link expression \"" + expression.getStringRepresentation() + "\" are incorrect: parameter name expression \"" + parameterNameExpr.getStringRepresentation() + "\" evaluated as null or empty string.");
/*     */       }
/*     */       
/*     */       Object parameterValue;
/*     */       Object parameterValue;
/* 334 */       if (parameterValueExpr == null)
/*     */       {
/*     */ 
/* 337 */         parameterValue = null;
/*     */       } else {
/* 339 */         Object value = parameterValueExpr.execute(context, expContext);
/* 340 */         Object parameterValue; if (value == null)
/*     */         {
/* 342 */           parameterValue = "";
/*     */         } else {
/* 344 */           parameterValue = LiteralValue.unwrap(value);
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 349 */       String lowerParameterName = parameterName.toLowerCase();
/* 350 */       if (normalizedParameterNames.containsKey(lowerParameterName)) {
/* 351 */         parameterName = (String)normalizedParameterNames.get(lowerParameterName);
/*     */       } else {
/* 353 */         normalizedParameterNames.put(lowerParameterName, parameterName);
/*     */       }
/*     */       
/*     */ 
/* 357 */       addParameter(parameters, parameterName, parameterValue);
/*     */     }
/*     */     
/* 360 */     return parameters;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void addParameter(Map<String, Object> parameters, String parameterName, Object parameterValue)
/*     */   {
/* 369 */     Validate.notEmpty(parameterName, "Parameter name cannot be null");
/*     */     
/* 371 */     Object normalizedParameterValue = normalizeParameterValue(parameterValue);
/*     */     
/* 373 */     if (parameters.containsKey(parameterName))
/*     */     {
/*     */ 
/* 376 */       Object currentValue = parameters.get(parameterName);
/*     */       
/* 378 */       if ((currentValue == null) || (!(currentValue instanceof List))) {
/* 379 */         List<Object> newValue = new ArrayList(3);
/* 380 */         newValue.add(currentValue);
/* 381 */         currentValue = newValue;
/* 382 */         parameters.put(parameterName, currentValue);
/*     */       }
/*     */       
/* 385 */       if ((normalizedParameterValue != null) && ((normalizedParameterValue instanceof List))) {
/* 386 */         ((List)currentValue).addAll((List)normalizedParameterValue);
/*     */       } else {
/* 388 */         ((List)currentValue).add(normalizedParameterValue);
/*     */       }
/*     */       
/* 391 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 396 */     parameters.put(parameterName, normalizedParameterValue);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Object normalizeParameterValue(Object parameterValue)
/*     */   {
/* 407 */     if (parameterValue == null) {
/* 408 */       return null;
/*     */     }
/*     */     Object localObject1;
/*     */     Object obj;
/* 412 */     if ((parameterValue instanceof Iterable))
/*     */     {
/* 414 */       if ((parameterValue instanceof List))
/*     */       {
/* 416 */         return new ArrayList((List)parameterValue);
/*     */       }
/* 418 */       if ((parameterValue instanceof Set))
/*     */       {
/* 420 */         return new ArrayList((Set)parameterValue);
/*     */       }
/*     */       
/* 423 */       List<Object> result = new ArrayList(4);
/* 424 */       for (localObject1 = ((Iterable)parameterValue).iterator(); ((Iterator)localObject1).hasNext();) { obj = ((Iterator)localObject1).next();
/* 425 */         result.add(obj);
/*     */       }
/* 427 */       return result;
/*     */     }
/*     */     
/*     */ 
/* 431 */     if (parameterValue.getClass().isArray())
/*     */     {
/* 433 */       List<Object> result = new ArrayList(4);
/* 434 */       if ((parameterValue instanceof byte[])) {
/* 435 */         localObject1 = (byte[])parameterValue;obj = localObject1.length; for (Object localObject2 = 0; localObject2 < obj; localObject2++) { byte obj = localObject1[localObject2];
/* 436 */           result.add(Byte.valueOf(obj));
/*     */         }
/* 438 */       } else if ((parameterValue instanceof short[])) {
/* 439 */         localObject1 = (short[])parameterValue;obj = localObject1.length; for (Object localObject3 = 0; localObject3 < obj; localObject3++) { short obj = localObject1[localObject3];
/* 440 */           result.add(Short.valueOf(obj));
/*     */         }
/* 442 */       } else if ((parameterValue instanceof int[])) {
/* 443 */         localObject1 = (int[])parameterValue;obj = localObject1.length; for (Object localObject4 = 0; localObject4 < obj; localObject4++) { int obj = localObject1[localObject4];
/* 444 */           result.add(Integer.valueOf(obj));
/*     */         }
/* 446 */       } else if ((parameterValue instanceof long[])) {
/* 447 */         localObject1 = (long[])parameterValue;obj = localObject1.length; for (Object localObject5 = 0; localObject5 < obj; localObject5++) { long obj = localObject1[localObject5];
/* 448 */           result.add(Long.valueOf(obj));
/*     */         }
/* 450 */       } else if ((parameterValue instanceof float[])) {
/* 451 */         localObject1 = (float[])parameterValue;obj = localObject1.length; for (Object localObject6 = 0; localObject6 < obj; localObject6++) { float obj = localObject1[localObject6];
/* 452 */           result.add(Float.valueOf(obj));
/*     */         }
/* 454 */       } else if ((parameterValue instanceof double[])) {
/* 455 */         localObject1 = (double[])parameterValue;obj = localObject1.length; for (Object localObject7 = 0; localObject7 < obj; localObject7++) { double obj = localObject1[localObject7];
/* 456 */           result.add(Double.valueOf(obj));
/*     */         }
/* 458 */       } else if ((parameterValue instanceof boolean[])) {
/* 459 */         localObject1 = (boolean[])parameterValue;obj = localObject1.length; for (Object localObject8 = 0; localObject8 < obj; localObject8++) { boolean obj = localObject1[localObject8];
/* 460 */           result.add(Boolean.valueOf(obj));
/*     */         }
/* 462 */       } else if ((parameterValue instanceof char[])) {
/* 463 */         localObject1 = (char[])parameterValue;obj = localObject1.length; for (Object localObject9 = 0; localObject9 < obj; localObject9++) { char obj = localObject1[localObject9];
/* 464 */           result.add(Character.valueOf(obj));
/*     */         }
/*     */       } else {
/* 467 */         Object[] objParameterValue = (Object[])parameterValue;
/* 468 */         Collections.addAll(result, objParameterValue);
/*     */       }
/* 470 */       return result;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 475 */     return parameterValue;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\expression\LinkExpression.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */