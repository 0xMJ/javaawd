package org.thymeleaf.standard.expression;

import org.thymeleaf.context.IExpressionContext;

public abstract interface IStandardExpressionParser
{
  public abstract IStandardExpression parseExpression(IExpressionContext paramIExpressionContext, String paramString);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\expression\IStandardExpressionParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */