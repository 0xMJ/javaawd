/*    */ package org.thymeleaf.standard.expression;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AdditionSubtractionExpression
/*    */   extends BinaryOperationExpression
/*    */ {
/*    */   private static final long serialVersionUID = -7977102096580376925L;
/*    */   protected static final String ADDITION_OPERATOR = "+";
/*    */   protected static final String SUBTRACTION_OPERATOR = "-";
/* 40 */   static final String[] OPERATORS = { "+", "-" };
/* 41 */   private static final boolean[] LENIENCIES = { false, true };
/*    */   
/*    */ 
/* 44 */   private static final Class<? extends BinaryOperationExpression>[] OPERATOR_CLASSES = { AdditionExpression.class, SubtractionExpression.class };
/*    */   
/*    */   private static final Method LEFT_ALLOWED_METHOD;
/*    */   
/*    */   private static final Method RIGHT_ALLOWED_METHOD;
/*    */   
/*    */   static
/*    */   {
/*    */     try
/*    */     {
/* 54 */       LEFT_ALLOWED_METHOD = AdditionSubtractionExpression.class.getDeclaredMethod("isLeftAllowed", new Class[] { IStandardExpression.class });
/* 55 */       RIGHT_ALLOWED_METHOD = AdditionSubtractionExpression.class.getDeclaredMethod("isRightAllowed", new Class[] { IStandardExpression.class });
/*    */     } catch (NoSuchMethodException e) {
/* 57 */       throw new ExceptionInInitializerError(e);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   protected AdditionSubtractionExpression(IStandardExpression left, IStandardExpression right)
/*    */   {
/* 64 */     super(left, right);
/*    */   }
/*    */   
/*    */ 
/*    */   static boolean isRightAllowed(IStandardExpression right)
/*    */   {
/* 70 */     return (right != null) && ((!(right instanceof Token)) || ((right instanceof NumberTokenExpression)) || ((right instanceof GenericTokenExpression)));
/*    */   }
/*    */   
/*    */   static boolean isLeftAllowed(IStandardExpression left) {
/* 74 */     return (left != null) && ((!(left instanceof Token)) || ((left instanceof NumberTokenExpression)) || ((left instanceof GenericTokenExpression)));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   static ExpressionParsingState composeAdditionSubtractionExpression(ExpressionParsingState state, int nodeIndex)
/*    */   {
/* 81 */     return composeBinaryOperationExpression(state, nodeIndex, OPERATORS, LENIENCIES, OPERATOR_CLASSES, LEFT_ALLOWED_METHOD, RIGHT_ALLOWED_METHOD);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\expression\AdditionSubtractionExpression.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */