/*     */ package org.thymeleaf.standard.expression;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.thymeleaf.IEngineConfiguration;
/*     */ import org.thymeleaf.TemplateEngine;
/*     */ import org.thymeleaf.context.IExpressionContext;
/*     */ import org.thymeleaf.context.ITemplateContext;
/*     */ import org.thymeleaf.engine.TemplateData;
/*     */ import org.thymeleaf.engine.TemplateManager;
/*     */ import org.thymeleaf.engine.TemplateModel;
/*     */ import org.thymeleaf.exceptions.TemplateInputException;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.util.StringUtils;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FragmentExpression
/*     */   extends SimpleExpression
/*     */ {
/*  53 */   private static final Logger logger = LoggerFactory.getLogger(FragmentExpression.class);
/*     */   
/*     */ 
/*     */ 
/*     */   private static final long serialVersionUID = -130371297698708001L;
/*     */   
/*     */ 
/*  60 */   public static final FragmentExpression EMPTY_FRAGMENT_EXPRESSION = new FragmentExpression();
/*     */   
/*     */ 
/*     */   private static final String TEMPLATE_NAME_CURRENT_TEMPLATE = "this";
/*     */   
/*     */   private static final String SEPARATOR = "::";
/*     */   
/*     */   static final String UNNAMED_PARAMETERS_PREFIX = "_arg";
/*     */   
/*     */   public static final char SELECTOR = '~';
/*     */   
/*  71 */   private static final Pattern FRAGMENT_PATTERN = Pattern.compile("^\\s*~\\{(.*?)\\}\\s*$", 32);
/*     */   
/*     */ 
/*     */   private final IStandardExpression templateName;
/*     */   
/*     */ 
/*     */   private final IStandardExpression fragmentSelector;
/*     */   
/*     */ 
/*     */   private final AssignationSequence parameters;
/*     */   
/*     */ 
/*     */   private final boolean syntheticParameters;
/*     */   
/*     */ 
/*     */ 
/*     */   public FragmentExpression(IStandardExpression templateName, IStandardExpression fragmentSelector, AssignationSequence parameters, boolean syntheticParameters)
/*     */   {
/*  89 */     if ((templateName == null) && (fragmentSelector == null)) {
/*  90 */       throw new IllegalArgumentException("Fragment Expression cannot have null template name and null fragment selector");
/*     */     }
/*     */     
/*  93 */     this.templateName = templateName;
/*  94 */     this.fragmentSelector = fragmentSelector;
/*  95 */     this.parameters = parameters;
/*  96 */     this.syntheticParameters = ((this.parameters != null) && (this.parameters.size() > 0) && (syntheticParameters));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private FragmentExpression()
/*     */   {
/* 103 */     this.templateName = null;
/* 104 */     this.fragmentSelector = null;
/* 105 */     this.parameters = null;
/* 106 */     this.syntheticParameters = false;
/*     */   }
/*     */   
/*     */   public IStandardExpression getTemplateName()
/*     */   {
/* 111 */     return this.templateName;
/*     */   }
/*     */   
/*     */   public IStandardExpression getFragmentSelector() {
/* 115 */     return this.fragmentSelector;
/*     */   }
/*     */   
/*     */   public boolean hasFragmentSelector() {
/* 119 */     return this.fragmentSelector != null;
/*     */   }
/*     */   
/*     */   public AssignationSequence getParameters() {
/* 123 */     return this.parameters;
/*     */   }
/*     */   
/*     */   public boolean hasParameters() {
/* 127 */     return (this.parameters != null) && (this.parameters.size() > 0);
/*     */   }
/*     */   
/*     */   public boolean hasSyntheticParameters() {
/* 131 */     return this.syntheticParameters;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getStringRepresentation()
/*     */   {
/* 139 */     StringBuilder sb = new StringBuilder();
/*     */     
/* 141 */     sb.append('~');
/* 142 */     sb.append('{');
/*     */     
/* 144 */     sb.append(this.templateName != null ? this.templateName.getStringRepresentation() : "");
/*     */     
/* 146 */     if (this.fragmentSelector != null) {
/* 147 */       sb.append(' ');
/* 148 */       sb.append("::");
/* 149 */       sb.append(' ');
/* 150 */       sb.append(this.fragmentSelector.getStringRepresentation());
/*     */     }
/*     */     
/* 153 */     if ((this.parameters != null) && (this.parameters.size() > 0)) {
/* 154 */       sb.append(' ');
/* 155 */       sb.append('(');
/* 156 */       sb.append(StringUtils.join(this.parameters.getAssignations(), ','));
/* 157 */       sb.append(')');
/*     */     }
/*     */     
/* 160 */     sb.append('}');
/*     */     
/* 162 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static FragmentExpression parseFragmentExpression(String input)
/*     */   {
/* 171 */     Matcher matcher = FRAGMENT_PATTERN.matcher(input);
/* 172 */     if (!matcher.matches()) {
/* 173 */       return null;
/*     */     }
/* 175 */     String expression = matcher.group(1);
/* 176 */     if (StringUtils.isEmptyOrWhitespace(expression)) {
/* 177 */       return EMPTY_FRAGMENT_EXPRESSION;
/*     */     }
/* 179 */     return parseFragmentExpressionContent(expression.trim());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static FragmentExpression parseFragmentExpressionContent(String input)
/*     */   {
/* 187 */     if (StringUtils.isEmptyOrWhitespace(input)) {
/* 188 */       return EMPTY_FRAGMENT_EXPRESSION;
/*     */     }
/*     */     
/* 191 */     String trimmedInput = input.trim();
/*     */     
/* 193 */     int lastParenthesesGroupPos = indexOfLastParenthesesGroup(trimmedInput);
/*     */     String inputWithoutParameters;
/*     */     String parametersStr;
/*     */     String inputWithoutParameters;
/* 197 */     if (lastParenthesesGroupPos != -1) {
/* 198 */       String parametersStr = trimmedInput.substring(lastParenthesesGroupPos).trim();
/* 199 */       inputWithoutParameters = trimmedInput.substring(0, lastParenthesesGroupPos).trim();
/*     */     } else {
/* 201 */       parametersStr = null;
/* 202 */       inputWithoutParameters = trimmedInput;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 208 */     int operatorPos = inputWithoutParameters.indexOf("::");
/* 209 */     String templateNameStr; String fragmentSpecStr; if (operatorPos == -1)
/*     */     {
/*     */ 
/*     */ 
/* 213 */       String templateNameStr = inputWithoutParameters;
/* 214 */       String fragmentSpecStr = null;
/* 215 */       if (StringUtils.isEmptyOrWhitespace(templateNameStr)) {
/* 216 */         if (parametersStr != null)
/*     */         {
/* 218 */           templateNameStr = parametersStr;
/* 219 */           parametersStr = null;
/*     */         }
/*     */         else {
/* 222 */           return null;
/*     */         }
/*     */         
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 229 */       templateNameStr = inputWithoutParameters.substring(0, operatorPos).trim();
/* 230 */       fragmentSpecStr = inputWithoutParameters.substring(operatorPos + "::".length()).trim();
/* 231 */       if (StringUtils.isEmptyOrWhitespace(fragmentSpecStr)) {
/* 232 */         if (parametersStr != null)
/*     */         {
/* 234 */           fragmentSpecStr = parametersStr;
/* 235 */           parametersStr = null;
/*     */         }
/*     */         else
/*     */         {
/* 239 */           return null;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     Expression templateNameExpression;
/*     */     
/* 246 */     if (!StringUtils.isEmptyOrWhitespace(templateNameStr)) {
/* 247 */       Expression templateNameExpression = parseDefaultAsLiteral(templateNameStr);
/* 248 */       if (templateNameExpression == null) {
/* 249 */         return null;
/*     */       }
/*     */     } else {
/* 252 */       templateNameExpression = null;
/*     */     }
/*     */     
/*     */     Expression fragmentSpecExpression;
/* 256 */     if (!StringUtils.isEmptyOrWhitespace(fragmentSpecStr)) {
/* 257 */       Expression fragmentSpecExpression = parseDefaultAsLiteral(fragmentSpecStr);
/* 258 */       if (fragmentSpecExpression == null) {
/* 259 */         return null;
/*     */       }
/*     */     } else {
/* 262 */       fragmentSpecExpression = null;
/*     */     }
/*     */     
/* 265 */     if (!StringUtils.isEmptyOrWhitespace(parametersStr))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 270 */       AssignationSequence parametersAsSeq = AssignationUtils.internalParseAssignationSequence(parametersStr, false);
/*     */       
/* 272 */       if (parametersAsSeq != null) {
/* 273 */         return new FragmentExpression(templateNameExpression, fragmentSpecExpression, parametersAsSeq, false);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 281 */       ExpressionSequence parametersExpSeq = ExpressionSequenceUtils.internalParseExpressionSequence(parametersStr);
/*     */       
/* 283 */       if (parametersExpSeq != null)
/*     */       {
/* 285 */         AssignationSequence parametersAsSeqFromExp = createSyntheticallyNamedParameterSequence(parametersExpSeq);
/* 286 */         return new FragmentExpression(templateNameExpression, fragmentSpecExpression, parametersAsSeqFromExp, true);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 292 */       return null;
/*     */     }
/*     */     
/*     */ 
/* 296 */     return new FragmentExpression(templateNameExpression, fragmentSpecExpression, null, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Expression parseDefaultAsLiteral(String input)
/*     */   {
/* 304 */     if (StringUtils.isEmptyOrWhitespace(input)) {
/* 305 */       return null;
/*     */     }
/*     */     
/* 308 */     Expression expr = Expression.parse(input);
/* 309 */     if (expr == null) {
/* 310 */       return Expression.parse(TextLiteralExpression.wrapStringIntoLiteral(input));
/*     */     }
/* 312 */     return expr;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static int indexOfLastParenthesesGroup(String input)
/*     */   {
/* 322 */     int inputLen = input.length();
/* 323 */     char finalC = input.charAt(inputLen - 1);
/* 324 */     if (finalC != ')')
/*     */     {
/* 326 */       return -1;
/*     */     }
/* 328 */     int parenLevel = 1;
/* 329 */     for (int i = inputLen - 2; i >= 0; i--) {
/* 330 */       char c = input.charAt(i);
/* 331 */       if (c == '(') {
/* 332 */         parenLevel--;
/* 333 */         if (parenLevel == 0)
/*     */         {
/* 335 */           if (i == inputLen - 2)
/*     */           {
/* 337 */             return -1;
/*     */           }
/* 339 */           return i;
/*     */         }
/* 341 */       } else if (c == ')') {
/* 342 */         parenLevel++;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 347 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static AssignationSequence createSyntheticallyNamedParameterSequence(ExpressionSequence expSeq)
/*     */   {
/* 354 */     List<Assignation> assignations = new ArrayList(expSeq.size() + 2);
/*     */     
/* 356 */     int argIndex = 0;
/* 357 */     for (IStandardExpression expression : expSeq.getExpressions())
/*     */     {
/* 359 */       IStandardExpression parameterName = Expression.parse(TextLiteralExpression.wrapStringIntoLiteral("_arg" + argIndex++));
/* 360 */       assignations.add(new Assignation(parameterName, expression));
/*     */     }
/*     */     
/* 363 */     return new AssignationSequence(assignations);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static Fragment executeFragmentExpression(IExpressionContext context, FragmentExpression expression)
/*     */   {
/* 379 */     if (!(context instanceof ITemplateContext))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 384 */       throw new TemplateProcessingException("Cannot evaluate expression \"" + expression + "\". Fragment expressions can only be evaluated in a template-processing environment (as a part of an in-template expression) where processing context is an implementation of " + ITemplateContext.class.getClass() + ", which it isn't (" + context.getClass().getName() + ")");
/*     */     }
/*     */     
/* 387 */     if (expression == EMPTY_FRAGMENT_EXPRESSION) {
/* 388 */       return Fragment.EMPTY_FRAGMENT;
/*     */     }
/*     */     
/* 391 */     return resolveExecutedFragmentExpression((ITemplateContext)context, 
/*     */     
/* 393 */       createExecutedFragmentExpression(context, expression), false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public static ExecutedFragmentExpression createExecutedFragmentExpression(IExpressionContext context, FragmentExpression expression, StandardExpressionExecutionContext expContext)
/*     */   {
/* 419 */     return doCreateExecutedFragmentExpression(context, expression, expContext);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static ExecutedFragmentExpression createExecutedFragmentExpression(IExpressionContext context, FragmentExpression expression)
/*     */   {
/* 426 */     return doCreateExecutedFragmentExpression(context, expression, StandardExpressionExecutionContext.RESTRICTED);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static ExecutedFragmentExpression doCreateExecutedFragmentExpression(IExpressionContext context, FragmentExpression expression, StandardExpressionExecutionContext expContext)
/*     */   {
/* 434 */     Validate.notNull(context, "Context cannot be null");
/* 435 */     Validate.notNull(expression, "Fragment Expression cannot be null");
/*     */     
/* 437 */     if (logger.isTraceEnabled()) {
/* 438 */       logger.trace("[THYMELEAF][{}] Evaluating fragment: \"{}\"", TemplateEngine.threadIndex(), expression.getStringRepresentation());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 445 */     if (expression == EMPTY_FRAGMENT_EXPRESSION) {
/* 446 */       return ExecutedFragmentExpression.EMPTY_EXECUTED_FRAGMENT_EXPRESSION;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 453 */     IStandardExpression templateNameExpression = expression.getTemplateName();
/*     */     Object templateNameExpressionResult;
/* 455 */     Object templateNameExpressionResult; if (templateNameExpression != null)
/*     */     {
/*     */ 
/* 458 */       templateNameExpressionResult = templateNameExpression.execute(context, StandardExpressionExecutionContext.RESTRICTED);
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 463 */       templateNameExpressionResult = null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 471 */     Map<String, Object> fragmentParameters = createExecutedFragmentExpressionParameters(context, expression.getParameters(), expression.hasSyntheticParameters(), expContext);
/*     */     
/*     */ 
/*     */     Object fragmentSelectorExpressionResult;
/*     */     
/*     */     Object fragmentSelectorExpressionResult;
/*     */     
/* 478 */     if (expression.hasFragmentSelector())
/*     */     {
/* 480 */       fragmentSelectorExpressionResult = expression.getFragmentSelector().execute(context, expContext);
/*     */     }
/*     */     else
/*     */     {
/* 484 */       fragmentSelectorExpressionResult = null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 491 */     return new ExecutedFragmentExpression(expression, templateNameExpressionResult, fragmentSelectorExpressionResult, fragmentParameters, expression
/*     */     
/*     */ 
/* 494 */       .hasSyntheticParameters());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Map<String, Object> createExecutedFragmentExpressionParameters(IExpressionContext context, AssignationSequence parameters, boolean syntheticParameters, StandardExpressionExecutionContext expContext)
/*     */   {
/* 505 */     if ((parameters == null) || (parameters.size() == 0)) {
/* 506 */       return null;
/*     */     }
/*     */     
/* 509 */     Map<String, Object> parameterValues = new HashMap(parameters.size() + 2);
/* 510 */     List<Assignation> assignationValues = parameters.getAssignations();
/* 511 */     int assignationValuesLen = assignationValues.size();
/*     */     
/* 513 */     for (int i = 0; i < assignationValuesLen; i++)
/*     */     {
/* 515 */       Assignation assignation = (Assignation)assignationValues.get(i);
/*     */       
/* 517 */       IStandardExpression parameterNameExpr = assignation.getLeft();
/*     */       String parameterName;
/*     */       String parameterName;
/* 520 */       if (!syntheticParameters) {
/* 521 */         Object parameterNameValue = parameterNameExpr.execute(context, expContext);
/* 522 */         parameterName = parameterNameValue == null ? null : parameterNameValue.toString();
/*     */       }
/*     */       else {
/* 525 */         parameterName = ((TextLiteralExpression)parameterNameExpr).getValue().getValue();
/*     */       }
/*     */       
/* 528 */       IStandardExpression parameterValueExpr = assignation.getRight();
/* 529 */       Object parameterValueValue = parameterValueExpr.execute(context, expContext);
/*     */       
/* 531 */       parameterValues.put(parameterName, parameterValueValue);
/*     */     }
/*     */     
/*     */ 
/* 535 */     return parameterValues;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Fragment resolveExecutedFragmentExpression(ITemplateContext context, ExecutedFragmentExpression executedFragmentExpression, boolean failIfNotExists)
/*     */   {
/* 547 */     if (executedFragmentExpression == ExecutedFragmentExpression.EMPTY_EXECUTED_FRAGMENT_EXPRESSION) {
/* 548 */       return Fragment.EMPTY_FRAGMENT;
/*     */     }
/*     */     
/* 551 */     IEngineConfiguration configuration = context.getConfiguration();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 556 */     String templateName = resolveTemplateName(executedFragmentExpression);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 562 */     Set<String> fragments = resolveFragments(executedFragmentExpression);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 569 */     List<String> templateNameStack = null;
/*     */     
/* 571 */     if (StringUtils.isEmptyOrWhitespace(templateName))
/*     */     {
/* 573 */       if ((fragments == null) || (fragments.isEmpty())) {
/* 574 */         return null;
/*     */       }
/*     */       
/* 577 */       templateNameStack = new ArrayList(3);
/* 578 */       for (int i = context.getTemplateStack().size() - 1; i >= 0; i--) {
/* 579 */         templateNameStack.add(((TemplateData)context.getTemplateStack().get(i)).getTemplate());
/*     */       }
/* 581 */       templateName = (String)templateNameStack.get(0);
/*     */     }
/*     */     
/*     */ 
/* 585 */     int i = 0;
/*     */     TemplateModel fragmentModel;
/*     */     do {
/* 588 */       fragmentModel = configuration.getTemplateManager().parseStandalone(context, templateName, fragments, null, true, failIfNotExists);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 593 */       i++;
/* 594 */     } while ((fragmentModel != null) && 
/* 595 */       (fragmentModel.size() <= 2) && (templateNameStack != null) && 
/*     */       
/* 597 */       (i < templateNameStack.size()) && 
/* 598 */       ((templateName = (String)templateNameStack.get(i)) != null));
/*     */     
/* 600 */     if (fragmentModel == null)
/*     */     {
/*     */ 
/* 603 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 612 */     boolean fragmentIsEmpty = fragmentModel.size() == 2;
/*     */     
/* 614 */     if (fragmentIsEmpty)
/*     */     {
/*     */ 
/* 617 */       if (failIfNotExists)
/*     */       {
/* 619 */         throw new TemplateInputException("Error resolving fragment: \"" + executedFragmentExpression.fragmentExpression.getStringRepresentation() + "\": template or fragment could not be resolved");
/*     */       }
/*     */       
/* 622 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 629 */     return new Fragment(fragmentModel, executedFragmentExpression.fragmentParameters, executedFragmentExpression.syntheticParameters);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String resolveTemplateName(ExecutedFragmentExpression executedFragmentExpression)
/*     */   {
/* 638 */     Object templateNameObject = executedFragmentExpression.templateNameExpressionResult;
/* 639 */     if (templateNameObject == null)
/*     */     {
/* 641 */       return null;
/*     */     }
/* 643 */     String evaluatedTemplateName = templateNameObject.toString();
/* 644 */     if ("this".equals(evaluatedTemplateName))
/*     */     {
/* 646 */       return null;
/*     */     }
/* 648 */     return templateNameObject.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Set<String> resolveFragments(ExecutedFragmentExpression executedFragmentExpression)
/*     */   {
/* 657 */     Object fragmentSelectorObject = executedFragmentExpression.fragmentSelectorExpressionResult;
/* 658 */     if (fragmentSelectorObject != null)
/*     */     {
/* 660 */       String fragmentSelector = fragmentSelectorObject.toString();
/*     */       
/* 662 */       if ((fragmentSelector.length() > 3) && 
/* 663 */         (fragmentSelector.charAt(0) == '[') && (fragmentSelector.charAt(fragmentSelector.length() - 1) == ']') && 
/* 664 */         (fragmentSelector.charAt(fragmentSelector.length() - 2) != '\''))
/*     */       {
/*     */ 
/* 667 */         fragmentSelector = fragmentSelector.substring(1, fragmentSelector.length() - 1).trim();
/*     */       }
/*     */       
/* 670 */       if (fragmentSelector.trim().length() > 0) {
/* 671 */         return Collections.singleton(fragmentSelector);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 676 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final class ExecutedFragmentExpression
/*     */   {
/* 686 */     public static final ExecutedFragmentExpression EMPTY_EXECUTED_FRAGMENT_EXPRESSION = new ExecutedFragmentExpression(FragmentExpression.EMPTY_FRAGMENT_EXPRESSION, null, null, null, false);
/*     */     
/*     */     private final FragmentExpression fragmentExpression;
/*     */     
/*     */     private final Object templateNameExpressionResult;
/*     */     
/*     */     private final Object fragmentSelectorExpressionResult;
/*     */     
/*     */     private final Map<String, Object> fragmentParameters;
/*     */     
/*     */     private final boolean syntheticParameters;
/*     */     
/*     */     ExecutedFragmentExpression(FragmentExpression fragmentExpression, Object templateNameExpressionResult, Object fragmentSelectorExpressionResult, Map<String, Object> fragmentParameters, boolean syntheticParameters)
/*     */     {
/* 700 */       this.fragmentExpression = fragmentExpression;
/* 701 */       this.templateNameExpressionResult = templateNameExpressionResult;
/* 702 */       this.fragmentSelectorExpressionResult = fragmentSelectorExpressionResult;
/* 703 */       this.fragmentParameters = fragmentParameters;
/* 704 */       this.syntheticParameters = syntheticParameters;
/*     */     }
/*     */     
/*     */     FragmentExpression getFragmentExpression() {
/* 708 */       return this.fragmentExpression;
/*     */     }
/*     */     
/*     */     public Object getTemplateNameExpressionResult() {
/* 712 */       return this.templateNameExpressionResult;
/*     */     }
/*     */     
/*     */     public Object getFragmentSelectorExpressionResult() {
/* 716 */       return this.fragmentSelectorExpressionResult;
/*     */     }
/*     */     
/*     */     public Map<String, Object> getFragmentParameters() {
/* 720 */       return this.fragmentParameters;
/*     */     }
/*     */     
/*     */     public boolean hasSyntheticParameters() {
/* 724 */       return this.syntheticParameters;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\expression\FragmentExpression.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */