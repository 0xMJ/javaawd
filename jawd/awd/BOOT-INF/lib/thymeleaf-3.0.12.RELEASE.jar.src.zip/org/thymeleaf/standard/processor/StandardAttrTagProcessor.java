/*    */ package org.thymeleaf.standard.processor;
/*    */ 
/*    */ import org.thymeleaf.templatemode.TemplateMode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class StandardAttrTagProcessor
/*    */   extends AbstractStandardMultipleAttributeModifierTagProcessor
/*    */ {
/*    */   public static final int PRECEDENCE = 700;
/*    */   public static final String ATTR_NAME = "attr";
/*    */   
/*    */   public StandardAttrTagProcessor(TemplateMode templateMode, String dialectPrefix)
/*    */   {
/* 38 */     super(templateMode, dialectPrefix, "attr", 700, AbstractStandardMultipleAttributeModifierTagProcessor.ModificationType.SUBSTITUTION, true);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\processor\StandardAttrTagProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */