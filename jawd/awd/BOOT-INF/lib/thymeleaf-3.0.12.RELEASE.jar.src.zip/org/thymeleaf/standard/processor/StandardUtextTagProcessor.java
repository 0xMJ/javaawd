/*     */ package org.thymeleaf.standard.processor;
/*     */ 
/*     */ import java.util.Set;
/*     */ import org.thymeleaf.IEngineConfiguration;
/*     */ import org.thymeleaf.context.ITemplateContext;
/*     */ import org.thymeleaf.engine.AttributeName;
/*     */ import org.thymeleaf.engine.TemplateManager;
/*     */ import org.thymeleaf.engine.TemplateModel;
/*     */ import org.thymeleaf.model.IProcessableElementTag;
/*     */ import org.thymeleaf.postprocessor.IPostProcessor;
/*     */ import org.thymeleaf.processor.element.AbstractAttributeTagProcessor;
/*     */ import org.thymeleaf.processor.element.IElementTagStructureHandler;
/*     */ import org.thymeleaf.standard.expression.Fragment;
/*     */ import org.thymeleaf.standard.expression.FragmentExpression;
/*     */ import org.thymeleaf.standard.expression.FragmentExpression.ExecutedFragmentExpression;
/*     */ import org.thymeleaf.standard.expression.IStandardExpression;
/*     */ import org.thymeleaf.standard.expression.IStandardExpressionParser;
/*     */ import org.thymeleaf.standard.expression.NoOpToken;
/*     */ import org.thymeleaf.standard.expression.StandardExpressionExecutionContext;
/*     */ import org.thymeleaf.standard.expression.StandardExpressions;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class StandardUtextTagProcessor
/*     */   extends AbstractAttributeTagProcessor
/*     */ {
/*     */   public static final int PRECEDENCE = 1400;
/*     */   public static final String ATTR_NAME = "utext";
/*     */   
/*     */   public StandardUtextTagProcessor(TemplateMode templateMode, String dialectPrefix)
/*     */   {
/*  55 */     super(templateMode, dialectPrefix, null, false, "utext", true, 1400, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void doProcess(ITemplateContext context, IProcessableElementTag tag, AttributeName attributeName, String attributeValue, IElementTagStructureHandler structureHandler)
/*     */   {
/*  67 */     IEngineConfiguration configuration = context.getConfiguration();
/*     */     
/*  69 */     IStandardExpressionParser expressionParser = StandardExpressions.getExpressionParser(configuration);
/*     */     
/*  71 */     IStandardExpression expression = expressionParser.parseExpression(context, attributeValue);
/*     */     Object expressionResult;
/*     */     Object expressionResult;
/*  74 */     if ((expression != null) && ((expression instanceof FragmentExpression)))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  80 */       FragmentExpression.ExecutedFragmentExpression executedFragmentExpression = FragmentExpression.createExecutedFragmentExpression(context, (FragmentExpression)expression);
/*     */       
/*     */ 
/*  83 */       expressionResult = FragmentExpression.resolveExecutedFragmentExpression(context, executedFragmentExpression, true);
/*     */     }
/*     */     else
/*     */     {
/*  87 */       expressionResult = expression.execute(context, StandardExpressionExecutionContext.RESTRICTED);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  93 */     if (expressionResult == NoOpToken.VALUE) {
/*  94 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 102 */     if ((expressionResult != null) && ((expressionResult instanceof Fragment))) {
/* 103 */       if (expressionResult == Fragment.EMPTY_FRAGMENT) {
/* 104 */         structureHandler.removeBody();
/* 105 */         return;
/*     */       }
/* 107 */       structureHandler.setBody(((Fragment)expressionResult).getTemplateModel(), false);
/* 108 */       return;
/*     */     }
/*     */     
/*     */ 
/* 112 */     String unescapedTextStr = expressionResult == null ? "" : expressionResult.toString();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 125 */     Set<IPostProcessor> postProcessors = configuration.getPostProcessors(getTemplateMode());
/* 126 */     if (postProcessors.isEmpty()) {
/* 127 */       structureHandler.setBody(unescapedTextStr, false);
/* 128 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 136 */     if (!mightContainStructures(unescapedTextStr))
/*     */     {
/* 138 */       structureHandler.setBody(unescapedTextStr, false);
/* 139 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 147 */     TemplateModel parsedFragment = configuration.getTemplateManager().parseString(context
/* 148 */       .getTemplateData(), unescapedTextStr, 0, 0, null, false);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 156 */     structureHandler.setBody(parsedFragment, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean mightContainStructures(CharSequence unescapedText)
/*     */   {
/* 168 */     int n = unescapedText.length();
/*     */     
/* 170 */     while (n-- != 0) {
/* 171 */       char c = unescapedText.charAt(n);
/* 172 */       if ((c == '>') || (c == ']'))
/*     */       {
/* 174 */         return true;
/*     */       }
/*     */     }
/* 177 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\processor\StandardUtextTagProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */