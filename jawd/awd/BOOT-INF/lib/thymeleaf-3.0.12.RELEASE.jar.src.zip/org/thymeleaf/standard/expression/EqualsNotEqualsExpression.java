/*    */ package org.thymeleaf.standard.expression;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class EqualsNotEqualsExpression
/*    */   extends BinaryOperationExpression
/*    */ {
/*    */   private static final long serialVersionUID = -8648395536336588140L;
/*    */   protected static final String EQUALS_OPERATOR = "==";
/*    */   protected static final String EQUALS_OPERATOR_2 = "eq";
/*    */   protected static final String NOT_EQUALS_OPERATOR = "!=";
/*    */   protected static final String NOT_EQUALS_OPERATOR_2 = "neq";
/*    */   protected static final String NOT_EQUALS_OPERATOR_3 = "ne";
/* 44 */   static final String[] OPERATORS = { "==", "!=", "eq", "neq", "ne" };
/* 45 */   private static final boolean[] LENIENCIES = { false, false, false, false, false };
/*    */   
/*    */ 
/* 48 */   private static final Class<? extends BinaryOperationExpression>[] OPERATOR_CLASSES = { EqualsExpression.class, NotEqualsExpression.class, EqualsExpression.class, NotEqualsExpression.class, NotEqualsExpression.class };
/*    */   
/*    */   private static final Method LEFT_ALLOWED_METHOD;
/*    */   
/*    */   private static final Method RIGHT_ALLOWED_METHOD;
/*    */   
/*    */   static
/*    */   {
/*    */     try
/*    */     {
/* 58 */       LEFT_ALLOWED_METHOD = EqualsNotEqualsExpression.class.getDeclaredMethod("isLeftAllowed", new Class[] { IStandardExpression.class });
/* 59 */       RIGHT_ALLOWED_METHOD = EqualsNotEqualsExpression.class.getDeclaredMethod("isRightAllowed", new Class[] { IStandardExpression.class });
/*    */     } catch (NoSuchMethodException e) {
/* 61 */       throw new ExceptionInInitializerError(e);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   protected EqualsNotEqualsExpression(IStandardExpression left, IStandardExpression right)
/*    */   {
/* 69 */     super(left, right);
/*    */   }
/*    */   
/*    */ 
/*    */   static boolean isRightAllowed(IStandardExpression right)
/*    */   {
/* 75 */     return true;
/*    */   }
/*    */   
/*    */   static boolean isLeftAllowed(IStandardExpression left) {
/* 79 */     return true;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   protected static ExpressionParsingState composeEqualsNotEqualsExpression(ExpressionParsingState state, int nodeIndex)
/*    */   {
/* 87 */     return composeBinaryOperationExpression(state, nodeIndex, OPERATORS, LENIENCIES, OPERATOR_CLASSES, LEFT_ALLOWED_METHOD, RIGHT_ALLOWED_METHOD);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\expression\EqualsNotEqualsExpression.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */