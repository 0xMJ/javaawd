/*    */ package org.thymeleaf.standard.processor;
/*    */ 
/*    */ import org.thymeleaf.templatemode.TemplateMode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class StandardAttrprependTagProcessor
/*    */   extends AbstractStandardMultipleAttributeModifierTagProcessor
/*    */ {
/*    */   public static final int PRECEDENCE = 800;
/*    */   public static final String ATTR_NAME = "attrprepend";
/*    */   
/*    */   public StandardAttrprependTagProcessor(TemplateMode templateMode, String dialectPrefix)
/*    */   {
/* 38 */     super(templateMode, dialectPrefix, "attrprepend", 800, AbstractStandardMultipleAttributeModifierTagProcessor.ModificationType.PREPEND, true);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\processor\StandardAttrprependTagProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */