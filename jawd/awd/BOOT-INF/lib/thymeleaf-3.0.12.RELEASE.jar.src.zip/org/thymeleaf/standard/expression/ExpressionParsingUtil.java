/*     */ package org.thymeleaf.standard.expression;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import org.thymeleaf.util.ArrayUtils;
/*     */ import org.thymeleaf.util.StringUtils;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ExpressionParsingUtil
/*     */ {
/*     */   private static final String[] PROTECTED_TOKENS;
/*     */   
/*     */   static
/*     */   {
/*  78 */     List<String> protectedTokenList = new ArrayList(30);
/*  79 */     protectedTokenList.addAll(Arrays.asList(AndExpression.OPERATORS));
/*  80 */     protectedTokenList.addAll(Arrays.asList(EqualsNotEqualsExpression.OPERATORS));
/*  81 */     protectedTokenList.addAll(Arrays.asList(GreaterLesserExpression.OPERATORS));
/*  82 */     protectedTokenList.addAll(Arrays.asList(MultiplicationDivisionRemainderExpression.OPERATORS));
/*  83 */     protectedTokenList.addAll(Arrays.asList(NegationExpression.OPERATORS));
/*  84 */     protectedTokenList.addAll(Arrays.asList(OrExpression.OPERATORS));
/*  85 */     PROTECTED_TOKENS = (String[])protectedTokenList.toArray(new String[protectedTokenList.size()]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ExpressionParsingState decompose(String input)
/*     */   {
/*  93 */     ExpressionParsingState state = decomposeSimpleExpressions(LiteralSubstitutionUtil.performLiteralSubstitution(input));
/*  94 */     return decomposeNestingParenthesis(state, 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static ExpressionParsingState decomposeSimpleExpressions(String input)
/*     */   {
/* 102 */     if (input == null) {
/* 103 */       return null;
/*     */     }
/*     */     
/* 106 */     ExpressionParsingState state = new ExpressionParsingState();
/*     */     
/* 108 */     if (StringUtils.isEmptyOrWhitespace(input)) {
/* 109 */       state.addNode(input);
/* 110 */       return state;
/*     */     }
/*     */     
/* 113 */     StringBuilder decomposedInput = new StringBuilder(24);
/* 114 */     StringBuilder currentFragment = new StringBuilder(24);
/* 115 */     int currentIndex = 1;
/*     */     
/* 117 */     int expLevel = 0;
/* 118 */     boolean inLiteral = false;
/* 119 */     boolean inToken = false;
/* 120 */     boolean inNothing = true;
/*     */     
/* 122 */     int inputLen = input.length();
/* 123 */     for (int i = 0; i < inputLen; i++)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 128 */       if ((inToken) && (!Token.isTokenChar(input, i)))
/*     */       {
/* 130 */         if (finishCurrentToken(currentIndex, state, decomposedInput, currentFragment) != null)
/*     */         {
/*     */ 
/* 133 */           currentIndex++;
/*     */         }
/*     */         
/* 136 */         inToken = false;
/* 137 */         inNothing = true;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 146 */       char c = input.charAt(i);
/*     */       
/* 148 */       if ((inNothing) && (c == '\'') && (!TextLiteralExpression.isDelimiterEscaped(input, i)))
/*     */       {
/*     */ 
/* 151 */         finishCurrentFragment(decomposedInput, currentFragment);
/*     */         
/* 153 */         currentFragment.append(c);
/*     */         
/* 155 */         inLiteral = true;
/* 156 */         inNothing = false;
/*     */       }
/* 158 */       else if ((inLiteral) && (c == '\'') && (!TextLiteralExpression.isDelimiterEscaped(input, i)))
/*     */       {
/*     */ 
/* 161 */         currentFragment.append(c);
/*     */         
/*     */ 
/* 164 */         TextLiteralExpression expr = TextLiteralExpression.parseTextLiteralExpression(currentFragment.toString());
/* 165 */         if (addExpressionAtIndex(expr, currentIndex++, state, decomposedInput, currentFragment) == null) {
/* 166 */           return null;
/*     */         }
/*     */         
/* 169 */         inLiteral = false;
/* 170 */         inNothing = true;
/*     */       }
/* 172 */       else if (inLiteral)
/*     */       {
/*     */ 
/* 175 */         currentFragment.append(c);
/*     */       } else {
/* 177 */         if ((inNothing) && ((c == '$') || (c == '*') || (c == '#') || (c == '@') || (c == '~')) && (i + 1 < inputLen))
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 183 */           if (input.charAt(i + 1) == '{')
/*     */           {
/*     */ 
/* 186 */             finishCurrentFragment(decomposedInput, currentFragment);
/*     */             
/* 188 */             currentFragment.append(c);
/* 189 */             currentFragment.append('{');
/* 190 */             i++;
/*     */             
/* 192 */             expLevel = 1;
/* 193 */             inNothing = false; continue;
/*     */           } }
/* 195 */         if ((expLevel == 1) && (c == '}'))
/*     */         {
/*     */ 
/* 198 */           currentFragment.append('}');
/*     */           
/* 200 */           char expSelectorChar = currentFragment.charAt(0);
/*     */           Expression expr;
/*     */           Expression expr;
/* 203 */           Expression expr; Expression expr; Expression expr; switch (expSelectorChar) {
/*     */           case '$': 
/* 205 */             expr = VariableExpression.parseVariableExpression(currentFragment.toString()); break;
/*     */           case '*': 
/* 207 */             expr = SelectionVariableExpression.parseSelectionVariableExpression(currentFragment.toString()); break;
/*     */           case '#': 
/* 209 */             expr = MessageExpression.parseMessageExpression(currentFragment.toString()); break;
/*     */           case '@': 
/* 211 */             expr = LinkExpression.parseLinkExpression(currentFragment.toString()); break;
/*     */           case '~': 
/* 213 */             expr = FragmentExpression.parseFragmentExpression(currentFragment.toString()); break;
/*     */           default: 
/* 215 */             return null;
/*     */           }
/*     */           Expression expr;
/* 218 */           if (addExpressionAtIndex(expr, currentIndex++, state, decomposedInput, currentFragment) == null) {
/* 219 */             return null;
/*     */           }
/*     */           
/* 222 */           expLevel = 0;
/* 223 */           inNothing = true;
/*     */         }
/* 225 */         else if ((expLevel > 0) && (c == '{'))
/*     */         {
/*     */ 
/* 228 */           expLevel++;
/* 229 */           currentFragment.append('{');
/*     */         }
/* 231 */         else if ((expLevel > 1) && (c == '}'))
/*     */         {
/*     */ 
/* 234 */           expLevel--;
/* 235 */           currentFragment.append('}');
/*     */         }
/* 237 */         else if (expLevel > 0)
/*     */         {
/*     */ 
/* 240 */           currentFragment.append(c);
/*     */         }
/* 242 */         else if ((inNothing) && (Token.isTokenChar(input, i)))
/*     */         {
/*     */ 
/* 245 */           finishCurrentFragment(decomposedInput, currentFragment);
/*     */           
/* 247 */           currentFragment.append(c);
/*     */           
/* 249 */           inToken = true;
/* 250 */           inNothing = false;
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/*     */ 
/* 256 */           currentFragment.append(c);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 263 */     if ((inLiteral) || (expLevel > 0)) {
/* 264 */       return null;
/*     */     }
/*     */     
/* 267 */     if (inToken)
/*     */     {
/*     */ 
/* 270 */       if (finishCurrentToken(currentIndex++, state, decomposedInput, currentFragment) != null)
/*     */       {
/*     */ 
/* 273 */         currentIndex++;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 278 */     decomposedInput.append(currentFragment);
/*     */     
/* 280 */     state.insertNode(0, decomposedInput.toString());
/*     */     
/* 282 */     return state;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Expression addExpressionAtIndex(Expression expression, int index, ExpressionParsingState state, StringBuilder decomposedInput, StringBuilder currentFragment)
/*     */   {
/* 292 */     if (expression == null) {
/* 293 */       return null;
/*     */     }
/*     */     
/* 296 */     decomposedInput.append('§');
/* 297 */     decomposedInput.append(String.valueOf(index));
/* 298 */     decomposedInput.append('§');
/* 299 */     state.addNode(expression);
/* 300 */     currentFragment.setLength(0);
/*     */     
/* 302 */     return expression;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void finishCurrentFragment(StringBuilder decomposedInput, StringBuilder currentFragment)
/*     */   {
/* 310 */     decomposedInput.append(currentFragment);
/* 311 */     currentFragment.setLength(0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Expression finishCurrentToken(int currentIndex, ExpressionParsingState state, StringBuilder decomposedInput, StringBuilder currentFragment)
/*     */   {
/* 320 */     String token = currentFragment.toString();
/*     */     
/* 322 */     Expression expr = parseAsToken(token);
/* 323 */     if (addExpressionAtIndex(expr, currentIndex, state, decomposedInput, currentFragment) == null)
/*     */     {
/* 325 */       decomposedInput.append(currentFragment);
/* 326 */       currentFragment.setLength(0);
/* 327 */       return null;
/*     */     }
/*     */     
/* 330 */     return expr;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Expression parseAsToken(String token)
/*     */   {
/* 339 */     if (ArrayUtils.contains(PROTECTED_TOKENS, token.toLowerCase()))
/*     */     {
/*     */ 
/* 342 */       return null;
/*     */     }
/*     */     
/* 345 */     NumberTokenExpression numberTokenExpr = NumberTokenExpression.parseNumberTokenExpression(token);
/* 346 */     if (numberTokenExpr != null) {
/* 347 */       return numberTokenExpr;
/*     */     }
/*     */     
/* 350 */     BooleanTokenExpression booleanTokenExpr = BooleanTokenExpression.parseBooleanTokenExpression(token);
/* 351 */     if (booleanTokenExpr != null) {
/* 352 */       return booleanTokenExpr;
/*     */     }
/*     */     
/* 355 */     NullTokenExpression nullTokenExpr = NullTokenExpression.parseNullTokenExpression(token);
/* 356 */     if (nullTokenExpr != null) {
/* 357 */       return nullTokenExpr;
/*     */     }
/*     */     
/* 360 */     NoOpTokenExpression noOpTokenExpr = NoOpTokenExpression.parseNoOpTokenExpression(token);
/* 361 */     if (noOpTokenExpr != null) {
/* 362 */       return noOpTokenExpr;
/*     */     }
/*     */     
/* 365 */     GenericTokenExpression genericTokenExpr = GenericTokenExpression.parseGenericTokenExpression(token);
/* 366 */     if (genericTokenExpr != null) {
/* 367 */       return genericTokenExpr;
/*     */     }
/*     */     
/* 370 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ExpressionParsingState unnest(ExpressionParsingState state)
/*     */   {
/* 388 */     Validate.notNull(state, "Parsing state cannot be null");
/* 389 */     return decomposeNestingParenthesis(state, 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static ExpressionParsingState decomposeNestingParenthesis(ExpressionParsingState state, int nodeIndex)
/*     */   {
/* 397 */     if ((state == null) || (nodeIndex >= state.size())) {
/* 398 */       return null;
/*     */     }
/*     */     
/* 401 */     if (state.hasExpressionAt(nodeIndex)) {
/* 402 */       return state;
/*     */     }
/*     */     
/* 405 */     String input = ((ExpressionParsingNode)state.get(nodeIndex)).getInput();
/*     */     
/* 407 */     StringBuilder decomposedString = new StringBuilder(24);
/* 408 */     StringBuilder currentFragment = new StringBuilder(24);
/* 409 */     int currentIndex = state.size();
/* 410 */     List<Integer> nestedInputs = new ArrayList(6);
/*     */     
/* 412 */     int parLevel = 0;
/*     */     
/* 414 */     int inputLen = input.length();
/* 415 */     for (int i = 0; i < inputLen; i++)
/*     */     {
/* 417 */       char c = input.charAt(i);
/*     */       
/* 419 */       if (c == '(')
/*     */       {
/* 421 */         if (parLevel == 0)
/*     */         {
/* 423 */           decomposedString.append(currentFragment);
/* 424 */           currentFragment.setLength(0);
/*     */         } else {
/* 426 */           currentFragment.append('(');
/*     */         }
/*     */         
/* 429 */         parLevel++;
/*     */ 
/*     */       }
/* 432 */       else if (c == ')')
/*     */       {
/* 434 */         parLevel--;
/*     */         
/* 436 */         if (parLevel < 0) {
/* 437 */           return null;
/*     */         }
/*     */         
/* 440 */         if (parLevel == 0)
/*     */         {
/* 442 */           int nestedIndex = currentIndex++;
/* 443 */           nestedInputs.add(Integer.valueOf(nestedIndex));
/* 444 */           decomposedString.append('§');
/* 445 */           decomposedString.append(String.valueOf(nestedIndex));
/* 446 */           decomposedString.append('§');
/* 447 */           state.addNode(currentFragment.toString());
/* 448 */           currentFragment.setLength(0);
/*     */         } else {
/* 450 */           currentFragment.append(')');
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 455 */         currentFragment.append(c);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 461 */     if (parLevel > 0) {
/* 462 */       return null;
/*     */     }
/*     */     
/* 465 */     decomposedString.append(currentFragment);
/*     */     
/* 467 */     state.setNode(nodeIndex, decomposedString.toString());
/*     */     
/*     */ 
/* 470 */     for (Integer nestedInput : nestedInputs) {
/* 471 */       if (decomposeNestingParenthesis(state, nestedInput.intValue()) == null) {
/* 472 */         return null;
/*     */       }
/*     */     }
/*     */     
/* 476 */     return state;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ExpressionParsingState compose(ExpressionParsingState state)
/*     */   {
/* 491 */     return compose(state, 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static ExpressionParsingState compose(ExpressionParsingState state, int nodeIndex)
/*     */   {
/* 499 */     if ((state == null) || (nodeIndex >= state.size())) {
/* 500 */       return null;
/*     */     }
/*     */     
/* 503 */     if (state.hasExpressionAt(nodeIndex)) {
/* 504 */       return state;
/*     */     }
/*     */     
/* 507 */     String input = ((ExpressionParsingNode)state.get(nodeIndex)).getInput();
/*     */     
/* 509 */     if (StringUtils.isEmptyOrWhitespace(input)) {
/* 510 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 518 */     int parsedIndex = parseAsSimpleIndexPlaceholder(input);
/* 519 */     if (parsedIndex != -1) {
/* 520 */       if (compose(state, parsedIndex) == null) {
/* 521 */         return null;
/*     */       }
/* 523 */       if (!state.hasExpressionAt(parsedIndex)) {
/* 524 */         return null;
/*     */       }
/* 526 */       state.setNode(nodeIndex, ((ExpressionParsingNode)state.get(parsedIndex)).getExpression());
/* 527 */       return state;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 534 */     if (ConditionalExpression.composeConditionalExpression(state, nodeIndex) == null) {
/* 535 */       return null;
/*     */     }
/* 537 */     if (state.hasExpressionAt(nodeIndex)) {
/* 538 */       return state;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 545 */     if (DefaultExpression.composeDefaultExpression(state, nodeIndex) == null) {
/* 546 */       return null;
/*     */     }
/* 548 */     if (state.hasExpressionAt(nodeIndex)) {
/* 549 */       return state;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 556 */     if (OrExpression.composeOrExpression(state, nodeIndex) == null) {
/* 557 */       return null;
/*     */     }
/* 559 */     if (state.hasExpressionAt(nodeIndex)) {
/* 560 */       return state;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 567 */     if (AndExpression.composeAndExpression(state, nodeIndex) == null) {
/* 568 */       return null;
/*     */     }
/* 570 */     if (state.hasExpressionAt(nodeIndex)) {
/* 571 */       return state;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 578 */     if (EqualsNotEqualsExpression.composeEqualsNotEqualsExpression(state, nodeIndex) == null) {
/* 579 */       return null;
/*     */     }
/* 581 */     if (state.hasExpressionAt(nodeIndex)) {
/* 582 */       return state;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 589 */     if (GreaterLesserExpression.composeGreaterLesserExpression(state, nodeIndex) == null) {
/* 590 */       return null;
/*     */     }
/* 592 */     if (state.hasExpressionAt(nodeIndex)) {
/* 593 */       return state;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 600 */     if (AdditionSubtractionExpression.composeAdditionSubtractionExpression(state, nodeIndex) == null) {
/* 601 */       return null;
/*     */     }
/* 603 */     if (state.hasExpressionAt(nodeIndex)) {
/* 604 */       return state;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 611 */     if (MultiplicationDivisionRemainderExpression.composeMultiplicationDivisionRemainderExpression(state, nodeIndex) == null) {
/* 612 */       return null;
/*     */     }
/* 614 */     if (state.hasExpressionAt(nodeIndex)) {
/* 615 */       return state;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 622 */     if (MinusExpression.composeMinusExpression(state, nodeIndex) == null) {
/* 623 */       return null;
/*     */     }
/* 625 */     if (state.hasExpressionAt(nodeIndex)) {
/* 626 */       return state;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 633 */     if (NegationExpression.composeNegationExpression(state, nodeIndex) == null) {
/* 634 */       return null;
/*     */     }
/* 636 */     if (state.hasExpressionAt(nodeIndex)) {
/* 637 */       return state;
/*     */     }
/*     */     
/* 640 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int parseAsSimpleIndexPlaceholder(String placeholder)
/*     */   {
/* 650 */     String str = placeholder.trim();
/* 651 */     int strLen = str.length();
/* 652 */     if (strLen <= 2) {
/* 653 */       return -1;
/*     */     }
/* 655 */     if ((str.charAt(0) != '§') || (str.charAt(strLen - 1) != '§')) {
/* 656 */       return -1;
/*     */     }
/* 658 */     for (int i = 1; i < strLen - 1; i++) {
/* 659 */       if (!Character.isDigit(str.charAt(i))) {
/* 660 */         return -1;
/*     */       }
/*     */     }
/* 663 */     return Integer.parseInt(str.substring(1, strLen - 1));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static Expression parseAndCompose(ExpressionParsingState state, String parseTarget)
/*     */   {
/* 675 */     int index = parseAsSimpleIndexPlaceholder(parseTarget);
/* 676 */     if (index == -1)
/*     */     {
/* 678 */       index = state.size();
/* 679 */       state.addNode(parseTarget);
/*     */     }
/* 681 */     if ((compose(state, index) == null) || (!state.hasExpressionAt(index))) {
/* 682 */       return null;
/*     */     }
/* 684 */     return ((ExpressionParsingNode)state.get(index)).getExpression();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\expression\ExpressionParsingUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */