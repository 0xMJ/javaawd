/*    */ package org.thymeleaf.standard.expression;
/*    */ 
/*    */ import java.util.Map;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletRequestWrapper;
/*    */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class RestrictedRequestAccessUtils
/*    */ {
/*    */   public static Object wrapRequestObject(Object obj)
/*    */   {
/* 44 */     if ((obj == null) || (!(obj instanceof HttpServletRequest))) {
/* 45 */       return obj;
/*    */     }
/* 47 */     return new RestrictedRequestWrapper((HttpServletRequest)obj);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private static class RestrictedRequestWrapper
/*    */     extends HttpServletRequestWrapper
/*    */   {
/*    */     public RestrictedRequestWrapper(HttpServletRequest request)
/*    */     {
/* 63 */       super();
/*    */     }
/*    */     
/*    */     public String getParameter(String name)
/*    */     {
/* 68 */       throw createRestrictedParameterAccessException();
/*    */     }
/*    */     
/*    */     public Map getParameterMap()
/*    */     {
/* 73 */       throw createRestrictedParameterAccessException();
/*    */     }
/*    */     
/*    */     public String[] getParameterValues(String name)
/*    */     {
/* 78 */       throw createRestrictedParameterAccessException();
/*    */     }
/*    */     
/*    */     public String getQueryString()
/*    */     {
/* 83 */       throw createRestrictedParameterAccessException();
/*    */     }
/*    */     
/*    */     private static TemplateProcessingException createRestrictedParameterAccessException() {
/* 87 */       return new TemplateProcessingException("Access to request parameters is forbidden in this context. Note some restrictions apply to variable access. For example, direct access to request parameters is forbidden in preprocessing and unescaped expressions, in TEXT template mode, in fragment insertion specifications and in some specific attribute processors.");
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\expression\RestrictedRequestAccessUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */