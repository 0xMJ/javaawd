/*    */ package org.thymeleaf.standard.util;
/*    */ 
/*    */ import org.thymeleaf.engine.AttributeDefinition;
/*    */ import org.thymeleaf.engine.AttributeName;
/*    */ import org.thymeleaf.engine.ElementTagStructureHandler;
/*    */ import org.thymeleaf.processor.element.IElementTagStructureHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class StandardProcessorUtils
/*    */ {
/*    */   public static void replaceAttribute(IElementTagStructureHandler structureHandler, AttributeName oldAttributeName, AttributeDefinition attributeDefinition, String attributeName, String attributeValue)
/*    */   {
/* 49 */     if ((structureHandler instanceof ElementTagStructureHandler)) {
/* 50 */       ((ElementTagStructureHandler)structureHandler).replaceAttribute(oldAttributeName, attributeDefinition, attributeName, attributeValue, null);
/*    */     } else {
/* 52 */       structureHandler.replaceAttribute(oldAttributeName, attributeName, attributeValue);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static void setAttribute(IElementTagStructureHandler structureHandler, AttributeDefinition attributeDefinition, String attributeName, String attributeValue)
/*    */   {
/* 62 */     if ((structureHandler instanceof ElementTagStructureHandler)) {
/* 63 */       ((ElementTagStructureHandler)structureHandler).setAttribute(attributeDefinition, attributeName, attributeValue, null);
/*    */     } else {
/* 65 */       structureHandler.setAttribute(attributeName, attributeValue);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\util\StandardProcessorUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */