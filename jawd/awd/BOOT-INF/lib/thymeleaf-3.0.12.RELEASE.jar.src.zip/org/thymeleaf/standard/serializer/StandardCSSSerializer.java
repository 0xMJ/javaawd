/*     */ package org.thymeleaf.standard.serializer;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.unbescape.css.CssEscape;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class StandardCSSSerializer
/*     */   implements IStandardCSSSerializer
/*     */ {
/*     */   public void serializeValue(Object object, Writer writer)
/*     */   {
/*     */     try
/*     */     {
/*  53 */       writeValue(writer, object);
/*     */     } catch (IOException e) {
/*  55 */       throw new TemplateProcessingException("An exception was raised while trying to serialize object to CSS", e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void writeValue(Writer writer, Object object)
/*     */     throws IOException
/*     */   {
/*  66 */     if (object == null) {
/*  67 */       writeNull(writer);
/*  68 */       return;
/*     */     }
/*  70 */     if ((object instanceof CharSequence)) {
/*  71 */       writeString(writer, object.toString());
/*  72 */       return;
/*     */     }
/*  74 */     if ((object instanceof Character)) {
/*  75 */       writeString(writer, object.toString());
/*  76 */       return;
/*     */     }
/*  78 */     if ((object instanceof Number)) {
/*  79 */       writeNumber(writer, (Number)object);
/*  80 */       return;
/*     */     }
/*  82 */     if ((object instanceof Boolean)) {
/*  83 */       writeBoolean(writer, (Boolean)object);
/*  84 */       return;
/*     */     }
/*  86 */     writeString(writer, object.toString());
/*     */   }
/*     */   
/*     */   private static void writeNull(Writer writer) throws IOException
/*     */   {
/*  91 */     writer.write("");
/*     */   }
/*     */   
/*     */   private static void writeString(Writer writer, String str) throws IOException
/*     */   {
/*  96 */     writer.write(CssEscape.escapeCssIdentifier(str));
/*     */   }
/*     */   
/*     */   private static void writeNumber(Writer writer, Number number) throws IOException
/*     */   {
/* 101 */     writer.write(number.toString());
/*     */   }
/*     */   
/*     */   private static void writeBoolean(Writer writer, Boolean bool) throws IOException
/*     */   {
/* 106 */     writer.write(bool.toString());
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\serializer\StandardCSSSerializer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */