/*    */ package org.thymeleaf.standard.expression;
/*    */ 
/*    */ import org.thymeleaf.context.IExpressionContext;
/*    */ import org.thymeleaf.util.Validate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractStandardConversionService
/*    */   implements IStandardConversionService
/*    */ {
/*    */   public final <T> T convert(IExpressionContext context, Object object, Class<T> targetClass)
/*    */   {
/* 55 */     Validate.notNull(targetClass, "Target class cannot be null");
/*    */     
/*    */ 
/*    */ 
/*    */ 
/* 60 */     if (targetClass.equals(String.class)) {
/* 61 */       if ((object == null) || ((object instanceof String))) {
/* 62 */         return (T)object;
/*    */       }
/* 64 */       return convertToString(context, object);
/*    */     }
/*    */     
/*    */ 
/*    */ 
/*    */ 
/* 70 */     return (T)convertOther(context, object, targetClass);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected String convertToString(IExpressionContext context, Object object)
/*    */   {
/* 79 */     if (object == null) {
/* 80 */       return null;
/*    */     }
/* 82 */     return object.toString();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   protected <T> T convertOther(IExpressionContext context, Object object, Class<T> targetClass)
/*    */   {
/* 89 */     throw new IllegalArgumentException("No available conversion for target class \"" + targetClass.getName() + "\"");
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\expression\AbstractStandardConversionService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */