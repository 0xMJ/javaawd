/*     */ package org.thymeleaf.standard.expression;
/*     */ 
/*     */ import org.thymeleaf.IEngineConfiguration;
/*     */ import org.thymeleaf.cache.ExpressionCacheKey;
/*     */ import org.thymeleaf.cache.ICache;
/*     */ import org.thymeleaf.cache.ICacheManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ExpressionCache
/*     */ {
/*     */   private static final String EXPRESSION_CACHE_TYPE_STANDARD_EXPRESSION = "expr";
/*     */   private static final String EXPRESSION_CACHE_TYPE_ASSIGNATION_SEQUENCE = "aseq";
/*     */   private static final String EXPRESSION_CACHE_TYPE_EXPRESSION_SEQUENCE = "eseq";
/*     */   private static final String EXPRESSION_CACHE_TYPE_EACH = "each";
/*     */   private static final String EXPRESSION_CACHE_TYPE_FRAGMENT_SIGNATURE = "fsig";
/*     */   
/*     */   static Object getFromCache(IEngineConfiguration configuration, String input, String type)
/*     */   {
/*  51 */     ICacheManager cacheManager = configuration.getCacheManager();
/*  52 */     if (cacheManager != null) {
/*  53 */       ICache<ExpressionCacheKey, Object> cache = cacheManager.getExpressionCache();
/*  54 */       if (cache != null) {
/*  55 */         return cache.get(new ExpressionCacheKey(type, input));
/*     */       }
/*     */     }
/*  58 */     return null;
/*     */   }
/*     */   
/*     */   static <V> void putIntoCache(IEngineConfiguration configuration, String input, V value, String type)
/*     */   {
/*  63 */     ICacheManager cacheManager = configuration.getCacheManager();
/*  64 */     if (cacheManager != null) {
/*  65 */       ICache<ExpressionCacheKey, Object> cache = cacheManager.getExpressionCache();
/*  66 */       if (cache != null) {
/*  67 */         cache.put(new ExpressionCacheKey(type, input), value);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   static <V> void removeFromCache(IEngineConfiguration configuration, String input, String type)
/*     */   {
/*  74 */     ICacheManager cacheManager = configuration.getCacheManager();
/*  75 */     if (cacheManager != null) {
/*  76 */       ICache<ExpressionCacheKey, Object> cache = cacheManager.getExpressionCache();
/*  77 */       if (cache != null) {
/*  78 */         cache.clearKey(new ExpressionCacheKey(type, input));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static IStandardExpression getExpressionFromCache(IEngineConfiguration configuration, String input)
/*     */   {
/*  88 */     return (IStandardExpression)getFromCache(configuration, input, "expr");
/*     */   }
/*     */   
/*     */   static void putExpressionIntoCache(IEngineConfiguration configuration, String input, IStandardExpression value) {
/*  92 */     putIntoCache(configuration, input, value, "expr");
/*     */   }
/*     */   
/*     */ 
/*     */   static AssignationSequence getAssignationSequenceFromCache(IEngineConfiguration configuration, String input)
/*     */   {
/*  98 */     return (AssignationSequence)getFromCache(configuration, input, "aseq");
/*     */   }
/*     */   
/*     */   static void putAssignationSequenceIntoCache(IEngineConfiguration configuration, String input, AssignationSequence value) {
/* 102 */     putIntoCache(configuration, input, value, "aseq");
/*     */   }
/*     */   
/*     */ 
/*     */   static ExpressionSequence getExpressionSequenceFromCache(IEngineConfiguration configuration, String input)
/*     */   {
/* 108 */     return (ExpressionSequence)getFromCache(configuration, input, "eseq");
/*     */   }
/*     */   
/*     */   static void putExpressionSequenceIntoCache(IEngineConfiguration configuration, String input, ExpressionSequence value) {
/* 112 */     putIntoCache(configuration, input, value, "eseq");
/*     */   }
/*     */   
/*     */ 
/*     */   static Each getEachFromCache(IEngineConfiguration configuration, String input)
/*     */   {
/* 118 */     return (Each)getFromCache(configuration, input, "each");
/*     */   }
/*     */   
/*     */   static void putEachIntoCache(IEngineConfiguration configuration, String input, Each value) {
/* 122 */     putIntoCache(configuration, input, value, "each");
/*     */   }
/*     */   
/*     */ 
/*     */   static FragmentSignature getFragmentSignatureFromCache(IEngineConfiguration configuration, String input)
/*     */   {
/* 128 */     return (FragmentSignature)getFromCache(configuration, input, "fsig");
/*     */   }
/*     */   
/*     */   static void putFragmentSignatureIntoCache(IEngineConfiguration configuration, String input, FragmentSignature value) {
/* 132 */     putIntoCache(configuration, input, value, "fsig");
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\expression\ExpressionCache.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */