/*     */ package org.thymeleaf.standard.processor;
/*     */ 
/*     */ import org.thymeleaf.context.ITemplateContext;
/*     */ import org.thymeleaf.engine.AttributeName;
/*     */ import org.thymeleaf.engine.EngineEventUtils;
/*     */ import org.thymeleaf.model.IProcessableElementTag;
/*     */ import org.thymeleaf.processor.element.AbstractAttributeTagProcessor;
/*     */ import org.thymeleaf.processor.element.IElementTagStructureHandler;
/*     */ import org.thymeleaf.standard.expression.FragmentExpression;
/*     */ import org.thymeleaf.standard.expression.FragmentExpression.ExecutedFragmentExpression;
/*     */ import org.thymeleaf.standard.expression.IStandardExpression;
/*     */ import org.thymeleaf.standard.expression.NoOpToken;
/*     */ import org.thymeleaf.standard.expression.StandardExpressionExecutionContext;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractStandardExpressionAttributeTagProcessor
/*     */   extends AbstractAttributeTagProcessor
/*     */ {
/*     */   private final StandardExpressionExecutionContext expressionExecutionContext;
/*     */   private final boolean removeIfNoop;
/*     */   
/*     */   protected AbstractStandardExpressionAttributeTagProcessor(TemplateMode templateMode, String dialectPrefix, String attrName, int precedence, boolean removeAttribute)
/*     */   {
/*  63 */     this(templateMode, dialectPrefix, attrName, precedence, removeAttribute, StandardExpressionExecutionContext.NORMAL);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected AbstractStandardExpressionAttributeTagProcessor(TemplateMode templateMode, String dialectPrefix, String attrName, int precedence, boolean removeAttribute, boolean restrictedExpressionExecution)
/*     */   {
/*  85 */     this(templateMode, dialectPrefix, attrName, precedence, removeAttribute, 
/*  86 */       restrictedExpressionExecution ? StandardExpressionExecutionContext.RESTRICTED : StandardExpressionExecutionContext.NORMAL);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected AbstractStandardExpressionAttributeTagProcessor(TemplateMode templateMode, String dialectPrefix, String attrName, int precedence, boolean removeAttribute, StandardExpressionExecutionContext expressionExecutionContext)
/*     */   {
/* 107 */     super(templateMode, dialectPrefix, null, false, attrName, true, precedence, removeAttribute);
/* 108 */     this.removeIfNoop = (!removeAttribute);
/* 109 */     this.expressionExecutionContext = expressionExecutionContext;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final void doProcess(ITemplateContext context, IProcessableElementTag tag, AttributeName attributeName, String attributeValue, IElementTagStructureHandler structureHandler)
/*     */   {
/*     */     Object expressionResult;
/*     */     
/*     */ 
/*     */     Object expressionResult;
/*     */     
/*     */ 
/* 123 */     if (attributeValue != null)
/*     */     {
/* 125 */       IStandardExpression expression = EngineEventUtils.computeAttributeExpression(context, tag, attributeName, attributeValue);
/*     */       Object expressionResult;
/* 127 */       if ((expression != null) && ((expression instanceof FragmentExpression)))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 133 */         FragmentExpression.ExecutedFragmentExpression executedFragmentExpression = FragmentExpression.createExecutedFragmentExpression(context, (FragmentExpression)expression);
/*     */         
/*     */ 
/* 136 */         expressionResult = FragmentExpression.resolveExecutedFragmentExpression(context, executedFragmentExpression, true);
/*     */ 
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/*     */ 
/*     */ 
/* 144 */         expressionResult = expression.execute(context, this.expressionExecutionContext);
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 149 */       expressionResult = null;
/*     */     }
/*     */     
/*     */ 
/* 153 */     if (expressionResult == NoOpToken.VALUE) {
/* 154 */       if (this.removeIfNoop) {
/* 155 */         structureHandler.removeAttribute(attributeName);
/*     */       }
/* 157 */       return;
/*     */     }
/*     */     
/* 160 */     doProcess(context, tag, attributeName, attributeValue, expressionResult, structureHandler);
/*     */   }
/*     */   
/*     */   protected abstract void doProcess(ITemplateContext paramITemplateContext, IProcessableElementTag paramIProcessableElementTag, AttributeName paramAttributeName, String paramString, Object paramObject, IElementTagStructureHandler paramIElementTagStructureHandler);
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\processor\AbstractStandardExpressionAttributeTagProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */