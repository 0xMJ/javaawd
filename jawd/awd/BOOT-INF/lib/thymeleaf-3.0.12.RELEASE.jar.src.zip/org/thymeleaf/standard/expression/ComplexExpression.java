/*     */ package org.thymeleaf.standard.expression;
/*     */ 
/*     */ import org.thymeleaf.context.IExpressionContext;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ComplexExpression
/*     */   extends Expression
/*     */ {
/*     */   private static final long serialVersionUID = -3807499386899890260L;
/*     */   
/*     */   static Object executeComplex(IExpressionContext context, ComplexExpression expression, StandardExpressionExecutionContext expContext)
/*     */   {
/*  61 */     if ((expression instanceof AdditionExpression)) {
/*  62 */       return AdditionExpression.executeAddition(context, (AdditionExpression)expression, expContext);
/*     */     }
/*  64 */     if ((expression instanceof SubtractionExpression)) {
/*  65 */       return SubtractionExpression.executeSubtraction(context, (SubtractionExpression)expression, expContext);
/*     */     }
/*  67 */     if ((expression instanceof MultiplicationExpression)) {
/*  68 */       return MultiplicationExpression.executeMultiplication(context, (MultiplicationExpression)expression, expContext);
/*     */     }
/*  70 */     if ((expression instanceof DivisionExpression)) {
/*  71 */       return DivisionExpression.executeDivision(context, (DivisionExpression)expression, expContext);
/*     */     }
/*  73 */     if ((expression instanceof RemainderExpression)) {
/*  74 */       return RemainderExpression.executeRemainder(context, (RemainderExpression)expression, expContext);
/*     */     }
/*  76 */     if ((expression instanceof ConditionalExpression)) {
/*  77 */       return ConditionalExpression.executeConditional(context, (ConditionalExpression)expression, expContext);
/*     */     }
/*  79 */     if ((expression instanceof DefaultExpression)) {
/*  80 */       return DefaultExpression.executeDefault(context, (DefaultExpression)expression, expContext);
/*     */     }
/*  82 */     if ((expression instanceof MinusExpression)) {
/*  83 */       return MinusExpression.executeMinus(context, (MinusExpression)expression, expContext);
/*     */     }
/*  85 */     if ((expression instanceof NegationExpression)) {
/*  86 */       return NegationExpression.executeNegation(context, (NegationExpression)expression, expContext);
/*     */     }
/*  88 */     if ((expression instanceof AndExpression)) {
/*  89 */       return AndExpression.executeAnd(context, (AndExpression)expression, expContext);
/*     */     }
/*  91 */     if ((expression instanceof OrExpression)) {
/*  92 */       return OrExpression.executeOr(context, (OrExpression)expression, expContext);
/*     */     }
/*  94 */     if ((expression instanceof EqualsExpression)) {
/*  95 */       return EqualsExpression.executeEquals(context, (EqualsExpression)expression, expContext);
/*     */     }
/*  97 */     if ((expression instanceof NotEqualsExpression)) {
/*  98 */       return NotEqualsExpression.executeNotEquals(context, (NotEqualsExpression)expression, expContext);
/*     */     }
/* 100 */     if ((expression instanceof GreaterThanExpression)) {
/* 101 */       return GreaterThanExpression.executeGreaterThan(context, (GreaterThanExpression)expression, expContext);
/*     */     }
/* 103 */     if ((expression instanceof GreaterOrEqualToExpression)) {
/* 104 */       return GreaterOrEqualToExpression.executeGreaterOrEqualTo(context, (GreaterOrEqualToExpression)expression, expContext);
/*     */     }
/* 106 */     if ((expression instanceof LessThanExpression)) {
/* 107 */       return LessThanExpression.executeLessThan(context, (LessThanExpression)expression, expContext);
/*     */     }
/* 109 */     if ((expression instanceof LessOrEqualToExpression)) {
/* 110 */       return LessOrEqualToExpression.executeLessOrEqualTo(context, (LessOrEqualToExpression)expression, expContext);
/*     */     }
/*     */     
/* 113 */     throw new TemplateProcessingException("Unrecognized complex expression: " + expression.getClass().getName());
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\expression\ComplexExpression.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */