/*    */ package org.thymeleaf.standard.processor;
/*    */ 
/*    */ import org.thymeleaf.context.ITemplateContext;
/*    */ import org.thymeleaf.engine.AttributeName;
/*    */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*    */ import org.thymeleaf.model.IProcessableElementTag;
/*    */ import org.thymeleaf.processor.element.IElementTagStructureHandler;
/*    */ import org.thymeleaf.templatemode.TemplateMode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class StandardRemoveTagProcessor
/*    */   extends AbstractStandardExpressionAttributeTagProcessor
/*    */ {
/*    */   public static final int PRECEDENCE = 1600;
/*    */   public static final String ATTR_NAME = "remove";
/*    */   public static final String VALUE_ALL = "all";
/*    */   public static final String VALUE_ALL_BUT_FIRST = "all-but-first";
/*    */   public static final String VALUE_TAG = "tag";
/*    */   public static final String VALUE_TAGS = "tags";
/*    */   public static final String VALUE_BODY = "body";
/*    */   public static final String VALUE_NONE = "none";
/*    */   
/*    */   public StandardRemoveTagProcessor(TemplateMode templateMode, String dialectPrefix)
/*    */   {
/* 50 */     super(templateMode, dialectPrefix, "remove", 1600, true, false);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected void doProcess(ITemplateContext context, IProcessableElementTag tag, AttributeName attributeName, String attributeValue, Object expressionResult, IElementTagStructureHandler structureHandler)
/*    */   {
/* 63 */     if (expressionResult != null)
/*    */     {
/* 65 */       String resultStr = expressionResult.toString();
/*    */       
/* 67 */       if ("all".equalsIgnoreCase(resultStr)) {
/* 68 */         structureHandler.removeElement();
/* 69 */       } else if (("tag".equalsIgnoreCase(resultStr)) || ("tags".equalsIgnoreCase(resultStr))) {
/* 70 */         structureHandler.removeTags();
/* 71 */       } else if ("all-but-first".equalsIgnoreCase(resultStr)) {
/* 72 */         structureHandler.removeAllButFirstChild();
/* 73 */       } else if ("body".equalsIgnoreCase(resultStr)) {
/* 74 */         structureHandler.removeBody();
/* 75 */       } else if (!"none".equalsIgnoreCase(resultStr)) {
/* 76 */         throw new TemplateProcessingException("Invalid value specified for \"" + attributeName + "\": only 'all', 'tag', 'body', 'none' and 'all-but-first' are allowed, but \"" + attributeValue + "\" was specified.");
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\processor\StandardRemoveTagProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */