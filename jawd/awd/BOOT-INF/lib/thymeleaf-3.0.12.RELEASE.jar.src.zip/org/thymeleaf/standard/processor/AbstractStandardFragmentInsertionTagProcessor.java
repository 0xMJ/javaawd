/*     */ package org.thymeleaf.standard.processor;
/*     */ 
/*     */ import java.io.Writer;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import org.thymeleaf.IEngineConfiguration;
/*     */ import org.thymeleaf.context.IEngineContext;
/*     */ import org.thymeleaf.context.ITemplateContext;
/*     */ import org.thymeleaf.engine.AttributeName;
/*     */ import org.thymeleaf.engine.TemplateData;
/*     */ import org.thymeleaf.engine.TemplateManager;
/*     */ import org.thymeleaf.engine.TemplateModel;
/*     */ import org.thymeleaf.exceptions.TemplateInputException;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.model.ICloseElementTag;
/*     */ import org.thymeleaf.model.IModel;
/*     */ import org.thymeleaf.model.IOpenElementTag;
/*     */ import org.thymeleaf.model.IProcessableElementTag;
/*     */ import org.thymeleaf.model.ITemplateEvent;
/*     */ import org.thymeleaf.processor.element.AbstractAttributeTagProcessor;
/*     */ import org.thymeleaf.processor.element.IElementTagStructureHandler;
/*     */ import org.thymeleaf.standard.expression.Fragment;
/*     */ import org.thymeleaf.standard.expression.FragmentExpression;
/*     */ import org.thymeleaf.standard.expression.FragmentExpression.ExecutedFragmentExpression;
/*     */ import org.thymeleaf.standard.expression.FragmentSignature;
/*     */ import org.thymeleaf.standard.expression.FragmentSignatureUtils;
/*     */ import org.thymeleaf.standard.expression.IStandardExpression;
/*     */ import org.thymeleaf.standard.expression.IStandardExpressionParser;
/*     */ import org.thymeleaf.standard.expression.NoOpToken;
/*     */ import org.thymeleaf.standard.expression.StandardExpressions;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ import org.thymeleaf.util.EscapedAttributeUtils;
/*     */ import org.thymeleaf.util.FastStringWriter;
/*     */ import org.thymeleaf.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractStandardFragmentInsertionTagProcessor
/*     */   extends AbstractAttributeTagProcessor
/*     */ {
/*     */   private static final String FRAGMENT_ATTR_NAME = "fragment";
/*     */   private final boolean replaceHost;
/*     */   private final boolean insertOnlyContents;
/*     */   
/*     */   protected AbstractStandardFragmentInsertionTagProcessor(TemplateMode templateMode, String dialectPrefix, String attrName, int precedence, boolean replaceHost)
/*     */   {
/*  75 */     this(templateMode, dialectPrefix, attrName, precedence, replaceHost, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   AbstractStandardFragmentInsertionTagProcessor(TemplateMode templateMode, String dialectPrefix, String attrName, int precedence, boolean replaceHost, boolean insertOnlyContents)
/*     */   {
/*  86 */     super(templateMode, dialectPrefix, null, false, attrName, true, precedence, true);
/*  87 */     this.replaceHost = replaceHost;
/*  88 */     this.insertOnlyContents = insertOnlyContents;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void doProcess(ITemplateContext context, IProcessableElementTag tag, AttributeName attributeName, String attributeValue, IElementTagStructureHandler structureHandler)
/*     */   {
/* 101 */     if (StringUtils.isEmptyOrWhitespace(attributeValue)) {
/* 102 */       throw new TemplateProcessingException("Fragment specifications cannot be empty");
/*     */     }
/*     */     
/* 105 */     IEngineConfiguration configuration = context.getConfiguration();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 110 */     Object fragmentObj = computeFragment(context, attributeValue);
/* 111 */     if (fragmentObj == null)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 116 */       throw new TemplateInputException("Error resolving fragment: \"" + attributeValue + "\": template or fragment could not be resolved");
/*     */     }
/*     */     
/*     */ 
/* 120 */     if (fragmentObj == NoOpToken.VALUE)
/*     */     {
/*     */ 
/* 123 */       return;
/*     */     }
/* 125 */     if (fragmentObj == Fragment.EMPTY_FRAGMENT)
/*     */     {
/*     */ 
/*     */ 
/* 129 */       if (this.replaceHost) {
/* 130 */         structureHandler.removeElement();
/*     */       } else {
/* 132 */         structureHandler.removeBody();
/*     */       }
/* 134 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 139 */     Fragment fragment = (Fragment)fragmentObj;
/*     */     
/*     */ 
/* 142 */     TemplateModel fragmentModel = fragment.getTemplateModel();
/* 143 */     Map<String, Object> fragmentParameters = fragment.getParameters();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 156 */     boolean signatureApplied = false;
/* 157 */     ITemplateEvent firstEvent = fragmentModel.size() > 2 ? fragmentModel.get(1) : null;
/* 158 */     IProcessableElementTag fragmentHolderEvent; if ((firstEvent != null) && (IProcessableElementTag.class.isAssignableFrom(firstEvent.getClass())))
/*     */     {
/* 160 */       String dialectPrefix = attributeName.getPrefix();
/* 161 */       fragmentHolderEvent = (IProcessableElementTag)firstEvent;
/*     */       
/* 163 */       if (fragmentHolderEvent.hasAttribute(dialectPrefix, "fragment"))
/*     */       {
/*     */ 
/*     */ 
/* 167 */         String fragmentSignatureSpec = EscapedAttributeUtils.unescapeAttribute(fragmentModel.getTemplateMode(), fragmentHolderEvent.getAttributeValue(dialectPrefix, "fragment"));
/* 168 */         if (!StringUtils.isEmptyOrWhitespace(fragmentSignatureSpec))
/*     */         {
/*     */ 
/* 171 */           FragmentSignature fragmentSignature = FragmentSignatureUtils.parseFragmentSignature(configuration, fragmentSignatureSpec);
/* 172 */           if (fragmentSignature != null)
/*     */           {
/*     */ 
/* 175 */             fragmentParameters = FragmentSignatureUtils.processParameters(fragmentSignature, fragmentParameters, fragment.hasSyntheticParameters());
/* 176 */             signatureApplied = true;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 189 */     if ((!signatureApplied) && (fragment.hasSyntheticParameters())) {
/* 190 */       throw new TemplateProcessingException("Fragment '" + attributeValue + "' specifies synthetic (unnamed) parameters, but the resolved fragment does not match a fragment signature (th:fragment,data-th-fragment) which could apply names to the specified parameters.");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 210 */     if (context.getTemplateMode() != fragmentModel.getTemplateMode())
/*     */     {
/*     */ 
/* 213 */       if (this.insertOnlyContents)
/*     */       {
/*     */ 
/*     */ 
/* 217 */         throw new TemplateProcessingException("Template being processed uses template mode " + context.getTemplateMode() + ", inserted fragment \"" + attributeValue + "\" uses template mode " + fragmentModel.getTemplateMode() + ". Cross-template-mode fragment insertion is not allowed using the " + attributeName + " attribute, which is no longer recommended for use as of Thymeleaf 3.0. Use {th:insert,data-th-insert} or {th:replace,data-th-replace} instead, which do not remove the container element from the fragment being inserted.");
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 225 */       if ((fragmentParameters != null) && (fragmentParameters.size() > 0))
/*     */       {
/* 227 */         if (!(context instanceof IEngineContext))
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/* 232 */           throw new TemplateProcessingException("Parameterized fragment insertion is not supported because local variable support is DISABLED. This is due to the use of an implementation of the " + ITemplateContext.class.getName() + " interface that does not provide local-variable support. In order to have local-variable support, the variables map implementation should also implement the " + IEngineContext.class.getName() + " interface");
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 237 */         ((IEngineContext)context).setVariables(fragmentParameters);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 242 */       Writer stringWriter = new FastStringWriter(200);
/* 243 */       configuration.getTemplateManager().process(fragmentModel, context, stringWriter);
/*     */       
/*     */ 
/* 246 */       if (this.replaceHost) {
/* 247 */         structureHandler.replaceWith(stringWriter.toString(), false);
/*     */       } else {
/* 249 */         structureHandler.setBody(stringWriter.toString(), false);
/*     */       }
/*     */       
/* 252 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 260 */     TemplateData fragmentTemplateData = fragmentModel.getTemplateData();
/* 261 */     structureHandler.setTemplateData(fragmentTemplateData);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 267 */     if ((fragmentParameters != null) && (fragmentParameters.size() > 0)) {
/* 268 */       for (Map.Entry<String, Object> fragmentParameterEntry : fragmentParameters.entrySet()) {
/* 269 */         structureHandler.setLocalVariable((String)fragmentParameterEntry.getKey(), fragmentParameterEntry.getValue());
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 277 */     if ((this.insertOnlyContents) && (fragmentTemplateData.hasTemplateSelectors()))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 286 */       IModel model = fragmentModel.cloneModel();
/* 287 */       int modelLevel = 0;
/* 288 */       int n = model.size();
/* 289 */       while (n-- != 0)
/*     */       {
/* 291 */         ITemplateEvent event = model.get(n);
/*     */         
/* 293 */         if ((event instanceof ICloseElementTag)) {
/* 294 */           if (!((ICloseElementTag)event).isUnmatched())
/*     */           {
/*     */ 
/*     */ 
/* 298 */             if (modelLevel <= 0) {
/* 299 */               model.remove(n);
/*     */             }
/* 301 */             modelLevel++;
/*     */           }
/*     */         }
/* 304 */         else if ((event instanceof IOpenElementTag)) {
/* 305 */           modelLevel--;
/* 306 */           if (modelLevel <= 0) {
/* 307 */             model.remove(n);
/*     */           }
/*     */           
/*     */         }
/* 311 */         else if (modelLevel <= 0) {
/* 312 */           model.remove(n);
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 317 */       if (this.replaceHost) {
/* 318 */         structureHandler.replaceWith(model, true);
/*     */       } else {
/* 320 */         structureHandler.setBody(model, true);
/*     */       }
/*     */       
/* 323 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 328 */     if (this.replaceHost) {
/* 329 */       structureHandler.replaceWith(fragmentModel, true);
/*     */     } else {
/* 331 */       structureHandler.setBody(fragmentModel, true);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Object computeFragment(ITemplateContext context, String input)
/*     */   {
/* 344 */     IStandardExpressionParser expressionParser = StandardExpressions.getExpressionParser(context.getConfiguration());
/*     */     
/* 346 */     String trimmedInput = input.trim();
/*     */     
/* 348 */     if (shouldBeWrappedAsFragmentExpression(trimmedInput))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 356 */       FragmentExpression fragmentExpression = (FragmentExpression)expressionParser.parseExpression(context, "~{" + trimmedInput + "}");
/*     */       
/*     */ 
/* 359 */       FragmentExpression.ExecutedFragmentExpression executedFragmentExpression = FragmentExpression.createExecutedFragmentExpression(context, fragmentExpression);
/*     */       
/* 361 */       if ((executedFragmentExpression.getFragmentSelectorExpressionResult() == null) && (executedFragmentExpression.getFragmentParameters() == null))
/*     */       {
/*     */ 
/* 364 */         Object templateNameExpressionResult = executedFragmentExpression.getTemplateNameExpressionResult();
/* 365 */         if (templateNameExpressionResult != null) {
/* 366 */           if ((templateNameExpressionResult instanceof Fragment)) {
/* 367 */             return templateNameExpressionResult;
/*     */           }
/* 369 */           if (templateNameExpressionResult == NoOpToken.VALUE) {
/* 370 */             return NoOpToken.VALUE;
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 379 */       return FragmentExpression.resolveExecutedFragmentExpression(context, executedFragmentExpression, true);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 386 */     IStandardExpression fragmentExpression = expressionParser.parseExpression(context, trimmedInput);
/*     */     
/*     */     Object fragmentExpressionResult;
/*     */     Object fragmentExpressionResult;
/* 390 */     if ((fragmentExpression != null) && ((fragmentExpression instanceof FragmentExpression)))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 396 */       FragmentExpression.ExecutedFragmentExpression executedFragmentExpression = FragmentExpression.createExecutedFragmentExpression(context, (FragmentExpression)fragmentExpression);
/*     */       
/*     */ 
/* 399 */       fragmentExpressionResult = FragmentExpression.resolveExecutedFragmentExpression(context, executedFragmentExpression, true);
/*     */     }
/*     */     else
/*     */     {
/* 403 */       fragmentExpressionResult = fragmentExpression.execute(context);
/*     */     }
/*     */     
/*     */ 
/* 407 */     if ((fragmentExpressionResult == null) || (fragmentExpressionResult == NoOpToken.VALUE)) {
/* 408 */       return fragmentExpressionResult;
/*     */     }
/*     */     
/* 411 */     if (!(fragmentExpressionResult instanceof Fragment)) {
/* 412 */       throw new TemplateProcessingException("Invalid fragment specification: \"" + input + "\": expression does not return a Fragment object");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 417 */     return fragmentExpressionResult;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static boolean shouldBeWrappedAsFragmentExpression(String input)
/*     */   {
/* 425 */     int inputLen = input.length();
/* 426 */     if ((inputLen > 2) && (input.charAt(0) == '~') && (input.charAt(1) == '{'))
/*     */     {
/* 428 */       return false;
/*     */     }
/*     */     
/* 431 */     int bracketLevel = 0;
/* 432 */     int paramLevel = 0;
/* 433 */     boolean inLiteral = false;
/* 434 */     int n = inputLen;
/* 435 */     int i = 0;
/* 436 */     while (n-- != 0)
/*     */     {
/* 438 */       char c = input.charAt(i);
/*     */       
/* 440 */       if (((c >= 'a') && (c <= 'z')) || (c == ' '))
/*     */       {
/* 442 */         i++;
/*     */       }
/*     */       else
/*     */       {
/* 446 */         if (c == '\'') {
/* 447 */           inLiteral = !inLiteral;
/* 448 */         } else if (!inLiteral) {
/* 449 */           if (c == '{') {
/* 450 */             bracketLevel++;
/* 451 */           } else if (c == '}') {
/* 452 */             bracketLevel--;
/* 453 */           } else if (bracketLevel == 0) {
/* 454 */             if (c == '(') {
/* 455 */               paramLevel++;
/* 456 */             } else if (c == ')') {
/* 457 */               paramLevel--;
/* 458 */             } else { if ((c == '=') && (paramLevel == 1))
/*     */               {
/*     */ 
/* 461 */                 return true; }
/* 462 */               if ((c == '~') && (n != 0) && (input.charAt(i + 1) == '{'))
/*     */               {
/* 464 */                 return false; }
/* 465 */               if ((c == ':') && (n != 0) && (input.charAt(i + 1) == ':'))
/*     */               {
/*     */ 
/* 468 */                 return true;
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/* 473 */         i++;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 480 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\processor\AbstractStandardFragmentInsertionTagProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */