/*     */ package org.thymeleaf.standard.expression;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.thymeleaf.TemplateEngine;
/*     */ import org.thymeleaf.context.IExpressionContext;
/*     */ import org.thymeleaf.util.EvaluationUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AdditionExpression
/*     */   extends AdditionSubtractionExpression
/*     */ {
/*     */   private static final long serialVersionUID = -971366486450425605L;
/*  50 */   private static final Logger logger = LoggerFactory.getLogger(AdditionExpression.class);
/*     */   
/*     */ 
/*     */   public AdditionExpression(IStandardExpression left, IStandardExpression right)
/*     */   {
/*  55 */     super(left, right);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getStringRepresentation()
/*     */   {
/*  62 */     return getStringRepresentation("+");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static Object executeAddition(IExpressionContext context, AdditionExpression expression, StandardExpressionExecutionContext expContext)
/*     */   {
/*  73 */     if (logger.isTraceEnabled()) {
/*  74 */       logger.trace("[THYMELEAF][{}] Evaluating addition expression: \"{}\"", TemplateEngine.threadIndex(), expression.getStringRepresentation());
/*     */     }
/*     */     
/*     */ 
/*  78 */     IStandardVariableExpressionEvaluator expressionEvaluator = StandardExpressions.getVariableExpressionEvaluator(context.getConfiguration());
/*     */     
/*  80 */     IStandardExpression leftExpr = expression.getLeft();
/*  81 */     IStandardExpression rightExpr = expression.getRight();
/*     */     
/*     */     Object leftValue;
/*     */     
/*     */     Object leftValue;
/*     */     
/*  87 */     if ((leftExpr instanceof Expression))
/*     */     {
/*  89 */       leftValue = Expression.execute(context, (Expression)leftExpr, expressionEvaluator, expContext);
/*     */     } else
/*  91 */       leftValue = leftExpr.execute(context, expContext);
/*     */     Object rightValue;
/*     */     Object rightValue;
/*  94 */     if ((rightExpr instanceof Expression))
/*     */     {
/*  96 */       rightValue = Expression.execute(context, (Expression)rightExpr, expressionEvaluator, expContext);
/*     */     } else {
/*  98 */       rightValue = rightExpr.execute(context, expContext);
/*     */     }
/*     */     
/* 101 */     if (leftValue == null) {
/* 102 */       leftValue = "null";
/*     */     }
/* 104 */     if (rightValue == null) {
/* 105 */       rightValue = "null";
/*     */     }
/*     */     
/* 108 */     BigDecimal leftNumberValue = EvaluationUtils.evaluateAsNumber(leftValue);
/* 109 */     if (leftNumberValue != null) {
/* 110 */       BigDecimal rightNumberValue = EvaluationUtils.evaluateAsNumber(rightValue);
/* 111 */       if (rightNumberValue != null)
/*     */       {
/* 113 */         return leftNumberValue.add(rightNumberValue);
/*     */       }
/*     */     }
/*     */     
/* 117 */     return new LiteralValue(LiteralValue.unwrap(leftValue).toString() + LiteralValue.unwrap(rightValue).toString());
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\expression\AdditionExpression.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */