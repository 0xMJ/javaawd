/*     */ package org.thymeleaf.standard.expression;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.thymeleaf.TemplateEngine;
/*     */ import org.thymeleaf.context.IExpressionContext;
/*     */ import org.thymeleaf.util.EvaluationUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class EqualsExpression
/*     */   extends EqualsNotEqualsExpression
/*     */ {
/*     */   private static final long serialVersionUID = -3223406642461547141L;
/*  50 */   private static final Logger logger = LoggerFactory.getLogger(EqualsExpression.class);
/*     */   
/*     */   public EqualsExpression(IStandardExpression left, IStandardExpression right)
/*     */   {
/*  54 */     super(left, right);
/*     */   }
/*     */   
/*     */ 
/*     */   public String getStringRepresentation()
/*     */   {
/*  60 */     return getStringRepresentation("==");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static Object executeEquals(IExpressionContext context, EqualsExpression expression, StandardExpressionExecutionContext expContext)
/*     */   {
/*  73 */     Object leftValue = expression.getLeft().execute(context, expContext);
/*     */     
/*  75 */     Object rightValue = expression.getRight().execute(context, expContext);
/*     */     
/*  77 */     leftValue = LiteralValue.unwrap(leftValue);
/*  78 */     rightValue = LiteralValue.unwrap(rightValue);
/*     */     
/*  80 */     if (leftValue == null) {
/*  81 */       return Boolean.valueOf(rightValue == null);
/*     */     }
/*     */     
/*  84 */     Boolean result = null;
/*     */     
/*  86 */     BigDecimal leftNumberValue = EvaluationUtils.evaluateAsNumber(leftValue);
/*  87 */     BigDecimal rightNumberValue = EvaluationUtils.evaluateAsNumber(rightValue);
/*     */     
/*  89 */     if ((leftNumberValue != null) && (rightNumberValue != null)) {
/*  90 */       result = Boolean.valueOf(leftNumberValue.compareTo(rightNumberValue) == 0);
/*     */     } else {
/*  92 */       if ((leftValue instanceof Character)) {
/*  93 */         leftValue = leftValue.toString();
/*     */       }
/*  95 */       if ((rightValue != null) && ((rightValue instanceof Character))) {
/*  96 */         rightValue = rightValue.toString();
/*     */       }
/*  98 */       if ((rightValue != null) && 
/*  99 */         (leftValue.getClass().equals(rightValue.getClass())) && 
/* 100 */         (Comparable.class.isAssignableFrom(leftValue.getClass()))) {
/* 101 */         result = Boolean.valueOf(((Comparable)leftValue).compareTo(rightValue) == 0);
/*     */       } else {
/* 103 */         result = Boolean.valueOf(leftValue.equals(rightValue));
/*     */       }
/*     */     }
/*     */     
/* 107 */     if (logger.isTraceEnabled()) {
/* 108 */       logger.trace("[THYMELEAF][{}] Evaluating EQUALS expression: \"{}\". Left is \"{}\", right is \"{}\". Result is \"{}\"", new Object[] {
/* 109 */         TemplateEngine.threadIndex(), expression.getStringRepresentation(), leftValue, rightValue, result });
/*     */     }
/*     */     
/* 112 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\expression\EqualsExpression.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */