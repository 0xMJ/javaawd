/*    */ package org.thymeleaf.standard.processor;
/*    */ 
/*    */ import org.thymeleaf.templatemode.TemplateMode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class StandardIncludeTagProcessor
/*    */   extends AbstractStandardFragmentInsertionTagProcessor
/*    */ {
/*    */   public static final int PRECEDENCE = 100;
/*    */   public static final String ATTR_NAME = "include";
/*    */   
/*    */   public StandardIncludeTagProcessor(TemplateMode templateMode, String dialectPrefix)
/*    */   {
/* 41 */     super(templateMode, dialectPrefix, "include", 100, false, true);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\processor\StandardIncludeTagProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */