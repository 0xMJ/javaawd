/*     */ package org.thymeleaf.standard.expression;
/*     */ 
/*     */ import java.util.Map;
/*     */ import org.thymeleaf.IEngineConfiguration;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class StandardExpressions
/*     */ {
/*     */   public static final String STANDARD_VARIABLE_EXPRESSION_EVALUATOR_ATTRIBUTE_NAME = "StandardVariableExpressionEvaluator";
/*     */   public static final String STANDARD_EXPRESSION_PARSER_ATTRIBUTE_NAME = "StandardExpressionParser";
/*     */   public static final String STANDARD_CONVERSION_SERVICE_ATTRIBUTE_NAME = "StandardConversionService";
/*     */   
/*     */   public static IStandardExpressionParser getExpressionParser(IEngineConfiguration configuration)
/*     */   {
/*  81 */     Object parser = configuration.getExecutionAttributes().get("StandardExpressionParser");
/*  82 */     if ((parser == null) || (!(parser instanceof IStandardExpressionParser)))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  88 */       throw new TemplateProcessingException("No Standard Expression Parser has been registered as an execution argument. This is a requirement for using Standard Expressions, and might happen if neither the Standard or the SpringStandard dialects have been added to the Template Engine and none of the specified dialects registers an attribute of type " + IStandardExpressionParser.class.getName() + " with name \"" + "StandardExpressionParser" + "\"");
/*     */     }
/*     */     
/*  91 */     return (IStandardExpressionParser)parser;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static IStandardVariableExpressionEvaluator getVariableExpressionEvaluator(IEngineConfiguration configuration)
/*     */   {
/* 111 */     Object expressionEvaluator = configuration.getExecutionAttributes().get("StandardVariableExpressionEvaluator");
/* 112 */     if ((expressionEvaluator == null) || (!(expressionEvaluator instanceof IStandardVariableExpressionEvaluator)))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 118 */       throw new TemplateProcessingException("No Standard Variable Expression Evaluator has been registered as an execution argument. This is a requirement for using Standard Expressions, and might happen if neither the Standard or the SpringStandard dialects have been added to the Template Engine and none of the specified dialects registers an attribute of type " + IStandardVariableExpressionEvaluator.class.getName() + " with name \"" + "StandardVariableExpressionEvaluator" + "\"");
/*     */     }
/*     */     
/* 121 */     return (IStandardVariableExpressionEvaluator)expressionEvaluator;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static IStandardConversionService getConversionService(IEngineConfiguration configuration)
/*     */   {
/* 139 */     Object conversionService = configuration.getExecutionAttributes().get("StandardConversionService");
/* 140 */     if ((conversionService == null) || (!(conversionService instanceof IStandardConversionService)))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 146 */       throw new TemplateProcessingException("No Standard Conversion Service has been registered as an execution argument. This is a requirement for using Standard Expressions, and might happen if neither the Standard or the SpringStandard dialects have been added to the Template Engine and none of the specified dialects registers an attribute of type " + IStandardConversionService.class.getName() + " with name \"" + "StandardConversionService" + "\"");
/*     */     }
/*     */     
/* 149 */     return (IStandardConversionService)conversionService;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\expression\StandardExpressions.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */