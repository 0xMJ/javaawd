/*     */ package org.thymeleaf.standard.processor;
/*     */ 
/*     */ import org.thymeleaf.context.ITemplateContext;
/*     */ import org.thymeleaf.engine.AttributeDefinition;
/*     */ import org.thymeleaf.engine.AttributeDefinitions;
/*     */ import org.thymeleaf.engine.AttributeName;
/*     */ import org.thymeleaf.engine.IAttributeDefinitionsAware;
/*     */ import org.thymeleaf.model.IProcessableElementTag;
/*     */ import org.thymeleaf.processor.element.IElementTagStructureHandler;
/*     */ import org.thymeleaf.standard.expression.StandardExpressionExecutionContext;
/*     */ import org.thymeleaf.standard.util.StandardProcessorUtils;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ import org.thymeleaf.util.EscapedAttributeUtils;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractStandardAttributeModifierTagProcessor
/*     */   extends AbstractStandardExpressionAttributeTagProcessor
/*     */   implements IAttributeDefinitionsAware
/*     */ {
/*     */   private final boolean removeIfEmpty;
/*     */   private final String targetAttrCompleteName;
/*     */   private AttributeDefinition targetAttributeDefinition;
/*     */   
/*     */   protected AbstractStandardAttributeModifierTagProcessor(TemplateMode templateMode, String dialectPrefix, String attrName, int precedence, boolean removeIfEmpty)
/*     */   {
/*  69 */     this(templateMode, dialectPrefix, attrName, attrName, precedence, removeIfEmpty);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected AbstractStandardAttributeModifierTagProcessor(TemplateMode templateMode, String dialectPrefix, String attrName, int precedence, boolean removeIfEmpty, boolean restrictedExpressionExecution)
/*     */   {
/*  93 */     this(templateMode, dialectPrefix, attrName, attrName, precedence, removeIfEmpty, restrictedExpressionExecution);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected AbstractStandardAttributeModifierTagProcessor(TemplateMode templateMode, String dialectPrefix, String attrName, int precedence, boolean removeIfEmpty, StandardExpressionExecutionContext expressionExecutionContext)
/*     */   {
/* 116 */     this(templateMode, dialectPrefix, attrName, attrName, precedence, removeIfEmpty, expressionExecutionContext);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected AbstractStandardAttributeModifierTagProcessor(TemplateMode templateMode, String dialectPrefix, String attrName, String targetAttrCompleteName, int precedence, boolean removeIfEmpty)
/*     */   {
/* 138 */     super(templateMode, dialectPrefix, attrName, precedence, false);
/*     */     
/* 140 */     Validate.notNull(targetAttrCompleteName, "Complete name of target attribute cannot be null");
/*     */     
/* 142 */     this.targetAttrCompleteName = targetAttrCompleteName;
/* 143 */     this.removeIfEmpty = removeIfEmpty;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected AbstractStandardAttributeModifierTagProcessor(TemplateMode templateMode, String dialectPrefix, String attrName, String targetAttrCompleteName, int precedence, boolean removeIfEmpty, boolean restrictedExpressionExecution)
/*     */   {
/* 170 */     super(templateMode, dialectPrefix, attrName, precedence, false, restrictedExpressionExecution);
/*     */     
/* 172 */     Validate.notNull(targetAttrCompleteName, "Complete name of target attribute cannot be null");
/*     */     
/* 174 */     this.targetAttrCompleteName = targetAttrCompleteName;
/* 175 */     this.removeIfEmpty = removeIfEmpty;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected AbstractStandardAttributeModifierTagProcessor(TemplateMode templateMode, String dialectPrefix, String attrName, String targetAttrCompleteName, int precedence, boolean removeIfEmpty, StandardExpressionExecutionContext expressionExecutionContext)
/*     */   {
/* 201 */     super(templateMode, dialectPrefix, attrName, precedence, false, expressionExecutionContext);
/*     */     
/* 203 */     Validate.notNull(targetAttrCompleteName, "Complete name of target attribute cannot be null");
/*     */     
/* 205 */     this.targetAttrCompleteName = targetAttrCompleteName;
/* 206 */     this.removeIfEmpty = removeIfEmpty;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAttributeDefinitions(AttributeDefinitions attributeDefinitions)
/*     */   {
/* 214 */     Validate.notNull(attributeDefinitions, "Attribute Definitions cannot be null");
/*     */     
/*     */ 
/* 217 */     this.targetAttributeDefinition = attributeDefinitions.forName(getTemplateMode(), this.targetAttrCompleteName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final void doProcess(ITemplateContext context, IProcessableElementTag tag, AttributeName attributeName, String attributeValue, Object expressionResult, IElementTagStructureHandler structureHandler)
/*     */   {
/* 232 */     String newAttributeValue = EscapedAttributeUtils.escapeAttribute(getTemplateMode(), expressionResult == null ? null : expressionResult.toString());
/*     */     
/*     */ 
/* 235 */     if ((this.removeIfEmpty) && ((newAttributeValue == null) || (newAttributeValue.length() == 0)))
/*     */     {
/*     */ 
/* 238 */       structureHandler.removeAttribute(this.targetAttributeDefinition.getAttributeName());
/* 239 */       structureHandler.removeAttribute(attributeName);
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 244 */       StandardProcessorUtils.replaceAttribute(structureHandler, attributeName, this.targetAttributeDefinition, this.targetAttrCompleteName, 
/* 245 */         newAttributeValue == null ? "" : newAttributeValue);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\processor\AbstractStandardAttributeModifierTagProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */