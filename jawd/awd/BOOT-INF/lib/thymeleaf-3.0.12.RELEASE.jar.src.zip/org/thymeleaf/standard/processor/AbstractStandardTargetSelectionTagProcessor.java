/*    */ package org.thymeleaf.standard.processor;
/*    */ 
/*    */ import java.util.Map;
/*    */ import java.util.Map.Entry;
/*    */ import org.thymeleaf.context.ITemplateContext;
/*    */ import org.thymeleaf.engine.AttributeName;
/*    */ import org.thymeleaf.model.IProcessableElementTag;
/*    */ import org.thymeleaf.processor.element.AbstractAttributeTagProcessor;
/*    */ import org.thymeleaf.processor.element.IElementTagStructureHandler;
/*    */ import org.thymeleaf.standard.expression.IStandardExpression;
/*    */ import org.thymeleaf.standard.expression.IStandardExpressionParser;
/*    */ import org.thymeleaf.standard.expression.StandardExpressions;
/*    */ import org.thymeleaf.templatemode.TemplateMode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractStandardTargetSelectionTagProcessor
/*    */   extends AbstractAttributeTagProcessor
/*    */ {
/*    */   protected AbstractStandardTargetSelectionTagProcessor(TemplateMode templateMode, String dialectPrefix, String attrName, int precedence)
/*    */   {
/* 46 */     super(templateMode, dialectPrefix, null, false, attrName, true, precedence, true);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected final void doProcess(ITemplateContext context, IProcessableElementTag tag, AttributeName attributeName, String attributeValue, IElementTagStructureHandler structureHandler)
/*    */   {
/* 58 */     IStandardExpressionParser expressionParser = StandardExpressions.getExpressionParser(context.getConfiguration());
/*    */     
/*    */ 
/* 61 */     IStandardExpression expression = expressionParser.parseExpression(context, attributeValue);
/*    */     
/* 63 */     validateSelectionValue(context, tag, attributeName, attributeValue, expression);
/*    */     
/* 65 */     Object newSelectionTarget = expression.execute(context);
/*    */     
/*    */ 
/* 68 */     Map<String, Object> additionalLocalVariables = computeAdditionalLocalVariables(context, tag, attributeName, attributeValue, expression);
/* 69 */     if ((additionalLocalVariables != null) && (additionalLocalVariables.size() > 0)) {
/* 70 */       for (Map.Entry<String, Object> variableEntry : additionalLocalVariables.entrySet()) {
/* 71 */         structureHandler.setLocalVariable((String)variableEntry.getKey(), variableEntry.getValue());
/*    */       }
/*    */     }
/*    */     
/* 75 */     structureHandler.setSelectionTarget(newSelectionTarget);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected void validateSelectionValue(ITemplateContext context, IProcessableElementTag tag, AttributeName attributeName, String attributeValue, IStandardExpression expression) {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected Map<String, Object> computeAdditionalLocalVariables(ITemplateContext context, IProcessableElementTag tag, AttributeName attributeName, String attributeValue, IStandardExpression expression)
/*    */   {
/* 99 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\processor\AbstractStandardTargetSelectionTagProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */