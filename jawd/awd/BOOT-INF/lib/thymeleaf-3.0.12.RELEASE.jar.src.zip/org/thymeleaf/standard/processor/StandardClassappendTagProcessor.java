/*    */ package org.thymeleaf.standard.processor;
/*    */ 
/*    */ import org.thymeleaf.context.ITemplateContext;
/*    */ import org.thymeleaf.engine.AttributeDefinition;
/*    */ import org.thymeleaf.engine.AttributeDefinitions;
/*    */ import org.thymeleaf.engine.AttributeName;
/*    */ import org.thymeleaf.engine.IAttributeDefinitionsAware;
/*    */ import org.thymeleaf.model.IProcessableElementTag;
/*    */ import org.thymeleaf.processor.element.IElementTagStructureHandler;
/*    */ import org.thymeleaf.standard.util.StandardProcessorUtils;
/*    */ import org.thymeleaf.templatemode.TemplateMode;
/*    */ import org.thymeleaf.util.EscapedAttributeUtils;
/*    */ import org.thymeleaf.util.Validate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class StandardClassappendTagProcessor
/*    */   extends AbstractStandardExpressionAttributeTagProcessor
/*    */   implements IAttributeDefinitionsAware
/*    */ {
/*    */   public static final int PRECEDENCE = 1100;
/*    */   public static final String ATTR_NAME = "classappend";
/*    */   public static final String TARGET_ATTR_NAME = "class";
/* 49 */   private static final TemplateMode TEMPLATE_MODE = TemplateMode.HTML;
/*    */   
/*    */ 
/*    */   private AttributeDefinition targetAttributeDefinition;
/*    */   
/*    */ 
/*    */   public StandardClassappendTagProcessor(String dialectPrefix)
/*    */   {
/* 57 */     super(TEMPLATE_MODE, dialectPrefix, "classappend", 1100, true, false);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void setAttributeDefinitions(AttributeDefinitions attributeDefinitions)
/*    */   {
/* 64 */     Validate.notNull(attributeDefinitions, "Attribute Definitions cannot be null");
/*    */     
/*    */ 
/* 67 */     this.targetAttributeDefinition = attributeDefinitions.forName(TEMPLATE_MODE, "class");
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected final void doProcess(ITemplateContext context, IProcessableElementTag tag, AttributeName attributeName, String attributeValue, Object expressionResult, IElementTagStructureHandler structureHandler)
/*    */   {
/* 82 */     String newAttributeValue = EscapedAttributeUtils.escapeAttribute(getTemplateMode(), expressionResult == null ? null : expressionResult.toString());
/*    */     
/*    */ 
/* 85 */     if ((newAttributeValue != null) && (newAttributeValue.length() > 0))
/*    */     {
/* 87 */       AttributeName targetAttributeName = this.targetAttributeDefinition.getAttributeName();
/*    */       
/* 89 */       if (tag.hasAttribute(targetAttributeName)) {
/* 90 */         String currentValue = tag.getAttributeValue(targetAttributeName);
/* 91 */         if (currentValue.length() > 0) {
/* 92 */           newAttributeValue = currentValue + ' ' + newAttributeValue;
/*    */         }
/*    */       }
/*    */       
/* 96 */       StandardProcessorUtils.setAttribute(structureHandler, this.targetAttributeDefinition, "class", newAttributeValue);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\processor\StandardClassappendTagProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */