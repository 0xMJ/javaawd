/*    */ package org.thymeleaf.standard.processor;
/*    */ 
/*    */ import org.thymeleaf.context.ITemplateContext;
/*    */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*    */ import org.thymeleaf.model.ITemplateEnd;
/*    */ import org.thymeleaf.model.ITemplateStart;
/*    */ import org.thymeleaf.processor.templateboundaries.AbstractTemplateBoundariesProcessor;
/*    */ import org.thymeleaf.processor.templateboundaries.ITemplateBoundariesStructureHandler;
/*    */ import org.thymeleaf.standard.inline.StandardCSSInliner;
/*    */ import org.thymeleaf.standard.inline.StandardHTMLInliner;
/*    */ import org.thymeleaf.standard.inline.StandardJavaScriptInliner;
/*    */ import org.thymeleaf.standard.inline.StandardTextInliner;
/*    */ import org.thymeleaf.standard.inline.StandardXMLInliner;
/*    */ import org.thymeleaf.templatemode.TemplateMode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class StandardInlineEnablementTemplateBoundariesProcessor
/*    */   extends AbstractTemplateBoundariesProcessor
/*    */ {
/*    */   public static final int PRECEDENCE = 10;
/*    */   
/*    */   public StandardInlineEnablementTemplateBoundariesProcessor(TemplateMode templateMode)
/*    */   {
/* 47 */     super(templateMode, 10);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void doProcessTemplateStart(ITemplateContext context, ITemplateStart templateStart, ITemplateBoundariesStructureHandler structureHandler)
/*    */   {
/* 56 */     switch (getTemplateMode())
/*    */     {
/*    */     case HTML: 
/* 59 */       structureHandler.setInliner(new StandardHTMLInliner(context.getConfiguration()));
/* 60 */       break;
/*    */     case XML: 
/* 62 */       structureHandler.setInliner(new StandardXMLInliner(context.getConfiguration()));
/* 63 */       break;
/*    */     case TEXT: 
/* 65 */       structureHandler.setInliner(new StandardTextInliner(context.getConfiguration()));
/* 66 */       break;
/*    */     case JAVASCRIPT: 
/* 68 */       structureHandler.setInliner(new StandardJavaScriptInliner(context.getConfiguration()));
/* 69 */       break;
/*    */     case CSS: 
/* 71 */       structureHandler.setInliner(new StandardCSSInliner(context.getConfiguration()));
/* 72 */       break;
/*    */     
/*    */ 
/*    */     case RAW: 
/* 76 */       structureHandler.setInliner(null);
/* 77 */       break;
/*    */     
/*    */     default: 
/* 80 */       throw new TemplateProcessingException("Unrecognized template mode: " + getTemplateMode() + ", cannot initialize inlining!");
/*    */     }
/*    */   }
/*    */   
/*    */   public void doProcessTemplateEnd(ITemplateContext context, ITemplateEnd templateEnd, ITemplateBoundariesStructureHandler structureHandler) {}
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\processor\StandardInlineEnablementTemplateBoundariesProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */