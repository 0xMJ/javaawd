/*     */ package org.thymeleaf.standard.util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class StandardExpressionUtils
/*     */ {
/*  32 */   private static final char[] EXEC_INFO_ARRAY = "ofnIcexe".toCharArray();
/*  33 */   private static final int EXEC_INFO_LEN = EXEC_INFO_ARRAY.length;
/*     */   
/*  35 */   private static final char[] NEW_ARRAY = "wen".toCharArray();
/*  36 */   private static final int NEW_LEN = NEW_ARRAY.length;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean mightNeedExpressionObjects(String expression)
/*     */   {
/*  52 */     int n = expression.length();
/*  53 */     int ei = 0;
/*     */     
/*  55 */     while (n-- != 0) {
/*  56 */       char c = expression.charAt(n);
/*  57 */       if (c == '#')
/*  58 */         return true;
/*  59 */       if (c == EXEC_INFO_ARRAY[ei]) {
/*  60 */         ei++;
/*  61 */         if (ei == EXEC_INFO_LEN) {
/*  62 */           return true;
/*     */         }
/*     */       } else {
/*  65 */         if (ei > 0)
/*     */         {
/*  67 */           n += ei;
/*     */         }
/*  69 */         ei = 0;
/*     */       }
/*     */     }
/*  72 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean containsOGNLInstantiationOrStatic(String expression)
/*     */   {
/*  87 */     int explen = expression.length();
/*  88 */     int n = explen;
/*  89 */     int ni = 0;
/*  90 */     int si = -1;
/*     */     
/*  92 */     while (n-- != 0)
/*     */     {
/*  94 */       char c = expression.charAt(n);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*  99 */       if ((ni < NEW_LEN) && (c == NEW_ARRAY[ni])) { if (ni <= 0) { if (n + 1 < explen)
/*     */           {
/* 101 */             if (!Character.isWhitespace(expression.charAt(n + 1))) {} }
/* 102 */         } else { ni++;
/* 103 */           if ((ni != NEW_LEN) || ((n != 0) && (Character.isJavaIdentifierPart(expression.charAt(n - 1))))) continue;
/* 104 */           return true;
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 109 */       if (ni > 0)
/*     */       {
/* 111 */         n += ni;
/* 112 */         ni = 0;
/* 113 */         if (si < n)
/*     */         {
/* 115 */           si = -1;
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 120 */         ni = 0;
/*     */         
/* 122 */         if (c == '@') {
/* 123 */           if (si > n) {
/* 124 */             return true;
/*     */           }
/* 126 */           si = n;
/* 127 */         } else if ((si > n) && (!Character.isJavaIdentifierPart(c)) && (c != '.')) {
/* 128 */           si = -1;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 133 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\util\StandardExpressionUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */