/*     */ package org.thymeleaf.standard.processor;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.thymeleaf.context.ITemplateContext;
/*     */ import org.thymeleaf.model.IDocType;
/*     */ import org.thymeleaf.processor.doctype.AbstractDocTypeProcessor;
/*     */ import org.thymeleaf.processor.doctype.IDocTypeStructureHandler;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class StandardTranslationDocTypeProcessor
/*     */   extends AbstractDocTypeProcessor
/*     */ {
/*     */   private static final String XHTML1_STRICT_THYMELEAF1_SYSTEMID = "http://www.thymeleaf.org/dtd/xhtml1-strict-thymeleaf-1.dtd";
/*     */   private static final String XHTML1_STRICT_THYMELEAF2_SYSTEMID = "http://www.thymeleaf.org/dtd/xhtml1-strict-thymeleaf-2.dtd";
/*     */   private static final String XHTML1_STRICT_THYMELEAF3_SYSTEMID = "http://www.thymeleaf.org/dtd/xhtml1-strict-thymeleaf-3.dtd";
/*     */   private static final String XHTML1_STRICT_THYMELEAF4_SYSTEMID = "http://www.thymeleaf.org/dtd/xhtml1-strict-thymeleaf-4.dtd";
/*     */   private static final String XHTML1_TRANSITIONAL_THYMELEAF1_SYSTEMID = "http://www.thymeleaf.org/dtd/xhtml1-transitional-thymeleaf-1.dtd";
/*     */   private static final String XHTML1_TRANSITIONAL_THYMELEAF2_SYSTEMID = "http://www.thymeleaf.org/dtd/xhtml1-transitional-thymeleaf-2.dtd";
/*     */   private static final String XHTML1_TRANSITIONAL_THYMELEAF3_SYSTEMID = "http://www.thymeleaf.org/dtd/xhtml1-transitional-thymeleaf-3.dtd";
/*     */   private static final String XHTML1_TRANSITIONAL_THYMELEAF4_SYSTEMID = "http://www.thymeleaf.org/dtd/xhtml1-transitional-thymeleaf-4.dtd";
/*     */   private static final String XHTML1_FRAMESET_THYMELEAF1_SYSTEMID = "http://www.thymeleaf.org/dtd/xhtml1-frameset-thymeleaf-1.dtd";
/*     */   private static final String XHTML1_FRAMESET_THYMELEAF2_SYSTEMID = "http://www.thymeleaf.org/dtd/xhtml1-frameset-thymeleaf-2.dtd";
/*     */   private static final String XHTML1_FRAMESET_THYMELEAF3_SYSTEMID = "http://www.thymeleaf.org/dtd/xhtml1-frameset-thymeleaf-3.dtd";
/*     */   private static final String XHTML1_FRAMESET_THYMELEAF4_SYSTEMID = "http://www.thymeleaf.org/dtd/xhtml1-frameset-thymeleaf-4.dtd";
/*     */   private static final String XHTML11_THYMELEAF1_SYSTEMID = "http://www.thymeleaf.org/dtd/xhtml11-thymeleaf-1.dtd";
/*     */   private static final String XHTML11_THYMELEAF2_SYSTEMID = "http://www.thymeleaf.org/dtd/xhtml11-thymeleaf-2.dtd";
/*     */   private static final String XHTML11_THYMELEAF3_SYSTEMID = "http://www.thymeleaf.org/dtd/xhtml11-thymeleaf-3.dtd";
/*     */   private static final String XHTML11_THYMELEAF4_SYSTEMID = "http://www.thymeleaf.org/dtd/xhtml11-thymeleaf-4.dtd";
/*     */   private static final String XHTML_1_STRICT_PUBLICID = "-//W3C//DTD XHTML 1.0 Strict//EN";
/*     */   private static final String XHTML_1_STRICT_SYSTEMID = "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd";
/*     */   private static final String XHTML_1_TRANSITIONAL_PUBLICID = "-//W3C//DTD XHTML 1.0 Transitional//EN";
/*     */   private static final String XHTML_1_TRANSITIONAL_SYSTEMID = "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd";
/*     */   private static final String XHTML_1_FRAMESET_PUBLICID = "-//W3C//DTD XHTML 1.0 Frameset//EN";
/*     */   private static final String XHTML_1_FRAMESET_SYSTEMID = "http://www.w3.org/TR/xhtml1/DTD/xhtml1-frameset.dtd";
/*     */   private static final String XHTML_11_PUBLICID = "-//W3C//DTD XHTML 1.1//EN";
/*     */   private static final String XHTML_11_SYSTEMID = "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd";
/*  88 */   private static final Map<String, String> TRANSLATED_SYSTEM_IDS = new HashMap();
/*     */   
/*  90 */   static { TRANSLATED_SYSTEM_IDS.put("http://www.thymeleaf.org/dtd/xhtml1-strict-thymeleaf-1.dtd", "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd");
/*  91 */     TRANSLATED_SYSTEM_IDS.put("http://www.thymeleaf.org/dtd/xhtml1-strict-thymeleaf-2.dtd", "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd");
/*  92 */     TRANSLATED_SYSTEM_IDS.put("http://www.thymeleaf.org/dtd/xhtml1-strict-thymeleaf-3.dtd", "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd");
/*  93 */     TRANSLATED_SYSTEM_IDS.put("http://www.thymeleaf.org/dtd/xhtml1-strict-thymeleaf-4.dtd", "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd");
/*     */     
/*  95 */     TRANSLATED_SYSTEM_IDS.put("http://www.thymeleaf.org/dtd/xhtml1-transitional-thymeleaf-1.dtd", "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd");
/*  96 */     TRANSLATED_SYSTEM_IDS.put("http://www.thymeleaf.org/dtd/xhtml1-transitional-thymeleaf-2.dtd", "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd");
/*  97 */     TRANSLATED_SYSTEM_IDS.put("http://www.thymeleaf.org/dtd/xhtml1-transitional-thymeleaf-3.dtd", "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd");
/*  98 */     TRANSLATED_SYSTEM_IDS.put("http://www.thymeleaf.org/dtd/xhtml1-transitional-thymeleaf-4.dtd", "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd");
/*     */     
/* 100 */     TRANSLATED_SYSTEM_IDS.put("http://www.thymeleaf.org/dtd/xhtml1-frameset-thymeleaf-1.dtd", "http://www.w3.org/TR/xhtml1/DTD/xhtml1-frameset.dtd");
/* 101 */     TRANSLATED_SYSTEM_IDS.put("http://www.thymeleaf.org/dtd/xhtml1-frameset-thymeleaf-2.dtd", "http://www.w3.org/TR/xhtml1/DTD/xhtml1-frameset.dtd");
/* 102 */     TRANSLATED_SYSTEM_IDS.put("http://www.thymeleaf.org/dtd/xhtml1-frameset-thymeleaf-3.dtd", "http://www.w3.org/TR/xhtml1/DTD/xhtml1-frameset.dtd");
/* 103 */     TRANSLATED_SYSTEM_IDS.put("http://www.thymeleaf.org/dtd/xhtml1-frameset-thymeleaf-4.dtd", "http://www.w3.org/TR/xhtml1/DTD/xhtml1-frameset.dtd");
/*     */     
/* 105 */     TRANSLATED_SYSTEM_IDS.put("http://www.thymeleaf.org/dtd/xhtml11-thymeleaf-1.dtd", "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd");
/* 106 */     TRANSLATED_SYSTEM_IDS.put("http://www.thymeleaf.org/dtd/xhtml11-thymeleaf-2.dtd", "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd");
/* 107 */     TRANSLATED_SYSTEM_IDS.put("http://www.thymeleaf.org/dtd/xhtml11-thymeleaf-3.dtd", "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd");
/* 108 */     TRANSLATED_SYSTEM_IDS.put("http://www.thymeleaf.org/dtd/xhtml11-thymeleaf-4.dtd", "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd");
/*     */     
/*     */ 
/* 111 */     PUBLIC_IDS_BY_SYSTEM_IDS = new HashMap();
/*     */     
/* 113 */     PUBLIC_IDS_BY_SYSTEM_IDS.put("http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd", "-//W3C//DTD XHTML 1.0 Strict//EN");
/* 114 */     PUBLIC_IDS_BY_SYSTEM_IDS.put("http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd", "-//W3C//DTD XHTML 1.0 Transitional//EN");
/* 115 */     PUBLIC_IDS_BY_SYSTEM_IDS.put("http://www.w3.org/TR/xhtml1/DTD/xhtml1-frameset.dtd", "-//W3C//DTD XHTML 1.0 Frameset//EN");
/* 116 */     PUBLIC_IDS_BY_SYSTEM_IDS.put("http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd", "-//W3C//DTD XHTML 1.1//EN");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public StandardTranslationDocTypeProcessor()
/*     */   {
/* 123 */     super(TemplateMode.HTML, 1000);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static final Map<String, String> PUBLIC_IDS_BY_SYSTEM_IDS;
/*     */   
/*     */ 
/*     */   public static final int PRECEDENCE = 1000;
/*     */   
/*     */   protected void doProcess(ITemplateContext context, IDocType docType, IDocTypeStructureHandler structureHandler)
/*     */   {
/* 135 */     if ("SYSTEM".equalsIgnoreCase(docType.getType()))
/*     */     {
/* 137 */       String translatedSystemId = (String)TRANSLATED_SYSTEM_IDS.get(docType.getSystemId());
/*     */       
/* 139 */       if (translatedSystemId != null)
/*     */       {
/* 141 */         String translatedPublicId = (String)PUBLIC_IDS_BY_SYSTEM_IDS.get(translatedSystemId);
/*     */         
/* 143 */         structureHandler.setDocType(docType
/* 144 */           .getKeyword(), docType.getElementName(), translatedPublicId, translatedSystemId, docType
/*     */           
/* 146 */           .getInternalSubset());
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\processor\StandardTranslationDocTypeProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */