/*     */ package org.thymeleaf.standard.expression;
/*     */ 
/*     */ import org.thymeleaf.IEngineConfiguration;
/*     */ import org.thymeleaf.context.IExpressionContext;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class StandardExpressionParser
/*     */   implements IStandardExpressionParser
/*     */ {
/*     */   public Expression parseExpression(IExpressionContext context, String input)
/*     */   {
/*  60 */     Validate.notNull(context, "Context cannot be null");
/*  61 */     Validate.notNull(input, "Input cannot be null");
/*  62 */     return (Expression)parseExpression(context, input, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AssignationSequence parseAssignationSequence(IExpressionContext context, String input, boolean allowParametersWithoutValue)
/*     */   {
/*  71 */     Validate.notNull(context, "Context cannot be null");
/*  72 */     Validate.notNull(input, "Input cannot be null");
/*  73 */     return AssignationUtils.parseAssignationSequence(context, input, allowParametersWithoutValue);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ExpressionSequence parseExpressionSequence(IExpressionContext context, String input)
/*     */   {
/*  82 */     Validate.notNull(context, "Context cannot be null");
/*  83 */     Validate.notNull(input, "Input cannot be null");
/*  84 */     return ExpressionSequenceUtils.parseExpressionSequence(context, input);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Each parseEach(IExpressionContext context, String input)
/*     */   {
/*  93 */     Validate.notNull(context, "Context cannot be null");
/*  94 */     Validate.notNull(input, "Input cannot be null");
/*  95 */     return EachUtils.parseEach(context, input);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public FragmentSignature parseFragmentSignature(IEngineConfiguration configuration, String input)
/*     */   {
/* 102 */     Validate.notNull(configuration, "Configuration cannot be null");
/* 103 */     Validate.notNull(input, "Input cannot be null");
/* 104 */     return FragmentSignatureUtils.parseFragmentSignature(configuration, input);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static IStandardExpression parseExpression(IExpressionContext context, String input, boolean preprocess)
/*     */   {
/* 117 */     IEngineConfiguration configuration = context.getConfiguration();
/*     */     
/*     */ 
/* 120 */     String preprocessedInput = preprocess ? StandardExpressionPreprocessor.preprocess(context, input) : input;
/*     */     
/*     */ 
/* 123 */     IStandardExpression cachedExpression = ExpressionCache.getExpressionFromCache(configuration, preprocessedInput);
/* 124 */     if (cachedExpression != null) {
/* 125 */       return cachedExpression;
/*     */     }
/*     */     
/* 128 */     Expression expression = Expression.parse(preprocessedInput.trim());
/*     */     
/* 130 */     if (expression == null) {
/* 131 */       throw new TemplateProcessingException("Could not parse as expression: \"" + input + "\"");
/*     */     }
/*     */     
/* 134 */     ExpressionCache.putExpressionIntoCache(configuration, preprocessedInput, expression);
/*     */     
/* 136 */     return expression;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 150 */     return "Standard Expression Parser";
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\expression\StandardExpressionParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */