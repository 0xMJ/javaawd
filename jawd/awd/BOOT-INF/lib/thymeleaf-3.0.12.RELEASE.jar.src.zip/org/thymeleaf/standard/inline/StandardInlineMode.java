/*     */ package org.thymeleaf.standard.inline;
/*     */ 
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.thymeleaf.TemplateEngine;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum StandardInlineMode
/*     */ {
/*  40 */   NONE,  HTML,  XML,  TEXT,  JAVASCRIPT,  CSS;
/*     */   
/*     */ 
/*  43 */   private static final Logger LOGGER = LoggerFactory.getLogger(StandardInlineMode.class);
/*     */   
/*     */   private StandardInlineMode() {}
/*     */   
/*  47 */   public static StandardInlineMode parse(String mode) { if ((mode == null) || (mode.trim().length() == 0)) {
/*  48 */       throw new IllegalArgumentException("Inline mode cannot be null or empty");
/*     */     }
/*  50 */     if ("NONE".equalsIgnoreCase(mode)) {
/*  51 */       return NONE;
/*     */     }
/*  53 */     if ("HTML".equalsIgnoreCase(mode)) {
/*  54 */       return HTML;
/*     */     }
/*  56 */     if ("XML".equalsIgnoreCase(mode)) {
/*  57 */       return XML;
/*     */     }
/*  59 */     if ("TEXT".equalsIgnoreCase(mode)) {
/*  60 */       return TEXT;
/*     */     }
/*  62 */     if ("JAVASCRIPT".equalsIgnoreCase(mode)) {
/*  63 */       return JAVASCRIPT;
/*     */     }
/*  65 */     if ("CSS".equalsIgnoreCase(mode)) {
/*  66 */       return CSS;
/*     */     }
/*  68 */     if (checkDartInline(mode)) {
/*  69 */       return JAVASCRIPT;
/*     */     }
/*  71 */     throw new IllegalArgumentException("Unrecognized inline mode: " + mode);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   private static boolean checkDartInline(String inliner)
/*     */   {
/*  92 */     if ("DART".equalsIgnoreCase(inliner)) {
/*  93 */       LOGGER.warn("[THYMELEAF][{}] Found inline call with value \"dart\", which has been deprecated as no corresponding template mode exists for it. Inline will be redirected to \"javascript\", which should now be used instead. This redirection will be removed in future versions of Thymeleaf.", 
/*     */       
/*     */ 
/*     */ 
/*  97 */         TemplateEngine.threadIndex());
/*  98 */       return true;
/*     */     }
/* 100 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\inline\StandardInlineMode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */