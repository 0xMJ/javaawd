/*     */ package org.thymeleaf.standard.expression;
/*     */ 
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.thymeleaf.TemplateEngine;
/*     */ import org.thymeleaf.context.IExpressionContext;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class VariableExpression
/*     */   extends SimpleExpression
/*     */   implements IStandardVariableExpression
/*     */ {
/*  43 */   private static final Logger logger = LoggerFactory.getLogger(VariableExpression.class);
/*     */   
/*     */ 
/*     */ 
/*     */   private static final long serialVersionUID = -4911752782987240708L;
/*     */   
/*     */ 
/*     */   static final char SELECTOR = '$';
/*     */   
/*     */ 
/*  53 */   private static final Pattern VAR_PATTERN = Pattern.compile("^\\s*\\$\\{(.+?)\\}\\s*$", 32);
/*     */   
/*  55 */   static final Expression NULL_VALUE = parseVariableExpression("${null}");
/*     */   
/*     */ 
/*     */   private final String expression;
/*     */   
/*     */ 
/*     */   private final boolean convertToString;
/*     */   
/*  63 */   private volatile Object cachedExpression = null;
/*     */   
/*     */ 
/*     */   public VariableExpression(String expression)
/*     */   {
/*  68 */     this(expression, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public VariableExpression(String expression, boolean convertToString)
/*     */   {
/*  80 */     Validate.notNull(expression, "Expression cannot be null");
/*  81 */     this.expression = expression;
/*  82 */     this.convertToString = convertToString;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getExpression()
/*     */   {
/*  88 */     return this.expression;
/*     */   }
/*     */   
/*     */   public boolean getUseSelectionAsRoot() {
/*  92 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getConvertToString()
/*     */   {
/* 102 */     return this.convertToString;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object getCachedExpression()
/*     */   {
/* 109 */     return this.cachedExpression;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setCachedExpression(Object cachedExpression)
/*     */   {
/* 115 */     this.cachedExpression = cachedExpression;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getStringRepresentation()
/*     */   {
/* 122 */     return 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 127 */       String.valueOf('$') + String.valueOf('{') + (this.convertToString ? String.valueOf('{') : "") + this.expression + (this.convertToString ? String.valueOf('}') : "") + String.valueOf('}');
/*     */   }
/*     */   
/*     */ 
/*     */   static VariableExpression parseVariableExpression(String input)
/*     */   {
/* 133 */     Matcher matcher = VAR_PATTERN.matcher(input);
/* 134 */     if (!matcher.matches()) {
/* 135 */       return null;
/*     */     }
/* 137 */     String expression = matcher.group(1);
/* 138 */     int expressionLen = expression.length();
/* 139 */     if ((expressionLen > 2) && 
/* 140 */       (expression.charAt(0) == '{') && 
/* 141 */       (expression.charAt(expressionLen - 1) == '}'))
/*     */     {
/* 143 */       return new VariableExpression(expression.substring(1, expressionLen - 1), true);
/*     */     }
/* 145 */     return new VariableExpression(expression, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static Object executeVariableExpression(IExpressionContext context, VariableExpression expression, IStandardVariableExpressionEvaluator expressionEvaluator, StandardExpressionExecutionContext expContext)
/*     */   {
/* 159 */     if (logger.isTraceEnabled()) {
/* 160 */       logger.trace("[THYMELEAF][{}] Evaluating variable expression: \"{}\"", TemplateEngine.threadIndex(), expression.getStringRepresentation());
/*     */     }
/*     */     
/*     */ 
/* 164 */     StandardExpressionExecutionContext evalExpContext = expression.getConvertToString() ? expContext.withTypeConversion() : expContext.withoutTypeConversion();
/*     */     
/* 166 */     Object result = expressionEvaluator.evaluate(context, expression, evalExpContext);
/*     */     
/* 168 */     if (!expContext.getForbidUnsafeExpressionResults()) {
/* 169 */       return result;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 175 */     if ((result == null) || ((result instanceof Number)) || ((result instanceof Boolean)))
/*     */     {
/*     */ 
/* 178 */       return result;
/*     */     }
/*     */     
/* 181 */     throw new TemplateProcessingException("Only variable expressions returning numbers or booleans are allowed in this context, any other datatypes are not trusted in the context of this expression, including Strings or any other object that could be rendered as a text literal. A typical case is HTML attributes for event handlers (e.g. \"onload\"), in which textual data from variables should better be output to \"data-*\" attributes and then read from the event handler.");
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\expression\VariableExpression.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */