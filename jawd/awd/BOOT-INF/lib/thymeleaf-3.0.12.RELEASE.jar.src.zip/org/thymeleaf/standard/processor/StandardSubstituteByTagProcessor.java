/*    */ package org.thymeleaf.standard.processor;
/*    */ 
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ import org.thymeleaf.TemplateEngine;
/*    */ import org.thymeleaf.context.ITemplateContext;
/*    */ import org.thymeleaf.engine.AttributeName;
/*    */ import org.thymeleaf.engine.AttributeNames;
/*    */ import org.thymeleaf.engine.TemplateData;
/*    */ import org.thymeleaf.model.IAttribute;
/*    */ import org.thymeleaf.model.IProcessableElementTag;
/*    */ import org.thymeleaf.processor.element.IElementTagStructureHandler;
/*    */ import org.thymeleaf.templatemode.TemplateMode;
/*    */ import org.thymeleaf.util.LoggingUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class StandardSubstituteByTagProcessor
/*    */   extends AbstractStandardFragmentInsertionTagProcessor
/*    */ {
/* 42 */   private static final Logger LOGGER = LoggerFactory.getLogger(StandardSubstituteByTagProcessor.class);
/*    */   
/*    */ 
/*    */   public static final int PRECEDENCE = 100;
/*    */   
/*    */   public static final String ATTR_NAME = "substituteby";
/*    */   
/*    */ 
/*    */   public StandardSubstituteByTagProcessor(TemplateMode templateMode, String dialectPrefix)
/*    */   {
/* 52 */     super(templateMode, dialectPrefix, "substituteby", 100, true);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected void doProcess(ITemplateContext context, IProcessableElementTag tag, AttributeName attributeName, String attributeValue, IElementTagStructureHandler structureHandler)
/*    */   {
/* 63 */     if (LOGGER.isWarnEnabled()) {
/* 64 */       LOGGER.warn("[THYMELEAF][{}][{}] Deprecated attribute {} found in template {}, line {}, col {}. Please use {} instead, this deprecated attribute will be removed in future versions of Thymeleaf.", new Object[] {
/*    */       
/*    */ 
/*    */ 
/* 68 */         TemplateEngine.threadIndex(), LoggingUtils.loggifyTemplateName(context.getTemplateData().getTemplate()), attributeName, tag
/* 69 */         .getTemplateName(), 
/* 70 */         Integer.valueOf(tag.getAttribute(attributeName).getLine()), Integer.valueOf(tag.getAttribute(attributeName).getCol()), 
/* 71 */         AttributeNames.forHTMLName(attributeName.getPrefix(), "replace") });
/*    */     }
/*    */     
/* 74 */     super.doProcess(context, tag, attributeName, attributeValue, structureHandler);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\processor\StandardSubstituteByTagProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */