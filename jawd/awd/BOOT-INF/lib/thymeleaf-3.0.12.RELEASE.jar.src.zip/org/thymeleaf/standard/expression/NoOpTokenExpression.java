/*    */ package org.thymeleaf.standard.expression;
/*    */ 
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ import org.thymeleaf.TemplateEngine;
/*    */ import org.thymeleaf.context.IExpressionContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class NoOpTokenExpression
/*    */   extends Token
/*    */ {
/* 38 */   private static final Logger logger = LoggerFactory.getLogger(NoOpTokenExpression.class);
/*    */   
/*    */   private static final long serialVersionUID = -5180150929940011L;
/*    */   
/* 42 */   private static final NoOpTokenExpression SINGLETON = new NoOpTokenExpression();
/*    */   
/*    */   public NoOpTokenExpression()
/*    */   {
/* 46 */     super(null);
/*    */   }
/*    */   
/*    */ 
/*    */   public String getStringRepresentation()
/*    */   {
/* 52 */     return "_";
/*    */   }
/*    */   
/*    */   static NoOpTokenExpression parseNoOpTokenExpression(String input)
/*    */   {
/* 57 */     if ((input.length() == 1) && (input.charAt(0) == '_')) {
/* 58 */       return SINGLETON;
/*    */     }
/* 60 */     return null;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   static Object executeNoOpTokenExpression(IExpressionContext context, NoOpTokenExpression expression, StandardExpressionExecutionContext expContext)
/*    */   {
/* 69 */     if (logger.isTraceEnabled()) {
/* 70 */       logger.trace("[THYMELEAF][{}] Evaluating no-op token: \"{}\"", TemplateEngine.threadIndex(), expression.getStringRepresentation());
/*    */     }
/*    */     
/* 73 */     return NoOpToken.VALUE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\expression\NoOpTokenExpression.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */