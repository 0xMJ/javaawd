/*     */ package org.thymeleaf.standard.expression;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.thymeleaf.expression.IExpressionObjects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class OGNLExpressionObjectsWrapper
/*     */   extends HashMap<String, Object>
/*     */ {
/*     */   private final IExpressionObjects expressionObjects;
/*     */   private final boolean restrictedExpressionExecution;
/*     */   
/*     */   OGNLExpressionObjectsWrapper(IExpressionObjects expressionObjects, boolean restrictedExpressionExecution)
/*     */   {
/*  44 */     super(5);
/*  45 */     this.expressionObjects = expressionObjects;
/*  46 */     this.restrictedExpressionExecution = restrictedExpressionExecution;
/*     */   }
/*     */   
/*     */ 
/*     */   public int size()
/*     */   {
/*  52 */     return super.size() + this.expressionObjects.size();
/*     */   }
/*     */   
/*     */   public boolean isEmpty()
/*     */   {
/*  57 */     return (this.expressionObjects.size() == 0) && (super.isEmpty());
/*     */   }
/*     */   
/*     */ 
/*     */   public Object get(Object key)
/*     */   {
/*  63 */     if (this.expressionObjects.containsObject(key.toString()))
/*     */     {
/*  65 */       Object expressionObject = this.expressionObjects.getObject(key.toString());
/*     */       
/*     */ 
/*  68 */       if ((this.restrictedExpressionExecution) && (
/*  69 */         ("request".equals(key)) || 
/*  70 */         ("httpServletRequest".equals(key)))) {
/*  71 */         return RestrictedRequestAccessUtils.wrapRequestObject(expressionObject);
/*     */       }
/*     */       
/*  74 */       return expressionObject;
/*     */     }
/*     */     
/*  77 */     return super.get(key);
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean containsKey(Object key)
/*     */   {
/*  83 */     return (this.expressionObjects.containsObject(key.toString())) || (super.containsKey(key));
/*     */   }
/*     */   
/*     */   public Object put(String key, Object value)
/*     */   {
/*  88 */     if (this.expressionObjects.containsObject(key.toString())) {
/*  89 */       throw new IllegalArgumentException("Cannot put entry with key \"" + key + "\" into Expression Objects wrapper map: key matches the name of one of the expression objects");
/*     */     }
/*     */     
/*     */ 
/*  93 */     return super.put(key, value);
/*     */   }
/*     */   
/*     */ 
/*     */   public void putAll(Map<? extends String, ?> m)
/*     */   {
/*  99 */     super.putAll(m);
/*     */   }
/*     */   
/*     */   public Object remove(Object key)
/*     */   {
/* 104 */     if (this.expressionObjects.containsObject(key.toString())) {
/* 105 */       throw new IllegalArgumentException("Cannot remove entry with key \"" + key + "\" from Expression Objects wrapper map: key matches the name of one of the expression objects");
/*     */     }
/*     */     
/*     */ 
/* 109 */     return super.remove(key);
/*     */   }
/*     */   
/*     */   public void clear()
/*     */   {
/* 114 */     throw new UnsupportedOperationException("Cannot clear Expression Objects wrapper map");
/*     */   }
/*     */   
/*     */   public boolean containsValue(Object value)
/*     */   {
/* 119 */     throw new UnsupportedOperationException("Cannot perform by-value search on Expression Objects wrapper map");
/*     */   }
/*     */   
/*     */   public Object clone()
/*     */   {
/* 124 */     throw new UnsupportedOperationException("Cannot clone Expression Objects wrapper map");
/*     */   }
/*     */   
/*     */   public Set<String> keySet()
/*     */   {
/* 129 */     if (super.isEmpty()) {
/* 130 */       return this.expressionObjects.getObjectNames();
/*     */     }
/* 132 */     Set<String> keys = new LinkedHashSet(this.expressionObjects.getObjectNames());
/* 133 */     keys.addAll(super.keySet());
/* 134 */     return keys;
/*     */   }
/*     */   
/*     */   public Collection<Object> values()
/*     */   {
/* 139 */     return super.values();
/*     */   }
/*     */   
/*     */   public Set<Map.Entry<String, Object>> entrySet()
/*     */   {
/* 144 */     throw new UnsupportedOperationException("Cannot retrieve a complete entry set for Expression Objects wrapper map. Get a key set instead");
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/* 150 */     throw new UnsupportedOperationException("Cannot execute equals operation on Expression Objects wrapper map");
/*     */   }
/*     */   
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 156 */     throw new UnsupportedOperationException("Cannot execute hashCode operation on Expression Objects wrapper map");
/*     */   }
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/* 162 */     return "{EXPRESSION OBJECTS WRAPPER MAP FOR KEYS: " + keySet() + "}";
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\expression\OGNLExpressionObjectsWrapper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */