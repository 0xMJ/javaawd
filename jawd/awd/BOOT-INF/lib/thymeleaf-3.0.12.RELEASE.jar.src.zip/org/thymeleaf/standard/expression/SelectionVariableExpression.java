/*     */ package org.thymeleaf.standard.expression;
/*     */ 
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.thymeleaf.TemplateEngine;
/*     */ import org.thymeleaf.context.IExpressionContext;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SelectionVariableExpression
/*     */   extends SimpleExpression
/*     */   implements IStandardVariableExpression
/*     */ {
/*  43 */   private static final Logger logger = LoggerFactory.getLogger(SelectionVariableExpression.class);
/*     */   
/*     */ 
/*     */   private static final long serialVersionUID = 854441190427550056L;
/*     */   
/*     */   static final char SELECTOR = '*';
/*     */   
/*  50 */   private static final Pattern SELECTION_VAR_PATTERN = Pattern.compile("^\\s*\\*\\{(.+?)\\}\\s*$", 32);
/*     */   
/*     */ 
/*     */   private final String expression;
/*     */   
/*     */   private final boolean convertToString;
/*     */   
/*  57 */   private volatile Object cachedExpression = null;
/*     */   
/*     */ 
/*     */   public SelectionVariableExpression(String expression)
/*     */   {
/*  62 */     this(expression, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SelectionVariableExpression(String expression, boolean convertToString)
/*     */   {
/*  74 */     Validate.notNull(expression, "Expression cannot be null");
/*  75 */     this.expression = expression;
/*  76 */     this.convertToString = convertToString;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getExpression()
/*     */   {
/*  82 */     return this.expression;
/*     */   }
/*     */   
/*     */   public boolean getUseSelectionAsRoot() {
/*  86 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getConvertToString()
/*     */   {
/*  96 */     return this.convertToString;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object getCachedExpression()
/*     */   {
/* 103 */     return this.cachedExpression;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setCachedExpression(Object cachedExpression)
/*     */   {
/* 109 */     this.cachedExpression = cachedExpression;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getStringRepresentation()
/*     */   {
/* 116 */     return 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 121 */       String.valueOf('*') + String.valueOf('{') + (this.convertToString ? String.valueOf('{') : "") + this.expression + (this.convertToString ? String.valueOf('}') : "") + String.valueOf('}');
/*     */   }
/*     */   
/*     */ 
/*     */   static SelectionVariableExpression parseSelectionVariableExpression(String input)
/*     */   {
/* 127 */     Matcher matcher = SELECTION_VAR_PATTERN.matcher(input);
/* 128 */     if (!matcher.matches()) {
/* 129 */       return null;
/*     */     }
/* 131 */     String expression = matcher.group(1);
/* 132 */     int expressionLen = expression.length();
/* 133 */     if ((expressionLen > 2) && 
/* 134 */       (expression.charAt(0) == '{') && 
/* 135 */       (expression.charAt(expressionLen - 1) == '}'))
/*     */     {
/* 137 */       return new SelectionVariableExpression(expression.substring(1, expressionLen - 1), true);
/*     */     }
/* 139 */     return new SelectionVariableExpression(expression, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static Object executeSelectionVariableExpression(IExpressionContext context, SelectionVariableExpression expression, IStandardVariableExpressionEvaluator expressionEvaluator, StandardExpressionExecutionContext expContext)
/*     */   {
/* 151 */     if (logger.isTraceEnabled()) {
/* 152 */       logger.trace("[THYMELEAF][{}] Evaluating selection variable expression: \"{}\"", TemplateEngine.threadIndex(), expression.getStringRepresentation());
/*     */     }
/*     */     
/*     */ 
/* 156 */     StandardExpressionExecutionContext evalExpContext = expression.getConvertToString() ? expContext.withTypeConversion() : expContext.withoutTypeConversion();
/*     */     
/* 158 */     Object result = expressionEvaluator.evaluate(context, expression, evalExpContext);
/*     */     
/* 160 */     if (!expContext.getForbidUnsafeExpressionResults()) {
/* 161 */       return result;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 167 */     if ((result == null) || ((result instanceof Number)) || ((result instanceof Boolean)))
/*     */     {
/*     */ 
/* 170 */       return result;
/*     */     }
/*     */     
/* 173 */     throw new TemplateProcessingException("Only variable expressions returning numbers or booleans are allowed in this context, any other datatypes are not trusted in the context of this expression, including Strings or any other object that could be rendered as a text literal. A typical case is HTML attributes for event handlers (e.g. \"onload\"), in which textual data from variables should better be output to \"data-*\" attributes and then read from the event handler.");
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\expression\SelectionVariableExpression.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */