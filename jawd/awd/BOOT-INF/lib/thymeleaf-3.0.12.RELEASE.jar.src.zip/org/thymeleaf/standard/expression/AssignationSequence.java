/*    */ package org.thymeleaf.standard.expression;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Collections;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import org.thymeleaf.util.Validate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AssignationSequence
/*    */   implements Iterable<Assignation>, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = -4915282307441011014L;
/*    */   private final List<Assignation> assignations;
/*    */   
/*    */   AssignationSequence(List<Assignation> assignations)
/*    */   {
/* 50 */     Validate.notNull(assignations, "Assignation list cannot be null");
/* 51 */     Validate.containsNoNulls(assignations, "Assignation list cannot contain any nulls");
/* 52 */     this.assignations = Collections.unmodifiableList(assignations);
/*    */   }
/*    */   
/*    */   public List<Assignation> getAssignations()
/*    */   {
/* 57 */     return this.assignations;
/*    */   }
/*    */   
/*    */   public int size() {
/* 61 */     return this.assignations.size();
/*    */   }
/*    */   
/*    */   public Iterator<Assignation> iterator() {
/* 65 */     return this.assignations.iterator();
/*    */   }
/*    */   
/*    */   public String getStringRepresentation()
/*    */   {
/* 70 */     StringBuilder sb = new StringBuilder();
/* 71 */     if (this.assignations.size() > 0) {
/* 72 */       sb.append(this.assignations.get(0));
/* 73 */       for (int i = 1; i < this.assignations.size(); i++) {
/* 74 */         sb.append(',');
/* 75 */         sb.append(this.assignations.get(i));
/*    */       }
/*    */     }
/* 78 */     return sb.toString();
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 83 */     return getStringRepresentation();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\expression\AssignationSequence.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */