/*    */ package org.thymeleaf.standard.processor;
/*    */ 
/*    */ import org.thymeleaf.templatemode.TemplateMode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class StandardXmlLangTagProcessor
/*    */   extends AbstractStandardAttributeModifierTagProcessor
/*    */ {
/*    */   public static final int PRECEDENCE = 1000;
/*    */   public static final String ATTR_NAME = "xmllang";
/*    */   public static final String TARGET_ATTR_NAME = "xml:lang";
/*    */   
/*    */   public StandardXmlLangTagProcessor(String dialectPrefix)
/*    */   {
/* 38 */     super(TemplateMode.HTML, dialectPrefix, "xmllang", "xml:lang", 1000, true, false);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\processor\StandardXmlLangTagProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */