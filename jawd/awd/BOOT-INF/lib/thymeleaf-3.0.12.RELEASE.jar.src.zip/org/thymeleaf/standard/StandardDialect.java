/*     */ package org.thymeleaf.standard;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.thymeleaf.dialect.AbstractProcessorDialect;
/*     */ import org.thymeleaf.dialect.IExecutionAttributeDialect;
/*     */ import org.thymeleaf.dialect.IExpressionObjectDialect;
/*     */ import org.thymeleaf.expression.IExpressionObjectFactory;
/*     */ import org.thymeleaf.processor.IProcessor;
/*     */ import org.thymeleaf.standard.expression.IStandardConversionService;
/*     */ import org.thymeleaf.standard.expression.IStandardExpressionParser;
/*     */ import org.thymeleaf.standard.expression.IStandardVariableExpressionEvaluator;
/*     */ import org.thymeleaf.standard.expression.OGNLVariableExpressionEvaluator;
/*     */ import org.thymeleaf.standard.expression.StandardConversionService;
/*     */ import org.thymeleaf.standard.expression.StandardExpressionObjectFactory;
/*     */ import org.thymeleaf.standard.expression.StandardExpressionParser;
/*     */ import org.thymeleaf.standard.processor.StandardActionTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardAltTitleTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardAssertTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardAttrTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardAttrappendTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardAttrprependTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardBlockTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardCaseTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardClassappendTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardConditionalCommentProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardConditionalFixedValueTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardDOMEventAttributeTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardDefaultAttributesTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardEachTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardFragmentTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardHrefTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardIfTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardIncludeTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardInlineEnablementTemplateBoundariesProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardInlineHTMLTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardInlineTextualTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardInlineXMLTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardInliningCDATASectionProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardInliningCommentProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardInliningTextProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardInsertTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardLangXmlLangTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardMethodTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardNonRemovableAttributeTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardObjectTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardRefAttributeTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardRemovableAttributeTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardRemoveTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardReplaceTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardSrcTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardStyleappendTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardSubstituteByTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardSwitchTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardTextTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardTranslationDocTypeProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardUnlessTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardUtextTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardValueTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardWithTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardXmlBaseTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardXmlLangTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardXmlNsTagProcessor;
/*     */ import org.thymeleaf.standard.processor.StandardXmlSpaceTagProcessor;
/*     */ import org.thymeleaf.standard.serializer.IStandardCSSSerializer;
/*     */ import org.thymeleaf.standard.serializer.IStandardJavaScriptSerializer;
/*     */ import org.thymeleaf.standard.serializer.StandardCSSSerializer;
/*     */ import org.thymeleaf.standard.serializer.StandardJavaScriptSerializer;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardDialect
/*     */   extends AbstractProcessorDialect
/*     */   implements IExecutionAttributeDialect, IExpressionObjectDialect
/*     */ {
/*     */   public static final String NAME = "Standard";
/*     */   public static final String PREFIX = "th";
/*     */   public static final int PROCESSOR_PRECEDENCE = 1000;
/* 128 */   private IStandardVariableExpressionEvaluator variableExpressionEvaluator = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 133 */   private IStandardExpressionParser expressionParser = null;
/* 134 */   private IStandardConversionService conversionService = null;
/* 135 */   private IStandardJavaScriptSerializer javaScriptSerializer = null;
/* 136 */   private IStandardCSSSerializer cssSerializer = null;
/*     */   
/*     */ 
/* 139 */   private IExpressionObjectFactory expressionObjectFactory = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public StandardDialect()
/*     */   {
/* 147 */     super("Standard", "th", 1000);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected StandardDialect(String name, String prefix, int processorPrecedence)
/*     */   {
/* 156 */     super(name, prefix, processorPrecedence);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public IStandardVariableExpressionEvaluator getVariableExpressionEvaluator()
/*     */   {
/* 178 */     if (this.variableExpressionEvaluator == null) {
/* 179 */       this.variableExpressionEvaluator = new OGNLVariableExpressionEvaluator(true);
/*     */     }
/* 181 */     return this.variableExpressionEvaluator;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setVariableExpressionEvaluator(IStandardVariableExpressionEvaluator variableExpressionEvaluator)
/*     */   {
/* 207 */     Validate.notNull(variableExpressionEvaluator, "Standard Variable Expression Evaluator cannot be null");
/* 208 */     this.variableExpressionEvaluator = variableExpressionEvaluator;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public IStandardExpressionParser getExpressionParser()
/*     */   {
/* 224 */     if (this.expressionParser == null) {
/* 225 */       this.expressionParser = new StandardExpressionParser();
/*     */     }
/* 227 */     return this.expressionParser;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setExpressionParser(IStandardExpressionParser expressionParser)
/*     */   {
/* 249 */     Validate.notNull(expressionParser, "Standard Expression Parser cannot be null");
/* 250 */     this.expressionParser = expressionParser;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public IStandardConversionService getConversionService()
/*     */   {
/* 267 */     if (this.conversionService == null) {
/* 268 */       this.conversionService = new StandardConversionService();
/*     */     }
/* 270 */     return this.conversionService;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setConversionService(IStandardConversionService conversionService)
/*     */   {
/* 293 */     Validate.notNull(conversionService, "Standard Conversion Service cannot be null");
/* 294 */     this.conversionService = conversionService;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public IStandardJavaScriptSerializer getJavaScriptSerializer()
/*     */   {
/* 310 */     if (this.javaScriptSerializer == null) {
/* 311 */       this.javaScriptSerializer = new StandardJavaScriptSerializer(true);
/*     */     }
/* 313 */     return this.javaScriptSerializer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setJavaScriptSerializer(IStandardJavaScriptSerializer javaScriptSerializer)
/*     */   {
/* 335 */     Validate.notNull(javaScriptSerializer, "Standard JavaScript Serializer cannot be null");
/* 336 */     this.javaScriptSerializer = javaScriptSerializer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public IStandardCSSSerializer getCSSSerializer()
/*     */   {
/* 352 */     if (this.cssSerializer == null) {
/* 353 */       this.cssSerializer = new StandardCSSSerializer();
/*     */     }
/* 355 */     return this.cssSerializer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCSSSerializer(IStandardCSSSerializer cssSerializer)
/*     */   {
/* 377 */     Validate.notNull(cssSerializer, "Standard CSS Serializer cannot be null");
/* 378 */     this.cssSerializer = cssSerializer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<String, Object> getExecutionAttributes()
/*     */   {
/* 391 */     Map<String, Object> executionAttributes = new HashMap(5, 1.0F);
/* 392 */     executionAttributes.put("StandardVariableExpressionEvaluator", 
/* 393 */       getVariableExpressionEvaluator());
/* 394 */     executionAttributes.put("StandardExpressionParser", 
/* 395 */       getExpressionParser());
/* 396 */     executionAttributes.put("StandardConversionService", 
/* 397 */       getConversionService());
/* 398 */     executionAttributes.put("StandardJavaScriptSerializer", 
/* 399 */       getJavaScriptSerializer());
/* 400 */     executionAttributes.put("StandardCSSSerializer", 
/* 401 */       getCSSSerializer());
/*     */     
/* 403 */     return executionAttributes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public IExpressionObjectFactory getExpressionObjectFactory()
/*     */   {
/* 411 */     if (this.expressionObjectFactory == null) {
/* 412 */       this.expressionObjectFactory = new StandardExpressionObjectFactory();
/*     */     }
/* 414 */     return this.expressionObjectFactory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Set<IProcessor> getProcessors(String dialectPrefix)
/*     */   {
/* 421 */     return createStandardProcessorsSet(dialectPrefix);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Set<IProcessor> createStandardProcessorsSet(String dialectPrefix)
/*     */   {
/* 444 */     Set<IProcessor> processors = new LinkedHashSet();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 460 */     processors.add(new StandardActionTagProcessor(dialectPrefix));
/* 461 */     processors.add(new StandardAltTitleTagProcessor(dialectPrefix));
/* 462 */     processors.add(new StandardAssertTagProcessor(TemplateMode.HTML, dialectPrefix));
/* 463 */     processors.add(new StandardAttrTagProcessor(TemplateMode.HTML, dialectPrefix));
/* 464 */     processors.add(new StandardAttrappendTagProcessor(TemplateMode.HTML, dialectPrefix));
/* 465 */     processors.add(new StandardAttrprependTagProcessor(TemplateMode.HTML, dialectPrefix));
/* 466 */     processors.add(new StandardCaseTagProcessor(TemplateMode.HTML, dialectPrefix));
/* 467 */     processors.add(new StandardClassappendTagProcessor(dialectPrefix));
/* 468 */     for (String attrName : StandardConditionalFixedValueTagProcessor.ATTR_NAMES) {
/* 469 */       processors.add(new StandardConditionalFixedValueTagProcessor(dialectPrefix, attrName));
/*     */     }
/* 471 */     for (String attrName : StandardDOMEventAttributeTagProcessor.ATTR_NAMES) {
/* 472 */       processors.add(new StandardDOMEventAttributeTagProcessor(dialectPrefix, attrName));
/*     */     }
/* 474 */     processors.add(new StandardEachTagProcessor(TemplateMode.HTML, dialectPrefix));
/* 475 */     processors.add(new StandardFragmentTagProcessor(TemplateMode.HTML, dialectPrefix));
/* 476 */     processors.add(new StandardHrefTagProcessor(dialectPrefix));
/* 477 */     processors.add(new StandardIfTagProcessor(TemplateMode.HTML, dialectPrefix));
/* 478 */     processors.add(new StandardIncludeTagProcessor(TemplateMode.HTML, dialectPrefix));
/* 479 */     processors.add(new StandardInlineHTMLTagProcessor(dialectPrefix));
/* 480 */     processors.add(new StandardInsertTagProcessor(TemplateMode.HTML, dialectPrefix));
/* 481 */     processors.add(new StandardLangXmlLangTagProcessor(dialectPrefix));
/* 482 */     processors.add(new StandardMethodTagProcessor(dialectPrefix));
/* 483 */     for (String attrName : StandardNonRemovableAttributeTagProcessor.ATTR_NAMES) {
/* 484 */       processors.add(new StandardNonRemovableAttributeTagProcessor(dialectPrefix, attrName));
/*     */     }
/* 486 */     processors.add(new StandardObjectTagProcessor(TemplateMode.HTML, dialectPrefix));
/* 487 */     for (String attrName : StandardRemovableAttributeTagProcessor.ATTR_NAMES) {
/* 488 */       processors.add(new StandardRemovableAttributeTagProcessor(dialectPrefix, attrName));
/*     */     }
/* 490 */     processors.add(new StandardRemoveTagProcessor(TemplateMode.HTML, dialectPrefix));
/* 491 */     processors.add(new StandardReplaceTagProcessor(TemplateMode.HTML, dialectPrefix));
/* 492 */     processors.add(new StandardSrcTagProcessor(dialectPrefix));
/* 493 */     processors.add(new StandardStyleappendTagProcessor(dialectPrefix));
/* 494 */     processors.add(new StandardSubstituteByTagProcessor(TemplateMode.HTML, dialectPrefix));
/* 495 */     processors.add(new StandardSwitchTagProcessor(TemplateMode.HTML, dialectPrefix));
/* 496 */     processors.add(new StandardTextTagProcessor(TemplateMode.HTML, dialectPrefix));
/* 497 */     processors.add(new StandardUnlessTagProcessor(TemplateMode.HTML, dialectPrefix));
/* 498 */     processors.add(new StandardUtextTagProcessor(TemplateMode.HTML, dialectPrefix));
/* 499 */     processors.add(new StandardValueTagProcessor(dialectPrefix));
/* 500 */     processors.add(new StandardWithTagProcessor(TemplateMode.HTML, dialectPrefix));
/* 501 */     processors.add(new StandardXmlBaseTagProcessor(dialectPrefix));
/* 502 */     processors.add(new StandardXmlLangTagProcessor(dialectPrefix));
/* 503 */     processors.add(new StandardXmlSpaceTagProcessor(dialectPrefix));
/* 504 */     processors.add(new StandardXmlNsTagProcessor(TemplateMode.HTML, dialectPrefix));
/* 505 */     processors.add(new StandardRefAttributeTagProcessor(TemplateMode.HTML, dialectPrefix));
/* 506 */     processors.add(new StandardDefaultAttributesTagProcessor(TemplateMode.HTML, dialectPrefix));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 511 */     processors.add(new StandardBlockTagProcessor(TemplateMode.HTML, dialectPrefix, "block"));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 522 */     processors.add(new StandardInliningTextProcessor(TemplateMode.HTML));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 530 */     processors.add(new StandardInliningCDATASectionProcessor(TemplateMode.HTML));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 535 */     processors.add(new StandardTranslationDocTypeProcessor());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 543 */     processors.add(new StandardInliningCommentProcessor(TemplateMode.HTML));
/* 544 */     processors.add(new StandardConditionalCommentProcessor());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 549 */     processors.add(new StandardInlineEnablementTemplateBoundariesProcessor(TemplateMode.HTML));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 565 */     processors.add(new StandardAssertTagProcessor(TemplateMode.XML, dialectPrefix));
/* 566 */     processors.add(new StandardAttrTagProcessor(TemplateMode.XML, dialectPrefix));
/* 567 */     processors.add(new StandardAttrappendTagProcessor(TemplateMode.XML, dialectPrefix));
/* 568 */     processors.add(new StandardAttrprependTagProcessor(TemplateMode.XML, dialectPrefix));
/* 569 */     processors.add(new StandardCaseTagProcessor(TemplateMode.XML, dialectPrefix));
/* 570 */     processors.add(new StandardEachTagProcessor(TemplateMode.XML, dialectPrefix));
/* 571 */     processors.add(new StandardFragmentTagProcessor(TemplateMode.XML, dialectPrefix));
/* 572 */     processors.add(new StandardIfTagProcessor(TemplateMode.XML, dialectPrefix));
/* 573 */     processors.add(new StandardIncludeTagProcessor(TemplateMode.XML, dialectPrefix));
/* 574 */     processors.add(new StandardInlineXMLTagProcessor(dialectPrefix));
/* 575 */     processors.add(new StandardInsertTagProcessor(TemplateMode.XML, dialectPrefix));
/* 576 */     processors.add(new StandardObjectTagProcessor(TemplateMode.XML, dialectPrefix));
/* 577 */     processors.add(new StandardRemoveTagProcessor(TemplateMode.XML, dialectPrefix));
/* 578 */     processors.add(new StandardReplaceTagProcessor(TemplateMode.XML, dialectPrefix));
/* 579 */     processors.add(new StandardSubstituteByTagProcessor(TemplateMode.XML, dialectPrefix));
/* 580 */     processors.add(new StandardSwitchTagProcessor(TemplateMode.XML, dialectPrefix));
/* 581 */     processors.add(new StandardTextTagProcessor(TemplateMode.XML, dialectPrefix));
/* 582 */     processors.add(new StandardUnlessTagProcessor(TemplateMode.XML, dialectPrefix));
/* 583 */     processors.add(new StandardUtextTagProcessor(TemplateMode.XML, dialectPrefix));
/* 584 */     processors.add(new StandardWithTagProcessor(TemplateMode.XML, dialectPrefix));
/* 585 */     processors.add(new StandardXmlNsTagProcessor(TemplateMode.XML, dialectPrefix));
/* 586 */     processors.add(new StandardRefAttributeTagProcessor(TemplateMode.XML, dialectPrefix));
/* 587 */     processors.add(new StandardDefaultAttributesTagProcessor(TemplateMode.XML, dialectPrefix));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 592 */     processors.add(new StandardBlockTagProcessor(TemplateMode.XML, dialectPrefix, "block"));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 603 */     processors.add(new StandardInliningTextProcessor(TemplateMode.XML));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 611 */     processors.add(new StandardInliningCDATASectionProcessor(TemplateMode.XML));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 619 */     processors.add(new StandardInliningCommentProcessor(TemplateMode.XML));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 624 */     processors.add(new StandardInlineEnablementTemplateBoundariesProcessor(TemplateMode.XML));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 640 */     processors.add(new StandardAssertTagProcessor(TemplateMode.TEXT, dialectPrefix));
/* 641 */     processors.add(new StandardCaseTagProcessor(TemplateMode.TEXT, dialectPrefix));
/* 642 */     processors.add(new StandardEachTagProcessor(TemplateMode.TEXT, dialectPrefix));
/*     */     
/* 644 */     processors.add(new StandardIfTagProcessor(TemplateMode.TEXT, dialectPrefix));
/*     */     
/* 646 */     processors.add(new StandardInlineTextualTagProcessor(TemplateMode.TEXT, dialectPrefix));
/* 647 */     processors.add(new StandardInsertTagProcessor(TemplateMode.TEXT, dialectPrefix));
/* 648 */     processors.add(new StandardObjectTagProcessor(TemplateMode.TEXT, dialectPrefix));
/* 649 */     processors.add(new StandardRemoveTagProcessor(TemplateMode.TEXT, dialectPrefix));
/* 650 */     processors.add(new StandardReplaceTagProcessor(TemplateMode.TEXT, dialectPrefix));
/*     */     
/* 652 */     processors.add(new StandardSwitchTagProcessor(TemplateMode.TEXT, dialectPrefix));
/* 653 */     processors.add(new StandardTextTagProcessor(TemplateMode.TEXT, dialectPrefix));
/* 654 */     processors.add(new StandardUnlessTagProcessor(TemplateMode.TEXT, dialectPrefix));
/* 655 */     processors.add(new StandardUtextTagProcessor(TemplateMode.TEXT, dialectPrefix));
/* 656 */     processors.add(new StandardWithTagProcessor(TemplateMode.TEXT, dialectPrefix));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 661 */     processors.add(new StandardBlockTagProcessor(TemplateMode.TEXT, dialectPrefix, "block"));
/* 662 */     processors.add(new StandardBlockTagProcessor(TemplateMode.TEXT, null, ""));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 672 */     processors.add(new StandardInliningTextProcessor(TemplateMode.TEXT));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 677 */     processors.add(new StandardInlineEnablementTemplateBoundariesProcessor(TemplateMode.TEXT));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 693 */     processors.add(new StandardAssertTagProcessor(TemplateMode.JAVASCRIPT, dialectPrefix));
/* 694 */     processors.add(new StandardCaseTagProcessor(TemplateMode.JAVASCRIPT, dialectPrefix));
/* 695 */     processors.add(new StandardEachTagProcessor(TemplateMode.JAVASCRIPT, dialectPrefix));
/*     */     
/* 697 */     processors.add(new StandardIfTagProcessor(TemplateMode.JAVASCRIPT, dialectPrefix));
/*     */     
/* 699 */     processors.add(new StandardInlineTextualTagProcessor(TemplateMode.JAVASCRIPT, dialectPrefix));
/* 700 */     processors.add(new StandardInsertTagProcessor(TemplateMode.JAVASCRIPT, dialectPrefix));
/* 701 */     processors.add(new StandardObjectTagProcessor(TemplateMode.JAVASCRIPT, dialectPrefix));
/* 702 */     processors.add(new StandardRemoveTagProcessor(TemplateMode.JAVASCRIPT, dialectPrefix));
/* 703 */     processors.add(new StandardReplaceTagProcessor(TemplateMode.JAVASCRIPT, dialectPrefix));
/*     */     
/* 705 */     processors.add(new StandardSwitchTagProcessor(TemplateMode.JAVASCRIPT, dialectPrefix));
/* 706 */     processors.add(new StandardTextTagProcessor(TemplateMode.JAVASCRIPT, dialectPrefix));
/* 707 */     processors.add(new StandardUnlessTagProcessor(TemplateMode.JAVASCRIPT, dialectPrefix));
/* 708 */     processors.add(new StandardUtextTagProcessor(TemplateMode.JAVASCRIPT, dialectPrefix));
/* 709 */     processors.add(new StandardWithTagProcessor(TemplateMode.JAVASCRIPT, dialectPrefix));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 714 */     processors.add(new StandardBlockTagProcessor(TemplateMode.JAVASCRIPT, dialectPrefix, "block"));
/* 715 */     processors.add(new StandardBlockTagProcessor(TemplateMode.JAVASCRIPT, null, ""));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 725 */     processors.add(new StandardInliningTextProcessor(TemplateMode.JAVASCRIPT));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 730 */     processors.add(new StandardInlineEnablementTemplateBoundariesProcessor(TemplateMode.JAVASCRIPT));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 746 */     processors.add(new StandardAssertTagProcessor(TemplateMode.CSS, dialectPrefix));
/* 747 */     processors.add(new StandardCaseTagProcessor(TemplateMode.CSS, dialectPrefix));
/* 748 */     processors.add(new StandardEachTagProcessor(TemplateMode.CSS, dialectPrefix));
/*     */     
/* 750 */     processors.add(new StandardIfTagProcessor(TemplateMode.CSS, dialectPrefix));
/*     */     
/* 752 */     processors.add(new StandardInlineTextualTagProcessor(TemplateMode.CSS, dialectPrefix));
/* 753 */     processors.add(new StandardInsertTagProcessor(TemplateMode.CSS, dialectPrefix));
/* 754 */     processors.add(new StandardObjectTagProcessor(TemplateMode.CSS, dialectPrefix));
/* 755 */     processors.add(new StandardRemoveTagProcessor(TemplateMode.CSS, dialectPrefix));
/* 756 */     processors.add(new StandardReplaceTagProcessor(TemplateMode.CSS, dialectPrefix));
/*     */     
/* 758 */     processors.add(new StandardSwitchTagProcessor(TemplateMode.CSS, dialectPrefix));
/* 759 */     processors.add(new StandardTextTagProcessor(TemplateMode.CSS, dialectPrefix));
/* 760 */     processors.add(new StandardUnlessTagProcessor(TemplateMode.CSS, dialectPrefix));
/* 761 */     processors.add(new StandardUtextTagProcessor(TemplateMode.CSS, dialectPrefix));
/* 762 */     processors.add(new StandardWithTagProcessor(TemplateMode.CSS, dialectPrefix));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 767 */     processors.add(new StandardBlockTagProcessor(TemplateMode.CSS, dialectPrefix, "block"));
/* 768 */     processors.add(new StandardBlockTagProcessor(TemplateMode.CSS, null, ""));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 778 */     processors.add(new StandardInliningTextProcessor(TemplateMode.CSS));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 783 */     processors.add(new StandardInlineEnablementTemplateBoundariesProcessor(TemplateMode.CSS));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 798 */     return processors;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\StandardDialect.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */