/*     */ package org.thymeleaf.standard.expression;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.util.StringUtils;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BinaryOperationExpression
/*     */   extends ComplexExpression
/*     */ {
/*     */   private static final long serialVersionUID = 7524261639178859585L;
/*     */   private final IStandardExpression left;
/*     */   private final IStandardExpression right;
/*     */   
/*     */   protected BinaryOperationExpression(IStandardExpression left, IStandardExpression right)
/*     */   {
/*  50 */     Validate.notNull(left, "Left-side expression cannot be null");
/*  51 */     Validate.notNull(right, "Right-side expression cannot be null");
/*  52 */     this.left = left;
/*  53 */     this.right = right;
/*     */   }
/*     */   
/*     */   public IStandardExpression getLeft() {
/*  57 */     return this.left;
/*     */   }
/*     */   
/*     */   public IStandardExpression getRight() {
/*  61 */     return this.right;
/*     */   }
/*     */   
/*     */ 
/*     */   protected String getStringRepresentation(String operator)
/*     */   {
/*  67 */     StringBuilder sb = new StringBuilder();
/*  68 */     if ((this.left instanceof ComplexExpression)) {
/*  69 */       sb.append('(');
/*  70 */       sb.append(this.left);
/*  71 */       sb.append(')');
/*     */     } else {
/*  73 */       sb.append(this.left);
/*     */     }
/*  75 */     sb.append(' ');
/*  76 */     sb.append(operator);
/*  77 */     sb.append(' ');
/*  78 */     if ((this.right instanceof ComplexExpression)) {
/*  79 */       sb.append('(');
/*  80 */       sb.append(this.right);
/*  81 */       sb.append(')');
/*     */     } else {
/*  83 */       sb.append(this.right);
/*     */     }
/*  85 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static ExpressionParsingState composeBinaryOperationExpression(ExpressionParsingState state, int nodeIndex, String[] operators, boolean[] leniencies, Class<? extends BinaryOperationExpression>[] operationClasses, Method leftAllowedMethod, Method rightAllowedMethod)
/*     */   {
/* 104 */     String input = ((ExpressionParsingNode)state.get(nodeIndex)).getInput();
/*     */     
/* 106 */     if (StringUtils.isEmptyOrWhitespace(input)) {
/* 107 */       return null;
/*     */     }
/*     */     
/* 110 */     String scannedInput = input.toLowerCase();
/*     */     
/*     */     for (;;)
/*     */     {
/* 114 */       int operatorIndex = -1;
/* 115 */       int operatorPosFrom = -1;
/* 116 */       int operatorPosTo = Integer.MAX_VALUE;
/* 117 */       int operatorLen = 0;
/*     */       
/* 119 */       for (int i = 0; i < operators.length; i++)
/*     */       {
/* 121 */         int currentOperatorPosFrom = scannedInput.lastIndexOf(operators[i]);
/* 122 */         if (currentOperatorPosFrom != -1) {
/* 123 */           int currentOperatorLen = operators[i].length();
/* 124 */           int currentOperatorPosTo = currentOperatorPosFrom + currentOperatorLen;
/* 125 */           if ((operatorPosFrom == -1) || (operatorPosTo < currentOperatorPosFrom) || ((currentOperatorLen > operatorLen) && (currentOperatorPosTo >= operatorPosTo)))
/*     */           {
/*     */ 
/* 128 */             operatorPosFrom = currentOperatorPosFrom;
/* 129 */             operatorLen = operators[i].length();
/* 130 */             operatorPosTo = currentOperatorPosFrom + operatorLen;
/* 131 */             operatorIndex = i;
/*     */           }
/*     */         }
/*     */       }
/* 135 */       if (operatorPosFrom == -1) {
/* 136 */         return state;
/*     */       }
/*     */       
/* 139 */       if (doComposeBinaryOperationExpression(state, nodeIndex, operators[operatorIndex], operationClasses[operatorIndex], leftAllowedMethod, rightAllowedMethod, input, operatorPosFrom) == null)
/*     */       {
/*     */ 
/*     */ 
/* 143 */         if (leniencies[operatorIndex] != 0) {
/* 144 */           scannedInput = scannedInput.substring(0, operatorPosFrom);
/*     */         } else {
/* 146 */           return null;
/*     */         }
/*     */       }
/*     */       else {
/* 150 */         return state;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static ExpressionParsingState doComposeBinaryOperationExpression(ExpressionParsingState state, int nodeIndex, String operator, Class<? extends BinaryOperationExpression> operationClass, Method leftAllowedMethod, Method rightAllowedMethod, String input, int operatorPos)
/*     */   {
/* 169 */     String leftStr = input.substring(0, operatorPos).trim();
/* 170 */     String rightStr = input.substring(operatorPos + operator.length()).trim();
/*     */     
/* 172 */     if ((leftStr.length() == 0) || (rightStr.length() == 0)) {
/* 173 */       return null;
/*     */     }
/*     */     
/* 176 */     Expression leftExpr = ExpressionParsingUtil.parseAndCompose(state, leftStr);
/*     */     try {
/* 178 */       if (leftExpr != null) { if (((Boolean)leftAllowedMethod.invoke(null, new Object[] { leftExpr })).booleanValue()) {}
/* 179 */       } else return null;
/*     */     }
/*     */     catch (IllegalAccessException e)
/*     */     {
/* 183 */       throw new TemplateProcessingException("Error invoking operand validation in binary operation", e);
/*     */     }
/*     */     catch (InvocationTargetException e) {
/* 186 */       throw new TemplateProcessingException("Error invoking operand validation in binary operation", e);
/*     */     }
/*     */     
/* 189 */     Expression rightExpr = ExpressionParsingUtil.parseAndCompose(state, rightStr);
/*     */     try {
/* 191 */       if (rightExpr != null) { if (((Boolean)rightAllowedMethod.invoke(null, new Object[] { rightExpr })).booleanValue()) {}
/* 192 */       } else return null;
/*     */     }
/*     */     catch (IllegalAccessException e)
/*     */     {
/* 196 */       throw new TemplateProcessingException("Error invoking operand validation in binary operation", e);
/*     */     }
/*     */     catch (InvocationTargetException e) {
/* 199 */       throw new TemplateProcessingException("Error invoking operand validation in binary operation", e);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 206 */       BinaryOperationExpression operationExpression = (BinaryOperationExpression)operationClass.getDeclaredConstructor(new Class[] { IStandardExpression.class, IStandardExpression.class }).newInstance(new Object[] { leftExpr, rightExpr });
/* 207 */       state.setNode(nodeIndex, operationExpression);
/*     */     }
/*     */     catch (TemplateProcessingException e) {
/* 210 */       throw e;
/*     */     } catch (Exception e) {
/* 212 */       throw new TemplateProcessingException("Error during creation of Binary Operation expression for operator: \"" + operator + "\"", e);
/*     */     }
/*     */     
/*     */ 
/* 216 */     return state;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\expression\BinaryOperationExpression.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */