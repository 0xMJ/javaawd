/*     */ package org.thymeleaf.standard.expression;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.thymeleaf.IEngineConfiguration;
/*     */ import org.thymeleaf.context.IExpressionContext;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.util.StringUtils;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ExpressionSequenceUtils
/*     */ {
/*     */   public static ExpressionSequence parseExpressionSequence(IExpressionContext context, String input)
/*     */   {
/*  47 */     Validate.notNull(context, "Context cannot be null");
/*  48 */     Validate.notNull(input, "Input cannot be null");
/*     */     
/*     */ 
/*  51 */     String preprocessedInput = StandardExpressionPreprocessor.preprocess(context, input);
/*     */     
/*  53 */     IEngineConfiguration configuration = context.getConfiguration();
/*     */     
/*  55 */     if (configuration != null)
/*     */     {
/*  57 */       ExpressionSequence cachedExpressionSequence = ExpressionCache.getExpressionSequenceFromCache(configuration, preprocessedInput);
/*  58 */       if (cachedExpressionSequence != null) {
/*  59 */         return cachedExpressionSequence;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*  64 */     ExpressionSequence expressionSequence = internalParseExpressionSequence(preprocessedInput.trim());
/*     */     
/*  66 */     if (expressionSequence == null) {
/*  67 */       throw new TemplateProcessingException("Could not parse as expression sequence: \"" + input + "\"");
/*     */     }
/*     */     
/*  70 */     if (configuration != null) {
/*  71 */       ExpressionCache.putExpressionSequenceIntoCache(configuration, preprocessedInput, expressionSequence);
/*     */     }
/*     */     
/*  74 */     return expressionSequence;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static ExpressionSequence internalParseExpressionSequence(String input)
/*     */   {
/*  82 */     if (StringUtils.isEmptyOrWhitespace(input)) {
/*  83 */       return null;
/*     */     }
/*     */     
/*  86 */     ExpressionParsingState decomposition = ExpressionParsingUtil.decompose(input);
/*     */     
/*  88 */     if (decomposition == null) {
/*  89 */       return null;
/*     */     }
/*     */     
/*  92 */     return composeSequence(decomposition, 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static ExpressionSequence composeSequence(ExpressionParsingState state, int nodeIndex)
/*     */   {
/* 101 */     if ((state == null) || (nodeIndex >= state.size())) {
/* 102 */       return null;
/*     */     }
/*     */     
/* 105 */     if (state.hasExpressionAt(nodeIndex))
/*     */     {
/*     */ 
/* 108 */       List<IStandardExpression> expressions = new ArrayList(2);
/* 109 */       expressions.add(((ExpressionParsingNode)state.get(nodeIndex)).getExpression());
/* 110 */       return new ExpressionSequence(expressions);
/*     */     }
/*     */     
/* 113 */     String input = ((ExpressionParsingNode)state.get(nodeIndex)).getInput();
/*     */     
/* 115 */     if (StringUtils.isEmptyOrWhitespace(input)) {
/* 116 */       return null;
/*     */     }
/*     */     
/*     */ 
/* 120 */     int pointer = ExpressionParsingUtil.parseAsSimpleIndexPlaceholder(input);
/* 121 */     if (pointer != -1) {
/* 122 */       return composeSequence(state, pointer);
/*     */     }
/*     */     
/* 125 */     String[] inputParts = StringUtils.split(input, ",");
/*     */     
/* 127 */     List<IStandardExpression> expressions = new ArrayList(4);
/* 128 */     for (String inputPart : inputParts) {
/* 129 */       Expression expression = ExpressionParsingUtil.parseAndCompose(state, inputPart);
/* 130 */       if (expression == null) {
/* 131 */         return null;
/*     */       }
/* 133 */       expressions.add(expression);
/*     */     }
/*     */     
/* 136 */     return new ExpressionSequence(expressions);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\expression\ExpressionSequenceUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */