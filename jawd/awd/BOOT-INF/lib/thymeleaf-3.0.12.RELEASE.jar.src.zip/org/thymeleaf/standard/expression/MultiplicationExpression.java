/*    */ package org.thymeleaf.standard.expression;
/*    */ 
/*    */ import java.math.BigDecimal;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ import org.thymeleaf.TemplateEngine;
/*    */ import org.thymeleaf.context.IExpressionContext;
/*    */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*    */ import org.thymeleaf.util.EvaluationUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class MultiplicationExpression
/*    */   extends MultiplicationDivisionRemainderExpression
/*    */ {
/*    */   private static final long serialVersionUID = 4822815123712162053L;
/* 52 */   private static final Logger logger = LoggerFactory.getLogger(MultiplicationExpression.class);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public MultiplicationExpression(IStandardExpression left, IStandardExpression right)
/*    */   {
/* 59 */     super(left, right);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public String getStringRepresentation()
/*    */   {
/* 66 */     return getStringRepresentation("*");
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   static Object executeMultiplication(IExpressionContext context, MultiplicationExpression expression, StandardExpressionExecutionContext expContext)
/*    */   {
/* 76 */     if (logger.isTraceEnabled()) {
/* 77 */       logger.trace("[THYMELEAF][{}] Evaluating multiplication expression: \"{}\"", TemplateEngine.threadIndex(), expression.getStringRepresentation());
/*    */     }
/*    */     
/* 80 */     Object leftValue = expression.getLeft().execute(context, expContext);
/* 81 */     Object rightValue = expression.getRight().execute(context, expContext);
/*    */     
/* 83 */     if (leftValue == null) {
/* 84 */       leftValue = "null";
/*    */     }
/* 86 */     if (rightValue == null) {
/* 87 */       rightValue = "null";
/*    */     }
/*    */     
/* 90 */     BigDecimal leftNumberValue = EvaluationUtils.evaluateAsNumber(leftValue);
/* 91 */     BigDecimal rightNumberValue = EvaluationUtils.evaluateAsNumber(rightValue);
/* 92 */     if ((leftNumberValue != null) && (rightNumberValue != null))
/*    */     {
/* 94 */       return leftNumberValue.multiply(rightNumberValue);
/*    */     }
/*    */     
/*    */ 
/* 98 */     throw new TemplateProcessingException("Cannot execute multiplication: operands are \"" + LiteralValue.unwrap(leftValue) + "\" and \"" + LiteralValue.unwrap(rightValue) + "\"");
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\expression\MultiplicationExpression.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */