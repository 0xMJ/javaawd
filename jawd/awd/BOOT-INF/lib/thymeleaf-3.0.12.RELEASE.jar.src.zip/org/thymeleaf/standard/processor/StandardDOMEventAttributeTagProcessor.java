/*     */ package org.thymeleaf.standard.processor;
/*     */ 
/*     */ import java.io.Writer;
/*     */ import org.thymeleaf.IEngineConfiguration;
/*     */ import org.thymeleaf.context.ITemplateContext;
/*     */ import org.thymeleaf.engine.AttributeDefinition;
/*     */ import org.thymeleaf.engine.AttributeDefinitions;
/*     */ import org.thymeleaf.engine.AttributeName;
/*     */ import org.thymeleaf.engine.EngineEventUtils;
/*     */ import org.thymeleaf.engine.IAttributeDefinitionsAware;
/*     */ import org.thymeleaf.engine.TemplateManager;
/*     */ import org.thymeleaf.engine.TemplateModel;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.model.IAttribute;
/*     */ import org.thymeleaf.model.IProcessableElementTag;
/*     */ import org.thymeleaf.processor.element.AbstractAttributeTagProcessor;
/*     */ import org.thymeleaf.processor.element.IElementTagStructureHandler;
/*     */ import org.thymeleaf.standard.expression.IStandardExpression;
/*     */ import org.thymeleaf.standard.expression.NoOpToken;
/*     */ import org.thymeleaf.standard.expression.StandardExpressionExecutionContext;
/*     */ import org.thymeleaf.standard.util.StandardProcessorUtils;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ import org.thymeleaf.util.EscapedAttributeUtils;
/*     */ import org.thymeleaf.util.FastStringWriter;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class StandardDOMEventAttributeTagProcessor
/*     */   extends AbstractAttributeTagProcessor
/*     */   implements IAttributeDefinitionsAware
/*     */ {
/*     */   public static final int PRECEDENCE = 1000;
/*  62 */   public static final String[] ATTR_NAMES = { "onabort", "onafterprint", "onbeforeprint", "onbeforeunload", "onblur", "oncanplay", "oncanplaythrough", "onchange", "onclick", "oncontextmenu", "ondblclick", "ondrag", "ondragend", "ondragenter", "ondragleave", "ondragover", "ondragstart", "ondrop", "ondurationchange", "onemptied", "onended", "onerror", "onfocus", "onformchange", "onforminput", "onhashchange", "oninput", "oninvalid", "onkeydown", "onkeypress", "onkeyup", "onload", "onloadeddata", "onloadedmetadata", "onloadstart", "onmessage", "onmousedown", "onmousemove", "onmouseout", "onmouseover", "onmouseup", "onmousewheel", "onoffline", "ononline", "onpause", "onplay", "onplaying", "onpopstate", "onprogress", "onratechange", "onreadystatechange", "onredo", "onreset", "onresize", "onscroll", "onseeked", "onseeking", "onselect", "onshow", "onstalled", "onstorage", "onsubmit", "onsuspend", "ontimeupdate", "onundo", "onunload", "onvolumechange", "onwaiting" };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final String targetAttrCompleteName;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private AttributeDefinition targetAttributeDefinition;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public StandardDOMEventAttributeTagProcessor(String dialectPrefix, String attrName)
/*     */   {
/* 144 */     super(TemplateMode.HTML, dialectPrefix, null, false, attrName, true, 1000, false);
/*     */     
/* 146 */     Validate.notNull(attrName, "Complete name of target attribute cannot be null");
/*     */     
/* 148 */     this.targetAttrCompleteName = attrName;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setAttributeDefinitions(AttributeDefinitions attributeDefinitions)
/*     */   {
/* 154 */     Validate.notNull(attributeDefinitions, "Attribute Definitions cannot be null");
/*     */     
/*     */ 
/* 157 */     this.targetAttributeDefinition = attributeDefinitions.forName(getTemplateMode(), this.targetAttrCompleteName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void doProcess(ITemplateContext context, IProcessableElementTag tag, AttributeName attributeName, String attributeValue, Object expressionResult, IElementTagStructureHandler structureHandler)
/*     */   {
/* 170 */     String newAttributeValue = EscapedAttributeUtils.escapeAttribute(getTemplateMode(), expressionResult == null ? null : expressionResult.toString());
/*     */     
/*     */ 
/* 173 */     if ((newAttributeValue == null) || (newAttributeValue.length() == 0))
/*     */     {
/*     */ 
/* 176 */       structureHandler.removeAttribute(this.targetAttributeDefinition.getAttributeName());
/* 177 */       structureHandler.removeAttribute(attributeName);
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 182 */       StandardProcessorUtils.replaceAttribute(structureHandler, attributeName, this.targetAttributeDefinition, this.targetAttrCompleteName, 
/* 183 */         newAttributeValue == null ? "" : newAttributeValue);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void doProcess(ITemplateContext context, IProcessableElementTag tag, AttributeName attributeName, String attributeValue, IElementTagStructureHandler structureHandler)
/*     */   {
/*     */     Object expressionResult;
/*     */     
/*     */ 
/*     */     Object expressionResult;
/*     */     
/*     */ 
/* 198 */     if (attributeValue != null)
/*     */     {
/* 200 */       IStandardExpression expression = null;
/*     */       try {
/* 202 */         expression = EngineEventUtils.computeAttributeExpression(context, tag, attributeName, attributeValue);
/*     */       }
/*     */       catch (TemplateProcessingException localTemplateProcessingException) {}
/*     */       
/*     */ 
/*     */       Object expressionResult;
/*     */       
/* 209 */       if (expression != null)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 214 */         expressionResult = expression.execute(context, StandardExpressionExecutionContext.RESTRICTED_FORBID_UNSAFE_EXP_RESULTS);
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/*     */ 
/* 220 */         IAttribute attribute = tag.getAttribute(attributeName);
/* 221 */         TemplateManager templateManager = context.getConfiguration().getTemplateManager();
/*     */         
/*     */ 
/* 224 */         TemplateModel templateModel = templateManager.parseString(context
/* 225 */           .getTemplateData(), attributeValue, attribute
/* 226 */           .getLine(), attribute.getCol(), TemplateMode.JAVASCRIPT, true);
/*     */         
/*     */ 
/* 229 */         Writer stringWriter = new FastStringWriter(50);
/* 230 */         templateManager.process(templateModel, context, stringWriter);
/*     */         
/* 232 */         expressionResult = stringWriter.toString();
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 237 */       expressionResult = null;
/*     */     }
/*     */     
/*     */ 
/* 241 */     if (expressionResult == NoOpToken.VALUE) {
/* 242 */       structureHandler.removeAttribute(attributeName);
/* 243 */       return;
/*     */     }
/*     */     
/* 246 */     doProcess(context, tag, attributeName, attributeValue, expressionResult, structureHandler);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\processor\StandardDOMEventAttributeTagProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */