/*    */ package org.thymeleaf.standard.inline;
/*    */ 
/*    */ import java.io.Writer;
/*    */ import org.thymeleaf.IEngineConfiguration;
/*    */ import org.thymeleaf.standard.serializer.IStandardCSSSerializer;
/*    */ import org.thymeleaf.standard.serializer.StandardSerializers;
/*    */ import org.thymeleaf.templatemode.TemplateMode;
/*    */ import org.thymeleaf.util.FastStringWriter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class StandardCSSInliner
/*    */   extends AbstractStandardInliner
/*    */ {
/*    */   private final IStandardCSSSerializer serializer;
/*    */   
/*    */   public StandardCSSInliner(IEngineConfiguration configuration)
/*    */   {
/* 42 */     super(configuration, TemplateMode.CSS);
/* 43 */     this.serializer = StandardSerializers.getCSSSerializer(configuration);
/*    */   }
/*    */   
/*    */ 
/*    */   protected String produceEscapedOutput(Object input)
/*    */   {
/* 49 */     Writer cssWriter = new FastStringWriter((input instanceof String) ? ((String)input).length() * 2 : 20);
/* 50 */     this.serializer.serializeValue(input, cssWriter);
/* 51 */     return cssWriter.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\inline\StandardCSSInliner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */