/*     */ package org.thymeleaf.standard.expression;
/*     */ 
/*     */ import org.thymeleaf.IEngineConfiguration;
/*     */ import org.thymeleaf.context.IExpressionContext;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.util.StringUtils;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class EachUtils
/*     */ {
/*     */   private static final String OPERATOR = ":";
/*     */   private static final String STAT_SEPARATOR = ",";
/*     */   
/*     */   public static Each parseEach(IExpressionContext context, String input)
/*     */   {
/*  50 */     Validate.notNull(context, "Context cannot be null");
/*  51 */     Validate.notNull(input, "Input cannot be null");
/*     */     
/*     */ 
/*  54 */     String preprocessedInput = StandardExpressionPreprocessor.preprocess(context, input);
/*     */     
/*  56 */     IEngineConfiguration configuration = context.getConfiguration();
/*     */     
/*  58 */     if (configuration != null) {
/*  59 */       Each cachedEach = ExpressionCache.getEachFromCache(configuration, preprocessedInput);
/*  60 */       if (cachedEach != null) {
/*  61 */         return cachedEach;
/*     */       }
/*     */     }
/*     */     
/*  65 */     Each each = internalParseEach(preprocessedInput.trim());
/*     */     
/*  67 */     if (each == null) {
/*  68 */       throw new TemplateProcessingException("Could not parse as each: \"" + input + "\"");
/*     */     }
/*     */     
/*  71 */     if (configuration != null) {
/*  72 */       ExpressionCache.putEachIntoCache(configuration, preprocessedInput, each);
/*     */     }
/*     */     
/*  75 */     return each;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static Each internalParseEach(String input)
/*     */   {
/*  84 */     if (StringUtils.isEmptyOrWhitespace(input)) {
/*  85 */       return null;
/*     */     }
/*     */     
/*  88 */     ExpressionParsingState decomposition = ExpressionParsingUtil.decompose(input);
/*     */     
/*  90 */     if (decomposition == null) {
/*  91 */       return null;
/*     */     }
/*     */     
/*  94 */     return composeEach(decomposition, 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Each composeEach(ExpressionParsingState state, int nodeIndex)
/*     */   {
/* 103 */     if ((state == null) || (nodeIndex >= state.size())) {
/* 104 */       return null;
/*     */     }
/*     */     
/* 107 */     if (state.hasExpressionAt(nodeIndex))
/*     */     {
/* 109 */       return null;
/*     */     }
/*     */     
/* 112 */     String input = ((ExpressionParsingNode)state.get(nodeIndex)).getInput();
/*     */     
/* 114 */     if (StringUtils.isEmptyOrWhitespace(input)) {
/* 115 */       return null;
/*     */     }
/*     */     
/*     */ 
/* 119 */     int pointer = ExpressionParsingUtil.parseAsSimpleIndexPlaceholder(input);
/* 120 */     if (pointer != -1) {
/* 121 */       return composeEach(state, pointer);
/*     */     }
/*     */     
/* 124 */     int inputLen = input.length();
/*     */     
/* 126 */     int operatorLen = ":".length();
/* 127 */     int operatorPos = input.indexOf(":");
/* 128 */     if ((operatorPos == -1) || (operatorPos == 0) || (operatorPos >= inputLen - operatorLen)) {
/* 129 */       return null;
/*     */     }
/*     */     
/* 132 */     String left = input.substring(0, operatorPos).trim();
/* 133 */     String iterableStr = input.substring(operatorPos + operatorLen).trim();
/*     */     
/* 135 */     int statPos = left.indexOf(",");
/*     */     String statusVarStr;
/*     */     String iterVarStr;
/* 138 */     String statusVarStr; if (statPos == -1) {
/* 139 */       String iterVarStr = left;
/* 140 */       statusVarStr = null;
/*     */     } else {
/* 142 */       if ((statPos == 0) || (statPos >= left.length() - operatorLen)) {
/* 143 */         return null;
/*     */       }
/* 145 */       iterVarStr = left.substring(0, statPos);
/* 146 */       statusVarStr = left.substring(statPos + operatorLen);
/*     */     }
/*     */     
/* 149 */     Expression iterVarExpr = ExpressionParsingUtil.parseAndCompose(state, iterVarStr);
/* 150 */     if (iterVarStr == null) {
/* 151 */       return null;
/*     */     }
/*     */     
/*     */     Expression statusVarExpr;
/* 155 */     if (statusVarStr != null) {
/* 156 */       Expression statusVarExpr = ExpressionParsingUtil.parseAndCompose(state, statusVarStr);
/* 157 */       if (statusVarExpr == null) {
/* 158 */         return null;
/*     */       }
/*     */     } else {
/* 161 */       statusVarExpr = null;
/*     */     }
/*     */     
/* 164 */     Expression iterableExpr = ExpressionParsingUtil.parseAndCompose(state, iterableStr);
/* 165 */     if (iterableExpr == null) {
/* 166 */       return null;
/*     */     }
/*     */     
/* 169 */     return new Each(iterVarExpr, statusVarExpr, iterableExpr);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\expression\EachUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */