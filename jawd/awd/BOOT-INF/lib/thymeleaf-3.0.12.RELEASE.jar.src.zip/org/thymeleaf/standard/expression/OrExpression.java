/*     */ package org.thymeleaf.standard.expression;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.thymeleaf.TemplateEngine;
/*     */ import org.thymeleaf.context.IExpressionContext;
/*     */ import org.thymeleaf.util.EvaluationUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class OrExpression
/*     */   extends BinaryOperationExpression
/*     */ {
/*     */   private static final long serialVersionUID = -8085738202412415337L;
/*  50 */   private static final Logger logger = LoggerFactory.getLogger(OrExpression.class);
/*     */   
/*     */   private static final String OPERATOR = "or";
/*  53 */   static final String[] OPERATORS = { "or" };
/*  54 */   private static final boolean[] LENIENCIES = { false };
/*     */   
/*  56 */   private static final Class<? extends BinaryOperationExpression>[] OPERATOR_CLASSES = { OrExpression.class };
/*     */   
/*     */   private static final Method LEFT_ALLOWED_METHOD;
/*     */   private static final Method RIGHT_ALLOWED_METHOD;
/*     */   
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  65 */       LEFT_ALLOWED_METHOD = OrExpression.class.getDeclaredMethod("isLeftAllowed", new Class[] { IStandardExpression.class });
/*  66 */       RIGHT_ALLOWED_METHOD = OrExpression.class.getDeclaredMethod("isRightAllowed", new Class[] { IStandardExpression.class });
/*     */     } catch (NoSuchMethodException e) {
/*  68 */       throw new ExceptionInInitializerError(e);
/*     */     }
/*     */   }
/*     */   
/*     */   public OrExpression(IStandardExpression left, IStandardExpression right)
/*     */   {
/*  74 */     super(left, right);
/*     */   }
/*     */   
/*     */ 
/*     */   public String getStringRepresentation()
/*     */   {
/*  80 */     return getStringRepresentation("or");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   static boolean isRightAllowed(IStandardExpression right)
/*     */   {
/*  87 */     return (right != null) && ((!(right instanceof Token)) || ((right instanceof BooleanTokenExpression)));
/*     */   }
/*     */   
/*     */   static boolean isLeftAllowed(IStandardExpression left) {
/*  91 */     return (left != null) && ((!(left instanceof Token)) || ((left instanceof BooleanTokenExpression)));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static ExpressionParsingState composeOrExpression(ExpressionParsingState state, int inputIndex)
/*     */   {
/*  99 */     return composeBinaryOperationExpression(state, inputIndex, OPERATORS, LENIENCIES, OPERATOR_CLASSES, LEFT_ALLOWED_METHOD, RIGHT_ALLOWED_METHOD);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static Object executeOr(IExpressionContext context, OrExpression expression, StandardExpressionExecutionContext expContext)
/*     */   {
/* 111 */     if (logger.isTraceEnabled()) {
/* 112 */       logger.trace("[THYMELEAF][{}] Evaluating OR expression: \"{}\"", TemplateEngine.threadIndex(), expression.getStringRepresentation());
/*     */     }
/*     */     
/* 115 */     Object leftValue = expression.getLeft().execute(context, expContext);
/*     */     
/*     */ 
/* 118 */     boolean leftBooleanValue = EvaluationUtils.evaluateAsBoolean(leftValue);
/* 119 */     if (leftBooleanValue) {
/* 120 */       return Boolean.TRUE;
/*     */     }
/*     */     
/* 123 */     Object rightValue = expression.getRight().execute(context, expContext);
/*     */     
/* 125 */     boolean rightBooleanValue = EvaluationUtils.evaluateAsBoolean(rightValue);
/* 126 */     return Boolean.valueOf(rightBooleanValue);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\expression\OrExpression.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */