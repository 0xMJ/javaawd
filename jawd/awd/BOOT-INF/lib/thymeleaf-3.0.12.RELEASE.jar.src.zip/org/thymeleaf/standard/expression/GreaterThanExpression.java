/*     */ package org.thymeleaf.standard.expression;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.thymeleaf.TemplateEngine;
/*     */ import org.thymeleaf.context.IExpressionContext;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.util.EvaluationUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class GreaterThanExpression
/*     */   extends GreaterLesserExpression
/*     */ {
/*     */   private static final long serialVersionUID = -1416343400122380675L;
/*  51 */   private static final Logger logger = LoggerFactory.getLogger(GreaterThanExpression.class);
/*     */   
/*     */   public GreaterThanExpression(IStandardExpression left, IStandardExpression right)
/*     */   {
/*  55 */     super(left, right);
/*     */   }
/*     */   
/*     */ 
/*     */   public String getStringRepresentation()
/*     */   {
/*  61 */     return getStringRepresentation(">");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static Object executeGreaterThan(IExpressionContext context, GreaterThanExpression expression, StandardExpressionExecutionContext expContext)
/*     */   {
/*  73 */     if (logger.isTraceEnabled()) {
/*  74 */       logger.trace("[THYMELEAF][{}] Evaluating GREATER THAN expression: \"{}\"", TemplateEngine.threadIndex(), expression.getStringRepresentation());
/*     */     }
/*     */     
/*  77 */     Object leftValue = expression.getLeft().execute(context, expContext);
/*  78 */     Object rightValue = expression.getRight().execute(context, expContext);
/*     */     
/*  80 */     if ((leftValue == null) || (rightValue == null))
/*     */     {
/*  82 */       throw new TemplateProcessingException("Cannot execute GREATER THAN comparison: operands are \"" + LiteralValue.unwrap(leftValue) + "\" and \"" + LiteralValue.unwrap(rightValue) + "\"");
/*     */     }
/*     */     
/*  85 */     leftValue = LiteralValue.unwrap(leftValue);
/*  86 */     rightValue = LiteralValue.unwrap(rightValue);
/*     */     
/*  88 */     Boolean result = null;
/*     */     
/*  90 */     BigDecimal leftNumberValue = EvaluationUtils.evaluateAsNumber(leftValue);
/*  91 */     BigDecimal rightNumberValue = EvaluationUtils.evaluateAsNumber(rightValue);
/*     */     
/*  93 */     if ((leftNumberValue != null) && (rightNumberValue != null)) {
/*  94 */       result = Boolean.valueOf(leftNumberValue.compareTo(rightNumberValue) == 1);
/*     */     }
/*  96 */     else if ((leftValue != null) && (rightValue != null) && 
/*  97 */       (leftValue.getClass().equals(rightValue.getClass())) && 
/*  98 */       (Comparable.class.isAssignableFrom(leftValue.getClass()))) {
/*  99 */       result = Boolean.valueOf(((Comparable)leftValue).compareTo(rightValue) > 0);
/*     */     }
/*     */     else
/*     */     {
/* 103 */       throw new TemplateProcessingException("Cannot execute GREATER THAN from Expression \"" + expression.getStringRepresentation() + "\". Left is \"" + leftValue + "\", right is \"" + rightValue + "\"");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 108 */     if (logger.isTraceEnabled()) {
/* 109 */       logger.trace("[THYMELEAF][{}] Evaluating GREATER THAN expression: \"{}\". Left is \"{}\", right is \"{}\". Result is \"{}\"", new Object[] {
/* 110 */         TemplateEngine.threadIndex(), expression.getStringRepresentation(), leftValue, rightValue, result });
/*     */     }
/*     */     
/* 113 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\expression\GreaterThanExpression.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */