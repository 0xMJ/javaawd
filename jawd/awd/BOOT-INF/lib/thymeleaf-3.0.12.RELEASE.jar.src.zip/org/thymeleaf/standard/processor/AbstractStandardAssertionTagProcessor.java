/*    */ package org.thymeleaf.standard.processor;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.thymeleaf.context.ITemplateContext;
/*    */ import org.thymeleaf.engine.AttributeName;
/*    */ import org.thymeleaf.exceptions.TemplateAssertionException;
/*    */ import org.thymeleaf.model.IAttribute;
/*    */ import org.thymeleaf.model.IProcessableElementTag;
/*    */ import org.thymeleaf.processor.element.AbstractAttributeTagProcessor;
/*    */ import org.thymeleaf.processor.element.IElementTagStructureHandler;
/*    */ import org.thymeleaf.standard.expression.ExpressionSequence;
/*    */ import org.thymeleaf.standard.expression.ExpressionSequenceUtils;
/*    */ import org.thymeleaf.standard.expression.IStandardExpression;
/*    */ import org.thymeleaf.templatemode.TemplateMode;
/*    */ import org.thymeleaf.util.EvaluationUtils;
/*    */ import org.thymeleaf.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractStandardAssertionTagProcessor
/*    */   extends AbstractAttributeTagProcessor
/*    */ {
/*    */   protected AbstractStandardAssertionTagProcessor(TemplateMode templateMode, String dialectPrefix, String attrName, int precedence)
/*    */   {
/* 50 */     super(templateMode, dialectPrefix, null, false, attrName, true, precedence, true);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected final void doProcess(ITemplateContext context, IProcessableElementTag tag, AttributeName attributeName, String attributeValue, IElementTagStructureHandler structureHandler)
/*    */   {
/* 62 */     if (StringUtils.isEmptyOrWhitespace(attributeValue)) {
/* 63 */       return;
/*    */     }
/*    */     
/*    */ 
/* 67 */     ExpressionSequence expressionSequence = ExpressionSequenceUtils.parseExpressionSequence(context, attributeValue);
/*    */     
/* 69 */     List<IStandardExpression> expressions = expressionSequence.getExpressions();
/*    */     
/* 71 */     for (IStandardExpression expression : expressions) {
/* 72 */       Object expressionResult = expression.execute(context);
/* 73 */       boolean expressionBooleanResult = EvaluationUtils.evaluateAsBoolean(expressionResult);
/* 74 */       if (!expressionBooleanResult)
/*    */       {
/*    */ 
/* 77 */         throw new TemplateAssertionException(expression.getStringRepresentation(), tag.getTemplateName(), tag.getAttribute(attributeName).getLine(), tag.getAttribute(attributeName).getCol());
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\processor\AbstractStandardAssertionTagProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */