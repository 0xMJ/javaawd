/*     */ package org.thymeleaf.standard.expression;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class LiteralSubstitutionUtil
/*     */ {
/*     */   private static final char LITERAL_SUBSTITUTION_DELIMITER = '|';
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static String performLiteralSubstitution(String input)
/*     */   {
/*  64 */     if (input == null) {
/*  65 */       return null;
/*     */     }
/*     */     
/*  68 */     StringBuilder strBuilder = null;
/*     */     
/*  70 */     boolean inLiteralSubstitution = false;
/*  71 */     boolean inLiteralSubstitutionInsertion = false;
/*     */     
/*  73 */     int expLevel = 0;
/*  74 */     boolean inLiteral = false;
/*  75 */     boolean inNothing = true;
/*     */     
/*  77 */     int inputLen = input.length();
/*  78 */     for (int i = 0; i < inputLen; i++)
/*     */     {
/*  80 */       char c = input.charAt(i);
/*     */       
/*  82 */       if ((c == '|') && (!inLiteralSubstitution) && (inNothing))
/*     */       {
/*  84 */         if (strBuilder == null) {
/*  85 */           strBuilder = new StringBuilder(inputLen + 20);
/*  86 */           strBuilder.append(input, 0, i);
/*     */         }
/*  88 */         inLiteralSubstitution = true;
/*     */       }
/*  90 */       else if ((c == '|') && (inLiteralSubstitution) && (inNothing))
/*     */       {
/*  92 */         if (inLiteralSubstitutionInsertion) {
/*  93 */           strBuilder.append('\'');
/*  94 */           inLiteralSubstitutionInsertion = false;
/*     */         }
/*     */         
/*  97 */         inLiteralSubstitution = false;
/*     */       } else {
/*  99 */         if ((inNothing) && ((c == '$') || (c == '*') || (c == '#') || (c == '@')) && (i + 1 < inputLen))
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/* 104 */           if (input.charAt(i + 1) == '{')
/*     */           {
/*     */ 
/* 107 */             if ((inLiteralSubstitution) && (inLiteralSubstitutionInsertion)) {
/* 108 */               strBuilder.append("' + ");
/* 109 */               inLiteralSubstitutionInsertion = false;
/* 110 */             } else if ((inLiteralSubstitution) && (i > 0) && (input.charAt(i - 1) == '}'))
/*     */             {
/* 112 */               strBuilder.append(" + '' + ");
/*     */             }
/*     */             
/* 115 */             if (strBuilder != null) {
/* 116 */               strBuilder.append(c);
/* 117 */               strBuilder.append('{');
/*     */             }
/*     */             
/* 120 */             expLevel = 1;
/* 121 */             i++;
/* 122 */             inNothing = false; continue;
/*     */           } }
/* 124 */         if ((expLevel == 1) && (c == '}'))
/*     */         {
/*     */ 
/* 127 */           if (strBuilder != null) {
/* 128 */             strBuilder.append('}');
/*     */           }
/*     */           
/* 131 */           expLevel = 0;
/* 132 */           inNothing = true;
/*     */         }
/* 134 */         else if ((expLevel > 0) && (c == '{'))
/*     */         {
/*     */ 
/* 137 */           if (strBuilder != null) {
/* 138 */             strBuilder.append('{');
/*     */           }
/* 140 */           expLevel++;
/*     */         }
/* 142 */         else if ((expLevel > 1) && (c == '}'))
/*     */         {
/*     */ 
/* 145 */           if (strBuilder != null) {
/* 146 */             strBuilder.append('}');
/*     */           }
/* 148 */           expLevel--;
/*     */         }
/* 150 */         else if (expLevel > 0)
/*     */         {
/*     */ 
/* 153 */           if (strBuilder != null) {
/* 154 */             strBuilder.append(c);
/*     */           }
/*     */         }
/* 157 */         else if ((inNothing) && (!inLiteralSubstitution) && (c == '\'') && 
/* 158 */           (!TextLiteralExpression.isDelimiterEscaped(input, i)))
/*     */         {
/*     */ 
/* 161 */           inNothing = false;
/* 162 */           inLiteral = true;
/*     */           
/* 164 */           if (strBuilder != null) {
/* 165 */             strBuilder.append(c);
/*     */           }
/*     */         }
/* 168 */         else if ((inLiteral) && (!inLiteralSubstitution) && (c == '\'') && 
/* 169 */           (!TextLiteralExpression.isDelimiterEscaped(input, i)))
/*     */         {
/* 171 */           inLiteral = false;
/* 172 */           inNothing = true;
/*     */           
/* 174 */           if (strBuilder != null) {
/* 175 */             strBuilder.append(c);
/*     */           }
/*     */         }
/* 178 */         else if ((inLiteralSubstitution) && (inNothing))
/*     */         {
/*     */ 
/*     */ 
/* 182 */           if (!inLiteralSubstitutionInsertion) {
/* 183 */             if (input.charAt(i - 1) != '|') {
/* 184 */               strBuilder.append(" + ");
/*     */             }
/* 186 */             strBuilder.append('\'');
/* 187 */             inLiteralSubstitutionInsertion = true;
/*     */           }
/*     */           
/* 190 */           if (c == '\'') {
/* 191 */             strBuilder.append('\\');
/* 192 */           } else if (c == '\\') {
/* 193 */             strBuilder.append('\\');
/*     */           }
/*     */           
/* 196 */           strBuilder.append(c);
/*     */ 
/*     */ 
/*     */ 
/*     */         }
/* 201 */         else if (strBuilder != null) {
/* 202 */           strBuilder.append(c);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 209 */     if (strBuilder == null) {
/* 210 */       return input;
/*     */     }
/*     */     
/* 213 */     return strBuilder.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\expression\LiteralSubstitutionUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */