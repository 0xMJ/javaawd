/*     */ package org.thymeleaf.standard.expression;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.math.RoundingMode;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.thymeleaf.TemplateEngine;
/*     */ import org.thymeleaf.context.IExpressionContext;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.util.EvaluationUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DivisionExpression
/*     */   extends MultiplicationDivisionRemainderExpression
/*     */ {
/*     */   private static final long serialVersionUID = -6480768503994179971L;
/*  54 */   private static final Logger logger = LoggerFactory.getLogger(DivisionExpression.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public DivisionExpression(IStandardExpression left, IStandardExpression right)
/*     */   {
/*  61 */     super(left, right);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getStringRepresentation()
/*     */   {
/*  68 */     return getStringRepresentation("/");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static Object executeDivision(IExpressionContext context, DivisionExpression expression, StandardExpressionExecutionContext expContext)
/*     */   {
/*  78 */     if (logger.isTraceEnabled()) {
/*  79 */       logger.trace("[THYMELEAF][{}] Evaluating division expression: \"{}\"", TemplateEngine.threadIndex(), expression.getStringRepresentation());
/*     */     }
/*     */     
/*  82 */     Object leftValue = expression.getLeft().execute(context, expContext);
/*     */     
/*  84 */     Object rightValue = expression.getRight().execute(context, expContext);
/*     */     
/*  86 */     if (leftValue == null) {
/*  87 */       leftValue = "null";
/*     */     }
/*  89 */     if (rightValue == null) {
/*  90 */       rightValue = "null";
/*     */     }
/*     */     
/*  93 */     BigDecimal leftNumberValue = EvaluationUtils.evaluateAsNumber(leftValue);
/*  94 */     BigDecimal rightNumberValue = EvaluationUtils.evaluateAsNumber(rightValue);
/*  95 */     if ((leftNumberValue != null) && (rightNumberValue != null)) {
/*     */       try {
/*  97 */         return leftNumberValue.divide(rightNumberValue);
/*     */       }
/*     */       catch (ArithmeticException ignored)
/*     */       {
/* 101 */         return leftNumberValue.divide(rightNumberValue, 
/*     */         
/* 103 */           Math.max(Math.max(leftNumberValue.scale(), rightNumberValue.scale()), 10), RoundingMode.HALF_UP);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 109 */     throw new TemplateProcessingException("Cannot execute division: operands are \"" + LiteralValue.unwrap(leftValue) + "\" and \"" + LiteralValue.unwrap(rightValue) + "\"");
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\standard\expression\DivisionExpression.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */