/*      */ package org.thymeleaf.util;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class TextUtils
/*      */ {
/*      */   public static boolean equals(boolean caseSensitive, CharSequence text1, CharSequence text2)
/*      */   {
/*   49 */     if (text1 == null) {
/*   50 */       throw new IllegalArgumentException("First text being compared cannot be null");
/*      */     }
/*   52 */     if (text2 == null) {
/*   53 */       throw new IllegalArgumentException("Second text being compared cannot be null");
/*      */     }
/*      */     
/*   56 */     if (text1 == text2) {
/*   57 */       return true;
/*      */     }
/*      */     
/*   60 */     if (((text1 instanceof String)) && ((text2 instanceof String))) {
/*   61 */       return caseSensitive ? text1.equals(text2) : ((String)text1).equalsIgnoreCase((String)text2);
/*      */     }
/*      */     
/*   64 */     return equals(caseSensitive, text1, 0, text1.length(), text2, 0, text2.length());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean equals(boolean caseSensitive, CharSequence text1, char[] text2)
/*      */   {
/*   80 */     return equals(caseSensitive, text1, 0, text1.length(), text2, 0, text2.length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean equals(boolean caseSensitive, char[] text1, char[] text2)
/*      */   {
/*   95 */     return (text1 == text2) || (equals(caseSensitive, text1, 0, text1.length, text2, 0, text2.length));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean equals(boolean caseSensitive, char[] text1, int text1Offset, int text1Len, char[] text2, int text2Offset, int text2Len)
/*      */   {
/*  119 */     if (text1 == null) {
/*  120 */       throw new IllegalArgumentException("First text buffer being compared cannot be null");
/*      */     }
/*  122 */     if (text2 == null) {
/*  123 */       throw new IllegalArgumentException("Second text buffer being compared cannot be null");
/*      */     }
/*      */     
/*  126 */     if (text1Len != text2Len) {
/*  127 */       return false;
/*      */     }
/*      */     
/*  130 */     if ((text1 == text2) && (text1Offset == text2Offset) && (text1Len == text2Len)) {
/*  131 */       return true;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  136 */     int n = text1Len;
/*  137 */     int i = 0;
/*      */     
/*  139 */     while (n-- != 0)
/*      */     {
/*  141 */       char c1 = text1[(text1Offset + i)];
/*  142 */       char c2 = text2[(text2Offset + i)];
/*      */       
/*  144 */       if (c1 != c2)
/*      */       {
/*  146 */         if (caseSensitive) {
/*  147 */           return false;
/*      */         }
/*      */         
/*  150 */         c1 = Character.toUpperCase(c1);
/*  151 */         c2 = Character.toUpperCase(c2);
/*      */         
/*  153 */         if (c1 != c2)
/*      */         {
/*      */ 
/*      */ 
/*  157 */           if (Character.toLowerCase(c1) != Character.toLowerCase(c2)) {
/*  158 */             return false;
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  165 */       i++;
/*      */     }
/*      */     
/*      */ 
/*  169 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean equals(boolean caseSensitive, CharSequence text1, int text1Offset, int text1Len, char[] text2, int text2Offset, int text2Len)
/*      */   {
/*  194 */     if (text1 == null) {
/*  195 */       throw new IllegalArgumentException("First text being compared cannot be null");
/*      */     }
/*  197 */     if (text2 == null) {
/*  198 */       throw new IllegalArgumentException("Second text buffer being compared cannot be null");
/*      */     }
/*      */     
/*  201 */     if (text1Len != text2Len) {
/*  202 */       return false;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  207 */     int n = text1Len;
/*  208 */     int i = 0;
/*      */     
/*  210 */     while (n-- != 0)
/*      */     {
/*  212 */       char c1 = text1.charAt(text1Offset + i);
/*  213 */       char c2 = text2[(text2Offset + i)];
/*      */       
/*  215 */       if (c1 != c2)
/*      */       {
/*  217 */         if (caseSensitive) {
/*  218 */           return false;
/*      */         }
/*      */         
/*  221 */         c1 = Character.toUpperCase(c1);
/*  222 */         c2 = Character.toUpperCase(c2);
/*      */         
/*  224 */         if (c1 != c2)
/*      */         {
/*      */ 
/*      */ 
/*  228 */           if (Character.toLowerCase(c1) != Character.toLowerCase(c2)) {
/*  229 */             return false;
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  236 */       i++;
/*      */     }
/*      */     
/*      */ 
/*  240 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean equals(boolean caseSensitive, CharSequence text1, int text1Offset, int text1Len, CharSequence text2, int text2Offset, int text2Len)
/*      */   {
/*  265 */     if (text1 == null) {
/*  266 */       throw new IllegalArgumentException("First text being compared cannot be null");
/*      */     }
/*  268 */     if (text2 == null) {
/*  269 */       throw new IllegalArgumentException("Second text being compared cannot be null");
/*      */     }
/*      */     
/*  272 */     if (text1Len != text2Len) {
/*  273 */       return false;
/*      */     }
/*      */     
/*  276 */     if ((text1 == text2) && (text1Offset == text2Offset) && (text1Len == text2Len)) {
/*  277 */       return true;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  282 */     int n = text1Len;
/*  283 */     int i = 0;
/*      */     
/*  285 */     while (n-- != 0)
/*      */     {
/*  287 */       char c1 = text1.charAt(text1Offset + i);
/*  288 */       char c2 = text2.charAt(text2Offset + i);
/*      */       
/*  290 */       if (c1 != c2)
/*      */       {
/*  292 */         if (caseSensitive) {
/*  293 */           return false;
/*      */         }
/*      */         
/*  296 */         c1 = Character.toUpperCase(c1);
/*  297 */         c2 = Character.toUpperCase(c2);
/*      */         
/*  299 */         if (c1 != c2)
/*      */         {
/*      */ 
/*      */ 
/*  303 */           if (Character.toLowerCase(c1) != Character.toLowerCase(c2)) {
/*  304 */             return false;
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  311 */       i++;
/*      */     }
/*      */     
/*      */ 
/*  315 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean startsWith(boolean caseSensitive, CharSequence text, CharSequence prefix)
/*      */   {
/*  336 */     if (text == null) {
/*  337 */       throw new IllegalArgumentException("Text cannot be null");
/*      */     }
/*  339 */     if (prefix == null) {
/*  340 */       throw new IllegalArgumentException("Prefix cannot be null");
/*      */     }
/*      */     
/*  343 */     if (((text instanceof String)) && ((prefix instanceof String))) {
/*  344 */       return caseSensitive ? ((String)text).startsWith((String)prefix) : startsWith(caseSensitive, text, 0, text.length(), prefix, 0, prefix.length());
/*      */     }
/*      */     
/*  347 */     return startsWith(caseSensitive, text, 0, text.length(), prefix, 0, prefix.length());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean startsWith(boolean caseSensitive, CharSequence text, char[] prefix)
/*      */   {
/*  363 */     return startsWith(caseSensitive, text, 0, text.length(), prefix, 0, prefix.length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean startsWith(boolean caseSensitive, char[] text, char[] prefix)
/*      */   {
/*  378 */     return startsWith(caseSensitive, text, 0, text.length, prefix, 0, prefix.length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean startsWith(boolean caseSensitive, char[] text, int textOffset, int textLen, char[] prefix, int prefixOffset, int prefixLen)
/*      */   {
/*  402 */     if (text == null) {
/*  403 */       throw new IllegalArgumentException("Text cannot be null");
/*      */     }
/*  405 */     if (prefix == null) {
/*  406 */       throw new IllegalArgumentException("Prefix cannot be null");
/*      */     }
/*      */     
/*  409 */     if (textLen < prefixLen) {
/*  410 */       return false;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  415 */     int n = prefixLen;
/*  416 */     int i = 0;
/*      */     
/*  418 */     while (n-- != 0)
/*      */     {
/*  420 */       char c1 = text[(textOffset + i)];
/*  421 */       char c2 = prefix[(prefixOffset + i)];
/*      */       
/*  423 */       if (c1 != c2)
/*      */       {
/*  425 */         if (caseSensitive) {
/*  426 */           return false;
/*      */         }
/*      */         
/*  429 */         c1 = Character.toUpperCase(c1);
/*  430 */         c2 = Character.toUpperCase(c2);
/*      */         
/*  432 */         if (c1 != c2)
/*      */         {
/*      */ 
/*      */ 
/*  436 */           if (Character.toLowerCase(c1) != Character.toLowerCase(c2)) {
/*  437 */             return false;
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  444 */       i++;
/*      */     }
/*      */     
/*      */ 
/*  448 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean startsWith(boolean caseSensitive, CharSequence text, int textOffset, int textLen, char[] prefix, int prefixOffset, int prefixLen)
/*      */   {
/*  473 */     if (text == null) {
/*  474 */       throw new IllegalArgumentException("Text cannot be null");
/*      */     }
/*  476 */     if (prefix == null) {
/*  477 */       throw new IllegalArgumentException("Prefix cannot be null");
/*      */     }
/*      */     
/*  480 */     if (textLen < prefixLen) {
/*  481 */       return false;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  486 */     int n = prefixLen;
/*  487 */     int i = 0;
/*      */     
/*  489 */     while (n-- != 0)
/*      */     {
/*  491 */       char c1 = text.charAt(textOffset + i);
/*  492 */       char c2 = prefix[(prefixOffset + i)];
/*      */       
/*  494 */       if (c1 != c2)
/*      */       {
/*  496 */         if (caseSensitive) {
/*  497 */           return false;
/*      */         }
/*      */         
/*  500 */         c1 = Character.toUpperCase(c1);
/*  501 */         c2 = Character.toUpperCase(c2);
/*      */         
/*  503 */         if (c1 != c2)
/*      */         {
/*      */ 
/*      */ 
/*  507 */           if (Character.toLowerCase(c1) != Character.toLowerCase(c2)) {
/*  508 */             return false;
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  515 */       i++;
/*      */     }
/*      */     
/*      */ 
/*  519 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean startsWith(boolean caseSensitive, char[] text, int textOffset, int textLen, CharSequence prefix, int prefixOffset, int prefixLen)
/*      */   {
/*  544 */     if (text == null) {
/*  545 */       throw new IllegalArgumentException("Text cannot be null");
/*      */     }
/*  547 */     if (prefix == null) {
/*  548 */       throw new IllegalArgumentException("Prefix cannot be null");
/*      */     }
/*      */     
/*  551 */     if (textLen < prefixLen) {
/*  552 */       return false;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  557 */     int n = prefixLen;
/*  558 */     int i = 0;
/*      */     
/*  560 */     while (n-- != 0)
/*      */     {
/*  562 */       char c1 = text[(textOffset + i)];
/*  563 */       char c2 = prefix.charAt(prefixOffset + i);
/*      */       
/*  565 */       if (c1 != c2)
/*      */       {
/*  567 */         if (caseSensitive) {
/*  568 */           return false;
/*      */         }
/*      */         
/*  571 */         c1 = Character.toUpperCase(c1);
/*  572 */         c2 = Character.toUpperCase(c2);
/*      */         
/*  574 */         if (c1 != c2)
/*      */         {
/*      */ 
/*      */ 
/*  578 */           if (Character.toLowerCase(c1) != Character.toLowerCase(c2)) {
/*  579 */             return false;
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  586 */       i++;
/*      */     }
/*      */     
/*      */ 
/*  590 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean startsWith(boolean caseSensitive, CharSequence text, int textOffset, int textLen, CharSequence prefix, int prefixOffset, int prefixLen)
/*      */   {
/*  615 */     if (text == null) {
/*  616 */       throw new IllegalArgumentException("Text cannot be null");
/*      */     }
/*  618 */     if (prefix == null) {
/*  619 */       throw new IllegalArgumentException("Prefix cannot be null");
/*      */     }
/*      */     
/*  622 */     if (textLen < prefixLen) {
/*  623 */       return false;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  628 */     int n = prefixLen;
/*  629 */     int i = 0;
/*      */     
/*  631 */     while (n-- != 0)
/*      */     {
/*  633 */       char c1 = text.charAt(textOffset + i);
/*  634 */       char c2 = prefix.charAt(prefixOffset + i);
/*      */       
/*  636 */       if (c1 != c2)
/*      */       {
/*  638 */         if (caseSensitive) {
/*  639 */           return false;
/*      */         }
/*      */         
/*  642 */         c1 = Character.toUpperCase(c1);
/*  643 */         c2 = Character.toUpperCase(c2);
/*      */         
/*  645 */         if (c1 != c2)
/*      */         {
/*      */ 
/*      */ 
/*  649 */           if (Character.toLowerCase(c1) != Character.toLowerCase(c2)) {
/*  650 */             return false;
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  657 */       i++;
/*      */     }
/*      */     
/*      */ 
/*  661 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean endsWith(boolean caseSensitive, CharSequence text, CharSequence suffix)
/*      */   {
/*  682 */     if (text == null) {
/*  683 */       throw new IllegalArgumentException("Text cannot be null");
/*      */     }
/*  685 */     if (suffix == null) {
/*  686 */       throw new IllegalArgumentException("Suffix cannot be null");
/*      */     }
/*      */     
/*  689 */     if (((text instanceof String)) && ((suffix instanceof String))) {
/*  690 */       return caseSensitive ? ((String)text).endsWith((String)suffix) : endsWith(caseSensitive, text, 0, text.length(), suffix, 0, suffix.length());
/*      */     }
/*      */     
/*  693 */     return endsWith(caseSensitive, text, 0, text.length(), suffix, 0, suffix.length());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean endsWith(boolean caseSensitive, CharSequence text, char[] suffix)
/*      */   {
/*  709 */     return endsWith(caseSensitive, text, 0, text.length(), suffix, 0, suffix.length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean endsWith(boolean caseSensitive, char[] text, char[] suffix)
/*      */   {
/*  724 */     return endsWith(caseSensitive, text, 0, text.length, suffix, 0, suffix.length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean endsWith(boolean caseSensitive, char[] text, int textOffset, int textLen, char[] suffix, int suffixOffset, int suffixLen)
/*      */   {
/*  748 */     if (text == null) {
/*  749 */       throw new IllegalArgumentException("Text cannot be null");
/*      */     }
/*  751 */     if (suffix == null) {
/*  752 */       throw new IllegalArgumentException("Suffix cannot be null");
/*      */     }
/*      */     
/*  755 */     if (textLen < suffixLen) {
/*  756 */       return false;
/*      */     }
/*      */     
/*  759 */     int textReverseOffset = textOffset + textLen - 1;
/*  760 */     int suffixReverseOffset = suffixOffset + suffixLen - 1;
/*      */     
/*      */ 
/*      */ 
/*  764 */     int n = suffixLen;
/*  765 */     int i = 0;
/*      */     
/*  767 */     while (n-- != 0)
/*      */     {
/*  769 */       char c1 = text[(textReverseOffset - i)];
/*  770 */       char c2 = suffix[(suffixReverseOffset - i)];
/*      */       
/*  772 */       if (c1 != c2)
/*      */       {
/*  774 */         if (caseSensitive) {
/*  775 */           return false;
/*      */         }
/*      */         
/*  778 */         c1 = Character.toUpperCase(c1);
/*  779 */         c2 = Character.toUpperCase(c2);
/*      */         
/*  781 */         if (c1 != c2)
/*      */         {
/*      */ 
/*      */ 
/*  785 */           if (Character.toLowerCase(c1) != Character.toLowerCase(c2)) {
/*  786 */             return false;
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  793 */       i++;
/*      */     }
/*      */     
/*      */ 
/*  797 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean endsWith(boolean caseSensitive, CharSequence text, int textOffset, int textLen, char[] suffix, int suffixOffset, int suffixLen)
/*      */   {
/*  822 */     if (text == null) {
/*  823 */       throw new IllegalArgumentException("Text cannot be null");
/*      */     }
/*  825 */     if (suffix == null) {
/*  826 */       throw new IllegalArgumentException("Suffix cannot be null");
/*      */     }
/*      */     
/*  829 */     if (textLen < suffixLen) {
/*  830 */       return false;
/*      */     }
/*      */     
/*  833 */     int textReverseOffset = textOffset + textLen - 1;
/*  834 */     int suffixReverseOffset = suffixOffset + suffixLen - 1;
/*      */     
/*      */ 
/*      */ 
/*  838 */     int n = suffixLen;
/*  839 */     int i = 0;
/*      */     
/*  841 */     while (n-- != 0)
/*      */     {
/*  843 */       char c1 = text.charAt(textReverseOffset - i);
/*  844 */       char c2 = suffix[(suffixReverseOffset - i)];
/*      */       
/*  846 */       if (c1 != c2)
/*      */       {
/*  848 */         if (caseSensitive) {
/*  849 */           return false;
/*      */         }
/*      */         
/*  852 */         c1 = Character.toUpperCase(c1);
/*  853 */         c2 = Character.toUpperCase(c2);
/*      */         
/*  855 */         if (c1 != c2)
/*      */         {
/*      */ 
/*      */ 
/*  859 */           if (Character.toLowerCase(c1) != Character.toLowerCase(c2)) {
/*  860 */             return false;
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  867 */       i++;
/*      */     }
/*      */     
/*      */ 
/*  871 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean endsWith(boolean caseSensitive, char[] text, int textOffset, int textLen, CharSequence suffix, int suffixOffset, int suffixLen)
/*      */   {
/*  896 */     if (text == null) {
/*  897 */       throw new IllegalArgumentException("Text cannot be null");
/*      */     }
/*  899 */     if (suffix == null) {
/*  900 */       throw new IllegalArgumentException("Suffix cannot be null");
/*      */     }
/*      */     
/*  903 */     if (textLen < suffixLen) {
/*  904 */       return false;
/*      */     }
/*      */     
/*  907 */     int textReverseOffset = textOffset + textLen - 1;
/*  908 */     int suffixReverseOffset = suffixOffset + suffixLen - 1;
/*      */     
/*      */ 
/*      */ 
/*  912 */     int n = suffixLen;
/*  913 */     int i = 0;
/*      */     
/*  915 */     while (n-- != 0)
/*      */     {
/*  917 */       char c1 = text[(textReverseOffset - i)];
/*  918 */       char c2 = suffix.charAt(suffixReverseOffset - i);
/*      */       
/*  920 */       if (c1 != c2)
/*      */       {
/*  922 */         if (caseSensitive) {
/*  923 */           return false;
/*      */         }
/*      */         
/*  926 */         c1 = Character.toUpperCase(c1);
/*  927 */         c2 = Character.toUpperCase(c2);
/*      */         
/*  929 */         if (c1 != c2)
/*      */         {
/*      */ 
/*      */ 
/*  933 */           if (Character.toLowerCase(c1) != Character.toLowerCase(c2)) {
/*  934 */             return false;
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  941 */       i++;
/*      */     }
/*      */     
/*      */ 
/*  945 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean endsWith(boolean caseSensitive, CharSequence text, int textOffset, int textLen, CharSequence suffix, int suffixOffset, int suffixLen)
/*      */   {
/*  970 */     if (text == null) {
/*  971 */       throw new IllegalArgumentException("Text cannot be null");
/*      */     }
/*  973 */     if (suffix == null) {
/*  974 */       throw new IllegalArgumentException("Suffix cannot be null");
/*      */     }
/*      */     
/*  977 */     if (textLen < suffixLen) {
/*  978 */       return false;
/*      */     }
/*      */     
/*  981 */     int textReverseOffset = textOffset + textLen - 1;
/*  982 */     int suffixReverseOffset = suffixOffset + suffixLen - 1;
/*      */     
/*      */ 
/*      */ 
/*  986 */     int n = suffixLen;
/*  987 */     int i = 0;
/*      */     
/*  989 */     while (n-- != 0)
/*      */     {
/*  991 */       char c1 = text.charAt(textReverseOffset - i);
/*  992 */       char c2 = suffix.charAt(suffixReverseOffset - i);
/*      */       
/*  994 */       if (c1 != c2)
/*      */       {
/*  996 */         if (caseSensitive) {
/*  997 */           return false;
/*      */         }
/*      */         
/* 1000 */         c1 = Character.toUpperCase(c1);
/* 1001 */         c2 = Character.toUpperCase(c2);
/*      */         
/* 1003 */         if (c1 != c2)
/*      */         {
/*      */ 
/*      */ 
/* 1007 */           if (Character.toLowerCase(c1) != Character.toLowerCase(c2)) {
/* 1008 */             return false;
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1015 */       i++;
/*      */     }
/*      */     
/*      */ 
/* 1019 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean contains(boolean caseSensitive, CharSequence text, CharSequence fragment)
/*      */   {
/* 1040 */     if (text == null) {
/* 1041 */       throw new IllegalArgumentException("Text cannot be null");
/*      */     }
/* 1043 */     if (fragment == null) {
/* 1044 */       throw new IllegalArgumentException("Fragment cannot be null");
/*      */     }
/*      */     
/* 1047 */     if (((text instanceof String)) && ((fragment instanceof String)))
/*      */     {
/*      */ 
/*      */ 
/* 1051 */       return caseSensitive ? ((String)text).contains(fragment) : contains(caseSensitive, text, 0, text.length(), fragment, 0, fragment.length());
/*      */     }
/*      */     
/* 1054 */     return contains(caseSensitive, text, 0, text.length(), fragment, 0, fragment.length());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean contains(boolean caseSensitive, CharSequence text, char[] fragment)
/*      */   {
/* 1070 */     return contains(caseSensitive, text, 0, text.length(), fragment, 0, fragment.length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean contains(boolean caseSensitive, char[] text, char[] fragment)
/*      */   {
/* 1085 */     return contains(caseSensitive, text, 0, text.length, fragment, 0, fragment.length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean contains(boolean caseSensitive, char[] text, int textOffset, int textLen, char[] fragment, int fragmentOffset, int fragmentLen)
/*      */   {
/* 1109 */     if (text == null) {
/* 1110 */       throw new IllegalArgumentException("Text cannot be null");
/*      */     }
/* 1112 */     if (fragment == null) {
/* 1113 */       throw new IllegalArgumentException("Fragment cannot be null");
/*      */     }
/*      */     
/* 1116 */     if (textLen < fragmentLen) {
/* 1117 */       return false;
/*      */     }
/* 1119 */     if (fragmentLen == 0) {
/* 1120 */       return true;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1125 */     int i = 0; for (int j = 0; i < textLen; i++)
/*      */     {
/* 1127 */       char c1 = text[(textOffset + i)];
/* 1128 */       char c2 = fragment[(fragmentOffset + j)];
/*      */       
/* 1130 */       if (c1 == c2) {
/* 1131 */         j++; if (j == fragmentLen) {
/* 1132 */           return true;
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/* 1137 */         if (!caseSensitive)
/*      */         {
/* 1139 */           c1 = Character.toUpperCase(c1);
/* 1140 */           c2 = Character.toUpperCase(c2);
/* 1141 */           if (c1 == c2) {
/* 1142 */             j++; if (j != fragmentLen) continue;
/* 1143 */             return true;
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1150 */           if (Character.toLowerCase(c1) == Character.toLowerCase(c2)) {
/* 1151 */             j++; if (j != fragmentLen) continue;
/* 1152 */             return true;
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 1159 */         if (j > 0)
/*      */         {
/* 1161 */           i -= j;
/*      */         }
/*      */         
/* 1164 */         j = 0;
/*      */       }
/*      */     }
/*      */     
/* 1168 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean contains(boolean caseSensitive, CharSequence text, int textOffset, int textLen, char[] fragment, int fragmentOffset, int fragmentLen)
/*      */   {
/* 1193 */     if (text == null) {
/* 1194 */       throw new IllegalArgumentException("Text cannot be null");
/*      */     }
/* 1196 */     if (fragment == null) {
/* 1197 */       throw new IllegalArgumentException("Fragment cannot be null");
/*      */     }
/*      */     
/* 1200 */     if (textLen < fragmentLen) {
/* 1201 */       return false;
/*      */     }
/* 1203 */     if (fragmentLen == 0) {
/* 1204 */       return true;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1209 */     int i = 0; for (int j = 0; i < textLen; i++)
/*      */     {
/* 1211 */       char c1 = text.charAt(textOffset + i);
/* 1212 */       char c2 = fragment[(fragmentOffset + j)];
/*      */       
/* 1214 */       if (c1 == c2) {
/* 1215 */         j++; if (j == fragmentLen) {
/* 1216 */           return true;
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/* 1221 */         if (!caseSensitive)
/*      */         {
/* 1223 */           c1 = Character.toUpperCase(c1);
/* 1224 */           c2 = Character.toUpperCase(c2);
/* 1225 */           if (c1 == c2) {
/* 1226 */             j++; if (j != fragmentLen) continue;
/* 1227 */             return true;
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1234 */           if (Character.toLowerCase(c1) == Character.toLowerCase(c2)) {
/* 1235 */             j++; if (j != fragmentLen) continue;
/* 1236 */             return true;
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 1243 */         if (j > 0)
/*      */         {
/* 1245 */           i -= j;
/*      */         }
/*      */         
/* 1248 */         j = 0;
/*      */       }
/*      */     }
/*      */     
/* 1252 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean contains(boolean caseSensitive, char[] text, int textOffset, int textLen, CharSequence fragment, int fragmentOffset, int fragmentLen)
/*      */   {
/* 1277 */     if (text == null) {
/* 1278 */       throw new IllegalArgumentException("Text cannot be null");
/*      */     }
/* 1280 */     if (fragment == null) {
/* 1281 */       throw new IllegalArgumentException("Fragment cannot be null");
/*      */     }
/*      */     
/* 1284 */     if (textLen < fragmentLen) {
/* 1285 */       return false;
/*      */     }
/* 1287 */     if (fragmentLen == 0) {
/* 1288 */       return true;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1293 */     int i = 0; for (int j = 0; i < textLen; i++)
/*      */     {
/* 1295 */       char c1 = text[(textOffset + i)];
/* 1296 */       char c2 = fragment.charAt(fragmentOffset + j);
/*      */       
/* 1298 */       if (c1 == c2) {
/* 1299 */         j++; if (j == fragmentLen) {
/* 1300 */           return true;
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/* 1305 */         if (!caseSensitive)
/*      */         {
/* 1307 */           c1 = Character.toUpperCase(c1);
/* 1308 */           c2 = Character.toUpperCase(c2);
/* 1309 */           if (c1 == c2) {
/* 1310 */             j++; if (j != fragmentLen) continue;
/* 1311 */             return true;
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1318 */           if (Character.toLowerCase(c1) == Character.toLowerCase(c2)) {
/* 1319 */             j++; if (j != fragmentLen) continue;
/* 1320 */             return true;
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 1327 */         if (j > 0)
/*      */         {
/* 1329 */           i -= j;
/*      */         }
/*      */         
/* 1332 */         j = 0;
/*      */       }
/*      */     }
/*      */     
/* 1336 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean contains(boolean caseSensitive, CharSequence text, int textOffset, int textLen, CharSequence fragment, int fragmentOffset, int fragmentLen)
/*      */   {
/* 1361 */     if (text == null) {
/* 1362 */       throw new IllegalArgumentException("Text cannot be null");
/*      */     }
/* 1364 */     if (fragment == null) {
/* 1365 */       throw new IllegalArgumentException("Fragment cannot be null");
/*      */     }
/*      */     
/* 1368 */     if (textLen < fragmentLen) {
/* 1369 */       return false;
/*      */     }
/* 1371 */     if (fragmentLen == 0) {
/* 1372 */       return true;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1377 */     int i = 0; for (int j = 0; i < textLen; i++)
/*      */     {
/* 1379 */       char c1 = text.charAt(textOffset + i);
/* 1380 */       char c2 = fragment.charAt(fragmentOffset + j);
/*      */       
/* 1382 */       if (c1 == c2) {
/* 1383 */         j++; if (j == fragmentLen) {
/* 1384 */           return true;
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/* 1389 */         if (!caseSensitive)
/*      */         {
/* 1391 */           c1 = Character.toUpperCase(c1);
/* 1392 */           c2 = Character.toUpperCase(c2);
/* 1393 */           if (c1 == c2) {
/* 1394 */             j++; if (j != fragmentLen) continue;
/* 1395 */             return true;
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1402 */           if (Character.toLowerCase(c1) == Character.toLowerCase(c2)) {
/* 1403 */             j++; if (j != fragmentLen) continue;
/* 1404 */             return true;
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 1411 */         if (j > 0)
/*      */         {
/* 1413 */           i -= j;
/*      */         }
/*      */         
/* 1416 */         j = 0;
/*      */       }
/*      */     }
/*      */     
/* 1420 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int compareTo(boolean caseSensitive, CharSequence text1, CharSequence text2)
/*      */   {
/* 1457 */     if (text1 == null) {
/* 1458 */       throw new IllegalArgumentException("First text being compared cannot be null");
/*      */     }
/* 1460 */     if (text2 == null) {
/* 1461 */       throw new IllegalArgumentException("Second text being compared cannot be null");
/*      */     }
/*      */     
/* 1464 */     if (((text1 instanceof String)) && ((text2 instanceof String))) {
/* 1465 */       return caseSensitive ? ((String)text1).compareTo((String)text2) : ((String)text1).compareToIgnoreCase((String)text2);
/*      */     }
/*      */     
/* 1468 */     return compareTo(caseSensitive, text1, 0, text1.length(), text2, 0, text2.length());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int compareTo(boolean caseSensitive, CharSequence text1, char[] text2)
/*      */   {
/* 1500 */     return compareTo(caseSensitive, text1, 0, text1.length(), text2, 0, text2.length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int compareTo(boolean caseSensitive, char[] text1, char[] text2)
/*      */   {
/* 1531 */     return compareTo(caseSensitive, text1, 0, text1.length, text2, 0, text2.length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int compareTo(boolean caseSensitive, char[] text1, int text1Offset, int text1Len, char[] text2, int text2Offset, int text2Len)
/*      */   {
/* 1570 */     if (text1 == null) {
/* 1571 */       throw new IllegalArgumentException("First text buffer being compared cannot be null");
/*      */     }
/* 1573 */     if (text2 == null) {
/* 1574 */       throw new IllegalArgumentException("Second text buffer being compared cannot be null");
/*      */     }
/*      */     
/* 1577 */     if ((text1 == text2) && (text1Offset == text2Offset) && (text1Len == text2Len)) {
/* 1578 */       return 0;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1583 */     int n = Math.min(text1Len, text2Len);
/* 1584 */     int i = 0;
/*      */     
/* 1586 */     while (n-- != 0)
/*      */     {
/* 1588 */       char c1 = text1[(text1Offset + i)];
/* 1589 */       char c2 = text2[(text2Offset + i)];
/*      */       
/* 1591 */       if (c1 != c2)
/*      */       {
/* 1593 */         if (caseSensitive) {
/* 1594 */           return c1 - c2;
/*      */         }
/*      */         
/* 1597 */         c1 = Character.toUpperCase(c1);
/* 1598 */         c2 = Character.toUpperCase(c2);
/*      */         
/* 1600 */         if (c1 != c2)
/*      */         {
/* 1602 */           c1 = Character.toLowerCase(c1);
/* 1603 */           c2 = Character.toLowerCase(c2);
/* 1604 */           if (c1 != c2) {
/* 1605 */             return c1 - c2;
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1612 */       i++;
/*      */     }
/*      */     
/*      */ 
/* 1616 */     return text1Len - text2Len;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int compareTo(boolean caseSensitive, CharSequence text1, int text1Offset, int text1Len, char[] text2, int text2Offset, int text2Len)
/*      */   {
/* 1656 */     if (text1 == null) {
/* 1657 */       throw new IllegalArgumentException("First text being compared cannot be null");
/*      */     }
/* 1659 */     if (text2 == null) {
/* 1660 */       throw new IllegalArgumentException("Second text buffer being compared cannot be null");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1665 */     int n = Math.min(text1Len, text2Len);
/* 1666 */     int i = 0;
/*      */     
/* 1668 */     while (n-- != 0)
/*      */     {
/* 1670 */       char c1 = text1.charAt(text1Offset + i);
/* 1671 */       char c2 = text2[(text2Offset + i)];
/*      */       
/* 1673 */       if (c1 != c2)
/*      */       {
/* 1675 */         if (caseSensitive) {
/* 1676 */           return c1 - c2;
/*      */         }
/*      */         
/* 1679 */         c1 = Character.toUpperCase(c1);
/* 1680 */         c2 = Character.toUpperCase(c2);
/*      */         
/* 1682 */         if (c1 != c2)
/*      */         {
/* 1684 */           c1 = Character.toLowerCase(c1);
/* 1685 */           c2 = Character.toLowerCase(c2);
/* 1686 */           if (c1 != c2) {
/* 1687 */             return c1 - c2;
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1694 */       i++;
/*      */     }
/*      */     
/*      */ 
/* 1698 */     return text1Len - text2Len;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int compareTo(boolean caseSensitive, CharSequence text1, int text1Offset, int text1Len, CharSequence text2, int text2Offset, int text2Len)
/*      */   {
/* 1738 */     if (text1 == null) {
/* 1739 */       throw new IllegalArgumentException("First text being compared cannot be null");
/*      */     }
/* 1741 */     if (text2 == null) {
/* 1742 */       throw new IllegalArgumentException("Second text being compared cannot be null");
/*      */     }
/*      */     
/* 1745 */     if ((text1 == text2) && (text1Offset == text2Offset) && (text1Len == text2Len)) {
/* 1746 */       return 0;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1751 */     int n = Math.min(text1Len, text2Len);
/* 1752 */     int i = 0;
/*      */     
/* 1754 */     while (n-- != 0)
/*      */     {
/* 1756 */       char c1 = text1.charAt(text1Offset + i);
/* 1757 */       char c2 = text2.charAt(text2Offset + i);
/*      */       
/* 1759 */       if (c1 != c2)
/*      */       {
/* 1761 */         if (caseSensitive) {
/* 1762 */           return c1 - c2;
/*      */         }
/*      */         
/* 1765 */         c1 = Character.toUpperCase(c1);
/* 1766 */         c2 = Character.toUpperCase(c2);
/*      */         
/* 1768 */         if (c1 != c2)
/*      */         {
/* 1770 */           c1 = Character.toLowerCase(c1);
/* 1771 */           c2 = Character.toLowerCase(c2);
/* 1772 */           if (c1 != c2) {
/* 1773 */             return c1 - c2;
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1780 */       i++;
/*      */     }
/*      */     
/*      */ 
/* 1784 */     return text1Len - text2Len;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int binarySearch(boolean caseSensitive, char[][] values, char[] text, int textOffset, int textLen)
/*      */   {
/* 1817 */     if (values == null) {
/* 1818 */       throw new IllegalArgumentException("Values array cannot be null");
/*      */     }
/* 1820 */     return binarySearch(caseSensitive, values, 0, values.length, text, textOffset, textLen);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int binarySearch(boolean caseSensitive, char[][] values, CharSequence text, int textOffset, int textLen)
/*      */   {
/* 1849 */     if (values == null) {
/* 1850 */       throw new IllegalArgumentException("Values array cannot be null");
/*      */     }
/* 1852 */     return binarySearch(caseSensitive, values, 0, values.length, text, textOffset, textLen);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int binarySearch(boolean caseSensitive, CharSequence[] values, char[] text, int textOffset, int textLen)
/*      */   {
/* 1881 */     if (values == null) {
/* 1882 */       throw new IllegalArgumentException("Values array cannot be null");
/*      */     }
/* 1884 */     return binarySearch(caseSensitive, values, 0, values.length, text, textOffset, textLen);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int binarySearch(boolean caseSensitive, CharSequence[] values, CharSequence text, int textOffset, int textLen)
/*      */   {
/* 1913 */     if (values == null) {
/* 1914 */       throw new IllegalArgumentException("Values array cannot be null");
/*      */     }
/* 1916 */     return binarySearch(caseSensitive, values, 0, values.length, text, textOffset, textLen);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int binarySearch(boolean caseSensitive, char[][] values, int valuesOffset, int valuesLen, char[] text, int textOffset, int textLen)
/*      */   {
/* 1949 */     if (values == null) {
/* 1950 */       throw new IllegalArgumentException("Values array cannot be null");
/*      */     }
/* 1952 */     if (text == null) {
/* 1953 */       throw new IllegalArgumentException("Text cannot be null");
/*      */     }
/*      */     
/* 1956 */     int low = valuesOffset;
/* 1957 */     int high = valuesOffset + valuesLen - 1;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1962 */     while (low <= high)
/*      */     {
/* 1964 */       int mid = low + high >>> 1;
/* 1965 */       char[] midVal = values[mid];
/*      */       
/* 1967 */       int cmp = compareTo(caseSensitive, midVal, 0, midVal.length, text, textOffset, textLen);
/*      */       
/* 1969 */       if (cmp < 0) {
/* 1970 */         low = mid + 1;
/* 1971 */       } else if (cmp > 0) {
/* 1972 */         high = mid - 1;
/*      */       }
/*      */       else {
/* 1975 */         return mid;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1980 */     return -(low + 1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int binarySearch(boolean caseSensitive, char[][] values, int valuesOffset, int valuesLen, CharSequence text, int textOffset, int textLen)
/*      */   {
/* 2013 */     if (values == null) {
/* 2014 */       throw new IllegalArgumentException("Values array cannot be null");
/*      */     }
/* 2016 */     if (text == null) {
/* 2017 */       throw new IllegalArgumentException("Text cannot be null");
/*      */     }
/*      */     
/* 2020 */     int low = valuesOffset;
/* 2021 */     int high = valuesOffset + valuesLen - 1;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 2026 */     while (low <= high)
/*      */     {
/* 2028 */       int mid = low + high >>> 1;
/* 2029 */       char[] midVal = values[mid];
/*      */       
/* 2031 */       int cmp = compareTo(caseSensitive, text, textOffset, textLen, midVal, 0, midVal.length);
/*      */       
/* 2033 */       if (cmp > 0) {
/* 2034 */         low = mid + 1;
/* 2035 */       } else if (cmp < 0) {
/* 2036 */         high = mid - 1;
/*      */       }
/*      */       else {
/* 2039 */         return mid;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 2044 */     return -(low + 1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int binarySearch(boolean caseSensitive, CharSequence[] values, int valuesOffset, int valuesLen, char[] text, int textOffset, int textLen)
/*      */   {
/* 2077 */     if (values == null) {
/* 2078 */       throw new IllegalArgumentException("Values array cannot be null");
/*      */     }
/* 2080 */     if (text == null) {
/* 2081 */       throw new IllegalArgumentException("Text cannot be null");
/*      */     }
/*      */     
/* 2084 */     int low = valuesOffset;
/* 2085 */     int high = valuesOffset + valuesLen - 1;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 2090 */     while (low <= high)
/*      */     {
/* 2092 */       int mid = low + high >>> 1;
/* 2093 */       CharSequence midVal = values[mid];
/*      */       
/* 2095 */       int cmp = compareTo(caseSensitive, midVal, 0, midVal.length(), text, textOffset, textLen);
/*      */       
/* 2097 */       if (cmp < 0) {
/* 2098 */         low = mid + 1;
/* 2099 */       } else if (cmp > 0) {
/* 2100 */         high = mid - 1;
/*      */       }
/*      */       else {
/* 2103 */         return mid;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 2108 */     return -(low + 1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int binarySearch(boolean caseSensitive, CharSequence[] values, int valuesOffset, int valuesLen, CharSequence text, int textOffset, int textLen)
/*      */   {
/* 2141 */     if (values == null) {
/* 2142 */       throw new IllegalArgumentException("Values array cannot be null");
/*      */     }
/* 2144 */     if (text == null) {
/* 2145 */       throw new IllegalArgumentException("Text cannot be null");
/*      */     }
/*      */     
/* 2148 */     int low = valuesOffset;
/* 2149 */     int high = valuesOffset + valuesLen - 1;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 2154 */     while (low <= high)
/*      */     {
/* 2156 */       int mid = low + high >>> 1;
/* 2157 */       CharSequence midVal = values[mid];
/*      */       
/* 2159 */       int cmp = compareTo(caseSensitive, text, textOffset, textLen, midVal, 0, midVal.length());
/*      */       
/* 2161 */       if (cmp > 0) {
/* 2162 */         low = mid + 1;
/* 2163 */       } else if (cmp < 0) {
/* 2164 */         high = mid - 1;
/*      */       }
/*      */       else {
/* 2167 */         return mid;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 2172 */     return -(low + 1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int hashCode(char[] text, int textOffset, int textLen)
/*      */   {
/* 2196 */     int h = 0;
/* 2197 */     int off = textOffset;
/* 2198 */     for (int i = 0; i < textLen; i++) {
/* 2199 */       h = 31 * h + text[(off++)];
/*      */     }
/* 2201 */     return h;
/*      */   }
/*      */   
/*      */   public static int hashCode(CharSequence text)
/*      */   {
/* 2206 */     return hashCodePart(0, text);
/*      */   }
/*      */   
/*      */   public static int hashCode(CharSequence text, int beginIndex, int endIndex)
/*      */   {
/* 2211 */     return hashCodePart(0, text, beginIndex, endIndex);
/*      */   }
/*      */   
/*      */   public static int hashCode(CharSequence text0, CharSequence text1)
/*      */   {
/* 2216 */     return hashCodePart(hashCodePart(0, text0), text1);
/*      */   }
/*      */   
/*      */   public static int hashCode(CharSequence text0, CharSequence text1, CharSequence text2)
/*      */   {
/* 2221 */     return hashCodePart(hashCodePart(hashCodePart(0, text0), text1), text2);
/*      */   }
/*      */   
/*      */   public static int hashCode(CharSequence text0, CharSequence text1, CharSequence text2, CharSequence text3)
/*      */   {
/* 2226 */     return hashCodePart(hashCodePart(hashCodePart(hashCodePart(0, text0), text1), text2), text3);
/*      */   }
/*      */   
/*      */   public static int hashCode(CharSequence text0, CharSequence text1, CharSequence text2, CharSequence text3, CharSequence text4)
/*      */   {
/* 2231 */     return hashCodePart(hashCodePart(hashCodePart(hashCodePart(hashCodePart(0, text0), text1), text2), text3), text4);
/*      */   }
/*      */   
/*      */ 
/*      */   private static int hashCodePart(int h, CharSequence text)
/*      */   {
/* 2237 */     return hashCodePart(h, text, 0, text.length());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static int hashCodePart(int h, CharSequence text, int beginIndex, int endIndex)
/*      */   {
/* 2252 */     if ((h == 0) && (beginIndex == 0) && (endIndex == text.length()) && ((text instanceof String))) {
/* 2253 */       return text.hashCode();
/*      */     }
/* 2255 */     int hh = h;
/* 2256 */     for (int i = beginIndex; i < endIndex; i++) {
/* 2257 */       hh = 31 * hh + text.charAt(i);
/*      */     }
/* 2259 */     return hh;
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\util\TextUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */