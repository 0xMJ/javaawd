/*     */ package org.thymeleaf.util;
/*     */ 
/*     */ import java.text.DecimalFormat;
/*     */ import java.text.DecimalFormatSymbols;
/*     */ import java.text.NumberFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class NumberUtils
/*     */ {
/*     */   public static String format(Number target, Integer minIntegerDigits, Locale locale)
/*     */   {
/*  41 */     if (target == null) {
/*  42 */       return null;
/*     */     }
/*  44 */     Validate.notNull(minIntegerDigits, "Minimum integer digits cannot be null");
/*  45 */     return formatNumber(target, minIntegerDigits, NumberPointType.NONE, Integer.valueOf(0), NumberPointType.NONE, locale);
/*     */   }
/*     */   
/*     */   public static String format(Number target, Integer minIntegerDigits, NumberPointType thousandsPointType, Locale locale) {
/*  49 */     if (target == null) {
/*  50 */       return null;
/*     */     }
/*  52 */     Validate.notNull(minIntegerDigits, "Minimum integer digits cannot be null");
/*  53 */     Validate.notNull(thousandsPointType, "Thousands point type cannot be null");
/*  54 */     return formatNumber(target, minIntegerDigits, thousandsPointType, Integer.valueOf(0), NumberPointType.NONE, locale);
/*     */   }
/*     */   
/*     */ 
/*     */   public static String format(Number target, Integer minIntegerDigits, Integer decimalDigits, Locale locale)
/*     */   {
/*  60 */     if (target == null) {
/*  61 */       return null;
/*     */     }
/*  63 */     Validate.notNull(minIntegerDigits, "Minimum integer digits cannot be null");
/*  64 */     Validate.notNull(decimalDigits, "Decimal digits cannot be null");
/*  65 */     return formatNumber(target, minIntegerDigits, NumberPointType.NONE, decimalDigits, NumberPointType.DEFAULT, locale);
/*     */   }
/*     */   
/*     */ 
/*     */   public static String format(Number target, Integer minIntegerDigits, Integer decimalDigits, NumberPointType decimalPointType, Locale locale)
/*     */   {
/*  71 */     if (target == null) {
/*  72 */       return null;
/*     */     }
/*  74 */     Validate.notNull(minIntegerDigits, "Minimum integer digits cannot be null");
/*  75 */     Validate.notNull(decimalDigits, "Decimal digits cannot be null");
/*  76 */     Validate.notNull(decimalPointType, "Decimal point type cannot be null");
/*  77 */     return formatNumber(target, minIntegerDigits, NumberPointType.NONE, decimalDigits, decimalPointType, locale);
/*     */   }
/*     */   
/*     */ 
/*     */   public static String format(Number target, Integer minIntegerDigits, NumberPointType thousandsPointType, Integer decimalDigits, Locale locale)
/*     */   {
/*  83 */     if (target == null) {
/*  84 */       return null;
/*     */     }
/*  86 */     Validate.notNull(minIntegerDigits, "Minimum integer digits cannot be null");
/*  87 */     Validate.notNull(thousandsPointType, "Thousands point type cannot be null");
/*  88 */     Validate.notNull(decimalDigits, "Decimal digits cannot be null");
/*  89 */     return formatNumber(target, minIntegerDigits, thousandsPointType, decimalDigits, NumberPointType.DEFAULT, locale);
/*     */   }
/*     */   
/*     */ 
/*     */   public static String format(Number target, Integer minIntegerDigits, NumberPointType thousandsPointType, Integer decimalDigits, NumberPointType decimalPointType, Locale locale)
/*     */   {
/*  95 */     if (target == null) {
/*  96 */       return null;
/*     */     }
/*  98 */     Validate.notNull(minIntegerDigits, "Minimum integer digits cannot be null");
/*  99 */     Validate.notNull(thousandsPointType, "Thousands point type cannot be null");
/* 100 */     Validate.notNull(decimalDigits, "Decimal digits cannot be null");
/* 101 */     Validate.notNull(decimalPointType, "Decimal point type cannot be null");
/* 102 */     return formatNumber(target, minIntegerDigits, thousandsPointType, decimalDigits, decimalPointType, locale);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Integer[] sequence(Integer from, Integer to)
/*     */   {
/* 121 */     return sequence(from, to, Integer.valueOf(from.intValue() <= to.intValue() ? 1 : -1));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Integer[] sequence(Integer from, Integer to, Integer step)
/*     */   {
/* 142 */     Validate.notNull(from, "Value to start the sequence from cannot be null");
/* 143 */     Validate.notNull(to, "Value to generate the sequence up to cannot be null");
/* 144 */     Validate.notNull(step, "Step to generate the sequence cannot be null");
/*     */     
/* 146 */     int iFrom = from.intValue();
/* 147 */     int iTo = to.intValue();
/* 148 */     int iStep = step.intValue();
/*     */     
/* 150 */     if (iFrom == iTo) {
/* 151 */       return new Integer[] { Integer.valueOf(iFrom) };
/*     */     }
/*     */     
/* 154 */     if (iStep == 0)
/*     */     {
/* 156 */       throw new IllegalArgumentException("Cannot create sequence from " + iFrom + " to " + iTo + " with step " + iStep);
/*     */     }
/*     */     
/* 159 */     List<Integer> values = new ArrayList(10);
/* 160 */     if ((iFrom < iTo) && (iStep > 0)) {
/* 161 */       int i = iFrom;
/* 162 */       while (i <= iTo) {
/* 163 */         values.add(Integer.valueOf(i));
/* 164 */         i += iStep;
/*     */       }
/* 166 */     } else if ((iFrom > iTo) && (iStep < 0))
/*     */     {
/* 168 */       int i = iFrom;
/* 169 */       while (i >= iTo) {
/* 170 */         values.add(Integer.valueOf(i));
/* 171 */         i += iStep;
/*     */       }
/*     */     }
/*     */     
/* 175 */     return (Integer[])values.toArray(new Integer[values.size()]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static String formatNumber(Number target, Integer minIntegerDigits, NumberPointType thousandsPointType, Integer fractionDigits, NumberPointType decimalPointType, Locale locale)
/*     */   {
/* 196 */     Validate.notNull(fractionDigits, "Fraction digits cannot be null");
/* 197 */     Validate.notNull(decimalPointType, "Decimal point type cannot be null");
/* 198 */     Validate.notNull(thousandsPointType, "Thousands point type cannot be null");
/* 199 */     Validate.notNull(locale, "Locale cannot be null");
/*     */     
/* 201 */     if (target == null) {
/* 202 */       return null;
/*     */     }
/*     */     
/* 205 */     DecimalFormat format = (DecimalFormat)NumberFormat.getNumberInstance(locale);
/* 206 */     format.setMinimumFractionDigits(fractionDigits.intValue());
/* 207 */     format.setMaximumFractionDigits(fractionDigits.intValue());
/* 208 */     if (minIntegerDigits != null) {
/* 209 */       format.setMinimumIntegerDigits(minIntegerDigits.intValue());
/*     */     }
/* 211 */     format.setDecimalSeparatorAlwaysShown((decimalPointType != NumberPointType.NONE) && (fractionDigits.intValue() > 0));
/* 212 */     format.setGroupingUsed(thousandsPointType != NumberPointType.NONE);
/* 213 */     format.setDecimalFormatSymbols(computeDecimalFormatSymbols(decimalPointType, thousandsPointType, locale));
/*     */     
/* 215 */     return format.format(target);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static DecimalFormatSymbols computeDecimalFormatSymbols(NumberPointType decimalPointType, NumberPointType thousandsPointType, Locale locale)
/*     */   {
/* 222 */     Validate.notNull(decimalPointType, "Decimal point type cannot be null");
/* 223 */     Validate.notNull(thousandsPointType, "Thousands point type cannot be null");
/* 224 */     Validate.notNull(locale, "Locale cannot be null");
/*     */     
/* 226 */     DecimalFormatSymbols symbols = new DecimalFormatSymbols(locale);
/*     */     
/* 228 */     switch (decimalPointType) {
/*     */     case POINT: 
/* 230 */       symbols.setDecimalSeparator('.');
/* 231 */       break;
/*     */     case COMMA: 
/* 233 */       symbols.setDecimalSeparator(',');
/* 234 */       break;
/*     */     case WHITESPACE: 
/* 236 */       symbols.setDecimalSeparator(' ');
/* 237 */       break;
/*     */     
/*     */     case DEFAULT: 
/*     */       break;
/*     */     
/*     */     case NONE: 
/* 243 */       symbols.setDecimalSeparator('?');
/*     */     }
/*     */     
/* 246 */     switch (thousandsPointType) {
/*     */     case POINT: 
/* 248 */       symbols.setGroupingSeparator('.');
/* 249 */       break;
/*     */     case COMMA: 
/* 251 */       symbols.setGroupingSeparator(',');
/* 252 */       break;
/*     */     case WHITESPACE: 
/* 254 */       symbols.setGroupingSeparator(' ');
/* 255 */       break;
/*     */     
/*     */     case DEFAULT: 
/*     */       break;
/*     */     
/*     */     case NONE: 
/* 261 */       symbols.setGroupingSeparator('?');
/*     */     }
/*     */     
/*     */     
/* 265 */     return symbols;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String formatCurrency(Number target, Locale locale)
/*     */   {
/* 279 */     Validate.notNull(locale, "Locale cannot be null");
/*     */     
/* 281 */     if (target == null) {
/* 282 */       return null;
/*     */     }
/*     */     
/* 285 */     NumberFormat format = NumberFormat.getCurrencyInstance(locale);
/*     */     
/* 287 */     return format.format(target);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String formatPercent(Number target, Integer minIntegerDigits, Integer fractionDigits, Locale locale)
/*     */   {
/* 304 */     Validate.notNull(fractionDigits, "Fraction digits cannot be null");
/* 305 */     Validate.notNull(locale, "Locale cannot be null");
/*     */     
/* 307 */     if (target == null) {
/* 308 */       return null;
/*     */     }
/*     */     
/* 311 */     NumberFormat format = NumberFormat.getPercentInstance(locale);
/* 312 */     format.setMinimumFractionDigits(fractionDigits.intValue());
/* 313 */     format.setMaximumFractionDigits(fractionDigits.intValue());
/* 314 */     if (minIntegerDigits != null) {
/* 315 */       format.setMinimumIntegerDigits(minIntegerDigits.intValue());
/*     */     }
/*     */     
/* 318 */     return format.format(target);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\util\NumberUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */