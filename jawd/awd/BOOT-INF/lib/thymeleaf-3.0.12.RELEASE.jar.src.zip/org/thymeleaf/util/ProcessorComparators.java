/*     */ package org.thymeleaf.util;
/*     */ 
/*     */ import java.util.Comparator;
/*     */ import org.thymeleaf.dialect.IProcessorDialect;
/*     */ import org.thymeleaf.postprocessor.IPostProcessor;
/*     */ import org.thymeleaf.preprocessor.IPreProcessor;
/*     */ import org.thymeleaf.processor.IProcessor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ProcessorComparators
/*     */ {
/*  37 */   public static final Comparator<IProcessor> PROCESSOR_COMPARATOR = new ProcessorPrecedenceComparator();
/*  38 */   public static final Comparator<IPreProcessor> PRE_PROCESSOR_COMPARATOR = new PreProcessorPrecedenceComparator();
/*  39 */   public static final Comparator<IPostProcessor> POST_PROCESSOR_COMPARATOR = new PostProcessorPrecedenceComparator();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final class ProcessorPrecedenceComparator
/*     */     implements Comparator<IProcessor>
/*     */   {
/*     */     public int compare(IProcessor o1, IProcessor o2)
/*     */     {
/*  59 */       if (o1 == o2)
/*     */       {
/*  61 */         return 0;
/*     */       }
/*  63 */       if (((o1 instanceof ProcessorConfigurationUtils.AbstractProcessorWrapper)) && ((o2 instanceof ProcessorConfigurationUtils.AbstractProcessorWrapper))) {
/*  64 */         return compareWrapped((ProcessorConfigurationUtils.AbstractProcessorWrapper)o1, (ProcessorConfigurationUtils.AbstractProcessorWrapper)o2);
/*     */       }
/*  66 */       int processorPrecedenceComp = compareInts(o1.getPrecedence(), o2.getPrecedence());
/*  67 */       if (processorPrecedenceComp != 0) {
/*  68 */         return processorPrecedenceComp;
/*     */       }
/*  70 */       int classNameComp = o1.getClass().getName().compareTo(o2.getClass().getName());
/*  71 */       if (classNameComp != 0) {
/*  72 */         return classNameComp;
/*     */       }
/*  74 */       return compareInts(System.identityHashCode(o1), System.identityHashCode(o2));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private int compareWrapped(ProcessorConfigurationUtils.AbstractProcessorWrapper o1w, ProcessorConfigurationUtils.AbstractProcessorWrapper o2w)
/*     */     {
/*  83 */       int dialectPrecedenceComp = compareInts(o1w.getDialectPrecedence(), o2w.getDialectPrecedence());
/*  84 */       if (dialectPrecedenceComp != 0) {
/*  85 */         return dialectPrecedenceComp;
/*     */       }
/*     */       
/*  88 */       IProcessor o1 = o1w.unwrap();
/*  89 */       IProcessor o2 = o2w.unwrap();
/*     */       
/*  91 */       int processorPrecedenceComp = compareInts(o1.getPrecedence(), o2.getPrecedence());
/*  92 */       if (processorPrecedenceComp != 0) {
/*  93 */         return processorPrecedenceComp;
/*     */       }
/*  95 */       int classNameComp = o1.getClass().getName().compareTo(o2.getClass().getName());
/*  96 */       if (classNameComp != 0) {
/*  97 */         return classNameComp;
/*     */       }
/*  99 */       return compareInts(System.identityHashCode(o1), System.identityHashCode(o2));
/*     */     }
/*     */     
/*     */ 
/*     */     private static int compareInts(int x, int y)
/*     */     {
/* 105 */       return x == y ? 0 : x < y ? -1 : 1;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final class PreProcessorPrecedenceComparator
/*     */     implements Comparator<IPreProcessor>
/*     */   {
/*     */     public int compare(IPreProcessor o1, IPreProcessor o2)
/*     */     {
/* 122 */       if (o1 == o2)
/*     */       {
/* 124 */         return 0;
/*     */       }
/* 126 */       if (((o1 instanceof ProcessorConfigurationUtils.PreProcessorWrapper)) && ((o2 instanceof ProcessorConfigurationUtils.PreProcessorWrapper))) {
/* 127 */         return compareWrapped((ProcessorConfigurationUtils.PreProcessorWrapper)o1, (ProcessorConfigurationUtils.PreProcessorWrapper)o2);
/*     */       }
/* 129 */       int preProcessorPrecedenceComp = compareInts(o1.getPrecedence(), o2.getPrecedence());
/* 130 */       if (preProcessorPrecedenceComp != 0) {
/* 131 */         return preProcessorPrecedenceComp;
/*     */       }
/* 133 */       int classNameComp = o1.getClass().getName().compareTo(o2.getClass().getName());
/* 134 */       if (classNameComp != 0) {
/* 135 */         return classNameComp;
/*     */       }
/* 137 */       return compareInts(System.identityHashCode(o1), System.identityHashCode(o2));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private int compareWrapped(ProcessorConfigurationUtils.PreProcessorWrapper o1w, ProcessorConfigurationUtils.PreProcessorWrapper o2w)
/*     */     {
/* 146 */       int dialectPrecedenceComp = compareInts(o1w.getDialect().getDialectProcessorPrecedence(), o2w.getDialect().getDialectProcessorPrecedence());
/* 147 */       if (dialectPrecedenceComp != 0) {
/* 148 */         return dialectPrecedenceComp;
/*     */       }
/*     */       
/* 151 */       IPreProcessor o1 = o1w.unwrap();
/* 152 */       IPreProcessor o2 = o2w.unwrap();
/*     */       
/* 154 */       int processorPrecedenceComp = compareInts(o1.getPrecedence(), o2.getPrecedence());
/* 155 */       if (processorPrecedenceComp != 0) {
/* 156 */         return processorPrecedenceComp;
/*     */       }
/* 158 */       int classNameComp = o1.getClass().getName().compareTo(o2.getClass().getName());
/* 159 */       if (classNameComp != 0) {
/* 160 */         return classNameComp;
/*     */       }
/* 162 */       return compareInts(System.identityHashCode(o1), System.identityHashCode(o2));
/*     */     }
/*     */     
/*     */ 
/*     */     private static int compareInts(int x, int y)
/*     */     {
/* 168 */       return x == y ? 0 : x < y ? -1 : 1;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final class PostProcessorPrecedenceComparator
/*     */     implements Comparator<IPostProcessor>
/*     */   {
/*     */     public int compare(IPostProcessor o1, IPostProcessor o2)
/*     */     {
/* 185 */       if (o1 == o2)
/*     */       {
/* 187 */         return 0;
/*     */       }
/* 189 */       if (((o1 instanceof ProcessorConfigurationUtils.PostProcessorWrapper)) && ((o2 instanceof ProcessorConfigurationUtils.PostProcessorWrapper))) {
/* 190 */         return compareWrapped((ProcessorConfigurationUtils.PostProcessorWrapper)o1, (ProcessorConfigurationUtils.PostProcessorWrapper)o2);
/*     */       }
/* 192 */       int postProcessorPrecedenceComp = compareInts(o1.getPrecedence(), o2.getPrecedence());
/* 193 */       if (postProcessorPrecedenceComp != 0) {
/* 194 */         return postProcessorPrecedenceComp;
/*     */       }
/* 196 */       int classNameComp = o1.getClass().getName().compareTo(o2.getClass().getName());
/* 197 */       if (classNameComp != 0) {
/* 198 */         return classNameComp;
/*     */       }
/* 200 */       return compareInts(System.identityHashCode(o1), System.identityHashCode(o2));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private int compareWrapped(ProcessorConfigurationUtils.PostProcessorWrapper o1w, ProcessorConfigurationUtils.PostProcessorWrapper o2w)
/*     */     {
/* 209 */       int dialectPrecedenceComp = compareInts(o1w.getDialect().getDialectProcessorPrecedence(), o2w.getDialect().getDialectProcessorPrecedence());
/* 210 */       if (dialectPrecedenceComp != 0) {
/* 211 */         return dialectPrecedenceComp;
/*     */       }
/*     */       
/* 214 */       IPostProcessor o1 = o1w.unwrap();
/* 215 */       IPostProcessor o2 = o2w.unwrap();
/*     */       
/* 217 */       int processorPrecedenceComp = compareInts(o1.getPrecedence(), o2.getPrecedence());
/* 218 */       if (processorPrecedenceComp != 0) {
/* 219 */         return processorPrecedenceComp;
/*     */       }
/* 221 */       int classNameComp = o1.getClass().getName().compareTo(o2.getClass().getName());
/* 222 */       if (classNameComp != 0) {
/* 223 */         return classNameComp;
/*     */       }
/* 225 */       return compareInts(System.identityHashCode(o1), System.identityHashCode(o2));
/*     */     }
/*     */     
/*     */ 
/*     */     private static int compareInts(int x, int y)
/*     */     {
/* 231 */       return x == y ? 0 : x < y ? -1 : 1;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\util\ProcessorComparators.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */