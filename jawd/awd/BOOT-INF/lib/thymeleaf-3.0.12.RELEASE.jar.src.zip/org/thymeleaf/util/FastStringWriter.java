/*     */ package org.thymeleaf.util;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FastStringWriter
/*     */   extends Writer
/*     */ {
/*     */   private final StringBuilder builder;
/*     */   
/*     */   public FastStringWriter()
/*     */   {
/*  45 */     this.builder = new StringBuilder();
/*     */   }
/*     */   
/*     */ 
/*     */   public FastStringWriter(int initialSize)
/*     */   {
/*  51 */     if (initialSize < 0) {
/*  52 */       throw new IllegalArgumentException("Negative buffer size");
/*     */     }
/*  54 */     this.builder = new StringBuilder(initialSize);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void write(int c)
/*     */   {
/*  62 */     this.builder.append((char)c);
/*     */   }
/*     */   
/*     */ 
/*     */   public void write(String str)
/*     */   {
/*  68 */     this.builder.append(str);
/*     */   }
/*     */   
/*     */ 
/*     */   public void write(String str, int off, int len)
/*     */   {
/*  74 */     this.builder.append(str, off, off + len);
/*     */   }
/*     */   
/*     */ 
/*     */   public void write(char[] cbuf)
/*     */   {
/*  80 */     this.builder.append(cbuf, 0, cbuf.length);
/*     */   }
/*     */   
/*     */ 
/*     */   public void write(char[] cbuf, int off, int len)
/*     */   {
/*  86 */     if ((off < 0) || (off > cbuf.length) || (len < 0) || (off + len > cbuf.length) || (off + len < 0))
/*     */     {
/*  88 */       throw new IndexOutOfBoundsException(); }
/*  89 */     if (len == 0) {
/*  90 */       return;
/*     */     }
/*  92 */     this.builder.append(cbuf, off, len);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void flush()
/*     */     throws IOException
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 111 */     return this.builder.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\util\FastStringWriter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */