/*     */ package org.thymeleaf.util;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PatternSpec
/*     */ {
/*     */   private static final int DEFAULT_PATTERN_SET_SIZE = 3;
/*     */   private LinkedHashSet<String> patternStrs;
/*     */   private LinkedHashSet<Pattern> patterns;
/*     */   
/*     */   public boolean isEmpty()
/*     */   {
/*  63 */     return (this.patterns == null) || (this.patterns.size() == 0);
/*     */   }
/*     */   
/*     */   public Set<String> getPatterns()
/*     */   {
/*  68 */     if (this.patternStrs == null) {
/*  69 */       return Collections.EMPTY_SET;
/*     */     }
/*  71 */     return Collections.unmodifiableSet(this.patternStrs);
/*     */   }
/*     */   
/*     */   public void setPatterns(Set<String> newPatterns)
/*     */   {
/*  76 */     if (newPatterns != null) {
/*  77 */       if (this.patterns == null) {
/*  78 */         this.patternStrs = new LinkedHashSet(3);
/*  79 */         this.patterns = new LinkedHashSet(3);
/*     */       } else {
/*  81 */         this.patternStrs.clear();
/*  82 */         this.patterns.clear();
/*     */       }
/*  84 */       this.patternStrs.addAll(newPatterns);
/*  85 */       for (String pattern : newPatterns) {
/*  86 */         this.patterns.add(PatternUtils.strPatternToPattern(pattern));
/*     */       }
/*  88 */     } else if (this.patterns != null) {
/*  89 */       this.patternStrs.clear();
/*  90 */       this.patterns.clear();
/*     */     }
/*     */   }
/*     */   
/*     */   public void addPattern(String pattern)
/*     */   {
/*  96 */     Validate.notEmpty(pattern, "Pattern cannot be null or empty");
/*  97 */     if (this.patterns == null) {
/*  98 */       this.patternStrs = new LinkedHashSet(3);
/*  99 */       this.patterns = new LinkedHashSet(3);
/*     */     }
/* 101 */     this.patternStrs.add(pattern);
/* 102 */     this.patterns.add(PatternUtils.strPatternToPattern(pattern));
/*     */   }
/*     */   
/*     */   public void clearPatterns()
/*     */   {
/* 107 */     if (this.patterns != null) {
/* 108 */       this.patternStrs.clear();
/* 109 */       this.patterns.clear();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean matches(String templateName)
/*     */   {
/* 117 */     if (this.patterns == null) {
/* 118 */       return false;
/*     */     }
/* 120 */     for (Pattern p : this.patterns) {
/* 121 */       if (p.matcher(templateName).matches()) {
/* 122 */         return true;
/*     */       }
/*     */     }
/* 125 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\util\PatternSpec.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */