/*     */ package org.thymeleaf.util;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ListUtils
/*     */ {
/*     */   public static List<?> toList(Object target)
/*     */   {
/*  42 */     Validate.notNull(target, "Cannot convert null to list");
/*     */     
/*  44 */     if ((target instanceof List)) {
/*  45 */       return (List)target;
/*     */     }
/*     */     
/*  48 */     if (target.getClass().isArray()) {
/*  49 */       return new ArrayList(Arrays.asList((Object[])target));
/*     */     }
/*     */     
/*  52 */     if ((target instanceof Iterable)) {
/*  53 */       List<Object> elements = new ArrayList(10);
/*  54 */       for (Object element : (Iterable)target) {
/*  55 */         elements.add(element);
/*     */       }
/*  57 */       return elements;
/*     */     }
/*     */     
/*     */ 
/*  61 */     throw new IllegalArgumentException("Cannot convert object of class \"" + target.getClass().getName() + "\" to a list");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static int size(List<?> target)
/*     */   {
/*  68 */     Validate.notNull(target, "Cannot get list size of null");
/*  69 */     return target.size();
/*     */   }
/*     */   
/*     */   public static boolean isEmpty(List<?> target)
/*     */   {
/*  74 */     return (target == null) || (target.isEmpty());
/*     */   }
/*     */   
/*     */   public static boolean contains(List<?> target, Object element) {
/*  78 */     Validate.notNull(target, "Cannot execute list contains: target is null");
/*  79 */     return target.contains(element);
/*     */   }
/*     */   
/*     */   public static boolean containsAll(List<?> target, Object[] elements)
/*     */   {
/*  84 */     Validate.notNull(target, "Cannot execute list containsAll: target is null");
/*  85 */     Validate.notNull(elements, "Cannot execute list containsAll: elements is null");
/*  86 */     return containsAll(target, Arrays.asList(elements));
/*     */   }
/*     */   
/*     */   public static boolean containsAll(List<?> target, Collection<?> elements)
/*     */   {
/*  91 */     Validate.notNull(target, "Cannot execute list contains: target is null");
/*  92 */     Validate.notNull(elements, "Cannot execute list containsAll: elements is null");
/*  93 */     return target.containsAll(elements);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static <T extends Comparable<? super T>> List<T> sort(List<T> list)
/*     */   {
/* 108 */     Validate.notNull(list, "Cannot execute list sort: list is null");
/* 109 */     Object[] a = list.toArray();
/* 110 */     Arrays.sort(a);
/*     */     
/* 112 */     return fillNewList(a, list.getClass());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static <T> List<T> sort(List<T> list, Comparator<? super T> c)
/*     */   {
/* 129 */     Validate.notNull(list, "Cannot execute list sort: list is null");
/* 130 */     Object[] a = list.toArray();
/* 131 */     Arrays.sort(a, c);
/*     */     
/* 133 */     return fillNewList(a, list.getClass());
/*     */   }
/*     */   
/*     */   private static <T> List<T> fillNewList(Object[] a, Class<? extends List> listType)
/*     */   {
/*     */     List<T> newList;
/*     */     try
/*     */     {
/* 141 */       newList = (List)listType.getConstructor(new Class[0]).newInstance(new Object[0]);
/*     */     } catch (Exception e) { List<T> newList;
/* 143 */       newList = new ArrayList(a.length + 2);
/*     */     }
/*     */     
/* 146 */     for (Object object : a) {
/* 147 */       newList.add(object);
/*     */     }
/* 149 */     return newList;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\util\ListUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */