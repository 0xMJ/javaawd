/*    */ package org.thymeleaf.util;
/*    */ 
/*    */ import java.math.BigDecimal;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public final class EvaluationUtil
/*    */ {
/*    */   @Deprecated
/*    */   public static boolean evaluateAsBoolean(Object condition)
/*    */   {
/* 39 */     return EvaluationUtils.evaluateAsBoolean(condition);
/*    */   }
/*    */   
/*    */   @Deprecated
/*    */   public static BigDecimal evaluateAsNumber(Object object) {
/* 44 */     return EvaluationUtils.evaluateAsNumber(object);
/*    */   }
/*    */   
/*    */   @Deprecated
/*    */   public static List<Object> evaluateAsList(Object value) {
/* 49 */     return EvaluationUtils.evaluateAsList(value);
/*    */   }
/*    */   
/*    */   @Deprecated
/*    */   public static Object[] evaluateAsArray(Object value) {
/* 54 */     return EvaluationUtils.evaluateAsArray(value);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\util\EvaluationUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */