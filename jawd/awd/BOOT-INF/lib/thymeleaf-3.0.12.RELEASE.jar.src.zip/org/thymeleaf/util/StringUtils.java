/*     */ package org.thymeleaf.util;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Iterator;
/*     */ import java.util.Locale;
/*     */ import java.util.Random;
/*     */ import java.util.StringTokenizer;
/*     */ import org.unbescape.html.HtmlEscape;
/*     */ import org.unbescape.java.JavaEscape;
/*     */ import org.unbescape.javascript.JavaScriptEscape;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class StringUtils
/*     */ {
/*     */   private static final String ALPHA_NUMERIC = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
/*  52 */   private static final Random RANDOM = new Random();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String toString(Object target)
/*     */   {
/*  67 */     if (target == null) {
/*  68 */       return null;
/*     */     }
/*  70 */     return target.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static String abbreviate(Object target, int maxSize)
/*     */   {
/*  77 */     Validate.isTrue(maxSize >= 3, "Maximum size must be greater or equal to 3");
/*     */     
/*  79 */     if (target == null) {
/*  80 */       return null;
/*     */     }
/*     */     
/*  83 */     String str = target.toString();
/*  84 */     if (str.length() <= maxSize) {
/*  85 */       return str;
/*     */     }
/*     */     
/*  88 */     StringBuilder strBuilder = new StringBuilder(maxSize + 2);
/*  89 */     strBuilder.append(str, 0, maxSize - 3);
/*  90 */     strBuilder.append("...");
/*  91 */     return strBuilder.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Boolean equals(Object first, Object second)
/*     */   {
/* 106 */     if ((first == null) && (second == null)) {
/* 107 */       return Boolean.TRUE;
/*     */     }
/* 109 */     if ((first == null) || (second == null)) {
/* 110 */       return Boolean.FALSE;
/*     */     }
/* 112 */     return Boolean.valueOf(first.toString().equals(second.toString()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Boolean equalsIgnoreCase(Object first, Object second)
/*     */   {
/* 124 */     if ((first == null) && (second == null)) {
/* 125 */       return Boolean.TRUE;
/*     */     }
/* 127 */     if ((first == null) || (second == null)) {
/* 128 */       return Boolean.FALSE;
/*     */     }
/* 130 */     return Boolean.valueOf(first.toString().equalsIgnoreCase(second.toString()));
/*     */   }
/*     */   
/*     */   public static Boolean contains(Object target, String fragment)
/*     */   {
/* 135 */     Validate.notNull(target, "Cannot apply contains on null");
/* 136 */     Validate.notNull(fragment, "Fragment cannot be null");
/*     */     
/* 138 */     return Boolean.valueOf(target.toString().contains(fragment));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Boolean containsIgnoreCase(Object target, String fragment, Locale locale)
/*     */   {
/* 146 */     Validate.notNull(target, "Cannot apply containsIgnoreCase on null");
/* 147 */     Validate.notNull(fragment, "Fragment cannot be null");
/* 148 */     Validate.notNull(locale, "Locale cannot be null");
/*     */     
/* 150 */     return Boolean.valueOf(target.toString().toUpperCase(locale).contains(fragment.toUpperCase(locale)));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Boolean startsWith(Object target, String prefix)
/*     */   {
/* 158 */     Validate.notNull(target, "Cannot apply startsWith on null");
/* 159 */     Validate.notNull(prefix, "Prefix cannot be null");
/*     */     
/* 161 */     return Boolean.valueOf(target.toString().startsWith(prefix));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Boolean endsWith(Object target, String suffix)
/*     */   {
/* 169 */     Validate.notNull(target, "Cannot apply endsWith on null");
/* 170 */     Validate.notNull(suffix, "Suffix cannot be null");
/*     */     
/* 172 */     return Boolean.valueOf(target.toString().endsWith(suffix));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String substring(Object target, int beginIndex, int endIndex)
/*     */   {
/* 180 */     if (target == null) {
/* 181 */       return null;
/*     */     }
/* 183 */     Validate.isTrue(beginIndex >= 0, "Begin index must be >= 0");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 188 */     return new String(target.toString().substring(beginIndex, endIndex));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String substring(Object target, int beginIndex)
/*     */   {
/* 206 */     if (target == null) {
/* 207 */       return null;
/*     */     }
/* 209 */     String str = target.toString();
/* 210 */     int len = str.length();
/* 211 */     Validate.isTrue((beginIndex >= 0) && (beginIndex < len), "beginIndex must be >= 0 and < " + len);
/*     */     
/*     */ 
/* 214 */     return str.substring(beginIndex);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static String substringAfter(Object target, String substr)
/*     */   {
/* 221 */     Validate.notNull(substr, "Parameter substring cannot be null");
/*     */     
/* 223 */     if (target == null) {
/* 224 */       return null;
/*     */     }
/*     */     
/* 227 */     String str = target.toString();
/* 228 */     int index = str.indexOf(substr);
/* 229 */     if (index < 0) {
/* 230 */       return null;
/*     */     }
/*     */     
/*     */ 
/* 234 */     return str.substring(index + substr.length());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String substringBefore(Object target, String substr)
/*     */   {
/* 242 */     Validate.notNull(substr, "Parameter substring cannot be null");
/*     */     
/* 244 */     if (target == null) {
/* 245 */       return null;
/*     */     }
/*     */     
/* 248 */     String str = target.toString();
/* 249 */     int index = str.indexOf(substr);
/* 250 */     if (index < 0) {
/* 251 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 257 */     return new String(str.substring(0, index));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static String prepend(Object target, String prefix)
/*     */   {
/* 264 */     Validate.notNull(prefix, "Prefix cannot be null");
/* 265 */     if (target == null) {
/* 266 */       return null;
/*     */     }
/* 268 */     return prefix + target;
/*     */   }
/*     */   
/*     */ 
/*     */   public static String append(Object target, String suffix)
/*     */   {
/* 274 */     Validate.notNull(suffix, "Suffix cannot be null");
/* 275 */     if (target == null) {
/* 276 */       return null;
/*     */     }
/* 278 */     return target + suffix;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String repeat(Object target, int times)
/*     */   {
/* 290 */     if (target == null) {
/* 291 */       return null;
/*     */     }
/* 293 */     String str = target.toString();
/* 294 */     StringBuilder strBuilder = new StringBuilder(str.length() * times + 10);
/* 295 */     for (int i = 0; i < times; i++) {
/* 296 */       strBuilder.append(str);
/*     */     }
/* 298 */     return strBuilder.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String concat(Object... values)
/*     */   {
/* 309 */     return concatReplaceNulls("", values);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String concatReplaceNulls(String nullValue, Object... values)
/*     */   {
/* 321 */     if (values == null) {
/* 322 */       return "";
/*     */     }
/*     */     
/* 325 */     StringBuilder sb = new StringBuilder();
/* 326 */     for (Object value : values) {
/* 327 */       if (value == null) {
/* 328 */         sb.append(nullValue);
/*     */       } else {
/* 330 */         sb.append(value.toString());
/*     */       }
/*     */     }
/*     */     
/* 334 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */   public static Integer indexOf(Object target, String fragment)
/*     */   {
/* 340 */     Validate.notNull(target, "Cannot apply indexOf on null");
/* 341 */     Validate.notNull(fragment, "Fragment cannot be null");
/*     */     
/* 343 */     return Integer.valueOf(target.toString().indexOf(fragment));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isEmpty(String target)
/*     */   {
/* 356 */     return (target == null) || (target.length() == 0);
/*     */   }
/*     */   
/*     */ 
/*     */   public static boolean isEmptyOrWhitespace(String target)
/*     */   {
/* 362 */     if (target == null) {
/* 363 */       return true;
/*     */     }
/* 365 */     int targetLen = target.length();
/* 366 */     if (targetLen == 0) {
/* 367 */       return true;
/*     */     }
/* 369 */     char c0 = target.charAt(0);
/* 370 */     if (((c0 >= 'a') && (c0 <= 'z')) || ((c0 >= 'A') && (c0 <= 'Z')))
/*     */     {
/* 372 */       return false;
/*     */     }
/* 374 */     for (int i = 0; i < targetLen; i++) {
/* 375 */       char c = target.charAt(i);
/* 376 */       if ((c != ' ') && (!Character.isWhitespace(c))) {
/* 377 */         return false;
/*     */       }
/*     */     }
/* 380 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static String join(Object[] target, String separator)
/*     */   {
/* 387 */     Validate.notNull(separator, "Separator cannot be null");
/*     */     
/* 389 */     if (target == null) {
/* 390 */       return null;
/*     */     }
/*     */     
/* 393 */     StringBuilder sb = new StringBuilder();
/* 394 */     if (target.length > 0) {
/* 395 */       sb.append(target[0]);
/* 396 */       for (int i = 1; i < target.length; i++) {
/* 397 */         sb.append(separator);
/* 398 */         sb.append(target[i]);
/*     */       }
/*     */     }
/* 401 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static String join(Iterable<?> target, String separator)
/*     */   {
/* 408 */     Validate.notNull(separator, "Separator cannot be null");
/*     */     
/* 410 */     if (target == null) {
/* 411 */       return null;
/*     */     }
/*     */     
/* 414 */     StringBuilder sb = new StringBuilder();
/* 415 */     Iterator<?> it = target.iterator();
/* 416 */     if (it.hasNext()) {
/* 417 */       sb.append(it.next());
/* 418 */       while (it.hasNext()) {
/* 419 */         sb.append(separator);
/* 420 */         sb.append(it.next());
/*     */       }
/*     */     }
/* 423 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static String join(Iterable<?> target, char separator)
/*     */   {
/* 430 */     if (target == null) {
/* 431 */       return null;
/*     */     }
/*     */     
/* 434 */     StringBuilder sb = new StringBuilder();
/* 435 */     Iterator<?> it = target.iterator();
/* 436 */     if (it.hasNext()) {
/* 437 */       sb.append(it.next());
/* 438 */       while (it.hasNext()) {
/* 439 */         sb.append(separator);
/* 440 */         sb.append(it.next());
/*     */       }
/*     */     }
/* 443 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String[] split(Object target, String separator)
/*     */   {
/* 451 */     Validate.notNull(separator, "Separator cannot be null");
/*     */     
/* 453 */     if (target == null) {
/* 454 */       return null;
/*     */     }
/*     */     
/* 457 */     StringTokenizer strTok = new StringTokenizer(target.toString(), separator);
/* 458 */     int size = strTok.countTokens();
/* 459 */     String[] array = new String[size];
/* 460 */     for (int i = 0; i < size; i++) {
/* 461 */       array[i] = strTok.nextToken();
/*     */     }
/* 463 */     return array;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static Integer length(Object target)
/*     */   {
/* 470 */     Validate.notNull(target, "Cannot apply length on null");
/*     */     
/* 472 */     return Integer.valueOf(target.toString().length());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String replace(Object target, String before, String after)
/*     */   {
/* 480 */     Validate.notNull(before, "Parameter \"before\" cannot be null");
/* 481 */     Validate.notNull(after, "Parameter \"after\" cannot be null");
/*     */     
/* 483 */     if (target == null) {
/* 484 */       return null;
/*     */     }
/*     */     
/* 487 */     String targetStr = target.toString();
/* 488 */     int targetStrLen = targetStr.length();
/* 489 */     int beforeLen = before.length();
/*     */     
/* 491 */     if ((targetStrLen == 0) || (beforeLen == 0)) {
/* 492 */       return targetStr;
/*     */     }
/*     */     
/* 495 */     int index = targetStr.indexOf(before);
/* 496 */     if (index < 0) {
/* 497 */       return targetStr;
/*     */     }
/*     */     
/* 500 */     StringBuilder stringBuilder = new StringBuilder(targetStrLen + 10);
/*     */     
/* 502 */     int lastPos = 0;
/* 503 */     while (index >= 0)
/*     */     {
/* 505 */       stringBuilder.append(targetStr, lastPos, index);
/* 506 */       stringBuilder.append(after);
/* 507 */       lastPos = index + beforeLen;
/* 508 */       index = targetStr.indexOf(before, lastPos);
/*     */     }
/*     */     
/*     */ 
/* 512 */     stringBuilder.append(targetStr, lastPos, targetStrLen);
/*     */     
/* 514 */     return stringBuilder.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String toUpperCase(Object target, Locale locale)
/*     */   {
/* 522 */     Validate.notNull(locale, "Locale cannot be null");
/*     */     
/* 524 */     if (target == null) {
/* 525 */       return null;
/*     */     }
/* 527 */     return target.toString().toUpperCase(locale);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String toLowerCase(Object target, Locale locale)
/*     */   {
/* 535 */     Validate.notNull(locale, "Locale cannot be null");
/*     */     
/* 537 */     if (target == null) {
/* 538 */       return null;
/*     */     }
/* 540 */     return target.toString().toLowerCase(locale);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static String trim(Object target)
/*     */   {
/* 547 */     if (target == null) {
/* 548 */       return null;
/*     */     }
/* 550 */     return target.toString().trim();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String pack(String target)
/*     */   {
/* 564 */     if (target == null) {
/* 565 */       return null;
/*     */     }
/* 567 */     int targetLen = target.length();
/* 568 */     StringBuilder strBuilder = null;
/*     */     
/* 570 */     for (int i = 0; i < targetLen; i++) {
/* 571 */       char c = target.charAt(i);
/* 572 */       if ((Character.isWhitespace(c)) || (c <= ' ')) {
/* 573 */         if (strBuilder == null) {
/* 574 */           strBuilder = new StringBuilder();
/* 575 */           strBuilder.append(target, 0, i);
/*     */         }
/*     */       }
/* 578 */       else if (strBuilder != null) {
/* 579 */         strBuilder.append(c);
/*     */       }
/*     */     }
/*     */     
/* 583 */     return strBuilder == null ? target.toLowerCase() : strBuilder.toString().toLowerCase();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String capitalize(Object target)
/*     */   {
/* 599 */     if (target == null) {
/* 600 */       return null;
/*     */     }
/* 602 */     StringBuilder result = new StringBuilder(target.toString());
/* 603 */     if (result.length() > 0) {
/* 604 */       result.setCharAt(0, Character.toTitleCase(result.charAt(0)));
/*     */     }
/* 606 */     return result.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String unCapitalize(Object target)
/*     */   {
/* 624 */     if (target == null) {
/* 625 */       return null;
/*     */     }
/* 627 */     StringBuilder result = new StringBuilder(target.toString());
/*     */     
/* 629 */     if (result.length() > 0) {
/* 630 */       result.setCharAt(0, Character.toLowerCase(result.charAt(0)));
/*     */     }
/*     */     
/* 633 */     return result.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static int findNextWord(char[] buffer, int idx, char[] delimiterChars)
/*     */   {
/* 640 */     int len = buffer.length;
/*     */     
/* 642 */     if ((idx < 0) || (idx >= len)) {
/* 643 */       return -1;
/*     */     }
/*     */     
/* 646 */     boolean foundDelimiters = idx == 0;
/* 647 */     int i = idx;
/* 648 */     while (i < len) {
/* 649 */       char ch = buffer[i];
/*     */       
/*     */ 
/*     */ 
/* 653 */       boolean isDelimiter = Arrays.binarySearch(delimiterChars, ch) >= 0 ? true : delimiterChars == null ? Character.isWhitespace(ch) : false;
/* 654 */       if (isDelimiter) {
/* 655 */         foundDelimiters = true;
/*     */       }
/* 657 */       else if (foundDelimiters) {
/* 658 */         return i;
/*     */       }
/*     */       
/* 661 */       i++;
/*     */     }
/*     */     
/* 664 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String capitalizeWords(Object target)
/*     */   {
/* 685 */     return capitalizeWords(target, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String capitalizeWords(Object target, Object delimiters)
/*     */   {
/* 706 */     if (target == null) {
/* 707 */       return null;
/*     */     }
/*     */     
/* 710 */     char[] buffer = target.toString().toCharArray();
/*     */     
/* 712 */     char[] delimiterChars = delimiters == null ? null : delimiters.toString().toCharArray();
/* 713 */     if (delimiterChars != null)
/*     */     {
/* 715 */       Arrays.sort(delimiterChars);
/*     */     }
/*     */     
/* 718 */     int idx = 0;
/*     */     
/* 720 */     idx = findNextWord(buffer, idx, delimiterChars);
/* 721 */     while (idx != -1) {
/* 722 */       buffer[idx] = Character.toTitleCase(buffer[idx]);
/* 723 */       idx++;
/* 724 */       idx = findNextWord(buffer, idx, delimiterChars);
/*     */     }
/*     */     
/* 727 */     return new String(buffer);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String escapeXml(Object target)
/*     */   {
/* 743 */     if (target == null) {
/* 744 */       return null;
/*     */     }
/* 746 */     return HtmlEscape.escapeHtml4Xml(target.toString());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String escapeJavaScript(Object target)
/*     */   {
/* 761 */     if (target == null) {
/* 762 */       return null;
/*     */     }
/* 764 */     return JavaScriptEscape.escapeJavaScript(target.toString());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String escapeJava(Object target)
/*     */   {
/* 779 */     if (target == null) {
/* 780 */       return null;
/*     */     }
/* 782 */     return JavaEscape.escapeJava(target.toString());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String unescapeJavaScript(Object target)
/*     */   {
/* 797 */     if (target == null) {
/* 798 */       return null;
/*     */     }
/* 800 */     return JavaScriptEscape.unescapeJavaScript(target.toString());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String unescapeJava(Object target)
/*     */   {
/* 815 */     if (target == null) {
/* 816 */       return null;
/*     */     }
/* 818 */     return JavaEscape.unescapeJava(target.toString());
/*     */   }
/*     */   
/*     */ 
/*     */   public static String randomAlphanumeric(int count)
/*     */   {
/* 824 */     StringBuilder strBuilder = new StringBuilder(count);
/* 825 */     int anLen = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ".length();
/* 826 */     synchronized (RANDOM) {
/* 827 */       for (int i = 0; i < count; i++) {
/* 828 */         strBuilder.append("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ".charAt(RANDOM.nextInt(anLen)));
/*     */       }
/*     */     }
/* 831 */     return strBuilder.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\util\StringUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */