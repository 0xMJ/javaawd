/*     */ package org.thymeleaf.util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class VersionUtils
/*     */ {
/*     */   public static VersionSpec parseVersion(String version)
/*     */   {
/*  37 */     return parseVersion(version, null);
/*     */   }
/*     */   
/*     */ 
/*     */   public static VersionSpec parseVersion(String version, String buildTimestamp)
/*     */   {
/*  43 */     if ((version == null) || (version.trim().length() == 0))
/*     */     {
/*     */ 
/*  46 */       return new VersionSpec(buildTimestamp, null);
/*     */     }
/*     */     
/*     */ 
/*     */     try
/*     */     {
/*  52 */       String ver = version.trim();
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  58 */       int endOfNumericVersionIdx = findEndOfNumericVersion(ver);
/*  59 */       String qualifier; String numVer; Character qualifierSeparator; String qualifier; if (endOfNumericVersionIdx < 0) {
/*  60 */         String numVer = ver;
/*  61 */         Character qualifierSeparator = null;
/*  62 */         qualifier = null;
/*     */       } else {
/*  64 */         numVer = ver.substring(0, endOfNumericVersionIdx);
/*  65 */         char c = ver.charAt(endOfNumericVersionIdx);
/*  66 */         String qualifier; if (Character.isLetter(c)) {
/*  67 */           Character qualifierSeparator = null;
/*  68 */           qualifier = ver.substring(endOfNumericVersionIdx);
/*     */         } else {
/*  70 */           qualifierSeparator = Character.valueOf(ver.charAt(endOfNumericVersionIdx));
/*  71 */           qualifier = ver.substring(endOfNumericVersionIdx + 1);
/*  72 */           if ((qualifier == null) || (qualifier.trim().length() == 0))
/*     */           {
/*  74 */             return new VersionSpec(buildTimestamp, null);
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  84 */       int separator1Idx = numVer.indexOf('.');
/*  85 */       Integer patch; int major; Integer minor; Integer patch; if (separator1Idx < 0) {
/*  86 */         int major = Integer.parseInt(numVer);
/*  87 */         Integer minor = null;
/*  88 */         patch = null;
/*     */       } else {
/*  90 */         major = Integer.parseInt(numVer.substring(0, separator1Idx));
/*  91 */         int separator2Idx = numVer.indexOf('.', separator1Idx + 1);
/*  92 */         Integer patch; if (separator2Idx < 0) {
/*  93 */           Integer minor = Integer.valueOf(numVer.substring(separator1Idx + 1));
/*  94 */           patch = null;
/*     */         } else {
/*  96 */           minor = Integer.valueOf(numVer.substring(separator1Idx + 1, separator2Idx));
/*  97 */           patch = Integer.valueOf(numVer.substring(separator2Idx + 1));
/*     */         }
/*     */       }
/*     */       
/* 101 */       return new VersionSpec(major, minor, patch, qualifierSeparator, qualifier, buildTimestamp, null);
/*     */     }
/*     */     catch (Exception e) {}
/*     */     
/* 105 */     return new VersionSpec(buildTimestamp, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static int findEndOfNumericVersion(CharSequence sequence)
/*     */   {
/* 114 */     int seqLen = sequence.length();
/*     */     
/* 116 */     for (int i = 0; i < seqLen; i++) {
/* 117 */       char c = sequence.charAt(i);
/* 118 */       if ((c != '.') && (!Character.isDigit(c))) {
/* 119 */         if ((i > 1) && (sequence.charAt(i - 1) == '.')) {
/* 120 */           return i - 1;
/*     */         }
/* 122 */         return i;
/*     */       }
/*     */     }
/* 125 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static final class VersionSpec
/*     */   {
/*     */     private static final String UNKNOWN_VERSION = "UNKNOWN";
/*     */     
/*     */ 
/*     */     private boolean unknown;
/*     */     
/*     */ 
/*     */     private int major;
/*     */     
/*     */ 
/*     */     private int minor;
/*     */     
/*     */ 
/*     */     private int patch;
/*     */     
/*     */ 
/*     */     private String qualifier;
/*     */     
/*     */     private String buildTimestamp;
/*     */     
/*     */     private String versionCore;
/*     */     
/*     */     private String version;
/*     */     
/*     */     private String fullVersion;
/*     */     
/*     */ 
/*     */     private VersionSpec(String buildTimestamp)
/*     */     {
/* 160 */       this.unknown = true;
/*     */       
/* 162 */       this.major = 0;
/* 163 */       this.minor = 0;
/* 164 */       this.patch = 0;
/* 165 */       this.qualifier = null;
/* 166 */       this.buildTimestamp = buildTimestamp;
/*     */       
/* 168 */       this.versionCore = "UNKNOWN";
/* 169 */       this.version = this.versionCore;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 174 */       this.fullVersion = (this.buildTimestamp != null ? String.format("%s (%s)", new Object[] { this.version, this.buildTimestamp }) : this.version);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private VersionSpec(int major, Integer minor, Integer patch, Character qualifierSeparator, String qualifier, String buildTimestamp)
/*     */     {
/* 186 */       Validate.isTrue(major >= 0, "Major version must be >= 0");
/* 187 */       Validate.isTrue((minor == null) || (minor.intValue() >= 0), "Minor version must be >= 0");
/* 188 */       Validate.isTrue((patch == null) || (patch.intValue() >= 0), "Patch version must be >= 0");
/* 189 */       Validate.isTrue((patch == null) || (minor != null), "Patch version present without minor");
/*     */       
/* 191 */       this.unknown = false;
/*     */       
/* 193 */       this.major = major;
/* 194 */       this.minor = (minor != null ? minor.intValue() : 0);
/* 195 */       this.patch = (patch != null ? patch.intValue() : 0);
/* 196 */       this.qualifier = qualifier;
/* 197 */       this.buildTimestamp = buildTimestamp;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 203 */       this.versionCore = (minor != null ? String.format("%d.%d", new Object[] { Integer.valueOf(major), minor }) : patch != null ? String.format("%d.%d.%d", new Object[] { Integer.valueOf(major), minor, patch }) : String.valueOf(major));
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 210 */       this.version = (qualifierSeparator != null ? String.format("%s%c%s", new Object[] { this.versionCore, qualifierSeparator, qualifier }) : qualifier == null ? this.versionCore : String.format("%s%s", new Object[] { this.versionCore, qualifier }));
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 215 */       this.fullVersion = (buildTimestamp != null ? String.format("%s (%s)", new Object[] { this.version, this.buildTimestamp }) : this.version);
/*     */     }
/*     */     
/*     */     public boolean isUnknown()
/*     */     {
/* 220 */       return this.unknown;
/*     */     }
/*     */     
/*     */     public int getMajor() {
/* 224 */       return this.major;
/*     */     }
/*     */     
/*     */     public int getMinor() {
/* 228 */       return this.minor;
/*     */     }
/*     */     
/*     */     public int getPatch() {
/* 232 */       return this.patch;
/*     */     }
/*     */     
/*     */     public boolean hasQualifier() {
/* 236 */       return this.qualifier != null;
/*     */     }
/*     */     
/*     */     public String getQualifier() {
/* 240 */       return this.qualifier;
/*     */     }
/*     */     
/*     */     public String getVersionCore() {
/* 244 */       return this.versionCore;
/*     */     }
/*     */     
/*     */     public String getVersion() {
/* 248 */       return this.version;
/*     */     }
/*     */     
/*     */     public boolean hasBuildTimestamp() {
/* 252 */       return this.buildTimestamp != null;
/*     */     }
/*     */     
/*     */     public String getBuildTimestamp() {
/* 256 */       return this.buildTimestamp;
/*     */     }
/*     */     
/*     */     public String getFullVersion() {
/* 260 */       return this.fullVersion;
/*     */     }
/*     */     
/*     */     public boolean isAtLeast(int major) {
/* 264 */       return isAtLeast(major, 0);
/*     */     }
/*     */     
/*     */     public boolean isAtLeast(int major, int minor) {
/* 268 */       return isAtLeast(major, minor, 0);
/*     */     }
/*     */     
/*     */     public boolean isAtLeast(int major, int minor, int patch) {
/* 272 */       return (this.major > major) || ((this.major == major) && (this.minor > minor)) || ((this.major == major) && (this.minor == minor) && (this.patch >= patch));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\util\VersionUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */