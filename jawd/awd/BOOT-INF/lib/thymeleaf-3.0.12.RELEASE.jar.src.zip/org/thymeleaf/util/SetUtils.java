/*     */ package org.thymeleaf.util;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SetUtils
/*     */ {
/*     */   public static Set<?> toSet(Object target)
/*     */   {
/*  43 */     Validate.notNull(target, "Cannot convert null to set");
/*     */     
/*  45 */     if ((target instanceof Set)) {
/*  46 */       return (Set)target;
/*     */     }
/*     */     
/*  49 */     if (target.getClass().isArray()) {
/*  50 */       return new LinkedHashSet(Arrays.asList((Object[])target));
/*     */     }
/*     */     
/*  53 */     if ((target instanceof Iterable)) {
/*  54 */       Set<Object> elements = new LinkedHashSet();
/*  55 */       for (Object element : (Iterable)target) {
/*  56 */         elements.add(element);
/*     */       }
/*  58 */       return elements;
/*     */     }
/*     */     
/*     */ 
/*  62 */     throw new IllegalArgumentException("Cannot convert object of class \"" + target.getClass().getName() + "\" to a set");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static int size(Set<?> target)
/*     */   {
/*  69 */     Validate.notNull(target, "Cannot get set size of null");
/*  70 */     return target.size();
/*     */   }
/*     */   
/*     */   public static boolean isEmpty(Set<?> target)
/*     */   {
/*  75 */     return (target == null) || (target.isEmpty());
/*     */   }
/*     */   
/*     */   public static boolean contains(Set<?> target, Object element) {
/*  79 */     Validate.notNull(target, "Cannot execute set contains: target is null");
/*  80 */     return target.contains(element);
/*     */   }
/*     */   
/*     */   public static boolean containsAll(Set<?> target, Object[] elements)
/*     */   {
/*  85 */     Validate.notNull(target, "Cannot execute set containsAll: target is null");
/*  86 */     Validate.notNull(elements, "Cannot execute set containsAll: elements is null");
/*  87 */     return containsAll(target, Arrays.asList(elements));
/*     */   }
/*     */   
/*     */   public static boolean containsAll(Set<?> target, Collection<?> elements)
/*     */   {
/*  92 */     Validate.notNull(target, "Cannot execute set contains: target is null");
/*  93 */     Validate.notNull(elements, "Cannot execute set containsAll: elements is null");
/*  94 */     return target.containsAll(elements);
/*     */   }
/*     */   
/*     */ 
/*     */   public static <X> Set<X> singletonSet(X element)
/*     */   {
/* 100 */     Set<X> set = new HashSet(2, 1.0F);
/* 101 */     set.add(element);
/* 102 */     return Collections.unmodifiableSet(set);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\util\SetUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */