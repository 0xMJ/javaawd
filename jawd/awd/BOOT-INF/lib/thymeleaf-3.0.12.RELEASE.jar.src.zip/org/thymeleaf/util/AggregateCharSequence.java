/*     */ package org.thymeleaf.util;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Serializable;
/*     */ import java.io.Writer;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AggregateCharSequence
/*     */   implements Serializable, IWritableCharSequence
/*     */ {
/*     */   protected static final long serialVersionUID = 823987612L;
/*  60 */   private static final int[] UNIQUE_ZERO_OFFSET = { 0 };
/*     */   
/*     */ 
/*     */   private final CharSequence[] values;
/*     */   
/*     */ 
/*     */   private final int[] offsets;
/*     */   
/*     */ 
/*     */   private final int length;
/*     */   
/*     */   private int hash;
/*     */   
/*     */ 
/*     */   public AggregateCharSequence(CharSequence component)
/*     */   {
/*  76 */     if (component == null) {
/*  77 */       throw new IllegalArgumentException("Component argument is null, which is forbidden");
/*     */     }
/*     */     
/*  80 */     this.values = new CharSequence[] { component };
/*  81 */     this.offsets = UNIQUE_ZERO_OFFSET;
/*  82 */     this.length = component.length();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AggregateCharSequence(CharSequence component0, CharSequence component1)
/*     */   {
/*  91 */     if ((component0 == null) || (component1 == null)) {
/*  92 */       throw new IllegalArgumentException("At least one component argument is null, which is forbidden");
/*     */     }
/*     */     
/*  95 */     this.values = new CharSequence[] { component0, component1 };
/*  96 */     this.offsets = new int[] { 0, component0.length() };
/*  97 */     this.length = (this.offsets[1] + component1.length());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AggregateCharSequence(CharSequence component0, CharSequence component1, CharSequence component2)
/*     */   {
/* 106 */     if ((component0 == null) || (component1 == null) || (component2 == null)) {
/* 107 */       throw new IllegalArgumentException("At least one component argument is null, which is forbidden");
/*     */     }
/*     */     
/* 110 */     this.values = new CharSequence[] { component0, component1, component2 };
/* 111 */     this.offsets = new int[] { 0, component0.length(), component0.length() + component1.length() };
/* 112 */     this.length = (this.offsets[2] + component2.length());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AggregateCharSequence(CharSequence component0, CharSequence component1, CharSequence component2, CharSequence component3)
/*     */   {
/* 121 */     if ((component0 == null) || (component1 == null) || (component2 == null) || (component3 == null)) {
/* 122 */       throw new IllegalArgumentException("At least one component argument is null, which is forbidden");
/*     */     }
/*     */     
/* 125 */     this.values = new CharSequence[] { component0, component1, component2, component3 };
/* 126 */     this.offsets = new int[] { 0, component0.length(), component0.length() + component1.length(), component0.length() + component1.length() + component2.length() };
/* 127 */     this.length = (this.offsets[3] + component3.length());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AggregateCharSequence(CharSequence component0, CharSequence component1, CharSequence component2, CharSequence component3, CharSequence component4)
/*     */   {
/* 136 */     if ((component0 == null) || (component1 == null) || (component2 == null) || (component3 == null) || (component4 == null)) {
/* 137 */       throw new IllegalArgumentException("At least one component argument is null, which is forbidden");
/*     */     }
/*     */     
/* 140 */     this.values = new CharSequence[] { component0, component1, component2, component3, component4 };
/* 141 */     this.offsets = new int[] { 0, component0.length(), component0.length() + component1.length(), component0.length() + component1.length() + component2.length(), component0.length() + component1.length() + component2.length() + component3.length() };
/* 142 */     this.length = (this.offsets[4] + component3.length());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AggregateCharSequence(CharSequence[] components)
/*     */   {
/* 155 */     if (components == null) {
/* 156 */       throw new IllegalArgumentException("Components argument array cannot be null");
/*     */     }
/*     */     
/* 159 */     if (components.length == 0)
/*     */     {
/*     */ 
/* 162 */       this.values = new CharSequence[] { "" };
/* 163 */       this.offsets = UNIQUE_ZERO_OFFSET;
/* 164 */       this.length = 0;
/*     */     }
/*     */     else
/*     */     {
/* 168 */       this.values = new CharSequence[components.length];
/* 169 */       this.offsets = new int[components.length];
/*     */       
/* 171 */       int totalLength = 0;
/* 172 */       int i = 0;
/* 173 */       while (i < components.length) {
/* 174 */         if (components[i] == null) {
/* 175 */           throw new IllegalArgumentException("Components argument contains at least a null, which is forbidden");
/*     */         }
/* 177 */         int componentLen = components[i].length();
/* 178 */         this.values[i] = components[i];
/* 179 */         this.offsets[i] = (i == 0 ? 0 : this.offsets[(i - 1)] + this.values[(i - 1)].length());
/* 180 */         totalLength += componentLen;
/* 181 */         i++;
/*     */       }
/*     */       
/* 184 */       this.length = totalLength;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AggregateCharSequence(List<? extends CharSequence> components)
/*     */   {
/* 196 */     if (components == null) {
/* 197 */       throw new IllegalArgumentException("Components argument array cannot be null");
/*     */     }
/*     */     
/* 200 */     int componentsSize = components.size();
/*     */     
/* 202 */     if (componentsSize == 0)
/*     */     {
/*     */ 
/* 205 */       this.values = new CharSequence[] { "" };
/* 206 */       this.offsets = UNIQUE_ZERO_OFFSET;
/* 207 */       this.length = 0;
/*     */     }
/*     */     else
/*     */     {
/* 211 */       this.values = new CharSequence[componentsSize];
/* 212 */       this.offsets = new int[componentsSize];
/*     */       
/* 214 */       int totalLength = 0;
/* 215 */       int i = 0;
/* 216 */       while (i < componentsSize) {
/* 217 */         CharSequence element = (CharSequence)components.get(i);
/* 218 */         if (element == null) {
/* 219 */           throw new IllegalArgumentException("Components argument contains at least a null, which is forbidden");
/*     */         }
/* 221 */         int componentLen = element.length();
/* 222 */         this.values[i] = element;
/* 223 */         this.offsets[i] = (i == 0 ? 0 : this.offsets[(i - 1)] + this.values[(i - 1)].length());
/* 224 */         totalLength += componentLen;
/* 225 */         i++;
/*     */       }
/*     */       
/* 228 */       this.length = totalLength;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int length()
/*     */   {
/* 238 */     return this.length;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public char charAt(int index)
/*     */   {
/* 245 */     if ((index < 0) || (index >= this.length)) {
/* 246 */       throw new StringIndexOutOfBoundsException(index);
/*     */     }
/* 248 */     int n = this.values.length;
/* 249 */     while (n-- != 0) {
/* 250 */       if (this.offsets[n] <= index) {
/* 251 */         return this.values[n].charAt(index - this.offsets[n]);
/*     */       }
/*     */     }
/*     */     
/* 255 */     throw new IllegalStateException("Bad computing of charAt at AggregatedString");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public CharSequence subSequence(int beginIndex, int endIndex)
/*     */   {
/* 263 */     if (beginIndex < 0) {
/* 264 */       throw new StringIndexOutOfBoundsException(beginIndex);
/*     */     }
/* 266 */     if (endIndex > this.length) {
/* 267 */       throw new StringIndexOutOfBoundsException(endIndex);
/*     */     }
/* 269 */     int subLen = endIndex - beginIndex;
/* 270 */     if (subLen < 0) {
/* 271 */       throw new StringIndexOutOfBoundsException(subLen);
/*     */     }
/*     */     
/* 274 */     if (subLen == 0) {
/* 275 */       return "";
/*     */     }
/*     */     
/* 278 */     int n1 = this.values.length;
/* 279 */     while (n1-- != 0) {
/* 280 */       if (this.offsets[n1] < endIndex) {
/*     */         break;
/*     */       }
/*     */     }
/* 284 */     int n0 = n1 + 1;
/* 285 */     while (n0-- != 0) {
/* 286 */       if (this.offsets[n0] <= beginIndex) {
/*     */         break;
/*     */       }
/*     */     }
/* 290 */     if (n0 == n1)
/*     */     {
/* 292 */       return this.values[n0].subSequence(beginIndex - this.offsets[n0], endIndex - this.offsets[n0]);
/*     */     }
/* 294 */     char[] chars = new char[endIndex - beginIndex];
/* 295 */     int charsOffset = 0;
/* 296 */     int nx = n0;
/* 297 */     while (nx <= n1) {
/* 298 */       int nstart = Math.max(beginIndex, this.offsets[nx]) - this.offsets[nx];
/* 299 */       int nend = Math.min(endIndex, this.offsets[nx] + this.values[nx].length()) - this.offsets[nx];
/* 300 */       copyChars(this.values[nx], nstart, nend, chars, charsOffset);
/* 301 */       charsOffset += nend - nstart;
/* 302 */       nx++;
/*     */     }
/* 304 */     return new String(chars);
/*     */   }
/*     */   
/*     */ 
/*     */   public void write(Writer writer)
/*     */     throws IOException
/*     */   {
/* 311 */     if (writer == null) {
/* 312 */       throw new IllegalArgumentException("Writer cannot be null");
/*     */     }
/* 314 */     for (int i = 0; i < this.values.length; i++) {
/* 315 */       writer.write(this.values[i].toString());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/* 325 */     if (this == o) {
/* 326 */       return true;
/*     */     }
/*     */     
/* 329 */     if (!(o instanceof AggregateCharSequence)) {
/* 330 */       return false;
/*     */     }
/*     */     
/* 333 */     AggregateCharSequence that = (AggregateCharSequence)o;
/*     */     
/* 335 */     if ((this.values.length == 1) && (that.values.length == 1) && 
/* 336 */       ((this.values[0] instanceof String)) && ((that.values[0] instanceof String))) {
/* 337 */       return this.values[0].equals(that.values[0]);
/*     */     }
/*     */     
/*     */ 
/* 341 */     if (this.length != that.length) {
/* 342 */       return false;
/*     */     }
/*     */     
/* 345 */     if (this.length == 0) {
/* 346 */       return true;
/*     */     }
/*     */     
/* 349 */     if ((this.hash != 0) && (that.hash != 0) && (this.hash != that.hash)) {
/* 350 */       return false;
/*     */     }
/*     */     
/* 353 */     int i = 0;
/*     */     
/* 355 */     int m1 = 0;
/* 356 */     int n1 = 0;
/* 357 */     int len1 = this.values[m1].length();
/*     */     
/* 359 */     int m2 = 0;
/* 360 */     int n2 = 0;
/* 361 */     int len2 = that.values[m2].length();
/*     */     
/* 363 */     while (i < this.length)
/*     */     {
/*     */ 
/* 366 */       while ((n1 >= len1) && (m1 + 1 < this.values.length)) {
/* 367 */         m1++;n1 = 0;
/* 368 */         len1 = this.values[m1].length();
/*     */       }
/* 370 */       while ((n2 >= len2) && (m2 + 1 < that.values.length)) {
/* 371 */         m2++;n2 = 0;
/* 372 */         len2 = that.values[m2].length();
/*     */       }
/*     */       
/*     */ 
/* 376 */       if ((n1 == 0) && (n2 == 0) && (len1 == len2) && ((this.values[m1] instanceof String)) && ((that.values[m2] instanceof String))) {
/* 377 */         if (!this.values[m1].equals(that.values[m2])) {
/* 378 */           return false;
/*     */         }
/* 380 */         n1 = len1;
/* 381 */         n2 = len2;
/* 382 */         i += len1;
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 387 */         if (this.values[m1].charAt(n1) != that.values[m2].charAt(n2)) {
/* 388 */           return false;
/*     */         }
/*     */         
/* 391 */         n1++;
/* 392 */         n2++;
/* 393 */         i++;
/*     */       }
/*     */     }
/*     */     
/* 397 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 413 */     int h = this.hash;
/* 414 */     if ((h == 0) && (this.length > 0)) {
/* 415 */       if (this.values.length == 1) {
/* 416 */         h = this.values[0].hashCode();
/*     */       } else {
/* 418 */         CharSequence[] vals = this.values;
/*     */         
/*     */ 
/* 421 */         for (int x = 0; x < vals.length; x++) {
/* 422 */           CharSequence val = vals[x];
/* 423 */           int valLen = val.length();
/* 424 */           for (int i = 0; i < valLen; i++) {
/* 425 */             h = 31 * h + val.charAt(i);
/*     */           }
/*     */         }
/*     */       }
/* 429 */       this.hash = h;
/*     */     }
/* 431 */     return h;
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public boolean contentEquals(StringBuffer sb)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_1
/*     */     //   1: dup
/*     */     //   2: astore_2
/*     */     //   3: monitorenter
/*     */     //   4: aload_0
/*     */     //   5: aload_1
/*     */     //   6: invokevirtual 36	org/thymeleaf/util/AggregateCharSequence:contentEquals	(Ljava/lang/CharSequence;)Z
/*     */     //   9: aload_2
/*     */     //   10: monitorexit
/*     */     //   11: ireturn
/*     */     //   12: astore_3
/*     */     //   13: aload_2
/*     */     //   14: monitorexit
/*     */     //   15: aload_3
/*     */     //   16: athrow
/*     */     // Line number table:
/*     */     //   Java source line #439	-> byte code offset #0
/*     */     //   Java source line #440	-> byte code offset #4
/*     */     //   Java source line #441	-> byte code offset #12
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	17	0	this	AggregateCharSequence
/*     */     //   0	17	1	sb	StringBuffer
/*     */     //   2	12	2	Ljava/lang/Object;	Object
/*     */     //   12	4	3	localObject1	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   4	11	12	finally
/*     */     //   12	15	12	finally
/*     */   }
/*     */   
/*     */   public boolean contentEquals(CharSequence cs)
/*     */   {
/* 447 */     if (this.length != cs.length()) {
/* 448 */       return false;
/*     */     }
/*     */     
/* 451 */     if (this.length == 0) {
/* 452 */       return true;
/*     */     }
/*     */     
/*     */ 
/* 456 */     if (cs.equals(this)) {
/* 457 */       return true;
/*     */     }
/*     */     
/* 460 */     if ((cs instanceof String)) {
/* 461 */       if ((this.values.length == 1) && ((this.values[0] instanceof String))) {
/* 462 */         return this.values[0].equals(cs);
/*     */       }
/* 464 */       if ((this.hash != 0) && (this.hash != cs.hashCode())) {
/* 465 */         return false;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 470 */     int i = 0;
/*     */     
/* 472 */     int m1 = 0;
/* 473 */     int n1 = 0;
/* 474 */     int len1 = this.values[m1].length();
/*     */     
/* 476 */     while (i < this.length)
/*     */     {
/*     */ 
/* 479 */       while ((n1 >= len1) && (m1 + 1 < this.values.length)) {
/* 480 */         m1++;n1 = 0;
/* 481 */         len1 = this.values[m1].length();
/*     */       }
/*     */       
/*     */ 
/* 485 */       if (this.values[m1].charAt(n1) != cs.charAt(i)) {
/* 486 */         return false;
/*     */       }
/*     */       
/* 489 */       n1++;
/* 490 */       i++;
/*     */     }
/*     */     
/* 493 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 502 */     if (this.length == 0) {
/* 503 */       return "";
/*     */     }
/* 505 */     if (this.values.length == 1) {
/* 506 */       return this.values[0].toString();
/*     */     }
/* 508 */     char[] chars = new char[this.length];
/* 509 */     for (int i = 0; i < this.values.length; i++) {
/* 510 */       copyChars(this.values[i], 0, this.values[i].length(), chars, this.offsets[i]);
/*     */     }
/* 512 */     return new String(chars);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void copyChars(CharSequence src, int srcBegin, int srcEnd, char[] dst, int dstBegin)
/*     */   {
/* 522 */     if ((src instanceof String)) {
/* 523 */       ((String)src).getChars(srcBegin, srcEnd, dst, dstBegin);
/* 524 */       return;
/*     */     }
/*     */     
/* 527 */     int i = srcBegin;
/* 528 */     while (i < srcEnd) {
/* 529 */       dst[(dstBegin + (i - srcBegin))] = src.charAt(i);
/* 530 */       i++;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\util\AggregateCharSequence.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */