/*    */ package org.thymeleaf.util;
/*    */ 
/*    */ import java.util.Collection;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Validate
/*    */ {
/*    */   public static void notNull(Object object, String message)
/*    */   {
/* 36 */     if (object == null) {
/* 37 */       throw new IllegalArgumentException(message);
/*    */     }
/*    */   }
/*    */   
/*    */   public static void notEmpty(String object, String message) {
/* 42 */     if (StringUtils.isEmptyOrWhitespace(object)) {
/* 43 */       throw new IllegalArgumentException(message);
/*    */     }
/*    */   }
/*    */   
/*    */   public static void notEmpty(Collection<?> object, String message) {
/* 48 */     if ((object == null) || (object.size() == 0)) {
/* 49 */       throw new IllegalArgumentException(message);
/*    */     }
/*    */   }
/*    */   
/*    */   public static void notEmpty(Object[] object, String message) {
/* 54 */     if ((object == null) || (object.length == 0)) {
/* 55 */       throw new IllegalArgumentException(message);
/*    */     }
/*    */   }
/*    */   
/*    */   public static void containsNoNulls(Iterable<?> collection, String message) {
/* 60 */     for (Object object : collection) {
/* 61 */       notNull(object, message);
/*    */     }
/*    */   }
/*    */   
/*    */   public static void containsNoEmpties(Iterable<String> collection, String message) {
/* 66 */     for (String object : collection) {
/* 67 */       notEmpty(object, message);
/*    */     }
/*    */   }
/*    */   
/*    */   public static void containsNoNulls(Object[] array, String message) {
/* 72 */     for (Object object : array) {
/* 73 */       notNull(object, message);
/*    */     }
/*    */   }
/*    */   
/*    */   public static void isTrue(boolean condition, String message) {
/* 78 */     if (!condition) {
/* 79 */       throw new IllegalArgumentException(message);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\util\Validate.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */