/*     */ package org.thymeleaf.util;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.math.RoundingMode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AggregateUtils
/*     */ {
/*     */   public static BigDecimal sum(Iterable<? extends Number> target)
/*     */   {
/*  48 */     Validate.notNull(target, "Cannot aggregate on null");
/*  49 */     Validate.containsNoNulls(target, "Cannot aggregate on iterable containing nulls");
/*  50 */     BigDecimal total = BigDecimal.ZERO;
/*  51 */     int size = 0;
/*  52 */     for (Number element : target) {
/*  53 */       total = total.add(toBigDecimal(element));
/*  54 */       size++;
/*     */     }
/*  56 */     if (size == 0) {
/*  57 */       return null;
/*     */     }
/*  59 */     return total;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static BigDecimal sum(Object[] target)
/*     */   {
/*  72 */     Validate.notNull(target, "Cannot aggregate on null");
/*  73 */     Validate.containsNoNulls(target, "Cannot aggregate on array containing nulls");
/*  74 */     if (target.length == 0) {
/*  75 */       return null;
/*     */     }
/*  77 */     BigDecimal total = BigDecimal.ZERO;
/*  78 */     for (Object element : target) {
/*  79 */       total = total.add(toBigDecimal((Number)element));
/*     */     }
/*  81 */     return total;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static BigDecimal sum(byte[] target)
/*     */   {
/*  94 */     Validate.notNull(target, "Cannot aggregate on null");
/*  95 */     if (target.length == 0) {
/*  96 */       return null;
/*     */     }
/*  98 */     BigDecimal total = BigDecimal.ZERO;
/*  99 */     for (byte element : target) {
/* 100 */       total = total.add(toBigDecimal(element));
/*     */     }
/* 102 */     return total;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static BigDecimal sum(short[] target)
/*     */   {
/* 115 */     Validate.notNull(target, "Cannot aggregate on null");
/* 116 */     if (target.length == 0) {
/* 117 */       return null;
/*     */     }
/* 119 */     BigDecimal total = BigDecimal.ZERO;
/* 120 */     for (short element : target) {
/* 121 */       total = total.add(toBigDecimal(element));
/*     */     }
/* 123 */     return total;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static BigDecimal sum(int[] target)
/*     */   {
/* 136 */     Validate.notNull(target, "Cannot aggregate on null");
/* 137 */     if (target.length == 0) {
/* 138 */       return null;
/*     */     }
/* 140 */     BigDecimal total = BigDecimal.ZERO;
/* 141 */     for (int element : target) {
/* 142 */       total = total.add(toBigDecimal(element));
/*     */     }
/* 144 */     return total;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static BigDecimal sum(long[] target)
/*     */   {
/* 157 */     Validate.notNull(target, "Cannot aggregate on null");
/* 158 */     if (target.length == 0) {
/* 159 */       return null;
/*     */     }
/* 161 */     BigDecimal total = BigDecimal.ZERO;
/* 162 */     for (long element : target) {
/* 163 */       total = total.add(toBigDecimal(element));
/*     */     }
/* 165 */     return total;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static BigDecimal sum(float[] target)
/*     */   {
/* 178 */     Validate.notNull(target, "Cannot aggregate on null");
/* 179 */     if (target.length == 0) {
/* 180 */       return null;
/*     */     }
/* 182 */     BigDecimal total = BigDecimal.ZERO;
/* 183 */     for (float element : target) {
/* 184 */       total = total.add(toBigDecimal(element));
/*     */     }
/* 186 */     return total;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static BigDecimal sum(double[] target)
/*     */   {
/* 199 */     Validate.notNull(target, "Cannot aggregate on null");
/* 200 */     if (target.length == 0) {
/* 201 */       return null;
/*     */     }
/* 203 */     BigDecimal total = BigDecimal.ZERO;
/* 204 */     for (double element : target) {
/* 205 */       total = total.add(toBigDecimal(element));
/*     */     }
/* 207 */     return total;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static BigDecimal avg(Iterable<? extends Number> target)
/*     */   {
/* 227 */     Validate.notNull(target, "Cannot aggregate on null");
/* 228 */     Validate.containsNoNulls(target, "Cannot aggregate on array containing nulls");
/* 229 */     BigDecimal total = BigDecimal.ZERO;
/* 230 */     int size = 0;
/* 231 */     for (Number element : target) {
/* 232 */       total = total.add(toBigDecimal(element));
/* 233 */       size++;
/*     */     }
/* 235 */     if (size == 0) {
/* 236 */       return null;
/*     */     }
/* 238 */     BigDecimal divisor = BigDecimal.valueOf(size);
/*     */     try {
/* 240 */       return total.divide(divisor);
/*     */     }
/*     */     catch (ArithmeticException e) {}
/*     */     
/*     */ 
/* 245 */     return total.divide(divisor, Math.max(total.scale(), 10), RoundingMode.HALF_UP);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static BigDecimal avg(Object[] target)
/*     */   {
/* 259 */     Validate.notNull(target, "Cannot aggregate on null");
/* 260 */     Validate.containsNoNulls(target, "Cannot aggregate on array containing nulls");
/* 261 */     if (target.length == 0) {
/* 262 */       return null;
/*     */     }
/* 264 */     BigDecimal total = BigDecimal.ZERO;
/* 265 */     for (Object element : target) {
/* 266 */       total = total.add(toBigDecimal((Number)element));
/*     */     }
/* 268 */     BigDecimal divisor = BigDecimal.valueOf(target.length);
/*     */     try {
/* 270 */       return total.divide(divisor);
/*     */     }
/*     */     catch (ArithmeticException e) {}
/*     */     
/*     */ 
/* 275 */     return total.divide(divisor, Math.max(total.scale(), 10), RoundingMode.HALF_UP);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static BigDecimal avg(byte[] target)
/*     */   {
/* 289 */     Validate.notNull(target, "Cannot aggregate on null");
/* 290 */     if (target.length == 0) {
/* 291 */       return null;
/*     */     }
/* 293 */     BigDecimal total = BigDecimal.ZERO;
/* 294 */     for (byte element : target) {
/* 295 */       total = total.add(toBigDecimal(element));
/*     */     }
/* 297 */     BigDecimal divisor = BigDecimal.valueOf(target.length);
/*     */     try {
/* 299 */       return total.divide(divisor);
/*     */     }
/*     */     catch (ArithmeticException e) {}
/*     */     
/*     */ 
/* 304 */     return total.divide(divisor, Math.max(total.scale(), 10), RoundingMode.HALF_UP);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static BigDecimal avg(short[] target)
/*     */   {
/* 318 */     Validate.notNull(target, "Cannot aggregate on null");
/* 319 */     if (target.length == 0) {
/* 320 */       return null;
/*     */     }
/* 322 */     BigDecimal total = BigDecimal.ZERO;
/* 323 */     for (short element : target) {
/* 324 */       total = total.add(toBigDecimal(element));
/*     */     }
/* 326 */     BigDecimal divisor = BigDecimal.valueOf(target.length);
/*     */     try {
/* 328 */       return total.divide(divisor);
/*     */     }
/*     */     catch (ArithmeticException e) {}
/*     */     
/*     */ 
/* 333 */     return total.divide(divisor, Math.max(total.scale(), 10), RoundingMode.HALF_UP);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static BigDecimal avg(int[] target)
/*     */   {
/* 347 */     Validate.notNull(target, "Cannot aggregate on null");
/* 348 */     if (target.length == 0) {
/* 349 */       return null;
/*     */     }
/* 351 */     BigDecimal total = BigDecimal.ZERO;
/* 352 */     for (int element : target) {
/* 353 */       total = total.add(toBigDecimal(element));
/*     */     }
/* 355 */     BigDecimal divisor = BigDecimal.valueOf(target.length);
/*     */     try {
/* 357 */       return total.divide(divisor);
/*     */     }
/*     */     catch (ArithmeticException e) {}
/*     */     
/*     */ 
/* 362 */     return total.divide(divisor, Math.max(total.scale(), 10), RoundingMode.HALF_UP);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static BigDecimal avg(long[] target)
/*     */   {
/* 376 */     Validate.notNull(target, "Cannot aggregate on null");
/* 377 */     if (target.length == 0) {
/* 378 */       return null;
/*     */     }
/* 380 */     BigDecimal total = BigDecimal.ZERO;
/* 381 */     for (long element : target) {
/* 382 */       total = total.add(toBigDecimal(element));
/*     */     }
/* 384 */     BigDecimal divisor = BigDecimal.valueOf(target.length);
/*     */     try {
/* 386 */       return total.divide(divisor);
/*     */     }
/*     */     catch (ArithmeticException e) {}
/*     */     
/*     */ 
/* 391 */     return total.divide(divisor, Math.max(total.scale(), 10), RoundingMode.HALF_UP);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static BigDecimal avg(float[] target)
/*     */   {
/* 405 */     Validate.notNull(target, "Cannot aggregate on null");
/* 406 */     if (target.length == 0) {
/* 407 */       return null;
/*     */     }
/* 409 */     BigDecimal total = BigDecimal.ZERO;
/* 410 */     for (float element : target) {
/* 411 */       total = total.add(toBigDecimal(element));
/*     */     }
/* 413 */     BigDecimal divisor = BigDecimal.valueOf(target.length);
/*     */     try {
/* 415 */       return total.divide(divisor);
/*     */     }
/*     */     catch (ArithmeticException e) {}
/*     */     
/*     */ 
/* 420 */     return total.divide(divisor, Math.max(total.scale(), 10), RoundingMode.HALF_UP);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static BigDecimal avg(double[] target)
/*     */   {
/* 434 */     Validate.notNull(target, "Cannot aggregate on null");
/* 435 */     if (target.length == 0) {
/* 436 */       return null;
/*     */     }
/* 438 */     BigDecimal total = BigDecimal.ZERO;
/* 439 */     for (double element : target) {
/* 440 */       total = total.add(toBigDecimal(element));
/*     */     }
/* 442 */     BigDecimal divisor = BigDecimal.valueOf(target.length);
/*     */     try {
/* 444 */       return total.divide(divisor);
/*     */     }
/*     */     catch (ArithmeticException e) {}
/*     */     
/*     */ 
/* 449 */     return total.divide(divisor, Math.max(total.scale(), 10), RoundingMode.HALF_UP);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static BigDecimal toBigDecimal(Number number)
/*     */   {
/* 464 */     Validate.notNull(number, "Cannot convert null to BigDecimal");
/*     */     
/* 466 */     if ((number instanceof BigDecimal)) {
/* 467 */       return (BigDecimal)number;
/*     */     }
/*     */     
/* 470 */     if ((number instanceof BigInteger)) {
/* 471 */       return new BigDecimal((BigInteger)number);
/*     */     }
/*     */     
/* 474 */     if (((number instanceof Byte)) || ((number instanceof Short)) || ((number instanceof Integer)) || ((number instanceof Long)))
/*     */     {
/*     */ 
/*     */ 
/* 478 */       return BigDecimal.valueOf(number.longValue());
/*     */     }
/* 480 */     return BigDecimal.valueOf(number.doubleValue());
/*     */   }
/*     */   
/*     */   private static BigDecimal toBigDecimal(byte number)
/*     */   {
/* 485 */     return BigDecimal.valueOf(number);
/*     */   }
/*     */   
/*     */   private static BigDecimal toBigDecimal(short number) {
/* 489 */     return BigDecimal.valueOf(number);
/*     */   }
/*     */   
/*     */   private static BigDecimal toBigDecimal(int number) {
/* 493 */     return BigDecimal.valueOf(number);
/*     */   }
/*     */   
/*     */   private static BigDecimal toBigDecimal(long number) {
/* 497 */     return BigDecimal.valueOf(number);
/*     */   }
/*     */   
/*     */   private static BigDecimal toBigDecimal(float number) {
/* 501 */     return BigDecimal.valueOf(number);
/*     */   }
/*     */   
/*     */   private static BigDecimal toBigDecimal(double number) {
/* 505 */     return BigDecimal.valueOf(number);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\util\AggregateUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */