/*    */ package org.thymeleaf.util;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.Writer;
/*    */ import org.thymeleaf.IEngineConfiguration;
/*    */ import org.thymeleaf.context.ITemplateContext;
/*    */ import org.thymeleaf.engine.TemplateManager;
/*    */ import org.thymeleaf.engine.TemplateModel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class LazyProcessingCharSequence
/*    */   extends AbstractLazyCharSequence
/*    */ {
/*    */   private final ITemplateContext context;
/*    */   private final TemplateModel templateModel;
/*    */   
/*    */   public LazyProcessingCharSequence(ITemplateContext context, TemplateModel templateModel)
/*    */   {
/* 60 */     if (context == null) {
/* 61 */       throw new IllegalArgumentException("Template Context is null, which is forbidden");
/*    */     }
/* 63 */     if (templateModel == null) {
/* 64 */       throw new IllegalArgumentException("Template Model is null, which is forbidden");
/*    */     }
/*    */     
/* 67 */     this.context = context;
/* 68 */     this.templateModel = templateModel;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected String resolveText()
/*    */   {
/* 77 */     Writer stringWriter = new FastStringWriter();
/* 78 */     this.context.getConfiguration().getTemplateManager().process(this.templateModel, this.context, stringWriter);
/* 79 */     return stringWriter.toString();
/*    */   }
/*    */   
/*    */   protected void writeUnresolved(Writer writer)
/*    */     throws IOException
/*    */   {
/* 85 */     this.context.getConfiguration().getTemplateManager().process(this.templateModel, this.context, writer);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\util\LazyProcessingCharSequence.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */