/*    */ package org.thymeleaf.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class LoggingUtils
/*    */ {
/*    */   public static String loggifyTemplateName(String template)
/*    */   {
/* 36 */     if (template == null) {
/* 37 */       return null;
/*    */     }
/* 39 */     if (template.length() <= 120) {
/* 40 */       return template.replace('\n', ' ');
/*    */     }
/* 42 */     StringBuilder strBuilder = new StringBuilder();
/* 43 */     strBuilder.append(template.substring(0, 35).replace('\n', ' '));
/* 44 */     strBuilder.append("[...]");
/* 45 */     strBuilder.append(template.substring(template.length() - 80).replace('\n', ' '));
/* 46 */     return strBuilder.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\util\LoggingUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */