/*    */ package org.thymeleaf.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum NumberPointType
/*    */ {
/* 35 */   POINT("POINT"), 
/* 36 */   COMMA("COMMA"), 
/* 37 */   WHITESPACE("WHITESPACE"), 
/* 38 */   NONE("NONE"), 
/* 39 */   DEFAULT("DEFAULT");
/*    */   
/*    */ 
/*    */ 
/*    */   private final String name;
/*    */   
/*    */ 
/*    */   public static NumberPointType match(String name)
/*    */   {
/* 48 */     if ("NONE".equals(name)) {
/* 49 */       return NONE;
/*    */     }
/* 51 */     if ("DEFAULT".equals(name)) {
/* 52 */       return DEFAULT;
/*    */     }
/* 54 */     if ("POINT".equals(name)) {
/* 55 */       return POINT;
/*    */     }
/* 57 */     if ("COMMA".equals(name)) {
/* 58 */       return COMMA;
/*    */     }
/* 60 */     if ("WHITESPACE".equals(name)) {
/* 61 */       return WHITESPACE;
/*    */     }
/* 63 */     return null;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   private NumberPointType(String name)
/*    */   {
/* 70 */     this.name = name;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 74 */     return this.name;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 79 */     return this.name;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\util\NumberPointType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */