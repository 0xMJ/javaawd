/*     */ package org.thymeleaf.util;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractLazyCharSequence
/*     */   implements IWritableCharSequence
/*     */ {
/*  51 */   private String resolvedText = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract String resolveText();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String getText()
/*     */   {
/*  67 */     if (this.resolvedText == null) {
/*  68 */       this.resolvedText = resolveText();
/*     */     }
/*  70 */     return this.resolvedText;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final int length()
/*     */   {
/*  77 */     return getText().length();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final char charAt(int index)
/*     */   {
/*  84 */     return getText().charAt(index);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final CharSequence subSequence(int beginIndex, int endIndex)
/*     */   {
/*  91 */     return getText().subSequence(beginIndex, endIndex);
/*     */   }
/*     */   
/*     */   public final void write(Writer writer)
/*     */     throws IOException
/*     */   {
/*  97 */     if (writer == null) {
/*  98 */       throw new IllegalArgumentException("Writer cannot be null");
/*     */     }
/* 100 */     if (this.resolvedText != null) {
/* 101 */       writer.write(this.resolvedText);
/*     */     } else {
/* 103 */       writeUnresolved(writer);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected abstract void writeUnresolved(Writer paramWriter)
/*     */     throws IOException;
/*     */   
/*     */ 
/*     */ 
/*     */   public final boolean equals(Object o)
/*     */   {
/* 116 */     if (this == o) {
/* 117 */       return true;
/*     */     }
/*     */     
/* 120 */     if ((o == null) || (getClass() != o.getClass())) {
/* 121 */       return false;
/*     */     }
/*     */     
/* 124 */     AbstractLazyCharSequence that = (AbstractLazyCharSequence)o;
/*     */     
/* 126 */     return getText().equals(that.getText());
/*     */   }
/*     */   
/*     */ 
/*     */   public final int hashCode()
/*     */   {
/* 132 */     return getText().hashCode();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final String toString()
/*     */   {
/* 140 */     return getText();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\util\AbstractLazyCharSequence.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */