/*     */ package org.thymeleaf.util;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.text.DateFormat;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.TimeZone;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DateUtils
/*     */ {
/*  42 */   private static final Map<DateFormatKey, DateFormat> dateFormats = new ConcurrentHashMap(4, 0.9F, 2);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  53 */   private static final SimpleDateFormat ISO8601_DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZZZ");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Calendar create(Object year, Object month, Object day)
/*     */   {
/*  69 */     return create(year, month, day, null, null, null, null, null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Calendar create(Object year, Object month, Object day, Object hour, Object minute)
/*     */   {
/*  85 */     return create(year, month, day, hour, minute, null, null, null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Calendar create(Object year, Object month, Object day, Object hour, Object minute, Object second)
/*     */   {
/* 102 */     return create(year, month, day, hour, minute, second, null, null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Calendar create(Object year, Object month, Object day, Object hour, Object minute, Object second, Object millisecond)
/*     */   {
/* 120 */     return create(year, month, day, hour, minute, second, millisecond, null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Calendar create(Object year, Object month, Object day, Object hour, Object minute, Object second, Object millisecond, Object timeZone)
/*     */   {
/* 140 */     return create(year, month, day, hour, minute, second, millisecond, timeZone, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Calendar create(Object year, Object month, Object day, Object hour, Object minute, Object second, Object millisecond, Object timeZone, Locale locale)
/*     */   {
/* 164 */     BigDecimal nYear = year == null ? null : EvaluationUtils.evaluateAsNumber(year);
/*     */     
/*     */ 
/* 167 */     BigDecimal nMonth = month == null ? null : EvaluationUtils.evaluateAsNumber(month);
/*     */     
/*     */ 
/* 170 */     BigDecimal nDay = day == null ? null : EvaluationUtils.evaluateAsNumber(day);
/*     */     
/*     */ 
/* 173 */     BigDecimal nHour = hour == null ? null : EvaluationUtils.evaluateAsNumber(hour);
/*     */     
/*     */ 
/* 176 */     BigDecimal nMinute = minute == null ? null : EvaluationUtils.evaluateAsNumber(minute);
/*     */     
/*     */ 
/* 179 */     BigDecimal nSecond = second == null ? null : EvaluationUtils.evaluateAsNumber(second);
/*     */     
/*     */ 
/* 182 */     BigDecimal nMillisecond = millisecond == null ? null : EvaluationUtils.evaluateAsNumber(millisecond);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 188 */     TimeZone tzTimeZone = timeZone != null ? TimeZone.getTimeZone(timeZone.toString()) : (timeZone instanceof TimeZone) ? (TimeZone)timeZone : null;
/*     */     Calendar cal;
/*     */     Calendar cal;
/* 191 */     if ((tzTimeZone != null) && (locale != null)) {
/* 192 */       cal = Calendar.getInstance(tzTimeZone, locale); } else { Calendar cal;
/* 193 */       if (tzTimeZone != null) {
/* 194 */         cal = Calendar.getInstance(tzTimeZone); } else { Calendar cal;
/* 195 */         if (locale != null) {
/* 196 */           cal = Calendar.getInstance(locale);
/*     */         } else
/* 198 */           cal = Calendar.getInstance();
/*     */       }
/*     */     }
/* 201 */     if ((nYear == null) || (nMonth == null) || (nDay == null)) {
/* 202 */       throw new IllegalArgumentException("Cannot create Calendar/Date object with null year (" + nYear + "), month (" + nMonth + ") or day (" + nDay + ")");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 207 */     cal.set(1, nYear.intValue());
/* 208 */     cal.set(2, nMonth.intValue() - 1);
/* 209 */     cal.set(5, nDay.intValue());
/* 210 */     cal.set(11, 0);
/* 211 */     cal.set(12, 0);
/* 212 */     cal.set(13, 0);
/* 213 */     cal.set(14, 0);
/*     */     
/* 215 */     if ((nHour != null) && (nMinute != null))
/*     */     {
/* 217 */       cal.set(11, nHour.intValue());
/* 218 */       cal.set(12, nMinute.intValue());
/*     */       
/* 220 */       if (nSecond != null)
/*     */       {
/* 222 */         cal.set(13, nSecond.intValue());
/*     */         
/* 224 */         if (nMillisecond != null)
/*     */         {
/* 226 */           cal.set(14, nMillisecond.intValue());
/*     */         }
/*     */         
/*     */       }
/* 230 */       else if (nMillisecond != null)
/*     */       {
/* 232 */         throw new IllegalArgumentException("Calendar/Date object cannot be correctly created from a null second but non-null millisecond.");
/*     */       }
/*     */       
/*     */     }
/*     */     else
/*     */     {
/* 238 */       if ((nHour != null) || (nMinute != null))
/*     */       {
/* 240 */         throw new IllegalArgumentException("Calendar/Date object can only be correctly created if hour (" + nHour + ") and minute (" + nMinute + ") are either both null or non-null.");
/*     */       }
/*     */       
/*     */ 
/* 244 */       if ((nSecond != null) || (nMillisecond != null))
/*     */       {
/* 246 */         throw new IllegalArgumentException("Calendar/Date object cannot be correctly created from a null hour and minute but non-null second and/or millisecond.");
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 253 */     return cal;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Calendar createNow()
/*     */   {
/* 264 */     return createNow(null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Calendar createNow(Object timeZone)
/*     */   {
/* 275 */     return createNow(timeZone, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Calendar createNow(Object timeZone, Locale locale)
/*     */   {
/* 292 */     TimeZone tzTimeZone = timeZone != null ? TimeZone.getTimeZone(timeZone.toString()) : (timeZone instanceof TimeZone) ? (TimeZone)timeZone : null;
/*     */     
/* 294 */     if ((tzTimeZone != null) && (locale != null)) {
/* 295 */       return Calendar.getInstance(tzTimeZone, locale);
/*     */     }
/* 297 */     if (tzTimeZone != null) {
/* 298 */       return Calendar.getInstance(tzTimeZone);
/*     */     }
/* 300 */     if (locale != null) {
/* 301 */       return Calendar.getInstance(locale);
/*     */     }
/* 303 */     return Calendar.getInstance();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Calendar createToday()
/*     */   {
/* 315 */     return createToday(null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Calendar createToday(Object timeZone)
/*     */   {
/* 327 */     return createToday(timeZone, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Calendar createToday(Object timeZone, Locale locale)
/*     */   {
/* 340 */     Calendar cal = createNow(timeZone, locale);
/* 341 */     cal.set(14, 0);
/* 342 */     cal.set(13, 0);
/* 343 */     cal.set(12, 0);
/* 344 */     cal.set(11, 0);
/* 345 */     return cal;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static String format(Object target, Locale locale)
/*     */   {
/* 352 */     if (target == null) {
/* 353 */       return null;
/*     */     }
/* 355 */     return formatDate(target, locale);
/*     */   }
/*     */   
/*     */   public static String format(Object target, String pattern, Locale locale) {
/* 359 */     Validate.notEmpty(pattern, "Pattern cannot be null or empty");
/* 360 */     if (target == null) {
/* 361 */       return null;
/*     */     }
/* 363 */     return formatDate(target, pattern, locale);
/*     */   }
/*     */   
/*     */   public static Integer day(Object target)
/*     */   {
/* 368 */     if (target == null) {
/* 369 */       return null;
/*     */     }
/* 371 */     Calendar cal = normalizeDate(target);
/* 372 */     return Integer.valueOf(cal.get(5));
/*     */   }
/*     */   
/*     */   public static Integer month(Object target)
/*     */   {
/* 377 */     if (target == null) {
/* 378 */       return null;
/*     */     }
/* 380 */     Calendar cal = normalizeDate(target);
/* 381 */     return Integer.valueOf(cal.get(2) + 1);
/*     */   }
/*     */   
/*     */   public static String monthName(Object target, Locale locale)
/*     */   {
/* 386 */     if (target == null) {
/* 387 */       return null;
/*     */     }
/* 389 */     return format(target, "MMMM", locale);
/*     */   }
/*     */   
/*     */   public static String monthNameShort(Object target, Locale locale)
/*     */   {
/* 394 */     if (target == null) {
/* 395 */       return null;
/*     */     }
/* 397 */     return format(target, "MMM", locale);
/*     */   }
/*     */   
/*     */   public static Integer year(Object target)
/*     */   {
/* 402 */     if (target == null) {
/* 403 */       return null;
/*     */     }
/* 405 */     Calendar cal = normalizeDate(target);
/* 406 */     return Integer.valueOf(cal.get(1));
/*     */   }
/*     */   
/*     */   public static Integer dayOfWeek(Object target)
/*     */   {
/* 411 */     if (target == null) {
/* 412 */       return null;
/*     */     }
/* 414 */     Calendar cal = normalizeDate(target);
/* 415 */     return Integer.valueOf(cal.get(7));
/*     */   }
/*     */   
/*     */   public static String dayOfWeekName(Object target, Locale locale)
/*     */   {
/* 420 */     if (target == null) {
/* 421 */       return null;
/*     */     }
/* 423 */     return format(target, "EEEE", locale);
/*     */   }
/*     */   
/*     */   public static String dayOfWeekNameShort(Object target, Locale locale)
/*     */   {
/* 428 */     if (target == null) {
/* 429 */       return null;
/*     */     }
/* 431 */     return format(target, "EEE", locale);
/*     */   }
/*     */   
/*     */   public static Integer hour(Object target)
/*     */   {
/* 436 */     if (target == null) {
/* 437 */       return null;
/*     */     }
/* 439 */     Calendar cal = normalizeDate(target);
/* 440 */     return Integer.valueOf(cal.get(11));
/*     */   }
/*     */   
/*     */   public static Integer minute(Object target)
/*     */   {
/* 445 */     if (target == null) {
/* 446 */       return null;
/*     */     }
/* 448 */     Calendar cal = normalizeDate(target);
/* 449 */     return Integer.valueOf(cal.get(12));
/*     */   }
/*     */   
/*     */   public static Integer second(Object target)
/*     */   {
/* 454 */     if (target == null) {
/* 455 */       return null;
/*     */     }
/* 457 */     Calendar cal = normalizeDate(target);
/* 458 */     return Integer.valueOf(cal.get(13));
/*     */   }
/*     */   
/*     */   public static Integer millisecond(Object target)
/*     */   {
/* 463 */     if (target == null) {
/* 464 */       return null;
/*     */     }
/* 466 */     Calendar cal = normalizeDate(target);
/* 467 */     return Integer.valueOf(cal.get(14));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Calendar normalizeDate(Object target)
/*     */   {
/* 476 */     if (target == null) {
/* 477 */       return null;
/*     */     }
/* 479 */     if ((target instanceof Calendar))
/* 480 */       return (Calendar)target;
/* 481 */     if ((target instanceof Date)) {
/* 482 */       Calendar cal = Calendar.getInstance();
/* 483 */       cal.setTimeInMillis(((Date)target).getTime());
/* 484 */       return cal;
/*     */     }
/*     */     
/* 487 */     throw new IllegalArgumentException("Cannot normalize class \"" + target.getClass().getName() + "\" as a date");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static String formatDate(Object target, Locale locale)
/*     */   {
/* 496 */     if (target == null) {
/* 497 */       return null;
/*     */     }
/* 499 */     return formatDate(target, null, locale);
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   private static String formatDate(Object target, String pattern, Locale locale)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_2
/*     */     //   1: ldc 50
/*     */     //   3: invokestatic 51	org/thymeleaf/util/Validate:notNull	(Ljava/lang/Object;Ljava/lang/String;)V
/*     */     //   6: aload_0
/*     */     //   7: ifnonnull +5 -> 12
/*     */     //   10: aconst_null
/*     */     //   11: areturn
/*     */     //   12: new 52	org/thymeleaf/util/DateUtils$DateFormatKey
/*     */     //   15: dup
/*     */     //   16: aload_0
/*     */     //   17: aload_1
/*     */     //   18: aload_2
/*     */     //   19: invokespecial 53	org/thymeleaf/util/DateUtils$DateFormatKey:<init>	(Ljava/lang/Object;Ljava/lang/String;Ljava/util/Locale;)V
/*     */     //   22: astore_3
/*     */     //   23: getstatic 54	org/thymeleaf/util/DateUtils:dateFormats	Ljava/util/Map;
/*     */     //   26: aload_3
/*     */     //   27: invokeinterface 55 2 0
/*     */     //   32: checkcast 56	java/text/DateFormat
/*     */     //   35: astore 4
/*     */     //   37: aload 4
/*     */     //   39: ifnonnull +60 -> 99
/*     */     //   42: aload_1
/*     */     //   43: invokestatic 57	org/thymeleaf/util/StringUtils:isEmptyOrWhitespace	(Ljava/lang/String;)Z
/*     */     //   46: ifeq +14 -> 60
/*     */     //   49: iconst_1
/*     */     //   50: iconst_1
/*     */     //   51: aload_2
/*     */     //   52: invokestatic 58	java/text/DateFormat:getDateTimeInstance	(IILjava/util/Locale;)Ljava/text/DateFormat;
/*     */     //   55: astore 4
/*     */     //   57: goto +14 -> 71
/*     */     //   60: new 59	java/text/SimpleDateFormat
/*     */     //   63: dup
/*     */     //   64: aload_1
/*     */     //   65: aload_2
/*     */     //   66: invokespecial 60	java/text/SimpleDateFormat:<init>	(Ljava/lang/String;Ljava/util/Locale;)V
/*     */     //   69: astore 4
/*     */     //   71: aload_3
/*     */     //   72: getfield 61	org/thymeleaf/util/DateUtils$DateFormatKey:timeZone	Ljava/util/TimeZone;
/*     */     //   75: ifnull +12 -> 87
/*     */     //   78: aload 4
/*     */     //   80: aload_3
/*     */     //   81: getfield 61	org/thymeleaf/util/DateUtils$DateFormatKey:timeZone	Ljava/util/TimeZone;
/*     */     //   84: invokevirtual 62	java/text/DateFormat:setTimeZone	(Ljava/util/TimeZone;)V
/*     */     //   87: getstatic 54	org/thymeleaf/util/DateUtils:dateFormats	Ljava/util/Map;
/*     */     //   90: aload_3
/*     */     //   91: aload 4
/*     */     //   93: invokeinterface 63 3 0
/*     */     //   98: pop
/*     */     //   99: aload_0
/*     */     //   100: instanceof 21
/*     */     //   103: ifeq +33 -> 136
/*     */     //   106: aload 4
/*     */     //   108: dup
/*     */     //   109: astore 5
/*     */     //   111: monitorenter
/*     */     //   112: aload 4
/*     */     //   114: aload_0
/*     */     //   115: checkcast 21	java/util/Calendar
/*     */     //   118: invokevirtual 64	java/util/Calendar:getTime	()Ljava/util/Date;
/*     */     //   121: invokevirtual 65	java/text/DateFormat:format	(Ljava/util/Date;)Ljava/lang/String;
/*     */     //   124: aload 5
/*     */     //   126: monitorexit
/*     */     //   127: areturn
/*     */     //   128: astore 6
/*     */     //   130: aload 5
/*     */     //   132: monitorexit
/*     */     //   133: aload 6
/*     */     //   135: athrow
/*     */     //   136: aload_0
/*     */     //   137: instanceof 43
/*     */     //   140: ifeq +30 -> 170
/*     */     //   143: aload 4
/*     */     //   145: dup
/*     */     //   146: astore 5
/*     */     //   148: monitorenter
/*     */     //   149: aload 4
/*     */     //   151: aload_0
/*     */     //   152: checkcast 43	java/util/Date
/*     */     //   155: invokevirtual 65	java/text/DateFormat:format	(Ljava/util/Date;)Ljava/lang/String;
/*     */     //   158: aload 5
/*     */     //   160: monitorexit
/*     */     //   161: areturn
/*     */     //   162: astore 7
/*     */     //   164: aload 5
/*     */     //   166: monitorexit
/*     */     //   167: aload 7
/*     */     //   169: athrow
/*     */     //   170: new 10	java/lang/IllegalArgumentException
/*     */     //   173: dup
/*     */     //   174: new 11	java/lang/StringBuilder
/*     */     //   177: dup
/*     */     //   178: invokespecial 12	java/lang/StringBuilder:<init>	()V
/*     */     //   181: ldc 66
/*     */     //   183: invokevirtual 14	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   186: aload_0
/*     */     //   187: invokevirtual 47	java/lang/Object:getClass	()Ljava/lang/Class;
/*     */     //   190: invokevirtual 48	java/lang/Class:getName	()Ljava/lang/String;
/*     */     //   193: invokevirtual 14	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   196: ldc 49
/*     */     //   198: invokevirtual 14	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   201: invokevirtual 19	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   204: invokespecial 20	java/lang/IllegalArgumentException:<init>	(Ljava/lang/String;)V
/*     */     //   207: athrow
/*     */     // Line number table:
/*     */     //   Java source line #505	-> byte code offset #0
/*     */     //   Java source line #507	-> byte code offset #6
/*     */     //   Java source line #508	-> byte code offset #10
/*     */     //   Java source line #511	-> byte code offset #12
/*     */     //   Java source line #513	-> byte code offset #23
/*     */     //   Java source line #514	-> byte code offset #37
/*     */     //   Java source line #515	-> byte code offset #42
/*     */     //   Java source line #516	-> byte code offset #49
/*     */     //   Java source line #518	-> byte code offset #60
/*     */     //   Java source line #520	-> byte code offset #71
/*     */     //   Java source line #521	-> byte code offset #78
/*     */     //   Java source line #523	-> byte code offset #87
/*     */     //   Java source line #526	-> byte code offset #99
/*     */     //   Java source line #527	-> byte code offset #106
/*     */     //   Java source line #528	-> byte code offset #112
/*     */     //   Java source line #529	-> byte code offset #128
/*     */     //   Java source line #530	-> byte code offset #136
/*     */     //   Java source line #531	-> byte code offset #143
/*     */     //   Java source line #532	-> byte code offset #149
/*     */     //   Java source line #533	-> byte code offset #162
/*     */     //   Java source line #535	-> byte code offset #170
/*     */     //   Java source line #536	-> byte code offset #187
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	208	0	target	Object
/*     */     //   0	208	1	pattern	String
/*     */     //   0	208	2	locale	Locale
/*     */     //   22	69	3	key	DateFormatKey
/*     */     //   35	115	4	dateFormat	DateFormat
/*     */     //   109	22	5	Ljava/lang/Object;	Object
/*     */     //   146	19	5	Ljava/lang/Object;	Object
/*     */     //   128	6	6	localObject1	Object
/*     */     //   162	6	7	localObject2	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   112	127	128	finally
/*     */     //   128	133	128	finally
/*     */     //   149	161	162	finally
/*     */     //   162	167	162	finally
/*     */   }
/*     */   
/*     */   public static String formatISO(Object target)
/*     */   {
/* 553 */     if (target == null) {
/* 554 */       return null;
/*     */     }
/*     */     
/*     */     Date targetDate;
/* 558 */     if ((target instanceof Calendar)) {
/* 559 */       targetDate = ((Calendar)target).getTime(); } else { Date targetDate;
/* 560 */       if ((target instanceof Date)) {
/* 561 */         targetDate = (Date)target;
/*     */       }
/*     */       else {
/* 564 */         throw new IllegalArgumentException("Cannot format object of class \"" + target.getClass().getName() + "\" as a date");
/*     */       }
/*     */     }
/*     */     String formatted;
/* 568 */     synchronized (ISO8601_DATE_FORMAT) { Date targetDate;
/* 569 */       formatted = ISO8601_DATE_FORMAT.format(targetDate);
/*     */     }
/*     */     String formatted;
/* 572 */     StringBuilder strBuilder = new StringBuilder(formatted.length() + 1);
/* 573 */     strBuilder.append(formatted);
/* 574 */     strBuilder.insert(26, ':');
/*     */     
/* 576 */     return strBuilder.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final class DateFormatKey
/*     */   {
/*     */     final String format;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     final TimeZone timeZone;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     final Locale locale;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     DateFormatKey(Object target, String format, Locale locale)
/*     */     {
/* 602 */       Validate.notNull(locale, "Locale cannot be null");
/* 603 */       this.format = format;
/* 604 */       this.locale = locale;
/* 605 */       if ((target != null) && ((target instanceof Calendar))) {
/* 606 */         this.timeZone = ((Calendar)target).getTimeZone();
/*     */       } else {
/* 608 */         this.timeZone = null;
/*     */       }
/*     */     }
/*     */     
/*     */     public int hashCode()
/*     */     {
/* 614 */       int prime = 31;
/* 615 */       int result = 1;
/* 616 */       result = 31 * result + (this.format == null ? 0 : this.format.hashCode());
/* 617 */       result = 31 * result + this.locale.hashCode();
/* 618 */       result = 31 * result + (this.timeZone == null ? 0 : this.timeZone.hashCode());
/* 619 */       return result;
/*     */     }
/*     */     
/*     */     public boolean equals(Object obj)
/*     */     {
/* 624 */       if (this == obj) {
/* 625 */         return true;
/*     */       }
/* 627 */       if (obj == null) {
/* 628 */         return false;
/*     */       }
/* 630 */       if (getClass() != obj.getClass()) {
/* 631 */         return false;
/*     */       }
/* 633 */       DateFormatKey other = (DateFormatKey)obj;
/* 634 */       if (this.format == null) {
/* 635 */         if (other.format != null) {
/* 636 */           return false;
/*     */         }
/* 638 */       } else if (!this.format.equals(other.format)) {
/* 639 */         return false;
/*     */       }
/* 641 */       if (this.timeZone == null) {
/* 642 */         if (other.timeZone != null) {
/* 643 */           return false;
/*     */         }
/* 645 */       } else if (!this.timeZone.equals(other.timeZone)) {
/* 646 */         return false;
/*     */       }
/* 648 */       return this.locale.equals(other.locale);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\util\DateUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */