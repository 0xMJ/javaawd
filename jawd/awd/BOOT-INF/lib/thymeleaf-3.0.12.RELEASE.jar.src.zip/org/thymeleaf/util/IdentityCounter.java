/*    */ package org.thymeleaf.util;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.IdentityHashMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class IdentityCounter<T>
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = -6965348731301112911L;
/*    */   private final IdentityHashMap<T, Object> counted;
/*    */   
/*    */   public IdentityCounter(int expectedMaxSize)
/*    */   {
/* 49 */     this.counted = new IdentityHashMap(expectedMaxSize);
/*    */   }
/*    */   
/*    */   public void count(T object) {
/* 53 */     this.counted.put(object, null);
/*    */   }
/*    */   
/*    */   public boolean isAlreadyCounted(T object) {
/* 57 */     return this.counted.containsKey(object);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\util\IdentityCounter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */