/*    */ package org.thymeleaf.util;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.Collection;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class MapUtils
/*    */ {
/*    */   public static int size(Map<?, ?> target)
/*    */   {
/* 39 */     Validate.notNull(target, "Cannot get map size of null");
/* 40 */     return target.size();
/*    */   }
/*    */   
/*    */   public static boolean isEmpty(Map<?, ?> target)
/*    */   {
/* 45 */     return (target == null) || (target.isEmpty());
/*    */   }
/*    */   
/*    */   public static <X> boolean containsKey(Map<? super X, ?> target, X key)
/*    */   {
/* 50 */     Validate.notNull(target, "Cannot execute map containsKey: target is null");
/* 51 */     return target.containsKey(key);
/*    */   }
/*    */   
/*    */   public static <X> boolean containsAllKeys(Map<? super X, ?> target, X[] keys) {
/* 55 */     Validate.notNull(target, "Cannot execute map containsAllKeys: target is null");
/* 56 */     Validate.notNull(keys, "Cannot execute map containsAllKeys: keys is null");
/* 57 */     return containsAllKeys(target, Arrays.asList(keys));
/*    */   }
/*    */   
/*    */   public static <X> boolean containsAllKeys(Map<? super X, ?> target, Collection<X> keys) {
/* 61 */     Validate.notNull(target, "Cannot execute map containsAllKeys: target is null");
/* 62 */     Validate.notNull(keys, "Cannot execute map containsAllKeys: keys is null");
/* 63 */     return target.keySet().containsAll(keys);
/*    */   }
/*    */   
/*    */   public static <X> boolean containsValue(Map<?, ? super X> target, X value)
/*    */   {
/* 68 */     Validate.notNull(target, "Cannot execute map containsValue: target is null");
/* 69 */     return target.containsValue(value);
/*    */   }
/*    */   
/*    */   public static <X> boolean containsAllValues(Map<?, ? super X> target, X[] values) {
/* 73 */     Validate.notNull(target, "Cannot execute map containsAllValues: target is null");
/* 74 */     Validate.notNull(values, "Cannot execute map containsAllValues: values is null");
/* 75 */     return containsAllValues(target, Arrays.asList(values));
/*    */   }
/*    */   
/*    */   public static <X> boolean containsAllValues(Map<?, ? super X> target, Collection<X> values) {
/* 79 */     Validate.notNull(target, "Cannot execute map containsAllValues: target is null");
/* 80 */     Validate.notNull(values, "Cannot execute map containsAllValues: values is null");
/* 81 */     return target.values().containsAll(values);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\util\MapUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */