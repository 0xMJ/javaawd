/*     */ package org.thymeleaf.util;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ClassLoaderUtils
/*     */ {
/*  47 */   private static final ClassLoader classClassLoader = getClassClassLoader(ClassLoaderUtils.class);
/*  48 */   private static final ClassLoader systemClassLoader = getSystemClassLoader();
/*  49 */   private static final boolean systemClassLoaderAccessibleFromClassClassLoader = isKnownClassLoaderAccessibleFrom(systemClassLoader, classClassLoader);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ClassLoader getClassLoader(Class<?> clazz)
/*     */   {
/*  70 */     ClassLoader contextClassLoader = getThreadContextClassLoader();
/*  71 */     if (contextClassLoader != null) {
/*  72 */       return contextClassLoader;
/*     */     }
/*  74 */     if (clazz != null)
/*     */     {
/*  76 */       ClassLoader clazzClassLoader = getClassClassLoader(clazz);
/*  77 */       if (clazzClassLoader != null) {
/*  78 */         return clazzClassLoader;
/*     */       }
/*     */     }
/*     */     
/*  82 */     return systemClassLoader;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Class<?> loadClass(String className)
/*     */     throws ClassNotFoundException
/*     */   {
/* 109 */     ClassNotFoundException notFoundException = null;
/*     */     
/*     */ 
/* 112 */     ClassLoader contextClassLoader = getThreadContextClassLoader();
/* 113 */     if (contextClassLoader != null) {
/*     */       try {
/* 115 */         return Class.forName(className, false, contextClassLoader);
/*     */       } catch (ClassNotFoundException cnfe) {
/* 117 */         notFoundException = cnfe;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 127 */     if (!isKnownLeafClassLoader(contextClassLoader))
/*     */     {
/*     */ 
/* 130 */       if ((classClassLoader != null) && (classClassLoader != contextClassLoader)) {
/*     */         try {
/* 132 */           return Class.forName(className, false, classClassLoader);
/*     */         } catch (ClassNotFoundException cnfe) {
/* 134 */           if (notFoundException == null) {
/* 135 */             notFoundException = cnfe;
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 141 */       if (!systemClassLoaderAccessibleFromClassClassLoader)
/*     */       {
/*     */ 
/* 144 */         if ((systemClassLoader != null) && (systemClassLoader != contextClassLoader) && (systemClassLoader != classClassLoader)) {
/*     */           try {
/* 146 */             return Class.forName(className, false, systemClassLoader);
/*     */           } catch (ClassNotFoundException cnfe) {
/* 148 */             if (notFoundException == null) {
/* 149 */               notFoundException = cnfe;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 162 */     throw notFoundException;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Class<?> findClass(String className)
/*     */   {
/*     */     try
/*     */     {
/* 184 */       return loadClass(className);
/*     */     }
/*     */     catch (ClassNotFoundException cnfe) {}
/* 187 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isClassPresent(String className)
/*     */   {
/* 208 */     return findClass(className) != null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static URL findResource(String resourceName)
/*     */   {
/* 234 */     ClassLoader contextClassLoader = getThreadContextClassLoader();
/* 235 */     if (contextClassLoader != null) {
/* 236 */       URL url = contextClassLoader.getResource(resourceName);
/* 237 */       if (url != null) {
/* 238 */         return url;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 248 */     if (!isKnownLeafClassLoader(contextClassLoader))
/*     */     {
/*     */ 
/* 251 */       if ((classClassLoader != null) && (classClassLoader != contextClassLoader)) {
/* 252 */         URL url = classClassLoader.getResource(resourceName);
/* 253 */         if (url != null) {
/* 254 */           return url;
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 259 */       if (!systemClassLoaderAccessibleFromClassClassLoader)
/*     */       {
/*     */ 
/* 262 */         if ((systemClassLoader != null) && (systemClassLoader != contextClassLoader) && (systemClassLoader != classClassLoader)) {
/* 263 */           URL url = systemClassLoader.getResource(resourceName);
/* 264 */           if (url != null) {
/* 265 */             return url;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 274 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isResourcePresent(String resourceName)
/*     */   {
/* 295 */     return findResource(resourceName) != null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static InputStream loadResourceAsStream(String resourceName)
/*     */     throws IOException
/*     */   {
/* 324 */     InputStream inputStream = findResourceAsStream(resourceName);
/* 325 */     if (inputStream != null) {
/* 326 */       return inputStream;
/*     */     }
/*     */     
/*     */ 
/* 330 */     throw new IOException("Could not locate resource '" + resourceName + "' in the application's class path");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static InputStream findResourceAsStream(String resourceName)
/*     */   {
/* 353 */     ClassLoader contextClassLoader = getThreadContextClassLoader();
/* 354 */     if (contextClassLoader != null) {
/* 355 */       InputStream inputStream = contextClassLoader.getResourceAsStream(resourceName);
/* 356 */       if (inputStream != null) {
/* 357 */         return inputStream;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 367 */     if (!isKnownLeafClassLoader(contextClassLoader))
/*     */     {
/*     */ 
/* 370 */       if ((classClassLoader != null) && (classClassLoader != contextClassLoader)) {
/* 371 */         InputStream inputStream = classClassLoader.getResourceAsStream(resourceName);
/* 372 */         if (inputStream != null) {
/* 373 */           return inputStream;
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 378 */       if (!systemClassLoaderAccessibleFromClassClassLoader)
/*     */       {
/*     */ 
/* 381 */         if ((systemClassLoader != null) && (systemClassLoader != contextClassLoader) && (systemClassLoader != classClassLoader)) {
/* 382 */           InputStream inputStream = systemClassLoader.getResourceAsStream(resourceName);
/* 383 */           if (inputStream != null) {
/* 384 */             return inputStream;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 393 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static ClassLoader getThreadContextClassLoader()
/*     */   {
/*     */     try
/*     */     {
/* 406 */       return Thread.currentThread().getContextClassLoader();
/*     */     }
/*     */     catch (SecurityException se) {}
/* 409 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static ClassLoader getClassClassLoader(Class<?> clazz)
/*     */   {
/*     */     try
/*     */     {
/* 420 */       return clazz.getClassLoader();
/*     */     }
/*     */     catch (SecurityException se) {}
/* 423 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static ClassLoader getSystemClassLoader()
/*     */   {
/*     */     try
/*     */     {
/* 434 */       return ClassLoader.getSystemClassLoader();
/*     */     }
/*     */     catch (SecurityException se) {}
/* 437 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean isKnownClassLoaderAccessibleFrom(ClassLoader accessibleCL, ClassLoader fromCL)
/*     */   {
/* 448 */     if (fromCL == null) {
/* 449 */       return false;
/*     */     }
/*     */     
/* 452 */     ClassLoader parent = fromCL;
/*     */     
/*     */     try
/*     */     {
/* 456 */       while ((parent != null) && (parent != accessibleCL)) {
/* 457 */         parent = parent.getParent();
/*     */       }
/*     */       
/* 460 */       return (parent != null) && (parent == accessibleCL);
/*     */     }
/*     */     catch (SecurityException se) {}
/*     */     
/* 464 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean isKnownLeafClassLoader(ClassLoader classLoader)
/*     */   {
/* 478 */     if (classLoader == null) {
/* 479 */       return false;
/*     */     }
/*     */     
/* 482 */     if (!isKnownClassLoaderAccessibleFrom(classClassLoader, classLoader))
/*     */     {
/* 484 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 489 */     return systemClassLoaderAccessibleFromClassClassLoader;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\util\ClassLoaderUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */