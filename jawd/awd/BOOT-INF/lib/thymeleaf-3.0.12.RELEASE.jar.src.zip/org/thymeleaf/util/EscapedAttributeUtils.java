/*     */ package org.thymeleaf.util;
/*     */ 
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ import org.unbescape.css.CssEscape;
/*     */ import org.unbescape.html.HtmlEscape;
/*     */ import org.unbescape.javascript.JavaScriptEscape;
/*     */ import org.unbescape.xml.XmlEscape;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class EscapedAttributeUtils
/*     */ {
/*     */   public static String escapeAttribute(TemplateMode templateMode, String input)
/*     */   {
/*  43 */     if (input == null) {
/*  44 */       return null;
/*     */     }
/*     */     
/*  47 */     Validate.notNull(templateMode, "Template mode cannot be null");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  62 */     switch (templateMode)
/*     */     {
/*     */     case HTML: 
/*  65 */       return HtmlEscape.escapeHtml4Xml(input);
/*     */     case XML: 
/*  67 */       return XmlEscape.escapeXml10Attribute(input);
/*     */     }
/*  69 */     throw new TemplateProcessingException("Unrecognized template mode " + templateMode + ". Cannot produce escaped attributes for this template mode.");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String unescapeAttribute(TemplateMode templateMode, String input)
/*     */   {
/*  80 */     if (input == null) {
/*  81 */       return null;
/*     */     }
/*     */     
/*  84 */     Validate.notNull(templateMode, "Template mode cannot be null");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  98 */     switch (templateMode)
/*     */     {
/*     */ 
/*     */     case HTML: 
/*     */     case TEXT: 
/* 103 */       return HtmlEscape.unescapeHtml(input);
/*     */     case XML: 
/* 105 */       return XmlEscape.unescapeXml(input);
/*     */     case JAVASCRIPT: 
/* 107 */       return JavaScriptEscape.unescapeJavaScript(input);
/*     */     case CSS: 
/* 109 */       return CssEscape.unescapeCss(input);
/*     */     case RAW: 
/* 111 */       return input; }
/*     */     
/* 113 */     throw new TemplateProcessingException("Unrecognized template mode " + templateMode + ". Cannot unescape attribute value for this template mode.");
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\util\EscapedAttributeUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */