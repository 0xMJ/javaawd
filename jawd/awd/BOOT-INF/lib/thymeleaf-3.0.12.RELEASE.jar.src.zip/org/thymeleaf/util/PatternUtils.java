/*    */ package org.thymeleaf.util;
/*    */ 
/*    */ import java.util.regex.Pattern;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class PatternUtils
/*    */ {
/*    */   public static Pattern strPatternToPattern(String pattern)
/*    */   {
/* 41 */     String pat = pattern.replace(".", "\\.").replace("(", "\\(").replace(")", "\\)").replace("[", "\\[").replace("]", "\\]").replace("?", "\\?").replace("$", "\\$").replace("+", "\\+").replace("*", "(?:.*?)");
/* 42 */     return Pattern.compile('^' + pat + '$');
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\util\PatternUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */