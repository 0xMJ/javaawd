/*     */ package org.thymeleaf.util;
/*     */ 
/*     */ import org.thymeleaf.context.ITemplateContext;
/*     */ import org.thymeleaf.dialect.IProcessorDialect;
/*     */ import org.thymeleaf.engine.AttributeDefinitions;
/*     */ import org.thymeleaf.engine.ElementDefinitions;
/*     */ import org.thymeleaf.engine.IAttributeDefinitionsAware;
/*     */ import org.thymeleaf.engine.IElementDefinitionsAware;
/*     */ import org.thymeleaf.engine.ITemplateHandler;
/*     */ import org.thymeleaf.model.ICDATASection;
/*     */ import org.thymeleaf.model.IComment;
/*     */ import org.thymeleaf.model.IDocType;
/*     */ import org.thymeleaf.model.IModel;
/*     */ import org.thymeleaf.model.IProcessableElementTag;
/*     */ import org.thymeleaf.model.IProcessingInstruction;
/*     */ import org.thymeleaf.model.ITemplateEnd;
/*     */ import org.thymeleaf.model.ITemplateStart;
/*     */ import org.thymeleaf.model.IText;
/*     */ import org.thymeleaf.model.IXMLDeclaration;
/*     */ import org.thymeleaf.postprocessor.IPostProcessor;
/*     */ import org.thymeleaf.preprocessor.IPreProcessor;
/*     */ import org.thymeleaf.processor.IProcessor;
/*     */ import org.thymeleaf.processor.cdatasection.ICDATASectionProcessor;
/*     */ import org.thymeleaf.processor.cdatasection.ICDATASectionStructureHandler;
/*     */ import org.thymeleaf.processor.comment.ICommentProcessor;
/*     */ import org.thymeleaf.processor.comment.ICommentStructureHandler;
/*     */ import org.thymeleaf.processor.doctype.IDocTypeProcessor;
/*     */ import org.thymeleaf.processor.doctype.IDocTypeStructureHandler;
/*     */ import org.thymeleaf.processor.element.IElementModelProcessor;
/*     */ import org.thymeleaf.processor.element.IElementModelStructureHandler;
/*     */ import org.thymeleaf.processor.element.IElementProcessor;
/*     */ import org.thymeleaf.processor.element.IElementTagProcessor;
/*     */ import org.thymeleaf.processor.element.IElementTagStructureHandler;
/*     */ import org.thymeleaf.processor.element.MatchingAttributeName;
/*     */ import org.thymeleaf.processor.element.MatchingElementName;
/*     */ import org.thymeleaf.processor.processinginstruction.IProcessingInstructionProcessor;
/*     */ import org.thymeleaf.processor.processinginstruction.IProcessingInstructionStructureHandler;
/*     */ import org.thymeleaf.processor.templateboundaries.ITemplateBoundariesProcessor;
/*     */ import org.thymeleaf.processor.templateboundaries.ITemplateBoundariesStructureHandler;
/*     */ import org.thymeleaf.processor.text.ITextProcessor;
/*     */ import org.thymeleaf.processor.text.ITextStructureHandler;
/*     */ import org.thymeleaf.processor.xmldeclaration.IXMLDeclarationProcessor;
/*     */ import org.thymeleaf.processor.xmldeclaration.IXMLDeclarationStructureHandler;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ProcessorConfigurationUtils
/*     */ {
/*     */   public static IElementProcessor wrap(IElementProcessor processor, IProcessorDialect dialect)
/*     */   {
/*  95 */     Validate.notNull(dialect, "Dialect cannot be null");
/*  96 */     if (processor == null) {
/*  97 */       return null;
/*     */     }
/*  99 */     if ((processor instanceof IElementTagProcessor)) {
/* 100 */       return new ElementTagProcessorWrapper((IElementTagProcessor)processor, dialect);
/*     */     }
/* 102 */     if ((processor instanceof IElementModelProcessor)) {
/* 103 */       return new ElementModelProcessorWrapper((IElementModelProcessor)processor, dialect);
/*     */     }
/*     */     
/* 106 */     throw new IllegalArgumentException("Unknown element processor interface implemented by " + processor + " of class: " + processor.getClass().getName());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ICDATASectionProcessor wrap(ICDATASectionProcessor processor, IProcessorDialect dialect)
/*     */   {
/* 124 */     Validate.notNull(dialect, "Dialect cannot be null");
/* 125 */     if (processor == null) {
/* 126 */       return null;
/*     */     }
/* 128 */     return new CDATASectionProcessorWrapper(processor, dialect);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ICommentProcessor wrap(ICommentProcessor processor, IProcessorDialect dialect)
/*     */   {
/* 146 */     Validate.notNull(dialect, "Dialect cannot be null");
/* 147 */     if (processor == null) {
/* 148 */       return null;
/*     */     }
/* 150 */     return new CommentProcessorWrapper(processor, dialect);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static IDocTypeProcessor wrap(IDocTypeProcessor processor, IProcessorDialect dialect)
/*     */   {
/* 168 */     Validate.notNull(dialect, "Dialect cannot be null");
/* 169 */     if (processor == null) {
/* 170 */       return null;
/*     */     }
/* 172 */     return new DocTypeProcessorWrapper(processor, dialect);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static IProcessingInstructionProcessor wrap(IProcessingInstructionProcessor processor, IProcessorDialect dialect)
/*     */   {
/* 190 */     Validate.notNull(dialect, "Dialect cannot be null");
/* 191 */     if (processor == null) {
/* 192 */       return null;
/*     */     }
/* 194 */     return new ProcessingInstructionProcessorWrapper(processor, dialect);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ITemplateBoundariesProcessor wrap(ITemplateBoundariesProcessor processor, IProcessorDialect dialect)
/*     */   {
/* 212 */     Validate.notNull(dialect, "Dialect cannot be null");
/* 213 */     if (processor == null) {
/* 214 */       return null;
/*     */     }
/* 216 */     return new TemplateBoundariesProcessorWrapper(processor, dialect);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ITextProcessor wrap(ITextProcessor processor, IProcessorDialect dialect)
/*     */   {
/* 234 */     Validate.notNull(dialect, "Dialect cannot be null");
/* 235 */     if (processor == null) {
/* 236 */       return null;
/*     */     }
/* 238 */     return new TextProcessorWrapper(processor, dialect);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static IXMLDeclarationProcessor wrap(IXMLDeclarationProcessor processor, IProcessorDialect dialect)
/*     */   {
/* 256 */     Validate.notNull(dialect, "Dialect cannot be null");
/* 257 */     if (processor == null) {
/* 258 */       return null;
/*     */     }
/* 260 */     return new XMLDeclarationProcessorWrapper(processor, dialect);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static IPreProcessor wrap(IPreProcessor preProcessor, IProcessorDialect dialect)
/*     */   {
/* 278 */     Validate.notNull(dialect, "Dialect cannot be null");
/* 279 */     if (preProcessor == null) {
/* 280 */       return null;
/*     */     }
/* 282 */     return new PreProcessorWrapper(preProcessor, dialect);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static IPostProcessor wrap(IPostProcessor postProcessor, IProcessorDialect dialect)
/*     */   {
/* 300 */     Validate.notNull(dialect, "Dialect cannot be null");
/* 301 */     if (postProcessor == null) {
/* 302 */       return null;
/*     */     }
/* 304 */     return new PostProcessorWrapper(postProcessor, dialect);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static IElementProcessor unwrap(IElementProcessor processor)
/*     */   {
/* 322 */     if (processor == null) {
/* 323 */       return null;
/*     */     }
/* 325 */     if ((processor instanceof AbstractProcessorWrapper)) {
/* 326 */       return (IElementProcessor)((AbstractProcessorWrapper)processor).unwrap();
/*     */     }
/* 328 */     return processor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ICDATASectionProcessor unwrap(ICDATASectionProcessor processor)
/*     */   {
/* 344 */     if (processor == null) {
/* 345 */       return null;
/*     */     }
/* 347 */     if ((processor instanceof AbstractProcessorWrapper)) {
/* 348 */       return (ICDATASectionProcessor)((AbstractProcessorWrapper)processor).unwrap();
/*     */     }
/* 350 */     return processor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ICommentProcessor unwrap(ICommentProcessor processor)
/*     */   {
/* 366 */     if (processor == null) {
/* 367 */       return null;
/*     */     }
/* 369 */     if ((processor instanceof AbstractProcessorWrapper)) {
/* 370 */       return (ICommentProcessor)((AbstractProcessorWrapper)processor).unwrap();
/*     */     }
/* 372 */     return processor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static IDocTypeProcessor unwrap(IDocTypeProcessor processor)
/*     */   {
/* 388 */     if (processor == null) {
/* 389 */       return null;
/*     */     }
/* 391 */     if ((processor instanceof AbstractProcessorWrapper)) {
/* 392 */       return (IDocTypeProcessor)((AbstractProcessorWrapper)processor).unwrap();
/*     */     }
/* 394 */     return processor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static IProcessingInstructionProcessor unwrap(IProcessingInstructionProcessor processor)
/*     */   {
/* 410 */     if (processor == null) {
/* 411 */       return null;
/*     */     }
/* 413 */     if ((processor instanceof AbstractProcessorWrapper)) {
/* 414 */       return (IProcessingInstructionProcessor)((AbstractProcessorWrapper)processor).unwrap();
/*     */     }
/* 416 */     return processor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ITemplateBoundariesProcessor unwrap(ITemplateBoundariesProcessor processor)
/*     */   {
/* 432 */     if (processor == null) {
/* 433 */       return null;
/*     */     }
/* 435 */     if ((processor instanceof AbstractProcessorWrapper)) {
/* 436 */       return (ITemplateBoundariesProcessor)((AbstractProcessorWrapper)processor).unwrap();
/*     */     }
/* 438 */     return processor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ITextProcessor unwrap(ITextProcessor processor)
/*     */   {
/* 454 */     if (processor == null) {
/* 455 */       return null;
/*     */     }
/* 457 */     if ((processor instanceof AbstractProcessorWrapper)) {
/* 458 */       return (ITextProcessor)((AbstractProcessorWrapper)processor).unwrap();
/*     */     }
/* 460 */     return processor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static IXMLDeclarationProcessor unwrap(IXMLDeclarationProcessor processor)
/*     */   {
/* 476 */     if (processor == null) {
/* 477 */       return null;
/*     */     }
/* 479 */     if ((processor instanceof AbstractProcessorWrapper)) {
/* 480 */       return (IXMLDeclarationProcessor)((AbstractProcessorWrapper)processor).unwrap();
/*     */     }
/* 482 */     return processor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static IPreProcessor unwrap(IPreProcessor preProcessor)
/*     */   {
/* 500 */     if (preProcessor == null) {
/* 501 */       return null;
/*     */     }
/* 503 */     if ((preProcessor instanceof PreProcessorWrapper)) {
/* 504 */       return ((PreProcessorWrapper)preProcessor).unwrap();
/*     */     }
/* 506 */     return preProcessor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static IPostProcessor unwrap(IPostProcessor postProcessor)
/*     */   {
/* 524 */     if (postProcessor == null) {
/* 525 */       return null;
/*     */     }
/* 527 */     if ((postProcessor instanceof PostProcessorWrapper)) {
/* 528 */       return ((PostProcessorWrapper)postProcessor).unwrap();
/*     */     }
/* 530 */     return postProcessor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static abstract class AbstractProcessorWrapper
/*     */     implements IProcessor, IAttributeDefinitionsAware, IElementDefinitionsAware
/*     */   {
/*     */     private final int dialectPrecedence;
/*     */     
/*     */ 
/*     */ 
/*     */     private final int processorPrecedence;
/*     */     
/*     */ 
/*     */ 
/*     */     private final IProcessorDialect dialect;
/*     */     
/*     */ 
/*     */ 
/*     */     private final IProcessor processor;
/*     */     
/*     */ 
/*     */ 
/*     */     AbstractProcessorWrapper(IProcessor processor, IProcessorDialect dialect)
/*     */     {
/* 557 */       this.dialect = dialect;
/* 558 */       this.processor = processor;
/* 559 */       this.dialectPrecedence = this.dialect.getDialectProcessorPrecedence();
/* 560 */       this.processorPrecedence = this.processor.getPrecedence();
/*     */     }
/*     */     
/*     */     public final TemplateMode getTemplateMode() {
/* 564 */       return this.processor.getTemplateMode();
/*     */     }
/*     */     
/*     */     public final int getDialectPrecedence() {
/* 568 */       return this.dialectPrecedence;
/*     */     }
/*     */     
/*     */     public final int getPrecedence() {
/* 572 */       return this.processorPrecedence;
/*     */     }
/*     */     
/*     */     public final IProcessorDialect getDialect() {
/* 576 */       return this.dialect;
/*     */     }
/*     */     
/*     */     public final IProcessor unwrap() {
/* 580 */       return this.processor;
/*     */     }
/*     */     
/*     */     public final void setAttributeDefinitions(AttributeDefinitions attributeDefinitions) {
/* 584 */       if ((this.processor instanceof IAttributeDefinitionsAware)) {
/* 585 */         ((IAttributeDefinitionsAware)this.processor).setAttributeDefinitions(attributeDefinitions);
/*     */       }
/*     */     }
/*     */     
/*     */     public final void setElementDefinitions(ElementDefinitions elementDefinitions) {
/* 590 */       if ((this.processor instanceof IElementDefinitionsAware)) {
/* 591 */         ((IElementDefinitionsAware)this.processor).setElementDefinitions(elementDefinitions);
/*     */       }
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/* 597 */       return this.processor.toString();
/*     */     }
/*     */   }
/*     */   
/*     */   static abstract class AbstractElementProcessorWrapper
/*     */     extends ProcessorConfigurationUtils.AbstractProcessorWrapper implements IElementProcessor
/*     */   {
/*     */     private final IElementProcessor processor;
/*     */     
/*     */     AbstractElementProcessorWrapper(IElementProcessor processor, IProcessorDialect dialect)
/*     */     {
/* 608 */       super(dialect);
/* 609 */       this.processor = processor;
/*     */     }
/*     */     
/*     */     public final MatchingElementName getMatchingElementName() {
/* 613 */       return this.processor.getMatchingElementName();
/*     */     }
/*     */     
/*     */     public final MatchingAttributeName getMatchingAttributeName() {
/* 617 */       return this.processor.getMatchingAttributeName();
/*     */     }
/*     */   }
/*     */   
/*     */   static final class ElementTagProcessorWrapper
/*     */     extends ProcessorConfigurationUtils.AbstractElementProcessorWrapper implements IElementTagProcessor
/*     */   {
/*     */     private final IElementTagProcessor processor;
/*     */     
/*     */     ElementTagProcessorWrapper(IElementTagProcessor processor, IProcessorDialect dialect)
/*     */     {
/* 628 */       super(dialect);
/* 629 */       this.processor = processor;
/*     */     }
/*     */     
/*     */     public void process(ITemplateContext context, IProcessableElementTag tag, IElementTagStructureHandler structureHandler) {
/* 633 */       this.processor.process(context, tag, structureHandler);
/*     */     }
/*     */   }
/*     */   
/*     */   static final class ElementModelProcessorWrapper
/*     */     extends ProcessorConfigurationUtils.AbstractElementProcessorWrapper implements IElementModelProcessor
/*     */   {
/*     */     private final IElementModelProcessor processor;
/*     */     
/*     */     ElementModelProcessorWrapper(IElementModelProcessor processor, IProcessorDialect dialect)
/*     */     {
/* 644 */       super(dialect);
/* 645 */       this.processor = processor;
/*     */     }
/*     */     
/*     */     public void process(ITemplateContext context, IModel model, IElementModelStructureHandler structureHandler) {
/* 649 */       this.processor.process(context, model, structureHandler);
/*     */     }
/*     */   }
/*     */   
/*     */   static final class CDATASectionProcessorWrapper
/*     */     extends ProcessorConfigurationUtils.AbstractProcessorWrapper implements ICDATASectionProcessor
/*     */   {
/*     */     private final ICDATASectionProcessor processor;
/*     */     
/*     */     CDATASectionProcessorWrapper(ICDATASectionProcessor processor, IProcessorDialect dialect)
/*     */     {
/* 660 */       super(dialect);
/* 661 */       this.processor = processor;
/*     */     }
/*     */     
/*     */     public void process(ITemplateContext context, ICDATASection cdataSection, ICDATASectionStructureHandler structureHandler) {
/* 665 */       this.processor.process(context, cdataSection, structureHandler);
/*     */     }
/*     */   }
/*     */   
/*     */   static final class CommentProcessorWrapper
/*     */     extends ProcessorConfigurationUtils.AbstractProcessorWrapper implements ICommentProcessor
/*     */   {
/*     */     private final ICommentProcessor processor;
/*     */     
/*     */     CommentProcessorWrapper(ICommentProcessor processor, IProcessorDialect dialect)
/*     */     {
/* 676 */       super(dialect);
/* 677 */       this.processor = processor;
/*     */     }
/*     */     
/*     */     public void process(ITemplateContext context, IComment comment, ICommentStructureHandler structureHandler) {
/* 681 */       this.processor.process(context, comment, structureHandler);
/*     */     }
/*     */   }
/*     */   
/*     */   static final class DocTypeProcessorWrapper
/*     */     extends ProcessorConfigurationUtils.AbstractProcessorWrapper implements IDocTypeProcessor
/*     */   {
/*     */     private final IDocTypeProcessor processor;
/*     */     
/*     */     DocTypeProcessorWrapper(IDocTypeProcessor processor, IProcessorDialect dialect)
/*     */     {
/* 692 */       super(dialect);
/* 693 */       this.processor = processor;
/*     */     }
/*     */     
/*     */     public void process(ITemplateContext context, IDocType docType, IDocTypeStructureHandler structureHandler) {
/* 697 */       this.processor.process(context, docType, structureHandler);
/*     */     }
/*     */   }
/*     */   
/*     */   static final class ProcessingInstructionProcessorWrapper
/*     */     extends ProcessorConfigurationUtils.AbstractProcessorWrapper implements IProcessingInstructionProcessor
/*     */   {
/*     */     private final IProcessingInstructionProcessor processor;
/*     */     
/*     */     ProcessingInstructionProcessorWrapper(IProcessingInstructionProcessor processor, IProcessorDialect dialect)
/*     */     {
/* 708 */       super(dialect);
/* 709 */       this.processor = processor;
/*     */     }
/*     */     
/*     */     public void process(ITemplateContext context, IProcessingInstruction processingInstruction, IProcessingInstructionStructureHandler structureHandler) {
/* 713 */       this.processor.process(context, processingInstruction, structureHandler);
/*     */     }
/*     */   }
/*     */   
/*     */   static final class TemplateBoundariesProcessorWrapper
/*     */     extends ProcessorConfigurationUtils.AbstractProcessorWrapper implements ITemplateBoundariesProcessor
/*     */   {
/*     */     private final ITemplateBoundariesProcessor processor;
/*     */     
/*     */     TemplateBoundariesProcessorWrapper(ITemplateBoundariesProcessor processor, IProcessorDialect dialect)
/*     */     {
/* 724 */       super(dialect);
/* 725 */       this.processor = processor;
/*     */     }
/*     */     
/*     */     public void processTemplateStart(ITemplateContext context, ITemplateStart templateStart, ITemplateBoundariesStructureHandler structureHandler) {
/* 729 */       this.processor.processTemplateStart(context, templateStart, structureHandler);
/*     */     }
/*     */     
/*     */     public void processTemplateEnd(ITemplateContext context, ITemplateEnd templateEnd, ITemplateBoundariesStructureHandler structureHandler) {
/* 733 */       this.processor.processTemplateEnd(context, templateEnd, structureHandler);
/*     */     }
/*     */   }
/*     */   
/*     */   static final class TextProcessorWrapper
/*     */     extends ProcessorConfigurationUtils.AbstractProcessorWrapper implements ITextProcessor
/*     */   {
/*     */     private final ITextProcessor processor;
/*     */     
/*     */     TextProcessorWrapper(ITextProcessor processor, IProcessorDialect dialect)
/*     */     {
/* 744 */       super(dialect);
/* 745 */       this.processor = processor;
/*     */     }
/*     */     
/*     */     public void process(ITemplateContext context, IText text, ITextStructureHandler structureHandler) {
/* 749 */       this.processor.process(context, text, structureHandler);
/*     */     }
/*     */   }
/*     */   
/*     */   static final class XMLDeclarationProcessorWrapper
/*     */     extends ProcessorConfigurationUtils.AbstractProcessorWrapper implements IXMLDeclarationProcessor
/*     */   {
/*     */     private final IXMLDeclarationProcessor processor;
/*     */     
/*     */     XMLDeclarationProcessorWrapper(IXMLDeclarationProcessor processor, IProcessorDialect dialect)
/*     */     {
/* 760 */       super(dialect);
/* 761 */       this.processor = processor;
/*     */     }
/*     */     
/*     */     public void process(ITemplateContext context, IXMLDeclaration xmlDeclaration, IXMLDeclarationStructureHandler structureHandler) {
/* 765 */       this.processor.process(context, xmlDeclaration, structureHandler);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   static final class PreProcessorWrapper
/*     */     implements IPreProcessor, IElementDefinitionsAware, IAttributeDefinitionsAware
/*     */   {
/*     */     private final IProcessorDialect dialect;
/*     */     
/*     */     private final IPreProcessor preProcessor;
/*     */     
/*     */ 
/*     */     PreProcessorWrapper(IPreProcessor preProcessor, IProcessorDialect dialect)
/*     */     {
/* 780 */       this.preProcessor = preProcessor;
/* 781 */       this.dialect = dialect;
/*     */     }
/*     */     
/*     */     public TemplateMode getTemplateMode()
/*     */     {
/* 786 */       return this.preProcessor.getTemplateMode();
/*     */     }
/*     */     
/*     */     public int getPrecedence() {
/* 790 */       return this.preProcessor.getPrecedence();
/*     */     }
/*     */     
/*     */     public final IProcessorDialect getDialect() {
/* 794 */       return this.dialect;
/*     */     }
/*     */     
/*     */     public Class<? extends ITemplateHandler> getHandlerClass() {
/* 798 */       return this.preProcessor.getHandlerClass();
/*     */     }
/*     */     
/*     */     public final IPreProcessor unwrap() {
/* 802 */       return this.preProcessor;
/*     */     }
/*     */     
/*     */     public final void setAttributeDefinitions(AttributeDefinitions attributeDefinitions) {
/* 806 */       if ((this.preProcessor instanceof IAttributeDefinitionsAware)) {
/* 807 */         ((IAttributeDefinitionsAware)this.preProcessor).setAttributeDefinitions(attributeDefinitions);
/*     */       }
/*     */     }
/*     */     
/*     */     public final void setElementDefinitions(ElementDefinitions elementDefinitions) {
/* 812 */       if ((this.preProcessor instanceof IElementDefinitionsAware)) {
/* 813 */         ((IElementDefinitionsAware)this.preProcessor).setElementDefinitions(elementDefinitions);
/*     */       }
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/* 819 */       return this.preProcessor.toString();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   static final class PostProcessorWrapper
/*     */     implements IPostProcessor, IElementDefinitionsAware, IAttributeDefinitionsAware
/*     */   {
/*     */     private final IProcessorDialect dialect;
/*     */     
/*     */     private final IPostProcessor postProcessor;
/*     */     
/*     */ 
/*     */     PostProcessorWrapper(IPostProcessor postProcessor, IProcessorDialect dialect)
/*     */     {
/* 834 */       this.postProcessor = postProcessor;
/* 835 */       this.dialect = dialect;
/*     */     }
/*     */     
/*     */     public TemplateMode getTemplateMode()
/*     */     {
/* 840 */       return this.postProcessor.getTemplateMode();
/*     */     }
/*     */     
/*     */     public int getPrecedence() {
/* 844 */       return this.postProcessor.getPrecedence();
/*     */     }
/*     */     
/*     */     public final IProcessorDialect getDialect() {
/* 848 */       return this.dialect;
/*     */     }
/*     */     
/*     */     public Class<? extends ITemplateHandler> getHandlerClass() {
/* 852 */       return this.postProcessor.getHandlerClass();
/*     */     }
/*     */     
/*     */     public final IPostProcessor unwrap() {
/* 856 */       return this.postProcessor;
/*     */     }
/*     */     
/*     */     public final void setAttributeDefinitions(AttributeDefinitions attributeDefinitions) {
/* 860 */       if ((this.postProcessor instanceof IAttributeDefinitionsAware)) {
/* 861 */         ((IAttributeDefinitionsAware)this.postProcessor).setAttributeDefinitions(attributeDefinitions);
/*     */       }
/*     */     }
/*     */     
/*     */     public final void setElementDefinitions(ElementDefinitions elementDefinitions) {
/* 866 */       if ((this.postProcessor instanceof IElementDefinitionsAware)) {
/* 867 */         ((IElementDefinitionsAware)this.postProcessor).setElementDefinitions(elementDefinitions);
/*     */       }
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/* 873 */       return this.postProcessor.toString();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\util\ProcessorConfigurationUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */