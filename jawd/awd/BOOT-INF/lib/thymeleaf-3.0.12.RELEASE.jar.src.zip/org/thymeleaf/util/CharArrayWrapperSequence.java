/*     */ package org.thymeleaf.util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CharArrayWrapperSequence
/*     */   implements CharSequence, Cloneable
/*     */ {
/*     */   private final char[] buffer;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final int offset;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final int len;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CharArrayWrapperSequence(char[] array)
/*     */   {
/*  54 */     this(array, 0, array != null ? array.length : -1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public CharArrayWrapperSequence(char[] buffer, int offset, int len)
/*     */   {
/*  62 */     if (buffer == null) {
/*  63 */       throw new IllegalArgumentException("Buffer cannot be null");
/*     */     }
/*     */     
/*  66 */     if ((offset < 0) || (offset >= buffer.length)) {
/*  67 */       throw new IllegalArgumentException(offset + " is not a valid offset for buffer (size: " + buffer.length + ")");
/*     */     }
/*     */     
/*  70 */     if (offset + len > buffer.length) {
/*  71 */       throw new IllegalArgumentException(len + " is not a valid length for buffer using offset " + offset + " (size: " + buffer.length + ")");
/*     */     }
/*     */     
/*  74 */     this.buffer = buffer;
/*  75 */     this.offset = offset;
/*  76 */     this.len = len;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public char charAt(int index)
/*     */   {
/*  83 */     if ((index < 0) || (index >= this.len)) {
/*  84 */       throw new ArrayIndexOutOfBoundsException(index);
/*     */     }
/*  86 */     return this.buffer[(index + this.offset)];
/*     */   }
/*     */   
/*     */ 
/*     */   public int length()
/*     */   {
/*  92 */     return this.len;
/*     */   }
/*     */   
/*     */ 
/*     */   public CharSequence subSequence(int start, int end)
/*     */   {
/*  98 */     if ((start < 0) || (start >= this.len)) {
/*  99 */       throw new ArrayIndexOutOfBoundsException(start);
/*     */     }
/* 101 */     if (end > this.len) {
/* 102 */       throw new ArrayIndexOutOfBoundsException(end);
/*     */     }
/* 104 */     return new CharArrayWrapperSequence(this.buffer, this.offset + start, end - start);
/*     */   }
/*     */   
/*     */ 
/*     */   protected CharArrayWrapperSequence clone()
/*     */     throws CloneNotSupportedException
/*     */   {
/* 111 */     return (CharArrayWrapperSequence)super.clone();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 123 */     if (this.len == 0) {
/* 124 */       return 0;
/*     */     }
/* 126 */     int prime = 31;
/* 127 */     int result = 0;
/* 128 */     int maxi = this.offset + this.len;
/* 129 */     for (int i = this.offset; i < maxi; i++) {
/* 130 */       result = 31 * result + this.buffer[i];
/*     */     }
/* 132 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 144 */     if (this == obj) {
/* 145 */       return true;
/*     */     }
/* 147 */     if (obj == null) {
/* 148 */       return false;
/*     */     }
/* 150 */     if ((obj instanceof CharArrayWrapperSequence)) {
/* 151 */       CharArrayWrapperSequence other = (CharArrayWrapperSequence)obj;
/* 152 */       if (this.len != other.len) {
/* 153 */         return false;
/*     */       }
/* 155 */       for (int i = 0; i < this.len; i++) {
/* 156 */         if (this.buffer[(i + this.offset)] != other.buffer[(i + other.offset)]) {
/* 157 */           return false;
/*     */         }
/*     */       }
/* 160 */       return true;
/*     */     }
/* 162 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 169 */     return new String(this.buffer, this.offset, this.len);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\util\CharArrayWrapperSequence.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */