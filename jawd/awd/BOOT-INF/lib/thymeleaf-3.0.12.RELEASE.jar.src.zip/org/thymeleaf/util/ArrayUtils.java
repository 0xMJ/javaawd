/*     */ package org.thymeleaf.util;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ArrayUtils
/*     */ {
/*     */   public static Object[] toArray(Object target)
/*     */   {
/*  43 */     return toArray(null, target);
/*     */   }
/*     */   
/*     */   public static Object[] toStringArray(Object target) {
/*  47 */     return toArray(String.class, target);
/*     */   }
/*     */   
/*     */   public static Object[] toIntegerArray(Object target) {
/*  51 */     return toArray(Integer.class, target);
/*     */   }
/*     */   
/*     */   public static Object[] toLongArray(Object target) {
/*  55 */     return toArray(Long.class, target);
/*     */   }
/*     */   
/*     */   public static Object[] toDoubleArray(Object target) {
/*  59 */     return toArray(Double.class, target);
/*     */   }
/*     */   
/*     */   public static Object[] toFloatArray(Object target) {
/*  63 */     return toArray(Float.class, target);
/*     */   }
/*     */   
/*     */   public static Object[] toBooleanArray(Object target) {
/*  67 */     return toArray(Boolean.class, target);
/*     */   }
/*     */   
/*     */   public static int length(Object[] target)
/*     */   {
/*  72 */     Validate.notNull(target, "Cannot get array length of null");
/*  73 */     return target.length;
/*     */   }
/*     */   
/*     */   public static boolean isEmpty(Object[] target)
/*     */   {
/*  78 */     return (target == null) || (target.length <= 0);
/*     */   }
/*     */   
/*     */ 
/*     */   public static boolean contains(Object[] target, Object element)
/*     */   {
/*  84 */     Validate.notNull(target, "Cannot execute array contains: target is null");
/*     */     
/*  86 */     if (element == null) {
/*  87 */       for (Object targetElement : target) {
/*  88 */         if (targetElement == null) {
/*  89 */           return true;
/*     */         }
/*     */       }
/*  92 */       return false;
/*     */     }
/*     */     
/*  95 */     for (Object targetElement : target) {
/*  96 */       if (element.equals(targetElement)) {
/*  97 */         return true;
/*     */       }
/*     */     }
/*     */     
/* 101 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public static boolean containsAll(Object[] target, Object[] elements)
/*     */   {
/* 107 */     Validate.notNull(target, "Cannot execute array containsAll: target is null");
/* 108 */     Validate.notNull(elements, "Cannot execute array containsAll: elements is null");
/* 109 */     return containsAll(target, Arrays.asList(elements));
/*     */   }
/*     */   
/*     */   public static boolean containsAll(Object[] target, Collection<?> elements)
/*     */   {
/* 114 */     Validate.notNull(target, "Cannot execute array contains: target is null");
/* 115 */     Validate.notNull(elements, "Cannot execute array containsAll: elements is null");
/* 116 */     Set<?> remainingElements = new HashSet(elements);
/* 117 */     remainingElements.removeAll(Arrays.asList(target));
/* 118 */     return remainingElements.isEmpty();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Object[] toArray(Class<?> componentClass, Object target)
/*     */   {
/* 126 */     Validate.notNull(target, "Cannot convert null to array");
/*     */     
/* 128 */     if (target.getClass().isArray())
/*     */     {
/* 130 */       if (componentClass == null) {
/* 131 */         return (Object[])target;
/*     */       }
/*     */       
/* 134 */       Class<?> targetComponentClass = target.getClass().getComponentType();
/* 135 */       if (componentClass.isAssignableFrom(targetComponentClass)) {
/* 136 */         return (Object[])target;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 141 */       throw new IllegalArgumentException("Cannot convert object of class \"" + targetComponentClass.getName() + "[]\" to an array of " + componentClass.getClass().getSimpleName());
/*     */     }
/*     */     
/*     */ 
/* 145 */     if ((target instanceof Iterable))
/*     */     {
/* 147 */       Class<?> computedComponentClass = null;
/* 148 */       Iterable<?> iterableTarget = (Iterable)target;
/* 149 */       List<Object> elements = new ArrayList(5);
/*     */       
/* 151 */       for (Object element : iterableTarget) {
/* 152 */         if ((componentClass == null) && (element != null)) {
/* 153 */           if (computedComponentClass == null) {
/* 154 */             computedComponentClass = element.getClass();
/* 155 */           } else if ((!computedComponentClass.equals(Object.class)) && 
/* 156 */             (!computedComponentClass.equals(element.getClass()))) {
/* 157 */             computedComponentClass = Object.class;
/*     */           }
/*     */         }
/*     */         
/* 161 */         elements.add(element);
/*     */       }
/*     */       
/* 164 */       if (computedComponentClass == null) {
/* 165 */         computedComponentClass = componentClass != null ? componentClass : Object.class;
/*     */       }
/*     */       
/*     */ 
/* 169 */       Object[] result = (Object[])Array.newInstance(computedComponentClass, elements.size());
/*     */       
/* 171 */       return elements.toArray(result);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 177 */     throw new IllegalArgumentException("Cannot convert object of class \"" + target.getClass().getName() + "\" to an array" + (componentClass == null ? "" : new StringBuilder().append(" of ").append(componentClass.getClass().getSimpleName()).toString()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static <T, X> X[] copyOf(T[] original, int newLength, Class<? extends X[]> newType)
/*     */   {
/* 189 */     X[] newArray = newType == Object[].class ? new Object[newLength] : (Object[])Array.newInstance(newType.getComponentType(), newLength);
/* 190 */     System.arraycopy(original, 0, newArray, 0, Math.min(original.length, newLength));
/* 191 */     return newArray;
/*     */   }
/*     */   
/*     */ 
/*     */   public static <T> T[] copyOf(T[] original, int newLength)
/*     */   {
/* 197 */     return copyOf(original, newLength, original.getClass());
/*     */   }
/*     */   
/*     */   public static char[] copyOf(char[] original, int newLength)
/*     */   {
/* 202 */     char[] copy = new char[newLength];
/* 203 */     System.arraycopy(original, 0, copy, 0, Math.min(original.length, newLength));
/* 204 */     return copy;
/*     */   }
/*     */   
/*     */   public static char[] copyOfRange(char[] original, int from, int to)
/*     */   {
/* 209 */     int newLength = to - from;
/* 210 */     if (newLength < 0) {
/* 211 */       throw new IllegalArgumentException("Cannot copy array range with indexes " + from + " and " + to);
/*     */     }
/* 213 */     char[] copy = new char[newLength];
/* 214 */     System.arraycopy(original, from, copy, 0, Math.min(original.length - from, newLength));
/* 215 */     return copy;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\util\ArrayUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */