package org.thymeleaf;

import java.io.OutputStream;
import java.io.Writer;
import java.nio.charset.Charset;

public abstract interface IThrottledTemplateProcessor
{
  public abstract String getProcessorIdentifier();
  
  public abstract TemplateSpec getTemplateSpec();
  
  public abstract boolean isFinished();
  
  public abstract int processAll(Writer paramWriter);
  
  public abstract int processAll(OutputStream paramOutputStream, Charset paramCharset);
  
  public abstract int process(int paramInt, Writer paramWriter);
  
  public abstract int process(int paramInt, OutputStream paramOutputStream, Charset paramCharset);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\IThrottledTemplateProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */