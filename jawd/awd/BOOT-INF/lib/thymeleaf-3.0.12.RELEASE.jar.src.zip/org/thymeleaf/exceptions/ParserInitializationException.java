/*    */ package org.thymeleaf.exceptions;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ParserInitializationException
/*    */   extends TemplateEngineException
/*    */ {
/*    */   private static final long serialVersionUID = -1642601374976564594L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ParserInitializationException(String message, Throwable cause)
/*    */   {
/* 34 */     super(message, cause);
/*    */   }
/*    */   
/*    */   public ParserInitializationException(String message) {
/* 38 */     super(message);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\exceptions\ParserInitializationException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */