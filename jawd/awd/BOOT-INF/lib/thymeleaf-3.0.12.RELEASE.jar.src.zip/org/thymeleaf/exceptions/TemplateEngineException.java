/*    */ package org.thymeleaf.exceptions;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class TemplateEngineException
/*    */   extends RuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = -1080862110715121407L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected TemplateEngineException(String message, Throwable cause)
/*    */   {
/* 34 */     super(message, cause);
/*    */   }
/*    */   
/*    */   protected TemplateEngineException(String message) {
/* 38 */     super(message);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\exceptions\TemplateEngineException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */