/*     */ package org.thymeleaf.exceptions;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TemplateProcessingException
/*     */   extends TemplateEngineException
/*     */ {
/*     */   private static final long serialVersionUID = 5985749439214775193L;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String templateName;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Integer line;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Integer col;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TemplateProcessingException(String message)
/*     */   {
/*  45 */     this(message, null);
/*     */   }
/*     */   
/*     */   public TemplateProcessingException(String message, Throwable cause) {
/*  49 */     this(message, null, cause);
/*     */   }
/*     */   
/*     */   public TemplateProcessingException(String message, String templateName, Throwable cause)
/*     */   {
/*  54 */     super(message, cause);
/*  55 */     this.templateName = templateName;
/*  56 */     this.line = null;
/*  57 */     this.col = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TemplateProcessingException(String message, String templateName, int line, int col)
/*     */   {
/*  72 */     super(message);
/*  73 */     this.templateName = templateName;
/*  74 */     this.line = (line < 0 ? null : Integer.valueOf(line));
/*  75 */     this.col = (col < 0 ? null : Integer.valueOf(col));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TemplateProcessingException(String message, String templateName, int line, int col, Throwable cause)
/*     */   {
/*  90 */     super(message, cause);
/*  91 */     this.templateName = templateName;
/*  92 */     this.line = (line < 0 ? null : Integer.valueOf(line));
/*  93 */     this.col = (col < 0 ? null : Integer.valueOf(col));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getTemplateName()
/*     */   {
/* 100 */     return this.templateName;
/*     */   }
/*     */   
/*     */   public boolean hasTemplateName() {
/* 104 */     return this.templateName != null;
/*     */   }
/*     */   
/*     */   public Integer getLine() {
/* 108 */     return this.line;
/*     */   }
/*     */   
/*     */   public Integer getCol() {
/* 112 */     return this.col;
/*     */   }
/*     */   
/*     */   public boolean hasLineAndCol() {
/* 116 */     return (this.line != null) && (this.col != null);
/*     */   }
/*     */   
/*     */   public void setTemplateName(String templateName) {
/* 120 */     this.templateName = templateName;
/*     */   }
/*     */   
/*     */   public void setLineAndCol(int line, int col) {
/* 124 */     this.line = (line < 0 ? null : Integer.valueOf(line));
/* 125 */     this.col = (col < 0 ? null : Integer.valueOf(col));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMessage()
/*     */   {
/* 134 */     StringBuilder sb = new StringBuilder();
/*     */     
/* 136 */     sb.append(super.getMessage());
/*     */     
/* 138 */     if (this.templateName != null) {
/* 139 */       sb.append(' ');
/* 140 */       sb.append('(');
/* 141 */       sb.append("template: \"");
/* 142 */       sb.append(this.templateName);
/* 143 */       sb.append('"');
/* 144 */       if ((this.line != null) || (this.col != null)) {
/* 145 */         sb.append(" - ");
/* 146 */         if (this.line != null) {
/* 147 */           sb.append("line ");
/* 148 */           sb.append(this.line);
/*     */         }
/* 150 */         if (this.col != null) {
/* 151 */           sb.append(", col ");
/* 152 */           sb.append(this.col);
/*     */         }
/*     */       }
/* 155 */       sb.append(')');
/*     */     }
/*     */     
/* 158 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\exceptions\TemplateProcessingException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */