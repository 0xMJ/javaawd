/*    */ package org.thymeleaf.exceptions;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TemplateAssertionException
/*    */   extends RuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = -2261382147273524844L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private static final String ASSERTION_MESSAGE = "Assertion '%s' not valid in template '%s'";
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private static final String ASSERTION_MESSAGE_LINE_COL = "Assertion '%s' not valid in template '%s', line %d col %d";
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public TemplateAssertionException(String assertionExpression, String templateName, int line, int col)
/*    */   {
/* 48 */     super(createMessage(assertionExpression, templateName, Integer.valueOf(line), Integer.valueOf(col)));
/*    */   }
/*    */   
/*    */   public TemplateAssertionException(String assertionExpression, String templateName)
/*    */   {
/* 53 */     super(createMessage(assertionExpression, templateName, null, null));
/*    */   }
/*    */   
/*    */ 
/*    */   private static String createMessage(String assertionExpression, String templateName, Integer line, Integer col)
/*    */   {
/* 59 */     if ((line == null) || (col == null)) {
/* 60 */       return String.format("Assertion '%s' not valid in template '%s'", new Object[] { assertionExpression, templateName });
/*    */     }
/* 62 */     return String.format("Assertion '%s' not valid in template '%s', line %d col %d", new Object[] { assertionExpression, templateName, line, col });
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\exceptions\TemplateAssertionException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */