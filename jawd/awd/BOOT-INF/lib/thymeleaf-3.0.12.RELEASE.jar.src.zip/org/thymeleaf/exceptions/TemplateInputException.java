/*    */ package org.thymeleaf.exceptions;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TemplateInputException
/*    */   extends TemplateProcessingException
/*    */ {
/*    */   private static final long serialVersionUID = 1818006121265449639L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public TemplateInputException(String message)
/*    */   {
/* 36 */     super(message);
/*    */   }
/*    */   
/*    */   public TemplateInputException(String message, Throwable cause) {
/* 40 */     super(message, cause);
/*    */   }
/*    */   
/*    */   public TemplateInputException(String message, String templateName, Throwable cause) {
/* 44 */     super(message, templateName, cause);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public TemplateInputException(String message, String templateName, int line, int col)
/*    */   {
/* 57 */     super(message, templateName, line, col);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public TemplateInputException(String message, String templateName, int line, int col, Throwable cause)
/*    */   {
/* 71 */     super(message, templateName, line, col, cause);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\exceptions\TemplateInputException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */