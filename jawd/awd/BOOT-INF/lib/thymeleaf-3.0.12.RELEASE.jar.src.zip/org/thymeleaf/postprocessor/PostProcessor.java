/*    */ package org.thymeleaf.postprocessor;
/*    */ 
/*    */ import org.thymeleaf.engine.ITemplateHandler;
/*    */ import org.thymeleaf.templatemode.TemplateMode;
/*    */ import org.thymeleaf.util.Validate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class PostProcessor
/*    */   implements IPostProcessor
/*    */ {
/*    */   private final TemplateMode templateMode;
/*    */   private final Class<? extends ITemplateHandler> handlerClass;
/*    */   private final int precedence;
/*    */   
/*    */   public PostProcessor(TemplateMode templateMode, Class<? extends ITemplateHandler> handlerClass, int precedence)
/*    */   {
/* 51 */     Validate.notNull(templateMode, "Template mode cannot be null");
/* 52 */     Validate.notNull(handlerClass, "Handler class cannot be null");
/*    */     
/* 54 */     this.templateMode = templateMode;
/* 55 */     this.handlerClass = handlerClass;
/* 56 */     this.precedence = precedence;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public final TemplateMode getTemplateMode()
/*    */   {
/* 63 */     return this.templateMode;
/*    */   }
/*    */   
/*    */   public final int getPrecedence()
/*    */   {
/* 68 */     return this.precedence;
/*    */   }
/*    */   
/*    */   public final Class<? extends ITemplateHandler> getHandlerClass()
/*    */   {
/* 73 */     return this.handlerClass;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\postprocessor\PostProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */