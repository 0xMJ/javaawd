/*    */ package org.thymeleaf.linkbuilder;
/*    */ 
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractLinkBuilder
/*    */   implements ILinkBuilder
/*    */ {
/* 40 */   private static final Logger logger = LoggerFactory.getLogger(AbstractLinkBuilder.class);
/*    */   
/* 42 */   private String name = getClass().getName();
/* 43 */   private Integer order = null;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public final String getName()
/*    */   {
/* 58 */     return this.name;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setName(String name)
/*    */   {
/* 70 */     this.name = name;
/*    */   }
/*    */   
/*    */ 
/*    */   public final Integer getOrder()
/*    */   {
/* 76 */     return this.order;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setOrder(Integer order)
/*    */   {
/* 88 */     this.order = order;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\linkbuilder\AbstractLinkBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */