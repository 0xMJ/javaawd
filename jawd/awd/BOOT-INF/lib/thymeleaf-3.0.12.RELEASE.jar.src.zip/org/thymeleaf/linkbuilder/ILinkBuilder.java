package org.thymeleaf.linkbuilder;

import java.util.Map;
import org.thymeleaf.context.IExpressionContext;

public abstract interface ILinkBuilder
{
  public abstract String getName();
  
  public abstract Integer getOrder();
  
  public abstract String buildLink(IExpressionContext paramIExpressionContext, String paramString, Map<String, Object> paramMap);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\linkbuilder\ILinkBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */