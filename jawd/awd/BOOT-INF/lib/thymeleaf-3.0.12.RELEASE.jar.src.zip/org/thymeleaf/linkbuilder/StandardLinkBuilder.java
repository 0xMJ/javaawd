/*     */ package org.thymeleaf.linkbuilder;
/*     */ 
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.thymeleaf.context.IExpressionContext;
/*     */ import org.thymeleaf.context.IWebContext;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.util.Validate;
/*     */ import org.unbescape.uri.UriEscape;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardLinkBuilder
/*     */   extends AbstractLinkBuilder
/*     */ {
/*     */   private static final char URL_TEMPLATE_DELIMITER_PREFIX = '{';
/*     */   private static final char URL_TEMPLATE_DELIMITER_SUFFIX = '}';
/*     */   private static final String URL_TEMPLATE_DELIMITER_SEGMENT_PREFIX = "{/";
/*     */   
/*     */   protected static enum LinkType
/*     */   {
/*  65 */     ABSOLUTE,  CONTEXT_RELATIVE,  SERVER_RELATIVE,  BASE_RELATIVE;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private LinkType() {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final String buildLink(IExpressionContext context, String base, Map<String, Object> parameters)
/*     */   {
/*  83 */     Validate.notNull(context, "Expression context cannot be null");
/*     */     
/*  85 */     if (base == null) {
/*  86 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  91 */     Map<String, Object> linkParameters = (parameters == null) || (parameters.size() == 0) ? null : new LinkedHashMap(parameters);
/*     */     
/*  93 */     filterOutJavaScriptLinks(base);
/*     */     LinkType linkType;
/*     */     LinkType linkType;
/*  96 */     if (isLinkBaseAbsolute(base)) {
/*  97 */       linkType = LinkType.ABSOLUTE; } else { LinkType linkType;
/*  98 */       if (isLinkBaseContextRelative(base)) {
/*  99 */         linkType = LinkType.CONTEXT_RELATIVE; } else { LinkType linkType;
/* 100 */         if (isLinkBaseServerRelative(base)) {
/* 101 */           linkType = LinkType.SERVER_RELATIVE;
/*     */         } else {
/* 103 */           linkType = LinkType.BASE_RELATIVE;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 111 */     int hashPosition = findCharInSequence(base, '#');
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 118 */     boolean mightHaveVariableTemplates = findCharInSequence(base, '{') >= 0;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 128 */     String contextPath = linkType == LinkType.CONTEXT_RELATIVE ? computeContextPath(context, base, parameters) : null;
/* 129 */     boolean contextPathEmpty = (contextPath == null) || (contextPath.length() == 0) || (contextPath.equals("/"));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 138 */     if ((contextPathEmpty) && (linkType != LinkType.SERVER_RELATIVE) && ((linkParameters == null) || 
/* 139 */       (linkParameters.size() == 0)) && (hashPosition < 0) && (!mightHaveVariableTemplates)) {
/* 140 */       return processLink(context, base);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 148 */     StringBuilder linkBase = new StringBuilder(base);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 155 */     String urlFragment = "";
/*     */     
/*     */ 
/* 158 */     if (hashPosition > 0)
/*     */     {
/* 160 */       urlFragment = linkBase.substring(hashPosition);
/* 161 */       linkBase.delete(hashPosition, linkBase.length());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 169 */     if (mightHaveVariableTemplates) {
/* 170 */       linkBase = replaceTemplateParamsInBase(linkBase, linkParameters);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 178 */     if ((linkParameters != null) && (linkParameters.size() > 0))
/*     */     {
/* 180 */       boolean linkBaseHasQuestionMark = findCharInSequence(linkBase, '?') >= 0;
/*     */       
/*     */ 
/* 183 */       if (linkBaseHasQuestionMark) {
/* 184 */         linkBase.append('&');
/*     */       } else {
/* 186 */         linkBase.append('?');
/*     */       }
/*     */       
/*     */ 
/* 190 */       processAllRemainingParametersAsQueryParams(linkBase, linkParameters);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 198 */     if (urlFragment.length() > 0) {
/* 199 */       linkBase.append(urlFragment);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 206 */     if (linkType == LinkType.SERVER_RELATIVE) {
/* 207 */       linkBase.delete(0, 1);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 214 */     if ((linkType == LinkType.CONTEXT_RELATIVE) && (!contextPathEmpty))
/*     */     {
/* 216 */       linkBase.insert(0, contextPath);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 225 */     return processLink(context, linkBase.toString());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static int findCharInSequence(CharSequence seq, char character)
/*     */   {
/* 233 */     int n = seq.length();
/* 234 */     while (n-- != 0) {
/* 235 */       char c = seq.charAt(n);
/* 236 */       if (c == character) {
/* 237 */         return n;
/*     */       }
/*     */     }
/* 240 */     return -1;
/*     */   }
/*     */   
/*     */   private static void filterOutJavaScriptLinks(CharSequence linkBase)
/*     */   {
/* 245 */     if ((linkBase.length() >= 11) && 
/* 246 */       (Character.toLowerCase(linkBase.charAt(0)) == 'j') && 
/* 247 */       (Character.toLowerCase(linkBase.charAt(1)) == 'a') && 
/* 248 */       (Character.toLowerCase(linkBase.charAt(2)) == 'v') && 
/* 249 */       (Character.toLowerCase(linkBase.charAt(3)) == 'a') && 
/* 250 */       (Character.toLowerCase(linkBase.charAt(4)) == 's') && 
/* 251 */       (Character.toLowerCase(linkBase.charAt(5)) == 'c') && 
/* 252 */       (Character.toLowerCase(linkBase.charAt(6)) == 'r') && 
/* 253 */       (Character.toLowerCase(linkBase.charAt(7)) == 'i') && 
/* 254 */       (Character.toLowerCase(linkBase.charAt(8)) == 'p') && 
/* 255 */       (Character.toLowerCase(linkBase.charAt(9)) == 't') && 
/* 256 */       (Character.toLowerCase(linkBase.charAt(10)) == ':'))
/*     */     {
/* 258 */       throw new TemplateProcessingException("'javascript:' is forbidden in this context. Link expressions cannot contain inlined JavaScript code.");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean isLinkBaseAbsolute(CharSequence linkBase)
/*     */   {
/* 268 */     int linkBaseLen = linkBase.length();
/* 269 */     if (linkBaseLen < 2) {
/* 270 */       return false;
/*     */     }
/* 272 */     char c0 = linkBase.charAt(0);
/* 273 */     if ((c0 == 'm') || (c0 == 'M'))
/*     */     {
/* 275 */       if ((linkBase.length() >= 7) && 
/* 276 */         (Character.toLowerCase(linkBase.charAt(1)) == 'a') && 
/* 277 */         (Character.toLowerCase(linkBase.charAt(2)) == 'i') && 
/* 278 */         (Character.toLowerCase(linkBase.charAt(3)) == 'l') && 
/* 279 */         (Character.toLowerCase(linkBase.charAt(4)) == 't') && 
/* 280 */         (Character.toLowerCase(linkBase.charAt(5)) == 'o') && 
/* 281 */         (Character.toLowerCase(linkBase.charAt(6)) == ':')) {
/* 282 */         return true;
/*     */       }
/* 284 */     } else if (c0 == '/') {
/* 285 */       return linkBase.charAt(1) == '/';
/*     */     }
/* 287 */     for (int i = 0; i < linkBaseLen - 2; i++)
/*     */     {
/* 289 */       if ((linkBase.charAt(i) == ':') && (linkBase.charAt(i + 1) == '/') && (linkBase.charAt(i + 2) == '/')) {
/* 290 */         return true;
/*     */       }
/*     */     }
/* 293 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   private static boolean isLinkBaseContextRelative(CharSequence linkBase)
/*     */   {
/* 299 */     if ((linkBase.length() == 0) || (linkBase.charAt(0) != '/')) {
/* 300 */       return false;
/*     */     }
/* 302 */     return (linkBase.length() == 1) || (linkBase.charAt(1) != '/');
/*     */   }
/*     */   
/*     */ 
/*     */   private static boolean isLinkBaseServerRelative(CharSequence linkBase)
/*     */   {
/* 308 */     return (linkBase.length() >= 2) && (linkBase.charAt(0) == '~') && (linkBase.charAt(1) == '/');
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static StringBuilder replaceTemplateParamsInBase(StringBuilder linkBase, Map<String, Object> parameters)
/*     */   {
/* 322 */     if (parameters == null) {
/* 323 */       return linkBase;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 333 */     int questionMarkPosition = findCharInSequence(linkBase, '?');
/*     */     
/* 335 */     Set<String> parameterNames = parameters.keySet();
/* 336 */     Set<String> alreadyProcessedParameters = null;
/*     */     
/* 338 */     for (String parameterName : parameterNames)
/*     */     {
/*     */ 
/* 341 */       boolean escapeAsPathSegment = false;
/*     */       
/*     */ 
/* 344 */       String template = '{' + parameterName + '}';
/*     */       
/* 346 */       int templateIndex = linkBase.indexOf(template);
/*     */       
/* 348 */       if (templateIndex < 0) {
/* 349 */         template = "{/" + parameterName + '}';
/* 350 */         templateIndex = linkBase.indexOf(template);
/*     */         
/* 352 */         if (templateIndex >= 0)
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 358 */           escapeAsPathSegment = true;
/*     */         }
/*     */       }
/*     */       else {
/* 362 */         if (alreadyProcessedParameters == null) {
/* 363 */           alreadyProcessedParameters = new HashSet(parameterNames.size());
/*     */         }
/* 365 */         alreadyProcessedParameters.add(parameterName);
/*     */         
/*     */ 
/* 368 */         Object parameterValue = parameters.get(parameterName);
/* 369 */         String templateReplacement = formatParameterValueAsUnescapedVariableTemplate(parameterValue);
/* 370 */         int templateReplacementLen = templateReplacement.length();
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 375 */         int templateLen = template.length();
/* 376 */         int start = templateIndex;
/* 377 */         while (start > -1)
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/* 382 */           String escapedReplacement = (questionMarkPosition == -1) || (start < questionMarkPosition) ? UriEscape.escapeUriPath(templateReplacement) : escapeAsPathSegment ? UriEscape.escapeUriPathSegment(templateReplacement) : UriEscape.escapeUriQueryParam(templateReplacement);
/* 383 */           linkBase.replace(start, start + templateLen, escapedReplacement);
/* 384 */           start = linkBase.indexOf(template, start + templateReplacementLen);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 389 */     if (alreadyProcessedParameters != null) {
/* 390 */       for (String alreadyProcessedParameter : alreadyProcessedParameters) {
/* 391 */         parameters.remove(alreadyProcessedParameter);
/*     */       }
/*     */     }
/*     */     
/* 395 */     return linkBase;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static String formatParameterValueAsUnescapedVariableTemplate(Object parameterValue)
/*     */   {
/* 409 */     if (parameterValue == null) {
/* 410 */       return "";
/*     */     }
/*     */     
/* 413 */     if (!(parameterValue instanceof List)) {
/* 414 */       return parameterValue.toString();
/*     */     }
/*     */     
/* 417 */     List<?> values = (List)parameterValue;
/* 418 */     int valuesLen = values.size();
/* 419 */     StringBuilder strBuilder = new StringBuilder(valuesLen * 16);
/* 420 */     for (int i = 0; i < valuesLen; i++) {
/* 421 */       Object valueItem = values.get(i);
/* 422 */       if (strBuilder.length() > 0) {
/* 423 */         strBuilder.append(',');
/*     */       }
/* 425 */       strBuilder.append(valueItem == null ? "" : valueItem.toString());
/*     */     }
/* 427 */     return strBuilder.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static void processAllRemainingParametersAsQueryParams(StringBuilder strBuilder, Map<String, Object> parameters)
/*     */   {
/* 434 */     int parameterSize = parameters.size();
/*     */     
/* 436 */     if (parameterSize <= 0) {
/* 437 */       return;
/*     */     }
/*     */     
/* 440 */     Set<String> parameterNames = parameters.keySet();
/*     */     
/* 442 */     int i = 0;
/* 443 */     for (String parameterName : parameterNames)
/*     */     {
/* 445 */       Object value = parameters.get(parameterName);
/*     */       
/* 447 */       if (value == null) {
/* 448 */         if (i > 0) {
/* 449 */           strBuilder.append('&');
/*     */         }
/* 451 */         strBuilder.append(UriEscape.escapeUriQueryParam(parameterName));
/* 452 */         i++;
/*     */ 
/*     */ 
/*     */       }
/* 456 */       else if (!(value instanceof List)) {
/* 457 */         if (i > 0) {
/* 458 */           strBuilder.append('&');
/*     */         }
/* 460 */         strBuilder.append(UriEscape.escapeUriQueryParam(parameterName));
/* 461 */         strBuilder.append('=');
/* 462 */         strBuilder.append(UriEscape.escapeUriQueryParam(value.toString()));
/* 463 */         i++;
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 468 */         List<?> values = (List)value;
/* 469 */         int valuesLen = values.size();
/* 470 */         for (int j = 0; j < valuesLen; j++) {
/* 471 */           Object valueItem = values.get(j);
/* 472 */           if ((i > 0) || (j > 0)) {
/* 473 */             strBuilder.append('&');
/*     */           }
/* 475 */           strBuilder.append(UriEscape.escapeUriQueryParam(parameterName));
/* 476 */           if (valueItem != null) {
/* 477 */             strBuilder.append('=');
/* 478 */             strBuilder.append(UriEscape.escapeUriQueryParam(valueItem.toString()));
/*     */           }
/*     */         }
/*     */         
/* 482 */         i++;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String computeContextPath(IExpressionContext context, String base, Map<String, Object> parameters)
/*     */   {
/* 513 */     if (!(context instanceof IWebContext))
/*     */     {
/*     */ 
/* 516 */       throw new TemplateProcessingException("Link base \"" + base + "\" cannot be context relative (/...) unless the context used for executing the engine implements the " + IWebContext.class.getName() + " interface");
/*     */     }
/*     */     
/*     */ 
/* 520 */     HttpServletRequest request = ((IWebContext)context).getRequest();
/* 521 */     return request.getContextPath();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String processLink(IExpressionContext context, String link)
/*     */   {
/* 546 */     if (!(context instanceof IWebContext)) {
/* 547 */       return link;
/*     */     }
/*     */     
/* 550 */     HttpServletResponse response = ((IWebContext)context).getResponse();
/* 551 */     return response != null ? response.encodeURL(link) : link;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\linkbuilder\StandardLinkBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */