/*      */ package org.thymeleaf;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.Writer;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.RoundingMode;
/*      */ import java.util.Collections;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Set;
/*      */ import org.slf4j.Logger;
/*      */ import org.slf4j.LoggerFactory;
/*      */ import org.thymeleaf.cache.ICacheManager;
/*      */ import org.thymeleaf.cache.StandardCacheManager;
/*      */ import org.thymeleaf.context.IContext;
/*      */ import org.thymeleaf.context.IEngineContextFactory;
/*      */ import org.thymeleaf.context.StandardEngineContextFactory;
/*      */ import org.thymeleaf.dialect.IDialect;
/*      */ import org.thymeleaf.engine.TemplateManager;
/*      */ import org.thymeleaf.exceptions.TemplateEngineException;
/*      */ import org.thymeleaf.exceptions.TemplateOutputException;
/*      */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*      */ import org.thymeleaf.linkbuilder.ILinkBuilder;
/*      */ import org.thymeleaf.linkbuilder.StandardLinkBuilder;
/*      */ import org.thymeleaf.messageresolver.IMessageResolver;
/*      */ import org.thymeleaf.messageresolver.StandardMessageResolver;
/*      */ import org.thymeleaf.standard.StandardDialect;
/*      */ import org.thymeleaf.templateparser.markup.decoupled.IDecoupledTemplateLogicResolver;
/*      */ import org.thymeleaf.templateparser.markup.decoupled.StandardDecoupledTemplateLogicResolver;
/*      */ import org.thymeleaf.templateresolver.ITemplateResolver;
/*      */ import org.thymeleaf.templateresolver.StringTemplateResolver;
/*      */ import org.thymeleaf.util.FastStringWriter;
/*      */ import org.thymeleaf.util.LoggingUtils;
/*      */ import org.thymeleaf.util.Validate;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class TemplateEngine
/*      */   implements ITemplateEngine
/*      */ {
/*  237 */   public static final String TIMER_LOGGER_NAME = TemplateEngine.class.getName() + ".TIMER";
/*      */   
/*  239 */   private static final Logger logger = LoggerFactory.getLogger(TemplateEngine.class);
/*  240 */   private static final Logger timerLogger = LoggerFactory.getLogger(TIMER_LOGGER_NAME);
/*      */   
/*      */   private static final int NANOS_IN_SECOND = 1000000;
/*      */   
/*  244 */   private volatile boolean initialized = false;
/*      */   
/*  246 */   private final Set<DialectConfiguration> dialectConfigurations = new LinkedHashSet(3);
/*  247 */   private final Set<ITemplateResolver> templateResolvers = new LinkedHashSet(3);
/*  248 */   private final Set<IMessageResolver> messageResolvers = new LinkedHashSet(3);
/*  249 */   private final Set<ILinkBuilder> linkBuilders = new LinkedHashSet(3);
/*  250 */   private ICacheManager cacheManager = null;
/*  251 */   private IEngineContextFactory engineContextFactory = null;
/*  252 */   private IDecoupledTemplateLogicResolver decoupledTemplateLogicResolver = null;
/*      */   
/*      */ 
/*  255 */   private IEngineConfiguration configuration = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public TemplateEngine()
/*      */   {
/*  273 */     setCacheManager(new StandardCacheManager());
/*  274 */     setEngineContextFactory(new StandardEngineContextFactory());
/*  275 */     setMessageResolver(new StandardMessageResolver());
/*  276 */     setLinkBuilder(new StandardLinkBuilder());
/*  277 */     setDecoupledTemplateLogicResolver(new StandardDecoupledTemplateLogicResolver());
/*  278 */     setDialect(new StandardDialect());
/*      */   }
/*      */   
/*      */ 
/*      */   private void checkNotInitialized()
/*      */   {
/*  284 */     if (this.initialized) {
/*  285 */       throw new IllegalStateException("Template engine has already been initialized (probably because it has already been executed or a fully-built Configuration object has been requested from it. At this state, no modifications on its configuration are allowed.");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final void initialize()
/*      */   {
/*  319 */     if (!this.initialized)
/*      */     {
/*  321 */       synchronized (this)
/*      */       {
/*  323 */         if (!this.initialized)
/*      */         {
/*  325 */           logger.debug("[THYMELEAF] INITIALIZING TEMPLATE ENGINE");
/*      */           
/*      */ 
/*  328 */           initializeSpecific();
/*      */           
/*      */ 
/*  331 */           if (this.templateResolvers.isEmpty()) {
/*  332 */             this.templateResolvers.add(new StringTemplateResolver());
/*      */           }
/*      */           
/*      */ 
/*  336 */           this.configuration = new EngineConfiguration(this.templateResolvers, this.messageResolvers, this.linkBuilders, this.dialectConfigurations, this.cacheManager, this.engineContextFactory, this.decoupledTemplateLogicResolver);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*  341 */           ((EngineConfiguration)this.configuration).initialize();
/*      */           
/*  343 */           this.initialized = true;
/*      */           
/*      */ 
/*  346 */           ConfigurationPrinterHelper.printConfiguration(this.configuration);
/*      */           
/*  348 */           logger.debug("[THYMELEAF] TEMPLATE ENGINE INITIALIZED");
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void initializeSpecific() {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final boolean isInitialized()
/*      */   {
/*  398 */     return this.initialized;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public IEngineConfiguration getConfiguration()
/*      */   {
/*  405 */     if (!this.initialized) {
/*  406 */       initialize();
/*      */     }
/*  408 */     return this.configuration;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public final Map<String, Set<IDialect>> getDialectsByPrefix()
/*      */   {
/*      */     Set<DialectConfiguration> dialectConfs;
/*      */     
/*      */ 
/*      */     Set<DialectConfiguration> dialectConfs;
/*      */     
/*      */ 
/*  422 */     if (this.initialized) {
/*  423 */       dialectConfs = this.configuration.getDialectConfigurations();
/*      */     } else {
/*  425 */       dialectConfs = this.dialectConfigurations;
/*      */     }
/*  427 */     Map<String, Set<IDialect>> dialectsByPrefix = new LinkedHashMap(3);
/*  428 */     for (DialectConfiguration dialectConfiguration : dialectConfs) {
/*  429 */       String prefix = dialectConfiguration.getPrefix();
/*  430 */       Set<IDialect> dialectsForPrefix = (Set)dialectsByPrefix.get(prefix);
/*  431 */       if (dialectsForPrefix == null) {
/*  432 */         dialectsForPrefix = new LinkedHashSet(2);
/*  433 */         dialectsByPrefix.put(prefix, dialectsForPrefix);
/*      */       }
/*  435 */       dialectsForPrefix.add(dialectConfiguration.getDialect());
/*      */     }
/*  437 */     return Collections.unmodifiableMap(dialectsByPrefix);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final Set<IDialect> getDialects()
/*      */   {
/*  449 */     if (this.initialized) {
/*  450 */       return this.configuration.getDialects();
/*      */     }
/*  452 */     Set<IDialect> dialects = new LinkedHashSet(this.dialectConfigurations.size());
/*  453 */     for (DialectConfiguration dialectConfiguration : this.dialectConfigurations) {
/*  454 */       dialects.add(dialectConfiguration.getDialect());
/*      */     }
/*  456 */     return Collections.unmodifiableSet(dialects);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDialect(IDialect dialect)
/*      */   {
/*  477 */     Validate.notNull(dialect, "Dialect cannot be null");
/*  478 */     checkNotInitialized();
/*  479 */     this.dialectConfigurations.clear();
/*  480 */     this.dialectConfigurations.add(new DialectConfiguration(dialect));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addDialect(String prefix, IDialect dialect)
/*      */   {
/*  501 */     Validate.notNull(dialect, "Dialect cannot be null");
/*  502 */     checkNotInitialized();
/*  503 */     this.dialectConfigurations.add(new DialectConfiguration(prefix, dialect));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addDialect(IDialect dialect)
/*      */   {
/*  524 */     Validate.notNull(dialect, "Dialect cannot be null");
/*  525 */     checkNotInitialized();
/*  526 */     this.dialectConfigurations.add(new DialectConfiguration(dialect));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDialectsByPrefix(Map<String, IDialect> dialects)
/*      */   {
/*  545 */     Validate.notNull(dialects, "Dialect map cannot be null");
/*  546 */     checkNotInitialized();
/*  547 */     this.dialectConfigurations.clear();
/*  548 */     for (Map.Entry<String, IDialect> dialectEntry : dialects.entrySet()) {
/*  549 */       addDialect((String)dialectEntry.getKey(), (IDialect)dialectEntry.getValue());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDialects(Set<IDialect> dialects)
/*      */   {
/*  568 */     Validate.notNull(dialects, "Dialect set cannot be null");
/*  569 */     checkNotInitialized();
/*  570 */     this.dialectConfigurations.clear();
/*  571 */     for (IDialect dialect : dialects) {
/*  572 */       addDialect(dialect);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAdditionalDialects(Set<IDialect> additionalDialects)
/*      */   {
/*  595 */     Validate.notNull(additionalDialects, "Dialect set cannot be null");
/*  596 */     checkNotInitialized();
/*  597 */     for (IDialect dialect : additionalDialects) {
/*  598 */       addDialect(dialect);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void clearDialects()
/*      */   {
/*  615 */     checkNotInitialized();
/*  616 */     this.dialectConfigurations.clear();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final Set<ITemplateResolver> getTemplateResolvers()
/*      */   {
/*  629 */     if (this.initialized) {
/*  630 */       return this.configuration.getTemplateResolvers();
/*      */     }
/*  632 */     return Collections.unmodifiableSet(this.templateResolvers);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTemplateResolvers(Set<ITemplateResolver> templateResolvers)
/*      */   {
/*  643 */     Validate.notNull(templateResolvers, "Template Resolver set cannot be null");
/*  644 */     checkNotInitialized();
/*  645 */     this.templateResolvers.clear();
/*  646 */     for (ITemplateResolver templateResolver : templateResolvers) {
/*  647 */       addTemplateResolver(templateResolver);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addTemplateResolver(ITemplateResolver templateResolver)
/*      */   {
/*  659 */     Validate.notNull(templateResolver, "Template Resolver cannot be null");
/*  660 */     checkNotInitialized();
/*  661 */     this.templateResolvers.add(templateResolver);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTemplateResolver(ITemplateResolver templateResolver)
/*      */   {
/*  676 */     Validate.notNull(templateResolver, "Template Resolver cannot be null");
/*  677 */     checkNotInitialized();
/*  678 */     this.templateResolvers.clear();
/*  679 */     this.templateResolvers.add(templateResolver);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final ICacheManager getCacheManager()
/*      */   {
/*  696 */     if (this.initialized) {
/*  697 */       return this.configuration.getCacheManager();
/*      */     }
/*  699 */     return this.cacheManager;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCacheManager(ICacheManager cacheManager)
/*      */   {
/*  723 */     checkNotInitialized();
/*  724 */     this.cacheManager = cacheManager;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final IEngineContextFactory getEngineContextFactory()
/*      */   {
/*  742 */     if (this.initialized) {
/*  743 */       return this.configuration.getEngineContextFactory();
/*      */     }
/*  745 */     return this.engineContextFactory;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setEngineContextFactory(IEngineContextFactory engineContextFactory)
/*      */   {
/*  768 */     Validate.notNull(engineContextFactory, "Engine Context Factory cannot be set to null");
/*  769 */     checkNotInitialized();
/*  770 */     this.engineContextFactory = engineContextFactory;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final IDecoupledTemplateLogicResolver getDecoupledTemplateLogicResolver()
/*      */   {
/*  788 */     if (this.initialized) {
/*  789 */       return this.configuration.getDecoupledTemplateLogicResolver();
/*      */     }
/*  791 */     return this.decoupledTemplateLogicResolver;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDecoupledTemplateLogicResolver(IDecoupledTemplateLogicResolver decoupledTemplateLogicResolver)
/*      */   {
/*  814 */     Validate.notNull(decoupledTemplateLogicResolver, "Decoupled Template Logic Resolver cannot be set to null");
/*  815 */     checkNotInitialized();
/*  816 */     this.decoupledTemplateLogicResolver = decoupledTemplateLogicResolver;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final Set<IMessageResolver> getMessageResolvers()
/*      */   {
/*  828 */     if (this.initialized) {
/*  829 */       return this.configuration.getMessageResolvers();
/*      */     }
/*  831 */     return Collections.unmodifiableSet(this.messageResolvers);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setMessageResolvers(Set<IMessageResolver> messageResolvers)
/*      */   {
/*  848 */     Validate.notNull(messageResolvers, "Message Resolver set cannot be null");
/*  849 */     checkNotInitialized();
/*  850 */     this.messageResolvers.clear();
/*  851 */     for (IMessageResolver messageResolver : messageResolvers) {
/*  852 */       addMessageResolver(messageResolver);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addMessageResolver(IMessageResolver messageResolver)
/*      */   {
/*  871 */     Validate.notNull(messageResolver, "Message Resolver cannot be null");
/*  872 */     checkNotInitialized();
/*  873 */     this.messageResolvers.add(messageResolver);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setMessageResolver(IMessageResolver messageResolver)
/*      */   {
/*  894 */     Validate.notNull(messageResolver, "Message Resolver cannot be null");
/*  895 */     checkNotInitialized();
/*  896 */     this.messageResolvers.clear();
/*  897 */     this.messageResolvers.add(messageResolver);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final Set<ILinkBuilder> getLinkBuilders()
/*      */   {
/*  909 */     if (this.initialized) {
/*  910 */       return this.configuration.getLinkBuilders();
/*      */     }
/*  912 */     return Collections.unmodifiableSet(this.linkBuilders);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLinkBuilders(Set<ILinkBuilder> linkBuilders)
/*      */   {
/*  929 */     Validate.notNull(linkBuilders, "Link Builder set cannot be null");
/*  930 */     checkNotInitialized();
/*  931 */     this.linkBuilders.clear();
/*  932 */     for (ILinkBuilder linkBuilder : linkBuilders) {
/*  933 */       addLinkBuilder(linkBuilder);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addLinkBuilder(ILinkBuilder linkBuilder)
/*      */   {
/*  952 */     Validate.notNull(linkBuilder, "Link Builder cannot be null");
/*  953 */     checkNotInitialized();
/*  954 */     this.linkBuilders.add(linkBuilder);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLinkBuilder(ILinkBuilder linkBuilder)
/*      */   {
/*  975 */     Validate.notNull(linkBuilder, "Link Builder cannot be null");
/*  976 */     checkNotInitialized();
/*  977 */     this.linkBuilders.clear();
/*  978 */     this.linkBuilders.add(linkBuilder);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void clearTemplateCache()
/*      */   {
/*  997 */     if (!this.initialized) {
/*  998 */       initialize();
/*      */     }
/* 1000 */     this.configuration.getTemplateManager().clearCaches();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void clearTemplateCacheFor(String templateName)
/*      */   {
/* 1017 */     Validate.notNull(templateName, "Template name cannot be null");
/* 1018 */     if (!this.initialized) {
/* 1019 */       initialize();
/*      */     }
/* 1021 */     this.configuration.getTemplateManager().clearCachesFor(templateName);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String threadIndex()
/*      */   {
/* 1041 */     return Thread.currentThread().getName();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public final String process(String template, IContext context)
/*      */   {
/* 1048 */     return process(new TemplateSpec(template, null, null, null, null), context);
/*      */   }
/*      */   
/*      */   public final String process(String template, Set<String> templateSelectors, IContext context)
/*      */   {
/* 1053 */     return process(new TemplateSpec(template, templateSelectors, null, null, null), context);
/*      */   }
/*      */   
/*      */   public final String process(TemplateSpec templateSpec, IContext context)
/*      */   {
/* 1058 */     Writer stringWriter = new FastStringWriter(100);
/* 1059 */     process(templateSpec, context, stringWriter);
/* 1060 */     return stringWriter.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public final void process(String template, IContext context, Writer writer)
/*      */   {
/* 1067 */     process(new TemplateSpec(template, null, null, null, null), context, writer);
/*      */   }
/*      */   
/*      */   public final void process(String template, Set<String> templateSelectors, IContext context, Writer writer)
/*      */   {
/* 1072 */     process(new TemplateSpec(template, templateSelectors, null, null, null), context, writer);
/*      */   }
/*      */   
/*      */ 
/*      */   public final void process(TemplateSpec templateSpec, IContext context, Writer writer)
/*      */   {
/* 1078 */     if (!this.initialized) {
/* 1079 */       initialize();
/*      */     }
/*      */     
/*      */     try
/*      */     {
/* 1084 */       Validate.notNull(templateSpec, "Template Specification cannot be null");
/* 1085 */       Validate.notNull(context, "Context cannot be null");
/* 1086 */       Validate.notNull(writer, "Writer cannot be null");
/*      */       
/*      */ 
/*      */ 
/* 1090 */       if (logger.isTraceEnabled()) {
/* 1091 */         logger.trace("[THYMELEAF][{}] STARTING PROCESS OF TEMPLATE \"{}\" WITH LOCALE {}", new Object[] {
/* 1092 */           threadIndex(), templateSpec, context.getLocale() });
/*      */       }
/*      */       
/* 1095 */       long startNanos = System.nanoTime();
/*      */       
/* 1097 */       TemplateManager templateManager = this.configuration.getTemplateManager();
/* 1098 */       templateManager.parseAndProcess(templateSpec, context, writer);
/*      */       
/* 1100 */       long endNanos = System.nanoTime();
/*      */       
/* 1102 */       if (logger.isTraceEnabled()) {
/* 1103 */         logger.trace("[THYMELEAF][{}] FINISHED PROCESS AND OUTPUT OF TEMPLATE \"{}\" WITH LOCALE {}", new Object[] {
/* 1104 */           threadIndex(), templateSpec, context.getLocale() });
/*      */       }
/*      */       
/* 1107 */       if (timerLogger.isTraceEnabled()) {
/* 1108 */         BigDecimal elapsed = BigDecimal.valueOf(endNanos - startNanos);
/* 1109 */         BigDecimal elapsedMs = elapsed.divide(BigDecimal.valueOf(1000000L), RoundingMode.HALF_UP);
/* 1110 */         timerLogger.trace("[THYMELEAF][{}][{}][{}][{}][{}] TEMPLATE \"{}\" WITH LOCALE {} PROCESSED IN {} nanoseconds (approx. {}ms)", new Object[] {
/*      */         
/*      */ 
/* 1113 */           threadIndex(), 
/* 1114 */           LoggingUtils.loggifyTemplateName(templateSpec.getTemplate()), context.getLocale(), elapsed, elapsedMs, templateSpec, context
/* 1115 */           .getLocale(), elapsed, elapsedMs });
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */       try
/*      */       {
/* 1122 */         writer.flush();
/*      */       } catch (IOException e) {
/* 1124 */         throw new TemplateOutputException("An error happened while flushing output writer", templateSpec.getTemplate(), -1, -1, e);
/*      */       }
/*      */       
/*      */     }
/*      */     catch (TemplateOutputException e)
/*      */     {
/* 1130 */       logger.error(String.format("[THYMELEAF][%s] Exception processing template \"%s\": %s", new Object[] { threadIndex(), templateSpec, e.getMessage() }), e);
/* 1131 */       throw e;
/*      */ 
/*      */     }
/*      */     catch (TemplateEngineException e)
/*      */     {
/* 1136 */       logger.error(String.format("[THYMELEAF][%s] Exception processing template \"%s\": %s", new Object[] { threadIndex(), templateSpec, e.getMessage() }), e);
/* 1137 */       throw e;
/*      */ 
/*      */     }
/*      */     catch (RuntimeException e)
/*      */     {
/* 1142 */       logger.error(String.format("[THYMELEAF][%s] Exception processing template \"%s\": %s", new Object[] { threadIndex(), templateSpec, e.getMessage() }), e);
/* 1143 */       throw new TemplateProcessingException("Exception processing template", templateSpec.toString(), e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final IThrottledTemplateProcessor processThrottled(String template, IContext context)
/*      */   {
/* 1153 */     return processThrottled(new TemplateSpec(template, null, null, null, null), context);
/*      */   }
/*      */   
/*      */   public final IThrottledTemplateProcessor processThrottled(String template, Set<String> templateSelectors, IContext context)
/*      */   {
/* 1158 */     return processThrottled(new TemplateSpec(template, templateSelectors, null, null, null), context);
/*      */   }
/*      */   
/*      */ 
/*      */   public final IThrottledTemplateProcessor processThrottled(TemplateSpec templateSpec, IContext context)
/*      */   {
/* 1164 */     if (!this.initialized) {
/* 1165 */       initialize();
/*      */     }
/*      */     
/*      */ 
/*      */     try
/*      */     {
/* 1171 */       Validate.notNull(templateSpec, "Template Specification cannot be null");
/* 1172 */       Validate.notNull(context, "Context cannot be null");
/*      */       
/*      */ 
/*      */ 
/* 1176 */       if (logger.isTraceEnabled()) {
/* 1177 */         logger.trace("[THYMELEAF][{}] STARTING PREPARATION OF THROTTLED TEMPLATE \"{}\" WITH LOCALE {}", new Object[] {
/* 1178 */           threadIndex(), templateSpec, context.getLocale() });
/*      */       }
/*      */       
/* 1181 */       long startNanos = System.nanoTime();
/*      */       
/* 1183 */       TemplateManager templateManager = this.configuration.getTemplateManager();
/* 1184 */       IThrottledTemplateProcessor throttledTemplateProcessor = templateManager.parseAndProcessThrottled(templateSpec, context);
/*      */       
/* 1186 */       long endNanos = System.nanoTime();
/*      */       
/* 1188 */       if (logger.isTraceEnabled()) {
/* 1189 */         logger.trace("[THYMELEAF][{}] FINISHED PREPARATION OF THROTTLED TEMPLATE \"{}\" WITH LOCALE {}", new Object[] {
/* 1190 */           threadIndex(), templateSpec, context.getLocale() });
/*      */       }
/*      */       
/* 1193 */       if (timerLogger.isTraceEnabled()) {
/* 1194 */         BigDecimal elapsed = BigDecimal.valueOf(endNanos - startNanos);
/* 1195 */         BigDecimal elapsedMs = elapsed.divide(BigDecimal.valueOf(1000000L), RoundingMode.HALF_UP);
/* 1196 */         timerLogger.trace("[THYMELEAF][{}][{}][{}][{}][{}] TEMPLATE \"{}\" WITH LOCALE {} PREPARED FOR THROTTLED PROCESSING IN {} nanoseconds (approx. {}ms)", new Object[] {
/*      */         
/*      */ 
/* 1199 */           threadIndex(), 
/* 1200 */           LoggingUtils.loggifyTemplateName(templateSpec.getTemplate()), context.getLocale(), elapsed, elapsedMs, templateSpec, context
/* 1201 */           .getLocale(), elapsed, elapsedMs });
/*      */       }
/*      */       
/*      */     }
/*      */     catch (TemplateOutputException e)
/*      */     {
/* 1207 */       logger.error(String.format("[THYMELEAF][%s] Exception preparing throttled template \"%s\": %s", new Object[] { threadIndex(), templateSpec, e.getMessage() }), e);
/* 1208 */       throw e;
/*      */ 
/*      */     }
/*      */     catch (TemplateEngineException e)
/*      */     {
/* 1213 */       logger.error(String.format("[THYMELEAF][%s] Exception preparing throttled template \"%s\": %s", new Object[] { threadIndex(), templateSpec, e.getMessage() }), e);
/* 1214 */       throw e;
/*      */ 
/*      */     }
/*      */     catch (RuntimeException e)
/*      */     {
/* 1219 */       logger.error(String.format("[THYMELEAF][%s] Exception preparing throttled template \"%s\": %s", new Object[] { threadIndex(), templateSpec, e.getMessage() }), e);
/* 1220 */       throw new TemplateProcessingException("Exception preparing throttled template", templateSpec.toString(), e);
/*      */     }
/*      */     
/*      */     IThrottledTemplateProcessor throttledTemplateProcessor;
/* 1224 */     return throttledTemplateProcessor;
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\TemplateEngine.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */