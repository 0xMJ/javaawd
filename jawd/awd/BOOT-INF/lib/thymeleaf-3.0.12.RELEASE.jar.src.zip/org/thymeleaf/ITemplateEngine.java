package org.thymeleaf;

import java.io.Writer;
import java.util.Set;
import org.thymeleaf.context.IContext;

public abstract interface ITemplateEngine
{
  public abstract IEngineConfiguration getConfiguration();
  
  public abstract String process(String paramString, IContext paramIContext);
  
  public abstract String process(String paramString, Set<String> paramSet, IContext paramIContext);
  
  public abstract String process(TemplateSpec paramTemplateSpec, IContext paramIContext);
  
  public abstract void process(String paramString, IContext paramIContext, Writer paramWriter);
  
  public abstract void process(String paramString, Set<String> paramSet, IContext paramIContext, Writer paramWriter);
  
  public abstract void process(TemplateSpec paramTemplateSpec, IContext paramIContext, Writer paramWriter);
  
  public abstract IThrottledTemplateProcessor processThrottled(String paramString, IContext paramIContext);
  
  public abstract IThrottledTemplateProcessor processThrottled(String paramString, Set<String> paramSet, IContext paramIContext);
  
  public abstract IThrottledTemplateProcessor processThrottled(TemplateSpec paramTemplateSpec, IContext paramIContext);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\ITemplateEngine.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */