/*     */ package org.thymeleaf;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.TreeSet;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ import org.thymeleaf.util.ContentTypeUtils;
/*     */ import org.thymeleaf.util.LoggingUtils;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class TemplateSpec
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 51214133L;
/*     */   private final String template;
/*     */   private final Set<String> templateSelectors;
/*     */   private final TemplateMode templateMode;
/*     */   private final Map<String, Object> templateResolutionAttributes;
/*     */   private final String outputContentType;
/*     */   private final boolean outputSSE;
/*     */   
/*     */   public TemplateSpec(String template, TemplateMode templateMode)
/*     */   {
/* 102 */     this(template, null, templateMode, null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TemplateSpec(String template, String outputContentType)
/*     */   {
/* 146 */     this(template, null, null, outputContentType, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TemplateSpec(String template, Map<String, Object> templateResolutionAttributes)
/*     */   {
/* 179 */     this(template, null, null, null, templateResolutionAttributes);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TemplateSpec(String template, Set<String> templateSelectors, TemplateMode templateMode, Map<String, Object> templateResolutionAttributes)
/*     */   {
/* 226 */     this(template, templateSelectors, templateMode, null, templateResolutionAttributes);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TemplateSpec(String template, Set<String> templateSelectors, String outputContentType, Map<String, Object> templateResolutionAttributes)
/*     */   {
/* 290 */     this(template, templateSelectors, null, outputContentType, templateResolutionAttributes);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   TemplateSpec(String template, Set<String> templateSelectors, TemplateMode templateMode, String outputContentType, Map<String, Object> templateResolutionAttributes)
/*     */   {
/* 314 */     Validate.notNull(template, "Template cannot be null");
/* 315 */     Validate.isTrue((templateMode == null) || (outputContentType == null), "If template mode or output content type are specified, the other one cannot");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 323 */     this.template = template;
/* 324 */     if ((templateSelectors != null) && (!templateSelectors.isEmpty())) {
/* 325 */       Validate.containsNoEmpties(templateSelectors, "If specified, the Template Selector set cannot contain any nulls or empties");
/*     */       
/* 327 */       if (templateSelectors.size() == 1) {
/* 328 */         this.templateSelectors = Collections.singleton(templateSelectors.iterator().next());
/*     */       }
/*     */       else
/*     */       {
/* 332 */         this.templateSelectors = Collections.unmodifiableSet(new TreeSet(templateSelectors));
/*     */       }
/*     */     } else {
/* 335 */       this.templateSelectors = null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 340 */     this.templateResolutionAttributes = ((templateResolutionAttributes != null) && (!templateResolutionAttributes.isEmpty()) ? Collections.unmodifiableMap(new HashMap(templateResolutionAttributes)) : null);
/*     */     
/* 342 */     this.outputContentType = outputContentType;
/*     */     
/*     */ 
/* 345 */     TemplateMode computedTemplateMode = ContentTypeUtils.computeTemplateModeForContentType(this.outputContentType);
/*     */     
/* 347 */     if (computedTemplateMode != null) {
/* 348 */       this.templateMode = computedTemplateMode;
/*     */     } else {
/* 350 */       this.templateMode = templateMode;
/*     */     }
/*     */     
/* 353 */     this.outputSSE = ContentTypeUtils.isContentTypeSSE(this.outputContentType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getTemplate()
/*     */   {
/* 372 */     return this.template;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasTemplateSelectors()
/*     */   {
/* 385 */     return this.templateSelectors != null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Set<String> getTemplateSelectors()
/*     */   {
/* 404 */     return this.templateSelectors;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasTemplateMode()
/*     */   {
/* 416 */     return this.templateMode != null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TemplateMode getTemplateMode()
/*     */   {
/* 433 */     return this.templateMode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasTemplateResolutionAttributes()
/*     */   {
/* 446 */     return this.templateResolutionAttributes != null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<String, Object> getTemplateResolutionAttributes()
/*     */   {
/* 470 */     return this.templateResolutionAttributes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getOutputContentType()
/*     */   {
/* 503 */     return this.outputContentType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isOutputSSE()
/*     */   {
/* 521 */     return this.outputSSE;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/* 528 */     if (this == o) {
/* 529 */       return true;
/*     */     }
/* 531 */     if (!(o instanceof TemplateSpec)) {
/* 532 */       return false;
/*     */     }
/* 534 */     TemplateSpec that = (TemplateSpec)o;
/* 535 */     if (!this.template.equals(that.template)) {
/* 536 */       return false;
/*     */     }
/* 538 */     if (this.templateSelectors != null ? !this.templateSelectors.equals(that.templateSelectors) : that.templateSelectors != null) {
/* 539 */       return false;
/*     */     }
/* 541 */     if (this.templateMode != that.templateMode) {
/* 542 */       return false;
/*     */     }
/* 544 */     if (!this.outputContentType.equals(that.outputContentType)) {
/* 545 */       return false;
/*     */     }
/*     */     
/* 548 */     return this.templateResolutionAttributes != null ? this.templateResolutionAttributes.equals(that.templateResolutionAttributes) : that.templateResolutionAttributes == null;
/*     */   }
/*     */   
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 554 */     int result = this.template.hashCode();
/* 555 */     result = 31 * result + (this.templateSelectors != null ? this.templateSelectors.hashCode() : 0);
/* 556 */     result = 31 * result + (this.templateMode != null ? this.templateMode.hashCode() : 0);
/* 557 */     result = 31 * result + (this.outputContentType != null ? this.outputContentType.hashCode() : 0);
/* 558 */     result = 31 * result + (this.templateResolutionAttributes != null ? this.templateResolutionAttributes.hashCode() : 0);
/* 559 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 567 */     StringBuilder strBuilder = new StringBuilder();
/* 568 */     strBuilder.append(LoggingUtils.loggifyTemplateName(this.template));
/* 569 */     if (this.templateSelectors != null) {
/* 570 */       strBuilder.append("::");
/* 571 */       strBuilder.append(this.templateSelectors);
/*     */     }
/* 573 */     if (this.templateMode != null) {
/* 574 */       strBuilder.append(" @");
/* 575 */       strBuilder.append(this.templateMode);
/*     */     }
/* 577 */     if (this.templateResolutionAttributes != null) {
/* 578 */       strBuilder.append(" (");
/* 579 */       strBuilder.append(this.templateResolutionAttributes);
/* 580 */       strBuilder.append(")");
/*     */     }
/* 582 */     if (this.outputContentType != null) {
/* 583 */       strBuilder.append(" [");
/* 584 */       strBuilder.append(this.outputContentType);
/* 585 */       strBuilder.append("]");
/*     */     }
/* 587 */     return strBuilder.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\TemplateSpec.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */