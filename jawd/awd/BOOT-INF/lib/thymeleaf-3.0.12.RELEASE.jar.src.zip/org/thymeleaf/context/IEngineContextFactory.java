package org.thymeleaf.context;

import java.util.Map;
import org.thymeleaf.IEngineConfiguration;
import org.thymeleaf.engine.TemplateData;

public abstract interface IEngineContextFactory
{
  public abstract IEngineContext createEngineContext(IEngineConfiguration paramIEngineConfiguration, TemplateData paramTemplateData, Map<String, Object> paramMap, IContext paramIContext);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\context\IEngineContextFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */