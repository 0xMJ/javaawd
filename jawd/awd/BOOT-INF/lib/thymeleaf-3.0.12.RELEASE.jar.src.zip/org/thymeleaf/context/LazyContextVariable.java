/*    */ package org.thymeleaf.context;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class LazyContextVariable<T>
/*    */   implements ILazyContextVariable<T>
/*    */ {
/* 57 */   private volatile boolean initialized = false;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private T value;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public final T getValue()
/*    */   {
/* 81 */     if (!this.initialized) {
/* 82 */       synchronized (this) {
/* 83 */         if (!this.initialized) {
/* 84 */           this.value = loadValue();
/* 85 */           this.initialized = true;
/*    */         }
/*    */       }
/*    */     }
/* 89 */     return (T)this.value;
/*    */   }
/*    */   
/*    */   protected abstract T loadValue();
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\context\LazyContextVariable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */