/*    */ package org.thymeleaf.context;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Context
/*    */   extends AbstractContext
/*    */ {
/*    */   public Context() {}
/*    */   
/*    */   public Context(Locale locale)
/*    */   {
/* 47 */     super(locale);
/*    */   }
/*    */   
/*    */   public Context(Locale locale, Map<String, Object> variables) {
/* 51 */     super(locale, variables);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\context\Context.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */