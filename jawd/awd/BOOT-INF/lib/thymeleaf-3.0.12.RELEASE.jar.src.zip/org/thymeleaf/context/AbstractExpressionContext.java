/*    */ package org.thymeleaf.context;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import java.util.Map;
/*    */ import org.thymeleaf.IEngineConfiguration;
/*    */ import org.thymeleaf.expression.ExpressionObjects;
/*    */ import org.thymeleaf.expression.IExpressionObjects;
/*    */ import org.thymeleaf.util.Validate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractExpressionContext
/*    */   extends AbstractContext
/*    */   implements IExpressionContext
/*    */ {
/*    */   private final IEngineConfiguration configuration;
/* 42 */   private IExpressionObjects expressionObjects = null;
/*    */   
/*    */ 
/*    */ 
/*    */   protected AbstractExpressionContext(IEngineConfiguration configuration)
/*    */   {
/* 48 */     Validate.notNull(configuration, "Configuration cannot be null");
/* 49 */     this.configuration = configuration;
/*    */   }
/*    */   
/*    */   protected AbstractExpressionContext(IEngineConfiguration configuration, Locale locale)
/*    */   {
/* 54 */     super(locale);
/* 55 */     Validate.notNull(configuration, "Configuration cannot be null");
/* 56 */     this.configuration = configuration;
/*    */   }
/*    */   
/*    */ 
/*    */   protected AbstractExpressionContext(IEngineConfiguration configuration, Locale locale, Map<String, Object> variables)
/*    */   {
/* 62 */     super(locale, variables);
/* 63 */     Validate.notNull(configuration, "Configuration cannot be null");
/* 64 */     this.configuration = configuration;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public final IEngineConfiguration getConfiguration()
/*    */   {
/* 71 */     return this.configuration;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public IExpressionObjects getExpressionObjects()
/*    */   {
/* 78 */     if (this.expressionObjects == null) {
/* 79 */       this.expressionObjects = new ExpressionObjects(this, this.configuration.getExpressionObjectFactory());
/*    */     }
/* 81 */     return this.expressionObjects;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\context\AbstractExpressionContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */