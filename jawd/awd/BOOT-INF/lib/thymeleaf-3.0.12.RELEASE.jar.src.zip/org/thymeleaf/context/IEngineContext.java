package org.thymeleaf.context;

import java.util.List;
import java.util.Map;
import org.thymeleaf.engine.TemplateData;
import org.thymeleaf.inline.IInliner;
import org.thymeleaf.model.IProcessableElementTag;

public abstract interface IEngineContext
  extends ITemplateContext
{
  public abstract void setVariable(String paramString, Object paramObject);
  
  public abstract void setVariables(Map<String, Object> paramMap);
  
  public abstract void removeVariable(String paramString);
  
  public abstract void setSelectionTarget(Object paramObject);
  
  public abstract void setInliner(IInliner paramIInliner);
  
  public abstract void setTemplateData(TemplateData paramTemplateData);
  
  public abstract void setElementTag(IProcessableElementTag paramIProcessableElementTag);
  
  public abstract List<IProcessableElementTag> getElementStackAbove(int paramInt);
  
  public abstract boolean isVariableLocal(String paramString);
  
  public abstract void increaseLevel();
  
  public abstract void decreaseLevel();
  
  public abstract int level();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\context\IEngineContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */