/*     */ package org.thymeleaf.context;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.thymeleaf.IEngineConfiguration;
/*     */ import org.thymeleaf.engine.TemplateData;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class StandardEngineContextFactory
/*     */   implements IEngineContextFactory
/*     */ {
/*     */   public IEngineContext createEngineContext(IEngineConfiguration configuration, TemplateData templateData, Map<String, Object> templateResolutionAttributes, IContext context)
/*     */   {
/*  66 */     Validate.notNull(context, "Context object cannot be null");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  72 */     Set<String> variableNames = context.getVariableNames();
/*     */     
/*  74 */     if ((variableNames == null) || (variableNames.isEmpty())) {
/*  75 */       if ((context instanceof IWebContext)) {
/*  76 */         IWebContext webContext = (IWebContext)context;
/*  77 */         return new WebEngineContext(configuration, templateData, templateResolutionAttributes, webContext
/*     */         
/*  79 */           .getRequest(), webContext.getResponse(), webContext.getServletContext(), webContext
/*  80 */           .getLocale(), Collections.EMPTY_MAP);
/*     */       }
/*  82 */       return new EngineContext(configuration, templateData, templateResolutionAttributes, context
/*     */       
/*  84 */         .getLocale(), Collections.EMPTY_MAP);
/*     */     }
/*     */     
/*  87 */     Map<String, Object> variables = new LinkedHashMap(variableNames.size() + 1, 1.0F);
/*  88 */     for (String variableName : variableNames) {
/*  89 */       variables.put(variableName, context.getVariable(variableName));
/*     */     }
/*  91 */     if ((context instanceof IWebContext)) {
/*  92 */       IWebContext webContext = (IWebContext)context;
/*  93 */       return new WebEngineContext(configuration, templateData, templateResolutionAttributes, webContext
/*     */       
/*  95 */         .getRequest(), webContext.getResponse(), webContext.getServletContext(), webContext
/*  96 */         .getLocale(), variables);
/*     */     }
/*     */     
/*  99 */     return new EngineContext(configuration, templateData, templateResolutionAttributes, context
/*     */     
/* 101 */       .getLocale(), variables);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\context\StandardEngineContextFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */