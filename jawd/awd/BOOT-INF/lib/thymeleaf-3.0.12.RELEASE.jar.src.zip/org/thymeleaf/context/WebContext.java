/*    */ package org.thymeleaf.context;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import java.util.Map;
/*    */ import javax.servlet.ServletContext;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import javax.servlet.http.HttpSession;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class WebContext
/*    */   extends AbstractContext
/*    */   implements IWebContext
/*    */ {
/*    */   private final HttpServletRequest request;
/*    */   private final HttpServletResponse response;
/*    */   private final ServletContext servletContext;
/*    */   
/*    */   public WebContext(HttpServletRequest request, HttpServletResponse response, ServletContext servletContext)
/*    */   {
/* 59 */     this.request = request;
/* 60 */     this.response = response;
/* 61 */     this.servletContext = servletContext;
/*    */   }
/*    */   
/*    */   public WebContext(HttpServletRequest request, HttpServletResponse response, ServletContext servletContext, Locale locale)
/*    */   {
/* 66 */     super(locale);
/* 67 */     this.request = request;
/* 68 */     this.response = response;
/* 69 */     this.servletContext = servletContext;
/*    */   }
/*    */   
/*    */   public WebContext(HttpServletRequest request, HttpServletResponse response, ServletContext servletContext, Locale locale, Map<String, Object> variables)
/*    */   {
/* 74 */     super(locale, variables);
/* 75 */     this.request = request;
/* 76 */     this.response = response;
/* 77 */     this.servletContext = servletContext;
/*    */   }
/*    */   
/*    */   public HttpServletRequest getRequest()
/*    */   {
/* 82 */     return this.request;
/*    */   }
/*    */   
/*    */   public HttpSession getSession() {
/* 86 */     return this.request.getSession(false);
/*    */   }
/*    */   
/*    */   public HttpServletResponse getResponse() {
/* 90 */     return this.response;
/*    */   }
/*    */   
/*    */   public ServletContext getServletContext() {
/* 94 */     return this.servletContext;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\context\WebContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */