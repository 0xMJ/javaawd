/*      */ package org.thymeleaf.context;
/*      */ 
/*      */ import java.lang.reflect.Array;
/*      */ import java.util.AbstractList;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Enumeration;
/*      */ import java.util.HashSet;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Set;
/*      */ import javax.servlet.ServletContext;
/*      */ import javax.servlet.http.HttpServletRequest;
/*      */ import javax.servlet.http.HttpServletResponse;
/*      */ import javax.servlet.http.HttpSession;
/*      */ import org.thymeleaf.IEngineConfiguration;
/*      */ import org.thymeleaf.engine.TemplateData;
/*      */ import org.thymeleaf.inline.IInliner;
/*      */ import org.thymeleaf.inline.NoOpInliner;
/*      */ import org.thymeleaf.model.IProcessableElementTag;
/*      */ import org.thymeleaf.util.Validate;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class WebEngineContext
/*      */   extends AbstractEngineContext
/*      */   implements IEngineContext, IWebContext
/*      */ {
/*      */   private static final String PARAM_VARIABLE_NAME = "param";
/*      */   private static final String SESSION_VARIABLE_NAME = "session";
/*      */   private static final String APPLICATION_VARIABLE_NAME = "application";
/*      */   private final HttpServletRequest request;
/*      */   private final HttpServletResponse response;
/*      */   private final HttpSession session;
/*      */   private final ServletContext servletContext;
/*      */   private final RequestAttributesVariablesMap requestAttributesVariablesMap;
/*      */   private final Map<String, Object> requestParametersVariablesMap;
/*      */   private final Map<String, Object> sessionAttributesVariablesMap;
/*      */   private final Map<String, Object> applicationAttributesVariablesMap;
/*      */   
/*      */   public WebEngineContext(IEngineConfiguration configuration, TemplateData templateData, Map<String, Object> templateResolutionAttributes, HttpServletRequest request, HttpServletResponse response, ServletContext servletContext, Locale locale, Map<String, Object> variables)
/*      */   {
/*  133 */     super(configuration, templateResolutionAttributes, locale);
/*      */     
/*  135 */     Validate.notNull(request, "Request cannot be null in web variables map");
/*  136 */     Validate.notNull(response, "Response cannot be null in web variables map");
/*  137 */     Validate.notNull(servletContext, "Servlet Context cannot be null in web variables map");
/*      */     
/*  139 */     this.request = request;
/*  140 */     this.response = response;
/*  141 */     this.session = request.getSession(false);
/*  142 */     this.servletContext = servletContext;
/*      */     
/*  144 */     this.requestAttributesVariablesMap = new RequestAttributesVariablesMap(configuration, templateData, templateResolutionAttributes, this.request, locale, variables);
/*      */     
/*  146 */     this.requestParametersVariablesMap = new RequestParametersMap(this.request);
/*  147 */     this.applicationAttributesVariablesMap = new ServletContextAttributesMap(this.servletContext);
/*  148 */     this.sessionAttributesVariablesMap = new SessionAttributesMap(this.session);
/*      */   }
/*      */   
/*      */ 
/*      */   public HttpServletRequest getRequest()
/*      */   {
/*  154 */     return this.request;
/*      */   }
/*      */   
/*      */   public HttpServletResponse getResponse()
/*      */   {
/*  159 */     return this.response;
/*      */   }
/*      */   
/*      */   public HttpSession getSession()
/*      */   {
/*  164 */     return this.session;
/*      */   }
/*      */   
/*      */   public ServletContext getServletContext()
/*      */   {
/*  169 */     return this.servletContext;
/*      */   }
/*      */   
/*      */   public boolean containsVariable(String name)
/*      */   {
/*  174 */     if ("session".equals(name)) {
/*  175 */       return this.sessionAttributesVariablesMap != null;
/*      */     }
/*  177 */     if ("param".equals(name)) {
/*  178 */       return true;
/*      */     }
/*  180 */     return ("application".equals(name)) || (this.requestAttributesVariablesMap.containsVariable(name));
/*      */   }
/*      */   
/*      */   public Object getVariable(String key)
/*      */   {
/*  185 */     if ("session".equals(key)) {
/*  186 */       return this.sessionAttributesVariablesMap;
/*      */     }
/*  188 */     if ("param".equals(key)) {
/*  189 */       return this.requestParametersVariablesMap;
/*      */     }
/*  191 */     if ("application".equals(key)) {
/*  192 */       return this.applicationAttributesVariablesMap;
/*      */     }
/*  194 */     return this.requestAttributesVariablesMap.getVariable(key);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Set<String> getVariableNames()
/*      */   {
/*  201 */     return this.requestAttributesVariablesMap.getVariableNames();
/*      */   }
/*      */   
/*      */   public void setVariable(String name, Object value)
/*      */   {
/*  206 */     if (("session".equals(name)) || 
/*  207 */       ("param".equals(name)) || 
/*  208 */       ("application".equals(name))) {
/*  209 */       throw new IllegalArgumentException("Cannot set variable called '" + name + "' into web variables map: such name is a reserved word");
/*      */     }
/*      */     
/*  212 */     this.requestAttributesVariablesMap.setVariable(name, value);
/*      */   }
/*      */   
/*      */   public void setVariables(Map<String, Object> variables)
/*      */   {
/*  217 */     if ((variables == null) || (variables.isEmpty())) {
/*  218 */       return;
/*      */     }
/*      */     
/*  221 */     for (String name : variables.keySet()) {
/*  222 */       if (("session".equals(name)) || 
/*  223 */         ("param".equals(name)) || 
/*  224 */         ("application".equals(name))) {
/*  225 */         throw new IllegalArgumentException("Cannot set variable called '" + name + "' into web variables map: such name is a reserved word");
/*      */       }
/*      */     }
/*      */     
/*  229 */     this.requestAttributesVariablesMap.setVariables(variables);
/*      */   }
/*      */   
/*      */   public void removeVariable(String name)
/*      */   {
/*  234 */     if (("session".equals(name)) || 
/*  235 */       ("param".equals(name)) || 
/*  236 */       ("application".equals(name))) {
/*  237 */       throw new IllegalArgumentException("Cannot remove variable called '" + name + "' in web variables map: such name is a reserved word");
/*      */     }
/*      */     
/*  240 */     this.requestAttributesVariablesMap.removeVariable(name);
/*      */   }
/*      */   
/*      */   public boolean isVariableLocal(String name)
/*      */   {
/*  245 */     return this.requestAttributesVariablesMap.isVariableLocal(name);
/*      */   }
/*      */   
/*      */   public boolean hasSelectionTarget()
/*      */   {
/*  250 */     return this.requestAttributesVariablesMap.hasSelectionTarget();
/*      */   }
/*      */   
/*      */   public Object getSelectionTarget()
/*      */   {
/*  255 */     return this.requestAttributesVariablesMap.getSelectionTarget();
/*      */   }
/*      */   
/*      */   public void setSelectionTarget(Object selectionTarget)
/*      */   {
/*  260 */     this.requestAttributesVariablesMap.setSelectionTarget(selectionTarget);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public IInliner getInliner()
/*      */   {
/*  267 */     return this.requestAttributesVariablesMap.getInliner();
/*      */   }
/*      */   
/*      */   public void setInliner(IInliner inliner) {
/*  271 */     this.requestAttributesVariablesMap.setInliner(inliner);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public TemplateData getTemplateData()
/*      */   {
/*  278 */     return this.requestAttributesVariablesMap.getTemplateData();
/*      */   }
/*      */   
/*      */   public void setTemplateData(TemplateData templateData) {
/*  282 */     this.requestAttributesVariablesMap.setTemplateData(templateData);
/*      */   }
/*      */   
/*      */   public List<TemplateData> getTemplateStack()
/*      */   {
/*  287 */     return this.requestAttributesVariablesMap.getTemplateStack();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setElementTag(IProcessableElementTag elementTag)
/*      */   {
/*  294 */     this.requestAttributesVariablesMap.setElementTag(elementTag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public List<IProcessableElementTag> getElementStack()
/*      */   {
/*  301 */     return this.requestAttributesVariablesMap.getElementStack();
/*      */   }
/*      */   
/*      */   public List<IProcessableElementTag> getElementStackAbove(int contextLevel)
/*      */   {
/*  306 */     return this.requestAttributesVariablesMap.getElementStackAbove(contextLevel);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public int level()
/*      */   {
/*  313 */     return this.requestAttributesVariablesMap.level();
/*      */   }
/*      */   
/*      */   public void increaseLevel()
/*      */   {
/*  318 */     this.requestAttributesVariablesMap.increaseLevel();
/*      */   }
/*      */   
/*      */   public void decreaseLevel()
/*      */   {
/*  323 */     this.requestAttributesVariablesMap.decreaseLevel();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getStringRepresentationByLevel()
/*      */   {
/*  331 */     return this.requestAttributesVariablesMap.getStringRepresentationByLevel();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String toString()
/*      */   {
/*  340 */     return this.requestAttributesVariablesMap.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static Object resolveLazy(Object variable)
/*      */   {
/*  350 */     if ((variable != null) && ((variable instanceof ILazyContextVariable))) {
/*  351 */       return ((ILazyContextVariable)variable).getValue();
/*      */     }
/*  353 */     return variable;
/*      */   }
/*      */   
/*      */ 
/*      */   private static final class SessionAttributesMap
/*      */     extends WebEngineContext.NoOpMapImpl
/*      */   {
/*      */     private final HttpSession session;
/*      */     
/*      */ 
/*      */     SessionAttributesMap(HttpSession session)
/*      */     {
/*  365 */       this.session = session;
/*      */     }
/*      */     
/*      */ 
/*      */     public int size()
/*      */     {
/*  371 */       if (this.session == null) {
/*  372 */         return 0;
/*      */       }
/*  374 */       int size = 0;
/*  375 */       Enumeration<String> attributeNames = this.session.getAttributeNames();
/*  376 */       while (attributeNames.hasMoreElements()) {
/*  377 */         attributeNames.nextElement();
/*  378 */         size++;
/*      */       }
/*  380 */       return size;
/*      */     }
/*      */     
/*      */     public boolean isEmpty()
/*      */     {
/*  385 */       if (this.session == null) {
/*  386 */         return true;
/*      */       }
/*  388 */       Enumeration<String> attributeNames = this.session.getAttributeNames();
/*  389 */       return !attributeNames.hasMoreElements();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public boolean containsKey(Object key)
/*      */     {
/*  398 */       return true;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public boolean containsValue(Object value)
/*      */     {
/*  405 */       throw new UnsupportedOperationException("Map does not support #containsValue()");
/*      */     }
/*      */     
/*      */     public Object get(Object key)
/*      */     {
/*  410 */       if (this.session == null) {
/*  411 */         return null;
/*      */       }
/*  413 */       return WebEngineContext.resolveLazy(this.session.getAttribute(key != null ? key.toString() : null));
/*      */     }
/*      */     
/*      */     public Set<String> keySet()
/*      */     {
/*  418 */       if (this.session == null) {
/*  419 */         return Collections.emptySet();
/*      */       }
/*  421 */       Set<String> keySet = new LinkedHashSet(5);
/*  422 */       Enumeration<String> attributeNames = this.session.getAttributeNames();
/*  423 */       while (attributeNames.hasMoreElements()) {
/*  424 */         keySet.add(attributeNames.nextElement());
/*      */       }
/*  426 */       return keySet;
/*      */     }
/*      */     
/*      */     public Collection<Object> values()
/*      */     {
/*  431 */       if (this.session == null) {
/*  432 */         return Collections.emptySet();
/*      */       }
/*  434 */       List<Object> values = new ArrayList(5);
/*  435 */       Enumeration<String> attributeNames = this.session.getAttributeNames();
/*  436 */       while (attributeNames.hasMoreElements()) {
/*  437 */         values.add(this.session.getAttribute((String)attributeNames.nextElement()));
/*      */       }
/*  439 */       return values;
/*      */     }
/*      */     
/*      */     public Set<Map.Entry<String, Object>> entrySet()
/*      */     {
/*  444 */       if (this.session == null) {
/*  445 */         return Collections.emptySet();
/*      */       }
/*  447 */       Set<Map.Entry<String, Object>> entrySet = new LinkedHashSet(5);
/*  448 */       Enumeration<String> attributeNames = this.session.getAttributeNames();
/*  449 */       while (attributeNames.hasMoreElements()) {
/*  450 */         String key = (String)attributeNames.nextElement();
/*  451 */         Object value = this.session.getAttribute(key);
/*  452 */         entrySet.add(new WebEngineContext.NoOpMapImpl.MapEntry(key, value));
/*      */       }
/*  454 */       return entrySet;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static final class ServletContextAttributesMap
/*      */     extends WebEngineContext.NoOpMapImpl
/*      */   {
/*      */     private final ServletContext servletContext;
/*      */     
/*      */ 
/*      */     ServletContextAttributesMap(ServletContext servletContext)
/*      */     {
/*  468 */       this.servletContext = servletContext;
/*      */     }
/*      */     
/*      */ 
/*      */     public int size()
/*      */     {
/*  474 */       int size = 0;
/*  475 */       Enumeration<String> attributeNames = this.servletContext.getAttributeNames();
/*  476 */       while (attributeNames.hasMoreElements()) {
/*  477 */         attributeNames.nextElement();
/*  478 */         size++;
/*      */       }
/*  480 */       return size;
/*      */     }
/*      */     
/*      */     public boolean isEmpty()
/*      */     {
/*  485 */       Enumeration<String> attributeNames = this.servletContext.getAttributeNames();
/*  486 */       return !attributeNames.hasMoreElements();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public boolean containsKey(Object key)
/*      */     {
/*  495 */       return true;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public boolean containsValue(Object value)
/*      */     {
/*  502 */       throw new UnsupportedOperationException("Map does not support #containsValue()");
/*      */     }
/*      */     
/*      */     public Object get(Object key)
/*      */     {
/*  507 */       return WebEngineContext.resolveLazy(this.servletContext.getAttribute(key != null ? key.toString() : null));
/*      */     }
/*      */     
/*      */     public Set<String> keySet()
/*      */     {
/*  512 */       Set<String> keySet = new LinkedHashSet(5);
/*  513 */       Enumeration<String> attributeNames = this.servletContext.getAttributeNames();
/*  514 */       while (attributeNames.hasMoreElements()) {
/*  515 */         keySet.add(attributeNames.nextElement());
/*      */       }
/*  517 */       return keySet;
/*      */     }
/*      */     
/*      */     public Collection<Object> values()
/*      */     {
/*  522 */       List<Object> values = new ArrayList(5);
/*  523 */       Enumeration<String> attributeNames = this.servletContext.getAttributeNames();
/*  524 */       while (attributeNames.hasMoreElements()) {
/*  525 */         values.add(this.servletContext.getAttribute((String)attributeNames.nextElement()));
/*      */       }
/*  527 */       return values;
/*      */     }
/*      */     
/*      */     public Set<Map.Entry<String, Object>> entrySet()
/*      */     {
/*  532 */       Set<Map.Entry<String, Object>> entrySet = new LinkedHashSet(5);
/*  533 */       Enumeration<String> attributeNames = this.servletContext.getAttributeNames();
/*  534 */       while (attributeNames.hasMoreElements()) {
/*  535 */         String key = (String)attributeNames.nextElement();
/*  536 */         Object value = this.servletContext.getAttribute(key);
/*  537 */         entrySet.add(new WebEngineContext.NoOpMapImpl.MapEntry(key, value));
/*      */       }
/*  539 */       return entrySet;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static final class RequestParametersMap
/*      */     extends WebEngineContext.NoOpMapImpl
/*      */   {
/*      */     private final HttpServletRequest request;
/*      */     
/*      */ 
/*      */     RequestParametersMap(HttpServletRequest request)
/*      */     {
/*  553 */       this.request = request;
/*      */     }
/*      */     
/*      */ 
/*      */     public int size()
/*      */     {
/*  559 */       return this.request.getParameterMap().size();
/*      */     }
/*      */     
/*      */     public boolean isEmpty()
/*      */     {
/*  564 */       return this.request.getParameterMap().isEmpty();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public boolean containsKey(Object key)
/*      */     {
/*  573 */       return true;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public boolean containsValue(Object value)
/*      */     {
/*  580 */       throw new UnsupportedOperationException("Map does not support #containsValue()");
/*      */     }
/*      */     
/*      */     public Object get(Object key)
/*      */     {
/*  585 */       String[] parameterValues = this.request.getParameterValues(key != null ? key.toString() : null);
/*  586 */       if (parameterValues == null) {
/*  587 */         return null;
/*      */       }
/*  589 */       return new WebEngineContext.RequestParameterValues(parameterValues);
/*      */     }
/*      */     
/*      */     public Set<String> keySet()
/*      */     {
/*  594 */       return this.request.getParameterMap().keySet();
/*      */     }
/*      */     
/*      */     public Collection<Object> values()
/*      */     {
/*  599 */       return this.request.getParameterMap().values();
/*      */     }
/*      */     
/*      */     public Set<Map.Entry<String, Object>> entrySet()
/*      */     {
/*  604 */       return this.request.getParameterMap().entrySet();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private static final class RequestAttributesVariablesMap
/*      */     extends AbstractEngineContext
/*      */     implements IEngineContext
/*      */   {
/*      */     private static final int DEFAULT_ELEMENT_HIERARCHY_SIZE = 20;
/*      */     
/*      */     private static final int DEFAULT_LEVELS_SIZE = 10;
/*      */     
/*      */     private static final int DEFAULT_LEVELARRAYS_SIZE = 5;
/*      */     
/*      */     private final HttpServletRequest request;
/*  620 */     private int level = 0;
/*  621 */     private int index = 0;
/*      */     
/*      */     private int[] levels;
/*      */     
/*      */     private String[][] names;
/*      */     private Object[][] oldValues;
/*      */     private Object[][] newValues;
/*      */     private int[] levelSizes;
/*      */     private SelectionTarget[] selectionTargets;
/*      */     private IInliner[] inliners;
/*      */     private TemplateData[] templateDatas;
/*      */     private IProcessableElementTag[] elementTags;
/*  633 */     private SelectionTarget lastSelectionTarget = null;
/*  634 */     private IInliner lastInliner = null;
/*  635 */     private TemplateData lastTemplateData = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private final List<TemplateData> templateStack;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     RequestAttributesVariablesMap(IEngineConfiguration configuration, TemplateData templateData, Map<String, Object> templateResolutionAttributes, HttpServletRequest request, Locale locale, Map<String, Object> variables)
/*      */     {
/*  649 */       super(templateResolutionAttributes, locale);
/*      */       
/*  651 */       this.request = request;
/*      */       
/*  653 */       this.levels = new int[10];
/*  654 */       this.names = new String[10][];
/*  655 */       this.oldValues = new Object[10][];
/*  656 */       this.newValues = new Object[10][];
/*  657 */       this.levelSizes = new int[10];
/*  658 */       this.selectionTargets = new SelectionTarget[10];
/*  659 */       this.inliners = new IInliner[10];
/*  660 */       this.templateDatas = new TemplateData[10];
/*      */       
/*  662 */       this.elementTags = new IProcessableElementTag[20];
/*      */       
/*  664 */       Arrays.fill(this.levels, Integer.MAX_VALUE);
/*  665 */       Arrays.fill(this.names, null);
/*  666 */       Arrays.fill(this.oldValues, null);
/*  667 */       Arrays.fill(this.newValues, null);
/*  668 */       Arrays.fill(this.levelSizes, 0);
/*  669 */       Arrays.fill(this.selectionTargets, null);
/*  670 */       Arrays.fill(this.inliners, null);
/*  671 */       Arrays.fill(this.templateDatas, null);
/*      */       
/*  673 */       Arrays.fill(this.elementTags, null);
/*      */       
/*  675 */       this.levels[0] = 0;
/*  676 */       this.templateDatas[0] = templateData;
/*  677 */       this.lastTemplateData = templateData;
/*      */       
/*  679 */       this.templateStack = new ArrayList(10);
/*  680 */       this.templateStack.add(templateData);
/*      */       
/*  682 */       if (variables != null) {
/*  683 */         setVariables(variables);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */     public boolean containsVariable(String name)
/*      */     {
/*  690 */       return this.request.getAttribute(name) != null;
/*      */     }
/*      */     
/*      */     public Object getVariable(String key)
/*      */     {
/*  695 */       return WebEngineContext.resolveLazy(this.request.getAttribute(key));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public Set<String> getVariableNames()
/*      */     {
/*  710 */       Set<String> variableNames = new HashSet(10);
/*  711 */       Enumeration<String> attributeNamesEnum = this.request.getAttributeNames();
/*  712 */       while (attributeNamesEnum.hasMoreElements()) {
/*  713 */         variableNames.add(attributeNamesEnum.nextElement());
/*      */       }
/*  715 */       return variableNames;
/*      */     }
/*      */     
/*      */ 
/*      */     private int searchNameInIndex(String name, int idx)
/*      */     {
/*  721 */       int n = this.levelSizes[idx];
/*  722 */       if (name == null) {
/*  723 */         while (n-- != 0) {
/*  724 */           if (this.names[idx][n] == null) {
/*  725 */             return n;
/*      */           }
/*      */         }
/*  728 */         return -1;
/*      */       }
/*  730 */       while (n-- != 0) {
/*  731 */         if (name.equals(this.names[idx][n])) {
/*  732 */           return n;
/*      */         }
/*      */       }
/*  735 */       return -1;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public void setVariable(String name, Object value)
/*      */     {
/*  743 */       ensureLevelInitialized(true);
/*      */       
/*  745 */       if (this.level > 0)
/*      */       {
/*      */ 
/*  748 */         int levelIndex = searchNameInIndex(name, this.index);
/*  749 */         if (levelIndex >= 0)
/*      */         {
/*      */ 
/*  752 */           this.newValues[this.index][levelIndex] = value;
/*      */         }
/*      */         else
/*      */         {
/*  756 */           if (this.names[this.index].length == this.levelSizes[this.index])
/*      */           {
/*  758 */             this.names[this.index] = ((String[])Arrays.copyOf(this.names[this.index], this.names[this.index].length + 5));
/*  759 */             this.newValues[this.index] = Arrays.copyOf(this.newValues[this.index], this.newValues[this.index].length + 5);
/*  760 */             this.oldValues[this.index] = Arrays.copyOf(this.oldValues[this.index], this.oldValues[this.index].length + 5);
/*      */           }
/*      */           
/*  763 */           levelIndex = this.levelSizes[this.index];
/*      */           
/*  765 */           this.names[this.index][levelIndex] = name;
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  772 */           this.oldValues[this.index][levelIndex] = this.request.getAttribute(name);
/*      */           
/*  774 */           this.newValues[this.index][levelIndex] = value;
/*      */           
/*  776 */           this.levelSizes[this.index] += 1;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  783 */       this.request.setAttribute(name, value);
/*      */     }
/*      */     
/*      */ 
/*      */     public void setVariables(Map<String, Object> variables)
/*      */     {
/*  789 */       if ((variables == null) || (variables.isEmpty())) {
/*  790 */         return;
/*      */       }
/*  792 */       for (Map.Entry<String, Object> entry : variables.entrySet()) {
/*  793 */         setVariable((String)entry.getKey(), entry.getValue());
/*      */       }
/*      */     }
/*      */     
/*      */     public void removeVariable(String name)
/*      */     {
/*  799 */       setVariable(name, null);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public boolean isVariableLocal(String name)
/*      */     {
/*  807 */       if (this.level == 0)
/*      */       {
/*  809 */         return false;
/*      */       }
/*      */       
/*  812 */       int n = this.index + 1;
/*  813 */       while (n-- > 1) {
/*  814 */         int idx = searchNameInIndex(name, n);
/*  815 */         if (idx >= 0) {
/*  816 */           return this.newValues[n][idx] != null;
/*      */         }
/*      */       }
/*      */       
/*  820 */       return false;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public boolean hasSelectionTarget()
/*      */     {
/*  828 */       if (this.lastSelectionTarget != null) {
/*  829 */         return true;
/*      */       }
/*  831 */       int n = this.index + 1;
/*  832 */       while (n-- != 0) {
/*  833 */         if (this.selectionTargets[n] != null) {
/*  834 */           return true;
/*      */         }
/*      */       }
/*  837 */       return false;
/*      */     }
/*      */     
/*      */     public Object getSelectionTarget()
/*      */     {
/*  842 */       if (this.lastSelectionTarget != null) {
/*  843 */         return this.lastSelectionTarget.selectionTarget;
/*      */       }
/*  845 */       int n = this.index + 1;
/*  846 */       while (n-- != 0) {
/*  847 */         if (this.selectionTargets[n] != null) {
/*  848 */           this.lastSelectionTarget = this.selectionTargets[n];
/*  849 */           return this.lastSelectionTarget.selectionTarget;
/*      */         }
/*      */       }
/*  852 */       return null;
/*      */     }
/*      */     
/*      */     public void setSelectionTarget(Object selectionTarget)
/*      */     {
/*  857 */       ensureLevelInitialized(false);
/*  858 */       this.lastSelectionTarget = new SelectionTarget(selectionTarget);
/*  859 */       this.selectionTargets[this.index] = this.lastSelectionTarget;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public IInliner getInliner()
/*      */     {
/*  866 */       if (this.lastInliner != null) {
/*  867 */         if (this.lastInliner == NoOpInliner.INSTANCE) {
/*  868 */           return null;
/*      */         }
/*  870 */         return this.lastInliner;
/*      */       }
/*  872 */       int n = this.index + 1;
/*  873 */       while (n-- != 0) {
/*  874 */         if (this.inliners[n] != null) {
/*  875 */           this.lastInliner = this.inliners[n];
/*  876 */           if (this.lastInliner == NoOpInliner.INSTANCE) {
/*  877 */             return null;
/*      */           }
/*  879 */           return this.lastInliner;
/*      */         }
/*      */       }
/*  882 */       return null;
/*      */     }
/*      */     
/*      */     public void setInliner(IInliner inliner)
/*      */     {
/*  887 */       ensureLevelInitialized(false);
/*      */       
/*  889 */       this.lastInliner = (inliner == null ? NoOpInliner.INSTANCE : inliner);
/*  890 */       this.inliners[this.index] = this.lastInliner;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public TemplateData getTemplateData()
/*      */     {
/*  897 */       if (this.lastTemplateData != null) {
/*  898 */         return this.lastTemplateData;
/*      */       }
/*  900 */       int n = this.index + 1;
/*  901 */       while (n-- != 0) {
/*  902 */         if (this.templateDatas[n] != null) {
/*  903 */           this.lastTemplateData = this.templateDatas[n];
/*  904 */           return this.lastTemplateData;
/*      */         }
/*      */       }
/*  907 */       return null;
/*      */     }
/*      */     
/*      */     public void setTemplateData(TemplateData templateData)
/*      */     {
/*  912 */       Validate.notNull(templateData, "Template Data cannot be null");
/*  913 */       ensureLevelInitialized(false);
/*  914 */       this.lastTemplateData = templateData;
/*  915 */       this.templateDatas[this.index] = this.lastTemplateData;
/*  916 */       this.templateStack.clear();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public List<TemplateData> getTemplateStack()
/*      */     {
/*  923 */       if (!this.templateStack.isEmpty())
/*      */       {
/*  925 */         return Collections.unmodifiableList(new ArrayList(this.templateStack));
/*      */       }
/*  927 */       for (int i = 0; i <= this.index; i++) {
/*  928 */         if (this.templateDatas[i] != null) {
/*  929 */           this.templateStack.add(this.templateDatas[i]);
/*      */         }
/*      */       }
/*      */       
/*  933 */       return Collections.unmodifiableList(new ArrayList(this.templateStack));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void setElementTag(IProcessableElementTag elementTag)
/*      */     {
/*  940 */       if (this.elementTags.length <= this.level) {
/*  941 */         this.elementTags = ((IProcessableElementTag[])Arrays.copyOf(this.elementTags, Math.max(this.level, this.elementTags.length + 20)));
/*      */       }
/*  943 */       this.elementTags[this.level] = elementTag;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public List<IProcessableElementTag> getElementStack()
/*      */     {
/*  950 */       List<IProcessableElementTag> elementStack = new ArrayList(this.level);
/*  951 */       for (int i = 0; (i <= this.level) && (i < this.elementTags.length); i++) {
/*  952 */         if (this.elementTags[i] != null) {
/*  953 */           elementStack.add(this.elementTags[i]);
/*      */         }
/*      */       }
/*      */       
/*  957 */       return Collections.unmodifiableList(elementStack);
/*      */     }
/*      */     
/*      */     public List<IProcessableElementTag> getElementStackAbove(int contextLevel)
/*      */     {
/*  962 */       List<IProcessableElementTag> elementStack = new ArrayList(this.level);
/*  963 */       for (int i = contextLevel + 1; (i <= this.level) && (i < this.elementTags.length); i++) {
/*  964 */         if (this.elementTags[i] != null) {
/*  965 */           elementStack.add(this.elementTags[i]);
/*      */         }
/*      */       }
/*      */       
/*  969 */       return Collections.unmodifiableList(elementStack);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private void ensureLevelInitialized(boolean initVariables)
/*      */     {
/*  978 */       if (this.levels[this.index] != this.level)
/*      */       {
/*      */ 
/*      */ 
/*  982 */         this.index += 1;
/*      */         
/*  984 */         if (this.levels.length == this.index) {
/*  985 */           this.levels = Arrays.copyOf(this.levels, this.levels.length + 10);
/*  986 */           Arrays.fill(this.levels, this.index, this.levels.length, Integer.MAX_VALUE);
/*  987 */           this.names = ((String[][])Arrays.copyOf(this.names, this.names.length + 10));
/*  988 */           this.newValues = ((Object[][])Arrays.copyOf(this.newValues, this.newValues.length + 10));
/*  989 */           this.oldValues = ((Object[][])Arrays.copyOf(this.oldValues, this.oldValues.length + 10));
/*  990 */           this.levelSizes = Arrays.copyOf(this.levelSizes, this.levelSizes.length + 10);
/*      */           
/*  992 */           this.selectionTargets = ((SelectionTarget[])Arrays.copyOf(this.selectionTargets, this.selectionTargets.length + 10));
/*  993 */           this.inliners = ((IInliner[])Arrays.copyOf(this.inliners, this.inliners.length + 10));
/*  994 */           this.templateDatas = ((TemplateData[])Arrays.copyOf(this.templateDatas, this.templateDatas.length + 10));
/*      */         }
/*      */         
/*  997 */         this.levels[this.index] = this.level;
/*      */       }
/*      */       
/*      */ 
/* 1001 */       if (this.level > 0)
/*      */       {
/*      */ 
/* 1004 */         if ((initVariables) && (this.names[this.index] == null))
/*      */         {
/*      */ 
/* 1007 */           this.names[this.index] = new String[5];
/* 1008 */           Arrays.fill(this.names[this.index], null);
/*      */           
/* 1010 */           this.newValues[this.index] = new Object[5];
/* 1011 */           Arrays.fill(this.newValues[this.index], null);
/*      */           
/* 1013 */           this.oldValues[this.index] = new Object[5];
/* 1014 */           Arrays.fill(this.oldValues[this.index], null);
/*      */           
/* 1016 */           this.levelSizes[this.index] = 0;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public int level()
/*      */     {
/* 1028 */       return this.level;
/*      */     }
/*      */     
/*      */     public void increaseLevel()
/*      */     {
/* 1033 */       this.level += 1;
/*      */     }
/*      */     
/*      */ 
/*      */     public void decreaseLevel()
/*      */     {
/* 1039 */       Validate.isTrue(this.level > 0, "Cannot decrease variable map level below 0");
/*      */       
/* 1041 */       if (this.levels[this.index] == this.level)
/*      */       {
/* 1043 */         this.levels[this.index] = Integer.MAX_VALUE;
/*      */         
/* 1045 */         if ((this.names[this.index] != null) && (this.levelSizes[this.index] > 0))
/*      */         {
/*      */ 
/* 1048 */           int n = this.levelSizes[this.index];
/* 1049 */           while (n-- != 0) {
/* 1050 */             String name = this.names[this.index][n];
/* 1051 */             Object newValue = this.newValues[this.index][n];
/* 1052 */             Object oldValue = this.oldValues[this.index][n];
/* 1053 */             Object currentValue = this.request.getAttribute(name);
/* 1054 */             if (newValue == currentValue)
/*      */             {
/*      */ 
/* 1057 */               this.request.setAttribute(name, oldValue);
/*      */             }
/*      */           }
/* 1060 */           this.levelSizes[this.index] = 0;
/*      */         }
/*      */         
/*      */ 
/* 1064 */         this.selectionTargets[this.index] = null;
/* 1065 */         this.inliners[this.index] = null;
/* 1066 */         this.templateDatas[this.index] = null;
/* 1067 */         this.index -= 1;
/*      */         
/*      */ 
/* 1070 */         this.lastSelectionTarget = null;
/* 1071 */         this.lastInliner = null;
/* 1072 */         this.lastTemplateData = null;
/* 1073 */         this.templateStack.clear();
/*      */       }
/*      */       
/*      */ 
/* 1077 */       if (this.level < this.elementTags.length) {
/* 1078 */         this.elementTags[this.level] = null;
/*      */       }
/*      */       
/* 1081 */       this.level -= 1;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public String getStringRepresentationByLevel()
/*      */     {
/* 1090 */       StringBuilder strBuilder = new StringBuilder();
/* 1091 */       strBuilder.append('{');
/* 1092 */       Map<String, Object> oldValuesSum = new LinkedHashMap();
/* 1093 */       int n = this.index + 1;
/* 1094 */       while (n-- != 1) {
/* 1095 */         Map<String, Object> levelVars = new LinkedHashMap();
/* 1096 */         if ((this.names[n] != null) && (this.levelSizes[n] > 0))
/* 1097 */           for (int i = 0; i < this.levelSizes[n]; i++) {
/* 1098 */             String name = this.names[n][i];
/* 1099 */             Object newValue = this.newValues[n][i];
/* 1100 */             Object oldValue = this.oldValues[n][i];
/* 1101 */             if (newValue != oldValue)
/*      */             {
/*      */ 
/*      */ 
/* 1105 */               if (!oldValuesSum.containsKey(name) ? 
/*      */               
/*      */ 
/* 1108 */                 newValue == this.request.getAttribute(name) : 
/*      */                 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1114 */                 newValue == oldValuesSum.get(name))
/*      */               {
/*      */ 
/*      */ 
/* 1118 */                 levelVars.put(name, newValue);
/* 1119 */                 oldValuesSum.put(name, oldValue);
/*      */               } }
/*      */           }
/* 1122 */         if ((!levelVars.isEmpty()) || (this.selectionTargets[n] != null) || (this.inliners[n] != null)) {
/* 1123 */           if (strBuilder.length() > 1) {
/* 1124 */             strBuilder.append(',');
/*      */           }
/* 1126 */           strBuilder.append(this.levels[n]).append(":");
/* 1127 */           if ((!levelVars.isEmpty()) || (n == 0)) {
/* 1128 */             strBuilder.append(levelVars);
/*      */           }
/* 1130 */           if (this.selectionTargets[n] != null) {
/* 1131 */             strBuilder.append("<").append(this.selectionTargets[n].selectionTarget).append(">");
/*      */           }
/* 1133 */           if (this.inliners[n] != null) {
/* 1134 */             strBuilder.append("[").append(this.inliners[n].getName()).append("]");
/*      */           }
/* 1136 */           if (this.templateDatas[n] != null) {
/* 1137 */             strBuilder.append("(").append(this.templateDatas[n].getTemplate()).append(")");
/*      */           }
/*      */         }
/*      */       }
/* 1141 */       Map<String, Object> requestAttributes = new LinkedHashMap();
/* 1142 */       Enumeration<String> attrNames = this.request.getAttributeNames();
/* 1143 */       String name; while (attrNames.hasMoreElements()) {
/* 1144 */         name = (String)attrNames.nextElement();
/* 1145 */         if (oldValuesSum.containsKey(name)) {
/* 1146 */           Object oldValue = oldValuesSum.get(name);
/* 1147 */           if (oldValue != null) {
/* 1148 */             requestAttributes.put(name, oldValuesSum.get(name));
/*      */           }
/* 1150 */           oldValuesSum.remove(name);
/*      */         } else {
/* 1152 */           requestAttributes.put(name, this.request.getAttribute(name));
/*      */         }
/*      */       }
/* 1155 */       for (Map.Entry<String, Object> oldValuesSumEntry : oldValuesSum.entrySet()) {
/* 1156 */         String name = (String)oldValuesSumEntry.getKey();
/* 1157 */         if (!requestAttributes.containsKey(name)) {
/* 1158 */           Object oldValue = oldValuesSumEntry.getValue();
/* 1159 */           if (oldValue != null) {
/* 1160 */             requestAttributes.put(name, oldValue);
/*      */           }
/*      */         }
/*      */       }
/* 1164 */       if (strBuilder.length() > 1) {
/* 1165 */         strBuilder.append(',');
/*      */       }
/* 1167 */       strBuilder.append(this.levels[n]).append(":");
/* 1168 */       strBuilder.append(requestAttributes.toString());
/* 1169 */       if (this.selectionTargets[0] != null) {
/* 1170 */         strBuilder.append("<").append(this.selectionTargets[0].selectionTarget).append(">");
/*      */       }
/* 1172 */       if (this.inliners[0] != null) {
/* 1173 */         strBuilder.append("[").append(this.inliners[0].getName()).append("]");
/*      */       }
/* 1175 */       if (this.templateDatas[0] != null) {
/* 1176 */         strBuilder.append("(").append(this.templateDatas[0].getTemplate()).append(")");
/*      */       }
/* 1178 */       strBuilder.append("}[");
/* 1179 */       strBuilder.append(this.level);
/* 1180 */       strBuilder.append(']');
/* 1181 */       return strBuilder.toString();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public String toString()
/*      */     {
/* 1191 */       Map<String, Object> equivalentMap = new LinkedHashMap();
/* 1192 */       Enumeration<String> attributeNamesEnum = this.request.getAttributeNames();
/* 1193 */       while (attributeNamesEnum.hasMoreElements()) {
/* 1194 */         String name = (String)attributeNamesEnum.nextElement();
/* 1195 */         equivalentMap.put(name, this.request.getAttribute(name));
/*      */       }
/* 1197 */       String textInliningStr = getInliner() != null ? "[" + getInliner().getName() + "]" : "";
/* 1198 */       String templateDataStr = "(" + getTemplateData().getTemplate() + ")";
/* 1199 */       return equivalentMap.toString() + (hasSelectionTarget() ? "<" + getSelectionTarget() + ">" : "") + textInliningStr + templateDataStr;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private static final class SelectionTarget
/*      */     {
/*      */       final Object selectionTarget;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       SelectionTarget(Object selectionTarget)
/*      */       {
/* 1216 */         this.selectionTarget = selectionTarget;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static abstract class NoOpMapImpl
/*      */     implements Map<String, Object>
/*      */   {
/*      */     public int size()
/*      */     {
/* 1235 */       return 0;
/*      */     }
/*      */     
/*      */     public boolean isEmpty() {
/* 1239 */       return true;
/*      */     }
/*      */     
/*      */     public boolean containsKey(Object key) {
/* 1243 */       return false;
/*      */     }
/*      */     
/*      */     public boolean containsValue(Object value) {
/* 1247 */       return false;
/*      */     }
/*      */     
/*      */     public Object get(Object key) {
/* 1251 */       return null;
/*      */     }
/*      */     
/*      */     public Object put(String key, Object value) {
/* 1255 */       throw new UnsupportedOperationException("Cannot add new entry: map is immutable");
/*      */     }
/*      */     
/*      */     public Object remove(Object key) {
/* 1259 */       throw new UnsupportedOperationException("Cannot remove entry: map is immutable");
/*      */     }
/*      */     
/*      */     public void putAll(Map<? extends String, ? extends Object> m) {
/* 1263 */       throw new UnsupportedOperationException("Cannot add new entry: map is immutable");
/*      */     }
/*      */     
/*      */     public void clear() {
/* 1267 */       throw new UnsupportedOperationException("Cannot clear: map is immutable");
/*      */     }
/*      */     
/*      */     public Set<String> keySet() {
/* 1271 */       return Collections.emptySet();
/*      */     }
/*      */     
/*      */     public Collection<Object> values() {
/* 1275 */       return Collections.emptyList();
/*      */     }
/*      */     
/*      */     public Set<Map.Entry<String, Object>> entrySet() {
/* 1279 */       return Collections.emptySet();
/*      */     }
/*      */     
/*      */     static final class MapEntry
/*      */       implements Map.Entry<String, Object>
/*      */     {
/*      */       private final String key;
/*      */       private final Object value;
/*      */       
/*      */       MapEntry(String key, Object value)
/*      */       {
/* 1290 */         this.key = key;
/* 1291 */         this.value = value;
/*      */       }
/*      */       
/*      */       public String getKey() {
/* 1295 */         return this.key;
/*      */       }
/*      */       
/*      */       public Object getValue() {
/* 1299 */         return this.value;
/*      */       }
/*      */       
/*      */       public Object setValue(Object value) {
/* 1303 */         throw new UnsupportedOperationException("Cannot set value: map is immutable");
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private static final class RequestParameterValues
/*      */     extends AbstractList<String>
/*      */   {
/*      */     private final String[] parameterValues;
/*      */     
/*      */     public final int length;
/*      */     
/*      */ 
/*      */     RequestParameterValues(String[] parameterValues)
/*      */     {
/* 1319 */       this.parameterValues = parameterValues;
/* 1320 */       this.length = this.parameterValues.length;
/*      */     }
/*      */     
/*      */     public int size()
/*      */     {
/* 1325 */       return this.length;
/*      */     }
/*      */     
/*      */     public Object[] toArray()
/*      */     {
/* 1330 */       return (Object[])this.parameterValues.clone();
/*      */     }
/*      */     
/*      */     public <T> T[] toArray(T[] arr)
/*      */     {
/* 1335 */       if (arr.length < this.length) {
/* 1336 */         T[] copy = (Object[])Array.newInstance(arr.getClass().getComponentType(), this.length);
/* 1337 */         System.arraycopy(this.parameterValues, 0, copy, 0, this.length);
/* 1338 */         return copy;
/*      */       }
/* 1340 */       System.arraycopy(this.parameterValues, 0, arr, 0, this.length);
/* 1341 */       if (arr.length > this.length) {
/* 1342 */         arr[this.length] = null;
/*      */       }
/* 1344 */       return arr;
/*      */     }
/*      */     
/*      */     public String get(int index)
/*      */     {
/* 1349 */       return this.parameterValues[index];
/*      */     }
/*      */     
/*      */     public int indexOf(Object obj)
/*      */     {
/* 1354 */       String[] a = this.parameterValues;
/* 1355 */       if (obj == null) {
/* 1356 */         for (int i = 0; i < a.length; i++) {
/* 1357 */           if (a[i] == null) {
/* 1358 */             return i;
/*      */           }
/*      */         }
/*      */       } else {
/* 1362 */         for (int i = 0; i < a.length; i++) {
/* 1363 */           if (obj.equals(a[i])) {
/* 1364 */             return i;
/*      */           }
/*      */         }
/*      */       }
/* 1368 */       return -1;
/*      */     }
/*      */     
/*      */     public boolean contains(Object obj)
/*      */     {
/* 1373 */       return indexOf(obj) != -1;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public String toString()
/*      */     {
/* 1383 */       if (this.length == 0) {
/* 1384 */         return "";
/*      */       }
/* 1386 */       if (this.length == 1) {
/* 1387 */         return this.parameterValues[0];
/*      */       }
/* 1389 */       return super.toString();
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\context\WebEngineContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */