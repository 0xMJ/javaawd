/*     */ package org.thymeleaf.context;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class IdentifierSequences
/*     */ {
/*     */   private final Map<String, Integer> idCounts;
/*     */   
/*     */   public IdentifierSequences()
/*     */   {
/*  49 */     this.idCounts = new HashMap(1, 1.0F);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Integer getAndIncrementIDSeq(String id)
/*     */   {
/*  66 */     Validate.notNull(id, "ID cannot be null");
/*  67 */     Integer count = (Integer)this.idCounts.get(id);
/*  68 */     if (count == null) {
/*  69 */       count = Integer.valueOf(1);
/*     */     }
/*  71 */     this.idCounts.put(id, Integer.valueOf(count.intValue() + 1));
/*  72 */     return count;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Integer getNextIDSeq(String id)
/*     */   {
/*  87 */     Validate.notNull(id, "ID cannot be null");
/*  88 */     Integer count = (Integer)this.idCounts.get(id);
/*  89 */     if (count == null) {
/*  90 */       count = Integer.valueOf(1);
/*     */     }
/*  92 */     return count;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Integer getPreviousIDSeq(String id)
/*     */   {
/* 107 */     Validate.notNull(id, "ID cannot be null");
/* 108 */     Integer count = (Integer)this.idCounts.get(id);
/* 109 */     if (count == null) {
/* 110 */       throw new TemplateProcessingException("Cannot obtain previous ID count for ID \"" + id + "\"");
/*     */     }
/*     */     
/* 113 */     return Integer.valueOf(count.intValue() - 1);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\context\IdentifierSequences.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */