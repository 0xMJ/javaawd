package org.thymeleaf.context;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public abstract interface IWebContext
  extends IContext
{
  public abstract HttpServletRequest getRequest();
  
  public abstract HttpServletResponse getResponse();
  
  public abstract HttpSession getSession();
  
  public abstract ServletContext getServletContext();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\context\IWebContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */