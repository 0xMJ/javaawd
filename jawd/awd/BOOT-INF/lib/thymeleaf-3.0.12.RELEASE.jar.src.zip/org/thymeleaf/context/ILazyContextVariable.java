package org.thymeleaf.context;

public abstract interface ILazyContextVariable<T>
{
  public abstract T getValue();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\context\ILazyContextVariable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */