/*    */ package org.thymeleaf.context;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import java.util.Map;
/*    */ import org.thymeleaf.IEngineConfiguration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ExpressionContext
/*    */   extends AbstractExpressionContext
/*    */ {
/*    */   public ExpressionContext(IEngineConfiguration configuration)
/*    */   {
/* 44 */     super(configuration);
/*    */   }
/*    */   
/*    */   public ExpressionContext(IEngineConfiguration configuration, Locale locale)
/*    */   {
/* 49 */     super(configuration, locale);
/*    */   }
/*    */   
/*    */ 
/*    */   public ExpressionContext(IEngineConfiguration configuration, Locale locale, Map<String, Object> variables)
/*    */   {
/* 55 */     super(configuration, locale, variables);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\context\ExpressionContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */