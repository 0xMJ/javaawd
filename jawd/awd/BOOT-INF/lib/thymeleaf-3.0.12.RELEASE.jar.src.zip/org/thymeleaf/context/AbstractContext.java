/*     */ package org.thymeleaf.context;
/*     */ 
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractContext
/*     */   implements IContext
/*     */ {
/*     */   private final Map<String, Object> variables;
/*     */   private Locale locale;
/*     */   
/*     */   protected AbstractContext()
/*     */   {
/*  51 */     this(null, null);
/*     */   }
/*     */   
/*     */   protected AbstractContext(Locale locale)
/*     */   {
/*  56 */     this(locale, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected AbstractContext(Locale locale, Map<String, Object> variables)
/*     */   {
/*  63 */     this.locale = (locale == null ? Locale.getDefault() : locale);
/*  64 */     this.variables = 
/*  65 */       (variables == null ? 
/*  66 */       new LinkedHashMap(10) : 
/*  67 */       new LinkedHashMap(variables));
/*     */   }
/*     */   
/*     */   public final Locale getLocale()
/*     */   {
/*  72 */     return this.locale;
/*     */   }
/*     */   
/*     */   public final boolean containsVariable(String name) {
/*  76 */     return this.variables.containsKey(name);
/*     */   }
/*     */   
/*     */   public final Set<String> getVariableNames() {
/*  80 */     return this.variables.keySet();
/*     */   }
/*     */   
/*     */   public final Object getVariable(String name)
/*     */   {
/*  85 */     return this.variables.get(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLocale(Locale locale)
/*     */   {
/*  97 */     Validate.notNull(locale, "Locale cannot be null");
/*  98 */     this.locale = locale;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setVariable(String name, Object value)
/*     */   {
/* 111 */     this.variables.put(name, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setVariables(Map<String, Object> variables)
/*     */   {
/* 123 */     if (variables == null) {
/* 124 */       return;
/*     */     }
/* 126 */     this.variables.putAll(variables);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeVariable(String name)
/*     */   {
/* 138 */     this.variables.remove(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void clearVariables()
/*     */   {
/* 148 */     this.variables.clear();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\context\AbstractContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */