package org.thymeleaf.context;

import org.thymeleaf.IEngineConfiguration;
import org.thymeleaf.expression.IExpressionObjects;

public abstract interface IExpressionContext
  extends IContext
{
  public abstract IEngineConfiguration getConfiguration();
  
  public abstract IExpressionObjects getExpressionObjects();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\context\IExpressionContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */