/*     */ package org.thymeleaf.context;
/*     */ 
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.thymeleaf.IEngineConfiguration;
/*     */ import org.thymeleaf.engine.TemplateData;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.expression.ExpressionObjects;
/*     */ import org.thymeleaf.expression.IExpressionObjects;
/*     */ import org.thymeleaf.linkbuilder.ILinkBuilder;
/*     */ import org.thymeleaf.messageresolver.IMessageResolver;
/*     */ import org.thymeleaf.model.IModelFactory;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractEngineContext
/*     */   implements IEngineContext
/*     */ {
/*     */   private final IEngineConfiguration configuration;
/*     */   private final Map<String, Object> templateResolutionAttributes;
/*     */   private final Locale locale;
/*  63 */   private IExpressionObjects expressionObjects = null;
/*  64 */   private IdentifierSequences identifierSequences = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected AbstractEngineContext(IEngineConfiguration configuration, Map<String, Object> templateResolutionAttributes, Locale locale)
/*     */   {
/*  75 */     Validate.notNull(configuration, "Configuration cannot be null");
/*     */     
/*  77 */     Validate.notNull(locale, "Locale cannot be null");
/*     */     
/*  79 */     this.configuration = configuration;
/*  80 */     this.locale = locale;
/*  81 */     this.templateResolutionAttributes = templateResolutionAttributes;
/*     */     
/*  83 */     this.identifierSequences = null;
/*     */   }
/*     */   
/*     */ 
/*     */   public final IEngineConfiguration getConfiguration()
/*     */   {
/*  89 */     return this.configuration;
/*     */   }
/*     */   
/*     */   public final Map<String, Object> getTemplateResolutionAttributes()
/*     */   {
/*  94 */     return this.templateResolutionAttributes;
/*     */   }
/*     */   
/*     */   public final Locale getLocale()
/*     */   {
/*  99 */     return this.locale;
/*     */   }
/*     */   
/*     */ 
/*     */   public final IExpressionObjects getExpressionObjects()
/*     */   {
/* 105 */     if (this.expressionObjects == null) {
/* 106 */       this.expressionObjects = new ExpressionObjects(this, this.configuration.getExpressionObjectFactory());
/*     */     }
/* 108 */     return this.expressionObjects;
/*     */   }
/*     */   
/*     */   public final TemplateMode getTemplateMode()
/*     */   {
/* 113 */     return getTemplateData().getTemplateMode();
/*     */   }
/*     */   
/*     */   public final IModelFactory getModelFactory()
/*     */   {
/* 118 */     return this.configuration.getModelFactory(getTemplateMode());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final String getMessage(Class<?> origin, String key, Object[] messageParameters, boolean useAbsentMessageRepresentation)
/*     */   {
/* 126 */     Validate.notNull(key, "Message key cannot be null");
/*     */     
/*     */ 
/* 129 */     Set<IMessageResolver> messageResolvers = this.configuration.getMessageResolvers();
/*     */     
/*     */ 
/* 132 */     for (IMessageResolver messageResolver : messageResolvers)
/*     */     {
/* 134 */       String resolvedMessage = messageResolver.resolveMessage(this, origin, key, messageParameters);
/* 135 */       if (resolvedMessage != null) {
/* 136 */         return resolvedMessage;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 141 */     if (useAbsentMessageRepresentation)
/*     */     {
/* 143 */       for (IMessageResolver messageResolver : messageResolvers)
/*     */       {
/* 145 */         String absentMessageRepresentation = messageResolver.createAbsentMessageRepresentation(this, origin, key, messageParameters);
/* 146 */         if (absentMessageRepresentation != null) {
/* 147 */           return absentMessageRepresentation;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 153 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final String buildLink(String base, Map<String, Object> parameters)
/*     */   {
/* 163 */     Set<ILinkBuilder> linkBuilders = this.configuration.getLinkBuilders();
/*     */     
/*     */ 
/* 166 */     for (ILinkBuilder linkBuilder : linkBuilders) {
/* 167 */       String link = linkBuilder.buildLink(this, base, parameters);
/* 168 */       if (link != null) {
/* 169 */         return link;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 175 */     throw new TemplateProcessingException("No configured link builder instance was able to build link with base \"" + base + "\" and parameters " + parameters);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final IdentifierSequences getIdentifierSequences()
/*     */   {
/* 185 */     if (this.identifierSequences == null) {
/* 186 */       this.identifierSequences = new IdentifierSequences();
/*     */     }
/* 188 */     return this.identifierSequences;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\context\AbstractEngineContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */