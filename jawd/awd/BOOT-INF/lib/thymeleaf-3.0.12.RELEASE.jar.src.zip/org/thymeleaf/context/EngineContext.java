/*     */ package org.thymeleaf.context;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.thymeleaf.IEngineConfiguration;
/*     */ import org.thymeleaf.engine.TemplateData;
/*     */ import org.thymeleaf.inline.IInliner;
/*     */ import org.thymeleaf.inline.NoOpInliner;
/*     */ import org.thymeleaf.model.IProcessableElementTag;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EngineContext
/*     */   extends AbstractEngineContext
/*     */   implements IEngineContext
/*     */ {
/*     */   private static final int DEFAULT_ELEMENT_HIERARCHY_SIZE = 20;
/*     */   private static final int DEFAULT_LEVELS_SIZE = 10;
/*     */   private static final int DEFAULT_MAP_SIZE = 5;
/*  73 */   private int level = 0;
/*  74 */   private int index = 0;
/*     */   
/*     */   private int[] levels;
/*     */   private HashMap<String, Object>[] maps;
/*     */   private SelectionTarget[] selectionTargets;
/*     */   private IInliner[] inliners;
/*     */   private TemplateData[] templateDatas;
/*     */   private IProcessableElementTag[] elementTags;
/*  82 */   private SelectionTarget lastSelectionTarget = null;
/*  83 */   private IInliner lastInliner = null;
/*  84 */   private TemplateData lastTemplateData = null;
/*     */   
/*     */ 
/*     */   private final List<TemplateData> templateStack;
/*     */   
/*  89 */   private static final Object NON_EXISTING = new Object()
/*     */   {
/*     */     public String toString() {
/*  92 */       return "(*removed*)";
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*  97 */   private static final Object NULL = new Object()
/*     */   {
/*     */     public String toString() {
/* 100 */       return "null";
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EngineContext(IEngineConfiguration configuration, TemplateData templateData, Map<String, Object> templateResolutionAttributes, Locale locale, Map<String, Object> variables)
/*     */   {
/* 130 */     super(configuration, templateResolutionAttributes, locale);
/*     */     
/* 132 */     this.levels = new int[10];
/* 133 */     this.maps = new HashMap[10];
/* 134 */     this.selectionTargets = new SelectionTarget[10];
/* 135 */     this.inliners = new IInliner[10];
/* 136 */     this.templateDatas = new TemplateData[10];
/*     */     
/* 138 */     this.elementTags = new IProcessableElementTag[20];
/*     */     
/* 140 */     Arrays.fill(this.levels, Integer.MAX_VALUE);
/* 141 */     Arrays.fill(this.maps, null);
/* 142 */     Arrays.fill(this.selectionTargets, null);
/* 143 */     Arrays.fill(this.inliners, null);
/* 144 */     Arrays.fill(this.templateDatas, null);
/*     */     
/* 146 */     Arrays.fill(this.elementTags, null);
/*     */     
/* 148 */     this.levels[0] = 0;
/* 149 */     this.templateDatas[0] = templateData;
/* 150 */     this.lastTemplateData = templateData;
/*     */     
/* 152 */     this.templateStack = new ArrayList(10);
/* 153 */     this.templateStack.add(templateData);
/*     */     
/* 155 */     if (variables != null) {
/* 156 */       setVariables(variables);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean containsVariable(String name)
/*     */   {
/* 163 */     int n = this.index + 1;
/*     */     
/*     */ 
/* 166 */     while (n-- != 0) {
/* 167 */       HashMap map = this.maps[n];
/* 168 */       if ((map != null) && (map.size() > 0))
/*     */       {
/* 170 */         Object value = map.get(name);
/* 171 */         if (value != null)
/*     */         {
/* 173 */           return value != NON_EXISTING;
/*     */         }
/*     */       }
/*     */     }
/* 177 */     return false;
/*     */   }
/*     */   
/*     */   public Object getVariable(String key)
/*     */   {
/* 182 */     int n = this.index + 1;
/*     */     
/*     */ 
/* 185 */     while (n-- != 0) {
/* 186 */       HashMap map = this.maps[n];
/* 187 */       if ((map != null) && (map.size() > 0))
/*     */       {
/* 189 */         Object value = map.get(key);
/* 190 */         if (value != null) {
/* 191 */           if ((value == NON_EXISTING) || (value == NULL)) {
/* 192 */             return null;
/*     */           }
/* 194 */           return resolveLazy(value);
/*     */         }
/*     */       }
/*     */     }
/* 198 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public Set<String> getVariableNames()
/*     */   {
/* 204 */     Set<String> variableNames = new HashSet();
/* 205 */     int n = this.index + 1;
/* 206 */     int i = 0;
/* 207 */     while (n-- != 0) {
/* 208 */       if (this.maps[i] != null) {
/* 209 */         for (Map.Entry<String, Object> mapEntry : this.maps[i].entrySet()) {
/* 210 */           if (mapEntry.getValue() == NON_EXISTING) {
/* 211 */             variableNames.remove(mapEntry.getKey());
/*     */           }
/*     */           else
/* 214 */             variableNames.add(mapEntry.getKey());
/*     */         }
/*     */       }
/* 217 */       i++;
/*     */     }
/* 219 */     return variableNames;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setVariable(String name, Object value)
/*     */   {
/* 226 */     ensureLevelInitialized(5);
/*     */     
/* 228 */     if ((value == NON_EXISTING) && (this.level == 0)) {
/* 229 */       this.maps[this.index].remove(name);
/*     */     }
/* 231 */     else if (value == null) {
/* 232 */       this.maps[this.index].put(name, NULL);
/*     */     } else {
/* 234 */       this.maps[this.index].put(name, value);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setVariables(Map<String, Object> variables)
/*     */   {
/* 243 */     if ((variables == null) || (variables.isEmpty())) {
/* 244 */       return;
/*     */     }
/*     */     
/* 247 */     ensureLevelInitialized(Math.max(5, variables.size() + 2));
/*     */     
/* 249 */     for (Map.Entry<String, Object> entry : variables.entrySet()) {
/* 250 */       Object value = entry.getValue();
/* 251 */       if (value == null) {
/* 252 */         this.maps[this.index].put(entry.getKey(), NULL);
/*     */       } else {
/* 254 */         this.maps[this.index].put(entry.getKey(), value);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeVariable(String name)
/*     */   {
/* 264 */     if (containsVariable(name)) {
/* 265 */       setVariable(name, NON_EXISTING);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isVariableLocal(String name)
/*     */   {
/* 273 */     int n = this.index + 1;
/* 274 */     while (n-- > 1) {
/* 275 */       if ((this.maps[n] != null) && (this.maps[n].containsKey(name))) {
/* 276 */         Object result = this.maps[n].get(name);
/* 277 */         if (result == NON_EXISTING) {
/* 278 */           return false;
/*     */         }
/* 280 */         return true;
/*     */       }
/*     */     }
/* 283 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean hasSelectionTarget()
/*     */   {
/* 290 */     if (this.lastSelectionTarget != null) {
/* 291 */       return true;
/*     */     }
/* 293 */     int n = this.index + 1;
/* 294 */     while (n-- != 0) {
/* 295 */       if (this.selectionTargets[n] != null) {
/* 296 */         return true;
/*     */       }
/*     */     }
/* 299 */     return false;
/*     */   }
/*     */   
/*     */   public Object getSelectionTarget()
/*     */   {
/* 304 */     if (this.lastSelectionTarget != null) {
/* 305 */       return this.lastSelectionTarget.selectionTarget;
/*     */     }
/* 307 */     int n = this.index + 1;
/* 308 */     while (n-- != 0) {
/* 309 */       if (this.selectionTargets[n] != null) {
/* 310 */         this.lastSelectionTarget = this.selectionTargets[n];
/* 311 */         return this.lastSelectionTarget.selectionTarget;
/*     */       }
/*     */     }
/* 314 */     return null;
/*     */   }
/*     */   
/*     */   public void setSelectionTarget(Object selectionTarget)
/*     */   {
/* 319 */     ensureLevelInitialized(-1);
/* 320 */     this.lastSelectionTarget = new SelectionTarget(selectionTarget);
/* 321 */     this.selectionTargets[this.index] = this.lastSelectionTarget;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public IInliner getInliner()
/*     */   {
/* 328 */     if (this.lastInliner != null) {
/* 329 */       if (this.lastInliner == NoOpInliner.INSTANCE) {
/* 330 */         return null;
/*     */       }
/* 332 */       return this.lastInliner;
/*     */     }
/* 334 */     int n = this.index + 1;
/* 335 */     while (n-- != 0) {
/* 336 */       if (this.inliners[n] != null) {
/* 337 */         this.lastInliner = this.inliners[n];
/* 338 */         if (this.lastInliner == NoOpInliner.INSTANCE) {
/* 339 */           return null;
/*     */         }
/* 341 */         return this.lastInliner;
/*     */       }
/*     */     }
/* 344 */     return null;
/*     */   }
/*     */   
/*     */   public void setInliner(IInliner inliner)
/*     */   {
/* 349 */     ensureLevelInitialized(-1);
/*     */     
/* 351 */     this.lastInliner = (inliner == null ? NoOpInliner.INSTANCE : inliner);
/* 352 */     this.inliners[this.index] = this.lastInliner;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public TemplateData getTemplateData()
/*     */   {
/* 359 */     if (this.lastTemplateData != null) {
/* 360 */       return this.lastTemplateData;
/*     */     }
/* 362 */     int n = this.index + 1;
/* 363 */     while (n-- != 0) {
/* 364 */       if (this.templateDatas[n] != null) {
/* 365 */         this.lastTemplateData = this.templateDatas[n];
/* 366 */         return this.lastTemplateData;
/*     */       }
/*     */     }
/* 369 */     return null;
/*     */   }
/*     */   
/*     */   public void setTemplateData(TemplateData templateData)
/*     */   {
/* 374 */     Validate.notNull(templateData, "Template Data cannot be null");
/* 375 */     ensureLevelInitialized(-1);
/* 376 */     this.lastTemplateData = templateData;
/* 377 */     this.templateDatas[this.index] = this.lastTemplateData;
/* 378 */     this.templateStack.clear();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public List<TemplateData> getTemplateStack()
/*     */   {
/* 385 */     if (!this.templateStack.isEmpty())
/*     */     {
/* 387 */       return Collections.unmodifiableList(new ArrayList(this.templateStack));
/*     */     }
/* 389 */     for (int i = 0; i <= this.index; i++) {
/* 390 */       if (this.templateDatas[i] != null) {
/* 391 */         this.templateStack.add(this.templateDatas[i]);
/*     */       }
/*     */     }
/*     */     
/* 395 */     return Collections.unmodifiableList(new ArrayList(this.templateStack));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setElementTag(IProcessableElementTag elementTag)
/*     */   {
/* 402 */     if (this.elementTags.length <= this.level) {
/* 403 */       this.elementTags = ((IProcessableElementTag[])Arrays.copyOf(this.elementTags, Math.max(this.level, this.elementTags.length + 20)));
/*     */     }
/* 405 */     this.elementTags[this.level] = elementTag;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public List<IProcessableElementTag> getElementStack()
/*     */   {
/* 412 */     List<IProcessableElementTag> elementStack = new ArrayList(this.level);
/* 413 */     for (int i = 0; (i <= this.level) && (i < this.elementTags.length); i++) {
/* 414 */       if (this.elementTags[i] != null) {
/* 415 */         elementStack.add(this.elementTags[i]);
/*     */       }
/*     */     }
/*     */     
/* 419 */     return Collections.unmodifiableList(elementStack);
/*     */   }
/*     */   
/*     */   public List<IProcessableElementTag> getElementStackAbove(int contextLevel)
/*     */   {
/* 424 */     List<IProcessableElementTag> elementStack = new ArrayList(this.level);
/* 425 */     for (int i = contextLevel + 1; (i <= this.level) && (i < this.elementTags.length); i++) {
/* 426 */       if (this.elementTags[i] != null) {
/* 427 */         elementStack.add(this.elementTags[i]);
/*     */       }
/*     */     }
/*     */     
/* 431 */     return Collections.unmodifiableList(elementStack);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void ensureLevelInitialized(int requiredSize)
/*     */   {
/* 440 */     if (this.levels[this.index] != this.level)
/*     */     {
/*     */ 
/*     */ 
/* 444 */       this.index += 1;
/*     */       
/* 446 */       if (this.levels.length == this.index) {
/* 447 */         this.levels = Arrays.copyOf(this.levels, this.levels.length + 10);
/* 448 */         Arrays.fill(this.levels, this.index, this.levels.length, Integer.MAX_VALUE);
/* 449 */         this.maps = ((HashMap[])Arrays.copyOf(this.maps, this.maps.length + 10));
/* 450 */         this.selectionTargets = ((SelectionTarget[])Arrays.copyOf(this.selectionTargets, this.selectionTargets.length + 10));
/* 451 */         this.inliners = ((IInliner[])Arrays.copyOf(this.inliners, this.inliners.length + 10));
/* 452 */         this.templateDatas = ((TemplateData[])Arrays.copyOf(this.templateDatas, this.templateDatas.length + 10));
/*     */       }
/*     */       
/* 455 */       this.levels[this.index] = this.level;
/*     */     }
/*     */     
/*     */ 
/* 459 */     if ((requiredSize >= 0) && (this.maps[this.index] == null))
/*     */     {
/* 461 */       this.maps[this.index] = new HashMap(requiredSize, 1.0F);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public int level()
/*     */   {
/* 468 */     return this.level;
/*     */   }
/*     */   
/*     */   public void increaseLevel()
/*     */   {
/* 473 */     this.level += 1;
/*     */   }
/*     */   
/*     */ 
/*     */   public void decreaseLevel()
/*     */   {
/* 479 */     Validate.isTrue(this.level > 0, "Cannot decrease variable map level below 0");
/*     */     
/* 481 */     if (this.levels[this.index] == this.level)
/*     */     {
/* 483 */       this.levels[this.index] = Integer.MAX_VALUE;
/* 484 */       if (this.maps[this.index] != null) {
/* 485 */         this.maps[this.index].clear();
/*     */       }
/* 487 */       this.selectionTargets[this.index] = null;
/* 488 */       this.inliners[this.index] = null;
/* 489 */       this.templateDatas[this.index] = null;
/* 490 */       this.index -= 1;
/*     */       
/*     */ 
/* 493 */       this.lastSelectionTarget = null;
/* 494 */       this.lastInliner = null;
/* 495 */       this.lastTemplateData = null;
/* 496 */       this.templateStack.clear();
/*     */     }
/*     */     
/*     */ 
/* 500 */     if (this.level < this.elementTags.length) {
/* 501 */       this.elementTags[this.level] = null;
/*     */     }
/*     */     
/* 504 */     this.level -= 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getStringRepresentationByLevel()
/*     */   {
/* 511 */     StringBuilder strBuilder = new StringBuilder();
/* 512 */     strBuilder.append('{');
/* 513 */     int n = this.index + 1;
/* 514 */     while (n-- != 0) {
/* 515 */       Map<String, Object> levelVars = new LinkedHashMap();
/* 516 */       if (this.maps[n] != null) {
/* 517 */         List<String> entryNames = new ArrayList(this.maps[n].keySet());
/* 518 */         Collections.sort(entryNames);
/* 519 */         Iterator localIterator = entryNames.iterator(); for (;;) { if (!localIterator.hasNext()) break label203; String name = (String)localIterator.next();
/* 520 */           Object value = this.maps[n].get(name);
/* 521 */           if (value == NON_EXISTING)
/*     */           {
/* 523 */             int n2 = n;
/* 524 */             if (n2-- == 0) continue;
/* 525 */             if ((this.maps[n2] == null) || (!this.maps[n2].containsKey(name))) break;
/* 526 */             if (this.maps[n2].get(name) == NON_EXISTING) continue;
/* 527 */             levelVars.put(name, value); continue;
/*     */           }
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 534 */           levelVars.put(name, value);
/*     */         } }
/*     */       label203:
/* 537 */       if ((n == 0) || (!levelVars.isEmpty()) || (this.selectionTargets[n] != null) || (this.inliners[n] != null) || (this.templateDatas[n] != null)) {
/* 538 */         if (strBuilder.length() > 1) {
/* 539 */           strBuilder.append(',');
/*     */         }
/* 541 */         strBuilder.append(this.levels[n]).append(":");
/* 542 */         if ((!levelVars.isEmpty()) || (n == 0)) {
/* 543 */           strBuilder.append(levelVars);
/*     */         }
/* 545 */         if (this.selectionTargets[n] != null) {
/* 546 */           strBuilder.append("<").append(this.selectionTargets[n].selectionTarget).append(">");
/*     */         }
/* 548 */         if (this.inliners[n] != null) {
/* 549 */           strBuilder.append("[").append(this.inliners[n].getName()).append("]");
/*     */         }
/* 551 */         if (this.templateDatas[n] != null) {
/* 552 */           strBuilder.append("(").append(this.templateDatas[n].getTemplate()).append(")");
/*     */         }
/*     */       }
/*     */     }
/* 556 */     strBuilder.append("}[");
/* 557 */     strBuilder.append(this.level);
/* 558 */     strBuilder.append(']');
/* 559 */     return strBuilder.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 569 */     Map<String, Object> equivalentMap = new LinkedHashMap();
/* 570 */     int n = this.index + 1;
/* 571 */     int i = 0;
/* 572 */     while (n-- != 0) {
/* 573 */       if (this.maps[i] != null) {
/* 574 */         List<String> entryNames = new ArrayList(this.maps[i].keySet());
/* 575 */         Collections.sort(entryNames);
/* 576 */         for (String name : entryNames) {
/* 577 */           Object value = this.maps[i].get(name);
/* 578 */           if (value == NON_EXISTING) {
/* 579 */             equivalentMap.remove(name);
/*     */           }
/*     */           else
/* 582 */             equivalentMap.put(name, value);
/*     */         }
/*     */       }
/* 585 */       i++;
/*     */     }
/* 587 */     String textInliningStr = getInliner() != null ? "[" + getInliner().getName() + "]" : "";
/* 588 */     String templateDataStr = "(" + getTemplateData().getTemplate() + ")";
/* 589 */     return equivalentMap.toString() + (hasSelectionTarget() ? "<" + getSelectionTarget() + ">" : "") + textInliningStr + templateDataStr;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Object resolveLazy(Object variable)
/*     */   {
/* 601 */     if ((variable != null) && ((variable instanceof ILazyContextVariable))) {
/* 602 */       return ((ILazyContextVariable)variable).getValue();
/*     */     }
/* 604 */     return variable;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final class SelectionTarget
/*     */   {
/*     */     final Object selectionTarget;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     SelectionTarget(Object selectionTarget)
/*     */     {
/* 619 */       this.selectionTarget = selectionTarget;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\context\EngineContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */