package org.thymeleaf.context;

import java.util.List;
import java.util.Map;
import org.thymeleaf.engine.TemplateData;
import org.thymeleaf.inline.IInliner;
import org.thymeleaf.model.IModelFactory;
import org.thymeleaf.model.IProcessableElementTag;
import org.thymeleaf.templatemode.TemplateMode;

public abstract interface ITemplateContext
  extends IExpressionContext
{
  public abstract TemplateData getTemplateData();
  
  public abstract TemplateMode getTemplateMode();
  
  public abstract List<TemplateData> getTemplateStack();
  
  public abstract List<IProcessableElementTag> getElementStack();
  
  public abstract Map<String, Object> getTemplateResolutionAttributes();
  
  public abstract IModelFactory getModelFactory();
  
  public abstract boolean hasSelectionTarget();
  
  public abstract Object getSelectionTarget();
  
  public abstract IInliner getInliner();
  
  public abstract String getMessage(Class<?> paramClass, String paramString, Object[] paramArrayOfObject, boolean paramBoolean);
  
  public abstract String buildLink(String paramString, Map<String, Object> paramMap);
  
  public abstract IdentifierSequences getIdentifierSequences();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\context\ITemplateContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */