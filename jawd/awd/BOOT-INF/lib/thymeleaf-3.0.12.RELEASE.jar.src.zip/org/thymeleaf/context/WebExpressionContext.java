/*    */ package org.thymeleaf.context;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import java.util.Map;
/*    */ import javax.servlet.ServletContext;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import javax.servlet.http.HttpSession;
/*    */ import org.thymeleaf.IEngineConfiguration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class WebExpressionContext
/*    */   extends AbstractExpressionContext
/*    */   implements IWebContext
/*    */ {
/*    */   private final HttpServletRequest request;
/*    */   private final HttpServletResponse response;
/*    */   private final ServletContext servletContext;
/*    */   
/*    */   public WebExpressionContext(IEngineConfiguration configuration, HttpServletRequest request, HttpServletResponse response, ServletContext servletContext)
/*    */   {
/* 55 */     super(configuration);
/* 56 */     this.request = request;
/* 57 */     this.response = response;
/* 58 */     this.servletContext = servletContext;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public WebExpressionContext(IEngineConfiguration configuration, HttpServletRequest request, HttpServletResponse response, ServletContext servletContext, Locale locale)
/*    */   {
/* 66 */     super(configuration, locale);
/* 67 */     this.request = request;
/* 68 */     this.response = response;
/* 69 */     this.servletContext = servletContext;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public WebExpressionContext(IEngineConfiguration configuration, HttpServletRequest request, HttpServletResponse response, ServletContext servletContext, Locale locale, Map<String, Object> variables)
/*    */   {
/* 78 */     super(configuration, locale, variables);
/* 79 */     this.request = request;
/* 80 */     this.response = response;
/* 81 */     this.servletContext = servletContext;
/*    */   }
/*    */   
/*    */   public HttpServletRequest getRequest()
/*    */   {
/* 86 */     return this.request;
/*    */   }
/*    */   
/*    */   public HttpSession getSession() {
/* 90 */     return this.request.getSession(false);
/*    */   }
/*    */   
/*    */   public HttpServletResponse getResponse() {
/* 94 */     return this.response;
/*    */   }
/*    */   
/*    */   public ServletContext getServletContext() {
/* 98 */     return this.servletContext;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\context\WebExpressionContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */