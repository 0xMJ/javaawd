/*     */ package org.thymeleaf.templateparser.reader;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class BlockAwareReader
/*     */   extends Reader
/*     */ {
/*     */   private final Reader reader;
/*     */   private final BlockAction action;
/*     */   private final char[] prefix;
/*     */   private final char[] suffix;
/*     */   private final char p0;
/*     */   private final char s0;
/*     */   
/*     */   public static enum BlockAction
/*     */   {
/*  33 */     DISCARD_ALL,  DISCARD_CONTAINER;
/*     */     
/*     */ 
/*     */ 
/*     */     private BlockAction() {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*  42 */   private char[] overflowBuffer = null;
/*  43 */   private int overflowBufferLen = 0;
/*     */   
/*  45 */   private boolean insideComment = false;
/*  46 */   private int index = 0;
/*  47 */   private int discardFrom = -1;
/*     */   
/*     */ 
/*     */   protected BlockAwareReader(Reader reader, BlockAction action, char[] prefix, char[] suffix)
/*     */   {
/*  52 */     this.reader = reader;
/*  53 */     this.action = action;
/*  54 */     this.prefix = prefix;
/*  55 */     this.suffix = suffix;
/*  56 */     this.p0 = this.prefix[0];
/*  57 */     this.s0 = this.suffix[0];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int read(char[] cbuf, int off, int len)
/*     */     throws IOException
/*     */   {
/*  68 */     int read = readBytes(cbuf, off, len);
/*  69 */     if (read <= 0)
/*     */     {
/*  71 */       if ((read < 0) && (this.insideComment))
/*     */       {
/*     */ 
/*  74 */         throw new IOException("Unfinished block structure " + new String(this.prefix) + "..." + new String(this.suffix));
/*     */       }
/*     */       
/*     */ 
/*  78 */       return read;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  84 */     this.discardFrom = (this.discardFrom < 0 ? this.discardFrom : Math.max(off, this.discardFrom));
/*     */     
/*  86 */     int maxi = off + read;
/*     */     
/*     */ 
/*  89 */     int i = off;
/*  90 */     while (i < maxi)
/*     */     {
/*  92 */       char c = cbuf[(i++)];
/*     */       
/*  94 */       if ((this.index != 0) || (c == this.p0) || (c == this.s0))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*  99 */         if (!this.insideComment)
/*     */         {
/* 101 */           if (c == this.prefix[this.index]) {
/* 102 */             this.index += 1;
/* 103 */             if (this.index == this.prefix.length)
/*     */             {
/* 105 */               if (i < maxi) {
/* 106 */                 System.arraycopy(cbuf, i, cbuf, i - this.prefix.length, maxi - i);
/*     */               }
/* 108 */               this.insideComment = true;
/* 109 */               this.index = 0;
/* 110 */               read -= this.prefix.length;
/* 111 */               maxi -= this.prefix.length;
/* 112 */               i -= this.prefix.length;
/* 113 */               this.discardFrom = (this.action == BlockAction.DISCARD_ALL ? i : -1);
/*     */             }
/*     */           } else {
/* 116 */             if (this.index > 0) {
/* 117 */               i -= this.index;
/*     */             }
/* 119 */             this.index = 0;
/*     */           }
/*     */           
/*     */ 
/*     */         }
/* 124 */         else if (c == this.suffix[this.index]) {
/* 125 */           this.index += 1;
/* 126 */           if (this.index == this.suffix.length)
/*     */           {
/*     */ 
/* 129 */             if (i < maxi) {
/* 130 */               System.arraycopy(cbuf, i, cbuf, i - this.suffix.length, maxi - i);
/*     */             }
/* 132 */             this.insideComment = false;
/* 133 */             this.index = 0;
/* 134 */             read -= this.suffix.length;
/* 135 */             maxi -= this.suffix.length;
/* 136 */             i -= this.suffix.length;
/*     */             
/*     */ 
/*     */ 
/* 140 */             if (this.discardFrom >= 0) {
/* 141 */               if (i < maxi) {
/* 142 */                 System.arraycopy(cbuf, i, cbuf, this.discardFrom, maxi - i);
/*     */               }
/* 144 */               read -= i - this.discardFrom;
/* 145 */               maxi -= i - this.discardFrom;
/* 146 */               i = this.discardFrom;
/* 147 */               this.discardFrom = -1;
/*     */             }
/*     */           }
/*     */         }
/*     */         else {
/* 152 */           if (this.index > 0) {
/* 153 */             i -= this.index;
/*     */           }
/* 155 */           this.index = 0;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 163 */     if (this.index > 0)
/*     */     {
/*     */ 
/*     */ 
/* 167 */       overflowLastBytes(cbuf, maxi, this.index);
/* 168 */       read -= this.index;
/* 169 */       maxi -= this.index;
/*     */       
/*     */ 
/*     */ 
/* 173 */       char[] structure = this.insideComment ? this.suffix : this.prefix;
/*     */       
/*     */ 
/* 176 */       if (matchOverflow(structure))
/*     */       {
/* 178 */         this.insideComment = (!this.insideComment);
/*     */         
/* 180 */         this.overflowBufferLen -= structure.length;
/* 181 */         this.index = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/*     */ 
/*     */ 
/* 190 */         System.arraycopy(this.overflowBuffer, 0, cbuf, maxi, 1);
/* 191 */         read++;
/* 192 */         maxi++;
/* 193 */         System.arraycopy(this.overflowBuffer, 1, this.overflowBuffer, 0, this.overflowBufferLen - 1);
/* 194 */         this.overflowBufferLen -= 1;
/* 195 */         this.index = 0;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 202 */     if (this.discardFrom >= 0) {
/* 203 */       read -= maxi - this.discardFrom;
/* 204 */       this.discardFrom = 0;
/*     */     }
/*     */     
/* 207 */     this.discardFrom = ((this.insideComment) && (this.action == BlockAction.DISCARD_ALL) ? 0 : -1);
/*     */     
/* 209 */     return read;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int readBytes(char[] buffer, int off, int len)
/*     */     throws IOException
/*     */   {
/* 218 */     if (len == 0) {
/* 219 */       return 0;
/*     */     }
/*     */     
/* 222 */     if (this.overflowBufferLen == 0) {
/* 223 */       return this.reader.read(buffer, off, len);
/*     */     }
/*     */     
/* 226 */     if (this.overflowBufferLen <= len)
/*     */     {
/*     */ 
/* 229 */       System.arraycopy(this.overflowBuffer, 0, buffer, off, this.overflowBufferLen);
/* 230 */       int read = this.overflowBufferLen;
/* 231 */       this.overflowBufferLen = 0;
/*     */       
/* 233 */       if (read < len) {
/* 234 */         int delegateRead = this.reader.read(buffer, off + read, len - read);
/* 235 */         if (delegateRead > 0) {
/* 236 */           read += delegateRead;
/*     */         }
/*     */       }
/*     */       
/* 240 */       return read;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 246 */     System.arraycopy(this.overflowBuffer, 0, buffer, off, len);
/* 247 */     if (len < this.overflowBufferLen) {
/* 248 */       System.arraycopy(this.overflowBuffer, len, this.overflowBuffer, 0, this.overflowBufferLen - len);
/*     */     }
/* 250 */     this.overflowBufferLen -= len;
/* 251 */     return len;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void overflowLastBytes(char[] buffer, int maxi, int overflowCount)
/*     */   {
/* 259 */     if (this.overflowBuffer == null) {
/* 260 */       this.overflowBuffer = new char[Math.max(this.prefix.length, this.suffix.length)];
/*     */     }
/* 262 */     if (this.overflowBufferLen > 0) {
/* 263 */       System.arraycopy(this.overflowBuffer, 0, this.overflowBuffer, overflowCount, this.overflowBufferLen);
/*     */     }
/* 265 */     System.arraycopy(buffer, maxi - overflowCount, this.overflowBuffer, 0, overflowCount);
/* 266 */     this.overflowBufferLen += overflowCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean matchOverflow(char[] structure)
/*     */     throws IOException
/*     */   {
/* 274 */     if (this.overflowBufferLen > 0) {
/* 275 */       for (int i = 0; i < this.overflowBufferLen; i++) {
/* 276 */         if (this.overflowBuffer[i] != structure[i]) {
/* 277 */           return false;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 282 */     int overflowRead = 0;
/* 283 */     while ((overflowRead >= 0) && (this.overflowBufferLen < structure.length)) {
/* 284 */       overflowRead = this.reader.read(this.overflowBuffer, this.overflowBufferLen, 1);
/* 285 */       if (overflowRead > 0) {
/* 286 */         this.overflowBufferLen += 1;
/* 287 */         if (this.overflowBuffer[(this.overflowBufferLen - 1)] != structure[(this.overflowBufferLen - 1)]) {
/* 288 */           return false;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 293 */     return this.overflowBufferLen == structure.length;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/* 302 */     this.reader.close();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\templateparser\reader\BlockAwareReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */