/*     */ package org.thymeleaf.templateparser.text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class TextParsingUtil
/*     */ {
/*     */   static int findNextStructureEndAvoidQuotes(char[] text, int offset, int maxi, int[] locator)
/*     */   {
/*  46 */     boolean inQuotes = false;
/*  47 */     boolean inApos = false;
/*     */     
/*     */ 
/*     */ 
/*  51 */     int colIndex = offset;
/*     */     
/*  53 */     int i = offset;
/*  54 */     int n = maxi - offset;
/*     */     
/*  56 */     while (n-- != 0)
/*     */     {
/*  58 */       char c = text[i];
/*     */       
/*  60 */       if (c == '\n') {
/*  61 */         colIndex = i;
/*  62 */         locator[1] = 0;
/*  63 */         locator[0] += 1;
/*  64 */       } else if ((c == '"') && (!inApos)) {
/*  65 */         inQuotes = !inQuotes;
/*  66 */       } else if ((c == '\'') && (!inQuotes)) {
/*  67 */         inApos = !inApos;
/*  68 */       } else if ((c == ']') && (!inQuotes) && (!inApos)) {
/*  69 */         locator[1] += i - colIndex;
/*  70 */         return i;
/*     */       }
/*     */       
/*  73 */       i++;
/*     */     }
/*     */     
/*     */ 
/*  77 */     locator[1] += maxi - colIndex;
/*  78 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static int findNextCommentBlockEnd(char[] text, int offset, int maxi, int[] locator)
/*     */   {
/*  89 */     int colIndex = offset;
/*     */     
/*  91 */     int i = offset;
/*  92 */     int n = maxi - offset;
/*     */     
/*  94 */     while (n-- != 0)
/*     */     {
/*  96 */       char c = text[i];
/*     */       
/*  98 */       if (c == '\n') {
/*  99 */         colIndex = i;
/* 100 */         locator[1] = 0;
/* 101 */         locator[0] += 1;
/* 102 */       } else if ((i > offset) && (c == '/') && (text[(i - 1)] == '*')) {
/* 103 */         locator[1] += i - colIndex;
/* 104 */         return i;
/*     */       }
/*     */       
/* 107 */       i++;
/*     */     }
/*     */     
/*     */ 
/* 111 */     locator[1] += maxi - colIndex;
/* 112 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static int findNextCommentLineEnd(char[] text, int offset, int maxi, int[] locator)
/*     */   {
/* 123 */     int colIndex = offset;
/*     */     
/* 125 */     int i = offset;
/* 126 */     int n = maxi - offset;
/*     */     
/* 128 */     while (n-- != 0)
/*     */     {
/* 130 */       char c = text[i];
/*     */       
/* 132 */       if (c == '\n') {
/* 133 */         locator[1] += i - colIndex;
/* 134 */         return i;
/*     */       }
/*     */       
/* 137 */       i++;
/*     */     }
/*     */     
/*     */ 
/* 141 */     locator[1] += maxi - colIndex;
/* 142 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static int findNextLiteralEnd(char[] text, int offset, int maxi, int[] locator, char literalMarker)
/*     */   {
/* 153 */     int colIndex = offset;
/*     */     
/* 155 */     int i = offset;
/* 156 */     int n = maxi - offset;
/*     */     
/* 158 */     while (n-- != 0)
/*     */     {
/* 160 */       char c = text[i];
/*     */       
/* 162 */       if (c == '\n') {
/* 163 */         colIndex = i;
/* 164 */         locator[1] = 0;
/* 165 */         locator[0] += 1;
/* 166 */       } else if ((i > offset) && (c == literalMarker) && 
/* 167 */         (isLiteralDelimiter(text, offset, i))) {
/* 168 */         locator[1] += i - colIndex;
/* 169 */         return i;
/*     */       }
/*     */       
/*     */ 
/* 173 */       i++;
/*     */     }
/*     */     
/*     */ 
/* 177 */     locator[1] += maxi - colIndex;
/* 178 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static int findNextStructureStartOrLiteralMarker(char[] text, int offset, int maxi, int[] locator, boolean processCommentsAndLiterals)
/*     */   {
/* 191 */     int colIndex = offset;
/*     */     
/* 193 */     int i = offset;
/* 194 */     int n = maxi - offset;
/*     */     
/* 196 */     while (n-- != 0)
/*     */     {
/* 198 */       char c = text[i];
/*     */       
/* 200 */       if (c == '\n') {
/* 201 */         colIndex = i;
/* 202 */         locator[1] = 0;
/* 203 */         locator[0] += 1;
/* 204 */       } else { if (c == '[') {
/* 205 */           locator[1] += i - colIndex;
/* 206 */           return i; }
/* 207 */         if (processCommentsAndLiterals) {
/* 208 */           if (c == '/') {
/* 209 */             locator[1] += i - colIndex;
/* 210 */             return i; }
/* 211 */           if (((c == '\'') || (c == '"') || (c == '`')) && 
/* 212 */             (isLiteralDelimiter(text, offset, i))) {
/* 213 */             locator[1] += i - colIndex;
/* 214 */             return i;
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 219 */       i++;
/*     */     }
/*     */     
/*     */ 
/* 223 */     locator[1] += maxi - colIndex;
/* 224 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */   private static boolean isLiteralDelimiter(char[] text, int offset, int i)
/*     */   {
/* 230 */     int escapes = 0;
/* 231 */     int j = i - 1;
/* 232 */     while ((j >= offset) && (text[(j--)] == '\\')) {
/* 233 */       escapes++;
/*     */     }
/* 235 */     return escapes % 2 == 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static int findNextWhitespaceCharWildcard(char[] text, int offset, int maxi, boolean avoidQuotes, int[] locator)
/*     */   {
/* 244 */     boolean inQuotes = false;
/* 245 */     boolean inApos = false;
/*     */     
/*     */ 
/*     */ 
/* 249 */     int i = offset;
/* 250 */     int n = maxi - offset;
/*     */     
/* 252 */     while (n-- != 0)
/*     */     {
/* 254 */       char c = text[i];
/*     */       
/* 256 */       if ((avoidQuotes) && (!inApos) && (c == '"')) {
/* 257 */         inQuotes = !inQuotes;
/* 258 */       } else if ((avoidQuotes) && (!inQuotes) && (c == '\'')) {
/* 259 */         inApos = !inApos;
/* 260 */       } else if ((!inQuotes) && (!inApos)) { if ((c != ' ') && (c != '\n') && (c != '\t') && (c != '\r') && (c != '\f') && (c != '\013') && (c != '\034') && (c != '\035') && (c != '\036') && (c != '\037')) { if (c > '')
/*     */           {
/* 262 */             if (!Character.isWhitespace(c)) {} }
/* 263 */         } else { return i;
/*     */         }
/*     */       }
/* 266 */       ParsingLocatorUtil.countChar(locator, c);
/*     */       
/* 268 */       i++;
/*     */     }
/*     */     
/*     */ 
/* 272 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static int findNextNonWhitespaceCharWildcard(char[] text, int offset, int maxi, int[] locator)
/*     */   {
/* 284 */     int i = offset;
/* 285 */     int n = maxi - offset;
/*     */     
/* 287 */     while (n-- != 0)
/*     */     {
/* 289 */       char c = text[i];
/* 290 */       if ((c != ' ') && (c != '\n') && (c != '\t') && (c != '\r') && (c != '\f') && (c != '\013') && (c != '\034') && (c != '\035') && (c != '\036') && (c != '\037')) if (c <= '') break label111;
/*     */       label111:
/* 292 */       boolean isWhitespace = Character.isWhitespace(c);
/*     */       
/* 294 */       if (!isWhitespace) {
/* 295 */         return i;
/*     */       }
/*     */       
/* 298 */       ParsingLocatorUtil.countChar(locator, c);
/*     */       
/* 300 */       i++;
/*     */     }
/*     */     
/*     */ 
/* 304 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static int findNextOperatorCharWildcard(char[] text, int offset, int maxi, int[] locator)
/*     */   {
/* 315 */     int i = offset;
/* 316 */     int n = maxi - offset;
/*     */     
/* 318 */     while (n-- != 0)
/*     */     {
/* 320 */       char c = text[i];
/*     */       
/* 322 */       if ((c != '=') && (c != ' ') && (c != '\n') && (c != '\t') && (c != '\r') && (c != '\f') && (c != '\013') && (c != '\034') && (c != '\035') && (c != '\036') && (c != '\037')) { if (c > '')
/*     */         {
/* 324 */           if (!Character.isWhitespace(c)) {} }
/* 325 */       } else { return i;
/*     */       }
/*     */       
/* 328 */       ParsingLocatorUtil.countChar(locator, c);
/*     */       
/* 330 */       i++;
/*     */     }
/*     */     
/*     */ 
/* 334 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static int findNextNonOperatorCharWildcard(char[] text, int offset, int maxi, int[] locator)
/*     */   {
/* 345 */     int i = offset;
/* 346 */     int n = maxi - offset;
/*     */     
/* 348 */     while (n-- != 0)
/*     */     {
/* 350 */       char c = text[i];
/*     */       
/* 352 */       if ((c != '=') && (c != ' ') && (c != '\n') && (c != '\t') && (c != '\r') && (c != '\f') && (c != '\013') && (c != '\034') && (c != '\035') && (c != '\036') && (c != '\037') && ((c <= '') || 
/*     */       
/* 354 */         (!Character.isWhitespace(c)))) {
/* 355 */         return i;
/*     */       }
/*     */       
/* 358 */       ParsingLocatorUtil.countChar(locator, c);
/*     */       
/* 360 */       i++;
/*     */     }
/*     */     
/*     */ 
/* 364 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static int findNextAnyCharAvoidQuotesWildcard(char[] text, int offset, int maxi, int[] locator)
/*     */   {
/* 373 */     boolean inQuotes = false;
/* 374 */     boolean inApos = false;
/*     */     
/*     */ 
/*     */ 
/* 378 */     int i = offset;
/* 379 */     int n = maxi - offset;
/*     */     
/* 381 */     while (n-- != 0)
/*     */     {
/* 383 */       char c = text[i];
/*     */       
/* 385 */       if ((!inApos) && (c == '"')) {
/* 386 */         if (inQuotes) {
/* 387 */           ParsingLocatorUtil.countChar(locator, c);
/* 388 */           i++;
/* 389 */           return i < maxi ? i : -1;
/*     */         }
/* 391 */         inQuotes = true;
/* 392 */       } else if ((!inQuotes) && (c == '\'')) {
/* 393 */         if (inApos) {
/* 394 */           ParsingLocatorUtil.countChar(locator, c);
/* 395 */           i++;
/* 396 */           return i < maxi ? i : -1;
/*     */         }
/* 398 */         inApos = true;
/* 399 */       } else if ((!inQuotes) && (!inApos)) {
/* 400 */         return i;
/*     */       }
/*     */       
/* 403 */       ParsingLocatorUtil.countChar(locator, c);
/*     */       
/* 405 */       i++;
/*     */     }
/*     */     
/*     */ 
/* 409 */     return -1;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\templateparser\text\TextParsingUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */