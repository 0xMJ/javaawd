/*     */ package org.thymeleaf.templateparser.raw;
/*     */ 
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class RawParser
/*     */ {
/*     */   private final BufferPool pool;
/*     */   
/*     */   RawParser(int poolSize, int bufferSize)
/*     */   {
/*  50 */     this.pool = new BufferPool(poolSize, bufferSize, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void parse(String document, IRawHandler handler)
/*     */     throws RawParseException
/*     */   {
/*  60 */     if (document == null) {
/*  61 */       throw new IllegalArgumentException("Document cannot be null");
/*     */     }
/*  63 */     parse(new StringReader(document), handler);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void parse(Reader reader, IRawHandler handler)
/*     */     throws RawParseException
/*     */   {
/*  73 */     if (reader == null) {
/*  74 */       throw new IllegalArgumentException("Reader cannot be null");
/*     */     }
/*     */     
/*  77 */     if (handler == null) {
/*  78 */       throw new IllegalArgumentException("Handler cannot be null");
/*     */     }
/*     */     
/*  81 */     parseDocument(reader, this.pool.poolBufferSize, handler);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void parseDocument(Reader reader, int suggestedBufferSize, IRawHandler handler)
/*     */     throws RawParseException
/*     */   {
/* 101 */     long parsingStartTimeNanos = System.nanoTime();
/*     */     
/* 103 */     char[] buffer = null;
/*     */     
/*     */     try
/*     */     {
/* 107 */       handler.handleDocumentStart(parsingStartTimeNanos, 1, 1);
/*     */       
/* 109 */       int bufferSize = suggestedBufferSize;
/* 110 */       buffer = this.pool.allocateBuffer(bufferSize);
/*     */       
/* 112 */       int bufferContentSize = reader.read(buffer);
/*     */       
/* 114 */       boolean cont = bufferContentSize != -1;
/*     */       
/* 116 */       while (cont)
/*     */       {
/* 118 */         if (bufferContentSize == bufferSize)
/*     */         {
/*     */ 
/* 121 */           char[] newBuffer = null;
/*     */           try
/*     */           {
/* 124 */             bufferSize *= 2;
/*     */             
/* 126 */             newBuffer = this.pool.allocateBuffer(bufferSize);
/* 127 */             System.arraycopy(buffer, 0, newBuffer, 0, bufferContentSize);
/*     */             
/* 129 */             this.pool.releaseBuffer(buffer);
/*     */             
/* 131 */             buffer = newBuffer;
/*     */           }
/*     */           catch (Exception ignored) {
/* 134 */             this.pool.releaseBuffer(newBuffer);
/*     */           }
/*     */         }
/*     */         
/*     */ 
/* 139 */         int read = reader.read(buffer, bufferContentSize, bufferSize - bufferContentSize);
/* 140 */         if (read != -1) {
/* 141 */           bufferContentSize += read;
/*     */         } else {
/* 143 */           cont = false;
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 148 */       handler.handleText(buffer, 0, bufferContentSize, 1, 1);
/*     */       
/* 150 */       int[] lastLineCol = computeLastLineCol(buffer, bufferContentSize);
/*     */       
/* 152 */       long parsingEndTimeNanos = System.nanoTime();
/* 153 */       handler.handleDocumentEnd(parsingEndTimeNanos, parsingEndTimeNanos - parsingStartTimeNanos, lastLineCol[0], lastLineCol[1]); return;
/*     */     }
/*     */     catch (RawParseException e) {
/* 156 */       throw e;
/*     */     } catch (Exception e) {
/* 158 */       throw new RawParseException(e);
/*     */     } finally {
/* 160 */       this.pool.releaseBuffer(buffer);
/*     */       try {
/* 162 */         reader.close();
/*     */       }
/*     */       catch (Throwable localThrowable1) {}
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static int[] computeLastLineCol(char[] buffer, int bufferContentSize)
/*     */   {
/* 174 */     if (bufferContentSize == 0) {
/* 175 */       return new int[] { 1, 1 };
/*     */     }
/*     */     
/* 178 */     int line = 1;
/* 179 */     int col = 1;
/*     */     
/*     */ 
/*     */ 
/* 183 */     int lastLineFeed = 0;
/*     */     
/* 185 */     int n = bufferContentSize;
/* 186 */     int i = 0;
/*     */     
/* 188 */     while (n-- != 0) {
/* 189 */       char c = buffer[i];
/* 190 */       if (c == '\n') {
/* 191 */         line++;
/* 192 */         lastLineFeed = i;
/*     */       }
/* 194 */       i++;
/*     */     }
/*     */     
/* 197 */     col = bufferContentSize - lastLineFeed;
/*     */     
/* 199 */     return new int[] { line, col };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final class BufferPool
/*     */   {
/*     */     private final char[][] pool;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private final boolean[] allocated;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private final int poolBufferSize;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private BufferPool(int poolSize, int poolBufferSize)
/*     */     {
/* 227 */       this.pool = new char[poolSize][];
/* 228 */       this.allocated = new boolean[poolSize];
/* 229 */       this.poolBufferSize = poolBufferSize;
/*     */       
/* 231 */       for (int i = 0; i < this.pool.length; i++) {
/* 232 */         this.pool[i] = new char[this.poolBufferSize];
/*     */       }
/* 234 */       Arrays.fill(this.allocated, false);
/*     */     }
/*     */     
/*     */     private synchronized char[] allocateBuffer(int bufferSize)
/*     */     {
/* 239 */       if (bufferSize != this.poolBufferSize)
/*     */       {
/*     */ 
/* 242 */         return new char[bufferSize];
/*     */       }
/* 244 */       for (int i = 0; i < this.pool.length; i++) {
/* 245 */         if (this.allocated[i] == 0) {
/* 246 */           this.allocated[i] = true;
/* 247 */           return this.pool[i];
/*     */         }
/*     */       }
/* 250 */       return new char[bufferSize];
/*     */     }
/*     */     
/*     */     private synchronized void releaseBuffer(char[] buffer) {
/* 254 */       if (buffer == null) {
/* 255 */         return;
/*     */       }
/* 257 */       if (buffer.length != this.poolBufferSize)
/*     */       {
/* 259 */         return;
/*     */       }
/* 261 */       for (int i = 0; i < this.pool.length; i++) {
/* 262 */         if (this.pool[i] == buffer)
/*     */         {
/* 264 */           this.allocated[i] = false;
/* 265 */           return;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\templateparser\raw\RawParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */