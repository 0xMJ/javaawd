/*     */ package org.thymeleaf.templateparser.text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractChainedTextHandler
/*     */   extends AbstractTextHandler
/*     */ {
/*     */   private final ITextHandler next;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected AbstractChainedTextHandler(ITextHandler next)
/*     */   {
/*  38 */     this.next = next;
/*     */   }
/*     */   
/*     */   protected ITextHandler getNext()
/*     */   {
/*  43 */     return this.next;
/*     */   }
/*     */   
/*     */ 
/*     */   public void handleDocumentStart(long startTimeNanos, int line, int col)
/*     */     throws TextParseException
/*     */   {
/*  50 */     this.next.handleDocumentStart(startTimeNanos, line, col);
/*     */   }
/*     */   
/*     */   public void handleDocumentEnd(long endTimeNanos, long totalTimeNanos, int line, int col) throws TextParseException
/*     */   {
/*  55 */     this.next.handleDocumentEnd(endTimeNanos, totalTimeNanos, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void handleText(char[] buffer, int offset, int len, int line, int col)
/*     */     throws TextParseException
/*     */   {
/*  63 */     this.next.handleText(buffer, offset, len, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleComment(char[] buffer, int contentOffset, int contentLen, int outerOffset, int outerLen, int line, int col)
/*     */     throws TextParseException
/*     */   {
/*  72 */     this.next.handleComment(buffer, contentOffset, contentLen, outerOffset, outerLen, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleStandaloneElementStart(char[] buffer, int nameOffset, int nameLen, boolean minimized, int line, int col)
/*     */     throws TextParseException
/*     */   {
/*  81 */     this.next.handleStandaloneElementStart(buffer, nameOffset, nameLen, minimized, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleStandaloneElementEnd(char[] buffer, int nameOffset, int nameLen, boolean minimized, int line, int col)
/*     */     throws TextParseException
/*     */   {
/*  90 */     this.next.handleStandaloneElementEnd(buffer, nameOffset, nameLen, minimized, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void handleOpenElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws TextParseException
/*     */   {
/*  98 */     this.next.handleOpenElementStart(buffer, nameOffset, nameLen, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void handleOpenElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws TextParseException
/*     */   {
/* 106 */     this.next.handleOpenElementEnd(buffer, nameOffset, nameLen, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void handleCloseElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws TextParseException
/*     */   {
/* 114 */     this.next.handleCloseElementStart(buffer, nameOffset, nameLen, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void handleCloseElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws TextParseException
/*     */   {
/* 122 */     this.next.handleCloseElementEnd(buffer, nameOffset, nameLen, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleAttribute(char[] buffer, int nameOffset, int nameLen, int nameLine, int nameCol, int operatorOffset, int operatorLen, int operatorLine, int operatorCol, int valueContentOffset, int valueContentLen, int valueOuterOffset, int valueOuterLen, int valueLine, int valueCol)
/*     */     throws TextParseException
/*     */   {
/* 135 */     this.next.handleAttribute(buffer, nameOffset, nameLen, nameLine, nameCol, operatorOffset, operatorLen, operatorLine, operatorCol, valueContentOffset, valueContentLen, valueOuterOffset, valueOuterLen, valueLine, valueCol);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\templateparser\text\AbstractChainedTextHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */