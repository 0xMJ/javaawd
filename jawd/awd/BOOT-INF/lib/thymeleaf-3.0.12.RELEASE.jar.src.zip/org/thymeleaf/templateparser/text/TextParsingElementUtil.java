/*     */ package org.thymeleaf.templateparser.text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class TextParsingElementUtil
/*     */ {
/*     */   public static void parseStandaloneElement(char[] buffer, int offset, int len, int line, int col, ITextHandler handler)
/*     */     throws TextParseException
/*     */   {
/*  50 */     if ((len < 4) || (!isOpenElementStart(buffer, offset, offset + len)) || (!isElementEnd(buffer, offset + len - 2, offset + len, true))) {
/*  51 */       throw new TextParseException("Could not parse as a well-formed standalone element: \"" + new String(buffer, offset, len) + "\"", line, col);
/*     */     }
/*     */     
/*     */ 
/*  55 */     int contentOffset = offset + 2;
/*  56 */     int contentLen = len - 4;
/*     */     
/*  58 */     int maxi = contentOffset + contentLen;
/*     */     
/*  60 */     int[] locator = { line, col + 2 };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  67 */     int elementNameEnd = TextParsingUtil.findNextWhitespaceCharWildcard(buffer, contentOffset, maxi, true, locator);
/*     */     
/*  69 */     if (elementNameEnd == -1)
/*     */     {
/*     */ 
/*  72 */       handler.handleStandaloneElementStart(buffer, contentOffset, contentLen, true, line, col);
/*     */       
/*     */ 
/*     */ 
/*  76 */       handler.handleStandaloneElementEnd(buffer, contentOffset, contentLen, true, locator[0], locator[1]);
/*     */       
/*     */ 
/*     */ 
/*  80 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  85 */     handler.handleStandaloneElementStart(buffer, contentOffset, elementNameEnd - contentOffset, true, line, col);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  91 */     TextParsingAttributeSequenceUtil.parseAttributeSequence(buffer, elementNameEnd, maxi - elementNameEnd, locator[0], locator[1], handler);
/*     */     
/*     */ 
/*     */ 
/*  95 */     TextParsingUtil.findNextStructureEndAvoidQuotes(buffer, elementNameEnd, maxi, locator);
/*     */     
/*  97 */     handler.handleStandaloneElementEnd(buffer, contentOffset, elementNameEnd - contentOffset, true, locator[0], locator[1]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void parseOpenElement(char[] buffer, int offset, int len, int line, int col, ITextHandler handler)
/*     */     throws TextParseException
/*     */   {
/* 113 */     if ((len < 3) || (!isOpenElementStart(buffer, offset, offset + len)) || (!isElementEnd(buffer, offset + len - 1, offset + len, false))) {
/* 114 */       throw new TextParseException("Could not parse as a well-formed open element: \"" + new String(buffer, offset, len) + "\"", line, col);
/*     */     }
/*     */     
/*     */ 
/* 118 */     int contentOffset = offset + 2;
/* 119 */     int contentLen = len - 3;
/*     */     
/* 121 */     int maxi = contentOffset + contentLen;
/*     */     
/* 123 */     int[] locator = { line, col + 2 };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 130 */     int elementNameEnd = TextParsingUtil.findNextWhitespaceCharWildcard(buffer, contentOffset, maxi, true, locator);
/*     */     
/* 132 */     if (elementNameEnd == -1)
/*     */     {
/*     */ 
/* 135 */       handler.handleOpenElementStart(buffer, contentOffset, contentLen, line, col);
/*     */       
/*     */ 
/*     */ 
/* 139 */       handler.handleOpenElementEnd(buffer, contentOffset, contentLen, locator[0], locator[1]);
/*     */       
/*     */ 
/*     */ 
/* 143 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 148 */     handler.handleOpenElementStart(buffer, contentOffset, elementNameEnd - contentOffset, line, col);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 154 */     TextParsingAttributeSequenceUtil.parseAttributeSequence(buffer, elementNameEnd, maxi - elementNameEnd, locator[0], locator[1], handler);
/*     */     
/*     */ 
/*     */ 
/* 158 */     TextParsingUtil.findNextStructureEndAvoidQuotes(buffer, elementNameEnd, maxi, locator);
/*     */     
/* 160 */     handler.handleOpenElementEnd(buffer, contentOffset, elementNameEnd - contentOffset, locator[0], locator[1]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void parseCloseElement(char[] buffer, int offset, int len, int line, int col, ITextHandler handler)
/*     */     throws TextParseException
/*     */   {
/* 176 */     if ((len < 3) || (!isCloseElementStart(buffer, offset, offset + len)) || (!isElementEnd(buffer, offset + len - 1, offset + len, false))) {
/* 177 */       throw new TextParseException("Could not parse as a well-formed close element: \"" + new String(buffer, offset, len) + "\"", line, col);
/*     */     }
/*     */     
/*     */ 
/* 181 */     int contentOffset = offset + 2;
/* 182 */     int contentLen = len - 3;
/*     */     
/* 184 */     int maxi = contentOffset + contentLen;
/*     */     
/* 186 */     int[] locator = { line, col + 2 };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 193 */     int elementNameEnd = TextParsingUtil.findNextWhitespaceCharWildcard(buffer, contentOffset, maxi, true, locator);
/*     */     
/* 195 */     if (elementNameEnd == -1)
/*     */     {
/*     */ 
/* 198 */       handler.handleCloseElementStart(buffer, contentOffset, contentLen, line, col);
/*     */       
/*     */ 
/*     */ 
/* 202 */       handler.handleCloseElementEnd(buffer, contentOffset, contentLen, locator[0], locator[1]);
/*     */       
/*     */ 
/*     */ 
/* 206 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 211 */     handler.handleCloseElementStart(buffer, contentOffset, elementNameEnd - contentOffset, line, col);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 217 */     int wsEnd = TextParsingUtil.findNextNonWhitespaceCharWildcard(buffer, elementNameEnd, maxi, locator);
/*     */     
/* 219 */     if (wsEnd != -1)
/*     */     {
/*     */ 
/* 222 */       throw new TextParseException("Could not parse as a well-formed closing element \"" + new String(buffer, offset, len) + "\": No attributes are allowed here", line, col);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 227 */     handler.handleCloseElementEnd(buffer, contentOffset, elementNameEnd - contentOffset, locator[0], locator[1]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static boolean isOpenElementStart(char[] buffer, int offset, int maxi)
/*     */   {
/* 240 */     int len = maxi - offset;
/*     */     
/* 242 */     if ((len > 2) && (buffer[offset] == '[') && (buffer[(offset + 1)] == '#')) {} return 
/*     */     
/*     */ 
/* 245 */       isElementNameOrEnd(buffer, offset + 2, maxi);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   static boolean isCloseElementStart(char[] buffer, int offset, int maxi)
/*     */   {
/* 252 */     int len = maxi - offset;
/*     */     
/* 254 */     if ((len > 2) && (buffer[offset] == '[') && (buffer[(offset + 1)] == '/')) {} return 
/*     */     
/*     */ 
/* 257 */       isElementNameOrEnd(buffer, offset + 2, maxi);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   static boolean isElementEnd(char[] buffer, int offset, int maxi, boolean minimized)
/*     */   {
/* 264 */     int len = maxi - offset;
/*     */     
/* 266 */     if (len < 1) {
/* 267 */       return false;
/*     */     }
/*     */     
/* 270 */     if (minimized) {
/* 271 */       if ((len < 2) || (buffer[offset] != '/')) {
/* 272 */         return false;
/*     */       }
/* 274 */       return buffer[(offset + 1)] == ']';
/*     */     }
/*     */     
/* 277 */     return buffer[offset] == ']';
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean isElementNameOrEnd(char[] buffer, int offset, int maxi)
/*     */   {
/* 286 */     if (Character.isWhitespace(buffer[offset]))
/*     */     {
/* 288 */       return true;
/*     */     }
/*     */     
/* 291 */     int len = maxi - offset;
/*     */     
/* 293 */     if ((len > 1) && (buffer[offset] == '/'))
/*     */     {
/* 295 */       return isElementEnd(buffer, offset, maxi, true);
/*     */     }
/*     */     
/* 298 */     if ((len > 0) && (buffer[offset] == ']'))
/*     */     {
/* 300 */       return isElementEnd(buffer, offset, maxi, false);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 307 */     if ((len > 0) && (buffer[offset] != '-') && (buffer[offset] != '!') && (buffer[offset] != '/') && (buffer[offset] != '?') && (buffer[offset] != '[') && (buffer[offset] != '{')) {} return 
/*     */     
/*     */ 
/*     */ 
/* 311 */       !Character.isWhitespace(buffer[offset]);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\templateparser\text\TextParsingElementUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */