/*     */ package org.thymeleaf.templateparser.text;
/*     */ 
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class TextParser
/*     */ {
/*     */   private final BufferPool pool;
/*     */   private final boolean processCommentsAndLiterals;
/*     */   private final boolean standardDialectPresent;
/*     */   
/*     */   TextParser(int poolSize, int bufferSize, boolean processCommentsAndLiterals, boolean standardDialectPresent)
/*     */   {
/*  55 */     this.pool = new BufferPool(poolSize, bufferSize, null);
/*  56 */     this.processCommentsAndLiterals = processCommentsAndLiterals;
/*  57 */     this.standardDialectPresent = standardDialectPresent;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void parse(String document, ITextHandler handler)
/*     */     throws TextParseException
/*     */   {
/*  67 */     if (document == null) {
/*  68 */       throw new IllegalArgumentException("Document cannot be null");
/*     */     }
/*  70 */     parse(new StringReader(document), handler);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void parse(Reader reader, ITextHandler handler)
/*     */     throws TextParseException
/*     */   {
/*  80 */     if (reader == null) {
/*  81 */       throw new IllegalArgumentException("Reader cannot be null");
/*     */     }
/*     */     
/*  84 */     if (handler == null) {
/*  85 */       throw new IllegalArgumentException("Handler cannot be null");
/*     */     }
/*     */     
/*  88 */     ITextHandler handlerChain = handler;
/*     */     
/*     */ 
/*     */ 
/*  92 */     handlerChain = new EventProcessorTextHandler(handlerChain);
/*     */     
/*     */ 
/*     */ 
/*  96 */     if (this.processCommentsAndLiterals) {
/*  97 */       handlerChain = new CommentProcessorTextHandler(this.standardDialectPresent, handlerChain);
/*     */     }
/*     */     
/* 100 */     parseDocument(reader, this.pool.poolBufferSize, handlerChain);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void parseDocument(Reader reader, int suggestedBufferSize, ITextHandler handler)
/*     */     throws TextParseException
/*     */   {
/* 116 */     long parsingStartTimeNanos = System.nanoTime();
/*     */     
/* 118 */     char[] buffer = null;
/*     */     
/*     */     try
/*     */     {
/* 122 */       TextParseStatus status = new TextParseStatus();
/*     */       
/* 124 */       handler.handleDocumentStart(parsingStartTimeNanos, 1, 1);
/*     */       
/* 126 */       int bufferSize = suggestedBufferSize;
/* 127 */       buffer = this.pool.allocateBuffer(bufferSize);
/*     */       
/* 129 */       int bufferContentSize = reader.read(buffer);
/*     */       
/* 131 */       boolean cont = bufferContentSize != -1;
/*     */       
/* 133 */       status.offset = -1;
/* 134 */       status.line = 1;
/* 135 */       status.col = 1;
/* 136 */       status.inStructure = false;
/* 137 */       status.inCommentLine = false;
/* 138 */       status.literalMarker = '\000';
/*     */       
/* 140 */       while (cont)
/*     */       {
/* 142 */         parseBuffer(buffer, 0, bufferContentSize, handler, status);
/*     */         
/* 144 */         int readOffset = 0;
/* 145 */         int readLen = bufferSize;
/*     */         
/* 147 */         if (status.offset == 0)
/*     */         {
/* 149 */           if (bufferContentSize == bufferSize)
/*     */           {
/*     */ 
/* 152 */             char[] newBuffer = null;
/*     */             try
/*     */             {
/* 155 */               bufferSize *= 2;
/*     */               
/* 157 */               newBuffer = this.pool.allocateBuffer(bufferSize);
/* 158 */               System.arraycopy(buffer, 0, newBuffer, 0, bufferContentSize);
/*     */               
/* 160 */               this.pool.releaseBuffer(buffer);
/*     */               
/* 162 */               buffer = newBuffer;
/*     */             }
/*     */             catch (Exception ignored) {
/* 165 */               this.pool.releaseBuffer(newBuffer);
/*     */             }
/*     */           }
/*     */           
/*     */ 
/*     */ 
/*     */ 
/* 172 */           readOffset = bufferContentSize;
/* 173 */           readLen = bufferSize - readOffset;
/*     */         }
/* 175 */         else if (status.offset < bufferContentSize)
/*     */         {
/* 177 */           System.arraycopy(buffer, status.offset, buffer, 0, bufferContentSize - status.offset);
/*     */           
/* 179 */           readOffset = bufferContentSize - status.offset;
/* 180 */           readLen = bufferSize - readOffset;
/*     */           
/* 182 */           status.offset = 0;
/* 183 */           bufferContentSize = readOffset;
/*     */         }
/*     */         
/*     */ 
/* 187 */         int read = reader.read(buffer, readOffset, readLen);
/* 188 */         if (read != -1) {
/* 189 */           bufferContentSize = readOffset + read;
/*     */         } else {
/* 191 */           cont = false;
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 198 */       int lastLine = status.line;
/* 199 */       int lastCol = status.col;
/*     */       
/* 201 */       int lastStart = status.offset;
/* 202 */       int lastLen = bufferContentSize - lastStart;
/*     */       
/* 204 */       if (lastLen > 0)
/*     */       {
/*     */ 
/*     */ 
/* 208 */         if ((status.inStructure) && (!status.inCommentLine)) {
/* 209 */           throw new TextParseException("Incomplete structure: \"" + new String(buffer, lastStart, lastLen) + "\"", status.line, status.col);
/*     */         }
/*     */         
/*     */ 
/* 213 */         handler.handleText(buffer, lastStart, lastLen, status.line, status.col);
/*     */         
/*     */ 
/*     */ 
/* 217 */         for (int i = lastStart; i < lastStart + lastLen; i++) {
/* 218 */           char c = buffer[i];
/* 219 */           if (c == '\n') {
/* 220 */             lastLine++;
/* 221 */             lastCol = 1;
/*     */           } else {
/* 223 */             lastCol++;
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 230 */       long parsingEndTimeNanos = System.nanoTime();
/* 231 */       handler.handleDocumentEnd(parsingEndTimeNanos, parsingEndTimeNanos - parsingStartTimeNanos, lastLine, lastCol); return;
/*     */     }
/*     */     catch (TextParseException e) {
/* 234 */       throw e;
/*     */     } catch (Exception e) {
/* 236 */       throw new TextParseException(e);
/*     */     } finally {
/* 238 */       this.pool.releaseBuffer(buffer);
/*     */       try {
/* 240 */         reader.close();
/*     */       }
/*     */       catch (Throwable localThrowable1) {}
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void parseBuffer(char[] buffer, int offset, int len, ITextHandler handler, TextParseStatus status)
/*     */     throws TextParseException
/*     */   {
/* 261 */     int[] locator = { status.line, status.col };
/*     */     
/* 263 */     int currentLine = locator[0];
/* 264 */     int currentCol = locator[1];
/*     */     
/* 266 */     int maxi = offset + len;
/* 267 */     int i = offset;
/* 268 */     int current = i;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 273 */     boolean inOpenElement = false;
/* 274 */     boolean inCloseElement = false;
/* 275 */     boolean inCommentBlock = false;
/* 276 */     boolean inCommentLine = false;
/* 277 */     boolean inLiteral = false;
/*     */     
/* 279 */     int pos = i;
/* 280 */     int tagStart = i;
/* 281 */     int tagEnd = i;
/*     */     
/* 283 */     while (i < maxi)
/*     */     {
/* 285 */       boolean inStructure = (inOpenElement) || (inCloseElement) || (inCommentBlock) || (inCommentLine) || (inLiteral);
/*     */       
/* 287 */       if (!inStructure)
/*     */       {
/* 289 */         pos = TextParsingUtil.findNextStructureStartOrLiteralMarker(buffer, i, maxi, locator, this.processCommentsAndLiterals);
/*     */         
/*     */ 
/* 292 */         if (pos == -1)
/*     */         {
/* 294 */           status.offset = current;
/* 295 */           status.line = currentLine;
/* 296 */           status.col = currentCol;
/* 297 */           status.inStructure = false;
/* 298 */           status.inCommentLine = false;
/* 299 */           status.literalMarker = '\000';
/* 300 */           return;
/*     */         }
/*     */         
/*     */ 
/* 304 */         char c = buffer[pos];
/*     */         
/* 306 */         inOpenElement = TextParsingElementUtil.isOpenElementStart(buffer, pos, maxi);
/* 307 */         if (!inOpenElement) {
/* 308 */           inCloseElement = TextParsingElementUtil.isCloseElementStart(buffer, pos, maxi);
/* 309 */           if ((!inCloseElement) && 
/* 310 */             (this.processCommentsAndLiterals)) {
/* 311 */             inCommentBlock = TextParsingCommentUtil.isCommentBlockStart(buffer, pos, maxi);
/* 312 */             if (!inCommentBlock) {
/* 313 */               inCommentLine = TextParsingCommentUtil.isCommentLineStart(buffer, pos, maxi);
/* 314 */               if (!inCommentLine)
/*     */               {
/*     */ 
/*     */ 
/* 318 */                 inLiteral = (c == '\'') || (c == '"') || (c == '`') || (TextParsingLiteralUtil.isRegexLiteralStart(buffer, pos, maxi));
/* 319 */                 status.literalMarker = (inLiteral ? c : '\000');
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */         
/*     */ 
/* 326 */         inStructure = (inOpenElement) || (inCloseElement) || (inCommentBlock) || (inCommentLine) || (inLiteral);
/*     */         
/* 328 */         if ((inStructure) && (!inLiteral))
/*     */         {
/*     */ 
/* 331 */           tagStart = pos;
/*     */         }
/*     */         
/* 334 */         while (!inStructure)
/*     */         {
/*     */ 
/*     */ 
/* 338 */           ParsingLocatorUtil.countChar(locator, c);
/* 339 */           pos = TextParsingUtil.findNextStructureStartOrLiteralMarker(buffer, pos + 1, maxi, locator, this.processCommentsAndLiterals);
/*     */           
/*     */ 
/* 342 */           if (pos == -1) {
/* 343 */             status.offset = current;
/* 344 */             status.line = currentLine;
/* 345 */             status.col = currentCol;
/* 346 */             status.inStructure = false;
/* 347 */             status.inCommentLine = false;
/* 348 */             status.literalMarker = '\000';
/* 349 */             return;
/*     */           }
/*     */           
/* 352 */           c = buffer[pos];
/*     */           
/* 354 */           inOpenElement = TextParsingElementUtil.isOpenElementStart(buffer, pos, maxi);
/* 355 */           if (!inOpenElement) {
/* 356 */             inCloseElement = TextParsingElementUtil.isCloseElementStart(buffer, pos, maxi);
/* 357 */             if ((!inCloseElement) && 
/* 358 */               (this.processCommentsAndLiterals)) {
/* 359 */               inCommentBlock = TextParsingCommentUtil.isCommentBlockStart(buffer, pos, maxi);
/* 360 */               if (!inCommentBlock) {
/* 361 */                 inCommentLine = TextParsingCommentUtil.isCommentLineStart(buffer, pos, maxi);
/* 362 */                 if (!inCommentLine)
/*     */                 {
/*     */ 
/*     */ 
/* 366 */                   inLiteral = (c == '\'') || (c == '"') || (c == '`') || (TextParsingLiteralUtil.isRegexLiteralStart(buffer, pos, maxi));
/* 367 */                   status.literalMarker = (inLiteral ? c : '\000');
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */           
/*     */ 
/* 374 */           inStructure = (inOpenElement) || (inCloseElement) || (inCommentBlock) || (inCommentLine) || (inLiteral);
/*     */           
/* 376 */           if ((inStructure) && (!inLiteral))
/*     */           {
/*     */ 
/* 379 */             tagStart = pos;
/*     */           }
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 385 */         if (tagStart > current)
/*     */         {
/*     */ 
/* 388 */           handler.handleText(buffer, current, tagStart - current, currentLine, currentCol);
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 394 */         if (tagStart == pos)
/*     */         {
/* 396 */           current = tagStart;
/* 397 */           currentLine = locator[0];
/* 398 */           currentCol = locator[1];
/*     */         }
/* 400 */         i = pos;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 412 */         pos = inCommentLine ? TextParsingUtil.findNextCommentLineEnd(buffer, i, maxi, locator) : inCommentBlock ? TextParsingUtil.findNextCommentBlockEnd(buffer, i, maxi, locator) : inLiteral ? TextParsingUtil.findNextLiteralEnd(buffer, i, maxi, locator, status.literalMarker) : TextParsingUtil.findNextStructureEndAvoidQuotes(buffer, i, maxi, locator);
/*     */         
/* 414 */         if (pos < 0)
/*     */         {
/* 416 */           status.offset = current;
/* 417 */           status.line = currentLine;
/* 418 */           status.col = currentCol;
/* 419 */           status.inStructure = true;
/* 420 */           status.inCommentLine = inCommentLine;
/* 421 */           status.literalMarker = '\000';
/* 422 */           return;
/*     */         }
/*     */         
/* 425 */         if (inOpenElement)
/*     */         {
/*     */ 
/* 428 */           tagEnd = pos;
/*     */           
/* 430 */           if (buffer[(tagEnd - 1)] == '/')
/*     */           {
/* 432 */             TextParsingElementUtil.parseStandaloneElement(buffer, current, tagEnd - current + 1, currentLine, currentCol, handler);
/*     */           }
/*     */           else {
/* 435 */             TextParsingElementUtil.parseOpenElement(buffer, current, tagEnd - current + 1, currentLine, currentCol, handler);
/*     */           }
/*     */           
/* 438 */           inOpenElement = false;
/*     */         }
/* 440 */         else if (inCloseElement)
/*     */         {
/*     */ 
/* 443 */           tagEnd = pos;
/*     */           
/*     */ 
/* 446 */           TextParsingElementUtil.parseCloseElement(buffer, current, tagEnd - current + 1, currentLine, currentCol, handler);
/*     */           
/* 448 */           inCloseElement = false;
/*     */         }
/* 450 */         else if (inCommentBlock)
/*     */         {
/*     */ 
/* 453 */           tagEnd = pos;
/*     */           
/* 455 */           TextParsingCommentUtil.parseComment(buffer, current, tagEnd - current + 1, currentLine, currentCol, handler);
/*     */           
/* 457 */           inCommentBlock = false;
/*     */         }
/* 459 */         else if (inCommentLine)
/*     */         {
/*     */ 
/*     */ 
/* 463 */           tagEnd = pos;
/*     */           
/* 465 */           handler.handleText(buffer, current, tagEnd - current + 1, currentLine, currentCol);
/*     */           
/* 467 */           inCommentLine = false;
/*     */         }
/* 469 */         else if (inLiteral)
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/* 474 */           inLiteral = false;
/* 475 */           status.literalMarker = '\000';
/*     */         }
/*     */         else
/*     */         {
/* 479 */           throw new IllegalStateException("Illegal parsing state: structure is not of a recognized type");
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 484 */         ParsingLocatorUtil.countChar(locator, buffer[pos]);
/*     */         
/* 486 */         if (tagEnd == pos)
/*     */         {
/* 488 */           current = tagEnd + 1;
/* 489 */           currentLine = locator[0];
/* 490 */           currentCol = locator[1];
/*     */         }
/* 492 */         i = pos + 1;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 498 */     status.offset = current;
/* 499 */     status.line = currentLine;
/* 500 */     status.col = currentCol;
/* 501 */     status.inStructure = false;
/* 502 */     status.inCommentLine = false;
/* 503 */     status.literalMarker = '\000';
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final class BufferPool
/*     */   {
/*     */     private final char[][] pool;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private final boolean[] allocated;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private final int poolBufferSize;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private BufferPool(int poolSize, int poolBufferSize)
/*     */     {
/* 532 */       this.pool = new char[poolSize][];
/* 533 */       this.allocated = new boolean[poolSize];
/* 534 */       this.poolBufferSize = poolBufferSize;
/*     */       
/* 536 */       for (int i = 0; i < this.pool.length; i++) {
/* 537 */         this.pool[i] = new char[this.poolBufferSize];
/*     */       }
/* 539 */       Arrays.fill(this.allocated, false);
/*     */     }
/*     */     
/*     */     private synchronized char[] allocateBuffer(int bufferSize)
/*     */     {
/* 544 */       if (bufferSize != this.poolBufferSize)
/*     */       {
/*     */ 
/* 547 */         return new char[bufferSize];
/*     */       }
/* 549 */       for (int i = 0; i < this.pool.length; i++) {
/* 550 */         if (this.allocated[i] == 0) {
/* 551 */           this.allocated[i] = true;
/* 552 */           return this.pool[i];
/*     */         }
/*     */       }
/* 555 */       return new char[bufferSize];
/*     */     }
/*     */     
/*     */     private synchronized void releaseBuffer(char[] buffer) {
/* 559 */       if (buffer == null) {
/* 560 */         return;
/*     */       }
/* 562 */       if (buffer.length != this.poolBufferSize)
/*     */       {
/* 564 */         return;
/*     */       }
/* 566 */       for (int i = 0; i < this.pool.length; i++) {
/* 567 */         if (this.pool[i] == buffer)
/*     */         {
/* 569 */           this.allocated[i] = false;
/* 570 */           return;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\templateparser\text\TextParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */