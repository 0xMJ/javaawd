/*     */ package org.thymeleaf.templateparser.markup.decoupled;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.attoparser.AbstractMarkupHandler;
/*     */ import org.attoparser.ParseException;
/*     */ import org.thymeleaf.exceptions.TemplateInputException;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ import org.thymeleaf.util.StringUtils;
/*     */ import org.thymeleaf.util.TextUtils;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DecoupledTemplateLogicBuilderMarkupHandler
/*     */   extends AbstractMarkupHandler
/*     */ {
/*     */   public static final String TAG_NAME_LOGIC = "thlogic";
/*     */   public static final String TAG_NAME_ATTR = "attr";
/*     */   public static final String ATTRIBUTE_NAME_SEL = "sel";
/*  56 */   private static final char[] TAG_NAME_LOGIC_CHARS = "thlogic".toCharArray();
/*  57 */   private static final char[] TAG_NAME_ATTR_CHARS = "attr".toCharArray();
/*  58 */   private static final char[] ATTRIBUTE_NAME_SEL_CHARS = "sel".toCharArray();
/*     */   
/*     */   private final String templateName;
/*     */   
/*     */   private final TemplateMode templateMode;
/*     */   private final DecoupledTemplateLogic decoupledTemplateLogic;
/*  64 */   private boolean inLogicBody = false;
/*  65 */   private boolean inAttrTag = false;
/*  66 */   private Selector selector = new Selector();
/*  67 */   private List<DecoupledInjectedAttribute> currentInjectedAttributes = new ArrayList(8);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DecoupledTemplateLogicBuilderMarkupHandler(String templateName, TemplateMode templateMode)
/*     */   {
/*  76 */     Validate.notEmpty(templateName, "Template name cannot be null or empty");
/*  77 */     Validate.notNull(templateMode, "Template mode cannot be null");
/*     */     
/*  79 */     this.templateName = templateName;
/*  80 */     this.templateMode = templateMode;
/*  81 */     this.decoupledTemplateLogic = new DecoupledTemplateLogic();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public DecoupledTemplateLogic getDecoupledTemplateLogic()
/*     */   {
/*  88 */     return this.decoupledTemplateLogic;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleStandaloneElementStart(char[] buffer, int nameOffset, int nameLen, boolean minimized, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 100 */     if (!this.inLogicBody)
/*     */     {
/* 102 */       return;
/*     */     }
/*     */     
/* 105 */     if (!TextUtils.equals(this.templateMode.isCaseSensitive(), buffer, nameOffset, nameLen, TAG_NAME_ATTR_CHARS, 0, TAG_NAME_ATTR_CHARS.length))
/*     */     {
/* 107 */       return;
/*     */     }
/*     */     
/* 110 */     this.selector.increaseLevel();
/* 111 */     this.inAttrTag = true;
/* 112 */     this.currentInjectedAttributes.clear();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleStandaloneElementEnd(char[] buffer, int nameOffset, int nameLen, boolean minimized, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 123 */     if (!this.inLogicBody)
/*     */     {
/* 125 */       return;
/*     */     }
/*     */     
/* 128 */     if ((this.inAttrTag) && (this.selector.isLevelEmpty())) {
/* 129 */       throw new TemplateInputException("Error while processing decoupled logic file: <attr> injection tag does not contain any \"sel\" selector attributes.", this.templateName, line, col);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 136 */     String currentSelector = this.selector.getCurrentSelector();
/* 137 */     for (DecoupledInjectedAttribute injectedAttribute : this.currentInjectedAttributes) {
/* 138 */       this.decoupledTemplateLogic.addInjectedAttribute(currentSelector, injectedAttribute);
/*     */     }
/*     */     
/* 141 */     this.currentInjectedAttributes.clear();
/* 142 */     this.inAttrTag = false;
/* 143 */     this.selector.decreaseLevel();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleOpenElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 157 */     if (!this.inLogicBody) {
/* 158 */       if (TextUtils.equals(this.templateMode.isCaseSensitive(), buffer, nameOffset, nameLen, TAG_NAME_LOGIC_CHARS, 0, TAG_NAME_LOGIC_CHARS.length)) {
/* 159 */         this.inLogicBody = true;
/*     */       }
/* 161 */       return;
/*     */     }
/*     */     
/* 164 */     if (!TextUtils.equals(this.templateMode.isCaseSensitive(), buffer, nameOffset, nameLen, TAG_NAME_ATTR_CHARS, 0, TAG_NAME_ATTR_CHARS.length))
/*     */     {
/* 166 */       return;
/*     */     }
/*     */     
/* 169 */     this.selector.increaseLevel();
/* 170 */     this.inAttrTag = true;
/* 171 */     this.currentInjectedAttributes.clear();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleOpenElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 184 */     if (!this.inLogicBody)
/*     */     {
/* 186 */       return;
/*     */     }
/*     */     
/* 189 */     if ((this.inAttrTag) && (this.selector.isLevelEmpty())) {
/* 190 */       throw new TemplateInputException("Error while processing decoupled logic file: <attr> injection tag does not contain any \"sel\" selector attributes.", this.templateName, line, col);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 197 */     String currentSelector = this.selector.getCurrentSelector();
/* 198 */     for (DecoupledInjectedAttribute injectedAttribute : this.currentInjectedAttributes) {
/* 199 */       this.decoupledTemplateLogic.addInjectedAttribute(currentSelector, injectedAttribute);
/*     */     }
/*     */     
/* 202 */     this.currentInjectedAttributes.clear();
/* 203 */     this.inAttrTag = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleCloseElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 216 */     if (!this.inLogicBody)
/*     */     {
/* 218 */       return;
/*     */     }
/*     */     
/* 221 */     if (TextUtils.equals(this.templateMode.isCaseSensitive(), buffer, nameOffset, nameLen, TAG_NAME_LOGIC_CHARS, 0, TAG_NAME_LOGIC_CHARS.length)) {
/* 222 */       this.inLogicBody = false;
/* 223 */       return;
/*     */     }
/*     */     
/* 226 */     if (TextUtils.equals(this.templateMode.isCaseSensitive(), buffer, nameOffset, nameLen, TAG_NAME_ATTR_CHARS, 0, TAG_NAME_ATTR_CHARS.length)) {
/* 227 */       this.selector.decreaseLevel();
/* 228 */       return;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleAutoCloseElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 242 */     if (!this.inLogicBody)
/*     */     {
/* 244 */       return;
/*     */     }
/*     */     
/* 247 */     if (TextUtils.equals(this.templateMode.isCaseSensitive(), buffer, nameOffset, nameLen, TAG_NAME_LOGIC_CHARS, 0, TAG_NAME_LOGIC_CHARS.length)) {
/* 248 */       this.inLogicBody = false;
/* 249 */       return;
/*     */     }
/*     */     
/* 252 */     if (TextUtils.equals(this.templateMode.isCaseSensitive(), buffer, nameOffset, nameLen, TAG_NAME_ATTR_CHARS, 0, TAG_NAME_ATTR_CHARS.length)) {
/* 253 */       this.selector.decreaseLevel();
/* 254 */       return;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleAttribute(char[] buffer, int nameOffset, int nameLen, int nameLine, int nameCol, int operatorOffset, int operatorLen, int operatorLine, int operatorCol, int valueContentOffset, int valueContentLen, int valueOuterOffset, int valueOuterLen, int valueLine, int valueCol)
/*     */     throws ParseException
/*     */   {
/* 274 */     if (!this.inAttrTag)
/*     */     {
/* 276 */       return;
/*     */     }
/*     */     
/*     */ 
/* 280 */     if (TextUtils.equals(this.templateMode.isCaseSensitive(), buffer, nameOffset, nameLen, ATTRIBUTE_NAME_SEL_CHARS, 0, ATTRIBUTE_NAME_SEL_CHARS.length))
/*     */     {
/* 282 */       if (!this.selector.isLevelEmpty()) {
/* 283 */         throw new TemplateInputException("Error while processing decoupled logic file: selector (\"sel\") attribute found more than once in attr injection tag", this.templateName, nameLine, nameCol);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 288 */       this.selector.setSelector(new String(buffer, valueContentOffset, valueContentLen));
/* 289 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 300 */     DecoupledInjectedAttribute injectedAttribute = DecoupledInjectedAttribute.createAttribute(buffer, nameOffset, nameLen, operatorOffset, operatorLen, valueContentOffset, valueContentLen, valueOuterOffset, valueOuterLen);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 306 */     this.currentInjectedAttributes.add(injectedAttribute);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final class Selector
/*     */   {
/* 315 */     private int level = -1;
/* 316 */     private List<String> selectorLevels = new ArrayList(5);
/* 317 */     private String currentSelector = null;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     void increaseLevel()
/*     */     {
/* 324 */       this.level += 1;
/*     */     }
/*     */     
/*     */     void decreaseLevel() {
/* 328 */       if (this.level < 0) {
/* 329 */         throw new IndexOutOfBoundsException("Cannot decrease level when the selector is clean");
/*     */       }
/* 331 */       if (this.selectorLevels.size() > this.level) {
/* 332 */         this.selectorLevels.remove(this.level);
/*     */       }
/* 334 */       this.level -= 1;
/*     */     }
/*     */     
/*     */     void setSelector(String selector) {
/* 338 */       this.selectorLevels.add("//" + selector);
/* 339 */       this.currentSelector = null;
/*     */     }
/*     */     
/*     */     boolean isLevelEmpty() {
/* 343 */       return this.selectorLevels.size() <= this.level;
/*     */     }
/*     */     
/*     */     String getCurrentSelector() {
/* 347 */       if (this.currentSelector == null) {
/* 348 */         this.currentSelector = StringUtils.join(this.selectorLevels, "");
/*     */       }
/* 350 */       return this.currentSelector;
/*     */     }
/*     */     
/*     */ 
/*     */     public String toString()
/*     */     {
/* 356 */       return "[" + this.level + "]" + this.selectorLevels.toString();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\templateparser\markup\decoupled\DecoupledTemplateLogicBuilderMarkupHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */