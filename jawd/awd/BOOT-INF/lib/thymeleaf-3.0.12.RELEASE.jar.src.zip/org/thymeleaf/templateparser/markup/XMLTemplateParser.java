/*    */ package org.thymeleaf.templateparser.markup;
/*    */ 
/*    */ import org.attoparser.config.ParseConfiguration;
/*    */ import org.attoparser.config.ParseConfiguration.ElementBalancing;
/*    */ import org.attoparser.config.ParseConfiguration.PrologParseConfiguration;
/*    */ import org.attoparser.config.ParseConfiguration.PrologPresence;
/*    */ import org.attoparser.config.ParseConfiguration.UniqueRootElementPresence;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class XMLTemplateParser
/*    */   extends AbstractMarkupTemplateParser
/*    */ {
/* 43 */   static final ParseConfiguration MARKUP_PARSING_CONFIGURATION = ;
/* 44 */   static { MARKUP_PARSING_CONFIGURATION.setElementBalancing(ParseConfiguration.ElementBalancing.REQUIRE_BALANCED);
/* 45 */     MARKUP_PARSING_CONFIGURATION.setCaseSensitive(true);
/* 46 */     MARKUP_PARSING_CONFIGURATION.setNoUnmatchedCloseElementsRequired(true);
/* 47 */     MARKUP_PARSING_CONFIGURATION.setUniqueAttributesInElementRequired(true);
/* 48 */     MARKUP_PARSING_CONFIGURATION.setXmlWellFormedAttributeValuesRequired(true);
/* 49 */     MARKUP_PARSING_CONFIGURATION.setUniqueRootElementPresence(ParseConfiguration.UniqueRootElementPresence.NOT_VALIDATED);
/* 50 */     MARKUP_PARSING_CONFIGURATION.getPrologParseConfiguration().setDoctypePresence(ParseConfiguration.PrologPresence.ALLOWED);
/* 51 */     MARKUP_PARSING_CONFIGURATION.getPrologParseConfiguration().setRequireDoctypeKeywordsUpperCase(false);
/* 52 */     MARKUP_PARSING_CONFIGURATION.getPrologParseConfiguration().setValidateProlog(false);
/* 53 */     MARKUP_PARSING_CONFIGURATION.getPrologParseConfiguration().setXmlDeclarationPresence(ParseConfiguration.PrologPresence.ALLOWED);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public XMLTemplateParser(int bufferPoolSize, int bufferSize)
/*    */   {
/* 60 */     super(MARKUP_PARSING_CONFIGURATION, bufferPoolSize, bufferSize);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\templateparser\markup\XMLTemplateParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */