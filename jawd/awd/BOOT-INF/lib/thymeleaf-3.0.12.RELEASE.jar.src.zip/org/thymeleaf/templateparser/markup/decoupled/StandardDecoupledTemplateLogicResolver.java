/*     */ package org.thymeleaf.templateparser.markup.decoupled;
/*     */ 
/*     */ import java.util.Set;
/*     */ import org.thymeleaf.IEngineConfiguration;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ import org.thymeleaf.templateresource.ITemplateResource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class StandardDecoupledTemplateLogicResolver
/*     */   implements IDecoupledTemplateLogicResolver
/*     */ {
/*     */   public static final String DECOUPLED_TEMPLATE_LOGIC_FILE_SUFFIX = ".th.xml";
/*  67 */   private String prefix = null;
/*  68 */   private String suffix = ".th.xml";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getSuffix()
/*     */   {
/*  81 */     return this.suffix;
/*     */   }
/*     */   
/*     */   public void setSuffix(String suffix) {
/*  85 */     this.suffix = suffix;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getPrefix()
/*     */   {
/*  92 */     return this.prefix;
/*     */   }
/*     */   
/*     */   public void setPrefix(String prefix) {
/*  96 */     this.prefix = prefix;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ITemplateResource resolveDecoupledTemplateLogic(IEngineConfiguration configuration, String ownerTemplate, String template, Set<String> templateSelectors, ITemplateResource resource, TemplateMode templateMode)
/*     */   {
/* 107 */     String relativeLocation = resource.getBaseName();
/* 108 */     if (this.prefix != null) {
/* 109 */       relativeLocation = this.prefix + relativeLocation;
/*     */     }
/* 111 */     if (this.suffix != null) {
/* 112 */       relativeLocation = relativeLocation + this.suffix;
/*     */     }
/*     */     
/* 115 */     return resource.relative(relativeLocation);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\templateparser\markup\decoupled\StandardDecoupledTemplateLogicResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */