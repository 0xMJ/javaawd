/*     */ package org.thymeleaf.templateparser.markup;
/*     */ 
/*     */ import org.attoparser.AbstractChainedMarkupHandler;
/*     */ import org.attoparser.IMarkupHandler;
/*     */ import org.attoparser.ParseException;
/*     */ import org.thymeleaf.IEngineConfiguration;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.standard.inline.IInlinePreProcessorHandler;
/*     */ import org.thymeleaf.standard.inline.OutputExpressionInlinePreProcessorHandler;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class InlinedOutputExpressionMarkupHandler
/*     */   extends AbstractChainedMarkupHandler
/*     */ {
/*     */   private final OutputExpressionInlinePreProcessorHandler inlineHandler;
/*     */   
/*     */   InlinedOutputExpressionMarkupHandler(IEngineConfiguration configuration, TemplateMode templateMode, String standardDialectPrefix, IMarkupHandler handler)
/*     */   {
/*  60 */     super(handler);
/*     */     
/*  62 */     this.inlineHandler = new OutputExpressionInlinePreProcessorHandler(configuration, templateMode, standardDialectPrefix, new InlineMarkupAdapterPreProcessorHandler(handler));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleText(char[] buffer, int offset, int len, int line, int col)
/*     */     throws ParseException
/*     */   {
/*  80 */     this.inlineHandler.handleText(buffer, offset, len, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleStandaloneElementStart(char[] buffer, int nameOffset, int nameLen, boolean minimized, int line, int col)
/*     */     throws ParseException
/*     */   {
/*  93 */     this.inlineHandler.handleStandaloneElementStart(buffer, nameOffset, nameLen, minimized, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleStandaloneElementEnd(char[] buffer, int nameOffset, int nameLen, boolean minimized, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 104 */     this.inlineHandler.handleStandaloneElementEnd(buffer, nameOffset, nameLen, minimized, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleOpenElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 114 */     this.inlineHandler.handleOpenElementStart(buffer, nameOffset, nameLen, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleOpenElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 124 */     this.inlineHandler.handleOpenElementEnd(buffer, nameOffset, nameLen, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleAutoOpenElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 134 */     this.inlineHandler.handleAutoOpenElementStart(buffer, nameOffset, nameLen, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleAutoOpenElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 144 */     this.inlineHandler.handleAutoOpenElementEnd(buffer, nameOffset, nameLen, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleCloseElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 154 */     this.inlineHandler.handleCloseElementStart(buffer, nameOffset, nameLen, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleCloseElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 164 */     this.inlineHandler.handleCloseElementEnd(buffer, nameOffset, nameLen, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleAutoCloseElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 174 */     this.inlineHandler.handleAutoCloseElementStart(buffer, nameOffset, nameLen, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleAutoCloseElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 184 */     this.inlineHandler.handleAutoCloseElementEnd(buffer, nameOffset, nameLen, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleAttribute(char[] buffer, int nameOffset, int nameLen, int nameLine, int nameCol, int operatorOffset, int operatorLen, int operatorLine, int operatorCol, int valueContentOffset, int valueContentLen, int valueOuterOffset, int valueOuterLen, int valueLine, int valueCol)
/*     */     throws ParseException
/*     */   {
/* 205 */     this.inlineHandler.handleAttribute(buffer, nameOffset, nameLen, nameLine, nameCol, operatorOffset, operatorLen, operatorLine, operatorCol, valueContentOffset, valueContentLen, valueOuterOffset, valueOuterLen, valueLine, valueCol);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final class InlineMarkupAdapterPreProcessorHandler
/*     */     implements IInlinePreProcessorHandler
/*     */   {
/*     */     private IMarkupHandler handler;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     InlineMarkupAdapterPreProcessorHandler(IMarkupHandler handler)
/*     */     {
/* 223 */       this.handler = handler;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public void handleText(char[] buffer, int offset, int len, int line, int col)
/*     */     {
/*     */       try
/*     */       {
/* 232 */         this.handler.handleText(buffer, offset, len, line, col);
/*     */       } catch (ParseException e) {
/* 234 */         throw new TemplateProcessingException("Parse exception during processing of inlining", e);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public void handleStandaloneElementStart(char[] buffer, int nameOffset, int nameLen, boolean minimized, int line, int col)
/*     */     {
/*     */       try
/*     */       {
/* 244 */         this.handler.handleStandaloneElementStart(buffer, nameOffset, nameLen, minimized, line, col);
/*     */       } catch (ParseException e) {
/* 246 */         throw new TemplateProcessingException("Parse exception during processing of inlining", e);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public void handleStandaloneElementEnd(char[] buffer, int nameOffset, int nameLen, boolean minimized, int line, int col)
/*     */     {
/*     */       try
/*     */       {
/* 256 */         this.handler.handleStandaloneElementEnd(buffer, nameOffset, nameLen, minimized, line, col);
/*     */       } catch (ParseException e) {
/* 258 */         throw new TemplateProcessingException("Parse exception during processing of inlining", e);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */     public void handleOpenElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     {
/*     */       try
/*     */       {
/* 267 */         this.handler.handleOpenElementStart(buffer, nameOffset, nameLen, line, col);
/*     */       } catch (ParseException e) {
/* 269 */         throw new TemplateProcessingException("Parse exception during processing of inlining", e);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */     public void handleOpenElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     {
/*     */       try
/*     */       {
/* 278 */         this.handler.handleOpenElementEnd(buffer, nameOffset, nameLen, line, col);
/*     */       } catch (ParseException e) {
/* 280 */         throw new TemplateProcessingException("Parse exception during processing of inlining", e);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */     public void handleAutoOpenElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     {
/*     */       try
/*     */       {
/* 289 */         this.handler.handleAutoOpenElementStart(buffer, nameOffset, nameLen, line, col);
/*     */       } catch (ParseException e) {
/* 291 */         throw new TemplateProcessingException("Parse exception during processing of inlining", e);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */     public void handleAutoOpenElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     {
/*     */       try
/*     */       {
/* 300 */         this.handler.handleAutoOpenElementEnd(buffer, nameOffset, nameLen, line, col);
/*     */       } catch (ParseException e) {
/* 302 */         throw new TemplateProcessingException("Parse exception during processing of inlining", e);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */     public void handleCloseElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     {
/*     */       try
/*     */       {
/* 311 */         this.handler.handleCloseElementStart(buffer, nameOffset, nameLen, line, col);
/*     */       } catch (ParseException e) {
/* 313 */         throw new TemplateProcessingException("Parse exception during processing of inlining", e);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */     public void handleCloseElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     {
/*     */       try
/*     */       {
/* 322 */         this.handler.handleCloseElementEnd(buffer, nameOffset, nameLen, line, col);
/*     */       } catch (ParseException e) {
/* 324 */         throw new TemplateProcessingException("Parse exception during processing of inlining", e);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */     public void handleAutoCloseElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     {
/*     */       try
/*     */       {
/* 333 */         this.handler.handleAutoCloseElementStart(buffer, nameOffset, nameLen, line, col);
/*     */       } catch (ParseException e) {
/* 335 */         throw new TemplateProcessingException("Parse exception during processing of inlining", e);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */     public void handleAutoCloseElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     {
/*     */       try
/*     */       {
/* 344 */         this.handler.handleAutoCloseElementEnd(buffer, nameOffset, nameLen, line, col);
/*     */       } catch (ParseException e) {
/* 346 */         throw new TemplateProcessingException("Parse exception during processing of inlining", e);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void handleAttribute(char[] buffer, int nameOffset, int nameLen, int nameLine, int nameCol, int operatorOffset, int operatorLen, int operatorLine, int operatorCol, int valueContentOffset, int valueContentLen, int valueOuterOffset, int valueOuterLen, int valueLine, int valueCol)
/*     */     {
/*     */       try
/*     */       {
/* 360 */         this.handler.handleAttribute(buffer, nameOffset, nameLen, nameLine, nameCol, operatorOffset, operatorLen, operatorLine, operatorCol, valueContentOffset, valueContentLen, valueOuterOffset, valueOuterLen, valueLine, valueCol);
/*     */ 
/*     */       }
/*     */       catch (ParseException e)
/*     */       {
/*     */ 
/* 366 */         throw new TemplateProcessingException("Parse exception during processing of inlining", e);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\templateparser\markup\InlinedOutputExpressionMarkupHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */