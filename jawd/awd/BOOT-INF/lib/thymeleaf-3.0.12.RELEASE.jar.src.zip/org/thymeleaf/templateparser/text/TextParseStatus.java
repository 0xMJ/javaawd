package org.thymeleaf.templateparser.text;

final class TextParseStatus
{
  int offset;
  int line;
  int col;
  boolean inStructure;
  boolean inCommentLine;
  char literalMarker;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\templateparser\text\TextParseStatus.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */