/*     */ package org.thymeleaf.templateparser.markup;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ import java.util.Set;
/*     */ import org.attoparser.IMarkupHandler;
/*     */ import org.attoparser.IMarkupParser;
/*     */ import org.attoparser.MarkupParser;
/*     */ import org.attoparser.ParseException;
/*     */ import org.attoparser.config.ParseConfiguration;
/*     */ import org.attoparser.config.ParseConfiguration.ParsingMode;
/*     */ import org.attoparser.select.BlockSelectorMarkupHandler;
/*     */ import org.attoparser.select.NodeSelectorMarkupHandler;
/*     */ import org.thymeleaf.EngineConfiguration;
/*     */ import org.thymeleaf.IEngineConfiguration;
/*     */ import org.thymeleaf.engine.ITemplateHandler;
/*     */ import org.thymeleaf.engine.TemplateHandlerAdapterMarkupHandler;
/*     */ import org.thymeleaf.exceptions.TemplateInputException;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ import org.thymeleaf.templateparser.ITemplateParser;
/*     */ import org.thymeleaf.templateparser.markup.decoupled.DecoupledTemplateLogic;
/*     */ import org.thymeleaf.templateparser.markup.decoupled.DecoupledTemplateLogicMarkupHandler;
/*     */ import org.thymeleaf.templateparser.markup.decoupled.DecoupledTemplateLogicUtils;
/*     */ import org.thymeleaf.templateparser.reader.ParserLevelCommentMarkupReader;
/*     */ import org.thymeleaf.templateparser.reader.PrototypeOnlyCommentMarkupReader;
/*     */ import org.thymeleaf.templateresource.ITemplateResource;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractMarkupTemplateParser
/*     */   implements ITemplateParser
/*     */ {
/*     */   private final IMarkupParser parser;
/*     */   private final boolean html;
/*     */   
/*     */   protected AbstractMarkupTemplateParser(ParseConfiguration parseConfiguration, int bufferPoolSize, int bufferSize)
/*     */   {
/*  65 */     Validate.notNull(parseConfiguration, "Parse configuration cannot be null");
/*  66 */     this.parser = new MarkupParser(parseConfiguration, bufferPoolSize, bufferSize);
/*  67 */     this.html = parseConfiguration.getMode().equals(ParseConfiguration.ParsingMode.HTML);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void parseStandalone(IEngineConfiguration configuration, String ownerTemplate, String template, Set<String> templateSelectors, ITemplateResource resource, TemplateMode templateMode, boolean useDecoupledLogic, ITemplateHandler handler)
/*     */   {
/*  91 */     Validate.notNull(configuration, "Engine Configuration cannot be null");
/*     */     
/*  93 */     Validate.notNull(template, "Template cannot be null");
/*  94 */     Validate.notNull(resource, "Template Resource cannot be null");
/*     */     
/*  96 */     Validate.notNull(templateMode, "Template Mode cannot be null");
/*  97 */     Validate.isTrue(templateMode.isMarkup(), "Template Mode has to be a markup template mode");
/*  98 */     Validate.notNull(handler, "Template Handler cannot be null");
/*     */     
/* 100 */     parse(configuration, ownerTemplate, template, templateSelectors, resource, 0, 0, templateMode, useDecoupledLogic, handler);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void parseString(IEngineConfiguration configuration, String ownerTemplate, String template, int lineOffset, int colOffset, TemplateMode templateMode, ITemplateHandler handler)
/*     */   {
/* 113 */     Validate.notNull(configuration, "Engine Configuration cannot be null");
/* 114 */     Validate.notNull(ownerTemplate, "Owner template cannot be null");
/* 115 */     Validate.notNull(template, "Template cannot be null");
/*     */     
/* 117 */     Validate.notNull(templateMode, "Template mode cannot be null");
/* 118 */     Validate.isTrue(templateMode.isMarkup(), "Template Mode has to be a markup template mode");
/* 119 */     Validate.notNull(handler, "Template Handler cannot be null");
/*     */     
/* 121 */     parse(configuration, ownerTemplate, template, null, null, lineOffset, colOffset, templateMode, false, handler);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void parse(IEngineConfiguration configuration, String ownerTemplate, String template, Set<String> templateSelectors, ITemplateResource resource, int lineOffset, int colOffset, TemplateMode templateMode, boolean useDecoupledLogic, ITemplateHandler templateHandler)
/*     */   {
/* 136 */     if (templateMode == TemplateMode.HTML) {
/* 137 */       Validate.isTrue(this.html, "Parser is configured as XML, but HTML-mode template parsing is being requested");
/* 138 */     } else if (templateMode == TemplateMode.XML) {
/* 139 */       Validate.isTrue(!this.html, "Parser is configured as HTML, but XML-mode template parsing is being requested");
/*     */     }
/*     */     else {
/* 142 */       throw new IllegalArgumentException("Parser is configured as " + (this.html ? "HTML" : "XML") + " but an unsupported template mode has been specified: " + templateMode);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 147 */     String templateName = resource != null ? template : ownerTemplate;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 156 */       DecoupledTemplateLogic decoupledTemplateLogic = (useDecoupledLogic) && (resource != null) ? DecoupledTemplateLogicUtils.computeDecoupledTemplateLogic(configuration, ownerTemplate, template, templateSelectors, resource, templateMode, this.parser) : null;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 165 */       IMarkupHandler handler = new TemplateHandlerAdapterMarkupHandler(templateName, templateHandler, configuration.getElementDefinitions(), configuration.getAttributeDefinitions(), templateMode, lineOffset, colOffset);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 172 */       if (((configuration instanceof EngineConfiguration)) && (((EngineConfiguration)configuration).isModelReshapeable(templateMode)))
/*     */       {
/*     */ 
/*     */ 
/* 176 */         handler = new InlinedOutputExpressionMarkupHandler(configuration, templateMode, configuration.getStandardDialectPrefix(), handler);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 182 */       boolean injectAttributes = (decoupledTemplateLogic != null) && (decoupledTemplateLogic.hasInjectedAttributes());
/* 183 */       boolean selectBlock = (templateSelectors != null) && (!templateSelectors.isEmpty());
/*     */       
/*     */       TemplateFragmentMarkupReferenceResolver referenceResolver;
/*     */       
/*     */       TemplateFragmentMarkupReferenceResolver referenceResolver;
/*     */       
/* 189 */       if ((injectAttributes) || (selectBlock)) {
/* 190 */         String standardDialectPrefix = configuration.getStandardDialectPrefix();
/*     */         
/*     */ 
/* 193 */         referenceResolver = standardDialectPrefix != null ? TemplateFragmentMarkupReferenceResolver.forPrefix(this.html, standardDialectPrefix) : null;
/*     */       } else {
/* 195 */         referenceResolver = null;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 202 */       if (selectBlock) {
/* 203 */         handler = new BlockSelectorMarkupHandler(handler, (String[])templateSelectors.toArray(new String[templateSelectors.size()]), referenceResolver);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 210 */       if (injectAttributes)
/*     */       {
/*     */ 
/* 213 */         handler = new DecoupledTemplateLogicMarkupHandler(decoupledTemplateLogic, handler);
/*     */         
/*     */ 
/*     */ 
/* 217 */         Set<String> nodeSelectors = decoupledTemplateLogic.getAllInjectedAttributeSelectors();
/* 218 */         handler = new NodeSelectorMarkupHandler(handler, handler, (String[])nodeSelectors.toArray(new String[nodeSelectors.size()]), referenceResolver);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 223 */       Reader templateReader = resource != null ? resource.reader() : new StringReader(template);
/*     */       
/*     */ 
/*     */ 
/* 227 */       templateReader = new ParserLevelCommentMarkupReader(new PrototypeOnlyCommentMarkupReader(templateReader));
/*     */       
/*     */ 
/* 230 */       this.parser.parse(templateReader, handler);
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 234 */       String message = "An error happened during template parsing";
/* 235 */       throw new TemplateInputException("An error happened during template parsing", resource != null ? resource.getDescription() : template, e);
/*     */     } catch (ParseException e) {
/* 237 */       String message = "An error happened during template parsing";
/* 238 */       if ((e.getLine() != null) && (e.getCol() != null)) {
/* 239 */         throw new TemplateInputException("An error happened during template parsing", resource != null ? resource.getDescription() : template, e.getLine().intValue(), e.getCol().intValue(), e);
/*     */       }
/* 241 */       throw new TemplateInputException("An error happened during template parsing", resource != null ? resource.getDescription() : template, e);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\templateparser\markup\AbstractMarkupTemplateParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */