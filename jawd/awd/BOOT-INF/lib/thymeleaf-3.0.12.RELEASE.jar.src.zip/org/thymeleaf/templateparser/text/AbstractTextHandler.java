package org.thymeleaf.templateparser.text;

public abstract class AbstractTextHandler
  implements ITextHandler
{
  public void handleDocumentStart(long startTimeNanos, int line, int col)
    throws TextParseException
  {}
  
  public void handleDocumentEnd(long endTimeNanos, long totalTimeNanos, int line, int col)
    throws TextParseException
  {}
  
  public void handleText(char[] buffer, int offset, int len, int line, int col)
    throws TextParseException
  {}
  
  public void handleComment(char[] buffer, int contentOffset, int contentLen, int outerOffset, int outerLen, int line, int col)
    throws TextParseException
  {}
  
  public void handleStandaloneElementStart(char[] buffer, int nameOffset, int nameLen, boolean minimized, int line, int col)
    throws TextParseException
  {}
  
  public void handleStandaloneElementEnd(char[] buffer, int nameOffset, int nameLen, boolean minimized, int line, int col)
    throws TextParseException
  {}
  
  public void handleOpenElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
    throws TextParseException
  {}
  
  public void handleOpenElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
    throws TextParseException
  {}
  
  public void handleCloseElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
    throws TextParseException
  {}
  
  public void handleCloseElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
    throws TextParseException
  {}
  
  public void handleAttribute(char[] buffer, int nameOffset, int nameLen, int nameLine, int nameCol, int operatorOffset, int operatorLen, int operatorLine, int operatorCol, int valueContentOffset, int valueContentLen, int valueOuterOffset, int valueOuterLen, int valueLine, int valueCol)
    throws TextParseException
  {}
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\templateparser\text\AbstractTextHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */