package org.thymeleaf.templateparser;

import java.util.Set;
import org.thymeleaf.IEngineConfiguration;
import org.thymeleaf.engine.ITemplateHandler;
import org.thymeleaf.templatemode.TemplateMode;
import org.thymeleaf.templateresource.ITemplateResource;

public abstract interface ITemplateParser
{
  public abstract void parseStandalone(IEngineConfiguration paramIEngineConfiguration, String paramString1, String paramString2, Set<String> paramSet, ITemplateResource paramITemplateResource, TemplateMode paramTemplateMode, boolean paramBoolean, ITemplateHandler paramITemplateHandler);
  
  public abstract void parseString(IEngineConfiguration paramIEngineConfiguration, String paramString1, String paramString2, int paramInt1, int paramInt2, TemplateMode paramTemplateMode, ITemplateHandler paramITemplateHandler);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\templateparser\ITemplateParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */