/*     */ package org.thymeleaf.templateparser.raw;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ import java.util.Set;
/*     */ import org.thymeleaf.IEngineConfiguration;
/*     */ import org.thymeleaf.engine.ITemplateHandler;
/*     */ import org.thymeleaf.engine.TemplateHandlerAdapterRawHandler;
/*     */ import org.thymeleaf.exceptions.TemplateInputException;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ import org.thymeleaf.templateparser.ITemplateParser;
/*     */ import org.thymeleaf.templateresource.ITemplateResource;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RawTemplateParser
/*     */   implements ITemplateParser
/*     */ {
/*     */   private final RawParser parser;
/*     */   
/*     */   public RawTemplateParser(int bufferPoolSize, int bufferSize)
/*     */   {
/*  51 */     this.parser = new RawParser(bufferPoolSize, bufferSize);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void parseStandalone(IEngineConfiguration configuration, String ownerTemplate, String template, Set<String> templateSelectors, ITemplateResource resource, TemplateMode templateMode, boolean useDecoupledLogic, ITemplateHandler handler)
/*     */   {
/*  75 */     Validate.notNull(configuration, "Engine Configuration cannot be null");
/*     */     
/*  77 */     Validate.notNull(template, "Template cannot be null");
/*  78 */     Validate.notNull(resource, "Template Resource cannot be null");
/*  79 */     Validate.isTrue((templateSelectors == null) || (templateSelectors.isEmpty()), "Template selectors cannot be specified for a template using RAW template mode: template insertion operations must be always performed on whole template files, not fragments");
/*     */     
/*     */ 
/*  82 */     Validate.notNull(templateMode, "Template Mode cannot be null");
/*  83 */     Validate.isTrue(templateMode == TemplateMode.RAW, "Template Mode has to be RAW");
/*  84 */     Validate.isTrue(!useDecoupledLogic, "Cannot use decoupled logic in template mode " + templateMode);
/*  85 */     Validate.notNull(handler, "Template Handler cannot be null");
/*     */     
/*  87 */     parse(configuration, ownerTemplate, template, templateSelectors, resource, 0, 0, templateMode, handler);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void parseString(IEngineConfiguration configuration, String ownerTemplate, String template, int lineOffset, int colOffset, TemplateMode templateMode, ITemplateHandler handler)
/*     */   {
/* 100 */     Validate.notNull(configuration, "Engine Configuration cannot be null");
/* 101 */     Validate.notNull(ownerTemplate, "Owner template cannot be null");
/* 102 */     Validate.notNull(template, "Template cannot be null");
/*     */     
/* 104 */     Validate.notNull(templateMode, "Template mode cannot be null");
/* 105 */     Validate.isTrue(templateMode == TemplateMode.RAW, "Template Mode has to be RAW");
/* 106 */     Validate.notNull(handler, "Template Handler cannot be null");
/*     */     
/* 108 */     parse(configuration, ownerTemplate, template, null, null, lineOffset, colOffset, templateMode, handler);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void parse(IEngineConfiguration configuration, String ownerTemplate, String template, Set<String> templateSelectors, ITemplateResource resource, int lineOffset, int colOffset, TemplateMode templateMode, ITemplateHandler templateHandler)
/*     */   {
/* 124 */     String templateName = resource != null ? template : ownerTemplate;
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 129 */       IRawHandler handler = new TemplateHandlerAdapterRawHandler(templateName, templateHandler, lineOffset, colOffset);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 136 */       Reader templateReader = resource != null ? resource.reader() : new StringReader(template);
/*     */       
/* 138 */       this.parser.parse(templateReader, handler);
/*     */     }
/*     */     catch (IOException e) {
/* 141 */       String message = "An error happened during template parsing";
/* 142 */       throw new TemplateInputException("An error happened during template parsing", resource != null ? resource.getDescription() : template, e);
/*     */     } catch (RawParseException e) {
/* 144 */       String message = "An error happened during template parsing";
/* 145 */       if ((e.getLine() != null) && (e.getCol() != null)) {
/* 146 */         throw new TemplateInputException("An error happened during template parsing", resource != null ? resource.getDescription() : template, e.getLine().intValue(), e.getCol().intValue(), e);
/*     */       }
/* 148 */       throw new TemplateInputException("An error happened during template parsing", resource != null ? resource.getDescription() : template, e);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\templateparser\raw\RawTemplateParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */