/*     */ package org.thymeleaf.templateparser.markup;
/*     */ 
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.attoparser.select.IMarkupSelectorReferenceResolver;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class TemplateFragmentMarkupReferenceResolver
/*     */   implements IMarkupSelectorReferenceResolver
/*     */ {
/*  51 */   private final ConcurrentHashMap<String, String> selectorsByReference = new ConcurrentHashMap(20);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  58 */   private static final TemplateFragmentMarkupReferenceResolver HTML_INSTANCE_NO_PREFIX = new TemplateFragmentMarkupReferenceResolver(true, null);
/*  59 */   private static final TemplateFragmentMarkupReferenceResolver XML_INSTANCE_NO_PREFIX = new TemplateFragmentMarkupReferenceResolver(false, null);
/*  60 */   private static final ConcurrentHashMap<String, TemplateFragmentMarkupReferenceResolver> HTML_INSTANCES_BY_PREFIX = new ConcurrentHashMap(3, 0.9F, 2);
/*  61 */   private static final ConcurrentHashMap<String, TemplateFragmentMarkupReferenceResolver> XML_INSTANCES_BY_PREFIX = new ConcurrentHashMap(3, 0.9F, 2);
/*     */   private static final String HTML_FORMAT_WITHOUT_PREFIX = "/[ref='%1$s' or data-ref='%1$s' or fragment='%1$s' or data-fragment='%1$s' or fragment^='%1$s(' or data-fragment^='%1$s(' or fragment^='%1$s (' or data-fragment^='%1$s (']";
/*     */   private static final String HTML_FORMAT_WITH_PREFIX = "/[%1$s:ref='%%1$s' or data-%1$s-ref='%%1$s' or %1$s:fragment='%%1$s' or data-%1$s-fragment='%%1$s' or %1$s:fragment^='%%1$s(' or data-%1$s-fragment^='%%1$s(' or %1$s:fragment^='%%1$s (' or data-%1$s-fragment^='%%1$s (']";
/*     */   
/*     */   static TemplateFragmentMarkupReferenceResolver forPrefix(boolean html, String standardDialectPrefix)
/*     */   {
/*  67 */     return html ? forHTMLPrefix(standardDialectPrefix) : forXMLPrefix(standardDialectPrefix);
/*     */   }
/*     */   
/*     */   private static TemplateFragmentMarkupReferenceResolver forHTMLPrefix(String standardDialectPrefix)
/*     */   {
/*  72 */     if ((standardDialectPrefix == null) || (standardDialectPrefix.length() == 0)) {
/*  73 */       return HTML_INSTANCE_NO_PREFIX;
/*     */     }
/*  75 */     String prefix = standardDialectPrefix.toLowerCase();
/*  76 */     TemplateFragmentMarkupReferenceResolver resolver = (TemplateFragmentMarkupReferenceResolver)HTML_INSTANCES_BY_PREFIX.get(prefix);
/*  77 */     if (resolver != null) {
/*  78 */       return resolver;
/*     */     }
/*  80 */     TemplateFragmentMarkupReferenceResolver newResolver = new TemplateFragmentMarkupReferenceResolver(true, prefix);
/*     */     
/*  82 */     HTML_INSTANCES_BY_PREFIX.putIfAbsent(prefix, newResolver);
/*  83 */     return (TemplateFragmentMarkupReferenceResolver)HTML_INSTANCES_BY_PREFIX.get(prefix);
/*     */   }
/*     */   
/*     */   private static TemplateFragmentMarkupReferenceResolver forXMLPrefix(String standardDialectPrefix)
/*     */   {
/*  88 */     if ((standardDialectPrefix == null) || (standardDialectPrefix.length() == 0)) {
/*  89 */       return XML_INSTANCE_NO_PREFIX;
/*     */     }
/*  91 */     TemplateFragmentMarkupReferenceResolver resolver = (TemplateFragmentMarkupReferenceResolver)XML_INSTANCES_BY_PREFIX.get(standardDialectPrefix);
/*  92 */     if (resolver != null) {
/*  93 */       return resolver;
/*     */     }
/*  95 */     TemplateFragmentMarkupReferenceResolver newResolver = new TemplateFragmentMarkupReferenceResolver(false, standardDialectPrefix);
/*     */     
/*  97 */     XML_INSTANCES_BY_PREFIX.putIfAbsent(standardDialectPrefix, newResolver);
/*  98 */     return (TemplateFragmentMarkupReferenceResolver)XML_INSTANCES_BY_PREFIX.get(standardDialectPrefix);
/*     */   }
/*     */   
/*     */   private static final String XML_FORMAT_WITHOUT_PREFIX = "/[ref='%1$s' or fragment='%1$s' or fragment^='%1$s(' or fragment^='%1$s (']";
/*     */   private static final String XML_FORMAT_WITH_PREFIX = "/[%1$s:ref='%%1$s' or %1$s:fragment='%%1$s' or %1$s:fragment^='%%1$s(' or %1$s:fragment^='%%1$s (']";
/*     */   private final String resolverFormat;
/*     */   private TemplateFragmentMarkupReferenceResolver(boolean html, String standardDialectPrefix) {
/* 105 */     if (standardDialectPrefix == null) {
/* 106 */       this.resolverFormat = (html ? "/[ref='%1$s' or data-ref='%1$s' or fragment='%1$s' or data-fragment='%1$s' or fragment^='%1$s(' or data-fragment^='%1$s(' or fragment^='%1$s (' or data-fragment^='%1$s (']" : "/[ref='%1$s' or fragment='%1$s' or fragment^='%1$s(' or fragment^='%1$s (']");
/*     */     }
/*     */     else
/*     */     {
/* 110 */       this.resolverFormat = (html ? String.format("/[%1$s:ref='%%1$s' or data-%1$s-ref='%%1$s' or %1$s:fragment='%%1$s' or data-%1$s-fragment='%%1$s' or %1$s:fragment^='%%1$s(' or data-%1$s-fragment^='%%1$s(' or %1$s:fragment^='%%1$s (' or data-%1$s-fragment^='%%1$s (']", new Object[] { standardDialectPrefix }) : String.format("/[%1$s:ref='%%1$s' or %1$s:fragment='%%1$s' or %1$s:fragment^='%%1$s(' or %1$s:fragment^='%%1$s (']", new Object[] { standardDialectPrefix }));
/*     */     }
/*     */   }
/*     */   
/*     */   public String resolveSelectorFromReference(String reference)
/*     */   {
/* 116 */     Validate.notNull(reference, "Reference cannot be null");
/* 117 */     String selector = (String)this.selectorsByReference.get(reference);
/* 118 */     if (selector != null) {
/* 119 */       return selector;
/*     */     }
/* 121 */     String newSelector = String.format(this.resolverFormat, new Object[] { reference });
/* 122 */     this.selectorsByReference.put(reference, newSelector);
/* 123 */     return newSelector;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\templateparser\markup\TemplateFragmentMarkupReferenceResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */