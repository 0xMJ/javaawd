/*    */ package org.thymeleaf.templateparser.markup;
/*    */ 
/*    */ import org.attoparser.config.ParseConfiguration;
/*    */ import org.attoparser.config.ParseConfiguration.ElementBalancing;
/*    */ import org.attoparser.config.ParseConfiguration.PrologParseConfiguration;
/*    */ import org.attoparser.config.ParseConfiguration.PrologPresence;
/*    */ import org.attoparser.config.ParseConfiguration.UniqueRootElementPresence;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class HTMLTemplateParser
/*    */   extends AbstractMarkupTemplateParser
/*    */ {
/* 43 */   static final ParseConfiguration MARKUP_PARSING_CONFIGURATION = ;
/* 44 */   static { MARKUP_PARSING_CONFIGURATION.setElementBalancing(ParseConfiguration.ElementBalancing.AUTO_CLOSE);
/* 45 */     MARKUP_PARSING_CONFIGURATION.setCaseSensitive(false);
/* 46 */     MARKUP_PARSING_CONFIGURATION.setNoUnmatchedCloseElementsRequired(false);
/* 47 */     MARKUP_PARSING_CONFIGURATION.setUniqueAttributesInElementRequired(true);
/* 48 */     MARKUP_PARSING_CONFIGURATION.setXmlWellFormedAttributeValuesRequired(false);
/* 49 */     MARKUP_PARSING_CONFIGURATION.setUniqueRootElementPresence(ParseConfiguration.UniqueRootElementPresence.NOT_VALIDATED);
/* 50 */     MARKUP_PARSING_CONFIGURATION.getPrologParseConfiguration().setDoctypePresence(ParseConfiguration.PrologPresence.ALLOWED);
/* 51 */     MARKUP_PARSING_CONFIGURATION.getPrologParseConfiguration().setRequireDoctypeKeywordsUpperCase(false);
/* 52 */     MARKUP_PARSING_CONFIGURATION.getPrologParseConfiguration().setValidateProlog(false);
/* 53 */     MARKUP_PARSING_CONFIGURATION.getPrologParseConfiguration().setXmlDeclarationPresence(ParseConfiguration.PrologPresence.ALLOWED);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public HTMLTemplateParser(int bufferPoolSize, int bufferSize)
/*    */   {
/* 60 */     super(MARKUP_PARSING_CONFIGURATION, bufferPoolSize, bufferSize);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\templateparser\markup\HTMLTemplateParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */