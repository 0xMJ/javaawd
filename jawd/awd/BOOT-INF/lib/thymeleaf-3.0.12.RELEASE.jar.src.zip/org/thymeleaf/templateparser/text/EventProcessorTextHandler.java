/*     */ package org.thymeleaf.templateparser.text;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ import org.thymeleaf.util.TextUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class EventProcessorTextHandler
/*     */   extends AbstractChainedTextHandler
/*     */ {
/*     */   private static final int DEFAULT_STACK_LEN = 10;
/*     */   private static final int DEFAULT_ATTRIBUTE_NAMES_LEN = 3;
/*     */   private StructureNamesRepository structureNamesRepository;
/*     */   private char[][] elementStack;
/*     */   private int elementStackSize;
/*  52 */   private char[][] currentElementAttributeNames = null;
/*  53 */   private int currentElementAttributeNamesSize = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   EventProcessorTextHandler(ITextHandler handler)
/*     */   {
/*  60 */     super(handler);
/*     */     
/*  62 */     this.elementStack = new char[10][];
/*  63 */     this.elementStackSize = 0;
/*     */     
/*  65 */     this.structureNamesRepository = new StructureNamesRepository();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleDocumentEnd(long endTimeNanos, long totalTimeNanos, int line, int col)
/*     */     throws TextParseException
/*     */   {
/*  78 */     if (this.elementStackSize > 0) {
/*  79 */       char[] popped = popFromStack();
/*  80 */       throw new TextParseException("Malformed template: element \"" + new String(popped, 0, popped.length) + "\" is never closed (no closing tag at the end of document)");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  86 */     super.handleDocumentEnd(endTimeNanos, totalTimeNanos, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleStandaloneElementStart(char[] buffer, int nameOffset, int nameLen, boolean minimized, int line, int col)
/*     */     throws TextParseException
/*     */   {
/*  98 */     this.currentElementAttributeNames = null;
/*  99 */     this.currentElementAttributeNamesSize = 0;
/*     */     
/*     */ 
/*     */ 
/* 103 */     super.handleStandaloneElementStart(buffer, nameOffset, nameLen, minimized, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleOpenElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws TextParseException
/*     */   {
/* 114 */     this.currentElementAttributeNames = null;
/* 115 */     this.currentElementAttributeNamesSize = 0;
/*     */     
/* 117 */     super.handleOpenElementStart(buffer, nameOffset, nameLen, line, col);
/*     */     
/* 119 */     pushToStack(buffer, nameOffset, nameLen);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleCloseElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws TextParseException
/*     */   {
/* 130 */     if (!checkStackForElement(buffer, nameOffset, nameLen, line, col)) {
/* 131 */       throw new TextParseException("Malformed text: element \"" + new String(buffer, nameOffset, nameLen) + "\" is never closed", line, col);
/*     */     }
/*     */     
/*     */ 
/* 135 */     this.currentElementAttributeNames = null;
/* 136 */     this.currentElementAttributeNamesSize = 0;
/*     */     
/* 138 */     super.handleCloseElementStart(buffer, nameOffset, nameLen, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleAttribute(char[] buffer, int nameOffset, int nameLen, int nameLine, int nameCol, int operatorOffset, int operatorLen, int operatorLine, int operatorCol, int valueContentOffset, int valueContentLen, int valueOuterOffset, int valueOuterLen, int valueLine, int valueCol)
/*     */     throws TextParseException
/*     */   {
/* 155 */     if (this.currentElementAttributeNames == null)
/*     */     {
/* 157 */       this.currentElementAttributeNames = new char[3][];
/*     */     }
/* 159 */     for (int i = 0; i < this.currentElementAttributeNamesSize; i++)
/*     */     {
/* 161 */       if (TextUtils.equals(TemplateMode.TEXT
/* 162 */         .isCaseSensitive(), this.currentElementAttributeNames[i], 0, this.currentElementAttributeNames[i].length, buffer, nameOffset, nameLen))
/*     */       {
/*     */ 
/*     */ 
/* 166 */         throw new TextParseException("Malformed text: Attribute \"" + new String(buffer, nameOffset, nameLen) + "\" appears more than once in element", nameLine, nameCol);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 173 */     if (this.currentElementAttributeNamesSize == this.currentElementAttributeNames.length)
/*     */     {
/* 175 */       char[][] newCurrentElementAttributeNames = new char[this.currentElementAttributeNames.length + 3][];
/* 176 */       System.arraycopy(this.currentElementAttributeNames, 0, newCurrentElementAttributeNames, 0, this.currentElementAttributeNames.length);
/* 177 */       this.currentElementAttributeNames = newCurrentElementAttributeNames;
/*     */     }
/*     */     
/*     */ 
/* 181 */     this.currentElementAttributeNames[this.currentElementAttributeNamesSize] = this.structureNamesRepository.getStructureName(buffer, nameOffset, nameLen);
/*     */     
/* 183 */     this.currentElementAttributeNamesSize += 1;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 188 */     super.handleAttribute(buffer, nameOffset, nameLen, nameLine, nameCol, operatorOffset, operatorLen, operatorLine, operatorCol, valueContentOffset, valueContentLen, valueOuterOffset, valueOuterLen, valueLine, valueCol);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean checkStackForElement(char[] buffer, int offset, int len, int line, int col)
/*     */     throws TextParseException
/*     */   {
/* 202 */     char[] peek = peekFromStack();
/*     */     
/* 204 */     if (peek != null)
/*     */     {
/* 206 */       if (TextUtils.equals(TemplateMode.TEXT.isCaseSensitive(), peek, 0, peek.length, buffer, offset, len)) {
/* 207 */         popFromStack();
/* 208 */         return true;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 213 */       throw new TextParseException("Malformed template: " + (peek.length > 0 ? "element \"" + new String(peek, 0, peek.length) + "\"" : "unnamed element") + " is never closed", line, col);
/*     */     }
/*     */     
/*     */ 
/* 217 */     throw new TextParseException("Malformed template: unnamed closing element is never opened", line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void pushToStack(char[] buffer, int offset, int len)
/*     */   {
/* 227 */     if (this.elementStackSize == this.elementStack.length) {
/* 228 */       growStack();
/*     */     }
/*     */     
/*     */ 
/* 232 */     this.elementStack[this.elementStackSize] = this.structureNamesRepository.getStructureName(buffer, offset, len);
/*     */     
/* 234 */     this.elementStackSize += 1;
/*     */   }
/*     */   
/*     */ 
/*     */   private char[] peekFromStack()
/*     */   {
/* 240 */     if (this.elementStackSize == 0) {
/* 241 */       return null;
/*     */     }
/* 243 */     return this.elementStack[(this.elementStackSize - 1)];
/*     */   }
/*     */   
/*     */   private char[] popFromStack()
/*     */   {
/* 248 */     if (this.elementStackSize == 0) {
/* 249 */       return null;
/*     */     }
/* 251 */     char[] popped = this.elementStack[(this.elementStackSize - 1)];
/* 252 */     this.elementStack[(this.elementStackSize - 1)] = null;
/* 253 */     this.elementStackSize -= 1;
/* 254 */     return popped;
/*     */   }
/*     */   
/*     */ 
/*     */   private void growStack()
/*     */   {
/* 260 */     int newStackLen = this.elementStack.length + 10;
/* 261 */     char[][] newStack = new char[newStackLen][];
/* 262 */     System.arraycopy(this.elementStack, 0, newStack, 0, this.elementStack.length);
/* 263 */     this.elementStack = newStack;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static final class StructureNamesRepository
/*     */   {
/*     */     private static final int REPOSITORY_INITIAL_LEN = 20;
/*     */     
/*     */ 
/*     */ 
/*     */     private static final int REPOSITORY_INITIAL_INC = 5;
/*     */     
/*     */ 
/*     */ 
/*     */     private char[][] repository;
/*     */     
/*     */ 
/*     */ 
/*     */     private int repositorySize;
/*     */     
/*     */ 
/*     */ 
/*     */     StructureNamesRepository()
/*     */     {
/* 289 */       this.repository = new char[20][];
/* 290 */       this.repositorySize = 0;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     char[] getStructureName(char[] text, int offset, int len)
/*     */     {
/* 298 */       int index = TextUtils.binarySearch(true, this.repository, 0, this.repositorySize, text, offset, len);
/*     */       
/* 300 */       if (index >= 0) {
/* 301 */         return this.repository[index];
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 307 */       return storeStructureName(index, text, offset, len);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     private char[] storeStructureName(int index, char[] text, int offset, int len)
/*     */     {
/* 314 */       if (this.repositorySize == this.repository.length)
/*     */       {
/* 316 */         char[][] newRepository = new char[this.repository.length + 5][];
/* 317 */         Arrays.fill(newRepository, null);
/* 318 */         System.arraycopy(this.repository, 0, newRepository, 0, this.repositorySize);
/* 319 */         this.repository = newRepository;
/*     */       }
/*     */       
/*     */ 
/* 323 */       int insertionIndex = (index + 1) * -1;
/*     */       
/*     */ 
/* 326 */       char[] structureName = new char[len];
/* 327 */       System.arraycopy(text, offset, structureName, 0, len);
/*     */       
/*     */ 
/* 330 */       System.arraycopy(this.repository, insertionIndex, this.repository, insertionIndex + 1, this.repositorySize - insertionIndex);
/* 331 */       this.repository[insertionIndex] = structureName;
/* 332 */       this.repositorySize += 1;
/*     */       
/* 334 */       return structureName;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\templateparser\text\EventProcessorTextHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */