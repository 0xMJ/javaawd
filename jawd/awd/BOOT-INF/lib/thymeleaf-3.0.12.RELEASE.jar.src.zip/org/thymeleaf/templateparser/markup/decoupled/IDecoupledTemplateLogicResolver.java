package org.thymeleaf.templateparser.markup.decoupled;

import java.util.Set;
import org.thymeleaf.IEngineConfiguration;
import org.thymeleaf.templatemode.TemplateMode;
import org.thymeleaf.templateresource.ITemplateResource;

public abstract interface IDecoupledTemplateLogicResolver
{
  public abstract ITemplateResource resolveDecoupledTemplateLogic(IEngineConfiguration paramIEngineConfiguration, String paramString1, String paramString2, Set<String> paramSet, ITemplateResource paramITemplateResource, TemplateMode paramTemplateMode);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\templateparser\markup\decoupled\IDecoupledTemplateLogicResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */