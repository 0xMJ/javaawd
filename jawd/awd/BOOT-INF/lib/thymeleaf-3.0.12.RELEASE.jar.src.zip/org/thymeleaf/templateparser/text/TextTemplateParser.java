/*    */ package org.thymeleaf.templateparser.text;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class TextTemplateParser
/*    */   extends AbstractTextTemplateParser
/*    */ {
/*    */   public TextTemplateParser(int bufferPoolSize, int bufferSize, boolean standardDialectPresent)
/*    */   {
/* 32 */     super(bufferPoolSize, bufferSize, false, standardDialectPresent);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\templateparser\text\TextTemplateParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */