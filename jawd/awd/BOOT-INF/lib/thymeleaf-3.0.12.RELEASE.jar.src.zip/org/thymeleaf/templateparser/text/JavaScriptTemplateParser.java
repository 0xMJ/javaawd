/*    */ package org.thymeleaf.templateparser.text;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class JavaScriptTemplateParser
/*    */   extends AbstractTextTemplateParser
/*    */ {
/*    */   public JavaScriptTemplateParser(int bufferPoolSize, int bufferSize, boolean standardDialectPresent)
/*    */   {
/* 32 */     super(bufferPoolSize, bufferSize, true, standardDialectPresent);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\templateparser\text\JavaScriptTemplateParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */