/*    */ package org.thymeleaf.templateparser.text;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class ParsingLocatorUtil
/*    */ {
/*    */   public static void countChar(int[] locator, char c)
/*    */   {
/* 33 */     if (c == '\n') {
/* 34 */       locator[0] += 1;
/* 35 */       locator[1] = 1;
/* 36 */       return;
/*    */     }
/* 38 */     locator[1] += 1;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\templateparser\text\ParsingLocatorUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */