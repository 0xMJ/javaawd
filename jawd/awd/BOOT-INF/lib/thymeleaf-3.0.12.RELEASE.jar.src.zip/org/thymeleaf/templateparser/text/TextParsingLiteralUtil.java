/*    */ package org.thymeleaf.templateparser.text;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class TextParsingLiteralUtil
/*    */ {
/*    */   static boolean isRegexLiteralStart(char[] buffer, int offset, int maxi)
/*    */   {
/* 42 */     if ((offset == 0) || (buffer[offset] != '/')) {
/* 43 */       return false;
/*    */     }
/*    */     
/*    */ 
/*    */ 
/* 48 */     if (TextParsingCommentUtil.isCommentBlockStart(buffer, offset, maxi)) {
/* 49 */       return false;
/*    */     }
/*    */     
/* 52 */     if (TextParsingCommentUtil.isCommentLineStart(buffer, offset, maxi)) {
/* 53 */       return false;
/*    */     }
/*    */     
/*    */ 
/* 57 */     int i = offset - 1;
/* 58 */     while (i >= 0) {
/* 59 */       char c = buffer[i];
/* 60 */       if (!Character.isWhitespace(c)) {
/* 61 */         return (c == '(') || (c == '=') || (c == ',');
/*    */       }
/* 63 */       i--;
/*    */     }
/*    */     
/* 66 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\templateparser\text\TextParsingLiteralUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */