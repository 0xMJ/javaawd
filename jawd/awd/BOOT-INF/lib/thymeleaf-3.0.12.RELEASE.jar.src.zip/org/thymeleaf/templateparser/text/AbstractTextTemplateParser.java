/*     */ package org.thymeleaf.templateparser.text;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ import java.util.Set;
/*     */ import org.thymeleaf.EngineConfiguration;
/*     */ import org.thymeleaf.IEngineConfiguration;
/*     */ import org.thymeleaf.engine.ITemplateHandler;
/*     */ import org.thymeleaf.engine.TemplateHandlerAdapterTextHandler;
/*     */ import org.thymeleaf.exceptions.TemplateInputException;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ import org.thymeleaf.templateparser.ITemplateParser;
/*     */ import org.thymeleaf.templateparser.reader.ParserLevelCommentTextReader;
/*     */ import org.thymeleaf.templateparser.reader.PrototypeOnlyCommentTextReader;
/*     */ import org.thymeleaf.templateresource.ITemplateResource;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractTextTemplateParser
/*     */   implements ITemplateParser
/*     */ {
/*     */   private final TextParser parser;
/*     */   
/*     */   protected AbstractTextTemplateParser(int bufferPoolSize, int bufferSize, boolean processCommentsAndLiterals, boolean standardDialectPresent)
/*     */   {
/*  56 */     this.parser = new TextParser(bufferPoolSize, bufferSize, processCommentsAndLiterals, standardDialectPresent);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void parseStandalone(IEngineConfiguration configuration, String ownerTemplate, String template, Set<String> templateSelectors, ITemplateResource resource, TemplateMode templateMode, boolean useDecoupledLogic, ITemplateHandler handler)
/*     */   {
/*  80 */     Validate.notNull(configuration, "Engine Configuration cannot be null");
/*     */     
/*  82 */     Validate.notNull(template, "Template cannot be null");
/*  83 */     Validate.notNull(resource, "Template Resource cannot be null");
/*  84 */     Validate.isTrue((templateSelectors == null) || (templateSelectors.isEmpty()), "Template selectors cannot be specified for a template using a TEXT template mode: template insertion operations must be always performed on whole template files, not fragments");
/*     */     
/*     */ 
/*  87 */     Validate.notNull(templateMode, "Template Mode cannot be null");
/*  88 */     Validate.isTrue(templateMode.isText(), "Template Mode has to be a text template mode");
/*  89 */     Validate.isTrue(!useDecoupledLogic, "Cannot use decoupled logic in template mode " + templateMode);
/*  90 */     Validate.notNull(handler, "Template Handler cannot be null");
/*     */     
/*  92 */     parse(configuration, ownerTemplate, template, templateSelectors, resource, 0, 0, templateMode, handler);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void parseString(IEngineConfiguration configuration, String ownerTemplate, String template, int lineOffset, int colOffset, TemplateMode templateMode, ITemplateHandler handler)
/*     */   {
/* 105 */     Validate.notNull(configuration, "Engine Configuration cannot be null");
/* 106 */     Validate.notNull(ownerTemplate, "Owner template cannot be null");
/* 107 */     Validate.notNull(template, "Template cannot be null");
/*     */     
/* 109 */     Validate.notNull(templateMode, "Template mode cannot be null");
/* 110 */     Validate.isTrue(templateMode.isText(), "Template Mode has to be a text template mode");
/* 111 */     Validate.notNull(handler, "Template Handler cannot be null");
/*     */     
/* 113 */     parse(configuration, ownerTemplate, template, null, null, lineOffset, colOffset, templateMode, handler);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void parse(IEngineConfiguration configuration, String ownerTemplate, String template, Set<String> templateSelectors, ITemplateResource resource, int lineOffset, int colOffset, TemplateMode templateMode, ITemplateHandler templateHandler)
/*     */   {
/* 129 */     String templateName = resource != null ? template : ownerTemplate;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 139 */       ITextHandler handler = new TemplateHandlerAdapterTextHandler(templateName, templateHandler, configuration.getElementDefinitions(), configuration.getAttributeDefinitions(), templateMode, lineOffset, colOffset);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 147 */       if (((configuration instanceof EngineConfiguration)) && (((EngineConfiguration)configuration).isModelReshapeable(templateMode)))
/*     */       {
/*     */ 
/*     */ 
/* 151 */         handler = new InlinedOutputExpressionTextHandler(configuration, templateMode, configuration.getStandardDialectPrefix(), handler);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 156 */       Reader templateReader = resource != null ? resource.reader() : new StringReader(template);
/*     */       
/*     */ 
/*     */ 
/* 160 */       if (templateMode == TemplateMode.TEXT)
/*     */       {
/* 162 */         templateReader = new ParserLevelCommentTextReader(templateReader);
/*     */       }
/*     */       else {
/* 165 */         templateReader = new ParserLevelCommentTextReader(new PrototypeOnlyCommentTextReader(templateReader));
/*     */       }
/*     */       
/*     */ 
/* 169 */       this.parser.parse(templateReader, handler);
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 173 */       String message = "An error happened during template parsing";
/* 174 */       throw new TemplateInputException("An error happened during template parsing", resource != null ? resource.getDescription() : template, e);
/*     */     } catch (TextParseException e) {
/* 176 */       String message = "An error happened during template parsing";
/* 177 */       if ((e.getLine() != null) && (e.getCol() != null)) {
/* 178 */         throw new TemplateInputException("An error happened during template parsing", resource != null ? resource.getDescription() : template, e.getLine().intValue(), e.getCol().intValue(), e);
/*     */       }
/* 180 */       throw new TemplateInputException("An error happened during template parsing", resource != null ? resource.getDescription() : template, e);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\templateparser\text\AbstractTextTemplateParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */