/*     */ package org.thymeleaf.templateparser.markup.decoupled;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DecoupledTemplateLogic
/*     */ {
/*  59 */   private final Map<String, List<DecoupledInjectedAttribute>> injectedAttributes = new HashMap(20);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasInjectedAttributes()
/*     */   {
/*  70 */     return this.injectedAttributes.size() > 0;
/*     */   }
/*     */   
/*     */   public Set<String> getAllInjectedAttributeSelectors()
/*     */   {
/*  75 */     return this.injectedAttributes.keySet();
/*     */   }
/*     */   
/*     */   public List<DecoupledInjectedAttribute> getInjectedAttributesForSelector(String selector) {
/*  79 */     return (List)this.injectedAttributes.get(selector);
/*     */   }
/*     */   
/*     */ 
/*     */   public void addInjectedAttribute(String selector, DecoupledInjectedAttribute injectedAttribute)
/*     */   {
/*  85 */     Validate.notNull(selector, "Selector cannot be null");
/*  86 */     Validate.notNull(injectedAttribute, "Injected Attribute cannot be null");
/*     */     
/*  88 */     List<DecoupledInjectedAttribute> injectedAttributesForSelector = (List)this.injectedAttributes.get(selector);
/*  89 */     if (injectedAttributesForSelector == null) {
/*  90 */       injectedAttributesForSelector = new ArrayList(2);
/*  91 */       this.injectedAttributes.put(selector, injectedAttributesForSelector);
/*     */     }
/*     */     
/*  94 */     injectedAttributesForSelector.add(injectedAttribute);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 104 */     List<String> keys = new ArrayList(this.injectedAttributes.keySet());
/* 105 */     Collections.sort(keys);
/*     */     
/* 107 */     StringBuilder strBuilder = new StringBuilder();
/* 108 */     strBuilder.append('{');
/* 109 */     for (int i = 0; i < keys.size(); i++) {
/* 110 */       if (i > 0) {
/* 111 */         strBuilder.append(", ");
/*     */       }
/* 113 */       strBuilder.append((String)keys.get(i));
/* 114 */       strBuilder.append('=');
/* 115 */       strBuilder.append(this.injectedAttributes.get(keys.get(i)));
/*     */     }
/* 117 */     strBuilder.append('}');
/*     */     
/* 119 */     return strBuilder.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\templateparser\markup\decoupled\DecoupledTemplateLogic.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */