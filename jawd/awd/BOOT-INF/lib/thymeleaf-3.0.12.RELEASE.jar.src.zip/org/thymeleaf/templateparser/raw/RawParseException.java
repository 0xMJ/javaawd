/*     */ package org.thymeleaf.templateparser.raw;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RawParseException
/*     */   extends Exception
/*     */ {
/*     */   private static final long serialVersionUID = -104133072151159140L;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final Integer line;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final Integer col;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RawParseException()
/*     */   {
/*  44 */     this.line = null;
/*  45 */     this.col = null;
/*     */   }
/*     */   
/*     */   public RawParseException(String message, Throwable throwable)
/*     */   {
/*  50 */     super(message(message, throwable), throwable);
/*     */     
/*  52 */     if ((throwable != null) && ((throwable instanceof RawParseException))) {
/*  53 */       this.line = ((RawParseException)throwable).getLine();
/*  54 */       this.col = ((RawParseException)throwable).getCol();
/*     */     } else {
/*  56 */       this.line = null;
/*  57 */       this.col = null;
/*     */     }
/*     */   }
/*     */   
/*     */   public RawParseException(String message)
/*     */   {
/*  63 */     super(message);
/*  64 */     this.line = null;
/*  65 */     this.col = null;
/*     */   }
/*     */   
/*     */   public RawParseException(Throwable throwable)
/*     */   {
/*  70 */     super(message(null, throwable), throwable);
/*     */     
/*  72 */     if ((throwable != null) && ((throwable instanceof RawParseException))) {
/*  73 */       this.line = ((RawParseException)throwable).getLine();
/*  74 */       this.col = ((RawParseException)throwable).getCol();
/*     */     } else {
/*  76 */       this.line = null;
/*  77 */       this.col = null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public RawParseException(int line, int col)
/*     */   {
/*  84 */     super(messagePrefix(line, col));
/*  85 */     this.line = Integer.valueOf(line);
/*  86 */     this.col = Integer.valueOf(col);
/*     */   }
/*     */   
/*     */   public RawParseException(String message, Throwable throwable, int line, int col) {
/*  90 */     super(messagePrefix(line, col) + " " + message, throwable);
/*  91 */     this.line = Integer.valueOf(line);
/*  92 */     this.col = Integer.valueOf(col);
/*     */   }
/*     */   
/*     */   public RawParseException(String message, int line, int col) {
/*  96 */     super(messagePrefix(line, col) + " " + message);
/*  97 */     this.line = Integer.valueOf(line);
/*  98 */     this.col = Integer.valueOf(col);
/*     */   }
/*     */   
/*     */   public RawParseException(Throwable throwable, int line, int col) {
/* 102 */     super(messagePrefix(line, col), throwable);
/* 103 */     this.line = Integer.valueOf(line);
/* 104 */     this.col = Integer.valueOf(col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static String messagePrefix(int line, int col)
/*     */   {
/* 111 */     return "(Line = " + line + ", Column = " + col + ")";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static String message(String message, Throwable throwable)
/*     */   {
/* 118 */     if ((throwable != null) && ((throwable instanceof RawParseException)))
/*     */     {
/* 120 */       RawParseException exception = (RawParseException)throwable;
/* 121 */       if ((exception.getLine() != null) && (exception.getCol() != null)) {
/* 122 */         return 
/* 123 */           "(Line = " + exception.getLine() + ", Column = " + exception.getCol() + ")" + (message != null ? " " + message : throwable.getMessage());
/*     */       }
/*     */     }
/*     */     
/* 127 */     if (message != null) {
/* 128 */       return message;
/*     */     }
/* 130 */     if (throwable != null) {
/* 131 */       return throwable.getMessage();
/*     */     }
/* 133 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Integer getLine()
/*     */   {
/* 142 */     return this.line;
/*     */   }
/*     */   
/*     */   public Integer getCol() {
/* 146 */     return this.col;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\templateparser\raw\RawParseException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */