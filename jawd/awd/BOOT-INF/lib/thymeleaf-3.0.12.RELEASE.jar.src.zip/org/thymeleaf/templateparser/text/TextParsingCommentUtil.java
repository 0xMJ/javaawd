/*    */ package org.thymeleaf.templateparser.text;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class TextParsingCommentUtil
/*    */ {
/*    */   public static void parseComment(char[] buffer, int offset, int len, int line, int col, ITextHandler handler)
/*    */     throws TextParseException
/*    */   {
/* 47 */     if ((len < 4) || (!isCommentBlockStart(buffer, offset, offset + len)) || (!isCommentBlockEnd(buffer, offset + len - 2, offset + len))) {
/* 48 */       throw new TextParseException("Could not parse as a well-formed Comment: \"" + new String(buffer, offset, len) + "\"", line, col);
/*    */     }
/*    */     
/*    */ 
/* 52 */     int contentOffset = offset + 2;
/* 53 */     int contentLen = len - 4;
/*    */     
/* 55 */     handler.handleComment(buffer, contentOffset, contentLen, offset, len, line, col);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   static boolean isCommentBlockStart(char[] buffer, int offset, int maxi)
/*    */   {
/* 67 */     return (maxi - offset > 1) && (buffer[offset] == '/') && (buffer[(offset + 1)] == '*');
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   static boolean isCommentBlockEnd(char[] buffer, int offset, int maxi)
/*    */   {
/* 74 */     return (maxi - offset > 1) && (buffer[offset] == '*') && (buffer[(offset + 1)] == '/');
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   static boolean isCommentLineStart(char[] buffer, int offset, int maxi)
/*    */   {
/* 83 */     return (maxi - offset > 1) && (buffer[offset] == '/') && (buffer[(offset + 1)] == '/');
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\templateparser\text\TextParsingCommentUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */