package org.thymeleaf.templateparser.text;

public abstract interface ITextHandler
{
  public abstract void handleDocumentStart(long paramLong, int paramInt1, int paramInt2)
    throws TextParseException;
  
  public abstract void handleDocumentEnd(long paramLong1, long paramLong2, int paramInt1, int paramInt2)
    throws TextParseException;
  
  public abstract void handleText(char[] paramArrayOfChar, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
    throws TextParseException;
  
  public abstract void handleComment(char[] paramArrayOfChar, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6)
    throws TextParseException;
  
  public abstract void handleStandaloneElementStart(char[] paramArrayOfChar, int paramInt1, int paramInt2, boolean paramBoolean, int paramInt3, int paramInt4)
    throws TextParseException;
  
  public abstract void handleStandaloneElementEnd(char[] paramArrayOfChar, int paramInt1, int paramInt2, boolean paramBoolean, int paramInt3, int paramInt4)
    throws TextParseException;
  
  public abstract void handleOpenElementStart(char[] paramArrayOfChar, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
    throws TextParseException;
  
  public abstract void handleOpenElementEnd(char[] paramArrayOfChar, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
    throws TextParseException;
  
  public abstract void handleCloseElementStart(char[] paramArrayOfChar, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
    throws TextParseException;
  
  public abstract void handleCloseElementEnd(char[] paramArrayOfChar, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
    throws TextParseException;
  
  public abstract void handleAttribute(char[] paramArrayOfChar, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10, int paramInt11, int paramInt12, int paramInt13, int paramInt14)
    throws TextParseException;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\templateparser\text\ITextHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */