package org.thymeleaf.templateparser.raw;

public abstract interface IRawHandler
{
  public abstract void handleDocumentStart(long paramLong, int paramInt1, int paramInt2)
    throws RawParseException;
  
  public abstract void handleDocumentEnd(long paramLong1, long paramLong2, int paramInt1, int paramInt2)
    throws RawParseException;
  
  public abstract void handleText(char[] paramArrayOfChar, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
    throws RawParseException;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\templateparser\raw\IRawHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */