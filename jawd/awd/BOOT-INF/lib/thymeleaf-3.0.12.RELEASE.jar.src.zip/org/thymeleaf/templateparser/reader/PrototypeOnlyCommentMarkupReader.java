/*    */ package org.thymeleaf.templateparser.reader;
/*    */ 
/*    */ import java.io.Reader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class PrototypeOnlyCommentMarkupReader
/*    */   extends BlockAwareReader
/*    */ {
/* 32 */   private static final char[] PREFIX = "<!--/*/".toCharArray();
/* 33 */   private static final char[] SUFFIX = "/*/-->".toCharArray();
/*    */   
/*    */   public PrototypeOnlyCommentMarkupReader(Reader reader)
/*    */   {
/* 37 */     super(reader, BlockAwareReader.BlockAction.DISCARD_CONTAINER, PREFIX, SUFFIX);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\templateparser\reader\PrototypeOnlyCommentMarkupReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */