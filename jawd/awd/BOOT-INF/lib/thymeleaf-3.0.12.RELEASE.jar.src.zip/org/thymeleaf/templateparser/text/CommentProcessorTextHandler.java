/*     */ package org.thymeleaf.templateparser.text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class CommentProcessorTextHandler
/*     */   extends AbstractChainedTextHandler
/*     */ {
/*     */   private final boolean standardDialectPresent;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  50 */   private boolean filterTexts = false;
/*  51 */   private char[] filteredTextBuffer = null;
/*  52 */   private int filteredTextSize = 0;
/*  53 */   private int[] filteredTextLocator = null;
/*     */   
/*     */   CommentProcessorTextHandler(boolean standardDialectPresent, ITextHandler handler)
/*     */   {
/*  57 */     super(handler);
/*  58 */     this.standardDialectPresent = standardDialectPresent;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleDocumentEnd(long endTimeNanos, long totalTimeNanos, int line, int col)
/*     */     throws TextParseException
/*     */   {
/*  68 */     processFilteredTexts();
/*  69 */     super.handleDocumentEnd(endTimeNanos, totalTimeNanos, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleComment(char[] buffer, int contentOffset, int contentLen, int outerOffset, int outerLen, int line, int col)
/*     */     throws TextParseException
/*     */   {
/*  83 */     processFilteredTexts();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  91 */     if (!isCommentProcessable(buffer, contentOffset, contentLen)) {
/*  92 */       super.handleText(buffer, outerOffset, outerLen, line, col);
/*  93 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 101 */     int maxi = contentOffset + contentLen;
/*     */     
/* 103 */     if (TextParsingElementUtil.isOpenElementStart(buffer, contentOffset, maxi))
/*     */     {
/*     */ 
/* 106 */       if (TextParsingElementUtil.isElementEnd(buffer, maxi - 2, maxi, true))
/*     */       {
/*     */ 
/* 109 */         TextParsingElementUtil.parseStandaloneElement(buffer, contentOffset, contentLen, line, col + 2, getNext());
/* 110 */         return;
/*     */       }
/* 112 */       if (TextParsingElementUtil.isElementEnd(buffer, maxi - 1, maxi, false))
/*     */       {
/*     */ 
/* 115 */         TextParsingElementUtil.parseOpenElement(buffer, contentOffset, contentLen, line, col + 2, getNext());
/*     */       }
/*     */       
/*     */ 
/*     */     }
/* 120 */     else if (TextParsingElementUtil.isCloseElementStart(buffer, contentOffset, maxi))
/*     */     {
/*     */ 
/* 123 */       if (TextParsingElementUtil.isElementEnd(buffer, maxi - 1, maxi, false))
/*     */       {
/*     */ 
/* 126 */         TextParsingElementUtil.parseCloseElement(buffer, contentOffset, contentLen, line, col + 2, getNext());
/* 127 */         return;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 144 */     if (this.standardDialectPresent) {
/* 145 */       getNext().handleText(buffer, contentOffset, contentLen, line, col + 2);
/* 146 */       this.filterTexts = true;
/*     */     }
/*     */     else
/*     */     {
/* 150 */       getNext().handleText(buffer, outerOffset, outerLen, line, col);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean isCommentProcessable(char[] buffer, int contentOffset, int contentLen)
/*     */   {
/* 159 */     int maxi = contentOffset + contentLen;
/* 160 */     if ((contentLen < 3) || (buffer[contentOffset] != '[') || (buffer[(maxi - 1)] != ']')) {
/* 161 */       return false;
/*     */     }
/* 163 */     if ((contentLen >= 4) && (buffer[(contentOffset + 1)] == '(') && (buffer[(maxi - 2)] == ')'))
/*     */     {
/* 165 */       return true;
/*     */     }
/* 167 */     if ((contentLen >= 4) && (buffer[(contentOffset + 1)] == '[') && (buffer[(maxi - 2)] == ']'))
/*     */     {
/* 169 */       return true;
/*     */     }
/*     */     
/*     */ 
/* 173 */     if (TextParsingElementUtil.isOpenElementStart(buffer, contentOffset, maxi)) {
/* 174 */       return TextParsingElementUtil.isElementEnd(buffer, maxi - 1, maxi, false);
/*     */     }
/* 176 */     if (TextParsingElementUtil.isCloseElementStart(buffer, contentOffset, maxi)) {
/* 177 */       return TextParsingElementUtil.isElementEnd(buffer, maxi - 1, maxi, false);
/*     */     }
/* 179 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleText(char[] buffer, int offset, int len, int line, int col)
/*     */     throws TextParseException
/*     */   {
/* 192 */     if (this.filterTexts)
/*     */     {
/*     */ 
/* 195 */       filterText(buffer, offset, len, line, col);
/* 196 */       return;
/*     */     }
/*     */     
/* 199 */     super.handleText(buffer, offset, len, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void filterText(char[] buffer, int offset, int len, int line, int col)
/*     */   {
/* 207 */     if (this.filteredTextBuffer == null) {
/* 208 */       this.filteredTextBuffer = new char[Math.max(256, len)];
/* 209 */       this.filteredTextSize = 0;
/* 210 */       this.filteredTextLocator = new int[2];
/* 211 */     } else if (this.filteredTextSize + len > this.filteredTextBuffer.length)
/*     */     {
/* 213 */       char[] newFilteredTextBuffer = new char[Math.max(this.filteredTextBuffer.length + 256, this.filteredTextSize + len)];
/* 214 */       System.arraycopy(this.filteredTextBuffer, 0, newFilteredTextBuffer, 0, this.filteredTextSize);
/* 215 */       this.filteredTextBuffer = newFilteredTextBuffer;
/*     */     }
/*     */     
/* 218 */     System.arraycopy(buffer, offset, this.filteredTextBuffer, this.filteredTextSize, len);
/* 219 */     this.filteredTextSize += len;
/*     */     
/* 221 */     this.filteredTextLocator[0] = line;
/* 222 */     this.filteredTextLocator[1] = col;
/*     */   }
/*     */   
/*     */ 
/*     */   private void processFilteredTexts()
/*     */     throws TextParseException
/*     */   {
/* 229 */     if (!this.filterTexts) {
/* 230 */       return;
/*     */     }
/*     */     
/*     */ 
/* 234 */     int filterOffset = computeFilterOffset(this.filteredTextBuffer, 0, this.filteredTextSize, this.filteredTextLocator);
/*     */     
/* 236 */     if (filterOffset < this.filteredTextSize)
/*     */     {
/* 238 */       super.handleText(this.filteredTextBuffer, filterOffset, this.filteredTextSize - filterOffset, this.filteredTextLocator[0], this.filteredTextLocator[1]);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 246 */     this.filteredTextSize = 0;
/* 247 */     this.filterTexts = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleStandaloneElementStart(char[] buffer, int nameOffset, int nameLen, boolean minimized, int line, int col)
/*     */     throws TextParseException
/*     */   {
/* 259 */     processFilteredTexts();
/* 260 */     super.handleStandaloneElementStart(buffer, nameOffset, nameLen, minimized, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleOpenElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws TextParseException
/*     */   {
/* 270 */     processFilteredTexts();
/* 271 */     super.handleOpenElementStart(buffer, nameOffset, nameLen, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleCloseElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws TextParseException
/*     */   {
/* 281 */     processFilteredTexts();
/* 282 */     super.handleCloseElementStart(buffer, nameOffset, nameLen, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static int computeFilterOffset(char[] buffer, int offset, int maxi, int[] locator)
/*     */   {
/* 290 */     if (offset == maxi) {
/* 291 */       return 0;
/*     */     }
/*     */     
/* 294 */     char literalDelimiter = '\000';
/* 295 */     int arrayLevel = 0;
/* 296 */     int objectLevel = 0;
/*     */     
/* 298 */     int i = offset;
/*     */     
/* 300 */     while (i < maxi)
/*     */     {
/* 302 */       char c = buffer[(i++)];
/*     */       
/*     */ 
/* 305 */       if (literalDelimiter != 0) {
/* 306 */         if ((c == literalDelimiter) && (buffer[(i - 2)] != '\\')) {
/* 307 */           literalDelimiter = '\000';
/*     */         }
/* 309 */         ParsingLocatorUtil.countChar(locator, c);
/*     */ 
/*     */ 
/*     */       }
/* 313 */       else if ((c == '\'') || (c == '"')) {
/* 314 */         literalDelimiter = c;
/* 315 */         ParsingLocatorUtil.countChar(locator, c);
/*     */ 
/*     */ 
/*     */       }
/* 319 */       else if (c == '{') {
/* 320 */         objectLevel++;
/* 321 */         ParsingLocatorUtil.countChar(locator, c);
/*     */       }
/* 323 */       else if ((objectLevel > 0) && (c == '}')) {
/* 324 */         objectLevel--;
/* 325 */         ParsingLocatorUtil.countChar(locator, c);
/*     */       }
/* 327 */       else if (c == '[') {
/* 328 */         arrayLevel++;
/* 329 */         ParsingLocatorUtil.countChar(locator, c);
/*     */       }
/* 331 */       else if ((arrayLevel > 0) && (c == ']')) {
/* 332 */         arrayLevel--;
/* 333 */         ParsingLocatorUtil.countChar(locator, c);
/*     */       }
/*     */       else
/*     */       {
/* 337 */         if ((arrayLevel == 0) && (objectLevel == 0)) {
/* 338 */           if (c == '\n') {
/* 339 */             return i - 1;
/*     */           }
/* 341 */           if ((c == ';') || (c == ',') || (c == ')') || (c == '}') || (c == ']')) {
/* 342 */             return i - 1;
/*     */           }
/* 344 */           if ((c == '/') && (i < maxi) && (buffer[i] == '/')) {
/* 345 */             return i - 1;
/*     */           }
/*     */         }
/*     */         
/* 349 */         ParsingLocatorUtil.countChar(locator, c);
/*     */       }
/*     */     }
/*     */     
/* 353 */     return maxi;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\templateparser\text\CommentProcessorTextHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */