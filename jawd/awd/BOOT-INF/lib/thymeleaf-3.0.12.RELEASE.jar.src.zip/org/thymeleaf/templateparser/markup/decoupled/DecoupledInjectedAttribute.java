/*     */ package org.thymeleaf.templateparser.markup.decoupled;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DecoupledInjectedAttribute
/*     */ {
/*     */   final char[] buffer;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   final int nameOffset;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   final int nameLen;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   final int operatorOffset;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   final int operatorLen;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   final int valueContentOffset;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   final int valueContentLen;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   final int valueOuterOffset;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   final int valueOuterLen;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static DecoupledInjectedAttribute createAttribute(char[] buffer, int nameOffset, int nameLen, int operatorOffset, int operatorLen, int valueContentOffset, int valueContentLen, int valueOuterOffset, int valueOuterLen)
/*     */   {
/*  57 */     char[] newBuffer = new char[nameLen + operatorLen + valueOuterLen];
/*  58 */     System.arraycopy(buffer, nameOffset, newBuffer, 0, nameLen);
/*  59 */     System.arraycopy(buffer, operatorOffset, newBuffer, nameLen, operatorLen);
/*  60 */     System.arraycopy(buffer, valueOuterOffset, newBuffer, nameLen + operatorLen, valueOuterLen);
/*     */     
/*  62 */     return new DecoupledInjectedAttribute(newBuffer, 0, nameLen, operatorOffset - nameOffset, operatorLen, valueContentOffset - nameOffset, valueContentLen, valueOuterOffset - nameOffset, valueOuterLen);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private DecoupledInjectedAttribute(char[] buffer, int nameOffset, int nameLen, int operatorOffset, int operatorLen, int valueContentOffset, int valueContentLen, int valueOuterOffset, int valueOuterLen)
/*     */   {
/*  82 */     this.buffer = buffer;
/*  83 */     this.nameOffset = nameOffset;
/*  84 */     this.nameLen = nameLen;
/*  85 */     this.operatorOffset = operatorOffset;
/*  86 */     this.operatorLen = operatorLen;
/*  87 */     this.valueContentOffset = valueContentOffset;
/*  88 */     this.valueContentLen = valueContentLen;
/*  89 */     this.valueOuterOffset = valueOuterOffset;
/*  90 */     this.valueOuterLen = valueOuterLen;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getName()
/*     */   {
/*  96 */     return new String(this.buffer, this.nameOffset, this.nameLen);
/*     */   }
/*     */   
/*     */   public String getOperator() {
/* 100 */     return new String(this.buffer, this.operatorOffset, this.operatorLen);
/*     */   }
/*     */   
/*     */   public String getValueContent() {
/* 104 */     return new String(this.buffer, this.valueContentOffset, this.valueContentLen);
/*     */   }
/*     */   
/*     */   public String getValueOuter() {
/* 108 */     return new String(this.buffer, this.valueOuterOffset, this.valueOuterLen);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 117 */     return new String(this.buffer);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\templateparser\markup\decoupled\DecoupledInjectedAttribute.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */