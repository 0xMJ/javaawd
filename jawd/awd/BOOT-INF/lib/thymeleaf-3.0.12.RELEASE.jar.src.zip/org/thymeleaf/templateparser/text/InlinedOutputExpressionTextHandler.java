/*     */ package org.thymeleaf.templateparser.text;
/*     */ 
/*     */ import org.thymeleaf.IEngineConfiguration;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.standard.inline.IInlinePreProcessorHandler;
/*     */ import org.thymeleaf.standard.inline.OutputExpressionInlinePreProcessorHandler;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class InlinedOutputExpressionTextHandler
/*     */   extends AbstractChainedTextHandler
/*     */ {
/*     */   private final OutputExpressionInlinePreProcessorHandler inlineHandler;
/*     */   
/*     */   InlinedOutputExpressionTextHandler(IEngineConfiguration configuration, TemplateMode templateMode, String standardDialectPrefix, ITextHandler handler)
/*     */   {
/*  57 */     super(handler);
/*     */     
/*  59 */     this.inlineHandler = new OutputExpressionInlinePreProcessorHandler(configuration, templateMode, standardDialectPrefix, new InlineTextAdapterPreProcessorHandler(handler));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleText(char[] buffer, int offset, int len, int line, int col)
/*     */     throws TextParseException
/*     */   {
/*  78 */     this.inlineHandler.handleText(buffer, offset, len, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleStandaloneElementStart(char[] buffer, int nameOffset, int nameLen, boolean minimized, int line, int col)
/*     */     throws TextParseException
/*     */   {
/*  91 */     this.inlineHandler.handleStandaloneElementStart(buffer, nameOffset, nameLen, minimized, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleStandaloneElementEnd(char[] buffer, int nameOffset, int nameLen, boolean minimized, int line, int col)
/*     */     throws TextParseException
/*     */   {
/* 102 */     this.inlineHandler.handleStandaloneElementEnd(buffer, nameOffset, nameLen, minimized, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleOpenElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws TextParseException
/*     */   {
/* 112 */     this.inlineHandler.handleOpenElementStart(buffer, nameOffset, nameLen, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleOpenElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws TextParseException
/*     */   {
/* 122 */     this.inlineHandler.handleOpenElementEnd(buffer, nameOffset, nameLen, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleCloseElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws TextParseException
/*     */   {
/* 132 */     this.inlineHandler.handleCloseElementStart(buffer, nameOffset, nameLen, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleCloseElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws TextParseException
/*     */   {
/* 142 */     this.inlineHandler.handleCloseElementEnd(buffer, nameOffset, nameLen, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleAttribute(char[] buffer, int nameOffset, int nameLen, int nameLine, int nameCol, int operatorOffset, int operatorLen, int operatorLine, int operatorCol, int valueContentOffset, int valueContentLen, int valueOuterOffset, int valueOuterLen, int valueLine, int valueCol)
/*     */     throws TextParseException
/*     */   {
/* 159 */     this.inlineHandler.handleAttribute(buffer, nameOffset, nameLen, nameLine, nameCol, operatorOffset, operatorLen, operatorLine, operatorCol, valueContentOffset, valueContentLen, valueOuterOffset, valueOuterLen, valueLine, valueCol);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final class InlineTextAdapterPreProcessorHandler
/*     */     implements IInlinePreProcessorHandler
/*     */   {
/*     */     private ITextHandler handler;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     InlineTextAdapterPreProcessorHandler(ITextHandler handler)
/*     */     {
/* 178 */       this.handler = handler;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public void handleText(char[] buffer, int offset, int len, int line, int col)
/*     */     {
/*     */       try
/*     */       {
/* 187 */         this.handler.handleText(buffer, offset, len, line, col);
/*     */       } catch (TextParseException e) {
/* 189 */         throw new TemplateProcessingException("Parse exception during processing of inlining", e);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public void handleStandaloneElementStart(char[] buffer, int nameOffset, int nameLen, boolean minimized, int line, int col)
/*     */     {
/*     */       try
/*     */       {
/* 199 */         this.handler.handleStandaloneElementStart(buffer, nameOffset, nameLen, minimized, line, col);
/*     */       } catch (TextParseException e) {
/* 201 */         throw new TemplateProcessingException("Parse exception during processing of inlining", e);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public void handleStandaloneElementEnd(char[] buffer, int nameOffset, int nameLen, boolean minimized, int line, int col)
/*     */     {
/*     */       try
/*     */       {
/* 211 */         this.handler.handleStandaloneElementEnd(buffer, nameOffset, nameLen, minimized, line, col);
/*     */       } catch (TextParseException e) {
/* 213 */         throw new TemplateProcessingException("Parse exception during processing of inlining", e);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */     public void handleOpenElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     {
/*     */       try
/*     */       {
/* 222 */         this.handler.handleOpenElementStart(buffer, nameOffset, nameLen, line, col);
/*     */       } catch (TextParseException e) {
/* 224 */         throw new TemplateProcessingException("Parse exception during processing of inlining", e);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */     public void handleOpenElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     {
/*     */       try
/*     */       {
/* 233 */         this.handler.handleOpenElementEnd(buffer, nameOffset, nameLen, line, col);
/*     */       } catch (TextParseException e) {
/* 235 */         throw new TemplateProcessingException("Parse exception during processing of inlining", e);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public void handleAutoOpenElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     {
/* 243 */       throw new TemplateProcessingException("Parse exception during processing of inlining: auto-open not allowed in text mode");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public void handleAutoOpenElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     {
/* 250 */       throw new TemplateProcessingException("Parse exception during processing of inlining: auto-open not allowed in text mode");
/*     */     }
/*     */     
/*     */ 
/*     */     public void handleCloseElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     {
/*     */       try
/*     */       {
/* 258 */         this.handler.handleCloseElementStart(buffer, nameOffset, nameLen, line, col);
/*     */       } catch (TextParseException e) {
/* 260 */         throw new TemplateProcessingException("Parse exception during processing of inlining", e);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */     public void handleCloseElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     {
/*     */       try
/*     */       {
/* 269 */         this.handler.handleCloseElementEnd(buffer, nameOffset, nameLen, line, col);
/*     */       } catch (TextParseException e) {
/* 271 */         throw new TemplateProcessingException("Parse exception during processing of inlining", e);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public void handleAutoCloseElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     {
/* 279 */       throw new TemplateProcessingException("Parse exception during processing of inlining: auto-close not allowed in text mode");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public void handleAutoCloseElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     {
/* 286 */       throw new TemplateProcessingException("Parse exception during processing of inlining: auto-close not allowed in text mode");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void handleAttribute(char[] buffer, int nameOffset, int nameLen, int nameLine, int nameCol, int operatorOffset, int operatorLen, int operatorLine, int operatorCol, int valueContentOffset, int valueContentLen, int valueOuterOffset, int valueOuterLen, int valueLine, int valueCol)
/*     */     {
/*     */       try
/*     */       {
/* 299 */         this.handler.handleAttribute(buffer, nameOffset, nameLen, nameLine, nameCol, operatorOffset, operatorLen, operatorLine, operatorCol, valueContentOffset, valueContentLen, valueOuterOffset, valueOuterLen, valueLine, valueCol);
/*     */ 
/*     */       }
/*     */       catch (TextParseException e)
/*     */       {
/*     */ 
/* 305 */         throw new TemplateProcessingException("Parse exception during processing of inlining", e);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\templateparser\text\InlinedOutputExpressionTextHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */