/*     */ package org.thymeleaf.templateparser.markup.decoupled;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Set;
/*     */ import org.attoparser.IMarkupParser;
/*     */ import org.attoparser.ParseException;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.thymeleaf.IEngineConfiguration;
/*     */ import org.thymeleaf.TemplateEngine;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ import org.thymeleaf.templateresource.ITemplateResource;
/*     */ import org.thymeleaf.util.LoggingUtils;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DecoupledTemplateLogicUtils
/*     */ {
/*  52 */   private static final Logger logger = LoggerFactory.getLogger(DecoupledTemplateLogicUtils.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static DecoupledTemplateLogic computeDecoupledTemplateLogic(IEngineConfiguration configuration, String ownerTemplate, String template, Set<String> templateSelectors, ITemplateResource resource, TemplateMode templateMode, IMarkupParser parser)
/*     */     throws IOException, ParseException
/*     */   {
/*  63 */     Validate.notNull(configuration, "Engine Configuration cannot be null");
/*  64 */     Validate.notNull(template, "Template cannot be null");
/*  65 */     Validate.notNull(resource, "Template Resource cannot be null");
/*  66 */     Validate.notNull(templateMode, "Template Mode cannot be null");
/*     */     
/*  68 */     IDecoupledTemplateLogicResolver decoupledTemplateLogicResolver = configuration.getDecoupledTemplateLogicResolver();
/*     */     
/*     */ 
/*  71 */     ITemplateResource decoupledResource = decoupledTemplateLogicResolver.resolveDecoupledTemplateLogic(configuration, ownerTemplate, template, templateSelectors, resource, templateMode);
/*     */     
/*     */ 
/*  74 */     if (!decoupledResource.exists())
/*     */     {
/*  76 */       if (logger.isTraceEnabled()) {
/*  77 */         logger.trace("[THYMELEAF][{}] Decoupled logic for template \"{}\" could not be resolved as relative resource \"{}\". This does not need to be an error, as templates may lack a corresponding decoupled logic file.", new Object[] {
/*     */         
/*     */ 
/*  80 */           TemplateEngine.threadIndex(), LoggingUtils.loggifyTemplateName(template), decoupledResource.getDescription() });
/*     */       }
/*     */       
/*  83 */       return null;
/*     */     }
/*     */     
/*     */ 
/*  87 */     if (logger.isTraceEnabled()) {
/*  88 */       logger.trace("[THYMELEAF][{}] Decoupled logic for template \"{}\" has been resolved as relative resource \"{}\"", new Object[] {
/*     */       
/*  90 */         TemplateEngine.threadIndex(), LoggingUtils.loggifyTemplateName(template), decoupledResource.getDescription() });
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  99 */     DecoupledTemplateLogicBuilderMarkupHandler decoupledMarkupHandler = new DecoupledTemplateLogicBuilderMarkupHandler(template, templateMode);
/*     */     
/*     */ 
/* 102 */     parser.parse(decoupledResource.reader(), decoupledMarkupHandler);
/*     */     
/* 104 */     return decoupledMarkupHandler.getDecoupledTemplateLogic();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\templateparser\markup\decoupled\DecoupledTemplateLogicUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */