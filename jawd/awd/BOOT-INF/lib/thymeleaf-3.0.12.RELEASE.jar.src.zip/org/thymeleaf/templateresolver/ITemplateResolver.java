package org.thymeleaf.templateresolver;

import java.util.Map;
import org.thymeleaf.IEngineConfiguration;

public abstract interface ITemplateResolver
{
  public abstract String getName();
  
  public abstract Integer getOrder();
  
  public abstract TemplateResolution resolveTemplate(IEngineConfiguration paramIEngineConfiguration, String paramString1, String paramString2, Map<String, Object> paramMap);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\templateresolver\ITemplateResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */