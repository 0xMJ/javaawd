/*     */ package org.thymeleaf.templateresolver;
/*     */ 
/*     */ import java.util.Map;
/*     */ import org.thymeleaf.IEngineConfiguration;
/*     */ import org.thymeleaf.cache.AlwaysValidCacheEntryValidity;
/*     */ import org.thymeleaf.cache.ICacheEntryValidity;
/*     */ import org.thymeleaf.cache.NonCacheableCacheEntryValidity;
/*     */ import org.thymeleaf.cache.TTLCacheEntryValidity;
/*     */ import org.thymeleaf.exceptions.ConfigurationException;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ import org.thymeleaf.templateresource.ITemplateResource;
/*     */ import org.thymeleaf.templateresource.StringTemplateResource;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StringTemplateResolver
/*     */   extends AbstractTemplateResolver
/*     */ {
/*  69 */   public static final TemplateMode DEFAULT_TEMPLATE_MODE = TemplateMode.HTML;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final boolean DEFAULT_CACHEABLE = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  84 */   public static final Long DEFAULT_CACHE_TTL_MS = null;
/*     */   
/*     */ 
/*     */ 
/*  88 */   private TemplateMode templateMode = DEFAULT_TEMPLATE_MODE;
/*  89 */   private boolean cacheable = false;
/*  90 */   private Long cacheTTLMs = DEFAULT_CACHE_TTL_MS;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final TemplateMode getTemplateMode()
/*     */   {
/* 117 */     return this.templateMode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setTemplateMode(TemplateMode templateMode)
/*     */   {
/* 129 */     Validate.notNull(templateMode, "Cannot set a null template mode value");
/*     */     
/* 131 */     this.templateMode = TemplateMode.parse(templateMode.toString());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setTemplateMode(String templateMode)
/*     */   {
/* 149 */     Validate.notNull(templateMode, "Cannot set a null template mode value");
/* 150 */     this.templateMode = TemplateMode.parse(templateMode);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean isCacheable()
/*     */   {
/* 163 */     return this.cacheable;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setCacheable(boolean cacheable)
/*     */   {
/* 175 */     this.cacheable = cacheable;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final Long getCacheTTLMs()
/*     */   {
/* 193 */     return this.cacheTTLMs;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setCacheTTLMs(Long cacheTTLMs)
/*     */   {
/* 210 */     this.cacheTTLMs = cacheTTLMs;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setUseDecoupledLogic(boolean useDecoupledLogic)
/*     */   {
/* 217 */     if (useDecoupledLogic) {
/* 218 */       throw new ConfigurationException("The 'useDecoupledLogic' flag is not allowed for String template resolution");
/*     */     }
/* 220 */     super.setUseDecoupledLogic(useDecoupledLogic);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ITemplateResource computeTemplateResource(IEngineConfiguration configuration, String ownerTemplate, String template, Map<String, Object> templateResolutionAttributes)
/*     */   {
/* 228 */     return new StringTemplateResource(template);
/*     */   }
/*     */   
/*     */ 
/*     */   protected TemplateMode computeTemplateMode(IEngineConfiguration configuration, String ownerTemplate, String template, Map<String, Object> templateResolutionAttributes)
/*     */   {
/* 234 */     return this.templateMode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected ICacheEntryValidity computeValidity(IEngineConfiguration configuration, String ownerTemplate, String template, Map<String, Object> templateResolutionAttributes)
/*     */   {
/* 241 */     if (isCacheable()) {
/* 242 */       if (this.cacheTTLMs != null) {
/* 243 */         return new TTLCacheEntryValidity(this.cacheTTLMs.longValue());
/*     */       }
/* 245 */       return AlwaysValidCacheEntryValidity.INSTANCE;
/*     */     }
/* 247 */     return NonCacheableCacheEntryValidity.INSTANCE;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\templateresolver\StringTemplateResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */