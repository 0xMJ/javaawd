/*     */ package org.thymeleaf.templateresolver;
/*     */ 
/*     */ import java.util.Map;
/*     */ import org.thymeleaf.IEngineConfiguration;
/*     */ import org.thymeleaf.cache.AlwaysValidCacheEntryValidity;
/*     */ import org.thymeleaf.cache.ICacheEntryValidity;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ import org.thymeleaf.templateresource.ITemplateResource;
/*     */ import org.thymeleaf.templateresource.StringTemplateResource;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultTemplateResolver
/*     */   extends AbstractTemplateResolver
/*     */ {
/*  58 */   public static final TemplateMode DEFAULT_TEMPLATE_MODE = TemplateMode.HTML;
/*     */   
/*     */ 
/*     */ 
/*  62 */   private TemplateMode templateMode = DEFAULT_TEMPLATE_MODE;
/*  63 */   private String template = "";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final TemplateMode getTemplateMode()
/*     */   {
/*  90 */     return this.templateMode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setTemplateMode(TemplateMode templateMode)
/*     */   {
/* 102 */     Validate.notNull(templateMode, "Cannot set a null template mode value");
/*     */     
/* 104 */     this.templateMode = TemplateMode.parse(templateMode.toString());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setTemplateMode(String templateMode)
/*     */   {
/* 122 */     Validate.notNull(templateMode, "Cannot set a null template mode value");
/* 123 */     this.templateMode = TemplateMode.parse(templateMode);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getTemplate()
/*     */   {
/* 135 */     return this.template;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTemplate(String template)
/*     */   {
/* 147 */     this.template = template;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ITemplateResource computeTemplateResource(IEngineConfiguration configuration, String ownerTemplate, String template, Map<String, Object> templateResolutionAttributes)
/*     */   {
/* 155 */     return new StringTemplateResource(this.template);
/*     */   }
/*     */   
/*     */ 
/*     */   protected TemplateMode computeTemplateMode(IEngineConfiguration configuration, String ownerTemplate, String template, Map<String, Object> templateResolutionAttributes)
/*     */   {
/* 161 */     return this.templateMode;
/*     */   }
/*     */   
/*     */ 
/*     */   protected ICacheEntryValidity computeValidity(IEngineConfiguration configuration, String ownerTemplate, String template, Map<String, Object> templateResolutionAttributes)
/*     */   {
/* 167 */     return AlwaysValidCacheEntryValidity.INSTANCE;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\templateresolver\DefaultTemplateResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */