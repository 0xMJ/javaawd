/*    */ package org.thymeleaf.templateresolver;
/*    */ 
/*    */ import java.net.MalformedURLException;
/*    */ import java.util.Map;
/*    */ import java.util.regex.Matcher;
/*    */ import java.util.regex.Pattern;
/*    */ import org.thymeleaf.IEngineConfiguration;
/*    */ import org.thymeleaf.cache.ICacheEntryValidity;
/*    */ import org.thymeleaf.cache.NonCacheableCacheEntryValidity;
/*    */ import org.thymeleaf.templateresource.ITemplateResource;
/*    */ import org.thymeleaf.templateresource.UrlTemplateResource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UrlTemplateResolver
/*    */   extends AbstractConfigurableTemplateResolver
/*    */ {
/* 48 */   private static final Pattern JSESSIONID_PATTERN = Pattern.compile("(.*?);jsessionid(.*?)");
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected ITemplateResource computeTemplateResource(IEngineConfiguration configuration, String ownerTemplate, String template, String resourceName, String characterEncoding, Map<String, Object> templateResolutionAttributes)
/*    */   {
/*    */     try
/*    */     {
/* 60 */       return new UrlTemplateResource(resourceName, characterEncoding);
/*    */     } catch (MalformedURLException ignored) {}
/* 62 */     return null;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected ICacheEntryValidity computeValidity(IEngineConfiguration configuration, String ownerTemplate, String template, Map<String, Object> templateResolutionAttributes)
/*    */   {
/* 77 */     if (JSESSIONID_PATTERN.matcher(template.toLowerCase()).matches()) {
/* 78 */       return NonCacheableCacheEntryValidity.INSTANCE;
/*    */     }
/* 80 */     return super.computeValidity(configuration, ownerTemplate, template, templateResolutionAttributes);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\templateresolver\UrlTemplateResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */