/*      */ package org.thymeleaf.templateresolver;
/*      */ 
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import org.thymeleaf.IEngineConfiguration;
/*      */ import org.thymeleaf.cache.AlwaysValidCacheEntryValidity;
/*      */ import org.thymeleaf.cache.ICacheEntryValidity;
/*      */ import org.thymeleaf.cache.NonCacheableCacheEntryValidity;
/*      */ import org.thymeleaf.cache.TTLCacheEntryValidity;
/*      */ import org.thymeleaf.templatemode.TemplateMode;
/*      */ import org.thymeleaf.templateresource.ITemplateResource;
/*      */ import org.thymeleaf.util.ContentTypeUtils;
/*      */ import org.thymeleaf.util.PatternSpec;
/*      */ import org.thymeleaf.util.StringUtils;
/*      */ import org.thymeleaf.util.Validate;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class AbstractConfigurableTemplateResolver
/*      */   extends AbstractTemplateResolver
/*      */ {
/*   69 */   public static final TemplateMode DEFAULT_TEMPLATE_MODE = TemplateMode.HTML;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final boolean DEFAULT_CACHEABLE = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   84 */   public static final Long DEFAULT_CACHE_TTL_MS = null;
/*      */   
/*      */ 
/*   87 */   private String prefix = null;
/*   88 */   private String suffix = null;
/*   89 */   private boolean forceSuffix = false;
/*   90 */   private String characterEncoding = null;
/*   91 */   private TemplateMode templateMode = DEFAULT_TEMPLATE_MODE;
/*   92 */   private boolean forceTemplateMode = false;
/*   93 */   private boolean cacheable = true;
/*   94 */   private Long cacheTTLMs = DEFAULT_CACHE_TTL_MS;
/*      */   
/*   96 */   private final HashMap<String, String> templateAliases = new HashMap(8);
/*      */   
/*   98 */   private final PatternSpec xmlTemplateModePatternSpec = new PatternSpec();
/*   99 */   private final PatternSpec htmlTemplateModePatternSpec = new PatternSpec();
/*  100 */   private final PatternSpec textTemplateModePatternSpec = new PatternSpec();
/*  101 */   private final PatternSpec javaScriptTemplateModePatternSpec = new PatternSpec();
/*  102 */   private final PatternSpec cssTemplateModePatternSpec = new PatternSpec();
/*  103 */   private final PatternSpec rawTemplateModePatternSpec = new PatternSpec();
/*      */   
/*  105 */   private final PatternSpec cacheablePatternSpec = new PatternSpec();
/*  106 */   private final PatternSpec nonCacheablePatternSpec = new PatternSpec();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final String getPrefix()
/*      */   {
/*  129 */     return this.prefix;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final void setPrefix(String prefix)
/*      */   {
/*  142 */     this.prefix = prefix;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final String getSuffix()
/*      */   {
/*  162 */     return this.suffix;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final void setSuffix(String suffix)
/*      */   {
/*  182 */     this.suffix = suffix;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final boolean getForceSuffix()
/*      */   {
/*  203 */     return this.forceSuffix;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final void setForceSuffix(boolean forceSuffix)
/*      */   {
/*  224 */     this.forceSuffix = forceSuffix;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final String getCharacterEncoding()
/*      */   {
/*  237 */     return this.characterEncoding;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final void setCharacterEncoding(String characterEncoding)
/*      */   {
/*  249 */     this.characterEncoding = characterEncoding;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final TemplateMode getTemplateMode()
/*      */   {
/*  274 */     return this.templateMode;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final void setTemplateMode(TemplateMode templateMode)
/*      */   {
/*  298 */     Validate.notNull(templateMode, "Cannot set a null template mode value");
/*      */     
/*  300 */     this.templateMode = TemplateMode.parse(templateMode.toString());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final void setTemplateMode(String templateMode)
/*      */   {
/*  330 */     Validate.notNull(templateMode, "Cannot set a null template mode value");
/*  331 */     this.templateMode = TemplateMode.parse(templateMode);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final boolean getForceTemplateMode()
/*      */   {
/*  353 */     return this.forceTemplateMode;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final void setForceTemplateMode(boolean forceTemplateMode)
/*      */   {
/*  375 */     this.forceTemplateMode = forceTemplateMode;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final boolean isCacheable()
/*      */   {
/*  393 */     return this.cacheable;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final void setCacheable(boolean cacheable)
/*      */   {
/*  410 */     this.cacheable = cacheable;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final Long getCacheTTLMs()
/*      */   {
/*  428 */     return this.cacheTTLMs;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final void setCacheTTLMs(Long cacheTTLMs)
/*      */   {
/*  445 */     this.cacheTTLMs = cacheTTLMs;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final Map<String, String> getTemplateAliases()
/*      */   {
/*  464 */     return Collections.unmodifiableMap(this.templateAliases);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final void setTemplateAliases(Map<String, String> templateAliases)
/*      */   {
/*  483 */     if (templateAliases != null) {
/*  484 */       this.templateAliases.putAll(templateAliases);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final void addTemplateAlias(String alias, String templateName)
/*      */   {
/*  498 */     Validate.notNull(alias, "Alias cannot be null");
/*  499 */     Validate.notNull(templateName, "Template name cannot be null");
/*  500 */     this.templateAliases.put(alias, templateName);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final void clearTemplateAliases()
/*      */   {
/*  510 */     this.templateAliases.clear();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final PatternSpec getXmlTemplateModePatternSpec()
/*      */   {
/*  526 */     return this.xmlTemplateModePatternSpec;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final Set<String> getXmlTemplateModePatterns()
/*      */   {
/*  541 */     return this.xmlTemplateModePatternSpec.getPatterns();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final void setXmlTemplateModePatterns(Set<String> newXmlTemplateModePatterns)
/*      */   {
/*  556 */     this.xmlTemplateModePatternSpec.setPatterns(newXmlTemplateModePatterns);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final PatternSpec getHtmlTemplateModePatternSpec()
/*      */   {
/*  572 */     return this.htmlTemplateModePatternSpec;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final Set<String> getHtmlTemplateModePatterns()
/*      */   {
/*  588 */     return this.htmlTemplateModePatternSpec.getPatterns();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final void setHtmlTemplateModePatterns(Set<String> newHtmlTemplateModePatterns)
/*      */   {
/*  604 */     this.htmlTemplateModePatternSpec.setPatterns(newHtmlTemplateModePatterns);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final PatternSpec getJavaScriptTemplateModePatternSpec()
/*      */   {
/*  620 */     return this.javaScriptTemplateModePatternSpec;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final Set<String> getJavaScriptTemplateModePatterns()
/*      */   {
/*  636 */     return this.javaScriptTemplateModePatternSpec.getPatterns();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final void setJavaScriptTemplateModePatterns(Set<String> newJavaScriptTemplateModePatterns)
/*      */   {
/*  652 */     this.javaScriptTemplateModePatternSpec.setPatterns(newJavaScriptTemplateModePatterns);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final PatternSpec getCSSTemplateModePatternSpec()
/*      */   {
/*  668 */     return this.cssTemplateModePatternSpec;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final Set<String> getCSSTemplateModePatterns()
/*      */   {
/*  684 */     return this.cssTemplateModePatternSpec.getPatterns();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final void setCSSTemplateModePatterns(Set<String> newCSSTemplateModePatterns)
/*      */   {
/*  700 */     this.cssTemplateModePatternSpec.setPatterns(newCSSTemplateModePatterns);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final PatternSpec getRawTemplateModePatternSpec()
/*      */   {
/*  716 */     return this.rawTemplateModePatternSpec;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final Set<String> getRawTemplateModePatterns()
/*      */   {
/*  732 */     return this.rawTemplateModePatternSpec.getPatterns();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final void setRawTemplateModePatterns(Set<String> newRawTemplateModePatterns)
/*      */   {
/*  748 */     this.rawTemplateModePatternSpec.setPatterns(newRawTemplateModePatterns);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final PatternSpec getTextTemplateModePatternSpec()
/*      */   {
/*  764 */     return this.textTemplateModePatternSpec;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final Set<String> getTextTemplateModePatterns()
/*      */   {
/*  780 */     return this.textTemplateModePatternSpec.getPatterns();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final void setTextTemplateModePatterns(Set<String> newTextTemplateModePatterns)
/*      */   {
/*  796 */     this.textTemplateModePatternSpec.setPatterns(newTextTemplateModePatterns);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public final PatternSpec getValidXmlTemplateModePatternSpec()
/*      */   {
/*  816 */     return this.xmlTemplateModePatternSpec;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public final Set<String> getValidXmlTemplateModePatterns()
/*      */   {
/*  835 */     return this.xmlTemplateModePatternSpec.getPatterns();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public final void setValidXmlTemplateModePatterns(Set<String> newValidXmlTemplateModePatterns)
/*      */   {
/*  854 */     this.xmlTemplateModePatternSpec.setPatterns(newValidXmlTemplateModePatterns);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public final PatternSpec getXhtmlTemplateModePatternSpec()
/*      */   {
/*  875 */     return this.htmlTemplateModePatternSpec;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public final Set<String> getXhtmlTemplateModePatterns()
/*      */   {
/*  894 */     return this.htmlTemplateModePatternSpec.getPatterns();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public final void setXhtmlTemplateModePatterns(Set<String> newXhtmlTemplateModePatterns)
/*      */   {
/*  913 */     this.htmlTemplateModePatternSpec.setPatterns(newXhtmlTemplateModePatterns);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public final PatternSpec getValidXhtmlTemplateModePatternSpec()
/*      */   {
/*  935 */     return this.htmlTemplateModePatternSpec;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public final Set<String> getValidXhtmlTemplateModePatterns()
/*      */   {
/*  954 */     return this.htmlTemplateModePatternSpec.getPatterns();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public final void setValidXhtmlTemplateModePatterns(Set<String> newValidXhtmlTemplateModePatterns)
/*      */   {
/*  973 */     this.htmlTemplateModePatternSpec.setPatterns(newValidXhtmlTemplateModePatterns);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public final PatternSpec getLegacyHtml5TemplateModePatternSpec()
/*      */   {
/*  996 */     return this.htmlTemplateModePatternSpec;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public final Set<String> getLegacyHtml5TemplateModePatterns()
/*      */   {
/* 1015 */     return this.htmlTemplateModePatternSpec.getPatterns();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public final void setLegacyHtml5TemplateModePatterns(Set<String> newLegacyHtml5TemplateModePatterns)
/*      */   {
/* 1034 */     this.htmlTemplateModePatternSpec.setPatterns(newLegacyHtml5TemplateModePatterns);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public final PatternSpec getHtml5TemplateModePatternSpec()
/*      */   {
/* 1055 */     return this.htmlTemplateModePatternSpec;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public final Set<String> getHtml5TemplateModePatterns()
/*      */   {
/* 1074 */     return this.htmlTemplateModePatternSpec.getPatterns();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public final void setHtml5TemplateModePatterns(Set<String> newHtml5TemplateModePatterns)
/*      */   {
/* 1093 */     this.htmlTemplateModePatternSpec.setPatterns(newHtml5TemplateModePatterns);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final PatternSpec getCacheablePatternSpec()
/*      */   {
/* 1115 */     return this.cacheablePatternSpec;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final Set<String> getCacheablePatterns()
/*      */   {
/* 1136 */     return this.cacheablePatternSpec.getPatterns();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final void setCacheablePatterns(Set<String> cacheablePatterns)
/*      */   {
/* 1157 */     this.cacheablePatternSpec.setPatterns(cacheablePatterns);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final PatternSpec getNonCacheablePatternSpec()
/*      */   {
/* 1179 */     return this.nonCacheablePatternSpec;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final Set<String> getNonCacheablePatterns()
/*      */   {
/* 1200 */     return this.nonCacheablePatternSpec.getPatterns();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final void setNonCacheablePatterns(Set<String> nonCacheablePatterns)
/*      */   {
/* 1221 */     this.nonCacheablePatternSpec.setPatterns(nonCacheablePatterns);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   protected String computeResourceName(IEngineConfiguration configuration, String ownerTemplate, String template, String prefix, String suffix, Map<String, String> templateAliases, Map<String, Object> templateResolutionAttributes)
/*      */   {
/* 1261 */     return computeResourceName(configuration, ownerTemplate, template, prefix, suffix, false, templateAliases, templateResolutionAttributes);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String computeResourceName(IEngineConfiguration configuration, String ownerTemplate, String template, String prefix, String suffix, boolean forceSuffix, Map<String, String> templateAliases, Map<String, Object> templateResolutionAttributes)
/*      */   {
/* 1303 */     Validate.notNull(template, "Template name cannot be null");
/*      */     
/* 1305 */     String unaliasedName = (String)templateAliases.get(template);
/* 1306 */     if (unaliasedName == null) {
/* 1307 */       unaliasedName = template;
/*      */     }
/*      */     
/* 1310 */     boolean hasPrefix = !StringUtils.isEmptyOrWhitespace(prefix);
/* 1311 */     boolean hasSuffix = !StringUtils.isEmptyOrWhitespace(suffix);
/*      */     
/*      */ 
/* 1314 */     boolean shouldApplySuffix = (hasSuffix) && ((forceSuffix) || (!ContentTypeUtils.hasRecognizedFileExtension(unaliasedName)));
/*      */     
/* 1316 */     if ((!hasPrefix) && (!shouldApplySuffix)) {
/* 1317 */       return unaliasedName;
/*      */     }
/*      */     
/* 1320 */     if (!hasPrefix) {
/* 1321 */       return unaliasedName + suffix;
/*      */     }
/*      */     
/* 1324 */     if (!shouldApplySuffix) {
/* 1325 */       return prefix + unaliasedName;
/*      */     }
/*      */     
/*      */ 
/* 1329 */     return prefix + unaliasedName + suffix;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected TemplateMode computeTemplateMode(IEngineConfiguration configuration, String ownerTemplate, String template, Map<String, Object> templateResolutionAttributes)
/*      */   {
/* 1342 */     if (this.xmlTemplateModePatternSpec.matches(template)) {
/* 1343 */       return TemplateMode.XML;
/*      */     }
/* 1345 */     if (this.htmlTemplateModePatternSpec.matches(template)) {
/* 1346 */       return TemplateMode.HTML;
/*      */     }
/* 1348 */     if (this.textTemplateModePatternSpec.matches(template)) {
/* 1349 */       return TemplateMode.TEXT;
/*      */     }
/* 1351 */     if (this.javaScriptTemplateModePatternSpec.matches(template)) {
/* 1352 */       return TemplateMode.JAVASCRIPT;
/*      */     }
/* 1354 */     if (this.cssTemplateModePatternSpec.matches(template)) {
/* 1355 */       return TemplateMode.CSS;
/*      */     }
/* 1357 */     if (this.rawTemplateModePatternSpec.matches(template)) {
/* 1358 */       return TemplateMode.RAW;
/*      */     }
/*      */     
/* 1361 */     if (!this.forceTemplateMode)
/*      */     {
/*      */ 
/* 1364 */       String templateResourceName = computeResourceName(configuration, ownerTemplate, template, this.prefix, this.suffix, this.forceSuffix, this.templateAliases, templateResolutionAttributes);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1370 */       TemplateMode autoResolvedTemplateMode = ContentTypeUtils.computeTemplateModeForTemplateName(templateResourceName);
/* 1371 */       if (autoResolvedTemplateMode != null) {
/* 1372 */         return autoResolvedTemplateMode;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1377 */     return getTemplateMode();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected ICacheEntryValidity computeValidity(IEngineConfiguration configuration, String ownerTemplate, String template, Map<String, Object> templateResolutionAttributes)
/*      */   {
/* 1387 */     if (this.cacheablePatternSpec.matches(template)) {
/* 1388 */       if (this.cacheTTLMs != null) {
/* 1389 */         return new TTLCacheEntryValidity(this.cacheTTLMs.longValue());
/*      */       }
/* 1391 */       return AlwaysValidCacheEntryValidity.INSTANCE;
/*      */     }
/* 1393 */     if (this.nonCacheablePatternSpec.matches(template)) {
/* 1394 */       return NonCacheableCacheEntryValidity.INSTANCE;
/*      */     }
/*      */     
/* 1397 */     if (isCacheable()) {
/* 1398 */       if (this.cacheTTLMs != null) {
/* 1399 */         return new TTLCacheEntryValidity(this.cacheTTLMs.longValue());
/*      */       }
/* 1401 */       return AlwaysValidCacheEntryValidity.INSTANCE;
/*      */     }
/* 1403 */     return NonCacheableCacheEntryValidity.INSTANCE;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final ITemplateResource computeTemplateResource(IEngineConfiguration configuration, String ownerTemplate, String template, Map<String, Object> templateResolutionAttributes)
/*      */   {
/* 1413 */     String resourceName = computeResourceName(configuration, ownerTemplate, template, this.prefix, this.suffix, this.forceSuffix, this.templateAliases, templateResolutionAttributes);
/* 1414 */     return computeTemplateResource(configuration, ownerTemplate, template, resourceName, this.characterEncoding, templateResolutionAttributes);
/*      */   }
/*      */   
/*      */   protected abstract ITemplateResource computeTemplateResource(IEngineConfiguration paramIEngineConfiguration, String paramString1, String paramString2, String paramString3, String paramString4, Map<String, Object> paramMap);
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\templateresolver\AbstractConfigurableTemplateResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */