/*     */ package org.thymeleaf.templateresolver;
/*     */ 
/*     */ import org.thymeleaf.cache.ICacheEntryValidity;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ import org.thymeleaf.templateresource.ITemplateResource;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class TemplateResolution
/*     */ {
/*     */   private final ITemplateResource templateResource;
/*     */   private final boolean templateResourceExistenceVerified;
/*     */   private final TemplateMode templateMode;
/*     */   private final boolean useDecoupledLogic;
/*     */   private final ICacheEntryValidity validity;
/*     */   
/*     */   public TemplateResolution(ITemplateResource templateResource, TemplateMode templateMode, ICacheEntryValidity validity)
/*     */   {
/*  71 */     this(templateResource, false, templateMode, false, validity);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TemplateResolution(ITemplateResource templateResource, boolean templateResourceExistenceVerified, TemplateMode templateMode, boolean useDecoupledLogic, ICacheEntryValidity validity)
/*     */   {
/*  82 */     Validate.notNull(templateResource, "Template Resource cannot be null");
/*  83 */     Validate.notNull(templateMode, "Template mode cannot be null");
/*  84 */     Validate.notNull(validity, "Validity cannot be null");
/*  85 */     this.templateResource = templateResource;
/*  86 */     this.templateResourceExistenceVerified = templateResourceExistenceVerified;
/*  87 */     this.templateMode = templateMode;
/*  88 */     this.useDecoupledLogic = useDecoupledLogic;
/*  89 */     this.validity = validity;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ITemplateResource getTemplateResource()
/*     */   {
/* 111 */     return this.templateResource;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TemplateMode getTemplateMode()
/*     */   {
/* 128 */     return this.templateMode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isTemplateResourceExistenceVerified()
/*     */   {
/* 149 */     return this.templateResourceExistenceVerified;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getUseDecoupledLogic()
/*     */   {
/* 166 */     return this.useDecoupledLogic;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ICacheEntryValidity getValidity()
/*     */   {
/* 186 */     return this.validity;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\templateresolver\TemplateResolution.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */