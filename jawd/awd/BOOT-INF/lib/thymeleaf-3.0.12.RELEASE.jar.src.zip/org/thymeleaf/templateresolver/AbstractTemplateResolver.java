/*     */ package org.thymeleaf.templateresolver;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.thymeleaf.IEngineConfiguration;
/*     */ import org.thymeleaf.cache.ICacheEntryValidity;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ import org.thymeleaf.templateresource.ITemplateResource;
/*     */ import org.thymeleaf.util.PatternSpec;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractTemplateResolver
/*     */   implements ITemplateResolver
/*     */ {
/*     */   public static final boolean DEFAULT_EXISTENCE_CHECK = false;
/*     */   public static final boolean DEFAULT_USE_DECOUPLED_LOGIC = false;
/*  66 */   private String name = getClass().getName();
/*  67 */   private Integer order = null;
/*  68 */   private boolean checkExistence = false;
/*  69 */   private boolean useDecoupledLogic = false;
/*     */   
/*  71 */   private final PatternSpec resolvablePatternSpec = new PatternSpec();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final String getName()
/*     */   {
/*  90 */     return this.name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setName(String name)
/*     */   {
/* 102 */     this.name = name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final Integer getOrder()
/*     */   {
/* 118 */     return this.order;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOrder(Integer order)
/*     */   {
/* 130 */     this.order = order;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final PatternSpec getResolvablePatternSpec()
/*     */   {
/* 151 */     return this.resolvablePatternSpec;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final Set<String> getResolvablePatterns()
/*     */   {
/* 172 */     return this.resolvablePatternSpec.getPatterns();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setResolvablePatterns(Set<String> resolvablePatterns)
/*     */   {
/* 193 */     this.resolvablePatternSpec.setPatterns(resolvablePatterns);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean getCheckExistence()
/*     */   {
/* 229 */     return this.checkExistence;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCheckExistence(boolean checkExistence)
/*     */   {
/* 264 */     this.checkExistence = checkExistence;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean getUseDecoupledLogic()
/*     */   {
/* 300 */     return this.useDecoupledLogic;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUseDecoupledLogic(boolean useDecoupledLogic)
/*     */   {
/* 336 */     this.useDecoupledLogic = useDecoupledLogic;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final TemplateResolution resolveTemplate(IEngineConfiguration configuration, String ownerTemplate, String template, Map<String, Object> templateResolutionAttributes)
/*     */   {
/* 347 */     Validate.notNull(configuration, "Engine Configuration cannot be null");
/*     */     
/* 349 */     Validate.notNull(template, "Template Name cannot be null");
/*     */     
/*     */ 
/* 352 */     if (!computeResolvable(configuration, ownerTemplate, template, templateResolutionAttributes)) {
/* 353 */       return null;
/*     */     }
/*     */     
/* 356 */     ITemplateResource templateResource = computeTemplateResource(configuration, ownerTemplate, template, templateResolutionAttributes);
/* 357 */     if (templateResource == null) {
/* 358 */       return null;
/*     */     }
/*     */     
/* 361 */     if ((this.checkExistence) && (!templateResource.exists())) {
/* 362 */       return null;
/*     */     }
/*     */     
/* 365 */     return new TemplateResolution(templateResource, this.checkExistence, 
/*     */     
/*     */ 
/* 368 */       computeTemplateMode(configuration, ownerTemplate, template, templateResolutionAttributes), this.useDecoupledLogic, 
/*     */       
/* 370 */       computeValidity(configuration, ownerTemplate, template, templateResolutionAttributes));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean computeResolvable(IEngineConfiguration configuration, String ownerTemplate, String template, Map<String, Object> templateResolutionAttributes)
/*     */   {
/* 391 */     if (this.resolvablePatternSpec.isEmpty()) {
/* 392 */       return true;
/*     */     }
/* 394 */     return this.resolvablePatternSpec.matches(template);
/*     */   }
/*     */   
/*     */   protected abstract ITemplateResource computeTemplateResource(IEngineConfiguration paramIEngineConfiguration, String paramString1, String paramString2, Map<String, Object> paramMap);
/*     */   
/*     */   protected abstract TemplateMode computeTemplateMode(IEngineConfiguration paramIEngineConfiguration, String paramString1, String paramString2, Map<String, Object> paramMap);
/*     */   
/*     */   protected abstract ICacheEntryValidity computeValidity(IEngineConfiguration paramIEngineConfiguration, String paramString1, String paramString2, Map<String, Object> paramMap);
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\templateresolver\AbstractTemplateResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */