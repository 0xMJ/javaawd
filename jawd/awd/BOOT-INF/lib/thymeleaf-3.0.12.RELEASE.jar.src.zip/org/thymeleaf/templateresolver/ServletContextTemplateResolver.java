/*    */ package org.thymeleaf.templateresolver;
/*    */ 
/*    */ import java.util.Map;
/*    */ import javax.servlet.ServletContext;
/*    */ import org.thymeleaf.IEngineConfiguration;
/*    */ import org.thymeleaf.templateresource.ITemplateResource;
/*    */ import org.thymeleaf.templateresource.ServletContextTemplateResource;
/*    */ import org.thymeleaf.util.Validate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ServletContextTemplateResolver
/*    */   extends AbstractConfigurableTemplateResolver
/*    */ {
/*    */   private final ServletContext servletContext;
/*    */   
/*    */   public ServletContextTemplateResolver(ServletContext servletContext)
/*    */   {
/* 54 */     Validate.notNull(servletContext, "ServletContext cannot be null");
/* 55 */     this.servletContext = servletContext;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   protected ITemplateResource computeTemplateResource(IEngineConfiguration configuration, String ownerTemplate, String template, String resourceName, String characterEncoding, Map<String, Object> templateResolutionAttributes)
/*    */   {
/* 62 */     return new ServletContextTemplateResource(this.servletContext, resourceName, characterEncoding);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\templateresolver\ServletContextTemplateResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */