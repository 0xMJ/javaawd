package org.thymeleaf.preprocessor;

import org.thymeleaf.engine.ITemplateHandler;
import org.thymeleaf.templatemode.TemplateMode;

public abstract interface IPreProcessor
{
  public abstract TemplateMode getTemplateMode();
  
  public abstract int getPrecedence();
  
  public abstract Class<? extends ITemplateHandler> getHandlerClass();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\preprocessor\IPreProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */