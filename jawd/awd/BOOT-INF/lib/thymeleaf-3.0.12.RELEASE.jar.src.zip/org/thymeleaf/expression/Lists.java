/*    */ package org.thymeleaf.expression;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.Comparator;
/*    */ import java.util.List;
/*    */ import org.thymeleaf.util.ListUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Lists
/*    */ {
/*    */   public List<?> toList(Object target)
/*    */   {
/* 47 */     return ListUtils.toList(target);
/*    */   }
/*    */   
/*    */   public int size(List<?> target)
/*    */   {
/* 52 */     return ListUtils.size(target);
/*    */   }
/*    */   
/*    */   public boolean isEmpty(List<?> target)
/*    */   {
/* 57 */     return ListUtils.isEmpty(target);
/*    */   }
/*    */   
/*    */   public boolean contains(List<?> target, Object element)
/*    */   {
/* 62 */     return ListUtils.contains(target, element);
/*    */   }
/*    */   
/*    */   public boolean containsAll(List<?> target, Object[] elements)
/*    */   {
/* 67 */     return ListUtils.containsAll(target, elements);
/*    */   }
/*    */   
/*    */   public boolean containsAll(List<?> target, Collection<?> elements)
/*    */   {
/* 72 */     return ListUtils.containsAll(target, elements);
/*    */   }
/*    */   
/*    */   public <T extends Comparable<? super T>> List<T> sort(List<T> list)
/*    */   {
/* 77 */     return ListUtils.sort(list);
/*    */   }
/*    */   
/*    */   public <T> List<T> sort(List<T> list, Comparator<? super T> c) {
/* 81 */     return ListUtils.sort(list, c);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\expression\Lists.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */