/*     */ package org.thymeleaf.expression;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.thymeleaf.util.EvaluationUtils;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Bools
/*     */ {
/*     */   public Boolean isTrue(Object target)
/*     */   {
/*  57 */     return Boolean.valueOf(EvaluationUtils.evaluateAsBoolean(target));
/*     */   }
/*     */   
/*     */   public Boolean[] arrayIsTrue(Object[] target)
/*     */   {
/*  62 */     Validate.notNull(target, "Target cannot be null");
/*  63 */     Boolean[] result = new Boolean[target.length];
/*  64 */     for (int i = 0; i < target.length; i++) {
/*  65 */       result[i] = isTrue(target[i]);
/*     */     }
/*  67 */     return result;
/*     */   }
/*     */   
/*     */   public List<Boolean> listIsTrue(List<?> target) {
/*  71 */     Validate.notNull(target, "Target cannot be null");
/*  72 */     List<Boolean> result = new ArrayList(target.size() + 2);
/*  73 */     for (Object element : target) {
/*  74 */       result.add(isTrue(element));
/*     */     }
/*  76 */     return result;
/*     */   }
/*     */   
/*     */   public Set<Boolean> setIsTrue(Set<?> target) {
/*  80 */     Validate.notNull(target, "Target cannot be null");
/*  81 */     Set<Boolean> result = new LinkedHashSet(target.size() + 2);
/*  82 */     for (Object element : target) {
/*  83 */       result.add(isTrue(element));
/*     */     }
/*  85 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Boolean isFalse(Object target)
/*     */   {
/*  92 */     return Boolean.valueOf(!EvaluationUtils.evaluateAsBoolean(target));
/*     */   }
/*     */   
/*     */   public Boolean[] arrayIsFalse(Object[] target) {
/*  96 */     Validate.notNull(target, "Target cannot be null");
/*  97 */     Boolean[] result = new Boolean[target.length];
/*  98 */     for (int i = 0; i < target.length; i++) {
/*  99 */       result[i] = isFalse(target[i]);
/*     */     }
/* 101 */     return result;
/*     */   }
/*     */   
/*     */   public List<Boolean> listIsFalse(List<?> target) {
/* 105 */     Validate.notNull(target, "Target cannot be null");
/* 106 */     List<Boolean> result = new ArrayList(target.size() + 2);
/* 107 */     for (Object element : target) {
/* 108 */       result.add(isFalse(element));
/*     */     }
/* 110 */     return result;
/*     */   }
/*     */   
/*     */   public Set<Boolean> setIsFalse(Set<?> target) {
/* 114 */     Validate.notNull(target, "Target cannot be null");
/* 115 */     Set<Boolean> result = new LinkedHashSet(target.size() + 2);
/* 116 */     for (Object element : target) {
/* 117 */       result.add(isFalse(element));
/*     */     }
/* 119 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Boolean arrayAnd(Object[] target)
/*     */   {
/* 128 */     Validate.notNull(target, "Target cannot be null");
/* 129 */     for (Object aTarget : target) {
/* 130 */       if (!isTrue(aTarget).booleanValue()) {
/* 131 */         return Boolean.FALSE;
/*     */       }
/*     */     }
/* 134 */     return Boolean.TRUE;
/*     */   }
/*     */   
/*     */   public Boolean listAnd(List<?> target) {
/* 138 */     Validate.notNull(target, "Target cannot be null");
/* 139 */     for (Object element : target) {
/* 140 */       if (!isTrue(element).booleanValue()) {
/* 141 */         return Boolean.FALSE;
/*     */       }
/*     */     }
/* 144 */     return Boolean.TRUE;
/*     */   }
/*     */   
/*     */   public Boolean setAnd(Set<?> target) {
/* 148 */     Validate.notNull(target, "Target cannot be null");
/* 149 */     for (Object element : target) {
/* 150 */       if (!isTrue(element).booleanValue()) {
/* 151 */         return Boolean.FALSE;
/*     */       }
/*     */     }
/* 154 */     return Boolean.TRUE;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Boolean arrayOr(Object[] target)
/*     */   {
/* 162 */     Validate.notNull(target, "Target cannot be null");
/* 163 */     for (Object aTarget : target) {
/* 164 */       if (isTrue(aTarget).booleanValue()) {
/* 165 */         return Boolean.TRUE;
/*     */       }
/*     */     }
/* 168 */     return Boolean.FALSE;
/*     */   }
/*     */   
/*     */   public Boolean listOr(List<?> target) {
/* 172 */     Validate.notNull(target, "Target cannot be null");
/* 173 */     for (Object element : target) {
/* 174 */       if (isTrue(element).booleanValue()) {
/* 175 */         return Boolean.TRUE;
/*     */       }
/*     */     }
/* 178 */     return Boolean.FALSE;
/*     */   }
/*     */   
/*     */   public Boolean setOr(Set<?> target) {
/* 182 */     Validate.notNull(target, "Target cannot be null");
/* 183 */     for (Object element : target) {
/* 184 */       if (isTrue(element).booleanValue()) {
/* 185 */         return Boolean.TRUE;
/*     */       }
/*     */     }
/* 188 */     return Boolean.FALSE;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\expression\Bools.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */