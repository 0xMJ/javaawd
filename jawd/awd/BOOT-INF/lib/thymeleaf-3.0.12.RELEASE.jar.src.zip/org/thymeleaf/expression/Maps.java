/*    */ package org.thymeleaf.expression;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.Map;
/*    */ import org.thymeleaf.util.MapUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Maps
/*    */ {
/*    */   public int size(Map<?, ?> target)
/*    */   {
/* 46 */     return MapUtils.size(target);
/*    */   }
/*    */   
/*    */   public boolean isEmpty(Map<?, ?> target)
/*    */   {
/* 51 */     return MapUtils.isEmpty(target);
/*    */   }
/*    */   
/*    */   public <X> boolean containsKey(Map<? super X, ?> target, X key)
/*    */   {
/* 56 */     return MapUtils.containsKey(target, key);
/*    */   }
/*    */   
/*    */   public <X> boolean containsValue(Map<?, ? super X> target, X value) {
/* 60 */     return MapUtils.containsValue(target, value);
/*    */   }
/*    */   
/*    */   public <X> boolean containsAllKeys(Map<? super X, ?> target, X[] keys)
/*    */   {
/* 65 */     return MapUtils.containsAllKeys(target, keys);
/*    */   }
/*    */   
/*    */   public <X> boolean containsAllKeys(Map<? super X, ?> target, Collection<X> keys)
/*    */   {
/* 70 */     return MapUtils.containsAllKeys(target, keys);
/*    */   }
/*    */   
/*    */   public <X> boolean containsAllValues(Map<?, ? super X> target, X[] values)
/*    */   {
/* 75 */     return MapUtils.containsAllValues(target, values);
/*    */   }
/*    */   
/*    */   public <X> boolean containsAllValues(Map<?, ? super X> target, Collection<X> values)
/*    */   {
/* 80 */     return MapUtils.containsAllValues(target, values);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\expression\Maps.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */