/*     */ package org.thymeleaf.expression;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.thymeleaf.context.IExpressionContext;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExpressionObjects
/*     */   implements IExpressionObjects
/*     */ {
/*     */   private static final int EXPRESSION_OBJECT_MAP_DEFAULT_SIZE = 3;
/*     */   private final IExpressionContext context;
/*     */   private final IExpressionObjectFactory expressionObjectFactory;
/*     */   private final Set<String> expressionObjectNames;
/*     */   private Map<String, Object> objects;
/*     */   
/*     */   public ExpressionObjects(IExpressionContext context, IExpressionObjectFactory expressionObjectFactory)
/*     */   {
/*  62 */     Validate.notNull(context, "Context cannot be null");
/*  63 */     Validate.notNull(expressionObjectFactory, "Expression Object Factory cannot be null");
/*     */     
/*  65 */     this.context = context;
/*  66 */     this.expressionObjectFactory = expressionObjectFactory;
/*  67 */     this.expressionObjectNames = this.expressionObjectFactory.getAllExpressionObjectNames();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int size()
/*     */   {
/*  75 */     return this.expressionObjectNames.size();
/*     */   }
/*     */   
/*     */   public boolean containsObject(String name)
/*     */   {
/*  80 */     return this.expressionObjectNames.contains(name);
/*     */   }
/*     */   
/*     */   public Set<String> getObjectNames()
/*     */   {
/*  85 */     return this.expressionObjectNames;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getObject(String name)
/*     */   {
/*  94 */     if ((this.objects != null) && (this.objects.containsKey(name))) {
/*  95 */       return this.objects.get(name);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 101 */     if (!this.expressionObjectNames.contains(name)) {
/* 102 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 108 */     Object object = this.expressionObjectFactory.buildObject(this.context, name);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 113 */     if (!this.expressionObjectFactory.isCacheable(name)) {
/* 114 */       return object;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 121 */     if (this.objects == null) {
/* 122 */       this.objects = new HashMap(3);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 128 */     this.objects.put(name, object);
/* 129 */     return object;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\expression\ExpressionObjects.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */