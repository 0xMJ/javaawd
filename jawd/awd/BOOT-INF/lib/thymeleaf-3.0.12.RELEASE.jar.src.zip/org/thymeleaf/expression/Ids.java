/*    */ package org.thymeleaf.expression;
/*    */ 
/*    */ import org.thymeleaf.context.ITemplateContext;
/*    */ import org.thymeleaf.context.IdentifierSequences;
/*    */ import org.thymeleaf.util.Validate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Ids
/*    */ {
/*    */   private final ITemplateContext context;
/*    */   
/*    */   public String seq(Object id)
/*    */   {
/* 47 */     Validate.notNull(id, "ID cannot be null");
/* 48 */     String str = id.toString();
/* 49 */     return str + this.context.getIdentifierSequences().getAndIncrementIDSeq(str);
/*    */   }
/*    */   
/*    */   public String next(Object id) {
/* 53 */     Validate.notNull(id, "ID cannot be null");
/* 54 */     String str = id.toString();
/* 55 */     return str + this.context.getIdentifierSequences().getNextIDSeq(str);
/*    */   }
/*    */   
/*    */   public String prev(Object id) {
/* 59 */     Validate.notNull(id, "ID cannot be null");
/* 60 */     String str = id.toString();
/* 61 */     return str + this.context.getIdentifierSequences().getPreviousIDSeq(str);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public Ids(ITemplateContext context)
/*    */   {
/* 68 */     Validate.notNull(context, "Context cannot be null");
/* 69 */     this.context = context;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\expression\Ids.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */