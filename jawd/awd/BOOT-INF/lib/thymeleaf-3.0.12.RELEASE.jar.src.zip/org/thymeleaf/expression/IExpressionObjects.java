package org.thymeleaf.expression;

import java.util.Set;

public abstract interface IExpressionObjects
{
  public abstract int size();
  
  public abstract boolean containsObject(String paramString);
  
  public abstract Set<String> getObjectNames();
  
  public abstract Object getObject(String paramString);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\expression\IExpressionObjects.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */