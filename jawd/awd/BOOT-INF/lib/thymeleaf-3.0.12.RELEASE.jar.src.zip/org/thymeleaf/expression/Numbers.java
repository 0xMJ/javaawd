/*     */ package org.thymeleaf.expression;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Set;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.util.NumberPointType;
/*     */ import org.thymeleaf.util.NumberUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Numbers
/*     */ {
/*     */   private final Locale locale;
/*     */   
/*     */   public Numbers(Locale locale)
/*     */   {
/*  55 */     this.locale = locale;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String formatInteger(Number target, Integer minIntegerDigits)
/*     */   {
/*  62 */     if (target == null) {
/*  63 */       return null;
/*     */     }
/*     */     try {
/*  66 */       return NumberUtils.format(target, minIntegerDigits, this.locale);
/*     */     } catch (Exception e) {
/*  68 */       throw new TemplateProcessingException("Error formatting integer with minimum integer digits = " + minIntegerDigits, e);
/*     */     }
/*     */   }
/*     */   
/*     */   public String[] arrayFormatInteger(Object[] target, Integer minIntegerDigits)
/*     */   {
/*  74 */     if (target == null) {
/*  75 */       return null;
/*     */     }
/*  77 */     String[] result = new String[target.length];
/*  78 */     for (int i = 0; i < target.length; i++) {
/*  79 */       result[i] = formatInteger((Number)target[i], minIntegerDigits);
/*     */     }
/*  81 */     return result;
/*     */   }
/*     */   
/*     */   public List<String> listFormatInteger(List<? extends Number> target, Integer minIntegerDigits) {
/*  85 */     if (target == null) {
/*  86 */       return null;
/*     */     }
/*  88 */     List<String> result = new ArrayList(target.size() + 2);
/*  89 */     for (Number element : target) {
/*  90 */       result.add(formatInteger(element, minIntegerDigits));
/*     */     }
/*  92 */     return result;
/*     */   }
/*     */   
/*     */   public Set<String> setFormatInteger(Set<? extends Number> target, Integer minIntegerDigits) {
/*  96 */     if (target == null) {
/*  97 */       return null;
/*     */     }
/*  99 */     Set<String> result = new LinkedHashSet(target.size() + 2);
/* 100 */     for (Number element : target) {
/* 101 */       result.add(formatInteger(element, minIntegerDigits));
/*     */     }
/* 103 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String formatInteger(Number target, Integer minIntegerDigits, String thousandsPointType)
/*     */   {
/* 110 */     if (target == null) {
/* 111 */       return null;
/*     */     }
/* 113 */     NumberPointType thousandsNumberPointType = NumberPointType.match(thousandsPointType);
/* 114 */     if (thousandsNumberPointType == null) {
/* 115 */       throw new TemplateProcessingException("Unrecognized point format \"" + thousandsPointType + "\"");
/*     */     }
/*     */     try
/*     */     {
/* 119 */       return NumberUtils.format(target, minIntegerDigits, thousandsNumberPointType, this.locale);
/*     */     } catch (Exception e) {
/* 121 */       throw new TemplateProcessingException("Error formatting integer with minimum integer digits = " + minIntegerDigits + " and thousands point type = " + thousandsPointType, e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public String[] arrayFormatInteger(Object[] target, Integer minIntegerDigits, String thousandsPointType)
/*     */   {
/* 128 */     if (target == null) {
/* 129 */       return null;
/*     */     }
/* 131 */     String[] result = new String[target.length];
/* 132 */     for (int i = 0; i < target.length; i++) {
/* 133 */       result[i] = formatInteger((Number)target[i], minIntegerDigits, thousandsPointType);
/*     */     }
/* 135 */     return result;
/*     */   }
/*     */   
/*     */   public List<String> listFormatInteger(List<? extends Number> target, Integer minIntegerDigits, String thousandsPointType) {
/* 139 */     if (target == null) {
/* 140 */       return null;
/*     */     }
/* 142 */     List<String> result = new ArrayList(target.size() + 2);
/* 143 */     for (Number element : target) {
/* 144 */       result.add(formatInteger(element, minIntegerDigits, thousandsPointType));
/*     */     }
/* 146 */     return result;
/*     */   }
/*     */   
/*     */   public Set<String> setFormatInteger(Set<? extends Number> target, Integer minIntegerDigits, String thousandsPointType) {
/* 150 */     if (target == null) {
/* 151 */       return null;
/*     */     }
/* 153 */     Set<String> result = new LinkedHashSet(target.size() + 2);
/* 154 */     for (Number element : target) {
/* 155 */       result.add(formatInteger(element, minIntegerDigits, thousandsPointType));
/*     */     }
/* 157 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String formatDecimal(Number target, Integer minIntegerDigits, Integer decimalDigits)
/*     */   {
/* 166 */     if (target == null) {
/* 167 */       return null;
/*     */     }
/*     */     try {
/* 170 */       return NumberUtils.format(target, minIntegerDigits, decimalDigits, this.locale);
/*     */     } catch (Exception e) {
/* 172 */       throw new TemplateProcessingException("Error formatting decimal with minimum integer digits = " + minIntegerDigits + " and decimal digits " + decimalDigits, e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public String[] arrayFormatDecimal(Object[] target, Integer minIntegerDigits, Integer decimalDigits)
/*     */   {
/* 179 */     if (target == null) {
/* 180 */       return null;
/*     */     }
/* 182 */     String[] result = new String[target.length];
/* 183 */     for (int i = 0; i < target.length; i++) {
/* 184 */       result[i] = formatDecimal((Number)target[i], minIntegerDigits, decimalDigits);
/*     */     }
/* 186 */     return result;
/*     */   }
/*     */   
/*     */   public List<String> listFormatDecimal(List<? extends Number> target, Integer minIntegerDigits, Integer decimalDigits) {
/* 190 */     if (target == null) {
/* 191 */       return null;
/*     */     }
/* 193 */     List<String> result = new ArrayList(target.size() + 2);
/* 194 */     for (Number element : target) {
/* 195 */       result.add(formatDecimal(element, minIntegerDigits, decimalDigits));
/*     */     }
/* 197 */     return result;
/*     */   }
/*     */   
/*     */   public Set<String> setFormatDecimal(Set<? extends Number> target, Integer minIntegerDigits, Integer decimalDigits) {
/* 201 */     if (target == null) {
/* 202 */       return null;
/*     */     }
/* 204 */     Set<String> result = new LinkedHashSet(target.size() + 2);
/* 205 */     for (Number element : target) {
/* 206 */       result.add(formatDecimal(element, minIntegerDigits, decimalDigits));
/*     */     }
/* 208 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String formatDecimal(Number target, Integer minIntegerDigits, Integer decimalDigits, String decimalPointType)
/*     */   {
/* 218 */     if (target == null) {
/* 219 */       return null;
/*     */     }
/* 221 */     NumberPointType decimalNumberPointType = NumberPointType.match(decimalPointType);
/* 222 */     if (decimalNumberPointType == null) {
/* 223 */       throw new TemplateProcessingException("Unrecognized point format \"" + decimalPointType + "\"");
/*     */     }
/*     */     try
/*     */     {
/* 227 */       return NumberUtils.format(target, minIntegerDigits, decimalDigits, decimalNumberPointType, this.locale);
/*     */     } catch (Exception e) {
/* 229 */       throw new TemplateProcessingException("Error formatting decimal with minimum integer digits = " + minIntegerDigits + ", decimal digits = " + decimalDigits + " and decimal point type = " + decimalPointType, e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public String[] arrayFormatDecimal(Object[] target, Integer minIntegerDigits, Integer decimalDigits, String decimalPointType)
/*     */   {
/* 236 */     if (target == null) {
/* 237 */       return null;
/*     */     }
/* 239 */     String[] result = new String[target.length];
/* 240 */     for (int i = 0; i < target.length; i++) {
/* 241 */       result[i] = formatDecimal((Number)target[i], minIntegerDigits, decimalDigits, decimalPointType);
/*     */     }
/* 243 */     return result;
/*     */   }
/*     */   
/*     */   public List<String> listFormatDecimal(List<? extends Number> target, Integer minIntegerDigits, Integer decimalDigits, String decimalPointType) {
/* 247 */     if (target == null) {
/* 248 */       return null;
/*     */     }
/* 250 */     List<String> result = new ArrayList(target.size() + 2);
/* 251 */     for (Number element : target) {
/* 252 */       result.add(formatDecimal(element, minIntegerDigits, decimalDigits, decimalPointType));
/*     */     }
/* 254 */     return result;
/*     */   }
/*     */   
/*     */   public Set<String> setFormatDecimal(Set<? extends Number> target, Integer minIntegerDigits, Integer decimalDigits, String decimalPointType) {
/* 258 */     if (target == null) {
/* 259 */       return null;
/*     */     }
/* 261 */     Set<String> result = new LinkedHashSet(target.size() + 2);
/* 262 */     for (Number element : target) {
/* 263 */       result.add(formatDecimal(element, minIntegerDigits, decimalDigits, decimalPointType));
/*     */     }
/* 265 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String formatDecimal(Number target, Integer minIntegerDigits, String thousandsPointType, Integer decimalDigits, String decimalPointType)
/*     */   {
/* 275 */     if (target == null) {
/* 276 */       return null;
/*     */     }
/* 278 */     NumberPointType decimalNumberPointType = NumberPointType.match(decimalPointType);
/* 279 */     if (decimalNumberPointType == null) {
/* 280 */       throw new TemplateProcessingException("Unrecognized point format \"" + decimalPointType + "\"");
/*     */     }
/*     */     
/* 283 */     NumberPointType thousandsNumberPointType = NumberPointType.match(thousandsPointType);
/* 284 */     if (thousandsNumberPointType == null) {
/* 285 */       throw new TemplateProcessingException("Unrecognized point format \"" + thousandsPointType + "\"");
/*     */     }
/*     */     try
/*     */     {
/* 289 */       return NumberUtils.format(target, minIntegerDigits, thousandsNumberPointType, decimalDigits, decimalNumberPointType, this.locale);
/*     */     } catch (Exception e) {
/* 291 */       throw new TemplateProcessingException("Error formatting decimal with minimum integer digits = " + minIntegerDigits + ", thousands point type = " + thousandsPointType + ", decimal digits = " + decimalDigits + " and decimal point type = " + decimalPointType, e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String[] arrayFormatDecimal(Object[] target, Integer minIntegerDigits, String thousandsPointType, Integer decimalDigits, String decimalPointType)
/*     */   {
/* 299 */     if (target == null) {
/* 300 */       return null;
/*     */     }
/* 302 */     String[] result = new String[target.length];
/* 303 */     for (int i = 0; i < target.length; i++) {
/* 304 */       result[i] = formatDecimal((Number)target[i], minIntegerDigits, thousandsPointType, decimalDigits, decimalPointType);
/*     */     }
/* 306 */     return result;
/*     */   }
/*     */   
/*     */   public List<String> listFormatDecimal(List<? extends Number> target, Integer minIntegerDigits, String thousandsPointType, Integer decimalDigits, String decimalPointType) {
/* 310 */     if (target == null) {
/* 311 */       return null;
/*     */     }
/* 313 */     List<String> result = new ArrayList(target.size() + 2);
/* 314 */     for (Number element : target) {
/* 315 */       result.add(formatDecimal(element, minIntegerDigits, thousandsPointType, decimalDigits, decimalPointType));
/*     */     }
/* 317 */     return result;
/*     */   }
/*     */   
/*     */   public Set<String> setFormatDecimal(Set<? extends Number> target, Integer minIntegerDigits, String thousandsPointType, Integer decimalDigits, String decimalPointType) {
/* 321 */     if (target == null) {
/* 322 */       return null;
/*     */     }
/* 324 */     Set<String> result = new LinkedHashSet(target.size() + 2);
/* 325 */     for (Number element : target) {
/* 326 */       result.add(formatDecimal(element, minIntegerDigits, thousandsPointType, decimalDigits, decimalPointType));
/*     */     }
/* 328 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String formatCurrency(Number target)
/*     */   {
/* 338 */     if (target == null) {
/* 339 */       return null;
/*     */     }
/*     */     try {
/* 342 */       return NumberUtils.formatCurrency(target, this.locale);
/*     */     } catch (Exception e) {
/* 344 */       throw new TemplateProcessingException("Error formatting currency", e);
/*     */     }
/*     */   }
/*     */   
/*     */   public String[] arrayFormatCurrency(Object[] target) {
/* 349 */     if (target == null) {
/* 350 */       return null;
/*     */     }
/* 352 */     String[] result = new String[target.length];
/* 353 */     for (int i = 0; i < target.length; i++) {
/* 354 */       result[i] = formatCurrency((Number)target[i]);
/*     */     }
/* 356 */     return result;
/*     */   }
/*     */   
/*     */   public List<String> listFormatCurrency(List<? extends Number> target) {
/* 360 */     if (target == null) {
/* 361 */       return null;
/*     */     }
/* 363 */     List<String> result = new ArrayList(target.size() + 2);
/* 364 */     for (Number element : target) {
/* 365 */       result.add(formatCurrency(element));
/*     */     }
/* 367 */     return result;
/*     */   }
/*     */   
/*     */   public Set<String> setFormatCurrency(Set<? extends Number> target) {
/* 371 */     if (target == null) {
/* 372 */       return null;
/*     */     }
/* 374 */     Set<String> result = new LinkedHashSet(target.size() + 2);
/* 375 */     for (Number element : target) {
/* 376 */       result.add(formatCurrency(element));
/*     */     }
/* 378 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String formatPercent(Number target, Integer minIntegerDigits, Integer decimalDigits)
/*     */   {
/* 388 */     if (target == null) {
/* 389 */       return null;
/*     */     }
/*     */     try {
/* 392 */       return NumberUtils.formatPercent(target, minIntegerDigits, decimalDigits, this.locale);
/*     */     } catch (Exception e) {
/* 394 */       throw new TemplateProcessingException("Error formatting percent", e);
/*     */     }
/*     */   }
/*     */   
/*     */   public String[] arrayFormatPercent(Object[] target, Integer minIntegerDigits, Integer decimalDigits) {
/* 399 */     if (target == null) {
/* 400 */       return null;
/*     */     }
/* 402 */     String[] result = new String[target.length];
/* 403 */     for (int i = 0; i < target.length; i++) {
/* 404 */       result[i] = formatPercent((Number)target[i], minIntegerDigits, decimalDigits);
/*     */     }
/* 406 */     return result;
/*     */   }
/*     */   
/*     */   public List<String> listFormatPercent(List<? extends Number> target, Integer minIntegerDigits, Integer decimalDigits) {
/* 410 */     if (target == null) {
/* 411 */       return null;
/*     */     }
/* 413 */     List<String> result = new ArrayList(target.size() + 2);
/* 414 */     for (Number element : target) {
/* 415 */       result.add(formatPercent(element, minIntegerDigits, decimalDigits));
/*     */     }
/* 417 */     return result;
/*     */   }
/*     */   
/*     */   public Set<String> setFormatPercent(Set<? extends Number> target, Integer minIntegerDigits, Integer decimalDigits) {
/* 421 */     if (target == null) {
/* 422 */       return null;
/*     */     }
/* 424 */     Set<String> result = new LinkedHashSet(target.size() + 2);
/* 425 */     for (Number element : target) {
/* 426 */       result.add(formatPercent(element, minIntegerDigits, decimalDigits));
/*     */     }
/* 428 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Integer[] sequence(Integer from, Integer to)
/*     */   {
/* 445 */     return NumberUtils.sequence(from, to);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Integer[] sequence(Integer from, Integer to, Integer step)
/*     */   {
/* 464 */     return NumberUtils.sequence(from, to, step);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\expression\Numbers.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */