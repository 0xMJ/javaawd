/*      */ package org.thymeleaf.expression;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Set;
/*      */ import org.thymeleaf.util.StringUtils;
/*      */ import org.thymeleaf.util.Validate;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class Strings
/*      */ {
/*      */   private final Locale locale;
/*      */   
/*      */   public Strings(Locale locale)
/*      */   {
/*   57 */     this.locale = locale;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String toString(Object target)
/*      */   {
/*   75 */     if (target == null) {
/*   76 */       return null;
/*      */     }
/*   78 */     return StringUtils.toString(target);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String[] arrayToString(Object[] target)
/*      */   {
/*   94 */     if (target == null) {
/*   95 */       return null;
/*      */     }
/*   97 */     String[] result = new String[target.length];
/*   98 */     for (int i = 0; i < target.length; i++) {
/*   99 */       result[i] = toString(target[i]);
/*      */     }
/*  101 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public List<String> listToString(List<?> target)
/*      */   {
/*  117 */     if (target == null) {
/*  118 */       return null;
/*      */     }
/*  120 */     List<String> result = new ArrayList(target.size() + 2);
/*  121 */     for (Object element : target) {
/*  122 */       result.add(toString(element));
/*      */     }
/*  124 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Set<String> setToString(Set<?> target)
/*      */   {
/*  140 */     if (target == null) {
/*  141 */       return null;
/*      */     }
/*  143 */     Set<String> result = new LinkedHashSet(target.size() + 2);
/*  144 */     for (Object element : target) {
/*  145 */       result.add(toString(element));
/*      */     }
/*  147 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String abbreviate(Object target, int maxSize)
/*      */   {
/*  155 */     if (target == null) {
/*  156 */       return null;
/*      */     }
/*  158 */     return StringUtils.abbreviate(target, maxSize);
/*      */   }
/*      */   
/*      */   public String[] arrayAbbreviate(Object[] target, int maxSize) {
/*  162 */     if (target == null) {
/*  163 */       return null;
/*      */     }
/*  165 */     String[] result = new String[target.length];
/*  166 */     for (int i = 0; i < target.length; i++) {
/*  167 */       result[i] = abbreviate(target[i], maxSize);
/*      */     }
/*  169 */     return result;
/*      */   }
/*      */   
/*      */   public List<String> listAbbreviate(List<?> target, int maxSize) {
/*  173 */     if (target == null) {
/*  174 */       return null;
/*      */     }
/*  176 */     List<String> result = new ArrayList(target.size() + 2);
/*  177 */     for (Object element : target) {
/*  178 */       result.add(abbreviate(element, maxSize));
/*      */     }
/*  180 */     return result;
/*      */   }
/*      */   
/*      */   public Set<String> setAbbreviate(Set<?> target, int maxSize) {
/*  184 */     if (target == null) {
/*  185 */       return null;
/*      */     }
/*  187 */     Set<String> result = new LinkedHashSet(target.size() + 2);
/*  188 */     for (Object element : target) {
/*  189 */       result.add(abbreviate(element, maxSize));
/*      */     }
/*  191 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Boolean equals(Object first, Object second)
/*      */   {
/*  205 */     return StringUtils.equals(first, second);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Boolean equalsIgnoreCase(Object first, Object second)
/*      */   {
/*  216 */     return StringUtils.equalsIgnoreCase(first, second);
/*      */   }
/*      */   
/*      */   public Boolean contains(Object target, String fragment)
/*      */   {
/*  221 */     return StringUtils.contains(target, fragment);
/*      */   }
/*      */   
/*      */   public Boolean[] arrayContains(Object[] target, String fragment) {
/*  225 */     if (target == null) {
/*  226 */       return null;
/*      */     }
/*  228 */     Boolean[] result = new Boolean[target.length];
/*  229 */     for (int i = 0; i < target.length; i++) {
/*  230 */       result[i] = contains(target[i], fragment);
/*      */     }
/*  232 */     return result;
/*      */   }
/*      */   
/*      */   public List<Boolean> listContains(List<?> target, String fragment) {
/*  236 */     if (target == null) {
/*  237 */       return null;
/*      */     }
/*  239 */     List<Boolean> result = new ArrayList(target.size() + 2);
/*  240 */     for (Object element : target) {
/*  241 */       result.add(contains(element, fragment));
/*      */     }
/*  243 */     return result;
/*      */   }
/*      */   
/*      */   public Set<Boolean> setContains(Set<?> target, String fragment) {
/*  247 */     if (target == null) {
/*  248 */       return null;
/*      */     }
/*  250 */     Set<Boolean> result = new LinkedHashSet(target.size() + 2);
/*  251 */     for (Object element : target) {
/*  252 */       result.add(contains(element, fragment));
/*      */     }
/*  254 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Boolean containsIgnoreCase(Object target, String fragment)
/*      */   {
/*  263 */     return StringUtils.containsIgnoreCase(target, fragment, this.locale);
/*      */   }
/*      */   
/*      */   public Boolean[] arrayContainsIgnoreCase(Object[] target, String fragment) {
/*  267 */     if (target == null) {
/*  268 */       return null;
/*      */     }
/*  270 */     Boolean[] result = new Boolean[target.length];
/*  271 */     for (int i = 0; i < target.length; i++) {
/*  272 */       result[i] = containsIgnoreCase(target[i], fragment);
/*      */     }
/*  274 */     return result;
/*      */   }
/*      */   
/*      */   public List<Boolean> listContainsIgnoreCase(List<?> target, String fragment) {
/*  278 */     if (target == null) {
/*  279 */       return null;
/*      */     }
/*  281 */     List<Boolean> result = new ArrayList(target.size() + 2);
/*  282 */     for (Object element : target) {
/*  283 */       result.add(containsIgnoreCase(element, fragment));
/*      */     }
/*  285 */     return result;
/*      */   }
/*      */   
/*      */   public Set<Boolean> setContainsIgnoreCase(Set<?> target, String fragment) {
/*  289 */     if (target == null) {
/*  290 */       return null;
/*      */     }
/*  292 */     Set<Boolean> result = new LinkedHashSet(target.size() + 2);
/*  293 */     for (Object element : target) {
/*  294 */       result.add(containsIgnoreCase(element, fragment));
/*      */     }
/*  296 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Boolean startsWith(Object target, String prefix)
/*      */   {
/*  305 */     return StringUtils.startsWith(target, prefix);
/*      */   }
/*      */   
/*      */   public Boolean[] arrayStartsWith(Object[] target, String prefix) {
/*  309 */     if (target == null) {
/*  310 */       return null;
/*      */     }
/*  312 */     Boolean[] result = new Boolean[target.length];
/*  313 */     for (int i = 0; i < target.length; i++) {
/*  314 */       result[i] = startsWith(target[i], prefix);
/*      */     }
/*  316 */     return result;
/*      */   }
/*      */   
/*      */   public List<Boolean> listStartsWith(List<?> target, String prefix) {
/*  320 */     if (target == null) {
/*  321 */       return null;
/*      */     }
/*  323 */     List<Boolean> result = new ArrayList(target.size() + 2);
/*  324 */     for (Object element : target) {
/*  325 */       result.add(startsWith(element, prefix));
/*      */     }
/*  327 */     return result;
/*      */   }
/*      */   
/*      */   public Set<Boolean> setStartsWith(Set<?> target, String prefix) {
/*  331 */     if (target == null) {
/*  332 */       return null;
/*      */     }
/*  334 */     Set<Boolean> result = new LinkedHashSet(target.size() + 2);
/*  335 */     for (Object element : target) {
/*  336 */       result.add(startsWith(element, prefix));
/*      */     }
/*  338 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Boolean endsWith(Object target, String suffix)
/*      */   {
/*  347 */     return StringUtils.endsWith(target, suffix);
/*      */   }
/*      */   
/*      */   public Boolean[] arrayEndsWith(Object[] target, String suffix) {
/*  351 */     if (target == null) {
/*  352 */       return null;
/*      */     }
/*  354 */     Boolean[] result = new Boolean[target.length];
/*  355 */     for (int i = 0; i < target.length; i++) {
/*  356 */       result[i] = endsWith(target[i], suffix);
/*      */     }
/*  358 */     return result;
/*      */   }
/*      */   
/*      */   public List<Boolean> listEndsWith(List<?> target, String suffix) {
/*  362 */     if (target == null) {
/*  363 */       return null;
/*      */     }
/*  365 */     List<Boolean> result = new ArrayList(target.size() + 2);
/*  366 */     for (Object element : target) {
/*  367 */       result.add(endsWith(element, suffix));
/*      */     }
/*  369 */     return result;
/*      */   }
/*      */   
/*      */   public Set<Boolean> setEndsWith(Set<?> target, String suffix) {
/*  373 */     if (target == null) {
/*  374 */       return null;
/*      */     }
/*  376 */     Set<Boolean> result = new LinkedHashSet(target.size() + 2);
/*  377 */     for (Object element : target) {
/*  378 */       result.add(endsWith(element, suffix));
/*      */     }
/*  380 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String substring(Object target, int start, int end)
/*      */   {
/*  389 */     if (target == null) {
/*  390 */       return null;
/*      */     }
/*  392 */     return StringUtils.substring(target, start, end);
/*      */   }
/*      */   
/*      */   public String[] arraySubstring(Object[] target, int start, int end) {
/*  396 */     if (target == null) {
/*  397 */       return null;
/*      */     }
/*  399 */     String[] result = new String[target.length];
/*  400 */     for (int i = 0; i < target.length; i++) {
/*  401 */       result[i] = substring(target[i], start, end);
/*      */     }
/*  403 */     return result;
/*      */   }
/*      */   
/*      */   public List<String> listSubstring(List<?> target, int start, int end) {
/*  407 */     if (target == null) {
/*  408 */       return null;
/*      */     }
/*  410 */     List<String> result = new ArrayList(target.size() + 2);
/*  411 */     for (Object element : target) {
/*  412 */       result.add(substring(element, start, end));
/*      */     }
/*  414 */     return result;
/*      */   }
/*      */   
/*      */   public Set<String> setSubstring(Set<?> target, int start, int end) {
/*  418 */     if (target == null) {
/*  419 */       return null;
/*      */     }
/*  421 */     Set<String> result = new LinkedHashSet(target.size() + 2);
/*  422 */     for (Object element : target) {
/*  423 */       result.add(substring(element, start, end));
/*      */     }
/*  425 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String substring(Object target, int start)
/*      */   {
/*  443 */     if (target == null) {
/*  444 */       return null;
/*      */     }
/*  446 */     return StringUtils.substring(target, start);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String[] arraySubstring(Object[] target, int start)
/*      */   {
/*  464 */     if (target == null) {
/*  465 */       return null;
/*      */     }
/*  467 */     String[] result = new String[target.length];
/*  468 */     for (int i = 0; i < target.length; i++) {
/*  469 */       result[i] = substring(target[i], start);
/*      */     }
/*  471 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public List<String> listSubstring(List<?> target, int start)
/*      */   {
/*  489 */     if (target == null) {
/*  490 */       return null;
/*      */     }
/*  492 */     List<String> result = new ArrayList(target.size() + 2);
/*  493 */     for (Object element : target) {
/*  494 */       result.add(substring(element, start));
/*      */     }
/*  496 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Set<String> setSubstring(Set<?> target, int start)
/*      */   {
/*  514 */     if (target == null) {
/*  515 */       return null;
/*      */     }
/*  517 */     Set<String> result = new LinkedHashSet(target.size() + 2);
/*  518 */     for (Object element : target) {
/*  519 */       result.add(substring(element, start));
/*      */     }
/*  521 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String substringAfter(Object target, String substr)
/*      */   {
/*  530 */     if (target == null) {
/*  531 */       return null;
/*      */     }
/*  533 */     return StringUtils.substringAfter(target, substr);
/*      */   }
/*      */   
/*      */   public String[] arraySubstringAfter(Object[] target, String substr) {
/*  537 */     if (target == null) {
/*  538 */       return null;
/*      */     }
/*  540 */     String[] result = new String[target.length];
/*  541 */     for (int i = 0; i < target.length; i++) {
/*  542 */       result[i] = substringAfter(target[i], substr);
/*      */     }
/*  544 */     return result;
/*      */   }
/*      */   
/*      */   public List<String> listSubstringAfter(List<?> target, String substr) {
/*  548 */     if (target == null) {
/*  549 */       return null;
/*      */     }
/*  551 */     List<String> result = new ArrayList(target.size() + 2);
/*  552 */     for (Object element : target) {
/*  553 */       result.add(substringAfter(element, substr));
/*      */     }
/*  555 */     return result;
/*      */   }
/*      */   
/*      */   public Set<String> setSubstringAfter(Set<?> target, String substr) {
/*  559 */     if (target == null) {
/*  560 */       return null;
/*      */     }
/*  562 */     Set<String> result = new LinkedHashSet(target.size() + 2);
/*  563 */     for (Object element : target) {
/*  564 */       result.add(substringAfter(element, substr));
/*      */     }
/*  566 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String substringBefore(Object target, String substr)
/*      */   {
/*  575 */     if (target == null) {
/*  576 */       return null;
/*      */     }
/*  578 */     return StringUtils.substringBefore(target, substr);
/*      */   }
/*      */   
/*      */   public String[] arraySubstringBefore(Object[] target, String substr) {
/*  582 */     if (target == null) {
/*  583 */       return null;
/*      */     }
/*  585 */     String[] result = new String[target.length];
/*  586 */     for (int i = 0; i < target.length; i++) {
/*  587 */       result[i] = substringBefore(target[i], substr);
/*      */     }
/*  589 */     return result;
/*      */   }
/*      */   
/*      */   public List<String> listSubstringBefore(List<?> target, String substr) {
/*  593 */     if (target == null) {
/*  594 */       return null;
/*      */     }
/*  596 */     List<String> result = new ArrayList(target.size() + 2);
/*  597 */     for (Object element : target) {
/*  598 */       result.add(substringBefore(element, substr));
/*      */     }
/*  600 */     return result;
/*      */   }
/*      */   
/*      */   public Set<String> setSubstringBefore(Set<?> target, String substr) {
/*  604 */     if (target == null) {
/*  605 */       return null;
/*      */     }
/*  607 */     Set<String> result = new LinkedHashSet(target.size() + 2);
/*  608 */     for (Object element : target) {
/*  609 */       result.add(substringBefore(element, substr));
/*      */     }
/*  611 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String prepend(Object target, String prefix)
/*      */   {
/*  620 */     if (target == null) {
/*  621 */       return null;
/*      */     }
/*  623 */     return StringUtils.prepend(target, prefix);
/*      */   }
/*      */   
/*      */   public String[] arrayPrepend(Object[] target, String prefix) {
/*  627 */     if (target == null) {
/*  628 */       return null;
/*      */     }
/*  630 */     String[] result = new String[target.length];
/*  631 */     for (int i = 0; i < target.length; i++) {
/*  632 */       result[i] = prepend(target[i], prefix);
/*      */     }
/*  634 */     return result;
/*      */   }
/*      */   
/*      */   public List<String> listPrepend(List<?> target, String prefix) {
/*  638 */     if (target == null) {
/*  639 */       return null;
/*      */     }
/*  641 */     List<String> result = new ArrayList(target.size() + 2);
/*  642 */     for (Object element : target) {
/*  643 */       result.add(prepend(element, prefix));
/*      */     }
/*  645 */     return result;
/*      */   }
/*      */   
/*      */   public Set<String> setPrepend(Set<?> target, String prefix) {
/*  649 */     if (target == null) {
/*  650 */       return null;
/*      */     }
/*  652 */     Set<String> result = new LinkedHashSet(target.size() + 2);
/*  653 */     for (Object element : target) {
/*  654 */       result.add(prepend(element, prefix));
/*      */     }
/*  656 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String repeat(Object target, int times)
/*      */   {
/*  672 */     if (target == null) {
/*  673 */       return null;
/*      */     }
/*  675 */     return StringUtils.repeat(target, times);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String append(Object target, String suffix)
/*      */   {
/*  684 */     if (target == null) {
/*  685 */       return null;
/*      */     }
/*  687 */     return StringUtils.append(target, suffix);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String concat(Object... values)
/*      */   {
/*  697 */     return StringUtils.concat(values);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String concatReplaceNulls(String nullValue, Object... values)
/*      */   {
/*  708 */     return StringUtils.concatReplaceNulls(nullValue, values);
/*      */   }
/*      */   
/*      */   public String[] arrayAppend(Object[] target, String suffix) {
/*  712 */     if (target == null) {
/*  713 */       return null;
/*      */     }
/*  715 */     String[] result = new String[target.length];
/*  716 */     for (int i = 0; i < target.length; i++) {
/*  717 */       result[i] = append(target[i], suffix);
/*      */     }
/*  719 */     return result;
/*      */   }
/*      */   
/*      */   public List<String> listAppend(List<?> target, String suffix) {
/*  723 */     if (target == null) {
/*  724 */       return null;
/*      */     }
/*  726 */     List<String> result = new ArrayList(target.size() + 2);
/*  727 */     for (Object element : target) {
/*  728 */       result.add(append(element, suffix));
/*      */     }
/*  730 */     return result;
/*      */   }
/*      */   
/*      */   public Set<String> setAppend(Set<?> target, String suffix) {
/*  734 */     if (target == null) {
/*  735 */       return null;
/*      */     }
/*  737 */     Set<String> result = new LinkedHashSet(target.size() + 2);
/*  738 */     for (Object element : target) {
/*  739 */       result.add(append(element, suffix));
/*      */     }
/*  741 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Integer indexOf(Object target, String fragment)
/*      */   {
/*  750 */     return StringUtils.indexOf(target, fragment);
/*      */   }
/*      */   
/*      */   public Integer[] arrayIndexOf(Object[] target, String fragment) {
/*  754 */     if (target == null) {
/*  755 */       return null;
/*      */     }
/*  757 */     Integer[] result = new Integer[target.length];
/*  758 */     for (int i = 0; i < target.length; i++) {
/*  759 */       result[i] = indexOf(target[i], fragment);
/*      */     }
/*  761 */     return result;
/*      */   }
/*      */   
/*      */   public List<Integer> listIndexOf(List<?> target, String fragment) {
/*  765 */     if (target == null) {
/*  766 */       return null;
/*      */     }
/*  768 */     List<Integer> result = new ArrayList(target.size() + 2);
/*  769 */     for (Object element : target) {
/*  770 */       result.add(indexOf(element, fragment));
/*      */     }
/*  772 */     return result;
/*      */   }
/*      */   
/*      */   public Set<Integer> setIndexOf(Set<?> target, String fragment) {
/*  776 */     if (target == null) {
/*  777 */       return null;
/*      */     }
/*  779 */     Set<Integer> result = new LinkedHashSet(target.size() + 2);
/*  780 */     for (Object element : target) {
/*  781 */       result.add(indexOf(element, fragment));
/*      */     }
/*  783 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Boolean isEmpty(Object target)
/*      */   {
/*  793 */     return Boolean.valueOf((target == null) || (StringUtils.isEmptyOrWhitespace(target.toString())));
/*      */   }
/*      */   
/*      */   public Boolean[] arrayIsEmpty(Object[] target) {
/*  797 */     if (target == null) {
/*  798 */       return null;
/*      */     }
/*  800 */     Boolean[] result = new Boolean[target.length];
/*  801 */     for (int i = 0; i < target.length; i++) {
/*  802 */       result[i] = isEmpty(target[i]);
/*      */     }
/*  804 */     return result;
/*      */   }
/*      */   
/*      */   public List<Boolean> listIsEmpty(List<?> target) {
/*  808 */     if (target == null) {
/*  809 */       return null;
/*      */     }
/*  811 */     List<Boolean> result = new ArrayList(target.size() + 2);
/*  812 */     for (Object element : target) {
/*  813 */       result.add(isEmpty(element));
/*      */     }
/*  815 */     return result;
/*      */   }
/*      */   
/*      */   public Set<Boolean> setIsEmpty(Set<?> target) {
/*  819 */     if (target == null) {
/*  820 */       return null;
/*      */     }
/*  822 */     Set<Boolean> result = new LinkedHashSet(target.size() + 2);
/*  823 */     for (Object element : target) {
/*  824 */       result.add(isEmpty(element));
/*      */     }
/*  826 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String arrayJoin(Object[] stringArray, String separator)
/*      */   {
/*  836 */     if (stringArray == null) {
/*  837 */       return null;
/*      */     }
/*  839 */     return StringUtils.join(stringArray, separator);
/*      */   }
/*      */   
/*      */   public String listJoin(List<?> stringIter, String separator) {
/*  843 */     if (stringIter == null) {
/*  844 */       return null;
/*      */     }
/*  846 */     return StringUtils.join(stringIter, separator);
/*      */   }
/*      */   
/*      */   public String setJoin(Set<?> stringIter, String separator) {
/*  850 */     if (stringIter == null) {
/*  851 */       return null;
/*      */     }
/*  853 */     return StringUtils.join(stringIter, separator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String[] arraySplit(Object target, String separator)
/*      */   {
/*  861 */     if (target == null) {
/*  862 */       return null;
/*      */     }
/*  864 */     return StringUtils.split(target, separator);
/*      */   }
/*      */   
/*      */   public List<String> listSplit(Object target, String separator) {
/*  868 */     if (target == null) {
/*  869 */       return null;
/*      */     }
/*  871 */     return new ArrayList(Arrays.asList(StringUtils.split(target, separator)));
/*      */   }
/*      */   
/*      */   public Set<String> setSplit(Object target, String separator) {
/*  875 */     if (target == null) {
/*  876 */       return null;
/*      */     }
/*  878 */     return new LinkedHashSet(Arrays.asList(StringUtils.split(target, separator)));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Integer length(Object target)
/*      */   {
/*  886 */     return StringUtils.length(target);
/*      */   }
/*      */   
/*      */   public Integer[] arrayLength(Object[] target) {
/*  890 */     if (target == null) {
/*  891 */       return null;
/*      */     }
/*  893 */     Integer[] result = new Integer[target.length];
/*  894 */     for (int i = 0; i < target.length; i++) {
/*  895 */       result[i] = length(target[i]);
/*      */     }
/*  897 */     return result;
/*      */   }
/*      */   
/*      */   public List<Integer> listLength(List<?> target) {
/*  901 */     if (target == null) {
/*  902 */       return null;
/*      */     }
/*  904 */     List<Integer> result = new ArrayList(target.size() + 2);
/*  905 */     for (Object element : target) {
/*  906 */       result.add(length(element));
/*      */     }
/*  908 */     return result;
/*      */   }
/*      */   
/*      */   public Set<Integer> setLength(Set<?> target) {
/*  912 */     if (target == null) {
/*  913 */       return null;
/*      */     }
/*  915 */     Set<Integer> result = new LinkedHashSet(target.size() + 2);
/*  916 */     for (Object element : target) {
/*  917 */       result.add(length(element));
/*      */     }
/*  919 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String replace(Object target, String before, String after)
/*      */   {
/*  929 */     if (target == null) {
/*  930 */       return null;
/*      */     }
/*  932 */     return StringUtils.replace(target, before, after);
/*      */   }
/*      */   
/*      */   public String[] arrayReplace(Object[] target, String before, String after) {
/*  936 */     if (target == null) {
/*  937 */       return null;
/*      */     }
/*  939 */     String[] result = new String[target.length];
/*  940 */     for (int i = 0; i < target.length; i++) {
/*  941 */       result[i] = replace(target[i], before, after);
/*      */     }
/*  943 */     return result;
/*      */   }
/*      */   
/*      */   public List<String> listReplace(List<?> target, String before, String after) {
/*  947 */     if (target == null) {
/*  948 */       return null;
/*      */     }
/*  950 */     List<String> result = new ArrayList(target.size() + 2);
/*  951 */     for (Object element : target) {
/*  952 */       result.add(replace(element, before, after));
/*      */     }
/*  954 */     return result;
/*      */   }
/*      */   
/*      */   public Set<String> setReplace(Set<?> target, String before, String after) {
/*  958 */     if (target == null) {
/*  959 */       return null;
/*      */     }
/*  961 */     Set<String> result = new LinkedHashSet(target.size() + 2);
/*  962 */     for (Object element : target) {
/*  963 */       result.add(replace(element, before, after));
/*      */     }
/*  965 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String multipleReplace(Object target, String[] before, String[] after)
/*      */   {
/*  976 */     Validate.notNull(before, "Array of 'before' values cannot be null");
/*  977 */     Validate.notNull(after, "Array of 'after' values cannot be null");
/*  978 */     Validate.isTrue(before.length == after.length, "Arrays of 'before' and 'after' values must have the same length");
/*      */     
/*      */ 
/*  981 */     if (target == null) {
/*  982 */       return null;
/*      */     }
/*      */     
/*  985 */     String ret = target.toString();
/*  986 */     for (int i = 0; i < before.length; i++) {
/*  987 */       ret = StringUtils.replace(ret, before[i], after[i]);
/*      */     }
/*  989 */     return ret;
/*      */   }
/*      */   
/*      */ 
/*      */   public String[] arrayMultipleReplace(Object[] target, String[] before, String[] after)
/*      */   {
/*  995 */     if (target == null) {
/*  996 */       return null;
/*      */     }
/*  998 */     String[] result = new String[target.length];
/*  999 */     for (int i = 0; i < target.length; i++) {
/* 1000 */       result[i] = multipleReplace(target[i], before, after);
/*      */     }
/* 1002 */     return result;
/*      */   }
/*      */   
/*      */   public List<String> listMultipleReplace(List<?> target, String[] before, String[] after)
/*      */   {
/* 1007 */     if (target == null) {
/* 1008 */       return null;
/*      */     }
/* 1010 */     List<String> result = new ArrayList(target.size() + 2);
/* 1011 */     for (Object element : target) {
/* 1012 */       result.add(multipleReplace(element, before, after));
/*      */     }
/* 1014 */     return result;
/*      */   }
/*      */   
/*      */   public Set<String> setMultipleReplace(Set<?> target, String[] before, String[] after)
/*      */   {
/* 1019 */     if (target == null) {
/* 1020 */       return null;
/*      */     }
/* 1022 */     Set<String> result = new LinkedHashSet(target.size() + 2);
/* 1023 */     for (Object element : target) {
/* 1024 */       result.add(multipleReplace(element, before, after));
/*      */     }
/* 1026 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String toUpperCase(Object target)
/*      */   {
/* 1035 */     if (target == null) {
/* 1036 */       return null;
/*      */     }
/* 1038 */     return StringUtils.toUpperCase(target, this.locale);
/*      */   }
/*      */   
/*      */   public String[] arrayToUpperCase(Object[] target) {
/* 1042 */     if (target == null) {
/* 1043 */       return null;
/*      */     }
/* 1045 */     String[] result = new String[target.length];
/* 1046 */     for (int i = 0; i < target.length; i++) {
/* 1047 */       result[i] = toUpperCase(target[i]);
/*      */     }
/* 1049 */     return result;
/*      */   }
/*      */   
/*      */   public List<String> listToUpperCase(List<?> target) {
/* 1053 */     if (target == null) {
/* 1054 */       return null;
/*      */     }
/* 1056 */     List<String> result = new ArrayList(target.size() + 2);
/* 1057 */     for (Object element : target) {
/* 1058 */       result.add(toUpperCase(element));
/*      */     }
/* 1060 */     return result;
/*      */   }
/*      */   
/*      */   public Set<String> setToUpperCase(Set<?> target) {
/* 1064 */     if (target == null) {
/* 1065 */       return null;
/*      */     }
/* 1067 */     Set<String> result = new LinkedHashSet(target.size() + 2);
/* 1068 */     for (Object element : target) {
/* 1069 */       result.add(toUpperCase(element));
/*      */     }
/* 1071 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String toLowerCase(Object target)
/*      */   {
/* 1080 */     if (target == null) {
/* 1081 */       return null;
/*      */     }
/* 1083 */     return StringUtils.toLowerCase(target, this.locale);
/*      */   }
/*      */   
/*      */   public String[] arrayToLowerCase(Object[] target) {
/* 1087 */     if (target == null) {
/* 1088 */       return null;
/*      */     }
/* 1090 */     String[] result = new String[target.length];
/* 1091 */     for (int i = 0; i < target.length; i++) {
/* 1092 */       result[i] = toLowerCase(target[i]);
/*      */     }
/* 1094 */     return result;
/*      */   }
/*      */   
/*      */   public List<String> listToLowerCase(List<?> target) {
/* 1098 */     if (target == null) {
/* 1099 */       return null;
/*      */     }
/* 1101 */     List<String> result = new ArrayList(target.size() + 2);
/* 1102 */     for (Object element : target) {
/* 1103 */       result.add(toLowerCase(element));
/*      */     }
/* 1105 */     return result;
/*      */   }
/*      */   
/*      */   public Set<String> setToLowerCase(Set<?> target) {
/* 1109 */     if (target == null) {
/* 1110 */       return null;
/*      */     }
/* 1112 */     Set<String> result = new LinkedHashSet(target.size() + 2);
/* 1113 */     for (Object element : target) {
/* 1114 */       result.add(toLowerCase(element));
/*      */     }
/* 1116 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String trim(Object target)
/*      */   {
/* 1124 */     if (target == null) {
/* 1125 */       return null;
/*      */     }
/* 1127 */     return StringUtils.trim(target);
/*      */   }
/*      */   
/*      */   public String[] arrayTrim(Object[] target) {
/* 1131 */     if (target == null) {
/* 1132 */       return null;
/*      */     }
/* 1134 */     String[] result = new String[target.length];
/* 1135 */     for (int i = 0; i < target.length; i++) {
/* 1136 */       result[i] = trim(target[i]);
/*      */     }
/* 1138 */     return result;
/*      */   }
/*      */   
/*      */   public List<String> listTrim(List<?> target) {
/* 1142 */     if (target == null) {
/* 1143 */       return null;
/*      */     }
/* 1145 */     List<String> result = new ArrayList(target.size() + 2);
/* 1146 */     for (Object element : target) {
/* 1147 */       result.add(trim(element));
/*      */     }
/* 1149 */     return result;
/*      */   }
/*      */   
/*      */   public Set<String> setTrim(Set<?> target) {
/* 1153 */     if (target == null) {
/* 1154 */       return null;
/*      */     }
/* 1156 */     Set<String> result = new LinkedHashSet(target.size() + 2);
/* 1157 */     for (Object element : target) {
/* 1158 */       result.add(trim(element));
/*      */     }
/* 1160 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String capitalize(Object target)
/*      */   {
/* 1177 */     if (target == null) {
/* 1178 */       return null;
/*      */     }
/* 1180 */     return StringUtils.capitalize(target);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String[] arrayCapitalize(Object[] target)
/*      */   {
/* 1199 */     if (target == null) {
/* 1200 */       return null;
/*      */     }
/* 1202 */     String[] result = new String[target.length];
/* 1203 */     for (int i = 0; i < target.length; i++) {
/* 1204 */       result[i] = capitalize(target[i]);
/*      */     }
/* 1206 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public List<String> listCapitalize(List<?> target)
/*      */   {
/* 1225 */     if (target == null) {
/* 1226 */       return null;
/*      */     }
/* 1228 */     List<String> result = new ArrayList(target.size() + 2);
/* 1229 */     for (Object element : target) {
/* 1230 */       result.add(capitalize(element));
/*      */     }
/* 1232 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Set<String> setCapitalize(Set<?> target)
/*      */   {
/* 1250 */     if (target == null) {
/* 1251 */       return null;
/*      */     }
/* 1253 */     Set<String> result = new LinkedHashSet(target.size() + 2);
/* 1254 */     for (Object element : target) {
/* 1255 */       result.add(capitalize(element));
/*      */     }
/* 1257 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String unCapitalize(Object target)
/*      */   {
/* 1274 */     if (target == null) {
/* 1275 */       return null;
/*      */     }
/* 1277 */     return StringUtils.unCapitalize(target);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String[] arrayUnCapitalize(Object[] target)
/*      */   {
/* 1297 */     if (target == null) {
/* 1298 */       return null;
/*      */     }
/* 1300 */     String[] result = new String[target.length];
/* 1301 */     for (int i = 0; i < target.length; i++) {
/* 1302 */       result[i] = unCapitalize(target[i]);
/*      */     }
/* 1304 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public List<String> listUnCapitalize(List<?> target)
/*      */   {
/* 1324 */     if (target == null) {
/* 1325 */       return null;
/*      */     }
/* 1327 */     List<String> result = new ArrayList(target.size() + 2);
/* 1328 */     for (Object element : target) {
/* 1329 */       result.add(unCapitalize(element));
/*      */     }
/* 1331 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Set<String> setUnCapitalize(Set<?> target)
/*      */   {
/* 1351 */     if (target == null) {
/* 1352 */       return null;
/*      */     }
/* 1354 */     Set<String> result = new LinkedHashSet(target.size() + 2);
/* 1355 */     for (Object element : target) {
/* 1356 */       result.add(unCapitalize(element));
/*      */     }
/* 1358 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String capitalizeWords(Object target)
/*      */   {
/* 1380 */     if (target == null) {
/* 1381 */       return null;
/*      */     }
/* 1383 */     return StringUtils.capitalizeWords(target);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String[] arrayCapitalizeWords(Object[] target)
/*      */   {
/* 1407 */     if (target == null) {
/* 1408 */       return null;
/*      */     }
/* 1410 */     String[] result = new String[target.length];
/* 1411 */     for (int i = 0; i < target.length; i++) {
/* 1412 */       result[i] = capitalizeWords(target[i]);
/*      */     }
/* 1414 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public List<String> listCapitalizeWords(List<?> target)
/*      */   {
/* 1438 */     if (target == null) {
/* 1439 */       return null;
/*      */     }
/* 1441 */     List<String> result = new ArrayList(target.size() + 2);
/* 1442 */     for (Object element : target) {
/* 1443 */       result.add(capitalizeWords(element));
/*      */     }
/* 1445 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Set<String> setCapitalizeWords(Set<?> target)
/*      */   {
/* 1468 */     if (target == null) {
/* 1469 */       return null;
/*      */     }
/* 1471 */     Set<String> result = new LinkedHashSet(target.size() + 2);
/* 1472 */     for (Object element : target) {
/* 1473 */       result.add(capitalizeWords(element));
/*      */     }
/* 1475 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String capitalizeWords(Object target, Object delimiters)
/*      */   {
/* 1499 */     if (target == null) {
/* 1500 */       return null;
/*      */     }
/* 1502 */     return StringUtils.capitalizeWords(target, delimiters);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String[] arrayCapitalizeWords(Object[] target, Object delimiters)
/*      */   {
/* 1529 */     if (target == null) {
/* 1530 */       return null;
/*      */     }
/* 1532 */     String[] result = new String[target.length];
/* 1533 */     for (int i = 0; i < target.length; i++) {
/* 1534 */       result[i] = capitalizeWords(target[i], delimiters);
/*      */     }
/* 1536 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public List<String> listCapitalizeWords(List<?> target, Object delimiters)
/*      */   {
/* 1563 */     if (target == null) {
/* 1564 */       return null;
/*      */     }
/* 1566 */     List<String> result = new ArrayList(target.size() + 2);
/* 1567 */     for (Object element : target) {
/* 1568 */       result.add(capitalizeWords(element, delimiters));
/*      */     }
/* 1570 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Set<String> setCapitalizeWords(Set<?> target, Object delimiters)
/*      */   {
/* 1596 */     if (target == null) {
/* 1597 */       return null;
/*      */     }
/* 1599 */     Set<String> result = new LinkedHashSet(target.size() + 2);
/* 1600 */     for (Object element : target) {
/* 1601 */       result.add(capitalizeWords(element, delimiters));
/*      */     }
/* 1603 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String escapeXml(Object target)
/*      */   {
/* 1620 */     if (target == null) {
/* 1621 */       return null;
/*      */     }
/* 1623 */     return StringUtils.escapeXml(target);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String[] arrayEscapeXml(Object[] target)
/*      */   {
/* 1642 */     if (target == null) {
/* 1643 */       return null;
/*      */     }
/* 1645 */     String[] result = new String[target.length];
/* 1646 */     for (int i = 0; i < target.length; i++) {
/* 1647 */       result[i] = escapeXml(target[i]);
/*      */     }
/* 1649 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public List<String> listEscapeXml(List<?> target)
/*      */   {
/* 1668 */     if (target == null) {
/* 1669 */       return null;
/*      */     }
/* 1671 */     List<String> result = new ArrayList(target.size() + 2);
/* 1672 */     for (Object element : target) {
/* 1673 */       result.add(escapeXml(element));
/*      */     }
/* 1675 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Set<String> setEscapeXml(Set<?> target)
/*      */   {
/* 1694 */     if (target == null) {
/* 1695 */       return null;
/*      */     }
/* 1697 */     Set<String> result = new LinkedHashSet(target.size() + 2);
/* 1698 */     for (Object element : target) {
/* 1699 */       result.add(escapeXml(element));
/*      */     }
/* 1701 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String escapeJavaScript(Object target)
/*      */   {
/* 1724 */     if (target == null) {
/* 1725 */       return null;
/*      */     }
/* 1727 */     return StringUtils.escapeJavaScript(target);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String[] arrayEscapeJavaScript(Object[] target)
/*      */   {
/* 1746 */     if (target == null) {
/* 1747 */       return null;
/*      */     }
/* 1749 */     String[] result = new String[target.length];
/* 1750 */     for (int i = 0; i < target.length; i++) {
/* 1751 */       result[i] = escapeJavaScript(target[i]);
/*      */     }
/* 1753 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public List<String> listEscapeJavaScript(List<?> target)
/*      */   {
/* 1772 */     if (target == null) {
/* 1773 */       return null;
/*      */     }
/* 1775 */     List<String> result = new ArrayList(target.size() + 2);
/* 1776 */     for (Object element : target) {
/* 1777 */       result.add(escapeJavaScript(element));
/*      */     }
/* 1779 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Set<String> setEscapeJavaScript(Set<?> target)
/*      */   {
/* 1798 */     if (target == null) {
/* 1799 */       return null;
/*      */     }
/* 1801 */     Set<String> result = new LinkedHashSet(target.size() + 2);
/* 1802 */     for (Object element : target) {
/* 1803 */       result.add(escapeJavaScript(element));
/*      */     }
/* 1805 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String unescapeJavaScript(Object target)
/*      */   {
/* 1827 */     if (target == null) {
/* 1828 */       return null;
/*      */     }
/* 1830 */     return StringUtils.unescapeJavaScript(target);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String[] arrayUnescapeJavaScript(Object[] target)
/*      */   {
/* 1849 */     if (target == null) {
/* 1850 */       return null;
/*      */     }
/* 1852 */     String[] result = new String[target.length];
/* 1853 */     for (int i = 0; i < target.length; i++) {
/* 1854 */       result[i] = unescapeJavaScript(target[i]);
/*      */     }
/* 1856 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public List<String> listUnescapeJavaScript(List<?> target)
/*      */   {
/* 1875 */     if (target == null) {
/* 1876 */       return null;
/*      */     }
/* 1878 */     List<String> result = new ArrayList(target.size() + 2);
/* 1879 */     for (Object element : target) {
/* 1880 */       result.add(unescapeJavaScript(element));
/*      */     }
/* 1882 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Set<String> setUnescapeJavaScript(Set<?> target)
/*      */   {
/* 1901 */     if (target == null) {
/* 1902 */       return null;
/*      */     }
/* 1904 */     Set<String> result = new LinkedHashSet(target.size() + 2);
/* 1905 */     for (Object element : target) {
/* 1906 */       result.add(unescapeJavaScript(element));
/*      */     }
/* 1908 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String escapeJava(Object target)
/*      */   {
/* 1930 */     if (target == null) {
/* 1931 */       return null;
/*      */     }
/* 1933 */     return StringUtils.escapeJava(target);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String[] arrayEscapeJava(Object[] target)
/*      */   {
/* 1952 */     if (target == null) {
/* 1953 */       return null;
/*      */     }
/* 1955 */     String[] result = new String[target.length];
/* 1956 */     for (int i = 0; i < target.length; i++) {
/* 1957 */       result[i] = escapeJava(target[i]);
/*      */     }
/* 1959 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public List<String> listEscapeJava(List<?> target)
/*      */   {
/* 1978 */     if (target == null) {
/* 1979 */       return null;
/*      */     }
/* 1981 */     List<String> result = new ArrayList(target.size() + 2);
/* 1982 */     for (Object element : target) {
/* 1983 */       result.add(escapeJava(element));
/*      */     }
/* 1985 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Set<String> setEscapeJava(Set<?> target)
/*      */   {
/* 2004 */     if (target == null) {
/* 2005 */       return null;
/*      */     }
/* 2007 */     Set<String> result = new LinkedHashSet(target.size() + 2);
/* 2008 */     for (Object element : target) {
/* 2009 */       result.add(escapeJava(element));
/*      */     }
/* 2011 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String unescapeJava(Object target)
/*      */   {
/* 2036 */     if (target == null) {
/* 2037 */       return null;
/*      */     }
/* 2039 */     return StringUtils.unescapeJava(target);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String[] arrayUnescapeJava(Object[] target)
/*      */   {
/* 2058 */     if (target == null) {
/* 2059 */       return null;
/*      */     }
/* 2061 */     String[] result = new String[target.length];
/* 2062 */     for (int i = 0; i < target.length; i++) {
/* 2063 */       result[i] = unescapeJava(target[i]);
/*      */     }
/* 2065 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public List<String> listUnescapeJava(List<?> target)
/*      */   {
/* 2084 */     if (target == null) {
/* 2085 */       return null;
/*      */     }
/* 2087 */     List<String> result = new ArrayList(target.size() + 2);
/* 2088 */     for (Object element : target) {
/* 2089 */       result.add(unescapeJava(element));
/*      */     }
/* 2091 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Set<String> setUnescapeJava(Set<?> target)
/*      */   {
/* 2110 */     if (target == null) {
/* 2111 */       return null;
/*      */     }
/* 2113 */     Set<String> result = new LinkedHashSet(target.size() + 2);
/* 2114 */     for (Object element : target) {
/* 2115 */       result.add(unescapeJava(element));
/*      */     }
/* 2117 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String randomAlphanumeric(int count)
/*      */   {
/* 2134 */     return StringUtils.randomAlphanumeric(count);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String defaultString(Object target, Object defaultValue)
/*      */   {
/* 2155 */     if (target == null) {
/* 2156 */       if (defaultValue == null) {
/* 2157 */         return "null";
/*      */       }
/* 2159 */       return defaultValue.toString();
/*      */     }
/*      */     
/* 2162 */     String targetString = target.toString();
/* 2163 */     if (StringUtils.isEmptyOrWhitespace(targetString)) {
/* 2164 */       if (defaultValue == null) {
/* 2165 */         return "null";
/*      */       }
/* 2167 */       return defaultValue.toString();
/*      */     }
/* 2169 */     return targetString;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String[] arrayDefaultString(Object[] target, Object defaultValue)
/*      */   {
/* 2189 */     if (target == null) {
/* 2190 */       return null;
/*      */     }
/* 2192 */     String[] result = new String[target.length];
/* 2193 */     for (int i = 0; i < target.length; i++) {
/* 2194 */       result[i] = defaultString(target[i], defaultValue);
/*      */     }
/* 2196 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public List<String> listDefaultString(List<?> target, Object defaultValue)
/*      */   {
/* 2216 */     if (target == null) {
/* 2217 */       return null;
/*      */     }
/* 2219 */     List<String> result = new ArrayList(target.size() + 2);
/* 2220 */     for (Object element : target) {
/* 2221 */       result.add(defaultString(element, defaultValue));
/*      */     }
/* 2223 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Set<String> setDefaultString(Set<?> target, Object defaultValue)
/*      */   {
/* 2243 */     if (target == null) {
/* 2244 */       return null;
/*      */     }
/* 2246 */     Set<String> result = new LinkedHashSet(target.size() + 2);
/* 2247 */     for (Object element : target) {
/* 2248 */       result.add(defaultString(element, defaultValue));
/*      */     }
/* 2250 */     return result;
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\expression\Strings.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */