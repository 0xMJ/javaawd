/*     */ package org.thymeleaf.expression;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Set;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.util.DateUtils;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Dates
/*     */ {
/*     */   private final Locale locale;
/*     */   
/*     */   public Dates(Locale locale)
/*     */   {
/*  58 */     Validate.notNull(locale, "Locale cannot be null");
/*  59 */     this.locale = locale;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Date create(Object year, Object month, Object day)
/*     */   {
/*  75 */     return DateUtils.create(year, month, day, null, null, null, null, null, this.locale).getTime();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Date create(Object year, Object month, Object day, Object hour, Object minute)
/*     */   {
/*  91 */     return DateUtils.create(year, month, day, hour, minute, null, null, null, this.locale).getTime();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Date create(Object year, Object month, Object day, Object hour, Object minute, Object second)
/*     */   {
/* 108 */     return DateUtils.create(year, month, day, hour, minute, second, null, null, this.locale).getTime();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Date create(Object year, Object month, Object day, Object hour, Object minute, Object second, Object millisecond)
/*     */   {
/* 126 */     return DateUtils.create(year, month, day, hour, minute, second, millisecond, null, this.locale).getTime();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Date createNow()
/*     */   {
/* 136 */     return DateUtils.createNow(null, this.locale).getTime();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Date createNowForTimeZone(Object timeZone)
/*     */   {
/* 147 */     return DateUtils.createNow(timeZone, this.locale).getTime();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Date createToday()
/*     */   {
/* 157 */     return DateUtils.createToday(null, this.locale).getTime();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Date createTodayForTimeZone(Object timeZone)
/*     */   {
/* 168 */     return DateUtils.createToday(timeZone, this.locale).getTime();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String format(Date target)
/*     */   {
/* 175 */     if (target == null) {
/* 176 */       return null;
/*     */     }
/*     */     try {
/* 179 */       return DateUtils.format(target, this.locale);
/*     */     } catch (Exception e) {
/* 181 */       throw new TemplateProcessingException("Error formatting date with standard format for locale " + this.locale, e);
/*     */     }
/*     */   }
/*     */   
/*     */   public String[] arrayFormat(Object[] target)
/*     */   {
/* 187 */     if (target == null) {
/* 188 */       return null;
/*     */     }
/* 190 */     String[] result = new String[target.length];
/* 191 */     for (int i = 0; i < target.length; i++) {
/* 192 */       result[i] = format((Date)target[i]);
/*     */     }
/* 194 */     return result;
/*     */   }
/*     */   
/*     */   public List<String> listFormat(List<? extends Date> target) {
/* 198 */     if (target == null) {
/* 199 */       return null;
/*     */     }
/* 201 */     List<String> result = new ArrayList(target.size() + 2);
/* 202 */     for (Date element : target) {
/* 203 */       result.add(format(element));
/*     */     }
/* 205 */     return result;
/*     */   }
/*     */   
/*     */   public Set<String> setFormat(Set<? extends Date> target) {
/* 209 */     if (target == null) {
/* 210 */       return null;
/*     */     }
/* 212 */     Set<String> result = new LinkedHashSet(target.size() + 2);
/* 213 */     for (Date element : target) {
/* 214 */       result.add(format(element));
/*     */     }
/* 216 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String format(Date target, String pattern)
/*     */   {
/* 223 */     if (target == null) {
/* 224 */       return null;
/*     */     }
/*     */     try {
/* 227 */       return DateUtils.format(target, pattern, this.locale);
/*     */     } catch (Exception e) {
/* 229 */       throw new TemplateProcessingException("Error formatting date with format pattern \"" + pattern + "\"", e);
/*     */     }
/*     */   }
/*     */   
/*     */   public String[] arrayFormat(Object[] target, String pattern)
/*     */   {
/* 235 */     if (target == null) {
/* 236 */       return null;
/*     */     }
/* 238 */     String[] result = new String[target.length];
/* 239 */     for (int i = 0; i < target.length; i++) {
/* 240 */       result[i] = format((Date)target[i], pattern);
/*     */     }
/* 242 */     return result;
/*     */   }
/*     */   
/*     */   public List<String> listFormat(List<? extends Date> target, String pattern) {
/* 246 */     if (target == null) {
/* 247 */       return null;
/*     */     }
/* 249 */     List<String> result = new ArrayList(target.size() + 2);
/* 250 */     for (Date element : target) {
/* 251 */       result.add(format(element, pattern));
/*     */     }
/* 253 */     return result;
/*     */   }
/*     */   
/*     */   public Set<String> setFormat(Set<? extends Date> target, String pattern) {
/* 257 */     if (target == null) {
/* 258 */       return null;
/*     */     }
/* 260 */     Set<String> result = new LinkedHashSet(target.size() + 2);
/* 261 */     for (Date element : target) {
/* 262 */       result.add(format(element, pattern));
/*     */     }
/* 264 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Integer day(Date target)
/*     */   {
/* 272 */     if (target == null) {
/* 273 */       return null;
/*     */     }
/* 275 */     return DateUtils.day(target);
/*     */   }
/*     */   
/*     */   public Integer[] arrayDay(Object[] target) {
/* 279 */     if (target == null) {
/* 280 */       return null;
/*     */     }
/* 282 */     Integer[] result = new Integer[target.length];
/* 283 */     for (int i = 0; i < target.length; i++) {
/* 284 */       result[i] = day((Date)target[i]);
/*     */     }
/* 286 */     return result;
/*     */   }
/*     */   
/*     */   public List<Integer> listDay(List<? extends Date> target) {
/* 290 */     if (target == null) {
/* 291 */       return null;
/*     */     }
/* 293 */     List<Integer> result = new ArrayList(target.size() + 2);
/* 294 */     for (Date element : target) {
/* 295 */       result.add(day(element));
/*     */     }
/* 297 */     return result;
/*     */   }
/*     */   
/*     */   public Set<Integer> setDay(Set<? extends Date> target) {
/* 301 */     if (target == null) {
/* 302 */       return null;
/*     */     }
/* 304 */     Set<Integer> result = new LinkedHashSet(target.size() + 2);
/* 305 */     for (Date element : target) {
/* 306 */       result.add(day(element));
/*     */     }
/* 308 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Integer month(Date target)
/*     */   {
/* 316 */     if (target == null) {
/* 317 */       return null;
/*     */     }
/* 319 */     return DateUtils.month(target);
/*     */   }
/*     */   
/*     */   public Integer[] arrayMonth(Object[] target) {
/* 323 */     if (target == null) {
/* 324 */       return null;
/*     */     }
/* 326 */     Integer[] result = new Integer[target.length];
/* 327 */     for (int i = 0; i < target.length; i++) {
/* 328 */       result[i] = month((Date)target[i]);
/*     */     }
/* 330 */     return result;
/*     */   }
/*     */   
/*     */   public List<Integer> listMonth(List<? extends Date> target) {
/* 334 */     if (target == null) {
/* 335 */       return null;
/*     */     }
/* 337 */     List<Integer> result = new ArrayList(target.size() + 2);
/* 338 */     for (Date element : target) {
/* 339 */       result.add(month(element));
/*     */     }
/* 341 */     return result;
/*     */   }
/*     */   
/*     */   public Set<Integer> setMonth(Set<? extends Date> target) {
/* 345 */     if (target == null) {
/* 346 */       return null;
/*     */     }
/* 348 */     Set<Integer> result = new LinkedHashSet(target.size() + 2);
/* 349 */     for (Date element : target) {
/* 350 */       result.add(month(element));
/*     */     }
/* 352 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String monthName(Date target)
/*     */   {
/* 360 */     if (target == null) {
/* 361 */       return null;
/*     */     }
/* 363 */     return DateUtils.monthName(target, this.locale);
/*     */   }
/*     */   
/*     */   public String[] arrayMonthName(Object[] target) {
/* 367 */     if (target == null) {
/* 368 */       return null;
/*     */     }
/* 370 */     String[] result = new String[target.length];
/* 371 */     for (int i = 0; i < target.length; i++) {
/* 372 */       result[i] = monthName((Date)target[i]);
/*     */     }
/* 374 */     return result;
/*     */   }
/*     */   
/*     */   public List<String> listMonthName(List<? extends Date> target) {
/* 378 */     if (target == null) {
/* 379 */       return null;
/*     */     }
/* 381 */     List<String> result = new ArrayList(target.size() + 2);
/* 382 */     for (Date element : target) {
/* 383 */       result.add(monthName(element));
/*     */     }
/* 385 */     return result;
/*     */   }
/*     */   
/*     */   public Set<String> setMonthName(Set<? extends Date> target) {
/* 389 */     if (target == null) {
/* 390 */       return null;
/*     */     }
/* 392 */     Set<String> result = new LinkedHashSet(target.size() + 2);
/* 393 */     for (Date element : target) {
/* 394 */       result.add(monthName(element));
/*     */     }
/* 396 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String monthNameShort(Date target)
/*     */   {
/* 403 */     if (target == null) {
/* 404 */       return null;
/*     */     }
/* 406 */     return DateUtils.monthNameShort(target, this.locale);
/*     */   }
/*     */   
/*     */   public String[] arrayMonthNameShort(Object[] target) {
/* 410 */     if (target == null) {
/* 411 */       return null;
/*     */     }
/* 413 */     String[] result = new String[target.length];
/* 414 */     for (int i = 0; i < target.length; i++) {
/* 415 */       result[i] = monthNameShort((Date)target[i]);
/*     */     }
/* 417 */     return result;
/*     */   }
/*     */   
/*     */   public List<String> listMonthNameShort(List<? extends Date> target) {
/* 421 */     if (target == null) {
/* 422 */       return null;
/*     */     }
/* 424 */     List<String> result = new ArrayList(target.size() + 2);
/* 425 */     for (Date element : target) {
/* 426 */       result.add(monthNameShort(element));
/*     */     }
/* 428 */     return result;
/*     */   }
/*     */   
/*     */   public Set<String> setMonthNameShort(Set<? extends Date> target) {
/* 432 */     if (target == null) {
/* 433 */       return null;
/*     */     }
/* 435 */     Set<String> result = new LinkedHashSet(target.size() + 2);
/* 436 */     for (Date element : target) {
/* 437 */       result.add(monthNameShort(element));
/*     */     }
/* 439 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Integer year(Date target)
/*     */   {
/* 448 */     if (target == null) {
/* 449 */       return null;
/*     */     }
/* 451 */     return DateUtils.year(target);
/*     */   }
/*     */   
/*     */   public Integer[] arrayYear(Object[] target) {
/* 455 */     if (target == null) {
/* 456 */       return null;
/*     */     }
/* 458 */     Integer[] result = new Integer[target.length];
/* 459 */     for (int i = 0; i < target.length; i++) {
/* 460 */       result[i] = year((Date)target[i]);
/*     */     }
/* 462 */     return result;
/*     */   }
/*     */   
/*     */   public List<Integer> listYear(List<? extends Date> target) {
/* 466 */     if (target == null) {
/* 467 */       return null;
/*     */     }
/* 469 */     List<Integer> result = new ArrayList(target.size() + 2);
/* 470 */     for (Date element : target) {
/* 471 */       result.add(year(element));
/*     */     }
/* 473 */     return result;
/*     */   }
/*     */   
/*     */   public Set<Integer> setYear(Set<? extends Date> target) {
/* 477 */     if (target == null) {
/* 478 */       return null;
/*     */     }
/* 480 */     Set<Integer> result = new LinkedHashSet(target.size() + 2);
/* 481 */     for (Date element : target) {
/* 482 */       result.add(year(element));
/*     */     }
/* 484 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Integer dayOfWeek(Date target)
/*     */   {
/* 492 */     if (target == null) {
/* 493 */       return null;
/*     */     }
/* 495 */     return DateUtils.dayOfWeek(target);
/*     */   }
/*     */   
/*     */   public Integer[] arrayDayOfWeek(Object[] target) {
/* 499 */     if (target == null) {
/* 500 */       return null;
/*     */     }
/* 502 */     Integer[] result = new Integer[target.length];
/* 503 */     for (int i = 0; i < target.length; i++) {
/* 504 */       result[i] = dayOfWeek((Date)target[i]);
/*     */     }
/* 506 */     return result;
/*     */   }
/*     */   
/*     */   public List<Integer> listDayOfWeek(List<? extends Date> target) {
/* 510 */     if (target == null) {
/* 511 */       return null;
/*     */     }
/* 513 */     List<Integer> result = new ArrayList(target.size() + 2);
/* 514 */     for (Date element : target) {
/* 515 */       result.add(dayOfWeek(element));
/*     */     }
/* 517 */     return result;
/*     */   }
/*     */   
/*     */   public Set<Integer> setDayOfWeek(Set<? extends Date> target) {
/* 521 */     if (target == null) {
/* 522 */       return null;
/*     */     }
/* 524 */     Set<Integer> result = new LinkedHashSet(target.size() + 2);
/* 525 */     for (Date element : target) {
/* 526 */       result.add(dayOfWeek(element));
/*     */     }
/* 528 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String dayOfWeekName(Date target)
/*     */   {
/* 537 */     if (target == null) {
/* 538 */       return null;
/*     */     }
/* 540 */     return DateUtils.dayOfWeekName(target, this.locale);
/*     */   }
/*     */   
/*     */   public String[] arrayDayOfWeekName(Object[] target) {
/* 544 */     if (target == null) {
/* 545 */       return null;
/*     */     }
/* 547 */     String[] result = new String[target.length];
/* 548 */     for (int i = 0; i < target.length; i++) {
/* 549 */       result[i] = dayOfWeekName((Date)target[i]);
/*     */     }
/* 551 */     return result;
/*     */   }
/*     */   
/*     */   public List<String> listDayOfWeekName(List<? extends Date> target) {
/* 555 */     if (target == null) {
/* 556 */       return null;
/*     */     }
/* 558 */     List<String> result = new ArrayList(target.size() + 2);
/* 559 */     for (Date element : target) {
/* 560 */       result.add(dayOfWeekName(element));
/*     */     }
/* 562 */     return result;
/*     */   }
/*     */   
/*     */   public Set<String> setDayOfWeekName(Set<? extends Date> target) {
/* 566 */     if (target == null) {
/* 567 */       return null;
/*     */     }
/* 569 */     Set<String> result = new LinkedHashSet(target.size() + 2);
/* 570 */     for (Date element : target) {
/* 571 */       result.add(dayOfWeekName(element));
/*     */     }
/* 573 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String dayOfWeekNameShort(Date target)
/*     */   {
/* 582 */     if (target == null) {
/* 583 */       return null;
/*     */     }
/* 585 */     return DateUtils.dayOfWeekNameShort(target, this.locale);
/*     */   }
/*     */   
/*     */   public String[] arrayDayOfWeekNameShort(Object[] target) {
/* 589 */     if (target == null) {
/* 590 */       return null;
/*     */     }
/* 592 */     String[] result = new String[target.length];
/* 593 */     for (int i = 0; i < target.length; i++) {
/* 594 */       result[i] = dayOfWeekNameShort((Date)target[i]);
/*     */     }
/* 596 */     return result;
/*     */   }
/*     */   
/*     */   public List<String> listDayOfWeekNameShort(List<? extends Date> target) {
/* 600 */     if (target == null) {
/* 601 */       return null;
/*     */     }
/* 603 */     List<String> result = new ArrayList(target.size() + 2);
/* 604 */     for (Date element : target) {
/* 605 */       result.add(dayOfWeekNameShort(element));
/*     */     }
/* 607 */     return result;
/*     */   }
/*     */   
/*     */   public Set<String> setDayOfWeekNameShort(Set<? extends Date> target) {
/* 611 */     if (target == null) {
/* 612 */       return null;
/*     */     }
/* 614 */     Set<String> result = new LinkedHashSet(target.size() + 2);
/* 615 */     for (Date element : target) {
/* 616 */       result.add(dayOfWeekNameShort(element));
/*     */     }
/* 618 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Integer hour(Date target)
/*     */   {
/* 632 */     if (target == null) {
/* 633 */       return null;
/*     */     }
/* 635 */     return DateUtils.hour(target);
/*     */   }
/*     */   
/*     */   public Integer[] arrayHour(Object[] target) {
/* 639 */     if (target == null) {
/* 640 */       return null;
/*     */     }
/* 642 */     Integer[] result = new Integer[target.length];
/* 643 */     for (int i = 0; i < target.length; i++) {
/* 644 */       result[i] = hour((Date)target[i]);
/*     */     }
/* 646 */     return result;
/*     */   }
/*     */   
/*     */   public List<Integer> listHour(List<? extends Date> target) {
/* 650 */     if (target == null) {
/* 651 */       return null;
/*     */     }
/* 653 */     List<Integer> result = new ArrayList(target.size() + 2);
/* 654 */     for (Date element : target) {
/* 655 */       result.add(hour(element));
/*     */     }
/* 657 */     return result;
/*     */   }
/*     */   
/*     */   public Set<Integer> setHour(Set<? extends Date> target) {
/* 661 */     if (target == null) {
/* 662 */       return null;
/*     */     }
/* 664 */     Set<Integer> result = new LinkedHashSet(target.size() + 2);
/* 665 */     for (Date element : target) {
/* 666 */       result.add(hour(element));
/*     */     }
/* 668 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Integer minute(Date target)
/*     */   {
/* 678 */     if (target == null) {
/* 679 */       return null;
/*     */     }
/* 681 */     return DateUtils.minute(target);
/*     */   }
/*     */   
/*     */   public Integer[] arrayMinute(Object[] target) {
/* 685 */     if (target == null) {
/* 686 */       return null;
/*     */     }
/* 688 */     Integer[] result = new Integer[target.length];
/* 689 */     for (int i = 0; i < target.length; i++) {
/* 690 */       result[i] = minute((Date)target[i]);
/*     */     }
/* 692 */     return result;
/*     */   }
/*     */   
/*     */   public List<Integer> listMinute(List<? extends Date> target) {
/* 696 */     if (target == null) {
/* 697 */       return null;
/*     */     }
/* 699 */     List<Integer> result = new ArrayList(target.size() + 2);
/* 700 */     for (Date element : target) {
/* 701 */       result.add(minute(element));
/*     */     }
/* 703 */     return result;
/*     */   }
/*     */   
/*     */   public Set<Integer> setMinute(Set<? extends Date> target) {
/* 707 */     if (target == null) {
/* 708 */       return null;
/*     */     }
/* 710 */     Set<Integer> result = new LinkedHashSet(target.size() + 2);
/* 711 */     for (Date element : target) {
/* 712 */       result.add(minute(element));
/*     */     }
/* 714 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Integer second(Date target)
/*     */   {
/* 724 */     if (target == null) {
/* 725 */       return null;
/*     */     }
/* 727 */     return DateUtils.second(target);
/*     */   }
/*     */   
/*     */   public Integer[] arraySecond(Object[] target) {
/* 731 */     if (target == null) {
/* 732 */       return null;
/*     */     }
/* 734 */     Integer[] result = new Integer[target.length];
/* 735 */     for (int i = 0; i < target.length; i++) {
/* 736 */       result[i] = second((Date)target[i]);
/*     */     }
/* 738 */     return result;
/*     */   }
/*     */   
/*     */   public List<Integer> listSecond(List<? extends Date> target) {
/* 742 */     if (target == null) {
/* 743 */       return null;
/*     */     }
/* 745 */     List<Integer> result = new ArrayList(target.size() + 2);
/* 746 */     for (Date element : target) {
/* 747 */       result.add(second(element));
/*     */     }
/* 749 */     return result;
/*     */   }
/*     */   
/*     */   public Set<Integer> setSecond(Set<? extends Date> target) {
/* 753 */     if (target == null) {
/* 754 */       return null;
/*     */     }
/* 756 */     Set<Integer> result = new LinkedHashSet(target.size() + 2);
/* 757 */     for (Date element : target) {
/* 758 */       result.add(second(element));
/*     */     }
/* 760 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Integer millisecond(Date target)
/*     */   {
/* 770 */     if (target == null) {
/* 771 */       return null;
/*     */     }
/* 773 */     return DateUtils.millisecond(target);
/*     */   }
/*     */   
/*     */   public Integer[] arrayMillisecond(Object[] target) {
/* 777 */     if (target == null) {
/* 778 */       return null;
/*     */     }
/* 780 */     Integer[] result = new Integer[target.length];
/* 781 */     for (int i = 0; i < target.length; i++) {
/* 782 */       result[i] = millisecond((Date)target[i]);
/*     */     }
/* 784 */     return result;
/*     */   }
/*     */   
/*     */   public List<Integer> listMillisecond(List<? extends Date> target) {
/* 788 */     if (target == null) {
/* 789 */       return null;
/*     */     }
/* 791 */     List<Integer> result = new ArrayList(target.size() + 2);
/* 792 */     for (Date element : target) {
/* 793 */       result.add(millisecond(element));
/*     */     }
/* 795 */     return result;
/*     */   }
/*     */   
/*     */   public Set<Integer> setMillisecond(Set<? extends Date> target) {
/* 799 */     if (target == null) {
/* 800 */       return null;
/*     */     }
/* 802 */     Set<Integer> result = new LinkedHashSet(target.size() + 2);
/* 803 */     for (Date element : target) {
/* 804 */       result.add(millisecond(element));
/*     */     }
/* 806 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String formatISO(Date target)
/*     */   {
/* 819 */     if (target == null) {
/* 820 */       return null;
/*     */     }
/*     */     try {
/* 823 */       return DateUtils.formatISO(target);
/*     */     } catch (Exception e) {
/* 825 */       throw new TemplateProcessingException("Error formatting date as ISO8601", e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] arrayFormatISO(Object[] target)
/*     */   {
/* 836 */     if (target == null) {
/* 837 */       return null;
/*     */     }
/* 839 */     String[] result = new String[target.length];
/* 840 */     for (int i = 0; i < target.length; i++) {
/* 841 */       result[i] = formatISO((Date)target[i]);
/*     */     }
/* 843 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<String> listFormatISO(List<? extends Date> target)
/*     */   {
/* 853 */     if (target == null) {
/* 854 */       return null;
/*     */     }
/* 856 */     List<String> result = new ArrayList(target.size() + 2);
/* 857 */     for (Date element : target) {
/* 858 */       result.add(formatISO(element));
/*     */     }
/* 860 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Set<String> setFormatISO(Set<? extends Date> target)
/*     */   {
/* 870 */     if (target == null) {
/* 871 */       return null;
/*     */     }
/* 873 */     Set<String> result = new LinkedHashSet(target.size() + 2);
/* 874 */     for (Date element : target) {
/* 875 */       result.add(formatISO(element));
/*     */     }
/* 877 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\expression\Dates.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */