/*     */ package org.thymeleaf.expression;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.thymeleaf.context.ITemplateContext;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Messages
/*     */ {
/*  46 */   private static final String[] NO_PARAMETERS = new String[0];
/*     */   
/*     */   private final ITemplateContext context;
/*     */   
/*     */ 
/*     */   public String msg(String messageKey)
/*     */   {
/*  53 */     return msgWithParams(messageKey, NO_PARAMETERS);
/*     */   }
/*     */   
/*     */   public String msg(String messageKey, Object messageParameter0) {
/*  57 */     return msgWithParams(messageKey, new Object[] { messageParameter0 });
/*     */   }
/*     */   
/*     */   public String msg(String messageKey, Object messageParameter0, Object messageParameter1) {
/*  61 */     return msgWithParams(messageKey, new Object[] { messageParameter0, messageParameter1 });
/*     */   }
/*     */   
/*     */   public String msg(String messageKey, Object messageParameter0, Object messageParameter1, Object messageParameter2) {
/*  65 */     return msgWithParams(messageKey, new Object[] { messageParameter0, messageParameter1, messageParameter2 });
/*     */   }
/*     */   
/*     */   public String msgWithParams(String messageKey, Object[] messageParameters) {
/*  69 */     return this.context.getMessage(null, messageKey, messageParameters, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String msgOrNull(String messageKey)
/*     */   {
/*  76 */     return msgOrNullWithParams(messageKey, NO_PARAMETERS);
/*     */   }
/*     */   
/*     */   public String msgOrNull(String messageKey, Object messageParameter0) {
/*  80 */     return msgOrNullWithParams(messageKey, new Object[] { messageParameter0 });
/*     */   }
/*     */   
/*     */   public String msgOrNull(String messageKey, Object messageParameter0, Object messageParameter1) {
/*  84 */     return msgOrNullWithParams(messageKey, new Object[] { messageParameter0, messageParameter1 });
/*     */   }
/*     */   
/*     */   public String msgOrNull(String messageKey, Object messageParameter0, Object messageParameter1, Object messageParameter2) {
/*  88 */     return msgOrNullWithParams(messageKey, new Object[] { messageParameter0, messageParameter1, messageParameter2 });
/*     */   }
/*     */   
/*     */   public String msgOrNullWithParams(String messageKey, Object[] messageParameters) {
/*  92 */     return this.context.getMessage(null, messageKey, messageParameters, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] arrayMsg(Object[] messageKeys)
/*     */   {
/* 101 */     return arrayMsgWithParams(messageKeys, NO_PARAMETERS);
/*     */   }
/*     */   
/*     */   public String[] arrayMsg(Object[] messageKeys, Object messageParameter0) {
/* 105 */     return arrayMsgWithParams(messageKeys, new Object[] { messageParameter0 });
/*     */   }
/*     */   
/*     */   public String[] arrayMsg(Object[] messageKeys, Object messageParameter0, Object messageParameter1) {
/* 109 */     return arrayMsgWithParams(messageKeys, new Object[] { messageParameter0, messageParameter1 });
/*     */   }
/*     */   
/*     */   public String[] arrayMsg(Object[] messageKeys, Object messageParameter0, Object messageParameter1, Object messageParameter2) {
/* 113 */     return arrayMsgWithParams(messageKeys, new Object[] { messageParameter0, messageParameter1, messageParameter2 });
/*     */   }
/*     */   
/*     */   public String[] arrayMsgWithParams(Object[] messageKeys, Object[] messageParameters) {
/* 117 */     Validate.notNull(messageKeys, "Message keys cannot be null");
/* 118 */     String[] result = new String[messageKeys.length];
/* 119 */     for (int i = 0; i < messageKeys.length; i++)
/*     */     {
/* 121 */       result[i] = this.context.getMessage(null, (String)messageKeys[i], messageParameters, true);
/*     */     }
/* 123 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] arrayMsgOrNull(Object[] messageKeys)
/*     */   {
/* 131 */     return arrayMsgOrNullWithParams(messageKeys, NO_PARAMETERS);
/*     */   }
/*     */   
/*     */   public String[] arrayMsgOrNull(Object[] messageKeys, Object messageParameter0) {
/* 135 */     return arrayMsgOrNullWithParams(messageKeys, new Object[] { messageParameter0 });
/*     */   }
/*     */   
/*     */   public String[] arrayMsgOrNull(Object[] messageKeys, Object messageParameter0, Object messageParameter1) {
/* 139 */     return arrayMsgOrNullWithParams(messageKeys, new Object[] { messageParameter0, messageParameter1 });
/*     */   }
/*     */   
/*     */   public String[] arrayMsgOrNull(Object[] messageKeys, Object messageParameter0, Object messageParameter1, Object messageParameter2) {
/* 143 */     return arrayMsgOrNullWithParams(messageKeys, new Object[] { messageParameter0, messageParameter1, messageParameter2 });
/*     */   }
/*     */   
/*     */   public String[] arrayMsgOrNullWithParams(Object[] messageKeys, Object[] messageParameters) {
/* 147 */     Validate.notNull(messageKeys, "Message keys cannot be null");
/* 148 */     String[] result = new String[messageKeys.length];
/* 149 */     for (int i = 0; i < messageKeys.length; i++)
/*     */     {
/* 151 */       result[i] = this.context.getMessage(null, (String)messageKeys[i], messageParameters, false);
/*     */     }
/* 153 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<String> listMsg(List<String> messageKeys)
/*     */   {
/* 162 */     return listMsgWithParams(messageKeys, NO_PARAMETERS);
/*     */   }
/*     */   
/*     */   public List<String> listMsg(List<String> messageKeys, Object messageParameter0) {
/* 166 */     return listMsgWithParams(messageKeys, new Object[] { messageParameter0 });
/*     */   }
/*     */   
/*     */   public List<String> listMsg(List<String> messageKeys, Object messageParameter0, Object messageParameter1) {
/* 170 */     return listMsgWithParams(messageKeys, new Object[] { messageParameter0, messageParameter1 });
/*     */   }
/*     */   
/*     */   public List<String> listMsg(List<String> messageKeys, Object messageParameter0, Object messageParameter1, Object messageParameter2) {
/* 174 */     return listMsgWithParams(messageKeys, new Object[] { messageParameter0, messageParameter1, messageParameter2 });
/*     */   }
/*     */   
/*     */   public List<String> listMsgWithParams(List<String> messageKeys, Object[] messageParameters) {
/* 178 */     Validate.notNull(messageKeys, "Message keys cannot be null");
/* 179 */     return doMsg(true, messageKeys, messageParameters);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<String> listMsgOrNull(List<String> messageKeys)
/*     */   {
/* 188 */     return listMsgOrNullWithParams(messageKeys, NO_PARAMETERS);
/*     */   }
/*     */   
/*     */   public List<String> listMsgOrNull(List<String> messageKeys, Object messageParameter0) {
/* 192 */     return listMsgOrNullWithParams(messageKeys, new Object[] { messageParameter0 });
/*     */   }
/*     */   
/*     */   public List<String> listMsgOrNull(List<String> messageKeys, Object messageParameter0, Object messageParameter1) {
/* 196 */     return listMsgOrNullWithParams(messageKeys, new Object[] { messageParameter0, messageParameter1 });
/*     */   }
/*     */   
/*     */   public List<String> listMsgOrNull(List<String> messageKeys, Object messageParameter0, Object messageParameter1, Object messageParameter2) {
/* 200 */     return listMsgOrNullWithParams(messageKeys, new Object[] { messageParameter0, messageParameter1, messageParameter2 });
/*     */   }
/*     */   
/*     */   public List<String> listMsgOrNullWithParams(List<String> messageKeys, Object[] messageParameters) {
/* 204 */     Validate.notNull(messageKeys, "Message keys cannot be null");
/* 205 */     return doMsg(false, messageKeys, messageParameters);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Set<String> setMsg(Set<String> messageKeys)
/*     */   {
/* 214 */     return setMsgWithParams(messageKeys, NO_PARAMETERS);
/*     */   }
/*     */   
/*     */   public Set<String> setMsg(Set<String> messageKeys, Object messageParameter0) {
/* 218 */     return setMsgWithParams(messageKeys, new Object[] { messageParameter0 });
/*     */   }
/*     */   
/*     */   public Set<String> setMsg(Set<String> messageKeys, Object messageParameter0, Object messageParameter1) {
/* 222 */     return setMsgWithParams(messageKeys, new Object[] { messageParameter0, messageParameter1 });
/*     */   }
/*     */   
/*     */   public Set<String> setMsg(Set<String> messageKeys, Object messageParameter0, Object messageParameter1, Object messageParameter2) {
/* 226 */     return setMsgWithParams(messageKeys, new Object[] { messageParameter0, messageParameter1, messageParameter2 });
/*     */   }
/*     */   
/*     */   public Set<String> setMsgWithParams(Set<String> messageKeys, Object[] messageParameters) {
/* 230 */     Validate.notNull(messageKeys, "Message keys cannot be null");
/* 231 */     return new LinkedHashSet(doMsg(true, messageKeys, messageParameters));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Set<String> setMsgOrNull(Set<String> messageKeys)
/*     */   {
/* 239 */     return setMsgOrNullWithParams(messageKeys, NO_PARAMETERS);
/*     */   }
/*     */   
/*     */   public Set<String> setMsgOrNull(Set<String> messageKeys, Object messageParameter0) {
/* 243 */     return setMsgOrNullWithParams(messageKeys, new Object[] { messageParameter0 });
/*     */   }
/*     */   
/*     */   public Set<String> setMsgOrNull(Set<String> messageKeys, Object messageParameter0, Object messageParameter1) {
/* 247 */     return setMsgOrNullWithParams(messageKeys, new Object[] { messageParameter0, messageParameter1 });
/*     */   }
/*     */   
/*     */   public Set<String> setMsgOrNull(Set<String> messageKeys, Object messageParameter0, Object messageParameter1, Object messageParameter2) {
/* 251 */     return setMsgOrNullWithParams(messageKeys, new Object[] { messageParameter0, messageParameter1, messageParameter2 });
/*     */   }
/*     */   
/*     */   public Set<String> setMsgOrNullWithParams(Set<String> messageKeys, Object[] messageParameters) {
/* 255 */     Validate.notNull(messageKeys, "Message keys cannot be null");
/* 256 */     return new LinkedHashSet(doMsg(false, messageKeys, messageParameters));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private List<String> doMsg(boolean useAbsentMessageRepresentation, Iterable<String> messageKeys, Object... messageParameters)
/*     */   {
/* 266 */     List<String> result = new ArrayList(5);
/* 267 */     for (String messageKey : messageKeys) {
/* 268 */       result.add(this.context
/* 269 */         .getMessage(null, messageKey, messageParameters, useAbsentMessageRepresentation));
/*     */     }
/* 271 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Messages(ITemplateContext context)
/*     */   {
/* 279 */     Validate.notNull(context, "Context cannot be null");
/* 280 */     this.context = context;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\expression\Messages.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */