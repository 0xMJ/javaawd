/*    */ package org.thymeleaf.expression;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.LinkedHashSet;
/*    */ import java.util.List;
/*    */ import java.util.Set;
/*    */ import org.thymeleaf.util.ObjectUtils;
/*    */ import org.thymeleaf.util.Validate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Objects
/*    */ {
/*    */   public <T> T nullSafe(T target, T defaultValue)
/*    */   {
/* 50 */     return (T)ObjectUtils.nullSafe(target, defaultValue);
/*    */   }
/*    */   
/*    */   public <T> T[] arrayNullSafe(T[] target, T defaultValue) {
/* 54 */     Validate.notNull(target, "Target cannot be null");
/* 55 */     T[] result = (Object[])target.clone();
/* 56 */     for (int i = 0; i < target.length; i++) {
/* 57 */       result[i] = nullSafe(target[i], defaultValue);
/*    */     }
/* 59 */     return result;
/*    */   }
/*    */   
/*    */   public <T> List<T> listNullSafe(List<T> target, T defaultValue) {
/* 63 */     Validate.notNull(target, "Target cannot be null");
/* 64 */     List<T> result = new ArrayList(target.size() + 2);
/* 65 */     for (T element : target) {
/* 66 */       result.add(nullSafe(element, defaultValue));
/*    */     }
/* 68 */     return result;
/*    */   }
/*    */   
/*    */   public <T> Set<T> setNullSafe(Set<T> target, T defaultValue) {
/* 72 */     Validate.notNull(target, "Target cannot be null");
/* 73 */     Set<T> result = new LinkedHashSet(target.size() + 2);
/* 74 */     for (T element : target) {
/* 75 */       result.add(nullSafe(element, defaultValue));
/*    */     }
/* 77 */     return result;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\expression\Objects.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */