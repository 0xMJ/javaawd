/*    */ package org.thymeleaf.expression;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import org.thymeleaf.util.ArrayUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Arrays
/*    */ {
/*    */   public Object[] toArray(Object target)
/*    */   {
/* 45 */     return ArrayUtils.toArray(target);
/*    */   }
/*    */   
/*    */   public Object[] toStringArray(Object target) {
/* 49 */     return ArrayUtils.toStringArray(target);
/*    */   }
/*    */   
/*    */   public Object[] toIntegerArray(Object target) {
/* 53 */     return ArrayUtils.toIntegerArray(target);
/*    */   }
/*    */   
/*    */   public Object[] toLongArray(Object target) {
/* 57 */     return ArrayUtils.toLongArray(target);
/*    */   }
/*    */   
/*    */   public Object[] toDoubleArray(Object target) {
/* 61 */     return ArrayUtils.toDoubleArray(target);
/*    */   }
/*    */   
/*    */   public Object[] toFloatArray(Object target) {
/* 65 */     return ArrayUtils.toFloatArray(target);
/*    */   }
/*    */   
/*    */   public Object[] toBooleanArray(Object target) {
/* 69 */     return ArrayUtils.toBooleanArray(target);
/*    */   }
/*    */   
/*    */   public int length(Object[] target)
/*    */   {
/* 74 */     return ArrayUtils.length(target);
/*    */   }
/*    */   
/*    */   public boolean isEmpty(Object[] target)
/*    */   {
/* 79 */     return ArrayUtils.isEmpty(target);
/*    */   }
/*    */   
/*    */   public boolean contains(Object[] target, Object element)
/*    */   {
/* 84 */     return ArrayUtils.contains(target, element);
/*    */   }
/*    */   
/*    */   public boolean containsAll(Object[] target, Object[] elements)
/*    */   {
/* 89 */     return ArrayUtils.containsAll(target, elements);
/*    */   }
/*    */   
/*    */   public boolean containsAll(Object[] target, Collection<?> elements)
/*    */   {
/* 94 */     return ArrayUtils.containsAll(target, elements);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\expression\Arrays.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */