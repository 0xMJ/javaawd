/*     */ package org.thymeleaf.expression;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Calendar;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Set;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.util.DateUtils;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Calendars
/*     */ {
/*     */   private final Locale locale;
/*     */   
/*     */   public Calendars(Locale locale)
/*     */   {
/*  59 */     Validate.notNull(locale, "Locale cannot be null");
/*  60 */     this.locale = locale;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Calendar create(Object year, Object month, Object day)
/*     */   {
/*  74 */     return DateUtils.create(year, month, day, null, null, null, null, null, this.locale);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Calendar create(Object year, Object month, Object day, Object hour, Object minute)
/*     */   {
/*  90 */     return DateUtils.create(year, month, day, hour, minute, null, null, null, this.locale);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Calendar create(Object year, Object month, Object day, Object hour, Object minute, Object second)
/*     */   {
/* 107 */     return DateUtils.create(year, month, day, hour, minute, second, null, null, this.locale);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Calendar create(Object year, Object month, Object day, Object hour, Object minute, Object second, Object millisecond)
/*     */   {
/* 125 */     return DateUtils.create(year, month, day, hour, minute, second, millisecond, null, this.locale);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Calendar createForTimeZone(Object year, Object month, Object day, Object timeZone)
/*     */   {
/* 139 */     return DateUtils.create(year, month, day, null, null, null, null, timeZone, this.locale);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Calendar createForTimeZone(Object year, Object month, Object day, Object hour, Object minute, Object timeZone)
/*     */   {
/* 156 */     return DateUtils.create(year, month, day, hour, minute, null, null, timeZone, this.locale);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Calendar createForTimeZone(Object year, Object month, Object day, Object hour, Object minute, Object second, Object timeZone)
/*     */   {
/* 174 */     return DateUtils.create(year, month, day, hour, minute, second, null, timeZone, this.locale);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Calendar createForTimeZone(Object year, Object month, Object day, Object hour, Object minute, Object second, Object millisecond, Object timeZone)
/*     */   {
/* 194 */     return DateUtils.create(year, month, day, hour, minute, second, millisecond, timeZone, this.locale);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Calendar createNow()
/*     */   {
/* 204 */     return DateUtils.createNow(null, this.locale);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Calendar createNowForTimeZone(Object timeZone)
/*     */   {
/* 215 */     return DateUtils.createNow(timeZone, this.locale);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Calendar createToday()
/*     */   {
/* 225 */     return DateUtils.createToday(null, this.locale);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Calendar createTodayForTimeZone(Object timeZone)
/*     */   {
/* 236 */     return DateUtils.createToday(timeZone, this.locale);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String format(Calendar target)
/*     */   {
/* 243 */     if (target == null) {
/* 244 */       return null;
/*     */     }
/*     */     try {
/* 247 */       return DateUtils.format(target, this.locale);
/*     */     } catch (Exception e) {
/* 249 */       throw new TemplateProcessingException("Error formatting calendar with standard format for locale " + this.locale, e);
/*     */     }
/*     */   }
/*     */   
/*     */   public String[] arrayFormat(Object[] target)
/*     */   {
/* 255 */     if (target == null) {
/* 256 */       return null;
/*     */     }
/* 258 */     String[] result = new String[target.length];
/* 259 */     for (int i = 0; i < target.length; i++) {
/* 260 */       result[i] = format((Calendar)target[i]);
/*     */     }
/* 262 */     return result;
/*     */   }
/*     */   
/*     */   public List<String> listFormat(List<? extends Calendar> target) {
/* 266 */     if (target == null) {
/* 267 */       return null;
/*     */     }
/* 269 */     List<String> result = new ArrayList(target.size() + 2);
/* 270 */     for (Calendar element : target) {
/* 271 */       result.add(format(element));
/*     */     }
/* 273 */     return result;
/*     */   }
/*     */   
/*     */   public Set<String> setFormat(Set<? extends Calendar> target) {
/* 277 */     if (target == null) {
/* 278 */       return null;
/*     */     }
/* 280 */     Set<String> result = new LinkedHashSet(target.size() + 2);
/* 281 */     for (Calendar element : target) {
/* 282 */       result.add(format(element));
/*     */     }
/* 284 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String format(Calendar target, String pattern)
/*     */   {
/* 291 */     if (target == null) {
/* 292 */       return null;
/*     */     }
/*     */     try {
/* 295 */       return DateUtils.format(target, pattern, this.locale);
/*     */     } catch (Exception e) {
/* 297 */       throw new TemplateProcessingException("Error formatting calendar with format pattern \"" + pattern + "\"", e);
/*     */     }
/*     */   }
/*     */   
/*     */   public String[] arrayFormat(Object[] target, String pattern)
/*     */   {
/* 303 */     if (target == null) {
/* 304 */       return null;
/*     */     }
/* 306 */     String[] result = new String[target.length];
/* 307 */     for (int i = 0; i < target.length; i++) {
/* 308 */       result[i] = format((Calendar)target[i], pattern);
/*     */     }
/* 310 */     return result;
/*     */   }
/*     */   
/*     */   public List<String> listFormat(List<? extends Calendar> target, String pattern) {
/* 314 */     if (target == null) {
/* 315 */       return null;
/*     */     }
/* 317 */     List<String> result = new ArrayList(target.size() + 2);
/* 318 */     for (Calendar element : target) {
/* 319 */       result.add(format(element, pattern));
/*     */     }
/* 321 */     return result;
/*     */   }
/*     */   
/*     */   public Set<String> setFormat(Set<? extends Calendar> target, String pattern) {
/* 325 */     if (target == null) {
/* 326 */       return null;
/*     */     }
/* 328 */     Set<String> result = new LinkedHashSet(target.size() + 2);
/* 329 */     for (Calendar element : target) {
/* 330 */       result.add(format(element, pattern));
/*     */     }
/* 332 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Integer day(Calendar target)
/*     */   {
/* 340 */     if (target == null) {
/* 341 */       return null;
/*     */     }
/* 343 */     return DateUtils.day(target);
/*     */   }
/*     */   
/*     */   public Integer[] arrayDay(Object[] target) {
/* 347 */     if (target == null) {
/* 348 */       return null;
/*     */     }
/* 350 */     Integer[] result = new Integer[target.length];
/* 351 */     for (int i = 0; i < target.length; i++) {
/* 352 */       result[i] = day((Calendar)target[i]);
/*     */     }
/* 354 */     return result;
/*     */   }
/*     */   
/*     */   public List<Integer> listDay(List<? extends Calendar> target) {
/* 358 */     if (target == null) {
/* 359 */       return null;
/*     */     }
/* 361 */     List<Integer> result = new ArrayList(target.size() + 2);
/* 362 */     for (Calendar element : target) {
/* 363 */       result.add(day(element));
/*     */     }
/* 365 */     return result;
/*     */   }
/*     */   
/*     */   public Set<Integer> setDay(Set<? extends Calendar> target) {
/* 369 */     if (target == null) {
/* 370 */       return null;
/*     */     }
/* 372 */     Set<Integer> result = new LinkedHashSet(target.size() + 2);
/* 373 */     for (Calendar element : target) {
/* 374 */       result.add(day(element));
/*     */     }
/* 376 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Integer month(Calendar target)
/*     */   {
/* 384 */     if (target == null) {
/* 385 */       return null;
/*     */     }
/* 387 */     return DateUtils.month(target);
/*     */   }
/*     */   
/*     */   public Integer[] arrayMonth(Object[] target) {
/* 391 */     if (target == null) {
/* 392 */       return null;
/*     */     }
/* 394 */     Integer[] result = new Integer[target.length];
/* 395 */     for (int i = 0; i < target.length; i++) {
/* 396 */       result[i] = month((Calendar)target[i]);
/*     */     }
/* 398 */     return result;
/*     */   }
/*     */   
/*     */   public List<Integer> listMonth(List<? extends Calendar> target) {
/* 402 */     if (target == null) {
/* 403 */       return null;
/*     */     }
/* 405 */     List<Integer> result = new ArrayList(target.size() + 2);
/* 406 */     for (Calendar element : target) {
/* 407 */       result.add(month(element));
/*     */     }
/* 409 */     return result;
/*     */   }
/*     */   
/*     */   public Set<Integer> setMonth(Set<? extends Calendar> target) {
/* 413 */     if (target == null) {
/* 414 */       return null;
/*     */     }
/* 416 */     Set<Integer> result = new LinkedHashSet(target.size() + 2);
/* 417 */     for (Calendar element : target) {
/* 418 */       result.add(month(element));
/*     */     }
/* 420 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String monthName(Calendar target)
/*     */   {
/* 428 */     if (target == null) {
/* 429 */       return null;
/*     */     }
/* 431 */     return DateUtils.monthName(target, this.locale);
/*     */   }
/*     */   
/*     */   public String[] arrayMonthName(Object[] target) {
/* 435 */     if (target == null) {
/* 436 */       return null;
/*     */     }
/* 438 */     String[] result = new String[target.length];
/* 439 */     for (int i = 0; i < target.length; i++) {
/* 440 */       result[i] = monthName((Calendar)target[i]);
/*     */     }
/* 442 */     return result;
/*     */   }
/*     */   
/*     */   public List<String> listMonthName(List<? extends Calendar> target) {
/* 446 */     if (target == null) {
/* 447 */       return null;
/*     */     }
/* 449 */     List<String> result = new ArrayList(target.size() + 2);
/* 450 */     for (Calendar element : target) {
/* 451 */       result.add(monthName(element));
/*     */     }
/* 453 */     return result;
/*     */   }
/*     */   
/*     */   public Set<String> setMonthName(Set<? extends Calendar> target) {
/* 457 */     if (target == null) {
/* 458 */       return null;
/*     */     }
/* 460 */     Set<String> result = new LinkedHashSet(target.size() + 2);
/* 461 */     for (Calendar element : target) {
/* 462 */       result.add(monthName(element));
/*     */     }
/* 464 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String monthNameShort(Calendar target)
/*     */   {
/* 471 */     if (target == null) {
/* 472 */       return null;
/*     */     }
/* 474 */     return DateUtils.monthNameShort(target, this.locale);
/*     */   }
/*     */   
/*     */   public String[] arrayMonthNameShort(Object[] target) {
/* 478 */     if (target == null) {
/* 479 */       return null;
/*     */     }
/* 481 */     String[] result = new String[target.length];
/* 482 */     for (int i = 0; i < target.length; i++) {
/* 483 */       result[i] = monthNameShort((Calendar)target[i]);
/*     */     }
/* 485 */     return result;
/*     */   }
/*     */   
/*     */   public List<String> listMonthNameShort(List<? extends Calendar> target) {
/* 489 */     if (target == null) {
/* 490 */       return null;
/*     */     }
/* 492 */     List<String> result = new ArrayList(target.size() + 2);
/* 493 */     for (Calendar element : target) {
/* 494 */       result.add(monthNameShort(element));
/*     */     }
/* 496 */     return result;
/*     */   }
/*     */   
/*     */   public Set<String> setMonthNameShort(Set<? extends Calendar> target) {
/* 500 */     if (target == null) {
/* 501 */       return null;
/*     */     }
/* 503 */     Set<String> result = new LinkedHashSet(target.size() + 2);
/* 504 */     for (Calendar element : target) {
/* 505 */       result.add(monthNameShort(element));
/*     */     }
/* 507 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Integer year(Calendar target)
/*     */   {
/* 516 */     if (target == null) {
/* 517 */       return null;
/*     */     }
/* 519 */     return DateUtils.year(target);
/*     */   }
/*     */   
/*     */   public Integer[] arrayYear(Object[] target) {
/* 523 */     if (target == null) {
/* 524 */       return null;
/*     */     }
/* 526 */     Integer[] result = new Integer[target.length];
/* 527 */     for (int i = 0; i < target.length; i++) {
/* 528 */       result[i] = year((Calendar)target[i]);
/*     */     }
/* 530 */     return result;
/*     */   }
/*     */   
/*     */   public List<Integer> listYear(List<? extends Calendar> target) {
/* 534 */     if (target == null) {
/* 535 */       return null;
/*     */     }
/* 537 */     List<Integer> result = new ArrayList(target.size() + 2);
/* 538 */     for (Calendar element : target) {
/* 539 */       result.add(year(element));
/*     */     }
/* 541 */     return result;
/*     */   }
/*     */   
/*     */   public Set<Integer> setYear(Set<? extends Calendar> target) {
/* 545 */     if (target == null) {
/* 546 */       return null;
/*     */     }
/* 548 */     Set<Integer> result = new LinkedHashSet(target.size() + 2);
/* 549 */     for (Calendar element : target) {
/* 550 */       result.add(year(element));
/*     */     }
/* 552 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Integer dayOfWeek(Calendar target)
/*     */   {
/* 560 */     if (target == null) {
/* 561 */       return null;
/*     */     }
/* 563 */     return DateUtils.dayOfWeek(target);
/*     */   }
/*     */   
/*     */   public Integer[] arrayDayOfWeek(Object[] target) {
/* 567 */     if (target == null) {
/* 568 */       return null;
/*     */     }
/* 570 */     Integer[] result = new Integer[target.length];
/* 571 */     for (int i = 0; i < target.length; i++) {
/* 572 */       result[i] = dayOfWeek((Calendar)target[i]);
/*     */     }
/* 574 */     return result;
/*     */   }
/*     */   
/*     */   public List<Integer> listDayOfWeek(List<? extends Calendar> target) {
/* 578 */     if (target == null) {
/* 579 */       return null;
/*     */     }
/* 581 */     List<Integer> result = new ArrayList(target.size() + 2);
/* 582 */     for (Calendar element : target) {
/* 583 */       result.add(dayOfWeek(element));
/*     */     }
/* 585 */     return result;
/*     */   }
/*     */   
/*     */   public Set<Integer> setDayOfWeek(Set<? extends Calendar> target) {
/* 589 */     if (target == null) {
/* 590 */       return null;
/*     */     }
/* 592 */     Set<Integer> result = new LinkedHashSet(target.size() + 2);
/* 593 */     for (Calendar element : target) {
/* 594 */       result.add(dayOfWeek(element));
/*     */     }
/* 596 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String dayOfWeekName(Calendar target)
/*     */   {
/* 605 */     if (target == null) {
/* 606 */       return null;
/*     */     }
/* 608 */     return DateUtils.dayOfWeekName(target, this.locale);
/*     */   }
/*     */   
/*     */   public String[] arrayDayOfWeekName(Object[] target) {
/* 612 */     if (target == null) {
/* 613 */       return null;
/*     */     }
/* 615 */     String[] result = new String[target.length];
/* 616 */     for (int i = 0; i < target.length; i++) {
/* 617 */       result[i] = dayOfWeekName((Calendar)target[i]);
/*     */     }
/* 619 */     return result;
/*     */   }
/*     */   
/*     */   public List<String> listDayOfWeekName(List<? extends Calendar> target) {
/* 623 */     if (target == null) {
/* 624 */       return null;
/*     */     }
/* 626 */     List<String> result = new ArrayList(target.size() + 2);
/* 627 */     for (Calendar element : target) {
/* 628 */       result.add(dayOfWeekName(element));
/*     */     }
/* 630 */     return result;
/*     */   }
/*     */   
/*     */   public Set<String> setDayOfWeekName(Set<? extends Calendar> target) {
/* 634 */     if (target == null) {
/* 635 */       return null;
/*     */     }
/* 637 */     Set<String> result = new LinkedHashSet(target.size() + 2);
/* 638 */     for (Calendar element : target) {
/* 639 */       result.add(dayOfWeekName(element));
/*     */     }
/* 641 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String dayOfWeekNameShort(Calendar target)
/*     */   {
/* 650 */     if (target == null) {
/* 651 */       return null;
/*     */     }
/* 653 */     return DateUtils.dayOfWeekNameShort(target, this.locale);
/*     */   }
/*     */   
/*     */   public String[] arrayDayOfWeekNameShort(Object[] target) {
/* 657 */     if (target == null) {
/* 658 */       return null;
/*     */     }
/* 660 */     String[] result = new String[target.length];
/* 661 */     for (int i = 0; i < target.length; i++) {
/* 662 */       result[i] = dayOfWeekNameShort((Calendar)target[i]);
/*     */     }
/* 664 */     return result;
/*     */   }
/*     */   
/*     */   public List<String> listDayOfWeekNameShort(List<? extends Calendar> target) {
/* 668 */     if (target == null) {
/* 669 */       return null;
/*     */     }
/* 671 */     List<String> result = new ArrayList(target.size() + 2);
/* 672 */     for (Calendar element : target) {
/* 673 */       result.add(dayOfWeekNameShort(element));
/*     */     }
/* 675 */     return result;
/*     */   }
/*     */   
/*     */   public Set<String> setDayOfWeekNameShort(Set<? extends Calendar> target) {
/* 679 */     if (target == null) {
/* 680 */       return null;
/*     */     }
/* 682 */     Set<String> result = new LinkedHashSet(target.size() + 2);
/* 683 */     for (Calendar element : target) {
/* 684 */       result.add(dayOfWeekNameShort(element));
/*     */     }
/* 686 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Integer hour(Calendar target)
/*     */   {
/* 696 */     if (target == null) {
/* 697 */       return null;
/*     */     }
/* 699 */     return DateUtils.hour(target);
/*     */   }
/*     */   
/*     */   public Integer[] arrayHour(Object[] target) {
/* 703 */     if (target == null) {
/* 704 */       return null;
/*     */     }
/* 706 */     Integer[] result = new Integer[target.length];
/* 707 */     for (int i = 0; i < target.length; i++) {
/* 708 */       result[i] = hour((Calendar)target[i]);
/*     */     }
/* 710 */     return result;
/*     */   }
/*     */   
/*     */   public List<Integer> listHour(List<? extends Calendar> target) {
/* 714 */     if (target == null) {
/* 715 */       return null;
/*     */     }
/* 717 */     List<Integer> result = new ArrayList(target.size() + 2);
/* 718 */     for (Calendar element : target) {
/* 719 */       result.add(hour(element));
/*     */     }
/* 721 */     return result;
/*     */   }
/*     */   
/*     */   public Set<Integer> setHour(Set<? extends Calendar> target) {
/* 725 */     if (target == null) {
/* 726 */       return null;
/*     */     }
/* 728 */     Set<Integer> result = new LinkedHashSet(target.size() + 2);
/* 729 */     for (Calendar element : target) {
/* 730 */       result.add(hour(element));
/*     */     }
/* 732 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Integer minute(Calendar target)
/*     */   {
/* 742 */     if (target == null) {
/* 743 */       return null;
/*     */     }
/* 745 */     return DateUtils.minute(target);
/*     */   }
/*     */   
/*     */   public Integer[] arrayMinute(Object[] target) {
/* 749 */     if (target == null) {
/* 750 */       return null;
/*     */     }
/* 752 */     Integer[] result = new Integer[target.length];
/* 753 */     for (int i = 0; i < target.length; i++) {
/* 754 */       result[i] = minute((Calendar)target[i]);
/*     */     }
/* 756 */     return result;
/*     */   }
/*     */   
/*     */   public List<Integer> listMinute(List<? extends Calendar> target) {
/* 760 */     if (target == null) {
/* 761 */       return null;
/*     */     }
/* 763 */     List<Integer> result = new ArrayList(target.size() + 2);
/* 764 */     for (Calendar element : target) {
/* 765 */       result.add(minute(element));
/*     */     }
/* 767 */     return result;
/*     */   }
/*     */   
/*     */   public Set<Integer> setMinute(Set<? extends Calendar> target) {
/* 771 */     if (target == null) {
/* 772 */       return null;
/*     */     }
/* 774 */     Set<Integer> result = new LinkedHashSet(target.size() + 2);
/* 775 */     for (Calendar element : target) {
/* 776 */       result.add(minute(element));
/*     */     }
/* 778 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Integer second(Calendar target)
/*     */   {
/* 788 */     if (target == null) {
/* 789 */       return null;
/*     */     }
/* 791 */     return DateUtils.second(target);
/*     */   }
/*     */   
/*     */   public Integer[] arraySecond(Object[] target) {
/* 795 */     if (target == null) {
/* 796 */       return null;
/*     */     }
/* 798 */     Integer[] result = new Integer[target.length];
/* 799 */     for (int i = 0; i < target.length; i++) {
/* 800 */       result[i] = second((Calendar)target[i]);
/*     */     }
/* 802 */     return result;
/*     */   }
/*     */   
/*     */   public List<Integer> listSecond(List<? extends Calendar> target) {
/* 806 */     if (target == null) {
/* 807 */       return null;
/*     */     }
/* 809 */     List<Integer> result = new ArrayList(target.size() + 2);
/* 810 */     for (Calendar element : target) {
/* 811 */       result.add(second(element));
/*     */     }
/* 813 */     return result;
/*     */   }
/*     */   
/*     */   public Set<Integer> setSecond(Set<? extends Calendar> target) {
/* 817 */     if (target == null) {
/* 818 */       return null;
/*     */     }
/* 820 */     Set<Integer> result = new LinkedHashSet(target.size() + 2);
/* 821 */     for (Calendar element : target) {
/* 822 */       result.add(second(element));
/*     */     }
/* 824 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Integer millisecond(Calendar target)
/*     */   {
/* 834 */     if (target == null) {
/* 835 */       return null;
/*     */     }
/* 837 */     return DateUtils.millisecond(target);
/*     */   }
/*     */   
/*     */   public Integer[] arrayMillisecond(Object[] target) {
/* 841 */     if (target == null) {
/* 842 */       return null;
/*     */     }
/* 844 */     Integer[] result = new Integer[target.length];
/* 845 */     for (int i = 0; i < target.length; i++) {
/* 846 */       result[i] = millisecond((Calendar)target[i]);
/*     */     }
/* 848 */     return result;
/*     */   }
/*     */   
/*     */   public List<Integer> listMillisecond(List<? extends Calendar> target) {
/* 852 */     if (target == null) {
/* 853 */       return null;
/*     */     }
/* 855 */     List<Integer> result = new ArrayList(target.size() + 2);
/* 856 */     for (Calendar element : target) {
/* 857 */       result.add(millisecond(element));
/*     */     }
/* 859 */     return result;
/*     */   }
/*     */   
/*     */   public Set<Integer> setMillisecond(Set<? extends Calendar> target) {
/* 863 */     if (target == null) {
/* 864 */       return null;
/*     */     }
/* 866 */     Set<Integer> result = new LinkedHashSet(target.size() + 2);
/* 867 */     for (Calendar element : target) {
/* 868 */       result.add(millisecond(element));
/*     */     }
/* 870 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String formatISO(Calendar target)
/*     */   {
/* 882 */     if (target == null) {
/* 883 */       return null;
/*     */     }
/*     */     try {
/* 886 */       return DateUtils.formatISO(target);
/*     */     } catch (Exception e) {
/* 888 */       throw new TemplateProcessingException("Error formatting calendar as ISO8601", e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] arrayFormatISO(Object[] target)
/*     */   {
/* 899 */     if (target == null) {
/* 900 */       return null;
/*     */     }
/* 902 */     String[] result = new String[target.length];
/* 903 */     for (int i = 0; i < target.length; i++) {
/* 904 */       result[i] = formatISO((Calendar)target[i]);
/*     */     }
/* 906 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<String> listFormatISO(List<? extends Calendar> target)
/*     */   {
/* 916 */     if (target == null) {
/* 917 */       return null;
/*     */     }
/* 919 */     List<String> result = new ArrayList(target.size() + 2);
/* 920 */     for (Calendar element : target) {
/* 921 */       result.add(formatISO(element));
/*     */     }
/* 923 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Set<String> setFormatISO(Set<? extends Calendar> target)
/*     */   {
/* 933 */     if (target == null) {
/* 934 */       return null;
/*     */     }
/* 936 */     Set<String> result = new LinkedHashSet(target.size() + 2);
/* 937 */     for (Calendar element : target) {
/* 938 */       result.add(formatISO(element));
/*     */     }
/* 940 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\expression\Calendars.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */