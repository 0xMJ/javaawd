package org.thymeleaf.expression;

import java.util.Set;
import org.thymeleaf.context.IExpressionContext;

public abstract interface IExpressionObjectFactory
{
  public abstract Set<String> getAllExpressionObjectNames();
  
  public abstract Object buildObject(IExpressionContext paramIExpressionContext, String paramString);
  
  public abstract boolean isCacheable(String paramString);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\expression\IExpressionObjectFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */