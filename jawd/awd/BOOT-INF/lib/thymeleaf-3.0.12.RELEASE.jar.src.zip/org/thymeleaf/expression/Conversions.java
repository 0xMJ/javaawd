/*    */ package org.thymeleaf.expression;
/*    */ 
/*    */ import org.thymeleaf.context.IExpressionContext;
/*    */ import org.thymeleaf.standard.expression.IStandardConversionService;
/*    */ import org.thymeleaf.standard.expression.StandardExpressions;
/*    */ import org.thymeleaf.util.ClassLoaderUtils;
/*    */ import org.thymeleaf.util.Validate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Conversions
/*    */ {
/*    */   private final IExpressionContext context;
/*    */   
/*    */   public Conversions(IExpressionContext context)
/*    */   {
/* 54 */     Validate.notNull(context, "Context cannot be null");
/* 55 */     this.context = context;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public Object convert(Object target, String className)
/*    */   {
/*    */     try
/*    */     {
/* 64 */       Class<?> clazz = ClassLoaderUtils.loadClass(className);
/* 65 */       return convert(target, clazz);
/*    */     } catch (ClassNotFoundException e) {
/*    */       try {
/* 68 */         Class<?> clazz = ClassLoaderUtils.loadClass("java.lang." + className);
/* 69 */         return convert(target, clazz);
/*    */       } catch (ClassNotFoundException ex) {
/* 71 */         throw new IllegalArgumentException("Cannot convert to class '" + className + "'", e);
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public Object convert(Object target, Class<?> clazz)
/*    */   {
/* 81 */     IStandardConversionService conversionService = StandardExpressions.getConversionService(this.context.getConfiguration());
/* 82 */     return conversionService.convert(this.context, target, clazz);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\expression\Conversions.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */