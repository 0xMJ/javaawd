/*    */ package org.thymeleaf.expression;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.Set;
/*    */ import org.thymeleaf.util.SetUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Sets
/*    */ {
/*    */   public Set<?> toSet(Object target)
/*    */   {
/* 46 */     return SetUtils.toSet(target);
/*    */   }
/*    */   
/*    */   public int size(Set<?> target)
/*    */   {
/* 51 */     return SetUtils.size(target);
/*    */   }
/*    */   
/*    */   public boolean isEmpty(Set<?> target)
/*    */   {
/* 56 */     return SetUtils.isEmpty(target);
/*    */   }
/*    */   
/*    */   public boolean contains(Set<?> target, Object element)
/*    */   {
/* 61 */     return SetUtils.contains(target, element);
/*    */   }
/*    */   
/*    */   public boolean containsAll(Set<?> target, Object[] elements)
/*    */   {
/* 66 */     return SetUtils.containsAll(target, elements);
/*    */   }
/*    */   
/*    */   public boolean containsAll(Set<?> target, Collection<?> elements)
/*    */   {
/* 71 */     return SetUtils.containsAll(target, elements);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\expression\Sets.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */