/*     */ package org.thymeleaf.expression;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Calendar;
/*     */ import java.util.List;
/*     */ import org.thymeleaf.context.ITemplateContext;
/*     */ import org.thymeleaf.engine.TemplateData;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ExecutionInfo
/*     */ {
/*     */   private final ITemplateContext context;
/*     */   private final Calendar now;
/*     */   
/*     */   public ExecutionInfo(ITemplateContext context)
/*     */   {
/*  54 */     this.context = context;
/*  55 */     this.now = Calendar.getInstance(context.getLocale());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getTemplateName()
/*     */   {
/*  73 */     return this.context.getTemplateData().getTemplate();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TemplateMode getTemplateMode()
/*     */   {
/*  91 */     return this.context.getTemplateData().getTemplateMode();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getProcessedTemplateName()
/*     */   {
/* 108 */     return ((TemplateData)this.context.getTemplateStack().get(0)).getTemplate();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TemplateMode getProcessedTemplateMode()
/*     */   {
/* 125 */     return ((TemplateData)this.context.getTemplateStack().get(0)).getTemplateMode();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<String> getTemplateNames()
/*     */   {
/* 141 */     List<TemplateData> templateStack = this.context.getTemplateStack();
/* 142 */     List<String> templateNameStack = new ArrayList(templateStack.size());
/* 143 */     for (TemplateData templateData : templateStack) {
/* 144 */       templateNameStack.add(templateData.getTemplate());
/*     */     }
/* 146 */     return templateNameStack;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<TemplateMode> getTemplateModes()
/*     */   {
/* 162 */     List<TemplateData> templateStack = this.context.getTemplateStack();
/* 163 */     List<TemplateMode> templateModeStack = new ArrayList(templateStack.size());
/* 164 */     for (TemplateData templateData : templateStack) {
/* 165 */       templateModeStack.add(templateData.getTemplateMode());
/*     */     }
/* 167 */     return templateModeStack;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<TemplateData> getTemplateStack()
/*     */   {
/* 183 */     return this.context.getTemplateStack();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Calendar getNow()
/*     */   {
/* 195 */     return this.now;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\expression\ExecutionInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */