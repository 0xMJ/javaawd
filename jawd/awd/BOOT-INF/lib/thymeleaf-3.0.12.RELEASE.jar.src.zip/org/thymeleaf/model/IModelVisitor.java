package org.thymeleaf.model;

public abstract interface IModelVisitor
{
  public abstract void visit(ITemplateStart paramITemplateStart);
  
  public abstract void visit(ITemplateEnd paramITemplateEnd);
  
  public abstract void visit(IXMLDeclaration paramIXMLDeclaration);
  
  public abstract void visit(IDocType paramIDocType);
  
  public abstract void visit(ICDATASection paramICDATASection);
  
  public abstract void visit(IComment paramIComment);
  
  public abstract void visit(IText paramIText);
  
  public abstract void visit(IStandaloneElementTag paramIStandaloneElementTag);
  
  public abstract void visit(IOpenElementTag paramIOpenElementTag);
  
  public abstract void visit(ICloseElementTag paramICloseElementTag);
  
  public abstract void visit(IProcessingInstruction paramIProcessingInstruction);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\model\IModelVisitor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */