package org.thymeleaf.model;

public abstract interface IProcessingInstruction
  extends ITemplateEvent
{
  public abstract String getTarget();
  
  public abstract String getContent();
  
  public abstract String getProcessingInstruction();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\model\IProcessingInstruction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */