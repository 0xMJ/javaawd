package org.thymeleaf.model;

public abstract class AbstractModelVisitor
  implements IModelVisitor
{
  public void visit(ITemplateStart templateStart) {}
  
  public void visit(ITemplateEnd templateEnd) {}
  
  public void visit(IXMLDeclaration xmlDeclaration) {}
  
  public void visit(IDocType docType) {}
  
  public void visit(ICDATASection cdataSection) {}
  
  public void visit(IComment comment) {}
  
  public void visit(IText text) {}
  
  public void visit(IStandaloneElementTag standaloneElementTag) {}
  
  public void visit(IOpenElementTag openElementTag) {}
  
  public void visit(ICloseElementTag closeElementTag) {}
  
  public void visit(IProcessingInstruction processingInstruction) {}
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\model\AbstractModelVisitor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */