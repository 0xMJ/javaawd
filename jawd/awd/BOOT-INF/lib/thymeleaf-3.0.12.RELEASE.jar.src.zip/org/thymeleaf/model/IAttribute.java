package org.thymeleaf.model;

import java.io.IOException;
import java.io.Writer;
import org.thymeleaf.engine.AttributeDefinition;

public abstract interface IAttribute
{
  public abstract String getAttributeCompleteName();
  
  public abstract AttributeDefinition getAttributeDefinition();
  
  public abstract String getOperator();
  
  public abstract String getValue();
  
  public abstract AttributeValueQuotes getValueQuotes();
  
  public abstract boolean hasLocation();
  
  public abstract String getTemplateName();
  
  public abstract int getLine();
  
  public abstract int getCol();
  
  public abstract void write(Writer paramWriter)
    throws IOException;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\model\IAttribute.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */