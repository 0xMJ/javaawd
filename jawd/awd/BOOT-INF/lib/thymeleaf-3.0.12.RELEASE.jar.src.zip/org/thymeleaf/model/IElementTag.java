package org.thymeleaf.model;

import org.thymeleaf.engine.ElementDefinition;
import org.thymeleaf.templatemode.TemplateMode;

public abstract interface IElementTag
  extends ITemplateEvent
{
  public abstract TemplateMode getTemplateMode();
  
  public abstract String getElementCompleteName();
  
  public abstract ElementDefinition getElementDefinition();
  
  public abstract boolean isSynthetic();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\model\IElementTag.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */