package org.thymeleaf.model;

import java.util.Map;
import org.thymeleaf.engine.AttributeName;
import org.thymeleaf.engine.TemplateData;

public abstract interface IModelFactory
{
  public abstract IModel createModel();
  
  public abstract IModel createModel(ITemplateEvent paramITemplateEvent);
  
  public abstract IModel parse(TemplateData paramTemplateData, String paramString);
  
  public abstract ICDATASection createCDATASection(CharSequence paramCharSequence);
  
  public abstract IComment createComment(CharSequence paramCharSequence);
  
  public abstract IDocType createHTML5DocType();
  
  public abstract IDocType createDocType(String paramString1, String paramString2);
  
  public abstract IDocType createDocType(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5);
  
  public abstract IProcessingInstruction createProcessingInstruction(String paramString1, String paramString2);
  
  public abstract IText createText(CharSequence paramCharSequence);
  
  public abstract IXMLDeclaration createXMLDeclaration(String paramString1, String paramString2, String paramString3);
  
  public abstract IStandaloneElementTag createStandaloneElementTag(String paramString);
  
  public abstract IStandaloneElementTag createStandaloneElementTag(String paramString1, String paramString2, String paramString3);
  
  public abstract IStandaloneElementTag createStandaloneElementTag(String paramString, boolean paramBoolean1, boolean paramBoolean2);
  
  public abstract IStandaloneElementTag createStandaloneElementTag(String paramString1, String paramString2, String paramString3, boolean paramBoolean1, boolean paramBoolean2);
  
  public abstract IStandaloneElementTag createStandaloneElementTag(String paramString, Map<String, String> paramMap, AttributeValueQuotes paramAttributeValueQuotes, boolean paramBoolean1, boolean paramBoolean2);
  
  public abstract IOpenElementTag createOpenElementTag(String paramString);
  
  public abstract IOpenElementTag createOpenElementTag(String paramString1, String paramString2, String paramString3);
  
  public abstract IOpenElementTag createOpenElementTag(String paramString, boolean paramBoolean);
  
  public abstract IOpenElementTag createOpenElementTag(String paramString1, String paramString2, String paramString3, boolean paramBoolean);
  
  public abstract IOpenElementTag createOpenElementTag(String paramString, Map<String, String> paramMap, AttributeValueQuotes paramAttributeValueQuotes, boolean paramBoolean);
  
  public abstract ICloseElementTag createCloseElementTag(String paramString);
  
  public abstract ICloseElementTag createCloseElementTag(String paramString, boolean paramBoolean1, boolean paramBoolean2);
  
  public abstract <T extends IProcessableElementTag> T setAttribute(T paramT, String paramString1, String paramString2);
  
  public abstract <T extends IProcessableElementTag> T setAttribute(T paramT, String paramString1, String paramString2, AttributeValueQuotes paramAttributeValueQuotes);
  
  public abstract <T extends IProcessableElementTag> T replaceAttribute(T paramT, AttributeName paramAttributeName, String paramString1, String paramString2);
  
  public abstract <T extends IProcessableElementTag> T replaceAttribute(T paramT, AttributeName paramAttributeName, String paramString1, String paramString2, AttributeValueQuotes paramAttributeValueQuotes);
  
  public abstract <T extends IProcessableElementTag> T removeAttribute(T paramT, String paramString);
  
  public abstract <T extends IProcessableElementTag> T removeAttribute(T paramT, String paramString1, String paramString2);
  
  public abstract <T extends IProcessableElementTag> T removeAttribute(T paramT, AttributeName paramAttributeName);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\model\IModelFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */