package org.thymeleaf.model;

import java.util.Map;
import org.thymeleaf.engine.AttributeName;

public abstract interface IProcessableElementTag
  extends IElementTag
{
  public abstract IAttribute[] getAllAttributes();
  
  public abstract Map<String, String> getAttributeMap();
  
  public abstract boolean hasAttribute(String paramString);
  
  public abstract boolean hasAttribute(String paramString1, String paramString2);
  
  public abstract boolean hasAttribute(AttributeName paramAttributeName);
  
  public abstract IAttribute getAttribute(String paramString);
  
  public abstract IAttribute getAttribute(String paramString1, String paramString2);
  
  public abstract IAttribute getAttribute(AttributeName paramAttributeName);
  
  public abstract String getAttributeValue(String paramString);
  
  public abstract String getAttributeValue(String paramString1, String paramString2);
  
  public abstract String getAttributeValue(AttributeName paramAttributeName);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\model\IProcessableElementTag.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */