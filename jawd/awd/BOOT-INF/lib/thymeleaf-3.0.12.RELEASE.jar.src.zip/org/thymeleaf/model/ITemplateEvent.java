package org.thymeleaf.model;

import java.io.IOException;
import java.io.Writer;

public abstract interface ITemplateEvent
{
  public abstract boolean hasLocation();
  
  public abstract String getTemplateName();
  
  public abstract int getLine();
  
  public abstract int getCol();
  
  public abstract void accept(IModelVisitor paramIModelVisitor);
  
  public abstract void write(Writer paramWriter)
    throws IOException;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\model\ITemplateEvent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */