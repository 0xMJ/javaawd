package org.thymeleaf.model;

public enum AttributeValueQuotes
{
  DOUBLE,  SINGLE,  NONE;
  
  private AttributeValueQuotes() {}
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\model\AttributeValueQuotes.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */