package org.thymeleaf.model;

import java.io.IOException;
import java.io.Writer;
import org.thymeleaf.IEngineConfiguration;
import org.thymeleaf.templatemode.TemplateMode;

public abstract interface IModel
{
  public abstract IEngineConfiguration getConfiguration();
  
  public abstract TemplateMode getTemplateMode();
  
  public abstract int size();
  
  public abstract ITemplateEvent get(int paramInt);
  
  public abstract void add(ITemplateEvent paramITemplateEvent);
  
  public abstract void insert(int paramInt, ITemplateEvent paramITemplateEvent);
  
  public abstract void replace(int paramInt, ITemplateEvent paramITemplateEvent);
  
  public abstract void addModel(IModel paramIModel);
  
  public abstract void insertModel(int paramInt, IModel paramIModel);
  
  public abstract void remove(int paramInt);
  
  public abstract void reset();
  
  public abstract IModel cloneModel();
  
  public abstract void accept(IModelVisitor paramIModelVisitor);
  
  public abstract void write(Writer paramWriter)
    throws IOException;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\model\IModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */