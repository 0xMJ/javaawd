package org.thymeleaf.model;

public abstract interface IXMLDeclaration
  extends ITemplateEvent
{
  public abstract String getKeyword();
  
  public abstract String getVersion();
  
  public abstract String getEncoding();
  
  public abstract String getStandalone();
  
  public abstract String getXmlDeclaration();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\model\IXMLDeclaration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */