package org.thymeleaf.model;

public abstract interface ICloseElementTag
  extends IElementTag
{
  public abstract boolean isUnmatched();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\model\ICloseElementTag.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */