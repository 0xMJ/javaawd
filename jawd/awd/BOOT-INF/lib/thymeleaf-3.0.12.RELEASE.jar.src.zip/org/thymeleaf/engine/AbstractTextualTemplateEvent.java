/*     */ package org.thymeleaf.engine;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import org.thymeleaf.util.IWritableCharSequence;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class AbstractTextualTemplateEvent
/*     */   extends AbstractTemplateEvent
/*     */   implements IEngineTemplateEvent
/*     */ {
/*     */   private final CharSequence contentCharSeq;
/*     */   private final String contentStr;
/*     */   private final int contentLength;
/*  39 */   private volatile String computedContentStr = null;
/*  40 */   private volatile int computedContentLength = -1;
/*  41 */   private volatile Boolean computedContentIsWhitespace = null;
/*  42 */   private volatile Boolean computedContentIsInlineable = null;
/*     */   
/*     */ 
/*     */ 
/*     */   AbstractTextualTemplateEvent(CharSequence content)
/*     */   {
/*  48 */     this.contentCharSeq = content;
/*  49 */     if ((content != null) && ((content instanceof String))) {
/*  50 */       this.contentStr = ((String)content);
/*  51 */       this.contentLength = content.length();
/*     */     } else {
/*  53 */       this.contentStr = null;
/*  54 */       this.contentLength = -1;
/*     */     }
/*     */   }
/*     */   
/*     */   AbstractTextualTemplateEvent(CharSequence content, String templateName, int line, int col)
/*     */   {
/*  60 */     super(templateName, line, col);
/*  61 */     this.contentCharSeq = content;
/*  62 */     if ((content != null) && ((content instanceof String))) {
/*  63 */       this.contentStr = ((String)content);
/*  64 */       this.contentLength = content.length();
/*     */     } else {
/*  66 */       this.contentStr = null;
/*  67 */       this.contentLength = -1;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final String getContentText()
/*     */   {
/*  76 */     if ((this.contentStr != null) || (this.contentCharSeq == null)) {
/*  77 */       return this.contentStr;
/*     */     }
/*     */     
/*  80 */     String t = this.computedContentStr;
/*  81 */     if (t == null) {
/*  82 */       this.computedContentStr = (t = this.contentCharSeq.toString());
/*     */     }
/*  84 */     return t;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected final int getContentLength()
/*     */   {
/*  91 */     if ((this.contentLength >= 0) || (this.contentCharSeq == null)) {
/*  92 */       return this.contentLength;
/*     */     }
/*     */     
/*  95 */     int l = this.computedContentLength;
/*  96 */     if (l < 0) {
/*  97 */       this.computedContentLength = (l = this.contentCharSeq.length());
/*     */     }
/*  99 */     return l;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final char charAtContent(int index)
/*     */   {
/* 108 */     if (this.contentStr != null) {
/* 109 */       return this.contentStr.charAt(index);
/*     */     }
/* 111 */     if (this.computedContentStr != null)
/*     */     {
/* 113 */       return this.computedContentStr.charAt(index);
/*     */     }
/* 115 */     return this.contentCharSeq.charAt(index);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final CharSequence contentSubSequence(int start, int end)
/*     */   {
/* 123 */     if (this.contentStr != null) {
/* 124 */       return this.contentStr.subSequence(start, end);
/*     */     }
/* 126 */     if (this.computedContentStr != null)
/*     */     {
/* 128 */       return this.computedContentStr.subSequence(start, end);
/*     */     }
/* 130 */     return this.contentCharSeq.subSequence(start, end);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   final boolean isWhitespace()
/*     */   {
/* 138 */     Boolean w = this.computedContentIsWhitespace;
/* 139 */     if (w == null) {
/* 140 */       this.computedContentIsWhitespace = (w = computeWhitespace());
/*     */     }
/* 142 */     return w.booleanValue();
/*     */   }
/*     */   
/*     */   final boolean isInlineable()
/*     */   {
/* 147 */     Boolean i = this.computedContentIsInlineable;
/* 148 */     if (i == null) {
/* 149 */       this.computedContentIsInlineable = (i = computeInlineable());
/*     */     }
/* 151 */     return i.booleanValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private Boolean computeWhitespace()
/*     */   {
/* 159 */     int n = getContentLength();
/*     */     
/* 161 */     if (n == 0) {
/* 162 */       return Boolean.FALSE;
/*     */     }
/*     */     
/*     */ 
/* 166 */     while (n-- != 0) {
/* 167 */       char c = charAtContent(n);
/* 168 */       if ((c != ' ') && (c != '\n') && 
/* 169 */         (!Character.isWhitespace(c))) {
/* 170 */         return Boolean.FALSE;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 175 */     return Boolean.TRUE;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private Boolean computeInlineable()
/*     */   {
/* 182 */     int n = getContentLength();
/*     */     
/* 184 */     if (n == 0) {
/* 185 */       return Boolean.FALSE;
/*     */     }
/*     */     
/*     */ 
/* 189 */     char c0 = '\000';
/* 190 */     int inline = 0;
/* 191 */     while (n-- != 0) {
/* 192 */       char c1 = charAtContent(n);
/* 193 */       if ((n > 0) && (c1 == ']') && (c0 == ']')) {
/* 194 */         inline = 1;
/* 195 */         n--;
/* 196 */         c1 = charAtContent(n);
/* 197 */       } else if ((n > 0) && (c1 == ')') && (c0 == ']')) {
/* 198 */         inline = 2;
/* 199 */         n--;
/* 200 */         c1 = charAtContent(n);
/* 201 */       } else { if ((inline == 1) && (c1 == '[') && (c0 == '['))
/* 202 */           return Boolean.TRUE;
/* 203 */         if ((inline == 2) && (c1 == '[') && (c0 == '('))
/* 204 */           return Boolean.TRUE;
/*     */       }
/* 206 */       c0 = c1;
/*     */     }
/*     */     
/* 209 */     return Boolean.FALSE;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final void writeContent(Writer writer)
/*     */     throws IOException
/*     */   {
/* 217 */     if (this.contentStr != null) {
/* 218 */       writer.write(this.contentStr);
/* 219 */     } else if (this.computedContentStr != null) {
/* 220 */       writer.write(this.computedContentStr);
/* 221 */     } else if ((this.contentCharSeq instanceof IWritableCharSequence))
/*     */     {
/*     */ 
/* 224 */       ((IWritableCharSequence)this.contentCharSeq).write(writer);
/*     */     } else {
/* 226 */       writer.write(getContentText());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 234 */     return getContentText();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\AbstractTextualTemplateEvent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */