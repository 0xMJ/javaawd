/*    */ package org.thymeleaf.engine;
/*    */ 
/*    */ import org.thymeleaf.templateparser.raw.IRawHandler;
/*    */ import org.thymeleaf.templateparser.raw.RawParseException;
/*    */ import org.thymeleaf.util.Validate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class TemplateHandlerAdapterRawHandler
/*    */   implements IRawHandler
/*    */ {
/*    */   private final String templateName;
/*    */   private final ITemplateHandler templateHandler;
/*    */   private final int lineOffset;
/*    */   private final int colOffset;
/*    */   
/*    */   public TemplateHandlerAdapterRawHandler(String templateName, ITemplateHandler templateHandler, int lineOffset, int colOffset)
/*    */   {
/* 45 */     Validate.notNull(templateHandler, "Template handler cannot be null");
/*    */     
/* 47 */     this.templateName = templateName;
/*    */     
/* 49 */     this.templateHandler = templateHandler;
/*    */     
/*    */ 
/* 52 */     this.lineOffset = (lineOffset > 0 ? lineOffset - 1 : lineOffset);
/* 53 */     this.colOffset = (colOffset > 0 ? colOffset - 1 : colOffset);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void handleDocumentStart(long startTimeNanos, int line, int col)
/*    */     throws RawParseException
/*    */   {
/* 63 */     this.templateHandler.handleTemplateStart(TemplateStart.TEMPLATE_START_INSTANCE);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void handleDocumentEnd(long endTimeNanos, long totalTimeNanos, int line, int col)
/*    */     throws RawParseException
/*    */   {
/* 71 */     this.templateHandler.handleTemplateEnd(TemplateEnd.TEMPLATE_END_INSTANCE);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void handleText(char[] buffer, int offset, int len, int line, int col)
/*    */     throws RawParseException
/*    */   {
/* 81 */     this.templateHandler.handleText(new Text(new String(buffer, offset, len), this.templateName, this.lineOffset + line, 
/* 82 */       (line == 1 ? this.colOffset : 0) + col));
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\TemplateHandlerAdapterRawHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */