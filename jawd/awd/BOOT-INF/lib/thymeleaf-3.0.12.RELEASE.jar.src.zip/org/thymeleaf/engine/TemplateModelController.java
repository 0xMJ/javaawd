/*     */ package org.thymeleaf.engine;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.thymeleaf.IEngineConfiguration;
/*     */ import org.thymeleaf.context.IEngineContext;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.model.ICDATASection;
/*     */ import org.thymeleaf.model.ICloseElementTag;
/*     */ import org.thymeleaf.model.IComment;
/*     */ import org.thymeleaf.model.IDocType;
/*     */ import org.thymeleaf.model.IOpenElementTag;
/*     */ import org.thymeleaf.model.IProcessableElementTag;
/*     */ import org.thymeleaf.model.IProcessingInstruction;
/*     */ import org.thymeleaf.model.IStandaloneElementTag;
/*     */ import org.thymeleaf.model.ITemplateEvent;
/*     */ import org.thymeleaf.model.IText;
/*     */ import org.thymeleaf.model.IXMLDeclaration;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class TemplateModelController
/*     */ {
/*     */   static final int DEFAULT_MODEL_LEVELS = 25;
/*     */   
/*     */   static enum SkipBody
/*     */   {
/*  60 */     PROCESS(true, true, true), 
/*  61 */     SKIP_ALL(false, false, false), 
/*  62 */     SKIP_ELEMENTS(false, true, false), 
/*  63 */     PROCESS_ONE_ELEMENT(true, true, true);
/*     */     
/*     */     final boolean processElements;
/*     */     final boolean processNonElements;
/*     */     final boolean processChildren;
/*     */     
/*     */     private SkipBody(boolean processElements, boolean processNonElements, boolean processChildren) {
/*  70 */       this.processElements = processElements;
/*  71 */       this.processNonElements = processNonElements;
/*  72 */       this.processChildren = processChildren;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  80 */   private static final Set<HTMLElementName> ITERATION_WHITESPACE_APPLICABLE_ELEMENT_NAMES = new HashSet(
/*  81 */     Arrays.asList(new HTMLElementName[] {
/*  82 */     ElementNames.forHTMLName("address"), ElementNames.forHTMLName("article"), ElementNames.forHTMLName("aside"), 
/*  83 */     ElementNames.forHTMLName("audio"), ElementNames.forHTMLName("blockquote"), ElementNames.forHTMLName("canvas"), 
/*  84 */     ElementNames.forHTMLName("dd"), ElementNames.forHTMLName("div"), ElementNames.forHTMLName("dl"), 
/*  85 */     ElementNames.forHTMLName("dt"), ElementNames.forHTMLName("fieldset"), ElementNames.forHTMLName("figcaption"), 
/*  86 */     ElementNames.forHTMLName("figure"), ElementNames.forHTMLName("footer"), ElementNames.forHTMLName("form"), 
/*  87 */     ElementNames.forHTMLName("h1"), ElementNames.forHTMLName("h2"), ElementNames.forHTMLName("h3"), 
/*  88 */     ElementNames.forHTMLName("h4"), ElementNames.forHTMLName("h5"), ElementNames.forHTMLName("h6"), 
/*  89 */     ElementNames.forHTMLName("header"), ElementNames.forHTMLName("hgroup"), ElementNames.forHTMLName("hr"), 
/*  90 */     ElementNames.forHTMLName("li"), ElementNames.forHTMLName("main"), ElementNames.forHTMLName("nav"), 
/*  91 */     ElementNames.forHTMLName("noscript"), ElementNames.forHTMLName("ol"), ElementNames.forHTMLName("option"), 
/*  92 */     ElementNames.forHTMLName("output"), ElementNames.forHTMLName("p"), ElementNames.forHTMLName("pre"), 
/*  93 */     ElementNames.forHTMLName("section"), ElementNames.forHTMLName("table"), ElementNames.forHTMLName("tbody"), 
/*  94 */     ElementNames.forHTMLName("td"), ElementNames.forHTMLName("tfoot"), ElementNames.forHTMLName("th"), 
/*  95 */     ElementNames.forHTMLName("tr"), ElementNames.forHTMLName("ul"), ElementNames.forHTMLName("video") }));
/*     */   
/*     */   private final IEngineConfiguration configuration;
/*     */   
/*     */   private final TemplateMode templateMode;
/*     */   
/*     */   private final ProcessorTemplateHandler processorTemplateHandler;
/*     */   
/*     */   private final IEngineContext context;
/*     */   
/*     */   private TemplateFlowController templateFlowController;
/*     */   
/*     */   private AbstractGatheringModelProcessable gatheredModel;
/*     */   
/*     */   private SkipBody skipBody;
/*     */   
/*     */   private SkipBody[] skipBodyByLevel;
/*     */   
/*     */   private boolean[] skipCloseTagByLevel;
/*     */   
/*     */   private IProcessableElementTag[] unskippedFirstElementByLevel;
/*     */   
/* 117 */   private ITemplateEvent lastEvent = null;
/* 118 */   private ITemplateEvent secondToLastEvent = null;
/*     */   
/*     */ 
/*     */ 
/*     */   private int modelLevel;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   TemplateModelController(IEngineConfiguration configuration, TemplateMode templateMode, ProcessorTemplateHandler processorTemplateHandler, IEngineContext context)
/*     */   {
/* 129 */     this.configuration = configuration;
/* 130 */     this.templateMode = templateMode;
/* 131 */     this.processorTemplateHandler = processorTemplateHandler;
/* 132 */     this.context = context;
/*     */     
/* 134 */     this.gatheredModel = null;
/*     */     
/* 136 */     this.skipBodyByLevel = new SkipBody[25];
/* 137 */     this.skipBodyByLevel[this.modelLevel] = SkipBody.PROCESS;
/* 138 */     this.skipBody = this.skipBodyByLevel[this.modelLevel];
/*     */     
/* 140 */     this.skipCloseTagByLevel = new boolean[25];
/* 141 */     this.skipCloseTagByLevel[this.modelLevel] = false;
/*     */     
/* 143 */     this.unskippedFirstElementByLevel = new IProcessableElementTag[25];
/* 144 */     this.unskippedFirstElementByLevel[this.modelLevel] = null;
/*     */     
/* 146 */     this.modelLevel = 0;
/*     */   }
/*     */   
/*     */ 
/*     */   void setTemplateFlowController(TemplateFlowController templateFlowController)
/*     */   {
/* 152 */     this.templateFlowController = templateFlowController;
/*     */   }
/*     */   
/*     */   int getModelLevel()
/*     */   {
/* 157 */     return this.modelLevel;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   void startGatheringDelayedModel(IOpenElementTag firstTag, ProcessorExecutionVars processorExecutionVars)
/*     */   {
/* 164 */     this.modelLevel -= 1;
/*     */     
/* 166 */     SkipBody gatheredSkipBody = this.skipBodyByLevel[this.modelLevel];
/* 167 */     boolean gatheredSkipCloseTagByLevel = this.skipCloseTagByLevel[this.modelLevel];
/*     */     
/* 169 */     this.gatheredModel = new GatheringModelProcessable(this.configuration, this.processorTemplateHandler, this.context, this, this.templateFlowController, gatheredSkipBody, gatheredSkipCloseTagByLevel, processorExecutionVars);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 175 */     this.gatheredModel.gatherOpenElement(firstTag);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   void startGatheringDelayedModel(IStandaloneElementTag firstTag, ProcessorExecutionVars processorExecutionVars)
/*     */   {
/* 183 */     SkipBody gatheredSkipBody = this.skipBodyByLevel[this.modelLevel];
/* 184 */     gatheredSkipBody = gatheredSkipBody == SkipBody.SKIP_ELEMENTS ? SkipBody.PROCESS_ONE_ELEMENT : gatheredSkipBody;
/* 185 */     boolean gatheredSkipCloseTagByLevel = this.skipCloseTagByLevel[this.modelLevel];
/*     */     
/* 187 */     this.gatheredModel = new GatheringModelProcessable(this.configuration, this.processorTemplateHandler, this.context, this, this.templateFlowController, gatheredSkipBody, gatheredSkipCloseTagByLevel, processorExecutionVars);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 193 */     this.gatheredModel.gatherStandaloneElement(firstTag);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void startGatheringIteratedModel(IOpenElementTag firstTag, ProcessorExecutionVars processorExecutionVars, String iterVariableName, String iterStatusVariableName, Object iteratedObject)
/*     */   {
/* 202 */     this.modelLevel -= 1;
/*     */     
/* 204 */     SkipBody gatheredSkipBody = this.skipBodyByLevel[this.modelLevel];
/* 205 */     boolean gatheredSkipCloseTagByLevel = this.skipCloseTagByLevel[this.modelLevel];
/*     */     
/* 207 */     Text precedingWhitespace = computeWhiteSpacePrecedingIteration(firstTag.getElementDefinition().elementName);
/*     */     
/* 209 */     this.gatheredModel = new IteratedGatheringModelProcessable(this.configuration, this.processorTemplateHandler, this.context, this, this.templateFlowController, gatheredSkipBody, gatheredSkipCloseTagByLevel, processorExecutionVars, iterVariableName, iterStatusVariableName, iteratedObject, precedingWhitespace);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 216 */     this.gatheredModel.gatherOpenElement(firstTag);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void startGatheringIteratedModel(IStandaloneElementTag firstTag, ProcessorExecutionVars processorExecutionVars, String iterVariableName, String iterStatusVariableName, Object iteratedObject)
/*     */   {
/* 225 */     SkipBody gatheredSkipBody = this.skipBodyByLevel[this.modelLevel];
/* 226 */     gatheredSkipBody = gatheredSkipBody == SkipBody.SKIP_ELEMENTS ? SkipBody.PROCESS_ONE_ELEMENT : gatheredSkipBody;
/* 227 */     boolean gatheredSkipCloseTagByLevel = this.skipCloseTagByLevel[this.modelLevel];
/*     */     
/* 229 */     Text precedingWhitespace = computeWhiteSpacePrecedingIteration(firstTag.getElementDefinition().elementName);
/*     */     
/* 231 */     this.gatheredModel = new IteratedGatheringModelProcessable(this.configuration, this.processorTemplateHandler, this.context, this, this.templateFlowController, gatheredSkipBody, gatheredSkipCloseTagByLevel, processorExecutionVars, iterVariableName, iterStatusVariableName, iteratedObject, precedingWhitespace);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 238 */     this.gatheredModel.gatherStandaloneElement(firstTag);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   GatheringModelProcessable createStandaloneEquivalentModel(StandaloneElementTag standaloneElementTag, ProcessorExecutionVars processorExecutionVars)
/*     */   {
/* 246 */     SkipBody gatheredSkipBody = this.skipBodyByLevel[this.modelLevel];
/* 247 */     gatheredSkipBody = gatheredSkipBody == SkipBody.SKIP_ELEMENTS ? SkipBody.PROCESS_ONE_ELEMENT : gatheredSkipBody;
/* 248 */     boolean gatheredSkipCloseTagByLevel = this.skipCloseTagByLevel[this.modelLevel];
/*     */     
/* 250 */     OpenElementTag openTag = new OpenElementTag(standaloneElementTag.templateMode, standaloneElementTag.elementDefinition, standaloneElementTag.elementCompleteName, standaloneElementTag.attributes, standaloneElementTag.synthetic, standaloneElementTag.templateName, standaloneElementTag.line, standaloneElementTag.col);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 255 */     CloseElementTag closeTag = new CloseElementTag(standaloneElementTag.templateMode, standaloneElementTag.elementDefinition, standaloneElementTag.elementCompleteName, null, standaloneElementTag.synthetic, false, standaloneElementTag.templateName, standaloneElementTag.line, standaloneElementTag.col);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 261 */     GatheringModelProcessable equivalentModel = new GatheringModelProcessable(this.configuration, this.processorTemplateHandler, this.context, this, this.templateFlowController, gatheredSkipBody, gatheredSkipCloseTagByLevel, processorExecutionVars);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 267 */     equivalentModel.gatherOpenElement(openTag);
/* 268 */     equivalentModel.gatherCloseElement(closeTag);
/*     */     
/* 270 */     return equivalentModel;
/*     */   }
/*     */   
/*     */ 
/*     */   boolean isGatheringFinished()
/*     */   {
/* 276 */     return (this.gatheredModel != null) && (this.gatheredModel.isGatheringFinished());
/*     */   }
/*     */   
/*     */   IGatheringModelProcessable getGatheredModel()
/*     */   {
/* 281 */     return this.gatheredModel;
/*     */   }
/*     */   
/*     */   void resetGathering()
/*     */   {
/* 286 */     this.gatheredModel = null;
/*     */   }
/*     */   
/*     */ 
/*     */   void skip(SkipBody skipBody, boolean skipCloseTag)
/*     */   {
/* 292 */     skipBody(skipBody);
/* 293 */     skipCloseTag(skipCloseTag);
/*     */   }
/*     */   
/*     */   private void skipBody(SkipBody skipBody) {
/* 297 */     this.skipBodyByLevel[this.modelLevel] = skipBody;
/* 298 */     this.skipBody = skipBody;
/*     */   }
/*     */   
/*     */   private void skipCloseTag(boolean skipCloseTag)
/*     */   {
/* 303 */     if (!skipCloseTag) {
/* 304 */       return;
/*     */     }
/* 306 */     if (this.modelLevel == 0) {
/* 307 */       throw new TemplateProcessingException("Cannot set containing close tag to skip when model level is zero");
/*     */     }
/* 309 */     this.skipCloseTagByLevel[(this.modelLevel - 1)] = true;
/*     */   }
/*     */   
/*     */ 
/*     */   private void increaseModelLevel(IOpenElementTag openElementTag)
/*     */   {
/* 315 */     this.modelLevel += 1;
/* 316 */     if (this.skipBodyByLevel.length == this.modelLevel) {
/* 317 */       this.skipBodyByLevel = ((SkipBody[])Arrays.copyOf(this.skipBodyByLevel, this.skipBodyByLevel.length + 12));
/* 318 */       this.skipCloseTagByLevel = Arrays.copyOf(this.skipCloseTagByLevel, this.skipCloseTagByLevel.length + 12);
/* 319 */       this.unskippedFirstElementByLevel = ((IProcessableElementTag[])Arrays.copyOf(this.unskippedFirstElementByLevel, this.unskippedFirstElementByLevel.length + 12));
/*     */     }
/* 321 */     skipBody(this.skipBody.processChildren ? SkipBody.PROCESS : SkipBody.SKIP_ALL);
/* 322 */     this.skipCloseTagByLevel[this.modelLevel] = false;
/* 323 */     this.unskippedFirstElementByLevel[this.modelLevel] = null;
/* 324 */     if (this.context != null) {
/* 325 */       this.context.increaseLevel();
/* 326 */       this.context.setElementTag(openElementTag);
/*     */     }
/*     */   }
/*     */   
/*     */   private void decreaseModelLevel()
/*     */   {
/* 332 */     this.modelLevel -= 1;
/* 333 */     this.skipBody = this.skipBodyByLevel[this.modelLevel];
/* 334 */     if (this.context != null) {
/* 335 */       this.context.decreaseLevel();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean shouldProcessText(IText text)
/*     */   {
/* 346 */     this.lastEvent = text;
/* 347 */     if (this.gatheredModel != null) {
/* 348 */       this.gatheredModel.gatherText(text);
/* 349 */       return false;
/*     */     }
/* 351 */     return this.skipBody.processNonElements;
/*     */   }
/*     */   
/*     */   boolean shouldProcessComment(IComment comment)
/*     */   {
/* 356 */     this.lastEvent = comment;
/* 357 */     if (this.gatheredModel != null) {
/* 358 */       this.gatheredModel.gatherComment(comment);
/* 359 */       return false;
/*     */     }
/* 361 */     return this.skipBody.processNonElements;
/*     */   }
/*     */   
/*     */   boolean shouldProcessCDATASection(ICDATASection cdataSection)
/*     */   {
/* 366 */     this.lastEvent = cdataSection;
/* 367 */     if (this.gatheredModel != null) {
/* 368 */       this.gatheredModel.gatherCDATASection(cdataSection);
/* 369 */       return false;
/*     */     }
/* 371 */     return this.skipBody.processNonElements;
/*     */   }
/*     */   
/*     */   boolean shouldProcessStandaloneElement(IStandaloneElementTag standaloneElementTag)
/*     */   {
/* 376 */     this.secondToLastEvent = this.lastEvent;
/* 377 */     this.lastEvent = standaloneElementTag;
/* 378 */     if (this.gatheredModel != null) {
/* 379 */       this.gatheredModel.gatherStandaloneElement(standaloneElementTag);
/* 380 */       return false;
/*     */     }
/* 382 */     boolean process = this.skipBody.processElements;
/* 383 */     if (this.skipBody == SkipBody.PROCESS_ONE_ELEMENT)
/*     */     {
/* 385 */       this.unskippedFirstElementByLevel[this.modelLevel] = standaloneElementTag;
/* 386 */       skipBody(SkipBody.SKIP_ELEMENTS);
/* 387 */       process = true;
/*     */     }
/* 389 */     if (process)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 394 */       if (this.context != null) {
/* 395 */         this.context.increaseLevel();
/* 396 */         this.context.setElementTag(standaloneElementTag);
/*     */       }
/*     */     }
/* 399 */     return process;
/*     */   }
/*     */   
/*     */   boolean shouldProcessOpenElement(IOpenElementTag openElementTag)
/*     */   {
/* 404 */     this.secondToLastEvent = this.lastEvent;
/* 405 */     this.lastEvent = openElementTag;
/* 406 */     if (this.gatheredModel != null) {
/* 407 */       this.gatheredModel.gatherOpenElement(openElementTag);
/* 408 */       return false;
/*     */     }
/* 410 */     boolean process = this.skipBody.processElements;
/* 411 */     if (this.skipBody == SkipBody.PROCESS_ONE_ELEMENT)
/*     */     {
/* 413 */       this.unskippedFirstElementByLevel[this.modelLevel] = openElementTag;
/* 414 */     } else if ((this.skipBody == SkipBody.SKIP_ELEMENTS) && (this.unskippedFirstElementByLevel[this.modelLevel] == openElementTag))
/*     */     {
/* 416 */       skipBody(SkipBody.PROCESS_ONE_ELEMENT);
/* 417 */       process = true;
/*     */     }
/* 419 */     increaseModelLevel(openElementTag);
/* 420 */     return process;
/*     */   }
/*     */   
/*     */   boolean shouldProcessCloseElement(ICloseElementTag closeElementTag)
/*     */   {
/* 425 */     if (this.gatheredModel != null) {
/* 426 */       this.gatheredModel.gatherCloseElement(closeElementTag);
/* 427 */       return false;
/*     */     }
/* 429 */     this.lastEvent = closeElementTag;
/* 430 */     decreaseModelLevel();
/* 431 */     if (this.skipBody == SkipBody.PROCESS_ONE_ELEMENT)
/*     */     {
/* 433 */       skipBody(SkipBody.SKIP_ELEMENTS);
/* 434 */       if (this.skipCloseTagByLevel[this.modelLevel] != 0) {
/* 435 */         this.skipCloseTagByLevel[this.modelLevel] = false;
/* 436 */         return false;
/*     */       }
/* 438 */       return true;
/*     */     }
/*     */     
/* 441 */     if (this.skipCloseTagByLevel[this.modelLevel] != 0) {
/* 442 */       this.skipCloseTagByLevel[this.modelLevel] = false;
/* 443 */       return false;
/*     */     }
/* 445 */     return this.skipBody.processElements;
/*     */   }
/*     */   
/*     */   boolean shouldProcessUnmatchedCloseElement(ICloseElementTag closeElementTag)
/*     */   {
/* 450 */     this.lastEvent = closeElementTag;
/* 451 */     if (this.gatheredModel != null) {
/* 452 */       this.gatheredModel.gatherUnmatchedCloseElement(closeElementTag);
/* 453 */       return false;
/*     */     }
/* 455 */     return this.skipBody.processNonElements;
/*     */   }
/*     */   
/*     */   boolean shouldProcessDocType(IDocType docType)
/*     */   {
/* 460 */     this.lastEvent = docType;
/* 461 */     if (this.gatheredModel != null) {
/* 462 */       this.gatheredModel.gatherDocType(docType);
/* 463 */       return false;
/*     */     }
/* 465 */     return this.skipBody.processNonElements;
/*     */   }
/*     */   
/*     */   boolean shouldProcessXMLDeclaration(IXMLDeclaration xmlDeclaration)
/*     */   {
/* 470 */     this.lastEvent = xmlDeclaration;
/* 471 */     if (this.gatheredModel != null) {
/* 472 */       this.gatheredModel.gatherXMLDeclaration(xmlDeclaration);
/* 473 */       return false;
/*     */     }
/* 475 */     return this.skipBody.processNonElements;
/*     */   }
/*     */   
/*     */   boolean shouldProcessProcessingInstruction(IProcessingInstruction processingInstruction)
/*     */   {
/* 480 */     this.lastEvent = processingInstruction;
/* 481 */     if (this.gatheredModel != null) {
/* 482 */       this.gatheredModel.gatherProcessingInstruction(processingInstruction);
/* 483 */       return false;
/*     */     }
/* 485 */     return this.skipBody.processNonElements;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private Text computeWhiteSpacePrecedingIteration(ElementName iteratedElementName)
/*     */   {
/* 492 */     if ((this.secondToLastEvent == null) || (!(this.secondToLastEvent instanceof IText))) {
/* 493 */       return null;
/*     */     }
/* 495 */     if ((this.templateMode == TemplateMode.XML) || ((this.templateMode == TemplateMode.HTML) && 
/* 496 */       (ITERATION_WHITESPACE_APPLICABLE_ELEMENT_NAMES.contains(iteratedElementName)))) {
/* 497 */       Text lastEngineText = Text.asEngineText((IText)this.secondToLastEvent);
/* 498 */       if (lastEngineText.isWhitespace()) {
/* 499 */         return lastEngineText;
/*     */       }
/*     */     }
/* 502 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\TemplateModelController.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */