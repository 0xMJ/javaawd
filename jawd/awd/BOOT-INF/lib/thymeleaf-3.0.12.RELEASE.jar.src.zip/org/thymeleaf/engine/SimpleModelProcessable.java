/*    */ package org.thymeleaf.engine;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class SimpleModelProcessable
/*    */   implements IEngineProcessable
/*    */ {
/*    */   private final Model model;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private final ITemplateHandler modelHandler;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private final TemplateFlowController flowController;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private int offset;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   SimpleModelProcessable(Model model, ITemplateHandler modelHandler, TemplateFlowController flowController)
/*    */   {
/* 40 */     this.model = model;
/* 41 */     this.modelHandler = modelHandler;
/* 42 */     this.flowController = flowController;
/* 43 */     this.offset = 0;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean process()
/*    */   {
/* 52 */     if (this.flowController.stopProcessing) {
/* 53 */       return false;
/*    */     }
/*    */     
/*    */ 
/*    */ 
/*    */ 
/* 59 */     this.offset += this.model.process(this.modelHandler, this.offset, this.flowController);
/*    */     
/*    */ 
/*    */ 
/*    */ 
/* 64 */     return (this.offset == this.model.queueSize) && (!this.flowController.stopProcessing);
/*    */   }
/*    */   
/*    */ 
/*    */   ITemplateHandler getModelHandler()
/*    */   {
/* 70 */     return this.modelHandler;
/*    */   }
/*    */   
/*    */   Model getModel()
/*    */   {
/* 75 */     return this.model;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\SimpleModelProcessable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */