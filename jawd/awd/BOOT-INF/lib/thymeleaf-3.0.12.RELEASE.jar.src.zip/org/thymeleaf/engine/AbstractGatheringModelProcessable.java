/*     */ package org.thymeleaf.engine;
/*     */ 
/*     */ import org.thymeleaf.IEngineConfiguration;
/*     */ import org.thymeleaf.context.IEngineContext;
/*     */ import org.thymeleaf.context.ITemplateContext;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.model.ICDATASection;
/*     */ import org.thymeleaf.model.ICloseElementTag;
/*     */ import org.thymeleaf.model.IComment;
/*     */ import org.thymeleaf.model.IDocType;
/*     */ import org.thymeleaf.model.IOpenElementTag;
/*     */ import org.thymeleaf.model.IProcessingInstruction;
/*     */ import org.thymeleaf.model.IStandaloneElementTag;
/*     */ import org.thymeleaf.model.IText;
/*     */ import org.thymeleaf.model.IXMLDeclaration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class AbstractGatheringModelProcessable
/*     */   implements IGatheringModelProcessable
/*     */ {
/*     */   private final ProcessorTemplateHandler processorTemplateHandler;
/*     */   private final IEngineContext context;
/*     */   private final Model syntheticModel;
/*     */   private final TemplateModelController modelController;
/*     */   private final TemplateFlowController flowController;
/*     */   private final TemplateModelController.SkipBody buildTimeSkipBody;
/*     */   private final boolean buildTimeSkipCloseTag;
/*     */   private final ProcessorExecutionVars processorExecutionVars;
/*  58 */   private boolean gatheringFinished = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int modelLevel;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   AbstractGatheringModelProcessable(IEngineConfiguration configuration, ProcessorTemplateHandler processorTemplateHandler, IEngineContext context, TemplateModelController modelController, TemplateFlowController flowController, TemplateModelController.SkipBody buildTimeSkipBody, boolean buildTimeSkipCloseTag, ProcessorExecutionVars processorExecutionVars)
/*     */   {
/*  71 */     this.processorTemplateHandler = processorTemplateHandler;
/*  72 */     this.context = context;
/*  73 */     this.modelController = modelController;
/*  74 */     this.flowController = flowController;
/*  75 */     this.buildTimeSkipBody = buildTimeSkipBody;
/*  76 */     this.buildTimeSkipCloseTag = buildTimeSkipCloseTag;
/*     */     
/*  78 */     if (this.context == null)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*  83 */       throw new TemplateProcessingException("Neither iteration nor model gathering are supported because local variable support is DISABLED. This is due to the use of an implementation of the " + ITemplateContext.class.getName() + " interface that does not provide local-variable support. In order to have local-variable support, the context implementation should also implement the " + IEngineContext.class.getName() + " interface");
/*     */     }
/*     */     
/*     */ 
/*  87 */     this.syntheticModel = new Model(configuration, context.getTemplateMode());
/*  88 */     this.processorExecutionVars = processorExecutionVars.cloneVars();
/*  89 */     this.gatheringFinished = false;
/*  90 */     this.modelLevel = 0;
/*     */   }
/*     */   
/*     */   public final void resetGatheredSkipFlagsAfterNoIterations()
/*     */   {
/*  95 */     if (this.buildTimeSkipBody == TemplateModelController.SkipBody.PROCESS_ONE_ELEMENT) {
/*  96 */       this.modelController.skip(TemplateModelController.SkipBody.SKIP_ELEMENTS, this.buildTimeSkipCloseTag);
/*     */     } else {
/*  98 */       this.modelController.skip(this.buildTimeSkipBody, this.buildTimeSkipCloseTag);
/*     */     }
/*     */   }
/*     */   
/*     */   public final void resetGatheredSkipFlags() {
/* 103 */     this.modelController.skip(this.buildTimeSkipBody, this.buildTimeSkipCloseTag);
/*     */   }
/*     */   
/*     */   protected final void prepareProcessing()
/*     */   {
/* 108 */     this.processorTemplateHandler.setCurrentGatheringModel(this);
/* 109 */     resetGatheredSkipFlags();
/*     */   }
/*     */   
/*     */   protected final ProcessorTemplateHandler getProcessorTemplateHandler()
/*     */   {
/* 114 */     return this.processorTemplateHandler;
/*     */   }
/*     */   
/*     */   protected final TemplateFlowController getFlowController() {
/* 118 */     return this.flowController;
/*     */   }
/*     */   
/*     */   public final boolean isGatheringFinished()
/*     */   {
/* 123 */     return this.gatheringFinished;
/*     */   }
/*     */   
/*     */ 
/*     */   protected final IEngineContext getContext()
/*     */   {
/* 129 */     return this.context;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ProcessorExecutionVars initializeProcessorExecutionVars()
/*     */   {
/* 136 */     return this.processorExecutionVars;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final Model getInnerModel()
/*     */   {
/* 143 */     return this.syntheticModel;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void gatherText(IText text)
/*     */   {
/* 151 */     if (this.gatheringFinished) {
/* 152 */       throw new TemplateProcessingException("Gathering is finished already! We cannot gather more events");
/*     */     }
/* 154 */     this.syntheticModel.add(text);
/*     */   }
/*     */   
/*     */   public final void gatherComment(IComment comment)
/*     */   {
/* 159 */     if (this.gatheringFinished) {
/* 160 */       throw new TemplateProcessingException("Gathering is finished already! We cannot gather more events");
/*     */     }
/* 162 */     this.syntheticModel.add(comment);
/*     */   }
/*     */   
/*     */   public final void gatherCDATASection(ICDATASection cdataSection)
/*     */   {
/* 167 */     if (this.gatheringFinished) {
/* 168 */       throw new TemplateProcessingException("Gathering is finished already! We cannot gather more events");
/*     */     }
/* 170 */     this.syntheticModel.add(cdataSection);
/*     */   }
/*     */   
/*     */   public final void gatherStandaloneElement(IStandaloneElementTag standaloneElementTag)
/*     */   {
/* 175 */     if (this.gatheringFinished) {
/* 176 */       throw new TemplateProcessingException("Gathering is finished already! We cannot gather more events");
/*     */     }
/* 178 */     this.syntheticModel.add(standaloneElementTag);
/* 179 */     if (this.modelLevel == 0) {
/* 180 */       this.gatheringFinished = true;
/*     */     }
/*     */   }
/*     */   
/*     */   public final void gatherOpenElement(IOpenElementTag openElementTag)
/*     */   {
/* 186 */     if (this.gatheringFinished) {
/* 187 */       throw new TemplateProcessingException("Gathering is finished already! We cannot gather more events");
/*     */     }
/* 189 */     this.syntheticModel.add(openElementTag);
/* 190 */     this.modelLevel += 1;
/*     */   }
/*     */   
/*     */   public final void gatherCloseElement(ICloseElementTag closeElementTag)
/*     */   {
/* 195 */     if (closeElementTag.isUnmatched()) {
/* 196 */       gatherUnmatchedCloseElement(closeElementTag);
/* 197 */       return;
/*     */     }
/* 199 */     if (this.gatheringFinished) {
/* 200 */       throw new TemplateProcessingException("Gathering is finished already! We cannot gather more events");
/*     */     }
/* 202 */     this.modelLevel -= 1;
/* 203 */     this.syntheticModel.add(closeElementTag);
/* 204 */     if (this.modelLevel == 0)
/*     */     {
/* 206 */       this.gatheringFinished = true;
/*     */     }
/*     */   }
/*     */   
/*     */   public final void gatherUnmatchedCloseElement(ICloseElementTag closeElementTag)
/*     */   {
/* 212 */     if (this.gatheringFinished) {
/* 213 */       throw new TemplateProcessingException("Gathering is finished already! We cannot gather more events");
/*     */     }
/* 215 */     this.syntheticModel.add(closeElementTag);
/*     */   }
/*     */   
/*     */   public final void gatherDocType(IDocType docType)
/*     */   {
/* 220 */     if (this.gatheringFinished) {
/* 221 */       throw new TemplateProcessingException("Gathering is finished already! We cannot gather more events");
/*     */     }
/* 223 */     this.syntheticModel.add(docType);
/*     */   }
/*     */   
/*     */   public final void gatherXMLDeclaration(IXMLDeclaration xmlDeclaration)
/*     */   {
/* 228 */     if (this.gatheringFinished) {
/* 229 */       throw new TemplateProcessingException("Gathering is finished already! We cannot gather more events");
/*     */     }
/* 231 */     this.syntheticModel.add(xmlDeclaration);
/*     */   }
/*     */   
/*     */   public final void gatherProcessingInstruction(IProcessingInstruction processingInstruction)
/*     */   {
/* 236 */     if (this.gatheringFinished) {
/* 237 */       throw new TemplateProcessingException("Gathering is finished already! We cannot gather more events");
/*     */     }
/* 239 */     this.syntheticModel.add(processingInstruction);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\AbstractGatheringModelProcessable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */