/*    */ package org.thymeleaf.engine;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class HTMLElementName
/*    */   extends ElementName
/*    */ {
/*    */   final String completeNamespacedElementName;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   final String completeHTML5ElementName;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   static HTMLElementName forName(String prefix, String elementName)
/*    */   {
/* 38 */     boolean hasPrefix = (prefix != null) && (prefix.length() > 0);
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 44 */     String nameElementName = (elementName == null) || (elementName.length() == 0) ? "" : elementName.toLowerCase();
/*    */     
/*    */     String[] completeAttributeNames;
/*    */     String namePrefix;
/*    */     String completeNamespacedElementName;
/*    */     String completeHTML5ElementName;
/*    */     String[] completeAttributeNames;
/* 51 */     if (hasPrefix)
/*    */     {
/* 53 */       String namePrefix = prefix.toLowerCase();
/* 54 */       String completeNamespacedElementName = namePrefix + ":" + nameElementName;
/* 55 */       String completeHTML5ElementName = namePrefix + "-" + nameElementName;
/* 56 */       completeAttributeNames = new String[] { completeNamespacedElementName, completeHTML5ElementName };
/*    */     }
/*    */     else
/*    */     {
/* 60 */       namePrefix = null;
/* 61 */       completeNamespacedElementName = nameElementName;
/* 62 */       completeHTML5ElementName = nameElementName;
/* 63 */       completeAttributeNames = new String[] { nameElementName };
/*    */     }
/*    */     
/*    */ 
/* 67 */     return new HTMLElementName(namePrefix, nameElementName, completeNamespacedElementName, completeHTML5ElementName, completeAttributeNames);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private HTMLElementName(String prefix, String elementName, String completeNamespacedElementName, String completeHTML5ElementName, String[] completeElementNames)
/*    */   {
/* 80 */     super(prefix, elementName, completeElementNames);
/*    */     
/* 82 */     this.completeNamespacedElementName = completeNamespacedElementName;
/* 83 */     this.completeHTML5ElementName = completeHTML5ElementName;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public String getCompleteNamespacedElementName()
/*    */   {
/* 90 */     return this.completeNamespacedElementName;
/*    */   }
/*    */   
/*    */   public String getCompleteHTML5ElementName() {
/* 94 */     return this.completeHTML5ElementName;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\HTMLElementName.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */