/*     */ package org.thymeleaf.engine;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.thymeleaf.IEngineConfiguration;
/*     */ import org.thymeleaf.context.IEngineContext;
/*     */ import org.thymeleaf.model.ITemplateEvent;
/*     */ import org.thymeleaf.model.IText;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ import org.thymeleaf.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class IteratedGatheringModelProcessable
/*     */   extends AbstractGatheringModelProcessable
/*     */ {
/*     */   private static final String DEFAULT_STATUS_VAR_SUFFIX = "Stat";
/*     */   private final IEngineContext context;
/*     */   private final TemplateMode templateMode;
/*     */   private final String iterVariableName;
/*     */   private final String iterStatusVariableName;
/*     */   private final IterationStatusVar iterStatusVariable;
/*     */   private final Iterator<?> iterator;
/*     */   private final Text precedingWhitespace;
/*     */   private IterationModels iterationModels;
/*     */   private DataDrivenTemplateIterator dataDrivenIterator;
/*     */   private int iter;
/*     */   private int iterOffset;
/*     */   private Model iterModel;
/*     */   
/*     */   static enum IterationWhiteSpaceHandling
/*     */   {
/*  48 */     ZERO_ITER,  SINGLE_ITER,  MULTIPLE_ITER;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private IterationWhiteSpaceHandling() {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   IteratedGatheringModelProcessable(IEngineConfiguration configuration, ProcessorTemplateHandler processorTemplateHandler, IEngineContext context, TemplateModelController modelController, TemplateFlowController flowController, TemplateModelController.SkipBody gatheredSkipBody, boolean gatheredSkipCloseTag, ProcessorExecutionVars processorExecutionVars, String iterVariableName, String iterStatusVariableName, Object iteratedObject, Text precedingWhitespace)
/*     */   {
/*  77 */     super(configuration, processorTemplateHandler, context, modelController, flowController, gatheredSkipBody, gatheredSkipCloseTag, processorExecutionVars);
/*     */     
/*  79 */     this.context = context;
/*  80 */     this.templateMode = context.getTemplateMode();
/*     */     
/*  82 */     this.iterator = computeIteratedObjectIterator(iteratedObject);
/*     */     
/*  84 */     this.iterVariableName = iterVariableName;
/*     */     
/*  86 */     if (StringUtils.isEmptyOrWhitespace(iterStatusVariableName))
/*     */     {
/*  88 */       this.iterStatusVariableName = (iterVariableName + "Stat");
/*     */     } else {
/*  90 */       this.iterStatusVariableName = iterStatusVariableName;
/*     */     }
/*     */     
/*  93 */     this.iterStatusVariable = new IterationStatusVar();
/*  94 */     this.iterStatusVariable.index = 0;
/*  95 */     this.iterStatusVariable.size = computeIteratedObjectSize(iteratedObject);
/*     */     
/*  97 */     this.precedingWhitespace = precedingWhitespace;
/*     */     
/*  99 */     if ((this.iterator != null) && ((this.iterator instanceof DataDrivenTemplateIterator))) {
/* 100 */       this.dataDrivenIterator = ((DataDrivenTemplateIterator)this.iterator);
/*     */     } else {
/* 102 */       this.dataDrivenIterator = null;
/*     */     }
/*     */     
/* 105 */     this.iter = 0;
/* 106 */     this.iterOffset = 0;
/* 107 */     this.iterModel = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ProcessorExecutionVars initializeProcessorExecutionVars()
/*     */   {
/* 117 */     return super.initializeProcessorExecutionVars().cloneVars();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean process()
/*     */   {
/* 124 */     TemplateFlowController flowController = getFlowController();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 129 */     if ((flowController != null) && (flowController.stopProcessing)) {
/* 130 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 138 */     if ((this.iterModel == null) && 
/* 139 */       (flowController != null) && (this.dataDrivenIterator != null) && (this.dataDrivenIterator.isPaused())) {
/* 140 */       flowController.stopProcessing = true;
/* 141 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 150 */     if (this.iterationModels == null)
/*     */     {
/*     */       IterationWhiteSpaceHandling iterationWhiteSpaceHandling;
/*     */       IterationWhiteSpaceHandling iterationWhiteSpaceHandling;
/* 154 */       if (this.dataDrivenIterator != null)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 167 */         if (this.iterator.hasNext()) {
/* 168 */           IterationWhiteSpaceHandling iterationWhiteSpaceHandling = IterationWhiteSpaceHandling.SINGLE_ITER;
/* 169 */           this.iterStatusVariable.current = this.iterator.next();
/*     */         } else {
/* 171 */           iterationWhiteSpaceHandling = IterationWhiteSpaceHandling.ZERO_ITER;
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/*     */         IterationWhiteSpaceHandling iterationWhiteSpaceHandling;
/*     */         
/*     */ 
/* 179 */         if (this.iterator.hasNext()) {
/* 180 */           this.iterStatusVariable.current = this.iterator.next();
/* 181 */           IterationWhiteSpaceHandling iterationWhiteSpaceHandling; if (this.iterator.hasNext()) {
/* 182 */             iterationWhiteSpaceHandling = IterationWhiteSpaceHandling.MULTIPLE_ITER;
/*     */           } else {
/* 184 */             iterationWhiteSpaceHandling = IterationWhiteSpaceHandling.SINGLE_ITER;
/*     */           }
/*     */         } else {
/* 187 */           iterationWhiteSpaceHandling = IterationWhiteSpaceHandling.ZERO_ITER;
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 197 */       this.iterationModels = computeIterationModels(iterationWhiteSpaceHandling);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 207 */     if (this.iter == 0)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 212 */       if (!this.iterationModels.isEmpty())
/*     */       {
/* 214 */         boolean iterationIsNew = false;
/*     */         
/* 216 */         if (this.iterModel == null) {
/* 217 */           this.iterModel = this.iterationModels.modelFirst;
/* 218 */           iterationIsNew = true;
/*     */         }
/*     */         
/* 221 */         if (!processIterationModel(flowController, iterationIsNew))
/*     */         {
/*     */ 
/*     */ 
/* 225 */           return false;
/*     */         }
/*     */         
/* 228 */         this.iter += 1;
/* 229 */         this.iterOffset = 0;
/* 230 */         this.iterModel = null;
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 237 */         if ((flowController != null) && (this.dataDrivenIterator != null) && (this.dataDrivenIterator.isPaused())) {
/* 238 */           flowController.stopProcessing = true;
/* 239 */           return false;
/*     */ 
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/*     */ 
/* 249 */         resetGatheredSkipFlagsAfterNoIterations();
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 259 */     while ((this.iterModel != null) || (this.iterator.hasNext()))
/*     */     {
/* 261 */       boolean iterationIsNew = false;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 266 */       if ((this.iterModel == null) && (this.iterOffset == 0))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 271 */         this.iterStatusVariable.index += 1;
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 276 */         this.iterStatusVariable.current = this.iterator.next();
/*     */         
/* 278 */         iterationIsNew = true;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 285 */       if (this.iterModel == null)
/*     */       {
/* 287 */         this.iterModel = (this.iterator.hasNext() ? this.iterationModels.modelMiddle : this.iterationModels.modelLast);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 293 */       if (!processIterationModel(flowController, iterationIsNew))
/*     */       {
/*     */ 
/*     */ 
/* 297 */         return false;
/*     */       }
/*     */       
/* 300 */       this.iter += 1;
/* 301 */       this.iterOffset = 0;
/* 302 */       this.iterModel = null;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 309 */       if ((flowController != null) && (this.dataDrivenIterator != null) && (this.dataDrivenIterator.isPaused())) {
/* 310 */         flowController.stopProcessing = true;
/* 311 */         return false;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 321 */     this.context.decreaseLevel();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 327 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean processIterationModel(TemplateFlowController flowController, boolean iterationIsNew)
/*     */   {
/* 335 */     if (iterationIsNew)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 340 */       this.context.increaseLevel();
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 345 */       this.context.setVariable(this.iterVariableName, this.iterStatusVariable.current);
/* 346 */       this.context.setVariable(this.iterStatusVariableName, this.iterStatusVariable);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 352 */       prepareProcessing();
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 357 */       if (this.dataDrivenIterator != null) {
/* 358 */         this.dataDrivenIterator.startIteration();
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 367 */     this.iterOffset += this.iterModel.process(getProcessorTemplateHandler(), this.iterOffset, flowController);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 372 */     if ((flowController != null) && ((this.iterOffset < this.iterModel.queueSize) || (flowController.stopProcessing))) {
/* 373 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 380 */     this.context.decreaseLevel();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 386 */     if (this.dataDrivenIterator != null) {
/* 387 */       this.dataDrivenIterator.finishIteration();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 393 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Integer computeIteratedObjectSize(Object iteratedObject)
/*     */   {
/* 410 */     if (iteratedObject == null) {
/* 411 */       return Integer.valueOf(0);
/*     */     }
/* 413 */     if ((iteratedObject instanceof Collection)) {
/* 414 */       return Integer.valueOf(((Collection)iteratedObject).size());
/*     */     }
/* 416 */     if ((iteratedObject instanceof Map)) {
/* 417 */       return Integer.valueOf(((Map)iteratedObject).size());
/*     */     }
/* 419 */     if (iteratedObject.getClass().isArray()) {
/* 420 */       return Integer.valueOf(Array.getLength(iteratedObject));
/*     */     }
/* 422 */     if ((iteratedObject instanceof Iterable)) {
/* 423 */       return null;
/*     */     }
/* 425 */     if ((iteratedObject instanceof Iterator)) {
/* 426 */       return null;
/*     */     }
/* 428 */     return Integer.valueOf(1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Iterator<?> computeIteratedObjectIterator(Object iteratedObject)
/*     */   {
/* 438 */     if (iteratedObject == null) {
/* 439 */       return Collections.EMPTY_LIST.iterator();
/*     */     }
/* 441 */     if ((iteratedObject instanceof Collection)) {
/* 442 */       return ((Collection)iteratedObject).iterator();
/*     */     }
/* 444 */     if ((iteratedObject instanceof Map)) {
/* 445 */       return ((Map)iteratedObject).entrySet().iterator();
/*     */     }
/* 447 */     if (iteratedObject.getClass().isArray()) {
/* 448 */       new Iterator()
/*     */       {
/* 450 */         protected final Object array = IteratedGatheringModelProcessable.this;
/* 451 */         protected final int length = Array.getLength(this.array);
/* 452 */         private int i = 0;
/*     */         
/*     */         public boolean hasNext() {
/* 455 */           return this.i < this.length;
/*     */         }
/*     */         
/*     */         public Object next() {
/* 459 */           return Array.get(this.array, this.i++);
/*     */         }
/*     */         
/*     */         public void remove() {
/* 463 */           throw new UnsupportedOperationException("Cannot remove from an array iterator");
/*     */         }
/*     */       };
/*     */     }
/*     */     
/* 468 */     if ((iteratedObject instanceof Iterable)) {
/* 469 */       return ((Iterable)iteratedObject).iterator();
/*     */     }
/* 471 */     if ((iteratedObject instanceof Iterator)) {
/* 472 */       return (Iterator)iteratedObject;
/*     */     }
/* 474 */     if ((iteratedObject instanceof Enumeration)) {
/* 475 */       new Iterator()
/*     */       {
/* 477 */         protected final Enumeration<?> enumeration = (Enumeration)IteratedGatheringModelProcessable.this;
/*     */         
/*     */         public boolean hasNext()
/*     */         {
/* 481 */           return this.enumeration.hasMoreElements();
/*     */         }
/*     */         
/*     */         public Object next() {
/* 485 */           return this.enumeration.nextElement();
/*     */         }
/*     */         
/*     */         public void remove() {
/* 489 */           throw new UnsupportedOperationException("Cannot remove from an Enumeration iterator");
/*     */         }
/*     */       };
/*     */     }
/*     */     
/* 494 */     return Collections.singletonList(iteratedObject).iterator();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private IterationModels computeIterationModels(IterationWhiteSpaceHandling iterationWhiteSpaceHandling)
/*     */   {
/* 513 */     if (iterationWhiteSpaceHandling == IterationWhiteSpaceHandling.ZERO_ITER) {
/* 514 */       return IterationModels.EMPTY;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 521 */     Model innerModel = getInnerModel();
/* 522 */     int gatheredModelSize = innerModel.size();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 528 */     if (iterationWhiteSpaceHandling == IterationWhiteSpaceHandling.SINGLE_ITER) {
/* 529 */       return new IterationModels(innerModel, innerModel, innerModel);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 536 */     if (!this.templateMode.isText()) {
/* 537 */       if (this.precedingWhitespace != null) {
/* 538 */         Model modelWithWhiteSpace = new Model(innerModel);
/* 539 */         modelWithWhiteSpace.insert(0, this.precedingWhitespace);
/* 540 */         return new IterationModels(innerModel, modelWithWhiteSpace, modelWithWhiteSpace);
/*     */       }
/* 542 */       return new IterationModels(innerModel, innerModel, innerModel);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 585 */     if (innerModel.size() <= 2)
/*     */     {
/* 587 */       return new IterationModels(innerModel, innerModel, innerModel);
/*     */     }
/*     */     
/* 590 */     int firstBodyEventCutPoint = -1;
/* 591 */     int lastBodyEventCutPoint = -1;
/*     */     
/* 593 */     ITemplateEvent firstBodyEvent = innerModel.get(1);
/* 594 */     Text firstTextBodyEvent = null;
/* 595 */     if (((innerModel.get(0) instanceof OpenElementTag)) && ((firstBodyEvent instanceof IText)))
/*     */     {
/* 597 */       firstTextBodyEvent = Text.asEngineText((IText)firstBodyEvent);
/*     */       
/* 599 */       int firstTextEventLen = firstTextBodyEvent.length();
/* 600 */       int i = 0;
/*     */       
/* 602 */       while ((i < firstTextEventLen) && (firstBodyEventCutPoint < 0)) {
/* 603 */         char c = firstTextBodyEvent.charAt(i);
/* 604 */         if (c == '\n') {
/* 605 */           firstBodyEventCutPoint = i + 1;
/* 606 */           break; }
/* 607 */         if (!Character.isWhitespace(c)) break;
/* 608 */         i++;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 618 */     ITemplateEvent lastBodyEvent = innerModel.get(gatheredModelSize - 2);
/* 619 */     Text lastTextBodyEvent = null;
/* 620 */     if ((firstBodyEventCutPoint >= 0) && 
/* 621 */       ((innerModel.get(gatheredModelSize - 1) instanceof CloseElementTag)) && ((lastBodyEvent instanceof IText)))
/*     */     {
/* 623 */       lastTextBodyEvent = Text.asEngineText((IText)lastBodyEvent);
/*     */       
/* 625 */       int lastTextEventLen = lastTextBodyEvent.length();
/* 626 */       int i = lastTextEventLen - 1;
/*     */       
/* 628 */       while ((i >= 0) && (lastBodyEventCutPoint < 0)) {
/* 629 */         char c = lastTextBodyEvent.charAt(i);
/* 630 */         if (c == '\n') {
/* 631 */           lastBodyEventCutPoint = i + 1;
/* 632 */           break; }
/* 633 */         if (!Character.isWhitespace(c)) break;
/* 634 */         i--;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 648 */     if ((firstBodyEventCutPoint < 0) || (lastBodyEventCutPoint < 0))
/*     */     {
/* 650 */       return new IterationModels(innerModel, innerModel, innerModel);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 658 */     if (firstBodyEvent == lastBodyEvent)
/*     */     {
/*     */ 
/* 661 */       Text textForFirst = new Text(firstTextBodyEvent.subSequence(0, lastBodyEventCutPoint));
/* 662 */       Text textForMiddle = new Text(firstTextBodyEvent.subSequence(firstBodyEventCutPoint, lastBodyEventCutPoint));
/* 663 */       Text textForLast = new Text(firstTextBodyEvent.subSequence(firstBodyEventCutPoint, firstTextBodyEvent.length()));
/*     */       
/* 665 */       Model modelFirst = new Model(innerModel);
/* 666 */       modelFirst.replace(1, textForFirst);
/*     */       
/* 668 */       Model modelMiddle = new Model(innerModel);
/* 669 */       modelMiddle.replace(1, textForMiddle);
/*     */       
/* 671 */       Model modelLast = new Model(innerModel);
/* 672 */       modelLast.replace(1, textForLast);
/*     */       
/* 674 */       return new IterationModels(modelFirst, modelMiddle, modelLast);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 680 */     Model modelFirst = new Model(innerModel);
/* 681 */     Model modelMiddle = new Model(innerModel);
/* 682 */     Model modelLast = new Model(innerModel);
/*     */     
/* 684 */     if (firstBodyEventCutPoint > 0) {
/* 685 */       Text headTextForMiddleAndMax = new Text(firstTextBodyEvent.subSequence(firstBodyEventCutPoint, firstTextBodyEvent.length()));
/* 686 */       modelMiddle.replace(1, headTextForMiddleAndMax);
/* 687 */       modelLast.replace(1, headTextForMiddleAndMax);
/*     */     }
/*     */     
/* 690 */     if (lastBodyEventCutPoint < lastTextBodyEvent.length()) {
/* 691 */       Text tailTextForFirstAndMiddle = new Text(lastTextBodyEvent.subSequence(0, lastBodyEventCutPoint));
/* 692 */       modelFirst.replace(gatheredModelSize - 2, tailTextForFirstAndMiddle);
/* 693 */       modelMiddle.replace(gatheredModelSize - 2, tailTextForFirstAndMiddle);
/*     */     }
/*     */     
/* 696 */     return new IterationModels(modelFirst, modelMiddle, modelLast);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final class IterationModels
/*     */   {
/* 706 */     static IterationModels EMPTY = new IterationModels(null, null, null);
/*     */     
/*     */     final Model modelFirst;
/*     */     final Model modelMiddle;
/*     */     final Model modelLast;
/*     */     final boolean empty;
/*     */     
/*     */     IterationModels(Model modelFirst, Model modelMiddle, Model modelLast)
/*     */     {
/* 715 */       this.modelFirst = modelFirst;
/* 716 */       this.modelMiddle = modelMiddle;
/* 717 */       this.modelLast = modelLast;
/* 718 */       this.empty = ((this.modelFirst == null) && (this.modelMiddle == null) && (this.modelLast == null));
/*     */     }
/*     */     
/*     */     boolean isEmpty() {
/* 722 */       return this.empty;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\IteratedGatheringModelProcessable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */