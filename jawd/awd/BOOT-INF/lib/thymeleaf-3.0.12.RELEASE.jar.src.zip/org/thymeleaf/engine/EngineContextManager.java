/*    */ package org.thymeleaf.engine;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.thymeleaf.IEngineConfiguration;
/*    */ import org.thymeleaf.context.IContext;
/*    */ import org.thymeleaf.context.IEngineContext;
/*    */ import org.thymeleaf.context.IEngineContextFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class EngineContextManager
/*    */ {
/*    */   static IEngineContext prepareEngineContext(IEngineConfiguration configuration, TemplateData templateData, Map<String, Object> templateResolutionAttributes, IContext context)
/*    */   {
/* 49 */     IEngineContext engineContext = createEngineContextIfNeeded(configuration, templateData, templateResolutionAttributes, context);
/*    */     
/*    */ 
/*    */ 
/*    */ 
/* 54 */     engineContext.increaseLevel();
/*    */     
/* 56 */     if ((context instanceof IEngineContext))
/*    */     {
/* 58 */       engineContext.setTemplateData(templateData);
/*    */     }
/*    */     
/* 61 */     return engineContext;
/*    */   }
/*    */   
/*    */ 
/*    */   static void disposeEngineContext(IEngineContext engineContext)
/*    */   {
/* 67 */     engineContext.decreaseLevel();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private static IEngineContext createEngineContextIfNeeded(IEngineConfiguration configuration, TemplateData templateData, Map<String, Object> templateResolutionAttributes, IContext context)
/*    */   {
/* 78 */     if ((context instanceof IEngineContext))
/*    */     {
/* 80 */       return (IEngineContext)context;
/*    */     }
/*    */     
/*    */ 
/*    */ 
/* 85 */     IEngineContextFactory engineContextFactory = configuration.getEngineContextFactory();
/* 86 */     return engineContextFactory.createEngineContext(configuration, templateData, templateResolutionAttributes, context);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\EngineContextManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */