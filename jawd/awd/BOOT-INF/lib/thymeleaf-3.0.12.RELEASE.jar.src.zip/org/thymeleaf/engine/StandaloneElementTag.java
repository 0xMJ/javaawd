/*     */ package org.thymeleaf.engine;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import java.util.Arrays;
/*     */ import org.thymeleaf.model.AttributeValueQuotes;
/*     */ import org.thymeleaf.model.IAttribute;
/*     */ import org.thymeleaf.model.IModelVisitor;
/*     */ import org.thymeleaf.model.IStandaloneElementTag;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class StandaloneElementTag
/*     */   extends AbstractProcessableElementTag
/*     */   implements IStandaloneElementTag, IEngineTemplateEvent
/*     */ {
/*     */   final boolean minimized;
/*     */   
/*     */   StandaloneElementTag(TemplateMode templateMode, ElementDefinition elementDefinition, String elementCompleteName, Attributes attributes, boolean synthetic, boolean minimized)
/*     */   {
/*  54 */     super(templateMode, elementDefinition, elementCompleteName, attributes, synthetic);
/*  55 */     Validate.isTrue((minimized) || (templateMode == TemplateMode.HTML), "Not-minimized standalone elements are only allowed in HTML template mode (is " + templateMode + ")");
/*  56 */     this.minimized = minimized;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   StandaloneElementTag(TemplateMode templateMode, ElementDefinition elementDefinition, String elementCompleteName, Attributes attributes, boolean synthetic, boolean minimized, String templateName, int line, int col)
/*     */   {
/*  70 */     super(templateMode, elementDefinition, elementCompleteName, attributes, synthetic, templateName, line, col);
/*  71 */     Validate.isTrue((minimized) || (templateMode == TemplateMode.HTML), "Not-minimized standalone elements are only allowed in HTML template mode (is " + templateMode + ")");
/*  72 */     this.minimized = minimized;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isMinimized()
/*     */   {
/*  79 */     return this.minimized;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   StandaloneElementTag setAttribute(AttributeDefinitions attributeDefinitions, AttributeDefinition attributeDefinition, String completeName, String value, AttributeValueQuotes valueQuotes)
/*     */   {
/*  89 */     Attributes oldAttributes = this.attributes != null ? this.attributes : Attributes.EMPTY_ATTRIBUTES;
/*     */     
/*  91 */     Attributes newAttributes = oldAttributes.setAttribute(attributeDefinitions, this.templateMode, attributeDefinition, completeName, value, valueQuotes);
/*  92 */     return new StandaloneElementTag(this.templateMode, this.elementDefinition, this.elementCompleteName, newAttributes, this.synthetic, this.minimized, this.templateName, this.line, this.col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   StandaloneElementTag replaceAttribute(AttributeDefinitions attributeDefinitions, AttributeName oldName, AttributeDefinition newAttributeDefinition, String completeNewName, String value, AttributeValueQuotes valueQuotes)
/*     */   {
/* 102 */     Attributes oldAttributes = this.attributes != null ? this.attributes : Attributes.EMPTY_ATTRIBUTES;
/*     */     
/* 104 */     Attributes newAttributes = oldAttributes.replaceAttribute(attributeDefinitions, this.templateMode, oldName, newAttributeDefinition, completeNewName, value, valueQuotes);
/* 105 */     return new StandaloneElementTag(this.templateMode, this.elementDefinition, this.elementCompleteName, newAttributes, this.synthetic, this.minimized, this.templateName, this.line, this.col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   StandaloneElementTag removeAttribute(String prefix, String name)
/*     */   {
/* 112 */     Attributes oldAttributes = this.attributes != null ? this.attributes : Attributes.EMPTY_ATTRIBUTES;
/* 113 */     Attributes newAttributes = oldAttributes.removeAttribute(this.templateMode, prefix, name);
/* 114 */     if (oldAttributes == newAttributes) {
/* 115 */       return this;
/*     */     }
/* 117 */     return new StandaloneElementTag(this.templateMode, this.elementDefinition, this.elementCompleteName, newAttributes, this.synthetic, this.minimized, this.templateName, this.line, this.col);
/*     */   }
/*     */   
/*     */   StandaloneElementTag removeAttribute(String completeName)
/*     */   {
/* 122 */     Attributes oldAttributes = this.attributes != null ? this.attributes : Attributes.EMPTY_ATTRIBUTES;
/* 123 */     Attributes newAttributes = oldAttributes.removeAttribute(this.templateMode, completeName);
/* 124 */     if (oldAttributes == newAttributes) {
/* 125 */       return this;
/*     */     }
/* 127 */     return new StandaloneElementTag(this.templateMode, this.elementDefinition, this.elementCompleteName, newAttributes, this.synthetic, this.minimized, this.templateName, this.line, this.col);
/*     */   }
/*     */   
/*     */   StandaloneElementTag removeAttribute(AttributeName attributeName)
/*     */   {
/* 132 */     Attributes oldAttributes = this.attributes != null ? this.attributes : Attributes.EMPTY_ATTRIBUTES;
/* 133 */     Attributes newAttributes = oldAttributes.removeAttribute(attributeName);
/* 134 */     if (oldAttributes == newAttributes) {
/* 135 */       return this;
/*     */     }
/* 137 */     return new StandaloneElementTag(this.templateMode, this.elementDefinition, this.elementCompleteName, newAttributes, this.synthetic, this.minimized, this.templateName, this.line, this.col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void accept(IModelVisitor visitor)
/*     */   {
/* 144 */     visitor.visit(this);
/*     */   }
/*     */   
/*     */   public void write(Writer writer) throws IOException
/*     */   {
/* 149 */     if (this.synthetic)
/*     */     {
/* 151 */       return;
/*     */     }
/* 153 */     if (this.templateMode.isText()) {
/* 154 */       writer.write("[#");
/* 155 */       writer.write(this.elementCompleteName);
/* 156 */       if (this.attributes != null) {
/* 157 */         this.attributes.write(writer);
/*     */       }
/* 159 */       if (this.minimized) {
/* 160 */         writer.write("/]");
/*     */       } else {
/* 162 */         writer.write("]");
/*     */       }
/* 164 */       return;
/*     */     }
/* 166 */     writer.write(60);
/* 167 */     writer.write(this.elementCompleteName);
/* 168 */     if (this.attributes != null) {
/* 169 */       this.attributes.write(writer);
/*     */     }
/* 171 */     if (this.minimized) {
/* 172 */       writer.write("/>");
/*     */     } else {
/* 174 */       writer.write(62);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static StandaloneElementTag asEngineStandaloneElementTag(IStandaloneElementTag standaloneElementTag)
/*     */   {
/* 184 */     if ((standaloneElementTag instanceof StandaloneElementTag)) {
/* 185 */       return (StandaloneElementTag)standaloneElementTag;
/*     */     }
/*     */     
/*     */ 
/* 189 */     IAttribute[] originalAttributeArray = standaloneElementTag.getAllAttributes();
/*     */     Attributes attributes;
/*     */     Attributes attributes;
/* 192 */     if ((originalAttributeArray == null) || (originalAttributeArray.length == 0)) {
/* 193 */       attributes = null;
/*     */     }
/*     */     else
/*     */     {
/* 197 */       Attribute[] newAttributeArray = new Attribute[originalAttributeArray.length];
/* 198 */       for (int i = 0; i < originalAttributeArray.length; i++) {
/* 199 */         IAttribute originalAttribute = originalAttributeArray[i];
/* 200 */         newAttributeArray[i] = new Attribute(originalAttribute
/*     */         
/* 202 */           .getAttributeDefinition(), originalAttribute.getAttributeCompleteName(), originalAttribute
/* 203 */           .getOperator(), originalAttribute.getValue(), originalAttribute.getValueQuotes(), originalAttribute
/* 204 */           .getTemplateName(), originalAttribute.getLine(), originalAttribute.getCol()); }
/*     */       String[] newInnerWhiteSpaces;
/*     */       String[] newInnerWhiteSpaces;
/* 207 */       if (newAttributeArray.length == 1) {
/* 208 */         newInnerWhiteSpaces = Attributes.DEFAULT_WHITE_SPACE_ARRAY;
/*     */       } else {
/* 210 */         newInnerWhiteSpaces = new String[newAttributeArray.length];
/* 211 */         Arrays.fill(newInnerWhiteSpaces, " ");
/*     */       }
/* 213 */       attributes = new Attributes(newAttributeArray, newInnerWhiteSpaces);
/*     */     }
/*     */     
/* 216 */     return new StandaloneElementTag(standaloneElementTag
/* 217 */       .getTemplateMode(), standaloneElementTag.getElementDefinition(), standaloneElementTag.getElementCompleteName(), attributes, standaloneElementTag
/* 218 */       .isSynthetic(), standaloneElementTag.isMinimized(), standaloneElementTag
/* 219 */       .getTemplateName(), standaloneElementTag.getLine(), standaloneElementTag.getCol());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void beHandled(ITemplateHandler handler)
/*     */   {
/* 228 */     handler.handleStandaloneElement(this);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\StandaloneElementTag.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */