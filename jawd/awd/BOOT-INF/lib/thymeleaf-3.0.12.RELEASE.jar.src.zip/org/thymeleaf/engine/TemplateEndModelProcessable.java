/*    */ package org.thymeleaf.engine;
/*    */ 
/*    */ import org.thymeleaf.model.ITemplateEnd;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class TemplateEndModelProcessable
/*    */   implements IEngineProcessable
/*    */ {
/*    */   private final ITemplateEnd templateEnd;
/*    */   private final Model model;
/*    */   private final ITemplateHandler modelHandler;
/*    */   private final ProcessorTemplateHandler processorTemplateHandler;
/*    */   private final ITemplateHandler nextHandler;
/*    */   private final TemplateFlowController flowController;
/*    */   private int offset;
/*    */   
/*    */   TemplateEndModelProcessable(ITemplateEnd templateEnd, Model model, ITemplateHandler modelHandler, ProcessorTemplateHandler processorTemplateHandler, ITemplateHandler nextHandler, TemplateFlowController flowController)
/*    */   {
/* 48 */     this.templateEnd = templateEnd;
/* 49 */     this.model = model;
/* 50 */     this.modelHandler = modelHandler;
/* 51 */     this.processorTemplateHandler = processorTemplateHandler;
/* 52 */     this.nextHandler = nextHandler;
/* 53 */     this.flowController = flowController;
/* 54 */     this.offset = 0;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean process()
/*    */   {
/* 63 */     if (this.flowController.stopProcessing) {
/* 64 */       return false;
/*    */     }
/*    */     
/*    */ 
/*    */ 
/*    */ 
/* 70 */     this.offset += this.model.process(this.modelHandler, this.offset, this.flowController);
/* 71 */     if ((this.offset < this.model.queueSize) || (this.flowController.stopProcessing)) {
/* 72 */       return false;
/*    */     }
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 79 */     this.nextHandler.handleTemplateEnd(this.templateEnd);
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 85 */     this.processorTemplateHandler.performTearDownChecks(this.templateEnd);
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 93 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\TemplateEndModelProcessable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */