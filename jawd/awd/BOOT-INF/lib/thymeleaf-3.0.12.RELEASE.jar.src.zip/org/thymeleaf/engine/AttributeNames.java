/*     */ package org.thymeleaf.engine;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReadWriteLock;
/*     */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ import org.thymeleaf.util.TextUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AttributeNames
/*     */ {
/*  41 */   private static final AttributeNamesRepository htmlAttributeNamesRepository = new AttributeNamesRepository(TemplateMode.HTML);
/*  42 */   private static final AttributeNamesRepository xmlAttributeNamesRepository = new AttributeNamesRepository(TemplateMode.XML);
/*  43 */   private static final AttributeNamesRepository textAttributeNamesRepository = new AttributeNamesRepository(TemplateMode.TEXT);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static TextAttributeName buildTextAttributeName(char[] attributeNameBuffer, int attributeNameOffset, int attributeNameLen)
/*     */   {
/*  51 */     if ((attributeNameBuffer == null) || (attributeNameLen == 0)) {
/*  52 */       throw new IllegalArgumentException("Attribute name buffer cannot be null or empty");
/*     */     }
/*  54 */     if ((attributeNameOffset < 0) || (attributeNameLen < 0)) {
/*  55 */       throw new IllegalArgumentException("Attribute name offset and len must be equal or greater than zero");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  60 */     int i = attributeNameOffset;
/*  61 */     int n = attributeNameLen;
/*  62 */     while (n-- != 0)
/*     */     {
/*  64 */       char c = attributeNameBuffer[(i++)];
/*  65 */       if ((c == ':') && 
/*     */       
/*     */ 
/*     */ 
/*  69 */         (c == ':')) {
/*  70 */         if (i == attributeNameOffset + 1)
/*     */         {
/*  72 */           return TextAttributeName.forName(null, new String(attributeNameBuffer, attributeNameOffset, attributeNameLen));
/*     */         }
/*     */         
/*  75 */         return TextAttributeName.forName(new String(attributeNameBuffer, attributeNameOffset, i - (attributeNameOffset + 1)), new String(attributeNameBuffer, i, attributeNameOffset + attributeNameLen - i));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  82 */     return TextAttributeName.forName(null, new String(attributeNameBuffer, attributeNameOffset, attributeNameLen));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static XMLAttributeName buildXMLAttributeName(char[] attributeNameBuffer, int attributeNameOffset, int attributeNameLen)
/*     */   {
/*  90 */     if ((attributeNameBuffer == null) || (attributeNameLen == 0)) {
/*  91 */       throw new IllegalArgumentException("Attribute name buffer cannot be null or empty");
/*     */     }
/*  93 */     if ((attributeNameOffset < 0) || (attributeNameLen < 0)) {
/*  94 */       throw new IllegalArgumentException("Attribute name offset and len must be equal or greater than zero");
/*     */     }
/*     */     
/*     */ 
/*  98 */     int i = attributeNameOffset;
/*  99 */     int n = attributeNameLen;
/* 100 */     while (n-- != 0)
/*     */     {
/* 102 */       char c = attributeNameBuffer[(i++)];
/* 103 */       if ((c == ':') && 
/*     */       
/*     */ 
/*     */ 
/* 107 */         (c == ':')) {
/* 108 */         if (i == attributeNameOffset + 1)
/*     */         {
/* 110 */           return XMLAttributeName.forName(null, new String(attributeNameBuffer, attributeNameOffset, attributeNameLen));
/*     */         }
/*     */         
/* 113 */         return XMLAttributeName.forName(new String(attributeNameBuffer, attributeNameOffset, i - (attributeNameOffset + 1)), new String(attributeNameBuffer, i, attributeNameOffset + attributeNameLen - i));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 120 */     return XMLAttributeName.forName(null, new String(attributeNameBuffer, attributeNameOffset, attributeNameLen));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static HTMLAttributeName buildHTMLAttributeName(char[] attributeNameBuffer, int attributeNameOffset, int attributeNameLen)
/*     */   {
/* 128 */     if ((attributeNameBuffer == null) || (attributeNameLen == 0)) {
/* 129 */       throw new IllegalArgumentException("Attribute name buffer cannot be null or empty");
/*     */     }
/* 131 */     if ((attributeNameOffset < 0) || (attributeNameLen < 0)) {
/* 132 */       throw new IllegalArgumentException("Attribute name offset and len must be equal or greater than zero");
/*     */     }
/*     */     
/*     */ 
/* 136 */     int i = attributeNameOffset;
/* 137 */     int n = attributeNameLen;
/* 138 */     boolean inData = false;
/* 139 */     while (n-- != 0)
/*     */     {
/* 141 */       char c = attributeNameBuffer[(i++)];
/* 142 */       if ((c == ':') || (c == '-'))
/*     */       {
/*     */ 
/*     */ 
/* 146 */         if ((!inData) && (c == ':')) {
/* 147 */           if (i == attributeNameOffset + 1)
/*     */           {
/* 149 */             return HTMLAttributeName.forName(null, new String(attributeNameBuffer, attributeNameOffset, attributeNameLen));
/*     */           }
/*     */           
/* 152 */           if ((TextUtils.equals(TemplateMode.HTML.isCaseSensitive(), "xml:", 0, 4, attributeNameBuffer, attributeNameOffset, i - attributeNameOffset)) || 
/* 153 */             (TextUtils.equals(TemplateMode.HTML.isCaseSensitive(), "xmlns:", 0, 6, attributeNameBuffer, attributeNameOffset, i - attributeNameOffset)))
/*     */           {
/* 155 */             return HTMLAttributeName.forName(null, new String(attributeNameBuffer, attributeNameOffset, attributeNameLen));
/*     */           }
/*     */           
/* 158 */           return HTMLAttributeName.forName(new String(attributeNameBuffer, attributeNameOffset, i - (attributeNameOffset + 1)), new String(attributeNameBuffer, i, attributeNameOffset + attributeNameLen - i));
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 163 */         if ((!inData) && (c == '-')) {
/* 164 */           if ((i == attributeNameOffset + 5) && (TextUtils.equals(TemplateMode.HTML.isCaseSensitive(), "data", 0, 4, attributeNameBuffer, attributeNameOffset, i - (attributeNameOffset + 1)))) {
/* 165 */             inData = true;
/*     */           }
/*     */           else
/*     */           {
/* 169 */             return HTMLAttributeName.forName(null, new String(attributeNameBuffer, attributeNameOffset, attributeNameLen));
/*     */           }
/*     */           
/*     */         }
/* 173 */         else if ((inData) && (c == '-')) {
/* 174 */           if (i == attributeNameOffset + 6)
/*     */           {
/* 176 */             return HTMLAttributeName.forName(null, new String(attributeNameBuffer, attributeNameOffset, attributeNameLen));
/*     */           }
/*     */           
/* 179 */           return HTMLAttributeName.forName(new String(attributeNameBuffer, attributeNameOffset + 5, i - (attributeNameOffset + 6)), new String(attributeNameBuffer, i, attributeNameOffset + attributeNameLen - i));
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 186 */     return HTMLAttributeName.forName(null, new String(attributeNameBuffer, attributeNameOffset, attributeNameLen));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static TextAttributeName buildTextAttributeName(String attributeName)
/*     */   {
/* 194 */     if ((attributeName == null) || (attributeName.length() == 0)) {
/* 195 */       throw new IllegalArgumentException("Attribute name cannot be null or empty");
/*     */     }
/*     */     
/*     */ 
/* 199 */     int i = 0;
/* 200 */     int n = attributeName.length();
/* 201 */     while (n-- != 0)
/*     */     {
/* 203 */       char c = attributeName.charAt(i++);
/* 204 */       if ((c == ':') && 
/*     */       
/*     */ 
/*     */ 
/* 208 */         (c == ':')) {
/* 209 */         if (i == 1)
/*     */         {
/* 211 */           return TextAttributeName.forName(null, attributeName);
/*     */         }
/*     */         
/* 214 */         return TextAttributeName.forName(attributeName
/* 215 */           .substring(0, i - 1), attributeName
/* 216 */           .substring(i, attributeName.length()));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 221 */     return TextAttributeName.forName(null, attributeName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static XMLAttributeName buildXMLAttributeName(String attributeName)
/*     */   {
/* 229 */     if ((attributeName == null) || (attributeName.length() == 0)) {
/* 230 */       throw new IllegalArgumentException("Attribute name cannot be null or empty");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 235 */     int i = 0;
/* 236 */     int n = attributeName.length();
/* 237 */     while (n-- != 0)
/*     */     {
/* 239 */       char c = attributeName.charAt(i++);
/* 240 */       if ((c == ':') && 
/*     */       
/*     */ 
/*     */ 
/* 244 */         (c == ':')) {
/* 245 */         if (i == 1)
/*     */         {
/* 247 */           return XMLAttributeName.forName(null, attributeName);
/*     */         }
/*     */         
/* 250 */         return XMLAttributeName.forName(attributeName
/* 251 */           .substring(0, i - 1), attributeName
/* 252 */           .substring(i, attributeName.length()));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 257 */     return XMLAttributeName.forName(null, attributeName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static HTMLAttributeName buildHTMLAttributeName(String attributeName)
/*     */   {
/* 265 */     if ((attributeName == null) || (attributeName.length() == 0)) {
/* 266 */       throw new IllegalArgumentException("Attribute name cannot be null or empty");
/*     */     }
/*     */     
/*     */ 
/* 270 */     int i = 0;
/* 271 */     int n = attributeName.length();
/* 272 */     boolean inData = false;
/* 273 */     while (n-- != 0)
/*     */     {
/* 275 */       char c = attributeName.charAt(i++);
/* 276 */       if ((c == ':') || (c == '-'))
/*     */       {
/*     */ 
/*     */ 
/* 280 */         if ((!inData) && (c == ':')) {
/* 281 */           if (i == 1)
/*     */           {
/* 283 */             return HTMLAttributeName.forName(null, attributeName);
/*     */           }
/*     */           
/* 286 */           if ((TextUtils.equals(TemplateMode.HTML.isCaseSensitive(), "xml:", 0, 4, attributeName, 0, i)) || 
/* 287 */             (TextUtils.equals(TemplateMode.HTML.isCaseSensitive(), "xmlns:", 0, 6, attributeName, 0, i)))
/*     */           {
/* 289 */             return HTMLAttributeName.forName(null, attributeName);
/*     */           }
/*     */           
/* 292 */           return HTMLAttributeName.forName(attributeName
/* 293 */             .substring(0, i - 1), attributeName
/* 294 */             .substring(i, attributeName.length()));
/*     */         }
/*     */         
/* 297 */         if ((!inData) && (c == '-')) {
/* 298 */           if ((i == 5) && (TextUtils.equals(TemplateMode.HTML.isCaseSensitive(), "data", 0, 4, attributeName, 0, 4))) {
/* 299 */             inData = true;
/*     */           }
/*     */           else
/*     */           {
/* 303 */             return HTMLAttributeName.forName(null, attributeName);
/*     */           }
/*     */           
/*     */         }
/* 307 */         else if ((inData) && (c == '-')) {
/* 308 */           if (i == 6)
/*     */           {
/* 310 */             return HTMLAttributeName.forName(null, attributeName);
/*     */           }
/*     */           
/* 313 */           return HTMLAttributeName.forName(attributeName
/* 314 */             .substring(5, i - 1), attributeName
/* 315 */             .substring(i, attributeName.length()));
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 320 */     return HTMLAttributeName.forName(null, attributeName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static TextAttributeName buildTextAttributeName(String prefix, String attributeName)
/*     */   {
/* 327 */     if ((attributeName == null) || (attributeName.length() == 0)) {
/* 328 */       throw new IllegalArgumentException("Attribute name cannot be null or empty");
/*     */     }
/* 330 */     if ((prefix == null) || (prefix.trim().length() == 0)) {
/* 331 */       return buildTextAttributeName(attributeName);
/*     */     }
/* 333 */     return TextAttributeName.forName(prefix, attributeName);
/*     */   }
/*     */   
/*     */ 
/*     */   private static XMLAttributeName buildXMLAttributeName(String prefix, String attributeName)
/*     */   {
/* 339 */     if ((attributeName == null) || (attributeName.length() == 0)) {
/* 340 */       throw new IllegalArgumentException("Attribute name cannot be null or empty");
/*     */     }
/* 342 */     if ((prefix == null) || (prefix.trim().length() == 0)) {
/* 343 */       return buildXMLAttributeName(attributeName);
/*     */     }
/* 345 */     return XMLAttributeName.forName(prefix, attributeName);
/*     */   }
/*     */   
/*     */ 
/*     */   private static HTMLAttributeName buildHTMLAttributeName(String prefix, String attributeName)
/*     */   {
/* 351 */     if ((attributeName == null) || (attributeName.length() == 0)) {
/* 352 */       throw new IllegalArgumentException("Attribute name cannot be null or empty");
/*     */     }
/* 354 */     if ((prefix == null) || (prefix.trim().length() == 0)) {
/* 355 */       return buildHTMLAttributeName(attributeName);
/*     */     }
/* 357 */     return HTMLAttributeName.forName(prefix, attributeName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static AttributeName forName(TemplateMode templateMode, char[] attributeNameBuffer, int attributeNameOffset, int attributeNameLen)
/*     */   {
/* 366 */     if (templateMode == null) {
/* 367 */       throw new IllegalArgumentException("Template Mode cannot be null");
/*     */     }
/*     */     
/* 370 */     if (templateMode == TemplateMode.HTML) {
/* 371 */       return forHTMLName(attributeNameBuffer, attributeNameOffset, attributeNameLen);
/*     */     }
/*     */     
/* 374 */     if (templateMode == TemplateMode.XML) {
/* 375 */       return forXMLName(attributeNameBuffer, attributeNameOffset, attributeNameLen);
/*     */     }
/*     */     
/* 378 */     if (templateMode.isText()) {
/* 379 */       return forTextName(attributeNameBuffer, attributeNameOffset, attributeNameLen);
/*     */     }
/*     */     
/* 382 */     throw new IllegalArgumentException("Unknown template mode '" + templateMode + "'");
/*     */   }
/*     */   
/*     */ 
/*     */   public static AttributeName forName(TemplateMode templateMode, String attributeName)
/*     */   {
/* 388 */     if (templateMode == null) {
/* 389 */       throw new IllegalArgumentException("Template Mode cannot be null");
/*     */     }
/*     */     
/* 392 */     if (templateMode == TemplateMode.HTML) {
/* 393 */       return forHTMLName(attributeName);
/*     */     }
/*     */     
/* 396 */     if (templateMode == TemplateMode.XML) {
/* 397 */       return forXMLName(attributeName);
/*     */     }
/*     */     
/* 400 */     if (templateMode.isText()) {
/* 401 */       return forTextName(attributeName);
/*     */     }
/*     */     
/* 404 */     throw new IllegalArgumentException("Unknown template mode '" + templateMode + "'");
/*     */   }
/*     */   
/*     */ 
/*     */   public static AttributeName forName(TemplateMode templateMode, String prefix, String attributeName)
/*     */   {
/* 410 */     if (templateMode == null) {
/* 411 */       throw new IllegalArgumentException("Template Mode cannot be null");
/*     */     }
/*     */     
/* 414 */     if (templateMode == TemplateMode.HTML) {
/* 415 */       return forHTMLName(prefix, attributeName);
/*     */     }
/*     */     
/* 418 */     if (templateMode == TemplateMode.XML) {
/* 419 */       return forXMLName(prefix, attributeName);
/*     */     }
/*     */     
/* 422 */     if (templateMode.isText()) {
/* 423 */       return forTextName(prefix, attributeName);
/*     */     }
/*     */     
/* 426 */     throw new IllegalArgumentException("Unknown template mode '" + templateMode + "'");
/*     */   }
/*     */   
/*     */ 
/*     */   public static TextAttributeName forTextName(char[] attributeNameBuffer, int attributeNameOffset, int attributeNameLen)
/*     */   {
/* 432 */     if ((attributeNameBuffer == null) || (attributeNameLen == 0)) {
/* 433 */       throw new IllegalArgumentException("Name cannot be null or empty");
/*     */     }
/* 435 */     if ((attributeNameOffset < 0) || (attributeNameLen < 0)) {
/* 436 */       throw new IllegalArgumentException("Both name offset and length must be equal to or greater than zero");
/*     */     }
/* 438 */     return (TextAttributeName)textAttributeNamesRepository.getAttribute(attributeNameBuffer, attributeNameOffset, attributeNameLen);
/*     */   }
/*     */   
/*     */   public static XMLAttributeName forXMLName(char[] attributeNameBuffer, int attributeNameOffset, int attributeNameLen) {
/* 442 */     if ((attributeNameBuffer == null) || (attributeNameLen == 0)) {
/* 443 */       throw new IllegalArgumentException("Name cannot be null or empty");
/*     */     }
/* 445 */     if ((attributeNameOffset < 0) || (attributeNameLen < 0)) {
/* 446 */       throw new IllegalArgumentException("Both name offset and length must be equal to or greater than zero");
/*     */     }
/* 448 */     return (XMLAttributeName)xmlAttributeNamesRepository.getAttribute(attributeNameBuffer, attributeNameOffset, attributeNameLen);
/*     */   }
/*     */   
/*     */   public static HTMLAttributeName forHTMLName(char[] attributeNameBuffer, int attributeNameOffset, int attributeNameLen) {
/* 452 */     if ((attributeNameBuffer == null) || (attributeNameLen == 0)) {
/* 453 */       throw new IllegalArgumentException("Name cannot be null or empty");
/*     */     }
/* 455 */     if ((attributeNameOffset < 0) || (attributeNameLen < 0)) {
/* 456 */       throw new IllegalArgumentException("Both name offset and length must be equal to or greater than zero");
/*     */     }
/* 458 */     return (HTMLAttributeName)htmlAttributeNamesRepository.getAttribute(attributeNameBuffer, attributeNameOffset, attributeNameLen);
/*     */   }
/*     */   
/*     */   public static TextAttributeName forTextName(String attributeName)
/*     */   {
/* 463 */     if ((attributeName == null) || (attributeName.trim().length() == 0)) {
/* 464 */       throw new IllegalArgumentException("Name cannot be null or empty");
/*     */     }
/* 466 */     return (TextAttributeName)textAttributeNamesRepository.getAttribute(attributeName);
/*     */   }
/*     */   
/*     */   public static XMLAttributeName forXMLName(String attributeName) {
/* 470 */     if ((attributeName == null) || (attributeName.trim().length() == 0)) {
/* 471 */       throw new IllegalArgumentException("Name cannot be null or empty");
/*     */     }
/* 473 */     return (XMLAttributeName)xmlAttributeNamesRepository.getAttribute(attributeName);
/*     */   }
/*     */   
/*     */   public static HTMLAttributeName forHTMLName(String attributeName) {
/* 477 */     if ((attributeName == null) || (attributeName.trim().length() == 0)) {
/* 478 */       throw new IllegalArgumentException("Name cannot be null or empty");
/*     */     }
/* 480 */     return (HTMLAttributeName)htmlAttributeNamesRepository.getAttribute(attributeName);
/*     */   }
/*     */   
/*     */   public static TextAttributeName forTextName(String prefix, String attributeName)
/*     */   {
/* 485 */     if ((attributeName == null) || (attributeName.trim().length() == 0)) {
/* 486 */       throw new IllegalArgumentException("Name cannot be null or empty");
/*     */     }
/* 488 */     return (TextAttributeName)textAttributeNamesRepository.getAttribute(prefix, attributeName);
/*     */   }
/*     */   
/*     */   public static XMLAttributeName forXMLName(String prefix, String attributeName) {
/* 492 */     if ((attributeName == null) || (attributeName.trim().length() == 0)) {
/* 493 */       throw new IllegalArgumentException("Name cannot be null or empty");
/*     */     }
/* 495 */     return (XMLAttributeName)xmlAttributeNamesRepository.getAttribute(prefix, attributeName);
/*     */   }
/*     */   
/*     */   public static HTMLAttributeName forHTMLName(String prefix, String attributeName) {
/* 499 */     if ((attributeName == null) || (attributeName.trim().length() == 0)) {
/* 500 */       throw new IllegalArgumentException("Name cannot be null or empty");
/*     */     }
/* 502 */     return (HTMLAttributeName)htmlAttributeNamesRepository.getAttribute(prefix, attributeName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static final class AttributeNamesRepository
/*     */   {
/*     */     private final TemplateMode templateMode;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private final List<String> repositoryNames;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private final List<AttributeName> repository;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 530 */     private final ReadWriteLock lock = new ReentrantReadWriteLock(true);
/* 531 */     private final Lock readLock = this.lock.readLock();
/* 532 */     private final Lock writeLock = this.lock.writeLock();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     AttributeNamesRepository(TemplateMode templateMode)
/*     */     {
/* 539 */       this.templateMode = templateMode;
/*     */       
/* 541 */       this.repositoryNames = new ArrayList(500);
/* 542 */       this.repository = new ArrayList(500);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     AttributeName getAttribute(char[] text, int offset, int len)
/*     */     {
/* 551 */       this.readLock.lock();
/*     */       
/*     */       AttributeName localAttributeName;
/*     */       
/*     */       try
/*     */       {
/* 557 */         int index = binarySearch(this.templateMode.isCaseSensitive(), this.repositoryNames, text, offset, len);
/*     */         
/* 559 */         if (index >= 0) {
/* 560 */           return (AttributeName)this.repository.get(index);
/*     */         }
/*     */       }
/*     */       finally {
/* 564 */         this.readLock.unlock();
/*     */       }
/*     */       
/*     */ 
/*     */       int index;
/*     */       
/*     */ 
/* 571 */       this.writeLock.lock();
/*     */       try {
/* 573 */         return storeAttribute(text, offset, len);
/*     */       } finally {
/* 575 */         this.writeLock.unlock();
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     AttributeName getAttribute(String completeAttributeName)
/*     */     {
/* 585 */       this.readLock.lock();
/*     */       
/*     */       AttributeName localAttributeName;
/*     */       
/*     */       try
/*     */       {
/* 591 */         int index = binarySearch(this.templateMode.isCaseSensitive(), this.repositoryNames, completeAttributeName);
/*     */         
/* 593 */         if (index >= 0) {
/* 594 */           return (AttributeName)this.repository.get(index);
/*     */         }
/*     */       }
/*     */       finally {
/* 598 */         this.readLock.unlock();
/*     */       }
/*     */       
/*     */ 
/*     */       int index;
/*     */       
/*     */ 
/* 605 */       this.writeLock.lock();
/*     */       try {
/* 607 */         return storeAttribute(completeAttributeName);
/*     */       } finally {
/* 609 */         this.writeLock.unlock();
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     AttributeName getAttribute(String prefix, String attributeName)
/*     */     {
/* 619 */       this.readLock.lock();
/*     */       
/*     */       AttributeName localAttributeName;
/*     */       
/*     */       try
/*     */       {
/* 625 */         int index = binarySearch(this.templateMode.isCaseSensitive(), this.repositoryNames, prefix, attributeName);
/*     */         
/* 627 */         if (index >= 0) {
/* 628 */           return (AttributeName)this.repository.get(index);
/*     */         }
/*     */       }
/*     */       finally {
/* 632 */         this.readLock.unlock();
/*     */       }
/*     */       
/*     */ 
/*     */       int index;
/*     */       
/*     */ 
/* 639 */       this.writeLock.lock();
/*     */       try {
/* 641 */         return storeAttribute(prefix, attributeName);
/*     */       } finally {
/* 643 */         this.writeLock.unlock();
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     private AttributeName storeAttribute(char[] text, int offset, int len)
/*     */     {
/* 651 */       int index = binarySearch(this.templateMode.isCaseSensitive(), this.repositoryNames, text, offset, len);
/* 652 */       if (index >= 0)
/*     */       {
/* 654 */         return (AttributeName)this.repository.get(index);
/*     */       }
/*     */       AttributeName name;
/*     */       AttributeName name;
/* 658 */       if (this.templateMode == TemplateMode.HTML) {
/* 659 */         name = AttributeNames.buildHTMLAttributeName(text, offset, len); } else { AttributeName name;
/* 660 */         if (this.templateMode == TemplateMode.XML) {
/* 661 */           name = AttributeNames.buildXMLAttributeName(text, offset, len);
/*     */         } else {
/* 663 */           name = AttributeNames.buildTextAttributeName(text, offset, len);
/*     */         }
/*     */       }
/* 666 */       String[] completeAttributeNames = name.completeAttributeNames;
/*     */       
/* 668 */       for (String completeAttributeName : completeAttributeNames)
/*     */       {
/* 670 */         index = binarySearch(this.templateMode.isCaseSensitive(), this.repositoryNames, completeAttributeName);
/*     */         
/*     */ 
/* 673 */         this.repositoryNames.add((index + 1) * -1, completeAttributeName);
/* 674 */         this.repository.add((index + 1) * -1, name);
/*     */       }
/*     */       
/*     */ 
/* 678 */       return name;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     private AttributeName storeAttribute(String attributeName)
/*     */     {
/* 685 */       int index = binarySearch(this.templateMode.isCaseSensitive(), this.repositoryNames, attributeName);
/* 686 */       if (index >= 0)
/*     */       {
/* 688 */         return (AttributeName)this.repository.get(index);
/*     */       }
/*     */       AttributeName name;
/*     */       AttributeName name;
/* 692 */       if (this.templateMode == TemplateMode.HTML) {
/* 693 */         name = AttributeNames.buildHTMLAttributeName(attributeName); } else { AttributeName name;
/* 694 */         if (this.templateMode == TemplateMode.XML) {
/* 695 */           name = AttributeNames.buildXMLAttributeName(attributeName);
/*     */         } else {
/* 697 */           name = AttributeNames.buildTextAttributeName(attributeName);
/*     */         }
/*     */       }
/* 700 */       String[] completeAttributeNames = name.completeAttributeNames;
/*     */       
/* 702 */       for (String completeAttributeName : completeAttributeNames)
/*     */       {
/* 704 */         index = binarySearch(this.templateMode.isCaseSensitive(), this.repositoryNames, completeAttributeName);
/*     */         
/*     */ 
/* 707 */         this.repositoryNames.add((index + 1) * -1, completeAttributeName);
/* 708 */         this.repository.add((index + 1) * -1, name);
/*     */       }
/*     */       
/*     */ 
/* 712 */       return name;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     private AttributeName storeAttribute(String prefix, String attributeName)
/*     */     {
/* 719 */       int index = binarySearch(this.templateMode.isCaseSensitive(), this.repositoryNames, prefix, attributeName);
/* 720 */       if (index >= 0)
/*     */       {
/* 722 */         return (AttributeName)this.repository.get(index);
/*     */       }
/*     */       AttributeName name;
/*     */       AttributeName name;
/* 726 */       if (this.templateMode == TemplateMode.HTML) {
/* 727 */         name = AttributeNames.buildHTMLAttributeName(prefix, attributeName); } else { AttributeName name;
/* 728 */         if (this.templateMode == TemplateMode.XML) {
/* 729 */           name = AttributeNames.buildXMLAttributeName(prefix, attributeName);
/*     */         } else {
/* 731 */           name = AttributeNames.buildTextAttributeName(prefix, attributeName);
/*     */         }
/*     */       }
/* 734 */       String[] completeAttributeNames = name.completeAttributeNames;
/*     */       
/* 736 */       for (String completeAttributeName : completeAttributeNames)
/*     */       {
/* 738 */         index = binarySearch(this.templateMode.isCaseSensitive(), this.repositoryNames, completeAttributeName);
/*     */         
/*     */ 
/* 741 */         this.repositoryNames.add((index + 1) * -1, completeAttributeName);
/* 742 */         this.repository.add((index + 1) * -1, name);
/*     */       }
/*     */       
/*     */ 
/* 746 */       return name;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private static int binarySearch(boolean caseSensitive, List<String> values, char[] text, int offset, int len)
/*     */     {
/* 754 */       int low = 0;
/* 755 */       int high = values.size() - 1;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 760 */       while (low <= high)
/*     */       {
/* 762 */         int mid = low + high >>> 1;
/* 763 */         String midVal = (String)values.get(mid);
/*     */         
/* 765 */         int cmp = TextUtils.compareTo(caseSensitive, midVal, 0, midVal.length(), text, offset, len);
/*     */         
/* 767 */         if (cmp < 0) {
/* 768 */           low = mid + 1;
/* 769 */         } else if (cmp > 0) {
/* 770 */           high = mid - 1;
/*     */         }
/*     */         else {
/* 773 */           return mid;
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 778 */       return -(low + 1);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     private static int binarySearch(boolean caseSensitive, List<String> values, String text)
/*     */     {
/* 785 */       int low = 0;
/* 786 */       int high = values.size() - 1;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 791 */       while (low <= high)
/*     */       {
/* 793 */         int mid = low + high >>> 1;
/* 794 */         String midVal = (String)values.get(mid);
/*     */         
/* 796 */         int cmp = TextUtils.compareTo(caseSensitive, midVal, text);
/*     */         
/* 798 */         if (cmp < 0) {
/* 799 */           low = mid + 1;
/* 800 */         } else if (cmp > 0) {
/* 801 */           high = mid - 1;
/*     */         }
/*     */         else {
/* 804 */           return mid;
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 809 */       return -(low + 1);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private static int binarySearch(boolean caseSensitive, List<String> values, String prefix, String attributeName)
/*     */     {
/* 819 */       if ((prefix == null) || (prefix.trim().length() == 0)) {
/* 820 */         return binarySearch(caseSensitive, values, attributeName);
/*     */       }
/*     */       
/* 823 */       int prefixLen = prefix.length();
/* 824 */       int attributeNameLen = attributeName.length();
/*     */       
/* 826 */       int low = 0;
/* 827 */       int high = values.size() - 1;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 833 */       while (low <= high)
/*     */       {
/* 835 */         int mid = low + high >>> 1;
/* 836 */         String midVal = (String)values.get(mid);
/* 837 */         int midValLen = midVal.length();
/*     */         
/* 839 */         if (TextUtils.startsWith(caseSensitive, midVal, prefix))
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/* 844 */           if (midValLen <= prefixLen)
/*     */           {
/*     */ 
/* 847 */             low = mid + 1;
/*     */ 
/*     */           }
/*     */           else
/*     */           {
/* 852 */             int cmp = midVal.charAt(prefixLen) - ':';
/*     */             
/* 854 */             if (cmp < 0) {
/* 855 */               low = mid + 1;
/* 856 */             } else if (cmp > 0) {
/* 857 */               high = mid - 1;
/*     */             }
/*     */             else
/*     */             {
/* 861 */               cmp = TextUtils.compareTo(caseSensitive, midVal, prefixLen + 1, midValLen - (prefixLen + 1), attributeName, 0, attributeNameLen);
/*     */               
/* 863 */               if (cmp < 0) {
/* 864 */                 low = mid + 1;
/* 865 */               } else if (cmp > 0) {
/* 866 */                 high = mid - 1;
/*     */               }
/*     */               else {
/* 869 */                 return mid;
/*     */               }
/*     */               
/*     */             }
/*     */             
/*     */           }
/*     */           
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/* 880 */           int cmp = TextUtils.compareTo(caseSensitive, midVal, prefix);
/*     */           
/* 882 */           if (cmp < 0) {
/* 883 */             low = mid + 1;
/* 884 */           } else if (cmp > 0) {
/* 885 */             high = mid - 1;
/*     */           }
/*     */           else {
/* 888 */             throw new IllegalStateException("Bad comparison of midVal \"" + midVal + "\" and prefix \"" + prefix + "\"");
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 895 */       return -(low + 1);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\AttributeNames.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */