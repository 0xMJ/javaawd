package org.thymeleaf.engine;

import org.thymeleaf.context.ITemplateContext;
import org.thymeleaf.model.ICDATASection;
import org.thymeleaf.model.ICloseElementTag;
import org.thymeleaf.model.IComment;
import org.thymeleaf.model.IDocType;
import org.thymeleaf.model.IOpenElementTag;
import org.thymeleaf.model.IProcessingInstruction;
import org.thymeleaf.model.IStandaloneElementTag;
import org.thymeleaf.model.ITemplateEnd;
import org.thymeleaf.model.ITemplateStart;
import org.thymeleaf.model.IText;
import org.thymeleaf.model.IXMLDeclaration;

public abstract interface ITemplateHandler
{
  public abstract void setNext(ITemplateHandler paramITemplateHandler);
  
  public abstract void setContext(ITemplateContext paramITemplateContext);
  
  public abstract void handleTemplateStart(ITemplateStart paramITemplateStart);
  
  public abstract void handleTemplateEnd(ITemplateEnd paramITemplateEnd);
  
  public abstract void handleXMLDeclaration(IXMLDeclaration paramIXMLDeclaration);
  
  public abstract void handleDocType(IDocType paramIDocType);
  
  public abstract void handleCDATASection(ICDATASection paramICDATASection);
  
  public abstract void handleComment(IComment paramIComment);
  
  public abstract void handleText(IText paramIText);
  
  public abstract void handleStandaloneElement(IStandaloneElementTag paramIStandaloneElementTag);
  
  public abstract void handleOpenElement(IOpenElementTag paramIOpenElementTag);
  
  public abstract void handleCloseElement(ICloseElementTag paramICloseElementTag);
  
  public abstract void handleProcessingInstruction(IProcessingInstruction paramIProcessingInstruction);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\ITemplateHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */