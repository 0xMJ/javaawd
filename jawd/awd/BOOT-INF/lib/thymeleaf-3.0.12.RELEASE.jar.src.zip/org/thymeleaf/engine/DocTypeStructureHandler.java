/*     */ package org.thymeleaf.engine;
/*     */ 
/*     */ import org.thymeleaf.model.IModel;
/*     */ import org.thymeleaf.processor.doctype.IDocTypeStructureHandler;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DocTypeStructureHandler
/*     */   implements IDocTypeStructureHandler
/*     */ {
/*     */   boolean setDocType;
/*     */   String setDocTypeKeyword;
/*     */   String setDocTypeElementName;
/*     */   String setDocTypePublicId;
/*     */   String setDocTypeSystemId;
/*     */   String setDocTypeInternalSubset;
/*     */   boolean replaceWithModel;
/*     */   IModel replaceWithModelValue;
/*     */   boolean replaceWithModelProcessable;
/*     */   boolean removeDocType;
/*     */   
/*     */   DocTypeStructureHandler()
/*     */   {
/*  58 */     reset();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDocType(String keyword, String elementName, String publicId, String systemId, String internalSubset)
/*     */   {
/*  67 */     reset();
/*  68 */     Validate.notNull(keyword, "Keyword cannot be null");
/*  69 */     Validate.notNull(elementName, "Element name cannot be null");
/*  70 */     this.setDocType = true;
/*  71 */     this.setDocTypeKeyword = keyword;
/*  72 */     this.setDocTypeElementName = elementName;
/*  73 */     this.setDocTypePublicId = publicId;
/*  74 */     this.setDocTypeSystemId = systemId;
/*  75 */     this.setDocTypeInternalSubset = internalSubset;
/*     */   }
/*     */   
/*     */   public void replaceWith(IModel model, boolean processable)
/*     */   {
/*  80 */     reset();
/*  81 */     Validate.notNull(model, "Model cannot be null");
/*  82 */     this.replaceWithModel = true;
/*  83 */     this.replaceWithModelValue = model;
/*  84 */     this.replaceWithModelProcessable = processable;
/*     */   }
/*     */   
/*     */   public void removeDocType()
/*     */   {
/*  89 */     reset();
/*  90 */     this.removeDocType = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void reset()
/*     */   {
/*  98 */     this.setDocType = false;
/*  99 */     this.setDocTypeKeyword = null;
/* 100 */     this.setDocTypeElementName = null;
/* 101 */     this.setDocTypePublicId = null;
/* 102 */     this.setDocTypeSystemId = null;
/* 103 */     this.setDocTypeInternalSubset = null;
/*     */     
/* 105 */     this.replaceWithModel = false;
/* 106 */     this.replaceWithModelValue = null;
/* 107 */     this.replaceWithModelProcessable = false;
/*     */     
/* 109 */     this.removeDocType = false;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\DocTypeStructureHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */