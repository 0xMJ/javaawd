/*     */ package org.thymeleaf.engine;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import org.thymeleaf.model.ICloseElementTag;
/*     */ import org.thymeleaf.model.IModelVisitor;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class CloseElementTag
/*     */   extends AbstractElementTag
/*     */   implements ICloseElementTag, IEngineTemplateEvent
/*     */ {
/*     */   final String trailingWhiteSpace;
/*     */   final boolean unmatched;
/*     */   
/*     */   CloseElementTag(TemplateMode templateMode, ElementDefinition elementDefinition, String elementCompleteName, String trailingWhiteSpace, boolean synthetic, boolean unmatched)
/*     */   {
/*  53 */     super(templateMode, elementDefinition, elementCompleteName, synthetic);
/*  54 */     this.trailingWhiteSpace = trailingWhiteSpace;
/*  55 */     this.unmatched = unmatched;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   CloseElementTag(TemplateMode templateMode, ElementDefinition elementDefinition, String elementCompleteName, String trailingWhiteSpace, boolean synthetic, boolean unmatched, String templateName, int line, int col)
/*     */   {
/*  69 */     super(templateMode, elementDefinition, elementCompleteName, synthetic, templateName, line, col);
/*  70 */     this.trailingWhiteSpace = trailingWhiteSpace;
/*  71 */     this.unmatched = unmatched;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isUnmatched()
/*     */   {
/*  78 */     return this.unmatched;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void accept(IModelVisitor visitor)
/*     */   {
/*  90 */     visitor.visit(this);
/*     */   }
/*     */   
/*     */   public void write(Writer writer) throws IOException
/*     */   {
/*  95 */     if (this.synthetic)
/*     */     {
/*  97 */       return;
/*     */     }
/*     */     
/* 100 */     if (this.templateMode.isText()) {
/* 101 */       writer.write("[/");
/* 102 */       writer.write(this.elementCompleteName);
/* 103 */       if (this.trailingWhiteSpace != null) {
/* 104 */         writer.write(this.trailingWhiteSpace);
/*     */       }
/* 106 */       writer.write("]");
/* 107 */       return;
/*     */     }
/* 109 */     writer.write("</");
/* 110 */     writer.write(this.elementCompleteName);
/* 111 */     if (this.trailingWhiteSpace != null) {
/* 112 */       writer.write(this.trailingWhiteSpace);
/*     */     }
/* 114 */     writer.write(62);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static CloseElementTag asEngineCloseElementTag(ICloseElementTag closeElementTag)
/*     */   {
/* 123 */     if ((closeElementTag instanceof CloseElementTag)) {
/* 124 */       return (CloseElementTag)closeElementTag;
/*     */     }
/*     */     
/* 127 */     return new CloseElementTag(closeElementTag
/* 128 */       .getTemplateMode(), closeElementTag.getElementDefinition(), closeElementTag.getElementCompleteName(), null, closeElementTag
/* 129 */       .isSynthetic(), closeElementTag.isUnmatched(), closeElementTag
/* 130 */       .getTemplateName(), closeElementTag.getLine(), closeElementTag.getCol());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void beHandled(ITemplateHandler handler)
/*     */   {
/* 139 */     handler.handleCloseElement(this);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\CloseElementTag.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */