/*     */ package org.thymeleaf.engine;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.model.AttributeValueQuotes;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ import org.thymeleaf.util.FastStringWriter;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class Attributes
/*     */ {
/*     */   static final String DEFAULT_WHITE_SPACE = " ";
/*  43 */   static final String[] DEFAULT_WHITE_SPACE_ARRAY = { " " };
/*     */   
/*  45 */   static final Attributes EMPTY_ATTRIBUTES = new Attributes(null, null);
/*  46 */   static final Attribute[] EMPTY_ATTRIBUTE_ARRAY = new Attribute[0];
/*     */   
/*     */   final Attribute[] attributes;
/*     */   
/*     */   final String[] innerWhiteSpaces;
/*     */   
/*  52 */   private volatile int associatedProcessorCount = -1;
/*     */   
/*     */ 
/*     */ 
/*     */   Attributes(Attribute[] attributes, String[] innerWhiteSpaces)
/*     */   {
/*  58 */     this.attributes = attributes;
/*  59 */     this.innerWhiteSpaces = innerWhiteSpaces;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   int getAssociatedProcessorCount()
/*     */   {
/*  66 */     int c = this.associatedProcessorCount;
/*  67 */     if (c < 0) {
/*  68 */       this.associatedProcessorCount = (c = computeAssociatedProcessorCount());
/*     */     }
/*  70 */     return c;
/*     */   }
/*     */   
/*     */ 
/*     */   private int computeAssociatedProcessorCount()
/*     */   {
/*  76 */     if ((this.attributes == null) || (this.attributes.length == 0)) {
/*  77 */       return 0;
/*     */     }
/*  79 */     int count = 0;
/*  80 */     int n = this.attributes.length;
/*  81 */     while (n-- != 0) {
/*  82 */       if (this.attributes[n].definition.hasAssociatedProcessors) {
/*  83 */         count += this.attributes[n].definition.associatedProcessors.length;
/*     */       }
/*     */     }
/*  86 */     return count;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private int searchAttribute(TemplateMode templateMode, String completeName)
/*     */   {
/*  93 */     if ((this.attributes == null) || (this.attributes.length == 0)) {
/*  94 */       return -1;
/*     */     }
/*     */     
/*     */ 
/*  98 */     int n = this.attributes.length;
/*  99 */     while (n-- != 0) {
/* 100 */       if (this.attributes[n].completeName.equals(completeName)) {
/* 101 */         return n;
/*     */       }
/*     */     }
/*     */     
/* 105 */     return searchAttribute(AttributeNames.forName(templateMode, completeName));
/*     */   }
/*     */   
/*     */   private int searchAttribute(TemplateMode templateMode, String prefix, String name)
/*     */   {
/* 110 */     if ((this.attributes == null) || (this.attributes.length == 0)) {
/* 111 */       return -1;
/*     */     }
/* 113 */     if ((prefix == null) || (prefix.length() == 0))
/*     */     {
/* 115 */       return searchAttribute(templateMode, name);
/*     */     }
/* 117 */     return searchAttribute(AttributeNames.forName(templateMode, prefix, name));
/*     */   }
/*     */   
/*     */   private int searchAttribute(AttributeName attributeName)
/*     */   {
/* 122 */     if ((this.attributes == null) || (this.attributes.length == 0)) {
/* 123 */       return -1;
/*     */     }
/* 125 */     int n = this.attributes.length;
/* 126 */     while (n-- != 0)
/*     */     {
/* 128 */       if (this.attributes[n].definition.attributeName == attributeName) {
/* 129 */         return n;
/*     */       }
/*     */     }
/* 132 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   boolean hasAttribute(TemplateMode templateMode, String completeName)
/*     */   {
/* 139 */     return searchAttribute(templateMode, completeName) >= 0;
/*     */   }
/*     */   
/*     */   boolean hasAttribute(TemplateMode templateMode, String prefix, String name)
/*     */   {
/* 144 */     return searchAttribute(templateMode, prefix, name) >= 0;
/*     */   }
/*     */   
/*     */   boolean hasAttribute(AttributeName attributeName)
/*     */   {
/* 149 */     return searchAttribute(attributeName) >= 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   Attribute getAttribute(TemplateMode templateMode, String completeName)
/*     */   {
/* 156 */     int pos = searchAttribute(templateMode, completeName);
/* 157 */     if (pos < 0) {
/* 158 */       return null;
/*     */     }
/* 160 */     return this.attributes[pos];
/*     */   }
/*     */   
/*     */   Attribute getAttribute(TemplateMode templateMode, String prefix, String name)
/*     */   {
/* 165 */     int pos = searchAttribute(templateMode, prefix, name);
/* 166 */     if (pos < 0) {
/* 167 */       return null;
/*     */     }
/* 169 */     return this.attributes[pos];
/*     */   }
/*     */   
/*     */   Attribute getAttribute(AttributeName attributeName)
/*     */   {
/* 174 */     int pos = searchAttribute(attributeName);
/* 175 */     if (pos < 0) {
/* 176 */       return null;
/*     */     }
/* 178 */     return this.attributes[pos];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   Attribute[] getAllAttributes()
/*     */   {
/* 185 */     if ((this.attributes == null) || (this.attributes.length == 0)) {
/* 186 */       return EMPTY_ATTRIBUTE_ARRAY;
/*     */     }
/*     */     
/* 189 */     return (Attribute[])this.attributes.clone();
/*     */   }
/*     */   
/*     */   Map<String, String> getAttributeMap()
/*     */   {
/* 194 */     if ((this.attributes == null) || (this.attributes.length == 0)) {
/* 195 */       return Collections.emptyMap();
/*     */     }
/* 197 */     Map<String, String> attributeMap = new LinkedHashMap(this.attributes.length + 5);
/* 198 */     for (int i = 0; i < this.attributes.length; i++) {
/* 199 */       attributeMap.put(this.attributes[i].completeName, this.attributes[i].value);
/*     */     }
/* 201 */     return attributeMap;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Attributes setAttribute(AttributeDefinitions attributeDefinitions, TemplateMode templateMode, AttributeDefinition attributeDefinition, String completeName, String value, AttributeValueQuotes valueQuotes)
/*     */   {
/* 215 */     Validate.isTrue((value != null) || (templateMode != TemplateMode.XML), "Cannot set null-value attributes in XML template mode");
/* 216 */     Validate.isTrue((valueQuotes != AttributeValueQuotes.NONE) || (templateMode != TemplateMode.XML), "Cannot set unquoted attributes in XML template mode");
/*     */     
/*     */ 
/* 219 */     int existingIdx = attributeDefinition != null ? searchAttribute(attributeDefinition.attributeName) : searchAttribute(templateMode, completeName);
/*     */     
/* 221 */     if (existingIdx >= 0)
/*     */     {
/*     */ 
/* 224 */       Attribute[] newAttributes = (Attribute[])this.attributes.clone();
/* 225 */       newAttributes[existingIdx] = newAttributes[existingIdx]
/* 226 */         .modify(null, completeName, value, valueQuotes);
/*     */       
/* 228 */       return new Attributes(newAttributes, this.innerWhiteSpaces);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 233 */     AttributeDefinition newAttributeDefinition = attributeDefinition != null ? attributeDefinition : attributeDefinitions.forName(templateMode, completeName);
/*     */     
/* 235 */     Attribute newAttribute = new Attribute(newAttributeDefinition, completeName, null, value, valueQuotes, null, -1, -1);
/*     */     
/*     */ 
/*     */     Attribute[] newAttributes;
/*     */     
/* 240 */     if (this.attributes != null) {
/* 241 */       Attribute[] newAttributes = new Attribute[this.attributes.length + 1];
/* 242 */       System.arraycopy(this.attributes, 0, newAttributes, 0, this.attributes.length);
/* 243 */       newAttributes[this.attributes.length] = newAttribute;
/*     */     } else {
/* 245 */       newAttributes = new Attribute[] { newAttribute };
/*     */     }
/*     */     
/*     */     String[] newInnerWhiteSpaces;
/* 249 */     if (this.innerWhiteSpaces != null) {
/* 250 */       String[] newInnerWhiteSpaces = new String[this.innerWhiteSpaces.length + 1];
/* 251 */       System.arraycopy(this.innerWhiteSpaces, 0, newInnerWhiteSpaces, 0, this.innerWhiteSpaces.length);
/* 252 */       if (this.innerWhiteSpaces.length == (this.attributes != null ? this.attributes.length : 0))
/*     */       {
/* 254 */         newInnerWhiteSpaces[this.innerWhiteSpaces.length] = " ";
/*     */       }
/*     */       else {
/* 257 */         newInnerWhiteSpaces[this.innerWhiteSpaces.length] = newInnerWhiteSpaces[(this.innerWhiteSpaces.length - 1)];
/* 258 */         newInnerWhiteSpaces[(this.innerWhiteSpaces.length - 1)] = " ";
/*     */       }
/*     */     } else {
/* 261 */       newInnerWhiteSpaces = DEFAULT_WHITE_SPACE_ARRAY;
/*     */     }
/*     */     
/*     */ 
/* 265 */     return new Attributes(newAttributes, newInnerWhiteSpaces);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Attributes replaceAttribute(AttributeDefinitions attributeDefinitions, TemplateMode templateMode, AttributeName oldName, AttributeDefinition newAttributeDefinition, String newCompleteName, String value, AttributeValueQuotes valueQuotes)
/*     */   {
/* 281 */     Validate.isTrue((value != null) || (templateMode != TemplateMode.XML), "Cannot set null-value attributes in XML template mode");
/* 282 */     Validate.isTrue((valueQuotes != AttributeValueQuotes.NONE) || (templateMode != TemplateMode.XML), "Cannot set unquoted attributes in XML template mode");
/*     */     
/*     */ 
/* 285 */     if (this.attributes == null) {
/* 286 */       return setAttribute(attributeDefinitions, templateMode, newAttributeDefinition, newCompleteName, value, valueQuotes);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 291 */     int oldIdx = searchAttribute(oldName);
/* 292 */     if (oldIdx < 0) {
/* 293 */       return setAttribute(attributeDefinitions, templateMode, newAttributeDefinition, newCompleteName, value, valueQuotes);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 299 */     int existingIdx = newAttributeDefinition != null ? searchAttribute(newAttributeDefinition.attributeName) : searchAttribute(templateMode, newCompleteName);
/* 300 */     if (existingIdx >= 0)
/*     */     {
/* 302 */       if (oldIdx == existingIdx)
/*     */       {
/* 304 */         return setAttribute(attributeDefinitions, templateMode, newAttributeDefinition, newCompleteName, value, valueQuotes);
/*     */       }
/*     */       
/* 307 */       Attribute[] newAttributes = new Attribute[this.attributes.length - 1];
/*     */       
/*     */ 
/* 310 */       System.arraycopy(this.attributes, 0, newAttributes, 0, oldIdx);
/* 311 */       System.arraycopy(this.attributes, oldIdx + 1, newAttributes, oldIdx, newAttributes.length - oldIdx);
/*     */       
/*     */ 
/* 314 */       int iwIdx = oldIdx + 1;
/* 315 */       if (oldIdx + 1 == this.attributes.length)
/*     */       {
/*     */ 
/* 318 */         iwIdx = oldIdx;
/*     */       }
/*     */       
/* 321 */       String[] newInnerWhiteSpaces = new String[this.innerWhiteSpaces.length - 1];
/* 322 */       System.arraycopy(this.innerWhiteSpaces, 0, newInnerWhiteSpaces, 0, iwIdx);
/* 323 */       System.arraycopy(this.innerWhiteSpaces, iwIdx + 1, newInnerWhiteSpaces, iwIdx, newInnerWhiteSpaces.length - iwIdx);
/*     */       
/*     */ 
/*     */ 
/* 327 */       if (existingIdx > oldIdx) {
/* 328 */         existingIdx--;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 333 */       newAttributes[existingIdx] = newAttributes[existingIdx].modify(null, newCompleteName, value, valueQuotes);
/*     */       
/* 335 */       return new Attributes(newAttributes, newInnerWhiteSpaces);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 343 */     AttributeDefinition computedNewAttributeDefinition = newAttributeDefinition != null ? newAttributeDefinition : attributeDefinitions.forName(templateMode, newCompleteName);
/*     */     
/*     */ 
/*     */ 
/* 347 */     Attribute[] newAttributes = (Attribute[])this.attributes.clone();
/* 348 */     newAttributes[oldIdx] = newAttributes[oldIdx]
/* 349 */       .modify(computedNewAttributeDefinition, newCompleteName, value, valueQuotes);
/*     */     
/*     */ 
/* 352 */     return new Attributes(newAttributes, this.innerWhiteSpaces);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Attributes removeAttribute(TemplateMode templateMode, String prefix, String name)
/*     */   {
/* 361 */     if (this.attributes == null)
/*     */     {
/* 363 */       return this;
/*     */     }
/*     */     
/* 366 */     int attrIdx = searchAttribute(templateMode, prefix, name);
/* 367 */     if (attrIdx < 0)
/*     */     {
/* 369 */       return this;
/*     */     }
/*     */     
/* 372 */     return removeAttribute(attrIdx);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   Attributes removeAttribute(TemplateMode templateMode, String completeName)
/*     */   {
/* 379 */     if (this.attributes == null)
/*     */     {
/* 381 */       return this;
/*     */     }
/*     */     
/* 384 */     int attrIdx = searchAttribute(templateMode, completeName);
/* 385 */     if (attrIdx < 0)
/*     */     {
/* 387 */       return this;
/*     */     }
/*     */     
/* 390 */     return removeAttribute(attrIdx);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   Attributes removeAttribute(AttributeName attributeName)
/*     */   {
/* 397 */     if (this.attributes == null)
/*     */     {
/* 399 */       return this;
/*     */     }
/*     */     
/* 402 */     int attrIdx = searchAttribute(attributeName);
/* 403 */     if (attrIdx < 0)
/*     */     {
/* 405 */       return this;
/*     */     }
/*     */     
/* 408 */     return removeAttribute(attrIdx);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private Attributes removeAttribute(int attrIdx)
/*     */   {
/* 415 */     if ((this.attributes.length == 1) && (this.innerWhiteSpaces.length == 1))
/*     */     {
/* 417 */       return EMPTY_ATTRIBUTES;
/*     */     }
/*     */     
/*     */     Attribute[] newAttributes;
/*     */     Attribute[] newAttributes;
/* 422 */     if (this.attributes.length == 1) {
/* 423 */       newAttributes = null;
/*     */     } else {
/* 425 */       newAttributes = new Attribute[this.attributes.length - 1];
/* 426 */       System.arraycopy(this.attributes, 0, newAttributes, 0, attrIdx);
/* 427 */       System.arraycopy(this.attributes, attrIdx + 1, newAttributes, attrIdx, newAttributes.length - attrIdx);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 432 */     int iwIdx = attrIdx + 1;
/* 433 */     if (attrIdx + 1 == this.attributes.length)
/*     */     {
/*     */ 
/* 436 */       iwIdx = attrIdx;
/*     */     }
/*     */     
/* 439 */     String[] newInnerWhiteSpaces = new String[this.innerWhiteSpaces.length - 1];
/* 440 */     System.arraycopy(this.innerWhiteSpaces, 0, newInnerWhiteSpaces, 0, iwIdx);
/* 441 */     System.arraycopy(this.innerWhiteSpaces, iwIdx + 1, newInnerWhiteSpaces, iwIdx, newInnerWhiteSpaces.length - iwIdx);
/*     */     
/*     */ 
/* 444 */     return new Attributes(newAttributes, newInnerWhiteSpaces);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   void write(Writer writer)
/*     */     throws IOException
/*     */   {
/* 453 */     if (this.attributes == null) {
/* 454 */       if (this.innerWhiteSpaces != null)
/*     */       {
/* 456 */         writer.write(this.innerWhiteSpaces[0]);
/*     */       }
/* 458 */       return;
/*     */     }
/*     */     
/* 461 */     for (int i = 0; 
/* 462 */         i < this.attributes.length; i++) {
/* 463 */       writer.write(this.innerWhiteSpaces[i]);
/* 464 */       this.attributes[i].write(writer);
/*     */     }
/*     */     
/*     */ 
/* 468 */     if (i < this.innerWhiteSpaces.length) {
/* 469 */       writer.write(this.innerWhiteSpaces[i]);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 479 */     Writer stringWriter = new FastStringWriter();
/*     */     try {
/* 481 */       write(stringWriter);
/*     */     } catch (IOException e) {
/* 483 */       throw new TemplateProcessingException("Exception processing String form of ElementAttributes", e);
/*     */     }
/* 485 */     return stringWriter.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\Attributes.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */