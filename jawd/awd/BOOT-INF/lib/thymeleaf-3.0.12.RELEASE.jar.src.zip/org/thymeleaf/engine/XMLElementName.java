/*    */ package org.thymeleaf.engine;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class XMLElementName
/*    */   extends ElementName
/*    */ {
/*    */   final String completeNamespacedElementName;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   static XMLElementName forName(String prefix, String elementName)
/*    */   {
/* 36 */     boolean hasPrefix = (prefix != null) && (prefix.length() > 0);
/*    */     
/*    */     String[] completeElementNames;
/*    */     String completeNamespacedElementName;
/*    */     String[] completeElementNames;
/* 41 */     if (hasPrefix)
/*    */     {
/* 43 */       String completeNamespacedElementName = prefix + ":" + elementName;
/* 44 */       completeElementNames = new String[] { completeNamespacedElementName };
/*    */     }
/*    */     else
/*    */     {
/* 48 */       completeNamespacedElementName = elementName;
/* 49 */       completeElementNames = new String[] { elementName };
/*    */     }
/*    */     
/*    */ 
/* 53 */     return new XMLElementName(prefix, elementName, completeNamespacedElementName, completeElementNames);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private XMLElementName(String prefix, String elementName, String completeNamespacedElementName, String[] completeElementNames)
/*    */   {
/* 65 */     super(prefix, elementName, completeElementNames);
/* 66 */     this.completeNamespacedElementName = completeNamespacedElementName;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public String getCompleteNamespacedElementName()
/*    */   {
/* 73 */     return this.completeNamespacedElementName;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\XMLElementName.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */