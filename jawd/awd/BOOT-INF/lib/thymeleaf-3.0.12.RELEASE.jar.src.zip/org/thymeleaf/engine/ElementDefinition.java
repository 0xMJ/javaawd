/*     */ package org.thymeleaf.engine;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Set;
/*     */ import org.thymeleaf.processor.element.IElementProcessor;
/*     */ import org.thymeleaf.util.ProcessorComparators;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ElementDefinition
/*     */ {
/*     */   final ElementName elementName;
/*     */   private final Set<IElementProcessor> associatedProcessorsSet;
/*     */   final IElementProcessor[] associatedProcessors;
/*     */   final boolean hasAssociatedProcessors;
/*     */   
/*     */   ElementDefinition(ElementName elementName, Set<IElementProcessor> associatedProcessors)
/*     */   {
/*  47 */     if (elementName == null) {
/*  48 */       throw new IllegalArgumentException("Element name cannot be null");
/*     */     }
/*  50 */     if (associatedProcessors == null) {
/*  51 */       throw new IllegalArgumentException("Associated processors cannot be null");
/*     */     }
/*     */     
/*  54 */     this.elementName = elementName;
/*  55 */     this.associatedProcessorsSet = Collections.unmodifiableSet(associatedProcessors);
/*  56 */     this.associatedProcessors = new IElementProcessor[this.associatedProcessorsSet.size()];
/*  57 */     int i = 0;
/*  58 */     for (IElementProcessor processor : this.associatedProcessorsSet) {
/*  59 */       this.associatedProcessors[(i++)] = processor;
/*     */     }
/*  61 */     Arrays.sort(this.associatedProcessors, ProcessorComparators.PROCESSOR_COMPARATOR);
/*  62 */     this.hasAssociatedProcessors = (this.associatedProcessors.length > 0);
/*     */   }
/*     */   
/*     */ 
/*     */   public final ElementName getElementName()
/*     */   {
/*  68 */     return this.elementName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean hasAssociatedProcessors()
/*     */   {
/*  75 */     return this.hasAssociatedProcessors;
/*     */   }
/*     */   
/*     */ 
/*     */   public Set<IElementProcessor> getAssociatedProcessors()
/*     */   {
/*  81 */     return this.associatedProcessorsSet;
/*     */   }
/*     */   
/*     */ 
/*     */   public final String toString()
/*     */   {
/*  87 */     return getElementName().toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/*  95 */     if (this == o) {
/*  96 */       return true;
/*     */     }
/*     */     
/*  99 */     if (!o.getClass().equals(getClass())) {
/* 100 */       return false;
/*     */     }
/*     */     
/* 103 */     ElementDefinition that = (ElementDefinition)o;
/*     */     
/* 105 */     if (!this.elementName.equals(that.elementName)) {
/* 106 */       return false;
/*     */     }
/*     */     
/* 109 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 115 */     return this.elementName.hashCode();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\ElementDefinition.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */