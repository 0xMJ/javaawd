/*     */ package org.thymeleaf.engine;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import org.thymeleaf.model.ICDATASection;
/*     */ import org.thymeleaf.model.IModelVisitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class CDATASection
/*     */   extends AbstractTextualTemplateEvent
/*     */   implements ICDATASection
/*     */ {
/*     */   static final String CDATA_PREFIX = "<![CDATA[";
/*     */   static final String CDATA_SUFFIX = "]]>";
/*     */   final String prefix;
/*     */   final String suffix;
/*  44 */   private volatile String computedCDATASectionStr = null;
/*     */   
/*     */ 
/*     */   CDATASection(CharSequence content)
/*     */   {
/*  49 */     this("<![CDATA[", content, "]]>");
/*     */   }
/*     */   
/*     */   CDATASection(String prefix, CharSequence content, String suffix)
/*     */   {
/*  54 */     super(content);
/*  55 */     this.prefix = prefix;
/*  56 */     this.suffix = suffix;
/*     */   }
/*     */   
/*     */   CDATASection(CharSequence content, String templateName, int line, int col)
/*     */   {
/*  61 */     this("<![CDATA[", content, "]]>", templateName, line, col);
/*     */   }
/*     */   
/*     */   CDATASection(String prefix, CharSequence content, String suffix, String templateName, int line, int col)
/*     */   {
/*  66 */     super(content, templateName, line, col);
/*  67 */     this.prefix = prefix;
/*  68 */     this.suffix = suffix;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getCDATASection()
/*     */   {
/*  77 */     String c = this.computedCDATASectionStr;
/*  78 */     if (c == null) {
/*  79 */       this.computedCDATASectionStr = (c = this.prefix + getContentText() + this.suffix);
/*     */     }
/*  81 */     return c;
/*     */   }
/*     */   
/*     */   public String getContent()
/*     */   {
/*  86 */     return getContentText();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int length()
/*     */   {
/*  93 */     return this.prefix.length() + getContentLength() + this.suffix.length();
/*     */   }
/*     */   
/*     */   public char charAt(int index)
/*     */   {
/*  98 */     if (index < this.prefix.length()) {
/*  99 */       return this.prefix.charAt(index);
/*     */     }
/* 101 */     int prefixedContentLen = this.prefix.length() + getContentLength();
/* 102 */     if (index >= prefixedContentLen) {
/* 103 */       return this.suffix.charAt(index - prefixedContentLen);
/*     */     }
/* 105 */     return charAtContent(index - this.prefix.length());
/*     */   }
/*     */   
/*     */ 
/*     */   public CharSequence subSequence(int start, int end)
/*     */   {
/* 111 */     if ((start >= this.prefix.length()) && (end < this.prefix.length() + getContentLength())) {
/* 112 */       return contentSubSequence(start - this.prefix.length(), end - this.prefix.length());
/*     */     }
/* 114 */     return getCDATASection().subSequence(start, end);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void accept(IModelVisitor visitor)
/*     */   {
/* 121 */     visitor.visit(this);
/*     */   }
/*     */   
/*     */   public void write(Writer writer) throws IOException
/*     */   {
/* 126 */     writer.write(this.prefix);
/* 127 */     writeContent(writer);
/* 128 */     writer.write(this.suffix);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static CDATASection asEngineCDATASection(ICDATASection cdataSection)
/*     */   {
/* 136 */     if ((cdataSection instanceof CDATASection)) {
/* 137 */       return (CDATASection)cdataSection;
/*     */     }
/* 139 */     return new CDATASection(cdataSection.getContent(), cdataSection.getTemplateName(), cdataSection.getLine(), cdataSection.getCol());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void beHandled(ITemplateHandler handler)
/*     */   {
/* 147 */     handler.handleCDATASection(this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 155 */     return getCDATASection();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\CDATASection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */