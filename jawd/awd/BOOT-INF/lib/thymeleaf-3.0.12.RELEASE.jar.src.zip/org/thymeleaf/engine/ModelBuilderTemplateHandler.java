/*     */ package org.thymeleaf.engine;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.thymeleaf.IEngineConfiguration;
/*     */ import org.thymeleaf.model.ICDATASection;
/*     */ import org.thymeleaf.model.ICloseElementTag;
/*     */ import org.thymeleaf.model.IComment;
/*     */ import org.thymeleaf.model.IDocType;
/*     */ import org.thymeleaf.model.IOpenElementTag;
/*     */ import org.thymeleaf.model.IProcessingInstruction;
/*     */ import org.thymeleaf.model.IStandaloneElementTag;
/*     */ import org.thymeleaf.model.ITemplateEnd;
/*     */ import org.thymeleaf.model.ITemplateStart;
/*     */ import org.thymeleaf.model.IText;
/*     */ import org.thymeleaf.model.IXMLDeclaration;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ModelBuilderTemplateHandler
/*     */   extends AbstractTemplateHandler
/*     */ {
/*     */   private final List<IEngineTemplateEvent> events;
/*     */   private final IEngineConfiguration configuration;
/*     */   private final TemplateData templateData;
/*     */   
/*     */   public ModelBuilderTemplateHandler(IEngineConfiguration configuration, TemplateData templateData)
/*     */   {
/*  56 */     Validate.notNull(configuration, "Configuration cannot be null");
/*  57 */     Validate.notNull(templateData, "Template Data cannot be null");
/*  58 */     this.configuration = configuration;
/*  59 */     this.templateData = templateData;
/*  60 */     this.events = new ArrayList(100);
/*     */   }
/*     */   
/*     */ 
/*     */   public TemplateModel getModel()
/*     */   {
/*  66 */     return new TemplateModel(this.configuration, this.templateData, (IEngineTemplateEvent[])this.events.toArray(new IEngineTemplateEvent[this.events.size()]));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleTemplateStart(ITemplateStart templateStart)
/*     */   {
/*  77 */     this.events.add(TemplateStart.asEngineTemplateStart(templateStart));
/*     */     
/*  79 */     super.handleTemplateStart(templateStart);
/*     */   }
/*     */   
/*     */ 
/*     */   public void handleTemplateEnd(ITemplateEnd templateEnd)
/*     */   {
/*  85 */     this.events.add(TemplateEnd.asEngineTemplateEnd(templateEnd));
/*     */     
/*  87 */     super.handleTemplateEnd(templateEnd);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleText(IText text)
/*     */   {
/*  96 */     this.events.add(Text.asEngineText(text));
/*     */     
/*  98 */     super.handleText(text);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void handleComment(IComment comment)
/*     */   {
/* 105 */     this.events.add(Comment.asEngineComment(comment));
/*     */     
/* 107 */     super.handleComment(comment);
/*     */   }
/*     */   
/*     */ 
/*     */   public void handleCDATASection(ICDATASection cdataSection)
/*     */   {
/* 113 */     this.events.add(CDATASection.asEngineCDATASection(cdataSection));
/*     */     
/* 115 */     super.handleCDATASection(cdataSection);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleStandaloneElement(IStandaloneElementTag standaloneElementTag)
/*     */   {
/* 123 */     this.events.add(StandaloneElementTag.asEngineStandaloneElementTag(standaloneElementTag));
/*     */     
/* 125 */     super.handleStandaloneElement(standaloneElementTag);
/*     */   }
/*     */   
/*     */ 
/*     */   public void handleOpenElement(IOpenElementTag openElementTag)
/*     */   {
/* 131 */     this.events.add(OpenElementTag.asEngineOpenElementTag(openElementTag));
/*     */     
/* 133 */     super.handleOpenElement(openElementTag);
/*     */   }
/*     */   
/*     */ 
/*     */   public void handleCloseElement(ICloseElementTag closeElementTag)
/*     */   {
/* 139 */     this.events.add(CloseElementTag.asEngineCloseElementTag(closeElementTag));
/*     */     
/* 141 */     super.handleCloseElement(closeElementTag);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleDocType(IDocType docType)
/*     */   {
/* 149 */     this.events.add(DocType.asEngineDocType(docType));
/*     */     
/* 151 */     super.handleDocType(docType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleXMLDeclaration(IXMLDeclaration xmlDeclaration)
/*     */   {
/* 159 */     this.events.add(XMLDeclaration.asEngineXMLDeclaration(xmlDeclaration));
/*     */     
/* 161 */     super.handleXMLDeclaration(xmlDeclaration);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleProcessingInstruction(IProcessingInstruction processingInstruction)
/*     */   {
/* 169 */     this.events.add(ProcessingInstruction.asEngineProcessingInstruction(processingInstruction));
/*     */     
/* 171 */     super.handleProcessingInstruction(processingInstruction);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\ModelBuilderTemplateHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */