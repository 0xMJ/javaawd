/*     */ package org.thymeleaf.engine;
/*     */ 
/*     */ import org.thymeleaf.context.IEngineContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class StandaloneElementTagModelProcessable
/*     */   implements IEngineProcessable
/*     */ {
/*     */   private final StandaloneElementTag standaloneElementTag;
/*     */   private final ProcessorExecutionVars vars;
/*     */   private final IEngineContext context;
/*     */   private final TemplateFlowController flowController;
/*     */   private final TemplateModelController modelController;
/*     */   private final ProcessorTemplateHandler processorTemplateHandler;
/*     */   private final ITemplateHandler nextTemplateHandler;
/*     */   private boolean beforeProcessed;
/*     */   private boolean delegationProcessed;
/*     */   private boolean afterProcessed;
/*     */   private int offset;
/*     */   
/*     */   StandaloneElementTagModelProcessable(StandaloneElementTag standaloneElementTag, ProcessorExecutionVars vars, IEngineContext context, TemplateModelController modelController, TemplateFlowController flowController, ProcessorTemplateHandler processorTemplateHandler, ITemplateHandler nextTemplateHandler)
/*     */   {
/*  51 */     this.standaloneElementTag = standaloneElementTag;
/*  52 */     this.vars = vars;
/*  53 */     this.context = context;
/*  54 */     this.flowController = flowController;
/*  55 */     this.modelController = modelController;
/*  56 */     this.processorTemplateHandler = processorTemplateHandler;
/*  57 */     this.nextTemplateHandler = nextTemplateHandler;
/*  58 */     this.beforeProcessed = false;
/*  59 */     this.delegationProcessed = false;
/*  60 */     this.afterProcessed = false;
/*  61 */     this.offset = 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean process()
/*     */   {
/*  70 */     if (this.flowController.stopProcessing) {
/*  71 */       return false;
/*     */     }
/*     */     
/*     */ 
/*  75 */     if (!this.beforeProcessed)
/*     */     {
/*     */ 
/*     */ 
/*  79 */       if (this.vars.modelBefore != null) {
/*  80 */         this.offset += this.vars.modelBefore.process(this.nextTemplateHandler, this.offset, this.flowController);
/*  81 */         if ((this.offset < this.vars.modelBefore.queueSize) || (this.flowController.stopProcessing)) {
/*  82 */           return false;
/*     */         }
/*     */       }
/*  85 */       this.beforeProcessed = true;
/*  86 */       this.offset = 0;
/*     */     }
/*     */     
/*     */ 
/*  90 */     if (!this.delegationProcessed)
/*     */     {
/*     */ 
/*     */ 
/*  94 */       if (!this.vars.discardEvent) {
/*  95 */         this.nextTemplateHandler.handleStandaloneElement(this.standaloneElementTag);
/*     */       }
/*  97 */       this.delegationProcessed = true;
/*  98 */       this.offset = 0;
/*     */     }
/*     */     
/* 101 */     if (this.flowController.stopProcessing) {
/* 102 */       return false;
/*     */     }
/*     */     
/* 105 */     if (!this.afterProcessed)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 112 */       if (this.vars.modelAfter != null) {
/* 113 */         ITemplateHandler modelHandler = this.vars.modelAfterProcessable ? this.processorTemplateHandler : this.nextTemplateHandler;
/* 114 */         this.offset += this.vars.modelAfter.process(modelHandler, this.offset, this.flowController);
/* 115 */         if ((this.offset < this.vars.modelAfter.queueSize) || (this.flowController.stopProcessing)) {
/* 116 */           return false;
/*     */         }
/*     */       }
/* 119 */       this.afterProcessed = true;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 127 */     if (this.context != null) {
/* 128 */       this.context.decreaseLevel();
/*     */     }
/*     */     
/* 131 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\StandaloneElementTagModelProcessable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */