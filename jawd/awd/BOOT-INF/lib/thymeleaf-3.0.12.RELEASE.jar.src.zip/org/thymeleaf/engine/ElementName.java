/*     */ package org.thymeleaf.engine;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ElementName
/*     */ {
/*     */   protected final String prefix;
/*     */   protected final String elementName;
/*     */   protected final String[] completeElementNames;
/*     */   private final int h;
/*     */   
/*     */   protected ElementName(String prefix, String elementName, String[] completeElementNames)
/*     */   {
/*  49 */     if ((elementName == null) || ((elementName.length() > 0) && (elementName.trim().length() == 0))) {
/*  50 */       throw new IllegalArgumentException("Element name cannot be null");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  56 */     this.prefix = prefix;
/*  57 */     this.elementName = elementName;
/*  58 */     this.completeElementNames = completeElementNames;
/*  59 */     this.h = Arrays.hashCode(this.completeElementNames);
/*     */   }
/*     */   
/*     */ 
/*     */   public String getElementName()
/*     */   {
/*  65 */     return this.elementName;
/*     */   }
/*     */   
/*     */   public boolean isPrefixed() {
/*  69 */     return this.prefix != null;
/*     */   }
/*     */   
/*     */   public String getPrefix() {
/*  73 */     return this.prefix;
/*     */   }
/*     */   
/*     */   public String[] getCompleteElementNames() {
/*  77 */     return this.completeElementNames;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/*  86 */     if (this == o) {
/*  87 */       return true;
/*     */     }
/*  89 */     if (!(o instanceof ElementName)) {
/*  90 */       return false;
/*     */     }
/*     */     
/*  93 */     ElementName that = (ElementName)o;
/*     */     
/*  95 */     if (this.h != that.h) {
/*  96 */       return false;
/*     */     }
/*     */     
/*  99 */     if (!Arrays.equals(this.completeElementNames, that.completeElementNames)) {
/* 100 */       return false;
/*     */     }
/*     */     
/* 103 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 112 */     return this.h;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 120 */     StringBuilder strBuilder = new StringBuilder();
/* 121 */     strBuilder.append('{');
/* 122 */     strBuilder.append(this.completeElementNames[0]);
/* 123 */     for (int i = 1; i < this.completeElementNames.length; i++) {
/* 124 */       strBuilder.append(',');
/* 125 */       strBuilder.append(this.completeElementNames[i]);
/*     */     }
/* 127 */     strBuilder.append('}');
/* 128 */     return strBuilder.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\ElementName.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */