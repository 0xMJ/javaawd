/*      */ package org.thymeleaf.engine;
/*      */ 
/*      */ import java.util.Arrays;
/*      */ import java.util.List;
/*      */ import java.util.Set;
/*      */ import org.slf4j.Logger;
/*      */ import org.slf4j.LoggerFactory;
/*      */ import org.thymeleaf.IEngineConfiguration;
/*      */ import org.thymeleaf.context.IEngineContext;
/*      */ import org.thymeleaf.context.ITemplateContext;
/*      */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*      */ import org.thymeleaf.model.ICDATASection;
/*      */ import org.thymeleaf.model.ICloseElementTag;
/*      */ import org.thymeleaf.model.IComment;
/*      */ import org.thymeleaf.model.IDocType;
/*      */ import org.thymeleaf.model.IOpenElementTag;
/*      */ import org.thymeleaf.model.IProcessableElementTag;
/*      */ import org.thymeleaf.model.IProcessingInstruction;
/*      */ import org.thymeleaf.model.IStandaloneElementTag;
/*      */ import org.thymeleaf.model.ITemplateEnd;
/*      */ import org.thymeleaf.model.ITemplateEvent;
/*      */ import org.thymeleaf.model.ITemplateStart;
/*      */ import org.thymeleaf.model.IText;
/*      */ import org.thymeleaf.model.IXMLDeclaration;
/*      */ import org.thymeleaf.processor.cdatasection.ICDATASectionProcessor;
/*      */ import org.thymeleaf.processor.comment.ICommentProcessor;
/*      */ import org.thymeleaf.processor.doctype.IDocTypeProcessor;
/*      */ import org.thymeleaf.processor.element.IElementModelProcessor;
/*      */ import org.thymeleaf.processor.element.IElementProcessor;
/*      */ import org.thymeleaf.processor.element.IElementTagProcessor;
/*      */ import org.thymeleaf.processor.processinginstruction.IProcessingInstructionProcessor;
/*      */ import org.thymeleaf.processor.templateboundaries.ITemplateBoundariesProcessor;
/*      */ import org.thymeleaf.processor.text.ITextProcessor;
/*      */ import org.thymeleaf.processor.xmldeclaration.IXMLDeclarationProcessor;
/*      */ import org.thymeleaf.templatemode.TemplateMode;
/*      */ import org.thymeleaf.util.Validate;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class ProcessorTemplateHandler
/*      */   implements ITemplateHandler
/*      */ {
/*   78 */   private static final Logger logger = LoggerFactory.getLogger(ProcessorTemplateHandler.class);
/*      */   
/*      */ 
/*      */ 
/*   82 */   private static final ITemplateBoundariesProcessor[] EMPTY_TEMPLATE_BOUNDARIES_PROCESSORS = new ITemplateBoundariesProcessor[0];
/*   83 */   private static final ICDATASectionProcessor[] EMPTY_CDATA_SECTION_PROCESSORS = new ICDATASectionProcessor[0];
/*   84 */   private static final ICommentProcessor[] EMPTY_COMMENT_PROCESSORS = new ICommentProcessor[0];
/*   85 */   private static final IDocTypeProcessor[] EMPTY_DOCTYPE_PROCESSORS = new IDocTypeProcessor[0];
/*   86 */   private static final IProcessingInstructionProcessor[] EMPTY_PROCESSING_INSTRUCTION_PROCESSORS = new IProcessingInstructionProcessor[0];
/*   87 */   private static final ITextProcessor[] EMPTY_TEXT_PROCESSORS = new ITextProcessor[0];
/*   88 */   private static final IXMLDeclarationProcessor[] EMPTY_XML_DECLARATION_PROCESSORS = new IXMLDeclarationProcessor[0];
/*      */   
/*      */   private final ElementTagStructureHandler elementTagStructureHandler;
/*      */   
/*      */   private final ElementModelStructureHandler elementModelStructureHandler;
/*      */   
/*      */   private final TemplateBoundariesStructureHandler templateBoundariesStructureHandler;
/*      */   
/*      */   private final CDATASectionStructureHandler cdataSectionStructureHandler;
/*      */   
/*      */   private final CommentStructureHandler commentStructureHandler;
/*      */   
/*      */   private final DocTypeStructureHandler docTypeStructureHandler;
/*      */   
/*      */   private final ProcessingInstructionStructureHandler processingInstructionStructureHandler;
/*      */   
/*      */   private final TextStructureHandler textStructureHandler;
/*      */   
/*      */   private final XMLDeclarationStructureHandler xmlDeclarationStructureHandler;
/*  107 */   private ITemplateHandler next = null;
/*      */   
/*  109 */   private IEngineConfiguration configuration = null;
/*  110 */   private AttributeDefinitions attributeDefinitions = null;
/*  111 */   private TemplateMode templateMode = null;
/*      */   
/*      */ 
/*  114 */   private ITemplateContext context = null;
/*  115 */   private IEngineContext engineContext = null;
/*  116 */   private TemplateFlowController flowController = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  123 */   private ITemplateBoundariesProcessor[] templateBoundariesProcessors = null;
/*  124 */   private ICDATASectionProcessor[] cdataSectionProcessors = null;
/*  125 */   private ICommentProcessor[] commentProcessors = null;
/*  126 */   private IDocTypeProcessor[] docTypeProcessors = null;
/*  127 */   private IProcessingInstructionProcessor[] processingInstructionProcessors = null;
/*  128 */   private ITextProcessor[] textProcessors = null;
/*  129 */   private IXMLDeclarationProcessor[] xmlDeclarationProcessors = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  134 */   private Integer initialContextLevel = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  140 */   private TemplateModelController modelController = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  147 */   private IGatheringModelProcessable currentGatheringModel = null;
/*      */   
/*      */ 
/*      */ 
/*  151 */   private boolean throttleEngine = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  158 */   private IEngineProcessable[] pendingProcessings = null;
/*  159 */   private int pendingProcessingsSize = 0;
/*      */   
/*      */ 
/*      */ 
/*  163 */   private DecreaseContextLevelProcessable decreaseContextLevelProcessable = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ProcessorTemplateHandler()
/*      */   {
/*  177 */     this.elementTagStructureHandler = new ElementTagStructureHandler();
/*  178 */     this.elementModelStructureHandler = new ElementModelStructureHandler();
/*  179 */     this.templateBoundariesStructureHandler = new TemplateBoundariesStructureHandler();
/*  180 */     this.cdataSectionStructureHandler = new CDATASectionStructureHandler();
/*  181 */     this.commentStructureHandler = new CommentStructureHandler();
/*  182 */     this.docTypeStructureHandler = new DocTypeStructureHandler();
/*  183 */     this.processingInstructionStructureHandler = new ProcessingInstructionStructureHandler();
/*  184 */     this.textStructureHandler = new TextStructureHandler();
/*  185 */     this.xmlDeclarationStructureHandler = new XMLDeclarationStructureHandler();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setNext(ITemplateHandler next)
/*      */   {
/*  194 */     this.next = next;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setContext(ITemplateContext context)
/*      */   {
/*  203 */     this.context = context;
/*  204 */     Validate.notNull(this.context, "Context cannot be null");
/*  205 */     Validate.notNull(this.context.getTemplateMode(), "Template Mode returned by context cannot be null");
/*      */     
/*  207 */     this.configuration = context.getConfiguration();
/*  208 */     Validate.notNull(this.configuration, "Engine Configuration returned by context cannot be null");
/*  209 */     Validate.notNull(this.configuration.getElementDefinitions(), "Element Definitions returned by the Engine Configuration cannot be null");
/*  210 */     Validate.notNull(this.configuration.getAttributeDefinitions(), "Attribute Definitions returned by the Engine Configuration cannot be null");
/*      */     
/*  212 */     this.attributeDefinitions = this.configuration.getAttributeDefinitions();
/*      */     
/*  214 */     this.templateMode = this.context.getTemplateMode();
/*      */     
/*  216 */     if ((this.context instanceof IEngineContext)) {
/*  217 */       this.engineContext = ((IEngineContext)this.context);
/*      */     } else {
/*  219 */       logger.warn("Unknown implementation of the " + ITemplateContext.class.getName() + " interface: " + this.context
/*  220 */         .getClass().getName() + ". Local variable support will be DISABLED (this includes iteration, target selection and inlining). In order to enable these, context implementations should also implement the " + IEngineContext.class
/*      */         
/*  222 */         .getName() + " interface.");
/*      */       
/*  224 */       this.engineContext = null;
/*      */     }
/*      */     
/*      */ 
/*  228 */     this.modelController = new TemplateModelController(this.configuration, this.templateMode, this, this.engineContext);
/*  229 */     this.modelController.setTemplateFlowController(this.flowController);
/*  230 */     this.decreaseContextLevelProcessable = new DecreaseContextLevelProcessable(this.engineContext, this.flowController);
/*      */     
/*      */ 
/*  233 */     Set<ITemplateBoundariesProcessor> templateBoundariesProcessorSet = this.configuration.getTemplateBoundariesProcessors(this.templateMode);
/*  234 */     Set<ICDATASectionProcessor> cdataSectionProcessorSet = this.configuration.getCDATASectionProcessors(this.templateMode);
/*  235 */     Set<ICommentProcessor> commentProcessorSet = this.configuration.getCommentProcessors(this.templateMode);
/*  236 */     Set<IDocTypeProcessor> docTypeProcessorSet = this.configuration.getDocTypeProcessors(this.templateMode);
/*  237 */     Set<IProcessingInstructionProcessor> processingInstructionProcessorSet = this.configuration.getProcessingInstructionProcessors(this.templateMode);
/*  238 */     Set<ITextProcessor> textProcessorSet = this.configuration.getTextProcessors(this.templateMode);
/*  239 */     Set<IXMLDeclarationProcessor> xmlDeclarationProcessorSet = this.configuration.getXMLDeclarationProcessors(this.templateMode);
/*      */     
/*      */ 
/*      */ 
/*  243 */     this.templateBoundariesProcessors = (templateBoundariesProcessorSet.size() == 0 ? EMPTY_TEMPLATE_BOUNDARIES_PROCESSORS : (ITemplateBoundariesProcessor[])templateBoundariesProcessorSet.toArray(new ITemplateBoundariesProcessor[templateBoundariesProcessorSet.size()]));
/*      */     
/*  245 */     this.cdataSectionProcessors = (cdataSectionProcessorSet.size() == 0 ? EMPTY_CDATA_SECTION_PROCESSORS : (ICDATASectionProcessor[])cdataSectionProcessorSet.toArray(new ICDATASectionProcessor[cdataSectionProcessorSet.size()]));
/*      */     
/*  247 */     this.commentProcessors = (commentProcessorSet.size() == 0 ? EMPTY_COMMENT_PROCESSORS : (ICommentProcessor[])commentProcessorSet.toArray(new ICommentProcessor[commentProcessorSet.size()]));
/*      */     
/*  249 */     this.docTypeProcessors = (docTypeProcessorSet.size() == 0 ? EMPTY_DOCTYPE_PROCESSORS : (IDocTypeProcessor[])docTypeProcessorSet.toArray(new IDocTypeProcessor[docTypeProcessorSet.size()]));
/*      */     
/*  251 */     this.processingInstructionProcessors = (processingInstructionProcessorSet.size() == 0 ? EMPTY_PROCESSING_INSTRUCTION_PROCESSORS : (IProcessingInstructionProcessor[])processingInstructionProcessorSet.toArray(new IProcessingInstructionProcessor[processingInstructionProcessorSet.size()]));
/*      */     
/*  253 */     this.textProcessors = (textProcessorSet.size() == 0 ? EMPTY_TEXT_PROCESSORS : (ITextProcessor[])textProcessorSet.toArray(new ITextProcessor[textProcessorSet.size()]));
/*      */     
/*  255 */     this.xmlDeclarationProcessors = (xmlDeclarationProcessorSet.size() == 0 ? EMPTY_XML_DECLARATION_PROCESSORS : (IXMLDeclarationProcessor[])xmlDeclarationProcessorSet.toArray(new IXMLDeclarationProcessor[xmlDeclarationProcessorSet.size()]));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFlowController(TemplateFlowController flowController)
/*      */   {
/*  263 */     this.flowController = flowController;
/*  264 */     this.throttleEngine = (this.flowController != null);
/*  265 */     if ((this.throttleEngine) && (this.modelController != null)) {
/*  266 */       this.modelController.setTemplateFlowController(this.flowController);
/*      */     }
/*  268 */     if ((this.throttleEngine) && (this.engineContext != null)) {
/*  269 */       this.decreaseContextLevelProcessable = new DecreaseContextLevelProcessable(this.engineContext, this.flowController);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void handleTemplateStart(ITemplateStart itemplateStart)
/*      */   {
/*  288 */     if ((this.throttleEngine) && (this.flowController.stopProcessing)) {
/*  289 */       queueEvent(itemplateStart);
/*  290 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  299 */     if (this.engineContext != null) {
/*  300 */       this.initialContextLevel = Integer.valueOf(this.engineContext.level());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  307 */     if (this.templateBoundariesProcessors.length == 0) {
/*  308 */       this.next.handleTemplateStart(itemplateStart);
/*  309 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  316 */     Model model = null;
/*  317 */     ITemplateHandler modelHandler = this;
/*  318 */     TemplateBoundariesStructureHandler structureHandler = this.templateBoundariesStructureHandler;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  324 */     for (int i = 0; i < this.templateBoundariesProcessors.length; i++)
/*      */     {
/*  326 */       structureHandler.reset();
/*      */       
/*  328 */       this.templateBoundariesProcessors[i].processTemplateStart(this.context, itemplateStart, structureHandler);
/*      */       
/*  330 */       if (this.engineContext != null) {
/*  331 */         structureHandler.applyContextModifications(this.engineContext);
/*      */       }
/*      */       
/*  334 */       if (structureHandler.insertText)
/*      */       {
/*  336 */         model = resetModel(model, true);
/*  337 */         model.add(new Text(structureHandler.insertTextValue));
/*  338 */         modelHandler = structureHandler.insertTextProcessable ? this : this.next;
/*      */       }
/*  340 */       else if (structureHandler.insertModel)
/*      */       {
/*  342 */         model = resetModel(model, true);
/*  343 */         model.addModel(structureHandler.insertModelValue);
/*  344 */         modelHandler = structureHandler.insertModelProcessable ? this : this.next;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  354 */     this.next.handleTemplateStart(itemplateStart);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  360 */     if ((model == null) || (model.size() == 0)) {
/*  361 */       return;
/*      */     }
/*  363 */     if (!this.throttleEngine) {
/*  364 */       model.process(modelHandler);
/*      */     } else {
/*  366 */       queueProcessable(new SimpleModelProcessable(model, modelHandler, this.flowController));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void handleTemplateEnd(ITemplateEnd itemplateEnd)
/*      */   {
/*  386 */     if ((this.throttleEngine) && (this.flowController.stopProcessing)) {
/*  387 */       queueEvent(itemplateEnd);
/*  388 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  395 */     if (this.templateBoundariesProcessors.length == 0) {
/*  396 */       this.next.handleTemplateEnd(itemplateEnd);
/*  397 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  404 */     Model model = null;
/*  405 */     ITemplateHandler modelHandler = this;
/*  406 */     TemplateBoundariesStructureHandler structureHandler = this.templateBoundariesStructureHandler;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  411 */     for (int i = 0; i < this.templateBoundariesProcessors.length; i++)
/*      */     {
/*  413 */       structureHandler.reset();
/*      */       
/*  415 */       this.templateBoundariesProcessors[i].processTemplateEnd(this.context, itemplateEnd, structureHandler);
/*      */       
/*  417 */       if (this.engineContext != null) {
/*  418 */         structureHandler.applyContextModifications(this.engineContext);
/*      */       }
/*      */       
/*  421 */       if (structureHandler.insertText)
/*      */       {
/*  423 */         model = resetModel(model, true);
/*  424 */         model.add(new Text(structureHandler.insertTextValue));
/*  425 */         modelHandler = structureHandler.insertTextProcessable ? this : this.next;
/*      */       }
/*  427 */       else if (structureHandler.insertModel)
/*      */       {
/*  429 */         model = resetModel(model, true);
/*  430 */         model.addModel(structureHandler.insertModelValue);
/*  431 */         modelHandler = structureHandler.insertModelProcessable ? this : this.next;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  441 */     if ((this.throttleEngine) && (model != null) && (model.size() > 0)) {
/*  442 */       queueProcessable(new TemplateEndModelProcessable(itemplateEnd, model, modelHandler, this, this.next, this.flowController));
/*  443 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  450 */     if (model != null) {
/*  451 */       model.process(modelHandler);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  458 */     this.next.handleTemplateEnd(itemplateEnd);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  465 */     performTearDownChecks(itemplateEnd);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void performTearDownChecks(ITemplateEnd itemplateEnd)
/*      */   {
/*  478 */     if (this.modelController.getModelLevel() != 0)
/*      */     {
/*      */ 
/*  481 */       throw new TemplateProcessingException("Bad markup or template processing sequence. Model level is != 0 (" + this.modelController.getModelLevel() + ") at template end.", itemplateEnd.getTemplateName(), itemplateEnd.getLine(), itemplateEnd.getCol());
/*      */     }
/*  483 */     if (this.engineContext != null) {
/*  484 */       if (this.engineContext.level() != this.initialContextLevel.intValue())
/*      */       {
/*      */ 
/*      */ 
/*  488 */         throw new TemplateProcessingException("Bad markup or template processing sequence. Context level after processing (" + this.engineContext.level() + ") does not correspond to context level before processing (" + this.initialContextLevel.intValue() + ").", itemplateEnd.getTemplateName(), itemplateEnd.getLine(), itemplateEnd.getCol());
/*      */       }
/*  490 */       List<IProcessableElementTag> elementStack = this.engineContext.getElementStackAbove(this.initialContextLevel.intValue());
/*  491 */       if (!elementStack.isEmpty())
/*      */       {
/*      */ 
/*  494 */         throw new TemplateProcessingException("Bad markup or template processing sequence. Element stack after processing is not empty: " + elementStack, itemplateEnd.getTemplateName(), itemplateEnd.getLine(), itemplateEnd.getCol());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void handleText(IText itext)
/*      */   {
/*  515 */     if ((this.throttleEngine) && (this.flowController.stopProcessing)) {
/*  516 */       queueEvent(itext);
/*  517 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  524 */     if (!this.modelController.shouldProcessText(itext)) {
/*  525 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  532 */     if (this.textProcessors.length == 0) {
/*  533 */       this.next.handleText(itext);
/*  534 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  541 */     Text text = Text.asEngineText(itext);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  547 */     boolean discardEvent = false;
/*  548 */     Model model = null;
/*  549 */     ITemplateHandler modelHandler = this;
/*  550 */     TextStructureHandler structureHandler = this.textStructureHandler;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  556 */     for (int i = 0; (!discardEvent) && (i < this.textProcessors.length); i++)
/*      */     {
/*  558 */       structureHandler.reset();
/*      */       
/*  560 */       this.textProcessors[i].process(this.context, text, structureHandler);
/*      */       
/*  562 */       if (structureHandler.setText)
/*      */       {
/*  564 */         text = new Text(structureHandler.setTextValue);
/*      */       }
/*  566 */       else if (structureHandler.replaceWithModel)
/*      */       {
/*  568 */         model = resetModel(model, true);
/*  569 */         model.addModel(structureHandler.replaceWithModelValue);
/*  570 */         modelHandler = structureHandler.replaceWithModelProcessable ? this : this.next;
/*  571 */         discardEvent = true;
/*      */       }
/*  573 */       else if (structureHandler.removeText)
/*      */       {
/*  575 */         model = null;
/*  576 */         discardEvent = true;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  586 */     if (!discardEvent) {
/*  587 */       this.next.handleText(text);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  594 */     if ((model == null) || (model.size() == 0)) {
/*  595 */       return;
/*      */     }
/*  597 */     if (!this.throttleEngine) {
/*  598 */       model.process(modelHandler);
/*      */     } else {
/*  600 */       queueProcessable(new SimpleModelProcessable(model, modelHandler, this.flowController));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void handleComment(IComment icomment)
/*      */   {
/*  620 */     if ((this.throttleEngine) && (this.flowController.stopProcessing)) {
/*  621 */       queueEvent(icomment);
/*  622 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  629 */     if (!this.modelController.shouldProcessComment(icomment)) {
/*  630 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  637 */     if (this.commentProcessors.length == 0) {
/*  638 */       this.next.handleComment(icomment);
/*  639 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  646 */     Comment comment = Comment.asEngineComment(icomment);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  652 */     boolean discardEvent = false;
/*  653 */     Model model = null;
/*  654 */     ITemplateHandler modelHandler = this;
/*  655 */     CommentStructureHandler structureHandler = this.commentStructureHandler;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  661 */     for (int i = 0; (!discardEvent) && (i < this.commentProcessors.length); i++)
/*      */     {
/*  663 */       structureHandler.reset();
/*      */       
/*  665 */       this.commentProcessors[i].process(this.context, comment, structureHandler);
/*      */       
/*  667 */       if (structureHandler.setContent)
/*      */       {
/*  669 */         comment = new Comment(comment.prefix, structureHandler.setContentValue, comment.suffix);
/*      */       }
/*  671 */       else if (structureHandler.replaceWithModel)
/*      */       {
/*  673 */         model = resetModel(model, true);
/*  674 */         model.addModel(structureHandler.replaceWithModelValue);
/*  675 */         modelHandler = structureHandler.replaceWithModelProcessable ? this : this.next;
/*  676 */         discardEvent = true;
/*      */       }
/*  678 */       else if (structureHandler.removeComment)
/*      */       {
/*  680 */         model = null;
/*  681 */         discardEvent = true;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  691 */     if (!discardEvent) {
/*  692 */       this.next.handleComment(comment);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  699 */     if ((model == null) || (model.size() == 0)) {
/*  700 */       return;
/*      */     }
/*  702 */     if (!this.throttleEngine) {
/*  703 */       model.process(modelHandler);
/*      */     } else {
/*  705 */       queueProcessable(new SimpleModelProcessable(model, modelHandler, this.flowController));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void handleCDATASection(ICDATASection icdataSection)
/*      */   {
/*  725 */     if ((this.throttleEngine) && (this.flowController.stopProcessing)) {
/*  726 */       queueEvent(icdataSection);
/*  727 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  734 */     if (!this.modelController.shouldProcessCDATASection(icdataSection)) {
/*  735 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  742 */     if (this.cdataSectionProcessors.length == 0) {
/*  743 */       this.next.handleCDATASection(icdataSection);
/*  744 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  751 */     CDATASection cdataSection = CDATASection.asEngineCDATASection(icdataSection);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  757 */     boolean discardEvent = false;
/*  758 */     Model model = null;
/*  759 */     ITemplateHandler modelHandler = this;
/*  760 */     CDATASectionStructureHandler structureHandler = this.cdataSectionStructureHandler;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  766 */     for (int i = 0; (!discardEvent) && (i < this.cdataSectionProcessors.length); i++)
/*      */     {
/*  768 */       structureHandler.reset();
/*      */       
/*  770 */       this.cdataSectionProcessors[i].process(this.context, cdataSection, structureHandler);
/*      */       
/*  772 */       if (structureHandler.setContent)
/*      */       {
/*  774 */         cdataSection = new CDATASection(cdataSection.prefix, structureHandler.setContentValue, cdataSection.suffix);
/*      */       }
/*  776 */       else if (structureHandler.replaceWithModel)
/*      */       {
/*  778 */         model = resetModel(model, true);
/*  779 */         model.addModel(structureHandler.replaceWithModelValue);
/*  780 */         modelHandler = structureHandler.replaceWithModelProcessable ? this : this.next;
/*  781 */         discardEvent = true;
/*      */       }
/*  783 */       else if (structureHandler.removeCDATASection)
/*      */       {
/*  785 */         model = null;
/*  786 */         discardEvent = true;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  796 */     if (!discardEvent) {
/*  797 */       this.next.handleCDATASection(cdataSection);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  804 */     if ((model == null) || (model.size() == 0)) {
/*  805 */       return;
/*      */     }
/*  807 */     if (!this.throttleEngine) {
/*  808 */       model.process(modelHandler);
/*      */     } else {
/*  810 */       queueProcessable(new SimpleModelProcessable(model, modelHandler, this.flowController));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void handleStandaloneElement(IStandaloneElementTag istandaloneElementTag)
/*      */   {
/*  830 */     if ((this.throttleEngine) && (this.flowController.stopProcessing)) {
/*  831 */       queueEvent(istandaloneElementTag);
/*  832 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  839 */     if (!this.modelController.shouldProcessStandaloneElement(istandaloneElementTag)) {
/*  840 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  847 */     StandaloneElementTag standaloneElementTag = StandaloneElementTag.asEngineStandaloneElementTag(istandaloneElementTag);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  857 */     IGatheringModelProcessable currentGatheringModel = obtainCurrentGatheringModel();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  865 */     if ((currentGatheringModel != null) && (this.engineContext != null)) {
/*  866 */       this.engineContext.setElementTag(null);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  874 */     if ((currentGatheringModel == null) && (!standaloneElementTag.hasAssociatedProcessors()))
/*      */     {
/*  876 */       this.next.handleStandaloneElement(standaloneElementTag);
/*      */       
/*  878 */       if ((!this.throttleEngine) || (!this.flowController.stopProcessing)) {
/*  879 */         if (this.engineContext != null) {
/*  880 */           this.engineContext.decreaseLevel();
/*      */         }
/*      */       } else {
/*  883 */         queueProcessable(this.decreaseContextLevelProcessable);
/*      */       }
/*      */       
/*  886 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  896 */     ProcessorExecutionVars vars = currentGatheringModel == null ? new ProcessorExecutionVars() : currentGatheringModel.initializeProcessorExecutionVars();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  902 */     ElementTagStructureHandler tagStructureHandler = this.elementTagStructureHandler;
/*  903 */     ElementModelStructureHandler modelStructureHandler = this.elementModelStructureHandler;
/*      */     
/*      */ 
/*      */ 
/*      */     IElementProcessor processor;
/*      */     
/*      */ 
/*  910 */     while ((!vars.discardEvent) && ((processor = vars.processorIterator.next(standaloneElementTag)) != null))
/*      */     {
/*  912 */       tagStructureHandler.reset();
/*  913 */       modelStructureHandler.reset();
/*      */       
/*  915 */       if ((processor instanceof IElementTagProcessor))
/*      */       {
/*  917 */         IElementTagProcessor elementProcessor = (IElementTagProcessor)processor;
/*  918 */         elementProcessor.process(this.context, standaloneElementTag, tagStructureHandler);
/*      */         
/*      */ 
/*  921 */         tagStructureHandler.applyContextModifications(this.engineContext);
/*      */         
/*      */ 
/*      */ 
/*  925 */         standaloneElementTag = (StandaloneElementTag)tagStructureHandler.applyAttributes(this.attributeDefinitions, standaloneElementTag);
/*      */         
/*  927 */         if (tagStructureHandler.iterateElement)
/*      */         {
/*      */ 
/*  930 */           this.modelController.startGatheringIteratedModel(standaloneElementTag, vars, tagStructureHandler.iterVariableName, tagStructureHandler.iterStatusVariableName, tagStructureHandler.iteratedObject);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  937 */           IGatheringModelProcessable gatheredModel = this.modelController.getGatheredModel();
/*  938 */           this.modelController.resetGathering();
/*      */           
/*      */ 
/*  941 */           if (!this.throttleEngine) {
/*  942 */             gatheredModel.process();
/*      */           } else {
/*  944 */             queueProcessable(gatheredModel);
/*      */           }
/*      */           
/*      */ 
/*  948 */           return;
/*      */         }
/*  950 */         if (tagStructureHandler.setBodyText)
/*      */         {
/*      */ 
/*  953 */           vars.modelAfter = resetModel(vars.modelAfter, true);
/*      */           
/*      */ 
/*  956 */           Text text = new Text(tagStructureHandler.setBodyTextValue);
/*  957 */           vars.modelAfter.add(text);
/*      */           
/*      */ 
/*  960 */           vars.modelAfterProcessable = tagStructureHandler.setBodyTextProcessable;
/*      */           
/*      */ 
/*      */ 
/*  964 */           GatheringModelProcessable equivalentSyntheticModel = this.modelController.createStandaloneEquivalentModel(standaloneElementTag, vars);
/*      */           
/*      */ 
/*  967 */           if (!this.throttleEngine) {
/*  968 */             equivalentSyntheticModel.process();
/*      */           } else {
/*  970 */             queueProcessable(equivalentSyntheticModel);
/*      */           }
/*      */           
/*      */ 
/*  974 */           return;
/*      */         }
/*  976 */         if (tagStructureHandler.setBodyModel)
/*      */         {
/*      */ 
/*  979 */           vars.modelAfter = resetModel(vars.modelAfter, true);
/*      */           
/*      */ 
/*  982 */           vars.modelAfter.addModel(tagStructureHandler.setBodyModelValue);
/*      */           
/*      */ 
/*  985 */           vars.modelAfterProcessable = tagStructureHandler.setBodyModelProcessable;
/*      */           
/*      */ 
/*      */ 
/*  989 */           GatheringModelProcessable equivalentSyntheticModel = this.modelController.createStandaloneEquivalentModel(standaloneElementTag, vars);
/*      */           
/*      */ 
/*  992 */           if (!this.throttleEngine) {
/*  993 */             equivalentSyntheticModel.process();
/*      */           } else {
/*  995 */             queueProcessable(equivalentSyntheticModel);
/*      */           }
/*      */           
/*      */ 
/*  999 */           return;
/*      */         }
/* 1001 */         if (tagStructureHandler.insertBeforeModel)
/*      */         {
/*      */ 
/* 1004 */           vars.modelBefore = resetModel(vars.modelBefore, true);
/*      */           
/*      */ 
/* 1007 */           vars.modelBefore.addModel(tagStructureHandler.insertBeforeModelValue);
/*      */         }
/* 1009 */         else if (tagStructureHandler.insertImmediatelyAfterModel)
/*      */         {
/*      */ 
/*      */ 
/* 1013 */           if (vars.modelAfter == null) {
/* 1014 */             vars.modelAfter = resetModel(vars.modelAfter, true);
/*      */           }
/*      */           
/*      */ 
/* 1018 */           vars.modelAfterProcessable = tagStructureHandler.insertImmediatelyAfterModelProcessable;
/*      */           
/*      */ 
/* 1021 */           vars.modelAfter.insertModel(0, tagStructureHandler.insertImmediatelyAfterModelValue);
/*      */         }
/* 1023 */         else if (tagStructureHandler.replaceWithText)
/*      */         {
/*      */ 
/* 1026 */           vars.modelAfter = resetModel(vars.modelAfter, true);
/*      */           
/*      */ 
/* 1029 */           vars.modelAfterProcessable = tagStructureHandler.replaceWithTextProcessable;
/*      */           
/*      */ 
/* 1032 */           vars.modelAfter.add(new Text(tagStructureHandler.replaceWithTextValue));
/*      */           
/*      */ 
/* 1035 */           vars.discardEvent = true;
/*      */         }
/* 1037 */         else if (tagStructureHandler.replaceWithModel)
/*      */         {
/*      */ 
/* 1040 */           vars.modelAfter = resetModel(vars.modelAfter, true);
/*      */           
/*      */ 
/* 1043 */           vars.modelAfterProcessable = tagStructureHandler.replaceWithModelProcessable;
/*      */           
/*      */ 
/* 1046 */           vars.modelAfter.addModel(tagStructureHandler.replaceWithModelValue);
/*      */           
/*      */ 
/* 1049 */           vars.discardEvent = true;
/*      */         }
/* 1051 */         else if (tagStructureHandler.removeElement)
/*      */         {
/*      */ 
/* 1054 */           vars.modelAfter = resetModel(vars.modelAfter, false);
/*      */           
/*      */ 
/* 1057 */           vars.discardEvent = true;
/*      */         }
/* 1059 */         else if (tagStructureHandler.removeTags)
/*      */         {
/*      */ 
/* 1062 */           vars.discardEvent = true;
/*      */ 
/*      */ 
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */       }
/* 1070 */       else if ((processor instanceof IElementModelProcessor))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1085 */         if (!vars.processorIterator.lastWasRepeated())
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1091 */           if (((vars.modelBefore != null) && (vars.modelBefore.size() > 0)) || ((vars.modelAfter != null) && (vars.modelAfter.size() > 0)))
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1097 */             throw new TemplateProcessingException("Cannot execute model processor " + processor.getClass().getName() + " as the body of the target element has already been modified by a previously executed processor on the same tag. Model processors cannot execute on already-modified bodies as these might contain unprocessable events (e.g. as a result of a 'th:text' or similar)", standaloneElementTag.getTemplateName(), standaloneElementTag.getLine(), standaloneElementTag.getCol());
/*      */           }
/*      */           
/*      */ 
/* 1101 */           vars.processorIterator.setLastToBeRepeated(standaloneElementTag);
/*      */           
/*      */ 
/*      */ 
/* 1105 */           this.modelController.startGatheringDelayedModel(standaloneElementTag, vars);
/* 1106 */           IGatheringModelProcessable newModel = this.modelController.getGatheredModel();
/* 1107 */           this.modelController.resetGathering();
/*      */           
/*      */ 
/* 1110 */           if (!this.throttleEngine) {
/* 1111 */             newModel.process();
/*      */           } else {
/* 1113 */             queueProcessable(newModel);
/*      */           }
/*      */           
/*      */ 
/* 1117 */           return;
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1127 */         Model gatheredModel = currentGatheringModel.getInnerModel();
/* 1128 */         Model processedModel = new Model(gatheredModel);
/*      */         
/*      */ 
/* 1131 */         ((IElementModelProcessor)processor).process(this.context, processedModel, modelStructureHandler);
/*      */         
/*      */ 
/* 1134 */         modelStructureHandler.applyContextModifications(this.engineContext);
/*      */         
/*      */ 
/* 1137 */         currentGatheringModel.resetGatheredSkipFlags();
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1144 */         if (!gatheredModel.sameAs(processedModel))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1152 */           vars.modelAfter = resetModel(vars.modelAfter, true);
/*      */           
/*      */ 
/* 1155 */           vars.modelAfter.addModel(processedModel);
/* 1156 */           vars.modelAfterProcessable = true;
/*      */           
/*      */ 
/*      */ 
/*      */ 
/* 1161 */           vars.discardEvent = true;
/*      */         }
/*      */         
/*      */       }
/*      */       else
/*      */       {
/* 1167 */         throw new IllegalStateException("An element has been found with an associated processor of type " + processor.getClass().getName() + " which is neither a Tag Element Processor nor a Model Element Processor.");
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1177 */     if ((this.throttleEngine) && (((vars.modelAfter != null) && 
/* 1178 */       (vars.modelAfter.size() > 0)) || ((vars.modelBefore != null) && (vars.modelBefore.size() > 0)))) {
/* 1179 */       queueProcessable(new StandaloneElementTagModelProcessable(standaloneElementTag, vars, this.engineContext, this.modelController, this.flowController, this, this.next));
/* 1180 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1187 */     if (vars.modelBefore != null) {
/* 1188 */       vars.modelBefore.process(this.next);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1195 */     if (!vars.discardEvent) {
/* 1196 */       this.next.handleStandaloneElement(standaloneElementTag);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1203 */     if (vars.modelAfter != null) {
/* 1204 */       vars.modelAfter.process(vars.modelAfterProcessable ? this : this.next);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1212 */     if ((!this.throttleEngine) || (!this.flowController.stopProcessing)) {
/* 1213 */       if (this.engineContext != null) {
/* 1214 */         this.engineContext.decreaseLevel();
/*      */       }
/*      */     } else {
/* 1217 */       queueProcessable(this.decreaseContextLevelProcessable);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void handleOpenElement(IOpenElementTag iopenElementTag)
/*      */   {
/* 1237 */     if ((this.throttleEngine) && (this.flowController.stopProcessing)) {
/* 1238 */       queueEvent(iopenElementTag);
/* 1239 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1246 */     if (!this.modelController.shouldProcessOpenElement(iopenElementTag)) {
/* 1247 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1254 */     OpenElementTag openElementTag = OpenElementTag.asEngineOpenElementTag(iopenElementTag);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1264 */     IGatheringModelProcessable currentGatheringModel = obtainCurrentGatheringModel();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1272 */     if ((currentGatheringModel != null) && (this.engineContext != null)) {
/* 1273 */       this.engineContext.setElementTag(null);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1281 */     if ((currentGatheringModel == null) && (!openElementTag.hasAssociatedProcessors())) {
/* 1282 */       this.next.handleOpenElement(openElementTag);
/* 1283 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1292 */     ProcessorExecutionVars vars = currentGatheringModel == null ? new ProcessorExecutionVars() : currentGatheringModel.initializeProcessorExecutionVars();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1298 */     ElementTagStructureHandler tagStructureHandler = this.elementTagStructureHandler;
/* 1299 */     ElementModelStructureHandler modelStructureHandler = this.elementModelStructureHandler;
/*      */     
/*      */ 
/*      */ 
/*      */     IElementProcessor processor;
/*      */     
/*      */ 
/* 1306 */     while ((!vars.discardEvent) && ((processor = vars.processorIterator.next(openElementTag)) != null))
/*      */     {
/* 1308 */       tagStructureHandler.reset();
/* 1309 */       modelStructureHandler.reset();
/*      */       
/* 1311 */       if ((processor instanceof IElementTagProcessor))
/*      */       {
/* 1313 */         IElementTagProcessor elementProcessor = (IElementTagProcessor)processor;
/* 1314 */         elementProcessor.process(this.context, openElementTag, tagStructureHandler);
/*      */         
/*      */ 
/* 1317 */         tagStructureHandler.applyContextModifications(this.engineContext);
/*      */         
/*      */ 
/*      */ 
/* 1321 */         openElementTag = (OpenElementTag)tagStructureHandler.applyAttributes(this.attributeDefinitions, openElementTag);
/*      */         
/* 1323 */         if (tagStructureHandler.iterateElement)
/*      */         {
/*      */ 
/* 1326 */           this.modelController.startGatheringIteratedModel(openElementTag, vars, tagStructureHandler.iterVariableName, tagStructureHandler.iterStatusVariableName, tagStructureHandler.iteratedObject);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1333 */           return;
/*      */         }
/* 1335 */         if (tagStructureHandler.setBodyText)
/*      */         {
/*      */ 
/* 1338 */           vars.modelAfter = resetModel(vars.modelAfter, true);
/*      */           
/*      */ 
/* 1341 */           vars.modelAfterProcessable = tagStructureHandler.setBodyTextProcessable;
/*      */           
/*      */ 
/* 1344 */           vars.modelAfter.add(new Text(tagStructureHandler.setBodyTextValue));
/*      */           
/*      */ 
/* 1347 */           vars.skipBody = TemplateModelController.SkipBody.SKIP_ALL;
/*      */         }
/* 1349 */         else if (tagStructureHandler.setBodyModel)
/*      */         {
/*      */ 
/* 1352 */           vars.modelAfter = resetModel(vars.modelAfter, true);
/*      */           
/*      */ 
/* 1355 */           vars.modelAfterProcessable = tagStructureHandler.setBodyModelProcessable;
/*      */           
/*      */ 
/* 1358 */           vars.modelAfter.addModel(tagStructureHandler.setBodyModelValue);
/*      */           
/*      */ 
/* 1361 */           vars.skipBody = TemplateModelController.SkipBody.SKIP_ALL;
/*      */         }
/* 1363 */         else if (tagStructureHandler.insertBeforeModel)
/*      */         {
/*      */ 
/* 1366 */           vars.modelBefore = resetModel(vars.modelBefore, true);
/*      */           
/*      */ 
/* 1369 */           vars.modelBefore.addModel(tagStructureHandler.insertBeforeModelValue);
/*      */         }
/* 1371 */         else if (tagStructureHandler.insertImmediatelyAfterModel)
/*      */         {
/*      */ 
/*      */ 
/* 1375 */           if (vars.modelAfter == null) {
/* 1376 */             vars.modelAfter = resetModel(vars.modelAfter, true);
/*      */           }
/*      */           
/*      */ 
/* 1380 */           vars.modelAfterProcessable = tagStructureHandler.insertImmediatelyAfterModelProcessable;
/*      */           
/*      */ 
/* 1383 */           vars.modelAfter.insertModel(0, tagStructureHandler.insertImmediatelyAfterModelValue);
/*      */ 
/*      */ 
/*      */         }
/* 1387 */         else if (tagStructureHandler.replaceWithText)
/*      */         {
/*      */ 
/* 1390 */           vars.modelAfter = resetModel(vars.modelAfter, true);
/*      */           
/*      */ 
/* 1393 */           vars.modelAfterProcessable = tagStructureHandler.replaceWithTextProcessable;
/*      */           
/*      */ 
/* 1396 */           vars.modelAfter.add(new Text(tagStructureHandler.replaceWithTextValue));
/*      */           
/*      */ 
/* 1399 */           vars.discardEvent = true;
/* 1400 */           vars.skipBody = TemplateModelController.SkipBody.SKIP_ALL;
/* 1401 */           vars.skipCloseTag = true;
/*      */         }
/* 1403 */         else if (tagStructureHandler.replaceWithModel)
/*      */         {
/*      */ 
/* 1406 */           vars.modelAfter = resetModel(vars.modelAfter, true);
/*      */           
/*      */ 
/* 1409 */           vars.modelAfterProcessable = tagStructureHandler.replaceWithModelProcessable;
/*      */           
/*      */ 
/* 1412 */           vars.modelAfter.addModel(tagStructureHandler.replaceWithModelValue);
/*      */           
/*      */ 
/* 1415 */           vars.discardEvent = true;
/* 1416 */           vars.skipBody = TemplateModelController.SkipBody.SKIP_ALL;
/* 1417 */           vars.skipCloseTag = true;
/*      */         }
/* 1419 */         else if (tagStructureHandler.removeElement)
/*      */         {
/*      */ 
/* 1422 */           vars.modelAfter = resetModel(vars.modelAfter, false);
/*      */           
/*      */ 
/* 1425 */           vars.discardEvent = true;
/* 1426 */           vars.skipBody = TemplateModelController.SkipBody.SKIP_ALL;
/* 1427 */           vars.skipCloseTag = true;
/*      */         }
/* 1429 */         else if (tagStructureHandler.removeTags)
/*      */         {
/*      */ 
/* 1432 */           vars.discardEvent = true;
/* 1433 */           vars.skipCloseTag = true;
/*      */         }
/* 1435 */         else if (tagStructureHandler.removeBody)
/*      */         {
/*      */ 
/* 1438 */           vars.modelAfter = resetModel(vars.modelAfter, false);
/*      */           
/*      */ 
/* 1441 */           vars.skipBody = TemplateModelController.SkipBody.SKIP_ALL;
/*      */         }
/* 1443 */         else if (tagStructureHandler.removeAllButFirstChild)
/*      */         {
/*      */ 
/* 1446 */           vars.modelAfter = resetModel(vars.modelAfter, false);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1454 */           vars.skipBody = TemplateModelController.SkipBody.PROCESS_ONE_ELEMENT;
/*      */         }
/*      */         
/*      */       }
/* 1458 */       else if ((processor instanceof IElementModelProcessor))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1473 */         if (!vars.processorIterator.lastWasRepeated())
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1479 */           if (((vars.modelBefore != null) && (vars.modelBefore.size() > 0)) || ((vars.modelAfter != null) && (vars.modelAfter.size() > 0)))
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1485 */             throw new TemplateProcessingException("Cannot execute model processor " + processor.getClass().getName() + " as the body of the target element has already been modified by a previously executed processor on the same tag. Model processors cannot execute on already-modified bodies as these might contain unprocessable events (e.g. as a result of a 'th:text' or similar)", openElementTag.getTemplateName(), openElementTag.getLine(), openElementTag.getCol());
/*      */           }
/*      */           
/*      */ 
/* 1489 */           vars.processorIterator.setLastToBeRepeated(openElementTag);
/*      */           
/*      */ 
/*      */ 
/* 1493 */           this.modelController.startGatheringDelayedModel(openElementTag, vars);
/*      */           
/*      */ 
/* 1496 */           return;
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1506 */         Model gatheredModel = currentGatheringModel.getInnerModel();
/* 1507 */         Model processedModel = new Model(gatheredModel);
/*      */         
/*      */ 
/* 1510 */         ((IElementModelProcessor)processor).process(this.context, processedModel, modelStructureHandler);
/*      */         
/*      */ 
/* 1513 */         modelStructureHandler.applyContextModifications(this.engineContext);
/*      */         
/*      */ 
/* 1516 */         currentGatheringModel.resetGatheredSkipFlags();
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1523 */         if (!gatheredModel.sameAs(processedModel))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1531 */           vars.modelAfter = resetModel(vars.modelAfter, true);
/*      */           
/*      */ 
/* 1534 */           vars.modelAfter.addModel(processedModel);
/* 1535 */           vars.modelAfterProcessable = true;
/*      */           
/*      */ 
/*      */ 
/* 1539 */           vars.discardEvent = true;
/* 1540 */           vars.skipBody = TemplateModelController.SkipBody.SKIP_ALL;
/* 1541 */           vars.skipCloseTag = true;
/*      */         }
/*      */         
/*      */       }
/*      */       else
/*      */       {
/* 1547 */         throw new IllegalStateException("An element has been found with an associated processor of type " + processor.getClass().getName() + " which is neither a Tag Element Processor nor a Model Element Processor.");
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1557 */     if ((this.throttleEngine) && (((vars.modelAfter != null) && 
/* 1558 */       (vars.modelAfter.size() > 0)) || ((vars.modelBefore != null) && (vars.modelBefore.size() > 0)))) {
/* 1559 */       queueProcessable(new OpenElementTagModelProcessable(openElementTag, vars, this.modelController, this.flowController, this, this.next));
/* 1560 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1567 */     if (vars.modelBefore != null) {
/* 1568 */       vars.modelBefore.process(this.next);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1575 */     if (!vars.discardEvent) {
/* 1576 */       this.next.handleOpenElement(openElementTag);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1586 */     if (vars.modelAfter != null) {
/* 1587 */       vars.modelAfter.process(vars.modelAfterProcessable ? this : this.next);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1594 */     this.modelController.skip(vars.skipBody, vars.skipCloseTag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void handleCloseElement(ICloseElementTag icloseElementTag)
/*      */   {
/* 1611 */     if (icloseElementTag.isUnmatched()) {
/* 1612 */       handleUnmatchedCloseElement(icloseElementTag);
/* 1613 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1622 */     if ((this.throttleEngine) && (this.flowController.stopProcessing)) {
/* 1623 */       queueEvent(icloseElementTag);
/* 1624 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1631 */     if (!this.modelController.shouldProcessCloseElement(icloseElementTag))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1636 */       if (this.modelController.isGatheringFinished()) {
/* 1637 */         IGatheringModelProcessable gatheredModel = this.modelController.getGatheredModel();
/* 1638 */         this.modelController.resetGathering();
/* 1639 */         if (!this.throttleEngine) {
/* 1640 */           gatheredModel.process();
/*      */         } else {
/* 1642 */           queueProcessable(gatheredModel);
/*      */         }
/*      */       }
/*      */       
/* 1646 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1654 */     this.next.handleCloseElement(icloseElementTag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void handleUnmatchedCloseElement(ICloseElementTag icloseElementTag)
/*      */   {
/* 1672 */     if ((this.throttleEngine) && (this.flowController.stopProcessing)) {
/* 1673 */       queueEvent(icloseElementTag);
/* 1674 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1681 */     if (!this.modelController.shouldProcessUnmatchedCloseElement(icloseElementTag)) {
/* 1682 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1694 */     this.next.handleCloseElement(icloseElementTag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void handleDocType(IDocType idocType)
/*      */   {
/* 1713 */     if ((this.throttleEngine) && (this.flowController.stopProcessing)) {
/* 1714 */       queueEvent(idocType);
/* 1715 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1722 */     if (!this.modelController.shouldProcessDocType(idocType)) {
/* 1723 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1730 */     if (this.docTypeProcessors.length == 0) {
/* 1731 */       this.next.handleDocType(idocType);
/* 1732 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1739 */     DocType docType = DocType.asEngineDocType(idocType);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1745 */     boolean discardEvent = false;
/* 1746 */     Model model = null;
/* 1747 */     ITemplateHandler modelHandler = this;
/* 1748 */     DocTypeStructureHandler structureHandler = this.docTypeStructureHandler;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1754 */     for (int i = 0; (!discardEvent) && (i < this.docTypeProcessors.length); i++)
/*      */     {
/* 1756 */       structureHandler.reset();
/*      */       
/* 1758 */       this.docTypeProcessors[i].process(this.context, docType, structureHandler);
/*      */       
/* 1760 */       if (structureHandler.setDocType)
/*      */       {
/* 1762 */         docType = new DocType(structureHandler.setDocTypeKeyword, structureHandler.setDocTypeElementName, structureHandler.setDocTypePublicId, structureHandler.setDocTypeSystemId, structureHandler.setDocTypeInternalSubset);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/* 1770 */       else if (structureHandler.replaceWithModel)
/*      */       {
/* 1772 */         model = resetModel(model, true);
/* 1773 */         model.addModel(structureHandler.replaceWithModelValue);
/* 1774 */         modelHandler = structureHandler.replaceWithModelProcessable ? this : this.next;
/* 1775 */         discardEvent = true;
/*      */       }
/* 1777 */       else if (structureHandler.removeDocType)
/*      */       {
/* 1779 */         model = null;
/* 1780 */         discardEvent = true;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1790 */     if (!discardEvent) {
/* 1791 */       this.next.handleDocType(docType);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1798 */     if ((model == null) || (model.size() == 0)) {
/* 1799 */       return;
/*      */     }
/* 1801 */     if (!this.throttleEngine) {
/* 1802 */       model.process(modelHandler);
/*      */     } else {
/* 1804 */       queueProcessable(new SimpleModelProcessable(model, modelHandler, this.flowController));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void handleXMLDeclaration(IXMLDeclaration ixmlDeclaration)
/*      */   {
/* 1824 */     if ((this.throttleEngine) && (this.flowController.stopProcessing)) {
/* 1825 */       queueEvent(ixmlDeclaration);
/* 1826 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1833 */     if (!this.modelController.shouldProcessXMLDeclaration(ixmlDeclaration)) {
/* 1834 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1841 */     if (this.xmlDeclarationProcessors.length == 0) {
/* 1842 */       this.next.handleXMLDeclaration(ixmlDeclaration);
/* 1843 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1850 */     XMLDeclaration xmlDeclaration = XMLDeclaration.asEngineXMLDeclaration(ixmlDeclaration);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1856 */     boolean discardEvent = false;
/* 1857 */     Model model = null;
/* 1858 */     ITemplateHandler modelHandler = this;
/* 1859 */     XMLDeclarationStructureHandler structureHandler = this.xmlDeclarationStructureHandler;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1865 */     for (int i = 0; (!discardEvent) && (i < this.xmlDeclarationProcessors.length); i++)
/*      */     {
/* 1867 */       structureHandler.reset();
/*      */       
/* 1869 */       this.xmlDeclarationProcessors[i].process(this.context, xmlDeclaration, structureHandler);
/*      */       
/* 1871 */       if (structureHandler.setXMLDeclaration)
/*      */       {
/* 1873 */         xmlDeclaration = new XMLDeclaration(structureHandler.setXMLDeclarationKeyword, structureHandler.setXMLDeclarationVersion, structureHandler.setXMLDeclarationEncoding, structureHandler.setXMLDeclarationStandalone);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/* 1880 */       else if (structureHandler.replaceWithModel)
/*      */       {
/* 1882 */         model = resetModel(model, true);
/* 1883 */         model.addModel(structureHandler.replaceWithModelValue);
/* 1884 */         modelHandler = structureHandler.replaceWithModelProcessable ? this : this.next;
/* 1885 */         discardEvent = true;
/*      */       }
/* 1887 */       else if (structureHandler.removeXMLDeclaration)
/*      */       {
/* 1889 */         model = null;
/* 1890 */         discardEvent = true;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1900 */     if (!discardEvent) {
/* 1901 */       this.next.handleXMLDeclaration(xmlDeclaration);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1908 */     if ((model == null) || (model.size() == 0)) {
/* 1909 */       return;
/*      */     }
/* 1911 */     if (!this.throttleEngine) {
/* 1912 */       model.process(modelHandler);
/*      */     } else {
/* 1914 */       queueProcessable(new SimpleModelProcessable(model, modelHandler, this.flowController));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void handleProcessingInstruction(IProcessingInstruction iprocessingInstruction)
/*      */   {
/* 1934 */     if ((this.throttleEngine) && (this.flowController.stopProcessing)) {
/* 1935 */       queueEvent(iprocessingInstruction);
/* 1936 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1943 */     if (!this.modelController.shouldProcessProcessingInstruction(iprocessingInstruction)) {
/* 1944 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1951 */     if (this.processingInstructionProcessors.length == 0) {
/* 1952 */       this.next.handleProcessingInstruction(iprocessingInstruction);
/* 1953 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1960 */     ProcessingInstruction processingInstruction = ProcessingInstruction.asEngineProcessingInstruction(iprocessingInstruction);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1966 */     boolean discardEvent = false;
/* 1967 */     Model model = null;
/* 1968 */     ITemplateHandler modelHandler = this;
/* 1969 */     ProcessingInstructionStructureHandler structureHandler = this.processingInstructionStructureHandler;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1975 */     for (int i = 0; (!discardEvent) && (i < this.processingInstructionProcessors.length); i++)
/*      */     {
/* 1977 */       structureHandler.reset();
/*      */       
/* 1979 */       this.processingInstructionProcessors[i].process(this.context, processingInstruction, structureHandler);
/*      */       
/* 1981 */       if (structureHandler.setProcessingInstruction)
/*      */       {
/* 1983 */         processingInstruction = new ProcessingInstruction(structureHandler.setProcessingInstructionTarget, structureHandler.setProcessingInstructionContent);
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/* 1988 */       else if (structureHandler.replaceWithModel)
/*      */       {
/* 1990 */         model = resetModel(model, true);
/* 1991 */         model.addModel(structureHandler.replaceWithModelValue);
/* 1992 */         modelHandler = structureHandler.replaceWithModelProcessable ? this : this.next;
/* 1993 */         discardEvent = true;
/*      */       }
/* 1995 */       else if (structureHandler.removeProcessingInstruction)
/*      */       {
/* 1997 */         model = null;
/* 1998 */         discardEvent = true;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2008 */     if (!discardEvent) {
/* 2009 */       this.next.handleProcessingInstruction(processingInstruction);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2016 */     if ((model == null) || (model.size() == 0)) {
/* 2017 */       return;
/*      */     }
/* 2019 */     if (!this.throttleEngine) {
/* 2020 */       model.process(modelHandler);
/*      */     } else {
/* 2022 */       queueProcessable(new SimpleModelProcessable(model, modelHandler, this.flowController));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void handlePending()
/*      */   {
/* 2042 */     if (this.throttleEngine)
/*      */     {
/* 2044 */       TemplateFlowController controller = this.flowController;
/*      */       
/* 2046 */       if (controller.stopProcessing) {
/* 2047 */         controller.processorTemplateHandlerPending = true;
/* 2048 */         return;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 2053 */       while (this.pendingProcessingsSize > 0) {
/* 2054 */         boolean processed = this.pendingProcessings[(this.pendingProcessingsSize - 1)].process();
/* 2055 */         if (!processed)
/*      */         {
/*      */ 
/* 2058 */           controller.processorTemplateHandlerPending = true;
/* 2059 */           return;
/*      */         }
/* 2061 */         this.pendingProcessingsSize -= 1;
/*      */       }
/*      */       
/*      */ 
/* 2065 */       controller.processorTemplateHandlerPending = false;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void ensurePendingCapacity()
/*      */   {
/* 2078 */     if (this.pendingProcessings == null) {
/* 2079 */       this.pendingProcessings = new IEngineProcessable[5];
/* 2080 */       this.pendingProcessingsSize = 0;
/*      */     }
/* 2082 */     if (this.pendingProcessingsSize == this.pendingProcessings.length) {
/* 2083 */       this.pendingProcessings = ((IEngineProcessable[])Arrays.copyOf(this.pendingProcessings, this.pendingProcessings.length + 5));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void queueProcessable(IEngineProcessable processableModel)
/*      */   {
/* 2094 */     ensurePendingCapacity();
/*      */     
/* 2096 */     TemplateFlowController controller = this.flowController;
/*      */     
/* 2098 */     this.pendingProcessings[this.pendingProcessingsSize] = processableModel;
/* 2099 */     this.pendingProcessingsSize += 1;
/*      */     
/* 2101 */     if (controller.stopProcessing) {
/* 2102 */       controller.processorTemplateHandlerPending = true;
/* 2103 */       return;
/*      */     }
/*      */     
/* 2106 */     boolean processed = this.pendingProcessings[(this.pendingProcessingsSize - 1)].process();
/* 2107 */     if (!processed) {
/* 2108 */       controller.processorTemplateHandlerPending = true;
/* 2109 */       return;
/*      */     }
/* 2111 */     this.pendingProcessingsSize -= 1;
/*      */     
/* 2113 */     controller.processorTemplateHandlerPending = false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void queueEvent(ITemplateEvent event)
/*      */   {
/*      */     SimpleModelProcessable pendingProcessableModel;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2136 */     if (this.pendingProcessingsSize > 0) {
/* 2137 */       IEngineProcessable level0Pending = this.pendingProcessings[0];
/* 2138 */       SimpleModelProcessable pendingProcessableModel; if (((level0Pending instanceof SimpleModelProcessable)) && (((SimpleModelProcessable)level0Pending).getModelHandler() == this)) {
/* 2139 */         pendingProcessableModel = (SimpleModelProcessable)level0Pending;
/*      */       } else {
/* 2141 */         Model model = new Model(this.configuration, this.templateMode);
/* 2142 */         SimpleModelProcessable pendingProcessableModel = new SimpleModelProcessable(model, this, this.flowController);
/* 2143 */         ensurePendingCapacity();
/* 2144 */         System.arraycopy(this.pendingProcessings, 0, this.pendingProcessings, 1, this.pendingProcessingsSize);
/* 2145 */         this.pendingProcessings[0] = pendingProcessableModel;
/* 2146 */         this.pendingProcessingsSize += 1;
/*      */       }
/*      */     } else {
/* 2149 */       Model model = new Model(this.configuration, this.templateMode);
/* 2150 */       pendingProcessableModel = new SimpleModelProcessable(model, this, this.flowController);
/* 2151 */       ensurePendingCapacity();
/* 2152 */       this.pendingProcessings[0] = pendingProcessableModel;
/* 2153 */       this.pendingProcessingsSize += 1;
/*      */     }
/* 2155 */     pendingProcessableModel.getModel().add(event);
/* 2156 */     this.flowController.processorTemplateHandlerPending = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private IGatheringModelProcessable obtainCurrentGatheringModel()
/*      */   {
/* 2167 */     IGatheringModelProcessable gatheringModel = this.currentGatheringModel;
/* 2168 */     this.currentGatheringModel = null;
/* 2169 */     return gatheringModel;
/*      */   }
/*      */   
/*      */   void setCurrentGatheringModel(IGatheringModelProcessable gatheringModel)
/*      */   {
/* 2174 */     this.currentGatheringModel = gatheringModel;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private Model resetModel(Model model, boolean createIfNull)
/*      */   {
/* 2181 */     if (model == null) {
/* 2182 */       if (createIfNull) {
/* 2183 */         return new Model(this.configuration, this.templateMode);
/*      */       }
/* 2185 */       return model;
/*      */     }
/* 2187 */     model.reset();
/* 2188 */     return model;
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\ProcessorTemplateHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */