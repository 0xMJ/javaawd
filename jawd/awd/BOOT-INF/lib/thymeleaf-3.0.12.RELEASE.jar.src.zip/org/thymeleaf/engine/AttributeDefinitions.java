/*      */ package org.thymeleaf.engine;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collections;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.locks.Lock;
/*      */ import java.util.concurrent.locks.ReadWriteLock;
/*      */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*      */ import org.thymeleaf.exceptions.ConfigurationException;
/*      */ import org.thymeleaf.processor.element.IElementProcessor;
/*      */ import org.thymeleaf.processor.element.MatchingAttributeName;
/*      */ import org.thymeleaf.processor.element.MatchingElementName;
/*      */ import org.thymeleaf.templatemode.TemplateMode;
/*      */ import org.thymeleaf.util.TextUtils;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class AttributeDefinitions
/*      */ {
/*      */   public static final Set<String> ALL_STANDARD_HTML_ATTRIBUTE_NAMES;
/*      */   private static final Set<String> ALL_STANDARD_BOOLEAN_HTML_ATTRIBUTE_NAMES;
/*      */   private final AttributeDefinitionRepository htmlAttributeRepository;
/*      */   private final AttributeDefinitionRepository xmlAttributeRepository;
/*      */   private final AttributeDefinitionRepository textAttributeRepository;
/*      */   private final AttributeDefinitionRepository javascriptAttributeRepository;
/*      */   private final AttributeDefinitionRepository cssAttributeRepository;
/*      */   
/*      */   static
/*      */   {
/*   69 */     List<String> htmlAttributeNameListAux = new ArrayList(Arrays.asList(new String[] { "abbr", "accept", "accept-charset", "accesskey", "action", "align", "alt", "archive", "async", "autocomplete", "autofocus", "autoplay", "axis", "border", "cellpadding", "cellspacing", "challenge", "char", "charoff", "charset", "checked", "cite", "class", "classid", "codebase", "codetype", "cols", "colspan", "command", "content", "contenteditable", "contextmenu", "controls", "coords", "data", "datetime", "declare", "default", "defer", "dir", "disabled", "draggable", "dropzone", "enctype", "for", "form", "formaction", "formenctype", "formmethod", "formnovalidate", "formtarget", "frame", "headers", "height", "hidden", "high", "href", "hreflang", "http-equiv", "icon", "id", "ismap", "keytype", "kind", "label", "lang", "list", "longdesc", "loop", "low", "max", "maxlength", "media", "method", "min", "multiple", "muted", "name", "nohref", "novalidate", "nowrap", "onabort", "onafterprint", "onbeforeprint", "onbeforeunload", "onblur", "oncanplay", "oncanplaythrough", "onchange", "onclick", "oncontextmenu", "oncuechange", "ondblclick", "ondrag", "ondragend", "ondragenter", "ondragleave", "ondragover", "ondragstart", "ondrop", "ondurationchange", "onemptied", "onended", "onerror", "onfocus", "onformchange", "onforminput", "onhaschange", "oninput", "oninvalid", "onkeydown", "onkeypress", "onkeyup", "onload", "onloadeddata", "onloadedmetadata", "onloadstart", "onmessage", "onmousedown", "onmousemove", "onmouseout", "onmouseover", "onmouseup", "onmousewheel", "onoffline", "ononline", "onpagehide", "onpageshow", "onpause", "onplay", "onplaying", "onpopstate", "onprogress", "onratechange", "onredo", "onreset", "onresize", "onscroll", "onseeked", "onseeking", "onselect", "onstalled", "onstorage", "onsubmit", "onsuspend", "ontimeupdate", "onundo", "onunload", "onvolumechange", "onwaiting", "open", "optimum", "pattern", "placeholder", "poster", "preload", "profile", "pubdate", "radiogroup", "readonly", "rel", "required", "rev", "reversed", "rows", "rowspan", "rules", "scheme", "scope", "scoped", "seamless", "selected", "shape", "size", "span", "spellcheck", "src", "srclang", "standby", "style", "summary", "tabindex", "title", "translate", "type", "usemap", "valign", "value", "valuetype", "width", "xml:lang", "xml:space", "xmlns" }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  100 */     Collections.sort(htmlAttributeNameListAux);
/*      */     
/*      */ 
/*      */ 
/*  104 */     ALL_STANDARD_HTML_ATTRIBUTE_NAMES = Collections.unmodifiableSet(new LinkedHashSet(htmlAttributeNameListAux));
/*      */     
/*      */ 
/*      */ 
/*  108 */     Set<String> htmlBooleanAttributeNameSetAux = new HashSet(Arrays.asList(new String[] { "async", "autofocus", "autoplay", "checked", "controls", "declare", "default", "defer", "disabled", "formnovalidate", "hidden", "ismap", "loop", "multiple", "novalidate", "nowrap", "open", "pubdate", "readonly", "required", "reversed", "selected", "scoped", "seamless" }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  117 */     ALL_STANDARD_BOOLEAN_HTML_ATTRIBUTE_NAMES = Collections.unmodifiableSet(new LinkedHashSet(htmlBooleanAttributeNameSetAux));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public AttributeDefinitions(Map<TemplateMode, Set<IElementProcessor>> elementProcessorsByTemplateMode)
/*      */   {
/*  144 */     List<HTMLAttributeDefinition> standardHTMLAttributeDefinitions = new ArrayList(ALL_STANDARD_HTML_ATTRIBUTE_NAMES.size() + 1);
/*  145 */     for (String attributeNameStr : ALL_STANDARD_HTML_ATTRIBUTE_NAMES) {
/*  146 */       standardHTMLAttributeDefinitions.add(
/*  147 */         buildHTMLAttributeDefinition(
/*  148 */         AttributeNames.forHTMLName(attributeNameStr), 
/*  149 */         (Set)elementProcessorsByTemplateMode.get(TemplateMode.HTML)));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  156 */     this.htmlAttributeRepository = new AttributeDefinitionRepository(TemplateMode.HTML, elementProcessorsByTemplateMode);
/*  157 */     this.xmlAttributeRepository = new AttributeDefinitionRepository(TemplateMode.XML, elementProcessorsByTemplateMode);
/*  158 */     this.textAttributeRepository = new AttributeDefinitionRepository(TemplateMode.TEXT, elementProcessorsByTemplateMode);
/*  159 */     this.javascriptAttributeRepository = new AttributeDefinitionRepository(TemplateMode.JAVASCRIPT, elementProcessorsByTemplateMode);
/*  160 */     this.cssAttributeRepository = new AttributeDefinitionRepository(TemplateMode.CSS, elementProcessorsByTemplateMode);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  166 */     for (AttributeDefinition attributeDefinition : standardHTMLAttributeDefinitions) {
/*  167 */       this.htmlAttributeRepository.storeStandardAttribute(attributeDefinition);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static HTMLAttributeDefinition buildHTMLAttributeDefinition(HTMLAttributeName name, Set<IElementProcessor> elementProcessors)
/*      */   {
/*  185 */     Set<IElementProcessor> associatedProcessors = new LinkedHashSet(2);
/*      */     Iterator localIterator;
/*  187 */     if (elementProcessors != null) {
/*  188 */       for (localIterator = elementProcessors.iterator(); localIterator.hasNext();) { processor = (IElementProcessor)localIterator.next();
/*      */         
/*      */ 
/*  191 */         templateMode = processor.getTemplateMode();
/*      */         
/*  193 */         if (templateMode == TemplateMode.HTML)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*  198 */           matchingElementName = processor.getMatchingElementName();
/*  199 */           MatchingAttributeName matchingAttributeName = processor.getMatchingAttributeName();
/*      */           
/*  201 */           if (((matchingElementName != null) && (matchingElementName.getTemplateMode() != TemplateMode.HTML)) || ((matchingAttributeName != null) && 
/*  202 */             (matchingAttributeName.getTemplateMode() != TemplateMode.HTML))) {
/*  203 */             throw new ConfigurationException("HTML processors must return HTML element names and HTML attribute names (processor: " + processor.getClass().getName() + ")");
/*      */           }
/*      */           
/*  206 */           if ((matchingAttributeName != null) && (!matchingAttributeName.isMatchingAllAttributes()) && 
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*  211 */             (matchingAttributeName.matches(name)))
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*  216 */             associatedProcessors.add(processor);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  222 */     boolean booleanAttribute = false;
/*  223 */     IElementProcessor processor = name.getCompleteAttributeNames();TemplateMode templateMode = processor.length; for (MatchingElementName matchingElementName = 0; matchingElementName < templateMode; matchingElementName++) { String completeAttributeName = processor[matchingElementName];
/*  224 */       if (ALL_STANDARD_BOOLEAN_HTML_ATTRIBUTE_NAMES.contains(completeAttributeName)) {
/*  225 */         booleanAttribute = true;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  230 */     return new HTMLAttributeDefinition(name, booleanAttribute, associatedProcessors);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static XMLAttributeDefinition buildXMLAttributeDefinition(XMLAttributeName name, Set<IElementProcessor> elementProcessors)
/*      */   {
/*  241 */     Set<IElementProcessor> associatedProcessors = new LinkedHashSet(2);
/*      */     
/*  243 */     if (elementProcessors != null) {
/*  244 */       for (IElementProcessor processor : elementProcessors)
/*      */       {
/*      */ 
/*  247 */         TemplateMode templateMode = processor.getTemplateMode();
/*      */         
/*  249 */         if (templateMode == TemplateMode.XML)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*  254 */           MatchingElementName matchingElementName = processor.getMatchingElementName();
/*  255 */           MatchingAttributeName matchingAttributeName = processor.getMatchingAttributeName();
/*      */           
/*  257 */           if (((matchingElementName != null) && (matchingElementName.getTemplateMode() != TemplateMode.XML)) || ((matchingAttributeName != null) && 
/*  258 */             (matchingAttributeName.getTemplateMode() != TemplateMode.XML))) {
/*  259 */             throw new ConfigurationException("XML processors must return XML element names and XML attribute names (processor: " + processor.getClass().getName() + ")");
/*      */           }
/*      */           
/*  262 */           if ((matchingAttributeName != null) && (!matchingAttributeName.isMatchingAllAttributes()) && 
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*  267 */             (matchingAttributeName.matches(name)))
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*  272 */             associatedProcessors.add(processor);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  278 */     return new XMLAttributeDefinition(name, associatedProcessors);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static TextAttributeDefinition buildTextAttributeDefinition(TemplateMode templateMode, TextAttributeName name, Set<IElementProcessor> elementProcessors)
/*      */   {
/*  289 */     Set<IElementProcessor> associatedProcessors = new LinkedHashSet(2);
/*      */     
/*  291 */     if (elementProcessors != null) {
/*  292 */       for (IElementProcessor processor : elementProcessors)
/*      */       {
/*  294 */         if (processor.getTemplateMode() == templateMode)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*  299 */           MatchingElementName matchingElementName = processor.getMatchingElementName();
/*  300 */           MatchingAttributeName matchingAttributeName = processor.getMatchingAttributeName();
/*      */           
/*  302 */           if (((matchingElementName != null) && (matchingElementName.getTemplateMode() != templateMode)) || ((matchingAttributeName != null) && 
/*  303 */             (matchingAttributeName.getTemplateMode() != templateMode))) {
/*  304 */             throw new ConfigurationException(templateMode + " processors must return " + templateMode + "element names and " + templateMode + " attribute names (processor: " + processor.getClass().getName() + ")");
/*      */           }
/*      */           
/*  307 */           if ((matchingAttributeName != null) && (!matchingAttributeName.isMatchingAllAttributes()) && 
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*  312 */             (matchingAttributeName.matches(name)))
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*  317 */             associatedProcessors.add(processor);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  323 */     return new TextAttributeDefinition(name, associatedProcessors);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public AttributeDefinition forName(TemplateMode templateMode, String attributeName)
/*      */   {
/*  331 */     if (templateMode == null) {
/*  332 */       throw new IllegalArgumentException("Template Mode cannot be null");
/*      */     }
/*  334 */     switch (templateMode) {
/*      */     case HTML: 
/*  336 */       return forHTMLName(attributeName);
/*      */     case XML: 
/*  338 */       return forXMLName(attributeName);
/*      */     case TEXT: 
/*  340 */       return forTextName(attributeName);
/*      */     case JAVASCRIPT: 
/*  342 */       return forJavaScriptName(attributeName);
/*      */     case CSS: 
/*  344 */       return forCSSName(attributeName);
/*      */     case RAW: 
/*  346 */       throw new IllegalArgumentException("Attribute Definitions cannot be obtained for " + templateMode + " template mode ");
/*      */     }
/*  348 */     throw new IllegalArgumentException("Unknown template mode " + templateMode);
/*      */   }
/*      */   
/*      */ 
/*      */   public AttributeDefinition forName(TemplateMode templateMode, String prefix, String attributeName)
/*      */   {
/*  354 */     if (templateMode == null) {
/*  355 */       throw new IllegalArgumentException("Template Mode cannot be null");
/*      */     }
/*  357 */     switch (templateMode) {
/*      */     case HTML: 
/*  359 */       return forHTMLName(prefix, attributeName);
/*      */     case XML: 
/*  361 */       return forXMLName(prefix, attributeName);
/*      */     case TEXT: 
/*  363 */       return forTextName(prefix, attributeName);
/*      */     case JAVASCRIPT: 
/*  365 */       return forJavaScriptName(prefix, attributeName);
/*      */     case CSS: 
/*  367 */       return forCSSName(prefix, attributeName);
/*      */     case RAW: 
/*  369 */       throw new IllegalArgumentException("Attribute Definitions cannot be obtained for " + templateMode + " template mode ");
/*      */     }
/*  371 */     throw new IllegalArgumentException("Unknown template mode " + templateMode);
/*      */   }
/*      */   
/*      */ 
/*      */   public AttributeDefinition forName(TemplateMode templateMode, char[] attributeName, int attributeNameOffset, int attributeNameLen)
/*      */   {
/*  377 */     if (templateMode == null) {
/*  378 */       throw new IllegalArgumentException("Template Mode cannot be null");
/*      */     }
/*  380 */     switch (templateMode) {
/*      */     case HTML: 
/*  382 */       return forHTMLName(attributeName, attributeNameOffset, attributeNameLen);
/*      */     case XML: 
/*  384 */       return forXMLName(attributeName, attributeNameOffset, attributeNameLen);
/*      */     case TEXT: 
/*  386 */       return forTextName(attributeName, attributeNameOffset, attributeNameLen);
/*      */     case JAVASCRIPT: 
/*  388 */       return forJavaScriptName(attributeName, attributeNameOffset, attributeNameLen);
/*      */     case CSS: 
/*  390 */       return forCSSName(attributeName, attributeNameOffset, attributeNameLen);
/*      */     case RAW: 
/*  392 */       throw new IllegalArgumentException("Attribute Definitions cannot be obtained for " + templateMode + " template mode ");
/*      */     }
/*  394 */     throw new IllegalArgumentException("Unknown template mode " + templateMode);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public HTMLAttributeDefinition forHTMLName(String attributeName)
/*      */   {
/*  402 */     if ((attributeName == null) || (attributeName.length() == 0)) {
/*  403 */       throw new IllegalArgumentException("Name cannot be null or empty");
/*      */     }
/*  405 */     return (HTMLAttributeDefinition)this.htmlAttributeRepository.getAttribute(attributeName);
/*      */   }
/*      */   
/*      */   public HTMLAttributeDefinition forHTMLName(String prefix, String attributeName)
/*      */   {
/*  410 */     if ((attributeName == null) || (attributeName.length() == 0)) {
/*  411 */       throw new IllegalArgumentException("Name cannot be null or empty");
/*      */     }
/*  413 */     return (HTMLAttributeDefinition)this.htmlAttributeRepository.getAttribute(prefix, attributeName);
/*      */   }
/*      */   
/*      */   public HTMLAttributeDefinition forHTMLName(char[] attributeName, int attributeNameOffset, int attributeNameLen)
/*      */   {
/*  418 */     if ((attributeName == null) || (attributeNameLen == 0)) {
/*  419 */       throw new IllegalArgumentException("Name cannot be null or empty");
/*      */     }
/*  421 */     if ((attributeNameOffset < 0) || (attributeNameLen < 0)) {
/*  422 */       throw new IllegalArgumentException("Both name offset and length must be equal to or greater than zero");
/*      */     }
/*  424 */     return (HTMLAttributeDefinition)this.htmlAttributeRepository.getAttribute(attributeName, attributeNameOffset, attributeNameLen);
/*      */   }
/*      */   
/*      */ 
/*      */   public XMLAttributeDefinition forXMLName(String attributeName)
/*      */   {
/*  430 */     if ((attributeName == null) || (attributeName.length() == 0)) {
/*  431 */       throw new IllegalArgumentException("Name cannot be null or empty");
/*      */     }
/*  433 */     return (XMLAttributeDefinition)this.xmlAttributeRepository.getAttribute(attributeName);
/*      */   }
/*      */   
/*      */   public XMLAttributeDefinition forXMLName(String prefix, String attributeName)
/*      */   {
/*  438 */     if ((attributeName == null) || (attributeName.length() == 0)) {
/*  439 */       throw new IllegalArgumentException("Name cannot be null or empty");
/*      */     }
/*  441 */     return (XMLAttributeDefinition)this.xmlAttributeRepository.getAttribute(prefix, attributeName);
/*      */   }
/*      */   
/*      */   public XMLAttributeDefinition forXMLName(char[] attributeName, int attributeNameOffset, int attributeNameLen)
/*      */   {
/*  446 */     if ((attributeName == null) || (attributeNameLen == 0)) {
/*  447 */       throw new IllegalArgumentException("Name cannot be null or empty");
/*      */     }
/*  449 */     if ((attributeNameOffset < 0) || (attributeNameLen < 0)) {
/*  450 */       throw new IllegalArgumentException("Both name offset and length must be equal to or greater than zero");
/*      */     }
/*  452 */     return (XMLAttributeDefinition)this.xmlAttributeRepository.getAttribute(attributeName, attributeNameOffset, attributeNameLen);
/*      */   }
/*      */   
/*      */ 
/*      */   public TextAttributeDefinition forTextName(String attributeName)
/*      */   {
/*  458 */     if ((attributeName == null) || (attributeName.length() == 0)) {
/*  459 */       throw new IllegalArgumentException("Name cannot be null or empty");
/*      */     }
/*  461 */     return (TextAttributeDefinition)this.textAttributeRepository.getAttribute(attributeName);
/*      */   }
/*      */   
/*      */   public TextAttributeDefinition forTextName(String prefix, String attributeName)
/*      */   {
/*  466 */     if ((attributeName == null) || (attributeName.length() == 0)) {
/*  467 */       throw new IllegalArgumentException("Name cannot be null or empty");
/*      */     }
/*  469 */     return (TextAttributeDefinition)this.textAttributeRepository.getAttribute(prefix, attributeName);
/*      */   }
/*      */   
/*      */   public TextAttributeDefinition forTextName(char[] attributeName, int attributeNameOffset, int attributeNameLen)
/*      */   {
/*  474 */     if ((attributeName == null) || (attributeNameLen == 0)) {
/*  475 */       throw new IllegalArgumentException("Name cannot be null or empty");
/*      */     }
/*  477 */     if ((attributeNameOffset < 0) || (attributeNameLen < 0)) {
/*  478 */       throw new IllegalArgumentException("Both name offset and length must be equal to or greater than zero");
/*      */     }
/*  480 */     return (TextAttributeDefinition)this.textAttributeRepository.getAttribute(attributeName, attributeNameOffset, attributeNameLen);
/*      */   }
/*      */   
/*      */ 
/*      */   public TextAttributeDefinition forJavaScriptName(String attributeName)
/*      */   {
/*  486 */     if ((attributeName == null) || (attributeName.length() == 0)) {
/*  487 */       throw new IllegalArgumentException("Name cannot be null or empty");
/*      */     }
/*  489 */     return (TextAttributeDefinition)this.javascriptAttributeRepository.getAttribute(attributeName);
/*      */   }
/*      */   
/*      */   public TextAttributeDefinition forJavaScriptName(String prefix, String attributeName)
/*      */   {
/*  494 */     if ((attributeName == null) || (attributeName.length() == 0)) {
/*  495 */       throw new IllegalArgumentException("Name cannot be null or empty");
/*      */     }
/*  497 */     return (TextAttributeDefinition)this.javascriptAttributeRepository.getAttribute(prefix, attributeName);
/*      */   }
/*      */   
/*      */   public TextAttributeDefinition forJavaScriptName(char[] attributeName, int attributeNameOffset, int attributeNameLen)
/*      */   {
/*  502 */     if ((attributeName == null) || (attributeNameLen == 0)) {
/*  503 */       throw new IllegalArgumentException("Name cannot be null or empty");
/*      */     }
/*  505 */     if ((attributeNameOffset < 0) || (attributeNameLen < 0)) {
/*  506 */       throw new IllegalArgumentException("Both name offset and length must be equal to or greater than zero");
/*      */     }
/*  508 */     return (TextAttributeDefinition)this.javascriptAttributeRepository.getAttribute(attributeName, attributeNameOffset, attributeNameLen);
/*      */   }
/*      */   
/*      */ 
/*      */   public TextAttributeDefinition forCSSName(String attributeName)
/*      */   {
/*  514 */     if ((attributeName == null) || (attributeName.length() == 0)) {
/*  515 */       throw new IllegalArgumentException("Name cannot be null or empty");
/*      */     }
/*  517 */     return (TextAttributeDefinition)this.cssAttributeRepository.getAttribute(attributeName);
/*      */   }
/*      */   
/*      */   public TextAttributeDefinition forCSSName(String prefix, String attributeName)
/*      */   {
/*  522 */     if ((attributeName == null) || (attributeName.length() == 0)) {
/*  523 */       throw new IllegalArgumentException("Name cannot be null or empty");
/*      */     }
/*  525 */     return (TextAttributeDefinition)this.cssAttributeRepository.getAttribute(prefix, attributeName);
/*      */   }
/*      */   
/*      */   public TextAttributeDefinition forCSSName(char[] attributeName, int attributeNameOffset, int attributeNameLen)
/*      */   {
/*  530 */     if ((attributeName == null) || (attributeNameLen == 0)) {
/*  531 */       throw new IllegalArgumentException("Name cannot be null or empty");
/*      */     }
/*  533 */     if ((attributeNameOffset < 0) || (attributeNameLen < 0)) {
/*  534 */       throw new IllegalArgumentException("Both name offset and length must be equal to or greater than zero");
/*      */     }
/*  536 */     return (TextAttributeDefinition)this.cssAttributeRepository.getAttribute(attributeName, attributeNameOffset, attributeNameLen);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   static final class AttributeDefinitionRepository
/*      */   {
/*      */     private final TemplateMode templateMode;
/*      */     
/*      */ 
/*      */     private final Map<TemplateMode, Set<IElementProcessor>> elementProcessorsByTemplateMode;
/*      */     
/*      */ 
/*      */     private final List<String> standardRepositoryNames;
/*      */     
/*      */ 
/*      */     private final List<AttributeDefinition> standardRepository;
/*      */     
/*      */ 
/*      */     private final List<String> repositoryNames;
/*      */     
/*      */ 
/*      */     private final List<AttributeDefinition> repository;
/*      */     
/*      */ 
/*  562 */     private final ReadWriteLock lock = new ReentrantReadWriteLock(true);
/*  563 */     private final Lock readLock = this.lock.readLock();
/*  564 */     private final Lock writeLock = this.lock.writeLock();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     AttributeDefinitionRepository(TemplateMode templateMode, Map<TemplateMode, Set<IElementProcessor>> elementProcessorsByTemplateMode)
/*      */     {
/*  571 */       this.templateMode = templateMode;
/*  572 */       this.elementProcessorsByTemplateMode = elementProcessorsByTemplateMode;
/*      */       
/*  574 */       this.standardRepositoryNames = (templateMode == TemplateMode.HTML ? new ArrayList(150) : null);
/*  575 */       this.standardRepository = (templateMode == TemplateMode.HTML ? new ArrayList(150) : null);
/*      */       
/*  577 */       this.repositoryNames = new ArrayList(500);
/*  578 */       this.repository = new ArrayList(500);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     AttributeDefinition getAttribute(char[] text, int offset, int len)
/*      */     {
/*  587 */       if (this.standardRepository != null)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*  592 */         int index = binarySearch(this.templateMode.isCaseSensitive(), this.standardRepositoryNames, text, offset, len);
/*      */         
/*  594 */         if (index >= 0) {
/*  595 */           return (AttributeDefinition)this.standardRepository.get(index);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  604 */       this.readLock.lock();
/*      */       
/*      */       AttributeDefinition localAttributeDefinition;
/*      */       
/*      */       try
/*      */       {
/*  610 */         int index = binarySearch(this.templateMode.isCaseSensitive(), this.repositoryNames, text, offset, len);
/*      */         
/*  612 */         if (index >= 0) {
/*  613 */           return (AttributeDefinition)this.repository.get(index);
/*      */         }
/*      */       }
/*      */       finally {
/*  617 */         this.readLock.unlock();
/*      */       }
/*      */       
/*      */ 
/*      */       int index;
/*      */       
/*      */ 
/*  624 */       this.writeLock.lock();
/*      */       try {
/*  626 */         return storeAttribute(text, offset, len);
/*      */       } finally {
/*  628 */         this.writeLock.unlock();
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     AttributeDefinition getAttribute(String completeAttributeName)
/*      */     {
/*  638 */       if (this.standardRepository != null)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*  643 */         int index = binarySearch(this.templateMode.isCaseSensitive(), this.standardRepositoryNames, completeAttributeName);
/*      */         
/*  645 */         if (index >= 0) {
/*  646 */           return (AttributeDefinition)this.standardRepository.get(index);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  655 */       this.readLock.lock();
/*      */       
/*      */       AttributeDefinition localAttributeDefinition;
/*      */       
/*      */       try
/*      */       {
/*  661 */         int index = binarySearch(this.templateMode.isCaseSensitive(), this.repositoryNames, completeAttributeName);
/*      */         
/*  663 */         if (index >= 0) {
/*  664 */           return (AttributeDefinition)this.repository.get(index);
/*      */         }
/*      */       }
/*      */       finally {
/*  668 */         this.readLock.unlock();
/*      */       }
/*      */       
/*      */ 
/*      */       int index;
/*      */       
/*      */ 
/*  675 */       this.writeLock.lock();
/*      */       try {
/*  677 */         return storeAttribute(completeAttributeName);
/*      */       } finally {
/*  679 */         this.writeLock.unlock();
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     AttributeDefinition getAttribute(String prefix, String attributeName)
/*      */     {
/*  689 */       if (this.standardRepository != null)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*  694 */         int index = binarySearch(this.templateMode.isCaseSensitive(), this.standardRepositoryNames, prefix, attributeName);
/*      */         
/*  696 */         if (index >= 0) {
/*  697 */           return (AttributeDefinition)this.standardRepository.get(index);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  706 */       this.readLock.lock();
/*      */       
/*      */       AttributeDefinition localAttributeDefinition;
/*      */       
/*      */       try
/*      */       {
/*  712 */         int index = binarySearch(this.templateMode.isCaseSensitive(), this.repositoryNames, prefix, attributeName);
/*      */         
/*  714 */         if (index >= 0) {
/*  715 */           return (AttributeDefinition)this.repository.get(index);
/*      */         }
/*      */       }
/*      */       finally {
/*  719 */         this.readLock.unlock();
/*      */       }
/*      */       
/*      */ 
/*      */       int index;
/*      */       
/*      */ 
/*  726 */       this.writeLock.lock();
/*      */       try {
/*  728 */         return storeAttribute(prefix, attributeName);
/*      */       } finally {
/*  730 */         this.writeLock.unlock();
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     private AttributeDefinition storeAttribute(char[] text, int offset, int len)
/*      */     {
/*  738 */       int index = binarySearch(this.templateMode.isCaseSensitive(), this.repositoryNames, text, offset, len);
/*  739 */       if (index >= 0)
/*      */       {
/*  741 */         return (AttributeDefinition)this.repository.get(index);
/*      */       }
/*      */       
/*  744 */       Set<IElementProcessor> elementProcessors = (Set)this.elementProcessorsByTemplateMode.get(this.templateMode);
/*      */       AttributeDefinition attributeDefinition;
/*      */       AttributeDefinition attributeDefinition;
/*  747 */       if (this.templateMode == TemplateMode.HTML)
/*      */       {
/*  749 */         attributeDefinition = AttributeDefinitions.buildHTMLAttributeDefinition(AttributeNames.forHTMLName(text, offset, len), elementProcessors); } else { AttributeDefinition attributeDefinition;
/*  750 */         if (this.templateMode == TemplateMode.XML)
/*      */         {
/*  752 */           attributeDefinition = AttributeDefinitions.buildXMLAttributeDefinition(AttributeNames.forXMLName(text, offset, len), elementProcessors);
/*      */         }
/*      */         else {
/*  755 */           attributeDefinition = AttributeDefinitions.buildTextAttributeDefinition(this.templateMode, AttributeNames.forTextName(text, offset, len), elementProcessors);
/*      */         }
/*      */       }
/*  758 */       String[] completeAttributeNames = attributeDefinition.attributeName.completeAttributeNames;
/*      */       
/*  760 */       for (String completeAttributeName : completeAttributeNames)
/*      */       {
/*  762 */         index = binarySearch(this.templateMode.isCaseSensitive(), this.repositoryNames, completeAttributeName);
/*      */         
/*      */ 
/*  765 */         this.repositoryNames.add((index + 1) * -1, completeAttributeName);
/*  766 */         this.repository.add((index + 1) * -1, attributeDefinition);
/*      */       }
/*      */       
/*      */ 
/*  770 */       return attributeDefinition;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     private AttributeDefinition storeAttribute(String attributeName)
/*      */     {
/*  777 */       int index = binarySearch(this.templateMode.isCaseSensitive(), this.repositoryNames, attributeName);
/*  778 */       if (index >= 0)
/*      */       {
/*  780 */         return (AttributeDefinition)this.repository.get(index);
/*      */       }
/*      */       
/*  783 */       Set<IElementProcessor> elementProcessors = (Set)this.elementProcessorsByTemplateMode.get(this.templateMode);
/*      */       AttributeDefinition attributeDefinition;
/*      */       AttributeDefinition attributeDefinition;
/*  786 */       if (this.templateMode == TemplateMode.HTML)
/*      */       {
/*  788 */         attributeDefinition = AttributeDefinitions.buildHTMLAttributeDefinition(AttributeNames.forHTMLName(attributeName), elementProcessors); } else { AttributeDefinition attributeDefinition;
/*  789 */         if (this.templateMode == TemplateMode.XML)
/*      */         {
/*  791 */           attributeDefinition = AttributeDefinitions.buildXMLAttributeDefinition(AttributeNames.forXMLName(attributeName), elementProcessors);
/*      */         }
/*      */         else {
/*  794 */           attributeDefinition = AttributeDefinitions.buildTextAttributeDefinition(this.templateMode, AttributeNames.forTextName(attributeName), elementProcessors);
/*      */         }
/*      */       }
/*  797 */       String[] completeAttributeNames = attributeDefinition.attributeName.completeAttributeNames;
/*      */       
/*  799 */       for (String completeAttributeName : completeAttributeNames)
/*      */       {
/*  801 */         index = binarySearch(this.templateMode.isCaseSensitive(), this.repositoryNames, completeAttributeName);
/*      */         
/*      */ 
/*  804 */         this.repositoryNames.add((index + 1) * -1, completeAttributeName);
/*  805 */         this.repository.add((index + 1) * -1, attributeDefinition);
/*      */       }
/*      */       
/*      */ 
/*  809 */       return attributeDefinition;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     private AttributeDefinition storeAttribute(String prefix, String attributeName)
/*      */     {
/*  816 */       int index = binarySearch(this.templateMode.isCaseSensitive(), this.repositoryNames, prefix, attributeName);
/*  817 */       if (index >= 0)
/*      */       {
/*  819 */         return (AttributeDefinition)this.repository.get(index);
/*      */       }
/*      */       
/*  822 */       Set<IElementProcessor> elementProcessors = (Set)this.elementProcessorsByTemplateMode.get(this.templateMode);
/*      */       AttributeDefinition attributeDefinition;
/*      */       AttributeDefinition attributeDefinition;
/*  825 */       if (this.templateMode == TemplateMode.HTML)
/*      */       {
/*  827 */         attributeDefinition = AttributeDefinitions.buildHTMLAttributeDefinition(AttributeNames.forHTMLName(prefix, attributeName), elementProcessors); } else { AttributeDefinition attributeDefinition;
/*  828 */         if (this.templateMode == TemplateMode.XML)
/*      */         {
/*  830 */           attributeDefinition = AttributeDefinitions.buildXMLAttributeDefinition(AttributeNames.forXMLName(prefix, attributeName), elementProcessors);
/*      */         }
/*      */         else {
/*  833 */           attributeDefinition = AttributeDefinitions.buildTextAttributeDefinition(this.templateMode, AttributeNames.forTextName(prefix, attributeName), elementProcessors);
/*      */         }
/*      */       }
/*  836 */       String[] completeAttributeNames = attributeDefinition.attributeName.completeAttributeNames;
/*      */       
/*  838 */       for (String completeAttributeName : completeAttributeNames)
/*      */       {
/*  840 */         index = binarySearch(this.templateMode.isCaseSensitive(), this.repositoryNames, completeAttributeName);
/*      */         
/*      */ 
/*  843 */         this.repositoryNames.add((index + 1) * -1, completeAttributeName);
/*  844 */         this.repository.add((index + 1) * -1, attributeDefinition);
/*      */       }
/*      */       
/*      */ 
/*  848 */       return attributeDefinition;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private AttributeDefinition storeStandardAttribute(AttributeDefinition attributeDefinition)
/*      */     {
/*  858 */       String[] completeAttributeNames = attributeDefinition.attributeName.completeAttributeNames;
/*      */       
/*      */ 
/*  861 */       for (String completeAttributeName : completeAttributeNames)
/*      */       {
/*  863 */         int index = binarySearch(this.templateMode.isCaseSensitive(), this.standardRepositoryNames, completeAttributeName);
/*      */         
/*      */ 
/*  866 */         this.standardRepositoryNames.add((index + 1) * -1, completeAttributeName);
/*  867 */         this.standardRepository.add((index + 1) * -1, attributeDefinition);
/*      */         
/*  869 */         index = binarySearch(this.templateMode.isCaseSensitive(), this.repositoryNames, completeAttributeName);
/*      */         
/*      */ 
/*  872 */         this.repositoryNames.add((index + 1) * -1, completeAttributeName);
/*  873 */         this.repository.add((index + 1) * -1, attributeDefinition);
/*      */       }
/*      */       
/*      */ 
/*  877 */       return attributeDefinition;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private static int binarySearch(boolean caseSensitive, List<String> values, char[] text, int offset, int len)
/*      */     {
/*  885 */       int low = 0;
/*  886 */       int high = values.size() - 1;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  891 */       while (low <= high)
/*      */       {
/*  893 */         int mid = low + high >>> 1;
/*  894 */         String midVal = (String)values.get(mid);
/*      */         
/*  896 */         int cmp = TextUtils.compareTo(caseSensitive, midVal, 0, midVal.length(), text, offset, len);
/*      */         
/*  898 */         if (cmp < 0) {
/*  899 */           low = mid + 1;
/*  900 */         } else if (cmp > 0) {
/*  901 */           high = mid - 1;
/*      */         }
/*      */         else {
/*  904 */           return mid;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*  909 */       return -(low + 1);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     private static int binarySearch(boolean caseSensitive, List<String> values, String text)
/*      */     {
/*  916 */       int low = 0;
/*  917 */       int high = values.size() - 1;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  922 */       while (low <= high)
/*      */       {
/*  924 */         int mid = low + high >>> 1;
/*  925 */         String midVal = (String)values.get(mid);
/*      */         
/*  927 */         int cmp = TextUtils.compareTo(caseSensitive, midVal, text);
/*      */         
/*  929 */         if (cmp < 0) {
/*  930 */           low = mid + 1;
/*  931 */         } else if (cmp > 0) {
/*  932 */           high = mid - 1;
/*      */         }
/*      */         else {
/*  935 */           return mid;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*  940 */       return -(low + 1);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private static int binarySearch(boolean caseSensitive, List<String> values, String prefix, String attributeName)
/*      */     {
/*  950 */       if ((prefix == null) || (prefix.trim().length() == 0)) {
/*  951 */         return binarySearch(caseSensitive, values, attributeName);
/*      */       }
/*      */       
/*  954 */       int prefixLen = prefix.length();
/*  955 */       int attributeNameLen = attributeName.length();
/*      */       
/*  957 */       int low = 0;
/*  958 */       int high = values.size() - 1;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  964 */       while (low <= high)
/*      */       {
/*  966 */         int mid = low + high >>> 1;
/*  967 */         String midVal = (String)values.get(mid);
/*  968 */         int midValLen = midVal.length();
/*      */         
/*  970 */         if (TextUtils.startsWith(caseSensitive, midVal, prefix))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*  975 */           if (midValLen <= prefixLen)
/*      */           {
/*      */ 
/*  978 */             low = mid + 1;
/*      */ 
/*      */           }
/*      */           else
/*      */           {
/*  983 */             int cmp = midVal.charAt(prefixLen) - ':';
/*      */             
/*  985 */             if (cmp < 0) {
/*  986 */               low = mid + 1;
/*  987 */             } else if (cmp > 0) {
/*  988 */               high = mid - 1;
/*      */             }
/*      */             else
/*      */             {
/*  992 */               cmp = TextUtils.compareTo(caseSensitive, midVal, prefixLen + 1, midValLen - (prefixLen + 1), attributeName, 0, attributeNameLen);
/*      */               
/*  994 */               if (cmp < 0) {
/*  995 */                 low = mid + 1;
/*  996 */               } else if (cmp > 0) {
/*  997 */                 high = mid - 1;
/*      */               }
/*      */               else {
/* 1000 */                 return mid;
/*      */               }
/*      */               
/*      */             }
/*      */             
/*      */           }
/*      */           
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/* 1011 */           int cmp = TextUtils.compareTo(caseSensitive, midVal, prefix);
/*      */           
/* 1013 */           if (cmp < 0) {
/* 1014 */             low = mid + 1;
/* 1015 */           } else if (cmp > 0) {
/* 1016 */             high = mid - 1;
/*      */           }
/*      */           else {
/* 1019 */             throw new IllegalStateException("Bad comparison of midVal \"" + midVal + "\" and prefix \"" + prefix + "\"");
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1026 */       return -(low + 1);
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\AttributeDefinitions.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */