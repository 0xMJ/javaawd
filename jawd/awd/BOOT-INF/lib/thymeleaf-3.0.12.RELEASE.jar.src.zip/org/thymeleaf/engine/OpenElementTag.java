/*     */ package org.thymeleaf.engine;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import java.util.Arrays;
/*     */ import org.thymeleaf.model.AttributeValueQuotes;
/*     */ import org.thymeleaf.model.IAttribute;
/*     */ import org.thymeleaf.model.IModelVisitor;
/*     */ import org.thymeleaf.model.IOpenElementTag;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class OpenElementTag
/*     */   extends AbstractProcessableElementTag
/*     */   implements IOpenElementTag, IEngineTemplateEvent
/*     */ {
/*     */   OpenElementTag(TemplateMode templateMode, ElementDefinition elementDefinition, String elementCompleteName, Attributes attributes, boolean synthetic)
/*     */   {
/*  51 */     super(templateMode, elementDefinition, elementCompleteName, attributes, synthetic);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   OpenElementTag(TemplateMode templateMode, ElementDefinition elementDefinition, String elementCompleteName, Attributes attributes, boolean synthetic, String templateName, int line, int col)
/*     */   {
/*  64 */     super(templateMode, elementDefinition, elementCompleteName, attributes, synthetic, templateName, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   OpenElementTag setAttribute(AttributeDefinitions attributeDefinitions, AttributeDefinition attributeDefinition, String completeName, String value, AttributeValueQuotes valueQuotes)
/*     */   {
/*  74 */     Attributes oldAttributes = this.attributes != null ? this.attributes : Attributes.EMPTY_ATTRIBUTES;
/*     */     
/*  76 */     Attributes newAttributes = oldAttributes.setAttribute(attributeDefinitions, this.templateMode, attributeDefinition, completeName, value, valueQuotes);
/*  77 */     return new OpenElementTag(this.templateMode, this.elementDefinition, this.elementCompleteName, newAttributes, this.synthetic, this.templateName, this.line, this.col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   OpenElementTag replaceAttribute(AttributeDefinitions attributeDefinitions, AttributeName oldName, AttributeDefinition newAttributeDefinition, String completeNewName, String value, AttributeValueQuotes valueQuotes)
/*     */   {
/*  87 */     Attributes oldAttributes = this.attributes != null ? this.attributes : Attributes.EMPTY_ATTRIBUTES;
/*     */     
/*  89 */     Attributes newAttributes = oldAttributes.replaceAttribute(attributeDefinitions, this.templateMode, oldName, newAttributeDefinition, completeNewName, value, valueQuotes);
/*  90 */     return new OpenElementTag(this.templateMode, this.elementDefinition, this.elementCompleteName, newAttributes, this.synthetic, this.templateName, this.line, this.col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   OpenElementTag removeAttribute(String prefix, String name)
/*     */   {
/*  97 */     Attributes oldAttributes = this.attributes != null ? this.attributes : Attributes.EMPTY_ATTRIBUTES;
/*  98 */     Attributes newAttributes = oldAttributes.removeAttribute(this.templateMode, prefix, name);
/*  99 */     if (oldAttributes == newAttributes) {
/* 100 */       return this;
/*     */     }
/* 102 */     return new OpenElementTag(this.templateMode, this.elementDefinition, this.elementCompleteName, newAttributes, this.synthetic, this.templateName, this.line, this.col);
/*     */   }
/*     */   
/*     */   OpenElementTag removeAttribute(String completeName)
/*     */   {
/* 107 */     Attributes oldAttributes = this.attributes != null ? this.attributes : Attributes.EMPTY_ATTRIBUTES;
/* 108 */     Attributes newAttributes = oldAttributes.removeAttribute(this.templateMode, completeName);
/* 109 */     if (oldAttributes == newAttributes) {
/* 110 */       return this;
/*     */     }
/* 112 */     return new OpenElementTag(this.templateMode, this.elementDefinition, this.elementCompleteName, newAttributes, this.synthetic, this.templateName, this.line, this.col);
/*     */   }
/*     */   
/*     */   OpenElementTag removeAttribute(AttributeName attributeName)
/*     */   {
/* 117 */     Attributes oldAttributes = this.attributes != null ? this.attributes : Attributes.EMPTY_ATTRIBUTES;
/* 118 */     Attributes newAttributes = oldAttributes.removeAttribute(attributeName);
/* 119 */     if (oldAttributes == newAttributes) {
/* 120 */       return this;
/*     */     }
/* 122 */     return new OpenElementTag(this.templateMode, this.elementDefinition, this.elementCompleteName, newAttributes, this.synthetic, this.templateName, this.line, this.col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void accept(IModelVisitor visitor)
/*     */   {
/* 129 */     visitor.visit(this);
/*     */   }
/*     */   
/*     */   public void write(Writer writer) throws IOException
/*     */   {
/* 134 */     if (this.synthetic)
/*     */     {
/* 136 */       return;
/*     */     }
/* 138 */     if (this.templateMode.isText()) {
/* 139 */       writer.write("[#");
/* 140 */       writer.write(this.elementCompleteName);
/* 141 */       if (this.attributes != null) {
/* 142 */         this.attributes.write(writer);
/*     */       }
/* 144 */       writer.write("]");
/* 145 */       return;
/*     */     }
/* 147 */     writer.write(60);
/* 148 */     writer.write(this.elementCompleteName);
/* 149 */     if (this.attributes != null) {
/* 150 */       this.attributes.write(writer);
/*     */     }
/* 152 */     writer.write(62);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static OpenElementTag asEngineOpenElementTag(IOpenElementTag openElementTag)
/*     */   {
/* 161 */     if ((openElementTag instanceof OpenElementTag)) {
/* 162 */       return (OpenElementTag)openElementTag;
/*     */     }
/*     */     
/*     */ 
/* 166 */     IAttribute[] originalAttributeArray = openElementTag.getAllAttributes();
/*     */     Attributes attributes;
/*     */     Attributes attributes;
/* 169 */     if ((originalAttributeArray == null) || (originalAttributeArray.length == 0)) {
/* 170 */       attributes = null;
/*     */     }
/*     */     else
/*     */     {
/* 174 */       Attribute[] newAttributeArray = new Attribute[originalAttributeArray.length];
/* 175 */       for (int i = 0; i < originalAttributeArray.length; i++) {
/* 176 */         IAttribute originalAttribute = originalAttributeArray[i];
/* 177 */         newAttributeArray[i] = new Attribute(originalAttribute
/*     */         
/* 179 */           .getAttributeDefinition(), originalAttribute.getAttributeCompleteName(), originalAttribute
/* 180 */           .getOperator(), originalAttribute.getValue(), originalAttribute.getValueQuotes(), originalAttribute
/* 181 */           .getTemplateName(), originalAttribute.getLine(), originalAttribute.getCol()); }
/*     */       String[] newInnerWhiteSpaces;
/*     */       String[] newInnerWhiteSpaces;
/* 184 */       if (newAttributeArray.length == 1) {
/* 185 */         newInnerWhiteSpaces = Attributes.DEFAULT_WHITE_SPACE_ARRAY;
/*     */       } else {
/* 187 */         newInnerWhiteSpaces = new String[newAttributeArray.length];
/* 188 */         Arrays.fill(newInnerWhiteSpaces, " ");
/*     */       }
/* 190 */       attributes = new Attributes(newAttributeArray, newInnerWhiteSpaces);
/*     */     }
/*     */     
/* 193 */     return new OpenElementTag(openElementTag
/* 194 */       .getTemplateMode(), openElementTag.getElementDefinition(), openElementTag.getElementCompleteName(), attributes, openElementTag
/* 195 */       .isSynthetic(), openElementTag
/* 196 */       .getTemplateName(), openElementTag.getLine(), openElementTag.getCol());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void beHandled(ITemplateHandler handler)
/*     */   {
/* 205 */     handler.handleOpenElement(this);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\OpenElementTag.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */