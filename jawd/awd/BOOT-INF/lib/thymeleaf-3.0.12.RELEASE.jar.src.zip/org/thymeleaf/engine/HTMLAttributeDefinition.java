/*    */ package org.thymeleaf.engine;
/*    */ 
/*    */ import java.util.Set;
/*    */ import org.thymeleaf.processor.element.IElementProcessor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class HTMLAttributeDefinition
/*    */   extends AttributeDefinition
/*    */ {
/*    */   final boolean booleanAttribute;
/*    */   
/*    */   HTMLAttributeDefinition(HTMLAttributeName name, boolean booleanAttribute, Set<IElementProcessor> associatedProcessors)
/*    */   {
/* 40 */     super(name, associatedProcessors);
/*    */     
/* 42 */     this.booleanAttribute = booleanAttribute;
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean isBooleanAttribute()
/*    */   {
/* 48 */     return this.booleanAttribute;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\HTMLAttributeDefinition.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */