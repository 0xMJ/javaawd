/*     */ package org.thymeleaf.engine;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.thymeleaf.context.IEngineContext;
/*     */ import org.thymeleaf.inline.IInliner;
/*     */ import org.thymeleaf.processor.element.IElementModelStructureHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ElementModelStructureHandler
/*     */   implements IElementModelStructureHandler
/*     */ {
/*     */   boolean setLocalVariable;
/*     */   Map<String, Object> addedLocalVariables;
/*     */   boolean removeLocalVariable;
/*     */   Set<String> removedLocalVariableNames;
/*     */   boolean setSelectionTarget;
/*     */   Object selectionTargetObject;
/*     */   boolean setInliner;
/*     */   IInliner setInlinerValue;
/*     */   boolean setTemplateData;
/*     */   TemplateData setTemplateDataValue;
/*     */   
/*     */   ElementModelStructureHandler()
/*     */   {
/*  66 */     reset();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void removeLocalVariable(String name)
/*     */   {
/*  73 */     this.removeLocalVariable = true;
/*  74 */     if (this.removedLocalVariableNames == null) {
/*  75 */       this.removedLocalVariableNames = new HashSet(3);
/*     */     }
/*  77 */     this.removedLocalVariableNames.add(name);
/*     */   }
/*     */   
/*     */ 
/*     */   public void setLocalVariable(String name, Object value)
/*     */   {
/*  83 */     this.setLocalVariable = true;
/*  84 */     if (this.addedLocalVariables == null) {
/*  85 */       this.addedLocalVariables = new HashMap(3);
/*     */     }
/*  87 */     this.addedLocalVariables.put(name, value);
/*     */   }
/*     */   
/*     */ 
/*     */   public void setSelectionTarget(Object selectionTarget)
/*     */   {
/*  93 */     this.setSelectionTarget = true;
/*  94 */     this.selectionTargetObject = selectionTarget;
/*     */   }
/*     */   
/*     */   public void setInliner(IInliner inliner)
/*     */   {
/*  99 */     this.setInliner = true;
/* 100 */     this.setInlinerValue = inliner;
/*     */   }
/*     */   
/*     */   public void setTemplateData(TemplateData templateData)
/*     */   {
/* 105 */     this.setTemplateData = true;
/* 106 */     this.setTemplateDataValue = templateData;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void reset()
/*     */   {
/* 114 */     this.setLocalVariable = false;
/* 115 */     if ((this.addedLocalVariables != null) && (this.addedLocalVariables.size() > 0)) {
/* 116 */       this.addedLocalVariables.clear();
/*     */     }
/*     */     
/* 119 */     this.removeLocalVariable = false;
/* 120 */     if ((this.removedLocalVariableNames != null) && (this.removedLocalVariableNames.size() > 0)) {
/* 121 */       this.removedLocalVariableNames.clear();
/*     */     }
/*     */     
/* 124 */     this.setSelectionTarget = false;
/* 125 */     this.selectionTargetObject = null;
/*     */     
/* 127 */     this.setInliner = false;
/* 128 */     this.setInlinerValue = null;
/*     */     
/* 130 */     this.setTemplateData = false;
/* 131 */     this.setTemplateDataValue = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void applyContextModifications(IEngineContext engineContext)
/*     */   {
/* 140 */     if (engineContext == null) {
/* 141 */       return;
/*     */     }
/*     */     
/* 144 */     if (this.setLocalVariable) {
/* 145 */       engineContext.setVariables(this.addedLocalVariables);
/*     */     }
/*     */     
/* 148 */     if (this.removeLocalVariable) {
/* 149 */       for (String variableName : this.removedLocalVariableNames) {
/* 150 */         engineContext.removeVariable(variableName);
/*     */       }
/*     */     }
/*     */     
/* 154 */     if (this.setSelectionTarget) {
/* 155 */       engineContext.setSelectionTarget(this.selectionTargetObject);
/*     */     }
/*     */     
/* 158 */     if (this.setInliner) {
/* 159 */       engineContext.setInliner(this.setInlinerValue);
/*     */     }
/*     */     
/* 162 */     if (this.setTemplateData) {
/* 163 */       engineContext.setTemplateData(this.setTemplateDataValue);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\ElementModelStructureHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */