/*     */ package org.thymeleaf.engine;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Set;
/*     */ import org.thymeleaf.processor.element.IElementProcessor;
/*     */ import org.thymeleaf.util.ProcessorComparators;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AttributeDefinition
/*     */ {
/*     */   final AttributeName attributeName;
/*     */   private final Set<IElementProcessor> associatedProcessorsSet;
/*     */   final IElementProcessor[] associatedProcessors;
/*     */   final boolean hasAssociatedProcessors;
/*     */   
/*     */   AttributeDefinition(AttributeName attributeName, Set<IElementProcessor> associatedProcessors)
/*     */   {
/*  48 */     if (attributeName == null) {
/*  49 */       throw new IllegalArgumentException("Attribute name cannot be null");
/*     */     }
/*  51 */     if (associatedProcessors == null) {
/*  52 */       throw new IllegalArgumentException("Associated processors cannot be null");
/*     */     }
/*     */     
/*  55 */     this.attributeName = attributeName;
/*  56 */     this.associatedProcessorsSet = Collections.unmodifiableSet(associatedProcessors);
/*  57 */     this.associatedProcessors = new IElementProcessor[this.associatedProcessorsSet.size()];
/*  58 */     int i = 0;
/*  59 */     for (IElementProcessor processor : this.associatedProcessorsSet) {
/*  60 */       this.associatedProcessors[(i++)] = processor;
/*     */     }
/*  62 */     Arrays.sort(this.associatedProcessors, ProcessorComparators.PROCESSOR_COMPARATOR);
/*  63 */     this.hasAssociatedProcessors = (this.associatedProcessors.length > 0);
/*     */   }
/*     */   
/*     */ 
/*     */   public final AttributeName getAttributeName()
/*     */   {
/*  69 */     return this.attributeName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean hasAssociatedProcessors()
/*     */   {
/*  76 */     return this.hasAssociatedProcessors;
/*     */   }
/*     */   
/*     */ 
/*     */   public Set<IElementProcessor> getAssociatedProcessors()
/*     */   {
/*  82 */     return this.associatedProcessorsSet;
/*     */   }
/*     */   
/*     */ 
/*     */   public final String toString()
/*     */   {
/*  88 */     return getAttributeName().toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/*  96 */     if (this == o) {
/*  97 */       return true;
/*     */     }
/*     */     
/* 100 */     if (!o.getClass().equals(getClass())) {
/* 101 */       return false;
/*     */     }
/*     */     
/* 104 */     AttributeDefinition that = (AttributeDefinition)o;
/*     */     
/* 106 */     if (!this.attributeName.equals(that.attributeName)) {
/* 107 */       return false;
/*     */     }
/*     */     
/* 110 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 116 */     return this.attributeName.hashCode();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\AttributeDefinition.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */