/*     */ package org.thymeleaf.engine;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import java.util.Arrays;
/*     */ import org.thymeleaf.exceptions.TemplateOutputException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ThrottledTemplateWriterWriterAdapter
/*     */   extends Writer
/*     */   implements ThrottledTemplateWriter.IThrottledTemplateWriterAdapter
/*     */ {
/*  42 */   private static int OVERFLOW_BUFFER_INCREMENT = 256;
/*     */   
/*     */   private final String templateName;
/*     */   
/*     */   private final TemplateFlowController flowController;
/*     */   
/*     */   private Writer writer;
/*     */   
/*     */   private char[] overflow;
/*     */   
/*     */   private int overflowSize;
/*     */   private int maxOverflowSize;
/*     */   private int overflowGrowCount;
/*     */   private boolean unlimited;
/*     */   private int limit;
/*     */   private int writtenCount;
/*     */   
/*     */   ThrottledTemplateWriterWriterAdapter(String templateName, TemplateFlowController flowController)
/*     */   {
/*  61 */     this.templateName = templateName;
/*  62 */     this.flowController = flowController;
/*  63 */     this.overflow = null;
/*  64 */     this.overflowSize = 0;
/*  65 */     this.maxOverflowSize = 0;
/*  66 */     this.overflowGrowCount = 0;
/*  67 */     this.unlimited = false;
/*  68 */     this.limit = 0;
/*  69 */     this.writtenCount = 0;
/*  70 */     this.flowController.stopProcessing = true;
/*     */   }
/*     */   
/*     */   void setWriter(Writer writer) {
/*  74 */     this.writer = writer;
/*  75 */     this.writtenCount = 0;
/*     */   }
/*     */   
/*     */   public boolean isOverflown()
/*     */   {
/*  80 */     return this.overflowSize > 0;
/*     */   }
/*     */   
/*     */   public boolean isStopped() {
/*  84 */     return this.limit == 0;
/*     */   }
/*     */   
/*     */   public int getWrittenCount()
/*     */   {
/*  89 */     return this.writtenCount;
/*     */   }
/*     */   
/*     */   public int getMaxOverflowSize()
/*     */   {
/*  94 */     return this.maxOverflowSize;
/*     */   }
/*     */   
/*     */   public int getOverflowGrowCount()
/*     */   {
/*  99 */     return this.overflowGrowCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void allow(int limit)
/*     */   {
/* 107 */     if ((limit == Integer.MAX_VALUE) || (limit < 0)) {
/* 108 */       this.unlimited = true;
/* 109 */       this.limit = -1;
/*     */     } else {
/* 111 */       this.unlimited = false;
/* 112 */       this.limit = limit;
/*     */     }
/*     */     
/* 115 */     this.flowController.stopProcessing = (this.limit == 0);
/*     */     
/* 117 */     if ((this.overflowSize == 0) || (this.limit == 0)) {
/* 118 */       return;
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 123 */       if ((this.unlimited) || (this.limit > this.overflowSize)) {
/* 124 */         this.writer.write(this.overflow, 0, this.overflowSize);
/* 125 */         if (!this.unlimited) {
/* 126 */           this.limit -= this.overflowSize;
/*     */         }
/* 128 */         this.writtenCount += this.overflowSize;
/* 129 */         this.overflowSize = 0;
/* 130 */         return;
/*     */       }
/*     */       
/* 133 */       this.writer.write(this.overflow, 0, this.limit);
/* 134 */       if (this.limit < this.overflowSize) {
/* 135 */         System.arraycopy(this.overflow, this.limit, this.overflow, 0, this.overflowSize - this.limit);
/*     */       }
/* 137 */       this.overflowSize -= this.limit;
/* 138 */       this.writtenCount += this.limit;
/* 139 */       this.limit = 0;
/* 140 */       this.flowController.stopProcessing = true;
/*     */     }
/*     */     catch (IOException e) {
/* 143 */       throw new TemplateOutputException("Exception while trying to write overflowed buffer in throttled template", this.templateName, -1, -1, e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void write(int c)
/*     */     throws IOException
/*     */   {
/* 153 */     if (this.limit == 0) {
/* 154 */       overflow(c);
/* 155 */       return;
/*     */     }
/* 157 */     this.writer.write(c);
/* 158 */     if (!this.unlimited) {
/* 159 */       this.limit -= 1;
/*     */     }
/* 161 */     this.writtenCount += 1;
/* 162 */     if (this.limit == 0) {
/* 163 */       this.flowController.stopProcessing = true;
/*     */     }
/*     */   }
/*     */   
/*     */   public void write(String str)
/*     */     throws IOException
/*     */   {
/* 170 */     int len = str.length();
/* 171 */     if (this.limit == 0) {
/* 172 */       overflow(str, 0, len);
/* 173 */       return;
/*     */     }
/* 175 */     if ((this.unlimited) || (this.limit > len)) {
/* 176 */       this.writer.write(str, 0, len);
/* 177 */       if (!this.unlimited) {
/* 178 */         this.limit -= len;
/*     */       }
/* 180 */       this.writtenCount += len;
/* 181 */       return;
/*     */     }
/* 183 */     this.writer.write(str, 0, this.limit);
/* 184 */     if (this.limit < len) {
/* 185 */       overflow(str, this.limit, len - this.limit);
/*     */     }
/* 187 */     this.writtenCount += this.limit;
/* 188 */     this.limit = 0;
/* 189 */     this.flowController.stopProcessing = true;
/*     */   }
/*     */   
/*     */   public void write(String str, int off, int len)
/*     */     throws IOException
/*     */   {
/* 195 */     if (this.limit == 0) {
/* 196 */       overflow(str, off, len);
/* 197 */       return;
/*     */     }
/* 199 */     if ((this.unlimited) || (this.limit > len)) {
/* 200 */       this.writer.write(str, off, len);
/* 201 */       if (!this.unlimited) {
/* 202 */         this.limit -= len;
/*     */       }
/* 204 */       this.writtenCount += len;
/* 205 */       return;
/*     */     }
/* 207 */     this.writer.write(str, off, this.limit);
/* 208 */     if (this.limit < len) {
/* 209 */       overflow(str, off + this.limit, len - this.limit);
/*     */     }
/* 211 */     this.writtenCount += this.limit;
/* 212 */     this.limit = 0;
/* 213 */     this.flowController.stopProcessing = true;
/*     */   }
/*     */   
/*     */   public void write(char[] cbuf)
/*     */     throws IOException
/*     */   {
/* 219 */     int len = cbuf.length;
/* 220 */     if (this.limit == 0) {
/* 221 */       overflow(cbuf, 0, len);
/* 222 */       return;
/*     */     }
/* 224 */     if ((this.unlimited) || (this.limit > len)) {
/* 225 */       this.writer.write(cbuf, 0, len);
/* 226 */       if (!this.unlimited) {
/* 227 */         this.limit -= len;
/*     */       }
/* 229 */       this.writtenCount += len;
/* 230 */       return;
/*     */     }
/* 232 */     this.writer.write(cbuf, 0, this.limit);
/* 233 */     if (this.limit < len) {
/* 234 */       overflow(cbuf, this.limit, len - this.limit);
/*     */     }
/* 236 */     this.writtenCount += this.limit;
/* 237 */     this.limit = 0;
/* 238 */     this.flowController.stopProcessing = true;
/*     */   }
/*     */   
/*     */   public void write(char[] cbuf, int off, int len)
/*     */     throws IOException
/*     */   {
/* 244 */     if (this.limit == 0) {
/* 245 */       overflow(cbuf, off, len);
/* 246 */       return;
/*     */     }
/* 248 */     if ((this.unlimited) || (this.limit > len)) {
/* 249 */       this.writer.write(cbuf, off, len);
/* 250 */       if (!this.unlimited) {
/* 251 */         this.limit -= len;
/*     */       }
/* 253 */       this.writtenCount += len;
/* 254 */       return;
/*     */     }
/* 256 */     this.writer.write(cbuf, off, this.limit);
/* 257 */     if (this.limit < len) {
/* 258 */       overflow(cbuf, off + this.limit, len - this.limit);
/*     */     }
/* 260 */     this.writtenCount += this.limit;
/* 261 */     this.limit = 0;
/* 262 */     this.flowController.stopProcessing = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void overflow(int c)
/*     */   {
/* 269 */     ensureOverflowCapacity(1);
/* 270 */     this.overflow[this.overflowSize] = ((char)c);
/* 271 */     this.overflowSize += 1;
/* 272 */     if (this.overflowSize > this.maxOverflowSize) {
/* 273 */       this.maxOverflowSize = this.overflowSize;
/*     */     }
/*     */   }
/*     */   
/*     */   private void overflow(String str, int off, int len)
/*     */   {
/* 279 */     ensureOverflowCapacity(len);
/* 280 */     str.getChars(off, off + len, this.overflow, this.overflowSize);
/* 281 */     this.overflowSize += len;
/* 282 */     if (this.overflowSize > this.maxOverflowSize) {
/* 283 */       this.maxOverflowSize = this.overflowSize;
/*     */     }
/*     */   }
/*     */   
/*     */   private void overflow(char[] cbuf, int off, int len)
/*     */   {
/* 289 */     ensureOverflowCapacity(len);
/* 290 */     System.arraycopy(cbuf, off, this.overflow, this.overflowSize, len);
/* 291 */     this.overflowSize += len;
/* 292 */     if (this.overflowSize > this.maxOverflowSize) {
/* 293 */       this.maxOverflowSize = this.overflowSize;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void ensureOverflowCapacity(int len)
/*     */   {
/* 301 */     if (this.overflow == null) {
/* 302 */       this.overflow = new char[(len / OVERFLOW_BUFFER_INCREMENT + 1) * OVERFLOW_BUFFER_INCREMENT];
/* 303 */       return;
/*     */     }
/* 305 */     int targetLen = this.overflowSize + len;
/* 306 */     if (this.overflow.length < targetLen) {
/* 307 */       this.overflow = Arrays.copyOf(this.overflow, (targetLen / OVERFLOW_BUFFER_INCREMENT + 1) * OVERFLOW_BUFFER_INCREMENT);
/* 308 */       this.overflowGrowCount += 1;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void flush()
/*     */     throws IOException
/*     */   {
/* 319 */     this.writer.flush();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/* 327 */     this.writer.close();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\ThrottledTemplateWriterWriterAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */