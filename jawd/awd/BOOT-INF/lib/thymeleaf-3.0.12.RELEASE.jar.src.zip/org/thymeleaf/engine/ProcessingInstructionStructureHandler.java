/*    */ package org.thymeleaf.engine;
/*    */ 
/*    */ import org.thymeleaf.model.IModel;
/*    */ import org.thymeleaf.processor.processinginstruction.IProcessingInstructionStructureHandler;
/*    */ import org.thymeleaf.util.Validate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ProcessingInstructionStructureHandler
/*    */   implements IProcessingInstructionStructureHandler
/*    */ {
/*    */   boolean setProcessingInstruction;
/*    */   String setProcessingInstructionTarget;
/*    */   String setProcessingInstructionContent;
/*    */   boolean replaceWithModel;
/*    */   IModel replaceWithModelValue;
/*    */   boolean replaceWithModelProcessable;
/*    */   boolean removeProcessingInstruction;
/*    */   
/*    */   ProcessingInstructionStructureHandler()
/*    */   {
/* 56 */     reset();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void setProcessingInstruction(String target, String content)
/*    */   {
/* 63 */     reset();
/* 64 */     Validate.notNull(target, "Target cannot be null");
/* 65 */     Validate.notNull(content, "Content cannot be null");
/* 66 */     this.setProcessingInstruction = true;
/* 67 */     this.setProcessingInstructionTarget = target;
/* 68 */     this.setProcessingInstructionContent = content;
/*    */   }
/*    */   
/*    */   public void replaceWith(IModel model, boolean processable)
/*    */   {
/* 73 */     reset();
/* 74 */     Validate.notNull(model, "Model cannot be null");
/* 75 */     this.replaceWithModel = true;
/* 76 */     this.replaceWithModelValue = model;
/* 77 */     this.replaceWithModelProcessable = processable;
/*    */   }
/*    */   
/*    */   public void removeProcessingInstruction()
/*    */   {
/* 82 */     reset();
/* 83 */     this.removeProcessingInstruction = true;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void reset()
/*    */   {
/* 91 */     this.setProcessingInstruction = false;
/* 92 */     this.setProcessingInstructionTarget = null;
/* 93 */     this.setProcessingInstructionContent = null;
/*    */     
/* 95 */     this.replaceWithModel = false;
/* 96 */     this.replaceWithModelValue = null;
/* 97 */     this.replaceWithModelProcessable = false;
/*    */     
/* 99 */     this.removeProcessingInstruction = false;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\ProcessingInstructionStructureHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */