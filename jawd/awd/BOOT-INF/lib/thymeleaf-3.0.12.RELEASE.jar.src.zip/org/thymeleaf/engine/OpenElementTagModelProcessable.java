/*     */ package org.thymeleaf.engine;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class OpenElementTagModelProcessable
/*     */   implements IEngineProcessable
/*     */ {
/*     */   private final OpenElementTag openElementTag;
/*     */   
/*     */ 
/*     */ 
/*     */   private final ProcessorExecutionVars vars;
/*     */   
/*     */ 
/*     */ 
/*     */   private final TemplateFlowController flowController;
/*     */   
/*     */ 
/*     */ 
/*     */   private final TemplateModelController modelController;
/*     */   
/*     */ 
/*     */ 
/*     */   private final ProcessorTemplateHandler processorTemplateHandler;
/*     */   
/*     */ 
/*     */ 
/*     */   private final ITemplateHandler nextTemplateHandler;
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean beforeProcessed;
/*     */   
/*     */ 
/*     */   private boolean delegationProcessed;
/*     */   
/*     */ 
/*     */   private boolean afterProcessed;
/*     */   
/*     */ 
/*     */   private int offset;
/*     */   
/*     */ 
/*     */ 
/*     */   OpenElementTagModelProcessable(OpenElementTag openElementTag, ProcessorExecutionVars vars, TemplateModelController modelController, TemplateFlowController flowController, ProcessorTemplateHandler processorTemplateHandler, ITemplateHandler nextTemplateHandler)
/*     */   {
/*  48 */     this.openElementTag = openElementTag;
/*  49 */     this.vars = vars;
/*  50 */     this.flowController = flowController;
/*  51 */     this.modelController = modelController;
/*  52 */     this.processorTemplateHandler = processorTemplateHandler;
/*  53 */     this.nextTemplateHandler = nextTemplateHandler;
/*  54 */     this.beforeProcessed = false;
/*  55 */     this.delegationProcessed = false;
/*  56 */     this.afterProcessed = false;
/*  57 */     this.offset = 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean process()
/*     */   {
/*  66 */     if (this.flowController.stopProcessing) {
/*  67 */       return false;
/*     */     }
/*     */     
/*     */ 
/*  71 */     if (!this.beforeProcessed)
/*     */     {
/*     */ 
/*     */ 
/*  75 */       if (this.vars.modelBefore != null) {
/*  76 */         this.offset += this.vars.modelBefore.process(this.nextTemplateHandler, this.offset, this.flowController);
/*  77 */         if ((this.offset < this.vars.modelBefore.queueSize) || (this.flowController.stopProcessing)) {
/*  78 */           return false;
/*     */         }
/*     */       }
/*  81 */       this.beforeProcessed = true;
/*  82 */       this.offset = 0;
/*     */     }
/*     */     
/*     */ 
/*  86 */     if (!this.delegationProcessed)
/*     */     {
/*     */ 
/*     */ 
/*  90 */       if (!this.vars.discardEvent) {
/*  91 */         this.nextTemplateHandler.handleOpenElement(this.openElementTag);
/*     */       }
/*  93 */       this.delegationProcessed = true;
/*  94 */       this.offset = 0;
/*     */     }
/*     */     
/*  97 */     if (this.flowController.stopProcessing) {
/*  98 */       return false;
/*     */     }
/*     */     
/* 101 */     if (!this.afterProcessed)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 108 */       if (this.vars.modelAfter != null) {
/* 109 */         ITemplateHandler modelHandler = this.vars.modelAfterProcessable ? this.processorTemplateHandler : this.nextTemplateHandler;
/* 110 */         this.offset += this.vars.modelAfter.process(modelHandler, this.offset, this.flowController);
/* 111 */         if ((this.offset < this.vars.modelAfter.queueSize) || (this.flowController.stopProcessing)) {
/* 112 */           return false;
/*     */         }
/*     */       }
/* 115 */       this.afterProcessed = true;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 122 */     this.modelController.skip(this.vars.skipBody, this.vars.skipCloseTag);
/*     */     
/* 124 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\OpenElementTagModelProcessable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */