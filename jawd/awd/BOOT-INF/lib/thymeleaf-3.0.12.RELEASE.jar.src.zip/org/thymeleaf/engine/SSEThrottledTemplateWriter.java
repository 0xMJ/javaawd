/*     */ package org.thymeleaf.engine;
/*     */ 
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SSEThrottledTemplateWriter
/*     */   extends ThrottledTemplateWriter
/*     */   implements ISSEThrottledTemplateWriterControl
/*     */ {
/*  33 */   private static final char[] SSE_ID_PREFIX = "id: ".toCharArray();
/*  34 */   private static final char[] SSE_EVENT_PREFIX = "event: ".toCharArray();
/*  35 */   private static final char[] SSE_DATA_PREFIX = "data: ".toCharArray();
/*     */   
/*  37 */   private char[] id = null;
/*  38 */   private char[] event = null;
/*     */   
/*  40 */   private boolean eventHasMeta = false;
/*  41 */   private boolean newEvent = true;
/*     */   
/*     */   SSEThrottledTemplateWriter(String templateName, TemplateFlowController flowController)
/*     */   {
/*  45 */     super(templateName, flowController);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void startEvent(char[] id, char[] event)
/*     */   {
/*  54 */     this.newEvent = true;
/*  55 */     this.id = id;
/*  56 */     this.event = event;
/*     */   }
/*     */   
/*     */   private void doStartEvent() throws IOException
/*     */   {
/*  61 */     this.eventHasMeta = false;
/*  62 */     if (this.event != null)
/*     */     {
/*  64 */       if (!checkTokenValid(this.event)) {
/*  65 */         throw new IllegalArgumentException("Event for SSE event cannot contain a newline (\\n) character");
/*     */       }
/*  67 */       super.write(SSE_EVENT_PREFIX);
/*  68 */       super.write(this.event);
/*  69 */       super.write(10);
/*  70 */       this.eventHasMeta = true;
/*     */     }
/*  72 */     if (this.id != null)
/*     */     {
/*  74 */       if (!checkTokenValid(this.id)) {
/*  75 */         throw new IllegalArgumentException("ID for SSE event cannot contain a newline (\\n) character");
/*     */       }
/*  77 */       super.write(SSE_ID_PREFIX);
/*  78 */       super.write(this.id);
/*  79 */       super.write(10);
/*  80 */       this.eventHasMeta = true;
/*     */     }
/*     */   }
/*     */   
/*     */   public void endEvent() throws IOException
/*     */   {
/*  86 */     if (!this.newEvent) {
/*  87 */       super.write(10);
/*  88 */       super.write(10);
/*  89 */     } else if (this.eventHasMeta)
/*     */     {
/*  91 */       super.write(10);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void write(int c)
/*     */     throws IOException
/*     */   {
/* 100 */     if (this.newEvent) {
/* 101 */       doStartEvent();
/* 102 */       super.write(SSE_DATA_PREFIX);
/* 103 */       this.newEvent = false;
/*     */     }
/*     */     
/* 106 */     super.write(c);
/* 107 */     if (c == 10)
/*     */     {
/* 109 */       super.write(SSE_DATA_PREFIX);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void write(String str)
/*     */     throws IOException
/*     */   {
/* 117 */     write(str, 0, str.length());
/*     */   }
/*     */   
/*     */ 
/*     */   public void write(String str, int off, int len)
/*     */     throws IOException
/*     */   {
/* 124 */     if (str == null)
/* 125 */       throw new NullPointerException();
/* 126 */     if ((off < 0) || (off > str.length()) || (len < 0) || 
/* 127 */       (off + len > str.length()) || (off + len < 0)) {
/* 128 */       throw new IndexOutOfBoundsException();
/*     */     }
/*     */     
/* 131 */     if (len == 0)
/*     */     {
/*     */ 
/* 134 */       super.write(str, off, len);
/* 135 */       return;
/*     */     }
/*     */     
/* 138 */     if (this.newEvent) {
/* 139 */       doStartEvent();
/* 140 */       super.write(SSE_DATA_PREFIX);
/* 141 */       this.newEvent = false;
/*     */     }
/*     */     
/*     */ 
/* 145 */     int i = off;
/* 146 */     int x = i;
/* 147 */     int maxi = off + len;
/* 148 */     while (i < maxi) {
/* 149 */       char c = str.charAt(i++);
/* 150 */       if (c == '\n')
/*     */       {
/* 152 */         super.write(str, x, i - x);
/* 153 */         super.write(SSE_DATA_PREFIX);
/* 154 */         x = i;
/*     */       }
/*     */     }
/*     */     
/* 158 */     if (x < i) {
/* 159 */       super.write(str, x, i - x);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void write(char[] cbuf)
/*     */     throws IOException
/*     */   {
/* 167 */     write(cbuf, 0, cbuf.length);
/*     */   }
/*     */   
/*     */ 
/*     */   public void write(char[] cbuf, int off, int len)
/*     */     throws IOException
/*     */   {
/* 174 */     if (cbuf == null)
/* 175 */       throw new NullPointerException();
/* 176 */     if ((off < 0) || (off > cbuf.length) || (len < 0) || (off + len > cbuf.length) || (off + len < 0))
/*     */     {
/* 178 */       throw new IndexOutOfBoundsException();
/*     */     }
/*     */     
/* 181 */     if (len == 0)
/*     */     {
/*     */ 
/* 184 */       super.write(cbuf, off, len);
/* 185 */       return;
/*     */     }
/*     */     
/* 188 */     if (this.newEvent) {
/* 189 */       doStartEvent();
/* 190 */       super.write(SSE_DATA_PREFIX);
/* 191 */       this.newEvent = false;
/*     */     }
/*     */     
/*     */ 
/* 195 */     int i = off;
/* 196 */     int x = i;
/* 197 */     int maxi = off + len;
/* 198 */     while (i < maxi) {
/* 199 */       char c = cbuf[(i++)];
/* 200 */       if (c == '\n')
/*     */       {
/* 202 */         super.write(cbuf, x, i - x);
/* 203 */         super.write(SSE_DATA_PREFIX);
/* 204 */         x = i;
/*     */       }
/*     */     }
/*     */     
/* 208 */     if (x < i) {
/* 209 */       super.write(cbuf, x, i - x);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static boolean checkTokenValid(char[] token)
/*     */   {
/* 217 */     if ((token == null) || (token.length == 0)) {
/* 218 */       return true;
/*     */     }
/* 220 */     for (int i = 0; i < token.length; i++) {
/* 221 */       if (token[i] == '\n') {
/* 222 */         return false;
/*     */       }
/*     */     }
/*     */     
/* 226 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\SSEThrottledTemplateWriter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */