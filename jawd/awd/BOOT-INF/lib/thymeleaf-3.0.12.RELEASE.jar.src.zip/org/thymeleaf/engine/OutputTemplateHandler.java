/*     */ package org.thymeleaf.engine;
/*     */ 
/*     */ import java.io.Writer;
/*     */ import org.thymeleaf.exceptions.TemplateOutputException;
/*     */ import org.thymeleaf.model.ICDATASection;
/*     */ import org.thymeleaf.model.ICloseElementTag;
/*     */ import org.thymeleaf.model.IComment;
/*     */ import org.thymeleaf.model.IDocType;
/*     */ import org.thymeleaf.model.IOpenElementTag;
/*     */ import org.thymeleaf.model.IProcessingInstruction;
/*     */ import org.thymeleaf.model.IStandaloneElementTag;
/*     */ import org.thymeleaf.model.IText;
/*     */ import org.thymeleaf.model.IXMLDeclaration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class OutputTemplateHandler
/*     */   extends AbstractTemplateHandler
/*     */ {
/*     */   private final Writer writer;
/*     */   
/*     */   public OutputTemplateHandler(Writer writer)
/*     */   {
/*  58 */     if (writer == null) {
/*  59 */       throw new IllegalArgumentException("Writer cannot be null");
/*     */     }
/*  61 */     this.writer = writer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleText(IText text)
/*     */   {
/*     */     try
/*     */     {
/*  71 */       text.write(this.writer);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*  75 */       throw new TemplateOutputException("An error happened during template rendering", text.getTemplateName(), text.getLine(), text.getCol(), e);
/*     */     }
/*     */     
/*     */ 
/*  79 */     super.handleText(text);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleComment(IComment comment)
/*     */   {
/*     */     try
/*     */     {
/*  89 */       comment.write(this.writer);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*  93 */       throw new TemplateOutputException("An error happened during template rendering", comment.getTemplateName(), comment.getLine(), comment.getCol(), e);
/*     */     }
/*     */     
/*     */ 
/*  97 */     super.handleComment(comment);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void handleCDATASection(ICDATASection cdataSection)
/*     */   {
/*     */     try
/*     */     {
/* 106 */       cdataSection.write(this.writer);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 110 */       throw new TemplateOutputException("An error happened during template rendering", cdataSection.getTemplateName(), cdataSection.getLine(), cdataSection.getCol(), e);
/*     */     }
/*     */     
/*     */ 
/* 114 */     super.handleCDATASection(cdataSection);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleStandaloneElement(IStandaloneElementTag standaloneElementTag)
/*     */   {
/*     */     try
/*     */     {
/* 125 */       standaloneElementTag.write(this.writer);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 129 */       throw new TemplateOutputException("An error happened during template rendering", standaloneElementTag.getTemplateName(), standaloneElementTag.getLine(), standaloneElementTag.getCol(), e);
/*     */     }
/*     */     
/*     */ 
/* 133 */     super.handleStandaloneElement(standaloneElementTag);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void handleOpenElement(IOpenElementTag openElementTag)
/*     */   {
/*     */     try
/*     */     {
/* 142 */       openElementTag.write(this.writer);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 146 */       throw new TemplateOutputException("An error happened during template rendering", openElementTag.getTemplateName(), openElementTag.getLine(), openElementTag.getCol(), e);
/*     */     }
/*     */     
/*     */ 
/* 150 */     super.handleOpenElement(openElementTag);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void handleCloseElement(ICloseElementTag closeElementTag)
/*     */   {
/*     */     try
/*     */     {
/* 159 */       closeElementTag.write(this.writer);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 163 */       throw new TemplateOutputException("An error happened during template rendering", closeElementTag.getTemplateName(), closeElementTag.getLine(), closeElementTag.getCol(), e);
/*     */     }
/*     */     
/*     */ 
/* 167 */     super.handleCloseElement(closeElementTag);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleDocType(IDocType docType)
/*     */   {
/*     */     try
/*     */     {
/* 178 */       docType.write(this.writer);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 182 */       throw new TemplateOutputException("An error happened during template rendering", docType.getTemplateName(), docType.getLine(), docType.getCol(), e);
/*     */     }
/*     */     
/*     */ 
/* 186 */     super.handleDocType(docType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleXMLDeclaration(IXMLDeclaration xmlDeclaration)
/*     */   {
/*     */     try
/*     */     {
/* 197 */       xmlDeclaration.write(this.writer);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 201 */       throw new TemplateOutputException("An error happened during template rendering", xmlDeclaration.getTemplateName(), xmlDeclaration.getLine(), xmlDeclaration.getCol(), e);
/*     */     }
/*     */     
/*     */ 
/* 205 */     super.handleXMLDeclaration(xmlDeclaration);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleProcessingInstruction(IProcessingInstruction processingInstruction)
/*     */   {
/*     */     try
/*     */     {
/* 218 */       processingInstruction.write(this.writer);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 222 */       throw new TemplateOutputException("An error happened during template rendering", processingInstruction.getTemplateName(), processingInstruction.getLine(), processingInstruction.getCol(), e);
/*     */     }
/*     */     
/*     */ 
/* 226 */     super.handleProcessingInstruction(processingInstruction);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\OutputTemplateHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */