/*      */ package org.thymeleaf.engine;
/*      */ 
/*      */ import java.io.Writer;
/*      */ import java.util.Collections;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.TreeSet;
/*      */ import org.slf4j.Logger;
/*      */ import org.slf4j.LoggerFactory;
/*      */ import org.thymeleaf.IEngineConfiguration;
/*      */ import org.thymeleaf.TemplateEngine;
/*      */ import org.thymeleaf.TemplateSpec;
/*      */ import org.thymeleaf.cache.AlwaysValidCacheEntryValidity;
/*      */ import org.thymeleaf.cache.ICache;
/*      */ import org.thymeleaf.cache.ICacheEntryValidity;
/*      */ import org.thymeleaf.cache.ICacheManager;
/*      */ import org.thymeleaf.cache.NonCacheableCacheEntryValidity;
/*      */ import org.thymeleaf.cache.TemplateCacheKey;
/*      */ import org.thymeleaf.context.IContext;
/*      */ import org.thymeleaf.context.IEngineContext;
/*      */ import org.thymeleaf.context.ITemplateContext;
/*      */ import org.thymeleaf.exceptions.TemplateInputException;
/*      */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*      */ import org.thymeleaf.postprocessor.IPostProcessor;
/*      */ import org.thymeleaf.preprocessor.IPreProcessor;
/*      */ import org.thymeleaf.templatemode.TemplateMode;
/*      */ import org.thymeleaf.templateparser.ITemplateParser;
/*      */ import org.thymeleaf.templateparser.markup.HTMLTemplateParser;
/*      */ import org.thymeleaf.templateparser.markup.XMLTemplateParser;
/*      */ import org.thymeleaf.templateparser.raw.RawTemplateParser;
/*      */ import org.thymeleaf.templateparser.text.CSSTemplateParser;
/*      */ import org.thymeleaf.templateparser.text.JavaScriptTemplateParser;
/*      */ import org.thymeleaf.templateparser.text.TextTemplateParser;
/*      */ import org.thymeleaf.templateresolver.ITemplateResolver;
/*      */ import org.thymeleaf.templateresolver.TemplateResolution;
/*      */ import org.thymeleaf.templateresource.ITemplateResource;
/*      */ import org.thymeleaf.util.LoggingUtils;
/*      */ import org.thymeleaf.util.Validate;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class TemplateManager
/*      */ {
/*   71 */   private static final Logger logger = LoggerFactory.getLogger(TemplateManager.class);
/*      */   
/*      */ 
/*      */   private static final int DEFAULT_PARSER_POOL_SIZE = 40;
/*      */   
/*      */ 
/*      */   private static final int DEFAULT_PARSER_BLOCK_SIZE = 2048;
/*      */   
/*      */ 
/*      */   private final IEngineConfiguration configuration;
/*      */   
/*      */ 
/*      */   private final ITemplateParser htmlParser;
/*      */   
/*      */ 
/*      */   private final ITemplateParser xmlParser;
/*      */   
/*      */ 
/*      */   private final ITemplateParser textParser;
/*      */   
/*      */   private final ITemplateParser javascriptParser;
/*      */   
/*      */   private final ITemplateParser cssParser;
/*      */   
/*      */   private final ITemplateParser rawParser;
/*      */   
/*      */   private final ICache<TemplateCacheKey, TemplateModel> templateCache;
/*      */   
/*      */ 
/*      */   public TemplateManager(IEngineConfiguration configuration)
/*      */   {
/*  102 */     Validate.notNull(configuration, "Configuration cannot be null");
/*      */     
/*  104 */     this.configuration = configuration;
/*      */     
/*  106 */     ICacheManager cacheManager = this.configuration.getCacheManager();
/*      */     
/*  108 */     if (cacheManager == null) {
/*  109 */       this.templateCache = null;
/*      */     } else {
/*  111 */       this.templateCache = cacheManager.getTemplateCache();
/*      */     }
/*      */     
/*  114 */     boolean standardDialectPresent = this.configuration.isStandardDialectPresent();
/*      */     
/*      */ 
/*  117 */     this.htmlParser = new HTMLTemplateParser(40, 2048);
/*  118 */     this.xmlParser = new XMLTemplateParser(40, 2048);
/*  119 */     this.textParser = new TextTemplateParser(40, 2048, standardDialectPresent);
/*  120 */     this.javascriptParser = new JavaScriptTemplateParser(40, 2048, standardDialectPresent);
/*  121 */     this.cssParser = new CSSTemplateParser(40, 2048, standardDialectPresent);
/*  122 */     this.rawParser = new RawTemplateParser(40, 2048);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void clearCaches()
/*      */   {
/*  136 */     if (this.templateCache != null) {
/*  137 */       this.templateCache.clear();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void clearCachesFor(String template)
/*      */   {
/*  151 */     Validate.notNull(template, "Cannot specify null template");
/*  152 */     if (this.templateCache != null) {
/*  153 */       Set<TemplateCacheKey> keysToBeRemoved = new HashSet(4);
/*  154 */       Set<TemplateCacheKey> templateCacheKeys = this.templateCache.keySet();
/*      */       
/*      */ 
/*  157 */       for (TemplateCacheKey templateCacheKey : templateCacheKeys) {
/*  158 */         String ownerTemplate = templateCacheKey.getOwnerTemplate();
/*  159 */         if (ownerTemplate != null)
/*      */         {
/*  161 */           if (ownerTemplate.equals(template)) {
/*  162 */             keysToBeRemoved.add(templateCacheKey);
/*      */           }
/*      */         }
/*  165 */         else if (templateCacheKey.getTemplate().equals(template)) {
/*  166 */           keysToBeRemoved.add(templateCacheKey);
/*      */         }
/*      */       }
/*      */       
/*  170 */       for (TemplateCacheKey keyToBeRemoved : keysToBeRemoved) {
/*  171 */         this.templateCache.clearKey(keyToBeRemoved);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public TemplateModel parseStandalone(ITemplateContext context, String template, Set<String> templateSelectors, TemplateMode templateMode, boolean useCache, boolean failIfNotExists)
/*      */   {
/*  195 */     Validate.notNull(context, "Context cannot be null");
/*  196 */     Validate.notNull(template, "Template cannot be null");
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  202 */     String ownerTemplate = context.getTemplateData().getTemplate();
/*  203 */     Map<String, Object> templateResolutionAttributes = context.getTemplateResolutionAttributes();
/*      */     Set<String> cleanTemplateSelectors;
/*      */     Set<String> cleanTemplateSelectors;
/*  206 */     if ((templateSelectors != null) && (!templateSelectors.isEmpty())) {
/*  207 */       Validate.containsNoEmpties(templateSelectors, "If specified, the Template Selector set cannot contain any nulls or empties");
/*      */       Set<String> cleanTemplateSelectors;
/*  209 */       if (templateSelectors.size() == 1) {
/*  210 */         cleanTemplateSelectors = Collections.singleton(templateSelectors.iterator().next());
/*      */       }
/*      */       else
/*      */       {
/*  214 */         cleanTemplateSelectors = Collections.unmodifiableSet(new TreeSet(templateSelectors));
/*      */       }
/*      */     } else {
/*  217 */       cleanTemplateSelectors = null;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  229 */     TemplateCacheKey cacheKey = useCache ? new TemplateCacheKey(ownerTemplate, template, cleanTemplateSelectors, 0, 0, templateMode, templateResolutionAttributes) : null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  234 */     if ((useCache) && (this.templateCache != null)) {
/*  235 */       TemplateModel cached = (TemplateModel)this.templateCache.get(cacheKey);
/*  236 */       if (cached != null)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*  241 */         return applyPreProcessorsIfNeeded(context, cached);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  250 */     TemplateResolution templateResolution = resolveTemplate(this.configuration, ownerTemplate, template, templateResolutionAttributes, failIfNotExists);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  266 */     if (!failIfNotExists)
/*      */     {
/*  268 */       if (templateResolution == null)
/*      */       {
/*  270 */         return null;
/*      */       }
/*      */       
/*  273 */       if (!templateResolution.isTemplateResourceExistenceVerified()) {
/*  274 */         ITemplateResource resource = templateResolution.getTemplateResource();
/*  275 */         if ((resource == null) || (!resource.exists()))
/*      */         {
/*      */ 
/*  278 */           return null;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  289 */     TemplateData templateData = buildTemplateData(templateResolution, template, cleanTemplateSelectors, templateMode, useCache);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  295 */     ModelBuilderTemplateHandler builderHandler = new ModelBuilderTemplateHandler(this.configuration, templateData);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  301 */     ITemplateParser parser = getParserForTemplateMode(templateData.getTemplateMode());
/*  302 */     parser.parseStandalone(this.configuration, ownerTemplate, template, cleanTemplateSelectors, templateData
/*      */     
/*  304 */       .getTemplateResource(), templateData
/*  305 */       .getTemplateMode(), templateResolution.getUseDecoupledLogic(), builderHandler);
/*      */     
/*  307 */     TemplateModel templateModel = builderHandler.getModel();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  313 */     if ((useCache) && (this.templateCache != null) && 
/*  314 */       (templateResolution.getValidity().isCacheable())) {
/*  315 */       this.templateCache.put(cacheKey, templateModel);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  324 */     return applyPreProcessorsIfNeeded(context, templateModel);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private TemplateModel applyPreProcessorsIfNeeded(ITemplateContext context, TemplateModel templateModel)
/*      */   {
/*  347 */     TemplateData templateData = templateModel.getTemplateData();
/*      */     
/*  349 */     if (this.configuration.getPreProcessors(templateData.getTemplateMode()).isEmpty()) {
/*  350 */       return templateModel;
/*      */     }
/*      */     
/*      */ 
/*  354 */     IEngineContext engineContext = EngineContextManager.prepareEngineContext(this.configuration, templateData, context.getTemplateResolutionAttributes(), context);
/*      */     
/*  356 */     ModelBuilderTemplateHandler builderHandler = new ModelBuilderTemplateHandler(this.configuration, templateData);
/*      */     
/*  358 */     ITemplateHandler processingHandlerChain = createTemplateProcessingHandlerChain(engineContext, true, false, builderHandler, null);
/*      */     
/*  360 */     templateModel.process(processingHandlerChain);
/*      */     
/*  362 */     EngineContextManager.disposeEngineContext(engineContext);
/*      */     
/*  364 */     return builderHandler.getModel();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public TemplateModel parseString(TemplateData ownerTemplateData, String template, int lineOffset, int colOffset, TemplateMode templateMode, boolean useCache)
/*      */   {
/*  377 */     Validate.notNull(ownerTemplateData, "Owner template cannot be null");
/*  378 */     Validate.notNull(template, "Template cannot be null");
/*      */     
/*      */ 
/*      */ 
/*  382 */     String ownerTemplate = ownerTemplateData.getTemplate();
/*      */     
/*      */ 
/*  385 */     TemplateMode definitiveTemplateMode = templateMode != null ? templateMode : ownerTemplateData.getTemplateMode();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  396 */     TemplateCacheKey cacheKey = useCache ? new TemplateCacheKey(ownerTemplate, template, null, lineOffset, colOffset, definitiveTemplateMode, null) : null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  401 */     if ((useCache) && (this.templateCache != null)) {
/*  402 */       TemplateModel cached = (TemplateModel)this.templateCache.get(cacheKey);
/*  403 */       if (cached != null) {
/*  404 */         return cached;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  415 */     ICacheEntryValidity cacheValidity = (useCache) && (ownerTemplateData.getValidity().isCacheable()) ? AlwaysValidCacheEntryValidity.INSTANCE : NonCacheableCacheEntryValidity.INSTANCE;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  434 */     TemplateData templateData = templateMode == null ? ownerTemplateData : new TemplateData(ownerTemplateData.getTemplate(), ownerTemplateData.getTemplateSelectors(), ownerTemplateData.getTemplateResource(), templateMode, cacheValidity);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  444 */     ModelBuilderTemplateHandler builderHandler = new ModelBuilderTemplateHandler(this.configuration, templateData);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  450 */     ITemplateParser parser = getParserForTemplateMode(templateData.getTemplateMode());
/*      */     
/*  452 */     parser.parseString(this.configuration, ownerTemplate, template, lineOffset, colOffset, definitiveTemplateMode, builderHandler);
/*      */     
/*  454 */     TemplateModel parsedTemplate = builderHandler.getModel();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  460 */     if ((useCache) && (this.templateCache != null) && 
/*  461 */       (cacheValidity.isCacheable())) {
/*  462 */       this.templateCache.put(cacheKey, parsedTemplate);
/*      */     }
/*      */     
/*      */ 
/*  466 */     return parsedTemplate;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void process(TemplateModel template, ITemplateContext context, Writer writer)
/*      */   {
/*  489 */     Validate.isTrue(
/*  490 */       this.configuration == template.getConfiguration(), "Specified template was built by a different Template Engine instance");
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  497 */     IEngineContext engineContext = EngineContextManager.prepareEngineContext(this.configuration, template.getTemplateData(), context.getTemplateResolutionAttributes(), context);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  512 */     ProcessorTemplateHandler processorTemplateHandler = new ProcessorTemplateHandler();
/*      */     
/*  514 */     ITemplateHandler processingHandlerChain = createTemplateProcessingHandlerChain(engineContext, false, false, processorTemplateHandler, writer);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  519 */     template.process(processingHandlerChain);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  525 */     EngineContextManager.disposeEngineContext(engineContext);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void parseAndProcess(TemplateSpec templateSpec, IContext context, Writer writer)
/*      */   {
/*  549 */     Validate.notNull(templateSpec, "Template Specification cannot be null");
/*  550 */     Validate.notNull(context, "Context cannot be null");
/*  551 */     Validate.notNull(writer, "Writer cannot be null");
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  557 */     String template = templateSpec.getTemplate();
/*  558 */     Set<String> templateSelectors = templateSpec.getTemplateSelectors();
/*  559 */     TemplateMode templateMode = templateSpec.getTemplateMode();
/*  560 */     Map<String, Object> templateResolutionAttributes = templateSpec.getTemplateResolutionAttributes();
/*      */     
/*  562 */     TemplateCacheKey cacheKey = new TemplateCacheKey(null, template, templateSelectors, 0, 0, templateMode, templateResolutionAttributes);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  574 */     if (this.templateCache != null)
/*      */     {
/*  576 */       TemplateModel cached = (TemplateModel)this.templateCache.get(cacheKey);
/*      */       
/*  578 */       if (cached != null)
/*      */       {
/*      */ 
/*  581 */         IEngineContext engineContext = EngineContextManager.prepareEngineContext(this.configuration, cached.getTemplateData(), templateResolutionAttributes, context);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  588 */         ProcessorTemplateHandler processorTemplateHandler = new ProcessorTemplateHandler();
/*      */         
/*  590 */         ITemplateHandler processingHandlerChain = createTemplateProcessingHandlerChain(engineContext, true, true, processorTemplateHandler, writer);
/*      */         
/*  592 */         cached.process(processingHandlerChain);
/*      */         
/*  594 */         EngineContextManager.disposeEngineContext(engineContext);
/*      */         
/*  596 */         return;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  607 */     TemplateResolution templateResolution = resolveTemplate(this.configuration, null, template, templateResolutionAttributes, true);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  614 */     TemplateData templateData = buildTemplateData(templateResolution, template, templateSelectors, templateMode, true);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  621 */     IEngineContext engineContext = EngineContextManager.prepareEngineContext(this.configuration, templateData, templateResolutionAttributes, context);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  629 */     ProcessorTemplateHandler processorTemplateHandler = new ProcessorTemplateHandler();
/*      */     
/*  631 */     ITemplateHandler processingHandlerChain = createTemplateProcessingHandlerChain(engineContext, true, true, processorTemplateHandler, writer);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  637 */     ITemplateParser parser = getParserForTemplateMode(engineContext.getTemplateMode());
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  643 */     if ((templateResolution.getValidity().isCacheable()) && (this.templateCache != null))
/*      */     {
/*      */ 
/*  646 */       ModelBuilderTemplateHandler builderHandler = new ModelBuilderTemplateHandler(this.configuration, templateData);
/*      */       
/*      */ 
/*  649 */       parser.parseStandalone(this.configuration, null, template, templateSelectors, templateData
/*      */       
/*  651 */         .getTemplateResource(), engineContext
/*  652 */         .getTemplateMode(), templateResolution.getUseDecoupledLogic(), builderHandler);
/*      */       
/*      */ 
/*  655 */       TemplateModel templateModel = builderHandler.getModel();
/*      */       
/*      */ 
/*  658 */       this.templateCache.put(cacheKey, templateModel);
/*      */       
/*      */ 
/*  661 */       templateModel.process(processingHandlerChain);
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*  666 */       parser.parseStandalone(this.configuration, null, template, templateSelectors, templateData
/*      */       
/*  668 */         .getTemplateResource(), engineContext
/*  669 */         .getTemplateMode(), templateResolution.getUseDecoupledLogic(), processingHandlerChain);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  677 */     EngineContextManager.disposeEngineContext(engineContext);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public ThrottledTemplateProcessor parseAndProcessThrottled(TemplateSpec templateSpec, IContext context)
/*      */   {
/*  685 */     Validate.notNull(templateSpec, "Template Specification cannot be null");
/*  686 */     Validate.notNull(context, "Context cannot be null");
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  692 */     String template = templateSpec.getTemplate();
/*  693 */     Set<String> templateSelectors = templateSpec.getTemplateSelectors();
/*  694 */     TemplateMode templateMode = templateSpec.getTemplateMode();
/*  695 */     Map<String, Object> templateResolutionAttributes = templateSpec.getTemplateResolutionAttributes();
/*      */     
/*  697 */     TemplateCacheKey cacheKey = new TemplateCacheKey(null, template, templateSelectors, 0, 0, templateMode, templateResolutionAttributes);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  709 */     TemplateFlowController flowController = new TemplateFlowController();
/*      */     ThrottledTemplateWriter throttledTemplateWriter;
/*      */     ThrottledTemplateWriter throttledTemplateWriter;
/*  712 */     if (templateSpec.isOutputSSE()) {
/*  713 */       throttledTemplateWriter = new SSEThrottledTemplateWriter(template, flowController);
/*      */     } else {
/*  715 */       throttledTemplateWriter = new ThrottledTemplateWriter(template, flowController);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  722 */     if (this.templateCache != null)
/*      */     {
/*  724 */       TemplateModel cached = (TemplateModel)this.templateCache.get(cacheKey);
/*      */       
/*  726 */       if (cached != null)
/*      */       {
/*      */ 
/*  729 */         IEngineContext engineContext = EngineContextManager.prepareEngineContext(this.configuration, cached.getTemplateData(), templateResolutionAttributes, context);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  736 */         ProcessorTemplateHandler processorTemplateHandler = new ProcessorTemplateHandler();
/*  737 */         processorTemplateHandler.setFlowController(flowController);
/*      */         
/*  739 */         ITemplateHandler processingHandlerChain = createTemplateProcessingHandlerChain(engineContext, true, true, processorTemplateHandler, throttledTemplateWriter);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  744 */         return new ThrottledTemplateProcessor(templateSpec, engineContext, cached, processingHandlerChain, processorTemplateHandler, flowController, throttledTemplateWriter);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  757 */     TemplateResolution templateResolution = resolveTemplate(this.configuration, null, template, templateResolutionAttributes, true);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  764 */     TemplateData templateData = buildTemplateData(templateResolution, template, templateSelectors, templateMode, true);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  771 */     IEngineContext engineContext = EngineContextManager.prepareEngineContext(this.configuration, templateData, templateResolutionAttributes, context);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  779 */     ProcessorTemplateHandler processorTemplateHandler = new ProcessorTemplateHandler();
/*  780 */     processorTemplateHandler.setFlowController(flowController);
/*      */     
/*  782 */     ITemplateHandler processingHandlerChain = createTemplateProcessingHandlerChain(engineContext, true, true, processorTemplateHandler, throttledTemplateWriter);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  788 */     ITemplateParser parser = getParserForTemplateMode(engineContext.getTemplateMode());
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  796 */     ModelBuilderTemplateHandler builderHandler = new ModelBuilderTemplateHandler(this.configuration, templateData);
/*  797 */     parser.parseStandalone(this.configuration, null, template, templateSelectors, templateData
/*      */     
/*  799 */       .getTemplateResource(), engineContext
/*  800 */       .getTemplateMode(), templateResolution.getUseDecoupledLogic(), builderHandler);
/*  801 */     TemplateModel templateModel = builderHandler.getModel();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  807 */     if ((templateResolution.getValidity().isCacheable()) && (this.templateCache != null))
/*      */     {
/*      */ 
/*  810 */       this.templateCache.put(cacheKey, templateModel);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  818 */     return new ThrottledTemplateProcessor(templateSpec, engineContext, templateModel, processingHandlerChain, processorTemplateHandler, flowController, throttledTemplateWriter);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static TemplateResolution resolveTemplate(IEngineConfiguration configuration, String ownerTemplate, String template, Map<String, Object> templateResolutionAttributes, boolean failIfNotExists)
/*      */   {
/*  842 */     for (ITemplateResolver templateResolver : configuration.getTemplateResolvers())
/*      */     {
/*      */ 
/*  845 */       TemplateResolution templateResolution = templateResolver.resolveTemplate(configuration, ownerTemplate, template, templateResolutionAttributes);
/*  846 */       if (templateResolution != null) {
/*  847 */         if (logger.isTraceEnabled()) {
/*  848 */           logger.trace("[THYMELEAF][{}] Template resolver match! Resolver \"{}\" will resolve template \"{}\"", new Object[] {
/*      */           
/*  850 */             TemplateEngine.threadIndex(), templateResolver.getName(), LoggingUtils.loggifyTemplateName(template) });
/*      */         }
/*  852 */         return templateResolution;
/*      */       }
/*      */       
/*  855 */       if (logger.isTraceEnabled()) {
/*  856 */         logger.trace("[THYMELEAF][{}] Skipping template resolver \"{}\" for template \"{}\"", new Object[] {
/*      */         
/*  858 */           TemplateEngine.threadIndex(), templateResolver.getName(), LoggingUtils.loggifyTemplateName(template) });
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  863 */     if (!failIfNotExists)
/*      */     {
/*      */ 
/*  866 */       return null;
/*      */     }
/*      */     
/*  869 */     throw new TemplateInputException("Error resolving template [" + template + "], template might not exist or might not be accessible by any of the configured Template Resolvers");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static TemplateData buildTemplateData(TemplateResolution templateResolution, String template, Set<String> templateSelectors, TemplateMode templateMode, boolean useCache)
/*      */   {
/*  887 */     TemplateMode definitiveTemplateMode = templateMode == null ? templateResolution.getTemplateMode() : templateMode;
/*      */     
/*      */ 
/*  890 */     ICacheEntryValidity definitiveCacheEntryValidity = useCache ? templateResolution.getValidity() : NonCacheableCacheEntryValidity.INSTANCE;
/*      */     
/*  892 */     return new TemplateData(template, templateSelectors, templateResolution
/*  893 */       .getTemplateResource(), definitiveTemplateMode, definitiveCacheEntryValidity);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private ITemplateParser getParserForTemplateMode(TemplateMode templateMode)
/*      */   {
/*  902 */     switch (templateMode) {
/*  903 */     case HTML:  return this.htmlParser;
/*  904 */     case XML:  return this.xmlParser;
/*  905 */     case TEXT:  return this.textParser;
/*  906 */     case JAVASCRIPT:  return this.javascriptParser;
/*  907 */     case CSS:  return this.cssParser;
/*  908 */     case RAW:  return this.rawParser;
/*      */     }
/*  910 */     throw new IllegalArgumentException("No parser exists for template mode: " + templateMode);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static ITemplateHandler createTemplateProcessingHandlerChain(IEngineContext context, boolean setPreProcessors, boolean setPostProcessors, ITemplateHandler handler, Writer writer)
/*      */   {
/*  923 */     IEngineConfiguration configuration = context.getConfiguration();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  928 */     ITemplateHandler firstHandler = null;
/*  929 */     ITemplateHandler lastHandler = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  934 */     if (setPreProcessors) {
/*  935 */       Set<IPreProcessor> preProcessors = configuration.getPreProcessors(context.getTemplateMode());
/*  936 */       if ((preProcessors != null) && (preProcessors.size() > 0)) {
/*  937 */         for (IPreProcessor preProcessor : preProcessors) {
/*  938 */           Class<? extends ITemplateHandler> preProcessorClass = preProcessor.getHandlerClass();
/*      */           try
/*      */           {
/*  941 */             preProcessorHandler = (ITemplateHandler)preProcessorClass.newInstance();
/*      */           }
/*      */           catch (Exception e) {
/*      */             ITemplateHandler preProcessorHandler;
/*  945 */             throw new TemplateProcessingException("An exception happened during the creation of a new instance of pre-processor " + preProcessorClass.getClass().getName(), e);
/*      */           }
/*      */           ITemplateHandler preProcessorHandler;
/*  948 */           preProcessorHandler.setContext(context);
/*  949 */           if (firstHandler == null) {
/*  950 */             firstHandler = preProcessorHandler;
/*  951 */             lastHandler = preProcessorHandler;
/*      */           } else {
/*  953 */             lastHandler.setNext(preProcessorHandler);
/*  954 */             lastHandler = preProcessorHandler;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  964 */     handler.setContext(context);
/*  965 */     if (firstHandler == null) {
/*  966 */       firstHandler = handler;
/*  967 */       lastHandler = handler;
/*      */     } else {
/*  969 */       lastHandler.setNext(handler);
/*  970 */       lastHandler = handler;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  977 */     if (setPostProcessors) {
/*  978 */       Set<IPostProcessor> postProcessors = configuration.getPostProcessors(context.getTemplateMode());
/*  979 */       if ((postProcessors != null) && (postProcessors.size() > 0)) {
/*  980 */         for (IPostProcessor postProcessor : postProcessors) {
/*  981 */           Class<? extends ITemplateHandler> postProcessorClass = postProcessor.getHandlerClass();
/*      */           try
/*      */           {
/*  984 */             postProcessorHandler = (ITemplateHandler)postProcessorClass.newInstance();
/*      */           }
/*      */           catch (Exception e) {
/*      */             ITemplateHandler postProcessorHandler;
/*  988 */             throw new TemplateProcessingException("An exception happened during the creation of a new instance of post-processor " + postProcessorClass.getClass().getName(), e);
/*      */           }
/*      */           ITemplateHandler postProcessorHandler;
/*  991 */           postProcessorHandler.setContext(context);
/*  992 */           if (firstHandler == null) {
/*  993 */             firstHandler = postProcessorHandler;
/*  994 */             lastHandler = postProcessorHandler;
/*      */           } else {
/*  996 */             lastHandler.setNext(postProcessorHandler);
/*  997 */             lastHandler = postProcessorHandler;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1007 */     if (writer != null) {
/* 1008 */       OutputTemplateHandler outputHandler = new OutputTemplateHandler(writer);
/* 1009 */       outputHandler.setContext(context);
/* 1010 */       if (firstHandler == null) {
/* 1011 */         firstHandler = outputHandler;
/*      */       } else {
/* 1013 */         lastHandler.setNext(outputHandler);
/*      */       }
/*      */     }
/*      */     
/* 1017 */     return firstHandler;
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\TemplateManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */