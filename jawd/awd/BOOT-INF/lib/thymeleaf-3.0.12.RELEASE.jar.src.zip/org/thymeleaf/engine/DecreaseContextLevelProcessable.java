/*    */ package org.thymeleaf.engine;
/*    */ 
/*    */ import org.thymeleaf.context.IEngineContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class DecreaseContextLevelProcessable
/*    */   implements IEngineProcessable
/*    */ {
/*    */   private final IEngineContext context;
/*    */   private final TemplateFlowController flowController;
/*    */   
/*    */   DecreaseContextLevelProcessable(IEngineContext context, TemplateFlowController flowController)
/*    */   {
/* 38 */     this.context = context;
/* 39 */     this.flowController = flowController;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean process()
/*    */   {
/* 48 */     if (this.flowController.stopProcessing) {
/* 49 */       return false;
/*    */     }
/*    */     
/*    */ 
/*    */ 
/*    */ 
/* 55 */     if (this.context != null) {
/* 56 */       this.context.decreaseLevel();
/*    */     }
/*    */     
/* 59 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\DecreaseContextLevelProcessable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */