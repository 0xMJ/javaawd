/*     */ package org.thymeleaf.engine;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.model.IElementTag;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ import org.thymeleaf.util.FastStringWriter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class AbstractElementTag
/*     */   extends AbstractTemplateEvent
/*     */   implements IElementTag
/*     */ {
/*     */   final TemplateMode templateMode;
/*     */   final ElementDefinition elementDefinition;
/*     */   final String elementCompleteName;
/*     */   final boolean synthetic;
/*     */   
/*     */   protected AbstractElementTag(TemplateMode templateMode, ElementDefinition elementDefinition, String elementCompleteName, boolean synthetic)
/*     */   {
/*  52 */     this.templateMode = templateMode;
/*  53 */     this.elementDefinition = elementDefinition;
/*  54 */     this.elementCompleteName = elementCompleteName;
/*  55 */     this.synthetic = synthetic;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected AbstractElementTag(TemplateMode templateMode, ElementDefinition elementDefinition, String elementCompleteName, boolean synthetic, String templateName, int line, int col)
/*     */   {
/*  65 */     super(templateName, line, col);
/*  66 */     this.templateMode = templateMode;
/*  67 */     this.elementDefinition = elementDefinition;
/*  68 */     this.elementCompleteName = elementCompleteName;
/*  69 */     this.synthetic = synthetic;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final TemplateMode getTemplateMode()
/*     */   {
/*  76 */     return this.templateMode;
/*     */   }
/*     */   
/*     */   public final String getElementCompleteName() {
/*  80 */     return this.elementCompleteName;
/*     */   }
/*     */   
/*     */   public final ElementDefinition getElementDefinition() {
/*  84 */     return this.elementDefinition;
/*     */   }
/*     */   
/*     */   public final boolean isSynthetic() {
/*  88 */     return this.synthetic;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final String toString()
/*     */   {
/*  96 */     Writer stringWriter = new FastStringWriter();
/*     */     try {
/*  98 */       write(stringWriter);
/*     */     } catch (IOException e) {
/* 100 */       throw new TemplateProcessingException("Exception while creating String representation of model entity", e);
/*     */     }
/* 102 */     return stringWriter.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\AbstractElementTag.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */