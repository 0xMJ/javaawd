/*    */ package org.thymeleaf.engine;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class IterationStatusVar
/*    */ {
/*    */   int index;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   Integer size;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   Object current;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public int getIndex()
/*    */   {
/* 40 */     return this.index;
/*    */   }
/*    */   
/*    */   public int getCount() {
/* 44 */     return this.index + 1;
/*    */   }
/*    */   
/*    */   public boolean hasSize() {
/* 48 */     return this.size != null;
/*    */   }
/*    */   
/*    */   public Integer getSize() {
/* 52 */     return this.size;
/*    */   }
/*    */   
/*    */   public Object getCurrent() {
/* 56 */     return this.current;
/*    */   }
/*    */   
/*    */   public boolean isEven()
/*    */   {
/* 61 */     return (this.index + 1) % 2 == 0;
/*    */   }
/*    */   
/*    */   public boolean isOdd() {
/* 65 */     return !isEven();
/*    */   }
/*    */   
/*    */   public boolean isFirst() {
/* 69 */     return this.index == 0;
/*    */   }
/*    */   
/*    */   public boolean isLast() {
/* 73 */     return this.index == this.size.intValue() - 1;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 78 */     return 
/* 79 */       "{index = " + this.index + ", count = " + (this.index + 1) + ", size = " + this.size + ", current = " + (this.current == null ? "null" : this.current.toString()) + "}";
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\IterationStatusVar.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */