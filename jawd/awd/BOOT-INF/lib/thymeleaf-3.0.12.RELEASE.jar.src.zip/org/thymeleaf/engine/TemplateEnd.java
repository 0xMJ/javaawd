/*    */ package org.thymeleaf.engine;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.Writer;
/*    */ import org.thymeleaf.model.IModelVisitor;
/*    */ import org.thymeleaf.model.ITemplateEnd;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class TemplateEnd
/*    */   extends AbstractTemplateEvent
/*    */   implements ITemplateEnd, IEngineTemplateEvent
/*    */ {
/* 36 */   static final TemplateEnd TEMPLATE_END_INSTANCE = new TemplateEnd();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void accept(IModelVisitor visitor)
/*    */   {
/* 49 */     visitor.visit(this);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void write(Writer writer)
/*    */     throws IOException
/*    */   {}
/*    */   
/*    */ 
/*    */ 
/*    */   static TemplateEnd asEngineTemplateEnd(ITemplateEnd templateEnd)
/*    */   {
/* 62 */     return TEMPLATE_END_INSTANCE;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void beHandled(ITemplateHandler handler)
/*    */   {
/* 70 */     handler.handleTemplateEnd(this);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public final String toString()
/*    */   {
/* 78 */     return "";
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\TemplateEnd.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */