/*     */ package org.thymeleaf.engine;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import org.thymeleaf.IEngineConfiguration;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.model.IModel;
/*     */ import org.thymeleaf.model.IModelVisitor;
/*     */ import org.thymeleaf.model.ITemplateEvent;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ import org.thymeleaf.util.FastStringWriter;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class TemplateModel
/*     */   implements IModel
/*     */ {
/*     */   final IEngineConfiguration configuration;
/*     */   final TemplateData templateData;
/*     */   final IEngineTemplateEvent[] queue;
/*     */   
/*     */   TemplateModel(IEngineConfiguration configuration, TemplateData templateData, IEngineTemplateEvent[] queue)
/*     */   {
/*  57 */     Validate.notNull(configuration, "Engine Configuration cannot be null");
/*  58 */     Validate.notNull(templateData, "Template Resolution cannot be null");
/*  59 */     Validate.notNull(queue, "Event queue cannot be null");
/*  60 */     Validate.isTrue(queue.length >= 2, "At least TemplateStart/TemplateEnd events must be added to a TemplateModel");
/*  61 */     Validate.isTrue(queue[0] == TemplateStart.TEMPLATE_START_INSTANCE, "First event in queue is not TemplateStart");
/*  62 */     Validate.isTrue(queue[(queue.length - 1)] == TemplateEnd.TEMPLATE_END_INSTANCE, "Last event in queue is not TemplateEnd");
/*     */     
/*  64 */     this.configuration = configuration;
/*  65 */     this.templateData = templateData;
/*  66 */     this.queue = queue;
/*     */   }
/*     */   
/*     */ 
/*     */   public final TemplateData getTemplateData()
/*     */   {
/*  72 */     return this.templateData;
/*     */   }
/*     */   
/*     */   public final IEngineConfiguration getConfiguration()
/*     */   {
/*  77 */     return this.configuration;
/*     */   }
/*     */   
/*     */   public final TemplateMode getTemplateMode()
/*     */   {
/*  82 */     return this.templateData.getTemplateMode();
/*     */   }
/*     */   
/*     */ 
/*     */   public final int size()
/*     */   {
/*  88 */     return this.queue.length;
/*     */   }
/*     */   
/*     */   public final ITemplateEvent get(int pos)
/*     */   {
/*  93 */     return this.queue[pos];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void add(ITemplateEvent event) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void insert(int pos, ITemplateEvent event) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void replace(int pos, ITemplateEvent event) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void addModel(IModel model) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void insertModel(int pos, IModel model) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void remove(int pos) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void reset() {}
/*     */   
/*     */ 
/*     */ 
/*     */   void process(ITemplateHandler handler)
/*     */   {
/* 135 */     for (int i = 0; i < this.queue.length; i++) {
/* 136 */       this.queue[i].beHandled(handler);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   int process(ITemplateHandler handler, int offset, TemplateFlowController controller)
/*     */   {
/* 143 */     if (controller == null) {
/* 144 */       process(handler);
/* 145 */       return this.queue.length;
/*     */     }
/*     */     
/* 148 */     if ((this.queue.length == 0) || (offset >= this.queue.length)) {
/* 149 */       return 0;
/*     */     }
/*     */     
/* 152 */     int processed = 0;
/*     */     
/* 154 */     for (int i = offset; (i < this.queue.length) && (!controller.stopProcessing); i++) {
/* 155 */       this.queue[i].beHandled(handler);
/* 156 */       processed++;
/*     */     }
/*     */     
/* 159 */     return processed;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final IModel cloneModel()
/*     */   {
/* 167 */     return new Model(this);
/*     */   }
/*     */   
/*     */ 
/*     */   public final void write(Writer writer)
/*     */     throws IOException
/*     */   {
/* 174 */     for (int i = 0; i < this.queue.length; i++) {
/* 175 */       this.queue[i].write(writer);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void accept(IModelVisitor visitor)
/*     */   {
/* 183 */     for (int i = 0; i < this.queue.length; i++)
/*     */     {
/* 185 */       this.queue[i].accept(visitor);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public final String toString()
/*     */   {
/*     */     try
/*     */     {
/* 194 */       Writer writer = new FastStringWriter();
/* 195 */       write(writer);
/* 196 */       return writer.toString();
/*     */     } catch (IOException e) {
/* 198 */       throw new TemplateProcessingException("Error while creating String representation of model");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void immutableModelException()
/*     */   {
/* 211 */     throw new UnsupportedOperationException("Modifications are not allowed on immutable model objects. This model object is an immutable implementation of the " + IModel.class.getName() + " interface, and no modifications are allowed in order to keep cache consistency and improve performance. To modify model events, convert first your immutable model object to a mutable one by means of the " + IModel.class.getName() + "#cloneModel() method");
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\TemplateModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */