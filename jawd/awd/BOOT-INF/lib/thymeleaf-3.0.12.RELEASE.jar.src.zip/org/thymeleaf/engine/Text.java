/*     */ package org.thymeleaf.engine;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import org.thymeleaf.model.IModelVisitor;
/*     */ import org.thymeleaf.model.IText;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class Text
/*     */   extends AbstractTextualTemplateEvent
/*     */   implements IText
/*     */ {
/*     */   Text(CharSequence text)
/*     */   {
/*  39 */     super(text);
/*     */   }
/*     */   
/*     */   Text(CharSequence text, String templateName, int line, int col)
/*     */   {
/*  44 */     super(text, templateName, line, col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getText()
/*     */   {
/*  51 */     return getContentText();
/*     */   }
/*     */   
/*     */   public int length()
/*     */   {
/*  56 */     return getContentLength();
/*     */   }
/*     */   
/*     */   public char charAt(int index)
/*     */   {
/*  61 */     return charAtContent(index);
/*     */   }
/*     */   
/*     */   public CharSequence subSequence(int start, int end)
/*     */   {
/*  66 */     return contentSubSequence(start, end);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void accept(IModelVisitor visitor)
/*     */   {
/*  73 */     visitor.visit(this);
/*     */   }
/*     */   
/*     */   public void write(Writer writer) throws IOException
/*     */   {
/*  78 */     writeContent(writer);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static Text asEngineText(IText text)
/*     */   {
/*  86 */     if ((text instanceof Text)) {
/*  87 */       return (Text)text;
/*     */     }
/*  89 */     return new Text(text.getText(), text.getTemplateName(), text.getLine(), text.getCol());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void beHandled(ITemplateHandler handler)
/*     */   {
/*  97 */     handler.handleText(this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 105 */     return getText();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\Text.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */