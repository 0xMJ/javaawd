/*     */ package org.thymeleaf.engine;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReadWriteLock;
/*     */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ import org.thymeleaf.util.TextUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ElementNames
/*     */ {
/*  41 */   private static final ElementNamesRepository htmlElementNamesRepository = new ElementNamesRepository(TemplateMode.HTML);
/*  42 */   private static final ElementNamesRepository xmlElementNamesRepository = new ElementNamesRepository(TemplateMode.XML);
/*  43 */   private static final ElementNamesRepository textElementNamesRepository = new ElementNamesRepository(TemplateMode.TEXT);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static TextElementName buildTextElementName(char[] elementNameBuffer, int elementNameOffset, int elementNameLen)
/*     */   {
/*  51 */     if (elementNameBuffer == null) {
/*  52 */       throw new IllegalArgumentException("Element name buffer cannot be null or empty");
/*     */     }
/*  54 */     if ((elementNameOffset < 0) || (elementNameLen < 0)) {
/*  55 */       throw new IllegalArgumentException("Element name offset and len must be equal or greater than zero");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  60 */     int i = elementNameOffset;
/*  61 */     int n = elementNameLen;
/*  62 */     while (n-- != 0)
/*     */     {
/*  64 */       char c = elementNameBuffer[(i++)];
/*  65 */       if ((c == ':') && 
/*     */       
/*     */ 
/*     */ 
/*  69 */         (c == ':')) {
/*  70 */         if (i == elementNameOffset + 1)
/*     */         {
/*  72 */           return TextElementName.forName(null, new String(elementNameBuffer, elementNameOffset, elementNameLen));
/*     */         }
/*     */         
/*  75 */         return TextElementName.forName(new String(elementNameBuffer, elementNameOffset, i - (elementNameOffset + 1)), new String(elementNameBuffer, i, elementNameOffset + elementNameLen - i));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  82 */     return TextElementName.forName(null, new String(elementNameBuffer, elementNameOffset, elementNameLen));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static XMLElementName buildXMLElementName(char[] elementNameBuffer, int elementNameOffset, int elementNameLen)
/*     */   {
/*  90 */     if ((elementNameBuffer == null) || (elementNameLen == 0)) {
/*  91 */       throw new IllegalArgumentException("Element name buffer cannot be null or empty");
/*     */     }
/*  93 */     if ((elementNameOffset < 0) || (elementNameLen < 0)) {
/*  94 */       throw new IllegalArgumentException("Element name offset and len must be equal or greater than zero");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  99 */     int i = elementNameOffset;
/* 100 */     int n = elementNameLen;
/* 101 */     while (n-- != 0)
/*     */     {
/* 103 */       char c = elementNameBuffer[(i++)];
/* 104 */       if ((c == ':') && 
/*     */       
/*     */ 
/*     */ 
/* 108 */         (c == ':')) {
/* 109 */         if (i == elementNameOffset + 1)
/*     */         {
/* 111 */           return XMLElementName.forName(null, new String(elementNameBuffer, elementNameOffset, elementNameLen));
/*     */         }
/*     */         
/* 114 */         return XMLElementName.forName(new String(elementNameBuffer, elementNameOffset, i - (elementNameOffset + 1)), new String(elementNameBuffer, i, elementNameOffset + elementNameLen - i));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 121 */     return XMLElementName.forName(null, new String(elementNameBuffer, elementNameOffset, elementNameLen));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static HTMLElementName buildHTMLElementName(char[] elementNameBuffer, int elementNameOffset, int elementNameLen)
/*     */   {
/* 129 */     if ((elementNameBuffer == null) || (elementNameLen == 0)) {
/* 130 */       throw new IllegalArgumentException("Element name buffer cannot be null or empty");
/*     */     }
/* 132 */     if ((elementNameOffset < 0) || (elementNameLen < 0)) {
/* 133 */       throw new IllegalArgumentException("Element name offset and len must be equal or greater than zero");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 138 */     int i = elementNameOffset;
/* 139 */     int n = elementNameLen;
/* 140 */     while (n-- != 0)
/*     */     {
/* 142 */       char c = elementNameBuffer[(i++)];
/* 143 */       if ((c == ':') || (c == '-'))
/*     */       {
/*     */ 
/*     */ 
/* 147 */         if (c == ':') {
/* 148 */           if (i == elementNameOffset + 1)
/*     */           {
/* 150 */             return HTMLElementName.forName(null, new String(elementNameBuffer, elementNameOffset, elementNameLen));
/*     */           }
/*     */           
/* 153 */           if ((TextUtils.equals(TemplateMode.HTML.isCaseSensitive(), "xml:", 0, 4, elementNameBuffer, elementNameOffset, i - elementNameOffset)) || 
/* 154 */             (TextUtils.equals(TemplateMode.HTML.isCaseSensitive(), "xmlns:", 0, 6, elementNameBuffer, elementNameOffset, i - elementNameOffset)))
/*     */           {
/* 156 */             return HTMLElementName.forName(null, new String(elementNameBuffer, elementNameOffset, elementNameLen));
/*     */           }
/*     */           
/* 159 */           return HTMLElementName.forName(new String(elementNameBuffer, elementNameOffset, i - (elementNameOffset + 1)), new String(elementNameBuffer, i, elementNameOffset + elementNameLen - i));
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 164 */         if (c == '-') {
/* 165 */           if (i == elementNameOffset + 1)
/*     */           {
/* 167 */             return HTMLElementName.forName(null, new String(elementNameBuffer, elementNameOffset, elementNameLen));
/*     */           }
/*     */           
/* 170 */           return HTMLElementName.forName(new String(elementNameBuffer, elementNameOffset, i - (elementNameOffset + 1)), new String(elementNameBuffer, i, elementNameOffset + elementNameLen - i));
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 177 */     return HTMLElementName.forName(null, new String(elementNameBuffer, elementNameOffset, elementNameLen));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static TextElementName buildTextElementName(String elementName)
/*     */   {
/* 185 */     if (elementName == null) {
/* 186 */       throw new IllegalArgumentException("Element name cannot be null");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 191 */     int i = 0;
/* 192 */     int n = elementName.length();
/* 193 */     while (n-- != 0)
/*     */     {
/* 195 */       char c = elementName.charAt(i++);
/* 196 */       if ((c == ':') && 
/*     */       
/*     */ 
/*     */ 
/* 200 */         (c == ':')) {
/* 201 */         if (i == 1)
/*     */         {
/* 203 */           return TextElementName.forName(null, elementName);
/*     */         }
/*     */         
/* 206 */         return TextElementName.forName(elementName
/* 207 */           .substring(0, i - 1), elementName
/* 208 */           .substring(i, elementName.length()));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 213 */     return TextElementName.forName(null, elementName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static XMLElementName buildXMLElementName(String elementName)
/*     */   {
/* 221 */     if ((elementName == null) || (elementName.length() == 0)) {
/* 222 */       throw new IllegalArgumentException("Element name cannot be null or empty");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 227 */     int i = 0;
/* 228 */     int n = elementName.length();
/* 229 */     while (n-- != 0)
/*     */     {
/* 231 */       char c = elementName.charAt(i++);
/* 232 */       if ((c == ':') && 
/*     */       
/*     */ 
/*     */ 
/* 236 */         (c == ':')) {
/* 237 */         if (i == 1)
/*     */         {
/* 239 */           return XMLElementName.forName(null, elementName);
/*     */         }
/*     */         
/* 242 */         return XMLElementName.forName(elementName
/* 243 */           .substring(0, i - 1), elementName
/* 244 */           .substring(i, elementName.length()));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 249 */     return XMLElementName.forName(null, elementName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static HTMLElementName buildHTMLElementName(String elementName)
/*     */   {
/* 257 */     if ((elementName == null) || (elementName.length() == 0)) {
/* 258 */       throw new IllegalArgumentException("Element name cannot be null or empty");
/*     */     }
/*     */     
/*     */ 
/* 262 */     int i = 0;
/* 263 */     int n = elementName.length();
/* 264 */     while (n-- != 0)
/*     */     {
/* 266 */       char c = elementName.charAt(i++);
/* 267 */       if ((c == ':') || (c == '-'))
/*     */       {
/*     */ 
/*     */ 
/* 271 */         if (c == ':') {
/* 272 */           if (i == 1)
/*     */           {
/* 274 */             return HTMLElementName.forName(null, elementName);
/*     */           }
/*     */           
/* 277 */           if ((TextUtils.equals(TemplateMode.HTML.isCaseSensitive(), "xml:", 0, 4, elementName, 0, i)) || 
/* 278 */             (TextUtils.equals(TemplateMode.HTML.isCaseSensitive(), "xmlns:", 0, 6, elementName, 0, i)))
/*     */           {
/* 280 */             return HTMLElementName.forName(null, elementName);
/*     */           }
/*     */           
/* 283 */           return HTMLElementName.forName(elementName
/* 284 */             .substring(0, i - 1), elementName
/* 285 */             .substring(i, elementName.length()));
/*     */         }
/*     */         
/* 288 */         if (c == '-') {
/* 289 */           if (i == 1)
/*     */           {
/* 291 */             return HTMLElementName.forName(null, elementName);
/*     */           }
/*     */           
/* 294 */           return HTMLElementName.forName(elementName
/* 295 */             .substring(0, i - 1), elementName
/* 296 */             .substring(i, elementName.length()));
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 301 */     return HTMLElementName.forName(null, elementName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static TextElementName buildTextElementName(String prefix, String elementName)
/*     */   {
/* 308 */     if (elementName == null) {
/* 309 */       throw new IllegalArgumentException("Element name cannot be null or empty");
/*     */     }
/* 311 */     if ((prefix == null) || (prefix.trim().length() == 0)) {
/* 312 */       return buildTextElementName(elementName);
/*     */     }
/* 314 */     return TextElementName.forName(prefix, elementName);
/*     */   }
/*     */   
/*     */ 
/*     */   private static XMLElementName buildXMLElementName(String prefix, String elementName)
/*     */   {
/* 320 */     if ((elementName == null) || (elementName.length() == 0)) {
/* 321 */       throw new IllegalArgumentException("Element name cannot be null or empty");
/*     */     }
/* 323 */     if ((prefix == null) || (prefix.trim().length() == 0)) {
/* 324 */       return buildXMLElementName(elementName);
/*     */     }
/* 326 */     return XMLElementName.forName(prefix, elementName);
/*     */   }
/*     */   
/*     */ 
/*     */   private static HTMLElementName buildHTMLElementName(String prefix, String elementName)
/*     */   {
/* 332 */     if ((elementName == null) || (elementName.length() == 0)) {
/* 333 */       throw new IllegalArgumentException("Element name cannot be null or empty");
/*     */     }
/* 335 */     if ((prefix == null) || (prefix.trim().length() == 0)) {
/* 336 */       return buildHTMLElementName(elementName);
/*     */     }
/* 338 */     return HTMLElementName.forName(prefix, elementName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ElementName forName(TemplateMode templateMode, char[] elementNameBuffer, int elementNameOffset, int elementNameLen)
/*     */   {
/* 346 */     if (templateMode == null) {
/* 347 */       throw new IllegalArgumentException("Template Mode cannot be null");
/*     */     }
/*     */     
/* 350 */     if (templateMode == TemplateMode.HTML) {
/* 351 */       return forHTMLName(elementNameBuffer, elementNameOffset, elementNameLen);
/*     */     }
/*     */     
/* 354 */     if (templateMode == TemplateMode.XML) {
/* 355 */       return forXMLName(elementNameBuffer, elementNameOffset, elementNameLen);
/*     */     }
/*     */     
/* 358 */     if (templateMode.isText()) {
/* 359 */       return forTextName(elementNameBuffer, elementNameOffset, elementNameLen);
/*     */     }
/*     */     
/* 362 */     throw new IllegalArgumentException("Unknown template mode '" + templateMode + "'");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ElementName forName(TemplateMode templateMode, String elementName)
/*     */   {
/* 370 */     if (templateMode == null) {
/* 371 */       throw new IllegalArgumentException("Template Mode cannot be null");
/*     */     }
/*     */     
/* 374 */     if (templateMode == TemplateMode.HTML) {
/* 375 */       return forHTMLName(elementName);
/*     */     }
/*     */     
/* 378 */     if (templateMode == TemplateMode.XML) {
/* 379 */       return forXMLName(elementName);
/*     */     }
/*     */     
/* 382 */     if (templateMode.isText()) {
/* 383 */       return forTextName(elementName);
/*     */     }
/*     */     
/* 386 */     throw new IllegalArgumentException("Unknown template mode '" + templateMode + "'");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ElementName forName(TemplateMode templateMode, String prefix, String elementName)
/*     */   {
/* 394 */     if (templateMode == null) {
/* 395 */       throw new IllegalArgumentException("Template Mode cannot be null");
/*     */     }
/*     */     
/* 398 */     if (templateMode == TemplateMode.HTML) {
/* 399 */       return forHTMLName(prefix, elementName);
/*     */     }
/*     */     
/* 402 */     if (templateMode == TemplateMode.XML) {
/* 403 */       return forXMLName(prefix, elementName);
/*     */     }
/*     */     
/* 406 */     if (templateMode.isText()) {
/* 407 */       return forTextName(prefix, elementName);
/*     */     }
/*     */     
/* 410 */     throw new IllegalArgumentException("Unknown template mode '" + templateMode + "'");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static TextElementName forTextName(char[] elementNameBuffer, int elementNameOffset, int elementNameLen)
/*     */   {
/* 417 */     if (elementNameBuffer == null) {
/* 418 */       throw new IllegalArgumentException("Name cannot be null or empty");
/*     */     }
/* 420 */     if ((elementNameOffset < 0) || (elementNameLen < 0)) {
/* 421 */       throw new IllegalArgumentException("Both name offset and length must be equal to or greater than zero");
/*     */     }
/* 423 */     return (TextElementName)textElementNamesRepository.getElement(elementNameBuffer, elementNameOffset, elementNameLen);
/*     */   }
/*     */   
/*     */   public static XMLElementName forXMLName(char[] elementNameBuffer, int elementNameOffset, int elementNameLen) {
/* 427 */     if ((elementNameBuffer == null) || (elementNameLen == 0)) {
/* 428 */       throw new IllegalArgumentException("Name cannot be null or empty");
/*     */     }
/* 430 */     if ((elementNameOffset < 0) || (elementNameLen < 0)) {
/* 431 */       throw new IllegalArgumentException("Both name offset and length must be equal to or greater than zero");
/*     */     }
/* 433 */     return (XMLElementName)xmlElementNamesRepository.getElement(elementNameBuffer, elementNameOffset, elementNameLen);
/*     */   }
/*     */   
/*     */   public static HTMLElementName forHTMLName(char[] elementNameBuffer, int elementNameOffset, int elementNameLen) {
/* 437 */     if ((elementNameBuffer == null) || (elementNameLen == 0)) {
/* 438 */       throw new IllegalArgumentException("Name cannot be null or empty");
/*     */     }
/* 440 */     if ((elementNameOffset < 0) || (elementNameLen < 0)) {
/* 441 */       throw new IllegalArgumentException("Both name offset and length must be equal to or greater than zero");
/*     */     }
/* 443 */     return (HTMLElementName)htmlElementNamesRepository.getElement(elementNameBuffer, elementNameOffset, elementNameLen);
/*     */   }
/*     */   
/*     */   public static TextElementName forTextName(String elementName)
/*     */   {
/* 448 */     if (elementName == null) {
/* 449 */       throw new IllegalArgumentException("Name cannot be null or empty");
/*     */     }
/* 451 */     return (TextElementName)textElementNamesRepository.getElement(elementName);
/*     */   }
/*     */   
/*     */   public static XMLElementName forXMLName(String elementName) {
/* 455 */     if ((elementName == null) || (elementName.trim().length() == 0)) {
/* 456 */       throw new IllegalArgumentException("Name cannot be null or empty");
/*     */     }
/* 458 */     return (XMLElementName)xmlElementNamesRepository.getElement(elementName);
/*     */   }
/*     */   
/*     */   public static HTMLElementName forHTMLName(String elementName) {
/* 462 */     if ((elementName == null) || (elementName.trim().length() == 0)) {
/* 463 */       throw new IllegalArgumentException("Name cannot be null or empty");
/*     */     }
/* 465 */     return (HTMLElementName)htmlElementNamesRepository.getElement(elementName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static TextElementName forTextName(String prefix, String elementName)
/*     */   {
/* 472 */     if ((elementName == null) || ((elementName.trim().length() == 0) && (prefix != null) && (prefix.trim().length() > 0))) {
/* 473 */       throw new IllegalArgumentException("Name cannot be null (nor empty if prefix is not empty)");
/*     */     }
/* 475 */     return (TextElementName)textElementNamesRepository.getElement(prefix, elementName);
/*     */   }
/*     */   
/*     */   public static XMLElementName forXMLName(String prefix, String elementName) {
/* 479 */     if ((elementName == null) || (elementName.trim().length() == 0)) {
/* 480 */       throw new IllegalArgumentException("Name cannot be null or empty");
/*     */     }
/* 482 */     return (XMLElementName)xmlElementNamesRepository.getElement(prefix, elementName);
/*     */   }
/*     */   
/*     */   public static HTMLElementName forHTMLName(String prefix, String elementName) {
/* 486 */     if ((elementName == null) || (elementName.trim().length() == 0)) {
/* 487 */       throw new IllegalArgumentException("Name cannot be null or empty");
/*     */     }
/* 489 */     return (HTMLElementName)htmlElementNamesRepository.getElement(prefix, elementName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static final class ElementNamesRepository
/*     */   {
/*     */     private final TemplateMode templateMode;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private final List<String> repositoryNames;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private final List<ElementName> repository;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 517 */     private final ReadWriteLock lock = new ReentrantReadWriteLock(true);
/* 518 */     private final Lock readLock = this.lock.readLock();
/* 519 */     private final Lock writeLock = this.lock.writeLock();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     ElementNamesRepository(TemplateMode templateMode)
/*     */     {
/* 526 */       this.templateMode = templateMode;
/*     */       
/* 528 */       this.repositoryNames = new ArrayList(500);
/* 529 */       this.repository = new ArrayList(500);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     ElementName getElement(char[] text, int offset, int len)
/*     */     {
/* 538 */       this.readLock.lock();
/*     */       
/*     */       ElementName localElementName;
/*     */       
/*     */       try
/*     */       {
/* 544 */         int index = binarySearch(this.templateMode.isCaseSensitive(), this.repositoryNames, text, offset, len);
/*     */         
/* 546 */         if (index >= 0) {
/* 547 */           return (ElementName)this.repository.get(index);
/*     */         }
/*     */       }
/*     */       finally {
/* 551 */         this.readLock.unlock();
/*     */       }
/*     */       
/*     */ 
/*     */       int index;
/*     */       
/*     */ 
/* 558 */       this.writeLock.lock();
/*     */       try {
/* 560 */         return storeElement(text, offset, len);
/*     */       } finally {
/* 562 */         this.writeLock.unlock();
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     ElementName getElement(String completeElementName)
/*     */     {
/* 572 */       this.readLock.lock();
/*     */       
/*     */       ElementName localElementName;
/*     */       
/*     */       try
/*     */       {
/* 578 */         int index = binarySearch(this.templateMode.isCaseSensitive(), this.repositoryNames, completeElementName);
/*     */         
/* 580 */         if (index >= 0) {
/* 581 */           return (ElementName)this.repository.get(index);
/*     */         }
/*     */       }
/*     */       finally {
/* 585 */         this.readLock.unlock();
/*     */       }
/*     */       
/*     */ 
/*     */       int index;
/*     */       
/*     */ 
/* 592 */       this.writeLock.lock();
/*     */       try {
/* 594 */         return storeElement(completeElementName);
/*     */       } finally {
/* 596 */         this.writeLock.unlock();
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     ElementName getElement(String prefix, String elementName)
/*     */     {
/* 606 */       this.readLock.lock();
/*     */       
/*     */       ElementName localElementName;
/*     */       
/*     */       try
/*     */       {
/* 612 */         int index = binarySearch(this.templateMode.isCaseSensitive(), this.repositoryNames, prefix, elementName);
/*     */         
/* 614 */         if (index >= 0) {
/* 615 */           return (ElementName)this.repository.get(index);
/*     */         }
/*     */       }
/*     */       finally {
/* 619 */         this.readLock.unlock();
/*     */       }
/*     */       
/*     */ 
/*     */       int index;
/*     */       
/*     */ 
/* 626 */       this.writeLock.lock();
/*     */       try {
/* 628 */         return storeElement(prefix, elementName);
/*     */       } finally {
/* 630 */         this.writeLock.unlock();
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     private ElementName storeElement(char[] text, int offset, int len)
/*     */     {
/* 638 */       int index = binarySearch(this.templateMode.isCaseSensitive(), this.repositoryNames, text, offset, len);
/* 639 */       if (index >= 0)
/*     */       {
/* 641 */         return (ElementName)this.repository.get(index);
/*     */       }
/*     */       ElementName name;
/*     */       ElementName name;
/* 645 */       if (this.templateMode == TemplateMode.HTML) {
/* 646 */         name = ElementNames.buildHTMLElementName(text, offset, len); } else { ElementName name;
/* 647 */         if (this.templateMode == TemplateMode.XML) {
/* 648 */           name = ElementNames.buildXMLElementName(text, offset, len);
/*     */         } else {
/* 650 */           name = ElementNames.buildTextElementName(text, offset, len);
/*     */         }
/*     */       }
/* 653 */       String[] completeElementNames = name.completeElementNames;
/*     */       
/* 655 */       for (String completeElementName : completeElementNames)
/*     */       {
/* 657 */         index = binarySearch(this.templateMode.isCaseSensitive(), this.repositoryNames, completeElementName);
/*     */         
/*     */ 
/* 660 */         this.repositoryNames.add((index + 1) * -1, completeElementName);
/* 661 */         this.repository.add((index + 1) * -1, name);
/*     */       }
/*     */       
/*     */ 
/* 665 */       return name;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     private ElementName storeElement(String elementName)
/*     */     {
/* 672 */       int index = binarySearch(this.templateMode.isCaseSensitive(), this.repositoryNames, elementName);
/* 673 */       if (index >= 0)
/*     */       {
/* 675 */         return (ElementName)this.repository.get(index);
/*     */       }
/*     */       ElementName name;
/*     */       ElementName name;
/* 679 */       if (this.templateMode == TemplateMode.HTML) {
/* 680 */         name = ElementNames.buildHTMLElementName(elementName); } else { ElementName name;
/* 681 */         if (this.templateMode == TemplateMode.XML) {
/* 682 */           name = ElementNames.buildXMLElementName(elementName);
/*     */         } else {
/* 684 */           name = ElementNames.buildTextElementName(elementName);
/*     */         }
/*     */       }
/* 687 */       String[] completeElementNames = name.completeElementNames;
/*     */       
/* 689 */       for (String completeElementName : completeElementNames)
/*     */       {
/* 691 */         index = binarySearch(this.templateMode.isCaseSensitive(), this.repositoryNames, completeElementName);
/*     */         
/*     */ 
/* 694 */         this.repositoryNames.add((index + 1) * -1, completeElementName);
/* 695 */         this.repository.add((index + 1) * -1, name);
/*     */       }
/*     */       
/*     */ 
/* 699 */       return name;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     private ElementName storeElement(String prefix, String elementName)
/*     */     {
/* 706 */       int index = binarySearch(this.templateMode.isCaseSensitive(), this.repositoryNames, prefix, elementName);
/* 707 */       if (index >= 0)
/*     */       {
/* 709 */         return (ElementName)this.repository.get(index);
/*     */       }
/*     */       ElementName name;
/*     */       ElementName name;
/* 713 */       if (this.templateMode == TemplateMode.HTML) {
/* 714 */         name = ElementNames.buildHTMLElementName(prefix, elementName); } else { ElementName name;
/* 715 */         if (this.templateMode == TemplateMode.XML) {
/* 716 */           name = ElementNames.buildXMLElementName(prefix, elementName);
/*     */         } else {
/* 718 */           name = ElementNames.buildTextElementName(prefix, elementName);
/*     */         }
/*     */       }
/* 721 */       String[] completeElementNames = name.completeElementNames;
/*     */       
/* 723 */       for (String completeElementName : completeElementNames)
/*     */       {
/* 725 */         index = binarySearch(this.templateMode.isCaseSensitive(), this.repositoryNames, completeElementName);
/*     */         
/*     */ 
/* 728 */         this.repositoryNames.add((index + 1) * -1, completeElementName);
/* 729 */         this.repository.add((index + 1) * -1, name);
/*     */       }
/*     */       
/*     */ 
/* 733 */       return name;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private static int binarySearch(boolean caseSensitive, List<String> values, char[] text, int offset, int len)
/*     */     {
/* 741 */       int low = 0;
/* 742 */       int high = values.size() - 1;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 747 */       while (low <= high)
/*     */       {
/* 749 */         int mid = low + high >>> 1;
/* 750 */         String midVal = (String)values.get(mid);
/*     */         
/* 752 */         int cmp = TextUtils.compareTo(caseSensitive, midVal, 0, midVal.length(), text, offset, len);
/*     */         
/* 754 */         if (cmp < 0) {
/* 755 */           low = mid + 1;
/* 756 */         } else if (cmp > 0) {
/* 757 */           high = mid - 1;
/*     */         }
/*     */         else {
/* 760 */           return mid;
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 765 */       return -(low + 1);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     private static int binarySearch(boolean caseSensitive, List<String> values, String text)
/*     */     {
/* 772 */       int low = 0;
/* 773 */       int high = values.size() - 1;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 778 */       while (low <= high)
/*     */       {
/* 780 */         int mid = low + high >>> 1;
/* 781 */         String midVal = (String)values.get(mid);
/*     */         
/* 783 */         int cmp = TextUtils.compareTo(caseSensitive, midVal, text);
/*     */         
/* 785 */         if (cmp < 0) {
/* 786 */           low = mid + 1;
/* 787 */         } else if (cmp > 0) {
/* 788 */           high = mid - 1;
/*     */         }
/*     */         else {
/* 791 */           return mid;
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 796 */       return -(low + 1);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private static int binarySearch(boolean caseSensitive, List<String> values, String prefix, String elementName)
/*     */     {
/* 806 */       if ((prefix == null) || (prefix.trim().length() == 0)) {
/* 807 */         return binarySearch(caseSensitive, values, elementName);
/*     */       }
/*     */       
/* 810 */       int prefixLen = prefix.length();
/* 811 */       int elementNameLen = elementName.length();
/*     */       
/* 813 */       int low = 0;
/* 814 */       int high = values.size() - 1;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 820 */       while (low <= high)
/*     */       {
/* 822 */         int mid = low + high >>> 1;
/* 823 */         String midVal = (String)values.get(mid);
/* 824 */         int midValLen = midVal.length();
/*     */         
/* 826 */         if (TextUtils.startsWith(caseSensitive, midVal, prefix))
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/* 831 */           if (midValLen <= prefixLen)
/*     */           {
/*     */ 
/* 834 */             low = mid + 1;
/*     */ 
/*     */           }
/*     */           else
/*     */           {
/* 839 */             int cmp = midVal.charAt(prefixLen) - ':';
/*     */             
/* 841 */             if (cmp < 0) {
/* 842 */               low = mid + 1;
/* 843 */             } else if (cmp > 0) {
/* 844 */               high = mid - 1;
/*     */             }
/*     */             else
/*     */             {
/* 848 */               cmp = TextUtils.compareTo(caseSensitive, midVal, prefixLen + 1, midValLen - (prefixLen + 1), elementName, 0, elementNameLen);
/*     */               
/* 850 */               if (cmp < 0) {
/* 851 */                 low = mid + 1;
/* 852 */               } else if (cmp > 0) {
/* 853 */                 high = mid - 1;
/*     */               }
/*     */               else {
/* 856 */                 return mid;
/*     */               }
/*     */               
/*     */             }
/*     */             
/*     */           }
/*     */           
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/* 867 */           int cmp = TextUtils.compareTo(caseSensitive, midVal, prefix);
/*     */           
/* 869 */           if (cmp < 0) {
/* 870 */             low = mid + 1;
/* 871 */           } else if (cmp > 0) {
/* 872 */             high = mid - 1;
/*     */           }
/*     */           else {
/* 875 */             throw new IllegalStateException("Bad comparison of midVal \"" + midVal + "\" and prefix \"" + prefix + "\"");
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 882 */       return -(low + 1);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\ElementNames.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */