/*     */ package org.thymeleaf.engine;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.thymeleaf.context.IEngineContext;
/*     */ import org.thymeleaf.inline.IInliner;
/*     */ import org.thymeleaf.model.IModel;
/*     */ import org.thymeleaf.processor.templateboundaries.ITemplateBoundariesStructureHandler;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class TemplateBoundariesStructureHandler
/*     */   implements ITemplateBoundariesStructureHandler
/*     */ {
/*     */   boolean insertText;
/*     */   String insertTextValue;
/*     */   boolean insertTextProcessable;
/*     */   boolean insertModel;
/*     */   IModel insertModelValue;
/*     */   boolean insertModelProcessable;
/*     */   boolean setLocalVariable;
/*     */   Map<String, Object> addedLocalVariables;
/*     */   boolean removeLocalVariable;
/*     */   Set<String> removedLocalVariableNames;
/*     */   boolean setSelectionTarget;
/*     */   Object selectionTargetObject;
/*     */   boolean setInliner;
/*     */   IInliner setInlinerValue;
/*     */   
/*     */   TemplateBoundariesStructureHandler()
/*     */   {
/*  73 */     reset();
/*     */   }
/*     */   
/*     */ 
/*     */   public void insert(String text, boolean processable)
/*     */   {
/*  79 */     resetAllButLocalVariables();
/*  80 */     Validate.notNull(text, "Text cannot be null");
/*  81 */     this.insertText = true;
/*  82 */     this.insertTextValue = text;
/*  83 */     this.insertTextProcessable = processable;
/*     */   }
/*     */   
/*     */   public void insert(IModel model, boolean processable)
/*     */   {
/*  88 */     resetAllButLocalVariables();
/*  89 */     Validate.notNull(model, "Model cannot be null");
/*  90 */     this.insertModel = true;
/*  91 */     this.insertModelValue = model;
/*  92 */     this.insertModelProcessable = processable;
/*     */   }
/*     */   
/*     */ 
/*     */   public void removeLocalVariable(String name)
/*     */   {
/*  98 */     this.removeLocalVariable = true;
/*  99 */     if (this.removedLocalVariableNames == null) {
/* 100 */       this.removedLocalVariableNames = new HashSet(3);
/*     */     }
/* 102 */     this.removedLocalVariableNames.add(name);
/*     */   }
/*     */   
/*     */ 
/*     */   public void setLocalVariable(String name, Object value)
/*     */   {
/* 108 */     this.setLocalVariable = true;
/* 109 */     if (this.addedLocalVariables == null) {
/* 110 */       this.addedLocalVariables = new HashMap(3);
/*     */     }
/* 112 */     this.addedLocalVariables.put(name, value);
/*     */   }
/*     */   
/*     */ 
/*     */   public void setSelectionTarget(Object selectionTarget)
/*     */   {
/* 118 */     this.setSelectionTarget = true;
/* 119 */     this.selectionTargetObject = selectionTarget;
/*     */   }
/*     */   
/*     */   public void setInliner(IInliner inliner)
/*     */   {
/* 124 */     this.setInliner = true;
/* 125 */     this.setInlinerValue = inliner;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void reset()
/*     */   {
/* 133 */     resetAllButLocalVariables();
/*     */     
/* 135 */     this.setLocalVariable = false;
/* 136 */     if (this.addedLocalVariables != null) {
/* 137 */       this.addedLocalVariables.clear();
/*     */     }
/*     */     
/* 140 */     this.removeLocalVariable = false;
/* 141 */     if (this.removedLocalVariableNames != null) {
/* 142 */       this.removedLocalVariableNames.clear();
/*     */     }
/*     */     
/* 145 */     this.setSelectionTarget = false;
/* 146 */     this.selectionTargetObject = null;
/*     */     
/* 148 */     this.setInliner = false;
/* 149 */     this.setInlinerValue = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void resetAllButLocalVariables()
/*     */   {
/* 156 */     this.insertText = false;
/* 157 */     this.insertTextValue = null;
/* 158 */     this.insertTextProcessable = false;
/*     */     
/* 160 */     this.insertModel = false;
/* 161 */     this.insertModelValue = null;
/* 162 */     this.insertModelProcessable = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void applyContextModifications(IEngineContext engineContext)
/*     */   {
/* 171 */     if (this.setLocalVariable) {
/* 172 */       engineContext.setVariables(this.addedLocalVariables);
/*     */     }
/*     */     
/* 175 */     if (this.removeLocalVariable) {
/* 176 */       for (String variableName : this.removedLocalVariableNames) {
/* 177 */         engineContext.removeVariable(variableName);
/*     */       }
/*     */     }
/*     */     
/* 181 */     if (this.setSelectionTarget) {
/* 182 */       engineContext.setSelectionTarget(this.selectionTargetObject);
/*     */     }
/*     */     
/* 185 */     if (this.setInliner) {
/* 186 */       engineContext.setInliner(this.setInlinerValue);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\TemplateBoundariesStructureHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */