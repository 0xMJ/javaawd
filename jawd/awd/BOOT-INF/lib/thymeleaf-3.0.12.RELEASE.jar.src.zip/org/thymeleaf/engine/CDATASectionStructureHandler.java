/*    */ package org.thymeleaf.engine;
/*    */ 
/*    */ import org.thymeleaf.model.IModel;
/*    */ import org.thymeleaf.processor.cdatasection.ICDATASectionStructureHandler;
/*    */ import org.thymeleaf.util.Validate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class CDATASectionStructureHandler
/*    */   implements ICDATASectionStructureHandler
/*    */ {
/*    */   boolean setContent;
/*    */   CharSequence setContentValue;
/*    */   boolean replaceWithModel;
/*    */   IModel replaceWithModelValue;
/*    */   boolean replaceWithModelProcessable;
/*    */   boolean removeCDATASection;
/*    */   
/*    */   CDATASectionStructureHandler()
/*    */   {
/* 55 */     reset();
/*    */   }
/*    */   
/*    */ 
/*    */   public void setContent(CharSequence content)
/*    */   {
/* 61 */     reset();
/* 62 */     Validate.notNull(content, "Content cannot be null");
/* 63 */     this.setContent = true;
/* 64 */     this.setContentValue = content;
/*    */   }
/*    */   
/*    */   public void replaceWith(IModel model, boolean processable)
/*    */   {
/* 69 */     reset();
/* 70 */     Validate.notNull(model, "Model cannot be null");
/* 71 */     this.replaceWithModel = true;
/* 72 */     this.replaceWithModelValue = model;
/* 73 */     this.replaceWithModelProcessable = processable;
/*    */   }
/*    */   
/*    */   public void removeCDATASection()
/*    */   {
/* 78 */     reset();
/* 79 */     this.removeCDATASection = true;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void reset()
/*    */   {
/* 87 */     this.setContent = false;
/* 88 */     this.setContentValue = null;
/*    */     
/* 90 */     this.replaceWithModel = false;
/* 91 */     this.replaceWithModelValue = null;
/* 92 */     this.replaceWithModelProcessable = false;
/*    */     
/* 94 */     this.removeCDATASection = false;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\CDATASectionStructureHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */