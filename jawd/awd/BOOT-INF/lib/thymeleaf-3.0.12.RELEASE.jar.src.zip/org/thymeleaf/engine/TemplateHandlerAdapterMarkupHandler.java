/*     */ package org.thymeleaf.engine;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.attoparser.AbstractMarkupHandler;
/*     */ import org.attoparser.ParseException;
/*     */ import org.thymeleaf.model.AttributeValueQuotes;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class TemplateHandlerAdapterMarkupHandler
/*     */   extends AbstractMarkupHandler
/*     */ {
/*     */   private final String templateName;
/*     */   private final ITemplateHandler templateHandler;
/*     */   private final ElementDefinitions elementDefinitions;
/*     */   private final AttributeDefinitions attributeDefinitions;
/*     */   private final TemplateMode templateMode;
/*     */   private final int lineOffset;
/*     */   private final int colOffset;
/*  48 */   private int currentElementLine = -1;
/*  49 */   private int currentElementCol = -1;
/*     */   
/*     */ 
/*     */ 
/*     */   private final List<Attribute> currentElementAttributes;
/*     */   
/*     */ 
/*     */ 
/*     */   private final List<String> currentElementInnerWhiteSpaces;
/*     */   
/*     */ 
/*     */ 
/*     */   public TemplateHandlerAdapterMarkupHandler(String templateName, ITemplateHandler templateHandler, ElementDefinitions elementDefinitions, AttributeDefinitions attributeDefinitions, TemplateMode templateMode, int lineOffset, int colOffset)
/*     */   {
/*  63 */     Validate.notNull(templateHandler, "Template handler cannot be null");
/*  64 */     Validate.notNull(elementDefinitions, "Element Definitions repository cannot be null");
/*  65 */     Validate.notNull(attributeDefinitions, "Attribute Definitions repository cannot be null");
/*  66 */     Validate.notNull(templateMode, "Template mode cannot be null");
/*     */     
/*  68 */     this.templateName = templateName;
/*     */     
/*  70 */     this.templateHandler = templateHandler;
/*     */     
/*     */ 
/*  73 */     this.elementDefinitions = elementDefinitions;
/*  74 */     this.attributeDefinitions = attributeDefinitions;
/*  75 */     this.templateMode = templateMode;
/*  76 */     this.lineOffset = (lineOffset > 0 ? lineOffset - 1 : lineOffset);
/*  77 */     this.colOffset = (colOffset > 0 ? colOffset - 1 : colOffset);
/*     */     
/*     */ 
/*  80 */     this.currentElementAttributes = new ArrayList(10);
/*  81 */     this.currentElementInnerWhiteSpaces = new ArrayList(10);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleDocumentStart(long startTimeNanos, int line, int col)
/*     */     throws ParseException
/*     */   {
/*  92 */     this.templateHandler.handleTemplateStart(TemplateStart.TEMPLATE_START_INSTANCE);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleDocumentEnd(long endTimeNanos, long totalTimeNanos, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 101 */     this.templateHandler.handleTemplateEnd(TemplateEnd.TEMPLATE_END_INSTANCE);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleXmlDeclaration(char[] buffer, int keywordOffset, int keywordLen, int keywordLine, int keywordCol, int versionOffset, int versionLen, int versionLine, int versionCol, int encodingOffset, int encodingLen, int encodingLine, int encodingCol, int standaloneOffset, int standaloneLen, int standaloneLine, int standaloneCol, int outerOffset, int outerLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 121 */     String fullXmlDeclaration = new String(buffer, outerOffset, outerLen);
/* 122 */     String keyword = new String(buffer, keywordOffset, keywordLen);
/*     */     
/* 124 */     String version = versionLen == 0 ? null : new String(buffer, versionOffset, versionLen);
/*     */     
/* 126 */     String encoding = encodingLen == 0 ? null : new String(buffer, encodingOffset, encodingLen);
/*     */     
/* 128 */     String standalone = standaloneLen == 0 ? null : new String(buffer, standaloneOffset, standaloneLen);
/*     */     
/* 130 */     this.templateHandler.handleXMLDeclaration(new XMLDeclaration(fullXmlDeclaration, keyword, version, encoding, standalone, this.templateName, this.lineOffset + line, 
/*     */     
/*     */ 
/* 133 */       (line == 1 ? this.colOffset : 0) + col));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleDocType(char[] buffer, int keywordOffset, int keywordLen, int keywordLine, int keywordCol, int elementNameOffset, int elementNameLen, int elementNameLine, int elementNameCol, int typeOffset, int typeLen, int typeLine, int typeCol, int publicIdOffset, int publicIdLen, int publicIdLine, int publicIdCol, int systemIdOffset, int systemIdLen, int systemIdLine, int systemIdCol, int internalSubsetOffset, int internalSubsetLen, int internalSubsetLine, int internalSubsetCol, int outerOffset, int outerLen, int outerLine, int outerCol)
/*     */     throws ParseException
/*     */   {
/* 158 */     String fullDocType = new String(buffer, outerOffset, outerLen);
/* 159 */     String keyword = new String(buffer, keywordOffset, keywordLen);
/* 160 */     String rootElementName = new String(buffer, elementNameOffset, elementNameLen);
/* 161 */     String publicId = publicIdLen == 0 ? null : new String(buffer, publicIdOffset, publicIdLen);
/* 162 */     String systemId = systemIdLen == 0 ? null : new String(buffer, systemIdOffset, systemIdLen);
/* 163 */     String internalSubset = internalSubsetLen == 0 ? null : new String(buffer, internalSubsetOffset, internalSubsetLen);
/*     */     
/* 165 */     this.templateHandler.handleDocType(new DocType(fullDocType, keyword, rootElementName, publicId, systemId, internalSubset, this.templateName, this.lineOffset + outerLine, 
/*     */     
/*     */ 
/* 168 */       (outerLine == 1 ? this.colOffset : 0) + outerCol));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleCDATASection(char[] buffer, int contentOffset, int contentLen, int outerOffset, int outerLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 182 */     String prefix = new String(buffer, outerOffset, contentOffset - outerOffset);
/* 183 */     String content = new String(buffer, contentOffset, contentLen);
/* 184 */     String suffix = new String(buffer, contentOffset + contentLen, outerOffset + outerLen - (contentOffset + contentLen));
/*     */     
/* 186 */     this.templateHandler.handleCDATASection(new CDATASection(prefix, content, suffix, this.templateName, this.lineOffset + line, 
/* 187 */       (line == 1 ? this.colOffset : 0) + col));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleComment(char[] buffer, int contentOffset, int contentLen, int outerOffset, int outerLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 201 */     String prefix = new String(buffer, outerOffset, contentOffset - outerOffset);
/* 202 */     String content = new String(buffer, contentOffset, contentLen);
/* 203 */     String suffix = new String(buffer, contentOffset + contentLen, outerOffset + outerLen - (contentOffset + contentLen));
/*     */     
/* 205 */     this.templateHandler.handleComment(new Comment(prefix, content, suffix, this.templateName, this.lineOffset + line, 
/* 206 */       (line == 1 ? this.colOffset : 0) + col));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleText(char[] buffer, int offset, int len, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 218 */     this.templateHandler.handleText(new Text(new String(buffer, offset, len), this.templateName, this.lineOffset + line, 
/* 219 */       (line == 1 ? this.colOffset : 0) + col));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleStandaloneElementStart(char[] buffer, int nameOffset, int nameLen, boolean minimized, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 232 */     this.currentElementLine = line;
/* 233 */     this.currentElementCol = col;
/* 234 */     this.currentElementAttributes.clear();
/* 235 */     this.currentElementInnerWhiteSpaces.clear();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleStandaloneElementEnd(char[] buffer, int nameOffset, int nameLen, boolean minimized, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 246 */     String elementCompleteName = new String(buffer, nameOffset, nameLen);
/* 247 */     ElementDefinition elementDefinition = this.elementDefinitions.forName(this.templateMode, elementCompleteName);
/*     */     Attributes attributes;
/*     */     Attributes attributes;
/* 250 */     if ((this.currentElementAttributes.isEmpty()) && (this.currentElementInnerWhiteSpaces.isEmpty())) {
/* 251 */       attributes = null;
/*     */     }
/*     */     else
/*     */     {
/* 255 */       Attribute[] attributesArr = this.currentElementAttributes.isEmpty() ? Attributes.EMPTY_ATTRIBUTE_ARRAY : (Attribute[])this.currentElementAttributes.toArray(new Attribute[this.currentElementAttributes.size()]);
/* 256 */       String[] innerWhiteSpaces = (String[])this.currentElementInnerWhiteSpaces.toArray(new String[this.currentElementInnerWhiteSpaces.size()]);
/* 257 */       attributes = new Attributes(attributesArr, innerWhiteSpaces);
/*     */     }
/*     */     
/* 260 */     this.templateHandler.handleStandaloneElement(new StandaloneElementTag(this.templateMode, elementDefinition, elementCompleteName, attributes, false, minimized, this.templateName, this.lineOffset + this.currentElementLine, 
/*     */     
/*     */ 
/* 263 */       (this.currentElementLine == 1 ? this.colOffset : 0) + this.currentElementCol));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleOpenElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 276 */     this.currentElementLine = line;
/* 277 */     this.currentElementCol = col;
/* 278 */     this.currentElementAttributes.clear();
/* 279 */     this.currentElementInnerWhiteSpaces.clear();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleOpenElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 290 */     String elementCompleteName = new String(buffer, nameOffset, nameLen);
/* 291 */     ElementDefinition elementDefinition = this.elementDefinitions.forName(this.templateMode, elementCompleteName);
/*     */     Attributes attributes;
/*     */     Attributes attributes;
/* 294 */     if ((this.currentElementAttributes.isEmpty()) && (this.currentElementInnerWhiteSpaces.isEmpty())) {
/* 295 */       attributes = null;
/*     */     }
/*     */     else
/*     */     {
/* 299 */       Attribute[] attributesArr = this.currentElementAttributes.isEmpty() ? Attributes.EMPTY_ATTRIBUTE_ARRAY : (Attribute[])this.currentElementAttributes.toArray(new Attribute[this.currentElementAttributes.size()]);
/* 300 */       String[] innerWhiteSpaces = (String[])this.currentElementInnerWhiteSpaces.toArray(new String[this.currentElementInnerWhiteSpaces.size()]);
/* 301 */       attributes = new Attributes(attributesArr, innerWhiteSpaces);
/*     */     }
/*     */     
/* 304 */     this.templateHandler.handleOpenElement(new OpenElementTag(this.templateMode, elementDefinition, elementCompleteName, attributes, false, this.templateName, this.lineOffset + this.currentElementLine, 
/*     */     
/*     */ 
/* 307 */       (this.currentElementLine == 1 ? this.colOffset : 0) + this.currentElementCol));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleAutoOpenElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 320 */     this.currentElementLine = line;
/* 321 */     this.currentElementCol = col;
/* 322 */     this.currentElementAttributes.clear();
/* 323 */     this.currentElementInnerWhiteSpaces.clear();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleAutoOpenElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 334 */     String elementCompleteName = new String(buffer, nameOffset, nameLen);
/* 335 */     ElementDefinition elementDefinition = this.elementDefinitions.forName(this.templateMode, elementCompleteName);
/*     */     Attributes attributes;
/*     */     Attributes attributes;
/* 338 */     if ((this.currentElementAttributes.isEmpty()) && (this.currentElementInnerWhiteSpaces.isEmpty())) {
/* 339 */       attributes = null;
/*     */     }
/*     */     else
/*     */     {
/* 343 */       Attribute[] attributesArr = this.currentElementAttributes.isEmpty() ? Attributes.EMPTY_ATTRIBUTE_ARRAY : (Attribute[])this.currentElementAttributes.toArray(new Attribute[this.currentElementAttributes.size()]);
/* 344 */       String[] innerWhiteSpaces = (String[])this.currentElementInnerWhiteSpaces.toArray(new String[this.currentElementInnerWhiteSpaces.size()]);
/* 345 */       attributes = new Attributes(attributesArr, innerWhiteSpaces);
/*     */     }
/*     */     
/* 348 */     this.templateHandler.handleOpenElement(new OpenElementTag(this.templateMode, elementDefinition, elementCompleteName, attributes, true, this.templateName, this.lineOffset + this.currentElementLine, 
/*     */     
/*     */ 
/* 351 */       (this.currentElementLine == 1 ? this.colOffset : 0) + this.currentElementCol));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleCloseElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 364 */     this.currentElementLine = line;
/* 365 */     this.currentElementCol = col;
/* 366 */     this.currentElementAttributes.clear();
/* 367 */     this.currentElementInnerWhiteSpaces.clear();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleCloseElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 378 */     String elementCompleteName = new String(buffer, nameOffset, nameLen);
/* 379 */     ElementDefinition elementDefinition = this.elementDefinitions.forName(this.templateMode, elementCompleteName);
/*     */     String trailingWhiteSpace;
/*     */     String trailingWhiteSpace;
/* 382 */     if (this.currentElementInnerWhiteSpaces.isEmpty()) {
/* 383 */       trailingWhiteSpace = null;
/*     */     } else {
/* 385 */       trailingWhiteSpace = (String)this.currentElementInnerWhiteSpaces.get(0);
/*     */     }
/*     */     
/* 388 */     this.templateHandler.handleCloseElement(new CloseElementTag(this.templateMode, elementDefinition, elementCompleteName, trailingWhiteSpace, false, false, this.templateName, this.lineOffset + this.currentElementLine, 
/*     */     
/*     */ 
/* 391 */       (this.currentElementLine == 1 ? this.colOffset : 0) + this.currentElementCol));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleAutoCloseElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 404 */     this.currentElementLine = line;
/* 405 */     this.currentElementCol = col;
/* 406 */     this.currentElementAttributes.clear();
/* 407 */     this.currentElementInnerWhiteSpaces.clear();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleAutoCloseElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 418 */     String elementCompleteName = new String(buffer, nameOffset, nameLen);
/* 419 */     ElementDefinition elementDefinition = this.elementDefinitions.forName(this.templateMode, elementCompleteName);
/*     */     String trailingWhiteSpace;
/*     */     String trailingWhiteSpace;
/* 422 */     if (this.currentElementInnerWhiteSpaces.isEmpty()) {
/* 423 */       trailingWhiteSpace = null;
/*     */     } else {
/* 425 */       trailingWhiteSpace = (String)this.currentElementInnerWhiteSpaces.get(0);
/*     */     }
/*     */     
/* 428 */     this.templateHandler.handleCloseElement(new CloseElementTag(this.templateMode, elementDefinition, elementCompleteName, trailingWhiteSpace, true, false, this.templateName, this.lineOffset + this.currentElementLine, 
/*     */     
/*     */ 
/* 431 */       (this.currentElementLine == 1 ? this.colOffset : 0) + this.currentElementCol));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleUnmatchedCloseElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 444 */     this.currentElementLine = line;
/* 445 */     this.currentElementCol = col;
/* 446 */     this.currentElementAttributes.clear();
/* 447 */     this.currentElementInnerWhiteSpaces.clear();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleUnmatchedCloseElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 459 */     String elementCompleteName = new String(buffer, nameOffset, nameLen);
/* 460 */     ElementDefinition elementDefinition = this.elementDefinitions.forName(this.templateMode, elementCompleteName);
/*     */     String trailingWhiteSpace;
/*     */     String trailingWhiteSpace;
/* 463 */     if (this.currentElementInnerWhiteSpaces.isEmpty()) {
/* 464 */       trailingWhiteSpace = null;
/*     */     } else {
/* 466 */       trailingWhiteSpace = (String)this.currentElementInnerWhiteSpaces.get(0);
/*     */     }
/*     */     
/* 469 */     this.templateHandler.handleCloseElement(new CloseElementTag(this.templateMode, elementDefinition, elementCompleteName, trailingWhiteSpace, false, true, this.templateName, this.lineOffset + this.currentElementLine, 
/*     */     
/*     */ 
/* 472 */       (this.currentElementLine == 1 ? this.colOffset : 0) + this.currentElementCol));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleAttribute(char[] buffer, int nameOffset, int nameLen, int nameLine, int nameCol, int operatorOffset, int operatorLen, int operatorLine, int operatorCol, int valueContentOffset, int valueContentLen, int valueOuterOffset, int valueOuterLen, int valueLine, int valueCol)
/*     */     throws ParseException
/*     */   {
/* 490 */     String attributeName = new String(buffer, nameOffset, nameLen);
/*     */     
/* 492 */     AttributeDefinition attributeDefinition = this.attributeDefinitions.forName(this.templateMode, attributeName);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 499 */     String attributeOperator = operatorLen > 0 ? new String(buffer, operatorOffset, operatorLen) : (operatorLen == 1) && (buffer[operatorOffset] == '=') ? "=" : null;
/*     */     
/*     */ 
/* 502 */     String value = attributeOperator != null ? new String(buffer, valueContentOffset, valueContentLen) : null;
/*     */     AttributeValueQuotes valueQuotes;
/*     */     AttributeValueQuotes valueQuotes;
/* 505 */     if (value == null) {
/* 506 */       valueQuotes = null; } else { AttributeValueQuotes valueQuotes;
/* 507 */       if (valueOuterOffset == valueContentOffset) {
/* 508 */         valueQuotes = AttributeValueQuotes.NONE; } else { AttributeValueQuotes valueQuotes;
/* 509 */         if (buffer[valueOuterOffset] == '"') {
/* 510 */           valueQuotes = AttributeValueQuotes.DOUBLE; } else { AttributeValueQuotes valueQuotes;
/* 511 */           if (buffer[valueOuterOffset] == '\'') {
/* 512 */             valueQuotes = AttributeValueQuotes.SINGLE;
/*     */           } else {
/* 514 */             valueQuotes = AttributeValueQuotes.NONE;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 520 */     Attribute newAttribute = new Attribute(attributeDefinition, attributeName, attributeOperator, value, valueQuotes, this.templateName, this.lineOffset + nameLine, (nameLine == 1 ? this.colOffset : 0) + nameCol);
/*     */     
/* 522 */     this.currentElementAttributes.add(newAttribute);
/*     */     
/*     */ 
/* 525 */     if (this.currentElementInnerWhiteSpaces.size() < this.currentElementAttributes.size()) {
/* 526 */       this.currentElementInnerWhiteSpaces.add("");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void handleInnerWhiteSpace(char[] buffer, int offset, int len, int line, int col)
/*     */     throws ParseException
/*     */   {
/*     */     String elementWhiteSpace;
/*     */     
/*     */ 
/*     */     String elementWhiteSpace;
/*     */     
/*     */ 
/* 541 */     if ((len == 1) && (buffer[offset] == ' ')) {
/* 542 */       elementWhiteSpace = " ";
/*     */     } else {
/* 544 */       elementWhiteSpace = new String(buffer, offset, len);
/*     */     }
/*     */     
/* 547 */     this.currentElementInnerWhiteSpaces.add(elementWhiteSpace);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleProcessingInstruction(char[] buffer, int targetOffset, int targetLen, int targetLine, int targetCol, int contentOffset, int contentLen, int contentLine, int contentCol, int outerOffset, int outerLen, int line, int col)
/*     */     throws ParseException
/*     */   {
/* 564 */     String fullProcessingInstruction = new String(buffer, outerOffset, outerLen);
/* 565 */     String target = new String(buffer, targetOffset, targetLen);
/* 566 */     String content = contentLen == 0 ? null : new String(buffer, contentOffset, contentLen);
/*     */     
/* 568 */     this.templateHandler.handleProcessingInstruction(new ProcessingInstruction(fullProcessingInstruction, target, content, this.templateName, this.lineOffset + line, 
/* 569 */       (line == 1 ? this.colOffset : 0) + col));
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\TemplateHandlerAdapterMarkupHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */