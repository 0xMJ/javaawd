/*      */ package org.thymeleaf.engine;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.locks.Lock;
/*      */ import java.util.concurrent.locks.ReadWriteLock;
/*      */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*      */ import org.thymeleaf.exceptions.ConfigurationException;
/*      */ import org.thymeleaf.processor.element.IElementProcessor;
/*      */ import org.thymeleaf.processor.element.MatchingAttributeName;
/*      */ import org.thymeleaf.processor.element.MatchingElementName;
/*      */ import org.thymeleaf.templatemode.TemplateMode;
/*      */ import org.thymeleaf.util.TextUtils;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class ElementDefinitions
/*      */ {
/*      */   public static final Set<String> ALL_STANDARD_HTML_ELEMENT_NAMES;
/*   53 */   private static final HTMLElementDefinitionSpec HTML = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("html"), HTMLElementType.NORMAL);
/*      */   
/*      */ 
/*   56 */   private static final HTMLElementDefinitionSpec HEAD = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("head"), HTMLElementType.NORMAL);
/*   57 */   private static final HTMLElementDefinitionSpec TITLE = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("title"), HTMLElementType.ESCAPABLE_RAW_TEXT);
/*   58 */   private static final HTMLElementDefinitionSpec BASE = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("base"), HTMLElementType.VOID);
/*   59 */   private static final HTMLElementDefinitionSpec LINK = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("link"), HTMLElementType.VOID);
/*   60 */   private static final HTMLElementDefinitionSpec META = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("meta"), HTMLElementType.VOID);
/*   61 */   private static final HTMLElementDefinitionSpec STYLE = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("style"), HTMLElementType.RAW_TEXT);
/*      */   
/*      */ 
/*   64 */   private static final HTMLElementDefinitionSpec SCRIPT = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("script"), HTMLElementType.RAW_TEXT);
/*   65 */   private static final HTMLElementDefinitionSpec NOSCRIPT = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("noscript"), HTMLElementType.NORMAL);
/*      */   
/*      */ 
/*   68 */   private static final HTMLElementDefinitionSpec BODY = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("body"), HTMLElementType.NORMAL);
/*   69 */   private static final HTMLElementDefinitionSpec ARTICLE = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("article"), HTMLElementType.NORMAL);
/*   70 */   private static final HTMLElementDefinitionSpec SECTION = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("section"), HTMLElementType.NORMAL);
/*   71 */   private static final HTMLElementDefinitionSpec NAV = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("nav"), HTMLElementType.NORMAL);
/*   72 */   private static final HTMLElementDefinitionSpec ASIDE = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("aside"), HTMLElementType.NORMAL);
/*   73 */   private static final HTMLElementDefinitionSpec H1 = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("h1"), HTMLElementType.NORMAL);
/*   74 */   private static final HTMLElementDefinitionSpec H2 = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("h2"), HTMLElementType.NORMAL);
/*   75 */   private static final HTMLElementDefinitionSpec H3 = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("h3"), HTMLElementType.NORMAL);
/*   76 */   private static final HTMLElementDefinitionSpec H4 = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("h4"), HTMLElementType.NORMAL);
/*   77 */   private static final HTMLElementDefinitionSpec H5 = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("h5"), HTMLElementType.NORMAL);
/*   78 */   private static final HTMLElementDefinitionSpec H6 = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("h6"), HTMLElementType.NORMAL);
/*   79 */   private static final HTMLElementDefinitionSpec HGROUP = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("hgroup"), HTMLElementType.NORMAL);
/*   80 */   private static final HTMLElementDefinitionSpec HEADER = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("header"), HTMLElementType.NORMAL);
/*   81 */   private static final HTMLElementDefinitionSpec FOOTER = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("footer"), HTMLElementType.NORMAL);
/*   82 */   private static final HTMLElementDefinitionSpec ADDRESS = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("address"), HTMLElementType.NORMAL);
/*   83 */   private static final HTMLElementDefinitionSpec MAIN = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("main"), HTMLElementType.NORMAL);
/*      */   
/*      */ 
/*   86 */   private static final HTMLElementDefinitionSpec P = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("p"), HTMLElementType.NORMAL);
/*   87 */   private static final HTMLElementDefinitionSpec HR = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("hr"), HTMLElementType.VOID);
/*   88 */   private static final HTMLElementDefinitionSpec PRE = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("pre"), HTMLElementType.NORMAL);
/*   89 */   private static final HTMLElementDefinitionSpec BLOCKQUOTE = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("blockquote"), HTMLElementType.NORMAL);
/*   90 */   private static final HTMLElementDefinitionSpec OL = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("ol"), HTMLElementType.NORMAL);
/*   91 */   private static final HTMLElementDefinitionSpec UL = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("ul"), HTMLElementType.NORMAL);
/*   92 */   private static final HTMLElementDefinitionSpec LI = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("li"), HTMLElementType.NORMAL);
/*   93 */   private static final HTMLElementDefinitionSpec DL = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("dl"), HTMLElementType.NORMAL);
/*   94 */   private static final HTMLElementDefinitionSpec DT = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("dt"), HTMLElementType.NORMAL);
/*   95 */   private static final HTMLElementDefinitionSpec DD = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("dd"), HTMLElementType.NORMAL);
/*   96 */   private static final HTMLElementDefinitionSpec FIGURE = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("figure"), HTMLElementType.NORMAL);
/*   97 */   private static final HTMLElementDefinitionSpec FIGCAPTION = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("figcaption"), HTMLElementType.NORMAL);
/*   98 */   private static final HTMLElementDefinitionSpec DIV = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("div"), HTMLElementType.NORMAL);
/*      */   
/*      */ 
/*  101 */   private static final HTMLElementDefinitionSpec A = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("a"), HTMLElementType.NORMAL);
/*  102 */   private static final HTMLElementDefinitionSpec EM = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("em"), HTMLElementType.NORMAL);
/*  103 */   private static final HTMLElementDefinitionSpec STRONG = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("strong"), HTMLElementType.NORMAL);
/*  104 */   private static final HTMLElementDefinitionSpec SMALL = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("small"), HTMLElementType.NORMAL);
/*  105 */   private static final HTMLElementDefinitionSpec S = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("s"), HTMLElementType.NORMAL);
/*  106 */   private static final HTMLElementDefinitionSpec CITE = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("cite"), HTMLElementType.NORMAL);
/*  107 */   private static final HTMLElementDefinitionSpec G = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("g"), HTMLElementType.NORMAL);
/*  108 */   private static final HTMLElementDefinitionSpec DFN = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("dfn"), HTMLElementType.NORMAL);
/*  109 */   private static final HTMLElementDefinitionSpec ABBR = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("abbr"), HTMLElementType.NORMAL);
/*  110 */   private static final HTMLElementDefinitionSpec TIME = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("time"), HTMLElementType.NORMAL);
/*  111 */   private static final HTMLElementDefinitionSpec CODE = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("code"), HTMLElementType.NORMAL);
/*  112 */   private static final HTMLElementDefinitionSpec VAR = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("var"), HTMLElementType.NORMAL);
/*  113 */   private static final HTMLElementDefinitionSpec SAMP = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("samp"), HTMLElementType.NORMAL);
/*  114 */   private static final HTMLElementDefinitionSpec KBD = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("kbd"), HTMLElementType.NORMAL);
/*  115 */   private static final HTMLElementDefinitionSpec SUB = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("sub"), HTMLElementType.NORMAL);
/*  116 */   private static final HTMLElementDefinitionSpec SUP = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("sup"), HTMLElementType.NORMAL);
/*  117 */   private static final HTMLElementDefinitionSpec I = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("i"), HTMLElementType.NORMAL);
/*  118 */   private static final HTMLElementDefinitionSpec B = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("b"), HTMLElementType.NORMAL);
/*  119 */   private static final HTMLElementDefinitionSpec U = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("u"), HTMLElementType.NORMAL);
/*  120 */   private static final HTMLElementDefinitionSpec MARK = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("mark"), HTMLElementType.NORMAL);
/*  121 */   private static final HTMLElementDefinitionSpec RUBY = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("ruby"), HTMLElementType.NORMAL);
/*  122 */   private static final HTMLElementDefinitionSpec RB = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("rb"), HTMLElementType.NORMAL);
/*  123 */   private static final HTMLElementDefinitionSpec RT = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("rt"), HTMLElementType.NORMAL);
/*  124 */   private static final HTMLElementDefinitionSpec RTC = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("rtc"), HTMLElementType.NORMAL);
/*  125 */   private static final HTMLElementDefinitionSpec RP = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("rp"), HTMLElementType.NORMAL);
/*  126 */   private static final HTMLElementDefinitionSpec BDI = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("bdi"), HTMLElementType.NORMAL);
/*  127 */   private static final HTMLElementDefinitionSpec BDO = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("bdo"), HTMLElementType.NORMAL);
/*  128 */   private static final HTMLElementDefinitionSpec SPAN = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("span"), HTMLElementType.NORMAL);
/*  129 */   private static final HTMLElementDefinitionSpec BR = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("br"), HTMLElementType.VOID);
/*  130 */   private static final HTMLElementDefinitionSpec WBR = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("wbr"), HTMLElementType.VOID);
/*      */   
/*      */ 
/*  133 */   private static final HTMLElementDefinitionSpec INS = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("ins"), HTMLElementType.NORMAL);
/*  134 */   private static final HTMLElementDefinitionSpec DEL = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("del"), HTMLElementType.NORMAL);
/*      */   
/*      */ 
/*  137 */   private static final HTMLElementDefinitionSpec IMG = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("img"), HTMLElementType.VOID);
/*  138 */   private static final HTMLElementDefinitionSpec IFRAME = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("iframe"), HTMLElementType.NORMAL);
/*  139 */   private static final HTMLElementDefinitionSpec EMBED = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("embed"), HTMLElementType.VOID);
/*  140 */   private static final HTMLElementDefinitionSpec OBJECT = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("object"), HTMLElementType.NORMAL);
/*  141 */   private static final HTMLElementDefinitionSpec PARAM = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("param"), HTMLElementType.VOID);
/*  142 */   private static final HTMLElementDefinitionSpec VIDEO = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("video"), HTMLElementType.NORMAL);
/*  143 */   private static final HTMLElementDefinitionSpec AUDIO = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("audio"), HTMLElementType.NORMAL);
/*  144 */   private static final HTMLElementDefinitionSpec SOURCE = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("source"), HTMLElementType.VOID);
/*  145 */   private static final HTMLElementDefinitionSpec TRACK = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("track"), HTMLElementType.VOID);
/*  146 */   private static final HTMLElementDefinitionSpec CANVAS = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("canvas"), HTMLElementType.NORMAL);
/*  147 */   private static final HTMLElementDefinitionSpec MAP = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("map"), HTMLElementType.NORMAL);
/*  148 */   private static final HTMLElementDefinitionSpec AREA = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("area"), HTMLElementType.VOID);
/*      */   
/*      */ 
/*  151 */   private static final HTMLElementDefinitionSpec TABLE = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("table"), HTMLElementType.NORMAL);
/*  152 */   private static final HTMLElementDefinitionSpec CAPTION = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("caption"), HTMLElementType.NORMAL);
/*  153 */   private static final HTMLElementDefinitionSpec COLGROUP = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("colgroup"), HTMLElementType.NORMAL);
/*  154 */   private static final HTMLElementDefinitionSpec COL = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("col"), HTMLElementType.VOID);
/*  155 */   private static final HTMLElementDefinitionSpec TBODY = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("tbody"), HTMLElementType.NORMAL);
/*  156 */   private static final HTMLElementDefinitionSpec THEAD = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("thead"), HTMLElementType.NORMAL);
/*  157 */   private static final HTMLElementDefinitionSpec TFOOT = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("tfoot"), HTMLElementType.NORMAL);
/*  158 */   private static final HTMLElementDefinitionSpec TR = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("tr"), HTMLElementType.NORMAL);
/*  159 */   private static final HTMLElementDefinitionSpec TD = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("td"), HTMLElementType.NORMAL);
/*  160 */   private static final HTMLElementDefinitionSpec TH = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("th"), HTMLElementType.NORMAL);
/*      */   
/*      */ 
/*  163 */   private static final HTMLElementDefinitionSpec FORM = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("form"), HTMLElementType.NORMAL);
/*  164 */   private static final HTMLElementDefinitionSpec FIELDSET = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("fieldset"), HTMLElementType.NORMAL);
/*  165 */   private static final HTMLElementDefinitionSpec LEGEND = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("legend"), HTMLElementType.NORMAL);
/*  166 */   private static final HTMLElementDefinitionSpec LABEL = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("label"), HTMLElementType.NORMAL);
/*  167 */   private static final HTMLElementDefinitionSpec INPUT = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("input"), HTMLElementType.VOID);
/*  168 */   private static final HTMLElementDefinitionSpec BUTTON = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("button"), HTMLElementType.NORMAL);
/*  169 */   private static final HTMLElementDefinitionSpec SELECT = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("select"), HTMLElementType.NORMAL);
/*  170 */   private static final HTMLElementDefinitionSpec DATALIST = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("datalist"), HTMLElementType.NORMAL);
/*  171 */   private static final HTMLElementDefinitionSpec OPTGROUP = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("optgroup"), HTMLElementType.NORMAL);
/*  172 */   private static final HTMLElementDefinitionSpec OPTION = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("option"), HTMLElementType.NORMAL);
/*  173 */   private static final HTMLElementDefinitionSpec TEXTAREA = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("textarea"), HTMLElementType.ESCAPABLE_RAW_TEXT);
/*  174 */   private static final HTMLElementDefinitionSpec KEYGEN = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("keygen"), HTMLElementType.VOID);
/*  175 */   private static final HTMLElementDefinitionSpec OUTPUT = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("output"), HTMLElementType.NORMAL);
/*  176 */   private static final HTMLElementDefinitionSpec PROGRESS = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("progress"), HTMLElementType.NORMAL);
/*  177 */   private static final HTMLElementDefinitionSpec METER = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("meter"), HTMLElementType.NORMAL);
/*      */   
/*      */ 
/*  180 */   private static final HTMLElementDefinitionSpec DETAILS = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("details"), HTMLElementType.NORMAL);
/*  181 */   private static final HTMLElementDefinitionSpec SUMMARY = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("summary"), HTMLElementType.NORMAL);
/*  182 */   private static final HTMLElementDefinitionSpec COMMAND = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("command"), HTMLElementType.NORMAL);
/*  183 */   private static final HTMLElementDefinitionSpec MENU = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("menu"), HTMLElementType.NORMAL);
/*  184 */   private static final HTMLElementDefinitionSpec MENUITEM = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("menuitem"), HTMLElementType.VOID);
/*  185 */   private static final HTMLElementDefinitionSpec DIALOG = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("dialog"), HTMLElementType.NORMAL);
/*      */   
/*      */ 
/*  188 */   private static final HTMLElementDefinitionSpec TEMPLATE = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("template"), HTMLElementType.RAW_TEXT);
/*  189 */   private static final HTMLElementDefinitionSpec ELEMENT = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("element"), HTMLElementType.NORMAL);
/*  190 */   private static final HTMLElementDefinitionSpec DECORATOR = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("decorator"), HTMLElementType.NORMAL);
/*  191 */   private static final HTMLElementDefinitionSpec CONTENT = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("content"), HTMLElementType.NORMAL);
/*  192 */   private static final HTMLElementDefinitionSpec SHADOW = new HTMLElementDefinitionSpec(ElementNames.forHTMLName("shadow"), HTMLElementType.NORMAL);
/*      */   
/*      */ 
/*      */ 
/*      */   private final ElementDefinitionRepository htmlElementRepository;
/*      */   
/*      */ 
/*      */ 
/*      */   private final ElementDefinitionRepository xmlElementRepository;
/*      */   
/*      */ 
/*      */ 
/*      */   private final ElementDefinitionRepository textElementRepository;
/*      */   
/*      */ 
/*      */ 
/*      */   private final ElementDefinitionRepository javascriptElementRepository;
/*      */   
/*      */ 
/*      */   private final ElementDefinitionRepository cssElementRepository;
/*      */   
/*      */ 
/*      */ 
/*      */   static
/*      */   {
/*  217 */     List<String> htmlElementDefinitionNamesAux = new ArrayList(HTMLElementDefinitionSpec.ALL_SPECS.size() + 1);
/*  218 */     for (HTMLElementDefinitionSpec elementDefinitionSpec : HTMLElementDefinitionSpec.ALL_SPECS) {
/*  219 */       for (String completeElementName : elementDefinitionSpec.name.completeElementNames) {
/*  220 */         htmlElementDefinitionNamesAux.add(completeElementName);
/*      */       }
/*      */     }
/*      */     
/*  224 */     Collections.sort(htmlElementDefinitionNamesAux);
/*      */     
/*  226 */     ALL_STANDARD_HTML_ELEMENT_NAMES = Collections.unmodifiableSet(new LinkedHashSet(htmlElementDefinitionNamesAux));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ElementDefinitions(Map<TemplateMode, Set<IElementProcessor>> elementProcessorsByTemplateMode)
/*      */   {
/*  245 */     List<HTMLElementDefinition> standardHTMLElementDefinitions = new ArrayList(HTMLElementDefinitionSpec.ALL_SPECS.size() + 1);
/*  246 */     for (HTMLElementDefinitionSpec definitionSpec : HTMLElementDefinitionSpec.ALL_SPECS) {
/*  247 */       standardHTMLElementDefinitions.add(
/*  248 */         buildHTMLElementDefinition(definitionSpec.name, definitionSpec.type, (Set)elementProcessorsByTemplateMode.get(TemplateMode.HTML)));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  255 */     this.htmlElementRepository = new ElementDefinitionRepository(TemplateMode.HTML, elementProcessorsByTemplateMode);
/*  256 */     this.xmlElementRepository = new ElementDefinitionRepository(TemplateMode.XML, elementProcessorsByTemplateMode);
/*  257 */     this.textElementRepository = new ElementDefinitionRepository(TemplateMode.TEXT, elementProcessorsByTemplateMode);
/*  258 */     this.javascriptElementRepository = new ElementDefinitionRepository(TemplateMode.JAVASCRIPT, elementProcessorsByTemplateMode);
/*  259 */     this.cssElementRepository = new ElementDefinitionRepository(TemplateMode.CSS, elementProcessorsByTemplateMode);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  265 */     for (HTMLElementDefinition elementDefinition : standardHTMLElementDefinitions) {
/*  266 */       this.htmlElementRepository.storeStandardElement(elementDefinition);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static HTMLElementDefinition buildHTMLElementDefinition(HTMLElementName name, HTMLElementType type, Set<IElementProcessor> elementProcessors)
/*      */   {
/*  278 */     Set<IElementProcessor> associatedProcessors = new LinkedHashSet(2);
/*      */     
/*  280 */     if (elementProcessors != null) {
/*  281 */       for (IElementProcessor processor : elementProcessors)
/*      */       {
/*      */ 
/*  284 */         TemplateMode templateMode = processor.getTemplateMode();
/*      */         
/*  286 */         if (templateMode == TemplateMode.HTML)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*  291 */           MatchingElementName matchingElementName = processor.getMatchingElementName();
/*  292 */           MatchingAttributeName matchingAttributeName = processor.getMatchingAttributeName();
/*      */           
/*  294 */           if (((matchingElementName != null) && (matchingElementName.getTemplateMode() != TemplateMode.HTML)) || ((matchingAttributeName != null) && 
/*  295 */             (matchingAttributeName.getTemplateMode() != TemplateMode.HTML))) {
/*  296 */             throw new ConfigurationException("HTML processors must return HTML element names and HTML attribute names (processor: " + processor.getClass().getName() + ")");
/*      */           }
/*      */           
/*  299 */           if (((matchingAttributeName == null) || (matchingAttributeName.isMatchingAllAttributes())) && (
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  306 */             (matchingElementName == null) || (matchingElementName.matches(name))))
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*  311 */             associatedProcessors.add(processor);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  317 */     return new HTMLElementDefinition(name, type, associatedProcessors);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static XMLElementDefinition buildXMLElementDefinition(XMLElementName name, Set<IElementProcessor> elementProcessors)
/*      */   {
/*  328 */     Set<IElementProcessor> associatedProcessors = new LinkedHashSet(2);
/*      */     
/*  330 */     if (elementProcessors != null) {
/*  331 */       for (IElementProcessor processor : elementProcessors)
/*      */       {
/*      */ 
/*  334 */         TemplateMode templateMode = processor.getTemplateMode();
/*      */         
/*  336 */         if (templateMode == TemplateMode.XML)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*  341 */           MatchingElementName matchingElementName = processor.getMatchingElementName();
/*  342 */           MatchingAttributeName matchingAttributeName = processor.getMatchingAttributeName();
/*      */           
/*  344 */           if (((matchingElementName != null) && (matchingElementName.getTemplateMode() != TemplateMode.XML)) || ((matchingAttributeName != null) && 
/*  345 */             (matchingAttributeName.getTemplateMode() != TemplateMode.XML))) {
/*  346 */             throw new ConfigurationException("XML processors must return XML element names and XML attribute names (processor: " + processor.getClass().getName() + ")");
/*      */           }
/*      */           
/*  349 */           if (((matchingAttributeName == null) || (matchingAttributeName.isMatchingAllAttributes())) && (
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  356 */             (matchingElementName == null) || (matchingElementName.matches(name))))
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  362 */             associatedProcessors.add(processor);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  368 */     return new XMLElementDefinition(name, associatedProcessors);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static TextElementDefinition buildTextElementDefinition(TemplateMode templateMode, TextElementName name, Set<IElementProcessor> elementProcessors)
/*      */   {
/*  379 */     Set<IElementProcessor> associatedProcessors = new LinkedHashSet(2);
/*      */     
/*  381 */     if (elementProcessors != null) {
/*  382 */       for (IElementProcessor processor : elementProcessors)
/*      */       {
/*  384 */         if (processor.getTemplateMode() == templateMode)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*  389 */           MatchingElementName matchingElementName = processor.getMatchingElementName();
/*  390 */           MatchingAttributeName matchingAttributeName = processor.getMatchingAttributeName();
/*      */           
/*  392 */           if (((matchingElementName != null) && (matchingElementName.getTemplateMode() != templateMode)) || ((matchingAttributeName != null) && 
/*  393 */             (matchingAttributeName.getTemplateMode() != templateMode))) {
/*  394 */             throw new ConfigurationException(templateMode + " processors must return " + templateMode + "element names and " + templateMode + " attribute names (processor: " + processor.getClass().getName() + ")");
/*      */           }
/*      */           
/*  397 */           if (((matchingAttributeName == null) || (matchingAttributeName.isMatchingAllAttributes())) && (
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  404 */             (matchingElementName == null) || (matchingElementName.matches(name))))
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  410 */             associatedProcessors.add(processor);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  416 */     return new TextElementDefinition(name, associatedProcessors);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public ElementDefinition forName(TemplateMode templateMode, String elementName)
/*      */   {
/*  424 */     if (templateMode == null) {
/*  425 */       throw new IllegalArgumentException("Template Mode cannot be null");
/*      */     }
/*  427 */     switch (templateMode) {
/*      */     case HTML: 
/*  429 */       return forHTMLName(elementName);
/*      */     case XML: 
/*  431 */       return forXMLName(elementName);
/*      */     case TEXT: 
/*  433 */       return forTextName(elementName);
/*      */     case JAVASCRIPT: 
/*  435 */       return forJavaScriptName(elementName);
/*      */     case CSS: 
/*  437 */       return forCSSName(elementName);
/*      */     case RAW: 
/*  439 */       throw new IllegalArgumentException("Element Definitions cannot be obtained for " + templateMode + " template mode ");
/*      */     }
/*  441 */     throw new IllegalArgumentException("Unknown template mode " + templateMode);
/*      */   }
/*      */   
/*      */ 
/*      */   public ElementDefinition forName(TemplateMode templateMode, String prefix, String elementName)
/*      */   {
/*  447 */     if (templateMode == null) {
/*  448 */       throw new IllegalArgumentException("Template Mode cannot be null");
/*      */     }
/*  450 */     switch (templateMode) {
/*      */     case HTML: 
/*  452 */       return forHTMLName(prefix, elementName);
/*      */     case XML: 
/*  454 */       return forXMLName(prefix, elementName);
/*      */     case TEXT: 
/*  456 */       return forTextName(prefix, elementName);
/*      */     case JAVASCRIPT: 
/*  458 */       return forJavaScriptName(prefix, elementName);
/*      */     case CSS: 
/*  460 */       return forCSSName(prefix, elementName);
/*      */     case RAW: 
/*  462 */       throw new IllegalArgumentException("Element Definitions cannot be obtained for " + templateMode + " template mode ");
/*      */     }
/*  464 */     throw new IllegalArgumentException("Unknown template mode " + templateMode);
/*      */   }
/*      */   
/*      */ 
/*      */   public ElementDefinition forName(TemplateMode templateMode, char[] elementName, int elementNameOffset, int elementNameLen)
/*      */   {
/*  470 */     if (templateMode == null) {
/*  471 */       throw new IllegalArgumentException("Template Mode cannot be null");
/*      */     }
/*  473 */     switch (templateMode) {
/*      */     case HTML: 
/*  475 */       return forHTMLName(elementName, elementNameOffset, elementNameLen);
/*      */     case XML: 
/*  477 */       return forXMLName(elementName, elementNameOffset, elementNameLen);
/*      */     case TEXT: 
/*  479 */       return forTextName(elementName, elementNameOffset, elementNameLen);
/*      */     case JAVASCRIPT: 
/*  481 */       return forJavaScriptName(elementName, elementNameOffset, elementNameLen);
/*      */     case CSS: 
/*  483 */       return forCSSName(elementName, elementNameOffset, elementNameLen);
/*      */     case RAW: 
/*  485 */       throw new IllegalArgumentException("Element Definitions cannot be obtained for " + templateMode + " template mode ");
/*      */     }
/*  487 */     throw new IllegalArgumentException("Unknown template mode " + templateMode);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public HTMLElementDefinition forHTMLName(String elementName)
/*      */   {
/*  495 */     if ((elementName == null) || (elementName.length() == 0)) {
/*  496 */       throw new IllegalArgumentException("Name cannot be null or empty");
/*      */     }
/*  498 */     return (HTMLElementDefinition)this.htmlElementRepository.getElement(elementName);
/*      */   }
/*      */   
/*      */   public HTMLElementDefinition forHTMLName(String prefix, String elementName)
/*      */   {
/*  503 */     if ((elementName == null) || (elementName.length() == 0)) {
/*  504 */       throw new IllegalArgumentException("Name cannot be null or empty");
/*      */     }
/*  506 */     return (HTMLElementDefinition)this.htmlElementRepository.getElement(prefix, elementName);
/*      */   }
/*      */   
/*      */   public HTMLElementDefinition forHTMLName(char[] elementName, int elementNameOffset, int elementNameLen)
/*      */   {
/*  511 */     if ((elementName == null) || (elementNameLen == 0)) {
/*  512 */       throw new IllegalArgumentException("Name cannot be null or empty");
/*      */     }
/*  514 */     if ((elementNameOffset < 0) || (elementNameLen < 0)) {
/*  515 */       throw new IllegalArgumentException("Both name offset and length must be equal to or greater than zero");
/*      */     }
/*  517 */     return (HTMLElementDefinition)this.htmlElementRepository.getElement(elementName, elementNameOffset, elementNameLen);
/*      */   }
/*      */   
/*      */ 
/*      */   public XMLElementDefinition forXMLName(String elementName)
/*      */   {
/*  523 */     if ((elementName == null) || (elementName.length() == 0)) {
/*  524 */       throw new IllegalArgumentException("Name cannot be null or empty");
/*      */     }
/*  526 */     return (XMLElementDefinition)this.xmlElementRepository.getElement(elementName);
/*      */   }
/*      */   
/*      */   public XMLElementDefinition forXMLName(String prefix, String elementName)
/*      */   {
/*  531 */     if ((elementName == null) || (elementName.length() == 0)) {
/*  532 */       throw new IllegalArgumentException("Name cannot be null or empty");
/*      */     }
/*  534 */     return (XMLElementDefinition)this.xmlElementRepository.getElement(prefix, elementName);
/*      */   }
/*      */   
/*      */   public XMLElementDefinition forXMLName(char[] elementName, int elementNameOffset, int elementNameLen)
/*      */   {
/*  539 */     if ((elementName == null) || (elementNameLen == 0)) {
/*  540 */       throw new IllegalArgumentException("Name cannot be null or empty");
/*      */     }
/*  542 */     if ((elementNameOffset < 0) || (elementNameLen < 0)) {
/*  543 */       throw new IllegalArgumentException("Both name offset and length must be equal to or greater than zero");
/*      */     }
/*  545 */     return (XMLElementDefinition)this.xmlElementRepository.getElement(elementName, elementNameOffset, elementNameLen);
/*      */   }
/*      */   
/*      */ 
/*      */   public TextElementDefinition forTextName(String elementName)
/*      */   {
/*  551 */     if (elementName == null) {
/*  552 */       throw new IllegalArgumentException("Name cannot be null");
/*      */     }
/*  554 */     return (TextElementDefinition)this.textElementRepository.getElement(elementName);
/*      */   }
/*      */   
/*      */   public TextElementDefinition forTextName(String prefix, String elementName)
/*      */   {
/*  559 */     if (elementName == null) {
/*  560 */       throw new IllegalArgumentException("Name cannot be null");
/*      */     }
/*  562 */     return (TextElementDefinition)this.textElementRepository.getElement(prefix, elementName);
/*      */   }
/*      */   
/*      */   public TextElementDefinition forTextName(char[] elementName, int elementNameOffset, int elementNameLen)
/*      */   {
/*  567 */     if (elementName == null) {
/*  568 */       throw new IllegalArgumentException("Name cannot be null");
/*      */     }
/*  570 */     if ((elementNameOffset < 0) || (elementNameLen < 0)) {
/*  571 */       throw new IllegalArgumentException("Both name offset and length must be equal to or greater than zero");
/*      */     }
/*  573 */     return (TextElementDefinition)this.textElementRepository.getElement(elementName, elementNameOffset, elementNameLen);
/*      */   }
/*      */   
/*      */ 
/*      */   public TextElementDefinition forJavaScriptName(String elementName)
/*      */   {
/*  579 */     if (elementName == null) {
/*  580 */       throw new IllegalArgumentException("Name cannot be null or empty");
/*      */     }
/*  582 */     return (TextElementDefinition)this.javascriptElementRepository.getElement(elementName);
/*      */   }
/*      */   
/*      */   public TextElementDefinition forJavaScriptName(String prefix, String elementName)
/*      */   {
/*  587 */     if (elementName == null) {
/*  588 */       throw new IllegalArgumentException("Name cannot be null or empty");
/*      */     }
/*  590 */     return (TextElementDefinition)this.javascriptElementRepository.getElement(prefix, elementName);
/*      */   }
/*      */   
/*      */   public TextElementDefinition forJavaScriptName(char[] elementName, int elementNameOffset, int elementNameLen)
/*      */   {
/*  595 */     if (elementName == null) {
/*  596 */       throw new IllegalArgumentException("Name cannot be null or empty");
/*      */     }
/*  598 */     if ((elementNameOffset < 0) || (elementNameLen < 0)) {
/*  599 */       throw new IllegalArgumentException("Both name offset and length must be equal to or greater than zero");
/*      */     }
/*  601 */     return (TextElementDefinition)this.javascriptElementRepository.getElement(elementName, elementNameOffset, elementNameLen);
/*      */   }
/*      */   
/*      */ 
/*      */   public TextElementDefinition forCSSName(String elementName)
/*      */   {
/*  607 */     if (elementName == null) {
/*  608 */       throw new IllegalArgumentException("Name cannot be null or empty");
/*      */     }
/*  610 */     return (TextElementDefinition)this.cssElementRepository.getElement(elementName);
/*      */   }
/*      */   
/*      */   public TextElementDefinition forCSSName(String prefix, String elementName)
/*      */   {
/*  615 */     if (elementName == null) {
/*  616 */       throw new IllegalArgumentException("Name cannot be null or empty");
/*      */     }
/*  618 */     return (TextElementDefinition)this.cssElementRepository.getElement(prefix, elementName);
/*      */   }
/*      */   
/*      */   public TextElementDefinition forCSSName(char[] elementName, int elementNameOffset, int elementNameLen)
/*      */   {
/*  623 */     if (elementName == null) {
/*  624 */       throw new IllegalArgumentException("Name cannot be null or empty");
/*      */     }
/*  626 */     if ((elementNameOffset < 0) || (elementNameLen < 0)) {
/*  627 */       throw new IllegalArgumentException("Both name offset and length must be equal to or greater than zero");
/*      */     }
/*  629 */     return (TextElementDefinition)this.cssElementRepository.getElement(elementName, elementNameOffset, elementNameLen);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   static final class ElementDefinitionRepository
/*      */   {
/*      */     private final TemplateMode templateMode;
/*      */     
/*      */ 
/*      */ 
/*      */     private final Map<TemplateMode, Set<IElementProcessor>> elementProcessorsByTemplateMode;
/*      */     
/*      */ 
/*      */ 
/*      */     private final List<String> standardRepositoryNames;
/*      */     
/*      */ 
/*      */ 
/*      */     private final List<ElementDefinition> standardRepository;
/*      */     
/*      */ 
/*      */     private final List<String> repositoryNames;
/*      */     
/*      */ 
/*      */     private final List<ElementDefinition> repository;
/*      */     
/*      */ 
/*  658 */     private final ReadWriteLock lock = new ReentrantReadWriteLock(true);
/*  659 */     private final Lock readLock = this.lock.readLock();
/*  660 */     private final Lock writeLock = this.lock.writeLock();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     ElementDefinitionRepository(TemplateMode templateMode, Map<TemplateMode, Set<IElementProcessor>> elementProcessorsByTemplateMode)
/*      */     {
/*  667 */       this.templateMode = templateMode;
/*  668 */       this.elementProcessorsByTemplateMode = elementProcessorsByTemplateMode;
/*      */       
/*  670 */       this.standardRepositoryNames = (templateMode == TemplateMode.HTML ? new ArrayList(150) : null);
/*  671 */       this.standardRepository = (templateMode == TemplateMode.HTML ? new ArrayList(150) : null);
/*      */       
/*  673 */       this.repositoryNames = new ArrayList(150);
/*  674 */       this.repository = new ArrayList(150);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     ElementDefinition getElement(char[] text, int offset, int len)
/*      */     {
/*  683 */       if (this.standardRepository != null)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*  688 */         int index = binarySearch(this.templateMode.isCaseSensitive(), this.standardRepositoryNames, text, offset, len);
/*      */         
/*  690 */         if (index >= 0) {
/*  691 */           return (ElementDefinition)this.standardRepository.get(index);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  701 */       this.readLock.lock();
/*      */       
/*      */       ElementDefinition localElementDefinition;
/*      */       
/*      */       try
/*      */       {
/*  707 */         int index = binarySearch(this.templateMode.isCaseSensitive(), this.repositoryNames, text, offset, len);
/*      */         
/*  709 */         if (index >= 0) {
/*  710 */           return (ElementDefinition)this.repository.get(index);
/*      */         }
/*      */       }
/*      */       finally {
/*  714 */         this.readLock.unlock();
/*      */       }
/*      */       
/*      */ 
/*      */       int index;
/*      */       
/*      */ 
/*  721 */       this.writeLock.lock();
/*      */       try {
/*  723 */         return storeElement(text, offset, len);
/*      */       } finally {
/*  725 */         this.writeLock.unlock();
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     ElementDefinition getElement(String completeElementName)
/*      */     {
/*  735 */       if (this.standardRepository != null)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*  740 */         int index = binarySearch(this.templateMode.isCaseSensitive(), this.standardRepositoryNames, completeElementName);
/*      */         
/*  742 */         if (index >= 0) {
/*  743 */           return (ElementDefinition)this.standardRepository.get(index);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  752 */       this.readLock.lock();
/*      */       
/*      */       ElementDefinition localElementDefinition;
/*      */       
/*      */       try
/*      */       {
/*  758 */         int index = binarySearch(this.templateMode.isCaseSensitive(), this.repositoryNames, completeElementName);
/*      */         
/*  760 */         if (index >= 0) {
/*  761 */           return (ElementDefinition)this.repository.get(index);
/*      */         }
/*      */       }
/*      */       finally {
/*  765 */         this.readLock.unlock();
/*      */       }
/*      */       
/*      */ 
/*      */       int index;
/*      */       
/*      */ 
/*  772 */       this.writeLock.lock();
/*      */       try {
/*  774 */         return storeElement(completeElementName);
/*      */       } finally {
/*  776 */         this.writeLock.unlock();
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     ElementDefinition getElement(String prefix, String elementName)
/*      */     {
/*  786 */       if (this.standardRepository != null)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*  791 */         int index = binarySearch(this.templateMode.isCaseSensitive(), this.standardRepositoryNames, prefix, elementName);
/*      */         
/*  793 */         if (index >= 0) {
/*  794 */           return (ElementDefinition)this.standardRepository.get(index);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  803 */       this.readLock.lock();
/*      */       
/*      */       ElementDefinition localElementDefinition;
/*      */       
/*      */       try
/*      */       {
/*  809 */         int index = binarySearch(this.templateMode.isCaseSensitive(), this.repositoryNames, prefix, elementName);
/*      */         
/*  811 */         if (index >= 0) {
/*  812 */           return (ElementDefinition)this.repository.get(index);
/*      */         }
/*      */       }
/*      */       finally {
/*  816 */         this.readLock.unlock();
/*      */       }
/*      */       
/*      */ 
/*      */       int index;
/*      */       
/*      */ 
/*  823 */       this.writeLock.lock();
/*      */       try {
/*  825 */         return storeElement(prefix, elementName);
/*      */       } finally {
/*  827 */         this.writeLock.unlock();
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     private ElementDefinition storeElement(char[] text, int offset, int len)
/*      */     {
/*  835 */       int index = binarySearch(this.templateMode.isCaseSensitive(), this.repositoryNames, text, offset, len);
/*  836 */       if (index >= 0)
/*      */       {
/*  838 */         return (ElementDefinition)this.repository.get(index);
/*      */       }
/*      */       
/*  841 */       Set<IElementProcessor> elementProcessors = (Set)this.elementProcessorsByTemplateMode.get(this.templateMode);
/*      */       ElementDefinition elementDefinition;
/*      */       ElementDefinition elementDefinition;
/*  844 */       if (this.templateMode == TemplateMode.HTML)
/*      */       {
/*  846 */         elementDefinition = ElementDefinitions.buildHTMLElementDefinition(ElementNames.forHTMLName(text, offset, len), HTMLElementType.NORMAL, elementProcessors); } else { ElementDefinition elementDefinition;
/*  847 */         if (this.templateMode == TemplateMode.XML)
/*      */         {
/*  849 */           elementDefinition = ElementDefinitions.buildXMLElementDefinition(ElementNames.forXMLName(text, offset, len), elementProcessors);
/*      */         }
/*      */         else {
/*  852 */           elementDefinition = ElementDefinitions.buildTextElementDefinition(this.templateMode, ElementNames.forTextName(text, offset, len), elementProcessors);
/*      */         }
/*      */       }
/*  855 */       String[] completeElementNames = elementDefinition.elementName.completeElementNames;
/*      */       
/*  857 */       for (String completeElementName : completeElementNames)
/*      */       {
/*  859 */         index = binarySearch(this.templateMode.isCaseSensitive(), this.repositoryNames, completeElementName);
/*      */         
/*      */ 
/*  862 */         this.repositoryNames.add((index + 1) * -1, completeElementName);
/*  863 */         this.repository.add((index + 1) * -1, elementDefinition);
/*      */       }
/*      */       
/*      */ 
/*  867 */       return elementDefinition;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     private ElementDefinition storeElement(String text)
/*      */     {
/*  874 */       int index = binarySearch(this.templateMode.isCaseSensitive(), this.repositoryNames, text);
/*  875 */       if (index >= 0)
/*      */       {
/*  877 */         return (ElementDefinition)this.repository.get(index);
/*      */       }
/*      */       
/*  880 */       Set<IElementProcessor> elementProcessors = (Set)this.elementProcessorsByTemplateMode.get(this.templateMode);
/*      */       ElementDefinition elementDefinition;
/*      */       ElementDefinition elementDefinition;
/*  883 */       if (this.templateMode == TemplateMode.HTML)
/*      */       {
/*  885 */         elementDefinition = ElementDefinitions.buildHTMLElementDefinition(ElementNames.forHTMLName(text), HTMLElementType.NORMAL, elementProcessors); } else { ElementDefinition elementDefinition;
/*  886 */         if (this.templateMode == TemplateMode.XML)
/*      */         {
/*  888 */           elementDefinition = ElementDefinitions.buildXMLElementDefinition(ElementNames.forXMLName(text), elementProcessors);
/*      */         }
/*      */         else {
/*  891 */           elementDefinition = ElementDefinitions.buildTextElementDefinition(this.templateMode, ElementNames.forTextName(text), elementProcessors);
/*      */         }
/*      */       }
/*  894 */       String[] completeElementNames = elementDefinition.elementName.completeElementNames;
/*      */       
/*  896 */       for (String completeElementName : completeElementNames)
/*      */       {
/*  898 */         index = binarySearch(this.templateMode.isCaseSensitive(), this.repositoryNames, completeElementName);
/*      */         
/*      */ 
/*  901 */         this.repositoryNames.add((index + 1) * -1, completeElementName);
/*  902 */         this.repository.add((index + 1) * -1, elementDefinition);
/*      */       }
/*      */       
/*      */ 
/*  906 */       return elementDefinition;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     private ElementDefinition storeElement(String prefix, String elementName)
/*      */     {
/*  913 */       int index = binarySearch(this.templateMode.isCaseSensitive(), this.repositoryNames, prefix, elementName);
/*  914 */       if (index >= 0)
/*      */       {
/*  916 */         return (ElementDefinition)this.repository.get(index);
/*      */       }
/*      */       
/*  919 */       Set<IElementProcessor> elementProcessors = (Set)this.elementProcessorsByTemplateMode.get(this.templateMode);
/*      */       ElementDefinition elementDefinition;
/*      */       ElementDefinition elementDefinition;
/*  922 */       if (this.templateMode == TemplateMode.HTML)
/*      */       {
/*  924 */         elementDefinition = ElementDefinitions.buildHTMLElementDefinition(ElementNames.forHTMLName(prefix, elementName), HTMLElementType.NORMAL, elementProcessors); } else { ElementDefinition elementDefinition;
/*  925 */         if (this.templateMode == TemplateMode.XML)
/*      */         {
/*  927 */           elementDefinition = ElementDefinitions.buildXMLElementDefinition(ElementNames.forXMLName(prefix, elementName), elementProcessors);
/*      */         }
/*      */         else {
/*  930 */           elementDefinition = ElementDefinitions.buildTextElementDefinition(this.templateMode, ElementNames.forTextName(prefix, elementName), elementProcessors);
/*      */         }
/*      */       }
/*  933 */       String[] completeElementNames = elementDefinition.elementName.completeElementNames;
/*      */       
/*  935 */       for (String completeElementName : completeElementNames)
/*      */       {
/*  937 */         index = binarySearch(this.templateMode.isCaseSensitive(), this.repositoryNames, completeElementName);
/*      */         
/*      */ 
/*  940 */         this.repositoryNames.add((index + 1) * -1, completeElementName);
/*  941 */         this.repository.add((index + 1) * -1, elementDefinition);
/*      */       }
/*      */       
/*      */ 
/*  945 */       return elementDefinition;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private ElementDefinition storeStandardElement(ElementDefinition elementDefinition)
/*      */     {
/*  955 */       String[] completeElementNames = elementDefinition.elementName.completeElementNames;
/*      */       
/*      */ 
/*  958 */       for (String completeElementName : completeElementNames)
/*      */       {
/*  960 */         int index = binarySearch(this.templateMode.isCaseSensitive(), this.standardRepositoryNames, completeElementName);
/*      */         
/*      */ 
/*  963 */         this.standardRepositoryNames.add((index + 1) * -1, completeElementName);
/*  964 */         this.standardRepository.add((index + 1) * -1, elementDefinition);
/*      */         
/*  966 */         index = binarySearch(this.templateMode.isCaseSensitive(), this.repositoryNames, completeElementName);
/*      */         
/*      */ 
/*  969 */         this.repositoryNames.add((index + 1) * -1, completeElementName);
/*  970 */         this.repository.add((index + 1) * -1, elementDefinition);
/*      */       }
/*      */       
/*      */ 
/*  974 */       return elementDefinition;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private static int binarySearch(boolean caseSensitive, List<String> values, char[] text, int offset, int len)
/*      */     {
/*  982 */       int low = 0;
/*  983 */       int high = values.size() - 1;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  988 */       while (low <= high)
/*      */       {
/*  990 */         int mid = low + high >>> 1;
/*  991 */         String midVal = (String)values.get(mid);
/*      */         
/*  993 */         int cmp = TextUtils.compareTo(caseSensitive, midVal, 0, midVal.length(), text, offset, len);
/*      */         
/*  995 */         if (cmp < 0) {
/*  996 */           low = mid + 1;
/*  997 */         } else if (cmp > 0) {
/*  998 */           high = mid - 1;
/*      */         }
/*      */         else {
/* 1001 */           return mid;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 1006 */       return -(low + 1);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     private static int binarySearch(boolean caseSensitive, List<String> values, String text)
/*      */     {
/* 1013 */       int low = 0;
/* 1014 */       int high = values.size() - 1;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1019 */       while (low <= high)
/*      */       {
/* 1021 */         int mid = low + high >>> 1;
/* 1022 */         String midVal = (String)values.get(mid);
/*      */         
/* 1024 */         int cmp = TextUtils.compareTo(caseSensitive, midVal, text);
/*      */         
/* 1026 */         if (cmp < 0) {
/* 1027 */           low = mid + 1;
/* 1028 */         } else if (cmp > 0) {
/* 1029 */           high = mid - 1;
/*      */         }
/*      */         else {
/* 1032 */           return mid;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 1037 */       return -(low + 1);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private static int binarySearch(boolean caseSensitive, List<String> values, String prefix, String elementName)
/*      */     {
/* 1047 */       if ((prefix == null) || (prefix.trim().length() == 0)) {
/* 1048 */         return binarySearch(caseSensitive, values, elementName);
/*      */       }
/*      */       
/* 1051 */       int prefixLen = prefix.length();
/* 1052 */       int elementNameLen = elementName.length();
/*      */       
/* 1054 */       int low = 0;
/* 1055 */       int high = values.size() - 1;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1061 */       while (low <= high)
/*      */       {
/* 1063 */         int mid = low + high >>> 1;
/* 1064 */         String midVal = (String)values.get(mid);
/* 1065 */         int midValLen = midVal.length();
/*      */         
/* 1067 */         if (TextUtils.startsWith(caseSensitive, midVal, prefix))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/* 1072 */           if (midValLen <= prefixLen)
/*      */           {
/*      */ 
/* 1075 */             low = mid + 1;
/*      */ 
/*      */           }
/*      */           else
/*      */           {
/* 1080 */             int cmp = midVal.charAt(prefixLen) - ':';
/*      */             
/* 1082 */             if (cmp < 0) {
/* 1083 */               low = mid + 1;
/* 1084 */             } else if (cmp > 0) {
/* 1085 */               high = mid - 1;
/*      */             }
/*      */             else
/*      */             {
/* 1089 */               cmp = TextUtils.compareTo(caseSensitive, midVal, prefixLen + 1, midValLen - (prefixLen + 1), elementName, 0, elementNameLen);
/*      */               
/* 1091 */               if (cmp < 0) {
/* 1092 */                 low = mid + 1;
/* 1093 */               } else if (cmp > 0) {
/* 1094 */                 high = mid - 1;
/*      */               }
/*      */               else {
/* 1097 */                 return mid;
/*      */               }
/*      */               
/*      */             }
/*      */             
/*      */           }
/*      */           
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/* 1108 */           int cmp = TextUtils.compareTo(caseSensitive, midVal, prefix);
/*      */           
/* 1110 */           if (cmp < 0) {
/* 1111 */             low = mid + 1;
/* 1112 */           } else if (cmp > 0) {
/* 1113 */             high = mid - 1;
/*      */           }
/*      */           else {
/* 1116 */             throw new IllegalStateException("Bad comparison of midVal \"" + midVal + "\" and prefix \"" + prefix + "\"");
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1123 */       return -(low + 1);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final class HTMLElementDefinitionSpec
/*      */   {
/* 1135 */     static final List<HTMLElementDefinitionSpec> ALL_SPECS = new ArrayList();
/*      */     
/*      */     HTMLElementName name;
/*      */     HTMLElementType type;
/*      */     
/*      */     HTMLElementDefinitionSpec(HTMLElementName name, HTMLElementType type)
/*      */     {
/* 1142 */       this.name = name;
/* 1143 */       this.type = type;
/* 1144 */       ALL_SPECS.add(this);
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\ElementDefinitions.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */