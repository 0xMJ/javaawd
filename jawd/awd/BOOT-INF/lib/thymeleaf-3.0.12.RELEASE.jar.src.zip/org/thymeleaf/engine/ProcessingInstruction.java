/*     */ package org.thymeleaf.engine;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import org.thymeleaf.model.IModelVisitor;
/*     */ import org.thymeleaf.model.IProcessingInstruction;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ProcessingInstruction
/*     */   extends AbstractTemplateEvent
/*     */   implements IProcessingInstruction, IEngineTemplateEvent
/*     */ {
/*     */   private final String target;
/*     */   private final String content;
/*     */   private final String processingInstruction;
/*     */   
/*     */   ProcessingInstruction(String target, String content)
/*     */   {
/*  48 */     this.target = target;
/*  49 */     this.content = content;
/*  50 */     this.processingInstruction = computeProcessingInstruction();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   ProcessingInstruction(String processingInstruction, String target, String content, String templateName, int line, int col)
/*     */   {
/*  59 */     super(templateName, line, col);
/*  60 */     this.target = target;
/*  61 */     this.content = content;
/*  62 */     this.processingInstruction = (processingInstruction != null ? processingInstruction : computeProcessingInstruction());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getTarget()
/*     */   {
/*  69 */     return this.target;
/*     */   }
/*     */   
/*     */   public String getContent() {
/*  73 */     return this.content;
/*     */   }
/*     */   
/*     */   public String getProcessingInstruction() {
/*  77 */     return this.processingInstruction;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private String computeProcessingInstruction()
/*     */   {
/*  84 */     StringBuilder strBuilder = new StringBuilder(100);
/*     */     
/*  86 */     strBuilder.append("<?");
/*  87 */     strBuilder.append(this.target);
/*  88 */     if (this.content != null) {
/*  89 */       strBuilder.append(' ');
/*  90 */       strBuilder.append(this.content);
/*     */     }
/*  92 */     strBuilder.append("?>");
/*     */     
/*  94 */     return strBuilder.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void accept(IModelVisitor visitor)
/*     */   {
/* 102 */     visitor.visit(this);
/*     */   }
/*     */   
/*     */   public void write(Writer writer) throws IOException
/*     */   {
/* 107 */     writer.write(this.processingInstruction);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static ProcessingInstruction asEngineProcessingInstruction(IProcessingInstruction processingInstruction)
/*     */   {
/* 115 */     if ((processingInstruction instanceof ProcessingInstruction)) {
/* 116 */       return (ProcessingInstruction)processingInstruction;
/*     */     }
/*     */     
/* 119 */     return new ProcessingInstruction(null, processingInstruction
/*     */     
/* 121 */       .getTarget(), processingInstruction.getContent(), processingInstruction
/* 122 */       .getTemplateName(), processingInstruction.getLine(), processingInstruction.getCol());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void beHandled(ITemplateHandler handler)
/*     */   {
/* 131 */     handler.handleProcessingInstruction(this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 139 */     return getProcessingInstruction();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\ProcessingInstruction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */