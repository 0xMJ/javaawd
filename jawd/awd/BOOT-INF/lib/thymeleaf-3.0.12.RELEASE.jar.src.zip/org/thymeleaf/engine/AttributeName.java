/*     */ package org.thymeleaf.engine;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AttributeName
/*     */ {
/*     */   protected final String prefix;
/*     */   protected final String attributeName;
/*     */   protected final String[] completeAttributeNames;
/*     */   private final int h;
/*     */   
/*     */   protected AttributeName(String prefix, String attributeName, String[] completeAttributeNames)
/*     */   {
/*  50 */     if ((attributeName == null) || (attributeName.trim().length() == 0)) {
/*  51 */       throw new IllegalArgumentException("Attribute name cannot be null or empty");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  56 */     this.prefix = prefix;
/*  57 */     this.attributeName = attributeName;
/*  58 */     this.completeAttributeNames = completeAttributeNames;
/*  59 */     this.h = Arrays.hashCode(this.completeAttributeNames);
/*     */   }
/*     */   
/*     */ 
/*     */   public String getAttributeName()
/*     */   {
/*  65 */     return this.attributeName;
/*     */   }
/*     */   
/*     */   public boolean isPrefixed() {
/*  69 */     return this.prefix != null;
/*     */   }
/*     */   
/*     */   public String getPrefix() {
/*  73 */     return this.prefix;
/*     */   }
/*     */   
/*     */   public String[] getCompleteAttributeNames() {
/*  77 */     return this.completeAttributeNames;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/*  86 */     if (this == o) {
/*  87 */       return true;
/*     */     }
/*     */     
/*  90 */     if (o == null) {
/*  91 */       return false;
/*     */     }
/*     */     
/*  94 */     if (!o.getClass().equals(getClass())) {
/*  95 */       return false;
/*     */     }
/*     */     
/*  98 */     AttributeName that = (AttributeName)o;
/*     */     
/* 100 */     if (this.h != that.h) {
/* 101 */       return false;
/*     */     }
/*     */     
/* 104 */     if (!this.completeAttributeNames[0].equals(that.completeAttributeNames[0]))
/*     */     {
/* 106 */       return false;
/*     */     }
/*     */     
/* 109 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 118 */     return this.h;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 126 */     StringBuilder strBuilder = new StringBuilder();
/* 127 */     strBuilder.append('{');
/* 128 */     strBuilder.append(this.completeAttributeNames[0]);
/* 129 */     for (int i = 1; i < this.completeAttributeNames.length; i++) {
/* 130 */       strBuilder.append(',');
/* 131 */       strBuilder.append(this.completeAttributeNames[i]);
/*     */     }
/* 133 */     strBuilder.append('}');
/* 134 */     return strBuilder.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\AttributeName.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */