/*     */ package org.thymeleaf.engine;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.thymeleaf.context.IEngineContext;
/*     */ import org.thymeleaf.inline.IInliner;
/*     */ import org.thymeleaf.model.AttributeValueQuotes;
/*     */ import org.thymeleaf.model.IModel;
/*     */ import org.thymeleaf.processor.element.IElementTagStructureHandler;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ElementTagStructureHandler
/*     */   implements IElementTagStructureHandler
/*     */ {
/*     */   boolean setBodyText;
/*     */   CharSequence setBodyTextValue;
/*     */   boolean setBodyTextProcessable;
/*     */   boolean setBodyModel;
/*     */   IModel setBodyModelValue;
/*     */   boolean setBodyModelProcessable;
/*     */   boolean insertBeforeModel;
/*     */   IModel insertBeforeModelValue;
/*     */   boolean insertImmediatelyAfterModel;
/*     */   IModel insertImmediatelyAfterModelValue;
/*     */   boolean insertImmediatelyAfterModelProcessable;
/*     */   boolean replaceWithText;
/*     */   CharSequence replaceWithTextValue;
/*     */   boolean replaceWithTextProcessable;
/*     */   boolean replaceWithModel;
/*     */   IModel replaceWithModelValue;
/*     */   boolean replaceWithModelProcessable;
/*     */   boolean removeElement;
/*     */   boolean removeTags;
/*     */   boolean removeBody;
/*     */   boolean removeAllButFirstChild;
/*     */   boolean setLocalVariable;
/*     */   Map<String, Object> addedLocalVariables;
/*     */   boolean removeLocalVariable;
/*     */   Set<String> removedLocalVariableNames;
/*     */   boolean setAttribute;
/*     */   Object[][] setAttributeValues;
/*     */   int setAttributeValuesSize;
/*     */   boolean replaceAttribute;
/*     */   Object[][] replaceAttributeValues;
/*     */   int replaceAttributeValuesSize;
/*     */   boolean removeAttribute;
/*     */   Object[][] removeAttributeValues;
/*     */   int removeAttributeValuesSize;
/*     */   boolean setSelectionTarget;
/*     */   Object selectionTargetObject;
/*     */   boolean setInliner;
/*     */   IInliner setInlinerValue;
/*     */   boolean setTemplateData;
/*     */   TemplateData setTemplateDataValue;
/*     */   boolean iterateElement;
/*     */   String iterVariableName;
/*     */   String iterStatusVariableName;
/*     */   Object iteratedObject;
/*     */   
/*     */   ElementTagStructureHandler()
/*     */   {
/* 119 */     reset();
/*     */   }
/*     */   
/*     */ 
/*     */   public void setBody(CharSequence text, boolean processable)
/*     */   {
/* 125 */     resetAllButVariablesOrAttributes();
/* 126 */     Validate.notNull(text, "Text cannot be null");
/* 127 */     this.setBodyText = true;
/* 128 */     this.setBodyTextValue = text;
/* 129 */     this.setBodyTextProcessable = processable;
/*     */   }
/*     */   
/*     */   public void setBody(IModel model, boolean processable)
/*     */   {
/* 134 */     resetAllButVariablesOrAttributes();
/* 135 */     Validate.notNull(model, "Model cannot be null");
/* 136 */     this.setBodyModel = true;
/* 137 */     this.setBodyModelValue = model;
/* 138 */     this.setBodyModelProcessable = processable;
/*     */   }
/*     */   
/*     */   public void insertBefore(IModel model)
/*     */   {
/* 143 */     resetAllButVariablesOrAttributes();
/* 144 */     Validate.notNull(model, "Model cannot be null");
/* 145 */     this.insertBeforeModel = true;
/* 146 */     this.insertBeforeModelValue = model;
/*     */   }
/*     */   
/*     */ 
/*     */   public void insertImmediatelyAfter(IModel model, boolean processable)
/*     */   {
/* 152 */     resetAllButVariablesOrAttributes();
/* 153 */     Validate.notNull(model, "Model cannot be null");
/* 154 */     this.insertImmediatelyAfterModel = true;
/* 155 */     this.insertImmediatelyAfterModelValue = model;
/* 156 */     this.insertImmediatelyAfterModelProcessable = processable;
/*     */   }
/*     */   
/*     */   public void replaceWith(CharSequence text, boolean processable)
/*     */   {
/* 161 */     resetAllButVariablesOrAttributes();
/* 162 */     Validate.notNull(text, "Text cannot be null");
/* 163 */     this.replaceWithText = true;
/* 164 */     this.replaceWithTextValue = text;
/* 165 */     this.replaceWithTextProcessable = processable;
/*     */   }
/*     */   
/*     */   public void replaceWith(IModel model, boolean processable)
/*     */   {
/* 170 */     resetAllButVariablesOrAttributes();
/* 171 */     Validate.notNull(model, "Model cannot be null");
/* 172 */     this.replaceWithModel = true;
/* 173 */     this.replaceWithModelValue = model;
/* 174 */     this.replaceWithModelProcessable = processable;
/*     */   }
/*     */   
/*     */   public void removeElement()
/*     */   {
/* 179 */     resetAllButVariablesOrAttributes();
/* 180 */     this.removeElement = true;
/*     */   }
/*     */   
/*     */   public void removeTags()
/*     */   {
/* 185 */     resetAllButVariablesOrAttributes();
/* 186 */     this.removeTags = true;
/*     */   }
/*     */   
/*     */   public void removeBody()
/*     */   {
/* 191 */     resetAllButVariablesOrAttributes();
/* 192 */     this.removeBody = true;
/*     */   }
/*     */   
/*     */   public void removeAllButFirstChild()
/*     */   {
/* 197 */     resetAllButVariablesOrAttributes();
/* 198 */     this.removeAllButFirstChild = true;
/*     */   }
/*     */   
/*     */ 
/*     */   public void removeLocalVariable(String name)
/*     */   {
/* 204 */     Validate.notNull(name, "Variable name cannot be null");
/* 205 */     this.removeLocalVariable = true;
/* 206 */     if (this.removedLocalVariableNames == null) {
/* 207 */       this.removedLocalVariableNames = new HashSet(3);
/*     */     }
/* 209 */     this.removedLocalVariableNames.add(name);
/*     */   }
/*     */   
/*     */ 
/*     */   public void setLocalVariable(String name, Object value)
/*     */   {
/* 215 */     Validate.notNull(name, "Variable name cannot be null");
/* 216 */     this.setLocalVariable = true;
/* 217 */     if (this.addedLocalVariables == null) {
/* 218 */       this.addedLocalVariables = new HashMap(3);
/*     */     }
/* 220 */     this.addedLocalVariables.put(name, value);
/*     */   }
/*     */   
/*     */ 
/*     */   public void setAttribute(String attributeName, String attributeValue)
/*     */   {
/* 226 */     Validate.notNull(attributeName, "Attribute name cannot be null");
/* 227 */     ensureSetAttributeSize();
/* 228 */     this.setAttribute = true;
/* 229 */     Object[] values = this.setAttributeValues[this.setAttributeValuesSize];
/* 230 */     values[0] = null;
/* 231 */     values[1] = attributeName;
/* 232 */     values[2] = attributeValue;
/* 233 */     values[3] = null;
/* 234 */     this.setAttributeValuesSize += 1;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setAttribute(String attributeName, String attributeValue, AttributeValueQuotes attributeValueQuotes)
/*     */   {
/* 240 */     Validate.notNull(attributeName, "Attribute name cannot be null");
/* 241 */     ensureSetAttributeSize();
/* 242 */     this.setAttribute = true;
/* 243 */     Object[] values = this.setAttributeValues[this.setAttributeValuesSize];
/* 244 */     values[0] = null;
/* 245 */     values[1] = attributeName;
/* 246 */     values[2] = attributeValue;
/* 247 */     values[3] = attributeValueQuotes;
/* 248 */     this.setAttributeValuesSize += 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAttribute(AttributeDefinition attributeDefinition, String attributeName, String attributeValue, AttributeValueQuotes attributeValueQuotes)
/*     */   {
/* 256 */     Validate.notNull(attributeDefinition, "Attribute definition cannot be null");
/* 257 */     Validate.notNull(attributeName, "Attribute name cannot be null");
/* 258 */     ensureSetAttributeSize();
/* 259 */     this.setAttribute = true;
/* 260 */     Object[] values = this.setAttributeValues[this.setAttributeValuesSize];
/* 261 */     values[0] = attributeDefinition;
/* 262 */     values[1] = attributeName;
/* 263 */     values[2] = attributeValue;
/* 264 */     values[3] = attributeValueQuotes;
/* 265 */     this.setAttributeValuesSize += 1;
/*     */   }
/*     */   
/*     */   private void ensureSetAttributeSize()
/*     */   {
/* 270 */     if (this.setAttributeValues == null) {
/* 271 */       this.setAttributeValues = new Object[3][];
/*     */     }
/* 273 */     if (this.setAttributeValues.length == this.setAttributeValuesSize) {
/* 274 */       this.setAttributeValues = ((Object[][])Arrays.copyOf(this.setAttributeValues, this.setAttributeValues.length + 3));
/*     */     }
/* 276 */     if (this.setAttributeValues[this.setAttributeValuesSize] == null) {
/* 277 */       this.setAttributeValues[this.setAttributeValuesSize] = new Object[4];
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void replaceAttribute(AttributeName oldAttributeName, String attributeName, String attributeValue)
/*     */   {
/* 284 */     Validate.notNull(oldAttributeName, "Old attribute name cannot be null");
/* 285 */     Validate.notNull(attributeName, "Attribute name cannot be null");
/* 286 */     ensureReplaceAttributeSize();
/* 287 */     this.replaceAttribute = true;
/* 288 */     Object[] values = this.replaceAttributeValues[this.replaceAttributeValuesSize];
/* 289 */     values[0] = oldAttributeName;
/* 290 */     values[1] = null;
/* 291 */     values[2] = attributeName;
/* 292 */     values[3] = attributeValue;
/* 293 */     values[4] = null;
/* 294 */     this.replaceAttributeValuesSize += 1;
/*     */   }
/*     */   
/*     */ 
/*     */   public void replaceAttribute(AttributeName oldAttributeName, String attributeName, String attributeValue, AttributeValueQuotes attributeValueQuotes)
/*     */   {
/* 300 */     Validate.notNull(oldAttributeName, "Old attribute name cannot be null");
/* 301 */     Validate.notNull(attributeName, "Attribute name cannot be null");
/* 302 */     ensureReplaceAttributeSize();
/* 303 */     this.replaceAttribute = true;
/* 304 */     Object[] values = this.replaceAttributeValues[this.replaceAttributeValuesSize];
/* 305 */     values[0] = oldAttributeName;
/* 306 */     values[1] = null;
/* 307 */     values[2] = attributeName;
/* 308 */     values[3] = attributeValue;
/* 309 */     values[4] = attributeValueQuotes;
/* 310 */     this.replaceAttributeValuesSize += 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void replaceAttribute(AttributeName oldAttributeName, AttributeDefinition attributeDefinition, String attributeName, String attributeValue, AttributeValueQuotes attributeValueQuotes)
/*     */   {
/* 318 */     Validate.notNull(oldAttributeName, "Old attribute name cannot be null");
/* 319 */     Validate.notNull(attributeDefinition, "Attribute definition cannot be null");
/* 320 */     Validate.notNull(attributeName, "Attribute name cannot be null");
/* 321 */     ensureReplaceAttributeSize();
/* 322 */     this.replaceAttribute = true;
/* 323 */     Object[] values = this.replaceAttributeValues[this.replaceAttributeValuesSize];
/* 324 */     values[0] = oldAttributeName;
/* 325 */     values[1] = attributeDefinition;
/* 326 */     values[2] = attributeName;
/* 327 */     values[3] = attributeValue;
/* 328 */     values[4] = attributeValueQuotes;
/* 329 */     this.replaceAttributeValuesSize += 1;
/*     */   }
/*     */   
/*     */   private void ensureReplaceAttributeSize()
/*     */   {
/* 334 */     if (this.replaceAttributeValues == null) {
/* 335 */       this.replaceAttributeValues = new Object[3][];
/*     */     }
/* 337 */     if (this.replaceAttributeValues.length == this.replaceAttributeValuesSize) {
/* 338 */       this.replaceAttributeValues = ((Object[][])Arrays.copyOf(this.replaceAttributeValues, this.replaceAttributeValues.length + 3));
/*     */     }
/* 340 */     if (this.replaceAttributeValues[this.replaceAttributeValuesSize] == null) {
/* 341 */       this.replaceAttributeValues[this.replaceAttributeValuesSize] = new Object[5];
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void removeAttribute(String attributeName)
/*     */   {
/* 348 */     Validate.notNull(attributeName, "Attribute name cannot be null");
/* 349 */     ensureRemoveAttributeSize();
/* 350 */     this.removeAttribute = true;
/* 351 */     Object[] values = this.removeAttributeValues[this.removeAttributeValuesSize];
/* 352 */     values[0] = attributeName;
/* 353 */     values[1] = null;
/* 354 */     this.removeAttributeValuesSize += 1;
/*     */   }
/*     */   
/*     */ 
/*     */   public void removeAttribute(String prefix, String name)
/*     */   {
/* 360 */     Validate.notNull(name, "Attribute name cannot be null");
/* 361 */     ensureRemoveAttributeSize();
/* 362 */     this.removeAttribute = true;
/* 363 */     Object[] values = this.removeAttributeValues[this.removeAttributeValuesSize];
/* 364 */     values[0] = prefix;
/* 365 */     values[1] = name;
/* 366 */     this.removeAttributeValuesSize += 1;
/*     */   }
/*     */   
/*     */ 
/*     */   public void removeAttribute(AttributeName attributeName)
/*     */   {
/* 372 */     Validate.notNull(attributeName, "Attribute name cannot be null");
/* 373 */     ensureRemoveAttributeSize();
/* 374 */     this.removeAttribute = true;
/* 375 */     Object[] values = this.removeAttributeValues[this.removeAttributeValuesSize];
/* 376 */     values[0] = attributeName;
/* 377 */     values[1] = null;
/* 378 */     this.removeAttributeValuesSize += 1;
/*     */   }
/*     */   
/*     */   private void ensureRemoveAttributeSize()
/*     */   {
/* 383 */     if (this.removeAttributeValues == null) {
/* 384 */       this.removeAttributeValues = new Object[3][];
/*     */     }
/* 386 */     if (this.removeAttributeValues.length == this.removeAttributeValuesSize) {
/* 387 */       this.removeAttributeValues = ((Object[][])Arrays.copyOf(this.removeAttributeValues, this.removeAttributeValues.length + 3));
/*     */     }
/* 389 */     if (this.removeAttributeValues[this.removeAttributeValuesSize] == null) {
/* 390 */       this.removeAttributeValues[this.removeAttributeValuesSize] = new Object[2];
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void setSelectionTarget(Object selectionTarget)
/*     */   {
/* 397 */     this.setSelectionTarget = true;
/* 398 */     this.selectionTargetObject = selectionTarget;
/*     */   }
/*     */   
/*     */   public void setInliner(IInliner inliner)
/*     */   {
/* 403 */     this.setInliner = true;
/* 404 */     this.setInlinerValue = inliner;
/*     */   }
/*     */   
/*     */   public void setTemplateData(TemplateData templateData)
/*     */   {
/* 409 */     this.setTemplateData = true;
/* 410 */     this.setTemplateDataValue = templateData;
/*     */   }
/*     */   
/*     */   public void iterateElement(String iterVariableName, String iterStatusVariableName, Object iteratedObject)
/*     */   {
/* 415 */     Validate.notEmpty(iterVariableName, "Iteration variable name cannot be null");
/*     */     
/*     */ 
/* 418 */     resetAllButVariablesOrAttributes();
/* 419 */     this.iterateElement = true;
/* 420 */     this.iterVariableName = iterVariableName;
/* 421 */     this.iterStatusVariableName = iterStatusVariableName;
/* 422 */     this.iteratedObject = iteratedObject;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void reset()
/*     */   {
/* 430 */     resetAllButVariablesOrAttributes();
/*     */     
/* 432 */     this.setLocalVariable = false;
/* 433 */     if ((this.addedLocalVariables != null) && (this.addedLocalVariables.size() > 0)) {
/* 434 */       this.addedLocalVariables.clear();
/*     */     }
/*     */     
/* 437 */     this.removeLocalVariable = false;
/* 438 */     if ((this.removedLocalVariableNames != null) && (this.removedLocalVariableNames.size() > 0)) {
/* 439 */       this.removedLocalVariableNames.clear();
/*     */     }
/*     */     
/* 442 */     this.setSelectionTarget = false;
/* 443 */     this.selectionTargetObject = null;
/*     */     
/* 445 */     this.setInliner = false;
/* 446 */     this.setInlinerValue = null;
/*     */     
/* 448 */     this.setTemplateData = false;
/* 449 */     this.setTemplateDataValue = null;
/*     */     
/* 451 */     this.setAttribute = false;
/* 452 */     this.setAttributeValuesSize = 0;
/*     */     
/* 454 */     this.replaceAttribute = false;
/* 455 */     this.replaceAttributeValuesSize = 0;
/*     */     
/* 457 */     this.removeAttribute = false;
/* 458 */     this.removeAttributeValuesSize = 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void resetAllButVariablesOrAttributes()
/*     */   {
/* 465 */     this.setBodyText = false;
/* 466 */     this.setBodyTextValue = null;
/* 467 */     this.setBodyTextProcessable = false;
/*     */     
/* 469 */     this.setBodyModel = false;
/* 470 */     this.setBodyModelValue = null;
/* 471 */     this.setBodyModelProcessable = false;
/*     */     
/* 473 */     this.insertBeforeModel = false;
/* 474 */     this.insertBeforeModelValue = null;
/*     */     
/*     */ 
/* 477 */     this.insertImmediatelyAfterModel = false;
/* 478 */     this.insertImmediatelyAfterModelValue = null;
/* 479 */     this.insertImmediatelyAfterModelProcessable = false;
/*     */     
/* 481 */     this.replaceWithText = false;
/* 482 */     this.replaceWithTextValue = null;
/* 483 */     this.replaceWithTextProcessable = false;
/*     */     
/* 485 */     this.replaceWithModel = false;
/* 486 */     this.replaceWithModelValue = null;
/* 487 */     this.replaceWithModelProcessable = false;
/*     */     
/* 489 */     this.removeElement = false;
/*     */     
/* 491 */     this.removeTags = false;
/*     */     
/* 493 */     this.removeBody = false;
/*     */     
/* 495 */     this.removeAllButFirstChild = false;
/*     */     
/* 497 */     this.iterateElement = false;
/* 498 */     this.iterVariableName = null;
/* 499 */     this.iterStatusVariableName = null;
/* 500 */     this.iteratedObject = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void applyContextModifications(IEngineContext engineContext)
/*     */   {
/* 509 */     if (engineContext == null) {
/* 510 */       return;
/*     */     }
/*     */     
/* 513 */     if (this.setLocalVariable) {
/* 514 */       engineContext.setVariables(this.addedLocalVariables);
/*     */     }
/*     */     
/* 517 */     if (this.removeLocalVariable) {
/* 518 */       for (String variableName : this.removedLocalVariableNames) {
/* 519 */         engineContext.removeVariable(variableName);
/*     */       }
/*     */     }
/*     */     
/* 523 */     if (this.setSelectionTarget) {
/* 524 */       engineContext.setSelectionTarget(this.selectionTargetObject);
/*     */     }
/*     */     
/* 527 */     if (this.setInliner) {
/* 528 */       engineContext.setInliner(this.setInlinerValue);
/*     */     }
/*     */     
/* 531 */     if (this.setTemplateData) {
/* 532 */       engineContext.setTemplateData(this.setTemplateDataValue);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   <T extends AbstractProcessableElementTag> T applyAttributes(AttributeDefinitions attributeDefinitions, T tag)
/*     */   {
/* 540 */     T ttag = tag;
/*     */     
/* 542 */     if (this.removeAttribute) {
/* 543 */       for (int i = 0; i < this.removeAttributeValuesSize; i++) {
/* 544 */         Object[] values = this.removeAttributeValues[i];
/* 545 */         if (values[1] != null)
/*     */         {
/* 547 */           ttag = ttag.removeAttribute((String)values[0], (String)values[1]);
/* 548 */         } else if ((values[0] instanceof AttributeName))
/*     */         {
/* 550 */           ttag = ttag.removeAttribute((AttributeName)values[0]);
/*     */         }
/*     */         else {
/* 553 */           ttag = ttag.removeAttribute((String)values[0]);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 558 */     if (this.replaceAttribute) {
/* 559 */       for (int i = 0; i < this.replaceAttributeValuesSize; i++) {
/* 560 */         Object[] values = this.replaceAttributeValues[i];
/* 561 */         ttag = ttag.replaceAttribute(attributeDefinitions, (AttributeName)values[0], (AttributeDefinition)values[1], (String)values[2], (String)values[3], (AttributeValueQuotes)values[4]);
/*     */       }
/*     */     }
/*     */     
/* 565 */     if (this.setAttribute) {
/* 566 */       for (int i = 0; i < this.setAttributeValuesSize; i++) {
/* 567 */         Object[] values = this.setAttributeValues[i];
/* 568 */         ttag = ttag.setAttribute(attributeDefinitions, (AttributeDefinition)values[0], (String)values[1], (String)values[2], (AttributeValueQuotes)values[3]);
/*     */       }
/*     */     }
/*     */     
/* 572 */     return ttag;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\ElementTagStructureHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */