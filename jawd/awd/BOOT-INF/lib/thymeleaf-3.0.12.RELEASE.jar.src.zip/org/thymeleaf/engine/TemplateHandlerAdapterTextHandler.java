/*     */ package org.thymeleaf.engine;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import org.thymeleaf.model.AttributeValueQuotes;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ import org.thymeleaf.templateparser.text.AbstractTextHandler;
/*     */ import org.thymeleaf.templateparser.text.TextParseException;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class TemplateHandlerAdapterTextHandler
/*     */   extends AbstractTextHandler
/*     */ {
/*  40 */   private static final String[][] SYNTHETIC_INNER_WHITESPACES = { new String[0], Attributes.DEFAULT_WHITE_SPACE_ARRAY, { " ", " " }, { " ", " ", " " }, { " ", " ", " ", " " }, { " ", " ", " ", " ", " " } };
/*     */   
/*     */ 
/*     */   private final String templateName;
/*     */   
/*     */   private final ITemplateHandler templateHandler;
/*     */   
/*     */   private final ElementDefinitions elementDefinitions;
/*     */   
/*     */   private final AttributeDefinitions attributeDefinitions;
/*     */   
/*     */   private final TemplateMode templateMode;
/*     */   
/*     */   private final int lineOffset;
/*     */   
/*     */   private final int colOffset;
/*     */   
/*  57 */   private int currentElementLine = -1;
/*  58 */   private int currentElementCol = -1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final List<Attribute> currentElementAttributes;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public TemplateHandlerAdapterTextHandler(String templateName, ITemplateHandler templateHandler, ElementDefinitions elementDefinitions, AttributeDefinitions attributeDefinitions, TemplateMode templateMode, int lineOffset, int colOffset)
/*     */   {
/*  70 */     Validate.notNull(templateHandler, "Template handler cannot be null");
/*  71 */     Validate.notNull(elementDefinitions, "Element Definitions repository cannot be null");
/*  72 */     Validate.notNull(attributeDefinitions, "Attribute Definitions repository cannot be null");
/*  73 */     Validate.notNull(templateMode, "Template mode cannot be null");
/*     */     
/*  75 */     this.templateName = templateName;
/*     */     
/*  77 */     this.templateHandler = templateHandler;
/*     */     
/*     */ 
/*  80 */     this.elementDefinitions = elementDefinitions;
/*  81 */     this.attributeDefinitions = attributeDefinitions;
/*  82 */     this.templateMode = templateMode;
/*  83 */     this.lineOffset = (lineOffset > 0 ? lineOffset - 1 : lineOffset);
/*  84 */     this.colOffset = (colOffset > 0 ? colOffset - 1 : colOffset);
/*     */     
/*     */ 
/*  87 */     this.currentElementAttributes = new ArrayList(10);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleDocumentStart(long startTimeNanos, int line, int col)
/*     */     throws TextParseException
/*     */   {
/*  98 */     this.templateHandler.handleTemplateStart(TemplateStart.TEMPLATE_START_INSTANCE);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleDocumentEnd(long endTimeNanos, long totalTimeNanos, int line, int col)
/*     */     throws TextParseException
/*     */   {
/* 107 */     this.templateHandler.handleTemplateEnd(TemplateEnd.TEMPLATE_END_INSTANCE);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleText(char[] buffer, int offset, int len, int line, int col)
/*     */     throws TextParseException
/*     */   {
/* 118 */     this.templateHandler.handleText(new Text(new String(buffer, offset, len), this.templateName, this.lineOffset + line, 
/* 119 */       (line == 1 ? this.colOffset : 0) + col));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleStandaloneElementStart(char[] buffer, int nameOffset, int nameLen, boolean minimized, int line, int col)
/*     */     throws TextParseException
/*     */   {
/* 132 */     this.currentElementLine = line;
/* 133 */     this.currentElementCol = col;
/* 134 */     this.currentElementAttributes.clear();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleStandaloneElementEnd(char[] buffer, int nameOffset, int nameLen, boolean minimized, int line, int col)
/*     */     throws TextParseException
/*     */   {
/* 145 */     String elementCompleteName = new String(buffer, nameOffset, nameLen);
/* 146 */     ElementDefinition elementDefinition = this.elementDefinitions.forName(this.templateMode, elementCompleteName);
/*     */     Attributes attributes;
/*     */     Attributes attributes;
/* 149 */     if (this.currentElementAttributes.isEmpty()) {
/* 150 */       attributes = null;
/*     */     }
/*     */     else
/*     */     {
/* 154 */       Attribute[] attributesArr = this.currentElementAttributes.isEmpty() ? Attributes.EMPTY_ATTRIBUTE_ARRAY : (Attribute[])this.currentElementAttributes.toArray(new Attribute[this.currentElementAttributes.size()]);
/*     */       String[] innerWhiteSpaces;
/* 156 */       String[] innerWhiteSpaces; if (attributesArr.length < SYNTHETIC_INNER_WHITESPACES.length) {
/* 157 */         innerWhiteSpaces = SYNTHETIC_INNER_WHITESPACES[attributesArr.length];
/*     */       } else {
/* 159 */         innerWhiteSpaces = new String[attributesArr.length];
/* 160 */         Arrays.fill(innerWhiteSpaces, " ");
/*     */       }
/* 162 */       attributes = new Attributes(attributesArr, innerWhiteSpaces);
/*     */     }
/*     */     
/* 165 */     this.templateHandler.handleStandaloneElement(new StandaloneElementTag(this.templateMode, elementDefinition, elementCompleteName, attributes, false, minimized, this.templateName, this.lineOffset + this.currentElementLine, 
/*     */     
/*     */ 
/* 168 */       (this.currentElementLine == 1 ? this.colOffset : 0) + this.currentElementCol));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleOpenElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws TextParseException
/*     */   {
/* 181 */     this.currentElementLine = line;
/* 182 */     this.currentElementCol = col;
/* 183 */     this.currentElementAttributes.clear();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleOpenElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws TextParseException
/*     */   {
/* 194 */     String elementCompleteName = new String(buffer, nameOffset, nameLen);
/* 195 */     ElementDefinition elementDefinition = this.elementDefinitions.forName(this.templateMode, elementCompleteName);
/*     */     Attributes attributes;
/*     */     Attributes attributes;
/* 198 */     if (this.currentElementAttributes.isEmpty()) {
/* 199 */       attributes = null;
/*     */     }
/*     */     else
/*     */     {
/* 203 */       Attribute[] attributesArr = this.currentElementAttributes.isEmpty() ? Attributes.EMPTY_ATTRIBUTE_ARRAY : (Attribute[])this.currentElementAttributes.toArray(new Attribute[this.currentElementAttributes.size()]);
/*     */       String[] innerWhiteSpaces;
/* 205 */       String[] innerWhiteSpaces; if (attributesArr.length < SYNTHETIC_INNER_WHITESPACES.length) {
/* 206 */         innerWhiteSpaces = SYNTHETIC_INNER_WHITESPACES[attributesArr.length];
/*     */       } else {
/* 208 */         innerWhiteSpaces = new String[attributesArr.length];
/* 209 */         Arrays.fill(innerWhiteSpaces, " ");
/*     */       }
/* 211 */       attributes = new Attributes(attributesArr, innerWhiteSpaces);
/*     */     }
/*     */     
/* 214 */     this.templateHandler.handleOpenElement(new OpenElementTag(this.templateMode, elementDefinition, elementCompleteName, attributes, false, this.templateName, this.lineOffset + this.currentElementLine, 
/*     */     
/*     */ 
/* 217 */       (this.currentElementLine == 1 ? this.colOffset : 0) + this.currentElementCol));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleCloseElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws TextParseException
/*     */   {
/* 230 */     this.currentElementLine = line;
/* 231 */     this.currentElementCol = col;
/* 232 */     this.currentElementAttributes.clear();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleCloseElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col)
/*     */     throws TextParseException
/*     */   {
/* 243 */     String elementCompleteName = new String(buffer, nameOffset, nameLen);
/* 244 */     ElementDefinition elementDefinition = this.elementDefinitions.forName(this.templateMode, elementCompleteName);
/*     */     
/* 246 */     this.templateHandler.handleCloseElement(new CloseElementTag(this.templateMode, elementDefinition, elementCompleteName, null, false, false, this.templateName, this.lineOffset + this.currentElementLine, 
/*     */     
/*     */ 
/* 249 */       (this.currentElementLine == 1 ? this.colOffset : 0) + this.currentElementCol));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleAttribute(char[] buffer, int nameOffset, int nameLen, int nameLine, int nameCol, int operatorOffset, int operatorLen, int operatorLine, int operatorCol, int valueContentOffset, int valueContentLen, int valueOuterOffset, int valueOuterLen, int valueLine, int valueCol)
/*     */     throws TextParseException
/*     */   {
/* 267 */     String attributeName = new String(buffer, nameOffset, nameLen);
/*     */     
/* 269 */     AttributeDefinition attributeDefinition = this.attributeDefinitions.forName(this.templateMode, attributeName);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 276 */     String attributeOperator = operatorLen > 0 ? new String(buffer, operatorOffset, operatorLen) : (operatorLen == 1) && (buffer[operatorOffset] == '=') ? "=" : null;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 281 */     String value = attributeOperator != null ? new String(buffer, valueContentOffset, valueContentLen) : null;
/*     */     AttributeValueQuotes valueQuotes;
/*     */     AttributeValueQuotes valueQuotes;
/* 284 */     if (value == null) {
/* 285 */       valueQuotes = null; } else { AttributeValueQuotes valueQuotes;
/* 286 */       if (valueOuterOffset == valueContentOffset) {
/* 287 */         valueQuotes = AttributeValueQuotes.NONE; } else { AttributeValueQuotes valueQuotes;
/* 288 */         if (buffer[valueOuterOffset] == '"') {
/* 289 */           valueQuotes = AttributeValueQuotes.DOUBLE; } else { AttributeValueQuotes valueQuotes;
/* 290 */           if (buffer[valueOuterOffset] == '\'') {
/* 291 */             valueQuotes = AttributeValueQuotes.SINGLE;
/*     */           } else {
/* 293 */             valueQuotes = AttributeValueQuotes.NONE;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 299 */     Attribute newAttribute = new Attribute(attributeDefinition, attributeName, attributeOperator, value, valueQuotes, this.templateName, this.lineOffset + nameLine, (nameLine == 1 ? this.colOffset : 0) + nameCol);
/*     */     
/* 301 */     this.currentElementAttributes.add(newAttribute);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\TemplateHandlerAdapterTextHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */