/*    */ package org.thymeleaf.engine;
/*    */ 
/*    */ import java.util.Set;
/*    */ import org.thymeleaf.processor.element.IElementProcessor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class TextElementDefinition
/*    */   extends ElementDefinition
/*    */ {
/*    */   TextElementDefinition(TextElementName name, Set<IElementProcessor> associatedProcessors)
/*    */   {
/* 37 */     super(name, associatedProcessors);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\TextElementDefinition.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */