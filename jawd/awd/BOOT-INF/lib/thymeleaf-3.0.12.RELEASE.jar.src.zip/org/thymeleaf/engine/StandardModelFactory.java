/*     */ package org.thymeleaf.engine;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import org.thymeleaf.IEngineConfiguration;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.model.AttributeValueQuotes;
/*     */ import org.thymeleaf.model.ICDATASection;
/*     */ import org.thymeleaf.model.ICloseElementTag;
/*     */ import org.thymeleaf.model.IComment;
/*     */ import org.thymeleaf.model.IDocType;
/*     */ import org.thymeleaf.model.IModel;
/*     */ import org.thymeleaf.model.IModelFactory;
/*     */ import org.thymeleaf.model.IOpenElementTag;
/*     */ import org.thymeleaf.model.IProcessableElementTag;
/*     */ import org.thymeleaf.model.IProcessingInstruction;
/*     */ import org.thymeleaf.model.IStandaloneElementTag;
/*     */ import org.thymeleaf.model.ITemplateEvent;
/*     */ import org.thymeleaf.model.IText;
/*     */ import org.thymeleaf.model.IXMLDeclaration;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardModelFactory
/*     */   implements IModelFactory
/*     */ {
/*  52 */   private static final String[][] SYNTHETIC_INNER_WHITESPACES = { new String[0], Attributes.DEFAULT_WHITE_SPACE_ARRAY, { " ", " " }, { " ", " ", " " }, { " ", " ", " ", " " }, { " ", " ", " ", " ", " " } };
/*     */   
/*     */ 
/*     */ 
/*     */   private final IEngineConfiguration configuration;
/*     */   
/*     */ 
/*     */ 
/*     */   private final AttributeDefinitions attributeDefinitions;
/*     */   
/*     */ 
/*     */ 
/*     */   private final ElementDefinitions elementDefinitions;
/*     */   
/*     */ 
/*     */   private final TemplateMode templateMode;
/*     */   
/*     */ 
/*     */ 
/*     */   public StandardModelFactory(IEngineConfiguration configuration, TemplateMode templateMode)
/*     */   {
/*  73 */     Validate.notNull(configuration, "Configuration cannot be null");
/*  74 */     Validate.notNull(configuration.getAttributeDefinitions(), "Attribute Definitions returned by Engine Configuration cannot be null");
/*  75 */     Validate.notNull(configuration.getElementDefinitions(), "Element Definitions returned by Engine Configuration cannot be null");
/*  76 */     Validate.notNull(templateMode, "Template Mode cannot be null");
/*     */     
/*  78 */     this.configuration = configuration;
/*  79 */     this.attributeDefinitions = this.configuration.getAttributeDefinitions();
/*  80 */     this.elementDefinitions = this.configuration.getElementDefinitions();
/*  81 */     this.templateMode = templateMode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void checkRestrictedEventForTextTemplateMode(String eventClass)
/*     */   {
/*  88 */     if (this.templateMode.isText()) {
/*  89 */       throw new TemplateProcessingException("Events of class " + eventClass + " cannot be created in a text-type template mode (" + this.templateMode + ")");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public IModel createModel()
/*     */   {
/*  98 */     return new Model(this.configuration, this.templateMode);
/*     */   }
/*     */   
/*     */   public IModel createModel(ITemplateEvent event)
/*     */   {
/* 103 */     Model model = new Model(this.configuration, this.templateMode);
/* 104 */     model.add(event);
/* 105 */     return model;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public IModel parse(TemplateData ownerTemplate, String template)
/*     */   {
/* 115 */     return this.configuration.getTemplateManager().parseString(ownerTemplate, template, 0, 0, this.templateMode, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ICDATASection createCDATASection(CharSequence content)
/*     */   {
/* 122 */     checkRestrictedEventForTextTemplateMode("CDATASection");
/* 123 */     return new CDATASection(content);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public IComment createComment(CharSequence content)
/*     */   {
/* 130 */     checkRestrictedEventForTextTemplateMode("Comment");
/* 131 */     return new Comment(content);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public IDocType createHTML5DocType()
/*     */   {
/* 138 */     checkRestrictedEventForTextTemplateMode("DocType");
/* 139 */     return new DocType(null, null);
/*     */   }
/*     */   
/*     */   public IDocType createDocType(String publicId, String systemId)
/*     */   {
/* 144 */     checkRestrictedEventForTextTemplateMode("DocType");
/* 145 */     return new DocType(publicId, systemId);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public IDocType createDocType(String keyword, String elementName, String publicId, String systemId, String internalSubset)
/*     */   {
/* 156 */     checkRestrictedEventForTextTemplateMode("DocType");
/* 157 */     return new DocType(keyword, elementName, publicId, systemId, internalSubset);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public IProcessingInstruction createProcessingInstruction(String target, String content)
/*     */   {
/* 164 */     checkRestrictedEventForTextTemplateMode("ProcessingInstruction");
/* 165 */     return new ProcessingInstruction(target, content);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public IText createText(CharSequence text)
/*     */   {
/* 172 */     return new Text(text);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public IXMLDeclaration createXMLDeclaration(String version, String encoding, String standalone)
/*     */   {
/* 179 */     checkRestrictedEventForTextTemplateMode("XMLDeclaration");
/* 180 */     return new XMLDeclaration("xml", version, encoding, standalone);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public IStandaloneElementTag createStandaloneElementTag(String elementName)
/*     */   {
/* 188 */     return createStandaloneElementTag(elementName, false, true);
/*     */   }
/*     */   
/*     */ 
/*     */   public IStandaloneElementTag createStandaloneElementTag(String elementName, String attributeName, String attributeValue)
/*     */   {
/* 194 */     return createStandaloneElementTag(elementName, attributeName, attributeValue, false, true);
/*     */   }
/*     */   
/*     */ 
/*     */   public IStandaloneElementTag createStandaloneElementTag(String elementName, boolean synthetic, boolean minimized)
/*     */   {
/* 200 */     ElementDefinition elementDefinition = this.elementDefinitions.forName(this.templateMode, elementName);
/* 201 */     return new StandaloneElementTag(this.templateMode, elementDefinition, elementName, null, synthetic, minimized);
/*     */   }
/*     */   
/*     */ 
/*     */   public IStandaloneElementTag createStandaloneElementTag(String elementName, String attributeName, String attributeValue, boolean synthetic, boolean minimized)
/*     */   {
/* 207 */     ElementDefinition elementDefinition = this.elementDefinitions.forName(this.templateMode, elementName);
/* 208 */     Attributes attributes = buildAttributes(new Attribute[] { buildAttribute(attributeName, attributeValue, null) });
/* 209 */     return new StandaloneElementTag(this.templateMode, elementDefinition, elementName, attributes, synthetic, minimized);
/*     */   }
/*     */   
/*     */ 
/*     */   public IStandaloneElementTag createStandaloneElementTag(String elementName, Map<String, String> attributes, AttributeValueQuotes attributeValueQuotes, boolean synthetic, boolean minimized)
/*     */   {
/* 215 */     ElementDefinition elementDefinition = this.elementDefinitions.forName(this.templateMode, elementName);
/* 216 */     Attributes attributesObj = buildAttributes(buildAttributeArray(attributes, attributeValueQuotes));
/* 217 */     return new StandaloneElementTag(this.templateMode, elementDefinition, elementName, attributesObj, synthetic, minimized);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public IOpenElementTag createOpenElementTag(String elementName)
/*     */   {
/* 225 */     return createOpenElementTag(elementName, false);
/*     */   }
/*     */   
/*     */ 
/*     */   public IOpenElementTag createOpenElementTag(String elementName, String attributeName, String attributeValue)
/*     */   {
/* 231 */     return createOpenElementTag(elementName, attributeName, attributeValue, false);
/*     */   }
/*     */   
/*     */ 
/*     */   public IOpenElementTag createOpenElementTag(String elementName, boolean synthetic)
/*     */   {
/* 237 */     ElementDefinition elementDefinition = this.elementDefinitions.forName(this.templateMode, elementName);
/* 238 */     return new OpenElementTag(this.templateMode, elementDefinition, elementName, null, synthetic);
/*     */   }
/*     */   
/*     */ 
/*     */   public IOpenElementTag createOpenElementTag(String elementName, String attributeName, String attributeValue, boolean synthetic)
/*     */   {
/* 244 */     ElementDefinition elementDefinition = this.elementDefinitions.forName(this.templateMode, elementName);
/* 245 */     Attributes attributes = buildAttributes(new Attribute[] { buildAttribute(attributeName, attributeValue, null) });
/* 246 */     return new OpenElementTag(this.templateMode, elementDefinition, elementName, attributes, synthetic);
/*     */   }
/*     */   
/*     */ 
/*     */   public IOpenElementTag createOpenElementTag(String elementName, Map<String, String> attributes, AttributeValueQuotes attributeValueQuotes, boolean synthetic)
/*     */   {
/* 252 */     ElementDefinition elementDefinition = this.elementDefinitions.forName(this.templateMode, elementName);
/* 253 */     Attributes attributesObj = buildAttributes(buildAttributeArray(attributes, attributeValueQuotes));
/* 254 */     return new OpenElementTag(this.templateMode, elementDefinition, elementName, attributesObj, synthetic);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public <T extends IProcessableElementTag> T setAttribute(T tag, String attributeName, String attributeValue)
/*     */   {
/* 262 */     if (tag == null) {
/* 263 */       return null;
/*     */     }
/* 265 */     if ((tag instanceof IOpenElementTag)) {
/* 266 */       return setAttribute((IOpenElementTag)tag, attributeName, attributeValue);
/*     */     }
/* 268 */     if ((tag instanceof IStandaloneElementTag)) {
/* 269 */       return setAttribute((IStandaloneElementTag)tag, attributeName, attributeValue);
/*     */     }
/* 271 */     throw new TemplateProcessingException("Unknown type of processable element tag: " + tag.getClass().getName());
/*     */   }
/*     */   
/*     */ 
/*     */   public <T extends IProcessableElementTag> T setAttribute(T tag, String attributeName, String attributeValue, AttributeValueQuotes attributeValueQuotes)
/*     */   {
/* 277 */     if (tag == null) {
/* 278 */       return null;
/*     */     }
/* 280 */     if ((tag instanceof IOpenElementTag)) {
/* 281 */       return setAttribute((IOpenElementTag)tag, attributeName, attributeValue, attributeValueQuotes);
/*     */     }
/* 283 */     if ((tag instanceof IStandaloneElementTag)) {
/* 284 */       return setAttribute((IStandaloneElementTag)tag, attributeName, attributeValue, attributeValueQuotes);
/*     */     }
/* 286 */     throw new TemplateProcessingException("Unknown type of processable element tag: " + tag.getClass().getName());
/*     */   }
/*     */   
/*     */ 
/*     */   public <T extends IProcessableElementTag> T replaceAttribute(T tag, AttributeName oldAttributeName, String attributeName, String attributeValue)
/*     */   {
/* 292 */     if (tag == null) {
/* 293 */       return null;
/*     */     }
/* 295 */     if ((tag instanceof IOpenElementTag)) {
/* 296 */       return replaceAttribute((IOpenElementTag)tag, oldAttributeName, attributeName, attributeValue);
/*     */     }
/* 298 */     if ((tag instanceof IStandaloneElementTag)) {
/* 299 */       return replaceAttribute((IStandaloneElementTag)tag, oldAttributeName, attributeName, attributeValue);
/*     */     }
/* 301 */     throw new TemplateProcessingException("Unknown type of processable element tag: " + tag.getClass().getName());
/*     */   }
/*     */   
/*     */ 
/*     */   public <T extends IProcessableElementTag> T replaceAttribute(T tag, AttributeName oldAttributeName, String attributeName, String attributeValue, AttributeValueQuotes attributeValueQuotes)
/*     */   {
/* 307 */     if (tag == null) {
/* 308 */       return null;
/*     */     }
/* 310 */     if ((tag instanceof IOpenElementTag)) {
/* 311 */       return replaceAttribute((IOpenElementTag)tag, oldAttributeName, attributeName, attributeValue, attributeValueQuotes);
/*     */     }
/* 313 */     if ((tag instanceof IStandaloneElementTag)) {
/* 314 */       return replaceAttribute((IStandaloneElementTag)tag, oldAttributeName, attributeName, attributeValue, attributeValueQuotes);
/*     */     }
/* 316 */     throw new TemplateProcessingException("Unknown type of processable element tag: " + tag.getClass().getName());
/*     */   }
/*     */   
/*     */ 
/*     */   public <T extends IProcessableElementTag> T removeAttribute(T tag, String attributeName)
/*     */   {
/* 322 */     if (tag == null) {
/* 323 */       return null;
/*     */     }
/* 325 */     if ((tag instanceof IOpenElementTag)) {
/* 326 */       return removeAttribute((IOpenElementTag)tag, attributeName);
/*     */     }
/* 328 */     if ((tag instanceof IStandaloneElementTag)) {
/* 329 */       return removeAttribute((IStandaloneElementTag)tag, attributeName);
/*     */     }
/* 331 */     throw new TemplateProcessingException("Unknown type of processable element tag: " + tag.getClass().getName());
/*     */   }
/*     */   
/*     */ 
/*     */   public <T extends IProcessableElementTag> T removeAttribute(T tag, String prefix, String name)
/*     */   {
/* 337 */     if (tag == null) {
/* 338 */       return null;
/*     */     }
/* 340 */     if ((tag instanceof IOpenElementTag)) {
/* 341 */       return removeAttribute((IOpenElementTag)tag, prefix, name);
/*     */     }
/* 343 */     if ((tag instanceof IStandaloneElementTag)) {
/* 344 */       return removeAttribute((IStandaloneElementTag)tag, prefix, name);
/*     */     }
/* 346 */     throw new TemplateProcessingException("Unknown type of processable element tag: " + tag.getClass().getName());
/*     */   }
/*     */   
/*     */ 
/*     */   public <T extends IProcessableElementTag> T removeAttribute(T tag, AttributeName attributeName)
/*     */   {
/* 352 */     if (tag == null) {
/* 353 */       return null;
/*     */     }
/* 355 */     if ((tag instanceof IOpenElementTag)) {
/* 356 */       return removeAttribute((IOpenElementTag)tag, attributeName);
/*     */     }
/* 358 */     if ((tag instanceof IStandaloneElementTag)) {
/* 359 */       return removeAttribute((IStandaloneElementTag)tag, attributeName);
/*     */     }
/* 361 */     throw new TemplateProcessingException("Unknown type of processable element tag: " + tag.getClass().getName());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private IStandaloneElementTag setAttribute(IStandaloneElementTag standaloneElementTag, String attributeName, String attributeValue)
/*     */   {
/* 368 */     if (!(standaloneElementTag instanceof StandaloneElementTag)) {
/* 369 */       return setAttribute(StandaloneElementTag.asEngineStandaloneElementTag(standaloneElementTag), attributeName, attributeValue);
/*     */     }
/* 371 */     return ((StandaloneElementTag)standaloneElementTag).setAttribute(this.attributeDefinitions, null, attributeName, attributeValue, null);
/*     */   }
/*     */   
/*     */   private IStandaloneElementTag setAttribute(IStandaloneElementTag standaloneElementTag, String attributeName, String attributeValue, AttributeValueQuotes attributeValueQuotes)
/*     */   {
/* 376 */     if (!(standaloneElementTag instanceof StandaloneElementTag)) {
/* 377 */       return setAttribute(StandaloneElementTag.asEngineStandaloneElementTag(standaloneElementTag), attributeName, attributeValue, attributeValueQuotes);
/*     */     }
/* 379 */     return ((StandaloneElementTag)standaloneElementTag).setAttribute(this.attributeDefinitions, null, attributeName, attributeValue, attributeValueQuotes);
/*     */   }
/*     */   
/*     */   private IStandaloneElementTag replaceAttribute(IStandaloneElementTag standaloneElementTag, AttributeName oldAttributeName, String attributeName, String attributeValue)
/*     */   {
/* 384 */     if (!(standaloneElementTag instanceof StandaloneElementTag)) {
/* 385 */       return replaceAttribute(StandaloneElementTag.asEngineStandaloneElementTag(standaloneElementTag), oldAttributeName, attributeName, attributeValue);
/*     */     }
/* 387 */     return ((StandaloneElementTag)standaloneElementTag).replaceAttribute(this.attributeDefinitions, oldAttributeName, null, attributeName, attributeValue, null);
/*     */   }
/*     */   
/*     */   private IStandaloneElementTag replaceAttribute(IStandaloneElementTag standaloneElementTag, AttributeName oldAttributeName, String attributeName, String attributeValue, AttributeValueQuotes attributeValueQuotes)
/*     */   {
/* 392 */     if (!(standaloneElementTag instanceof StandaloneElementTag)) {
/* 393 */       return replaceAttribute(StandaloneElementTag.asEngineStandaloneElementTag(standaloneElementTag), oldAttributeName, attributeName, attributeValue, attributeValueQuotes);
/*     */     }
/* 395 */     return ((StandaloneElementTag)standaloneElementTag).replaceAttribute(this.attributeDefinitions, oldAttributeName, null, attributeName, attributeValue, attributeValueQuotes);
/*     */   }
/*     */   
/*     */   private IStandaloneElementTag removeAttribute(IStandaloneElementTag standaloneElementTag, String attributeName)
/*     */   {
/* 400 */     if (!(standaloneElementTag instanceof StandaloneElementTag)) {
/* 401 */       return removeAttribute(StandaloneElementTag.asEngineStandaloneElementTag(standaloneElementTag), attributeName);
/*     */     }
/* 403 */     return ((StandaloneElementTag)standaloneElementTag).removeAttribute(attributeName);
/*     */   }
/*     */   
/*     */   private IStandaloneElementTag removeAttribute(IStandaloneElementTag standaloneElementTag, String prefix, String name)
/*     */   {
/* 408 */     if (!(standaloneElementTag instanceof StandaloneElementTag)) {
/* 409 */       return removeAttribute(StandaloneElementTag.asEngineStandaloneElementTag(standaloneElementTag), prefix, name);
/*     */     }
/* 411 */     return ((StandaloneElementTag)standaloneElementTag).removeAttribute(prefix, name);
/*     */   }
/*     */   
/*     */   private IStandaloneElementTag removeAttribute(IStandaloneElementTag standaloneElementTag, AttributeName attributeName)
/*     */   {
/* 416 */     if (!(standaloneElementTag instanceof StandaloneElementTag)) {
/* 417 */       return removeAttribute(StandaloneElementTag.asEngineStandaloneElementTag(standaloneElementTag), attributeName);
/*     */     }
/* 419 */     return ((StandaloneElementTag)standaloneElementTag).removeAttribute(attributeName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private IOpenElementTag setAttribute(IOpenElementTag openElementTag, String attributeName, String attributeValue)
/*     */   {
/* 426 */     if (!(openElementTag instanceof OpenElementTag)) {
/* 427 */       return setAttribute(OpenElementTag.asEngineOpenElementTag(openElementTag), attributeName, attributeValue);
/*     */     }
/* 429 */     return ((OpenElementTag)openElementTag).setAttribute(this.attributeDefinitions, null, attributeName, attributeValue, null);
/*     */   }
/*     */   
/*     */   private IOpenElementTag setAttribute(IOpenElementTag openElementTag, String attributeName, String attributeValue, AttributeValueQuotes attributeValueQuotes)
/*     */   {
/* 434 */     if (!(openElementTag instanceof OpenElementTag)) {
/* 435 */       return setAttribute(OpenElementTag.asEngineOpenElementTag(openElementTag), attributeName, attributeValue, attributeValueQuotes);
/*     */     }
/* 437 */     return ((OpenElementTag)openElementTag).setAttribute(this.attributeDefinitions, null, attributeName, attributeValue, attributeValueQuotes);
/*     */   }
/*     */   
/*     */   private IOpenElementTag replaceAttribute(IOpenElementTag openElementTag, AttributeName oldAttributeName, String attributeName, String attributeValue)
/*     */   {
/* 442 */     if (!(openElementTag instanceof OpenElementTag)) {
/* 443 */       return replaceAttribute(OpenElementTag.asEngineOpenElementTag(openElementTag), oldAttributeName, attributeName, attributeValue);
/*     */     }
/* 445 */     return ((OpenElementTag)openElementTag).replaceAttribute(this.attributeDefinitions, oldAttributeName, null, attributeName, attributeValue, null);
/*     */   }
/*     */   
/*     */   private IOpenElementTag replaceAttribute(IOpenElementTag openElementTag, AttributeName oldAttributeName, String attributeName, String attributeValue, AttributeValueQuotes attributeValueQuotes)
/*     */   {
/* 450 */     if (!(openElementTag instanceof OpenElementTag)) {
/* 451 */       return replaceAttribute(OpenElementTag.asEngineOpenElementTag(openElementTag), oldAttributeName, attributeName, attributeValue, attributeValueQuotes);
/*     */     }
/* 453 */     return ((OpenElementTag)openElementTag).replaceAttribute(this.attributeDefinitions, oldAttributeName, null, attributeName, attributeValue, attributeValueQuotes);
/*     */   }
/*     */   
/*     */   private IOpenElementTag removeAttribute(IOpenElementTag openElementTag, String attributeName)
/*     */   {
/* 458 */     if (!(openElementTag instanceof OpenElementTag)) {
/* 459 */       return removeAttribute(OpenElementTag.asEngineOpenElementTag(openElementTag), attributeName);
/*     */     }
/* 461 */     return ((OpenElementTag)openElementTag).removeAttribute(attributeName);
/*     */   }
/*     */   
/*     */   private IOpenElementTag removeAttribute(IOpenElementTag openElementTag, String prefix, String name)
/*     */   {
/* 466 */     if (!(openElementTag instanceof OpenElementTag)) {
/* 467 */       return removeAttribute(OpenElementTag.asEngineOpenElementTag(openElementTag), prefix, name);
/*     */     }
/* 469 */     return ((OpenElementTag)openElementTag).removeAttribute(prefix, name);
/*     */   }
/*     */   
/*     */   private IOpenElementTag removeAttribute(IOpenElementTag openElementTag, AttributeName attributeName)
/*     */   {
/* 474 */     if (!(openElementTag instanceof OpenElementTag)) {
/* 475 */       return removeAttribute(OpenElementTag.asEngineOpenElementTag(openElementTag), attributeName);
/*     */     }
/* 477 */     return ((OpenElementTag)openElementTag).removeAttribute(attributeName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ICloseElementTag createCloseElementTag(String elementName)
/*     */   {
/* 485 */     return createCloseElementTag(elementName, false, false);
/*     */   }
/*     */   
/*     */ 
/*     */   public ICloseElementTag createCloseElementTag(String elementName, boolean synthetic, boolean unmatched)
/*     */   {
/* 491 */     ElementDefinition elementDefinition = this.elementDefinitions.forName(this.templateMode, elementName);
/* 492 */     return new CloseElementTag(this.templateMode, elementDefinition, elementName, null, synthetic, unmatched);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private Attribute buildAttribute(String name, String value, AttributeValueQuotes quotes)
/*     */   {
/* 499 */     AttributeDefinition attributeDefinition = this.attributeDefinitions.forName(this.templateMode, name);
/* 500 */     return new Attribute(attributeDefinition, name, "=", value, quotes, null, -1, -1);
/*     */   }
/*     */   
/*     */   private Attribute[] buildAttributeArray(Map<String, String> attributes, AttributeValueQuotes quotes)
/*     */   {
/* 505 */     if ((attributes == null) || (attributes.size() == 0)) {
/* 506 */       return Attributes.EMPTY_ATTRIBUTE_ARRAY;
/*     */     }
/* 508 */     int i = 0;
/* 509 */     Attribute[] newAttributes = new Attribute[attributes.size()];
/* 510 */     for (Map.Entry<String, String> attributesEntry : attributes.entrySet()) {
/* 511 */       newAttributes[(i++)] = buildAttribute((String)attributesEntry.getKey(), (String)attributesEntry.getValue(), quotes);
/*     */     }
/* 513 */     return newAttributes;
/*     */   }
/*     */   
/*     */   private Attributes buildAttributes(Attribute[] attributeArray)
/*     */   {
/* 518 */     if ((attributeArray == null) || (attributeArray.length == 0))
/* 519 */       return Attributes.EMPTY_ATTRIBUTES;
/*     */     String[] innerWhiteSpaces;
/*     */     String[] innerWhiteSpaces;
/* 522 */     if (attributeArray.length < SYNTHETIC_INNER_WHITESPACES.length) {
/* 523 */       innerWhiteSpaces = SYNTHETIC_INNER_WHITESPACES[attributeArray.length];
/*     */     } else {
/* 525 */       innerWhiteSpaces = new String[attributeArray.length];
/* 526 */       Arrays.fill(innerWhiteSpaces, " ");
/*     */     }
/* 528 */     return new Attributes(attributeArray, innerWhiteSpaces);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\StandardModelFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */