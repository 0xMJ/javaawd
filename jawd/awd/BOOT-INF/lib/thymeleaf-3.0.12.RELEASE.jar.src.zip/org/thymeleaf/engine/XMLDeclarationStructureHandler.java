/*     */ package org.thymeleaf.engine;
/*     */ 
/*     */ import org.thymeleaf.model.IModel;
/*     */ import org.thymeleaf.processor.xmldeclaration.IXMLDeclarationStructureHandler;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class XMLDeclarationStructureHandler
/*     */   implements IXMLDeclarationStructureHandler
/*     */ {
/*     */   boolean setXMLDeclaration;
/*     */   String setXMLDeclarationKeyword;
/*     */   String setXMLDeclarationVersion;
/*     */   String setXMLDeclarationEncoding;
/*     */   String setXMLDeclarationStandalone;
/*     */   boolean replaceWithModel;
/*     */   IModel replaceWithModelValue;
/*     */   boolean replaceWithModelProcessable;
/*     */   boolean removeXMLDeclaration;
/*     */   
/*     */   XMLDeclarationStructureHandler()
/*     */   {
/*  58 */     reset();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setXMLDeclaration(String keyword, String version, String encoding, String standalone)
/*     */   {
/*  66 */     reset();
/*  67 */     Validate.notNull(keyword, "Keyword cannot be null");
/*  68 */     this.setXMLDeclaration = true;
/*  69 */     this.setXMLDeclarationKeyword = keyword;
/*  70 */     this.setXMLDeclarationVersion = version;
/*  71 */     this.setXMLDeclarationEncoding = encoding;
/*  72 */     this.setXMLDeclarationStandalone = standalone;
/*     */   }
/*     */   
/*     */   public void replaceWith(IModel model, boolean processable)
/*     */   {
/*  77 */     reset();
/*  78 */     Validate.notNull(model, "Model cannot be null");
/*  79 */     this.replaceWithModel = true;
/*  80 */     this.replaceWithModelValue = model;
/*  81 */     this.replaceWithModelProcessable = processable;
/*     */   }
/*     */   
/*     */   public void removeXMLDeclaration()
/*     */   {
/*  86 */     reset();
/*  87 */     this.removeXMLDeclaration = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void reset()
/*     */   {
/*  95 */     this.setXMLDeclaration = false;
/*  96 */     this.setXMLDeclarationKeyword = null;
/*  97 */     this.setXMLDeclarationVersion = null;
/*  98 */     this.setXMLDeclarationEncoding = null;
/*  99 */     this.setXMLDeclarationStandalone = null;
/*     */     
/* 101 */     this.replaceWithModel = false;
/* 102 */     this.replaceWithModelValue = null;
/* 103 */     this.replaceWithModelProcessable = false;
/*     */     
/* 105 */     this.removeXMLDeclaration = false;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\XMLDeclarationStructureHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */