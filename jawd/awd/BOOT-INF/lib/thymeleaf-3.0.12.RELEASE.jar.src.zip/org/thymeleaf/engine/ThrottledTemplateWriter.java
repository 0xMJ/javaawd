/*     */ package org.thymeleaf.engine;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.Writer;
/*     */ import java.nio.channels.Channels;
/*     */ import java.nio.channels.WritableByteChannel;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.CharsetEncoder;
/*     */ import org.thymeleaf.exceptions.TemplateOutputException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ThrottledTemplateWriter
/*     */   extends Writer
/*     */   implements IThrottledTemplateWriterControl
/*     */ {
/*     */   private final String templateName;
/*     */   private final TemplateFlowController flowController;
/*     */   private IThrottledTemplateWriterAdapter adapter;
/*     */   private Writer writer;
/*     */   private boolean flushable;
/*     */   
/*     */   ThrottledTemplateWriter(String templateName, TemplateFlowController flowController)
/*     */   {
/*  52 */     this.templateName = templateName;
/*  53 */     this.flowController = flowController;
/*  54 */     this.adapter = null;
/*  55 */     this.writer = null;
/*  56 */     this.flushable = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   void setOutput(Writer writer)
/*     */   {
/*  63 */     if ((this.adapter != null) && ((this.adapter instanceof ThrottledTemplateWriterOutputStreamAdapter))) {
/*  64 */       throw new TemplateOutputException("The throttled processor has already been initialized to use byte-based output (OutputStream), but a Writer has been specified.", this.templateName, -1, -1, null);
/*     */     }
/*     */     
/*     */ 
/*  68 */     if (this.adapter == null) {
/*  69 */       this.adapter = new ThrottledTemplateWriterWriterAdapter(this.templateName, this.flowController);
/*  70 */       this.writer = ((ThrottledTemplateWriterWriterAdapter)this.adapter);
/*     */     }
/*  72 */     ((ThrottledTemplateWriterWriterAdapter)this.adapter).setWriter(writer);
/*     */   }
/*     */   
/*     */   void setOutput(OutputStream outputStream, Charset charset, int maxOutputInBytes)
/*     */   {
/*  77 */     if ((this.adapter != null) && ((this.adapter instanceof ThrottledTemplateWriterWriterAdapter))) {
/*  78 */       throw new TemplateOutputException("The throttled processor has already been initialized to use char-based output (Writer), but an OutputStream has been specified.", this.templateName, -1, -1, null);
/*     */     }
/*     */     
/*     */ 
/*  82 */     if (this.adapter == null)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*  87 */       int adapterOverflowBufferIncrementBytes = maxOutputInBytes == Integer.MAX_VALUE ? 128 : Math.min(128, Math.max(16, maxOutputInBytes / 8));
/*  88 */       this.adapter = new ThrottledTemplateWriterOutputStreamAdapter(this.templateName, this.flowController, adapterOverflowBufferIncrementBytes);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 111 */       CharsetEncoder charsetEncoder = charset.newEncoder();
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 118 */       int channelBufferSize = maxOutputInBytes == Integer.MAX_VALUE ? 1024 : Math.min(512, Math.max(64, adapterOverflowBufferIncrementBytes * 2));
/* 119 */       WritableByteChannel channel = Channels.newChannel((ThrottledTemplateWriterOutputStreamAdapter)this.adapter);
/* 120 */       this.writer = Channels.newWriter(channel, charsetEncoder, channelBufferSize);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 125 */     ((ThrottledTemplateWriterOutputStreamAdapter)this.adapter).setOutputStream(outputStream);
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isOverflown()
/*     */     throws IOException
/*     */   {
/* 132 */     if (this.flushable)
/*     */     {
/*     */ 
/*     */ 
/* 136 */       flush();
/* 137 */       this.flushable = false;
/*     */     }
/* 139 */     return this.adapter.isOverflown();
/*     */   }
/*     */   
/*     */   public boolean isStopped() throws IOException {
/* 143 */     if (this.flushable)
/*     */     {
/*     */ 
/*     */ 
/* 147 */       flush();
/* 148 */       this.flushable = false;
/*     */     }
/* 150 */     return this.adapter.isStopped();
/*     */   }
/*     */   
/*     */   public int getWrittenCount()
/*     */   {
/* 155 */     return this.adapter.getWrittenCount();
/*     */   }
/*     */   
/*     */   public int getMaxOverflowSize()
/*     */   {
/* 160 */     return this.adapter.getMaxOverflowSize();
/*     */   }
/*     */   
/*     */   public int getOverflowGrowCount()
/*     */   {
/* 165 */     return this.adapter.getOverflowGrowCount();
/*     */   }
/*     */   
/*     */   void allow(int limit)
/*     */   {
/* 170 */     this.adapter.allow(limit);
/*     */   }
/*     */   
/*     */ 
/*     */   public void write(int c)
/*     */     throws IOException
/*     */   {
/* 177 */     this.flushable = true;
/* 178 */     this.writer.write(c);
/*     */   }
/*     */   
/*     */   public void write(String str)
/*     */     throws IOException
/*     */   {
/* 184 */     this.flushable = true;
/* 185 */     this.writer.write(str);
/*     */   }
/*     */   
/*     */   public void write(String str, int off, int len)
/*     */     throws IOException
/*     */   {
/* 191 */     this.flushable = true;
/* 192 */     this.writer.write(str, off, len);
/*     */   }
/*     */   
/*     */   public void write(char[] cbuf)
/*     */     throws IOException
/*     */   {
/* 198 */     this.flushable = true;
/* 199 */     this.writer.write(cbuf);
/*     */   }
/*     */   
/*     */   public void write(char[] cbuf, int off, int len)
/*     */     throws IOException
/*     */   {
/* 205 */     this.flushable = true;
/* 206 */     this.writer.write(cbuf, off, len);
/*     */   }
/*     */   
/*     */   public void flush()
/*     */     throws IOException
/*     */   {
/* 212 */     this.writer.flush();
/*     */   }
/*     */   
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/* 218 */     this.writer.close();
/*     */   }
/*     */   
/*     */   static abstract interface IThrottledTemplateWriterAdapter
/*     */   {
/*     */     public abstract boolean isOverflown();
/*     */     
/*     */     public abstract boolean isStopped();
/*     */     
/*     */     public abstract int getWrittenCount();
/*     */     
/*     */     public abstract int getMaxOverflowSize();
/*     */     
/*     */     public abstract int getOverflowGrowCount();
/*     */     
/*     */     public abstract void allow(int paramInt);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\ThrottledTemplateWriter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */