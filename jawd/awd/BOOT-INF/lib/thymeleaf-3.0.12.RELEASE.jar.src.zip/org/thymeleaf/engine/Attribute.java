/*     */ package org.thymeleaf.engine;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.model.AttributeValueQuotes;
/*     */ import org.thymeleaf.model.IAttribute;
/*     */ import org.thymeleaf.standard.expression.IStandardExpression;
/*     */ import org.thymeleaf.util.FastStringWriter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class Attribute
/*     */   implements IAttribute
/*     */ {
/*     */   static final String DEFAULT_OPERATOR = "=";
/*     */   final AttributeDefinition definition;
/*     */   final String completeName;
/*     */   final String operator;
/*     */   final String value;
/*     */   final AttributeValueQuotes valueQuotes;
/*     */   final String templateName;
/*     */   final int line;
/*     */   final int col;
/*  57 */   private volatile IStandardExpression standardExpression = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Attribute(AttributeDefinition definition, String completeName, String operator, String value, AttributeValueQuotes valueQuotes, String templateName, int line, int col)
/*     */   {
/*  71 */     this.definition = definition;
/*  72 */     this.completeName = completeName;
/*  73 */     this.value = value;
/*  74 */     if (value == null) {
/*  75 */       this.operator = null;
/*     */     }
/*  77 */     else if (operator == null) {
/*  78 */       this.operator = "=";
/*     */     } else {
/*  80 */       this.operator = operator;
/*     */     }
/*     */     
/*  83 */     if (value == null)
/*     */     {
/*  85 */       this.valueQuotes = null;
/*     */     }
/*  87 */     else if (valueQuotes == null) {
/*  88 */       this.valueQuotes = AttributeValueQuotes.DOUBLE;
/*  89 */     } else if ((valueQuotes == AttributeValueQuotes.NONE) && (value.length() == 0))
/*     */     {
/*  91 */       this.valueQuotes = AttributeValueQuotes.DOUBLE;
/*     */     } else {
/*  93 */       this.valueQuotes = valueQuotes;
/*     */     }
/*     */     
/*  96 */     this.templateName = templateName;
/*  97 */     this.line = line;
/*  98 */     this.col = col;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public AttributeDefinition getAttributeDefinition()
/*     */   {
/* 106 */     return this.definition;
/*     */   }
/*     */   
/*     */   public String getAttributeCompleteName() {
/* 110 */     return this.completeName;
/*     */   }
/*     */   
/*     */   public String getOperator() {
/* 114 */     return this.operator;
/*     */   }
/*     */   
/*     */   public String getValue() {
/* 118 */     return this.value;
/*     */   }
/*     */   
/*     */   public AttributeValueQuotes getValueQuotes() {
/* 122 */     return this.valueQuotes;
/*     */   }
/*     */   
/*     */   public String getTemplateName() {
/* 126 */     return this.templateName;
/*     */   }
/*     */   
/*     */   public final boolean hasLocation() {
/* 130 */     return (this.templateName != null) && (this.line != -1) && (this.col != -1);
/*     */   }
/*     */   
/*     */   public int getLine() {
/* 134 */     return this.line;
/*     */   }
/*     */   
/*     */   public int getCol() {
/* 138 */     return this.col;
/*     */   }
/*     */   
/*     */   IStandardExpression getCachedStandardExpression()
/*     */   {
/* 143 */     return this.standardExpression;
/*     */   }
/*     */   
/*     */   void setCachedStandardExpression(IStandardExpression standardExpression) {
/* 147 */     this.standardExpression = standardExpression;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Attribute modify(AttributeDefinition definition, String completeName, String value, AttributeValueQuotes valueQuotes)
/*     */   {
/* 161 */     return new Attribute(
/* 162 */       definition == null ? this.definition : definition, 
/* 163 */       completeName == null ? this.completeName : completeName, this.operator, value, 
/*     */       
/*     */ 
/* 166 */       valueQuotes == null ? this.valueQuotes : valueQuotes, this.templateName, this.line, this.col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void write(Writer writer)
/*     */     throws IOException
/*     */   {
/* 183 */     writer.write(this.completeName);
/* 184 */     if (this.value != null) {
/* 185 */       writer.write(this.operator);
/* 186 */       if (this.valueQuotes == null) {
/* 187 */         writer.write(this.value);
/*     */       } else {
/* 189 */         switch (this.valueQuotes) {
/*     */         case DOUBLE: 
/* 191 */           writer.write(34);
/* 192 */           writer.write(this.value);
/* 193 */           writer.write(34);
/* 194 */           break;
/*     */         case SINGLE: 
/* 196 */           writer.write(39);
/* 197 */           writer.write(this.value);
/* 198 */           writer.write(39);
/* 199 */           break;
/*     */         case NONE: 
/* 201 */           writer.write(this.value);
/*     */         }
/*     */         
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 214 */     Writer stringWriter = new FastStringWriter();
/*     */     try {
/* 216 */       write(stringWriter);
/*     */     }
/*     */     catch (IOException e) {
/* 219 */       throw new TemplateProcessingException("Error computing attribute representation", e);
/*     */     }
/* 221 */     return stringWriter.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\Attribute.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */