/*     */ package org.thymeleaf.engine;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import org.thymeleaf.model.IModelVisitor;
/*     */ import org.thymeleaf.model.IXMLDeclaration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class XMLDeclaration
/*     */   extends AbstractTemplateEvent
/*     */   implements IXMLDeclaration, IEngineTemplateEvent
/*     */ {
/*     */   public static final String DEFAULT_KEYWORD = "xml";
/*     */   public static final String DEFAULT_VERSION = "1.0";
/*     */   public static final String ATTRIBUTE_NAME_VERSION = "version";
/*     */   public static final String ATTRIBUTE_NAME_ENCODING = "encoding";
/*     */   public static final String ATTRIBUTE_NAME_STANDALONE = "standalone";
/*     */   private final String keyword;
/*     */   private final String version;
/*     */   private final String encoding;
/*     */   private final String standalone;
/*     */   private final String xmlDeclaration;
/*     */   
/*     */   XMLDeclaration(String encoding)
/*     */   {
/*  54 */     this("xml", "1.0", encoding, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   XMLDeclaration(String keyword, String version, String encoding, String standalone)
/*     */   {
/*  64 */     this.keyword = keyword;
/*  65 */     this.version = version;
/*  66 */     this.encoding = encoding;
/*  67 */     this.standalone = standalone;
/*  68 */     this.xmlDeclaration = computeXmlDeclaration();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   XMLDeclaration(String xmlDeclaration, String keyword, String version, String encoding, String standalone, String templateName, int line, int col)
/*     */   {
/*  79 */     super(templateName, line, col);
/*  80 */     this.keyword = keyword;
/*  81 */     this.version = version;
/*  82 */     this.encoding = encoding;
/*  83 */     this.standalone = standalone;
/*  84 */     this.xmlDeclaration = (xmlDeclaration != null ? xmlDeclaration : computeXmlDeclaration());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getKeyword()
/*     */   {
/*  91 */     return this.keyword;
/*     */   }
/*     */   
/*     */   public String getVersion() {
/*  95 */     return this.version;
/*     */   }
/*     */   
/*     */   public String getEncoding() {
/*  99 */     return this.encoding;
/*     */   }
/*     */   
/*     */   public String getStandalone() {
/* 103 */     return this.standalone;
/*     */   }
/*     */   
/*     */   public String getXmlDeclaration() {
/* 107 */     return this.xmlDeclaration;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String computeXmlDeclaration()
/*     */   {
/* 115 */     StringBuilder strBuilder = new StringBuilder(40);
/*     */     
/* 117 */     strBuilder.append("<?");
/* 118 */     strBuilder.append(this.keyword);
/* 119 */     if (this.version != null) {
/* 120 */       strBuilder.append(' ');
/* 121 */       strBuilder.append("version");
/* 122 */       strBuilder.append("=\"");
/* 123 */       strBuilder.append(this.version);
/* 124 */       strBuilder.append('"');
/*     */     }
/* 126 */     if (this.encoding != null) {
/* 127 */       strBuilder.append(' ');
/* 128 */       strBuilder.append("encoding");
/* 129 */       strBuilder.append("=\"");
/* 130 */       strBuilder.append(this.encoding);
/* 131 */       strBuilder.append('"');
/*     */     }
/* 133 */     if (this.standalone != null) {
/* 134 */       strBuilder.append(' ');
/* 135 */       strBuilder.append("standalone");
/* 136 */       strBuilder.append("=\"");
/* 137 */       strBuilder.append(this.standalone);
/* 138 */       strBuilder.append('"');
/*     */     }
/* 140 */     strBuilder.append("?>");
/*     */     
/* 142 */     return strBuilder.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void accept(IModelVisitor visitor)
/*     */   {
/* 150 */     visitor.visit(this);
/*     */   }
/*     */   
/*     */   public void write(Writer writer) throws IOException
/*     */   {
/* 155 */     writer.write(this.xmlDeclaration);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static XMLDeclaration asEngineXMLDeclaration(IXMLDeclaration xmlDeclaration)
/*     */   {
/* 163 */     if ((xmlDeclaration instanceof XMLDeclaration)) {
/* 164 */       return (XMLDeclaration)xmlDeclaration;
/*     */     }
/*     */     
/* 167 */     return new XMLDeclaration(null, xmlDeclaration
/*     */     
/* 169 */       .getKeyword(), xmlDeclaration
/* 170 */       .getVersion(), xmlDeclaration
/* 171 */       .getEncoding(), xmlDeclaration
/* 172 */       .getStandalone(), xmlDeclaration
/* 173 */       .getTemplateName(), xmlDeclaration.getLine(), xmlDeclaration.getCol());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void beHandled(ITemplateHandler handler)
/*     */   {
/* 182 */     handler.handleXMLDeclaration(this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 190 */     return getXmlDeclaration();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\XMLDeclaration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */