/*     */ package org.thymeleaf.engine;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import org.thymeleaf.model.AttributeValueQuotes;
/*     */ import org.thymeleaf.model.IAttribute;
/*     */ import org.thymeleaf.model.IProcessableElementTag;
/*     */ import org.thymeleaf.processor.element.IElementProcessor;
/*     */ import org.thymeleaf.processor.element.MatchingElementName;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ import org.thymeleaf.util.ProcessorComparators;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class AbstractProcessableElementTag
/*     */   extends AbstractElementTag
/*     */   implements IProcessableElementTag
/*     */ {
/*  44 */   private static final IElementProcessor[] EMPTY_ASSOCIATED_PROCESSORS = new IElementProcessor[0];
/*     */   
/*     */ 
/*     */   final Attributes attributes;
/*     */   
/*     */ 
/*  50 */   private volatile IElementProcessor[] associatedProcessors = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   AbstractProcessableElementTag(TemplateMode templateMode, ElementDefinition elementDefinition, String elementCompleteName, Attributes attributes, boolean synthetic)
/*     */   {
/*  61 */     super(templateMode, elementDefinition, elementCompleteName, synthetic);
/*  62 */     this.attributes = attributes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   AbstractProcessableElementTag(TemplateMode templateMode, ElementDefinition elementDefinition, String elementCompleteName, Attributes attributes, boolean synthetic, String templateName, int line, int col)
/*     */   {
/*  75 */     super(templateMode, elementDefinition, elementCompleteName, synthetic, templateName, line, col);
/*  76 */     this.attributes = attributes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final boolean hasAttribute(String completeName)
/*     */   {
/*  83 */     Validate.notNull(completeName, "Attribute name cannot be null");
/*  84 */     if (this.attributes == null) {
/*  85 */       return false;
/*     */     }
/*  87 */     return this.attributes.hasAttribute(this.templateMode, completeName);
/*     */   }
/*     */   
/*     */   public final boolean hasAttribute(String prefix, String name)
/*     */   {
/*  92 */     Validate.notNull(name, "Attribute name cannot be null");
/*  93 */     if (this.attributes == null) {
/*  94 */       return false;
/*     */     }
/*  96 */     return this.attributes.hasAttribute(this.templateMode, prefix, name);
/*     */   }
/*     */   
/*     */   public final boolean hasAttribute(AttributeName attributeName)
/*     */   {
/* 101 */     Validate.notNull(attributeName, "Attribute name cannot be null");
/* 102 */     if (this.attributes == null) {
/* 103 */       return false;
/*     */     }
/* 105 */     return this.attributes.hasAttribute(attributeName);
/*     */   }
/*     */   
/*     */   public final IAttribute getAttribute(String completeName)
/*     */   {
/* 110 */     Validate.notNull(completeName, "Attribute name cannot be null");
/* 111 */     if (this.attributes == null) {
/* 112 */       return null;
/*     */     }
/* 114 */     return this.attributes.getAttribute(this.templateMode, completeName);
/*     */   }
/*     */   
/*     */   public final IAttribute getAttribute(String prefix, String name)
/*     */   {
/* 119 */     Validate.notNull(name, "Attribute name cannot be null");
/* 120 */     if (this.attributes == null) {
/* 121 */       return null;
/*     */     }
/* 123 */     return this.attributes.getAttribute(this.templateMode, prefix, name);
/*     */   }
/*     */   
/*     */   public final IAttribute getAttribute(AttributeName attributeName)
/*     */   {
/* 128 */     Validate.notNull(attributeName, "Attribute name cannot be null");
/* 129 */     if (this.attributes == null) {
/* 130 */       return null;
/*     */     }
/* 132 */     return this.attributes.getAttribute(attributeName);
/*     */   }
/*     */   
/*     */   public final String getAttributeValue(String completeName)
/*     */   {
/* 137 */     Validate.notNull(completeName, "Attribute name cannot be null");
/* 138 */     if (this.attributes == null) {
/* 139 */       return null;
/*     */     }
/* 141 */     Attribute attribute = this.attributes.getAttribute(this.templateMode, completeName);
/* 142 */     return attribute != null ? attribute.getValue() : null;
/*     */   }
/*     */   
/*     */   public final String getAttributeValue(String prefix, String name)
/*     */   {
/* 147 */     Validate.notNull(name, "Attribute name cannot be null");
/* 148 */     if (this.attributes == null) {
/* 149 */       return null;
/*     */     }
/* 151 */     Attribute attribute = this.attributes.getAttribute(this.templateMode, prefix, name);
/* 152 */     return attribute != null ? attribute.getValue() : null;
/*     */   }
/*     */   
/*     */   public final String getAttributeValue(AttributeName attributeName)
/*     */   {
/* 157 */     Validate.notNull(attributeName, "Attribute name cannot be null");
/* 158 */     if (this.attributes == null) {
/* 159 */       return null;
/*     */     }
/* 161 */     Attribute attribute = this.attributes.getAttribute(attributeName);
/* 162 */     return attribute != null ? attribute.getValue() : null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public IAttribute[] getAllAttributes()
/*     */   {
/* 169 */     if (this.attributes == null) {
/* 170 */       return Attributes.EMPTY_ATTRIBUTE_ARRAY;
/*     */     }
/* 172 */     return this.attributes.getAllAttributes();
/*     */   }
/*     */   
/*     */   public Map<String, String> getAttributeMap()
/*     */   {
/* 177 */     if (this.attributes == null) {
/* 178 */       return Collections.emptyMap();
/*     */     }
/* 180 */     return this.attributes.getAttributeMap();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   IElementProcessor[] getAssociatedProcessors()
/*     */   {
/* 187 */     IElementProcessor[] p = this.associatedProcessors;
/* 188 */     if (p == null) {
/* 189 */       this.associatedProcessors = (p = computeProcessors());
/*     */     }
/* 191 */     return p;
/*     */   }
/*     */   
/*     */ 
/*     */   boolean hasAssociatedProcessors()
/*     */   {
/* 197 */     return getAssociatedProcessors().length > 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private IElementProcessor[] computeProcessors()
/*     */   {
/* 205 */     int associatedProcessorCount = this.attributes != null ? this.attributes.getAssociatedProcessorCount() : 0;
/*     */     
/*     */ 
/* 208 */     if ((this.attributes == null) || (associatedProcessorCount == 0)) {
/* 209 */       return this.elementDefinition.hasAssociatedProcessors ? this.elementDefinition.associatedProcessors : EMPTY_ASSOCIATED_PROCESSORS;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 214 */     int elementProcessorCount = this.elementDefinition.hasAssociatedProcessors ? this.elementDefinition.associatedProcessors.length : 0;
/* 215 */     IElementProcessor[] processors = new IElementProcessor[elementProcessorCount + associatedProcessorCount];
/*     */     
/* 217 */     if (elementProcessorCount > 0) {
/* 218 */       System.arraycopy(this.elementDefinition.associatedProcessors, 0, processors, 0, elementProcessorCount);
/*     */     }
/*     */     
/* 221 */     int idx = elementProcessorCount;
/* 222 */     int n = this.attributes.attributes.length;
/* 223 */     while (n-- != 0)
/*     */     {
/* 225 */       if (this.attributes.attributes[n].definition.hasAssociatedProcessors)
/*     */       {
/*     */ 
/*     */ 
/* 229 */         IElementProcessor[] attributeAssociatedProcessors = this.attributes.attributes[n].definition.associatedProcessors;
/* 230 */         for (int i = 0; i < attributeAssociatedProcessors.length; i++)
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 239 */           MatchingElementName matchingElementName = attributeAssociatedProcessors[i].getMatchingElementName();
/* 240 */           if ((matchingElementName == null) || (matchingElementName.matches(this.elementDefinition.elementName)))
/*     */           {
/*     */ 
/*     */ 
/*     */ 
/* 245 */             processors[(idx++)] = attributeAssociatedProcessors[i];
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 253 */     if (idx < processors.length) {
/* 254 */       processors = (IElementProcessor[])Arrays.copyOf(processors, idx);
/*     */     }
/*     */     
/* 257 */     if (processors.length > 1) {
/* 258 */       Arrays.sort(processors, ProcessorComparators.PROCESSOR_COMPARATOR);
/*     */     }
/*     */     
/* 261 */     return processors;
/*     */   }
/*     */   
/*     */   abstract AbstractProcessableElementTag setAttribute(AttributeDefinitions paramAttributeDefinitions, AttributeDefinition paramAttributeDefinition, String paramString1, String paramString2, AttributeValueQuotes paramAttributeValueQuotes);
/*     */   
/*     */   abstract AbstractProcessableElementTag replaceAttribute(AttributeDefinitions paramAttributeDefinitions, AttributeName paramAttributeName, AttributeDefinition paramAttributeDefinition, String paramString1, String paramString2, AttributeValueQuotes paramAttributeValueQuotes);
/*     */   
/*     */   abstract AbstractProcessableElementTag removeAttribute(String paramString1, String paramString2);
/*     */   
/*     */   abstract AbstractProcessableElementTag removeAttribute(String paramString);
/*     */   
/*     */   abstract AbstractProcessableElementTag removeAttribute(AttributeName paramAttributeName);
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\AbstractProcessableElementTag.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */