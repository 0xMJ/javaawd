/*    */ package org.thymeleaf.engine;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class TextAttributeName
/*    */   extends AttributeName
/*    */ {
/*    */   final String completeNamespacedAttributeName;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   static TextAttributeName forName(String prefix, String attributeName)
/*    */   {
/* 36 */     boolean hasPrefix = (prefix != null) && (prefix.length() > 0);
/*    */     
/*    */     String[] completeAttributeNames;
/*    */     String completeNamespacedAttributeName;
/*    */     String[] completeAttributeNames;
/* 41 */     if (hasPrefix)
/*    */     {
/* 43 */       String completeNamespacedAttributeName = prefix + ":" + attributeName;
/* 44 */       completeAttributeNames = new String[] { completeNamespacedAttributeName };
/*    */     }
/*    */     else
/*    */     {
/* 48 */       completeNamespacedAttributeName = attributeName;
/* 49 */       completeAttributeNames = new String[] { attributeName };
/*    */     }
/*    */     
/*    */ 
/* 53 */     return new TextAttributeName(prefix, attributeName, completeNamespacedAttributeName, completeAttributeNames);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private TextAttributeName(String prefix, String attributeName, String completeNamespacedAttributeName, String[] completeAttributeNames)
/*    */   {
/* 65 */     super(prefix, attributeName, completeAttributeNames);
/* 66 */     this.completeNamespacedAttributeName = completeNamespacedAttributeName;
/*    */   }
/*    */   
/*    */ 
/*    */   public String getCompleteNamespacedAttributeName()
/*    */   {
/* 72 */     return this.completeNamespacedAttributeName;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\TextAttributeName.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */