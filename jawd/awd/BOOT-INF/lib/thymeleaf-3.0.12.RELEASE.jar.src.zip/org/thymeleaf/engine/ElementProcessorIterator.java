/*     */ package org.thymeleaf.engine;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Comparator;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.processor.element.IElementProcessor;
/*     */ import org.thymeleaf.util.ProcessorComparators;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ElementProcessorIterator
/*     */ {
/*  43 */   private int last = -1;
/*     */   
/*     */ 
/*     */ 
/*  47 */   private IElementProcessor[] processors = null;
/*  48 */   private boolean[] visited = null;
/*  49 */   private int size = 0;
/*     */   
/*     */ 
/*     */ 
/*  53 */   private IElementProcessor[] auxProcessors = null;
/*  54 */   private boolean[] auxVisited = null;
/*  55 */   private int auxSize = 0;
/*     */   
/*     */ 
/*  58 */   private AbstractProcessableElementTag currentTag = null;
/*     */   
/*     */ 
/*  61 */   private boolean lastToBeRepeated = false;
/*  62 */   private boolean lastWasRepeated = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void reset()
/*     */   {
/*  73 */     this.size = 0;
/*  74 */     this.last = -1;
/*  75 */     this.currentTag = null;
/*  76 */     this.lastToBeRepeated = false;
/*  77 */     this.lastWasRepeated = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   IElementProcessor next(AbstractProcessableElementTag tag)
/*     */   {
/*  85 */     if (this.lastToBeRepeated) {
/*  86 */       IElementProcessor repeatedLast = computeRepeatedLast(tag);
/*  87 */       this.lastToBeRepeated = false;
/*  88 */       this.lastWasRepeated = true;
/*  89 */       return repeatedLast;
/*     */     }
/*     */     
/*  92 */     this.lastWasRepeated = false;
/*     */     
/*  94 */     if (this.currentTag != tag) {
/*  95 */       recompute(tag);
/*  96 */       this.currentTag = tag;
/*  97 */       this.last = -1;
/*     */     }
/*     */     
/* 100 */     if (this.processors == null) {
/* 101 */       return null;
/*     */     }
/*     */     
/*     */ 
/* 105 */     int i = this.last + 1;
/* 106 */     int n = this.size - i;
/* 107 */     while (n-- != 0) {
/* 108 */       if (this.visited[i] == 0) {
/* 109 */         this.visited[i] = true;
/* 110 */         this.last = i;
/* 111 */         return this.processors[i];
/*     */       }
/* 113 */       i++;
/*     */     }
/* 115 */     this.last = this.size;
/* 116 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private IElementProcessor computeRepeatedLast(AbstractProcessableElementTag tag)
/*     */   {
/* 123 */     if (this.currentTag != tag) {
/* 124 */       throw new TemplateProcessingException("Cannot return last processor to be repeated: changes were made and processor recompute is needed!");
/*     */     }
/*     */     
/* 127 */     if (this.processors == null) {
/* 128 */       throw new TemplateProcessingException("Cannot return last processor to be repeated: no processors in tag!");
/*     */     }
/*     */     
/* 131 */     return this.processors[this.last];
/*     */   }
/*     */   
/*     */ 
/*     */   boolean lastWasRepeated()
/*     */   {
/* 137 */     return this.lastWasRepeated;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   void setLastToBeRepeated(AbstractProcessableElementTag tag)
/*     */   {
/* 144 */     if (this.currentTag != tag) {
/* 145 */       throw new TemplateProcessingException("Cannot set last processor to be repeated: processor recompute is needed!");
/*     */     }
/*     */     
/* 148 */     if (this.processors == null) {
/* 149 */       throw new TemplateProcessingException("Cannot set last processor to be repeated: no processors in tag!");
/*     */     }
/*     */     
/* 152 */     this.lastToBeRepeated = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void recompute(AbstractProcessableElementTag tag)
/*     */   {
/* 160 */     IElementProcessor[] associatedProcessors = tag.getAssociatedProcessors();
/*     */     
/* 162 */     if (associatedProcessors.length == 0)
/*     */     {
/*     */ 
/* 165 */       if (this.processors != null)
/*     */       {
/* 167 */         this.size = 0;
/*     */       }
/*     */       
/* 170 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 175 */     if (this.processors == null)
/*     */     {
/*     */ 
/* 178 */       this.size = associatedProcessors.length;
/* 179 */       this.processors = new IElementProcessor[Math.max(this.size, 4)];
/* 180 */       this.visited = new boolean[Math.max(this.size, 4)];
/*     */       
/* 182 */       System.arraycopy(associatedProcessors, 0, this.processors, 0, this.size);
/* 183 */       Arrays.fill(this.visited, false);
/*     */       
/* 185 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 192 */     this.auxSize = associatedProcessors.length;
/* 193 */     if ((this.auxProcessors == null) || (this.auxSize > this.auxProcessors.length))
/*     */     {
/* 195 */       this.auxProcessors = new IElementProcessor[Math.max(this.auxSize, 4)];
/* 196 */       this.auxVisited = new boolean[Math.max(this.auxSize, 4)];
/*     */     }
/*     */     
/* 199 */     System.arraycopy(associatedProcessors, 0, this.auxProcessors, 0, this.auxSize);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 204 */     int i = 0;
/* 205 */     int j = 0;
/* 206 */     while (i < this.auxSize)
/*     */     {
/* 208 */       if ((i >= this.size) || (j >= this.size))
/*     */       {
/*     */ 
/*     */ 
/* 212 */         Arrays.fill(this.auxVisited, i, this.auxSize, false);
/* 213 */         break;
/*     */       }
/*     */       
/* 216 */       if (this.auxProcessors[i] == this.processors[j]) {
/* 217 */         this.auxVisited[i] = this.visited[j];
/* 218 */         i++;
/* 219 */         j++;
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/*     */ 
/* 225 */         int comp = ProcessorComparators.PROCESSOR_COMPARATOR.compare(this.auxProcessors[i], this.processors[j]);
/*     */         
/* 227 */         if (comp == 0)
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 235 */           throw new IllegalStateException("Two different registered processors have returned zero as a result of their comparison, which is forbidden. Offending processors are " + this.auxProcessors[i].getClass().getName() + " and " + this.processors[j].getClass().getName());
/*     */         }
/* 237 */         if (comp < 0)
/*     */         {
/*     */ 
/* 240 */           this.auxVisited[i] = false;
/* 241 */           i++;
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/* 246 */           j++;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 254 */     IElementProcessor[] swapProcessors = this.auxProcessors;
/* 255 */     boolean[] swapVisited = this.auxVisited;
/* 256 */     this.auxProcessors = this.processors;
/* 257 */     this.auxVisited = this.visited;
/* 258 */     this.processors = swapProcessors;
/* 259 */     this.visited = swapVisited;
/* 260 */     this.size = this.auxSize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   void resetAsCloneOf(ElementProcessorIterator original)
/*     */   {
/* 268 */     this.size = original.size;
/* 269 */     this.last = original.last;
/* 270 */     this.currentTag = original.currentTag;
/* 271 */     this.lastToBeRepeated = original.lastToBeRepeated;
/* 272 */     this.lastWasRepeated = original.lastWasRepeated;
/*     */     
/* 274 */     if ((this.size > 0) && (original.processors != null)) {
/* 275 */       if ((this.processors == null) || (this.processors.length < this.size)) {
/* 276 */         this.processors = new IElementProcessor[this.size];
/* 277 */         this.visited = new boolean[this.size];
/*     */       }
/* 279 */       System.arraycopy(original.processors, 0, this.processors, 0, this.size);
/* 280 */       System.arraycopy(original.visited, 0, this.visited, 0, this.size);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\ElementProcessorIterator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */