/*     */ package org.thymeleaf.engine;
/*     */ 
/*     */ import org.thymeleaf.context.ITemplateContext;
/*     */ import org.thymeleaf.model.ICDATASection;
/*     */ import org.thymeleaf.model.ICloseElementTag;
/*     */ import org.thymeleaf.model.IComment;
/*     */ import org.thymeleaf.model.IDocType;
/*     */ import org.thymeleaf.model.IOpenElementTag;
/*     */ import org.thymeleaf.model.IProcessingInstruction;
/*     */ import org.thymeleaf.model.IStandaloneElementTag;
/*     */ import org.thymeleaf.model.ITemplateEnd;
/*     */ import org.thymeleaf.model.ITemplateStart;
/*     */ import org.thymeleaf.model.IText;
/*     */ import org.thymeleaf.model.IXMLDeclaration;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractTemplateHandler
/*     */   implements ITemplateHandler
/*     */ {
/*  55 */   private ITemplateHandler next = null;
/*  56 */   private ITemplateContext context = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected AbstractTemplateHandler(ITemplateHandler next)
/*     */   {
/*  69 */     this.next = next;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected AbstractTemplateHandler() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setNext(ITemplateHandler next)
/*     */   {
/*  95 */     this.next = next;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setContext(ITemplateContext context)
/*     */   {
/* 111 */     Validate.notNull(context, "Context cannot be null");
/* 112 */     this.context = context;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final ITemplateHandler getNext()
/*     */   {
/* 124 */     return this.next;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final ITemplateContext getContext()
/*     */   {
/* 137 */     return this.context;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleTemplateStart(ITemplateStart templateStart)
/*     */   {
/* 146 */     if (this.next == null) {
/* 147 */       return;
/*     */     }
/*     */     
/* 150 */     this.next.handleTemplateStart(templateStart);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void handleTemplateEnd(ITemplateEnd templateEnd)
/*     */   {
/* 157 */     if (this.next == null) {
/* 158 */       return;
/*     */     }
/*     */     
/* 161 */     this.next.handleTemplateEnd(templateEnd);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleXMLDeclaration(IXMLDeclaration xmlDeclaration)
/*     */   {
/* 169 */     if (this.next == null) {
/* 170 */       return;
/*     */     }
/*     */     
/* 173 */     this.next.handleXMLDeclaration(xmlDeclaration);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleDocType(IDocType docType)
/*     */   {
/* 181 */     if (this.next == null) {
/* 182 */       return;
/*     */     }
/*     */     
/* 185 */     this.next.handleDocType(docType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleCDATASection(ICDATASection cdataSection)
/*     */   {
/* 193 */     if (this.next == null) {
/* 194 */       return;
/*     */     }
/*     */     
/* 197 */     this.next.handleCDATASection(cdataSection);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleComment(IComment comment)
/*     */   {
/* 205 */     if (this.next == null) {
/* 206 */       return;
/*     */     }
/*     */     
/* 209 */     this.next.handleComment(comment);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleText(IText text)
/*     */   {
/* 217 */     if (this.next == null) {
/* 218 */       return;
/*     */     }
/*     */     
/* 221 */     this.next.handleText(text);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void handleStandaloneElement(IStandaloneElementTag standaloneElementTag)
/*     */   {
/* 228 */     if (this.next == null) {
/* 229 */       return;
/*     */     }
/*     */     
/* 232 */     this.next.handleStandaloneElement(standaloneElementTag);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void handleOpenElement(IOpenElementTag openElementTag)
/*     */   {
/* 239 */     if (this.next == null) {
/* 240 */       return;
/*     */     }
/*     */     
/* 243 */     this.next.handleOpenElement(openElementTag);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void handleCloseElement(ICloseElementTag closeElementTag)
/*     */   {
/* 250 */     if (this.next == null) {
/* 251 */       return;
/*     */     }
/*     */     
/* 254 */     this.next.handleCloseElement(closeElementTag);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleProcessingInstruction(IProcessingInstruction processingInstruction)
/*     */   {
/* 262 */     if (this.next == null) {
/* 263 */       return;
/*     */     }
/*     */     
/* 266 */     this.next.handleProcessingInstruction(processingInstruction);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\AbstractTemplateHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */