/*    */ package org.thymeleaf.engine;
/*    */ 
/*    */ import org.thymeleaf.model.IModel;
/*    */ import org.thymeleaf.processor.text.ITextStructureHandler;
/*    */ import org.thymeleaf.util.Validate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class TextStructureHandler
/*    */   implements ITextStructureHandler
/*    */ {
/*    */   boolean setText;
/*    */   CharSequence setTextValue;
/*    */   boolean replaceWithModel;
/*    */   IModel replaceWithModelValue;
/*    */   boolean replaceWithModelProcessable;
/*    */   boolean removeText;
/*    */   
/*    */   TextStructureHandler()
/*    */   {
/* 55 */     reset();
/*    */   }
/*    */   
/*    */ 
/*    */   public void setText(CharSequence text)
/*    */   {
/* 61 */     reset();
/* 62 */     Validate.notNull(text, "Text cannot be null");
/* 63 */     this.setText = true;
/* 64 */     this.setTextValue = text;
/*    */   }
/*    */   
/*    */   public void replaceWith(IModel model, boolean processable)
/*    */   {
/* 69 */     reset();
/* 70 */     Validate.notNull(model, "Model cannot be null");
/* 71 */     this.replaceWithModel = true;
/* 72 */     this.replaceWithModelValue = model;
/* 73 */     this.replaceWithModelProcessable = processable;
/*    */   }
/*    */   
/*    */   public void removeText()
/*    */   {
/* 78 */     reset();
/* 79 */     this.removeText = true;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void reset()
/*    */   {
/* 87 */     this.setText = false;
/* 88 */     this.setTextValue = null;
/*    */     
/* 90 */     this.replaceWithModel = false;
/* 91 */     this.replaceWithModelValue = null;
/* 92 */     this.replaceWithModelProcessable = false;
/*    */     
/* 94 */     this.removeText = false;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\TextStructureHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */