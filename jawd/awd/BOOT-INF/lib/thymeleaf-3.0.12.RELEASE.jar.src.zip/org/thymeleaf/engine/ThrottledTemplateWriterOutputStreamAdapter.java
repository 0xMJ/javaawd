/*     */ package org.thymeleaf.engine;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.util.Arrays;
/*     */ import org.thymeleaf.exceptions.TemplateOutputException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ThrottledTemplateWriterOutputStreamAdapter
/*     */   extends OutputStream
/*     */   implements ThrottledTemplateWriter.IThrottledTemplateWriterAdapter
/*     */ {
/*     */   private final String templateName;
/*     */   private final TemplateFlowController flowController;
/*     */   private final int overflowIncrementInBytes;
/*     */   private OutputStream os;
/*     */   private byte[] overflow;
/*     */   private int overflowSize;
/*     */   private int maxOverflowSize;
/*     */   private int overflowGrowCount;
/*     */   private boolean unlimited;
/*     */   private int limit;
/*     */   private int writtenCount;
/*     */   
/*     */   ThrottledTemplateWriterOutputStreamAdapter(String templateName, TemplateFlowController flowController, int overflowIncrementInBytes)
/*     */   {
/*  66 */     this.templateName = templateName;
/*  67 */     this.flowController = flowController;
/*  68 */     this.overflowIncrementInBytes = overflowIncrementInBytes;
/*  69 */     this.overflow = null;
/*  70 */     this.overflowSize = 0;
/*  71 */     this.maxOverflowSize = 0;
/*  72 */     this.overflowGrowCount = 0;
/*  73 */     this.unlimited = false;
/*  74 */     this.limit = 0;
/*  75 */     this.writtenCount = 0;
/*  76 */     this.flowController.stopProcessing = true;
/*     */   }
/*     */   
/*     */   void setOutputStream(OutputStream os) {
/*  80 */     this.os = os;
/*  81 */     this.writtenCount = 0;
/*     */   }
/*     */   
/*     */   public boolean isOverflown()
/*     */   {
/*  86 */     return this.overflowSize > 0;
/*     */   }
/*     */   
/*     */   public boolean isStopped() {
/*  90 */     return this.limit == 0;
/*     */   }
/*     */   
/*     */   public int getWrittenCount()
/*     */   {
/*  95 */     return this.writtenCount;
/*     */   }
/*     */   
/*     */   public int getMaxOverflowSize()
/*     */   {
/* 100 */     return this.maxOverflowSize;
/*     */   }
/*     */   
/*     */   public int getOverflowGrowCount()
/*     */   {
/* 105 */     return this.overflowGrowCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void allow(int limit)
/*     */   {
/* 113 */     if ((limit == Integer.MAX_VALUE) || (limit < 0)) {
/* 114 */       this.unlimited = true;
/* 115 */       this.limit = -1;
/*     */     } else {
/* 117 */       this.unlimited = false;
/* 118 */       this.limit = limit;
/*     */     }
/*     */     
/* 121 */     this.flowController.stopProcessing = (this.limit == 0);
/*     */     
/* 123 */     if ((this.overflowSize == 0) || (this.limit == 0)) {
/* 124 */       return;
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 129 */       if ((this.unlimited) || (this.limit > this.overflowSize)) {
/* 130 */         this.os.write(this.overflow, 0, this.overflowSize);
/* 131 */         if (!this.unlimited) {
/* 132 */           this.limit -= this.overflowSize;
/*     */         }
/* 134 */         this.writtenCount += this.overflowSize;
/* 135 */         this.overflowSize = 0;
/* 136 */         return;
/*     */       }
/*     */       
/* 139 */       this.os.write(this.overflow, 0, this.limit);
/* 140 */       if (this.limit < this.overflowSize) {
/* 141 */         System.arraycopy(this.overflow, this.limit, this.overflow, 0, this.overflowSize - this.limit);
/*     */       }
/* 143 */       this.overflowSize -= this.limit;
/* 144 */       this.writtenCount += this.limit;
/* 145 */       this.limit = 0;
/* 146 */       this.flowController.stopProcessing = true;
/*     */     }
/*     */     catch (IOException e) {
/* 149 */       throw new TemplateOutputException("Exception while trying to write overflowed buffer in throttled template", this.templateName, -1, -1, e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void write(int b)
/*     */     throws IOException
/*     */   {
/* 160 */     if (this.limit == 0) {
/* 161 */       overflow(b);
/* 162 */       return;
/*     */     }
/* 164 */     this.os.write(b);
/* 165 */     if (!this.unlimited) {
/* 166 */       this.limit -= 1;
/*     */     }
/* 168 */     this.writtenCount += 1;
/* 169 */     if (this.limit == 0) {
/* 170 */       this.flowController.stopProcessing = true;
/*     */     }
/*     */   }
/*     */   
/*     */   public void write(byte[] bytes, int off, int len)
/*     */     throws IOException
/*     */   {
/* 177 */     if (this.limit == 0) {
/* 178 */       overflow(bytes, off, len);
/* 179 */       return;
/*     */     }
/* 181 */     if ((this.unlimited) || (this.limit > len)) {
/* 182 */       this.os.write(bytes, off, len);
/* 183 */       if (!this.unlimited) {
/* 184 */         this.limit -= len;
/*     */       }
/* 186 */       this.writtenCount += len;
/* 187 */       return;
/*     */     }
/* 189 */     this.os.write(bytes, off, this.limit);
/* 190 */     if (this.limit < len) {
/* 191 */       overflow(bytes, off + this.limit, len - this.limit);
/*     */     }
/* 193 */     this.writtenCount += this.limit;
/* 194 */     this.limit = 0;
/* 195 */     this.flowController.stopProcessing = true;
/*     */   }
/*     */   
/*     */   public void write(byte[] bytes)
/*     */     throws IOException
/*     */   {
/* 201 */     int len = bytes.length;
/* 202 */     if (this.limit == 0) {
/* 203 */       overflow(bytes, 0, len);
/* 204 */       return;
/*     */     }
/* 206 */     if ((this.unlimited) || (this.limit > len)) {
/* 207 */       this.os.write(bytes, 0, len);
/* 208 */       if (!this.unlimited) {
/* 209 */         this.limit -= len;
/*     */       }
/* 211 */       this.writtenCount += len;
/* 212 */       return;
/*     */     }
/* 214 */     this.os.write(bytes, 0, this.limit);
/* 215 */     if (this.limit < len) {
/* 216 */       overflow(bytes, this.limit, len - this.limit);
/*     */     }
/* 218 */     this.writtenCount += this.limit;
/* 219 */     this.limit = 0;
/* 220 */     this.flowController.stopProcessing = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void overflow(int c)
/*     */   {
/* 227 */     ensureOverflowCapacity(1);
/* 228 */     this.overflow[this.overflowSize] = ((byte)c);
/* 229 */     this.overflowSize += 1;
/* 230 */     if (this.overflowSize > this.maxOverflowSize) {
/* 231 */       this.maxOverflowSize = this.overflowSize;
/*     */     }
/*     */   }
/*     */   
/*     */   private void overflow(byte[] bytes, int off, int len)
/*     */   {
/* 237 */     ensureOverflowCapacity(len);
/* 238 */     System.arraycopy(bytes, off, this.overflow, this.overflowSize, len);
/* 239 */     this.overflowSize += len;
/* 240 */     if (this.overflowSize > this.maxOverflowSize) {
/* 241 */       this.maxOverflowSize = this.overflowSize;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void ensureOverflowCapacity(int len)
/*     */   {
/* 249 */     if (this.overflow == null) {
/* 250 */       int bufferInitialSize = this.overflowIncrementInBytes * 3;
/* 251 */       while (bufferInitialSize < len) {
/* 252 */         bufferInitialSize += this.overflowIncrementInBytes;
/*     */       }
/* 254 */       this.overflow = new byte[bufferInitialSize];
/* 255 */       return;
/*     */     }
/* 257 */     int targetLen = this.overflowSize + len;
/* 258 */     if (this.overflow.length < targetLen) {
/* 259 */       int newLen = this.overflow.length;
/*     */       do {
/* 261 */         newLen += this.overflowIncrementInBytes;
/* 262 */       } while (newLen < targetLen);
/* 263 */       this.overflow = Arrays.copyOf(this.overflow, newLen);
/* 264 */       this.overflowGrowCount += 1;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void flush()
/*     */     throws IOException
/*     */   {
/* 275 */     this.os.flush();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/* 283 */     this.os.close();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\ThrottledTemplateWriterOutputStreamAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */