package org.thymeleaf.engine;

import org.thymeleaf.model.ICDATASection;
import org.thymeleaf.model.ICloseElementTag;
import org.thymeleaf.model.IComment;
import org.thymeleaf.model.IDocType;
import org.thymeleaf.model.IOpenElementTag;
import org.thymeleaf.model.IProcessingInstruction;
import org.thymeleaf.model.IStandaloneElementTag;
import org.thymeleaf.model.IText;
import org.thymeleaf.model.IXMLDeclaration;

abstract interface IGatheringModelProcessable
  extends IEngineProcessable
{
  public abstract boolean isGatheringFinished();
  
  public abstract Model getInnerModel();
  
  public abstract void resetGatheredSkipFlags();
  
  public abstract ProcessorExecutionVars initializeProcessorExecutionVars();
  
  public abstract void gatherText(IText paramIText);
  
  public abstract void gatherComment(IComment paramIComment);
  
  public abstract void gatherCDATASection(ICDATASection paramICDATASection);
  
  public abstract void gatherStandaloneElement(IStandaloneElementTag paramIStandaloneElementTag);
  
  public abstract void gatherOpenElement(IOpenElementTag paramIOpenElementTag);
  
  public abstract void gatherCloseElement(ICloseElementTag paramICloseElementTag);
  
  public abstract void gatherUnmatchedCloseElement(ICloseElementTag paramICloseElementTag);
  
  public abstract void gatherDocType(IDocType paramIDocType);
  
  public abstract void gatherXMLDeclaration(IXMLDeclaration paramIXMLDeclaration);
  
  public abstract void gatherProcessingInstruction(IProcessingInstruction paramIProcessingInstruction);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\IGatheringModelProcessable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */