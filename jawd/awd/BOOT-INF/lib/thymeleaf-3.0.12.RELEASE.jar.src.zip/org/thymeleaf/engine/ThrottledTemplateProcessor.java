/*     */ package org.thymeleaf.engine;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.Writer;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.RoundingMode;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.thymeleaf.IThrottledTemplateProcessor;
/*     */ import org.thymeleaf.TemplateEngine;
/*     */ import org.thymeleaf.TemplateSpec;
/*     */ import org.thymeleaf.context.IEngineContext;
/*     */ import org.thymeleaf.exceptions.TemplateEngineException;
/*     */ import org.thymeleaf.exceptions.TemplateOutputException;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.util.LoggingUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ThrottledTemplateProcessor
/*     */   implements IThrottledTemplateProcessor
/*     */ {
/*  57 */   private static final Logger logger = LoggerFactory.getLogger(TemplateEngine.class);
/*  58 */   private static final Logger timerLogger = LoggerFactory.getLogger(TemplateEngine.TIMER_LOGGER_NAME);
/*     */   
/*     */ 
/*     */   private static final int NANOS_IN_SECOND = 1000000;
/*     */   
/*     */   private static final String OUTPUT_TYPE_CHARS = "chars";
/*     */   
/*     */   private static final String OUTPUT_TYPE_BYTES = "bytes";
/*     */   
/*  67 */   private static final AtomicLong identifierGenerator = new AtomicLong(0L);
/*     */   
/*     */ 
/*     */   private final String identifier;
/*     */   
/*     */ 
/*     */   private final TemplateSpec templateSpec;
/*     */   
/*     */   private final IEngineContext context;
/*     */   
/*     */   private final TemplateModel templateModel;
/*     */   
/*     */   private final ITemplateHandler templateHandler;
/*     */   
/*     */   private final ProcessorTemplateHandler processorTemplateHandler;
/*     */   
/*     */   private final TemplateFlowController flowController;
/*     */   
/*     */   private final ThrottledTemplateWriter writer;
/*     */   
/*     */   private int offset;
/*     */   
/*     */   private boolean eventProcessingFinished;
/*     */   
/*     */   private volatile boolean allProcessingFinished;
/*     */   
/*     */ 
/*     */   ThrottledTemplateProcessor(TemplateSpec templateSpec, IEngineContext context, TemplateModel templateModel, ITemplateHandler templateHandler, ProcessorTemplateHandler processorTemplateHandler, TemplateFlowController flowController, ThrottledTemplateWriter writer)
/*     */   {
/*  96 */     this.identifier = Long.toString(identifierGenerator.getAndIncrement());
/*  97 */     this.templateSpec = templateSpec;
/*  98 */     this.context = context;
/*  99 */     this.templateModel = templateModel;
/* 100 */     this.templateHandler = templateHandler;
/* 101 */     this.processorTemplateHandler = processorTemplateHandler;
/* 102 */     this.flowController = flowController;
/* 103 */     this.writer = writer;
/* 104 */     this.offset = 0;
/* 105 */     this.eventProcessingFinished = false;
/* 106 */     this.allProcessingFinished = false;
/*     */   }
/*     */   
/*     */ 
/*     */   public IThrottledTemplateWriterControl getThrottledTemplateWriterControl()
/*     */   {
/* 112 */     return this.writer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isFinished()
/*     */   {
/* 119 */     return this.allProcessingFinished;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean computeFinish()
/*     */     throws IOException
/*     */   {
/* 127 */     if (this.allProcessingFinished) {
/* 128 */       return true;
/*     */     }
/*     */     
/*     */ 
/* 132 */     boolean finished = (this.eventProcessingFinished) && (!this.flowController.processorTemplateHandlerPending) && (!this.writer.isOverflown());
/* 133 */     if (finished)
/*     */     {
/* 135 */       this.allProcessingFinished = finished;
/*     */     }
/*     */     
/* 138 */     return finished;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void reportFinish(String outputType)
/*     */   {
/* 145 */     if ((this.allProcessingFinished) && 
/* 146 */       (logger.isTraceEnabled())) {
/* 147 */       logger.trace("[THYMELEAF][{}] Finished throttled processing of template \"{}\" with locale {}. Maximum overflow was {} {} (overflow buffer grown {} times).", new Object[] {
/*     */       
/* 149 */         TemplateEngine.threadIndex(), this.templateSpec, this.context.getLocale(), Integer.valueOf(this.writer.getMaxOverflowSize()), outputType, Integer.valueOf(this.writer.getOverflowGrowCount()) });
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getProcessorIdentifier()
/*     */   {
/* 160 */     return this.identifier;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public TemplateSpec getTemplateSpec()
/*     */   {
/* 168 */     return this.templateSpec;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int processAll(Writer writer)
/*     */   {
/* 176 */     this.writer.setOutput(writer);
/* 177 */     return process(Integer.MAX_VALUE, "chars");
/*     */   }
/*     */   
/*     */ 
/*     */   public int processAll(OutputStream outputStream, Charset charset)
/*     */   {
/* 183 */     this.writer.setOutput(outputStream, charset, Integer.MAX_VALUE);
/* 184 */     return process(Integer.MAX_VALUE, "bytes");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int process(int maxOutputInChars, Writer writer)
/*     */   {
/* 192 */     this.writer.setOutput(writer);
/* 193 */     return process(maxOutputInChars, "chars");
/*     */   }
/*     */   
/*     */ 
/*     */   public int process(int maxOutputInBytes, OutputStream outputStream, Charset charset)
/*     */   {
/* 199 */     this.writer.setOutput(outputStream, charset, maxOutputInBytes);
/* 200 */     return process(maxOutputInBytes, "bytes");
/*     */   }
/*     */   
/*     */ 
/*     */   private int process(int maxOutput, String outputType)
/*     */   {
/* 206 */     int writtenCount = 0;
/*     */     try
/*     */     {
/* 209 */       if ((this.allProcessingFinished) || (maxOutput == 0)) {
/* 210 */         return 0;
/*     */       }
/*     */       
/* 213 */       if (logger.isTraceEnabled()) {
/* 214 */         logger.trace("[THYMELEAF][{}] Starting throttled process (limit:{} {}) of template \"{}\" with locale {}", new Object[] {
/* 215 */           TemplateEngine.threadIndex(), Integer.valueOf(maxOutput), outputType, this.templateSpec, this.context.getLocale() });
/*     */       }
/*     */       
/* 218 */       long startNanos = System.nanoTime();
/*     */       
/*     */ 
/* 221 */       int initialWrittenCount = this.writer.getWrittenCount();
/*     */       
/*     */ 
/* 224 */       this.writer.allow(maxOutput);
/*     */       
/*     */ 
/* 227 */       if ((!computeFinish()) && (!this.writer.isStopped()))
/*     */       {
/* 229 */         if (this.flowController.processorTemplateHandlerPending) {
/* 230 */           this.processorTemplateHandler.handlePending();
/*     */         }
/*     */         
/* 233 */         if ((!computeFinish()) && (!this.writer.isStopped()))
/*     */         {
/* 235 */           this.offset += this.templateModel.process(this.templateHandler, this.offset, this.flowController);
/* 236 */           if (this.offset == this.templateModel.size()) {
/* 237 */             EngineContextManager.disposeEngineContext(this.context);
/* 238 */             this.eventProcessingFinished = true;
/* 239 */             computeFinish();
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 246 */       long endNanos = System.nanoTime();
/*     */       
/*     */ 
/*     */ 
/*     */       try
/*     */       {
/* 252 */         this.writer.flush();
/*     */       } catch (IOException e) {
/* 254 */         throw new TemplateOutputException("An error happened while flushing output writer", this.templateSpec.getTemplate(), -1, -1, e);
/*     */       }
/*     */       
/* 257 */       writtenCount = this.writer.getWrittenCount() - initialWrittenCount;
/*     */       
/* 259 */       if (logger.isTraceEnabled()) {
/* 260 */         logger.trace("[THYMELEAF][{}] Finished throttled process (limit:{} {}, output: {} {}) of template \"{}\" with locale {}", new Object[] {
/* 261 */           TemplateEngine.threadIndex(), Integer.valueOf(maxOutput), outputType, Integer.valueOf(writtenCount), outputType, this.templateSpec, this.context.getLocale() });
/*     */       }
/*     */       
/* 264 */       if (timerLogger.isTraceEnabled()) {
/* 265 */         BigDecimal elapsed = BigDecimal.valueOf(endNanos - startNanos);
/* 266 */         BigDecimal elapsedMs = elapsed.divide(BigDecimal.valueOf(1000000L), RoundingMode.HALF_UP);
/* 267 */         timerLogger.trace("[THYMELEAF][{}][{}][{}][{}][{}] TEMPLATE \"{}\" WITH LOCALE {} PROCESSED (THROTTLED, LIMIT:{} {}, OUTPUT: {} {}) IN {} nanoseconds (approx. {}ms)", new Object[] {
/*     */         
/*     */ 
/* 270 */           TemplateEngine.threadIndex(), 
/* 271 */           LoggingUtils.loggifyTemplateName(this.templateSpec.getTemplate()), this.context.getLocale(), elapsed, elapsedMs, this.templateSpec, this.context
/* 272 */           .getLocale(), Integer.valueOf(maxOutput), outputType, Integer.valueOf(writtenCount), outputType, elapsed, elapsedMs });
/*     */       }
/*     */     }
/*     */     catch (TemplateOutputException e)
/*     */     {
/* 277 */       this.eventProcessingFinished = true;
/* 278 */       this.allProcessingFinished = true;
/*     */       
/* 280 */       logger.error(String.format("[THYMELEAF][%s] Exception processing throttled template \"%s\": %s", new Object[] { TemplateEngine.threadIndex(), this.templateSpec, e.getMessage() }), e);
/* 281 */       throw e;
/*     */     }
/*     */     catch (TemplateEngineException e)
/*     */     {
/* 285 */       this.eventProcessingFinished = true;
/* 286 */       this.allProcessingFinished = true;
/*     */       
/* 288 */       logger.error(String.format("[THYMELEAF][%s] Exception processing throttled template \"%s\": %s", new Object[] { TemplateEngine.threadIndex(), this.templateSpec, e.getMessage() }), e);
/* 289 */       throw e;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 293 */       this.eventProcessingFinished = true;
/* 294 */       this.allProcessingFinished = true;
/*     */       
/* 296 */       logger.error(String.format("[THYMELEAF][%s] Exception processing throttled template \"%s\": %s", new Object[] { TemplateEngine.threadIndex(), this.templateSpec, e.getMessage() }), e);
/* 297 */       throw new TemplateProcessingException("Exception processing throttled template", this.templateSpec.toString(), e);
/*     */     }
/*     */     
/*     */ 
/* 301 */     reportFinish(outputType);
/*     */     
/* 303 */     return writtenCount;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\ThrottledTemplateProcessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */