/*     */ package org.thymeleaf.engine;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import java.util.Arrays;
/*     */ import org.thymeleaf.IEngineConfiguration;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.model.ICDATASection;
/*     */ import org.thymeleaf.model.ICloseElementTag;
/*     */ import org.thymeleaf.model.IComment;
/*     */ import org.thymeleaf.model.IDocType;
/*     */ import org.thymeleaf.model.IModel;
/*     */ import org.thymeleaf.model.IModelVisitor;
/*     */ import org.thymeleaf.model.IOpenElementTag;
/*     */ import org.thymeleaf.model.IProcessingInstruction;
/*     */ import org.thymeleaf.model.IStandaloneElementTag;
/*     */ import org.thymeleaf.model.ITemplateEnd;
/*     */ import org.thymeleaf.model.ITemplateEvent;
/*     */ import org.thymeleaf.model.ITemplateStart;
/*     */ import org.thymeleaf.model.IText;
/*     */ import org.thymeleaf.model.IXMLDeclaration;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ import org.thymeleaf.util.FastStringWriter;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class Model
/*     */   implements IModel
/*     */ {
/*     */   private static final int INITIAL_EVENT_QUEUE_SIZE = 50;
/*     */   private IEngineConfiguration configuration;
/*     */   private TemplateMode templateMode;
/*     */   IEngineTemplateEvent[] queue;
/*     */   int queueSize;
/*     */   
/*     */   Model(IEngineConfiguration configuration, TemplateMode templateMode)
/*     */   {
/*  70 */     Validate.notNull(configuration, "Engine Configuration cannot be null");
/*  71 */     Validate.notNull(templateMode, "Template Mode cannot be null");
/*     */     
/*  73 */     this.templateMode = templateMode;
/*  74 */     this.configuration = configuration;
/*     */     
/*  76 */     this.queue = new IEngineTemplateEvent[50];
/*  77 */     Arrays.fill(this.queue, null);
/*     */     
/*  79 */     this.queueSize = 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Model(IModel model)
/*     */   {
/*  88 */     Validate.notNull(model, "Model cannot be null");
/*     */     
/*  90 */     this.configuration = model.getConfiguration();
/*  91 */     this.templateMode = model.getTemplateMode();
/*     */     
/*  93 */     if ((model instanceof Model))
/*     */     {
/*  95 */       Model mmodel = (Model)model;
/*  96 */       this.queue = ((IEngineTemplateEvent[])mmodel.queue.clone());
/*  97 */       this.queueSize = mmodel.queueSize;
/*     */     }
/*  99 */     else if ((model instanceof TemplateModel))
/*     */     {
/* 101 */       TemplateModel templateModel = (TemplateModel)model;
/* 102 */       this.queue = new IEngineTemplateEvent[templateModel.queue.length + 25];
/* 103 */       System.arraycopy(templateModel.queue, 1, this.queue, 0, templateModel.queue.length - 2);
/* 104 */       this.queueSize = (templateModel.queue.length - 2);
/*     */     }
/*     */     else
/*     */     {
/* 108 */       this.queue = new IEngineTemplateEvent[50];
/* 109 */       Arrays.fill(this.queue, null);
/* 110 */       this.queueSize = 0;
/* 111 */       insertModel(0, model);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final IEngineConfiguration getConfiguration()
/*     */   {
/* 121 */     return this.configuration;
/*     */   }
/*     */   
/*     */   public final TemplateMode getTemplateMode()
/*     */   {
/* 126 */     return this.templateMode;
/*     */   }
/*     */   
/*     */   public int size()
/*     */   {
/* 131 */     return this.queueSize;
/*     */   }
/*     */   
/*     */   public ITemplateEvent get(int pos)
/*     */   {
/* 136 */     return this.queue[pos];
/*     */   }
/*     */   
/*     */   public void add(ITemplateEvent event)
/*     */   {
/* 141 */     insert(this.queueSize, event);
/*     */   }
/*     */   
/*     */ 
/*     */   public void insert(int pos, ITemplateEvent event)
/*     */   {
/* 147 */     if (event == null) {
/* 148 */       return;
/*     */     }
/*     */     
/* 151 */     IEngineTemplateEvent engineEvent = asEngineEvent(event);
/*     */     
/*     */ 
/* 154 */     if ((engineEvent == TemplateStart.TEMPLATE_START_INSTANCE) || (engineEvent == TemplateEnd.TEMPLATE_END_INSTANCE)) {
/* 155 */       throw new TemplateProcessingException("Cannot insert event of type TemplateStart/TemplateEnd. These events can only be added to models internally during template parsing.");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 161 */     if (this.queue.length == this.queueSize) {
/* 162 */       this.queue = ((IEngineTemplateEvent[])Arrays.copyOf(this.queue, this.queue.length + 25));
/*     */     }
/*     */     
/*     */ 
/* 166 */     if (pos != this.queueSize) {
/* 167 */       System.arraycopy(this.queue, pos, this.queue, pos + 1, this.queueSize - pos);
/*     */     }
/*     */     
/*     */ 
/* 171 */     this.queue[pos] = engineEvent;
/*     */     
/* 173 */     this.queueSize += 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void replace(int pos, ITemplateEvent event)
/*     */   {
/* 180 */     if (event == null) {
/* 181 */       return;
/*     */     }
/*     */     
/* 184 */     IEngineTemplateEvent engineEvent = asEngineEvent(event);
/*     */     
/*     */ 
/* 187 */     if ((engineEvent == TemplateStart.TEMPLATE_START_INSTANCE) || (engineEvent == TemplateEnd.TEMPLATE_END_INSTANCE)) {
/* 188 */       throw new TemplateProcessingException("Cannot insert event of type TemplateStart/TemplateEnd. These events can only be added to models internally during template parsing.");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 194 */     this.queue[pos] = engineEvent;
/*     */   }
/*     */   
/*     */ 
/*     */   public void addModel(IModel model)
/*     */   {
/* 200 */     insertModel(this.queueSize, model);
/*     */   }
/*     */   
/*     */ 
/*     */   public void insertModel(int pos, IModel model)
/*     */   {
/* 206 */     if ((model == null) || (model.size() == 0)) {
/* 207 */       return;
/*     */     }
/*     */     
/* 210 */     if (this.configuration != model.getConfiguration())
/*     */     {
/* 212 */       throw new TemplateProcessingException("Cannot add model of class " + model.getClass().getName() + " to the current template, as it was created using a different Template Engine Configuration.");
/*     */     }
/*     */     
/*     */ 
/* 216 */     if (this.templateMode != model.getTemplateMode())
/*     */     {
/*     */ 
/* 219 */       throw new TemplateProcessingException("Cannot add model of class " + model.getClass().getName() + " to the current template, as it was created using a different Template Mode: " + model.getTemplateMode() + " instead of the current " + this.templateMode);
/*     */     }
/*     */     
/*     */ 
/* 223 */     if (this.queue.length <= this.queueSize + model.size())
/*     */     {
/* 225 */       this.queue = ((IEngineTemplateEvent[])Arrays.copyOf(this.queue, Math.max(this.queueSize + model.size(), this.queue.length + 25)));
/*     */     }
/*     */     
/* 228 */     if ((model instanceof TemplateModel)) {
/* 229 */       doInsertTemplateModel(pos, (TemplateModel)model);
/* 230 */     } else if ((model instanceof Model)) {
/* 231 */       doInsertModel(pos, (Model)model);
/*     */     } else {
/* 233 */       doInsertOtherModel(pos, model);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void doInsertModel(int pos, Model model)
/*     */   {
/* 241 */     System.arraycopy(this.queue, pos, this.queue, pos + model.queueSize, this.queueSize - pos);
/*     */     
/* 243 */     System.arraycopy(model.queue, 0, this.queue, pos, model.queueSize);
/* 244 */     this.queueSize += model.queueSize;
/*     */   }
/*     */   
/*     */ 
/*     */   private void doInsertTemplateModel(int pos, TemplateModel model)
/*     */   {
/* 250 */     int insertionSize = model.queue.length - 2;
/*     */     
/* 252 */     System.arraycopy(this.queue, pos, this.queue, pos + insertionSize, this.queueSize - pos);
/*     */     
/* 254 */     System.arraycopy(model.queue, 1, this.queue, pos, insertionSize);
/* 255 */     this.queueSize += insertionSize;
/*     */   }
/*     */   
/*     */ 
/*     */   private void doInsertOtherModel(int pos, IModel model)
/*     */   {
/* 261 */     int modelSize = model.size();
/* 262 */     for (int i = 0; i < modelSize; i++) {
/* 263 */       insert(pos + i, model.get(i));
/*     */     }
/*     */   }
/*     */   
/*     */   public void remove(int pos)
/*     */   {
/* 269 */     System.arraycopy(this.queue, pos + 1, this.queue, pos, this.queueSize - (pos + 1));
/* 270 */     this.queueSize -= 1;
/*     */   }
/*     */   
/*     */   public void reset()
/*     */   {
/* 275 */     this.queueSize = 0;
/*     */   }
/*     */   
/*     */ 
/*     */   void process(ITemplateHandler handler)
/*     */   {
/* 281 */     for (int i = 0; i < this.queueSize; i++) {
/* 282 */       this.queue[i].beHandled(handler);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   int process(ITemplateHandler handler, int offset, TemplateFlowController controller)
/*     */   {
/* 289 */     if (controller == null) {
/* 290 */       process(handler);
/* 291 */       return this.queueSize;
/*     */     }
/*     */     
/* 294 */     if ((this.queueSize == 0) || (offset >= this.queueSize)) {
/* 295 */       return 0;
/*     */     }
/*     */     
/* 298 */     int i = offset;
/* 299 */     while ((i < this.queueSize) && (!controller.stopProcessing)) {
/* 300 */       this.queue[(i++)].beHandled(handler);
/*     */     }
/*     */     
/* 303 */     return i - offset;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public IModel cloneModel()
/*     */   {
/* 312 */     return new Model(this);
/*     */   }
/*     */   
/*     */ 
/*     */   void resetAsCloneOf(Model model)
/*     */   {
/* 318 */     this.configuration = model.configuration;
/* 319 */     this.templateMode = model.templateMode;
/* 320 */     if (this.queue.length < model.queueSize) {
/* 321 */       this.queue = new IEngineTemplateEvent[model.queueSize];
/*     */     }
/* 323 */     System.arraycopy(model.queue, 0, this.queue, 0, model.queueSize);
/* 324 */     this.queueSize = model.queueSize;
/*     */   }
/*     */   
/*     */ 
/*     */   public final void write(Writer writer)
/*     */     throws IOException
/*     */   {
/* 331 */     for (int i = 0; i < this.queueSize; i++) {
/* 332 */       this.queue[i].write(writer);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void accept(IModelVisitor visitor)
/*     */   {
/* 340 */     for (int i = 0; i < this.queueSize; i++)
/*     */     {
/* 342 */       this.queue[i].accept(visitor);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean sameAs(Model model)
/*     */   {
/* 353 */     if ((model == null) || (model.queueSize != this.queueSize)) {
/* 354 */       return false;
/*     */     }
/* 356 */     for (int i = 0; i < this.queueSize; i++) {
/* 357 */       if (this.queue[i] != model.queue[i]) {
/* 358 */         return false;
/*     */       }
/*     */     }
/* 361 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final String toString()
/*     */   {
/*     */     try
/*     */     {
/* 370 */       Writer writer = new FastStringWriter();
/* 371 */       write(writer);
/* 372 */       return writer.toString();
/*     */     } catch (IOException e) {
/* 374 */       throw new TemplateProcessingException("Error while creating String representation of model");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static IEngineTemplateEvent asEngineEvent(ITemplateEvent event)
/*     */   {
/* 384 */     if ((event instanceof IEngineTemplateEvent)) {
/* 385 */       return (IEngineTemplateEvent)event;
/*     */     }
/*     */     
/* 388 */     if ((event instanceof IText)) {
/* 389 */       return Text.asEngineText((IText)event);
/*     */     }
/* 391 */     if ((event instanceof IOpenElementTag)) {
/* 392 */       return OpenElementTag.asEngineOpenElementTag((IOpenElementTag)event);
/*     */     }
/* 394 */     if ((event instanceof ICloseElementTag)) {
/* 395 */       return CloseElementTag.asEngineCloseElementTag((ICloseElementTag)event);
/*     */     }
/* 397 */     if ((event instanceof IStandaloneElementTag)) {
/* 398 */       return StandaloneElementTag.asEngineStandaloneElementTag((IStandaloneElementTag)event);
/*     */     }
/* 400 */     if ((event instanceof IDocType)) {
/* 401 */       return DocType.asEngineDocType((IDocType)event);
/*     */     }
/* 403 */     if ((event instanceof IComment)) {
/* 404 */       return Comment.asEngineComment((IComment)event);
/*     */     }
/* 406 */     if ((event instanceof ICDATASection)) {
/* 407 */       return CDATASection.asEngineCDATASection((ICDATASection)event);
/*     */     }
/* 409 */     if ((event instanceof IXMLDeclaration)) {
/* 410 */       return XMLDeclaration.asEngineXMLDeclaration((IXMLDeclaration)event);
/*     */     }
/* 412 */     if ((event instanceof IProcessingInstruction)) {
/* 413 */       return ProcessingInstruction.asEngineProcessingInstruction((IProcessingInstruction)event);
/*     */     }
/* 415 */     if ((event instanceof ITemplateStart)) {
/* 416 */       return TemplateStart.asEngineTemplateStart((ITemplateStart)event);
/*     */     }
/* 418 */     if ((event instanceof ITemplateEnd)) {
/* 419 */       return TemplateEnd.asEngineTemplateEnd((ITemplateEnd)event);
/*     */     }
/*     */     
/* 422 */     throw new TemplateProcessingException("Cannot handle in event of type: " + event.getClass().getName());
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\Model.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */