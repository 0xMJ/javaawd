/*    */ package org.thymeleaf.engine;
/*    */ 
/*    */ import java.util.Set;
/*    */ import org.thymeleaf.processor.element.IElementProcessor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class HTMLElementDefinition
/*    */   extends ElementDefinition
/*    */ {
/*    */   final HTMLElementType type;
/*    */   
/*    */   HTMLElementDefinition(HTMLElementName name, HTMLElementType type, Set<IElementProcessor> associatedProcessors)
/*    */   {
/* 39 */     super(name, associatedProcessors);
/* 40 */     this.type = type;
/*    */   }
/*    */   
/*    */   public HTMLElementType getType()
/*    */   {
/* 45 */     return this.type;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\HTMLElementDefinition.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */