/*     */ package org.thymeleaf.engine;
/*     */ 
/*     */ import org.thymeleaf.context.ITemplateContext;
/*     */ import org.thymeleaf.model.ICDATASection;
/*     */ import org.thymeleaf.model.IComment;
/*     */ import org.thymeleaf.model.IProcessableElementTag;
/*     */ import org.thymeleaf.model.IText;
/*     */ import org.thymeleaf.standard.expression.FragmentExpression;
/*     */ import org.thymeleaf.standard.expression.IStandardExpression;
/*     */ import org.thymeleaf.standard.expression.IStandardExpressionParser;
/*     */ import org.thymeleaf.standard.expression.StandardExpressions;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class EngineEventUtils
/*     */ {
/*     */   public static boolean isWhitespace(IText text)
/*     */   {
/*  51 */     if (text == null) {
/*  52 */       return false;
/*     */     }
/*     */     
/*  55 */     if ((text instanceof Text)) {
/*  56 */       return ((Text)text).isWhitespace();
/*     */     }
/*     */     
/*  59 */     return computeWhitespace(text);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static boolean isWhitespace(ICDATASection cdataSection)
/*     */   {
/*  66 */     if (cdataSection == null) {
/*  67 */       return false;
/*     */     }
/*     */     
/*  70 */     if ((cdataSection instanceof CDATASection)) {
/*  71 */       return ((CDATASection)cdataSection).isWhitespace();
/*     */     }
/*     */     
/*  74 */     return computeWhitespace(cdataSection.getContent());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static boolean isWhitespace(IComment comment)
/*     */   {
/*  81 */     if (comment == null) {
/*  82 */       return false;
/*     */     }
/*     */     
/*  85 */     if ((comment instanceof Comment)) {
/*  86 */       return ((Comment)comment).isWhitespace();
/*     */     }
/*     */     
/*  89 */     return computeWhitespace(comment.getContent());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isInlineable(IText text)
/*     */   {
/*  97 */     if (text == null) {
/*  98 */       return false;
/*     */     }
/*     */     
/* 101 */     if ((text instanceof Text)) {
/* 102 */       return ((Text)text).isInlineable();
/*     */     }
/*     */     
/* 105 */     return computeInlineable(text);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static boolean isInlineable(ICDATASection cdataSection)
/*     */   {
/* 112 */     if (cdataSection == null) {
/* 113 */       return false;
/*     */     }
/*     */     
/* 116 */     if ((cdataSection instanceof CDATASection)) {
/* 117 */       return ((CDATASection)cdataSection).isInlineable();
/*     */     }
/*     */     
/* 120 */     return computeInlineable(cdataSection.getContent());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static boolean isInlineable(IComment comment)
/*     */   {
/* 127 */     if (comment == null) {
/* 128 */       return false;
/*     */     }
/*     */     
/* 131 */     if ((comment instanceof Comment)) {
/* 132 */       return ((Comment)comment).isInlineable();
/*     */     }
/*     */     
/* 135 */     return computeInlineable(comment.getContent());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean computeWhitespace(CharSequence text)
/*     */   {
/* 146 */     int n = text.length();
/* 147 */     if (n == 0) {
/* 148 */       return false;
/*     */     }
/*     */     
/* 151 */     while (n-- != 0) {
/* 152 */       char c = text.charAt(n);
/* 153 */       if (!Character.isWhitespace(c)) {
/* 154 */         return false;
/*     */       }
/*     */     }
/* 157 */     return true;
/*     */   }
/*     */   
/*     */   private static boolean computeInlineable(CharSequence text)
/*     */   {
/* 162 */     int n = text.length();
/* 163 */     if (n == 0) {
/* 164 */       return false;
/*     */     }
/*     */     
/* 167 */     char c0 = '\000';
/* 168 */     int inline = 0;
/* 169 */     while (n-- != 0) {
/* 170 */       char c1 = text.charAt(n);
/* 171 */       if ((c1 == ']') && (c0 == ']')) {
/* 172 */         inline = 1;
/* 173 */       } else if ((c1 == ')') && (c0 == ']')) {
/* 174 */         inline = 2;
/* 175 */       } else { if ((inline == 1) && (c1 == '[') && (c0 == '['))
/* 176 */           return true;
/* 177 */         if ((inline == 2) && (c1 == '[') && (c0 == '('))
/* 178 */           return true;
/*     */       }
/* 180 */       c0 = c1;
/*     */     }
/* 182 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static IStandardExpression computeAttributeExpression(ITemplateContext context, IProcessableElementTag tag, AttributeName attributeName, String attributeValue)
/*     */   {
/* 195 */     if (!(tag instanceof AbstractProcessableElementTag)) {
/* 196 */       return parseAttributeExpression(context, attributeValue);
/*     */     }
/*     */     
/* 199 */     AbstractProcessableElementTag processableElementTag = (AbstractProcessableElementTag)tag;
/* 200 */     Attribute attribute = (Attribute)processableElementTag.getAttribute(attributeName);
/*     */     
/* 202 */     IStandardExpression expression = attribute.getCachedStandardExpression();
/* 203 */     if (expression != null) {
/* 204 */       return expression;
/*     */     }
/*     */     
/* 207 */     expression = parseAttributeExpression(context, attributeValue);
/*     */     
/* 209 */     if ((expression != null) && (!(expression instanceof FragmentExpression)) && (attributeValue.indexOf('_') < 0)) {
/* 210 */       attribute.setCachedStandardExpression(expression);
/*     */     }
/*     */     
/* 213 */     return expression;
/*     */   }
/*     */   
/*     */ 
/*     */   private static IStandardExpression parseAttributeExpression(ITemplateContext context, String attributeValue)
/*     */   {
/* 219 */     IStandardExpressionParser expressionParser = StandardExpressions.getExpressionParser(context.getConfiguration());
/* 220 */     return expressionParser.parseExpression(context, attributeValue);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\EngineEventUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */