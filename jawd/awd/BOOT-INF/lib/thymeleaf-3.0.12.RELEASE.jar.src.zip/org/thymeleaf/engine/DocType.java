/*     */ package org.thymeleaf.engine;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import org.thymeleaf.model.IDocType;
/*     */ import org.thymeleaf.model.IModelVisitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class DocType
/*     */   extends AbstractTemplateEvent
/*     */   implements IDocType, IEngineTemplateEvent
/*     */ {
/*     */   public static final String DEFAULT_KEYWORD = "DOCTYPE";
/*     */   public static final String DEFAULT_ELEMENT_NAME = "html";
/*     */   public static final String DEFAULT_TYPE_PUBLIC = "PUBLIC";
/*     */   public static final String DEFAULT_TYPE_SYSTEM = "SYSTEM";
/*     */   private final String keyword;
/*     */   private final String elementName;
/*     */   private final String type;
/*     */   private final String publicId;
/*     */   private final String systemId;
/*     */   private final String internalSubset;
/*     */   private final String docType;
/*     */   
/*     */   DocType()
/*     */   {
/*  53 */     this(null, null);
/*     */   }
/*     */   
/*     */   DocType(String publicId, String systemId)
/*     */   {
/*  58 */     this("DOCTYPE", "html", publicId, systemId, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   DocType(String keyword, String elementName, String publicId, String systemId, String internalSubset)
/*     */   {
/*  69 */     this.keyword = keyword;
/*  70 */     this.elementName = elementName;
/*  71 */     this.type = computeType(publicId, systemId);
/*  72 */     this.publicId = publicId;
/*  73 */     this.systemId = systemId;
/*  74 */     this.internalSubset = internalSubset;
/*  75 */     this.docType = computeDocType();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   DocType(String docType, String keyword, String elementName, String publicId, String systemId, String internalSubset, String templateName, int line, int col)
/*     */   {
/*  87 */     super(templateName, line, col);
/*  88 */     this.keyword = keyword;
/*  89 */     this.elementName = elementName;
/*  90 */     this.type = computeType(publicId, systemId);
/*  91 */     this.publicId = publicId;
/*  92 */     this.systemId = systemId;
/*  93 */     this.internalSubset = internalSubset;
/*  94 */     this.docType = (docType != null ? docType : computeDocType());
/*     */   }
/*     */   
/*     */ 
/*     */   public String getKeyword()
/*     */   {
/* 100 */     return this.keyword;
/*     */   }
/*     */   
/*     */   public String getElementName() {
/* 104 */     return this.elementName;
/*     */   }
/*     */   
/*     */   public String getType() {
/* 108 */     return this.type;
/*     */   }
/*     */   
/*     */   public String getPublicId() {
/* 112 */     return this.publicId;
/*     */   }
/*     */   
/*     */   public String getSystemId() {
/* 116 */     return this.systemId;
/*     */   }
/*     */   
/*     */   public String getInternalSubset() {
/* 120 */     return this.internalSubset;
/*     */   }
/*     */   
/*     */   public String getDocType() {
/* 124 */     return this.docType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String computeDocType()
/*     */   {
/* 132 */     StringBuilder strBuilder = new StringBuilder(120);
/*     */     
/* 134 */     strBuilder.append("<!");
/* 135 */     strBuilder.append(this.keyword);
/* 136 */     strBuilder.append(' ');
/* 137 */     strBuilder.append(this.elementName);
/* 138 */     if (this.type != null) {
/* 139 */       strBuilder.append(' ');
/* 140 */       strBuilder.append(this.type);
/* 141 */       if (this.publicId != null) {
/* 142 */         strBuilder.append(" \"");
/* 143 */         strBuilder.append(this.publicId);
/* 144 */         strBuilder.append('"');
/*     */       }
/* 146 */       strBuilder.append(" \"");
/* 147 */       strBuilder.append(this.systemId);
/* 148 */       strBuilder.append('"');
/*     */     }
/* 150 */     if (this.internalSubset != null) {
/* 151 */       strBuilder.append(" [");
/* 152 */       strBuilder.append(this.internalSubset);
/* 153 */       strBuilder.append(']');
/*     */     }
/* 155 */     strBuilder.append('>');
/*     */     
/* 157 */     return strBuilder.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static String computeType(String publicId, String systemId)
/*     */   {
/* 166 */     if ((publicId != null) && (systemId == null)) {
/* 167 */       throw new IllegalArgumentException("DOCTYPE clause cannot have a non-null PUBLIC ID and a null SYSTEM ID");
/*     */     }
/*     */     
/*     */ 
/* 171 */     if ((publicId == null) && (systemId == null)) {
/* 172 */       return null;
/*     */     }
/*     */     
/* 175 */     if (publicId != null) {
/* 176 */       return "PUBLIC";
/*     */     }
/*     */     
/* 179 */     return "SYSTEM";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void accept(IModelVisitor visitor)
/*     */   {
/* 187 */     visitor.visit(this);
/*     */   }
/*     */   
/*     */   public void write(Writer writer) throws IOException
/*     */   {
/* 192 */     writer.write(this.docType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static DocType asEngineDocType(IDocType docType)
/*     */   {
/* 201 */     if ((docType instanceof DocType)) {
/* 202 */       return (DocType)docType;
/*     */     }
/*     */     
/* 205 */     return new DocType(null, docType
/*     */     
/* 207 */       .getKeyword(), docType
/* 208 */       .getElementName(), docType
/* 209 */       .getPublicId(), docType
/* 210 */       .getSystemId(), docType
/* 211 */       .getInternalSubset(), docType
/* 212 */       .getTemplateName(), docType.getLine(), docType.getCol());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void beHandled(ITemplateHandler handler)
/*     */   {
/* 221 */     handler.handleDocType(this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 229 */     return getDocType();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\DocType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */