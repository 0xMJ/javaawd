/*    */ package org.thymeleaf.engine;
/*    */ 
/*    */ import org.thymeleaf.IEngineConfiguration;
/*    */ import org.thymeleaf.context.IEngineContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class GatheringModelProcessable
/*    */   extends AbstractGatheringModelProcessable
/*    */ {
/*    */   private final IEngineContext context;
/*    */   private int offset;
/*    */   
/*    */   GatheringModelProcessable(IEngineConfiguration configuration, ProcessorTemplateHandler processorTemplateHandler, IEngineContext context, TemplateModelController modelController, TemplateFlowController flowController, TemplateModelController.SkipBody gatheredSkipBody, boolean gatheredSkipCloseTag, ProcessorExecutionVars processorExecutionVars)
/*    */   {
/* 48 */     super(configuration, processorTemplateHandler, context, modelController, flowController, gatheredSkipBody, gatheredSkipCloseTag, processorExecutionVars);
/* 49 */     this.context = context;
/* 50 */     this.offset = 0;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean process()
/*    */   {
/* 61 */     TemplateFlowController flowController = getFlowController();
/* 62 */     if ((flowController != null) && (flowController.stopProcessing)) {
/* 63 */       return false;
/*    */     }
/*    */     
/* 66 */     if (this.offset == 0)
/*    */     {
/*    */ 
/*    */ 
/*    */ 
/* 71 */       prepareProcessing();
/*    */     }
/*    */     
/*    */ 
/*    */ 
/*    */ 
/* 77 */     Model model = getInnerModel();
/* 78 */     this.offset += model.process(getProcessorTemplateHandler(), this.offset, flowController);
/*    */     
/*    */ 
/*    */ 
/*    */ 
/* 83 */     boolean processed = (flowController == null) || ((this.offset == model.queueSize) && (!flowController.stopProcessing));
/*    */     
/*    */ 
/* 86 */     if (processed)
/*    */     {
/*    */ 
/*    */ 
/*    */ 
/* 91 */       this.context.decreaseLevel();
/*    */     }
/*    */     
/* 94 */     return processed;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\GatheringModelProcessable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */