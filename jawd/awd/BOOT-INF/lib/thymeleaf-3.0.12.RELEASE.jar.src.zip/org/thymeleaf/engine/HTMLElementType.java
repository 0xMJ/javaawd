/*    */ package org.thymeleaf.engine;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum HTMLElementType
/*    */ {
/* 32 */   VOID(true),  RAW_TEXT(false),  ESCAPABLE_RAW_TEXT(false),  FOREIGN(false),  NORMAL(false);
/*    */   
/*    */   final boolean isVoid;
/*    */   
/*    */   private HTMLElementType(boolean voidElement) {
/* 37 */     this.isVoid = voidElement;
/*    */   }
/*    */   
/*    */   public boolean isVoid() {
/* 41 */     return this.isVoid;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\HTMLElementType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */