/*    */ package org.thymeleaf.engine;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class ProcessorExecutionVars
/*    */ {
/*    */   final ElementProcessorIterator processorIterator;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 31 */   Model modelBefore = null;
/* 32 */   Model modelAfter = null;
/* 33 */   boolean modelAfterProcessable = false;
/* 34 */   boolean discardEvent = false;
/* 35 */   TemplateModelController.SkipBody skipBody = TemplateModelController.SkipBody.PROCESS;
/* 36 */   boolean skipCloseTag = false;
/*    */   
/*    */ 
/*    */   ProcessorExecutionVars()
/*    */   {
/* 41 */     this.processorIterator = new ElementProcessorIterator();
/*    */   }
/*    */   
/*    */   ProcessorExecutionVars cloneVars()
/*    */   {
/* 46 */     ProcessorExecutionVars clone = new ProcessorExecutionVars();
/* 47 */     clone.processorIterator.resetAsCloneOf(this.processorIterator);
/* 48 */     if (this.modelBefore != null) {
/* 49 */       clone.modelBefore = ((Model)this.modelBefore.cloneModel());
/*    */     }
/* 51 */     if (this.modelAfter != null) {
/* 52 */       clone.modelAfter = ((Model)this.modelAfter.cloneModel());
/*    */     }
/* 54 */     clone.modelAfterProcessable = this.modelAfterProcessable;
/* 55 */     clone.discardEvent = this.discardEvent;
/* 56 */     clone.skipBody = this.skipBody;
/* 57 */     clone.skipCloseTag = this.skipCloseTag;
/* 58 */     return clone;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\ProcessorExecutionVars.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */