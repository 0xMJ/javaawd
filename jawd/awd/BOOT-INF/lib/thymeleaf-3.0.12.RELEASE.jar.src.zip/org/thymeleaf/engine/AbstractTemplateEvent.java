/*    */ package org.thymeleaf.engine;
/*    */ 
/*    */ import org.thymeleaf.model.ITemplateEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class AbstractTemplateEvent
/*    */   implements ITemplateEvent
/*    */ {
/*    */   final String templateName;
/*    */   final int line;
/*    */   final int col;
/*    */   
/*    */   AbstractTemplateEvent()
/*    */   {
/* 38 */     this(null, -1, -1);
/*    */   }
/*    */   
/*    */ 
/*    */   AbstractTemplateEvent(String templateName, int line, int col)
/*    */   {
/* 44 */     this.templateName = templateName;
/* 45 */     this.line = line;
/* 46 */     this.col = col;
/*    */   }
/*    */   
/*    */ 
/*    */   AbstractTemplateEvent(AbstractTemplateEvent original)
/*    */   {
/* 52 */     this.templateName = original.templateName;
/* 53 */     this.line = original.line;
/* 54 */     this.col = original.col;
/*    */   }
/*    */   
/*    */ 
/*    */   public final boolean hasLocation()
/*    */   {
/* 60 */     return (this.templateName != null) && (this.line != -1) && (this.col != -1);
/*    */   }
/*    */   
/*    */   public final String getTemplateName() {
/* 64 */     return this.templateName;
/*    */   }
/*    */   
/*    */   public final int getLine() {
/* 68 */     return this.line;
/*    */   }
/*    */   
/*    */   public final int getCol() {
/* 72 */     return this.col;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\engine\AbstractTemplateEvent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */