/*     */ package org.thymeleaf;
/*     */ 
/*     */ import java.util.Properties;
/*     */ import org.thymeleaf.util.ClassLoaderUtils;
/*     */ import org.thymeleaf.util.VersionUtils;
/*     */ import org.thymeleaf.util.VersionUtils.VersionSpec;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Thymeleaf
/*     */ {
/*     */   private static final String STABLE_RELEASE_QUALIFIER = "RELEASE";
/*     */   
/*     */   static
/*     */   {
/*  73 */     String version = null;
/*  74 */     String buildTimestamp = null;
/*     */     try {
/*  76 */       Properties properties = new Properties();
/*  77 */       properties.load(ClassLoaderUtils.loadResourceAsStream("org/thymeleaf/thymeleaf.properties"));
/*  78 */       version = properties.getProperty("version");
/*  79 */       buildTimestamp = properties.getProperty("build.date");
/*     */     }
/*     */     catch (Exception localException) {}
/*     */     
/*     */ 
/*     */ 
/*  85 */     VERSION_SPEC = VersionUtils.parseVersion(version, buildTimestamp); } /**
/*     */    * @deprecated
/*     */    */
/*  87 */   public static final String VERSION = VERSION_SPEC.getVersion(); /**
/*     */    * @deprecated
/*     */    */
/*  88 */   public static final String BUILD_TIMESTAMP = VERSION_SPEC.getBuildTimestamp(); /**
/*     */    * @deprecated
/*     */    */
/*  89 */   public static final int VERSION_MAJOR = VERSION_SPEC.getMajor(); /**
/*     */    * @deprecated
/*     */    */
/*  90 */   public static final int VERSION_MINOR = VERSION_SPEC.getMinor(); /**
/*     */    * @deprecated
/*     */    */
/*  91 */   public static final int VERSION_BUILD = VERSION_SPEC.getPatch(); /**
/*     */    * @deprecated
/*     */    */
/*  92 */   public static final String VERSION_TYPE = VERSION_SPEC.getQualifier();
/*     */   
/*     */ 
/*     */ 
/*     */   private static final VersionUtils.VersionSpec VERSION_SPEC;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getVersion()
/*     */   {
/* 103 */     return VERSION_SPEC.getVersion();
/*     */   }
/*     */   
/*     */   public static String getBuildTimestamp() {
/* 107 */     return VERSION_SPEC.getBuildTimestamp();
/*     */   }
/*     */   
/*     */   public static int getVersionMajor() {
/* 111 */     return VERSION_SPEC.getMajor();
/*     */   }
/*     */   
/*     */   public static int getVersionMinor() {
/* 115 */     return VERSION_SPEC.getMinor();
/*     */   }
/*     */   
/*     */   public static int getVersionPatch() {
/* 119 */     return VERSION_SPEC.getPatch();
/*     */   }
/*     */   
/*     */   public static String getVersionQualifier() {
/* 123 */     return VERSION_SPEC.getQualifier();
/*     */   }
/*     */   
/*     */   public static boolean isVersionStableRelease()
/*     */   {
/* 128 */     return "RELEASE".equals(VERSION_SPEC.getQualifier());
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\Thymeleaf.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */