/*    */ package org.thymeleaf;
/*    */ 
/*    */ import org.thymeleaf.dialect.IDialect;
/*    */ import org.thymeleaf.util.Validate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DialectConfiguration
/*    */ {
/*    */   private final boolean prefixSpecified;
/*    */   private final String prefix;
/*    */   private final IDialect dialect;
/*    */   
/*    */   public DialectConfiguration(IDialect dialect)
/*    */   {
/* 63 */     Validate.notNull(dialect, "Dialect cannot be null");
/* 64 */     this.prefixSpecified = false;
/* 65 */     this.prefix = null;
/* 66 */     this.dialect = dialect;
/*    */   }
/*    */   
/*    */ 
/*    */   public DialectConfiguration(String prefix, IDialect dialect)
/*    */   {
/* 72 */     Validate.notNull(dialect, "Dialect cannot be null");
/* 73 */     this.prefixSpecified = true;
/* 74 */     this.prefix = prefix;
/* 75 */     this.dialect = dialect;
/*    */   }
/*    */   
/*    */ 
/*    */   public IDialect getDialect()
/*    */   {
/* 81 */     return this.dialect;
/*    */   }
/*    */   
/*    */ 
/*    */   public String getPrefix()
/*    */   {
/* 87 */     return this.prefix;
/*    */   }
/*    */   
/*    */   public boolean isPrefixSpecified()
/*    */   {
/* 92 */     return this.prefixSpecified;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\DialectConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */