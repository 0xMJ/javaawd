package org.thymeleaf.templateresource;

import java.io.IOException;
import java.io.Reader;

public abstract interface ITemplateResource
{
  public abstract String getDescription();
  
  public abstract String getBaseName();
  
  public abstract boolean exists();
  
  public abstract Reader reader()
    throws IOException;
  
  public abstract ITemplateResource relative(String paramString);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\templateresource\ITemplateResource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */