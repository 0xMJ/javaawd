/*    */ package org.thymeleaf.templateresource;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.Reader;
/*    */ import java.io.StringReader;
/*    */ import org.thymeleaf.exceptions.TemplateInputException;
/*    */ import org.thymeleaf.util.Validate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class StringTemplateResource
/*    */   implements ITemplateResource
/*    */ {
/*    */   private final String resource;
/*    */   
/*    */   public StringTemplateResource(String resource)
/*    */   {
/* 52 */     Validate.notNull(resource, "Resource cannot be null or empty");
/* 53 */     this.resource = resource;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public String getDescription()
/*    */   {
/* 60 */     return this.resource;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getBaseName()
/*    */   {
/* 68 */     return null;
/*    */   }
/*    */   
/*    */ 
/*    */   public Reader reader()
/*    */     throws IOException
/*    */   {
/* 75 */     return new StringReader(this.resource);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public ITemplateResource relative(String relativeLocation)
/*    */   {
/* 83 */     throw new TemplateInputException(String.format("Cannot create a relative resource for String resource  \"%s\"", new Object[] { this.resource }));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public boolean exists()
/*    */   {
/* 90 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\templateresource\StringTemplateResource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */