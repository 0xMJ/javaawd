/*     */ package org.thymeleaf.templateresource;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ import org.thymeleaf.util.ClassLoaderUtils;
/*     */ import org.thymeleaf.util.StringUtils;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ClassLoaderTemplateResource
/*     */   implements ITemplateResource
/*     */ {
/*     */   private final ClassLoader optionalClassLoader;
/*     */   private final String path;
/*     */   private final String characterEncoding;
/*     */   
/*     */   public ClassLoaderTemplateResource(String path, String characterEncoding)
/*     */   {
/*  72 */     this(null, path, characterEncoding);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ClassLoaderTemplateResource(ClassLoader classLoader, String path, String characterEncoding)
/*     */   {
/*  93 */     Validate.notEmpty(path, "Resource Path cannot be null or empty");
/*     */     
/*     */ 
/*  96 */     this.optionalClassLoader = classLoader;
/*  97 */     String cleanPath = TemplateResourceUtils.cleanPath(path);
/*  98 */     this.path = (cleanPath.charAt(0) == '/' ? cleanPath.substring(1) : cleanPath);
/*  99 */     this.characterEncoding = characterEncoding;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getDescription()
/*     */   {
/* 107 */     return this.path;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getBaseName()
/*     */   {
/* 114 */     return TemplateResourceUtils.computeBaseName(this.path);
/*     */   }
/*     */   
/*     */ 
/*     */   public Reader reader()
/*     */     throws IOException
/*     */   {
/*     */     InputStream inputStream;
/*     */     InputStream inputStream;
/* 123 */     if (this.optionalClassLoader != null) {
/* 124 */       inputStream = this.optionalClassLoader.getResourceAsStream(this.path);
/*     */     } else {
/* 126 */       inputStream = ClassLoaderUtils.findResourceAsStream(this.path);
/*     */     }
/*     */     
/* 129 */     if (inputStream == null) {
/* 130 */       throw new FileNotFoundException(String.format("ClassLoader resource \"%s\" could not be resolved", new Object[] { this.path }));
/*     */     }
/*     */     
/* 133 */     if (!StringUtils.isEmptyOrWhitespace(this.characterEncoding)) {
/* 134 */       return new BufferedReader(new InputStreamReader(new BufferedInputStream(inputStream), this.characterEncoding));
/*     */     }
/*     */     
/* 137 */     return new BufferedReader(new InputStreamReader(new BufferedInputStream(inputStream)));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ITemplateResource relative(String relativeLocation)
/*     */   {
/* 146 */     Validate.notEmpty(relativeLocation, "Relative Path cannot be null or empty");
/*     */     
/* 148 */     String fullRelativeLocation = TemplateResourceUtils.computeRelativeLocation(this.path, relativeLocation);
/* 149 */     return new ClassLoaderTemplateResource(this.optionalClassLoader, fullRelativeLocation, this.characterEncoding);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean exists()
/*     */   {
/* 157 */     if (this.optionalClassLoader != null) {
/* 158 */       return this.optionalClassLoader.getResource(this.path) != null;
/*     */     }
/* 160 */     return ClassLoaderUtils.isResourcePresent(this.path);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\templateresource\ClassLoaderTemplateResource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */