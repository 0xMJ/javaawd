/*     */ package org.thymeleaf.templateresource;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ import java.io.Serializable;
/*     */ import org.thymeleaf.util.StringUtils;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FileTemplateResource
/*     */   implements ITemplateResource, Serializable
/*     */ {
/*     */   private final String path;
/*     */   private final File file;
/*     */   private final String characterEncoding;
/*     */   
/*     */   public FileTemplateResource(String path, String characterEncoding)
/*     */   {
/*  60 */     Validate.notEmpty(path, "Resource Path cannot be null or empty");
/*     */     
/*     */ 
/*  63 */     this.path = TemplateResourceUtils.cleanPath(path);
/*  64 */     this.file = new File(path);
/*  65 */     this.characterEncoding = characterEncoding;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FileTemplateResource(File file, String characterEncoding)
/*     */   {
/*  74 */     Validate.notNull(file, "Resource File cannot be null");
/*     */     
/*     */ 
/*  77 */     this.path = TemplateResourceUtils.cleanPath(file.getPath());
/*  78 */     this.file = file;
/*  79 */     this.characterEncoding = characterEncoding;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getDescription()
/*     */   {
/*  87 */     return this.file.getAbsolutePath();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getBaseName()
/*     */   {
/*  94 */     return TemplateResourceUtils.computeBaseName(this.path);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Reader reader()
/*     */     throws IOException
/*     */   {
/* 102 */     InputStream inputStream = new FileInputStream(this.file);
/*     */     
/* 104 */     if (!StringUtils.isEmptyOrWhitespace(this.characterEncoding)) {
/* 105 */       return new BufferedReader(new InputStreamReader(new BufferedInputStream(inputStream), this.characterEncoding));
/*     */     }
/*     */     
/* 108 */     return new BufferedReader(new InputStreamReader(new BufferedInputStream(inputStream)));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ITemplateResource relative(String relativeLocation)
/*     */   {
/* 117 */     Validate.notEmpty(relativeLocation, "Relative Path cannot be null or empty");
/*     */     
/* 119 */     String fullRelativeLocation = TemplateResourceUtils.computeRelativeLocation(this.path, relativeLocation);
/* 120 */     return new FileTemplateResource(fullRelativeLocation, this.characterEncoding);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean exists()
/*     */   {
/* 128 */     return this.file.exists();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\templateresource\FileTemplateResource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */