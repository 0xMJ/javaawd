/*     */ package org.thymeleaf.templateresource;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ import java.net.MalformedURLException;
/*     */ import javax.servlet.ServletContext;
/*     */ import org.thymeleaf.util.StringUtils;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ServletContextTemplateResource
/*     */   implements ITemplateResource
/*     */ {
/*     */   private final ServletContext servletContext;
/*     */   private final String path;
/*     */   private final String characterEncoding;
/*     */   
/*     */   public ServletContextTemplateResource(ServletContext servletContext, String path, String characterEncoding)
/*     */   {
/*  63 */     Validate.notNull(servletContext, "ServletContext cannot be null");
/*  64 */     Validate.notEmpty(path, "Resource Path cannot be null or empty");
/*     */     
/*     */ 
/*  67 */     this.servletContext = servletContext;
/*  68 */     String cleanPath = TemplateResourceUtils.cleanPath(path);
/*  69 */     this.path = (cleanPath.charAt(0) != '/' ? "/" + cleanPath : cleanPath);
/*  70 */     this.characterEncoding = characterEncoding;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getDescription()
/*     */   {
/*  78 */     return this.path;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getBaseName()
/*     */   {
/*  85 */     return TemplateResourceUtils.computeBaseName(this.path);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Reader reader()
/*     */     throws IOException
/*     */   {
/*  93 */     InputStream inputStream = this.servletContext.getResourceAsStream(this.path);
/*  94 */     if (inputStream == null) {
/*  95 */       throw new FileNotFoundException(String.format("ServletContext resource \"%s\" does not exist", new Object[] { this.path }));
/*     */     }
/*     */     
/*  98 */     if (!StringUtils.isEmptyOrWhitespace(this.characterEncoding)) {
/*  99 */       return new BufferedReader(new InputStreamReader(new BufferedInputStream(inputStream), this.characterEncoding));
/*     */     }
/*     */     
/* 102 */     return new BufferedReader(new InputStreamReader(new BufferedInputStream(inputStream)));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ITemplateResource relative(String relativeLocation)
/*     */   {
/* 111 */     Validate.notEmpty(relativeLocation, "Relative Path cannot be null or empty");
/*     */     
/* 113 */     String fullRelativeLocation = TemplateResourceUtils.computeRelativeLocation(this.path, relativeLocation);
/* 114 */     return new ServletContextTemplateResource(this.servletContext, fullRelativeLocation, this.characterEncoding);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean exists()
/*     */   {
/*     */     try
/*     */     {
/* 123 */       return this.servletContext.getResource(this.path) != null;
/*     */     } catch (MalformedURLException e) {}
/* 125 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\templateresource\ServletContextTemplateResource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */