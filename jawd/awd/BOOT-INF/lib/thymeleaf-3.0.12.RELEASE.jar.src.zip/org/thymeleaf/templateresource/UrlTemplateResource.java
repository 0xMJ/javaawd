/*     */ package org.thymeleaf.templateresource;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ import java.io.Serializable;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import org.thymeleaf.exceptions.TemplateInputException;
/*     */ import org.thymeleaf.util.StringUtils;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class UrlTemplateResource
/*     */   implements ITemplateResource, Serializable
/*     */ {
/*     */   private final URL url;
/*     */   private final String characterEncoding;
/*     */   
/*     */   public UrlTemplateResource(String path, String characterEncoding)
/*     */     throws MalformedURLException
/*     */   {
/*  65 */     Validate.notEmpty(path, "Resource Path cannot be null or empty");
/*     */     
/*     */ 
/*  68 */     this.url = new URL(path);
/*  69 */     this.characterEncoding = characterEncoding;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UrlTemplateResource(URL url, String characterEncoding)
/*     */   {
/*  78 */     Validate.notNull(url, "Resource URL cannot be null");
/*     */     
/*     */ 
/*  81 */     this.url = url;
/*  82 */     this.characterEncoding = characterEncoding;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getDescription()
/*     */   {
/*  90 */     return this.url.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getBaseName()
/*     */   {
/*  97 */     return TemplateResourceUtils.computeBaseName(TemplateResourceUtils.cleanPath(this.url.getPath()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Reader reader()
/*     */     throws IOException
/*     */   {
/* 105 */     InputStream inputStream = inputStream();
/*     */     
/* 107 */     if (!StringUtils.isEmptyOrWhitespace(this.characterEncoding)) {
/* 108 */       return new BufferedReader(new InputStreamReader(new BufferedInputStream(inputStream), this.characterEncoding));
/*     */     }
/*     */     
/* 111 */     return new BufferedReader(new InputStreamReader(new BufferedInputStream(inputStream)));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private InputStream inputStream()
/*     */     throws IOException
/*     */   {
/* 120 */     URLConnection connection = this.url.openConnection();
/* 121 */     if (connection.getClass().getSimpleName().startsWith("JNLP")) {
/* 122 */       connection.setUseCaches(true);
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 127 */       inputStream = connection.getInputStream();
/*     */     } catch (IOException e) { InputStream inputStream;
/* 129 */       if ((connection instanceof HttpURLConnection))
/*     */       {
/* 131 */         ((HttpURLConnection)connection).disconnect();
/*     */       }
/* 133 */       throw e;
/*     */     }
/*     */     InputStream inputStream;
/* 136 */     return inputStream;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ITemplateResource relative(String relativeLocation)
/*     */   {
/* 145 */     Validate.notEmpty(relativeLocation, "Relative Path cannot be null or empty");
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 150 */       relativeURL = new URL(this.url, relativeLocation.charAt(0) == '/' ? relativeLocation.substring(1) : relativeLocation);
/*     */     } catch (MalformedURLException e) {
/*     */       URL relativeURL;
/* 153 */       throw new TemplateInputException("Could not create relative URL resource for resource \"" + getDescription() + "\" and relative location \"" + relativeLocation + "\"", e);
/*     */     }
/*     */     
/*     */     URL relativeURL;
/* 157 */     return new UrlTemplateResource(relativeURL, this.characterEncoding);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean exists()
/*     */   {
/*     */     try
/*     */     {
/* 168 */       String protocol = this.url.getProtocol();
/*     */       
/* 170 */       if ("file".equals(protocol))
/*     */       {
/*     */ 
/* 173 */         File file = null;
/*     */         try {
/* 175 */           file = new File(toURI(this.url).getSchemeSpecificPart());
/*     */         }
/*     */         catch (URISyntaxException ignored) {
/* 178 */           file = new File(this.url.getFile());
/*     */         }
/*     */         
/* 181 */         return file.exists();
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 187 */       URLConnection connection = this.url.openConnection();
/*     */       
/* 189 */       if (connection.getClass().getSimpleName().startsWith("JNLP")) {
/* 190 */         connection.setUseCaches(true);
/*     */       }
/*     */       
/* 193 */       if ((connection instanceof HttpURLConnection))
/*     */       {
/* 195 */         HttpURLConnection httpConnection = (HttpURLConnection)connection;
/* 196 */         httpConnection.setRequestMethod("HEAD");
/*     */         
/* 198 */         int responseCode = httpConnection.getResponseCode();
/* 199 */         if (responseCode == 200)
/* 200 */           return true;
/* 201 */         if (responseCode == 404) {
/* 202 */           return false;
/*     */         }
/*     */         
/* 205 */         if (httpConnection.getContentLength() >= 0)
/*     */         {
/* 207 */           return true;
/*     */         }
/*     */         
/*     */ 
/* 211 */         httpConnection.disconnect();
/* 212 */         return false;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 217 */       if (connection.getContentLength() >= 0) {
/* 218 */         return true;
/*     */       }
/*     */       
/*     */ 
/* 222 */       InputStream is = inputStream();
/* 223 */       is.close();
/*     */       
/* 225 */       return true;
/*     */     }
/*     */     catch (IOException ignored) {}
/* 228 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static URI toURI(URL url)
/*     */     throws URISyntaxException
/*     */   {
/* 238 */     String location = url.toString();
/* 239 */     if (location.indexOf(' ') == -1)
/*     */     {
/* 241 */       return new URI(location);
/*     */     }
/*     */     
/* 244 */     return new URI(StringUtils.replace(location, " ", "%20"));
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\templateresource\UrlTemplateResource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */