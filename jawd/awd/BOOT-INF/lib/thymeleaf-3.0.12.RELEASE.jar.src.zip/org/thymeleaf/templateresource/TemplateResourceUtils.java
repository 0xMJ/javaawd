/*     */ package org.thymeleaf.templateresource;
/*     */ 
/*     */ import org.thymeleaf.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class TemplateResourceUtils
/*     */ {
/*     */   static String cleanPath(String path)
/*     */   {
/*  39 */     if (path == null) {
/*  40 */       return null;
/*     */     }
/*     */     
/*     */ 
/*  44 */     String unixPath = StringUtils.replace(path, "\\", "/");
/*     */     
/*     */ 
/*  47 */     if ((unixPath.length() == 0) || ((unixPath.indexOf("/.") < 0) && (unixPath.indexOf("//") < 0))) {
/*  48 */       return unixPath;
/*     */     }
/*     */     
/*     */ 
/*  52 */     boolean rootBased = unixPath.charAt(0) == '/';
/*  53 */     unixPath = '/' + unixPath;
/*     */     
/*     */ 
/*  56 */     StringBuilder strBuilder = new StringBuilder(unixPath.length());
/*     */     
/*  58 */     int index = unixPath.lastIndexOf('/');
/*  59 */     int pos = unixPath.length() - 1;
/*  60 */     int topCount = 0;
/*  61 */     while (index >= 0)
/*     */     {
/*  63 */       int tokenLen = pos - index;
/*     */       
/*  65 */       if (tokenLen > 0)
/*     */       {
/*  67 */         if ((tokenLen != 1) || (unixPath.charAt(index + 1) != '.'))
/*     */         {
/*  69 */           if ((tokenLen == 2) && (unixPath.charAt(index + 1) == '.') && (unixPath.charAt(index + 2) == '.'))
/*     */           {
/*  71 */             topCount++;
/*  72 */           } else if (topCount > 0)
/*     */           {
/*  74 */             topCount--;
/*     */           }
/*     */           else {
/*  77 */             strBuilder.insert(0, unixPath, index, index + tokenLen + 1);
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*  82 */       pos = index - 1;
/*  83 */       index = pos >= 0 ? unixPath.lastIndexOf('/', pos) : -1;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  88 */     for (int i = 0; i < topCount; i++) {
/*  89 */       strBuilder.insert(0, "/..");
/*     */     }
/*     */     
/*     */ 
/*  93 */     if (!rootBased) {
/*  94 */       strBuilder.deleteCharAt(0);
/*     */     }
/*     */     
/*  97 */     return strBuilder.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   static String computeRelativeLocation(String location, String relativeLocation)
/*     */   {
/* 104 */     int separatorPos = location.lastIndexOf('/');
/* 105 */     if (separatorPos != -1) {
/* 106 */       StringBuilder relativeBuilder = new StringBuilder(location.length() + relativeLocation.length());
/* 107 */       relativeBuilder.append(location, 0, separatorPos);
/* 108 */       if (relativeLocation.charAt(0) != '/') {
/* 109 */         relativeBuilder.append('/');
/*     */       }
/* 111 */       relativeBuilder.append(relativeLocation);
/* 112 */       return relativeBuilder.toString();
/*     */     }
/* 114 */     return relativeLocation;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static String computeBaseName(String path)
/*     */   {
/* 122 */     if ((path == null) || (path.length() == 0)) {
/* 123 */       return null;
/*     */     }
/*     */     
/*     */ 
/* 127 */     String basePath = path.charAt(path.length() - 1) == '/' ? path.substring(0, path.length() - 1) : path;
/*     */     
/* 129 */     int slashPos = basePath.lastIndexOf('/');
/* 130 */     if (slashPos != -1) {
/* 131 */       int dotPos = basePath.lastIndexOf('.');
/* 132 */       if ((dotPos != -1) && (dotPos > slashPos + 1)) {
/* 133 */         return basePath.substring(slashPos + 1, dotPos);
/*     */       }
/* 135 */       return basePath.substring(slashPos + 1);
/*     */     }
/* 137 */     int dotPos = basePath.lastIndexOf('.');
/* 138 */     if (dotPos != -1) {
/* 139 */       return basePath.substring(0, dotPos);
/*     */     }
/*     */     
/*     */ 
/* 143 */     return basePath.length() > 0 ? basePath : null;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\templateresource\TemplateResourceUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */