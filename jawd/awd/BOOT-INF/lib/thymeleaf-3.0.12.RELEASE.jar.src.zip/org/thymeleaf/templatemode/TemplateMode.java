/*     */ package org.thymeleaf.templatemode;
/*     */ 
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.thymeleaf.TemplateEngine;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum TemplateMode
/*     */ {
/*  37 */   HTML(true, false, false),  XML(false, true, false), 
/*  38 */   TEXT(false, false, true),  JAVASCRIPT(false, false, true),  CSS(false, false, true), 
/*  39 */   RAW(false, false, false), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  49 */   HTML5(true, false, false), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  59 */   LEGACYHTML5(true, false, false), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  69 */   XHTML(true, false, false), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  79 */   VALIDXHTML(true, false, false), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  89 */   VALIDXML(false, true, false);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  96 */   private static Logger logger = LoggerFactory.getLogger(TemplateMode.class);
/*     */   
/*     */   private final boolean html;
/*     */   private final boolean xml;
/*     */   private final boolean text;
/*     */   private final boolean caseSensitive;
/*     */   
/*     */   private TemplateMode(boolean html, boolean xml, boolean text)
/*     */   {
/* 105 */     this.html = html;
/* 106 */     this.xml = xml;
/* 107 */     this.text = text;
/* 108 */     this.caseSensitive = (!this.html);
/*     */   }
/*     */   
/*     */   public boolean isMarkup() {
/* 112 */     return (this.html) || (this.xml);
/*     */   }
/*     */   
/*     */   public boolean isText() {
/* 116 */     return this.text;
/*     */   }
/*     */   
/*     */   public boolean isCaseSensitive() {
/* 120 */     return this.caseSensitive;
/*     */   }
/*     */   
/*     */   public static TemplateMode parse(String mode)
/*     */   {
/* 125 */     if ((mode == null) || (mode.trim().length() == 0)) {
/* 126 */       throw new IllegalArgumentException("Template mode cannot be null or empty");
/*     */     }
/* 128 */     if ("HTML".equalsIgnoreCase(mode)) {
/* 129 */       return HTML;
/*     */     }
/* 131 */     if ("XML".equalsIgnoreCase(mode)) {
/* 132 */       return XML;
/*     */     }
/* 134 */     if ("TEXT".equalsIgnoreCase(mode)) {
/* 135 */       return TEXT;
/*     */     }
/* 137 */     if ("JAVASCRIPT".equalsIgnoreCase(mode)) {
/* 138 */       return JAVASCRIPT;
/*     */     }
/* 140 */     if ("CSS".equalsIgnoreCase(mode)) {
/* 141 */       return CSS;
/*     */     }
/* 143 */     if ("RAW".equalsIgnoreCase(mode)) {
/* 144 */       return RAW;
/*     */     }
/*     */     
/*     */ 
/* 148 */     if (("HTML5".equalsIgnoreCase(mode)) || ("XHTML".equalsIgnoreCase(mode)) || 
/* 149 */       ("VALIDXHTML".equalsIgnoreCase(mode)) || ("LEGACYHTML5".equalsIgnoreCase(mode))) {
/* 150 */       logger.warn("[THYMELEAF][{}] Template Mode '{}' is deprecated. Using Template Mode '{}' instead.", new Object[] {
/*     */       
/* 152 */         TemplateEngine.threadIndex(), mode, HTML });
/* 153 */       return HTML;
/*     */     }
/* 155 */     if ("VALIDXML".equalsIgnoreCase(mode)) {
/* 156 */       logger.warn("[THYMELEAF][{}] Template Mode '{}' is deprecated. Using Template Mode '{}' instead.", new Object[] {
/*     */       
/* 158 */         TemplateEngine.threadIndex(), mode, XML });
/* 159 */       return XML;
/*     */     }
/* 161 */     logger.warn("[THYMELEAF][{}] Unknown Template Mode '{}'. Must be one of: 'HTML', 'XML', 'TEXT', 'JAVASCRIPT', 'CSS', 'RAW'. Using default Template Mode '{}'.", new Object[] {
/*     */     
/*     */ 
/* 164 */       TemplateEngine.threadIndex(), mode, HTML });
/* 165 */     return HTML;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\templatemode\TemplateMode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */