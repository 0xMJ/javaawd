package org.thymeleaf.cache;

import java.util.List;
import org.thymeleaf.engine.TemplateModel;

public abstract interface ICacheManager
{
  public abstract ICache<TemplateCacheKey, TemplateModel> getTemplateCache();
  
  public abstract ICache<ExpressionCacheKey, Object> getExpressionCache();
  
  public abstract <K, V> ICache<K, V> getSpecificCache(String paramString);
  
  public abstract List<String> getAllSpecificCacheNames();
  
  public abstract void clearAllCaches();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\cache\ICacheManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */