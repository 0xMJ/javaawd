/*    */ package org.thymeleaf.cache;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TTLCacheEntryValidity
/*    */   implements ICacheEntryValidity
/*    */ {
/*    */   private final long cacheTTLMs;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private final long creationTimeInMillis;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public TTLCacheEntryValidity(long cacheTTLMs)
/*    */   {
/* 50 */     this.cacheTTLMs = cacheTTLMs;
/* 51 */     this.creationTimeInMillis = System.currentTimeMillis();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public long getCacheTTLMs()
/*    */   {
/* 64 */     return this.cacheTTLMs;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean isCacheable()
/*    */   {
/* 77 */     return true;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean isCacheStillValid()
/*    */   {
/* 92 */     long currentTimeInMillis = System.currentTimeMillis();
/* 93 */     return currentTimeInMillis < this.creationTimeInMillis + this.cacheTTLMs;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\cache\TTLCacheEntryValidity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */