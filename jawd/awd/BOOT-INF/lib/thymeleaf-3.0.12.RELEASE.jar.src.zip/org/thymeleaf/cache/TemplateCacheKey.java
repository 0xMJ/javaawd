/*     */ package org.thymeleaf.cache;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ import org.thymeleaf.util.LoggingUtils;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class TemplateCacheKey
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 45842555123291L;
/*     */   private final String ownerTemplate;
/*     */   private final String template;
/*     */   private final Set<String> templateSelectors;
/*     */   private final int lineOffset;
/*     */   private final int colOffset;
/*     */   private final TemplateMode templateMode;
/*     */   private final Map<String, Object> templateResolutionAttributes;
/*     */   private final int h;
/*     */   
/*     */   public TemplateCacheKey(String ownerTemplate, String template, Set<String> templateSelectors, int lineOffset, int colOffset, TemplateMode templateMode, Map<String, Object> templateResolutionAttributes)
/*     */   {
/*  69 */     Validate.notNull(template, "Template cannot be null");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  74 */     this.ownerTemplate = ownerTemplate;
/*  75 */     this.template = template;
/*  76 */     this.templateSelectors = templateSelectors;
/*  77 */     this.lineOffset = lineOffset;
/*  78 */     this.colOffset = colOffset;
/*  79 */     this.templateMode = templateMode;
/*  80 */     this.templateResolutionAttributes = templateResolutionAttributes;
/*     */     
/*     */ 
/*     */ 
/*  84 */     this.h = computeHashCode();
/*     */   }
/*     */   
/*     */   public String getOwnerTemplate()
/*     */   {
/*  89 */     return this.ownerTemplate;
/*     */   }
/*     */   
/*     */   public String getTemplate() {
/*  93 */     return this.template;
/*     */   }
/*     */   
/*     */   public Set<String> getTemplateSelectors() {
/*  97 */     return this.templateSelectors;
/*     */   }
/*     */   
/*     */   public int getLineOffset() {
/* 101 */     return this.lineOffset;
/*     */   }
/*     */   
/*     */   public int getColOffset() {
/* 105 */     return this.colOffset;
/*     */   }
/*     */   
/*     */   public TemplateMode getTemplateMode() {
/* 109 */     return this.templateMode;
/*     */   }
/*     */   
/*     */   public Map<String, Object> getTemplateResolutionAttributes() {
/* 113 */     return this.templateResolutionAttributes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/* 120 */     if (this == o) {
/* 121 */       return true;
/*     */     }
/*     */     
/* 124 */     if (!(o instanceof TemplateCacheKey)) {
/* 125 */       return false;
/*     */     }
/*     */     
/* 128 */     TemplateCacheKey that = (TemplateCacheKey)o;
/*     */     
/* 130 */     if (this.h != that.h) {
/* 131 */       return false;
/*     */     }
/*     */     
/* 134 */     if (this.lineOffset != that.lineOffset) {
/* 135 */       return false;
/*     */     }
/* 137 */     if (this.colOffset != that.colOffset) {
/* 138 */       return false;
/*     */     }
/* 140 */     if (this.ownerTemplate != null ? !this.ownerTemplate.equals(that.ownerTemplate) : that.ownerTemplate != null) {
/* 141 */       return false;
/*     */     }
/* 143 */     if (!this.template.equals(that.template)) {
/* 144 */       return false;
/*     */     }
/* 146 */     if (this.templateSelectors != null ? !this.templateSelectors.equals(that.templateSelectors) : that.templateSelectors != null) {
/* 147 */       return false;
/*     */     }
/* 149 */     if (this.templateMode != that.templateMode) {
/* 150 */       return false;
/*     */     }
/*     */     
/* 153 */     return this.templateResolutionAttributes != null ? this.templateResolutionAttributes.equals(that.templateResolutionAttributes) : that.templateResolutionAttributes == null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 160 */     return this.h;
/*     */   }
/*     */   
/*     */   private int computeHashCode()
/*     */   {
/* 165 */     int result = this.ownerTemplate != null ? this.ownerTemplate.hashCode() : 0;
/* 166 */     result = 31 * result + this.template.hashCode();
/* 167 */     result = 31 * result + (this.templateSelectors != null ? this.templateSelectors.hashCode() : 0);
/* 168 */     result = 31 * result + this.lineOffset;
/* 169 */     result = 31 * result + this.colOffset;
/* 170 */     result = 31 * result + (this.templateMode != null ? this.templateMode.hashCode() : 0);
/* 171 */     result = 31 * result + (this.templateResolutionAttributes != null ? this.templateResolutionAttributes.hashCode() : 0);
/* 172 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 180 */     StringBuilder strBuilder = new StringBuilder();
/* 181 */     strBuilder.append(LoggingUtils.loggifyTemplateName(this.template));
/* 182 */     if (this.ownerTemplate != null) {
/* 183 */       strBuilder.append('@');
/* 184 */       strBuilder.append('(');
/* 185 */       strBuilder.append(LoggingUtils.loggifyTemplateName(this.ownerTemplate));
/* 186 */       strBuilder.append(';');
/* 187 */       strBuilder.append(this.lineOffset);
/* 188 */       strBuilder.append(',');
/* 189 */       strBuilder.append(this.colOffset);
/* 190 */       strBuilder.append(')');
/*     */     }
/* 192 */     if (this.templateSelectors != null) {
/* 193 */       strBuilder.append("::");
/* 194 */       strBuilder.append(this.templateSelectors);
/*     */     }
/* 196 */     if (this.templateMode != null) {
/* 197 */       strBuilder.append(" @");
/* 198 */       strBuilder.append(this.templateMode);
/*     */     }
/* 200 */     if (this.templateResolutionAttributes != null) {
/* 201 */       strBuilder.append(" (");
/* 202 */       strBuilder.append(this.templateResolutionAttributes);
/* 203 */       strBuilder.append(")");
/*     */     }
/* 205 */     return strBuilder.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\cache\TemplateCacheKey.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */