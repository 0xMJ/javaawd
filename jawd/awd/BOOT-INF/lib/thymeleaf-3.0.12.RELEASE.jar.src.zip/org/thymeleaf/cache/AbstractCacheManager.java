/*     */ package org.thymeleaf.cache;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.thymeleaf.engine.TemplateModel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractCacheManager
/*     */   implements ICacheManager
/*     */ {
/*     */   private volatile ICache<TemplateCacheKey, TemplateModel> templateCache;
/*  49 */   private volatile boolean templateCacheInitialized = false;
/*     */   
/*     */   private volatile ICache<ExpressionCacheKey, Object> expressionCache;
/*  52 */   private volatile boolean expressionCacheInitialized = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final ICache<TemplateCacheKey, TemplateModel> getTemplateCache()
/*     */   {
/*  61 */     if (!this.templateCacheInitialized) {
/*  62 */       synchronized (this) {
/*  63 */         if (!this.templateCacheInitialized) {
/*  64 */           this.templateCache = initializeTemplateCache();
/*  65 */           this.templateCacheInitialized = true;
/*     */         }
/*     */       }
/*     */     }
/*  69 */     return this.templateCache;
/*     */   }
/*     */   
/*     */   public final ICache<ExpressionCacheKey, Object> getExpressionCache() {
/*  73 */     if (!this.expressionCacheInitialized) {
/*  74 */       synchronized (this) {
/*  75 */         if (!this.expressionCacheInitialized) {
/*  76 */           this.expressionCache = initializeExpressionCache();
/*  77 */           this.expressionCacheInitialized = true;
/*     */         }
/*     */       }
/*     */     }
/*  81 */     return this.expressionCache;
/*     */   }
/*     */   
/*     */ 
/*     */   public <K, V> ICache<K, V> getSpecificCache(String name)
/*     */   {
/*  87 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public List<String> getAllSpecificCacheNames()
/*     */   {
/*  93 */     return Collections.emptyList();
/*     */   }
/*     */   
/*     */ 
/*     */   public void clearAllCaches()
/*     */   {
/*  99 */     ICache<TemplateCacheKey, TemplateModel> templateCacheObj = getTemplateCache();
/* 100 */     if (templateCacheObj != null) {
/* 101 */       templateCacheObj.clear();
/*     */     }
/*     */     
/* 104 */     ICache<ExpressionCacheKey, Object> expressionCacheObj = getExpressionCache();
/* 105 */     if (expressionCacheObj != null) {
/* 106 */       expressionCacheObj.clear();
/*     */     }
/*     */     
/* 109 */     List<String> allSpecificCacheNamesObj = getAllSpecificCacheNames();
/* 110 */     if (allSpecificCacheNamesObj != null) {
/* 111 */       for (String specificCacheName : allSpecificCacheNamesObj) {
/* 112 */         ICache<?, ?> specificCache = getSpecificCache(specificCacheName);
/* 113 */         if (specificCache != null) {
/* 114 */           specificCache.clear();
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected abstract ICache<TemplateCacheKey, TemplateModel> initializeTemplateCache();
/*     */   
/*     */   protected abstract ICache<ExpressionCacheKey, Object> initializeExpressionCache();
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\cache\AbstractCacheManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */