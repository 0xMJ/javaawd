/*    */ package org.thymeleaf.cache;
/*    */ 
/*    */ import org.thymeleaf.engine.TemplateData;
/*    */ import org.thymeleaf.engine.TemplateModel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class StandardParsedTemplateEntryValidator
/*    */   implements ICacheEntryValidityChecker<TemplateCacheKey, TemplateModel>
/*    */ {
/*    */   private static final long serialVersionUID = -185355204140990247L;
/*    */   
/*    */   public boolean checkIsValueStillValid(TemplateCacheKey key, TemplateModel value, long entryCreationTimestamp)
/*    */   {
/* 44 */     return value.getTemplateData().getValidity().isCacheStillValid();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\cache\StandardParsedTemplateEntryValidator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */