package org.thymeleaf.cache;

import java.io.Serializable;

public abstract interface ICacheEntryValidityChecker<K, V>
  extends Serializable
{
  public abstract boolean checkIsValueStillValid(K paramK, V paramV, long paramLong);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\cache\ICacheEntryValidityChecker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */