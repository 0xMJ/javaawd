/*     */ package org.thymeleaf.cache;
/*     */ 
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.thymeleaf.TemplateEngine;
/*     */ import org.thymeleaf.engine.TemplateModel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardCacheManager
/*     */   extends AbstractCacheManager
/*     */ {
/*     */   public static final String DEFAULT_TEMPLATE_CACHE_NAME = "TEMPLATE_CACHE";
/*     */   public static final int DEFAULT_TEMPLATE_CACHE_INITIAL_SIZE = 20;
/*     */   public static final int DEFAULT_TEMPLATE_CACHE_MAX_SIZE = 200;
/*     */   public static final boolean DEFAULT_TEMPLATE_CACHE_ENABLE_COUNTERS = false;
/*     */   public static final boolean DEFAULT_TEMPLATE_CACHE_USE_SOFT_REFERENCES = true;
/* 102 */   public static final String DEFAULT_TEMPLATE_CACHE_LOGGER_NAME = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 107 */   public static final ICacheEntryValidityChecker<TemplateCacheKey, TemplateModel> DEFAULT_TEMPLATE_CACHE_VALIDITY_CHECKER = new StandardParsedTemplateEntryValidator();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String DEFAULT_EXPRESSION_CACHE_NAME = "EXPRESSION_CACHE";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int DEFAULT_EXPRESSION_CACHE_INITIAL_SIZE = 100;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int DEFAULT_EXPRESSION_CACHE_MAX_SIZE = 500;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final boolean DEFAULT_EXPRESSION_CACHE_ENABLE_COUNTERS = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final boolean DEFAULT_EXPRESSION_CACHE_USE_SOFT_REFERENCES = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 138 */   public static final String DEFAULT_EXPRESSION_CACHE_LOGGER_NAME = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 143 */   public static final ICacheEntryValidityChecker<ExpressionCacheKey, Object> DEFAULT_EXPRESSION_CACHE_VALIDITY_CHECKER = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 148 */   private String templateCacheName = "TEMPLATE_CACHE";
/* 149 */   private int templateCacheInitialSize = 20;
/* 150 */   private int templateCacheMaxSize = 200;
/* 151 */   private boolean templateCacheEnableCounters = false;
/* 152 */   private boolean templateCacheUseSoftReferences = true;
/* 153 */   private String templateCacheLoggerName = DEFAULT_TEMPLATE_CACHE_LOGGER_NAME;
/* 154 */   private ICacheEntryValidityChecker<TemplateCacheKey, TemplateModel> templateCacheValidityChecker = DEFAULT_TEMPLATE_CACHE_VALIDITY_CHECKER;
/*     */   
/* 156 */   private String expressionCacheName = "EXPRESSION_CACHE";
/* 157 */   private int expressionCacheInitialSize = 100;
/* 158 */   private int expressionCacheMaxSize = 500;
/* 159 */   private boolean expressionCacheEnableCounters = false;
/* 160 */   private boolean expressionCacheUseSoftReferences = true;
/* 161 */   private String expressionCacheLoggerName = DEFAULT_EXPRESSION_CACHE_LOGGER_NAME;
/* 162 */   private ICacheEntryValidityChecker<ExpressionCacheKey, Object> expressionCacheValidityChecker = DEFAULT_EXPRESSION_CACHE_VALIDITY_CHECKER;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final ICache<TemplateCacheKey, TemplateModel> initializeTemplateCache()
/*     */   {
/* 174 */     int maxSize = getTemplateCacheMaxSize();
/* 175 */     if (maxSize == 0) {
/* 176 */       return null;
/*     */     }
/* 178 */     return new StandardCache(
/* 179 */       getTemplateCacheName(), getTemplateCacheUseSoftReferences(), 
/* 180 */       getTemplateCacheInitialSize(), maxSize, 
/* 181 */       getTemplateCacheValidityChecker(), getTemplateCacheLogger(), getTemplateCacheEnableCounters());
/*     */   }
/*     */   
/*     */ 
/*     */   protected final ICache<ExpressionCacheKey, Object> initializeExpressionCache()
/*     */   {
/* 187 */     int maxSize = getExpressionCacheMaxSize();
/* 188 */     if (maxSize == 0) {
/* 189 */       return null;
/*     */     }
/* 191 */     return new StandardCache(
/* 192 */       getExpressionCacheName(), getExpressionCacheUseSoftReferences(), 
/* 193 */       getExpressionCacheInitialSize(), maxSize, 
/* 194 */       getExpressionCacheValidityChecker(), getExpressionCacheLogger(), getExpressionCacheEnableCounters());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getTemplateCacheName()
/*     */   {
/* 201 */     return this.templateCacheName;
/*     */   }
/*     */   
/*     */   public boolean getTemplateCacheUseSoftReferences() {
/* 205 */     return this.templateCacheUseSoftReferences;
/*     */   }
/*     */   
/*     */   private boolean getTemplateCacheEnableCounters() {
/* 209 */     return this.templateCacheEnableCounters;
/*     */   }
/*     */   
/*     */   public int getTemplateCacheInitialSize() {
/* 213 */     return this.templateCacheInitialSize;
/*     */   }
/*     */   
/*     */   public int getTemplateCacheMaxSize() {
/* 217 */     return this.templateCacheMaxSize;
/*     */   }
/*     */   
/*     */   public String getTemplateCacheLoggerName() {
/* 221 */     return this.templateCacheLoggerName;
/*     */   }
/*     */   
/*     */   public ICacheEntryValidityChecker<TemplateCacheKey, TemplateModel> getTemplateCacheValidityChecker() {
/* 225 */     return this.templateCacheValidityChecker;
/*     */   }
/*     */   
/*     */   public final Logger getTemplateCacheLogger() {
/* 229 */     String loggerName = getTemplateCacheLoggerName();
/* 230 */     if (loggerName != null) {
/* 231 */       return LoggerFactory.getLogger(loggerName);
/*     */     }
/* 233 */     return LoggerFactory.getLogger(TemplateEngine.class.getName() + ".cache." + getTemplateCacheName());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getExpressionCacheName()
/*     */   {
/* 240 */     return this.expressionCacheName;
/*     */   }
/*     */   
/*     */   public boolean getExpressionCacheUseSoftReferences() {
/* 244 */     return this.expressionCacheUseSoftReferences;
/*     */   }
/*     */   
/*     */   private boolean getExpressionCacheEnableCounters() {
/* 248 */     return this.expressionCacheEnableCounters;
/*     */   }
/*     */   
/*     */   public int getExpressionCacheInitialSize() {
/* 252 */     return this.expressionCacheInitialSize;
/*     */   }
/*     */   
/*     */   public int getExpressionCacheMaxSize() {
/* 256 */     return this.expressionCacheMaxSize;
/*     */   }
/*     */   
/*     */   public String getExpressionCacheLoggerName() {
/* 260 */     return this.expressionCacheLoggerName;
/*     */   }
/*     */   
/*     */   public ICacheEntryValidityChecker<ExpressionCacheKey, Object> getExpressionCacheValidityChecker() {
/* 264 */     return this.expressionCacheValidityChecker;
/*     */   }
/*     */   
/*     */   public final Logger getExpressionCacheLogger() {
/* 268 */     String loggerName = getExpressionCacheLoggerName();
/* 269 */     if (loggerName != null) {
/* 270 */       return LoggerFactory.getLogger(loggerName);
/*     */     }
/* 272 */     return LoggerFactory.getLogger(TemplateEngine.class.getName() + ".cache." + getExpressionCacheName());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTemplateCacheName(String templateCacheName)
/*     */   {
/* 280 */     this.templateCacheName = templateCacheName;
/*     */   }
/*     */   
/*     */   public void setTemplateCacheInitialSize(int templateCacheInitialSize) {
/* 284 */     this.templateCacheInitialSize = templateCacheInitialSize;
/*     */   }
/*     */   
/*     */   public void setTemplateCacheMaxSize(int templateCacheMaxSize) {
/* 288 */     this.templateCacheMaxSize = templateCacheMaxSize;
/*     */   }
/*     */   
/*     */   public void setTemplateCacheUseSoftReferences(boolean templateCacheUseSoftReferences) {
/* 292 */     this.templateCacheUseSoftReferences = templateCacheUseSoftReferences;
/*     */   }
/*     */   
/*     */   public void setTemplateCacheLoggerName(String templateCacheLoggerName) {
/* 296 */     this.templateCacheLoggerName = templateCacheLoggerName;
/*     */   }
/*     */   
/*     */   public void setTemplateCacheValidityChecker(ICacheEntryValidityChecker<TemplateCacheKey, TemplateModel> templateCacheValidityChecker) {
/* 300 */     this.templateCacheValidityChecker = templateCacheValidityChecker;
/*     */   }
/*     */   
/*     */   public void setTemplateCacheEnableCounters(boolean templateCacheEnableCounters) {
/* 304 */     this.templateCacheEnableCounters = templateCacheEnableCounters;
/*     */   }
/*     */   
/*     */   public void setExpressionCacheName(String expressionCacheName)
/*     */   {
/* 309 */     this.expressionCacheName = expressionCacheName;
/*     */   }
/*     */   
/*     */   public void setExpressionCacheInitialSize(int expressionCacheInitialSize) {
/* 313 */     this.expressionCacheInitialSize = expressionCacheInitialSize;
/*     */   }
/*     */   
/*     */   public void setExpressionCacheMaxSize(int expressionCacheMaxSize) {
/* 317 */     this.expressionCacheMaxSize = expressionCacheMaxSize;
/*     */   }
/*     */   
/*     */   public void setExpressionCacheUseSoftReferences(boolean expressionCacheUseSoftReferences) {
/* 321 */     this.expressionCacheUseSoftReferences = expressionCacheUseSoftReferences;
/*     */   }
/*     */   
/*     */   public void setExpressionCacheLoggerName(String expressionCacheLoggerName) {
/* 325 */     this.expressionCacheLoggerName = expressionCacheLoggerName;
/*     */   }
/*     */   
/*     */   public void setExpressionCacheValidityChecker(ICacheEntryValidityChecker<ExpressionCacheKey, Object> expressionCacheValidityChecker) {
/* 329 */     this.expressionCacheValidityChecker = expressionCacheValidityChecker;
/*     */   }
/*     */   
/*     */   public void setExpressionCacheEnableCounters(boolean expressionCacheEnableCounters) {
/* 333 */     this.expressionCacheEnableCounters = expressionCacheEnableCounters;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\cache\StandardCacheManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */