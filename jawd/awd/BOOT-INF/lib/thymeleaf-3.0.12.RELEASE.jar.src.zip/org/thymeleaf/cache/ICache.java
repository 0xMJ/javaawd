package org.thymeleaf.cache;

import java.util.Set;

public abstract interface ICache<K, V>
{
  public abstract void put(K paramK, V paramV);
  
  public abstract V get(K paramK);
  
  public abstract V get(K paramK, ICacheEntryValidityChecker<? super K, ? super V> paramICacheEntryValidityChecker);
  
  public abstract void clear();
  
  public abstract void clearKey(K paramK);
  
  public abstract Set<K> keySet();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\cache\ICache.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */