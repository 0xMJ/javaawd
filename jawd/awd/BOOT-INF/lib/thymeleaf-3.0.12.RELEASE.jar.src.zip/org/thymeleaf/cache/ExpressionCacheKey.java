/*     */ package org.thymeleaf.cache;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ExpressionCacheKey
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 872451230923L;
/*     */   private final String type;
/*     */   private final String expression0;
/*     */   private final String expression1;
/*     */   private final int h;
/*     */   
/*     */   public ExpressionCacheKey(String type, String expression0)
/*     */   {
/*  50 */     this(type, expression0, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ExpressionCacheKey(String type, String expression0, String expression1)
/*     */   {
/*  57 */     Validate.notNull(type, "Type cannot be null");
/*  58 */     Validate.notNull(expression0, "Expression cannot be null");
/*     */     
/*  60 */     this.type = type;
/*  61 */     this.expression0 = expression0;
/*  62 */     this.expression1 = expression1;
/*     */     
/*     */ 
/*     */ 
/*  66 */     this.h = computeHashCode();
/*     */   }
/*     */   
/*     */   public String getType()
/*     */   {
/*  71 */     return this.type;
/*     */   }
/*     */   
/*     */   public String getExpression0() {
/*  75 */     return this.expression0;
/*     */   }
/*     */   
/*     */   public String getExpression1() {
/*  79 */     return this.expression1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/*  86 */     if (this == o) {
/*  87 */       return true;
/*     */     }
/*     */     
/*  90 */     if (!(o instanceof ExpressionCacheKey)) {
/*  91 */       return false;
/*     */     }
/*     */     
/*  94 */     ExpressionCacheKey that = (ExpressionCacheKey)o;
/*     */     
/*  96 */     if (this.h != that.h) {
/*  97 */       return false;
/*     */     }
/*     */     
/* 100 */     if (!this.type.equals(that.type)) {
/* 101 */       return false;
/*     */     }
/* 103 */     if (!this.expression0.equals(that.expression0)) {
/* 104 */       return false;
/*     */     }
/* 106 */     return that.expression1 == null ? true : this.expression1 != null ? this.expression1.equals(that.expression1) : false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 113 */     return this.h;
/*     */   }
/*     */   
/*     */   private int computeHashCode()
/*     */   {
/* 118 */     int result = this.type.hashCode();
/* 119 */     result = 31 * result + this.expression0.hashCode();
/* 120 */     result = 31 * result + (this.expression1 != null ? this.expression1.hashCode() : 0);
/* 121 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/* 127 */     StringBuilder strBuilder = new StringBuilder();
/* 128 */     strBuilder.append(this.type);
/* 129 */     strBuilder.append('|');
/* 130 */     strBuilder.append(this.expression0);
/* 131 */     if (this.expression1 != null) {
/* 132 */       strBuilder.append('|');
/* 133 */       strBuilder.append(this.expression1);
/*     */     }
/* 135 */     return strBuilder.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\cache\ExpressionCacheKey.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */