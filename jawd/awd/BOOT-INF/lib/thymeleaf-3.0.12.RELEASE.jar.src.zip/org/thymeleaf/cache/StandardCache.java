/*     */ package org.thymeleaf.cache;
/*     */ 
/*     */ import java.lang.ref.SoftReference;
/*     */ import java.util.Arrays;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ import org.slf4j.Logger;
/*     */ import org.thymeleaf.TemplateEngine;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class StandardCache<K, V>
/*     */   implements ICache<K, V>
/*     */ {
/*     */   private static final long REPORT_INTERVAL = 300000L;
/*     */   private static final String REPORT_FORMAT = "[THYMELEAF][*][*][*][CACHE_REPORT] %8s elements | %12s puts | %12s gets | %12s hits | %12s misses | %.2f hit ratio | %.2f miss ratio - [%s]";
/*  51 */   private volatile long lastExecution = System.currentTimeMillis();
/*     */   
/*     */   private final String name;
/*     */   
/*     */   private final boolean useSoftReferences;
/*     */   
/*     */   private final int maxSize;
/*     */   
/*     */   private final CacheDataContainer<K, V> dataContainer;
/*     */   
/*     */   private final ICacheEntryValidityChecker<? super K, ? super V> entryValidityChecker;
/*     */   
/*     */   private final boolean traceExecution;
/*     */   
/*     */   private final boolean enableCounters;
/*     */   
/*     */   private final Logger logger;
/*     */   
/*     */   private final AtomicLong getCount;
/*     */   
/*     */   private final AtomicLong putCount;
/*     */   
/*     */   private final AtomicLong hitCount;
/*     */   private final AtomicLong missCount;
/*     */   
/*     */   public StandardCache(String name, boolean useSoftReferences, int initialCapacity, Logger logger)
/*     */   {
/*  78 */     this(name, useSoftReferences, initialCapacity, -1, null, logger, false);
/*     */   }
/*     */   
/*     */ 
/*     */   public StandardCache(String name, boolean useSoftReferences, int initialCapacity, ICacheEntryValidityChecker<? super K, ? super V> entryValidityChecker, Logger logger)
/*     */   {
/*  84 */     this(name, useSoftReferences, initialCapacity, -1, entryValidityChecker, logger, false);
/*     */   }
/*     */   
/*     */   public StandardCache(String name, boolean useSoftReferences, int initialCapacity, int maxSize, Logger logger)
/*     */   {
/*  89 */     this(name, useSoftReferences, initialCapacity, maxSize, null, logger, false);
/*     */   }
/*     */   
/*     */ 
/*     */   public StandardCache(String name, boolean useSoftReferences, int initialCapacity, int maxSize, ICacheEntryValidityChecker<? super K, ? super V> entryValidityChecker, Logger logger)
/*     */   {
/*  95 */     this(name, useSoftReferences, initialCapacity, maxSize, entryValidityChecker, logger, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public StandardCache(String name, boolean useSoftReferences, int initialCapacity, int maxSize, ICacheEntryValidityChecker<? super K, ? super V> entryValidityChecker, Logger logger, boolean enableCounters)
/*     */   {
/* 104 */     Validate.notEmpty(name, "Name cannot be null or empty");
/* 105 */     Validate.isTrue(initialCapacity > 0, "Initial capacity must be > 0");
/* 106 */     Validate.isTrue(maxSize != 0, "Cache max size must be either -1 (no limit) or > 0");
/*     */     
/* 108 */     this.name = name;
/* 109 */     this.useSoftReferences = useSoftReferences;
/* 110 */     this.maxSize = maxSize;
/* 111 */     this.entryValidityChecker = entryValidityChecker;
/*     */     
/* 113 */     this.logger = logger;
/* 114 */     this.traceExecution = ((logger != null) && (logger.isTraceEnabled()));
/* 115 */     this.enableCounters = ((this.traceExecution) || (enableCounters));
/* 116 */     this.dataContainer = new CacheDataContainer(this.name, initialCapacity, maxSize, this.traceExecution, this.logger);
/*     */     
/*     */ 
/* 119 */     this.getCount = new AtomicLong(0L);
/* 120 */     this.putCount = new AtomicLong(0L);
/* 121 */     this.hitCount = new AtomicLong(0L);
/* 122 */     this.missCount = new AtomicLong(0L);
/*     */     
/* 124 */     if (this.logger != null) {
/* 125 */       if (this.maxSize < 0) {
/* 126 */         this.logger.trace("[THYMELEAF][CACHE_INITIALIZE] Initializing cache {}. Soft references {}.", this.name, 
/* 127 */           this.useSoftReferences ? "are used" : "not used");
/*     */       } else {
/* 129 */         this.logger.trace("[THYMELEAF][CACHE_INITIALIZE] Initializing cache {}. Max size: {}. Soft references {}.", new Object[] { this.name, 
/* 130 */           Integer.valueOf(this.maxSize), this.useSoftReferences ? "are used" : "not used" });
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void put(K key, V value)
/*     */   {
/* 145 */     incrementReportEntity(this.putCount);
/*     */     
/* 147 */     CacheEntry<V> entry = new CacheEntry(value, this.useSoftReferences);
/*     */     
/*     */ 
/* 150 */     int newSize = this.dataContainer.put(key, entry);
/*     */     
/* 152 */     if (this.traceExecution) {
/* 153 */       this.logger.trace("[THYMELEAF][{}][{}][CACHE_ADD][{}] Adding cache entry in cache \"{}\" for key \"{}\". New size is {}.", new Object[] {
/*     */       
/* 155 */         TemplateEngine.threadIndex(), this.name, Integer.valueOf(newSize), this.name, key, Integer.valueOf(newSize) });
/* 156 */       outputReportIfNeeded();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public V get(K key)
/*     */   {
/* 165 */     return (V)get(key, this.entryValidityChecker);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public V get(K key, ICacheEntryValidityChecker<? super K, ? super V> validityChecker)
/*     */   {
/* 172 */     incrementReportEntity(this.getCount);
/* 173 */     CacheEntry<V> resultEntry = this.dataContainer.get(key);
/*     */     
/* 175 */     if (resultEntry == null) {
/* 176 */       incrementReportEntity(this.missCount);
/* 177 */       if (this.traceExecution) {
/* 178 */         this.logger.trace("[THYMELEAF][{}][{}][CACHE_MISS] Cache miss in cache \"{}\" for key \"{}\".", new Object[] {
/*     */         
/* 180 */           TemplateEngine.threadIndex(), this.name, this.name, key });
/* 181 */         outputReportIfNeeded();
/*     */       }
/* 183 */       return null;
/*     */     }
/*     */     
/*     */ 
/* 187 */     V resultValue = resultEntry.getValueIfStillValid(this.name, key, validityChecker, this.traceExecution, this.logger);
/* 188 */     if (resultValue == null) {
/* 189 */       int newSize = this.dataContainer.remove(key);
/* 190 */       incrementReportEntity(this.missCount);
/* 191 */       if (this.traceExecution) {
/* 192 */         this.logger.trace("[THYMELEAF][{}][{}][CACHE_REMOVE][{}] Removing cache entry in cache \"{}\" (Entry \"{}\" is not valid anymore). New size is {}.", new Object[] {
/*     */         
/* 194 */           TemplateEngine.threadIndex(), this.name, Integer.valueOf(newSize), this.name, key, Integer.valueOf(newSize) });
/* 195 */         this.logger.trace("[THYMELEAF][{}][{}][CACHE_MISS] Cache miss in cache \"{}\" for key \"{}\".", new Object[] {
/*     */         
/* 197 */           TemplateEngine.threadIndex(), this.name, this.name, key });
/* 198 */         outputReportIfNeeded();
/*     */       }
/* 200 */       return null;
/*     */     }
/*     */     
/* 203 */     incrementReportEntity(this.hitCount);
/* 204 */     if (this.traceExecution) {
/* 205 */       this.logger.trace("[THYMELEAF][{}][{}][CACHE_HIT] Cache hit in cache \"{}\" for key \"{}\".", new Object[] {
/*     */       
/* 207 */         TemplateEngine.threadIndex(), this.name, this.name, key });
/* 208 */       outputReportIfNeeded();
/*     */     }
/*     */     
/* 211 */     return resultValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Set<K> keySet()
/*     */   {
/* 227 */     return this.dataContainer.keySet();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void clear()
/*     */   {
/* 234 */     this.dataContainer.clear();
/*     */     
/* 236 */     if (this.traceExecution) {
/* 237 */       this.logger.trace("[THYMELEAF][{}][*][{}][CACHE_REMOVE][0] Removing ALL cache entries in cache \"{}\". New size is 0.", new Object[] {
/*     */       
/* 239 */         TemplateEngine.threadIndex(), this.name, this.name });
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void clearKey(K key)
/*     */   {
/* 248 */     int newSize = this.dataContainer.remove(key);
/*     */     
/* 250 */     if ((this.traceExecution) && (newSize != -1)) {
/* 251 */       this.logger.trace("[THYMELEAF][{}][*][{}][CACHE_REMOVE][{}] Removed cache entry in cache \"{}\" for key \"{}\". New size is {}.", new Object[] {
/*     */       
/* 253 */         TemplateEngine.threadIndex(), this.name, Integer.valueOf(newSize), this.name, key, Integer.valueOf(newSize) });
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/* 265 */     return this.name;
/*     */   }
/*     */   
/*     */   public boolean hasMaxSize() {
/* 269 */     return this.maxSize > 0;
/*     */   }
/*     */   
/*     */   public int getMaxSize() {
/* 273 */     return this.maxSize;
/*     */   }
/*     */   
/*     */   public boolean getUseSoftReferences() {
/* 277 */     return this.useSoftReferences;
/*     */   }
/*     */   
/*     */   public int size() {
/* 281 */     return this.dataContainer.size();
/*     */   }
/*     */   
/*     */   public long getPutCount() {
/* 285 */     return this.putCount.get();
/*     */   }
/*     */   
/*     */   public long getGetCount() {
/* 289 */     return this.getCount.get();
/*     */   }
/*     */   
/*     */   public long getHitCount() {
/* 293 */     return this.hitCount.get();
/*     */   }
/*     */   
/*     */   public long getMissCount() {
/* 297 */     return this.missCount.get();
/*     */   }
/*     */   
/*     */   public double getHitRatio()
/*     */   {
/* 302 */     long hitCount = getHitCount();
/* 303 */     long getCount = getGetCount();
/*     */     
/* 305 */     if ((hitCount == 0L) || (getCount == 0L)) {
/* 306 */       return 0.0D;
/*     */     }
/*     */     
/* 309 */     return hitCount / getCount;
/*     */   }
/*     */   
/*     */   public double getMissRatio() {
/* 313 */     return 1.0D - getHitRatio();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void incrementReportEntity(AtomicLong entity)
/*     */   {
/* 322 */     if (this.enableCounters) {
/* 323 */       entity.incrementAndGet();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void outputReportIfNeeded()
/*     */   {
/* 330 */     long currentTime = System.currentTimeMillis();
/* 331 */     if (currentTime - this.lastExecution >= 300000L) {
/* 332 */       synchronized (this) {
/* 333 */         if (currentTime - this.lastExecution >= 300000L) {
/* 334 */           long hitCount = getHitCount();
/* 335 */           long missCount = getMissCount();
/* 336 */           long putCount = getPutCount();
/* 337 */           long getCount = getGetCount();
/*     */           
/* 339 */           double hitRatio = hitCount / getCount;
/* 340 */           double missRatio = 1.0D - hitRatio;
/*     */           
/* 342 */           this.logger.trace(
/* 343 */             String.format("[THYMELEAF][*][*][*][CACHE_REPORT] %8s elements | %12s puts | %12s gets | %12s hits | %12s misses | %.2f hit ratio | %.2f miss ratio - [%s]", new Object[] {
/* 344 */             Integer.valueOf(size()), 
/* 345 */             Long.valueOf(putCount), 
/* 346 */             Long.valueOf(getCount), 
/* 347 */             Long.valueOf(hitCount), 
/* 348 */             Long.valueOf(missCount), 
/* 349 */             Double.valueOf(hitRatio), 
/* 350 */             Double.valueOf(missRatio), this.name }));
/*     */           
/* 352 */           this.lastExecution = currentTime;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   static final class CacheDataContainer<K, V>
/*     */   {
/*     */     private final String name;
/*     */     
/*     */ 
/*     */     private final boolean sizeLimit;
/*     */     
/*     */     private final int maxSize;
/*     */     
/*     */     private final boolean traceExecution;
/*     */     
/*     */     private final Logger logger;
/*     */     
/*     */     private final ConcurrentHashMap<K, StandardCache.CacheEntry<V>> container;
/*     */     
/*     */     private final Object[] fifo;
/*     */     
/*     */     private int fifoPointer;
/*     */     
/*     */ 
/*     */     CacheDataContainer(String name, int initialCapacity, int maxSize, boolean traceExecution, Logger logger)
/*     */     {
/* 382 */       this.name = name;
/* 383 */       this.container = new ConcurrentHashMap(initialCapacity, 0.9F, 2);
/* 384 */       this.maxSize = maxSize;
/* 385 */       this.sizeLimit = (maxSize >= 0);
/* 386 */       if (this.sizeLimit) {
/* 387 */         this.fifo = new Object[this.maxSize];
/* 388 */         Arrays.fill(this.fifo, null);
/*     */       } else {
/* 390 */         this.fifo = null;
/*     */       }
/* 392 */       this.fifoPointer = 0;
/* 393 */       this.traceExecution = traceExecution;
/* 394 */       this.logger = logger;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public StandardCache.CacheEntry<V> get(Object key)
/*     */     {
/* 401 */       return (StandardCache.CacheEntry)this.container.get(key);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public Set<K> keySet()
/*     */     {
/* 412 */       return this.container.keySet();
/*     */     }
/*     */     
/*     */     public int put(K key, StandardCache.CacheEntry<V> value)
/*     */     {
/* 417 */       if (this.traceExecution) {
/* 418 */         return putWithTracing(key, value);
/*     */       }
/* 420 */       return putWithoutTracing(key, value);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private int putWithoutTracing(K key, StandardCache.CacheEntry<V> value)
/*     */     {
/* 429 */       StandardCache.CacheEntry<V> existing = (StandardCache.CacheEntry)this.container.putIfAbsent(key, value);
/* 430 */       if (existing != null)
/*     */       {
/* 432 */         return -1;
/*     */       }
/*     */       
/* 435 */       if (this.sizeLimit) {
/* 436 */         synchronized (this.fifo) {
/* 437 */           Object removedKey = this.fifo[this.fifoPointer];
/* 438 */           if (removedKey != null) {
/* 439 */             this.container.remove(removedKey);
/*     */           }
/* 441 */           this.fifo[this.fifoPointer] = key;
/* 442 */           this.fifoPointer = ((this.fifoPointer + 1) % this.maxSize);
/*     */         }
/*     */       }
/*     */       
/* 446 */       return -1;
/*     */     }
/*     */     
/*     */ 
/*     */     private synchronized int putWithTracing(K key, StandardCache.CacheEntry<V> value)
/*     */     {
/* 452 */       StandardCache.CacheEntry<V> existing = (StandardCache.CacheEntry)this.container.putIfAbsent(key, value);
/* 453 */       if ((existing == null) && 
/* 454 */         (this.sizeLimit)) {
/* 455 */         Object removedKey = this.fifo[this.fifoPointer];
/* 456 */         if (removedKey != null) {
/* 457 */           StandardCache.CacheEntry<V> removed = (StandardCache.CacheEntry)this.container.remove(removedKey);
/* 458 */           if (removed != null) {
/* 459 */             Integer newSize = Integer.valueOf(this.container.size());
/* 460 */             this.logger.trace("[THYMELEAF][{}][{}][CACHE_REMOVE][{}] Max size exceeded for cache \"{}\". Removing entry for key \"{}\". New size is {}.", new Object[] {
/*     */             
/* 462 */               TemplateEngine.threadIndex(), this.name, newSize, this.name, removedKey, newSize });
/*     */           }
/*     */         }
/* 465 */         this.fifo[this.fifoPointer] = key;
/* 466 */         this.fifoPointer = ((this.fifoPointer + 1) % this.maxSize);
/*     */       }
/*     */       
/* 469 */       return this.container.size();
/*     */     }
/*     */     
/*     */ 
/*     */     public int remove(K key)
/*     */     {
/* 475 */       if (this.traceExecution) {
/* 476 */         return removeWithTracing(key);
/*     */       }
/* 478 */       return removeWithoutTracing(key);
/*     */     }
/*     */     
/*     */ 
/*     */     private int removeWithoutTracing(K key)
/*     */     {
/* 484 */       StandardCache.CacheEntry<V> removed = (StandardCache.CacheEntry)this.container.remove(key);
/* 485 */       if ((removed != null) && 
/* 486 */         (this.sizeLimit) && (key != null)) {
/* 487 */         for (int i = 0; i < this.maxSize; i++) {
/* 488 */           if (key.equals(this.fifo[i])) {
/* 489 */             this.fifo[i] = null;
/* 490 */             break;
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 495 */       return -1;
/*     */     }
/*     */     
/*     */ 
/*     */     private synchronized int removeWithTracing(K key)
/*     */     {
/* 501 */       StandardCache.CacheEntry<V> removed = (StandardCache.CacheEntry)this.container.remove(key);
/* 502 */       if (removed == null)
/*     */       {
/* 504 */         return -1;
/*     */       }
/* 506 */       if ((this.sizeLimit) && (key != null)) {
/* 507 */         for (int i = 0; i < this.maxSize; i++) {
/* 508 */           if (key.equals(this.fifo[i])) {
/* 509 */             this.fifo[i] = null;
/* 510 */             break;
/*     */           }
/*     */         }
/*     */       }
/* 514 */       return this.container.size();
/*     */     }
/*     */     
/*     */     public void clear()
/*     */     {
/* 519 */       this.container.clear();
/*     */     }
/*     */     
/*     */     public int size()
/*     */     {
/* 524 */       return this.container.size();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static final class CacheEntry<V>
/*     */   {
/*     */     private final SoftReference<V> cachedValueReference;
/*     */     
/*     */ 
/*     */ 
/*     */     private final long creationTimeInMillis;
/*     */     
/*     */ 
/*     */ 
/*     */     private final V cachedValueAnchor;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     CacheEntry(V cachedValue, boolean useSoftReferences)
/*     */     {
/* 548 */       this.cachedValueReference = new SoftReference(cachedValue);
/* 549 */       this.cachedValueAnchor = (!useSoftReferences ? cachedValue : null);
/* 550 */       this.creationTimeInMillis = System.currentTimeMillis();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public <K> V getValueIfStillValid(String cacheMapName, K key, ICacheEntryValidityChecker<? super K, ? super V> checker, boolean traceExecution, Logger logger)
/*     */     {
/* 558 */       V cachedValue = this.cachedValueReference.get();
/*     */       
/* 560 */       if (cachedValue == null)
/*     */       {
/* 562 */         if (traceExecution) {
/* 563 */           logger.trace("[THYMELEAF][{}][*][{}][CACHE_DELETED_REFERENCES] Some entries at cache \"{}\" seem to have been sacrificed by the Garbage Collector (soft references).", new Object[] {
/*     */           
/*     */ 
/* 566 */             TemplateEngine.threadIndex(), cacheMapName, cacheMapName });
/*     */         }
/* 568 */         return null;
/*     */       }
/* 570 */       if ((checker == null) || (checker.checkIsValueStillValid(key, cachedValue, this.creationTimeInMillis))) {
/* 571 */         return cachedValue;
/*     */       }
/* 573 */       return null;
/*     */     }
/*     */     
/*     */     public long getCreationTimeInMillis() {
/* 577 */       return this.creationTimeInMillis;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\thymeleaf-3.0.12.RELEASE.jar!\org\thymeleaf\cache\StandardCache.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */