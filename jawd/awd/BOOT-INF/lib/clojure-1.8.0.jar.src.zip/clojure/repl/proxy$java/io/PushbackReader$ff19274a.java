package clojure.repl.proxy$java.io;

import clojure.lang.IPersistentCollection;
import clojure.lang.IPersistentMap;
import clojure.lang.IProxy;
import java.io.PushbackReader;
import java.io.Reader;

public class PushbackReader$ff19274a
  extends PushbackReader
  implements IProxy
{
  private volatile IPersistentMap __clojureFnMap;
  
  public PushbackReader$ff19274a(Reader paramReader, int paramInt)
  {
    super(paramReader, paramInt);
  }
  
  public PushbackReader$ff19274a(Reader paramReader)
  {
    super(paramReader);
  }
  
  public void __initClojureFnMappings(IPersistentMap paramIPersistentMap)
  {
    this.__clojureFnMap = paramIPersistentMap;
  }
  
  public void __updateClojureFnMappings(IPersistentMap paramIPersistentMap)
  {
    this.__clojureFnMap = ((IPersistentMap)((IPersistentCollection)this.__clojureFnMap).cons(paramIPersistentMap));
  }
  
  public IPersistentMap __getClojureFnMappings()
  {
    return this.__clojureFnMap;
  }
  
  /* Error */
  public boolean equals(Object arg1)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 19	clojure/repl/proxy$java/io/PushbackReader$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 33
    //   6: invokestatic 39	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +22 -> 32
    //   13: checkcast 41	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: invokeinterface 44 3 0
    //   23: checkcast 46	java/lang/Boolean
    //   26: invokevirtual 50	java/lang/Boolean:booleanValue	()Z
    //   29: goto +9 -> 38
    //   32: pop
    //   33: aload_0
    //   34: aload_1
    //   35: invokespecial 52	java/io/PushbackReader:equals	(Ljava/lang/Object;)Z
    //   38: ireturn
  }
  
  /* Error */
  public String toString()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 19	clojure/repl/proxy$java/io/PushbackReader$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 55
    //   6: invokestatic 39	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +18 -> 28
    //   13: checkcast 41	clojure/lang/IFn
    //   16: aload_0
    //   17: invokeinterface 58 2 0
    //   22: checkcast 60	java/lang/String
    //   25: goto +8 -> 33
    //   28: pop
    //   29: aload_0
    //   30: invokespecial 62	java/io/PushbackReader:toString	()Ljava/lang/String;
    //   33: areturn
  }
  
  /* Error */
  public long skip(long arg1)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 19	clojure/repl/proxy$java/io/PushbackReader$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 65
    //   6: invokestatic 39	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +25 -> 35
    //   13: checkcast 41	clojure/lang/IFn
    //   16: aload_0
    //   17: lload_1
    //   18: invokestatic 71	clojure/lang/Numbers:num	(J)Ljava/lang/Number;
    //   21: invokeinterface 44 3 0
    //   26: checkcast 73	java/lang/Number
    //   29: invokevirtual 77	java/lang/Number:longValue	()J
    //   32: goto +9 -> 41
    //   35: pop
    //   36: aload_0
    //   37: lload_1
    //   38: invokespecial 79	java/io/PushbackReader:skip	(J)J
    //   41: lreturn
  }
  
  /* Error */
  public void close()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 19	clojure/repl/proxy$java/io/PushbackReader$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 82
    //   6: invokestatic 39	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +16 -> 26
    //   13: checkcast 41	clojure/lang/IFn
    //   16: aload_0
    //   17: invokeinterface 58 2 0
    //   22: pop
    //   23: goto +8 -> 31
    //   26: pop
    //   27: aload_0
    //   28: invokespecial 84	java/io/PushbackReader:close	()V
    //   31: return
  }
  
  /* Error */
  public void unread(char[] arg1)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 19	clojure/repl/proxy$java/io/PushbackReader$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 87
    //   6: invokestatic 39	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +17 -> 27
    //   13: checkcast 41	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: invokeinterface 44 3 0
    //   23: pop
    //   24: goto +9 -> 33
    //   27: pop
    //   28: aload_0
    //   29: aload_1
    //   30: invokespecial 89	java/io/PushbackReader:unread	([C)V
    //   33: return
  }
  
  /* Error */
  public boolean ready()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 19	clojure/repl/proxy$java/io/PushbackReader$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 91
    //   6: invokestatic 39	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +21 -> 31
    //   13: checkcast 41	clojure/lang/IFn
    //   16: aload_0
    //   17: invokeinterface 58 2 0
    //   22: checkcast 46	java/lang/Boolean
    //   25: invokevirtual 50	java/lang/Boolean:booleanValue	()Z
    //   28: goto +8 -> 36
    //   31: pop
    //   32: aload_0
    //   33: invokespecial 93	java/io/PushbackReader:ready	()Z
    //   36: ireturn
  }
  
  /* Error */
  public void mark(int arg1)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 19	clojure/repl/proxy$java/io/PushbackReader$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 96
    //   6: invokestatic 39	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +20 -> 30
    //   13: checkcast 41	clojure/lang/IFn
    //   16: aload_0
    //   17: iload_1
    //   18: invokestatic 102	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   21: invokeinterface 44 3 0
    //   26: pop
    //   27: goto +9 -> 36
    //   30: pop
    //   31: aload_0
    //   32: iload_1
    //   33: invokespecial 104	java/io/PushbackReader:mark	(I)V
    //   36: return
  }
  
  /* Error */
  public int read()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 19	clojure/repl/proxy$java/io/PushbackReader$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 107
    //   6: invokestatic 39	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +21 -> 31
    //   13: checkcast 41	clojure/lang/IFn
    //   16: aload_0
    //   17: invokeinterface 58 2 0
    //   22: checkcast 73	java/lang/Number
    //   25: invokevirtual 110	java/lang/Number:intValue	()I
    //   28: goto +8 -> 36
    //   31: pop
    //   32: aload_0
    //   33: invokespecial 112	java/io/PushbackReader:read	()I
    //   36: ireturn
  }
  
  /* Error */
  public void unread(char[] arg1, int arg2, int arg3)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 19	clojure/repl/proxy$java/io/PushbackReader$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 87
    //   6: invokestatic 39	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +25 -> 35
    //   13: checkcast 41	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: iload_2
    //   19: invokestatic 102	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   22: iload_3
    //   23: invokestatic 102	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   26: invokeinterface 116 5 0
    //   31: pop
    //   32: goto +11 -> 43
    //   35: pop
    //   36: aload_0
    //   37: aload_1
    //   38: iload_2
    //   39: iload_3
    //   40: invokespecial 118	java/io/PushbackReader:unread	([CII)V
    //   43: return
  }
  
  /* Error */
  public int hashCode()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 19	clojure/repl/proxy$java/io/PushbackReader$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 120
    //   6: invokestatic 39	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +21 -> 31
    //   13: checkcast 41	clojure/lang/IFn
    //   16: aload_0
    //   17: invokeinterface 58 2 0
    //   22: checkcast 73	java/lang/Number
    //   25: invokevirtual 110	java/lang/Number:intValue	()I
    //   28: goto +8 -> 36
    //   31: pop
    //   32: aload_0
    //   33: invokespecial 122	java/io/PushbackReader:hashCode	()I
    //   36: ireturn
  }
  
  /* Error */
  public void unread(int arg1)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 19	clojure/repl/proxy$java/io/PushbackReader$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 87
    //   6: invokestatic 39	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +20 -> 30
    //   13: checkcast 41	clojure/lang/IFn
    //   16: aload_0
    //   17: iload_1
    //   18: invokestatic 102	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   21: invokeinterface 44 3 0
    //   26: pop
    //   27: goto +9 -> 36
    //   30: pop
    //   31: aload_0
    //   32: iload_1
    //   33: invokespecial 124	java/io/PushbackReader:unread	(I)V
    //   36: return
  }
  
  /* Error */
  public int read(char[] arg1, int arg2, int arg3)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 19	clojure/repl/proxy$java/io/PushbackReader$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 107
    //   6: invokestatic 39	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +30 -> 40
    //   13: checkcast 41	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: iload_2
    //   19: invokestatic 102	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   22: iload_3
    //   23: invokestatic 102	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   26: invokeinterface 116 5 0
    //   31: checkcast 73	java/lang/Number
    //   34: invokevirtual 110	java/lang/Number:intValue	()I
    //   37: goto +11 -> 48
    //   40: pop
    //   41: aload_0
    //   42: aload_1
    //   43: iload_2
    //   44: iload_3
    //   45: invokespecial 127	java/io/PushbackReader:read	([CII)I
    //   48: ireturn
  }
  
  /* Error */
  public int read(char[] arg1)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 19	clojure/repl/proxy$java/io/PushbackReader$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 107
    //   6: invokestatic 39	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +22 -> 32
    //   13: checkcast 41	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: invokeinterface 44 3 0
    //   23: checkcast 73	java/lang/Number
    //   26: invokevirtual 110	java/lang/Number:intValue	()I
    //   29: goto +9 -> 38
    //   32: pop
    //   33: aload_0
    //   34: aload_1
    //   35: invokespecial 130	java/io/PushbackReader:read	([C)I
    //   38: ireturn
  }
  
  /* Error */
  public int read(java.nio.CharBuffer arg1)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 19	clojure/repl/proxy$java/io/PushbackReader$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 107
    //   6: invokestatic 39	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +22 -> 32
    //   13: checkcast 41	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: invokeinterface 44 3 0
    //   23: checkcast 73	java/lang/Number
    //   26: invokevirtual 110	java/lang/Number:intValue	()I
    //   29: goto +9 -> 38
    //   32: pop
    //   33: aload_0
    //   34: aload_1
    //   35: invokespecial 133	java/io/PushbackReader:read	(Ljava/nio/CharBuffer;)I
    //   38: ireturn
  }
  
  /* Error */
  public void reset()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 19	clojure/repl/proxy$java/io/PushbackReader$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc -121
    //   6: invokestatic 39	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +16 -> 26
    //   13: checkcast 41	clojure/lang/IFn
    //   16: aload_0
    //   17: invokeinterface 58 2 0
    //   22: pop
    //   23: goto +8 -> 31
    //   26: pop
    //   27: aload_0
    //   28: invokespecial 137	java/io/PushbackReader:reset	()V
    //   31: return
  }
  
  /* Error */
  public boolean markSupported()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 19	clojure/repl/proxy$java/io/PushbackReader$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc -117
    //   6: invokestatic 39	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +21 -> 31
    //   13: checkcast 41	clojure/lang/IFn
    //   16: aload_0
    //   17: invokeinterface 58 2 0
    //   22: checkcast 46	java/lang/Boolean
    //   25: invokevirtual 50	java/lang/Boolean:booleanValue	()Z
    //   28: goto +8 -> 36
    //   31: pop
    //   32: aload_0
    //   33: invokespecial 141	java/io/PushbackReader:markSupported	()Z
    //   36: ireturn
  }
  
  /* Error */
  public Object clone()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 19	clojure/repl/proxy$java/io/PushbackReader$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc -112
    //   6: invokestatic 39	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +15 -> 25
    //   13: checkcast 41	clojure/lang/IFn
    //   16: aload_0
    //   17: invokeinterface 58 2 0
    //   22: goto +8 -> 30
    //   25: pop
    //   26: aload_0
    //   27: invokespecial 146	java/io/PushbackReader:clone	()Ljava/lang/Object;
    //   30: areturn
  }
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\repl\proxy$java\io\PushbackReader$ff19274a.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */