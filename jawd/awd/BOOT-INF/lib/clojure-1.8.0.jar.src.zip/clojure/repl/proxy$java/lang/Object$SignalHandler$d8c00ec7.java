package clojure.repl.proxy$java.lang;

import clojure.lang.IPersistentCollection;
import clojure.lang.IPersistentMap;
import clojure.lang.IProxy;
import sun.misc.SignalHandler;

public class Object$SignalHandler$d8c00ec7
  implements IProxy, SignalHandler
{
  private volatile IPersistentMap __clojureFnMap;
  
  public void __initClojureFnMappings(IPersistentMap paramIPersistentMap)
  {
    this.__clojureFnMap = paramIPersistentMap;
  }
  
  public void __updateClojureFnMappings(IPersistentMap paramIPersistentMap)
  {
    this.__clojureFnMap = ((IPersistentMap)((IPersistentCollection)this.__clojureFnMap).cons(paramIPersistentMap));
  }
  
  public IPersistentMap __getClojureFnMappings()
  {
    return this.__clojureFnMap;
  }
  
  /* Error */
  public boolean equals(Object arg1)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 18	clojure/repl/proxy$java/lang/Object$SignalHandler$d8c00ec7:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 32
    //   6: invokestatic 38	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +22 -> 32
    //   13: checkcast 40	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: invokeinterface 43 3 0
    //   23: checkcast 45	java/lang/Boolean
    //   26: invokevirtual 49	java/lang/Boolean:booleanValue	()Z
    //   29: goto +9 -> 38
    //   32: pop
    //   33: aload_0
    //   34: aload_1
    //   35: invokespecial 51	java/lang/Object:equals	(Ljava/lang/Object;)Z
    //   38: ireturn
  }
  
  /* Error */
  public String toString()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 18	clojure/repl/proxy$java/lang/Object$SignalHandler$d8c00ec7:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 54
    //   6: invokestatic 38	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +18 -> 28
    //   13: checkcast 40	clojure/lang/IFn
    //   16: aload_0
    //   17: invokeinterface 57 2 0
    //   22: checkcast 59	java/lang/String
    //   25: goto +8 -> 33
    //   28: pop
    //   29: aload_0
    //   30: invokespecial 61	java/lang/Object:toString	()Ljava/lang/String;
    //   33: areturn
  }
  
  /* Error */
  public int hashCode()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 18	clojure/repl/proxy$java/lang/Object$SignalHandler$d8c00ec7:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 64
    //   6: invokestatic 38	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +21 -> 31
    //   13: checkcast 40	clojure/lang/IFn
    //   16: aload_0
    //   17: invokeinterface 57 2 0
    //   22: checkcast 66	java/lang/Number
    //   25: invokevirtual 69	java/lang/Number:intValue	()I
    //   28: goto +8 -> 36
    //   31: pop
    //   32: aload_0
    //   33: invokespecial 71	java/lang/Object:hashCode	()I
    //   36: ireturn
  }
  
  /* Error */
  public Object clone()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 18	clojure/repl/proxy$java/lang/Object$SignalHandler$d8c00ec7:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 74
    //   6: invokestatic 38	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +15 -> 25
    //   13: checkcast 40	clojure/lang/IFn
    //   16: aload_0
    //   17: invokeinterface 57 2 0
    //   22: goto +8 -> 30
    //   25: pop
    //   26: aload_0
    //   27: invokespecial 76	java/lang/Object:clone	()Ljava/lang/Object;
    //   30: areturn
  }
  
  /* Error */
  public void handle(sun.misc.Signal arg1)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 18	clojure/repl/proxy$java/lang/Object$SignalHandler$d8c00ec7:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 79
    //   6: invokestatic 38	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +17 -> 27
    //   13: checkcast 40	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: invokeinterface 43 3 0
    //   23: pop
    //   24: goto +14 -> 38
    //   27: pop
    //   28: new 81	java/lang/UnsupportedOperationException
    //   31: dup
    //   32: ldc 79
    //   34: invokespecial 84	java/lang/UnsupportedOperationException:<init>	(Ljava/lang/String;)V
    //   37: athrow
    //   38: return
  }
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\repl\proxy$java\lang\Object$SignalHandler$d8c00ec7.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */