/*    */ package clojure.core;
/*    */ 
/*    */ import clojure.core.apply;
/*    */ import clojure.core.concat;
/*    */ import clojure.core.seq__4357;
/*    */ import clojure.core.with_meta__4375;
/*    */ import clojure.lang.AFn;
/*    */ import clojure.lang.ArraySeq;
/*    */ import clojure.lang.ISeq;
/*    */ import clojure.lang.PersistentList.Primordial;
/*    */ import clojure.lang.RT;
/*    */ import clojure.lang.RestFn;
/*    */ import clojure.lang.Symbol;
/*    */ import clojure.lang.Var;
/*    */ 
/*    */ public final class server$with_lock
/*    */   extends RestFn
/*    */ {
/*    */   public int getRequiredArity()
/*    */   {
/*    */     return 3;
/*    */   }
/*    */   
/*    */   public Object doInvoke(Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4)
/*    */   {
/* 26 */     paramObject1 = null;paramObject2 = null;paramObject3 = null;paramObject4 = null;return invokeStatic(paramObject1, paramObject2, paramObject3, (ISeq)paramObject4); } public static Object invokeStatic(Object _AMPERSAND_form, Object _AMPERSAND_env, Object lock_expr, ISeq body) { Object[] tmp20_17 = new Object[1]; Object[] tmp48_45 = new Object[1];lock_expr = null;tmp48_45[0] = core.with_meta__4375.invokeStatic(lock_expr, const__10);tmp20_17[0] = core.apply.invokeStatic(const__5.getRawRoot(), core.seq__4357.invokeStatic(core.concat.invokeStatic(PersistentList.Primordial.invokeStatic(ArraySeq.create(new Object[] { const__6 })), PersistentList.Primordial.invokeStatic(ArraySeq.create(tmp48_45))))); Object[] tmp146_143 = new Object[1];body = null;tmp146_143[0] = core.seq__4357.invokeStatic(core.concat.invokeStatic(PersistentList.Primordial.invokeStatic(ArraySeq.create(new Object[] { const__12 })), body, ArraySeq.create(new Object[] { PersistentList.Primordial.invokeStatic(ArraySeq.create(new Object[] { core.seq__4357.invokeStatic(core.concat.invokeStatic(PersistentList.Primordial.invokeStatic(ArraySeq.create(new Object[] { const__13 })), PersistentList.Primordial.invokeStatic(ArraySeq.create(new Object[] { core.seq__4357.invokeStatic(core.concat.invokeStatic(PersistentList.Primordial.invokeStatic(ArraySeq.create(new Object[] { const__14 })), PersistentList.Primordial.invokeStatic(ArraySeq.create(new Object[] { const__6 })))) })))) })) })));{ PersistentList.Primordial.invokeStatic(ArraySeq.create(new Object[] { core.seq__4357.invokeStatic(core.concat.invokeStatic(PersistentList.Primordial.invokeStatic(ArraySeq.create(new Object[] { const__11 })), PersistentList.Primordial.invokeStatic(ArraySeq.create(new Object[] { const__6 })))) })) }[1] = PersistentList.Primordial.invokeStatic(ArraySeq.create(tmp146_143));return core.seq__4357.invokeStatic(core.concat.invokeStatic(PersistentList.Primordial.invokeStatic(ArraySeq.create(new Object[] { const__3 })), PersistentList.Primordial.invokeStatic(ArraySeq.create(tmp20_17)), ArraySeq.create(tmp140_86))); } public static final AFn const__14 = (AFn)Symbol.intern(null, ".unlock"); public static final AFn const__13 = (AFn)Symbol.intern(null, "finally"); public static final AFn const__12 = (AFn)Symbol.intern(null, "try"); public static final AFn const__11 = (AFn)Symbol.intern(null, ".lock"); public static final AFn const__10 = (AFn)RT.map(new Object[] { RT.keyword(null, "tag"), Symbol.intern(null, "java.util.concurrent.locks.ReentrantLock") }); public static final AFn const__6 = (AFn)Symbol.intern(null, "lockee__7306__auto__"); public static final Var const__5 = (Var)RT.var("clojure.core", "vector"); public static final AFn const__3 = (AFn)Symbol.intern("clojure.core", "let");
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\core\server$with_lock.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */