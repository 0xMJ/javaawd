/*    */ package clojure.core;
/*    */ 
/*    */ import clojure.lang.AFunction;
/*    */ import clojure.lang.RT;
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class protocols$fn__6684$G__6679__6697
/*    */   extends AFunction
/*    */ {
/*    */   Object G__6680;
/*    */   
/* 13 */   public protocols$fn__6684$G__6679__6697(Object paramObject) { this.G__6680 = paramObject; } public static final Object const__1 = RT.classForName("clojure.core.protocols.CollReduce");
/*    */   
/*    */   /* Error */
/*    */   public Object invoke(Object gf__coll__6694, Object gf__f__6695, Object gf__val__6696)
/*    */   {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: checkcast 4	clojure/lang/AFunction
/*    */     //   4: getfield 20	clojure/lang/AFunction:__methodImplCache	Lclojure/lang/MethodImplCache;
/*    */     //   7: astore 4
/*    */     //   9: aload 4
/*    */     //   11: aconst_null
/*    */     //   12: astore 4
/*    */     //   14: checkcast 22	clojure/lang/MethodImplCache
/*    */     //   17: aload_1
/*    */     //   18: invokestatic 28	clojure/lang/Util:classOf	(Ljava/lang/Object;)Ljava/lang/Class;
/*    */     //   21: checkcast 30	java/lang/Class
/*    */     //   24: invokevirtual 34	clojure/lang/MethodImplCache:fnFor	(Ljava/lang/Class;)Lclojure/lang/IFn;
/*    */     //   27: astore 5
/*    */     //   29: aload 5
/*    */     //   31: dup
/*    */     //   32: ifnull +34 -> 66
/*    */     //   35: getstatic 40	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*    */     //   38: if_acmpeq +29 -> 67
/*    */     //   41: aload 5
/*    */     //   43: aconst_null
/*    */     //   44: astore 5
/*    */     //   46: checkcast 42	clojure/lang/IFn
/*    */     //   49: aload_1
/*    */     //   50: aconst_null
/*    */     //   51: astore_1
/*    */     //   52: aload_2
/*    */     //   53: aconst_null
/*    */     //   54: astore_2
/*    */     //   55: aload_3
/*    */     //   56: aconst_null
/*    */     //   57: astore_3
/*    */     //   58: invokeinterface 44 4 0
/*    */     //   63: goto +33 -> 96
/*    */     //   66: pop
/*    */     //   67: aload_0
/*    */     //   68: aload_1
/*    */     //   69: getstatic 47	clojure/core/protocols$fn__6684$G__6679__6697:const__1	Ljava/lang/Object;
/*    */     //   72: aload_0
/*    */     //   73: getfield 14	clojure/core/protocols$fn__6684$G__6679__6697:G__6680	Ljava/lang/Object;
/*    */     //   76: invokestatic 53	clojure/core$_cache_protocol_fn:invokeStatic	(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   79: checkcast 42	clojure/lang/IFn
/*    */     //   82: aload_1
/*    */     //   83: aconst_null
/*    */     //   84: astore_1
/*    */     //   85: aload_2
/*    */     //   86: aconst_null
/*    */     //   87: astore_2
/*    */     //   88: aload_3
/*    */     //   89: aconst_null
/*    */     //   90: astore_3
/*    */     //   91: invokeinterface 44 4 0
/*    */     //   96: areturn
/*    */     // Line number table:
/*    */     //   Java source line #13	-> byte code offset #0
/*    */     //   Java source line #13	-> byte code offset #1
/*    */     //   Java source line #13	-> byte code offset #18
/*    */     //   Java source line #13	-> byte code offset #24
/*    */     //   Java source line #13	-> byte code offset #29
/*    */     //   Java source line #13	-> byte code offset #46
/*    */     //   Java source line #13	-> byte code offset #58
/*    */     //   Java source line #13	-> byte code offset #79
/*    */     //   Java source line #13	-> byte code offset #91
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	signature
/*    */     //   0	96	0	this	Object
/*    */     //   0	96	1	gf__coll__6694	Object
/*    */     //   0	96	2	gf__f__6695	Object
/*    */     //   0	96	3	gf__val__6696	Object
/*    */     //   9	87	4	cache__6568__auto__6699	Object
/*    */     //   29	67	5	f__6569__auto__6700	Object
/*    */   }
/*    */   
/*    */   /* Error */
/*    */   public Object invoke(Object gf__coll__6692, Object gf__f__6693)
/*    */   {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: checkcast 4	clojure/lang/AFunction
/*    */     //   4: getfield 20	clojure/lang/AFunction:__methodImplCache	Lclojure/lang/MethodImplCache;
/*    */     //   7: astore_3
/*    */     //   8: aload_3
/*    */     //   9: aconst_null
/*    */     //   10: astore_3
/*    */     //   11: checkcast 22	clojure/lang/MethodImplCache
/*    */     //   14: aload_1
/*    */     //   15: invokestatic 28	clojure/lang/Util:classOf	(Ljava/lang/Object;)Ljava/lang/Class;
/*    */     //   18: checkcast 30	java/lang/Class
/*    */     //   21: invokevirtual 34	clojure/lang/MethodImplCache:fnFor	(Ljava/lang/Class;)Lclojure/lang/IFn;
/*    */     //   24: astore 4
/*    */     //   26: aload 4
/*    */     //   28: dup
/*    */     //   29: ifnull +31 -> 60
/*    */     //   32: getstatic 40	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*    */     //   35: if_acmpeq +26 -> 61
/*    */     //   38: aload 4
/*    */     //   40: aconst_null
/*    */     //   41: astore 4
/*    */     //   43: checkcast 42	clojure/lang/IFn
/*    */     //   46: aload_1
/*    */     //   47: aconst_null
/*    */     //   48: astore_1
/*    */     //   49: aload_2
/*    */     //   50: aconst_null
/*    */     //   51: astore_2
/*    */     //   52: invokeinterface 62 3 0
/*    */     //   57: goto +30 -> 87
/*    */     //   60: pop
/*    */     //   61: aload_0
/*    */     //   62: aload_1
/*    */     //   63: getstatic 47	clojure/core/protocols$fn__6684$G__6679__6697:const__1	Ljava/lang/Object;
/*    */     //   66: aload_0
/*    */     //   67: getfield 14	clojure/core/protocols$fn__6684$G__6679__6697:G__6680	Ljava/lang/Object;
/*    */     //   70: invokestatic 53	clojure/core$_cache_protocol_fn:invokeStatic	(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   73: checkcast 42	clojure/lang/IFn
/*    */     //   76: aload_1
/*    */     //   77: aconst_null
/*    */     //   78: astore_1
/*    */     //   79: aload_2
/*    */     //   80: aconst_null
/*    */     //   81: astore_2
/*    */     //   82: invokeinterface 62 3 0
/*    */     //   87: areturn
/*    */     // Line number table:
/*    */     //   Java source line #13	-> byte code offset #0
/*    */     //   Java source line #13	-> byte code offset #1
/*    */     //   Java source line #13	-> byte code offset #15
/*    */     //   Java source line #13	-> byte code offset #21
/*    */     //   Java source line #13	-> byte code offset #26
/*    */     //   Java source line #13	-> byte code offset #43
/*    */     //   Java source line #13	-> byte code offset #52
/*    */     //   Java source line #13	-> byte code offset #73
/*    */     //   Java source line #13	-> byte code offset #82
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	signature
/*    */     //   0	87	0	this	Object
/*    */     //   0	87	1	gf__coll__6692	Object
/*    */     //   0	87	2	gf__f__6693	Object
/*    */     //   8	79	3	cache__6568__auto__6701	Object
/*    */     //   26	61	4	f__6569__auto__6702	Object
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\core\protocols$fn__6684$G__6679__6697.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */