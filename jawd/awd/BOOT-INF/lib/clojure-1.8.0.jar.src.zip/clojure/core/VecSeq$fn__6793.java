/*    */ package clojure.core;
/*    */ 
/*    */ import clojure.lang.AFunction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class VecSeq$fn__6793
/*    */   extends AFunction
/*    */ {
/*    */   Object am;
/*    */   Object result;
/*    */   Object node;
/*    */   Object f;
/*    */   long aidx;
/*    */   
/*    */   public VecSeq$fn__6793(Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4, long paramLong)
/*    */   {
/* 68 */     this.am = paramObject1;this.result = paramObject2;this.node = paramObject3;this.f = paramObject4;this.aidx = paramLong;
/*    */   }
/*    */   
/*    */   /* Error */
/*    */   public Object invoke()
/*    */   {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: getfield 21	clojure/core/VecSeq$fn__6793:result	Ljava/lang/Object;
/*    */     //   4: astore_1
/*    */     //   5: ldc2_w 30
/*    */     //   8: aload_0
/*    */     //   9: getfield 27	clojure/core/VecSeq$fn__6793:aidx	J
/*    */     //   12: land
/*    */     //   13: lstore_2
/*    */     //   14: lload_2
/*    */     //   15: aload_0
/*    */     //   16: getfield 19	clojure/core/VecSeq$fn__6793:am	Ljava/lang/Object;
/*    */     //   19: checkcast 33	clojure/core/ArrayManager
/*    */     //   22: aload_0
/*    */     //   23: getfield 23	clojure/core/VecSeq$fn__6793:node	Ljava/lang/Object;
/*    */     //   26: invokeinterface 37 2 0
/*    */     //   31: i2l
/*    */     //   32: lcmp
/*    */     //   33: ifge +75 -> 108
/*    */     //   36: aload_0
/*    */     //   37: getfield 25	clojure/core/VecSeq$fn__6793:f	Ljava/lang/Object;
/*    */     //   40: checkcast 39	clojure/lang/IFn
/*    */     //   43: aload_1
/*    */     //   44: aconst_null
/*    */     //   45: astore_1
/*    */     //   46: aload_0
/*    */     //   47: getfield 19	clojure/core/VecSeq$fn__6793:am	Ljava/lang/Object;
/*    */     //   50: checkcast 33	clojure/core/ArrayManager
/*    */     //   53: aload_0
/*    */     //   54: getfield 23	clojure/core/VecSeq$fn__6793:node	Ljava/lang/Object;
/*    */     //   57: lload_2
/*    */     //   58: invokestatic 45	clojure/lang/RT:intCast	(J)I
/*    */     //   61: invokeinterface 49 3 0
/*    */     //   66: invokeinterface 52 3 0
/*    */     //   71: astore 4
/*    */     //   73: aload 4
/*    */     //   75: invokestatic 56	clojure/lang/RT:isReduced	(Ljava/lang/Object;)Z
/*    */     //   78: ifeq +12 -> 90
/*    */     //   81: aload 4
/*    */     //   83: aconst_null
/*    */     //   84: astore 4
/*    */     //   86: goto +18 -> 104
/*    */     //   89: pop
/*    */     //   90: aload 4
/*    */     //   92: aconst_null
/*    */     //   93: astore 4
/*    */     //   95: lload_2
/*    */     //   96: invokestatic 62	clojure/lang/Numbers:inc	(J)J
/*    */     //   99: lstore_2
/*    */     //   100: astore_1
/*    */     //   101: goto -87 -> 14
/*    */     //   104: goto +7 -> 111
/*    */     //   107: pop
/*    */     //   108: aload_1
/*    */     //   109: aconst_null
/*    */     //   110: astore_1
/*    */     //   111: areturn
/*    */     // Line number table:
/*    */     //   Java source line #68	-> byte code offset #0
/*    */     //   Java source line #69	-> byte code offset #12
/*    */     //   Java source line #70	-> byte code offset #14
/*    */     //   Java source line #70	-> byte code offset #14
/*    */     //   Java source line #70	-> byte code offset #26
/*    */     //   Java source line #71	-> byte code offset #40
/*    */     //   Java source line #71	-> byte code offset #61
/*    */     //   Java source line #71	-> byte code offset #66
/*    */     //   Java source line #72	-> byte code offset #73
/*    */     //   Java source line #72	-> byte code offset #75
/*    */     //   Java source line #74	-> byte code offset #96
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	signature
/*    */     //   0	111	0	this	Object
/*    */     //   5	106	1	result	Object
/*    */     //   14	97	2	node_idx	long
/*    */     //   73	31	4	result	Object
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\core\VecSeq$fn__6793.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */