/*    */ package clojure.core;
/*    */ 
/*    */ import clojure.lang.AFunction;
/*    */ import clojure.lang.RT;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class protocols$fn__6710$G__6705__6719
/*    */   extends AFunction
/*    */ {
/*    */   Object G__6706;
/*    */   
/* 19 */   public protocols$fn__6710$G__6705__6719(Object paramObject) { this.G__6706 = paramObject; } public static final Object const__1 = RT.classForName("clojure.core.protocols.InternalReduce");
/*    */   
/*    */   /* Error */
/*    */   public Object invoke(Object gf__seq__6716, Object gf__f__6717, Object gf__start__6718)
/*    */   {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: checkcast 4	clojure/lang/AFunction
/*    */     //   4: getfield 20	clojure/lang/AFunction:__methodImplCache	Lclojure/lang/MethodImplCache;
/*    */     //   7: astore 4
/*    */     //   9: aload 4
/*    */     //   11: aconst_null
/*    */     //   12: astore 4
/*    */     //   14: checkcast 22	clojure/lang/MethodImplCache
/*    */     //   17: aload_1
/*    */     //   18: invokestatic 28	clojure/lang/Util:classOf	(Ljava/lang/Object;)Ljava/lang/Class;
/*    */     //   21: checkcast 30	java/lang/Class
/*    */     //   24: invokevirtual 34	clojure/lang/MethodImplCache:fnFor	(Ljava/lang/Class;)Lclojure/lang/IFn;
/*    */     //   27: astore 5
/*    */     //   29: aload 5
/*    */     //   31: dup
/*    */     //   32: ifnull +34 -> 66
/*    */     //   35: getstatic 40	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*    */     //   38: if_acmpeq +29 -> 67
/*    */     //   41: aload 5
/*    */     //   43: aconst_null
/*    */     //   44: astore 5
/*    */     //   46: checkcast 42	clojure/lang/IFn
/*    */     //   49: aload_1
/*    */     //   50: aconst_null
/*    */     //   51: astore_1
/*    */     //   52: aload_2
/*    */     //   53: aconst_null
/*    */     //   54: astore_2
/*    */     //   55: aload_3
/*    */     //   56: aconst_null
/*    */     //   57: astore_3
/*    */     //   58: invokeinterface 44 4 0
/*    */     //   63: goto +33 -> 96
/*    */     //   66: pop
/*    */     //   67: aload_0
/*    */     //   68: aload_1
/*    */     //   69: getstatic 47	clojure/core/protocols$fn__6710$G__6705__6719:const__1	Ljava/lang/Object;
/*    */     //   72: aload_0
/*    */     //   73: getfield 14	clojure/core/protocols$fn__6710$G__6705__6719:G__6706	Ljava/lang/Object;
/*    */     //   76: invokestatic 53	clojure/core$_cache_protocol_fn:invokeStatic	(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   79: checkcast 42	clojure/lang/IFn
/*    */     //   82: aload_1
/*    */     //   83: aconst_null
/*    */     //   84: astore_1
/*    */     //   85: aload_2
/*    */     //   86: aconst_null
/*    */     //   87: astore_2
/*    */     //   88: aload_3
/*    */     //   89: aconst_null
/*    */     //   90: astore_3
/*    */     //   91: invokeinterface 44 4 0
/*    */     //   96: areturn
/*    */     // Line number table:
/*    */     //   Java source line #19	-> byte code offset #0
/*    */     //   Java source line #19	-> byte code offset #1
/*    */     //   Java source line #19	-> byte code offset #18
/*    */     //   Java source line #19	-> byte code offset #24
/*    */     //   Java source line #19	-> byte code offset #29
/*    */     //   Java source line #19	-> byte code offset #46
/*    */     //   Java source line #19	-> byte code offset #58
/*    */     //   Java source line #19	-> byte code offset #79
/*    */     //   Java source line #19	-> byte code offset #91
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	signature
/*    */     //   0	96	0	this	Object
/*    */     //   0	96	1	gf__seq__6716	Object
/*    */     //   0	96	2	gf__f__6717	Object
/*    */     //   0	96	3	gf__start__6718	Object
/*    */     //   9	87	4	cache__6568__auto__6721	Object
/*    */     //   29	67	5	f__6569__auto__6722	Object
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\core\protocols$fn__6710$G__6705__6719.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */