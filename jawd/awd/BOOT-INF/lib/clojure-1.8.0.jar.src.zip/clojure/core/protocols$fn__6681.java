/*    */ package clojure.core;
/*    */ 
/*    */ import clojure.lang.AFn;
/*    */ import clojure.lang.AFunction;
/*    */ import clojure.lang.RT;
/*    */ import clojure.lang.Var;
/*    */ 
/*    */ public final class protocols$fn__6681
/*    */   extends AFunction
/*    */ {
/*    */   /* Error */
/*    */   public static Object invokeStatic()
/*    */   {
/*    */     // Byte code:
/*    */     //   0: getstatic 15	clojure/core/protocols$fn__6681:const__0	Lclojure/lang/Var;
/*    */     //   3: dup
/*    */     //   4: getstatic 19	clojure/core/protocols$fn__6681:const__6	Lclojure/lang/AFn;
/*    */     //   7: checkcast 21	clojure/lang/IPersistentMap
/*    */     //   10: invokevirtual 27	clojure/lang/Var:setMeta	(Lclojure/lang/IPersistentMap;)V
/*    */     //   13: astore_0
/*    */     //   14: aload_0
/*    */     //   15: aconst_null
/*    */     //   16: astore_0
/*    */     //   17: checkcast 23	clojure/lang/Var
/*    */     //   20: invokevirtual 31	clojure/lang/Var:hasRoot	()Z
/*    */     //   23: ifeq +8 -> 31
/*    */     //   26: aconst_null
/*    */     //   27: goto +24 -> 51
/*    */     //   30: pop
/*    */     //   31: getstatic 15	clojure/core/protocols$fn__6681:const__0	Lclojure/lang/Var;
/*    */     //   34: dup
/*    */     //   35: getstatic 34	clojure/core/protocols$fn__6681:const__7	Lclojure/lang/AFn;
/*    */     //   38: checkcast 21	clojure/lang/IPersistentMap
/*    */     //   41: invokevirtual 27	clojure/lang/Var:setMeta	(Lclojure/lang/IPersistentMap;)V
/*    */     //   44: dup
/*    */     //   45: getstatic 40	clojure/lang/PersistentArrayMap:EMPTY	Lclojure/lang/PersistentArrayMap;
/*    */     //   48: invokevirtual 44	clojure/lang/Var:bindRoot	(Ljava/lang/Object;)V
/*    */     //   51: areturn
/*    */     // Line number table:
/*    */     //   Java source line #13	-> byte code offset #0
/*    */     //   Java source line #13	-> byte code offset #14
/*    */     //   Java source line #13	-> byte code offset #20
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	signature
/*    */     //   14	37	0	v__5590__auto__6683	Object
/*    */   }
/*    */   
/* 13 */   public Object invoke() { return invokeStatic(); } public static final AFn const__7 = (AFn)RT.map(new Object[] { RT.keyword(null, "line"), Integer.valueOf(13), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/core/protocols.clj" }); public static final AFn const__6 = (AFn)RT.map(new Object[] { RT.keyword(null, "line"), Integer.valueOf(13), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/core/protocols.clj" }); public static final Var const__0 = (Var)RT.var("clojure.core.protocols", "CollReduce");
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\core\protocols$fn__6681.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */