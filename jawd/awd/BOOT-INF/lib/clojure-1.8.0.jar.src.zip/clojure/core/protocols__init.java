/*     */ package clojure.core;
/*     */ 
/*     */ import clojure.lang.RT;
/*     */ 
/*     */ public class protocols__init {
/*     */   public static final clojure.lang.Var const__0;
/*     */   public static final clojure.lang.AFn const__1;
/*     */   
/*   9 */   public static void load() { if (((clojure.lang.Symbol)const__1).equals(const__2)) { tmpTernaryOp = null; break label67; ((clojure.lang.IFn)new protocols.loading__5569__auto____6675()).invoke(); } else { clojure.lang.LockingTransaction.runInTransaction((java.util.concurrent.Callable)new protocols.fn__6677()); } label67: new protocols.fn__6681();
/*     */     
/*     */ 
/*     */ 
/*  13 */     new protocols.fn__6707(); clojure.lang.Var 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  19 */       tmp559_556 = const__43;tmp559_556.setMeta((clojure.lang.IPersistentMap)const__52);tmp559_556.bindRoot(new protocols.seq_reduce()); clojure.lang.Var tmp583_580 = const__53;tmp583_580.setMeta((clojure.lang.IPersistentMap)const__56);tmp583_580.bindRoot(new protocols.iter_reduce()); clojure.lang.Var tmp607_604 = const__57;tmp607_604.setMeta((clojure.lang.IPersistentMap)const__60);tmp607_604.bindRoot(new protocols.naive_seq_reduce()); clojure.lang.Var tmp631_628 = const__61;tmp631_628.setMeta((clojure.lang.IPersistentMap)const__64);tmp631_628.bindRoot(new protocols.interface_or_naive_reduce());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 124 */     new protocols.fn__6760();
/*     */   }
/*     */   
/*     */   public static final clojure.lang.AFn const__2;
/*     */   public static final clojure.lang.Var const__3;
/*     */   public static final Object const__4;
/*     */   public static final clojure.lang.Var const__5;
/*     */   public static final clojure.lang.Var const__6;
/*     */   public static final clojure.lang.Var const__7;
/*     */   public static final clojure.lang.Keyword const__8;
/*     */   public static final clojure.lang.Var const__9;
/*     */   public static final clojure.lang.ISeq const__10;
/*     */   public static final clojure.lang.Var const__11;
/*     */   public static final clojure.lang.Var const__12;
/*     */   public static final clojure.lang.AFn const__16;
/*     */   public static final clojure.lang.Keyword const__17;
/*     */   public static final clojure.lang.AFn const__18;
/*     */   public static final clojure.lang.Keyword const__19;
/*     */   public static final clojure.lang.Keyword const__20;
/*     */   public static final clojure.lang.Keyword const__21;
/*     */   public static final clojure.lang.AFn const__22;
/*     */   public static final clojure.lang.Keyword const__23;
/*     */   public static final clojure.lang.Var const__24;
/*     */   public static final clojure.lang.Var const__25;
/*     */   public static final clojure.lang.Var const__26;
/*     */   public static final clojure.lang.AFn const__27;
/*     */   public static final clojure.lang.AFn const__28;
/*     */   public static final clojure.lang.Keyword const__29;
/*     */   public static final clojure.lang.Var const__30;
/*     */   public static final clojure.lang.AFn const__31;
/*     */   public static final Object const__32;
/*     */   public static final clojure.lang.Var const__33;
/*     */   public static final clojure.lang.ISeq const__34;
/*     */   public static final clojure.lang.AFn const__36;
/*     */   public static final clojure.lang.AFn const__37;
/*     */   public static final clojure.lang.Keyword const__38;
/*     */   public static final clojure.lang.AFn const__39;
/*     */   public static final clojure.lang.AFn const__40;
/*     */   public static final clojure.lang.AFn const__41;
/*     */   public static final clojure.lang.AFn const__42;
/*     */   public static final clojure.lang.Var const__43;
/*     */   public static final clojure.lang.AFn const__52;
/*     */   public static final clojure.lang.Var const__53;
/*     */   public static final clojure.lang.AFn const__56;
/*     */   public static final clojure.lang.Var const__57;
/*     */   public static final clojure.lang.AFn const__60;
/*     */   public static final clojure.lang.Var const__61;
/*     */   public static final clojure.lang.AFn const__64;
/*     */   public static final clojure.lang.Var const__65;
/*     */   public static final Object const__66;
/*     */   public static final Object const__67;
/*     */   public static final Object const__68;
/*     */   public static final Object const__69;
/*     */   public static final Object const__70;
/*     */   public static final Object const__71;
/*     */   public static final Object const__72;
/*     */   public static final Object const__73;
/*     */   public static final Object const__74;
/*     */   public static final Object const__75;
/*     */   public static final Object const__76;
/*     */   public static final clojure.lang.Var const__77;
/*     */   public static final clojure.lang.ISeq const__78;
/*     */   public static final clojure.lang.AFn const__80;
/*     */   public static final clojure.lang.AFn const__81;
/*     */   public static final clojure.lang.AFn const__83;
/*     */   public static final clojure.lang.AFn const__84;
/*     */   public static final clojure.lang.AFn const__85;
/*     */   public static final clojure.lang.AFn const__86;
/*     */   public static void __init0()
/*     */   {
/*     */     const__0 = (clojure.lang.Var)RT.var("clojure.core", "in-ns");
/*     */     const__1 = (clojure.lang.AFn)clojure.lang.Symbol.intern(null, "clojure.core.protocols");
/*     */     const__2 = (clojure.lang.AFn)clojure.lang.Symbol.intern(null, "clojure.core");
/*     */     const__3 = (clojure.lang.Var)RT.var("clojure.core", "*warn-on-reflection*");
/*     */     const__4 = RT.classForName("clojure.core.protocols.CollReduce");
/*     */     const__5 = (clojure.lang.Var)RT.var("clojure.core", "alter-meta!");
/*     */     const__6 = (clojure.lang.Var)RT.var("clojure.core.protocols", "CollReduce");
/*     */     const__7 = (clojure.lang.Var)RT.var("clojure.core", "assoc");
/*     */     const__8 = (clojure.lang.Keyword)RT.keyword(null, "doc");
/*     */     const__9 = (clojure.lang.Var)RT.var("clojure.core", "assert-same-protocol");
/*     */     const__10 = (clojure.lang.ISeq)clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { ((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "coll-reduce")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "doc"), null, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "coll"), clojure.lang.Symbol.intern(null, "f")), clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "coll"), clojure.lang.Symbol.intern(null, "f"), clojure.lang.Symbol.intern(null, "val")) })) })) }));
/*     */     const__11 = (clojure.lang.Var)RT.var("clojure.core", "alter-var-root");
/*     */     const__12 = (clojure.lang.Var)RT.var("clojure.core", "merge");
/*     */     const__16 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "on"), clojure.lang.Symbol.intern(null, "clojure.core.protocols.CollReduce"), RT.keyword(null, "on-interface"), RT.classForName("clojure.core.protocols.CollReduce"), RT.keyword(null, "doc"), "Protocol for collection types that can implement reduce faster than\n  first/next recursion. Called by clojure.core/reduce. Baseline\n  implementation defined in terms of Iterable." });
/*     */     const__17 = (clojure.lang.Keyword)RT.keyword(null, "sigs");
/*     */     const__18 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "coll-reduce"), RT.map(new Object[] { RT.keyword(null, "name"), ((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "coll-reduce")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "doc"), null, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "coll"), clojure.lang.Symbol.intern(null, "f")), clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "coll"), clojure.lang.Symbol.intern(null, "f"), clojure.lang.Symbol.intern(null, "val")) })) })), RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "coll"), clojure.lang.Symbol.intern(null, "f")), clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "coll"), clojure.lang.Symbol.intern(null, "f"), clojure.lang.Symbol.intern(null, "val")) })), RT.keyword(null, "doc"), null }) });
/*     */     const__19 = (clojure.lang.Keyword)RT.keyword(null, "var");
/*     */     const__20 = (clojure.lang.Keyword)RT.keyword(null, "method-map");
/*     */     const__21 = (clojure.lang.Keyword)RT.keyword(null, "coll-reduce");
/*     */     const__22 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "coll-reduce"), RT.keyword(null, "coll-reduce") });
/*     */     const__23 = (clojure.lang.Keyword)RT.keyword(null, "method-builders");
/*     */     const__24 = (clojure.lang.Var)RT.var("clojure.core", "intern");
/*     */     const__25 = (clojure.lang.Var)RT.var("clojure.core", "*ns*");
/*     */     const__26 = (clojure.lang.Var)RT.var("clojure.core", "with-meta");
/*     */     const__27 = (clojure.lang.AFn)((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "coll-reduce")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "doc"), null, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "coll"), clojure.lang.Symbol.intern(null, "f")), clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "coll"), clojure.lang.Symbol.intern(null, "f"), clojure.lang.Symbol.intern(null, "val")) })) }));
/*     */     const__28 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "name"), ((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "coll-reduce")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "doc"), null, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "coll"), clojure.lang.Symbol.intern(null, "f")), clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "coll"), clojure.lang.Symbol.intern(null, "f"), clojure.lang.Symbol.intern(null, "val")) })) })), RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "coll"), clojure.lang.Symbol.intern(null, "f")), clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "coll"), clojure.lang.Symbol.intern(null, "f"), clojure.lang.Symbol.intern(null, "val")) })), RT.keyword(null, "doc"), null });
/*     */     const__29 = (clojure.lang.Keyword)RT.keyword(null, "protocol");
/*     */     const__30 = (clojure.lang.Var)RT.var("clojure.core", "-reset-methods");
/*     */     const__31 = (clojure.lang.AFn)clojure.lang.Symbol.intern(null, "CollReduce");
/*     */     const__32 = RT.classForName("clojure.core.protocols.InternalReduce");
/*     */     const__33 = (clojure.lang.Var)RT.var("clojure.core.protocols", "InternalReduce");
/*     */     const__34 = (clojure.lang.ISeq)clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { ((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "internal-reduce")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "doc"), null, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "seq"), clojure.lang.Symbol.intern(null, "f"), clojure.lang.Symbol.intern(null, "start")) })) })) }));
/*     */     const__36 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "on"), clojure.lang.Symbol.intern(null, "clojure.core.protocols.InternalReduce"), RT.keyword(null, "on-interface"), RT.classForName("clojure.core.protocols.InternalReduce"), RT.keyword(null, "doc"), "Protocol for concrete seq types that can reduce themselves\n   faster than first/next recursion. Called by clojure.core/reduce." });
/*     */     const__37 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "internal-reduce"), RT.map(new Object[] { RT.keyword(null, "name"), ((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "internal-reduce")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "doc"), null, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "seq"), clojure.lang.Symbol.intern(null, "f"), clojure.lang.Symbol.intern(null, "start")) })) })), RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "seq"), clojure.lang.Symbol.intern(null, "f"), clojure.lang.Symbol.intern(null, "start")) })), RT.keyword(null, "doc"), null }) });
/*     */     const__38 = (clojure.lang.Keyword)RT.keyword(null, "internal-reduce");
/*     */     const__39 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "internal-reduce"), RT.keyword(null, "internal-reduce") });
/*     */     const__40 = (clojure.lang.AFn)((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "internal-reduce")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "doc"), null, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "seq"), clojure.lang.Symbol.intern(null, "f"), clojure.lang.Symbol.intern(null, "start")) })) }));
/*     */     const__41 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "name"), ((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "internal-reduce")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "doc"), null, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "seq"), clojure.lang.Symbol.intern(null, "f"), clojure.lang.Symbol.intern(null, "start")) })) })), RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "seq"), clojure.lang.Symbol.intern(null, "f"), clojure.lang.Symbol.intern(null, "start")) })), RT.keyword(null, "doc"), null });
/*     */     const__42 = (clojure.lang.AFn)clojure.lang.Symbol.intern(null, "InternalReduce");
/*     */     const__43 = (clojure.lang.Var)RT.var("clojure.core.protocols", "seq-reduce");
/*     */     const__52 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "coll"), clojure.lang.Symbol.intern(null, "f")), clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "coll"), clojure.lang.Symbol.intern(null, "f"), clojure.lang.Symbol.intern(null, "val")) })), RT.keyword(null, "line"), Integer.valueOf(24), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/core/protocols.clj" });
/*     */     const__53 = (clojure.lang.Var)RT.var("clojure.core.protocols", "iter-reduce");
/*     */     const__56 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "coll")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "tag"), clojure.lang.Symbol.intern(null, "java.lang.Iterable") })), clojure.lang.Symbol.intern(null, "f")), clojure.lang.Tuple.create(((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "coll")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "tag"), clojure.lang.Symbol.intern(null, "java.lang.Iterable") })), clojure.lang.Symbol.intern(null, "f"), clojure.lang.Symbol.intern(null, "val")) })), RT.keyword(null, "line"), Integer.valueOf(33), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/core/protocols.clj" });
/*     */     const__57 = (clojure.lang.Var)RT.var("clojure.core.protocols", "naive-seq-reduce");
/*     */     const__60 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "s"), clojure.lang.Symbol.intern(null, "f"), clojure.lang.Symbol.intern(null, "val")) })), RT.keyword(null, "doc"), "Reduces a seq, ignoring any opportunities to switch to a more\n  specialized implementation.", RT.keyword(null, "line"), Integer.valueOf(55), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/core/protocols.clj" });
/*     */     const__61 = (clojure.lang.Var)RT.var("clojure.core.protocols", "interface-or-naive-reduce");
/*     */     const__64 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "coll"), clojure.lang.Symbol.intern(null, "f"), clojure.lang.Symbol.intern(null, "val")) })), RT.keyword(null, "doc"), "Reduces via IReduceInit if possible, else naively.", RT.keyword(null, "line"), Integer.valueOf(68), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/core/protocols.clj" });
/*     */     const__65 = (clojure.lang.Var)RT.var("clojure.core", "extend");
/*     */     const__66 = RT.classForName("java.lang.Object");
/*     */     const__67 = RT.classForName("clojure.lang.IReduceInit");
/*     */     const__68 = RT.classForName("clojure.lang.ASeq");
/*     */     const__69 = RT.classForName("clojure.lang.LazySeq");
/*     */     const__70 = RT.classForName("clojure.lang.PersistentVector");
/*     */     const__71 = RT.classForName("java.lang.Iterable");
/*     */     const__72 = RT.classForName("clojure.lang.APersistentMap$KeySeq");
/*     */     const__73 = RT.classForName("clojure.lang.APersistentMap$ValSeq");
/*     */     const__74 = RT.classForName("clojure.lang.IChunkedSeq");
/*     */     const__75 = RT.classForName("clojure.lang.StringSeq");
/*     */     const__76 = RT.classForName("clojure.core.protocols.IKVReduce");
/*     */     const__77 = (clojure.lang.Var)RT.var("clojure.core.protocols", "IKVReduce");
/*     */     const__78 = (clojure.lang.ISeq)clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { ((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "kv-reduce")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "doc"), null, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "amap"), clojure.lang.Symbol.intern(null, "f"), clojure.lang.Symbol.intern(null, "init")) })) })) }));
/*     */     const__80 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "on"), clojure.lang.Symbol.intern(null, "clojure.core.protocols.IKVReduce"), RT.keyword(null, "on-interface"), RT.classForName("clojure.core.protocols.IKVReduce"), RT.keyword(null, "doc"), "Protocol for concrete associative types that can reduce themselves\n   via a function of key and val faster than first/next recursion over map\n   entries. Called by clojure.core/reduce-kv, and has same\n   semantics (just different arg order)." });
/*     */     const__81 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "kv-reduce"), RT.map(new Object[] { RT.keyword(null, "name"), ((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "kv-reduce")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "doc"), null, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "amap"), clojure.lang.Symbol.intern(null, "f"), clojure.lang.Symbol.intern(null, "init")) })) })), RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "amap"), clojure.lang.Symbol.intern(null, "f"), clojure.lang.Symbol.intern(null, "init")) })), RT.keyword(null, "doc"), null }) });
/*     */     const__83 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "kv-reduce"), RT.keyword(null, "kv-reduce") });
/*     */     const__84 = (clojure.lang.AFn)((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "kv-reduce")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "doc"), null, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "amap"), clojure.lang.Symbol.intern(null, "f"), clojure.lang.Symbol.intern(null, "init")) })) }));
/*     */     const__85 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "name"), ((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "kv-reduce")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "doc"), null, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "amap"), clojure.lang.Symbol.intern(null, "f"), clojure.lang.Symbol.intern(null, "init")) })) })), RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "amap"), clojure.lang.Symbol.intern(null, "f"), clojure.lang.Symbol.intern(null, "init")) })), RT.keyword(null, "doc"), null });
/*     */     const__86 = (clojure.lang.AFn)clojure.lang.Symbol.intern(null, "IKVReduce");
/*     */   }
/*     */   
/*     */   static
/*     */   {
/*     */     __init0();
/*     */     clojure.lang.Compiler.pushNSandLoader(RT.classForName("clojure.core.protocols__init").getClassLoader());
/*     */     try
/*     */     {
/*     */       load();
/*     */       clojure.lang.Var.popThreadBindings();
/*     */     }
/*     */     finally
/*     */     {
/*     */       clojure.lang.Var.popThreadBindings();
/*     */       throw finally;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\core\protocols__init.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */