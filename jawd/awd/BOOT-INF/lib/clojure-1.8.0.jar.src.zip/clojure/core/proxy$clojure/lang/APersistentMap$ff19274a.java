package clojure.core.proxy$clojure.lang;

import clojure.lang.APersistentMap;
import clojure.lang.IPersistentCollection;
import clojure.lang.IPersistentMap;
import clojure.lang.IProxy;

public class APersistentMap$ff19274a
  extends APersistentMap
  implements IProxy
{
  private volatile IPersistentMap __clojureFnMap;
  
  public void __initClojureFnMappings(IPersistentMap paramIPersistentMap)
  {
    this.__clojureFnMap = paramIPersistentMap;
  }
  
  public void __updateClojureFnMappings(IPersistentMap paramIPersistentMap)
  {
    this.__clojureFnMap = ((IPersistentMap)((IPersistentCollection)this.__clojureFnMap).cons(paramIPersistentMap));
  }
  
  public IPersistentMap __getClojureFnMappings()
  {
    return this.__clojureFnMap;
  }
  
  /* Error */
  public Object get(Object arg1)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/core/proxy$clojure/lang/APersistentMap$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 35
    //   6: invokestatic 40	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +16 -> 26
    //   13: checkcast 42	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: invokeinterface 45 3 0
    //   23: goto +9 -> 32
    //   26: pop
    //   27: aload_0
    //   28: aload_1
    //   29: invokespecial 47	clojure/lang/APersistentMap:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   32: areturn
  }
  
  /* Error */
  public boolean equiv(Object arg1)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/core/proxy$clojure/lang/APersistentMap$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 50
    //   6: invokestatic 40	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +22 -> 32
    //   13: checkcast 42	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: invokeinterface 45 3 0
    //   23: checkcast 52	java/lang/Boolean
    //   26: invokevirtual 56	java/lang/Boolean:booleanValue	()Z
    //   29: goto +9 -> 38
    //   32: pop
    //   33: aload_0
    //   34: aload_1
    //   35: invokespecial 58	clojure/lang/APersistentMap:equiv	(Ljava/lang/Object;)Z
    //   38: ireturn
  }
  
  /* Error */
  public int size()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/core/proxy$clojure/lang/APersistentMap$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 61
    //   6: invokestatic 40	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +21 -> 31
    //   13: checkcast 42	clojure/lang/IFn
    //   16: aload_0
    //   17: invokeinterface 63 2 0
    //   22: checkcast 65	java/lang/Number
    //   25: invokevirtual 68	java/lang/Number:intValue	()I
    //   28: goto +8 -> 36
    //   31: pop
    //   32: aload_0
    //   33: invokespecial 70	clojure/lang/APersistentMap:size	()I
    //   36: ireturn
  }
  
  /* Error */
  public void run()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/core/proxy$clojure/lang/APersistentMap$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 72
    //   6: invokestatic 40	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +16 -> 26
    //   13: checkcast 42	clojure/lang/IFn
    //   16: aload_0
    //   17: invokeinterface 63 2 0
    //   22: pop
    //   23: goto +8 -> 31
    //   26: pop
    //   27: aload_0
    //   28: invokespecial 74	clojure/lang/APersistentMap:run	()V
    //   31: return
  }
  
  /* Error */
  public boolean equals(Object arg1)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/core/proxy$clojure/lang/APersistentMap$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 76
    //   6: invokestatic 40	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +22 -> 32
    //   13: checkcast 42	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: invokeinterface 45 3 0
    //   23: checkcast 52	java/lang/Boolean
    //   26: invokevirtual 56	java/lang/Boolean:booleanValue	()Z
    //   29: goto +9 -> 38
    //   32: pop
    //   33: aload_0
    //   34: aload_1
    //   35: invokespecial 78	clojure/lang/APersistentMap:equals	(Ljava/lang/Object;)Z
    //   38: ireturn
  }
  
  /* Error */
  public void clear()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/core/proxy$clojure/lang/APersistentMap$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 80
    //   6: invokestatic 40	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +16 -> 26
    //   13: checkcast 42	clojure/lang/IFn
    //   16: aload_0
    //   17: invokeinterface 63 2 0
    //   22: pop
    //   23: goto +8 -> 31
    //   26: pop
    //   27: aload_0
    //   28: invokespecial 82	clojure/lang/APersistentMap:clear	()V
    //   31: return
  }
  
  /* Error */
  public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/core/proxy$clojure/lang/APersistentMap$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 84
    //   6: invokestatic 40	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +36 -> 46
    //   13: checkcast 42	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: aload_2
    //   19: aload_3
    //   20: aload 4
    //   22: aload 5
    //   24: aload 6
    //   26: aload 7
    //   28: aload 8
    //   30: aload 9
    //   32: aload 10
    //   34: aload 11
    //   36: aload 12
    //   38: invokeinterface 87 14 0
    //   43: goto +29 -> 72
    //   46: pop
    //   47: aload_0
    //   48: aload_1
    //   49: aload_2
    //   50: aload_3
    //   51: aload 4
    //   53: aload 5
    //   55: aload 6
    //   57: aload 7
    //   59: aload 8
    //   61: aload 9
    //   63: aload 10
    //   65: aload 11
    //   67: aload 12
    //   69: invokespecial 89	clojure/lang/APersistentMap:invoke	(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   72: areturn
  }
  
  /* Error */
  public IPersistentCollection cons(Object arg1)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/core/proxy$clojure/lang/APersistentMap$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 90
    //   6: invokestatic 40	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +19 -> 29
    //   13: checkcast 42	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: invokeinterface 45 3 0
    //   23: checkcast 19	clojure/lang/IPersistentCollection
    //   26: goto +9 -> 35
    //   29: pop
    //   30: aload_0
    //   31: aload_1
    //   32: invokespecial 91	clojure/lang/APersistentMap:cons	(Ljava/lang/Object;)Lclojure/lang/IPersistentCollection;
    //   35: areturn
  }
  
  /* Error */
  public String toString()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/core/proxy$clojure/lang/APersistentMap$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 94
    //   6: invokestatic 40	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +18 -> 28
    //   13: checkcast 42	clojure/lang/IFn
    //   16: aload_0
    //   17: invokeinterface 63 2 0
    //   22: checkcast 96	java/lang/String
    //   25: goto +8 -> 33
    //   28: pop
    //   29: aload_0
    //   30: invokespecial 98	clojure/lang/APersistentMap:toString	()Ljava/lang/String;
    //   33: areturn
  }
  
  /* Error */
  public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/core/proxy$clojure/lang/APersistentMap$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 84
    //   6: invokestatic 40	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +26 -> 36
    //   13: checkcast 42	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: aload_2
    //   19: aload_3
    //   20: aload 4
    //   22: aload 5
    //   24: aload 6
    //   26: aload 7
    //   28: invokeinterface 102 9 0
    //   33: goto +19 -> 52
    //   36: pop
    //   37: aload_0
    //   38: aload_1
    //   39: aload_2
    //   40: aload_3
    //   41: aload 4
    //   43: aload 5
    //   45: aload 6
    //   47: aload 7
    //   49: invokespecial 104	clojure/lang/APersistentMap:invoke	(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   52: areturn
  }
  
  /* Error */
  public boolean isEmpty()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/core/proxy$clojure/lang/APersistentMap$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 106
    //   6: invokestatic 40	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +21 -> 31
    //   13: checkcast 42	clojure/lang/IFn
    //   16: aload_0
    //   17: invokeinterface 63 2 0
    //   22: checkcast 52	java/lang/Boolean
    //   25: invokevirtual 56	java/lang/Boolean:booleanValue	()Z
    //   28: goto +8 -> 36
    //   31: pop
    //   32: aload_0
    //   33: invokespecial 108	clojure/lang/APersistentMap:isEmpty	()Z
    //   36: ireturn
  }
  
  /* Error */
  public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12, Object arg13, Object arg14, Object arg15, Object arg16, Object arg17)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/core/proxy$clojure/lang/APersistentMap$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 84
    //   6: invokestatic 40	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +46 -> 56
    //   13: checkcast 42	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: aload_2
    //   19: aload_3
    //   20: aload 4
    //   22: aload 5
    //   24: aload 6
    //   26: aload 7
    //   28: aload 8
    //   30: aload 9
    //   32: aload 10
    //   34: aload 11
    //   36: aload 12
    //   38: aload 13
    //   40: aload 14
    //   42: aload 15
    //   44: aload 16
    //   46: aload 17
    //   48: invokeinterface 112 19 0
    //   53: goto +39 -> 92
    //   56: pop
    //   57: aload_0
    //   58: aload_1
    //   59: aload_2
    //   60: aload_3
    //   61: aload 4
    //   63: aload 5
    //   65: aload 6
    //   67: aload 7
    //   69: aload 8
    //   71: aload 9
    //   73: aload 10
    //   75: aload 11
    //   77: aload 12
    //   79: aload 13
    //   81: aload 14
    //   83: aload 15
    //   85: aload 16
    //   87: aload 17
    //   89: invokespecial 114	clojure/lang/APersistentMap:invoke	(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   92: areturn
  }
  
  /* Error */
  public Object invoke(Object arg1, Object arg2)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/core/proxy$clojure/lang/APersistentMap$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 84
    //   6: invokestatic 40	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +17 -> 27
    //   13: checkcast 42	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: aload_2
    //   19: invokeinterface 117 4 0
    //   24: goto +10 -> 34
    //   27: pop
    //   28: aload_0
    //   29: aload_1
    //   30: aload_2
    //   31: invokespecial 118	clojure/lang/APersistentMap:invoke	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   34: areturn
  }
  
  public Object invoke(Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4, Object paramObject5, Object paramObject6, Object paramObject7, Object paramObject8, Object paramObject9, Object paramObject10, Object paramObject11, Object paramObject12, Object paramObject13, Object paramObject14, Object paramObject15, Object paramObject16, Object paramObject17, Object paramObject18, Object paramObject19, Object paramObject20)
  {
    return super.invoke(paramObject1, paramObject2, paramObject3, paramObject4, paramObject5, paramObject6, paramObject7, paramObject8, paramObject9, paramObject10, paramObject11, paramObject12, paramObject13, paramObject14, paramObject15, paramObject16, paramObject17, paramObject18, paramObject19, paramObject20);
  }
  
  /* Error */
  public java.util.Collection values()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/core/proxy$clojure/lang/APersistentMap$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 124
    //   6: invokestatic 40	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +18 -> 28
    //   13: checkcast 42	clojure/lang/IFn
    //   16: aload_0
    //   17: invokeinterface 63 2 0
    //   22: checkcast 126	java/util/Collection
    //   25: goto +8 -> 33
    //   28: pop
    //   29: aload_0
    //   30: invokespecial 128	clojure/lang/APersistentMap:values	()Ljava/util/Collection;
    //   33: areturn
  }
  
  public Object invoke(Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4, Object paramObject5, Object paramObject6, Object paramObject7, Object paramObject8, Object paramObject9, Object paramObject10, Object paramObject11, Object paramObject12, Object paramObject13, Object paramObject14, Object paramObject15, Object paramObject16, Object paramObject17, Object paramObject18, Object paramObject19, Object paramObject20, Object[] paramArrayOfObject)
  {
    return super.invoke(paramObject1, paramObject2, paramObject3, paramObject4, paramObject5, paramObject6, paramObject7, paramObject8, paramObject9, paramObject10, paramObject11, paramObject12, paramObject13, paramObject14, paramObject15, paramObject16, paramObject17, paramObject18, paramObject19, paramObject20, paramArrayOfObject);
  }
  
  /* Error */
  public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/core/proxy$clojure/lang/APersistentMap$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 84
    //   6: invokestatic 40	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +32 -> 42
    //   13: checkcast 42	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: aload_2
    //   19: aload_3
    //   20: aload 4
    //   22: aload 5
    //   24: aload 6
    //   26: aload 7
    //   28: aload 8
    //   30: aload 9
    //   32: aload 10
    //   34: invokeinterface 135 12 0
    //   39: goto +25 -> 64
    //   42: pop
    //   43: aload_0
    //   44: aload_1
    //   45: aload_2
    //   46: aload_3
    //   47: aload 4
    //   49: aload 5
    //   51: aload 6
    //   53: aload 7
    //   55: aload 8
    //   57: aload 9
    //   59: aload 10
    //   61: invokespecial 137	clojure/lang/APersistentMap:invoke	(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   64: areturn
  }
  
  /* Error */
  public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/core/proxy$clojure/lang/APersistentMap$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 84
    //   6: invokestatic 40	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +22 -> 32
    //   13: checkcast 42	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: aload_2
    //   19: aload_3
    //   20: aload 4
    //   22: aload 5
    //   24: invokeinterface 141 7 0
    //   29: goto +15 -> 44
    //   32: pop
    //   33: aload_0
    //   34: aload_1
    //   35: aload_2
    //   36: aload_3
    //   37: aload 4
    //   39: aload 5
    //   41: invokespecial 143	clojure/lang/APersistentMap:invoke	(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   44: areturn
  }
  
  /* Error */
  public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12, Object arg13, Object arg14, Object arg15, Object arg16)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/core/proxy$clojure/lang/APersistentMap$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 84
    //   6: invokestatic 40	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +44 -> 54
    //   13: checkcast 42	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: aload_2
    //   19: aload_3
    //   20: aload 4
    //   22: aload 5
    //   24: aload 6
    //   26: aload 7
    //   28: aload 8
    //   30: aload 9
    //   32: aload 10
    //   34: aload 11
    //   36: aload 12
    //   38: aload 13
    //   40: aload 14
    //   42: aload 15
    //   44: aload 16
    //   46: invokeinterface 145 18 0
    //   51: goto +37 -> 88
    //   54: pop
    //   55: aload_0
    //   56: aload_1
    //   57: aload_2
    //   58: aload_3
    //   59: aload 4
    //   61: aload 5
    //   63: aload 6
    //   65: aload 7
    //   67: aload 8
    //   69: aload 9
    //   71: aload 10
    //   73: aload 11
    //   75: aload 12
    //   77: aload 13
    //   79: aload 14
    //   81: aload 15
    //   83: aload 16
    //   85: invokespecial 147	clojure/lang/APersistentMap:invoke	(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   88: areturn
  }
  
  /* Error */
  public Object invoke(Object arg1, Object arg2, Object arg3)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/core/proxy$clojure/lang/APersistentMap$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 84
    //   6: invokestatic 40	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +18 -> 28
    //   13: checkcast 42	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: aload_2
    //   19: aload_3
    //   20: invokeinterface 150 5 0
    //   25: goto +11 -> 36
    //   28: pop
    //   29: aload_0
    //   30: aload_1
    //   31: aload_2
    //   32: aload_3
    //   33: invokespecial 151	clojure/lang/APersistentMap:invoke	(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   36: areturn
  }
  
  /* Error */
  public java.util.Set keySet()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/core/proxy$clojure/lang/APersistentMap$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc -102
    //   6: invokestatic 40	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +18 -> 28
    //   13: checkcast 42	clojure/lang/IFn
    //   16: aload_0
    //   17: invokeinterface 63 2 0
    //   22: checkcast 156	java/util/Set
    //   25: goto +8 -> 33
    //   28: pop
    //   29: aload_0
    //   30: invokespecial 158	clojure/lang/APersistentMap:keySet	()Ljava/util/Set;
    //   33: areturn
  }
  
  /* Error */
  public Object invoke(Object arg1)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/core/proxy$clojure/lang/APersistentMap$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 84
    //   6: invokestatic 40	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +16 -> 26
    //   13: checkcast 42	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: invokeinterface 45 3 0
    //   23: goto +9 -> 32
    //   26: pop
    //   27: aload_0
    //   28: aload_1
    //   29: invokespecial 159	clojure/lang/APersistentMap:invoke	(Ljava/lang/Object;)Ljava/lang/Object;
    //   32: areturn
  }
  
  /* Error */
  public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12, Object arg13, Object arg14)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/core/proxy$clojure/lang/APersistentMap$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 84
    //   6: invokestatic 40	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +40 -> 50
    //   13: checkcast 42	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: aload_2
    //   19: aload_3
    //   20: aload 4
    //   22: aload 5
    //   24: aload 6
    //   26: aload 7
    //   28: aload 8
    //   30: aload 9
    //   32: aload 10
    //   34: aload 11
    //   36: aload 12
    //   38: aload 13
    //   40: aload 14
    //   42: invokeinterface 163 16 0
    //   47: goto +33 -> 80
    //   50: pop
    //   51: aload_0
    //   52: aload_1
    //   53: aload_2
    //   54: aload_3
    //   55: aload 4
    //   57: aload 5
    //   59: aload 6
    //   61: aload 7
    //   63: aload 8
    //   65: aload 9
    //   67: aload 10
    //   69: aload 11
    //   71: aload 12
    //   73: aload 13
    //   75: aload 14
    //   77: invokespecial 165	clojure/lang/APersistentMap:invoke	(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   80: areturn
  }
  
  /* Error */
  public boolean containsValue(Object arg1)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/core/proxy$clojure/lang/APersistentMap$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc -89
    //   6: invokestatic 40	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +22 -> 32
    //   13: checkcast 42	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: invokeinterface 45 3 0
    //   23: checkcast 52	java/lang/Boolean
    //   26: invokevirtual 56	java/lang/Boolean:booleanValue	()Z
    //   29: goto +9 -> 38
    //   32: pop
    //   33: aload_0
    //   34: aload_1
    //   35: invokespecial 169	clojure/lang/APersistentMap:containsValue	(Ljava/lang/Object;)Z
    //   38: ireturn
  }
  
  /* Error */
  public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/core/proxy$clojure/lang/APersistentMap$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 84
    //   6: invokestatic 40	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +24 -> 34
    //   13: checkcast 42	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: aload_2
    //   19: aload_3
    //   20: aload 4
    //   22: aload 5
    //   24: aload 6
    //   26: invokeinterface 170 8 0
    //   31: goto +17 -> 48
    //   34: pop
    //   35: aload_0
    //   36: aload_1
    //   37: aload_2
    //   38: aload_3
    //   39: aload 4
    //   41: aload 5
    //   43: aload 6
    //   45: invokespecial 171	clojure/lang/APersistentMap:invoke	(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   48: areturn
  }
  
  /* Error */
  public Object invoke()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/core/proxy$clojure/lang/APersistentMap$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 84
    //   6: invokestatic 40	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +15 -> 25
    //   13: checkcast 42	clojure/lang/IFn
    //   16: aload_0
    //   17: invokeinterface 63 2 0
    //   22: goto +8 -> 30
    //   25: pop
    //   26: aload_0
    //   27: invokespecial 174	clojure/lang/APersistentMap:invoke	()Ljava/lang/Object;
    //   30: areturn
  }
  
  /* Error */
  public Object throwArity(int arg1)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/core/proxy$clojure/lang/APersistentMap$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc -79
    //   6: invokestatic 40	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +19 -> 29
    //   13: checkcast 42	clojure/lang/IFn
    //   16: aload_0
    //   17: iload_1
    //   18: invokestatic 183	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   21: invokeinterface 45 3 0
    //   26: goto +9 -> 35
    //   29: pop
    //   30: aload_0
    //   31: iload_1
    //   32: invokespecial 185	clojure/lang/APersistentMap:throwArity	(I)Ljava/lang/Object;
    //   35: areturn
  }
  
  /* Error */
  public void putAll(java.util.Map arg1)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/core/proxy$clojure/lang/APersistentMap$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc -68
    //   6: invokestatic 40	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +17 -> 27
    //   13: checkcast 42	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: invokeinterface 45 3 0
    //   23: pop
    //   24: goto +9 -> 33
    //   27: pop
    //   28: aload_0
    //   29: aload_1
    //   30: invokespecial 190	clojure/lang/APersistentMap:putAll	(Ljava/util/Map;)V
    //   33: return
  }
  
  /* Error */
  public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/core/proxy$clojure/lang/APersistentMap$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 84
    //   6: invokestatic 40	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +34 -> 44
    //   13: checkcast 42	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: aload_2
    //   19: aload_3
    //   20: aload 4
    //   22: aload 5
    //   24: aload 6
    //   26: aload 7
    //   28: aload 8
    //   30: aload 9
    //   32: aload 10
    //   34: aload 11
    //   36: invokeinterface 191 13 0
    //   41: goto +27 -> 68
    //   44: pop
    //   45: aload_0
    //   46: aload_1
    //   47: aload_2
    //   48: aload_3
    //   49: aload 4
    //   51: aload 5
    //   53: aload 6
    //   55: aload 7
    //   57: aload 8
    //   59: aload 9
    //   61: aload 10
    //   63: aload 11
    //   65: invokespecial 192	clojure/lang/APersistentMap:invoke	(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   68: areturn
  }
  
  /* Error */
  public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12, Object arg13, Object arg14, Object arg15, Object arg16, Object arg17, Object arg18)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/core/proxy$clojure/lang/APersistentMap$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 84
    //   6: invokestatic 40	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +48 -> 58
    //   13: checkcast 42	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: aload_2
    //   19: aload_3
    //   20: aload 4
    //   22: aload 5
    //   24: aload 6
    //   26: aload 7
    //   28: aload 8
    //   30: aload 9
    //   32: aload 10
    //   34: aload 11
    //   36: aload 12
    //   38: aload 13
    //   40: aload 14
    //   42: aload 15
    //   44: aload 16
    //   46: aload 17
    //   48: aload 18
    //   50: invokeinterface 195 20 0
    //   55: goto +41 -> 96
    //   58: pop
    //   59: aload_0
    //   60: aload_1
    //   61: aload_2
    //   62: aload_3
    //   63: aload 4
    //   65: aload 5
    //   67: aload 6
    //   69: aload 7
    //   71: aload 8
    //   73: aload 9
    //   75: aload 10
    //   77: aload 11
    //   79: aload 12
    //   81: aload 13
    //   83: aload 14
    //   85: aload 15
    //   87: aload 16
    //   89: aload 17
    //   91: aload 18
    //   93: invokespecial 196	clojure/lang/APersistentMap:invoke	(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   96: areturn
  }
  
  /* Error */
  public Object put(Object arg1, Object arg2)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/core/proxy$clojure/lang/APersistentMap$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc -58
    //   6: invokestatic 40	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +17 -> 27
    //   13: checkcast 42	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: aload_2
    //   19: invokeinterface 117 4 0
    //   24: goto +10 -> 34
    //   27: pop
    //   28: aload_0
    //   29: aload_1
    //   30: aload_2
    //   31: invokespecial 200	clojure/lang/APersistentMap:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   34: areturn
  }
  
  public Object invoke(Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4, Object paramObject5, Object paramObject6, Object paramObject7, Object paramObject8, Object paramObject9, Object paramObject10, Object paramObject11, Object paramObject12, Object paramObject13, Object paramObject14, Object paramObject15, Object paramObject16, Object paramObject17, Object paramObject18, Object paramObject19)
  {
    return super.invoke(paramObject1, paramObject2, paramObject3, paramObject4, paramObject5, paramObject6, paramObject7, paramObject8, paramObject9, paramObject10, paramObject11, paramObject12, paramObject13, paramObject14, paramObject15, paramObject16, paramObject17, paramObject18, paramObject19);
  }
  
  /* Error */
  public int hasheq()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/core/proxy$clojure/lang/APersistentMap$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc -53
    //   6: invokestatic 40	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +21 -> 31
    //   13: checkcast 42	clojure/lang/IFn
    //   16: aload_0
    //   17: invokeinterface 63 2 0
    //   22: checkcast 65	java/lang/Number
    //   25: invokevirtual 68	java/lang/Number:intValue	()I
    //   28: goto +8 -> 36
    //   31: pop
    //   32: aload_0
    //   33: invokespecial 205	clojure/lang/APersistentMap:hasheq	()I
    //   36: ireturn
  }
  
  /* Error */
  public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12, Object arg13)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/core/proxy$clojure/lang/APersistentMap$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 84
    //   6: invokestatic 40	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +38 -> 48
    //   13: checkcast 42	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: aload_2
    //   19: aload_3
    //   20: aload 4
    //   22: aload 5
    //   24: aload 6
    //   26: aload 7
    //   28: aload 8
    //   30: aload 9
    //   32: aload 10
    //   34: aload 11
    //   36: aload 12
    //   38: aload 13
    //   40: invokeinterface 206 15 0
    //   45: goto +31 -> 76
    //   48: pop
    //   49: aload_0
    //   50: aload_1
    //   51: aload_2
    //   52: aload_3
    //   53: aload 4
    //   55: aload 5
    //   57: aload 6
    //   59: aload 7
    //   61: aload 8
    //   63: aload 9
    //   65: aload 10
    //   67: aload 11
    //   69: aload 12
    //   71: aload 13
    //   73: invokespecial 207	clojure/lang/APersistentMap:invoke	(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   76: areturn
  }
  
  /* Error */
  public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12, Object arg13, Object arg14, Object arg15)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/core/proxy$clojure/lang/APersistentMap$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 84
    //   6: invokestatic 40	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +42 -> 52
    //   13: checkcast 42	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: aload_2
    //   19: aload_3
    //   20: aload 4
    //   22: aload 5
    //   24: aload 6
    //   26: aload 7
    //   28: aload 8
    //   30: aload 9
    //   32: aload 10
    //   34: aload 11
    //   36: aload 12
    //   38: aload 13
    //   40: aload 14
    //   42: aload 15
    //   44: invokeinterface 208 17 0
    //   49: goto +35 -> 84
    //   52: pop
    //   53: aload_0
    //   54: aload_1
    //   55: aload_2
    //   56: aload_3
    //   57: aload 4
    //   59: aload 5
    //   61: aload 6
    //   63: aload 7
    //   65: aload 8
    //   67: aload 9
    //   69: aload 10
    //   71: aload 11
    //   73: aload 12
    //   75: aload 13
    //   77: aload 14
    //   79: aload 15
    //   81: invokespecial 209	clojure/lang/APersistentMap:invoke	(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   84: areturn
  }
  
  /* Error */
  public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/core/proxy$clojure/lang/APersistentMap$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 84
    //   6: invokestatic 40	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +30 -> 40
    //   13: checkcast 42	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: aload_2
    //   19: aload_3
    //   20: aload 4
    //   22: aload 5
    //   24: aload 6
    //   26: aload 7
    //   28: aload 8
    //   30: aload 9
    //   32: invokeinterface 211 11 0
    //   37: goto +23 -> 60
    //   40: pop
    //   41: aload_0
    //   42: aload_1
    //   43: aload_2
    //   44: aload_3
    //   45: aload 4
    //   47: aload 5
    //   49: aload 6
    //   51: aload 7
    //   53: aload 8
    //   55: aload 9
    //   57: invokespecial 213	clojure/lang/APersistentMap:invoke	(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   60: areturn
  }
  
  /* Error */
  public int hashCode()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/core/proxy$clojure/lang/APersistentMap$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc -41
    //   6: invokestatic 40	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +21 -> 31
    //   13: checkcast 42	clojure/lang/IFn
    //   16: aload_0
    //   17: invokeinterface 63 2 0
    //   22: checkcast 65	java/lang/Number
    //   25: invokevirtual 68	java/lang/Number:intValue	()I
    //   28: goto +8 -> 36
    //   31: pop
    //   32: aload_0
    //   33: invokespecial 217	clojure/lang/APersistentMap:hashCode	()I
    //   36: ireturn
  }
  
  /* Error */
  public Object call()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/core/proxy$clojure/lang/APersistentMap$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc -37
    //   6: invokestatic 40	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +15 -> 25
    //   13: checkcast 42	clojure/lang/IFn
    //   16: aload_0
    //   17: invokeinterface 63 2 0
    //   22: goto +8 -> 30
    //   25: pop
    //   26: aload_0
    //   27: invokespecial 221	clojure/lang/APersistentMap:call	()Ljava/lang/Object;
    //   30: areturn
  }
  
  /* Error */
  public Object remove(Object arg1)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/core/proxy$clojure/lang/APersistentMap$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc -33
    //   6: invokestatic 40	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +16 -> 26
    //   13: checkcast 42	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: invokeinterface 45 3 0
    //   23: goto +9 -> 32
    //   26: pop
    //   27: aload_0
    //   28: aload_1
    //   29: invokespecial 225	clojure/lang/APersistentMap:remove	(Ljava/lang/Object;)Ljava/lang/Object;
    //   32: areturn
  }
  
  /* Error */
  public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/core/proxy$clojure/lang/APersistentMap$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 84
    //   6: invokestatic 40	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +28 -> 38
    //   13: checkcast 42	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: aload_2
    //   19: aload_3
    //   20: aload 4
    //   22: aload 5
    //   24: aload 6
    //   26: aload 7
    //   28: aload 8
    //   30: invokeinterface 226 10 0
    //   35: goto +21 -> 56
    //   38: pop
    //   39: aload_0
    //   40: aload_1
    //   41: aload_2
    //   42: aload_3
    //   43: aload 4
    //   45: aload 5
    //   47: aload 6
    //   49: aload 7
    //   51: aload 8
    //   53: invokespecial 227	clojure/lang/APersistentMap:invoke	(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   56: areturn
  }
  
  /* Error */
  public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/core/proxy$clojure/lang/APersistentMap$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 84
    //   6: invokestatic 40	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +20 -> 30
    //   13: checkcast 42	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: aload_2
    //   19: aload_3
    //   20: aload 4
    //   22: invokeinterface 228 6 0
    //   27: goto +13 -> 40
    //   30: pop
    //   31: aload_0
    //   32: aload_1
    //   33: aload_2
    //   34: aload_3
    //   35: aload 4
    //   37: invokespecial 229	clojure/lang/APersistentMap:invoke	(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   40: areturn
  }
  
  /* Error */
  public java.util.Set entrySet()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/core/proxy$clojure/lang/APersistentMap$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc -25
    //   6: invokestatic 40	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +18 -> 28
    //   13: checkcast 42	clojure/lang/IFn
    //   16: aload_0
    //   17: invokeinterface 63 2 0
    //   22: checkcast 156	java/util/Set
    //   25: goto +8 -> 33
    //   28: pop
    //   29: aload_0
    //   30: invokespecial 233	clojure/lang/APersistentMap:entrySet	()Ljava/util/Set;
    //   33: areturn
  }
  
  /* Error */
  public Object applyTo(clojure.lang.ISeq arg1)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/core/proxy$clojure/lang/APersistentMap$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc -20
    //   6: invokestatic 40	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +16 -> 26
    //   13: checkcast 42	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: invokeinterface 45 3 0
    //   23: goto +9 -> 32
    //   26: pop
    //   27: aload_0
    //   28: aload_1
    //   29: invokespecial 238	clojure/lang/APersistentMap:applyTo	(Lclojure/lang/ISeq;)Ljava/lang/Object;
    //   32: areturn
  }
  
  /* Error */
  public Object clone()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/core/proxy$clojure/lang/APersistentMap$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc -16
    //   6: invokestatic 40	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +15 -> 25
    //   13: checkcast 42	clojure/lang/IFn
    //   16: aload_0
    //   17: invokeinterface 63 2 0
    //   22: goto +8 -> 30
    //   25: pop
    //   26: aload_0
    //   27: invokespecial 242	clojure/lang/APersistentMap:clone	()Ljava/lang/Object;
    //   30: areturn
  }
  
  /* Error */
  public Object valAt(Object arg1)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/core/proxy$clojure/lang/APersistentMap$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc -12
    //   6: invokestatic 40	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +16 -> 26
    //   13: checkcast 42	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: invokeinterface 45 3 0
    //   23: goto +14 -> 37
    //   26: pop
    //   27: new 246	java/lang/UnsupportedOperationException
    //   30: dup
    //   31: ldc -12
    //   33: invokespecial 249	java/lang/UnsupportedOperationException:<init>	(Ljava/lang/String;)V
    //   36: athrow
    //   37: areturn
  }
  
  /* Error */
  public int count()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/core/proxy$clojure/lang/APersistentMap$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc -5
    //   6: invokestatic 40	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +21 -> 31
    //   13: checkcast 42	clojure/lang/IFn
    //   16: aload_0
    //   17: invokeinterface 63 2 0
    //   22: checkcast 65	java/lang/Number
    //   25: invokevirtual 68	java/lang/Number:intValue	()I
    //   28: goto +14 -> 42
    //   31: pop
    //   32: new 246	java/lang/UnsupportedOperationException
    //   35: dup
    //   36: ldc -5
    //   38: invokespecial 249	java/lang/UnsupportedOperationException:<init>	(Ljava/lang/String;)V
    //   41: athrow
    //   42: ireturn
  }
  
  /* Error */
  public Object valAt(Object arg1, Object arg2)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/core/proxy$clojure/lang/APersistentMap$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc -12
    //   6: invokestatic 40	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +17 -> 27
    //   13: checkcast 42	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: aload_2
    //   19: invokeinterface 117 4 0
    //   24: goto +14 -> 38
    //   27: pop
    //   28: new 246	java/lang/UnsupportedOperationException
    //   31: dup
    //   32: ldc -12
    //   34: invokespecial 249	java/lang/UnsupportedOperationException:<init>	(Ljava/lang/String;)V
    //   37: athrow
    //   38: areturn
  }
  
  /* Error */
  public clojure.lang.ISeq seq()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/core/proxy$clojure/lang/APersistentMap$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc -2
    //   6: invokestatic 40	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +18 -> 28
    //   13: checkcast 42	clojure/lang/IFn
    //   16: aload_0
    //   17: invokeinterface 63 2 0
    //   22: checkcast 256	clojure/lang/ISeq
    //   25: goto +14 -> 39
    //   28: pop
    //   29: new 246	java/lang/UnsupportedOperationException
    //   32: dup
    //   33: ldc -2
    //   35: invokespecial 249	java/lang/UnsupportedOperationException:<init>	(Ljava/lang/String;)V
    //   38: athrow
    //   39: areturn
  }
  
  /* Error */
  public java.util.Iterator iterator()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/core/proxy$clojure/lang/APersistentMap$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc_w 259
    //   7: invokestatic 40	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   10: dup
    //   11: ifnull +18 -> 29
    //   14: checkcast 42	clojure/lang/IFn
    //   17: aload_0
    //   18: invokeinterface 63 2 0
    //   23: checkcast 261	java/util/Iterator
    //   26: goto +15 -> 41
    //   29: pop
    //   30: new 246	java/lang/UnsupportedOperationException
    //   33: dup
    //   34: ldc_w 259
    //   37: invokespecial 249	java/lang/UnsupportedOperationException:<init>	(Ljava/lang/String;)V
    //   40: athrow
    //   41: areturn
  }
  
  /* Error */
  public clojure.lang.IMapEntry entryAt(Object arg1)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/core/proxy$clojure/lang/APersistentMap$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc_w 264
    //   7: invokestatic 40	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   10: dup
    //   11: ifnull +19 -> 30
    //   14: checkcast 42	clojure/lang/IFn
    //   17: aload_0
    //   18: aload_1
    //   19: invokeinterface 45 3 0
    //   24: checkcast 266	clojure/lang/IMapEntry
    //   27: goto +15 -> 42
    //   30: pop
    //   31: new 246	java/lang/UnsupportedOperationException
    //   34: dup
    //   35: ldc_w 264
    //   38: invokespecial 249	java/lang/UnsupportedOperationException:<init>	(Ljava/lang/String;)V
    //   41: athrow
    //   42: areturn
  }
  
  /* Error */
  public boolean containsKey(Object arg1)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/core/proxy$clojure/lang/APersistentMap$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc_w 268
    //   7: invokestatic 40	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   10: dup
    //   11: ifnull +22 -> 33
    //   14: checkcast 42	clojure/lang/IFn
    //   17: aload_0
    //   18: aload_1
    //   19: invokeinterface 45 3 0
    //   24: checkcast 52	java/lang/Boolean
    //   27: invokevirtual 56	java/lang/Boolean:booleanValue	()Z
    //   30: goto +15 -> 45
    //   33: pop
    //   34: new 246	java/lang/UnsupportedOperationException
    //   37: dup
    //   38: ldc_w 268
    //   41: invokespecial 249	java/lang/UnsupportedOperationException:<init>	(Ljava/lang/String;)V
    //   44: athrow
    //   45: ireturn
  }
  
  /* Error */
  public IPersistentMap assocEx(Object arg1, Object arg2)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/core/proxy$clojure/lang/APersistentMap$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc_w 270
    //   7: invokestatic 40	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   10: dup
    //   11: ifnull +20 -> 31
    //   14: checkcast 42	clojure/lang/IFn
    //   17: aload_0
    //   18: aload_1
    //   19: aload_2
    //   20: invokeinterface 117 4 0
    //   25: checkcast 25	clojure/lang/IPersistentMap
    //   28: goto +15 -> 43
    //   31: pop
    //   32: new 246	java/lang/UnsupportedOperationException
    //   35: dup
    //   36: ldc_w 270
    //   39: invokespecial 249	java/lang/UnsupportedOperationException:<init>	(Ljava/lang/String;)V
    //   42: athrow
    //   43: areturn
  }
  
  /* Error */
  public IPersistentMap without(Object arg1)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/core/proxy$clojure/lang/APersistentMap$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc_w 273
    //   7: invokestatic 40	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   10: dup
    //   11: ifnull +19 -> 30
    //   14: checkcast 42	clojure/lang/IFn
    //   17: aload_0
    //   18: aload_1
    //   19: invokeinterface 45 3 0
    //   24: checkcast 25	clojure/lang/IPersistentMap
    //   27: goto +15 -> 42
    //   30: pop
    //   31: new 246	java/lang/UnsupportedOperationException
    //   34: dup
    //   35: ldc_w 273
    //   38: invokespecial 249	java/lang/UnsupportedOperationException:<init>	(Ljava/lang/String;)V
    //   41: athrow
    //   42: areturn
  }
  
  /* Error */
  public IPersistentCollection empty()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/core/proxy$clojure/lang/APersistentMap$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc_w 276
    //   7: invokestatic 40	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   10: dup
    //   11: ifnull +18 -> 29
    //   14: checkcast 42	clojure/lang/IFn
    //   17: aload_0
    //   18: invokeinterface 63 2 0
    //   23: checkcast 19	clojure/lang/IPersistentCollection
    //   26: goto +15 -> 41
    //   29: pop
    //   30: new 246	java/lang/UnsupportedOperationException
    //   33: dup
    //   34: ldc_w 276
    //   37: invokespecial 249	java/lang/UnsupportedOperationException:<init>	(Ljava/lang/String;)V
    //   40: athrow
    //   41: areturn
  }
  
  /* Error */
  public IPersistentMap assoc(Object arg1, Object arg2)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/core/proxy$clojure/lang/APersistentMap$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc_w 277
    //   7: invokestatic 40	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   10: dup
    //   11: ifnull +20 -> 31
    //   14: checkcast 42	clojure/lang/IFn
    //   17: aload_0
    //   18: aload_1
    //   19: aload_2
    //   20: invokeinterface 117 4 0
    //   25: checkcast 25	clojure/lang/IPersistentMap
    //   28: goto +15 -> 43
    //   31: pop
    //   32: new 246	java/lang/UnsupportedOperationException
    //   35: dup
    //   36: ldc_w 277
    //   39: invokespecial 249	java/lang/UnsupportedOperationException:<init>	(Ljava/lang/String;)V
    //   42: athrow
    //   43: areturn
  }
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\core\proxy$clojure\lang\APersistentMap$ff19274a.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */