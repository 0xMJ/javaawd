/*    */ package clojure.core;
/*    */ 
/*    */ import clojure.core.apply;
/*    */ import clojure.core.concat;
/*    */ import clojure.core.seq__4357;
/*    */ import clojure.lang.AFn;
/*    */ import clojure.lang.ArraySeq;
/*    */ import clojure.lang.ISeq;
/*    */ import clojure.lang.PersistentList.Primordial;
/*    */ import clojure.lang.RT;
/*    */ import clojure.lang.RestFn;
/*    */ import clojure.lang.Symbol;
/*    */ import clojure.lang.Var;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class server$thread
/*    */   extends RestFn
/*    */ {
/*    */   public int getRequiredArity()
/*    */   {
/*    */     return 4;
/*    */   }
/*    */   
/*    */   public Object doInvoke(Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4, Object paramObject5)
/*    */   {
/* 35 */     paramObject1 = null;paramObject2 = null;paramObject3 = null;paramObject4 = null;paramObject5 = null;return invokeStatic(paramObject1, paramObject2, paramObject3, paramObject4, (ISeq)paramObject5); } public static Object invokeStatic(Object _AMPERSAND_form, Object _AMPERSAND_env, Object name, Object daemon, ISeq body) { Object[] tmp20_17 = new Object[1]; Object[] tmp42_39 = new Object[1]; Object[] tmp92_89 = new Object[1];body = null;tmp92_89[0] = body;tmp42_39[0] = core.seq__4357.invokeStatic(core.concat.invokeStatic(PersistentList.Primordial.invokeStatic(ArraySeq.create(new Object[] { const__5 })), PersistentList.Primordial.invokeStatic(ArraySeq.create(new Object[] { core.apply.invokeStatic(const__7.getRawRoot(), core.seq__4357.invokeStatic(core.concat.invokeStatic())) })), ArraySeq.create(tmp92_89))); Object[] tmp120_117 = new Object[1]; Object[] tmp126_123 = new Object[1];name = null;tmp126_123[0] = name;tmp120_117[0] = PersistentList.Primordial.invokeStatic(ArraySeq.create(tmp126_123));tmp20_17[0] = core.seq__4357.invokeStatic(core.concat.invokeStatic(PersistentList.Primordial.invokeStatic(ArraySeq.create(new Object[] { const__4 })), PersistentList.Primordial.invokeStatic(ArraySeq.create(tmp42_39)), ArraySeq.create(tmp120_117))); Object[] tmp159_156 = new Object[2]; Object[] tmp165_162 = new Object[1]; Object[] tmp187_184 = new Object[1];daemon = null;tmp187_184[0] = daemon;tmp165_162[0] = core.seq__4357.invokeStatic(core.concat.invokeStatic(PersistentList.Primordial.invokeStatic(ArraySeq.create(new Object[] { const__8 })), PersistentList.Primordial.invokeStatic(ArraySeq.create(tmp187_184))));tmp159_156[0] = PersistentList.Primordial.invokeStatic(ArraySeq.create(tmp165_162)); Object[] tmp213_159 = tmp159_156;tmp213_159[1] = PersistentList.Primordial.invokeStatic(ArraySeq.create(new Object[] { core.seq__4357.invokeStatic(core.concat.invokeStatic(PersistentList.Primordial.invokeStatic(ArraySeq.create(new Object[] { const__9 })))) }));return core.seq__4357.invokeStatic(core.concat.invokeStatic(PersistentList.Primordial.invokeStatic(ArraySeq.create(new Object[] { const__3 })), PersistentList.Primordial.invokeStatic(ArraySeq.create(tmp20_17)), ArraySeq.create(tmp213_159))); } public static final AFn const__9 = (AFn)Symbol.intern(null, ".start"); public static final AFn const__8 = (AFn)Symbol.intern(null, ".setDaemon"); public static final Var const__7 = (Var)RT.var("clojure.core", "vector"); public static final AFn const__5 = (AFn)Symbol.intern("clojure.core", "fn"); public static final AFn const__4 = (AFn)Symbol.intern(null, "java.lang.Thread."); public static final AFn const__3 = (AFn)Symbol.intern("clojure.core", "doto");
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\core\server$thread.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */