/*    */ package clojure.core;
/*    */ 
/*    */ import clojure.lang.AFunction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class protocols$iter_reduce
/*    */   extends AFunction
/*    */ {
/*    */   public Object invoke(Object paramObject1, Object paramObject2)
/*    */   {
/* 33 */     paramObject1 = null;paramObject2 = null;return invokeStatic(paramObject1, paramObject2);
/*    */   }
/*    */   
/*    */   /* Error */
/*    */   public static Object invokeStatic(Object coll, Object f)
/*    */   {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: aconst_null
/*    */     //   2: astore_0
/*    */     //   3: checkcast 13	java/lang/Iterable
/*    */     //   6: invokeinterface 17 1 0
/*    */     //   11: astore_2
/*    */     //   12: aload_2
/*    */     //   13: checkcast 19	java/util/Iterator
/*    */     //   16: invokeinterface 23 1 0
/*    */     //   21: ifeq +88 -> 109
/*    */     //   24: aload_2
/*    */     //   25: checkcast 19	java/util/Iterator
/*    */     //   28: invokeinterface 29 1 0
/*    */     //   33: astore_3
/*    */     //   34: aload_2
/*    */     //   35: checkcast 19	java/util/Iterator
/*    */     //   38: invokeinterface 23 1 0
/*    */     //   43: ifeq +59 -> 102
/*    */     //   46: aload_1
/*    */     //   47: checkcast 25	clojure/lang/IFn
/*    */     //   50: aload_3
/*    */     //   51: aconst_null
/*    */     //   52: astore_3
/*    */     //   53: aload_2
/*    */     //   54: checkcast 19	java/util/Iterator
/*    */     //   57: invokeinterface 29 1 0
/*    */     //   62: invokeinterface 33 3 0
/*    */     //   67: astore 4
/*    */     //   69: aload 4
/*    */     //   71: invokestatic 39	clojure/lang/RT:isReduced	(Ljava/lang/Object;)Z
/*    */     //   74: ifeq +15 -> 89
/*    */     //   77: aload 4
/*    */     //   79: aconst_null
/*    */     //   80: astore 4
/*    */     //   82: invokestatic 44	clojure/core$deref:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   85: goto +13 -> 98
/*    */     //   88: pop
/*    */     //   89: aload 4
/*    */     //   91: aconst_null
/*    */     //   92: astore 4
/*    */     //   94: astore_3
/*    */     //   95: goto -61 -> 34
/*    */     //   98: goto +7 -> 105
/*    */     //   101: pop
/*    */     //   102: aload_3
/*    */     //   103: aconst_null
/*    */     //   104: astore_3
/*    */     //   105: goto +15 -> 120
/*    */     //   108: pop
/*    */     //   109: aload_1
/*    */     //   110: aconst_null
/*    */     //   111: astore_1
/*    */     //   112: checkcast 25	clojure/lang/IFn
/*    */     //   115: invokeinterface 54 1 0
/*    */     //   120: areturn
/*    */     // Line number table:
/*    */     //   Java source line #33	-> byte code offset #0
/*    */     //   Java source line #35	-> byte code offset #6
/*    */     //   Java source line #36	-> byte code offset #12
/*    */     //   Java source line #36	-> byte code offset #16
/*    */     //   Java source line #37	-> byte code offset #28
/*    */     //   Java source line #38	-> byte code offset #34
/*    */     //   Java source line #38	-> byte code offset #38
/*    */     //   Java source line #39	-> byte code offset #47
/*    */     //   Java source line #39	-> byte code offset #57
/*    */     //   Java source line #39	-> byte code offset #62
/*    */     //   Java source line #40	-> byte code offset #69
/*    */     //   Java source line #40	-> byte code offset #71
/*    */     //   Java source line #44	-> byte code offset #112
/*    */     //   Java source line #44	-> byte code offset #115
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	signature
/*    */     //   0	120	0	coll	Object
/*    */     //   0	120	1	f	Object
/*    */     //   12	108	2	iter	Object
/*    */     //   34	71	3	ret	Object
/*    */     //   69	29	4	ret	Object
/*    */   }
/*    */   
/*    */   public Object invoke(Object paramObject1, Object paramObject2, Object paramObject3)
/*    */   {
/* 33 */     paramObject1 = null;paramObject2 = null;paramObject3 = null;return invokeStatic(paramObject1, paramObject2, paramObject3);
/*    */   }
/*    */   
/*    */   /* Error */
/*    */   public static Object invokeStatic(Object coll, Object f, Object val)
/*    */   {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: aconst_null
/*    */     //   2: astore_0
/*    */     //   3: checkcast 13	java/lang/Iterable
/*    */     //   6: invokeinterface 17 1 0
/*    */     //   11: astore_3
/*    */     //   12: aload_2
/*    */     //   13: aconst_null
/*    */     //   14: astore_2
/*    */     //   15: astore 4
/*    */     //   17: aload_3
/*    */     //   18: checkcast 19	java/util/Iterator
/*    */     //   21: invokeinterface 23 1 0
/*    */     //   26: ifeq +62 -> 88
/*    */     //   29: aload_1
/*    */     //   30: checkcast 25	clojure/lang/IFn
/*    */     //   33: aload 4
/*    */     //   35: aconst_null
/*    */     //   36: astore 4
/*    */     //   38: aload_3
/*    */     //   39: checkcast 19	java/util/Iterator
/*    */     //   42: invokeinterface 29 1 0
/*    */     //   47: invokeinterface 33 3 0
/*    */     //   52: astore 5
/*    */     //   54: aload 5
/*    */     //   56: invokestatic 39	clojure/lang/RT:isReduced	(Ljava/lang/Object;)Z
/*    */     //   59: ifeq +15 -> 74
/*    */     //   62: aload 5
/*    */     //   64: aconst_null
/*    */     //   65: astore 5
/*    */     //   67: invokestatic 44	clojure/core$deref:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   70: goto +14 -> 84
/*    */     //   73: pop
/*    */     //   74: aload 5
/*    */     //   76: aconst_null
/*    */     //   77: astore 5
/*    */     //   79: astore 4
/*    */     //   81: goto -64 -> 17
/*    */     //   84: goto +9 -> 93
/*    */     //   87: pop
/*    */     //   88: aload 4
/*    */     //   90: aconst_null
/*    */     //   91: astore 4
/*    */     //   93: areturn
/*    */     // Line number table:
/*    */     //   Java source line #33	-> byte code offset #0
/*    */     //   Java source line #46	-> byte code offset #6
/*    */     //   Java source line #48	-> byte code offset #17
/*    */     //   Java source line #48	-> byte code offset #21
/*    */     //   Java source line #49	-> byte code offset #30
/*    */     //   Java source line #49	-> byte code offset #42
/*    */     //   Java source line #49	-> byte code offset #47
/*    */     //   Java source line #50	-> byte code offset #54
/*    */     //   Java source line #50	-> byte code offset #56
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	signature
/*    */     //   0	93	0	coll	Object
/*    */     //   0	93	1	f	Object
/*    */     //   0	93	2	val	Object
/*    */     //   12	81	3	iter	Object
/*    */     //   17	76	4	ret	Object
/*    */     //   54	30	5	ret	Object
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\core\protocols$iter_reduce.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */