/*     */ package clojure.core;
/*     */ 
/*     */ import clojure.lang.AFunction;
/*     */ 
/*     */ public final class protocols$fn__6750
/*     */   extends AFunction
/*     */ {
/*     */   /* Error */
/*     */   public static Object invokeStatic(Object s, Object f, Object val)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: aconst_null
/*     */     //   2: astore_0
/*     */     //   3: invokestatic 16	clojure/core$seq__4357:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   6: astore_3
/*     */     //   7: aload_3
/*     */     //   8: dup
/*     */     //   9: ifnull +114 -> 123
/*     */     //   12: getstatic 22	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   15: if_acmpeq +109 -> 124
/*     */     //   18: aload_3
/*     */     //   19: aconst_null
/*     */     //   20: astore_3
/*     */     //   21: astore 4
/*     */     //   23: aload 4
/*     */     //   25: invokestatic 25	clojure/core$chunked_seq_QMARK_:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   28: dup
/*     */     //   29: ifnull +76 -> 105
/*     */     //   32: getstatic 22	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   35: if_acmpeq +71 -> 106
/*     */     //   38: aload 4
/*     */     //   40: invokestatic 28	clojure/core$chunk_first:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   43: checkcast 30	clojure/lang/IChunk
/*     */     //   46: aload_1
/*     */     //   47: checkcast 32	clojure/lang/IFn
/*     */     //   50: aload_2
/*     */     //   51: aconst_null
/*     */     //   52: astore_2
/*     */     //   53: invokeinterface 36 3 0
/*     */     //   58: astore 5
/*     */     //   60: aload 5
/*     */     //   62: invokestatic 42	clojure/lang/RT:isReduced	(Ljava/lang/Object;)Z
/*     */     //   65: ifeq +15 -> 80
/*     */     //   68: aload 5
/*     */     //   70: aconst_null
/*     */     //   71: astore 5
/*     */     //   73: invokestatic 45	clojure/core$deref:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   76: goto +26 -> 102
/*     */     //   79: pop
/*     */     //   80: aload 4
/*     */     //   82: aconst_null
/*     */     //   83: astore 4
/*     */     //   85: invokestatic 48	clojure/core$chunk_next:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   88: aload_1
/*     */     //   89: aconst_null
/*     */     //   90: astore_1
/*     */     //   91: aload 5
/*     */     //   93: aconst_null
/*     */     //   94: astore 5
/*     */     //   96: astore_2
/*     */     //   97: astore_1
/*     */     //   98: astore_0
/*     */     //   99: goto -99 -> 0
/*     */     //   102: goto +18 -> 120
/*     */     //   105: pop
/*     */     //   106: aload 4
/*     */     //   108: aconst_null
/*     */     //   109: astore 4
/*     */     //   111: aload_1
/*     */     //   112: aconst_null
/*     */     //   113: astore_1
/*     */     //   114: aload_2
/*     */     //   115: aconst_null
/*     */     //   116: astore_2
/*     */     //   117: invokestatic 54	clojure/core/protocols$interface_or_naive_reduce:invokeStatic	(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   120: goto +7 -> 127
/*     */     //   123: pop
/*     */     //   124: aload_2
/*     */     //   125: aconst_null
/*     */     //   126: astore_2
/*     */     //   127: areturn
/*     */     // Line number table:
/*     */     //   Java source line #124	-> byte code offset #0
/*     */     //   Java source line #134	-> byte code offset #7
/*     */     //   Java source line #135	-> byte code offset #23
/*     */     //   Java source line #136	-> byte code offset #53
/*     */     //   Java source line #137	-> byte code offset #60
/*     */     //   Java source line #137	-> byte code offset #62
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	127	0	s	Object
/*     */     //   0	127	1	f	Object
/*     */     //   0	127	2	val	Object
/*     */     //   7	120	3	temp__4655__auto__6752	Object
/*     */     //   23	97	4	s	Object
/*     */     //   60	42	5	ret	Object
/*     */   }
/*     */   
/*     */   public Object invoke(Object paramObject1, Object paramObject2, Object paramObject3)
/*     */   {
/* 124 */     paramObject1 = null;paramObject2 = null;paramObject3 = null;return invokeStatic(paramObject1, paramObject2, paramObject3);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\core\protocols$fn__6750.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */