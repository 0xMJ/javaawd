/*    */ package clojure.core;
/*    */ 
/*    */ import clojure.lang.AFunction;
/*    */ import clojure.lang.RT;
/*    */ import clojure.lang.Var;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class protocols$seq_reduce
/*    */   extends AFunction
/*    */ {
/*    */   private static Class __cached_class__0;
/*    */   private static Class __cached_class__1;
/*    */   
/*    */   public Object invoke(Object paramObject1, Object paramObject2)
/*    */   {
/* 24 */     paramObject1 = null;paramObject2 = null;return invokeStatic(paramObject1, paramObject2);
/*    */   }
/*    */   
/*    */   /* Error */
/*    */   public static Object invokeStatic(Object coll, Object f)
/*    */   {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: aconst_null
/*    */     //   2: astore_0
/*    */     //   3: invokestatic 19	clojure/core$seq__4357:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   6: astore_2
/*    */     //   7: aload_2
/*    */     //   8: dup
/*    */     //   9: ifnull +82 -> 91
/*    */     //   12: getstatic 61	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*    */     //   15: if_acmpeq +77 -> 92
/*    */     //   18: aload_2
/*    */     //   19: aconst_null
/*    */     //   20: astore_2
/*    */     //   21: astore_3
/*    */     //   22: aload_3
/*    */     //   23: invokestatic 64	clojure/core$next__4341:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   26: dup
/*    */     //   27: invokestatic 25	clojure/lang/Util:classOf	(Ljava/lang/Object;)Ljava/lang/Class;
/*    */     //   30: getstatic 66	clojure/core/protocols$seq_reduce:__cached_class__0	Ljava/lang/Class;
/*    */     //   33: if_acmpeq +17 -> 50
/*    */     //   36: dup
/*    */     //   37: instanceof 29
/*    */     //   40: ifne +34 -> 74
/*    */     //   43: dup
/*    */     //   44: invokestatic 25	clojure/lang/Util:classOf	(Ljava/lang/Object;)Ljava/lang/Class;
/*    */     //   47: putstatic 66	clojure/core/protocols$seq_reduce:__cached_class__0	Ljava/lang/Class;
/*    */     //   50: getstatic 33	clojure/core/protocols$seq_reduce:const__1	Lclojure/lang/Var;
/*    */     //   53: invokevirtual 39	clojure/lang/Var:getRawRoot	()Ljava/lang/Object;
/*    */     //   56: swap
/*    */     //   57: aload_1
/*    */     //   58: aconst_null
/*    */     //   59: astore_1
/*    */     //   60: aload_3
/*    */     //   61: aconst_null
/*    */     //   62: astore_3
/*    */     //   63: invokestatic 69	clojure/core$first__4339:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   66: invokeinterface 44 4 0
/*    */     //   71: goto +17 -> 88
/*    */     //   74: aload_1
/*    */     //   75: aconst_null
/*    */     //   76: astore_1
/*    */     //   77: aload_3
/*    */     //   78: aconst_null
/*    */     //   79: astore_3
/*    */     //   80: invokestatic 69	clojure/core$first__4339:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   83: invokeinterface 48 3 0
/*    */     //   88: goto +15 -> 103
/*    */     //   91: pop
/*    */     //   92: aload_1
/*    */     //   93: aconst_null
/*    */     //   94: astore_1
/*    */     //   95: checkcast 41	clojure/lang/IFn
/*    */     //   98: invokeinterface 71 1 0
/*    */     //   103: areturn
/*    */     // Line number table:
/*    */     //   Java source line #24	-> byte code offset #0
/*    */     //   Java source line #26	-> byte code offset #7
/*    */     //   Java source line #27	-> byte code offset #22
/*    */     //   Java source line #27	-> byte code offset #66
/*    */     //   Java source line #28	-> byte code offset #95
/*    */     //   Java source line #28	-> byte code offset #98
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	signature
/*    */     //   0	103	0	coll	Object
/*    */     //   0	103	1	f	Object
/*    */     //   7	96	2	temp__4655__auto__6726	Object
/*    */     //   22	66	3	s	Object
/*    */   }
/*    */   
/*    */   public Object invoke(Object paramObject1, Object paramObject2, Object paramObject3)
/*    */   {
/* 24 */     paramObject1 = null;paramObject2 = null;paramObject3 = null;return invokeStatic(paramObject1, paramObject2, paramObject3); } public static final Var const__1 = (Var)RT.var("clojure.core.protocols", "internal-reduce");
/*    */   
/*    */   /* Error */
/*    */   public static Object invokeStatic(Object coll, Object f, Object val)
/*    */   {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: aconst_null
/*    */     //   2: astore_0
/*    */     //   3: invokestatic 19	clojure/core$seq__4357:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   6: astore_3
/*    */     //   7: aload_3
/*    */     //   8: aconst_null
/*    */     //   9: astore_3
/*    */     //   10: dup
/*    */     //   11: invokestatic 25	clojure/lang/Util:classOf	(Ljava/lang/Object;)Ljava/lang/Class;
/*    */     //   14: getstatic 27	clojure/core/protocols$seq_reduce:__cached_class__1	Ljava/lang/Class;
/*    */     //   17: if_acmpeq +17 -> 34
/*    */     //   20: dup
/*    */     //   21: instanceof 29
/*    */     //   24: ifne +31 -> 55
/*    */     //   27: dup
/*    */     //   28: invokestatic 25	clojure/lang/Util:classOf	(Ljava/lang/Object;)Ljava/lang/Class;
/*    */     //   31: putstatic 27	clojure/core/protocols$seq_reduce:__cached_class__1	Ljava/lang/Class;
/*    */     //   34: getstatic 33	clojure/core/protocols$seq_reduce:const__1	Lclojure/lang/Var;
/*    */     //   37: invokevirtual 39	clojure/lang/Var:getRawRoot	()Ljava/lang/Object;
/*    */     //   40: swap
/*    */     //   41: aload_1
/*    */     //   42: aconst_null
/*    */     //   43: astore_1
/*    */     //   44: aload_2
/*    */     //   45: aconst_null
/*    */     //   46: astore_2
/*    */     //   47: invokeinterface 44 4 0
/*    */     //   52: goto +14 -> 66
/*    */     //   55: aload_1
/*    */     //   56: aconst_null
/*    */     //   57: astore_1
/*    */     //   58: aload_2
/*    */     //   59: aconst_null
/*    */     //   60: astore_2
/*    */     //   61: invokeinterface 48 3 0
/*    */     //   66: areturn
/*    */     // Line number table:
/*    */     //   Java source line #24	-> byte code offset #0
/*    */     //   Java source line #31	-> byte code offset #7
/*    */     //   Java source line #31	-> byte code offset #47
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	signature
/*    */     //   0	66	0	coll	Object
/*    */     //   0	66	1	f	Object
/*    */     //   0	66	2	val	Object
/*    */     //   7	59	3	s	Object
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\core\protocols$seq_reduce.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */