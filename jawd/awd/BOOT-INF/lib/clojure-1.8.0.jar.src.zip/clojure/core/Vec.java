/*     */ package clojure.core;
/*     */ 
/*     */ import clojure.core.every_QMARK_;
/*     */ import clojure.core.into_array;
/*     */ import clojure.core.some;
/*     */ import clojure.core.subvec;
/*     */ import clojure.lang.AFn;
/*     */ import clojure.lang.Associative;
/*     */ import clojure.lang.Counted;
/*     */ import clojure.lang.IFn;
/*     */ import clojure.lang.IHashEq;
/*     */ import clojure.lang.ILookup;
/*     */ import clojure.lang.IMeta;
/*     */ import clojure.lang.IObj;
/*     */ import clojure.lang.IPersistentCollection;
/*     */ import clojure.lang.IPersistentMap;
/*     */ import clojure.lang.IPersistentStack;
/*     */ import clojure.lang.IPersistentVector;
/*     */ import clojure.lang.IType;
/*     */ import clojure.lang.Indexed;
/*     */ import clojure.lang.Keyword;
/*     */ import clojure.lang.Murmur3;
/*     */ import clojure.lang.Numbers;
/*     */ import clojure.lang.RT;
/*     */ import clojure.lang.Reversible;
/*     */ import clojure.lang.Seqable;
/*     */ import clojure.lang.Sequential;
/*     */ import clojure.lang.Symbol;
/*     */ import clojure.lang.Tuple;
/*     */ import clojure.lang.Var;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Vec
/*     */   implements Associative, Collection, ILookup, Comparable, IPersistentCollection, IHashEq, IVecImpl, IObj, Reversible, IFn, IMeta, Counted, Sequential, IPersistentVector, Seqable, IPersistentStack, List, Iterable, Indexed, IType
/*     */ {
/*     */   public Vec(Object paramObject1, int paramInt1, int paramInt2, Object paramObject2, Object paramObject3, Object paramObject4)
/*     */   {
/* 131 */     this.am = paramObject1;this.cnt = paramInt1;this.shift = paramInt2;this.root = paramObject2;this.tail = paramObject3;this._meta = paramObject4; } public Iterator iterator() { Object i = new AtomicInteger(RT.intCast(0L));i = null;return (Iterator)((IObj)new Vec.reify__6815(null, this.cnt, i, this)).withMeta((IPersistentMap)const__56); } public List subList(int a, int z) { return (List)core.subvec.invokeStatic(this, Integer.valueOf(a), Integer.valueOf(z)); } public ListIterator listIterator(int i) { Object i = new AtomicInteger(i);i = null;return (ListIterator)((IObj)new Vec.reify__6813(null, this.cnt, i, this)).withMeta((IPersistentMap)const__53); } public int count() { return this.cnt; } public IPersistentMap meta() { return (IPersistentMap)this._meta; } public IObj withMeta(IPersistentMap m) { m = null;return (IObj)new Vec(this.am, this.cnt, this.shift, this.root, this.tail, m); } public int size() { return this.cnt; } public Object[] toArray() { return (Object[])core.into_array.invokeStatic(const__26, this); } public boolean containsAll(Collection c) { c = null;return ((Boolean)core.every_QMARK_.invokeStatic(new Vec.fn__6810(this), c)).booleanValue(); } public static final AFn const__56 = (AFn)RT.map(new Object[] { RT.keyword(null, "line"), Integer.valueOf(386), RT.keyword(null, "column"), Integer.valueOf(7) }); public static final AFn const__53 = (AFn)RT.map(new Object[] { RT.keyword(null, "line"), Integer.valueOf(431), RT.keyword(null, "column"), Integer.valueOf(7) }); public static final Var const__42 = (Var)RT.var("clojure.core", "EMPTY-NODE"); public static final Object const__35 = Long.valueOf(32L); public static final Object const__32 = Long.valueOf(-1L); public static final Object const__26 = RT.classForName("java.lang.Object"); public static final Object const__17 = Long.valueOf(1L); public static final Keyword const__12 = (Keyword)RT.keyword(null, "else"); public static final Object const__6 = RT.classForName("clojure.lang.IPersistentVector"); public static final Object const__1 = Long.valueOf(0L);
/*     */   
/*     */ 
/*     */ 
/*     */   public final Object _meta;
/*     */   
/*     */ 
/*     */ 
/*     */   public final Object tail;
/*     */   
/*     */ 
/*     */ 
/*     */   public final Object root;
/*     */   
/*     */ 
/*     */ 
/*     */   public final int shift;
/*     */   
/*     */ 
/*     */ 
/*     */   public final int cnt;
/*     */   
/*     */ 
/*     */ 
/*     */   public final Object am;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hasheq()
/*     */   {
/* 162 */     return Murmur3.hashOrdered((Iterable)this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object nth(int i)
/*     */   {
/* 175 */     Object a = ((IVecImpl)this).arrayFor(i);a = null;
/* 176 */     return ((ArrayManager)this.am).aget(a, RT.intCast(i & RT.intCast(31L)));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public IPersistentCollection empty()
/*     */   {
/* 200 */     return (IPersistentCollection)new Vec(this.am, RT.intCast(0L), RT.intCast(5L), const__42.getRawRoot(), ((ArrayManager)this.am).array(RT.intCast(0L)), null);
/*     */   }
/*     */   
/*     */   public Object valAt(Object k)
/*     */   {
/* 131 */     k = null;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 282 */     return ((ILookup)this).valAt(k, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int tailoff()
/*     */   {
/* 304 */     return RT.intCast(Numbers.minus(this.cnt, ((ArrayManager)this.am).alength(this.tail)));
/*     */   }
/*     */   
/*     */   public boolean contains(Object o)
/*     */   {
/* 131 */     o = null;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 395 */     return RT.booleanCast(core.some.invokeStatic(new Vec.fn__6808(o), this)); }
/*     */   
/* 397 */   public boolean isEmpty() { return Numbers.isZero(this.cnt); }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object get(int i)
/*     */   {
/* 415 */     return ((Indexed)this).nth(i);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ListIterator listIterator()
/*     */   {
/* 428 */     return (ListIterator)((List)this).listIterator(RT.intCast(0L));
/*     */   }
/*     */   
/*     */   public static IPersistentVector getBasis()
/*     */   {
/*     */     return Tuple.create(((IObj)Symbol.intern(null, "am")).withMeta((IPersistentMap)RT.map(new Object[] { RT.keyword(null, "tag"), Symbol.intern(null, "clojure.core.ArrayManager") })), ((IObj)Symbol.intern(null, "cnt")).withMeta((IPersistentMap)RT.map(new Object[] { RT.keyword(null, "tag"), Symbol.intern(null, "int") })), ((IObj)Symbol.intern(null, "shift")).withMeta((IPersistentMap)RT.map(new Object[] { RT.keyword(null, "tag"), Symbol.intern(null, "int") })), ((IObj)Symbol.intern(null, "root")).withMeta((IPersistentMap)RT.map(new Object[] { RT.keyword(null, "tag"), Symbol.intern(null, "clojure.core.VecNode") })), Symbol.intern(null, "tail"), Symbol.intern(null, "_meta"));
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public Object nth(int i, Object not_found)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: lconst_0
/*     */     //   1: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   4: istore_3
/*     */     //   5: iload_1
/*     */     //   6: i2l
/*     */     //   7: iload_3
/*     */     //   8: i2l
/*     */     //   9: invokestatic 126	clojure/lang/Numbers:gte	(JJ)Z
/*     */     //   12: istore 4
/*     */     //   14: iload 4
/*     */     //   16: ifeq +22 -> 38
/*     */     //   19: iload_1
/*     */     //   20: i2l
/*     */     //   21: aload_0
/*     */     //   22: checkcast 28	clojure/lang/Counted
/*     */     //   25: invokeinterface 130 1 0
/*     */     //   30: i2l
/*     */     //   31: invokestatic 133	clojure/lang/Numbers:lt	(JJ)Z
/*     */     //   34: goto +6 -> 40
/*     */     //   37: pop
/*     */     //   38: iload 4
/*     */     //   40: ifeq +17 -> 57
/*     */     //   43: aload_0
/*     */     //   44: checkcast 42	clojure/lang/Indexed
/*     */     //   47: iload_1
/*     */     //   48: invokeinterface 138 2 0
/*     */     //   53: goto +7 -> 60
/*     */     //   56: pop
/*     */     //   57: aload_2
/*     */     //   58: aconst_null
/*     */     //   59: astore_2
/*     */     //   60: areturn
/*     */     // Line number table:
/*     */     //   Java source line #131	-> byte code offset #0
/*     */     //   Java source line #178	-> byte code offset #1
/*     */     //   Java source line #179	-> byte code offset #5
/*     */     //   Java source line #179	-> byte code offset #9
/*     */     //   Java source line #179	-> byte code offset #14
/*     */     //   Java source line #179	-> byte code offset #25
/*     */     //   Java source line #179	-> byte code offset #31
/*     */     //   Java source line #180	-> byte code offset #48
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	60	0	this	Vec
/*     */     //   0	60	1	i	int
/*     */     //   0	60	2	not_found	Object
/*     */     //   5	55	3	z	int
/*     */     //   14	26	4	and__4467__auto__6818	boolean
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public Object set(int i, Object e)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: new 176	java/lang/UnsupportedOperationException
/*     */     //   3: dup
/*     */     //   4: invokespecial 177	java/lang/UnsupportedOperationException:<init>	()V
/*     */     //   7: checkcast 179	java/lang/Throwable
/*     */     //   10: athrow
/*     */     //   11: areturn
/*     */     // Line number table:
/*     */     //   Java source line #131	-> byte code offset #0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	11	0	this	Vec
/*     */     //   0	11	1	i	int
/*     */     //   0	11	2	e	Object
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public Object remove(int i)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: new 176	java/lang/UnsupportedOperationException
/*     */     //   3: dup
/*     */     //   4: invokespecial 177	java/lang/UnsupportedOperationException:<init>	()V
/*     */     //   7: checkcast 179	java/lang/Throwable
/*     */     //   10: athrow
/*     */     //   11: areturn
/*     */     // Line number table:
/*     */     //   Java source line #131	-> byte code offset #0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	11	0	this	Vec
/*     */     //   0	11	1	i	int
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public boolean addAll(int i, Collection c)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: new 176	java/lang/UnsupportedOperationException
/*     */     //   3: dup
/*     */     //   4: invokespecial 177	java/lang/UnsupportedOperationException:<init>	()V
/*     */     //   7: checkcast 179	java/lang/Throwable
/*     */     //   10: athrow
/*     */     //   11: checkcast 185	java/lang/Boolean
/*     */     //   14: invokevirtual 189	java/lang/Boolean:booleanValue	()Z
/*     */     //   17: ireturn
/*     */     // Line number table:
/*     */     //   Java source line #131	-> byte code offset #0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	17	0	this	Vec
/*     */     //   0	17	1	i	int
/*     */     //   0	17	2	c	Collection
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public void add(int i, Object o)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: new 176	java/lang/UnsupportedOperationException
/*     */     //   3: dup
/*     */     //   4: invokespecial 177	java/lang/UnsupportedOperationException:<init>	()V
/*     */     //   7: checkcast 179	java/lang/Throwable
/*     */     //   10: athrow
/*     */     //   11: pop
/*     */     //   12: return
/*     */     // Line number table:
/*     */     //   Java source line #131	-> byte code offset #0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	12	0	this	Vec
/*     */     //   0	12	1	i	int
/*     */     //   0	12	2	o	Object
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public int lastIndexOf(Object o)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 62	clojure/core/Vec:cnt	I
/*     */     //   4: i2l
/*     */     //   5: invokestatic 227	clojure/lang/Numbers:dec	(J)J
/*     */     //   8: lstore_2
/*     */     //   9: lload_2
/*     */     //   10: lconst_0
/*     */     //   11: lcmp
/*     */     //   12: ifge +10 -> 22
/*     */     //   15: getstatic 230	clojure/core/Vec:const__32	Ljava/lang/Object;
/*     */     //   18: goto +58 -> 76
/*     */     //   21: pop
/*     */     //   22: aload_1
/*     */     //   23: aload_0
/*     */     //   24: checkcast 42	clojure/lang/Indexed
/*     */     //   27: lload_2
/*     */     //   28: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   31: invokeinterface 138 2 0
/*     */     //   36: invokestatic 236	clojure/lang/Util:equiv	(Ljava/lang/Object;Ljava/lang/Object;)Z
/*     */     //   39: ifeq +11 -> 50
/*     */     //   42: lload_2
/*     */     //   43: invokestatic 240	clojure/lang/Numbers:num	(J)Ljava/lang/Number;
/*     */     //   46: goto +30 -> 76
/*     */     //   49: pop
/*     */     //   50: getstatic 244	clojure/core/Vec:const__12	Lclojure/lang/Keyword;
/*     */     //   53: dup
/*     */     //   54: ifnull +20 -> 74
/*     */     //   57: getstatic 248	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   60: if_acmpeq +15 -> 75
/*     */     //   63: lload_2
/*     */     //   64: invokestatic 227	clojure/lang/Numbers:dec	(J)J
/*     */     //   67: lstore_2
/*     */     //   68: goto -59 -> 9
/*     */     //   71: goto +5 -> 76
/*     */     //   74: pop
/*     */     //   75: aconst_null
/*     */     //   76: checkcast 251	java/lang/Number
/*     */     //   79: invokevirtual 254	java/lang/Number:intValue	()I
/*     */     //   82: ireturn
/*     */     // Line number table:
/*     */     //   Java source line #131	-> byte code offset #0
/*     */     //   Java source line #423	-> byte code offset #5
/*     */     //   Java source line #424	-> byte code offset #9
/*     */     //   Java source line #425	-> byte code offset #9
/*     */     //   Java source line #424	-> byte code offset #22
/*     */     //   Java source line #426	-> byte code offset #31
/*     */     //   Java source line #426	-> byte code offset #36
/*     */     //   Java source line #424	-> byte code offset #50
/*     */     //   Java source line #427	-> byte code offset #64
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	82	0	this	Vec
/*     */     //   0	82	1	o	Object
/*     */     //   9	67	2	i	long
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public int indexOf(Object o)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: lconst_0
/*     */     //   1: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   4: i2l
/*     */     //   5: lstore_2
/*     */     //   6: lload_2
/*     */     //   7: aload_0
/*     */     //   8: getfield 62	clojure/core/Vec:cnt	I
/*     */     //   11: i2l
/*     */     //   12: lcmp
/*     */     //   13: ifne +10 -> 23
/*     */     //   16: getstatic 230	clojure/core/Vec:const__32	Ljava/lang/Object;
/*     */     //   19: goto +58 -> 77
/*     */     //   22: pop
/*     */     //   23: aload_1
/*     */     //   24: aload_0
/*     */     //   25: checkcast 42	clojure/lang/Indexed
/*     */     //   28: lload_2
/*     */     //   29: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   32: invokeinterface 138 2 0
/*     */     //   37: invokestatic 236	clojure/lang/Util:equiv	(Ljava/lang/Object;Ljava/lang/Object;)Z
/*     */     //   40: ifeq +11 -> 51
/*     */     //   43: lload_2
/*     */     //   44: invokestatic 240	clojure/lang/Numbers:num	(J)Ljava/lang/Number;
/*     */     //   47: goto +30 -> 77
/*     */     //   50: pop
/*     */     //   51: getstatic 244	clojure/core/Vec:const__12	Lclojure/lang/Keyword;
/*     */     //   54: dup
/*     */     //   55: ifnull +20 -> 75
/*     */     //   58: getstatic 248	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   61: if_acmpeq +15 -> 76
/*     */     //   64: lload_2
/*     */     //   65: invokestatic 258	clojure/lang/Numbers:inc	(J)J
/*     */     //   68: lstore_2
/*     */     //   69: goto -63 -> 6
/*     */     //   72: goto +5 -> 77
/*     */     //   75: pop
/*     */     //   76: aconst_null
/*     */     //   77: checkcast 251	java/lang/Number
/*     */     //   80: invokevirtual 254	java/lang/Number:intValue	()I
/*     */     //   83: ireturn
/*     */     // Line number table:
/*     */     //   Java source line #131	-> byte code offset #0
/*     */     //   Java source line #417	-> byte code offset #1
/*     */     //   Java source line #0	-> byte code offset #4
/*     */     //   Java source line #418	-> byte code offset #6
/*     */     //   Java source line #419	-> byte code offset #6
/*     */     //   Java source line #418	-> byte code offset #23
/*     */     //   Java source line #420	-> byte code offset #32
/*     */     //   Java source line #420	-> byte code offset #37
/*     */     //   Java source line #418	-> byte code offset #51
/*     */     //   Java source line #421	-> byte code offset #65
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	83	0	this	Vec
/*     */     //   0	83	1	o	Object
/*     */     //   6	71	2	i	long
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public IPersistentStack pop()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 62	clojure/core/Vec:cnt	I
/*     */     //   4: i2l
/*     */     //   5: lconst_0
/*     */     //   6: lcmp
/*     */     //   7: ifne +24 -> 31
/*     */     //   10: new 263	java/lang/IllegalStateException
/*     */     //   13: dup
/*     */     //   14: ldc_w 265
/*     */     //   17: checkcast 267	java/lang/String
/*     */     //   20: invokespecial 270	java/lang/IllegalStateException:<init>	(Ljava/lang/String;)V
/*     */     //   23: checkcast 179	java/lang/Throwable
/*     */     //   26: athrow
/*     */     //   27: goto +470 -> 497
/*     */     //   30: pop
/*     */     //   31: lconst_1
/*     */     //   32: aload_0
/*     */     //   33: getfield 62	clojure/core/Vec:cnt	I
/*     */     //   36: i2l
/*     */     //   37: lcmp
/*     */     //   38: ifne +54 -> 92
/*     */     //   41: new 2	clojure/core/Vec
/*     */     //   44: dup
/*     */     //   45: aload_0
/*     */     //   46: getfield 60	clojure/core/Vec:am	Ljava/lang/Object;
/*     */     //   49: lconst_0
/*     */     //   50: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   53: ldc2_w 271
/*     */     //   56: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   59: getstatic 276	clojure/core/Vec:const__42	Lclojure/lang/Var;
/*     */     //   62: invokevirtual 282	clojure/lang/Var:getRawRoot	()Ljava/lang/Object;
/*     */     //   65: aload_0
/*     */     //   66: getfield 60	clojure/core/Vec:am	Ljava/lang/Object;
/*     */     //   69: checkcast 148	clojure/core/ArrayManager
/*     */     //   72: lconst_0
/*     */     //   73: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   76: invokeinterface 285 2 0
/*     */     //   81: aload_0
/*     */     //   82: invokestatic 290	clojure/core$meta__4373:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   85: invokespecial 292	clojure/core/Vec:<init>	(Ljava/lang/Object;IILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
/*     */     //   88: goto +409 -> 497
/*     */     //   91: pop
/*     */     //   92: aload_0
/*     */     //   93: getfield 62	clojure/core/Vec:cnt	I
/*     */     //   96: i2l
/*     */     //   97: aload_0
/*     */     //   98: checkcast 18	clojure/core/IVecImpl
/*     */     //   101: invokeinterface 295 1 0
/*     */     //   106: i2l
/*     */     //   107: invokestatic 299	clojure/lang/Numbers:minus	(JJ)J
/*     */     //   110: lconst_1
/*     */     //   111: lcmp
/*     */     //   112: ifle +109 -> 221
/*     */     //   115: aload_0
/*     */     //   116: getfield 60	clojure/core/Vec:am	Ljava/lang/Object;
/*     */     //   119: checkcast 148	clojure/core/ArrayManager
/*     */     //   122: aload_0
/*     */     //   123: getfield 60	clojure/core/Vec:am	Ljava/lang/Object;
/*     */     //   126: checkcast 148	clojure/core/ArrayManager
/*     */     //   129: aload_0
/*     */     //   130: getfield 68	clojure/core/Vec:tail	Ljava/lang/Object;
/*     */     //   133: invokeinterface 302 2 0
/*     */     //   138: i2l
/*     */     //   139: invokestatic 227	clojure/lang/Numbers:dec	(J)J
/*     */     //   142: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   145: invokeinterface 285 2 0
/*     */     //   150: astore_1
/*     */     //   151: aload_0
/*     */     //   152: getfield 68	clojure/core/Vec:tail	Ljava/lang/Object;
/*     */     //   155: lconst_0
/*     */     //   156: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   159: aload_1
/*     */     //   160: lconst_0
/*     */     //   161: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   164: aload_0
/*     */     //   165: getfield 60	clojure/core/Vec:am	Ljava/lang/Object;
/*     */     //   168: checkcast 148	clojure/core/ArrayManager
/*     */     //   171: aload_1
/*     */     //   172: invokeinterface 302 2 0
/*     */     //   177: invokestatic 308	java/lang/System:arraycopy	(Ljava/lang/Object;ILjava/lang/Object;II)V
/*     */     //   180: new 2	clojure/core/Vec
/*     */     //   183: dup
/*     */     //   184: aload_0
/*     */     //   185: getfield 60	clojure/core/Vec:am	Ljava/lang/Object;
/*     */     //   188: aload_0
/*     */     //   189: getfield 62	clojure/core/Vec:cnt	I
/*     */     //   192: i2l
/*     */     //   193: invokestatic 227	clojure/lang/Numbers:dec	(J)J
/*     */     //   196: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   199: aload_0
/*     */     //   200: getfield 64	clojure/core/Vec:shift	I
/*     */     //   203: aload_0
/*     */     //   204: getfield 66	clojure/core/Vec:root	Ljava/lang/Object;
/*     */     //   207: aload_1
/*     */     //   208: aconst_null
/*     */     //   209: astore_1
/*     */     //   210: aload_0
/*     */     //   211: invokestatic 290	clojure/core$meta__4373:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   214: invokespecial 292	clojure/core/Vec:<init>	(Ljava/lang/Object;IILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
/*     */     //   217: goto +280 -> 497
/*     */     //   220: pop
/*     */     //   221: getstatic 244	clojure/core/Vec:const__12	Lclojure/lang/Keyword;
/*     */     //   224: dup
/*     */     //   225: ifnull +270 -> 495
/*     */     //   228: getstatic 248	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   231: if_acmpeq +265 -> 496
/*     */     //   234: aload_0
/*     */     //   235: checkcast 18	clojure/core/IVecImpl
/*     */     //   238: aload_0
/*     */     //   239: getfield 62	clojure/core/Vec:cnt	I
/*     */     //   242: i2l
/*     */     //   243: ldc2_w 310
/*     */     //   246: invokestatic 299	clojure/lang/Numbers:minus	(JJ)J
/*     */     //   249: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   252: invokeinterface 146 2 0
/*     */     //   257: astore_1
/*     */     //   258: aload_0
/*     */     //   259: checkcast 18	clojure/core/IVecImpl
/*     */     //   262: aload_0
/*     */     //   263: getfield 64	clojure/core/Vec:shift	I
/*     */     //   266: aload_0
/*     */     //   267: getfield 66	clojure/core/Vec:root	Ljava/lang/Object;
/*     */     //   270: invokeinterface 314 3 0
/*     */     //   275: astore_2
/*     */     //   276: aload_2
/*     */     //   277: aconst_null
/*     */     //   278: invokestatic 317	clojure/lang/Util:identical	(Ljava/lang/Object;Ljava/lang/Object;)Z
/*     */     //   281: ifeq +46 -> 327
/*     */     //   284: new 2	clojure/core/Vec
/*     */     //   287: dup
/*     */     //   288: aload_0
/*     */     //   289: getfield 60	clojure/core/Vec:am	Ljava/lang/Object;
/*     */     //   292: aload_0
/*     */     //   293: getfield 62	clojure/core/Vec:cnt	I
/*     */     //   296: i2l
/*     */     //   297: invokestatic 227	clojure/lang/Numbers:dec	(J)J
/*     */     //   300: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   303: aload_0
/*     */     //   304: getfield 64	clojure/core/Vec:shift	I
/*     */     //   307: getstatic 276	clojure/core/Vec:const__42	Lclojure/lang/Var;
/*     */     //   310: invokevirtual 282	clojure/lang/Var:getRawRoot	()Ljava/lang/Object;
/*     */     //   313: aload_1
/*     */     //   314: aconst_null
/*     */     //   315: astore_1
/*     */     //   316: aload_0
/*     */     //   317: invokestatic 290	clojure/core$meta__4373:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   320: invokespecial 292	clojure/core/Vec:<init>	(Ljava/lang/Object;IILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
/*     */     //   323: goto +169 -> 492
/*     */     //   326: pop
/*     */     //   327: aload_0
/*     */     //   328: getfield 64	clojure/core/Vec:shift	I
/*     */     //   331: i2l
/*     */     //   332: ldc2_w 271
/*     */     //   335: invokestatic 320	clojure/lang/Numbers:gt	(JJ)Z
/*     */     //   338: istore_3
/*     */     //   339: iload_3
/*     */     //   340: ifeq +28 -> 368
/*     */     //   343: aload_2
/*     */     //   344: checkcast 322	clojure/core/VecNode
/*     */     //   347: getfield 325	clojure/core/VecNode:arr	Ljava/lang/Object;
/*     */     //   350: checkcast 327	[Ljava/lang/Object;
/*     */     //   353: lconst_1
/*     */     //   354: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   357: invokestatic 330	clojure/lang/RT:aget	([Ljava/lang/Object;I)Ljava/lang/Object;
/*     */     //   360: aconst_null
/*     */     //   361: invokestatic 317	clojure/lang/Util:identical	(Ljava/lang/Object;Ljava/lang/Object;)Z
/*     */     //   364: goto +5 -> 369
/*     */     //   367: pop
/*     */     //   368: iload_3
/*     */     //   369: ifeq +69 -> 438
/*     */     //   372: new 2	clojure/core/Vec
/*     */     //   375: dup
/*     */     //   376: aload_0
/*     */     //   377: getfield 60	clojure/core/Vec:am	Ljava/lang/Object;
/*     */     //   380: aload_0
/*     */     //   381: getfield 62	clojure/core/Vec:cnt	I
/*     */     //   384: i2l
/*     */     //   385: invokestatic 227	clojure/lang/Numbers:dec	(J)J
/*     */     //   388: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   391: aload_0
/*     */     //   392: getfield 64	clojure/core/Vec:shift	I
/*     */     //   395: i2l
/*     */     //   396: ldc2_w 271
/*     */     //   399: invokestatic 299	clojure/lang/Numbers:minus	(JJ)J
/*     */     //   402: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   405: aload_2
/*     */     //   406: aconst_null
/*     */     //   407: astore_2
/*     */     //   408: checkcast 322	clojure/core/VecNode
/*     */     //   411: getfield 325	clojure/core/VecNode:arr	Ljava/lang/Object;
/*     */     //   414: checkcast 327	[Ljava/lang/Object;
/*     */     //   417: lconst_0
/*     */     //   418: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   421: invokestatic 330	clojure/lang/RT:aget	([Ljava/lang/Object;I)Ljava/lang/Object;
/*     */     //   424: aload_1
/*     */     //   425: aconst_null
/*     */     //   426: astore_1
/*     */     //   427: aload_0
/*     */     //   428: invokestatic 290	clojure/core$meta__4373:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   431: invokespecial 292	clojure/core/Vec:<init>	(Ljava/lang/Object;IILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
/*     */     //   434: goto +58 -> 492
/*     */     //   437: pop
/*     */     //   438: getstatic 244	clojure/core/Vec:const__12	Lclojure/lang/Keyword;
/*     */     //   441: dup
/*     */     //   442: ifnull +48 -> 490
/*     */     //   445: getstatic 248	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   448: if_acmpeq +43 -> 491
/*     */     //   451: new 2	clojure/core/Vec
/*     */     //   454: dup
/*     */     //   455: aload_0
/*     */     //   456: getfield 60	clojure/core/Vec:am	Ljava/lang/Object;
/*     */     //   459: aload_0
/*     */     //   460: getfield 62	clojure/core/Vec:cnt	I
/*     */     //   463: i2l
/*     */     //   464: invokestatic 227	clojure/lang/Numbers:dec	(J)J
/*     */     //   467: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   470: aload_0
/*     */     //   471: getfield 64	clojure/core/Vec:shift	I
/*     */     //   474: aload_2
/*     */     //   475: aconst_null
/*     */     //   476: astore_2
/*     */     //   477: aload_1
/*     */     //   478: aconst_null
/*     */     //   479: astore_1
/*     */     //   480: aload_0
/*     */     //   481: invokestatic 290	clojure/core$meta__4373:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   484: invokespecial 292	clojure/core/Vec:<init>	(Ljava/lang/Object;IILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
/*     */     //   487: goto +5 -> 492
/*     */     //   490: pop
/*     */     //   491: aconst_null
/*     */     //   492: goto +5 -> 497
/*     */     //   495: pop
/*     */     //   496: aconst_null
/*     */     //   497: checkcast 36	clojure/lang/IPersistentStack
/*     */     //   500: areturn
/*     */     // Line number table:
/*     */     //   Java source line #131	-> byte code offset #0
/*     */     //   Java source line #220	-> byte code offset #0
/*     */     //   Java source line #221	-> byte code offset #0
/*     */     //   Java source line #220	-> byte code offset #31
/*     */     //   Java source line #223	-> byte code offset #31
/*     */     //   Java source line #224	-> byte code offset #76
/*     */     //   Java source line #220	-> byte code offset #92
/*     */     //   Java source line #225	-> byte code offset #92
/*     */     //   Java source line #225	-> byte code offset #101
/*     */     //   Java source line #225	-> byte code offset #107
/*     */     //   Java source line #226	-> byte code offset #133
/*     */     //   Java source line #226	-> byte code offset #139
/*     */     //   Java source line #226	-> byte code offset #145
/*     */     //   Java source line #227	-> byte code offset #172
/*     */     //   Java source line #227	-> byte code offset #177
/*     */     //   Java source line #228	-> byte code offset #193
/*     */     //   Java source line #220	-> byte code offset #221
/*     */     //   Java source line #230	-> byte code offset #246
/*     */     //   Java source line #230	-> byte code offset #252
/*     */     //   Java source line #231	-> byte code offset #270
/*     */     //   Java source line #232	-> byte code offset #276
/*     */     //   Java source line #233	-> byte code offset #278
/*     */     //   Java source line #234	-> byte code offset #297
/*     */     //   Java source line #232	-> byte code offset #327
/*     */     //   Java source line #235	-> byte code offset #335
/*     */     //   Java source line #235	-> byte code offset #339
/*     */     //   Java source line #235	-> byte code offset #344
/*     */     //   Java source line #235	-> byte code offset #354
/*     */     //   Java source line #235	-> byte code offset #357
/*     */     //   Java source line #235	-> byte code offset #361
/*     */     //   Java source line #236	-> byte code offset #385
/*     */     //   Java source line #236	-> byte code offset #399
/*     */     //   Java source line #236	-> byte code offset #408
/*     */     //   Java source line #236	-> byte code offset #418
/*     */     //   Java source line #236	-> byte code offset #421
/*     */     //   Java source line #232	-> byte code offset #438
/*     */     //   Java source line #238	-> byte code offset #464
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	500	0	this	Vec
/*     */     //   151	66	1	new_tail	Object
/*     */     //   258	234	1	new_tail	Object
/*     */     //   276	216	2	new_root	Object
/*     */     //   339	30	3	and__4467__auto__6819	boolean
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public Object peek()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 62	clojure/core/Vec:cnt	I
/*     */     //   4: i2l
/*     */     //   5: lconst_0
/*     */     //   6: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   9: i2l
/*     */     //   10: lcmp
/*     */     //   11: ifle +27 -> 38
/*     */     //   14: aload_0
/*     */     //   15: checkcast 42	clojure/lang/Indexed
/*     */     //   18: aload_0
/*     */     //   19: getfield 62	clojure/core/Vec:cnt	I
/*     */     //   22: i2l
/*     */     //   23: invokestatic 227	clojure/lang/Numbers:dec	(J)J
/*     */     //   26: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   29: invokeinterface 138 2 0
/*     */     //   34: goto +5 -> 39
/*     */     //   37: pop
/*     */     //   38: aconst_null
/*     */     //   39: areturn
/*     */     // Line number table:
/*     */     //   Java source line #131	-> byte code offset #0
/*     */     //   Java source line #216	-> byte code offset #0
/*     */     //   Java source line #216	-> byte code offset #0
/*     */     //   Java source line #216	-> byte code offset #6
/*     */     //   Java source line #217	-> byte code offset #23
/*     */     //   Java source line #217	-> byte code offset #29
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	39	0	this	Vec
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public clojure.lang.ISeq seq()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 62	clojure/core/Vec:cnt	I
/*     */     //   4: i2l
/*     */     //   5: lconst_0
/*     */     //   6: lcmp
/*     */     //   7: ifne +8 -> 15
/*     */     //   10: aconst_null
/*     */     //   11: goto +37 -> 48
/*     */     //   14: pop
/*     */     //   15: new 337	clojure/core/VecSeq
/*     */     //   18: dup
/*     */     //   19: aload_0
/*     */     //   20: getfield 60	clojure/core/Vec:am	Ljava/lang/Object;
/*     */     //   23: aload_0
/*     */     //   24: aload_0
/*     */     //   25: checkcast 18	clojure/core/IVecImpl
/*     */     //   28: lconst_0
/*     */     //   29: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   32: invokeinterface 146 2 0
/*     */     //   37: lconst_0
/*     */     //   38: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   41: lconst_0
/*     */     //   42: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   45: invokespecial 340	clojure/core/VecSeq:<init>	(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;II)V
/*     */     //   48: checkcast 342	clojure/lang/ISeq
/*     */     //   51: areturn
/*     */     // Line number table:
/*     */     //   Java source line #131	-> byte code offset #0
/*     */     //   Java source line #296	-> byte code offset #0
/*     */     //   Java source line #296	-> byte code offset #0
/*     */     //   Java source line #298	-> byte code offset #32
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	51	0	this	Vec
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public IPersistentVector assocN(int i, Object val)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: lconst_0
/*     */     //   1: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   4: i2l
/*     */     //   5: iload_1
/*     */     //   6: i2l
/*     */     //   7: invokestatic 347	clojure/lang/Numbers:lte	(JJ)Z
/*     */     //   10: istore_3
/*     */     //   11: iload_3
/*     */     //   12: ifeq +17 -> 29
/*     */     //   15: iload_1
/*     */     //   16: i2l
/*     */     //   17: aload_0
/*     */     //   18: getfield 62	clojure/core/Vec:cnt	I
/*     */     //   21: i2l
/*     */     //   22: invokestatic 133	clojure/lang/Numbers:lt	(JJ)Z
/*     */     //   25: goto +5 -> 30
/*     */     //   28: pop
/*     */     //   29: iload_3
/*     */     //   30: ifeq +196 -> 226
/*     */     //   33: iload_1
/*     */     //   34: i2l
/*     */     //   35: aload_0
/*     */     //   36: checkcast 18	clojure/core/IVecImpl
/*     */     //   39: invokeinterface 295 1 0
/*     */     //   44: i2l
/*     */     //   45: lcmp
/*     */     //   46: iflt +128 -> 174
/*     */     //   49: aload_0
/*     */     //   50: getfield 60	clojure/core/Vec:am	Ljava/lang/Object;
/*     */     //   53: checkcast 148	clojure/core/ArrayManager
/*     */     //   56: aload_0
/*     */     //   57: getfield 60	clojure/core/Vec:am	Ljava/lang/Object;
/*     */     //   60: checkcast 148	clojure/core/ArrayManager
/*     */     //   63: aload_0
/*     */     //   64: getfield 68	clojure/core/Vec:tail	Ljava/lang/Object;
/*     */     //   67: invokeinterface 302 2 0
/*     */     //   72: invokeinterface 285 2 0
/*     */     //   77: astore_3
/*     */     //   78: aload_0
/*     */     //   79: getfield 68	clojure/core/Vec:tail	Ljava/lang/Object;
/*     */     //   82: lconst_0
/*     */     //   83: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   86: aload_3
/*     */     //   87: lconst_0
/*     */     //   88: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   91: aload_0
/*     */     //   92: getfield 60	clojure/core/Vec:am	Ljava/lang/Object;
/*     */     //   95: checkcast 148	clojure/core/ArrayManager
/*     */     //   98: aload_0
/*     */     //   99: getfield 68	clojure/core/Vec:tail	Ljava/lang/Object;
/*     */     //   102: invokeinterface 302 2 0
/*     */     //   107: invokestatic 308	java/lang/System:arraycopy	(Ljava/lang/Object;ILjava/lang/Object;II)V
/*     */     //   110: aload_0
/*     */     //   111: getfield 60	clojure/core/Vec:am	Ljava/lang/Object;
/*     */     //   114: checkcast 148	clojure/core/ArrayManager
/*     */     //   117: aload_3
/*     */     //   118: iload_1
/*     */     //   119: i2l
/*     */     //   120: ldc2_w 149
/*     */     //   123: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   126: i2l
/*     */     //   127: land
/*     */     //   128: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   131: aload_2
/*     */     //   132: aconst_null
/*     */     //   133: astore_2
/*     */     //   134: invokeinterface 352 4 0
/*     */     //   139: pop
/*     */     //   140: new 2	clojure/core/Vec
/*     */     //   143: dup
/*     */     //   144: aload_0
/*     */     //   145: getfield 60	clojure/core/Vec:am	Ljava/lang/Object;
/*     */     //   148: aload_0
/*     */     //   149: getfield 62	clojure/core/Vec:cnt	I
/*     */     //   152: aload_0
/*     */     //   153: getfield 64	clojure/core/Vec:shift	I
/*     */     //   156: aload_0
/*     */     //   157: getfield 66	clojure/core/Vec:root	Ljava/lang/Object;
/*     */     //   160: aload_3
/*     */     //   161: aconst_null
/*     */     //   162: astore_3
/*     */     //   163: aload_0
/*     */     //   164: invokestatic 290	clojure/core$meta__4373:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   167: invokespecial 292	clojure/core/Vec:<init>	(Ljava/lang/Object;IILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
/*     */     //   170: goto +52 -> 222
/*     */     //   173: pop
/*     */     //   174: new 2	clojure/core/Vec
/*     */     //   177: dup
/*     */     //   178: aload_0
/*     */     //   179: getfield 60	clojure/core/Vec:am	Ljava/lang/Object;
/*     */     //   182: aload_0
/*     */     //   183: getfield 62	clojure/core/Vec:cnt	I
/*     */     //   186: aload_0
/*     */     //   187: getfield 64	clojure/core/Vec:shift	I
/*     */     //   190: aload_0
/*     */     //   191: checkcast 18	clojure/core/IVecImpl
/*     */     //   194: aload_0
/*     */     //   195: getfield 64	clojure/core/Vec:shift	I
/*     */     //   198: aload_0
/*     */     //   199: getfield 66	clojure/core/Vec:root	Ljava/lang/Object;
/*     */     //   202: iload_1
/*     */     //   203: aload_2
/*     */     //   204: aconst_null
/*     */     //   205: astore_2
/*     */     //   206: invokeinterface 356 5 0
/*     */     //   211: aload_0
/*     */     //   212: getfield 68	clojure/core/Vec:tail	Ljava/lang/Object;
/*     */     //   215: aload_0
/*     */     //   216: invokestatic 290	clojure/core$meta__4373:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   219: invokespecial 292	clojure/core/Vec:<init>	(Ljava/lang/Object;IILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
/*     */     //   222: goto +60 -> 282
/*     */     //   225: pop
/*     */     //   226: iload_1
/*     */     //   227: i2l
/*     */     //   228: aload_0
/*     */     //   229: getfield 62	clojure/core/Vec:cnt	I
/*     */     //   232: i2l
/*     */     //   233: lcmp
/*     */     //   234: ifne +19 -> 253
/*     */     //   237: aload_0
/*     */     //   238: checkcast 32	clojure/lang/IPersistentVector
/*     */     //   241: aload_2
/*     */     //   242: aconst_null
/*     */     //   243: astore_2
/*     */     //   244: invokeinterface 360 2 0
/*     */     //   249: goto +33 -> 282
/*     */     //   252: pop
/*     */     //   253: getstatic 244	clojure/core/Vec:const__12	Lclojure/lang/Keyword;
/*     */     //   256: dup
/*     */     //   257: ifnull +23 -> 280
/*     */     //   260: getstatic 248	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   263: if_acmpeq +18 -> 281
/*     */     //   266: new 362	java/lang/IndexOutOfBoundsException
/*     */     //   269: dup
/*     */     //   270: invokespecial 363	java/lang/IndexOutOfBoundsException:<init>	()V
/*     */     //   273: checkcast 179	java/lang/Throwable
/*     */     //   276: athrow
/*     */     //   277: goto +5 -> 282
/*     */     //   280: pop
/*     */     //   281: aconst_null
/*     */     //   282: checkcast 32	clojure/lang/IPersistentVector
/*     */     //   285: areturn
/*     */     // Line number table:
/*     */     //   Java source line #131	-> byte code offset #0
/*     */     //   Java source line #242	-> byte code offset #0
/*     */     //   Java source line #243	-> byte code offset #1
/*     */     //   Java source line #243	-> byte code offset #7
/*     */     //   Java source line #243	-> byte code offset #11
/*     */     //   Java source line #243	-> byte code offset #22
/*     */     //   Java source line #244	-> byte code offset #33
/*     */     //   Java source line #244	-> byte code offset #33
/*     */     //   Java source line #244	-> byte code offset #39
/*     */     //   Java source line #245	-> byte code offset #67
/*     */     //   Java source line #245	-> byte code offset #72
/*     */     //   Java source line #246	-> byte code offset #102
/*     */     //   Java source line #246	-> byte code offset #107
/*     */     //   Java source line #247	-> byte code offset #123
/*     */     //   Java source line #247	-> byte code offset #127
/*     */     //   Java source line #247	-> byte code offset #134
/*     */     //   Java source line #249	-> byte code offset #206
/*     */     //   Java source line #242	-> byte code offset #226
/*     */     //   Java source line #250	-> byte code offset #226
/*     */     //   Java source line #250	-> byte code offset #244
/*     */     //   Java source line #242	-> byte code offset #253
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	285	0	this	Vec
/*     */     //   0	285	1	i	int
/*     */     //   0	285	2	val	Object
/*     */     //   11	19	3	and__4467__auto__6820	boolean
/*     */     //   78	92	3	new_tail	Object
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public Object invoke(Object k)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_1
/*     */     //   1: invokestatic 371	clojure/lang/Util:isInteger	(Ljava/lang/Object;)Z
/*     */     //   4: ifeq +68 -> 72
/*     */     //   7: aload_1
/*     */     //   8: aconst_null
/*     */     //   9: astore_1
/*     */     //   10: invokestatic 373	clojure/lang/RT:intCast	(Ljava/lang/Object;)I
/*     */     //   13: istore_2
/*     */     //   14: iload_2
/*     */     //   15: i2l
/*     */     //   16: lconst_0
/*     */     //   17: invokestatic 126	clojure/lang/Numbers:gte	(JJ)Z
/*     */     //   20: istore_3
/*     */     //   21: iload_3
/*     */     //   22: ifeq +17 -> 39
/*     */     //   25: iload_2
/*     */     //   26: i2l
/*     */     //   27: aload_0
/*     */     //   28: getfield 62	clojure/core/Vec:cnt	I
/*     */     //   31: i2l
/*     */     //   32: invokestatic 133	clojure/lang/Numbers:lt	(JJ)Z
/*     */     //   35: goto +5 -> 40
/*     */     //   38: pop
/*     */     //   39: iload_3
/*     */     //   40: ifeq +17 -> 57
/*     */     //   43: aload_0
/*     */     //   44: checkcast 42	clojure/lang/Indexed
/*     */     //   47: iload_2
/*     */     //   48: invokeinterface 138 2 0
/*     */     //   53: goto +15 -> 68
/*     */     //   56: pop
/*     */     //   57: new 362	java/lang/IndexOutOfBoundsException
/*     */     //   60: dup
/*     */     //   61: invokespecial 363	java/lang/IndexOutOfBoundsException:<init>	()V
/*     */     //   64: checkcast 179	java/lang/Throwable
/*     */     //   67: athrow
/*     */     //   68: goto +21 -> 89
/*     */     //   71: pop
/*     */     //   72: new 376	java/lang/IllegalArgumentException
/*     */     //   75: dup
/*     */     //   76: ldc_w 378
/*     */     //   79: checkcast 267	java/lang/String
/*     */     //   82: invokespecial 379	java/lang/IllegalArgumentException:<init>	(Ljava/lang/String;)V
/*     */     //   85: checkcast 179	java/lang/Throwable
/*     */     //   88: athrow
/*     */     //   89: areturn
/*     */     // Line number table:
/*     */     //   Java source line #131	-> byte code offset #0
/*     */     //   Java source line #286	-> byte code offset #0
/*     */     //   Java source line #286	-> byte code offset #1
/*     */     //   Java source line #287	-> byte code offset #10
/*     */     //   Java source line #288	-> byte code offset #14
/*     */     //   Java source line #288	-> byte code offset #17
/*     */     //   Java source line #288	-> byte code offset #21
/*     */     //   Java source line #288	-> byte code offset #32
/*     */     //   Java source line #289	-> byte code offset #48
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	89	0	this	Vec
/*     */     //   0	89	1	k	Object
/*     */     //   14	54	2	i	int
/*     */     //   21	19	3	and__4467__auto__6821	boolean
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public clojure.lang.ISeq rseq()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: checkcast 28	clojure/lang/Counted
/*     */     //   4: invokeinterface 130 1 0
/*     */     //   9: i2l
/*     */     //   10: lconst_0
/*     */     //   11: lcmp
/*     */     //   12: ifle +34 -> 46
/*     */     //   15: new 383	clojure/lang/APersistentVector$RSeq
/*     */     //   18: dup
/*     */     //   19: aload_0
/*     */     //   20: checkcast 32	clojure/lang/IPersistentVector
/*     */     //   23: aload_0
/*     */     //   24: checkcast 28	clojure/lang/Counted
/*     */     //   27: invokeinterface 130 1 0
/*     */     //   32: i2l
/*     */     //   33: invokestatic 227	clojure/lang/Numbers:dec	(J)J
/*     */     //   36: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   39: invokespecial 386	clojure/lang/APersistentVector$RSeq:<init>	(Lclojure/lang/IPersistentVector;I)V
/*     */     //   42: goto +5 -> 47
/*     */     //   45: pop
/*     */     //   46: aconst_null
/*     */     //   47: checkcast 342	clojure/lang/ISeq
/*     */     //   50: areturn
/*     */     // Line number table:
/*     */     //   Java source line #131	-> byte code offset #0
/*     */     //   Java source line #255	-> byte code offset #0
/*     */     //   Java source line #255	-> byte code offset #0
/*     */     //   Java source line #255	-> byte code offset #4
/*     */     //   Java source line #256	-> byte code offset #27
/*     */     //   Java source line #256	-> byte code offset #33
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	50	0	this	Vec
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public Object doAssoc(int level, Object node, int i, Object val)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_2
/*     */     //   1: aconst_null
/*     */     //   2: astore_2
/*     */     //   3: astore 5
/*     */     //   5: iload_1
/*     */     //   6: i2l
/*     */     //   7: lconst_0
/*     */     //   8: lcmp
/*     */     //   9: ifne +85 -> 94
/*     */     //   12: aload_0
/*     */     //   13: getfield 60	clojure/core/Vec:am	Ljava/lang/Object;
/*     */     //   16: checkcast 148	clojure/core/ArrayManager
/*     */     //   19: aload 5
/*     */     //   21: checkcast 322	clojure/core/VecNode
/*     */     //   24: getfield 325	clojure/core/VecNode:arr	Ljava/lang/Object;
/*     */     //   27: invokeinterface 391 2 0
/*     */     //   32: astore 6
/*     */     //   34: aload_0
/*     */     //   35: getfield 60	clojure/core/Vec:am	Ljava/lang/Object;
/*     */     //   38: checkcast 148	clojure/core/ArrayManager
/*     */     //   41: aload 6
/*     */     //   43: iload_3
/*     */     //   44: i2l
/*     */     //   45: ldc2_w 149
/*     */     //   48: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   51: i2l
/*     */     //   52: land
/*     */     //   53: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   56: aload 4
/*     */     //   58: aconst_null
/*     */     //   59: astore 4
/*     */     //   61: invokeinterface 352 4 0
/*     */     //   66: pop
/*     */     //   67: new 322	clojure/core/VecNode
/*     */     //   70: dup
/*     */     //   71: aload 5
/*     */     //   73: aconst_null
/*     */     //   74: astore 5
/*     */     //   76: checkcast 322	clojure/core/VecNode
/*     */     //   79: getfield 394	clojure/core/VecNode:edit	Ljava/lang/Object;
/*     */     //   82: aload 6
/*     */     //   84: aconst_null
/*     */     //   85: astore 6
/*     */     //   87: invokespecial 397	clojure/core/VecNode:<init>	(Ljava/lang/Object;Ljava/lang/Object;)V
/*     */     //   90: goto +116 -> 206
/*     */     //   93: pop
/*     */     //   94: aload 5
/*     */     //   96: checkcast 322	clojure/core/VecNode
/*     */     //   99: getfield 325	clojure/core/VecNode:arr	Ljava/lang/Object;
/*     */     //   102: checkcast 327	[Ljava/lang/Object;
/*     */     //   105: invokestatic 400	clojure/lang/RT:aclone	([Ljava/lang/Object;)[Ljava/lang/Object;
/*     */     //   108: astore 6
/*     */     //   110: iload_3
/*     */     //   111: i2l
/*     */     //   112: iload_1
/*     */     //   113: i2l
/*     */     //   114: l2i
/*     */     //   115: lshr
/*     */     //   116: ldc2_w 149
/*     */     //   119: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   122: i2l
/*     */     //   123: land
/*     */     //   124: lstore 7
/*     */     //   126: aload 6
/*     */     //   128: checkcast 327	[Ljava/lang/Object;
/*     */     //   131: lload 7
/*     */     //   133: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   136: aload_0
/*     */     //   137: checkcast 18	clojure/core/IVecImpl
/*     */     //   140: iload_1
/*     */     //   141: i2l
/*     */     //   142: ldc2_w 271
/*     */     //   145: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   148: i2l
/*     */     //   149: invokestatic 299	clojure/lang/Numbers:minus	(JJ)J
/*     */     //   152: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   155: aload 6
/*     */     //   157: checkcast 327	[Ljava/lang/Object;
/*     */     //   160: lload 7
/*     */     //   162: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   165: invokestatic 330	clojure/lang/RT:aget	([Ljava/lang/Object;I)Ljava/lang/Object;
/*     */     //   168: iload_3
/*     */     //   169: aload 4
/*     */     //   171: aconst_null
/*     */     //   172: astore 4
/*     */     //   174: invokeinterface 356 5 0
/*     */     //   179: invokestatic 403	clojure/lang/RT:aset	([Ljava/lang/Object;ILjava/lang/Object;)Ljava/lang/Object;
/*     */     //   182: pop
/*     */     //   183: new 322	clojure/core/VecNode
/*     */     //   186: dup
/*     */     //   187: aload 5
/*     */     //   189: aconst_null
/*     */     //   190: astore 5
/*     */     //   192: checkcast 322	clojure/core/VecNode
/*     */     //   195: getfield 394	clojure/core/VecNode:edit	Ljava/lang/Object;
/*     */     //   198: aload 6
/*     */     //   200: aconst_null
/*     */     //   201: astore 6
/*     */     //   203: invokespecial 397	clojure/core/VecNode:<init>	(Ljava/lang/Object;Ljava/lang/Object;)V
/*     */     //   206: areturn
/*     */     // Line number table:
/*     */     //   Java source line #131	-> byte code offset #0
/*     */     //   Java source line #355	-> byte code offset #5
/*     */     //   Java source line #355	-> byte code offset #5
/*     */     //   Java source line #357	-> byte code offset #21
/*     */     //   Java source line #357	-> byte code offset #27
/*     */     //   Java source line #358	-> byte code offset #48
/*     */     //   Java source line #358	-> byte code offset #52
/*     */     //   Java source line #358	-> byte code offset #61
/*     */     //   Java source line #359	-> byte code offset #76
/*     */     //   Java source line #360	-> byte code offset #96
/*     */     //   Java source line #360	-> byte code offset #105
/*     */     //   Java source line #361	-> byte code offset #114
/*     */     //   Java source line #361	-> byte code offset #119
/*     */     //   Java source line #361	-> byte code offset #123
/*     */     //   Java source line #362	-> byte code offset #133
/*     */     //   Java source line #362	-> byte code offset #145
/*     */     //   Java source line #362	-> byte code offset #149
/*     */     //   Java source line #362	-> byte code offset #162
/*     */     //   Java source line #362	-> byte code offset #165
/*     */     //   Java source line #362	-> byte code offset #174
/*     */     //   Java source line #362	-> byte code offset #179
/*     */     //   Java source line #363	-> byte code offset #192
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	206	0	this	Vec
/*     */     //   0	206	1	level	int
/*     */     //   0	206	2	node	Object
/*     */     //   0	206	3	i	int
/*     */     //   0	206	4	val	Object
/*     */     //   5	201	5	node	Object
/*     */     //   34	56	6	arr	Object
/*     */     //   110	96	6	arr	Object
/*     */     //   126	80	7	subidx	long
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public Object newPath(Object edit, int level, Object node)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: iload_2
/*     */     //   1: i2l
/*     */     //   2: lconst_0
/*     */     //   3: lcmp
/*     */     //   4: ifne +10 -> 14
/*     */     //   7: aload_3
/*     */     //   8: aconst_null
/*     */     //   9: astore_3
/*     */     //   10: goto +74 -> 84
/*     */     //   13: pop
/*     */     //   14: new 322	clojure/core/VecNode
/*     */     //   17: dup
/*     */     //   18: aload_1
/*     */     //   19: getstatic 410	clojure/core/Vec:const__35	Ljava/lang/Object;
/*     */     //   22: invokestatic 414	clojure/lang/RT:object_array	(Ljava/lang/Object;)[Ljava/lang/Object;
/*     */     //   25: invokespecial 397	clojure/core/VecNode:<init>	(Ljava/lang/Object;Ljava/lang/Object;)V
/*     */     //   28: astore 4
/*     */     //   30: aload 4
/*     */     //   32: checkcast 322	clojure/core/VecNode
/*     */     //   35: getfield 325	clojure/core/VecNode:arr	Ljava/lang/Object;
/*     */     //   38: checkcast 327	[Ljava/lang/Object;
/*     */     //   41: lconst_0
/*     */     //   42: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   45: aload_0
/*     */     //   46: checkcast 18	clojure/core/IVecImpl
/*     */     //   49: aload_1
/*     */     //   50: aconst_null
/*     */     //   51: astore_1
/*     */     //   52: iload_2
/*     */     //   53: i2l
/*     */     //   54: ldc2_w 271
/*     */     //   57: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   60: i2l
/*     */     //   61: invokestatic 299	clojure/lang/Numbers:minus	(JJ)J
/*     */     //   64: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   67: aload_3
/*     */     //   68: aconst_null
/*     */     //   69: astore_3
/*     */     //   70: invokeinterface 416 4 0
/*     */     //   75: invokestatic 403	clojure/lang/RT:aset	([Ljava/lang/Object;ILjava/lang/Object;)Ljava/lang/Object;
/*     */     //   78: pop
/*     */     //   79: aload 4
/*     */     //   81: aconst_null
/*     */     //   82: astore 4
/*     */     //   84: areturn
/*     */     // Line number table:
/*     */     //   Java source line #131	-> byte code offset #0
/*     */     //   Java source line #347	-> byte code offset #0
/*     */     //   Java source line #347	-> byte code offset #0
/*     */     //   Java source line #349	-> byte code offset #22
/*     */     //   Java source line #350	-> byte code offset #32
/*     */     //   Java source line #350	-> byte code offset #42
/*     */     //   Java source line #350	-> byte code offset #57
/*     */     //   Java source line #350	-> byte code offset #61
/*     */     //   Java source line #350	-> byte code offset #70
/*     */     //   Java source line #350	-> byte code offset #75
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	84	0	this	Vec
/*     */     //   0	84	1	edit	Object
/*     */     //   0	84	2	level	int
/*     */     //   0	84	3	node	Object
/*     */     //   30	54	4	ret	Object
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public Object popTail(int level, Object node)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_2
/*     */     //   1: aconst_null
/*     */     //   2: astore_2
/*     */     //   3: astore_3
/*     */     //   4: aload_0
/*     */     //   5: getfield 62	clojure/core/Vec:cnt	I
/*     */     //   8: i2l
/*     */     //   9: ldc2_w 310
/*     */     //   12: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   15: i2l
/*     */     //   16: invokestatic 299	clojure/lang/Numbers:minus	(JJ)J
/*     */     //   19: iload_1
/*     */     //   20: i2l
/*     */     //   21: l2i
/*     */     //   22: lshr
/*     */     //   23: ldc2_w 149
/*     */     //   26: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   29: i2l
/*     */     //   30: land
/*     */     //   31: lstore 4
/*     */     //   33: iload_1
/*     */     //   34: i2l
/*     */     //   35: ldc2_w 271
/*     */     //   38: lcmp
/*     */     //   39: ifle +137 -> 176
/*     */     //   42: aload_0
/*     */     //   43: checkcast 18	clojure/core/IVecImpl
/*     */     //   46: iload_1
/*     */     //   47: i2l
/*     */     //   48: ldc2_w 271
/*     */     //   51: invokestatic 299	clojure/lang/Numbers:minus	(JJ)J
/*     */     //   54: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   57: aload_3
/*     */     //   58: checkcast 322	clojure/core/VecNode
/*     */     //   61: getfield 325	clojure/core/VecNode:arr	Ljava/lang/Object;
/*     */     //   64: checkcast 327	[Ljava/lang/Object;
/*     */     //   67: lload 4
/*     */     //   69: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   72: invokestatic 330	clojure/lang/RT:aget	([Ljava/lang/Object;I)Ljava/lang/Object;
/*     */     //   75: invokeinterface 314 3 0
/*     */     //   80: astore 6
/*     */     //   82: aload 6
/*     */     //   84: aconst_null
/*     */     //   85: invokestatic 317	clojure/lang/Util:identical	(Ljava/lang/Object;Ljava/lang/Object;)Z
/*     */     //   88: istore 7
/*     */     //   90: iload 7
/*     */     //   92: ifeq +12 -> 104
/*     */     //   95: lload 4
/*     */     //   97: invokestatic 421	clojure/lang/Numbers:isZero	(J)Z
/*     */     //   100: goto +6 -> 106
/*     */     //   103: pop
/*     */     //   104: iload 7
/*     */     //   106: ifeq +8 -> 114
/*     */     //   109: aconst_null
/*     */     //   110: goto +62 -> 172
/*     */     //   113: pop
/*     */     //   114: aload_3
/*     */     //   115: aconst_null
/*     */     //   116: astore_3
/*     */     //   117: checkcast 322	clojure/core/VecNode
/*     */     //   120: getfield 325	clojure/core/VecNode:arr	Ljava/lang/Object;
/*     */     //   123: checkcast 327	[Ljava/lang/Object;
/*     */     //   126: invokestatic 400	clojure/lang/RT:aclone	([Ljava/lang/Object;)[Ljava/lang/Object;
/*     */     //   129: astore 7
/*     */     //   131: aload 7
/*     */     //   133: checkcast 327	[Ljava/lang/Object;
/*     */     //   136: lload 4
/*     */     //   138: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   141: aload 6
/*     */     //   143: aconst_null
/*     */     //   144: astore 6
/*     */     //   146: invokestatic 403	clojure/lang/RT:aset	([Ljava/lang/Object;ILjava/lang/Object;)Ljava/lang/Object;
/*     */     //   149: pop
/*     */     //   150: new 322	clojure/core/VecNode
/*     */     //   153: dup
/*     */     //   154: aload_0
/*     */     //   155: getfield 66	clojure/core/Vec:root	Ljava/lang/Object;
/*     */     //   158: checkcast 322	clojure/core/VecNode
/*     */     //   161: getfield 394	clojure/core/VecNode:edit	Ljava/lang/Object;
/*     */     //   164: aload 7
/*     */     //   166: aconst_null
/*     */     //   167: astore 7
/*     */     //   169: invokespecial 397	clojure/core/VecNode:<init>	(Ljava/lang/Object;Ljava/lang/Object;)V
/*     */     //   172: goto +88 -> 260
/*     */     //   175: pop
/*     */     //   176: lload 4
/*     */     //   178: lconst_0
/*     */     //   179: lcmp
/*     */     //   180: ifne +8 -> 188
/*     */     //   183: aconst_null
/*     */     //   184: goto +76 -> 260
/*     */     //   187: pop
/*     */     //   188: getstatic 244	clojure/core/Vec:const__12	Lclojure/lang/Keyword;
/*     */     //   191: dup
/*     */     //   192: ifnull +66 -> 258
/*     */     //   195: getstatic 248	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   198: if_acmpeq +61 -> 259
/*     */     //   201: aload_3
/*     */     //   202: aconst_null
/*     */     //   203: astore_3
/*     */     //   204: checkcast 322	clojure/core/VecNode
/*     */     //   207: getfield 325	clojure/core/VecNode:arr	Ljava/lang/Object;
/*     */     //   210: checkcast 327	[Ljava/lang/Object;
/*     */     //   213: invokestatic 400	clojure/lang/RT:aclone	([Ljava/lang/Object;)[Ljava/lang/Object;
/*     */     //   216: astore 6
/*     */     //   218: aload 6
/*     */     //   220: checkcast 327	[Ljava/lang/Object;
/*     */     //   223: lload 4
/*     */     //   225: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   228: aconst_null
/*     */     //   229: invokestatic 403	clojure/lang/RT:aset	([Ljava/lang/Object;ILjava/lang/Object;)Ljava/lang/Object;
/*     */     //   232: pop
/*     */     //   233: new 322	clojure/core/VecNode
/*     */     //   236: dup
/*     */     //   237: aload_0
/*     */     //   238: getfield 66	clojure/core/Vec:root	Ljava/lang/Object;
/*     */     //   241: checkcast 322	clojure/core/VecNode
/*     */     //   244: getfield 394	clojure/core/VecNode:edit	Ljava/lang/Object;
/*     */     //   247: aload 6
/*     */     //   249: aconst_null
/*     */     //   250: astore 6
/*     */     //   252: invokespecial 397	clojure/core/VecNode:<init>	(Ljava/lang/Object;Ljava/lang/Object;)V
/*     */     //   255: goto +5 -> 260
/*     */     //   258: pop
/*     */     //   259: aconst_null
/*     */     //   260: areturn
/*     */     // Line number table:
/*     */     //   Java source line #131	-> byte code offset #0
/*     */     //   Java source line #332	-> byte code offset #12
/*     */     //   Java source line #332	-> byte code offset #16
/*     */     //   Java source line #332	-> byte code offset #21
/*     */     //   Java source line #332	-> byte code offset #26
/*     */     //   Java source line #332	-> byte code offset #30
/*     */     //   Java source line #333	-> byte code offset #33
/*     */     //   Java source line #334	-> byte code offset #33
/*     */     //   Java source line #335	-> byte code offset #51
/*     */     //   Java source line #335	-> byte code offset #58
/*     */     //   Java source line #335	-> byte code offset #69
/*     */     //   Java source line #335	-> byte code offset #72
/*     */     //   Java source line #335	-> byte code offset #75
/*     */     //   Java source line #336	-> byte code offset #82
/*     */     //   Java source line #336	-> byte code offset #85
/*     */     //   Java source line #336	-> byte code offset #90
/*     */     //   Java source line #336	-> byte code offset #97
/*     */     //   Java source line #338	-> byte code offset #117
/*     */     //   Java source line #338	-> byte code offset #126
/*     */     //   Java source line #339	-> byte code offset #138
/*     */     //   Java source line #339	-> byte code offset #146
/*     */     //   Java source line #340	-> byte code offset #158
/*     */     //   Java source line #333	-> byte code offset #176
/*     */     //   Java source line #341	-> byte code offset #176
/*     */     //   Java source line #333	-> byte code offset #188
/*     */     //   Java source line #342	-> byte code offset #204
/*     */     //   Java source line #342	-> byte code offset #213
/*     */     //   Java source line #343	-> byte code offset #225
/*     */     //   Java source line #343	-> byte code offset #229
/*     */     //   Java source line #344	-> byte code offset #241
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	260	0	this	Vec
/*     */     //   0	260	1	level	int
/*     */     //   0	260	2	node	Object
/*     */     //   4	256	3	node	Object
/*     */     //   33	227	4	subidx	long
/*     */     //   82	90	6	new_child	Object
/*     */     //   218	37	6	arr	Object
/*     */     //   90	16	7	and__4467__auto__6822	boolean
/*     */     //   131	41	7	arr	Object
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public Object pushTail(int level, VecNode parent, VecNode tailnode)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 62	clojure/core/Vec:cnt	I
/*     */     //   4: i2l
/*     */     //   5: invokestatic 227	clojure/lang/Numbers:dec	(J)J
/*     */     //   8: iload_1
/*     */     //   9: i2l
/*     */     //   10: l2i
/*     */     //   11: lshr
/*     */     //   12: ldc2_w 149
/*     */     //   15: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   18: i2l
/*     */     //   19: land
/*     */     //   20: lstore 4
/*     */     //   22: aload_2
/*     */     //   23: aconst_null
/*     */     //   24: astore_2
/*     */     //   25: astore 6
/*     */     //   27: new 322	clojure/core/VecNode
/*     */     //   30: dup
/*     */     //   31: aload 6
/*     */     //   33: checkcast 322	clojure/core/VecNode
/*     */     //   36: getfield 394	clojure/core/VecNode:edit	Ljava/lang/Object;
/*     */     //   39: aload 6
/*     */     //   41: checkcast 322	clojure/core/VecNode
/*     */     //   44: getfield 325	clojure/core/VecNode:arr	Ljava/lang/Object;
/*     */     //   47: checkcast 327	[Ljava/lang/Object;
/*     */     //   50: invokestatic 400	clojure/lang/RT:aclone	([Ljava/lang/Object;)[Ljava/lang/Object;
/*     */     //   53: invokespecial 397	clojure/core/VecNode:<init>	(Ljava/lang/Object;Ljava/lang/Object;)V
/*     */     //   56: astore 7
/*     */     //   58: iload_1
/*     */     //   59: i2l
/*     */     //   60: ldc2_w 271
/*     */     //   63: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   66: i2l
/*     */     //   67: lcmp
/*     */     //   68: ifne +10 -> 78
/*     */     //   71: aload_3
/*     */     //   72: aconst_null
/*     */     //   73: astore_3
/*     */     //   74: goto +119 -> 193
/*     */     //   77: pop
/*     */     //   78: aload 6
/*     */     //   80: aconst_null
/*     */     //   81: astore 6
/*     */     //   83: checkcast 322	clojure/core/VecNode
/*     */     //   86: getfield 325	clojure/core/VecNode:arr	Ljava/lang/Object;
/*     */     //   89: checkcast 327	[Ljava/lang/Object;
/*     */     //   92: lload 4
/*     */     //   94: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   97: invokestatic 330	clojure/lang/RT:aget	([Ljava/lang/Object;I)Ljava/lang/Object;
/*     */     //   100: astore 8
/*     */     //   102: aload 8
/*     */     //   104: dup
/*     */     //   105: ifnull +50 -> 155
/*     */     //   108: getstatic 248	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   111: if_acmpeq +45 -> 156
/*     */     //   114: aload_0
/*     */     //   115: checkcast 18	clojure/core/IVecImpl
/*     */     //   118: iload_1
/*     */     //   119: i2l
/*     */     //   120: ldc2_w 271
/*     */     //   123: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   126: i2l
/*     */     //   127: invokestatic 299	clojure/lang/Numbers:minus	(JJ)J
/*     */     //   130: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   133: aload 8
/*     */     //   135: aconst_null
/*     */     //   136: astore 8
/*     */     //   138: checkcast 322	clojure/core/VecNode
/*     */     //   141: aload_3
/*     */     //   142: aconst_null
/*     */     //   143: astore_3
/*     */     //   144: checkcast 322	clojure/core/VecNode
/*     */     //   147: invokeinterface 427 4 0
/*     */     //   152: goto +41 -> 193
/*     */     //   155: pop
/*     */     //   156: aload_0
/*     */     //   157: checkcast 18	clojure/core/IVecImpl
/*     */     //   160: aload_0
/*     */     //   161: getfield 66	clojure/core/Vec:root	Ljava/lang/Object;
/*     */     //   164: checkcast 322	clojure/core/VecNode
/*     */     //   167: getfield 394	clojure/core/VecNode:edit	Ljava/lang/Object;
/*     */     //   170: iload_1
/*     */     //   171: i2l
/*     */     //   172: ldc2_w 271
/*     */     //   175: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   178: i2l
/*     */     //   179: invokestatic 299	clojure/lang/Numbers:minus	(JJ)J
/*     */     //   182: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   185: aload_3
/*     */     //   186: aconst_null
/*     */     //   187: astore_3
/*     */     //   188: invokeinterface 416 4 0
/*     */     //   193: astore 8
/*     */     //   195: aload 7
/*     */     //   197: checkcast 322	clojure/core/VecNode
/*     */     //   200: getfield 325	clojure/core/VecNode:arr	Ljava/lang/Object;
/*     */     //   203: checkcast 327	[Ljava/lang/Object;
/*     */     //   206: lload 4
/*     */     //   208: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   211: aload 8
/*     */     //   213: aconst_null
/*     */     //   214: astore 8
/*     */     //   216: invokestatic 403	clojure/lang/RT:aset	([Ljava/lang/Object;ILjava/lang/Object;)Ljava/lang/Object;
/*     */     //   219: pop
/*     */     //   220: aload 7
/*     */     //   222: aconst_null
/*     */     //   223: astore 7
/*     */     //   225: areturn
/*     */     // Line number table:
/*     */     //   Java source line #131	-> byte code offset #0
/*     */     //   Java source line #318	-> byte code offset #5
/*     */     //   Java source line #318	-> byte code offset #10
/*     */     //   Java source line #318	-> byte code offset #15
/*     */     //   Java source line #318	-> byte code offset #19
/*     */     //   Java source line #320	-> byte code offset #33
/*     */     //   Java source line #320	-> byte code offset #41
/*     */     //   Java source line #320	-> byte code offset #50
/*     */     //   Java source line #321	-> byte code offset #58
/*     */     //   Java source line #321	-> byte code offset #58
/*     */     //   Java source line #321	-> byte code offset #63
/*     */     //   Java source line #323	-> byte code offset #83
/*     */     //   Java source line #323	-> byte code offset #94
/*     */     //   Java source line #323	-> byte code offset #97
/*     */     //   Java source line #324	-> byte code offset #102
/*     */     //   Java source line #325	-> byte code offset #123
/*     */     //   Java source line #325	-> byte code offset #127
/*     */     //   Java source line #325	-> byte code offset #147
/*     */     //   Java source line #326	-> byte code offset #164
/*     */     //   Java source line #326	-> byte code offset #175
/*     */     //   Java source line #326	-> byte code offset #179
/*     */     //   Java source line #326	-> byte code offset #188
/*     */     //   Java source line #327	-> byte code offset #197
/*     */     //   Java source line #327	-> byte code offset #208
/*     */     //   Java source line #327	-> byte code offset #216
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	225	0	this	Vec
/*     */     //   0	225	1	level	int
/*     */     //   0	225	2	parent	VecNode
/*     */     //   0	225	3	tailnode	VecNode
/*     */     //   22	203	4	subidx	long
/*     */     //   27	198	6	parent	Object
/*     */     //   58	167	7	ret	Object
/*     */     //   102	91	8	child	Object
/*     */     //   195	30	8	node_to_insert	Object
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public Object arrayFor(int i)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: lconst_0
/*     */     //   1: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   4: i2l
/*     */     //   5: iload_1
/*     */     //   6: i2l
/*     */     //   7: invokestatic 347	clojure/lang/Numbers:lte	(JJ)Z
/*     */     //   10: istore_2
/*     */     //   11: iload_2
/*     */     //   12: ifeq +17 -> 29
/*     */     //   15: iload_1
/*     */     //   16: i2l
/*     */     //   17: aload_0
/*     */     //   18: getfield 62	clojure/core/Vec:cnt	I
/*     */     //   21: i2l
/*     */     //   22: invokestatic 133	clojure/lang/Numbers:lt	(JJ)Z
/*     */     //   25: goto +5 -> 30
/*     */     //   28: pop
/*     */     //   29: iload_2
/*     */     //   30: ifeq +108 -> 138
/*     */     //   33: iload_1
/*     */     //   34: i2l
/*     */     //   35: aload_0
/*     */     //   36: checkcast 18	clojure/core/IVecImpl
/*     */     //   39: invokeinterface 295 1 0
/*     */     //   44: i2l
/*     */     //   45: lcmp
/*     */     //   46: iflt +11 -> 57
/*     */     //   49: aload_0
/*     */     //   50: getfield 68	clojure/core/Vec:tail	Ljava/lang/Object;
/*     */     //   53: goto +81 -> 134
/*     */     //   56: pop
/*     */     //   57: aload_0
/*     */     //   58: getfield 66	clojure/core/Vec:root	Ljava/lang/Object;
/*     */     //   61: astore_2
/*     */     //   62: aload_0
/*     */     //   63: getfield 64	clojure/core/Vec:shift	I
/*     */     //   66: i2l
/*     */     //   67: lstore_3
/*     */     //   68: lload_3
/*     */     //   69: lconst_0
/*     */     //   70: lcmp
/*     */     //   71: ifne +16 -> 87
/*     */     //   74: aload_2
/*     */     //   75: aconst_null
/*     */     //   76: astore_2
/*     */     //   77: checkcast 322	clojure/core/VecNode
/*     */     //   80: getfield 325	clojure/core/VecNode:arr	Ljava/lang/Object;
/*     */     //   83: goto +51 -> 134
/*     */     //   86: pop
/*     */     //   87: aload_2
/*     */     //   88: aconst_null
/*     */     //   89: astore_2
/*     */     //   90: checkcast 322	clojure/core/VecNode
/*     */     //   93: getfield 325	clojure/core/VecNode:arr	Ljava/lang/Object;
/*     */     //   96: checkcast 327	[Ljava/lang/Object;
/*     */     //   99: iload_1
/*     */     //   100: i2l
/*     */     //   101: lload_3
/*     */     //   102: l2i
/*     */     //   103: lshr
/*     */     //   104: ldc2_w 149
/*     */     //   107: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   110: i2l
/*     */     //   111: land
/*     */     //   112: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   115: invokestatic 330	clojure/lang/RT:aget	([Ljava/lang/Object;I)Ljava/lang/Object;
/*     */     //   118: lload_3
/*     */     //   119: ldc2_w 271
/*     */     //   122: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   125: i2l
/*     */     //   126: invokestatic 299	clojure/lang/Numbers:minus	(JJ)J
/*     */     //   129: lstore_3
/*     */     //   130: astore_2
/*     */     //   131: goto -63 -> 68
/*     */     //   134: goto +15 -> 149
/*     */     //   137: pop
/*     */     //   138: new 362	java/lang/IndexOutOfBoundsException
/*     */     //   141: dup
/*     */     //   142: invokespecial 363	java/lang/IndexOutOfBoundsException:<init>	()V
/*     */     //   145: checkcast 179	java/lang/Throwable
/*     */     //   148: athrow
/*     */     //   149: areturn
/*     */     // Line number table:
/*     */     //   Java source line #131	-> byte code offset #0
/*     */     //   Java source line #307	-> byte code offset #0
/*     */     //   Java source line #307	-> byte code offset #1
/*     */     //   Java source line #307	-> byte code offset #7
/*     */     //   Java source line #307	-> byte code offset #11
/*     */     //   Java source line #307	-> byte code offset #22
/*     */     //   Java source line #308	-> byte code offset #33
/*     */     //   Java source line #308	-> byte code offset #33
/*     */     //   Java source line #308	-> byte code offset #39
/*     */     //   Java source line #0	-> byte code offset #66
/*     */     //   Java source line #311	-> byte code offset #68
/*     */     //   Java source line #311	-> byte code offset #68
/*     */     //   Java source line #312	-> byte code offset #77
/*     */     //   Java source line #313	-> byte code offset #90
/*     */     //   Java source line #313	-> byte code offset #102
/*     */     //   Java source line #313	-> byte code offset #107
/*     */     //   Java source line #313	-> byte code offset #111
/*     */     //   Java source line #313	-> byte code offset #112
/*     */     //   Java source line #313	-> byte code offset #115
/*     */     //   Java source line #314	-> byte code offset #122
/*     */     //   Java source line #314	-> byte code offset #126
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	149	0	this	Vec
/*     */     //   0	149	1	i	int
/*     */     //   11	19	2	and__4467__auto__6823	boolean
/*     */     //   62	72	2	node	Object
/*     */     //   68	66	3	level	long
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public boolean equiv(Object o)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_1
/*     */     //   1: instanceof 32
/*     */     //   4: istore_2
/*     */     //   5: iload_2
/*     */     //   6: ifeq +8 -> 14
/*     */     //   9: iload_2
/*     */     //   10: goto +8 -> 18
/*     */     //   13: pop
/*     */     //   14: aload_1
/*     */     //   15: instanceof 442
/*     */     //   18: ifeq +125 -> 143
/*     */     //   21: aload_0
/*     */     //   22: getfield 62	clojure/core/Vec:cnt	I
/*     */     //   25: i2l
/*     */     //   26: aload_1
/*     */     //   27: invokestatic 445	clojure/lang/RT:count	(Ljava/lang/Object;)I
/*     */     //   30: i2l
/*     */     //   31: invokestatic 447	clojure/lang/Util:equiv	(JJ)Z
/*     */     //   34: istore_2
/*     */     //   35: iload_2
/*     */     //   36: ifeq +90 -> 126
/*     */     //   39: lconst_0
/*     */     //   40: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   43: i2l
/*     */     //   44: lstore_3
/*     */     //   45: lload_3
/*     */     //   46: aload_0
/*     */     //   47: getfield 62	clojure/core/Vec:cnt	I
/*     */     //   50: i2l
/*     */     //   51: lcmp
/*     */     //   52: ifne +10 -> 62
/*     */     //   55: getstatic 450	java/lang/Boolean:TRUE	Ljava/lang/Boolean;
/*     */     //   58: goto +64 -> 122
/*     */     //   61: pop
/*     */     //   62: aload_0
/*     */     //   63: checkcast 42	clojure/lang/Indexed
/*     */     //   66: lload_3
/*     */     //   67: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   70: invokeinterface 138 2 0
/*     */     //   75: aload_1
/*     */     //   76: lload_3
/*     */     //   77: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   80: invokestatic 452	clojure/lang/RT:nth	(Ljava/lang/Object;I)Ljava/lang/Object;
/*     */     //   83: invokestatic 236	clojure/lang/Util:equiv	(Ljava/lang/Object;Ljava/lang/Object;)Z
/*     */     //   86: ifeq +15 -> 101
/*     */     //   89: lload_3
/*     */     //   90: invokestatic 258	clojure/lang/Numbers:inc	(J)J
/*     */     //   93: lstore_3
/*     */     //   94: goto -49 -> 45
/*     */     //   97: goto +25 -> 122
/*     */     //   100: pop
/*     */     //   101: getstatic 244	clojure/core/Vec:const__12	Lclojure/lang/Keyword;
/*     */     //   104: dup
/*     */     //   105: ifnull +15 -> 120
/*     */     //   108: getstatic 248	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   111: if_acmpeq +10 -> 121
/*     */     //   114: getstatic 248	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   117: goto +5 -> 122
/*     */     //   120: pop
/*     */     //   121: aconst_null
/*     */     //   122: goto +17 -> 139
/*     */     //   125: pop
/*     */     //   126: iload_2
/*     */     //   127: ifeq +9 -> 136
/*     */     //   130: getstatic 450	java/lang/Boolean:TRUE	Ljava/lang/Boolean;
/*     */     //   133: goto +6 -> 139
/*     */     //   136: getstatic 248	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   139: goto +75 -> 214
/*     */     //   142: pop
/*     */     //   143: aload_1
/*     */     //   144: instanceof 30
/*     */     //   147: istore_2
/*     */     //   148: iload_2
/*     */     //   149: ifeq +8 -> 157
/*     */     //   152: iload_2
/*     */     //   153: goto +8 -> 161
/*     */     //   156: pop
/*     */     //   157: aload_1
/*     */     //   158: instanceof 38
/*     */     //   161: ifeq +32 -> 193
/*     */     //   164: aload_0
/*     */     //   165: invokestatic 457	clojure/core$seq__4357:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   168: aload_1
/*     */     //   169: aconst_null
/*     */     //   170: astore_1
/*     */     //   171: invokestatic 457	clojure/core$seq__4357:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   174: invokestatic 236	clojure/lang/Util:equiv	(Ljava/lang/Object;Ljava/lang/Object;)Z
/*     */     //   177: ifeq +9 -> 186
/*     */     //   180: getstatic 450	java/lang/Boolean:TRUE	Ljava/lang/Boolean;
/*     */     //   183: goto +6 -> 189
/*     */     //   186: getstatic 248	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   189: goto +25 -> 214
/*     */     //   192: pop
/*     */     //   193: getstatic 244	clojure/core/Vec:const__12	Lclojure/lang/Keyword;
/*     */     //   196: dup
/*     */     //   197: ifnull +15 -> 212
/*     */     //   200: getstatic 248	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   203: if_acmpeq +10 -> 213
/*     */     //   206: getstatic 248	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   209: goto +5 -> 214
/*     */     //   212: pop
/*     */     //   213: aconst_null
/*     */     //   214: checkcast 185	java/lang/Boolean
/*     */     //   217: invokevirtual 189	java/lang/Boolean:booleanValue	()Z
/*     */     //   220: ireturn
/*     */     // Line number table:
/*     */     //   Java source line #131	-> byte code offset #0
/*     */     //   Java source line #202	-> byte code offset #0
/*     */     //   Java source line #203	-> byte code offset #5
/*     */     //   Java source line #204	-> byte code offset #27
/*     */     //   Java source line #204	-> byte code offset #31
/*     */     //   Java source line #204	-> byte code offset #35
/*     */     //   Java source line #205	-> byte code offset #40
/*     */     //   Java source line #0	-> byte code offset #43
/*     */     //   Java source line #206	-> byte code offset #45
/*     */     //   Java source line #207	-> byte code offset #45
/*     */     //   Java source line #206	-> byte code offset #62
/*     */     //   Java source line #208	-> byte code offset #70
/*     */     //   Java source line #208	-> byte code offset #80
/*     */     //   Java source line #208	-> byte code offset #83
/*     */     //   Java source line #208	-> byte code offset #90
/*     */     //   Java source line #206	-> byte code offset #101
/*     */     //   Java source line #202	-> byte code offset #143
/*     */     //   Java source line #210	-> byte code offset #148
/*     */     //   Java source line #211	-> byte code offset #174
/*     */     //   Java source line #202	-> byte code offset #193
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	220	0	this	Vec
/*     */     //   0	220	1	o	Object
/*     */     //   5	13	2	or__4469__auto__6824	boolean
/*     */     //   35	104	2	and__4467__auto__6825	boolean
/*     */     //   148	13	2	or__4469__auto__6826	boolean
/*     */     //   45	77	3	i	long
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public IPersistentVector cons(Object val)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 62	clojure/core/Vec:cnt	I
/*     */     //   4: i2l
/*     */     //   5: aload_0
/*     */     //   6: checkcast 18	clojure/core/IVecImpl
/*     */     //   9: invokeinterface 295 1 0
/*     */     //   14: i2l
/*     */     //   15: invokestatic 299	clojure/lang/Numbers:minus	(JJ)J
/*     */     //   18: ldc2_w 460
/*     */     //   21: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   24: i2l
/*     */     //   25: lcmp
/*     */     //   26: ifge +145 -> 171
/*     */     //   29: aload_0
/*     */     //   30: getfield 60	clojure/core/Vec:am	Ljava/lang/Object;
/*     */     //   33: checkcast 148	clojure/core/ArrayManager
/*     */     //   36: aload_0
/*     */     //   37: getfield 60	clojure/core/Vec:am	Ljava/lang/Object;
/*     */     //   40: checkcast 148	clojure/core/ArrayManager
/*     */     //   43: aload_0
/*     */     //   44: getfield 68	clojure/core/Vec:tail	Ljava/lang/Object;
/*     */     //   47: invokeinterface 302 2 0
/*     */     //   52: i2l
/*     */     //   53: invokestatic 258	clojure/lang/Numbers:inc	(J)J
/*     */     //   56: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   59: invokeinterface 285 2 0
/*     */     //   64: astore_2
/*     */     //   65: aload_0
/*     */     //   66: getfield 68	clojure/core/Vec:tail	Ljava/lang/Object;
/*     */     //   69: lconst_0
/*     */     //   70: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   73: aload_2
/*     */     //   74: lconst_0
/*     */     //   75: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   78: aload_0
/*     */     //   79: getfield 60	clojure/core/Vec:am	Ljava/lang/Object;
/*     */     //   82: checkcast 148	clojure/core/ArrayManager
/*     */     //   85: aload_0
/*     */     //   86: getfield 68	clojure/core/Vec:tail	Ljava/lang/Object;
/*     */     //   89: invokeinterface 302 2 0
/*     */     //   94: invokestatic 308	java/lang/System:arraycopy	(Ljava/lang/Object;ILjava/lang/Object;II)V
/*     */     //   97: aload_0
/*     */     //   98: getfield 60	clojure/core/Vec:am	Ljava/lang/Object;
/*     */     //   101: checkcast 148	clojure/core/ArrayManager
/*     */     //   104: aload_2
/*     */     //   105: aload_0
/*     */     //   106: getfield 60	clojure/core/Vec:am	Ljava/lang/Object;
/*     */     //   109: checkcast 148	clojure/core/ArrayManager
/*     */     //   112: aload_0
/*     */     //   113: getfield 68	clojure/core/Vec:tail	Ljava/lang/Object;
/*     */     //   116: invokeinterface 302 2 0
/*     */     //   121: aload_1
/*     */     //   122: aconst_null
/*     */     //   123: astore_1
/*     */     //   124: invokeinterface 352 4 0
/*     */     //   129: pop
/*     */     //   130: new 2	clojure/core/Vec
/*     */     //   133: dup
/*     */     //   134: aload_0
/*     */     //   135: getfield 60	clojure/core/Vec:am	Ljava/lang/Object;
/*     */     //   138: aload_0
/*     */     //   139: getfield 62	clojure/core/Vec:cnt	I
/*     */     //   142: i2l
/*     */     //   143: invokestatic 258	clojure/lang/Numbers:inc	(J)J
/*     */     //   146: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   149: aload_0
/*     */     //   150: getfield 64	clojure/core/Vec:shift	I
/*     */     //   153: aload_0
/*     */     //   154: getfield 66	clojure/core/Vec:root	Ljava/lang/Object;
/*     */     //   157: aload_2
/*     */     //   158: aconst_null
/*     */     //   159: astore_2
/*     */     //   160: aload_0
/*     */     //   161: invokestatic 290	clojure/core$meta__4373:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   164: invokespecial 292	clojure/core/Vec:<init>	(Ljava/lang/Object;IILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
/*     */     //   167: goto +338 -> 505
/*     */     //   170: pop
/*     */     //   171: new 322	clojure/core/VecNode
/*     */     //   174: dup
/*     */     //   175: aload_0
/*     */     //   176: getfield 66	clojure/core/Vec:root	Ljava/lang/Object;
/*     */     //   179: checkcast 322	clojure/core/VecNode
/*     */     //   182: getfield 394	clojure/core/VecNode:edit	Ljava/lang/Object;
/*     */     //   185: aload_0
/*     */     //   186: getfield 68	clojure/core/Vec:tail	Ljava/lang/Object;
/*     */     //   189: invokespecial 397	clojure/core/VecNode:<init>	(Ljava/lang/Object;Ljava/lang/Object;)V
/*     */     //   192: astore_2
/*     */     //   193: aload_0
/*     */     //   194: getfield 62	clojure/core/Vec:cnt	I
/*     */     //   197: i2l
/*     */     //   198: ldc2_w 271
/*     */     //   201: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   204: i2l
/*     */     //   205: l2i
/*     */     //   206: lshr
/*     */     //   207: lconst_1
/*     */     //   208: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   211: i2l
/*     */     //   212: aload_0
/*     */     //   213: getfield 64	clojure/core/Vec:shift	I
/*     */     //   216: i2l
/*     */     //   217: l2i
/*     */     //   218: lshl
/*     */     //   219: lcmp
/*     */     //   220: ifle +188 -> 408
/*     */     //   223: new 322	clojure/core/VecNode
/*     */     //   226: dup
/*     */     //   227: aload_0
/*     */     //   228: getfield 66	clojure/core/Vec:root	Ljava/lang/Object;
/*     */     //   231: checkcast 322	clojure/core/VecNode
/*     */     //   234: getfield 394	clojure/core/VecNode:edit	Ljava/lang/Object;
/*     */     //   237: getstatic 410	clojure/core/Vec:const__35	Ljava/lang/Object;
/*     */     //   240: invokestatic 414	clojure/lang/RT:object_array	(Ljava/lang/Object;)[Ljava/lang/Object;
/*     */     //   243: invokespecial 397	clojure/core/VecNode:<init>	(Ljava/lang/Object;Ljava/lang/Object;)V
/*     */     //   246: astore_3
/*     */     //   247: aload_3
/*     */     //   248: checkcast 322	clojure/core/VecNode
/*     */     //   251: getfield 325	clojure/core/VecNode:arr	Ljava/lang/Object;
/*     */     //   254: astore 4
/*     */     //   256: aload 4
/*     */     //   258: checkcast 327	[Ljava/lang/Object;
/*     */     //   261: lconst_0
/*     */     //   262: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   265: aload_0
/*     */     //   266: getfield 66	clojure/core/Vec:root	Ljava/lang/Object;
/*     */     //   269: invokestatic 403	clojure/lang/RT:aset	([Ljava/lang/Object;ILjava/lang/Object;)Ljava/lang/Object;
/*     */     //   272: pop
/*     */     //   273: aload 4
/*     */     //   275: checkcast 327	[Ljava/lang/Object;
/*     */     //   278: lconst_1
/*     */     //   279: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   282: aload_0
/*     */     //   283: checkcast 18	clojure/core/IVecImpl
/*     */     //   286: aload_0
/*     */     //   287: getfield 66	clojure/core/Vec:root	Ljava/lang/Object;
/*     */     //   290: checkcast 322	clojure/core/VecNode
/*     */     //   293: getfield 394	clojure/core/VecNode:edit	Ljava/lang/Object;
/*     */     //   296: aload_0
/*     */     //   297: getfield 64	clojure/core/Vec:shift	I
/*     */     //   300: aload_2
/*     */     //   301: aconst_null
/*     */     //   302: astore_2
/*     */     //   303: invokeinterface 416 4 0
/*     */     //   308: invokestatic 403	clojure/lang/RT:aset	([Ljava/lang/Object;ILjava/lang/Object;)Ljava/lang/Object;
/*     */     //   311: pop
/*     */     //   312: new 2	clojure/core/Vec
/*     */     //   315: dup
/*     */     //   316: aload_0
/*     */     //   317: getfield 60	clojure/core/Vec:am	Ljava/lang/Object;
/*     */     //   320: aload_0
/*     */     //   321: getfield 62	clojure/core/Vec:cnt	I
/*     */     //   324: i2l
/*     */     //   325: invokestatic 258	clojure/lang/Numbers:inc	(J)J
/*     */     //   328: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   331: aload_0
/*     */     //   332: getfield 64	clojure/core/Vec:shift	I
/*     */     //   335: i2l
/*     */     //   336: ldc2_w 271
/*     */     //   339: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   342: i2l
/*     */     //   343: invokestatic 464	clojure/lang/Numbers:add	(JJ)J
/*     */     //   346: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   349: aload_3
/*     */     //   350: aconst_null
/*     */     //   351: astore_3
/*     */     //   352: aload_0
/*     */     //   353: getfield 60	clojure/core/Vec:am	Ljava/lang/Object;
/*     */     //   356: checkcast 148	clojure/core/ArrayManager
/*     */     //   359: lconst_1
/*     */     //   360: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   363: invokeinterface 285 2 0
/*     */     //   368: astore 4
/*     */     //   370: aload_0
/*     */     //   371: getfield 60	clojure/core/Vec:am	Ljava/lang/Object;
/*     */     //   374: checkcast 148	clojure/core/ArrayManager
/*     */     //   377: aload 4
/*     */     //   379: lconst_0
/*     */     //   380: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   383: aload_1
/*     */     //   384: aconst_null
/*     */     //   385: astore_1
/*     */     //   386: invokeinterface 352 4 0
/*     */     //   391: pop
/*     */     //   392: aload 4
/*     */     //   394: aconst_null
/*     */     //   395: astore 4
/*     */     //   397: aload_0
/*     */     //   398: invokestatic 290	clojure/core$meta__4373:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   401: invokespecial 292	clojure/core/Vec:<init>	(Ljava/lang/Object;IILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
/*     */     //   404: goto +101 -> 505
/*     */     //   407: pop
/*     */     //   408: new 2	clojure/core/Vec
/*     */     //   411: dup
/*     */     //   412: aload_0
/*     */     //   413: getfield 60	clojure/core/Vec:am	Ljava/lang/Object;
/*     */     //   416: aload_0
/*     */     //   417: getfield 62	clojure/core/Vec:cnt	I
/*     */     //   420: i2l
/*     */     //   421: invokestatic 258	clojure/lang/Numbers:inc	(J)J
/*     */     //   424: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   427: aload_0
/*     */     //   428: getfield 64	clojure/core/Vec:shift	I
/*     */     //   431: aload_0
/*     */     //   432: checkcast 18	clojure/core/IVecImpl
/*     */     //   435: aload_0
/*     */     //   436: getfield 64	clojure/core/Vec:shift	I
/*     */     //   439: aload_0
/*     */     //   440: getfield 66	clojure/core/Vec:root	Ljava/lang/Object;
/*     */     //   443: checkcast 322	clojure/core/VecNode
/*     */     //   446: aload_2
/*     */     //   447: aconst_null
/*     */     //   448: astore_2
/*     */     //   449: checkcast 322	clojure/core/VecNode
/*     */     //   452: invokeinterface 427 4 0
/*     */     //   457: aload_0
/*     */     //   458: getfield 60	clojure/core/Vec:am	Ljava/lang/Object;
/*     */     //   461: checkcast 148	clojure/core/ArrayManager
/*     */     //   464: lconst_1
/*     */     //   465: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   468: invokeinterface 285 2 0
/*     */     //   473: astore_3
/*     */     //   474: aload_0
/*     */     //   475: getfield 60	clojure/core/Vec:am	Ljava/lang/Object;
/*     */     //   478: checkcast 148	clojure/core/ArrayManager
/*     */     //   481: aload_3
/*     */     //   482: lconst_0
/*     */     //   483: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   486: aload_1
/*     */     //   487: aconst_null
/*     */     //   488: astore_1
/*     */     //   489: invokeinterface 352 4 0
/*     */     //   494: pop
/*     */     //   495: aload_3
/*     */     //   496: aconst_null
/*     */     //   497: astore_3
/*     */     //   498: aload_0
/*     */     //   499: invokestatic 290	clojure/core$meta__4373:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   502: invokespecial 292	clojure/core/Vec:<init>	(Ljava/lang/Object;IILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
/*     */     //   505: checkcast 32	clojure/lang/IPersistentVector
/*     */     //   508: areturn
/*     */     // Line number table:
/*     */     //   Java source line #131	-> byte code offset #0
/*     */     //   Java source line #185	-> byte code offset #0
/*     */     //   Java source line #185	-> byte code offset #0
/*     */     //   Java source line #185	-> byte code offset #9
/*     */     //   Java source line #185	-> byte code offset #15
/*     */     //   Java source line #185	-> byte code offset #21
/*     */     //   Java source line #186	-> byte code offset #47
/*     */     //   Java source line #186	-> byte code offset #53
/*     */     //   Java source line #186	-> byte code offset #59
/*     */     //   Java source line #187	-> byte code offset #89
/*     */     //   Java source line #187	-> byte code offset #94
/*     */     //   Java source line #188	-> byte code offset #116
/*     */     //   Java source line #188	-> byte code offset #124
/*     */     //   Java source line #189	-> byte code offset #143
/*     */     //   Java source line #190	-> byte code offset #179
/*     */     //   Java source line #191	-> byte code offset #193
/*     */     //   Java source line #191	-> byte code offset #193
/*     */     //   Java source line #191	-> byte code offset #201
/*     */     //   Java source line #191	-> byte code offset #205
/*     */     //   Java source line #191	-> byte code offset #208
/*     */     //   Java source line #191	-> byte code offset #217
/*     */     //   Java source line #192	-> byte code offset #231
/*     */     //   Java source line #192	-> byte code offset #240
/*     */     //   Java source line #193	-> byte code offset #248
/*     */     //   Java source line #193	-> byte code offset #262
/*     */     //   Java source line #193	-> byte code offset #269
/*     */     //   Java source line #193	-> byte code offset #279
/*     */     //   Java source line #195	-> byte code offset #290
/*     */     //   Java source line #195	-> byte code offset #303
/*     */     //   Java source line #193	-> byte code offset #308
/*     */     //   Java source line #196	-> byte code offset #325
/*     */     //   Java source line #196	-> byte code offset #339
/*     */     //   Java source line #196	-> byte code offset #343
/*     */     //   Java source line #196	-> byte code offset #363
/*     */     //   Java source line #196	-> byte code offset #386
/*     */     //   Java source line #197	-> byte code offset #421
/*     */     //   Java source line #197	-> byte code offset #452
/*     */     //   Java source line #198	-> byte code offset #468
/*     */     //   Java source line #198	-> byte code offset #489
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	508	0	this	Vec
/*     */     //   0	508	1	val	Object
/*     */     //   65	102	2	new_tail	Object
/*     */     //   193	312	2	tail_node	Object
/*     */     //   247	157	3	new_root	Object
/*     */     //   474	24	3	tl	Object
/*     */     //   256	56	4	G__6812	Object
/*     */     //   370	27	4	tl	Object
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public int compareTo(Object o)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: aload_1
/*     */     //   2: invokestatic 317	clojure/lang/Util:identical	(Ljava/lang/Object;Ljava/lang/Object;)Z
/*     */     //   5: ifeq +10 -> 15
/*     */     //   8: getstatic 470	clojure/core/Vec:const__1	Ljava/lang/Object;
/*     */     //   11: goto +163 -> 174
/*     */     //   14: pop
/*     */     //   15: getstatic 473	clojure/core/Vec:const__6	Ljava/lang/Object;
/*     */     //   18: aload_1
/*     */     //   19: aconst_null
/*     */     //   20: astore_1
/*     */     //   21: invokestatic 478	clojure/core$cast:invokeStatic	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   24: astore_2
/*     */     //   25: aload_2
/*     */     //   26: checkcast 28	clojure/lang/Counted
/*     */     //   29: invokeinterface 130 1 0
/*     */     //   34: istore_3
/*     */     //   35: aload_0
/*     */     //   36: getfield 62	clojure/core/Vec:cnt	I
/*     */     //   39: i2l
/*     */     //   40: iload_3
/*     */     //   41: i2l
/*     */     //   42: lcmp
/*     */     //   43: ifge +10 -> 53
/*     */     //   46: getstatic 230	clojure/core/Vec:const__32	Ljava/lang/Object;
/*     */     //   49: goto +125 -> 174
/*     */     //   52: pop
/*     */     //   53: aload_0
/*     */     //   54: getfield 62	clojure/core/Vec:cnt	I
/*     */     //   57: i2l
/*     */     //   58: iload_3
/*     */     //   59: i2l
/*     */     //   60: lcmp
/*     */     //   61: ifle +10 -> 71
/*     */     //   64: getstatic 481	clojure/core/Vec:const__17	Ljava/lang/Object;
/*     */     //   67: goto +107 -> 174
/*     */     //   70: pop
/*     */     //   71: getstatic 244	clojure/core/Vec:const__12	Lclojure/lang/Keyword;
/*     */     //   74: dup
/*     */     //   75: ifnull +97 -> 172
/*     */     //   78: getstatic 248	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   81: if_acmpeq +92 -> 173
/*     */     //   84: lconst_0
/*     */     //   85: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   88: i2l
/*     */     //   89: lstore 4
/*     */     //   91: lload 4
/*     */     //   93: aload_0
/*     */     //   94: getfield 62	clojure/core/Vec:cnt	I
/*     */     //   97: i2l
/*     */     //   98: lcmp
/*     */     //   99: ifne +10 -> 109
/*     */     //   102: getstatic 470	clojure/core/Vec:const__1	Ljava/lang/Object;
/*     */     //   105: goto +64 -> 169
/*     */     //   108: pop
/*     */     //   109: aload_0
/*     */     //   110: checkcast 42	clojure/lang/Indexed
/*     */     //   113: lload 4
/*     */     //   115: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   118: invokeinterface 138 2 0
/*     */     //   123: aload_2
/*     */     //   124: checkcast 42	clojure/lang/Indexed
/*     */     //   127: lload 4
/*     */     //   129: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   132: invokeinterface 138 2 0
/*     */     //   137: invokestatic 485	clojure/lang/Util:compare	(Ljava/lang/Object;Ljava/lang/Object;)I
/*     */     //   140: istore 6
/*     */     //   142: lconst_0
/*     */     //   143: iload 6
/*     */     //   145: i2l
/*     */     //   146: lcmp
/*     */     //   147: ifne +17 -> 164
/*     */     //   150: lload 4
/*     */     //   152: invokestatic 258	clojure/lang/Numbers:inc	(J)J
/*     */     //   155: lstore 4
/*     */     //   157: goto -66 -> 91
/*     */     //   160: goto +9 -> 169
/*     */     //   163: pop
/*     */     //   164: iload 6
/*     */     //   166: invokestatic 202	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
/*     */     //   169: goto +5 -> 174
/*     */     //   172: pop
/*     */     //   173: aconst_null
/*     */     //   174: checkcast 251	java/lang/Number
/*     */     //   177: invokevirtual 254	java/lang/Number:intValue	()I
/*     */     //   180: ireturn
/*     */     // Line number table:
/*     */     //   Java source line #131	-> byte code offset #0
/*     */     //   Java source line #367	-> byte code offset #0
/*     */     //   Java source line #367	-> byte code offset #2
/*     */     //   Java source line #370	-> byte code offset #29
/*     */     //   Java source line #371	-> byte code offset #35
/*     */     //   Java source line #372	-> byte code offset #35
/*     */     //   Java source line #371	-> byte code offset #53
/*     */     //   Java source line #373	-> byte code offset #53
/*     */     //   Java source line #371	-> byte code offset #71
/*     */     //   Java source line #375	-> byte code offset #85
/*     */     //   Java source line #0	-> byte code offset #88
/*     */     //   Java source line #376	-> byte code offset #91
/*     */     //   Java source line #376	-> byte code offset #91
/*     */     //   Java source line #378	-> byte code offset #118
/*     */     //   Java source line #378	-> byte code offset #132
/*     */     //   Java source line #378	-> byte code offset #137
/*     */     //   Java source line #379	-> byte code offset #142
/*     */     //   Java source line #379	-> byte code offset #142
/*     */     //   Java source line #380	-> byte code offset #152
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	180	0	this	Vec
/*     */     //   0	180	1	o	Object
/*     */     //   25	149	2	v	Object
/*     */     //   35	139	3	vcnt	int
/*     */     //   91	78	4	i	long
/*     */     //   142	27	6	comp	int
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public Object valAt(Object k, Object not_found)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_1
/*     */     //   1: invokestatic 371	clojure/lang/Util:isInteger	(Ljava/lang/Object;)Z
/*     */     //   4: ifeq +63 -> 67
/*     */     //   7: aload_1
/*     */     //   8: aconst_null
/*     */     //   9: astore_1
/*     */     //   10: invokestatic 373	clojure/lang/RT:intCast	(Ljava/lang/Object;)I
/*     */     //   13: istore_3
/*     */     //   14: iload_3
/*     */     //   15: i2l
/*     */     //   16: lconst_0
/*     */     //   17: invokestatic 126	clojure/lang/Numbers:gte	(JJ)Z
/*     */     //   20: istore 4
/*     */     //   22: iload 4
/*     */     //   24: ifeq +17 -> 41
/*     */     //   27: iload_3
/*     */     //   28: i2l
/*     */     //   29: aload_0
/*     */     //   30: getfield 62	clojure/core/Vec:cnt	I
/*     */     //   33: i2l
/*     */     //   34: invokestatic 133	clojure/lang/Numbers:lt	(JJ)Z
/*     */     //   37: goto +6 -> 43
/*     */     //   40: pop
/*     */     //   41: iload 4
/*     */     //   43: ifeq +17 -> 60
/*     */     //   46: aload_0
/*     */     //   47: checkcast 42	clojure/lang/Indexed
/*     */     //   50: iload_3
/*     */     //   51: invokeinterface 138 2 0
/*     */     //   56: goto +7 -> 63
/*     */     //   59: pop
/*     */     //   60: aload_2
/*     */     //   61: aconst_null
/*     */     //   62: astore_2
/*     */     //   63: goto +7 -> 70
/*     */     //   66: pop
/*     */     //   67: aload_2
/*     */     //   68: aconst_null
/*     */     //   69: astore_2
/*     */     //   70: areturn
/*     */     // Line number table:
/*     */     //   Java source line #131	-> byte code offset #0
/*     */     //   Java source line #275	-> byte code offset #0
/*     */     //   Java source line #275	-> byte code offset #1
/*     */     //   Java source line #276	-> byte code offset #10
/*     */     //   Java source line #277	-> byte code offset #14
/*     */     //   Java source line #277	-> byte code offset #17
/*     */     //   Java source line #277	-> byte code offset #22
/*     */     //   Java source line #277	-> byte code offset #34
/*     */     //   Java source line #278	-> byte code offset #51
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	70	0	this	Vec
/*     */     //   0	70	1	k	Object
/*     */     //   0	70	2	not_found	Object
/*     */     //   14	49	3	i	int
/*     */     //   22	21	4	and__4467__auto__6827	boolean
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public boolean retainAll(Collection c)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: new 176	java/lang/UnsupportedOperationException
/*     */     //   3: dup
/*     */     //   4: invokespecial 177	java/lang/UnsupportedOperationException:<init>	()V
/*     */     //   7: checkcast 179	java/lang/Throwable
/*     */     //   10: athrow
/*     */     //   11: checkcast 185	java/lang/Boolean
/*     */     //   14: invokevirtual 189	java/lang/Boolean:booleanValue	()Z
/*     */     //   17: ireturn
/*     */     // Line number table:
/*     */     //   Java source line #131	-> byte code offset #0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	17	0	this	Vec
/*     */     //   0	17	1	c	Collection
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public boolean removeAll(Collection c)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: new 176	java/lang/UnsupportedOperationException
/*     */     //   3: dup
/*     */     //   4: invokespecial 177	java/lang/UnsupportedOperationException:<init>	()V
/*     */     //   7: checkcast 179	java/lang/Throwable
/*     */     //   10: athrow
/*     */     //   11: checkcast 185	java/lang/Boolean
/*     */     //   14: invokevirtual 189	java/lang/Boolean:booleanValue	()Z
/*     */     //   17: ireturn
/*     */     // Line number table:
/*     */     //   Java source line #131	-> byte code offset #0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	17	0	this	Vec
/*     */     //   0	17	1	c	Collection
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public boolean remove(Object o)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: new 176	java/lang/UnsupportedOperationException
/*     */     //   3: dup
/*     */     //   4: invokespecial 177	java/lang/UnsupportedOperationException:<init>	()V
/*     */     //   7: checkcast 179	java/lang/Throwable
/*     */     //   10: athrow
/*     */     //   11: checkcast 185	java/lang/Boolean
/*     */     //   14: invokevirtual 189	java/lang/Boolean:booleanValue	()Z
/*     */     //   17: ireturn
/*     */     // Line number table:
/*     */     //   Java source line #131	-> byte code offset #0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	17	0	this	Vec
/*     */     //   0	17	1	o	Object
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public void clear()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: new 176	java/lang/UnsupportedOperationException
/*     */     //   3: dup
/*     */     //   4: invokespecial 177	java/lang/UnsupportedOperationException:<init>	()V
/*     */     //   7: checkcast 179	java/lang/Throwable
/*     */     //   10: athrow
/*     */     //   11: pop
/*     */     //   12: return
/*     */     // Line number table:
/*     */     //   Java source line #131	-> byte code offset #0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	12	0	this	Vec
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public boolean addAll(Collection c)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: new 176	java/lang/UnsupportedOperationException
/*     */     //   3: dup
/*     */     //   4: invokespecial 177	java/lang/UnsupportedOperationException:<init>	()V
/*     */     //   7: checkcast 179	java/lang/Throwable
/*     */     //   10: athrow
/*     */     //   11: checkcast 185	java/lang/Boolean
/*     */     //   14: invokevirtual 189	java/lang/Boolean:booleanValue	()Z
/*     */     //   17: ireturn
/*     */     // Line number table:
/*     */     //   Java source line #131	-> byte code offset #0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	17	0	this	Vec
/*     */     //   0	17	1	c	Collection
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public boolean add(Object o)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: new 176	java/lang/UnsupportedOperationException
/*     */     //   3: dup
/*     */     //   4: invokespecial 177	java/lang/UnsupportedOperationException:<init>	()V
/*     */     //   7: checkcast 179	java/lang/Throwable
/*     */     //   10: athrow
/*     */     //   11: checkcast 185	java/lang/Boolean
/*     */     //   14: invokevirtual 189	java/lang/Boolean:booleanValue	()Z
/*     */     //   17: ireturn
/*     */     // Line number table:
/*     */     //   Java source line #131	-> byte code offset #0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	17	0	this	Vec
/*     */     //   0	17	1	o	Object
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public Object[] toArray(Object[] arr)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_1
/*     */     //   1: invokestatic 445	clojure/lang/RT:count	(Ljava/lang/Object;)I
/*     */     //   4: i2l
/*     */     //   5: aload_0
/*     */     //   6: getfield 62	clojure/core/Vec:cnt	I
/*     */     //   9: i2l
/*     */     //   10: lcmp
/*     */     //   11: iflt +68 -> 79
/*     */     //   14: aload_0
/*     */     //   15: getfield 62	clojure/core/Vec:cnt	I
/*     */     //   18: i2l
/*     */     //   19: lstore_2
/*     */     //   20: lconst_0
/*     */     //   21: lstore 4
/*     */     //   23: lload 4
/*     */     //   25: lload_2
/*     */     //   26: lcmp
/*     */     //   27: ifge +43 -> 70
/*     */     //   30: aload_1
/*     */     //   31: checkcast 327	[Ljava/lang/Object;
/*     */     //   34: lload 4
/*     */     //   36: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   39: aload_0
/*     */     //   40: checkcast 42	clojure/lang/Indexed
/*     */     //   43: lload 4
/*     */     //   45: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   48: invokeinterface 138 2 0
/*     */     //   53: invokestatic 403	clojure/lang/RT:aset	([Ljava/lang/Object;ILjava/lang/Object;)Ljava/lang/Object;
/*     */     //   56: pop
/*     */     //   57: lload 4
/*     */     //   59: lconst_1
/*     */     //   60: ladd
/*     */     //   61: lstore 4
/*     */     //   63: goto -40 -> 23
/*     */     //   66: goto +6 -> 72
/*     */     //   69: pop
/*     */     //   70: aconst_null
/*     */     //   71: pop
/*     */     //   72: aload_1
/*     */     //   73: aconst_null
/*     */     //   74: astore_1
/*     */     //   75: goto +11 -> 86
/*     */     //   78: pop
/*     */     //   79: getstatic 502	clojure/core/Vec:const__26	Ljava/lang/Object;
/*     */     //   82: aload_0
/*     */     //   83: invokestatic 505	clojure/core$into_array:invokeStatic	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   86: checkcast 327	[Ljava/lang/Object;
/*     */     //   89: areturn
/*     */     // Line number table:
/*     */     //   Java source line #131	-> byte code offset #0
/*     */     //   Java source line #400	-> byte code offset #0
/*     */     //   Java source line #400	-> byte code offset #0
/*     */     //   Java source line #400	-> byte code offset #1
/*     */     //   Java source line #402	-> byte code offset #18
/*     */     //   Java source line #402	-> byte code offset #23
/*     */     //   Java source line #402	-> byte code offset #23
/*     */     //   Java source line #403	-> byte code offset #36
/*     */     //   Java source line #403	-> byte code offset #48
/*     */     //   Java source line #403	-> byte code offset #53
/*     */     //   Java source line #402	-> byte code offset #59
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	89	0	this	Vec
/*     */     //   0	89	1	arr	Object[]
/*     */     //   20	52	2	n__4940__auto__6828	long
/*     */     //   23	49	4	i	long
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public int hashCode()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: lconst_1
/*     */     //   1: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   4: i2l
/*     */     //   5: lstore_1
/*     */     //   6: lconst_0
/*     */     //   7: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   10: i2l
/*     */     //   11: lstore_3
/*     */     //   12: lload_3
/*     */     //   13: aload_0
/*     */     //   14: getfield 62	clojure/core/Vec:cnt	I
/*     */     //   17: i2l
/*     */     //   18: lcmp
/*     */     //   19: ifne +8 -> 27
/*     */     //   22: lload_1
/*     */     //   23: goto +49 -> 72
/*     */     //   26: pop
/*     */     //   27: aload_0
/*     */     //   28: checkcast 42	clojure/lang/Indexed
/*     */     //   31: lload_3
/*     */     //   32: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   35: invokeinterface 138 2 0
/*     */     //   40: astore 5
/*     */     //   42: ldc2_w 149
/*     */     //   45: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   48: lload_1
/*     */     //   49: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   52: imul
/*     */     //   53: aload 5
/*     */     //   55: aconst_null
/*     */     //   56: astore 5
/*     */     //   58: invokestatic 530	clojure/lang/Util:hash	(Ljava/lang/Object;)I
/*     */     //   61: iadd
/*     */     //   62: i2l
/*     */     //   63: lload_3
/*     */     //   64: invokestatic 258	clojure/lang/Numbers:inc	(J)J
/*     */     //   67: lstore_3
/*     */     //   68: lstore_1
/*     */     //   69: goto -57 -> 12
/*     */     //   72: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   75: ireturn
/*     */     // Line number table:
/*     */     //   Java source line #131	-> byte code offset #0
/*     */     //   Java source line #151	-> byte code offset #1
/*     */     //   Java source line #0	-> byte code offset #4
/*     */     //   Java source line #151	-> byte code offset #7
/*     */     //   Java source line #0	-> byte code offset #10
/*     */     //   Java source line #152	-> byte code offset #12
/*     */     //   Java source line #152	-> byte code offset #12
/*     */     //   Java source line #154	-> byte code offset #35
/*     */     //   Java source line #155	-> byte code offset #52
/*     */     //   Java source line #156	-> byte code offset #58
/*     */     //   Java source line #155	-> byte code offset #61
/*     */     //   Java source line #157	-> byte code offset #64
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	75	0	this	Vec
/*     */     //   6	66	1	hash	long
/*     */     //   12	60	3	i	long
/*     */     //   42	30	5	val	Object
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public boolean equals(Object o)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: aload_1
/*     */     //   2: invokestatic 317	clojure/lang/Util:identical	(Ljava/lang/Object;Ljava/lang/Object;)Z
/*     */     //   5: ifeq +10 -> 15
/*     */     //   8: getstatic 450	java/lang/Boolean:TRUE	Ljava/lang/Boolean;
/*     */     //   11: goto +266 -> 277
/*     */     //   14: pop
/*     */     //   15: aload_1
/*     */     //   16: instanceof 32
/*     */     //   19: istore_2
/*     */     //   20: iload_2
/*     */     //   21: ifeq +8 -> 29
/*     */     //   24: iload_2
/*     */     //   25: goto +8 -> 33
/*     */     //   28: pop
/*     */     //   29: aload_1
/*     */     //   30: instanceof 442
/*     */     //   33: ifeq +125 -> 158
/*     */     //   36: aload_0
/*     */     //   37: getfield 62	clojure/core/Vec:cnt	I
/*     */     //   40: i2l
/*     */     //   41: aload_1
/*     */     //   42: invokestatic 445	clojure/lang/RT:count	(Ljava/lang/Object;)I
/*     */     //   45: i2l
/*     */     //   46: invokestatic 447	clojure/lang/Util:equiv	(JJ)Z
/*     */     //   49: istore_2
/*     */     //   50: iload_2
/*     */     //   51: ifeq +90 -> 141
/*     */     //   54: lconst_0
/*     */     //   55: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   58: i2l
/*     */     //   59: lstore_3
/*     */     //   60: lload_3
/*     */     //   61: aload_0
/*     */     //   62: getfield 62	clojure/core/Vec:cnt	I
/*     */     //   65: i2l
/*     */     //   66: lcmp
/*     */     //   67: ifne +10 -> 77
/*     */     //   70: getstatic 450	java/lang/Boolean:TRUE	Ljava/lang/Boolean;
/*     */     //   73: goto +64 -> 137
/*     */     //   76: pop
/*     */     //   77: aload_0
/*     */     //   78: checkcast 42	clojure/lang/Indexed
/*     */     //   81: lload_3
/*     */     //   82: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   85: invokeinterface 138 2 0
/*     */     //   90: aload_1
/*     */     //   91: lload_3
/*     */     //   92: invokestatic 120	clojure/lang/RT:intCast	(J)I
/*     */     //   95: invokestatic 452	clojure/lang/RT:nth	(Ljava/lang/Object;I)Ljava/lang/Object;
/*     */     //   98: invokevirtual 534	java/lang/Object:equals	(Ljava/lang/Object;)Z
/*     */     //   101: ifeq +15 -> 116
/*     */     //   104: lload_3
/*     */     //   105: invokestatic 258	clojure/lang/Numbers:inc	(J)J
/*     */     //   108: lstore_3
/*     */     //   109: goto -49 -> 60
/*     */     //   112: goto +25 -> 137
/*     */     //   115: pop
/*     */     //   116: getstatic 244	clojure/core/Vec:const__12	Lclojure/lang/Keyword;
/*     */     //   119: dup
/*     */     //   120: ifnull +15 -> 135
/*     */     //   123: getstatic 248	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   126: if_acmpeq +10 -> 136
/*     */     //   129: getstatic 248	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   132: goto +5 -> 137
/*     */     //   135: pop
/*     */     //   136: aconst_null
/*     */     //   137: goto +17 -> 154
/*     */     //   140: pop
/*     */     //   141: iload_2
/*     */     //   142: ifeq +9 -> 151
/*     */     //   145: getstatic 450	java/lang/Boolean:TRUE	Ljava/lang/Boolean;
/*     */     //   148: goto +6 -> 154
/*     */     //   151: getstatic 248	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   154: goto +123 -> 277
/*     */     //   157: pop
/*     */     //   158: aload_1
/*     */     //   159: instanceof 30
/*     */     //   162: istore_2
/*     */     //   163: iload_2
/*     */     //   164: ifeq +8 -> 172
/*     */     //   167: iload_2
/*     */     //   168: goto +8 -> 176
/*     */     //   171: pop
/*     */     //   172: aload_1
/*     */     //   173: instanceof 38
/*     */     //   176: ifeq +80 -> 256
/*     */     //   179: aload_0
/*     */     //   180: invokestatic 457	clojure/core$seq__4357:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   183: astore_2
/*     */     //   184: aload_2
/*     */     //   185: dup
/*     */     //   186: ifnull +43 -> 229
/*     */     //   189: getstatic 248	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   192: if_acmpeq +38 -> 230
/*     */     //   195: aload_2
/*     */     //   196: aconst_null
/*     */     //   197: astore_2
/*     */     //   198: astore 5
/*     */     //   200: aload 5
/*     */     //   202: aconst_null
/*     */     //   203: astore 5
/*     */     //   205: aload_1
/*     */     //   206: aconst_null
/*     */     //   207: astore_1
/*     */     //   208: invokestatic 457	clojure/core$seq__4357:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   211: invokevirtual 534	java/lang/Object:equals	(Ljava/lang/Object;)Z
/*     */     //   214: ifeq +9 -> 223
/*     */     //   217: getstatic 450	java/lang/Boolean:TRUE	Ljava/lang/Boolean;
/*     */     //   220: goto +6 -> 226
/*     */     //   223: getstatic 248	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   226: goto +26 -> 252
/*     */     //   229: pop
/*     */     //   230: aload_1
/*     */     //   231: aconst_null
/*     */     //   232: astore_1
/*     */     //   233: invokestatic 457	clojure/core$seq__4357:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   236: aconst_null
/*     */     //   237: invokestatic 317	clojure/lang/Util:identical	(Ljava/lang/Object;Ljava/lang/Object;)Z
/*     */     //   240: ifeq +9 -> 249
/*     */     //   243: getstatic 450	java/lang/Boolean:TRUE	Ljava/lang/Boolean;
/*     */     //   246: goto +6 -> 252
/*     */     //   249: getstatic 248	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   252: goto +25 -> 277
/*     */     //   255: pop
/*     */     //   256: getstatic 244	clojure/core/Vec:const__12	Lclojure/lang/Keyword;
/*     */     //   259: dup
/*     */     //   260: ifnull +15 -> 275
/*     */     //   263: getstatic 248	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   266: if_acmpeq +10 -> 276
/*     */     //   269: getstatic 248	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   272: goto +5 -> 277
/*     */     //   275: pop
/*     */     //   276: aconst_null
/*     */     //   277: checkcast 185	java/lang/Boolean
/*     */     //   280: invokevirtual 189	java/lang/Boolean:booleanValue	()Z
/*     */     //   283: ireturn
/*     */     // Line number table:
/*     */     //   Java source line #131	-> byte code offset #0
/*     */     //   Java source line #134	-> byte code offset #0
/*     */     //   Java source line #135	-> byte code offset #2
/*     */     //   Java source line #134	-> byte code offset #15
/*     */     //   Java source line #136	-> byte code offset #20
/*     */     //   Java source line #137	-> byte code offset #42
/*     */     //   Java source line #137	-> byte code offset #46
/*     */     //   Java source line #137	-> byte code offset #50
/*     */     //   Java source line #138	-> byte code offset #55
/*     */     //   Java source line #0	-> byte code offset #58
/*     */     //   Java source line #139	-> byte code offset #60
/*     */     //   Java source line #140	-> byte code offset #60
/*     */     //   Java source line #139	-> byte code offset #77
/*     */     //   Java source line #141	-> byte code offset #85
/*     */     //   Java source line #141	-> byte code offset #95
/*     */     //   Java source line #141	-> byte code offset #98
/*     */     //   Java source line #141	-> byte code offset #105
/*     */     //   Java source line #139	-> byte code offset #116
/*     */     //   Java source line #134	-> byte code offset #158
/*     */     //   Java source line #143	-> byte code offset #163
/*     */     //   Java source line #144	-> byte code offset #184
/*     */     //   Java source line #145	-> byte code offset #211
/*     */     //   Java source line #146	-> byte code offset #237
/*     */     //   Java source line #134	-> byte code offset #256
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	283	0	this	Vec
/*     */     //   0	283	1	o	Object
/*     */     //   20	13	2	or__4469__auto__6829	boolean
/*     */     //   50	104	2	and__4467__auto__6830	boolean
/*     */     //   163	13	2	or__4469__auto__6831	boolean
/*     */     //   184	68	2	temp__4655__auto__6832	Object
/*     */     //   60	77	3	i	long
/*     */     //   200	26	5	st	Object
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public clojure.lang.IMapEntry entryAt(Object k)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: checkcast 6	clojure/lang/Associative
/*     */     //   4: aload_1
/*     */     //   5: invokeinterface 543 2 0
/*     */     //   10: ifeq +26 -> 36
/*     */     //   13: aload_1
/*     */     //   14: aload_0
/*     */     //   15: checkcast 42	clojure/lang/Indexed
/*     */     //   18: aload_1
/*     */     //   19: aconst_null
/*     */     //   20: astore_1
/*     */     //   21: invokestatic 373	clojure/lang/RT:intCast	(Ljava/lang/Object;)I
/*     */     //   24: invokeinterface 138 2 0
/*     */     //   29: invokestatic 548	clojure/lang/MapEntry:create	(Ljava/lang/Object;Ljava/lang/Object;)Lclojure/lang/MapEntry;
/*     */     //   32: goto +5 -> 37
/*     */     //   35: pop
/*     */     //   36: aconst_null
/*     */     //   37: checkcast 550	clojure/lang/IMapEntry
/*     */     //   40: areturn
/*     */     // Line number table:
/*     */     //   Java source line #131	-> byte code offset #0
/*     */     //   Java source line #269	-> byte code offset #0
/*     */     //   Java source line #269	-> byte code offset #5
/*     */     //   Java source line #270	-> byte code offset #21
/*     */     //   Java source line #270	-> byte code offset #24
/*     */     //   Java source line #270	-> byte code offset #29
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	40	0	this	Vec
/*     */     //   0	40	1	k	Object
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public boolean containsKey(Object k)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_1
/*     */     //   1: invokestatic 371	clojure/lang/Util:isInteger	(Ljava/lang/Object;)Z
/*     */     //   4: istore_2
/*     */     //   5: iload_2
/*     */     //   6: ifeq +41 -> 47
/*     */     //   9: lconst_0
/*     */     //   10: aload_1
/*     */     //   11: invokestatic 373	clojure/lang/RT:intCast	(Ljava/lang/Object;)I
/*     */     //   14: i2l
/*     */     //   15: invokestatic 347	clojure/lang/Numbers:lte	(JJ)Z
/*     */     //   18: istore_3
/*     */     //   19: iload_3
/*     */     //   20: ifeq +22 -> 42
/*     */     //   23: aload_1
/*     */     //   24: aconst_null
/*     */     //   25: astore_1
/*     */     //   26: invokestatic 373	clojure/lang/RT:intCast	(Ljava/lang/Object;)I
/*     */     //   29: i2l
/*     */     //   30: aload_0
/*     */     //   31: getfield 62	clojure/core/Vec:cnt	I
/*     */     //   34: i2l
/*     */     //   35: invokestatic 133	clojure/lang/Numbers:lt	(JJ)Z
/*     */     //   38: goto +5 -> 43
/*     */     //   41: pop
/*     */     //   42: iload_3
/*     */     //   43: goto +5 -> 48
/*     */     //   46: pop
/*     */     //   47: iload_2
/*     */     //   48: ireturn
/*     */     // Line number table:
/*     */     //   Java source line #131	-> byte code offset #0
/*     */     //   Java source line #265	-> byte code offset #1
/*     */     //   Java source line #265	-> byte code offset #5
/*     */     //   Java source line #266	-> byte code offset #11
/*     */     //   Java source line #266	-> byte code offset #15
/*     */     //   Java source line #265	-> byte code offset #19
/*     */     //   Java source line #267	-> byte code offset #26
/*     */     //   Java source line #267	-> byte code offset #35
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	48	0	this	Vec
/*     */     //   0	48	1	k	Object
/*     */     //   5	43	2	and__4467__auto__6834	boolean
/*     */     //   19	24	3	and__4467__auto__6833	boolean
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public Associative assoc(Object k, Object v)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_1
/*     */     //   1: invokestatic 371	clojure/lang/Util:isInteger	(Ljava/lang/Object;)Z
/*     */     //   4: ifeq +28 -> 32
/*     */     //   7: aload_0
/*     */     //   8: checkcast 32	clojure/lang/IPersistentVector
/*     */     //   11: aload_1
/*     */     //   12: aconst_null
/*     */     //   13: astore_1
/*     */     //   14: checkcast 251	java/lang/Number
/*     */     //   17: invokestatic 373	clojure/lang/RT:intCast	(Ljava/lang/Object;)I
/*     */     //   20: aload_2
/*     */     //   21: aconst_null
/*     */     //   22: astore_2
/*     */     //   23: invokeinterface 556 3 0
/*     */     //   28: goto +21 -> 49
/*     */     //   31: pop
/*     */     //   32: new 376	java/lang/IllegalArgumentException
/*     */     //   35: dup
/*     */     //   36: ldc_w 378
/*     */     //   39: checkcast 267	java/lang/String
/*     */     //   42: invokespecial 379	java/lang/IllegalArgumentException:<init>	(Ljava/lang/String;)V
/*     */     //   45: checkcast 179	java/lang/Throwable
/*     */     //   48: athrow
/*     */     //   49: checkcast 6	clojure/lang/Associative
/*     */     //   52: areturn
/*     */     // Line number table:
/*     */     //   Java source line #131	-> byte code offset #0
/*     */     //   Java source line #261	-> byte code offset #0
/*     */     //   Java source line #261	-> byte code offset #1
/*     */     //   Java source line #262	-> byte code offset #23
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	52	0	this	Vec
/*     */     //   0	52	1	k	Object
/*     */     //   0	52	2	v	Object
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\core\Vec.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */