package clojure.core;

public abstract interface IVecImpl
{
  public abstract int tailoff();
  
  public abstract Object arrayFor(int paramInt);
  
  public abstract Object pushTail(int paramInt, VecNode paramVecNode1, VecNode paramVecNode2);
  
  public abstract Object popTail(int paramInt, Object paramObject);
  
  public abstract Object newPath(Object paramObject1, int paramInt, Object paramObject2);
  
  public abstract Object doAssoc(int paramInt1, Object paramObject1, int paramInt2, Object paramObject2);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\core\IVecImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */