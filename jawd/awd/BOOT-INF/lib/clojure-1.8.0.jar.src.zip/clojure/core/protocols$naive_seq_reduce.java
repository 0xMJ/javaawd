/*    */ package clojure.core;
/*    */ 
/*    */ import clojure.lang.AFunction;
/*    */ 
/*    */ public final class protocols$naive_seq_reduce
/*    */   extends AFunction
/*    */ {
/*    */   /* Error */
/*    */   public static Object invokeStatic(Object s, Object f, Object val)
/*    */   {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: aconst_null
/*    */     //   2: astore_0
/*    */     //   3: invokestatic 16	clojure/core$seq__4357:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   6: astore_3
/*    */     //   7: aload_2
/*    */     //   8: aconst_null
/*    */     //   9: astore_2
/*    */     //   10: astore 4
/*    */     //   12: aload_3
/*    */     //   13: dup
/*    */     //   14: ifnull +69 -> 83
/*    */     //   17: getstatic 22	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*    */     //   20: if_acmpeq +64 -> 84
/*    */     //   23: aload_1
/*    */     //   24: checkcast 24	clojure/lang/IFn
/*    */     //   27: aload 4
/*    */     //   29: aconst_null
/*    */     //   30: astore 4
/*    */     //   32: aload_3
/*    */     //   33: invokestatic 27	clojure/core$first__4339:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   36: invokeinterface 31 3 0
/*    */     //   41: astore 5
/*    */     //   43: aload 5
/*    */     //   45: invokestatic 37	clojure/lang/RT:isReduced	(Ljava/lang/Object;)Z
/*    */     //   48: ifeq +15 -> 63
/*    */     //   51: aload 5
/*    */     //   53: aconst_null
/*    */     //   54: astore 5
/*    */     //   56: invokestatic 40	clojure/core$deref:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   59: goto +21 -> 80
/*    */     //   62: pop
/*    */     //   63: aload_3
/*    */     //   64: aconst_null
/*    */     //   65: astore_3
/*    */     //   66: invokestatic 43	clojure/core$next__4341:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   69: aload 5
/*    */     //   71: aconst_null
/*    */     //   72: astore 5
/*    */     //   74: astore 4
/*    */     //   76: astore_3
/*    */     //   77: goto -65 -> 12
/*    */     //   80: goto +9 -> 89
/*    */     //   83: pop
/*    */     //   84: aload 4
/*    */     //   86: aconst_null
/*    */     //   87: astore 4
/*    */     //   89: areturn
/*    */     // Line number table:
/*    */     //   Java source line #55	-> byte code offset #0
/*    */     //   Java source line #61	-> byte code offset #12
/*    */     //   Java source line #62	-> byte code offset #24
/*    */     //   Java source line #62	-> byte code offset #36
/*    */     //   Java source line #63	-> byte code offset #43
/*    */     //   Java source line #63	-> byte code offset #45
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	signature
/*    */     //   0	89	0	s	Object
/*    */     //   0	89	1	f	Object
/*    */     //   0	89	2	val	Object
/*    */     //   7	82	3	s	Object
/*    */     //   12	77	4	val	Object
/*    */     //   43	37	5	ret	Object
/*    */   }
/*    */   
/*    */   public Object invoke(Object paramObject1, Object paramObject2, Object paramObject3)
/*    */   {
/* 55 */     paramObject1 = null;paramObject2 = null;paramObject3 = null;return invokeStatic(paramObject1, paramObject2, paramObject3);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\core\protocols$naive_seq_reduce.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */