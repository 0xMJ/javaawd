/*     */ package clojure.core;
/*     */ 
/*     */ import clojure.core.protocols.InternalReduce;
/*     */ import clojure.lang.Cons;
/*     */ import clojure.lang.IChunk;
/*     */ import clojure.lang.IChunkedSeq;
/*     */ import clojure.lang.IObj;
/*     */ import clojure.lang.IPersistentCollection;
/*     */ import clojure.lang.IPersistentMap;
/*     */ import clojure.lang.IPersistentVector;
/*     */ import clojure.lang.ISeq;
/*     */ import clojure.lang.IType;
/*     */ import clojure.lang.Keyword;
/*     */ import clojure.lang.PersistentList;
/*     */ import clojure.lang.RT;
/*     */ import clojure.lang.Seqable;
/*     */ import clojure.lang.Symbol;
/*     */ import clojure.lang.Tuple;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class VecSeq
/*     */   implements ISeq, IChunkedSeq, InternalReduce, Seqable, IType
/*     */ {
/*     */   public final Object am;
/*     */   public final Object vec;
/*     */   public final Object anode;
/*     */   public final int i;
/*     */   public final int offset;
/*     */   
/*     */   public VecSeq(Object paramObject1, Object paramObject2, Object paramObject3, int paramInt1, int paramInt2)
/*     */   {
/*  58 */     this.am = paramObject1;this.vec = paramObject2;this.anode = paramObject3;this.i = paramInt1;this.offset = paramInt2; } public ISeq seq() { return (ISeq)this; } public IPersistentCollection empty() { return (IPersistentCollection)PersistentList.EMPTY; } public ISeq cons(Object o) { o = null;return (ISeq)new Cons(o, (ISeq)this); } public static final Keyword const__19 = (Keyword)RT.keyword(null, "else");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object first()
/*     */   {
/*  82 */     return ((ArrayManager)this.am).aget(this.anode, this.offset);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public IChunk chunkedFirst()
/*     */   {
/* 119 */     return (IChunk)new ArrayChunk(this.am, this.anode, this.offset, ((ArrayManager)this.am).alength(this.anode));
/*     */   }
/*     */   
/*     */   public static IPersistentVector getBasis()
/*     */   {
/*     */     return Tuple.create(((IObj)Symbol.intern(null, "am")).withMeta((IPersistentMap)RT.map(new Object[] { RT.keyword(null, "tag"), Symbol.intern(null, "clojure.core.ArrayManager") })), ((IObj)Symbol.intern(null, "vec")).withMeta((IPersistentMap)RT.map(new Object[] { RT.keyword(null, "tag"), Symbol.intern(null, "clojure.core.IVecImpl") })), Symbol.intern(null, "anode"), ((IObj)Symbol.intern(null, "i")).withMeta((IPersistentMap)RT.map(new Object[] { RT.keyword(null, "tag"), Symbol.intern(null, "int") })), ((IObj)Symbol.intern(null, "offset")).withMeta((IPersistentMap)RT.map(new Object[] { RT.keyword(null, "tag"), Symbol.intern(null, "int") })));
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public ISeq chunkedMore()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: checkcast 8	clojure/lang/IChunkedSeq
/*     */     //   4: invokeinterface 87 1 0
/*     */     //   9: astore_1
/*     */     //   10: aload_1
/*     */     //   11: aconst_null
/*     */     //   12: astore_1
/*     */     //   13: astore_2
/*     */     //   14: aload_2
/*     */     //   15: dup
/*     */     //   16: ifnull +15 -> 31
/*     */     //   19: getstatic 93	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   22: if_acmpeq +10 -> 32
/*     */     //   25: aload_2
/*     */     //   26: aconst_null
/*     */     //   27: astore_2
/*     */     //   28: goto +7 -> 35
/*     */     //   31: pop
/*     */     //   32: getstatic 99	clojure/lang/PersistentList:EMPTY	Lclojure/lang/PersistentList$EmptyList;
/*     */     //   35: checkcast 6	clojure/lang/ISeq
/*     */     //   38: areturn
/*     */     // Line number table:
/*     */     //   Java source line #58	-> byte code offset #0
/*     */     //   Java source line #125	-> byte code offset #4
/*     */     //   Java source line #126	-> byte code offset #14
/*     */     //   Java source line #126	-> byte code offset #32
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	38	0	this	VecSeq
/*     */     //   10	25	1	s	Object
/*     */     //   14	21	2	or__4469__auto__6796	Object
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public ISeq chunkedNext()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 35	clojure/core/VecSeq:i	I
/*     */     //   4: i2l
/*     */     //   5: aload_0
/*     */     //   6: getfield 29	clojure/core/VecSeq:am	Ljava/lang/Object;
/*     */     //   9: checkcast 105	clojure/core/ArrayManager
/*     */     //   12: aload_0
/*     */     //   13: getfield 33	clojure/core/VecSeq:anode	Ljava/lang/Object;
/*     */     //   16: invokeinterface 109 2 0
/*     */     //   21: i2l
/*     */     //   22: invokestatic 115	clojure/lang/Numbers:add	(JJ)J
/*     */     //   25: lstore_1
/*     */     //   26: lload_1
/*     */     //   27: aload_0
/*     */     //   28: getfield 31	clojure/core/VecSeq:vec	Ljava/lang/Object;
/*     */     //   31: invokestatic 118	clojure/lang/RT:count	(Ljava/lang/Object;)I
/*     */     //   34: i2l
/*     */     //   35: lcmp
/*     */     //   36: ifge +46 -> 82
/*     */     //   39: new 2	clojure/core/VecSeq
/*     */     //   42: dup
/*     */     //   43: aload_0
/*     */     //   44: getfield 29	clojure/core/VecSeq:am	Ljava/lang/Object;
/*     */     //   47: aload_0
/*     */     //   48: getfield 31	clojure/core/VecSeq:vec	Ljava/lang/Object;
/*     */     //   51: aload_0
/*     */     //   52: getfield 31	clojure/core/VecSeq:vec	Ljava/lang/Object;
/*     */     //   55: checkcast 120	clojure/core/IVecImpl
/*     */     //   58: lload_1
/*     */     //   59: invokestatic 124	clojure/lang/RT:intCast	(J)I
/*     */     //   62: invokeinterface 128 2 0
/*     */     //   67: lload_1
/*     */     //   68: invokestatic 124	clojure/lang/RT:intCast	(J)I
/*     */     //   71: lconst_0
/*     */     //   72: invokestatic 124	clojure/lang/RT:intCast	(J)I
/*     */     //   75: invokespecial 130	clojure/core/VecSeq:<init>	(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;II)V
/*     */     //   78: goto +5 -> 83
/*     */     //   81: pop
/*     */     //   82: aconst_null
/*     */     //   83: checkcast 6	clojure/lang/ISeq
/*     */     //   86: areturn
/*     */     // Line number table:
/*     */     //   Java source line #58	-> byte code offset #0
/*     */     //   Java source line #121	-> byte code offset #16
/*     */     //   Java source line #121	-> byte code offset #22
/*     */     //   Java source line #122	-> byte code offset #26
/*     */     //   Java source line #122	-> byte code offset #26
/*     */     //   Java source line #122	-> byte code offset #31
/*     */     //   Java source line #123	-> byte code offset #62
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	86	0	this	VecSeq
/*     */     //   26	57	1	nexti	long
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public boolean equiv(Object o)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: aload_1
/*     */     //   2: invokestatic 154	clojure/lang/Util:identical	(Ljava/lang/Object;Ljava/lang/Object;)Z
/*     */     //   5: ifeq +10 -> 15
/*     */     //   8: getstatic 157	java/lang/Boolean:TRUE	Ljava/lang/Boolean;
/*     */     //   11: goto +143 -> 154
/*     */     //   14: pop
/*     */     //   15: aload_1
/*     */     //   16: instanceof 159
/*     */     //   19: istore_2
/*     */     //   20: iload_2
/*     */     //   21: ifeq +8 -> 29
/*     */     //   24: iload_2
/*     */     //   25: goto +8 -> 33
/*     */     //   28: pop
/*     */     //   29: aload_1
/*     */     //   30: instanceof 161
/*     */     //   33: ifeq +100 -> 133
/*     */     //   36: aload_0
/*     */     //   37: astore_2
/*     */     //   38: aload_1
/*     */     //   39: aconst_null
/*     */     //   40: astore_1
/*     */     //   41: invokestatic 169	clojure/core$seq__4357:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   44: astore_3
/*     */     //   45: aload_2
/*     */     //   46: aconst_null
/*     */     //   47: invokestatic 154	clojure/lang/Util:identical	(Ljava/lang/Object;Ljava/lang/Object;)Z
/*     */     //   50: ifeq +26 -> 76
/*     */     //   53: aload_3
/*     */     //   54: aconst_null
/*     */     //   55: astore_3
/*     */     //   56: aconst_null
/*     */     //   57: invokestatic 154	clojure/lang/Util:identical	(Ljava/lang/Object;Ljava/lang/Object;)Z
/*     */     //   60: ifeq +9 -> 69
/*     */     //   63: getstatic 157	java/lang/Boolean:TRUE	Ljava/lang/Boolean;
/*     */     //   66: goto +6 -> 72
/*     */     //   69: getstatic 93	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   72: goto +57 -> 129
/*     */     //   75: pop
/*     */     //   76: aload_2
/*     */     //   77: invokestatic 172	clojure/core$first__4339:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   80: aload_3
/*     */     //   81: invokestatic 172	clojure/core$first__4339:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   84: invokestatic 174	clojure/lang/Util:equiv	(Ljava/lang/Object;Ljava/lang/Object;)Z
/*     */     //   87: istore 4
/*     */     //   89: iload 4
/*     */     //   91: ifeq +24 -> 115
/*     */     //   94: aload_2
/*     */     //   95: aconst_null
/*     */     //   96: astore_2
/*     */     //   97: invokestatic 177	clojure/core$next__4341:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   100: aload_3
/*     */     //   101: aconst_null
/*     */     //   102: astore_3
/*     */     //   103: invokestatic 177	clojure/core$next__4341:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   106: astore_3
/*     */     //   107: astore_2
/*     */     //   108: goto -63 -> 45
/*     */     //   111: goto +18 -> 129
/*     */     //   114: pop
/*     */     //   115: iload 4
/*     */     //   117: ifeq +9 -> 126
/*     */     //   120: getstatic 157	java/lang/Boolean:TRUE	Ljava/lang/Boolean;
/*     */     //   123: goto +6 -> 129
/*     */     //   126: getstatic 93	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   129: goto +25 -> 154
/*     */     //   132: pop
/*     */     //   133: getstatic 184	clojure/core/VecSeq:const__19	Lclojure/lang/Keyword;
/*     */     //   136: dup
/*     */     //   137: ifnull +15 -> 152
/*     */     //   140: getstatic 93	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   143: if_acmpeq +10 -> 153
/*     */     //   146: getstatic 93	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   149: goto +5 -> 154
/*     */     //   152: pop
/*     */     //   153: aconst_null
/*     */     //   154: checkcast 89	java/lang/Boolean
/*     */     //   157: invokevirtual 188	java/lang/Boolean:booleanValue	()Z
/*     */     //   160: ireturn
/*     */     // Line number table:
/*     */     //   Java source line #58	-> byte code offset #0
/*     */     //   Java source line #101	-> byte code offset #0
/*     */     //   Java source line #102	-> byte code offset #2
/*     */     //   Java source line #101	-> byte code offset #15
/*     */     //   Java source line #103	-> byte code offset #20
/*     */     //   Java source line #106	-> byte code offset #45
/*     */     //   Java source line #106	-> byte code offset #47
/*     */     //   Java source line #107	-> byte code offset #57
/*     */     //   Java source line #108	-> byte code offset #84
/*     */     //   Java source line #108	-> byte code offset #89
/*     */     //   Java source line #101	-> byte code offset #133
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	160	0	this	VecSeq
/*     */     //   0	160	1	o	Object
/*     */     //   20	13	2	or__4469__auto__6797	boolean
/*     */     //   38	91	2	me	Object
/*     */     //   45	84	3	you	Object
/*     */     //   89	40	4	and__4467__auto__6798	boolean
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public int count()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: lconst_1
/*     */     //   1: lstore_1
/*     */     //   2: aload_0
/*     */     //   3: invokestatic 177	clojure/core$next__4341:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   6: astore_3
/*     */     //   7: aload_3
/*     */     //   8: dup
/*     */     //   9: ifnull +54 -> 63
/*     */     //   12: getstatic 93	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   15: if_acmpeq +49 -> 64
/*     */     //   18: aload_3
/*     */     //   19: instanceof 192
/*     */     //   22: ifeq +23 -> 45
/*     */     //   25: lload_1
/*     */     //   26: aload_3
/*     */     //   27: aconst_null
/*     */     //   28: astore_3
/*     */     //   29: checkcast 146	clojure/lang/IPersistentCollection
/*     */     //   32: invokeinterface 194 1 0
/*     */     //   37: i2l
/*     */     //   38: invokestatic 115	clojure/lang/Numbers:add	(JJ)J
/*     */     //   41: goto +19 -> 60
/*     */     //   44: pop
/*     */     //   45: lload_1
/*     */     //   46: invokestatic 198	clojure/lang/Numbers:inc	(J)J
/*     */     //   49: aload_3
/*     */     //   50: aconst_null
/*     */     //   51: astore_3
/*     */     //   52: invokestatic 177	clojure/core$next__4341:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   55: astore_3
/*     */     //   56: lstore_1
/*     */     //   57: goto -50 -> 7
/*     */     //   60: goto +5 -> 65
/*     */     //   63: pop
/*     */     //   64: lload_1
/*     */     //   65: invokestatic 124	clojure/lang/RT:intCast	(J)I
/*     */     //   68: ireturn
/*     */     // Line number table:
/*     */     //   Java source line #58	-> byte code offset #0
/*     */     //   Java source line #95	-> byte code offset #7
/*     */     //   Java source line #96	-> byte code offset #18
/*     */     //   Java source line #97	-> byte code offset #32
/*     */     //   Java source line #97	-> byte code offset #38
/*     */     //   Java source line #98	-> byte code offset #46
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	68	0	this	VecSeq
/*     */     //   2	63	1	i	long
/*     */     //   7	58	3	s	Object
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public ISeq more()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: checkcast 6	clojure/lang/ISeq
/*     */     //   4: invokeinterface 209 1 0
/*     */     //   9: astore_1
/*     */     //   10: aload_1
/*     */     //   11: aconst_null
/*     */     //   12: astore_1
/*     */     //   13: astore_2
/*     */     //   14: aload_2
/*     */     //   15: dup
/*     */     //   16: ifnull +15 -> 31
/*     */     //   19: getstatic 93	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   22: if_acmpeq +10 -> 32
/*     */     //   25: aload_2
/*     */     //   26: aconst_null
/*     */     //   27: astore_2
/*     */     //   28: goto +7 -> 35
/*     */     //   31: pop
/*     */     //   32: getstatic 99	clojure/lang/PersistentList:EMPTY	Lclojure/lang/PersistentList$EmptyList;
/*     */     //   35: checkcast 6	clojure/lang/ISeq
/*     */     //   38: areturn
/*     */     // Line number table:
/*     */     //   Java source line #58	-> byte code offset #0
/*     */     //   Java source line #88	-> byte code offset #4
/*     */     //   Java source line #89	-> byte code offset #14
/*     */     //   Java source line #89	-> byte code offset #32
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	38	0	this	VecSeq
/*     */     //   10	25	1	s	Object
/*     */     //   14	21	2	or__4469__auto__6799	Object
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public ISeq next()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 37	clojure/core/VecSeq:offset	I
/*     */     //   4: i2l
/*     */     //   5: invokestatic 198	clojure/lang/Numbers:inc	(J)J
/*     */     //   8: aload_0
/*     */     //   9: getfield 29	clojure/core/VecSeq:am	Ljava/lang/Object;
/*     */     //   12: checkcast 105	clojure/core/ArrayManager
/*     */     //   15: aload_0
/*     */     //   16: getfield 33	clojure/core/VecSeq:anode	Ljava/lang/Object;
/*     */     //   19: invokeinterface 109 2 0
/*     */     //   24: i2l
/*     */     //   25: lcmp
/*     */     //   26: ifge +41 -> 67
/*     */     //   29: new 2	clojure/core/VecSeq
/*     */     //   32: dup
/*     */     //   33: aload_0
/*     */     //   34: getfield 29	clojure/core/VecSeq:am	Ljava/lang/Object;
/*     */     //   37: aload_0
/*     */     //   38: getfield 31	clojure/core/VecSeq:vec	Ljava/lang/Object;
/*     */     //   41: aload_0
/*     */     //   42: getfield 33	clojure/core/VecSeq:anode	Ljava/lang/Object;
/*     */     //   45: aload_0
/*     */     //   46: getfield 35	clojure/core/VecSeq:i	I
/*     */     //   49: aload_0
/*     */     //   50: getfield 37	clojure/core/VecSeq:offset	I
/*     */     //   53: i2l
/*     */     //   54: invokestatic 198	clojure/lang/Numbers:inc	(J)J
/*     */     //   57: invokestatic 124	clojure/lang/RT:intCast	(J)I
/*     */     //   60: invokespecial 130	clojure/core/VecSeq:<init>	(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;II)V
/*     */     //   63: goto +13 -> 76
/*     */     //   66: pop
/*     */     //   67: aload_0
/*     */     //   68: checkcast 8	clojure/lang/IChunkedSeq
/*     */     //   71: invokeinterface 87 1 0
/*     */     //   76: checkcast 6	clojure/lang/ISeq
/*     */     //   79: areturn
/*     */     // Line number table:
/*     */     //   Java source line #58	-> byte code offset #0
/*     */     //   Java source line #84	-> byte code offset #0
/*     */     //   Java source line #84	-> byte code offset #0
/*     */     //   Java source line #84	-> byte code offset #5
/*     */     //   Java source line #84	-> byte code offset #19
/*     */     //   Java source line #85	-> byte code offset #54
/*     */     //   Java source line #86	-> byte code offset #71
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	79	0	this	VecSeq
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public Object internal_reduce(Object f, Object val)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_2
/*     */     //   1: aconst_null
/*     */     //   2: astore_2
/*     */     //   3: astore_3
/*     */     //   4: aload_0
/*     */     //   5: getfield 35	clojure/core/VecSeq:i	I
/*     */     //   8: i2l
/*     */     //   9: aload_0
/*     */     //   10: getfield 37	clojure/core/VecSeq:offset	I
/*     */     //   13: i2l
/*     */     //   14: invokestatic 115	clojure/lang/Numbers:add	(JJ)J
/*     */     //   17: lstore 4
/*     */     //   19: lload 4
/*     */     //   21: aload_0
/*     */     //   22: getfield 31	clojure/core/VecSeq:vec	Ljava/lang/Object;
/*     */     //   25: invokestatic 118	clojure/lang/RT:count	(Ljava/lang/Object;)I
/*     */     //   28: i2l
/*     */     //   29: lcmp
/*     */     //   30: ifge +101 -> 131
/*     */     //   33: aload_0
/*     */     //   34: getfield 31	clojure/core/VecSeq:vec	Ljava/lang/Object;
/*     */     //   37: checkcast 120	clojure/core/IVecImpl
/*     */     //   40: lload 4
/*     */     //   42: invokestatic 124	clojure/lang/RT:intCast	(J)I
/*     */     //   45: invokeinterface 128 2 0
/*     */     //   50: astore 6
/*     */     //   52: new 220	clojure/core/VecSeq$fn__6793
/*     */     //   55: dup
/*     */     //   56: aload_0
/*     */     //   57: getfield 29	clojure/core/VecSeq:am	Ljava/lang/Object;
/*     */     //   60: aload_3
/*     */     //   61: aconst_null
/*     */     //   62: astore_3
/*     */     //   63: aload 6
/*     */     //   65: aconst_null
/*     */     //   66: astore 6
/*     */     //   68: aload_1
/*     */     //   69: lload 4
/*     */     //   71: invokespecial 223	clojure/core/VecSeq$fn__6793:<init>	(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;J)V
/*     */     //   74: checkcast 225	clojure/lang/IFn
/*     */     //   77: invokeinterface 228 1 0
/*     */     //   82: astore 7
/*     */     //   84: aload 7
/*     */     //   86: invokestatic 231	clojure/lang/RT:isReduced	(Ljava/lang/Object;)Z
/*     */     //   89: ifeq +15 -> 104
/*     */     //   92: aload 7
/*     */     //   94: aconst_null
/*     */     //   95: astore 7
/*     */     //   97: invokestatic 234	clojure/core$deref:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   100: goto +27 -> 127
/*     */     //   103: pop
/*     */     //   104: aload 7
/*     */     //   106: aconst_null
/*     */     //   107: astore 7
/*     */     //   109: ldc2_w 235
/*     */     //   112: lload 4
/*     */     //   114: ldc2_w 237
/*     */     //   117: invokestatic 115	clojure/lang/Numbers:add	(JJ)J
/*     */     //   120: land
/*     */     //   121: lstore 4
/*     */     //   123: astore_3
/*     */     //   124: goto -105 -> 19
/*     */     //   127: goto +7 -> 134
/*     */     //   130: pop
/*     */     //   131: aload_3
/*     */     //   132: aconst_null
/*     */     //   133: astore_3
/*     */     //   134: areturn
/*     */     // Line number table:
/*     */     //   Java source line #58	-> byte code offset #0
/*     */     //   Java source line #65	-> byte code offset #14
/*     */     //   Java source line #66	-> byte code offset #19
/*     */     //   Java source line #66	-> byte code offset #19
/*     */     //   Java source line #66	-> byte code offset #25
/*     */     //   Java source line #67	-> byte code offset #45
/*     */     //   Java source line #68	-> byte code offset #74
/*     */     //   Java source line #68	-> byte code offset #77
/*     */     //   Java source line #76	-> byte code offset #84
/*     */     //   Java source line #76	-> byte code offset #86
/*     */     //   Java source line #78	-> byte code offset #117
/*     */     //   Java source line #78	-> byte code offset #120
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	134	0	this	VecSeq
/*     */     //   0	134	1	f	Object
/*     */     //   0	134	2	val	Object
/*     */     //   4	130	3	result	Object
/*     */     //   19	115	4	aidx	long
/*     */     //   52	75	6	node	Object
/*     */     //   84	43	7	result	Object
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\core\VecSeq.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */