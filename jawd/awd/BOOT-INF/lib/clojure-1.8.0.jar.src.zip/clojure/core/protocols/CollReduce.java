package clojure.core.protocols;

public abstract interface CollReduce
{
  public abstract Object coll_reduce(Object paramObject);
  
  public abstract Object coll_reduce(Object paramObject1, Object paramObject2);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\core\protocols\CollReduce.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */