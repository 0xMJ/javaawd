/*    */ package clojure.core;
/*    */ 
/*    */ import clojure.core.protocols.InternalReduce;
/*    */ import clojure.lang.AFunction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class protocols$fn__6710$G__6706__6714
/*    */   extends AFunction
/*    */ {
/*    */   public Object invoke(Object gf__seq__6711, Object gf__f__6712, Object gf__start__6713)
/*    */   {
/* 19 */     gf__seq__6711 = null;gf__f__6712 = null;gf__start__6713 = null;return ((InternalReduce)gf__seq__6711).internal_reduce(gf__f__6712, gf__start__6713);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\core\protocols$fn__6710$G__6706__6714.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */