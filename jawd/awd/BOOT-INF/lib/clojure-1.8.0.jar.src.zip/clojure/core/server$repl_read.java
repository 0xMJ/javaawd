/*     */ package clojure.core;
/*     */ 
/*     */ import clojure.lang.AFn;
/*     */ import clojure.lang.AFunction;
/*     */ import clojure.lang.Keyword;
/*     */ import clojure.lang.RT;
/*     */ import clojure.lang.Var;
/*     */ 
/*     */ public final class server$repl_read
/*     */   extends AFunction
/*     */ {
/*     */   /* Error */
/*     */   public static Object invokeStatic(Object request_prompt, Object request_exit)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: iconst_4
/*     */     //   1: anewarray 13	java/lang/Object
/*     */     //   4: dup
/*     */     //   5: iconst_0
/*     */     //   6: getstatic 17	clojure/core/server$repl_read:const__0	Lclojure/lang/Keyword;
/*     */     //   9: aastore
/*     */     //   10: dup
/*     */     //   11: iconst_1
/*     */     //   12: aload_0
/*     */     //   13: aconst_null
/*     */     //   14: astore_0
/*     */     //   15: aastore
/*     */     //   16: dup
/*     */     //   17: iconst_2
/*     */     //   18: getstatic 20	clojure/core/server$repl_read:const__1	Lclojure/lang/Keyword;
/*     */     //   21: aastore
/*     */     //   22: dup
/*     */     //   23: iconst_3
/*     */     //   24: aload_1
/*     */     //   25: aastore
/*     */     //   26: invokestatic 26	clojure/lang/RT:mapUniqueKeys	([Ljava/lang/Object;)Lclojure/lang/IPersistentMap;
/*     */     //   29: checkcast 28	clojure/lang/IFn
/*     */     //   32: getstatic 32	clojure/core/server$repl_read:const__3	Lclojure/lang/Var;
/*     */     //   35: invokevirtual 38	clojure/lang/Var:get	()Ljava/lang/Object;
/*     */     //   38: invokestatic 43	clojure/main$skip_whitespace:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   41: invokeinterface 46 2 0
/*     */     //   46: astore_2
/*     */     //   47: aload_2
/*     */     //   48: dup
/*     */     //   49: ifnull +15 -> 64
/*     */     //   52: getstatic 52	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   55: if_acmpeq +10 -> 65
/*     */     //   58: aload_2
/*     */     //   59: aconst_null
/*     */     //   60: astore_2
/*     */     //   61: goto +72 -> 133
/*     */     //   64: pop
/*     */     //   65: getstatic 56	clojure/core/server$repl_read:const__7	Lclojure/lang/AFn;
/*     */     //   68: getstatic 32	clojure/core/server$repl_read:const__3	Lclojure/lang/Var;
/*     */     //   71: invokevirtual 38	clojure/lang/Var:get	()Ljava/lang/Object;
/*     */     //   74: invokestatic 60	clojure/core$read:invokeStatic	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   77: astore_3
/*     */     //   78: getstatic 32	clojure/core/server$repl_read:const__3	Lclojure/lang/Var;
/*     */     //   81: invokevirtual 38	clojure/lang/Var:get	()Ljava/lang/Object;
/*     */     //   84: invokestatic 63	clojure/main$skip_if_eol:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   87: pop
/*     */     //   88: aload_3
/*     */     //   89: astore 4
/*     */     //   91: aload 4
/*     */     //   93: invokestatic 69	clojure/lang/Util:hash	(Ljava/lang/Object;)I
/*     */     //   96: tableswitch	default:+34->130, 1244597485:+20->116
/*     */     //   116: aload 4
/*     */     //   118: getstatic 72	clojure/core/server$repl_read:const__9	Lclojure/lang/Keyword;
/*     */     //   121: if_acmpne +9 -> 130
/*     */     //   124: aload_1
/*     */     //   125: aconst_null
/*     */     //   126: astore_1
/*     */     //   127: goto +6 -> 133
/*     */     //   130: aload_3
/*     */     //   131: aconst_null
/*     */     //   132: astore_3
/*     */     //   133: areturn
/*     */     // Line number table:
/*     */     //   Java source line #166	-> byte code offset #0
/*     */     //   Java source line #169	-> byte code offset #29
/*     */     //   Java source line #169	-> byte code offset #41
/*     */     //   Java source line #169	-> byte code offset #47
/*     */     //   Java source line #173	-> byte code offset #91
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	133	0	request_prompt	Object
/*     */     //   0	133	1	request_exit	Object
/*     */     //   47	86	2	or__4469__auto__7377	Object
/*     */     //   78	55	3	input	Object
/*     */     //   91	42	4	G__7375	Object
/*     */   }
/*     */   
/*     */   public Object invoke(Object paramObject1, Object paramObject2)
/*     */   {
/* 166 */     paramObject1 = null;paramObject2 = null;return invokeStatic(paramObject1, paramObject2); } public static final Keyword const__9 = (Keyword)RT.keyword("repl", "quit"); public static final AFn const__7 = (AFn)RT.map(new Object[] { RT.keyword(null, "read-cond"), RT.keyword(null, "allow") }); public static final Var const__3 = (Var)RT.var("clojure.core", "*in*"); public static final Keyword const__1 = (Keyword)RT.keyword(null, "stream-end"); public static final Keyword const__0 = (Keyword)RT.keyword(null, "line-start");
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\core\server$repl_read.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */