/*    */ package clojure.core;
/*    */ 
/*    */ import clojure.lang.AFunction;
/*    */ 
/*    */ public final class protocols$interface_or_naive_reduce
/*    */   extends AFunction
/*    */ {
/*    */   /* Error */
/*    */   public static Object invokeStatic(Object coll, Object f, Object val)
/*    */   {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: instanceof 13
/*    */     //   4: ifeq +27 -> 31
/*    */     //   7: aload_0
/*    */     //   8: aconst_null
/*    */     //   9: astore_0
/*    */     //   10: checkcast 13	clojure/lang/IReduceInit
/*    */     //   13: aload_1
/*    */     //   14: aconst_null
/*    */     //   15: astore_1
/*    */     //   16: checkcast 15	clojure/lang/IFn
/*    */     //   19: aload_2
/*    */     //   20: aconst_null
/*    */     //   21: astore_2
/*    */     //   22: invokeinterface 19 3 0
/*    */     //   27: goto +16 -> 43
/*    */     //   30: pop
/*    */     //   31: aload_0
/*    */     //   32: aconst_null
/*    */     //   33: astore_0
/*    */     //   34: aload_1
/*    */     //   35: aconst_null
/*    */     //   36: astore_1
/*    */     //   37: aload_2
/*    */     //   38: aconst_null
/*    */     //   39: astore_2
/*    */     //   40: invokestatic 23	clojure/core/protocols$naive_seq_reduce:invokeStatic	(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   43: areturn
/*    */     // Line number table:
/*    */     //   Java source line #68	-> byte code offset #0
/*    */     //   Java source line #71	-> byte code offset #0
/*    */     //   Java source line #72	-> byte code offset #22
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	signature
/*    */     //   0	43	0	coll	Object
/*    */     //   0	43	1	f	Object
/*    */     //   0	43	2	val	Object
/*    */   }
/*    */   
/*    */   public Object invoke(Object paramObject1, Object paramObject2, Object paramObject3)
/*    */   {
/* 68 */     paramObject1 = null;paramObject2 = null;paramObject3 = null;return invokeStatic(paramObject1, paramObject2, paramObject3);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\core\protocols$interface_or_naive_reduce.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */