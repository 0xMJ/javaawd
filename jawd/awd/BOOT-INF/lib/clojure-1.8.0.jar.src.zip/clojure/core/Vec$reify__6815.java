/*     */ package clojure.core;
/*     */ 
/*     */ import clojure.lang.IObj;
/*     */ import clojure.lang.IPersistentMap;
/*     */ import clojure.lang.Numbers;
/*     */ import java.util.Iterator;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Vec$reify__6815
/*     */   implements Iterator, IObj
/*     */ {
/*     */   final IPersistentMap __meta;
/*     */   int cnt;
/*     */   Object i;
/*     */   Object jdField_this;
/*     */   
/*     */   public Vec$reify__6815(IPersistentMap paramIPersistentMap, int paramInt, Object paramObject1, Object paramObject2)
/*     */   {
/* 386 */     this.__meta = paramIPersistentMap;this.cnt = paramInt;this.i = paramObject1;this.jdField_this = paramObject2;
/*     */   }
/*     */   
/*     */   public Vec$reify__6815(int paramInt, Object paramObject1, Object paramObject2)
/*     */   {
/*     */     this(null, paramInt, paramObject1, paramObject2);
/*     */   }
/*     */   
/*     */   public IPersistentMap meta()
/*     */   {
/*     */     return this.__meta;
/*     */   }
/*     */   
/*     */   public IObj withMeta(IPersistentMap paramIPersistentMap)
/*     */   {
/*     */     return new reify__6815(paramIPersistentMap, this.cnt, this.i, this.jdField_this);
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public void remove()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: new 39	java/lang/UnsupportedOperationException
/*     */     //   3: dup
/*     */     //   4: invokespecial 40	java/lang/UnsupportedOperationException:<init>	()V
/*     */     //   7: checkcast 42	java/lang/Throwable
/*     */     //   10: athrow
/*     */     //   11: pop
/*     */     //   12: return
/*     */     // Line number table:
/*     */     //   Java source line #386	-> byte code offset #0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	12	0	this	reify__6815
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public Object next()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 29	clojure/core/Vec$reify__6815:this	Ljava/lang/Object;
/*     */     //   4: checkcast 47	clojure/lang/Indexed
/*     */     //   7: aload_0
/*     */     //   8: getfield 27	clojure/core/Vec$reify__6815:i	Ljava/lang/Object;
/*     */     //   11: checkcast 49	java/util/concurrent/atomic/AtomicInteger
/*     */     //   14: invokevirtual 53	java/util/concurrent/atomic/AtomicInteger:incrementAndGet	()I
/*     */     //   17: i2l
/*     */     //   18: invokestatic 59	clojure/lang/Numbers:dec	(J)J
/*     */     //   21: invokestatic 65	clojure/lang/RT:intCast	(J)I
/*     */     //   24: invokeinterface 69 2 0
/*     */     //   29: astore_1
/*     */     //   30: goto +19 -> 49
/*     */     //   33: astore_2
/*     */     //   34: new 71	java/util/NoSuchElementException
/*     */     //   37: dup
/*     */     //   38: invokespecial 72	java/util/NoSuchElementException:<init>	()V
/*     */     //   41: checkcast 42	java/lang/Throwable
/*     */     //   44: athrow
/*     */     //   45: astore_1
/*     */     //   46: goto +3 -> 49
/*     */     //   49: aload_1
/*     */     //   50: areturn
/*     */     // Line number table:
/*     */     //   Java source line #386	-> byte code offset #0
/*     */     //   Java source line #389	-> byte code offset #14
/*     */     //   Java source line #389	-> byte code offset #18
/*     */     //   Java source line #389	-> byte code offset #24
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	50	0	this	reify__6815
/*     */     //   33	13	2	_	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   0	30	33	java/lang/IndexOutOfBoundsException
/*     */   }
/*     */   
/*     */   public boolean hasNext()
/*     */   {
/* 387 */     return Numbers.lt(((AtomicInteger)this.i).get(), this.cnt);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\core\Vec$reify__6815.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */