package clojure.core;

public abstract interface ArrayManager
{
  public abstract Object array(int paramInt);
  
  public abstract int alength(Object paramObject);
  
  public abstract Object aclone(Object paramObject);
  
  public abstract Object aget(Object paramObject, int paramInt);
  
  public abstract Object aset(Object paramObject1, int paramInt, Object paramObject2);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\core\ArrayManager.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */