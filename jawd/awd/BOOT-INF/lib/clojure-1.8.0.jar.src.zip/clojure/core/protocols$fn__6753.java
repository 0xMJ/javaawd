/*     */ package clojure.core;
/*     */ 
/*     */ import clojure.lang.AFunction;
/*     */ 
/*     */ public final class protocols$fn__6753
/*     */   extends AFunction
/*     */ {
/*     */   /* Error */
/*     */   public static Object invokeStatic(Object str_seq, Object f, Object val)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: checkcast 13	clojure/lang/StringSeq
/*     */     //   4: getfield 17	clojure/lang/StringSeq:s	Ljava/lang/CharSequence;
/*     */     //   7: astore_3
/*     */     //   8: aload_0
/*     */     //   9: aconst_null
/*     */     //   10: astore_0
/*     */     //   11: checkcast 13	clojure/lang/StringSeq
/*     */     //   14: getfield 21	clojure/lang/StringSeq:i	I
/*     */     //   17: i2l
/*     */     //   18: lstore 4
/*     */     //   20: aload_2
/*     */     //   21: aconst_null
/*     */     //   22: astore_2
/*     */     //   23: astore 6
/*     */     //   25: lload 4
/*     */     //   27: aload_3
/*     */     //   28: checkcast 23	java/lang/CharSequence
/*     */     //   31: invokeinterface 27 1 0
/*     */     //   36: i2l
/*     */     //   37: lcmp
/*     */     //   38: ifge +77 -> 115
/*     */     //   41: aload_1
/*     */     //   42: checkcast 29	clojure/lang/IFn
/*     */     //   45: aload 6
/*     */     //   47: aconst_null
/*     */     //   48: astore 6
/*     */     //   50: aload_3
/*     */     //   51: checkcast 23	java/lang/CharSequence
/*     */     //   54: lload 4
/*     */     //   56: invokestatic 35	clojure/lang/RT:intCast	(J)I
/*     */     //   59: invokeinterface 39 2 0
/*     */     //   64: invokestatic 45	java/lang/Character:valueOf	(C)Ljava/lang/Character;
/*     */     //   67: invokeinterface 49 3 0
/*     */     //   72: astore 7
/*     */     //   74: aload 7
/*     */     //   76: invokestatic 53	clojure/lang/RT:isReduced	(Ljava/lang/Object;)Z
/*     */     //   79: ifeq +15 -> 94
/*     */     //   82: aload 7
/*     */     //   84: aconst_null
/*     */     //   85: astore 7
/*     */     //   87: invokestatic 58	clojure/core$deref:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   90: goto +21 -> 111
/*     */     //   93: pop
/*     */     //   94: lload 4
/*     */     //   96: invokestatic 64	clojure/lang/Numbers:inc	(J)J
/*     */     //   99: aload 7
/*     */     //   101: aconst_null
/*     */     //   102: astore 7
/*     */     //   104: astore 6
/*     */     //   106: lstore 4
/*     */     //   108: goto -83 -> 25
/*     */     //   111: goto +9 -> 120
/*     */     //   114: pop
/*     */     //   115: aload 6
/*     */     //   117: aconst_null
/*     */     //   118: astore 6
/*     */     //   120: areturn
/*     */     // Line number table:
/*     */     //   Java source line #124	-> byte code offset #0
/*     */     //   Java source line #148	-> byte code offset #1
/*     */     //   Java source line #149	-> byte code offset #11
/*     */     //   Java source line #0	-> byte code offset #17
/*     */     //   Java source line #151	-> byte code offset #25
/*     */     //   Java source line #151	-> byte code offset #25
/*     */     //   Java source line #151	-> byte code offset #31
/*     */     //   Java source line #152	-> byte code offset #42
/*     */     //   Java source line #152	-> byte code offset #59
/*     */     //   Java source line #152	-> byte code offset #67
/*     */     //   Java source line #153	-> byte code offset #74
/*     */     //   Java source line #153	-> byte code offset #76
/*     */     //   Java source line #155	-> byte code offset #96
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	120	0	str_seq	Object
/*     */     //   0	120	1	f	Object
/*     */     //   0	120	2	val	Object
/*     */     //   8	112	3	s	Object
/*     */     //   20	100	4	i	long
/*     */     //   25	95	6	val	Object
/*     */     //   74	37	7	ret	Object
/*     */   }
/*     */   
/*     */   public Object invoke(Object paramObject1, Object paramObject2, Object paramObject3)
/*     */   {
/* 124 */     paramObject1 = null;paramObject2 = null;paramObject3 = null;return invokeStatic(paramObject1, paramObject2, paramObject3);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\core\protocols$fn__6753.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */