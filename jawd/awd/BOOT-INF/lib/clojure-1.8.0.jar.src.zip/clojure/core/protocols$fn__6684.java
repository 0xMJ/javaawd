/*    */ package clojure.core;
/*    */ 
/*    */ import clojure.lang.AFunction;
/*    */ import clojure.lang.MethodImplCache;
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class protocols$fn__6684
/*    */   extends AFunction
/*    */ {
/*    */   public Object invoke(Object paramObject)
/*    */   {
/* 13 */     paramObject = null;return invokeStatic(paramObject); } public static Object invokeStatic(Object cache__6570__auto__) { Object G__6680 = new protocols.fn__6684.G__6680__6690();G__6680 = null;Object f__6571__auto__6704 = new protocols.fn__6684.G__6679__6697(G__6680);cache__6570__auto__ = null;((AFunction)f__6571__auto__6704).__methodImplCache = ((MethodImplCache)cache__6570__auto__);cache__6570__auto__;f__6571__auto__6704 = null;return f__6571__auto__6704;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\core\protocols$fn__6684.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */