/*    */ package clojure.core;
/*    */ 
/*    */ import clojure.lang.IChunk;
/*    */ import clojure.lang.IObj;
/*    */ import clojure.lang.IPersistentMap;
/*    */ import clojure.lang.IPersistentVector;
/*    */ import clojure.lang.IType;
/*    */ import clojure.lang.Indexed;
/*    */ import clojure.lang.Numbers;
/*    */ import clojure.lang.RT;
/*    */ import clojure.lang.Symbol;
/*    */ import clojure.lang.Tuple;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ArrayChunk
/*    */   implements IChunk, Indexed, IType
/*    */ {
/*    */   public final Object am;
/*    */   public final Object arr;
/*    */   public final int off;
/*    */   public final int end;
/*    */   
/*    */   public ArrayChunk(Object paramObject1, Object paramObject2, int paramInt1, int paramInt2)
/*    */   {
/* 36 */     this.am = paramObject1;this.arr = paramObject2;this.off = paramInt1;this.end = paramInt2;
/*    */   }
/*    */   
/* 39 */   public Object nth(int i) { return ((ArrayManager)this.am).aget(this.arr, RT.intCast(Numbers.add(this.off, i))); }
/*    */   
/* 41 */   public int count() { return RT.intCast(Numbers.minus(this.end, this.off)); }
/*    */   
/*    */   public static IPersistentVector getBasis()
/*    */   {
/*    */     return Tuple.create(((IObj)Symbol.intern(null, "am")).withMeta((IPersistentMap)RT.map(new Object[] { RT.keyword(null, "tag"), Symbol.intern(null, "clojure.core.ArrayManager") })), Symbol.intern(null, "arr"), ((IObj)Symbol.intern(null, "off")).withMeta((IPersistentMap)RT.map(new Object[] { RT.keyword(null, "tag"), Symbol.intern(null, "int") })), ((IObj)Symbol.intern(null, "end")).withMeta((IPersistentMap)RT.map(new Object[] { RT.keyword(null, "tag"), Symbol.intern(null, "int") })));
/*    */   }
/*    */   
/*    */   /* Error */
/*    */   public Object reduce(clojure.lang.IFn f, Object init)
/*    */   {
/*    */     // Byte code:
/*    */     //   0: aload_2
/*    */     //   1: aconst_null
/*    */     //   2: astore_2
/*    */     //   3: astore_3
/*    */     //   4: aload_0
/*    */     //   5: getfield 28	clojure/core/ArrayChunk:off	I
/*    */     //   8: i2l
/*    */     //   9: lstore 4
/*    */     //   11: lload 4
/*    */     //   13: aload_0
/*    */     //   14: getfield 30	clojure/core/ArrayChunk:end	I
/*    */     //   17: i2l
/*    */     //   18: lcmp
/*    */     //   19: ifge +75 -> 94
/*    */     //   22: aload_1
/*    */     //   23: checkcast 76	clojure/lang/IFn
/*    */     //   26: aload_3
/*    */     //   27: aconst_null
/*    */     //   28: astore_3
/*    */     //   29: aload_0
/*    */     //   30: getfield 24	clojure/core/ArrayChunk:am	Ljava/lang/Object;
/*    */     //   33: checkcast 78	clojure/core/ArrayManager
/*    */     //   36: aload_0
/*    */     //   37: getfield 26	clojure/core/ArrayChunk:arr	Ljava/lang/Object;
/*    */     //   40: lload 4
/*    */     //   42: invokestatic 82	clojure/lang/RT:intCast	(J)I
/*    */     //   45: invokeinterface 86 3 0
/*    */     //   50: invokeinterface 90 3 0
/*    */     //   55: astore 6
/*    */     //   57: aload 6
/*    */     //   59: invokestatic 94	clojure/lang/RT:isReduced	(Ljava/lang/Object;)Z
/*    */     //   62: ifeq +12 -> 74
/*    */     //   65: aload 6
/*    */     //   67: aconst_null
/*    */     //   68: astore 6
/*    */     //   70: goto +20 -> 90
/*    */     //   73: pop
/*    */     //   74: aload 6
/*    */     //   76: aconst_null
/*    */     //   77: astore 6
/*    */     //   79: lload 4
/*    */     //   81: invokestatic 100	clojure/lang/Numbers:inc	(J)J
/*    */     //   84: lstore 4
/*    */     //   86: astore_3
/*    */     //   87: goto -76 -> 11
/*    */     //   90: goto +7 -> 97
/*    */     //   93: pop
/*    */     //   94: aload_3
/*    */     //   95: aconst_null
/*    */     //   96: astore_3
/*    */     //   97: areturn
/*    */     // Line number table:
/*    */     //   Java source line #36	-> byte code offset #0
/*    */     //   Java source line #0	-> byte code offset #8
/*    */     //   Java source line #51	-> byte code offset #11
/*    */     //   Java source line #51	-> byte code offset #11
/*    */     //   Java source line #52	-> byte code offset #23
/*    */     //   Java source line #52	-> byte code offset #45
/*    */     //   Java source line #52	-> byte code offset #50
/*    */     //   Java source line #53	-> byte code offset #57
/*    */     //   Java source line #53	-> byte code offset #59
/*    */     //   Java source line #55	-> byte code offset #81
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	signature
/*    */     //   0	97	0	this	ArrayChunk
/*    */     //   0	97	1	f	clojure.lang.IFn
/*    */     //   0	97	2	init	Object
/*    */     //   4	93	3	ret	Object
/*    */     //   11	86	4	i	long
/*    */     //   57	33	6	ret	Object
/*    */   }
/*    */   
/*    */   /* Error */
/*    */   public IChunk dropFirst()
/*    */   {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: getfield 28	clojure/core/ArrayChunk:off	I
/*    */     //   4: i2l
/*    */     //   5: aload_0
/*    */     //   6: getfield 30	clojure/core/ArrayChunk:end	I
/*    */     //   9: i2l
/*    */     //   10: lcmp
/*    */     //   11: ifne +23 -> 34
/*    */     //   14: new 112	java/lang/IllegalStateException
/*    */     //   17: dup
/*    */     //   18: ldc 114
/*    */     //   20: checkcast 116	java/lang/String
/*    */     //   23: invokespecial 119	java/lang/IllegalStateException:<init>	(Ljava/lang/String;)V
/*    */     //   26: checkcast 121	java/lang/Throwable
/*    */     //   29: athrow
/*    */     //   30: goto +34 -> 64
/*    */     //   33: pop
/*    */     //   34: new 2	clojure/core/ArrayChunk
/*    */     //   37: dup
/*    */     //   38: aload_0
/*    */     //   39: getfield 24	clojure/core/ArrayChunk:am	Ljava/lang/Object;
/*    */     //   42: aload_0
/*    */     //   43: getfield 26	clojure/core/ArrayChunk:arr	Ljava/lang/Object;
/*    */     //   46: aload_0
/*    */     //   47: getfield 28	clojure/core/ArrayChunk:off	I
/*    */     //   50: i2l
/*    */     //   51: invokestatic 100	clojure/lang/Numbers:inc	(J)J
/*    */     //   54: invokestatic 82	clojure/lang/RT:intCast	(J)I
/*    */     //   57: aload_0
/*    */     //   58: getfield 30	clojure/core/ArrayChunk:end	I
/*    */     //   61: invokespecial 123	clojure/core/ArrayChunk:<init>	(Ljava/lang/Object;Ljava/lang/Object;II)V
/*    */     //   64: checkcast 6	clojure/lang/IChunk
/*    */     //   67: areturn
/*    */     // Line number table:
/*    */     //   Java source line #36	-> byte code offset #0
/*    */     //   Java source line #45	-> byte code offset #0
/*    */     //   Java source line #45	-> byte code offset #0
/*    */     //   Java source line #47	-> byte code offset #51
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	signature
/*    */     //   0	67	0	this	ArrayChunk
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\core\ArrayChunk.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */