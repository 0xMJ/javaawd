/*    */ package clojure.core;
/*    */ 
/*    */ import clojure.lang.AFunction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class protocols$fn__6736
/*    */   extends AFunction
/*    */ {
/*    */   public Object invoke(Object paramObject1, Object paramObject2)
/*    */   {
/* 75 */     paramObject1 = null;paramObject2 = null;return invokeStatic(paramObject1, paramObject2); } public static Object invokeStatic(Object coll, Object f) { coll = null;f = null;return protocols.seq_reduce.invokeStatic(coll, f); } public Object invoke(Object paramObject1, Object paramObject2, Object paramObject3) { paramObject1 = null;paramObject2 = null;paramObject3 = null;return invokeStatic(paramObject1, paramObject2, paramObject3); } public static Object invokeStatic(Object coll, Object f, Object val) { coll = null;f = null;val = null;return protocols.seq_reduce.invokeStatic(coll, f, val);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\core\protocols$fn__6736.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */