/*    */ package clojure.core;
/*    */ 
/*    */ import clojure.lang.IPersistentVector;
/*    */ import clojure.lang.IType;
/*    */ import clojure.lang.Symbol;
/*    */ import clojure.lang.Tuple;
/*    */ 
/*    */ 
/*    */ public final class VecNode
/*    */   implements IType
/*    */ {
/*    */   public final Object edit;
/*    */   public final Object arr;
/*    */   
/*    */   public VecNode(Object paramObject1, Object paramObject2)
/*    */   {
/* 17 */     this.edit = paramObject1;this.arr = paramObject2;
/*    */   }
/*    */   
/*    */   public static IPersistentVector getBasis()
/*    */   {
/*    */     return Tuple.create(Symbol.intern(null, "edit"), Symbol.intern(null, "arr"));
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\core\VecNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */