/*   */ package clojure.core;
/*   */ 
/*   */ import clojure.lang.RT;
/*   */ 
/*   */ 
/*   */ public final class server$fn__7298
/*   */   extends clojure.lang.AFunction
/*   */ {
/* 9 */   public Object invoke() { return invokeStatic(); } public static Object invokeStatic() { return clojure.core.commute.invokeStatic(clojure.core.deref.invokeStatic(const__2), const__3.getRawRoot(), clojure.lang.ArraySeq.create(new Object[] { const__4 })); } public static final clojure.lang.AFn const__4 = (clojure.lang.AFn)((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "clojure.core.server")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "doc"), "Socket server support", RT.keyword(null, "author"), "Alex Miller" })); public static final clojure.lang.Var const__3 = (clojure.lang.Var)RT.var("clojure.core", "conj"); public static final clojure.lang.Var const__2 = (clojure.lang.Var)RT.var("clojure.core", "*loaded-libs*");
/*   */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\core\server$fn__7298.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */