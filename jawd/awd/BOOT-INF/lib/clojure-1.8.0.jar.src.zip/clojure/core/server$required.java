/*    */ package clojure.core;
/*    */ 
/*    */ import clojure.lang.AFunction;
/*    */ 
/*    */ public final class server$required
/*    */   extends AFunction
/*    */ {
/*    */   /* Error */
/*    */   public static Object invokeStatic(Object opts, Object prop)
/*    */   {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: aload_1
/*    */     //   2: invokestatic 16	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   5: aconst_null
/*    */     //   6: invokestatic 22	clojure/lang/Util:identical	(Ljava/lang/Object;Ljava/lang/Object;)Z
/*    */     //   9: ifeq +35 -> 44
/*    */     //   12: ldc 24
/*    */     //   14: iconst_1
/*    */     //   15: anewarray 26	java/lang/Object
/*    */     //   18: dup
/*    */     //   19: iconst_0
/*    */     //   20: aload_1
/*    */     //   21: aconst_null
/*    */     //   22: astore_1
/*    */     //   23: aastore
/*    */     //   24: invokestatic 32	clojure/lang/ArraySeq:create	([Ljava/lang/Object;)Lclojure/lang/ArraySeq;
/*    */     //   27: invokestatic 37	clojure/core$str:invokeStatic	(Ljava/lang/Object;Lclojure/lang/ISeq;)Ljava/lang/Object;
/*    */     //   30: aload_0
/*    */     //   31: aconst_null
/*    */     //   32: astore_0
/*    */     //   33: invokestatic 41	clojure/core$ex_info:invokeStatic	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   36: checkcast 43	java/lang/Throwable
/*    */     //   39: athrow
/*    */     //   40: goto +5 -> 45
/*    */     //   43: pop
/*    */     //   44: aconst_null
/*    */     //   45: areturn
/*    */     // Line number table:
/*    */     //   Java source line #41	-> byte code offset #0
/*    */     //   Java source line #44	-> byte code offset #0
/*    */     //   Java source line #44	-> byte code offset #2
/*    */     //   Java source line #44	-> byte code offset #6
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	signature
/*    */     //   0	45	0	opts	Object
/*    */     //   0	45	1	prop	Object
/*    */   }
/*    */   
/*    */   public Object invoke(Object paramObject1, Object paramObject2)
/*    */   {
/* 41 */     paramObject1 = null;paramObject2 = null;return invokeStatic(paramObject1, paramObject2);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\core\server$required.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */