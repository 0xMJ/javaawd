/*     */ package clojure.core;
/*     */ 
/*     */ import clojure.lang.AFunction;
/*     */ 
/*     */ public final class protocols$fn__6755
/*     */   extends AFunction
/*     */ {
/*     */   /* Error */
/*     */   public static Object invokeStatic(Object s, Object f, Object val)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: invokestatic 16	clojure/core$class:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   4: astore_3
/*     */     //   5: aload_0
/*     */     //   6: aconst_null
/*     */     //   7: astore_0
/*     */     //   8: astore 4
/*     */     //   10: aload_1
/*     */     //   11: aconst_null
/*     */     //   12: astore_1
/*     */     //   13: astore 5
/*     */     //   15: aload_2
/*     */     //   16: aconst_null
/*     */     //   17: astore_2
/*     */     //   18: astore 6
/*     */     //   20: aload 4
/*     */     //   22: aconst_null
/*     */     //   23: astore 4
/*     */     //   25: invokestatic 19	clojure/core$seq__4357:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   28: astore 7
/*     */     //   30: aload 7
/*     */     //   32: dup
/*     */     //   33: ifnull +126 -> 159
/*     */     //   36: getstatic 25	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   39: if_acmpeq +121 -> 160
/*     */     //   42: aload 7
/*     */     //   44: aconst_null
/*     */     //   45: astore 7
/*     */     //   47: astore 8
/*     */     //   49: aload 8
/*     */     //   51: invokestatic 16	clojure/core$class:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   54: aload_3
/*     */     //   55: invokestatic 31	clojure/lang/Util:identical	(Ljava/lang/Object;Ljava/lang/Object;)Z
/*     */     //   58: ifeq +80 -> 138
/*     */     //   61: aload 5
/*     */     //   63: checkcast 33	clojure/lang/IFn
/*     */     //   66: aload 6
/*     */     //   68: aconst_null
/*     */     //   69: astore 6
/*     */     //   71: aload 8
/*     */     //   73: invokestatic 36	clojure/core$first__4339:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   76: invokeinterface 40 3 0
/*     */     //   81: astore 9
/*     */     //   83: aload 9
/*     */     //   85: invokestatic 46	clojure/lang/RT:isReduced	(Ljava/lang/Object;)Z
/*     */     //   88: ifeq +15 -> 103
/*     */     //   91: aload 9
/*     */     //   93: aconst_null
/*     */     //   94: astore 9
/*     */     //   96: invokestatic 49	clojure/core$deref:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   99: goto +35 -> 134
/*     */     //   102: pop
/*     */     //   103: aload_3
/*     */     //   104: aconst_null
/*     */     //   105: astore_3
/*     */     //   106: aload 8
/*     */     //   108: aconst_null
/*     */     //   109: astore 8
/*     */     //   111: invokestatic 52	clojure/core$next__4341:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   114: aload 5
/*     */     //   116: aconst_null
/*     */     //   117: astore 5
/*     */     //   119: aload 9
/*     */     //   121: aconst_null
/*     */     //   122: astore 9
/*     */     //   124: astore 6
/*     */     //   126: astore 5
/*     */     //   128: astore 4
/*     */     //   130: astore_3
/*     */     //   131: goto -111 -> 20
/*     */     //   134: goto +22 -> 156
/*     */     //   137: pop
/*     */     //   138: aload 8
/*     */     //   140: aconst_null
/*     */     //   141: astore 8
/*     */     //   143: aload 5
/*     */     //   145: aconst_null
/*     */     //   146: astore 5
/*     */     //   148: aload 6
/*     */     //   150: aconst_null
/*     */     //   151: astore 6
/*     */     //   153: invokestatic 58	clojure/core/protocols$interface_or_naive_reduce:invokeStatic	(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   156: goto +9 -> 165
/*     */     //   159: pop
/*     */     //   160: aload 6
/*     */     //   162: aconst_null
/*     */     //   163: astore 6
/*     */     //   165: areturn
/*     */     // Line number table:
/*     */     //   Java source line #124	-> byte code offset #0
/*     */     //   Java source line #165	-> byte code offset #30
/*     */     //   Java source line #166	-> byte code offset #49
/*     */     //   Java source line #166	-> byte code offset #55
/*     */     //   Java source line #167	-> byte code offset #63
/*     */     //   Java source line #167	-> byte code offset #76
/*     */     //   Java source line #168	-> byte code offset #83
/*     */     //   Java source line #168	-> byte code offset #85
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	165	0	s	Object
/*     */     //   0	165	1	f	Object
/*     */     //   0	165	2	val	Object
/*     */     //   5	160	3	cls	Object
/*     */     //   10	155	4	s	Object
/*     */     //   15	150	5	f	Object
/*     */     //   20	145	6	val	Object
/*     */     //   30	135	7	temp__4655__auto__6757	Object
/*     */     //   49	107	8	s	Object
/*     */     //   83	51	9	ret	Object
/*     */   }
/*     */   
/*     */   public Object invoke(Object paramObject1, Object paramObject2, Object paramObject3)
/*     */   {
/* 124 */     paramObject1 = null;paramObject2 = null;paramObject3 = null;return invokeStatic(paramObject1, paramObject2, paramObject3);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\core\protocols$fn__6755.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */