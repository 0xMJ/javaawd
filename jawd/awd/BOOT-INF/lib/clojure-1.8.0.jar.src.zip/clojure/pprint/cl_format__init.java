/*      */ package clojure.pprint;
/*      */ 
/*      */ import clojure.lang.RT;
/*      */ 
/*      */ public class cl_format__init { public static final clojure.lang.Var const__0;
/*      */   public static final clojure.lang.AFn const__1;
/*      */   public static final clojure.lang.Var const__2;
/*      */   public static final clojure.lang.AFn const__9;
/*      */   public static final clojure.lang.Var const__10;
/*      */   public static final clojure.lang.AFn const__12;
/*      */   public static final clojure.lang.Var const__13;
/*      */   public static final clojure.lang.AFn const__15;
/*      */   public static final clojure.lang.Var const__16;
/*      */   public static final clojure.lang.AFn const__26;
/*      */   public static final clojure.lang.Var const__27;
/*      */   public static final clojure.lang.AFn const__31;
/*      */   public static final clojure.lang.Var const__32;
/*      */   
/*   19 */   public static void load() { const__2.setMeta((clojure.lang.IPersistentMap)const__9);const__10.setMeta((clojure.lang.IPersistentMap)const__12);const__13.setMeta((clojure.lang.IPersistentMap)const__15); clojure.lang.Var tmp59_56 = const__16;tmp59_56.setMeta((clojure.lang.IPersistentMap)const__26);tmp59_56.bindRoot(new clojure.pprint.cl_format()); clojure.lang.Var tmp87_84 = const__27.setDynamic(true);tmp87_84.setMeta((clojure.lang.IPersistentMap)const__31);tmp87_84.bindRoot(null); clojure.lang.Var tmp105_102 = const__32;tmp105_102.setMeta((clojure.lang.IPersistentMap)const__35);tmp105_102.bindRoot(new clojure.pprint.format_error()); clojure.lang.Var tmp129_126 = const__36;tmp129_126.setMeta((clojure.lang.IPersistentMap)const__38);tmp129_126
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   79 */       .bindRoot(((clojure.lang.IFn)const__39.getRawRoot()).invoke(const__40, const__41, const__42)); clojure.lang.Var tmp169_166 = const__13;tmp169_166.setMeta((clojure.lang.IPersistentMap)const__46);tmp169_166.bindRoot(new clojure.pprint.init_navigator()); clojure.lang.Var tmp193_190 = const__47;tmp193_190.setMeta((clojure.lang.IPersistentMap)const__50);tmp193_190.bindRoot(new clojure.pprint.next_arg()); clojure.lang.Var tmp217_214 = const__51;tmp217_214.setMeta((clojure.lang.IPersistentMap)const__54);tmp217_214.bindRoot(new clojure.pprint.next_arg_or_nil()); clojure.lang.Var tmp241_238 = const__55;tmp241_238.setMeta((clojure.lang.IPersistentMap)const__58);tmp241_238.bindRoot(new clojure.pprint.get_format_arg());const__59.setMeta((clojure.lang.IPersistentMap)const__61); clojure.lang.Var tmp278_275 = const__62;tmp278_275.setMeta((clojure.lang.IPersistentMap)const__65);tmp278_275.bindRoot(new clojure.pprint.absolute_reposition()); clojure.lang.Var tmp302_299 = const__59;tmp302_299.setMeta((clojure.lang.IPersistentMap)const__68);tmp302_299.bindRoot(new clojure.pprint.relative_reposition()); clojure.lang.Var tmp326_323 = const__69;tmp326_323.setMeta((clojure.lang.IPersistentMap)const__71);tmp326_323
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  123 */       .bindRoot(((clojure.lang.IFn)const__39.getRawRoot()).invoke(const__72, const__73, const__74, const__75)); clojure.lang.Var tmp369_366 = const__76;tmp369_366.setMeta((clojure.lang.IPersistentMap)const__79);tmp369_366.bindRoot(new clojure.pprint.realize_parameter()); clojure.lang.Var tmp393_390 = const__80;tmp393_390.setMeta((clojure.lang.IPersistentMap)const__83);tmp393_390.bindRoot(new clojure.pprint.realize_parameter_list());const__84.setMeta((clojure.lang.IPersistentMap)const__86); clojure.lang.Var tmp430_427 = const__87;tmp430_427.setMeta((clojure.lang.IPersistentMap)const__89);tmp430_427.bindRoot(const__93); clojure.lang.Var tmp450_447 = const__94;tmp450_447.setMeta((clojure.lang.IPersistentMap)const__97);tmp450_447.bindRoot(new clojure.pprint.format_simple_number()); clojure.lang.Var tmp474_471 = const__98;tmp474_471.setMeta((clojure.lang.IPersistentMap)const__101);tmp474_471.bindRoot(new clojure.pprint.format_ascii()); clojure.lang.Var tmp498_495 = const__102;tmp498_495.setMeta((clojure.lang.IPersistentMap)const__105);tmp498_495.bindRoot(new clojure.pprint.integral_QMARK_()); clojure.lang.Var tmp522_519 = const__106;tmp522_519.setMeta((clojure.lang.IPersistentMap)const__109);tmp522_519.bindRoot(new clojure.pprint.remainders()); clojure.lang.Var tmp546_543 = const__110;tmp546_543.setMeta((clojure.lang.IPersistentMap)const__113);tmp546_543.bindRoot(new clojure.pprint.base_str()); clojure.lang.Var tmp570_567 = const__114;tmp570_567.setMeta((clojure.lang.IPersistentMap)const__116);tmp570_567.bindRoot(const__118); clojure.lang.Var tmp590_587 = const__84;tmp590_587.setMeta((clojure.lang.IPersistentMap)const__121);tmp590_587.bindRoot(new clojure.pprint.opt_base_str()); clojure.lang.Var tmp614_611 = const__122;tmp614_611.setMeta((clojure.lang.IPersistentMap)const__125);tmp614_611.bindRoot(new clojure.pprint.group_by_STAR_()); clojure.lang.Var tmp638_635 = const__126;tmp638_635.setMeta((clojure.lang.IPersistentMap)const__129);tmp638_635.bindRoot(new clojure.pprint.format_integer()); clojure.lang.Var tmp662_659 = const__130;tmp662_659.setMeta((clojure.lang.IPersistentMap)const__132);tmp662_659.bindRoot(const__133); clojure.lang.Var tmp682_679 = const__134;tmp682_679.setMeta((clojure.lang.IPersistentMap)const__136);tmp682_679.bindRoot(const__137); clojure.lang.Var tmp702_699 = const__138;tmp702_699.setMeta((clojure.lang.IPersistentMap)const__140);tmp702_699.bindRoot(const__141); clojure.lang.Var tmp722_719 = const__142;tmp722_719.setMeta((clojure.lang.IPersistentMap)const__144);tmp722_719.bindRoot(const__145); clojure.lang.Var tmp742_739 = const__146;tmp742_739.setMeta((clojure.lang.IPersistentMap)const__148);tmp742_739.bindRoot(const__149); clojure.lang.Var tmp762_759 = const__150;tmp762_759.setMeta((clojure.lang.IPersistentMap)const__153);tmp762_759.bindRoot(new clojure.pprint.format_simple_cardinal()); clojure.lang.Var tmp786_783 = const__154;tmp786_783.setMeta((clojure.lang.IPersistentMap)const__157);tmp786_783.bindRoot(new clojure.pprint.add_english_scales()); clojure.lang.Var tmp810_807 = const__158;tmp810_807.setMeta((clojure.lang.IPersistentMap)const__161);tmp810_807.bindRoot(new clojure.pprint.format_cardinal_english()); clojure.lang.Var tmp834_831 = const__162;tmp834_831.setMeta((clojure.lang.IPersistentMap)const__165);tmp834_831.bindRoot(new clojure.pprint.format_simple_ordinal()); clojure.lang.Var tmp858_855 = const__166;tmp858_855.setMeta((clojure.lang.IPersistentMap)const__169);tmp858_855.bindRoot(new clojure.pprint.format_ordinal_english()); clojure.lang.Var tmp882_879 = const__170;tmp882_879.setMeta((clojure.lang.IPersistentMap)const__172);tmp882_879.bindRoot(const__177); clojure.lang.Var tmp902_899 = const__178;tmp902_899.setMeta((clojure.lang.IPersistentMap)const__180);tmp902_899.bindRoot(const__185); clojure.lang.Var tmp922_919 = const__186;tmp922_919.setMeta((clojure.lang.IPersistentMap)const__189);tmp922_919.bindRoot(new clojure.pprint.format_roman()); clojure.lang.Var tmp946_943 = const__190;tmp946_943.setMeta((clojure.lang.IPersistentMap)const__193);tmp946_943.bindRoot(new clojure.pprint.format_old_roman()); clojure.lang.Var tmp970_967 = const__194;tmp970_967.setMeta((clojure.lang.IPersistentMap)const__197);tmp970_967.bindRoot(new clojure.pprint.format_new_roman()); clojure.lang.Var tmp994_991 = const__198;tmp994_991.setMeta((clojure.lang.IPersistentMap)const__200);tmp994_991.bindRoot(const__204); clojure.lang.Var tmp1014_1011 = const__205;tmp1014_1011.setMeta((clojure.lang.IPersistentMap)const__208);tmp1014_1011.bindRoot(new clojure.pprint.pretty_character()); clojure.lang.Var tmp1038_1035 = const__209;tmp1038_1035.setMeta((clojure.lang.IPersistentMap)const__212);tmp1038_1035.bindRoot(new clojure.pprint.readable_character()); clojure.lang.Var tmp1062_1059 = const__213;tmp1062_1059.setMeta((clojure.lang.IPersistentMap)const__216);tmp1062_1059.bindRoot(new clojure.pprint.plain_character()); clojure.lang.Var tmp1086_1083 = const__217;tmp1086_1083.setMeta((clojure.lang.IPersistentMap)const__220);tmp1086_1083.bindRoot(new clojure.pprint.abort_QMARK_()); clojure.lang.Var tmp1110_1107 = const__221;tmp1110_1107.setMeta((clojure.lang.IPersistentMap)const__224);tmp1110_1107.bindRoot(new clojure.pprint.execute_sub_format()); clojure.lang.Var tmp1134_1131 = const__225;tmp1134_1131.setMeta((clojure.lang.IPersistentMap)const__228);tmp1134_1131.bindRoot(new clojure.pprint.float_parts_base()); clojure.lang.Var tmp1158_1155 = const__229;tmp1158_1155.setMeta((clojure.lang.IPersistentMap)const__232);tmp1158_1155.bindRoot(new clojure.pprint.float_parts()); clojure.lang.Var tmp1182_1179 = const__233;tmp1182_1179.setMeta((clojure.lang.IPersistentMap)const__238);tmp1182_1179.bindRoot(new clojure.pprint.inc_s()); clojure.lang.Var tmp1206_1203 = const__239;tmp1206_1203.setMeta((clojure.lang.IPersistentMap)const__242);tmp1206_1203.bindRoot(new clojure.pprint.round_str()); clojure.lang.Var tmp1230_1227 = const__243;tmp1230_1227.setMeta((clojure.lang.IPersistentMap)const__246);tmp1230_1227.bindRoot(new clojure.pprint.expand_fixed()); clojure.lang.Var tmp1254_1251 = const__247;tmp1254_1251.setMeta((clojure.lang.IPersistentMap)const__250);tmp1254_1251.bindRoot(new clojure.pprint.insert_decimal()); clojure.lang.Var tmp1278_1275 = const__251;tmp1278_1275.setMeta((clojure.lang.IPersistentMap)const__254);tmp1278_1275.bindRoot(new clojure.pprint.get_fixed()); clojure.lang.Var tmp1302_1299 = const__255;tmp1302_1299.setMeta((clojure.lang.IPersistentMap)const__258);tmp1302_1299.bindRoot(new clojure.pprint.insert_scaled_decimal()); clojure.lang.Var tmp1326_1323 = const__259;tmp1326_1323.setMeta((clojure.lang.IPersistentMap)const__262);tmp1326_1323.bindRoot(new clojure.pprint.convert_ratio()); clojure.lang.Var tmp1350_1347 = const__263;tmp1350_1347.setMeta((clojure.lang.IPersistentMap)const__266);tmp1350_1347.bindRoot(new clojure.pprint.fixed_float()); clojure.lang.Var tmp1374_1371 = const__267;tmp1374_1371.setMeta((clojure.lang.IPersistentMap)const__270);tmp1374_1371.bindRoot(new clojure.pprint.exponential_float()); clojure.lang.Var tmp1398_1395 = const__271;tmp1398_1395.setMeta((clojure.lang.IPersistentMap)const__274);tmp1398_1395.bindRoot(new clojure.pprint.general_float()); clojure.lang.Var tmp1422_1419 = const__275;tmp1422_1419.setMeta((clojure.lang.IPersistentMap)const__278);tmp1422_1419.bindRoot(new clojure.pprint.dollar_float()); clojure.lang.Var tmp1446_1443 = const__279;tmp1446_1443.setMeta((clojure.lang.IPersistentMap)const__282);tmp1446_1443.bindRoot(new clojure.pprint.choice_conditional()); clojure.lang.Var tmp1470_1467 = const__283;tmp1470_1467.setMeta((clojure.lang.IPersistentMap)const__286);tmp1470_1467.bindRoot(new clojure.pprint.boolean_conditional()); clojure.lang.Var tmp1494_1491 = const__287;tmp1494_1491.setMeta((clojure.lang.IPersistentMap)const__290);tmp1494_1491.bindRoot(new clojure.pprint.check_arg_conditional()); clojure.lang.Var tmp1518_1515 = const__291;tmp1518_1515.setMeta((clojure.lang.IPersistentMap)const__294);tmp1518_1515.bindRoot(new clojure.pprint.iterate_sublist()); clojure.lang.Var tmp1542_1539 = const__295;tmp1542_1539.setMeta((clojure.lang.IPersistentMap)const__298);tmp1542_1539.bindRoot(new clojure.pprint.iterate_list_of_sublists()); clojure.lang.Var tmp1566_1563 = const__299;tmp1566_1563.setMeta((clojure.lang.IPersistentMap)const__302);tmp1566_1563.bindRoot(new clojure.pprint.iterate_main_list()); clojure.lang.Var tmp1590_1587 = const__303;tmp1590_1587.setMeta((clojure.lang.IPersistentMap)const__306);tmp1590_1587.bindRoot(new clojure.pprint.iterate_main_sublists());const__307.setMeta((clojure.lang.IPersistentMap)const__309);const__310.setMeta((clojure.lang.IPersistentMap)const__312); clojure.lang.Var tmp1640_1637 = const__313;tmp1640_1637.setMeta((clojure.lang.IPersistentMap)const__316);tmp1640_1637.bindRoot(new clojure.pprint.logical_block_or_justify()); clojure.lang.Var tmp1664_1661 = const__317;tmp1664_1661.setMeta((clojure.lang.IPersistentMap)const__320);tmp1664_1661.bindRoot(new clojure.pprint.render_clauses()); clojure.lang.Var tmp1688_1685 = const__310;tmp1688_1685.setMeta((clojure.lang.IPersistentMap)const__323);tmp1688_1685.bindRoot(new clojure.pprint.justify_clauses()); clojure.lang.Var tmp1712_1709 = const__324;tmp1712_1709.setMeta((clojure.lang.IPersistentMap)const__327);tmp1712_1709.bindRoot(new clojure.pprint.downcase_writer()); clojure.lang.Var tmp1736_1733 = const__328;tmp1736_1733.setMeta((clojure.lang.IPersistentMap)const__331);tmp1736_1733.bindRoot(new clojure.pprint.upcase_writer()); clojure.lang.Var tmp1760_1757 = const__332;tmp1760_1757.setMeta((clojure.lang.IPersistentMap)const__335);tmp1760_1757.bindRoot(new clojure.pprint.capitalize_string()); clojure.lang.Var tmp1784_1781 = const__336;tmp1784_1781.setMeta((clojure.lang.IPersistentMap)const__339);tmp1784_1781.bindRoot(new clojure.pprint.capitalize_word_writer()); clojure.lang.Var tmp1808_1805 = const__340;tmp1808_1805.setMeta((clojure.lang.IPersistentMap)const__343);tmp1808_1805.bindRoot(new clojure.pprint.init_cap_writer()); clojure.lang.Var tmp1832_1829 = const__344;tmp1832_1829.setMeta((clojure.lang.IPersistentMap)const__347);tmp1832_1829.bindRoot(new clojure.pprint.modify_case()); clojure.lang.Var tmp1856_1853 = const__348;tmp1856_1853.setMeta((clojure.lang.IPersistentMap)const__351);tmp1856_1853.bindRoot(new clojure.pprint.get_pretty_writer()); clojure.lang.Var tmp1880_1877 = const__352;tmp1880_1877.setMeta((clojure.lang.IPersistentMap)const__355);tmp1880_1877.bindRoot(new clojure.pprint.fresh_line()); clojure.lang.Var tmp1904_1901 = const__356;tmp1904_1901.setMeta((clojure.lang.IPersistentMap)const__359);tmp1904_1901.bindRoot(new clojure.pprint.absolute_tabulation()); clojure.lang.Var tmp1928_1925 = const__360;tmp1928_1925.setMeta((clojure.lang.IPersistentMap)const__363);tmp1928_1925.bindRoot(new clojure.pprint.relative_tabulation()); clojure.lang.Var tmp1952_1949 = const__307;tmp1952_1949.setMeta((clojure.lang.IPersistentMap)const__366);tmp1952_1949.bindRoot(new clojure.pprint.format_logical_block()); clojure.lang.Var tmp1976_1973 = const__367;tmp1976_1973.setMeta((clojure.lang.IPersistentMap)const__370);tmp1976_1973.bindRoot(new clojure.pprint.set_indent()); clojure.lang.Var tmp2000_1997 = const__371;tmp2000_1997.setMeta((clojure.lang.IPersistentMap)const__374);tmp2000_1997.bindRoot(new clojure.pprint.conditional_newline()); clojure.lang.Var tmp2024_2021 = const__375;tmp2024_2021.setMeta((clojure.lang.IPersistentMap)const__378);tmp2024_2021.bindRoot(new clojure.pprint.process_directive_table_element()); clojure.lang.Var tmp2048_2045 = const__379;tmp2048_2045.setMeta((clojure.lang.IPersistentMap)const__382);tmp2048_2045.bindRoot(new clojure.pprint.defdirectives());((clojure.lang.Var)const__379)
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1328 */       .setMacro(); clojure.lang.Var tmp2085_2082 = const__383;tmp2085_2082.setMeta((clojure.lang.IPersistentMap)const__385);tmp2085_2082
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1334 */       .bindRoot(((clojure.lang.IFn)const__386.getRawRoot()).invoke(const__387, RT.mapUniqueKeys(new Object[] { const__388, const__387, const__74, ((clojure.lang.IFn)const__389.getRawRoot()).invoke(const__390, const__393, const__394, const__396, const__397, const__398, const__399, const__402), const__403, const__407, const__408, clojure.lang.PersistentArrayMap.EMPTY, const__409, new clojure.pprint.fn__8807() }), const__410, RT.mapUniqueKeys(new Object[] { const__388, const__410, const__74, ((clojure.lang.IFn)const__389.getRawRoot()).invoke(const__390, const__411, const__394, const__412, const__397, const__413, const__399, const__414), const__403, const__415, const__408, clojure.lang.PersistentArrayMap.EMPTY, const__409, new clojure.pprint.fn__8811() }), const__416, RT.mapUniqueKeys(new Object[] { const__388, const__416, const__74, ((clojure.lang.IFn)const__389.getRawRoot()).invoke(const__390, const__417, const__399, const__418, const__419, const__421, const__422, const__424), const__403, const__425, const__408, clojure.lang.PersistentArrayMap.EMPTY, const__409, new clojure.pprint.fn__8815() }), const__426, RT.mapUniqueKeys(new Object[] { const__388, const__426, const__74, ((clojure.lang.IFn)const__389.getRawRoot()).invoke(const__390, const__427, const__399, const__428, const__419, const__429, const__422, const__430), const__403, const__431, const__408, clojure.lang.PersistentArrayMap.EMPTY, const__409, new clojure.pprint.fn__8819() }), const__432, RT.mapUniqueKeys(new Object[] { const__388, const__432, const__74, ((clojure.lang.IFn)const__389.getRawRoot()).invoke(const__390, const__433, const__399, const__434, const__419, const__435, const__422, const__436), const__403, const__437, const__408, clojure.lang.PersistentArrayMap.EMPTY, const__409, new clojure.pprint.fn__8823() }), const__438, RT.mapUniqueKeys(new Object[] { const__388, const__438, const__74, ((clojure.lang.IFn)const__389.getRawRoot()).invoke(const__390, const__439, const__399, const__440, const__419, const__441, const__422, const__442), const__403, const__443, const__408, clojure.lang.PersistentArrayMap.EMPTY, const__409, new clojure.pprint.fn__8827() }), const__444, RT.mapUniqueKeys(new Object[] { const__388, const__444, const__74, ((clojure.lang.IFn)const__389.getRawRoot()).invoke(const__445, const__446, const__390, const__447, const__399, const__448, const__419, const__449, const__422, const__450), const__403, const__451, const__408, clojure.lang.PersistentArrayMap.EMPTY, const__409, new clojure.pprint.fn__8831() }), const__452, RT.mapUniqueKeys(new Object[] { const__388, const__452, const__74, ((clojure.lang.IFn)const__389.getRawRoot()).invoke(), const__403, const__453, const__408, clojure.lang.PersistentArrayMap.EMPTY, const__409, new clojure.pprint.fn__8844() }), const__454, RT.mapUniqueKeys(new Object[] { const__388, const__454, const__74, ((clojure.lang.IFn)const__389.getRawRoot()).invoke(const__455, const__456), const__403, const__457, const__408, clojure.lang.PersistentArrayMap.EMPTY, const__409, new clojure.pprint.fn__8849() }), const__458, RT.mapUniqueKeys(new Object[] { const__388, const__458, const__74, ((clojure.lang.IFn)const__389.getRawRoot()).invoke(const__459, const__460, const__461, const__462, const__463, const__464, const__465, const__466, const__399, const__467), const__403, const__468, const__408, clojure.lang.PersistentArrayMap.EMPTY, const__409, new clojure.pprint.fn__8851() }), new Object[] { const__469, RT.mapUniqueKeys(new Object[] { const__388, const__469, const__74, ((clojure.lang.IFn)const__389.getRawRoot()).invoke(const__459, const__470, const__461, const__471, const__472, const__473, const__463, const__474, const__465, const__475, const__399, const__476, const__477, const__478), const__403, const__479, const__408, clojure.lang.PersistentArrayMap.EMPTY, const__409, new clojure.pprint.fn__8853() }), const__480, RT.mapUniqueKeys(new Object[] { const__388, const__480, const__74, ((clojure.lang.IFn)const__389.getRawRoot()).invoke(const__459, const__481, const__461, const__482, const__472, const__483, const__463, const__484, const__465, const__485, const__399, const__486, const__477, const__487), const__403, const__488, const__408, clojure.lang.PersistentArrayMap.EMPTY, const__409, new clojure.pprint.fn__8855() }), const__489, RT.mapUniqueKeys(new Object[] { const__388, const__489, const__74, ((clojure.lang.IFn)const__389.getRawRoot()).invoke(const__461, const__490, const__491, const__492, const__459, const__493, const__399, const__494), const__403, const__495, const__408, clojure.lang.PersistentArrayMap.EMPTY, const__409, new clojure.pprint.fn__8857() }), const__496, RT.mapUniqueKeys(new Object[] { const__388, const__496, const__74, ((clojure.lang.IFn)const__389.getRawRoot()).invoke(const__497, const__498), const__403, clojure.lang.PersistentHashSet.EMPTY, const__408, clojure.lang.PersistentArrayMap.EMPTY, const__409, new clojure.pprint.fn__8859() }), const__499, RT.mapUniqueKeys(new Object[] { const__388, const__499, const__74, ((clojure.lang.IFn)const__389.getRawRoot()).invoke(const__497, const__500), const__403, const__502, const__408, clojure.lang.PersistentArrayMap.EMPTY, const__409, new clojure.pprint.fn__8864() }), const__503, RT.mapUniqueKeys(new Object[] { const__388, const__503, const__74, ((clojure.lang.IFn)const__389.getRawRoot()).invoke(const__497, const__504), const__403, clojure.lang.PersistentHashSet.EMPTY, const__408, clojure.lang.PersistentArrayMap.EMPTY, const__409, new clojure.pprint.fn__8869() }), const__505, RT.mapUniqueKeys(new Object[] { const__388, const__505, const__74, ((clojure.lang.IFn)const__389.getRawRoot()).invoke(const__491, const__506), const__403, clojure.lang.PersistentHashSet.EMPTY, const__408, clojure.lang.PersistentArrayMap.EMPTY, const__409, new clojure.pprint.fn__8874() }), const__507, RT.mapUniqueKeys(new Object[] { const__388, const__507, const__74, ((clojure.lang.IFn)const__389.getRawRoot()).invoke(), const__403, const__508, const__408, clojure.lang.PersistentArrayMap.EMPTY, const__409, new clojure.pprint.fn__8878() }), const__509, RT.mapUniqueKeys(new Object[] { const__388, const__509, const__74, ((clojure.lang.IFn)const__389.getRawRoot()).invoke(const__510, const__511, const__394, const__512), const__403, const__513, const__408, clojure.lang.PersistentArrayMap.EMPTY, const__409, new clojure.pprint.fn__8882() }), const__514, RT.mapUniqueKeys(new Object[] { const__388, const__514, const__74, ((clojure.lang.IFn)const__389.getRawRoot()).invoke(const__491, const__515), const__403, const__516, const__408, clojure.lang.PersistentArrayMap.EMPTY, const__409, new clojure.pprint.fn__8888() }), const__517, RT.mapUniqueKeys(new Object[] { const__388, const__517, const__74, ((clojure.lang.IFn)const__389.getRawRoot()).invoke(), const__403, const__518, const__408, clojure.lang.PersistentArrayMap.EMPTY, const__409, new clojure.pprint.fn__8896() }), const__519, RT.mapUniqueKeys(new Object[] { const__388, const__519, const__74, ((clojure.lang.IFn)const__389.getRawRoot()).invoke(), const__403, const__520, const__408, const__525, const__409, new clojure.pprint.fn__8905() }), const__522, RT.mapUniqueKeys(new Object[] { const__388, const__522, const__74, ((clojure.lang.IFn)const__389.getRawRoot()).invoke(), const__403, clojure.lang.PersistentHashSet.EMPTY, const__408, clojure.lang.PersistentArrayMap.EMPTY, const__409, new clojure.pprint.fn__8910() }), const__526, RT.mapUniqueKeys(new Object[] { const__388, const__526, const__74, ((clojure.lang.IFn)const__389.getRawRoot()).invoke(const__527, const__528), const__403, const__529, const__408, const__532, const__409, new clojure.pprint.fn__8912() }), const__533, RT.mapUniqueKeys(new Object[] { const__388, const__533, const__74, ((clojure.lang.IFn)const__389.getRawRoot()).invoke(const__534, const__535, const__536, const__537), const__403, const__538, const__408, const__540, const__409, new clojure.pprint.fn__8914() }), const__530, RT.mapUniqueKeys(new Object[] { const__388, const__530, const__74, ((clojure.lang.IFn)const__389.getRawRoot()).invoke(), const__403, clojure.lang.PersistentHashSet.EMPTY, const__408, clojure.lang.PersistentArrayMap.EMPTY, const__409, new clojure.pprint.fn__8916() }), const__541, RT.mapUniqueKeys(new Object[] { const__388, const__541, const__74, ((clojure.lang.IFn)const__389.getRawRoot()).invoke(const__542, const__543), const__403, const__544, const__408, const__546, const__409, new clojure.pprint.fn__8918() }), const__545, RT.mapUniqueKeys(new Object[] { const__388, const__545, const__74, ((clojure.lang.IFn)const__389.getRawRoot()).invoke(), const__403, const__547, const__408, clojure.lang.PersistentArrayMap.EMPTY, const__409, new clojure.pprint.fn__8921() }), const__548, RT.mapUniqueKeys(new Object[] { const__388, const__548, const__74, ((clojure.lang.IFn)const__389.getRawRoot()).invoke(const__390, const__549, const__394, const__550, const__397, const__551, const__399, const__552), const__403, const__553, const__408, const__556, const__409, new clojure.pprint.fn__8923() }), const__554, RT.mapUniqueKeys(new Object[] { const__388, const__554, const__74, ((clojure.lang.IFn)const__389.getRawRoot()).invoke(), const__403, const__557, const__408, clojure.lang.PersistentArrayMap.EMPTY, const__409, new clojure.pprint.fn__8925() }), const__558, RT.mapUniqueKeys(new Object[] { const__388, const__558, const__74, ((clojure.lang.IFn)const__389.getRawRoot()).invoke(const__559, const__560, const__561, const__562, const__563, const__564), const__403, const__565, const__408, clojure.lang.PersistentArrayMap.EMPTY, const__409, new clojure.pprint.fn__8927() }), const__566, RT.mapUniqueKeys(new Object[] { const__388, const__566, const__74, ((clojure.lang.IFn)const__389.getRawRoot()).invoke(), const__403, const__567, const__408, clojure.lang.PersistentArrayMap.EMPTY, const__409, new clojure.pprint.fn__8934() }), const__568, RT.mapUniqueKeys(new Object[] { const__388, const__568, const__74, ((clojure.lang.IFn)const__389.getRawRoot()).invoke(), const__403, const__569, const__408, clojure.lang.PersistentArrayMap.EMPTY, const__409, new clojure.pprint.fn__8943() }), const__570, RT.mapUniqueKeys(new Object[] { const__388, const__570, const__74, ((clojure.lang.IFn)const__389.getRawRoot()).invoke(const__491, const__571), const__403, const__572, const__408, clojure.lang.PersistentArrayMap.EMPTY, const__409, new clojure.pprint.fn__8945() }) })); clojure.lang.Var tmp5799_5796 = const__573;tmp5799_5796.setMeta((clojure.lang.IPersistentMap)const__575);tmp5799_5796.bindRoot(const__576); clojure.lang.Var tmp5819_5816 = const__577;tmp5819_5816.setMeta((clojure.lang.IPersistentMap)const__579);tmp5819_5816.bindRoot(const__582); clojure.lang.Var tmp5839_5836 = const__583;tmp5839_5836.setMeta((clojure.lang.IPersistentMap)const__586);tmp5839_5836.bindRoot(new clojure.pprint.extract_param()); clojure.lang.Var tmp5863_5860 = const__587;tmp5863_5860.setMeta((clojure.lang.IPersistentMap)const__590);tmp5863_5860.bindRoot(new clojure.pprint.extract_params()); clojure.lang.Var tmp5887_5884 = const__591;tmp5887_5884.setMeta((clojure.lang.IPersistentMap)const__594);tmp5887_5884.bindRoot(new clojure.pprint.translate_param()); clojure.lang.Var tmp5911_5908 = const__595;tmp5911_5908.setMeta((clojure.lang.IPersistentMap)const__597);tmp5911_5908.bindRoot(const__600); clojure.lang.Var tmp5931_5928 = const__601;tmp5931_5928.setMeta((clojure.lang.IPersistentMap)const__604);tmp5931_5928.bindRoot(new clojure.pprint.extract_flags()); clojure.lang.Var tmp5955_5952 = const__605;tmp5955_5952.setMeta((clojure.lang.IPersistentMap)const__608);tmp5955_5952.bindRoot(new clojure.pprint.check_flags()); clojure.lang.Var tmp5979_5976 = const__609;tmp5979_5976.setMeta((clojure.lang.IPersistentMap)const__612);tmp5979_5976.bindRoot(new clojure.pprint.map_params()); clojure.lang.Var tmp6003_6000 = const__613;tmp6003_6000.setMeta((clojure.lang.IPersistentMap)const__616);tmp6003_6000.bindRoot(new clojure.pprint.compile_directive()); clojure.lang.Var tmp6027_6024 = const__617;tmp6027_6024.setMeta((clojure.lang.IPersistentMap)const__620);tmp6027_6024.bindRoot(new clojure.pprint.compile_raw_string()); clojure.lang.Var tmp6051_6048 = const__621;tmp6051_6048.setMeta((clojure.lang.IPersistentMap)const__624);tmp6051_6048.bindRoot(new clojure.pprint.right_bracket()); clojure.lang.Var tmp6075_6072 = const__625;tmp6075_6072.setMeta((clojure.lang.IPersistentMap)const__628);tmp6075_6072.bindRoot(new clojure.pprint.separator_QMARK_()); clojure.lang.Var tmp6099_6096 = const__629;tmp6099_6096.setMeta((clojure.lang.IPersistentMap)const__632);tmp6099_6096.bindRoot(new clojure.pprint.else_separator_QMARK_());const__633.setMeta((clojure.lang.IPersistentMap)const__635); clojure.lang.Var tmp6136_6133 = const__636;tmp6136_6133.setMeta((clojure.lang.IPersistentMap)const__639);tmp6136_6133.bindRoot(new clojure.pprint.process_bracket()); clojure.lang.Var tmp6160_6157 = const__640;tmp6160_6157.setMeta((clojure.lang.IPersistentMap)const__643);tmp6160_6157.bindRoot(new clojure.pprint.process_clause()); clojure.lang.Var tmp6184_6181 = const__633;tmp6184_6181.setMeta((clojure.lang.IPersistentMap)const__646);tmp6184_6181.bindRoot(new clojure.pprint.collect_clauses()); clojure.lang.Var tmp6208_6205 = const__647;tmp6208_6205.setMeta((clojure.lang.IPersistentMap)const__650);tmp6208_6205.bindRoot(new clojure.pprint.process_nesting()); clojure.lang.Var tmp6232_6229 = const__2;tmp6232_6229.setMeta((clojure.lang.IPersistentMap)const__653);tmp6232_6229.bindRoot(new clojure.pprint.compile_format()); clojure.lang.Var tmp6256_6253 = const__654;tmp6256_6253.setMeta((clojure.lang.IPersistentMap)const__657);tmp6256_6253.bindRoot(new clojure.pprint.needs_pretty()); clojure.lang.Var tmp6280_6277 = const__10;tmp6280_6277.setMeta((clojure.lang.IPersistentMap)const__660);tmp6280_6277.bindRoot(new clojure.pprint.execute_format()); clojure.lang.Var tmp6304_6301 = const__661;tmp6304_6301.setMeta((clojure.lang.IPersistentMap)const__663);tmp6304_6301
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1914 */       .bindRoot(((clojure.lang.IFn)const__664.getRawRoot()).invoke(const__2.getRawRoot())); clojure.lang.Var tmp6341_6338 = const__665;tmp6341_6338.setMeta((clojure.lang.IPersistentMap)const__668);tmp6341_6338.bindRoot(new clojure.pprint.formatter());((clojure.lang.Var)const__665)
/*      */     
/* 1916 */       .setMacro(); clojure.lang.Var tmp6378_6375 = const__669;tmp6378_6375.setMeta((clojure.lang.IPersistentMap)const__672);tmp6378_6375.bindRoot(new clojure.pprint.formatter_out());((clojure.lang.Var)const__669)
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1936 */       .setMacro();
/*      */   }
/*      */   
/*      */   public static final clojure.lang.AFn const__35;
/*      */   public static final clojure.lang.Var const__36;
/*      */   public static final clojure.lang.AFn const__38;
/*      */   public static final clojure.lang.Var const__39;
/*      */   public static final clojure.lang.Keyword const__40;
/*      */   public static final clojure.lang.Keyword const__41;
/*      */   public static final clojure.lang.Keyword const__42;
/*      */   public static final clojure.lang.AFn const__46;
/*      */   public static final clojure.lang.Var const__47;
/*      */   public static final clojure.lang.AFn const__50;
/*      */   public static final clojure.lang.Var const__51;
/*      */   public static final clojure.lang.AFn const__54;
/*      */   public static final clojure.lang.Var const__55;
/*      */   public static final clojure.lang.AFn const__58;
/*      */   public static final clojure.lang.Var const__59;
/*      */   public static final clojure.lang.AFn const__61;
/*      */   public static final clojure.lang.Var const__62;
/*      */   public static final clojure.lang.AFn const__65;
/*      */   public static final clojure.lang.AFn const__68;
/*      */   public static final clojure.lang.Var const__69;
/*      */   public static final clojure.lang.AFn const__71;
/*      */   public static final clojure.lang.Keyword const__72;
/*      */   public static final clojure.lang.Keyword const__73;
/*      */   public static final clojure.lang.Keyword const__74;
/*      */   public static final clojure.lang.Keyword const__75;
/*      */   public static final clojure.lang.Var const__76;
/*      */   public static final clojure.lang.AFn const__79;
/*      */   public static final clojure.lang.Var const__80;
/*      */   public static final clojure.lang.AFn const__83;
/*      */   public static final clojure.lang.Var const__84;
/*      */   public static final clojure.lang.AFn const__86;
/*      */   public static final clojure.lang.Var const__87;
/*      */   public static final clojure.lang.AFn const__89;
/*      */   public static final clojure.lang.AFn const__93;
/*      */   public static final clojure.lang.Var const__94;
/*      */   public static final clojure.lang.AFn const__97;
/*      */   public static final clojure.lang.Var const__98;
/*      */   public static final clojure.lang.AFn const__101;
/*      */   public static final clojure.lang.Var const__102;
/*      */   public static final clojure.lang.AFn const__105;
/*      */   public static final clojure.lang.Var const__106;
/*      */   public static final clojure.lang.AFn const__109;
/*      */   public static final clojure.lang.Var const__110;
/*      */   public static final clojure.lang.AFn const__113;
/*      */   public static final clojure.lang.Var const__114;
/*      */   public static final clojure.lang.AFn const__116;
/*      */   public static final clojure.lang.AFn const__118;
/*      */   public static final clojure.lang.AFn const__121;
/*      */   public static final clojure.lang.Var const__122;
/*      */   public static final clojure.lang.AFn const__125;
/*      */   public static final clojure.lang.Var const__126;
/*      */   public static final clojure.lang.AFn const__129;
/*      */   public static final clojure.lang.Var const__130;
/*      */   public static final clojure.lang.AFn const__132;
/*      */   public static final clojure.lang.AFn const__133;
/*      */   public static final clojure.lang.Var const__134;
/*      */   public static final clojure.lang.AFn const__136;
/*      */   public static final clojure.lang.AFn const__137;
/*      */   public static final clojure.lang.Var const__138;
/*      */   public static final clojure.lang.AFn const__140;
/*      */   public static final clojure.lang.AFn const__141;
/*      */   public static final clojure.lang.Var const__142;
/*      */   public static final clojure.lang.AFn const__144;
/*      */   public static final clojure.lang.AFn const__145;
/*      */   public static final clojure.lang.Var const__146;
/*      */   public static final clojure.lang.AFn const__148;
/*      */   public static final clojure.lang.AFn const__149;
/*      */   public static final clojure.lang.Var const__150;
/*      */   public static final clojure.lang.AFn const__153;
/*      */   public static final clojure.lang.Var const__154;
/*      */   public static final clojure.lang.AFn const__157;
/*      */   public static final clojure.lang.Var const__158;
/*      */   public static final clojure.lang.AFn const__161;
/*      */   public static final clojure.lang.Var const__162;
/*      */   public static final clojure.lang.AFn const__165;
/*      */   public static final clojure.lang.Var const__166;
/*      */   public static final clojure.lang.AFn const__169;
/*      */   public static final clojure.lang.Var const__170;
/*      */   public static final clojure.lang.AFn const__172;
/*      */   public static final clojure.lang.AFn const__177;
/*      */   public static final clojure.lang.Var const__178;
/*      */   public static final clojure.lang.AFn const__180;
/*      */   public static final clojure.lang.AFn const__185;
/*      */   public static final clojure.lang.Var const__186;
/*      */   public static final clojure.lang.AFn const__189;
/*      */   public static final clojure.lang.Var const__190;
/*      */   public static final clojure.lang.AFn const__193;
/*      */   public static final clojure.lang.Var const__194;
/*      */   public static final clojure.lang.AFn const__197;
/*      */   public static final clojure.lang.Var const__198;
/*      */   public static final clojure.lang.AFn const__200;
/*      */   public static final clojure.lang.AFn const__204;
/*      */   public static final clojure.lang.Var const__205;
/*      */   public static final clojure.lang.AFn const__208;
/*      */   public static final clojure.lang.Var const__209;
/*      */   public static final clojure.lang.AFn const__212;
/*      */   public static final clojure.lang.Var const__213;
/*      */   public static final clojure.lang.AFn const__216;
/*      */   public static final clojure.lang.Var const__217;
/*      */   public static final clojure.lang.AFn const__220;
/*      */   public static final clojure.lang.Var const__221;
/*      */   public static final clojure.lang.AFn const__224;
/*      */   public static final clojure.lang.Var const__225;
/*      */   public static final clojure.lang.AFn const__228;
/*      */   public static final clojure.lang.Var const__229;
/*      */   public static final clojure.lang.AFn const__232;
/*      */   public static final clojure.lang.Var const__233;
/*      */   public static final clojure.lang.AFn const__238;
/*      */   public static final clojure.lang.Var const__239;
/*      */   public static final clojure.lang.AFn const__242;
/*      */   public static final clojure.lang.Var const__243;
/*      */   public static final clojure.lang.AFn const__246;
/*      */   public static final clojure.lang.Var const__247;
/*      */   public static final clojure.lang.AFn const__250;
/*      */   public static final clojure.lang.Var const__251;
/*      */   public static final clojure.lang.AFn const__254;
/*      */   public static final clojure.lang.Var const__255;
/*      */   public static final clojure.lang.AFn const__258;
/*      */   public static final clojure.lang.Var const__259;
/*      */   public static final clojure.lang.AFn const__262;
/*      */   public static final clojure.lang.Var const__263;
/*      */   public static final clojure.lang.AFn const__266;
/*      */   public static final clojure.lang.Var const__267;
/*      */   public static final clojure.lang.AFn const__270;
/*      */   public static final clojure.lang.Var const__271;
/*      */   public static final clojure.lang.AFn const__274;
/*      */   public static final clojure.lang.Var const__275;
/*      */   public static final clojure.lang.AFn const__278;
/*      */   public static final clojure.lang.Var const__279;
/*      */   public static final clojure.lang.AFn const__282;
/*      */   public static final clojure.lang.Var const__283;
/*      */   public static final clojure.lang.AFn const__286;
/*      */   public static final clojure.lang.Var const__287;
/*      */   public static final clojure.lang.AFn const__290;
/*      */   public static final clojure.lang.Var const__291;
/*      */   public static final clojure.lang.AFn const__294;
/*      */   public static final clojure.lang.Var const__295;
/*      */   public static final clojure.lang.AFn const__298;
/*      */   public static final clojure.lang.Var const__299;
/*      */   public static final clojure.lang.AFn const__302;
/*      */   public static final clojure.lang.Var const__303;
/*      */   public static final clojure.lang.AFn const__306;
/*      */   public static final clojure.lang.Var const__307;
/*      */   public static final clojure.lang.AFn const__309;
/*      */   public static final clojure.lang.Var const__310;
/*      */   public static final clojure.lang.AFn const__312;
/*      */   public static final clojure.lang.Var const__313;
/*      */   public static final clojure.lang.AFn const__316;
/*      */   public static final clojure.lang.Var const__317;
/*      */   public static final clojure.lang.AFn const__320;
/*      */   public static final clojure.lang.AFn const__323;
/*      */   public static final clojure.lang.Var const__324;
/*      */   public static final clojure.lang.AFn const__327;
/*      */   public static final clojure.lang.Var const__328;
/*      */   public static final clojure.lang.AFn const__331;
/*      */   public static final clojure.lang.Var const__332;
/*      */   public static final clojure.lang.AFn const__335;
/*      */   public static final clojure.lang.Var const__336;
/*      */   public static final clojure.lang.AFn const__339;
/*      */   public static final clojure.lang.Var const__340;
/*      */   public static final clojure.lang.AFn const__343;
/*      */   public static final clojure.lang.Var const__344;
/*      */   public static final clojure.lang.AFn const__347;
/*      */   public static final clojure.lang.Var const__348;
/*      */   public static final clojure.lang.AFn const__351;
/*      */   public static final clojure.lang.Var const__352;
/*      */   public static final clojure.lang.AFn const__355;
/*      */   public static final clojure.lang.Var const__356;
/*      */   public static final clojure.lang.AFn const__359;
/*      */   public static final clojure.lang.Var const__360;
/*      */   public static final clojure.lang.AFn const__363;
/*      */   public static final clojure.lang.AFn const__366;
/*      */   public static final clojure.lang.Var const__367;
/*      */   public static final clojure.lang.AFn const__370;
/*      */   public static final clojure.lang.Var const__371;
/*      */   public static final clojure.lang.AFn const__374;
/*      */   public static final clojure.lang.Var const__375;
/*      */   public static final clojure.lang.AFn const__378;
/*      */   public static final clojure.lang.Var const__379;
/*      */   public static final clojure.lang.AFn const__382;
/*      */   public static final clojure.lang.Var const__383;
/*      */   public static final clojure.lang.AFn const__385;
/*      */   public static final clojure.lang.Var const__386;
/*      */   public static final Object const__387;
/*      */   public static final clojure.lang.Keyword const__388;
/*      */   public static final clojure.lang.Var const__389;
/*      */   public static final clojure.lang.Keyword const__390;
/*      */   public static final clojure.lang.AFn const__393;
/*      */   public static final clojure.lang.Keyword const__394;
/*      */   public static final clojure.lang.AFn const__396;
/*      */   public static final clojure.lang.Keyword const__397;
/*      */   public static final clojure.lang.AFn const__398;
/*      */   public static final clojure.lang.Keyword const__399;
/*      */   public static final clojure.lang.AFn const__402;
/*      */   public static final clojure.lang.Keyword const__403;
/*      */   public static final clojure.lang.AFn const__407;
/*      */   public static final clojure.lang.Keyword const__408;
/*      */   public static final clojure.lang.Keyword const__409;
/*      */   public static final Object const__410;
/*      */   public static final clojure.lang.AFn const__411;
/*      */   public static final clojure.lang.AFn const__412;
/*      */   public static final clojure.lang.AFn const__413;
/*      */   public static final clojure.lang.AFn const__414;
/*      */   public static final clojure.lang.AFn const__415;
/*      */   public static final Object const__416;
/*      */   public static final clojure.lang.AFn const__417;
/*      */   public static final clojure.lang.AFn const__418;
/*      */   public static final clojure.lang.Keyword const__419;
/*      */   public static final clojure.lang.AFn const__421;
/*      */   public static final clojure.lang.Keyword const__422;
/*      */   public static final clojure.lang.AFn const__424;
/*      */   public static final clojure.lang.AFn const__425;
/*      */   public static final Object const__426;
/*      */   public static final clojure.lang.AFn const__427;
/*      */   public static final clojure.lang.AFn const__428;
/*      */   public static final clojure.lang.AFn const__429;
/*      */   public static final clojure.lang.AFn const__430;
/*      */   public static final clojure.lang.AFn const__431;
/*      */   public static final Object const__432;
/*      */   public static final clojure.lang.AFn const__433;
/*      */   public static final clojure.lang.AFn const__434;
/*      */   public static final clojure.lang.AFn const__435;
/*      */   public static final clojure.lang.AFn const__436;
/*      */   public static final clojure.lang.AFn const__437;
/*      */   public static final Object const__438;
/*      */   public static final clojure.lang.AFn const__439;
/*      */   public static final clojure.lang.AFn const__440;
/*      */   public static final clojure.lang.AFn const__441;
/*      */   public static final clojure.lang.AFn const__442;
/*      */   public static final clojure.lang.AFn const__443;
/*      */   public static final Object const__444;
/*      */   public static final clojure.lang.Keyword const__445;
/*      */   public static final clojure.lang.AFn const__446;
/*      */   public static final clojure.lang.AFn const__447;
/*      */   public static final clojure.lang.AFn const__448;
/*      */   public static final clojure.lang.AFn const__449;
/*      */   public static final clojure.lang.AFn const__450;
/*      */   public static final clojure.lang.AFn const__451;
/*      */   public static final Object const__452;
/*      */   public static final clojure.lang.AFn const__453;
/*      */   public static final Object const__454;
/*      */   public static final clojure.lang.Keyword const__455;
/*      */   public static final clojure.lang.AFn const__456;
/*      */   public static final clojure.lang.AFn const__457;
/*      */   public static final Object const__458;
/*      */   public static final clojure.lang.Keyword const__459;
/*      */   public static final clojure.lang.AFn const__460;
/*      */   public static final clojure.lang.Keyword const__461;
/*      */   public static final clojure.lang.AFn const__462;
/*      */   public static final clojure.lang.Keyword const__463;
/*      */   public static final clojure.lang.AFn const__464;
/*      */   public static final clojure.lang.Keyword const__465;
/*      */   public static final clojure.lang.AFn const__466;
/*      */   public static final clojure.lang.AFn const__467;
/*      */   public static final clojure.lang.AFn const__468;
/*      */   public static final Object const__469;
/*      */   public static final clojure.lang.AFn const__470;
/*      */   public static final clojure.lang.AFn const__471;
/*      */   public static final clojure.lang.Keyword const__472;
/*      */   public static final clojure.lang.AFn const__473;
/*      */   public static final clojure.lang.AFn const__474;
/*      */   public static final clojure.lang.AFn const__475;
/*      */   public static final clojure.lang.AFn const__476;
/*      */   public static final clojure.lang.Keyword const__477;
/*      */   public static final clojure.lang.AFn const__478;
/*      */   public static final clojure.lang.AFn const__479;
/*      */   public static final Object const__480;
/*      */   public static final clojure.lang.AFn const__481;
/*      */   public static final clojure.lang.AFn const__482;
/*      */   public static final clojure.lang.AFn const__483;
/*      */   public static final clojure.lang.AFn const__484;
/*      */   public static final clojure.lang.AFn const__485;
/*      */   public static final clojure.lang.AFn const__486;
/*      */   public static final clojure.lang.AFn const__487;
/*      */   public static final clojure.lang.AFn const__488;
/*      */   public static final Object const__489;
/*      */   public static final clojure.lang.AFn const__490;
/*      */   public static final clojure.lang.Keyword const__491;
/*      */   public static final clojure.lang.AFn const__492;
/*      */   public static final clojure.lang.AFn const__493;
/*      */   public static final clojure.lang.AFn const__494;
/*      */   public static final clojure.lang.AFn const__495;
/*      */   public static final Object const__496;
/*      */   public static final clojure.lang.Keyword const__497;
/*      */   public static final clojure.lang.AFn const__498;
/*      */   public static final Object const__499;
/*      */   public static final clojure.lang.AFn const__500;
/*      */   public static final clojure.lang.AFn const__502;
/*      */   public static final Object const__503;
/*      */   public static final clojure.lang.AFn const__504;
/*      */   public static final Object const__505;
/*      */   public static final clojure.lang.AFn const__506;
/*      */   public static final Object const__507;
/*      */   public static final clojure.lang.AFn const__508;
/*      */   public static final Object const__509;
/*      */   public static final clojure.lang.Keyword const__510;
/*      */   public static final clojure.lang.AFn const__511;
/*      */   public static final clojure.lang.AFn const__512;
/*      */   public static final clojure.lang.AFn const__513;
/*      */   public static final Object const__514;
/*      */   public static final clojure.lang.AFn const__515;
/*      */   public static final clojure.lang.AFn const__516;
/*      */   public static final Object const__517;
/*      */   public static final clojure.lang.AFn const__518;
/*      */   public static final Object const__519;
/*      */   public static final clojure.lang.AFn const__520;
/*      */   public static final Object const__522;
/*      */   public static final clojure.lang.AFn const__525;
/*      */   public static final Object const__526;
/*      */   public static final clojure.lang.Keyword const__527;
/*      */   public static final clojure.lang.AFn const__528;
/*      */   public static final clojure.lang.AFn const__529;
/*      */   public static final Object const__530;
/*      */   public static final clojure.lang.AFn const__532;
/*      */   public static final Object const__533;
/*      */   public static final clojure.lang.Keyword const__534;
/*      */   public static final clojure.lang.AFn const__535;
/*      */   public static final clojure.lang.Keyword const__536;
/*      */   public static final clojure.lang.AFn const__537;
/*      */   public static final clojure.lang.AFn const__538;
/*      */   public static final clojure.lang.AFn const__540;
/*      */   public static final Object const__541;
/*      */   public static final clojure.lang.Keyword const__542;
/*      */   public static final clojure.lang.AFn const__543;
/*      */   public static final clojure.lang.AFn const__544;
/*      */   public static final Object const__545;
/*      */   public static final clojure.lang.AFn const__546;
/*      */   public static final clojure.lang.AFn const__547;
/*      */   public static final Object const__548;
/*      */   public static final clojure.lang.AFn const__549;
/*      */   public static final clojure.lang.AFn const__550;
/*      */   public static final clojure.lang.AFn const__551;
/*      */   public static final clojure.lang.AFn const__552;
/*      */   public static final clojure.lang.AFn const__553;
/*      */   public static final Object const__554;
/*      */   public static final clojure.lang.AFn const__556;
/*      */   public static final clojure.lang.AFn const__557;
/*      */   public static final Object const__558;
/*      */   public static final clojure.lang.Keyword const__559;
/*      */   public static final clojure.lang.AFn const__560;
/*      */   public static final clojure.lang.Keyword const__561;
/*      */   public static final clojure.lang.AFn const__562;
/*      */   public static final clojure.lang.Keyword const__563;
/*      */   public static final clojure.lang.AFn const__564;
/*      */   public static final clojure.lang.AFn const__565;
/*      */   public static final Object const__566;
/*      */   public static final clojure.lang.AFn const__567;
/*      */   public static final Object const__568;
/*      */   public static final clojure.lang.AFn const__569;
/*      */   public static final Object const__570;
/*      */   public static final clojure.lang.AFn const__571;
/*      */   public static final clojure.lang.AFn const__572;
/*      */   public static final clojure.lang.Var const__573;
/*      */   public static final clojure.lang.AFn const__575;
/*      */   public static final Object const__576;
/*      */   public static final clojure.lang.Var const__577;
/*      */   public static final clojure.lang.AFn const__579;
/*      */   public static final clojure.lang.AFn const__582;
/*      */   public static final clojure.lang.Var const__583;
/*      */   public static final clojure.lang.AFn const__586;
/*      */   public static final clojure.lang.Var const__587;
/*      */   public static final clojure.lang.AFn const__590;
/*      */   public static final clojure.lang.Var const__591;
/*      */   public static final clojure.lang.AFn const__594;
/*      */   public static final clojure.lang.Var const__595;
/*      */   public static final clojure.lang.AFn const__597;
/*      */   public static final clojure.lang.AFn const__600;
/*      */   public static final clojure.lang.Var const__601;
/*      */   public static final clojure.lang.AFn const__604;
/*      */   public static final clojure.lang.Var const__605;
/*      */   public static final clojure.lang.AFn const__608;
/*      */   public static final clojure.lang.Var const__609;
/*      */   public static final clojure.lang.AFn const__612;
/*      */   public static final clojure.lang.Var const__613;
/*      */   public static final clojure.lang.AFn const__616;
/*      */   public static final clojure.lang.Var const__617;
/*      */   public static final clojure.lang.AFn const__620;
/*      */   public static final clojure.lang.Var const__621;
/*      */   public static final clojure.lang.AFn const__624;
/*      */   public static final clojure.lang.Var const__625;
/*      */   public static final clojure.lang.AFn const__628;
/*      */   public static final clojure.lang.Var const__629;
/*      */   public static final clojure.lang.AFn const__632;
/*      */   public static final clojure.lang.Var const__633;
/*      */   public static final clojure.lang.AFn const__635;
/*      */   public static final clojure.lang.Var const__636;
/*      */   public static final clojure.lang.AFn const__639;
/*      */   public static final clojure.lang.Var const__640;
/*      */   public static final clojure.lang.AFn const__643;
/*      */   public static final clojure.lang.AFn const__646;
/*      */   public static final clojure.lang.Var const__647;
/*      */   public static final clojure.lang.AFn const__650;
/*      */   public static final clojure.lang.AFn const__653;
/*      */   public static final clojure.lang.Var const__654;
/*      */   public static final clojure.lang.AFn const__657;
/*      */   public static final clojure.lang.AFn const__660;
/*      */   public static final clojure.lang.Var const__661;
/*      */   public static final clojure.lang.AFn const__663;
/*      */   public static final clojure.lang.Var const__664;
/*      */   public static final clojure.lang.Var const__665;
/*      */   public static final clojure.lang.AFn const__668;
/*      */   public static final clojure.lang.Var const__669;
/*      */   public static final clojure.lang.AFn const__672;
/*      */   public static void __init0()
/*      */   {
/*      */     const__0 = (clojure.lang.Var)RT.var("clojure.core", "in-ns");
/*      */     const__1 = (clojure.lang.AFn)clojure.lang.Symbol.intern(null, "clojure.pprint");
/*      */     const__2 = (clojure.lang.Var)RT.var("clojure.pprint", "compile-format");
/*      */     const__9 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "declared"), Boolean.TRUE, RT.keyword(null, "line"), Integer.valueOf(22), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__10 = (clojure.lang.Var)RT.var("clojure.pprint", "execute-format");
/*      */     const__12 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "declared"), Boolean.TRUE, RT.keyword(null, "line"), Integer.valueOf(23), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__13 = (clojure.lang.Var)RT.var("clojure.pprint", "init-navigator");
/*      */     const__15 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "declared"), Boolean.TRUE, RT.keyword(null, "line"), Integer.valueOf(24), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__16 = (clojure.lang.Var)RT.var("clojure.pprint", "cl-format");
/*      */     const__26 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "writer"), clojure.lang.Symbol.intern(null, "format-in"), clojure.lang.Symbol.intern(null, "&"), clojure.lang.Symbol.intern(null, "args")) })), RT.keyword(null, "doc"), "An implementation of a Common Lisp compatible format function. cl-format formats its\narguments to an output stream or string based on the format control string given. It \nsupports sophisticated formatting of structured data.\n\nWriter is an instance of java.io.Writer, true to output to *out* or nil to output \nto a string, format-in is the format control string and the remaining arguments \nare the data to be formatted.\n\nThe format control string is a string to be output with embedded 'format directives' \ndescribing how to format the various arguments passed in.\n\nIf writer is nil, cl-format returns the formatted result string. Otherwise, cl-format \nreturns nil.\n\nFor example:\n (let [results [46 38 22]]\n        (cl-format true \"There ~[are~;is~:;are~]~:* ~d result~:p: ~{~d~^, ~}~%\" \n                   (count results) results))\n\nPrints to *out*:\n There are 3 results: 46, 38, 22\n\nDetailed documentation on format control strings is available in the \"Common Lisp the \nLanguage, 2nd edition\", Chapter 22 (available online at:\nhttp://www.cs.cmu.edu/afs/cs.cmu.edu/project/ai-repository/ai/html/cltl/clm/node200.html#SECTION002633000000000000000) \nand in the Common Lisp HyperSpec at \nhttp://www.lispworks.com/documentation/HyperSpec/Body/22_c.htm\n", RT.keyword(null, "added"), "1.2", RT.keyword(null, "see-also"), clojure.lang.Tuple.create(clojure.lang.Tuple.create("http://www.cs.cmu.edu/afs/cs.cmu.edu/project/ai-repository/ai/html/cltl/clm/node200.html#SECTION002633000000000000000", "Common Lisp the Language"), clojure.lang.Tuple.create("http://www.lispworks.com/documentation/HyperSpec/Body/22_c.htm", "Common Lisp HyperSpec")), RT.keyword(null, "line"), Integer.valueOf(27), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__27 = (clojure.lang.Var)RT.var("clojure.pprint", "*format-str*");
/*      */     const__31 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "dynamic"), Boolean.TRUE, RT.keyword(null, "line"), Integer.valueOf(66), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__32 = (clojure.lang.Var)RT.var("clojure.pprint", "format-error");
/*      */     const__35 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "message"), clojure.lang.Symbol.intern(null, "offset")) })), RT.keyword(null, "line"), Integer.valueOf(68), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__36 = (clojure.lang.Var)RT.var("clojure.pprint", "arg-navigator");
/*      */     const__38 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "line"), Integer.valueOf(79), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__39 = (clojure.lang.Var)RT.var("clojure.core", "create-struct");
/*      */     const__40 = (clojure.lang.Keyword)RT.keyword(null, "seq");
/*      */     const__41 = (clojure.lang.Keyword)RT.keyword(null, "rest");
/*      */     const__42 = (clojure.lang.Keyword)RT.keyword(null, "pos");
/*      */     const__46 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "s")) })), RT.keyword(null, "doc"), "Create a new arg-navigator from the sequence with the position set to 0", RT.keyword(null, "skip-wiki"), Boolean.TRUE, RT.keyword(null, "line"), Integer.valueOf(82), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__47 = (clojure.lang.Var)RT.var("clojure.pprint", "next-arg");
/*      */     const__50 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "navigator")) })), RT.keyword(null, "line"), Integer.valueOf(90), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__51 = (clojure.lang.Var)RT.var("clojure.pprint", "next-arg-or-nil");
/*      */     const__54 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "navigator")) })), RT.keyword(null, "line"), Integer.valueOf(96), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__55 = (clojure.lang.Var)RT.var("clojure.pprint", "get-format-arg");
/*      */     const__58 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "navigator")) })), RT.keyword(null, "line"), Integer.valueOf(103), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__59 = (clojure.lang.Var)RT.var("clojure.pprint", "relative-reposition");
/*      */     const__61 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "declared"), Boolean.TRUE, RT.keyword(null, "line"), Integer.valueOf(110), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__62 = (clojure.lang.Var)RT.var("clojure.pprint", "absolute-reposition");
/*      */     const__65 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "navigator"), clojure.lang.Symbol.intern(null, "position")) })), RT.keyword(null, "line"), Integer.valueOf(112), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__68 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "navigator"), clojure.lang.Symbol.intern(null, "position")) })), RT.keyword(null, "line"), Integer.valueOf(117), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__69 = (clojure.lang.Var)RT.var("clojure.pprint", "compiled-directive");
/*      */     const__71 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "line"), Integer.valueOf(123), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__72 = (clojure.lang.Keyword)RT.keyword(null, "func");
/*      */     const__73 = (clojure.lang.Keyword)RT.keyword(null, "def");
/*      */     const__74 = (clojure.lang.Keyword)RT.keyword(null, "params");
/*      */     const__75 = (clojure.lang.Keyword)RT.keyword(null, "offset");
/*      */     const__76 = (clojure.lang.Var)RT.var("clojure.pprint", "realize-parameter");
/*      */     const__79 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "param"), clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "raw-val"), clojure.lang.Symbol.intern(null, "offset"))), clojure.lang.Symbol.intern(null, "navigator")) })), RT.keyword(null, "line"), Integer.valueOf(134), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__80 = (clojure.lang.Var)RT.var("clojure.pprint", "realize-parameter-list");
/*      */     const__83 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "parameter-map"), clojure.lang.Symbol.intern(null, "navigator")) })), RT.keyword(null, "line"), Integer.valueOf(150), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__84 = (clojure.lang.Var)RT.var("clojure.pprint", "opt-base-str");
/*      */     const__86 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "declared"), Boolean.TRUE, RT.keyword(null, "line"), Integer.valueOf(163), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__87 = (clojure.lang.Var)RT.var("clojure.pprint", "special-radix-markers");
/*      */     const__89 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "line"), Integer.valueOf(165), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__93 = (clojure.lang.AFn)RT.map(new Object[] { Long.valueOf(2L), "#b", Long.valueOf(8L), "#o", Long.valueOf(16L), "#x" });
/*      */     const__94 = (clojure.lang.Var)RT.var("clojure.pprint", "format-simple-number");
/*      */     const__97 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "n")) })), RT.keyword(null, "line"), Integer.valueOf(168), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__98 = (clojure.lang.Var)RT.var("clojure.pprint", "format-ascii");
/*      */   }
/*      */   
/*      */   public static void __init1()
/*      */   {
/*      */     const__101 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "print-func"), clojure.lang.Symbol.intern(null, "params"), clojure.lang.Symbol.intern(null, "arg-navigator"), clojure.lang.Symbol.intern(null, "offsets")) })), RT.keyword(null, "line"), Integer.valueOf(182), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__102 = (clojure.lang.Var)RT.var("clojure.pprint", "integral?");
/*      */     const__105 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "x")) })), RT.keyword(null, "doc"), "returns true if a number is actually an integer (that is, has no fractional part)", RT.keyword(null, "line"), Integer.valueOf(205), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__106 = (clojure.lang.Var)RT.var("clojure.pprint", "remainders");
/*      */     const__109 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "base"), clojure.lang.Symbol.intern(null, "val")) })), RT.keyword(null, "doc"), "Return the list of remainders (essentially the 'digits') of val in the given base", RT.keyword(null, "line"), Integer.valueOf(216), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__110 = (clojure.lang.Var)RT.var("clojure.pprint", "base-str");
/*      */     const__113 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "base"), clojure.lang.Symbol.intern(null, "val")) })), RT.keyword(null, "doc"), "Return val as a string in the given base", RT.keyword(null, "line"), Integer.valueOf(227), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__114 = (clojure.lang.Var)RT.var("clojure.pprint", "java-base-formats");
/*      */     const__116 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "line"), Integer.valueOf(242), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__118 = (clojure.lang.AFn)RT.map(new Object[] { Long.valueOf(8L), "%o", Long.valueOf(10L), "%d", Long.valueOf(16L), "%x" });
/*      */     const__121 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "base"), clojure.lang.Symbol.intern(null, "val")) })), RT.keyword(null, "doc"), "Return val as a string in the given base, using clojure.core/format if supported\nfor improved performance", RT.keyword(null, "line"), Integer.valueOf(245), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__122 = (clojure.lang.Var)RT.var("clojure.pprint", "group-by*");
/*      */     const__125 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "unit"), clojure.lang.Symbol.intern(null, "lis")) })), RT.keyword(null, "line"), Integer.valueOf(254), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__126 = (clojure.lang.Var)RT.var("clojure.pprint", "format-integer");
/*      */     const__129 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "base"), clojure.lang.Symbol.intern(null, "params"), clojure.lang.Symbol.intern(null, "arg-navigator"), clojure.lang.Symbol.intern(null, "offsets")) })), RT.keyword(null, "line"), Integer.valueOf(259), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__130 = (clojure.lang.Var)RT.var("clojure.pprint", "english-cardinal-units");
/*      */     const__132 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "line"), Integer.valueOf(289), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__133 = (clojure.lang.AFn)RT.vector(new Object[] { "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen" });
/*      */     const__134 = (clojure.lang.Var)RT.var("clojure.pprint", "english-ordinal-units");
/*      */     const__136 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "line"), Integer.valueOf(295), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__137 = (clojure.lang.AFn)RT.vector(new Object[] { "zeroth", "first", "second", "third", "fourth", "fifth", "sixth", "seventh", "eighth", "ninth", "tenth", "eleventh", "twelfth", "thirteenth", "fourteenth", "fifteenth", "sixteenth", "seventeenth", "eighteenth", "nineteenth" });
/*      */     const__138 = (clojure.lang.Var)RT.var("clojure.pprint", "english-cardinal-tens");
/*      */     const__140 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "line"), Integer.valueOf(301), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__141 = (clojure.lang.AFn)RT.vector(new Object[] { "", "", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety" });
/*      */     const__142 = (clojure.lang.Var)RT.var("clojure.pprint", "english-ordinal-tens");
/*      */     const__144 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "line"), Integer.valueOf(305), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__145 = (clojure.lang.AFn)RT.vector(new Object[] { "", "", "twentieth", "thirtieth", "fortieth", "fiftieth", "sixtieth", "seventieth", "eightieth", "ninetieth" });
/*      */     const__146 = (clojure.lang.Var)RT.var("clojure.pprint", "english-scale-numbers");
/*      */     const__148 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "line"), Integer.valueOf(314), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__149 = (clojure.lang.AFn)RT.vector(new Object[] { "", "thousand", "million", "billion", "trillion", "quadrillion", "quintillion", "sextillion", "septillion", "octillion", "nonillion", "decillion", "undecillion", "duodecillion", "tredecillion", "quattuordecillion", "quindecillion", "sexdecillion", "septendecillion", "octodecillion", "novemdecillion", "vigintillion" });
/*      */     const__150 = (clojure.lang.Var)RT.var("clojure.pprint", "format-simple-cardinal");
/*      */     const__153 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "num")) })), RT.keyword(null, "doc"), "Convert a number less than 1000 to a cardinal english string", RT.keyword(null, "line"), Integer.valueOf(322), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__154 = (clojure.lang.Var)RT.var("clojure.pprint", "add-english-scales");
/*      */     const__157 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "parts"), clojure.lang.Symbol.intern(null, "offset")) })), RT.keyword(null, "doc"), "Take a sequence of parts, add scale numbers (e.g., million) and combine into a string\noffset is a factor of 10^3 to multiply by", RT.keyword(null, "line"), Integer.valueOf(340), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__158 = (clojure.lang.Var)RT.var("clojure.pprint", "format-cardinal-english");
/*      */     const__161 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "params"), clojure.lang.Symbol.intern(null, "navigator"), clojure.lang.Symbol.intern(null, "offsets")) })), RT.keyword(null, "line"), Integer.valueOf(363), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__162 = (clojure.lang.Var)RT.var("clojure.pprint", "format-simple-ordinal");
/*      */     const__165 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "num")) })), RT.keyword(null, "doc"), "Convert a number less than 1000 to a ordinal english string\nNote this should only be used for the last one in the sequence", RT.keyword(null, "line"), Integer.valueOf(380), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__166 = (clojure.lang.Var)RT.var("clojure.pprint", "format-ordinal-english");
/*      */     const__169 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "params"), clojure.lang.Symbol.intern(null, "navigator"), clojure.lang.Symbol.intern(null, "offsets")) })), RT.keyword(null, "line"), Integer.valueOf(402), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__170 = (clojure.lang.Var)RT.var("clojure.pprint", "old-roman-table");
/*      */     const__172 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "line"), Integer.valueOf(439), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__177 = (clojure.lang.AFn)clojure.lang.Tuple.create(RT.vector(new Object[] { "I", "II", "III", "IIII", "V", "VI", "VII", "VIII", "VIIII" }), RT.vector(new Object[] { "X", "XX", "XXX", "XXXX", "L", "LX", "LXX", "LXXX", "LXXXX" }), RT.vector(new Object[] { "C", "CC", "CCC", "CCCC", "D", "DC", "DCC", "DCCC", "DCCCC" }), clojure.lang.Tuple.create("M", "MM", "MMM"));
/*      */     const__178 = (clojure.lang.Var)RT.var("clojure.pprint", "new-roman-table");
/*      */     const__180 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "line"), Integer.valueOf(446), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__185 = (clojure.lang.AFn)clojure.lang.Tuple.create(RT.vector(new Object[] { "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX" }), RT.vector(new Object[] { "X", "XX", "XXX", "XL", "L", "LX", "LXX", "LXXX", "XC" }), RT.vector(new Object[] { "C", "CC", "CCC", "CD", "D", "DC", "DCC", "DCCC", "CM" }), clojure.lang.Tuple.create("M", "MM", "MMM"));
/*      */     const__186 = (clojure.lang.Var)RT.var("clojure.pprint", "format-roman");
/*      */     const__189 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "table"), clojure.lang.Symbol.intern(null, "params"), clojure.lang.Symbol.intern(null, "navigator"), clojure.lang.Symbol.intern(null, "offsets")) })), RT.keyword(null, "doc"), "Format a roman numeral using the specified look-up table", RT.keyword(null, "line"), Integer.valueOf(453), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__190 = (clojure.lang.Var)RT.var("clojure.pprint", "format-old-roman");
/*      */     const__193 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "params"), clojure.lang.Symbol.intern(null, "navigator"), clojure.lang.Symbol.intern(null, "offsets")) })), RT.keyword(null, "line"), Integer.valueOf(477), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__194 = (clojure.lang.Var)RT.var("clojure.pprint", "format-new-roman");
/*      */     const__197 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "params"), clojure.lang.Symbol.intern(null, "navigator"), clojure.lang.Symbol.intern(null, "offsets")) })), RT.keyword(null, "line"), Integer.valueOf(480), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__198 = (clojure.lang.Var)RT.var("clojure.pprint", "special-chars");
/*      */   }
/*      */   
/*      */   public static void __init2()
/*      */   {
/*      */     const__200 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "line"), Integer.valueOf(487), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__204 = (clojure.lang.AFn)RT.map(new Object[] { Long.valueOf(8L), "Backspace", Long.valueOf(9L), "Tab", Long.valueOf(10L), "Newline", Long.valueOf(13L), "Return", Long.valueOf(32L), "Space" });
/*      */     const__205 = (clojure.lang.Var)RT.var("clojure.pprint", "pretty-character");
/*      */     const__208 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "params"), clojure.lang.Symbol.intern(null, "navigator"), clojure.lang.Symbol.intern(null, "offsets")) })), RT.keyword(null, "line"), Integer.valueOf(490), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__209 = (clojure.lang.Var)RT.var("clojure.pprint", "readable-character");
/*      */     const__212 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "params"), clojure.lang.Symbol.intern(null, "navigator"), clojure.lang.Symbol.intern(null, "offsets")) })), RT.keyword(null, "line"), Integer.valueOf(504), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__213 = (clojure.lang.Var)RT.var("clojure.pprint", "plain-character");
/*      */     const__216 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "params"), clojure.lang.Symbol.intern(null, "navigator"), clojure.lang.Symbol.intern(null, "offsets")) })), RT.keyword(null, "line"), Integer.valueOf(512), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__217 = (clojure.lang.Var)RT.var("clojure.pprint", "abort?");
/*      */     const__220 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "context")) })), RT.keyword(null, "line"), Integer.valueOf(519), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__221 = (clojure.lang.Var)RT.var("clojure.pprint", "execute-sub-format");
/*      */     const__224 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "format"), clojure.lang.Symbol.intern(null, "args"), clojure.lang.Symbol.intern(null, "base-args")) })), RT.keyword(null, "line"), Integer.valueOf(524), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__225 = (clojure.lang.Var)RT.var("clojure.pprint", "float-parts-base");
/*      */     const__228 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "f")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "tag"), clojure.lang.Symbol.intern(null, "Object") }))) })), RT.keyword(null, "doc"), "Produce string parts for the mantissa (normalized 1-9) and exponent", RT.keyword(null, "line"), Integer.valueOf(542), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__229 = (clojure.lang.Var)RT.var("clojure.pprint", "float-parts");
/*      */     const__232 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "f")) })), RT.keyword(null, "doc"), "Take care of leading and trailing zeros in decomposed floats", RT.keyword(null, "line"), Integer.valueOf(557), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__233 = (clojure.lang.Var)RT.var("clojure.pprint", "inc-s");
/*      */     const__238 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "tag"), RT.classForName("java.lang.String"), RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "s")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "tag"), clojure.lang.Symbol.intern(null, "String") }))) })), RT.keyword(null, "doc"), "Assumption: The input string consists of one or more decimal digits,\nand no other characters.  Return a string containing one or more\ndecimal digits containing a decimal number one larger than the input\nstring.  The output string will always be the same length as the input\nstring, or one character longer.", RT.keyword(null, "line"), Integer.valueOf(569), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__239 = (clojure.lang.Var)RT.var("clojure.pprint", "round-str");
/*      */     const__242 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "m"), clojure.lang.Symbol.intern(null, "e"), clojure.lang.Symbol.intern(null, "d"), clojure.lang.Symbol.intern(null, "w")) })), RT.keyword(null, "line"), Integer.valueOf(585), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__243 = (clojure.lang.Var)RT.var("clojure.pprint", "expand-fixed");
/*      */     const__246 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "m"), clojure.lang.Symbol.intern(null, "e"), clojure.lang.Symbol.intern(null, "d")) })), RT.keyword(null, "line"), Integer.valueOf(627), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__247 = (clojure.lang.Var)RT.var("clojure.pprint", "insert-decimal");
/*      */     const__250 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "m"), clojure.lang.Symbol.intern(null, "e")) })), RT.keyword(null, "doc"), "Insert the decimal point at the right spot in the number to match an exponent", RT.keyword(null, "line"), Integer.valueOf(637), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__251 = (clojure.lang.Var)RT.var("clojure.pprint", "get-fixed");
/*      */     const__254 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "m"), clojure.lang.Symbol.intern(null, "e"), clojure.lang.Symbol.intern(null, "d")) })), RT.keyword(null, "line"), Integer.valueOf(645), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__255 = (clojure.lang.Var)RT.var("clojure.pprint", "insert-scaled-decimal");
/*      */     const__258 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "m"), clojure.lang.Symbol.intern(null, "k")) })), RT.keyword(null, "doc"), "Insert the decimal point at the right spot in the number to match an exponent", RT.keyword(null, "line"), Integer.valueOf(648), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__259 = (clojure.lang.Var)RT.var("clojure.pprint", "convert-ratio");
/*      */     const__262 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "x")) })), RT.keyword(null, "line"), Integer.valueOf(655), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__263 = (clojure.lang.Var)RT.var("clojure.pprint", "fixed-float");
/*      */     const__266 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "params"), clojure.lang.Symbol.intern(null, "navigator"), clojure.lang.Symbol.intern(null, "offsets")) })), RT.keyword(null, "line"), Integer.valueOf(672), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__267 = (clojure.lang.Var)RT.var("clojure.pprint", "exponential-float");
/*      */     const__270 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "params"), clojure.lang.Symbol.intern(null, "navigator"), clojure.lang.Symbol.intern(null, "offsets")) })), RT.keyword(null, "line"), Integer.valueOf(720), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__271 = (clojure.lang.Var)RT.var("clojure.pprint", "general-float");
/*      */     const__274 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "params"), clojure.lang.Symbol.intern(null, "navigator"), clojure.lang.Symbol.intern(null, "offsets")) })), RT.keyword(null, "line"), Integer.valueOf(794), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__275 = (clojure.lang.Var)RT.var("clojure.pprint", "dollar-float");
/*      */     const__278 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "params"), clojure.lang.Symbol.intern(null, "navigator"), clojure.lang.Symbol.intern(null, "offsets")) })), RT.keyword(null, "line"), Integer.valueOf(817), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__279 = (clojure.lang.Var)RT.var("clojure.pprint", "choice-conditional");
/*      */     const__282 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "params"), clojure.lang.Symbol.intern(null, "arg-navigator"), clojure.lang.Symbol.intern(null, "offsets")) })), RT.keyword(null, "line"), Integer.valueOf(843), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__283 = (clojure.lang.Var)RT.var("clojure.pprint", "boolean-conditional");
/*      */     const__286 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "params"), clojure.lang.Symbol.intern(null, "arg-navigator"), clojure.lang.Symbol.intern(null, "offsets")) })), RT.keyword(null, "line"), Integer.valueOf(855), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__287 = (clojure.lang.Var)RT.var("clojure.pprint", "check-arg-conditional");
/*      */     const__290 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "params"), clojure.lang.Symbol.intern(null, "arg-navigator"), clojure.lang.Symbol.intern(null, "offsets")) })), RT.keyword(null, "line"), Integer.valueOf(867), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__291 = (clojure.lang.Var)RT.var("clojure.pprint", "iterate-sublist");
/*      */     const__294 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "params"), clojure.lang.Symbol.intern(null, "navigator"), clojure.lang.Symbol.intern(null, "offsets")) })), RT.keyword(null, "line"), Integer.valueOf(886), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__295 = (clojure.lang.Var)RT.var("clojure.pprint", "iterate-list-of-sublists");
/*      */     const__298 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "params"), clojure.lang.Symbol.intern(null, "navigator"), clojure.lang.Symbol.intern(null, "offsets")) })), RT.keyword(null, "line"), Integer.valueOf(911), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__299 = (clojure.lang.Var)RT.var("clojure.pprint", "iterate-main-list");
/*      */   }
/*      */   
/*      */   public static void __init3()
/*      */   {
/*      */     const__302 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "params"), clojure.lang.Symbol.intern(null, "navigator"), clojure.lang.Symbol.intern(null, "offsets")) })), RT.keyword(null, "line"), Integer.valueOf(934), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__303 = (clojure.lang.Var)RT.var("clojure.pprint", "iterate-main-sublists");
/*      */     const__306 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "params"), clojure.lang.Symbol.intern(null, "navigator"), clojure.lang.Symbol.intern(null, "offsets")) })), RT.keyword(null, "line"), Integer.valueOf(958), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__307 = (clojure.lang.Var)RT.var("clojure.pprint", "format-logical-block");
/*      */     const__309 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "declared"), Boolean.TRUE, RT.keyword(null, "line"), Integer.valueOf(990), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__310 = (clojure.lang.Var)RT.var("clojure.pprint", "justify-clauses");
/*      */     const__312 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "declared"), Boolean.TRUE, RT.keyword(null, "line"), Integer.valueOf(991), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__313 = (clojure.lang.Var)RT.var("clojure.pprint", "logical-block-or-justify");
/*      */     const__316 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "params"), clojure.lang.Symbol.intern(null, "navigator"), clojure.lang.Symbol.intern(null, "offsets")) })), RT.keyword(null, "line"), Integer.valueOf(993), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__317 = (clojure.lang.Var)RT.var("clojure.pprint", "render-clauses");
/*      */     const__320 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "clauses"), clojure.lang.Symbol.intern(null, "navigator"), clojure.lang.Symbol.intern(null, "base-navigator")) })), RT.keyword(null, "line"), Integer.valueOf(1002), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__323 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "params"), clojure.lang.Symbol.intern(null, "navigator"), clojure.lang.Symbol.intern(null, "offsets")) })), RT.keyword(null, "line"), Integer.valueOf(1017), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__324 = (clojure.lang.Var)RT.var("clojure.pprint", "downcase-writer");
/*      */     const__327 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "writer")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "tag"), clojure.lang.Symbol.intern(null, "java.io.Writer") }))) })), RT.keyword(null, "doc"), "Returns a proxy that wraps writer, converting all characters to lower case", RT.keyword(null, "line"), Integer.valueOf(1072), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__328 = (clojure.lang.Var)RT.var("clojure.pprint", "upcase-writer");
/*      */     const__331 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "writer")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "tag"), clojure.lang.Symbol.intern(null, "java.io.Writer") }))) })), RT.keyword(null, "doc"), "Returns a proxy that wraps writer, converting all characters to upper case", RT.keyword(null, "line"), Integer.valueOf(1090), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__332 = (clojure.lang.Var)RT.var("clojure.pprint", "capitalize-string");
/*      */     const__335 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "s"), clojure.lang.Symbol.intern(null, "first?")) })), RT.keyword(null, "doc"), "Capitalizes the words in a string. If first? is false, don't capitalize the \n                                      first character of the string even if it's a letter.", RT.keyword(null, "line"), Integer.valueOf(1108), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__336 = (clojure.lang.Var)RT.var("clojure.pprint", "capitalize-word-writer");
/*      */     const__339 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "writer")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "tag"), clojure.lang.Symbol.intern(null, "java.io.Writer") }))) })), RT.keyword(null, "doc"), "Returns a proxy that wraps writer, capitalizing all words", RT.keyword(null, "line"), Integer.valueOf(1132), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__340 = (clojure.lang.Var)RT.var("clojure.pprint", "init-cap-writer");
/*      */     const__343 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "writer")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "tag"), clojure.lang.Symbol.intern(null, "java.io.Writer") }))) })), RT.keyword(null, "doc"), "Returns a proxy that wraps writer, capitalizing the first word", RT.keyword(null, "line"), Integer.valueOf(1160), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__344 = (clojure.lang.Var)RT.var("clojure.pprint", "modify-case");
/*      */     const__347 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "make-writer"), clojure.lang.Symbol.intern(null, "params"), clojure.lang.Symbol.intern(null, "navigator"), clojure.lang.Symbol.intern(null, "offsets")) })), RT.keyword(null, "line"), Integer.valueOf(1194), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__348 = (clojure.lang.Var)RT.var("clojure.pprint", "get-pretty-writer");
/*      */     const__351 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "writer")) })), RT.keyword(null, "doc"), "Returns the java.io.Writer passed in wrapped in a pretty writer proxy, unless it's \nalready a pretty writer. Generally, it is unnecessary to call this function, since pprint,\nwrite, and cl-format all call it if they need to. However if you want the state to be \npreserved across calls, you will want to wrap them with this. \n\nFor example, when you want to generate column-aware output with multiple calls to cl-format, \ndo it like in this example:\n\n    (defn print-table [aseq column-width]\n      (binding [*out* (get-pretty-writer *out*)]\n        (doseq [row aseq]\n          (doseq [col row]\n            (cl-format true \"~4D~7,vT\" col column-width))\n          (prn))))\n\nNow when you run:\n\n    user> (print-table (map #(vector % (* % %) (* % % %)) (range 1 11)) 8)\n\nIt prints a table of squares and cubes for the numbers from 1 to 10:\n\n       1      1       1    \n       2      4       8    \n       3      9      27    \n       4     16      64    \n       5     25     125    \n       6     36     216    \n       7     49     343    \n       8     64     512    \n       9     81     729    \n      10    100    1000", RT.keyword(null, "added"), "1.2", RT.keyword(null, "line"), Integer.valueOf(1203), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__352 = (clojure.lang.Var)RT.var("clojure.pprint", "fresh-line");
/*      */     const__355 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create() })), RT.keyword(null, "doc"), "Make a newline if *out* is not already at the beginning of the line. If *out* is\nnot a pretty writer (which keeps track of columns), this function always outputs a newline.", RT.keyword(null, "added"), "1.2", RT.keyword(null, "line"), Integer.valueOf(1245), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__356 = (clojure.lang.Var)RT.var("clojure.pprint", "absolute-tabulation");
/*      */     const__359 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "params"), clojure.lang.Symbol.intern(null, "navigator"), clojure.lang.Symbol.intern(null, "offsets")) })), RT.keyword(null, "line"), Integer.valueOf(1255), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__360 = (clojure.lang.Var)RT.var("clojure.pprint", "relative-tabulation");
/*      */     const__363 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "params"), clojure.lang.Symbol.intern(null, "navigator"), clojure.lang.Symbol.intern(null, "offsets")) })), RT.keyword(null, "line"), Integer.valueOf(1266), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__366 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "params"), clojure.lang.Symbol.intern(null, "navigator"), clojure.lang.Symbol.intern(null, "offsets")) })), RT.keyword(null, "line"), Integer.valueOf(1282), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__367 = (clojure.lang.Var)RT.var("clojure.pprint", "set-indent");
/*      */     const__370 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "params"), clojure.lang.Symbol.intern(null, "navigator"), clojure.lang.Symbol.intern(null, "offsets")) })), RT.keyword(null, "line"), Integer.valueOf(1300), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__371 = (clojure.lang.Var)RT.var("clojure.pprint", "conditional-newline");
/*      */     const__374 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "params"), clojure.lang.Symbol.intern(null, "navigator"), clojure.lang.Symbol.intern(null, "offsets")) })), RT.keyword(null, "line"), Integer.valueOf(1307), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__375 = (clojure.lang.Var)RT.var("clojure.pprint", "process-directive-table-element");
/*      */     const__378 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "char"), clojure.lang.Symbol.intern(null, "params"), clojure.lang.Symbol.intern(null, "flags"), clojure.lang.Symbol.intern(null, "bracket-info"), clojure.lang.Symbol.intern(null, "&"), clojure.lang.Symbol.intern(null, "generator-fn"))) })), RT.keyword(null, "line"), Integer.valueOf(1320), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__379 = (clojure.lang.Var)RT.var("clojure.pprint", "defdirectives");
/*      */     const__382 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "&"), clojure.lang.Symbol.intern(null, "directives")) })), RT.keyword(null, "line"), Integer.valueOf(1328), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__383 = (clojure.lang.Var)RT.var("clojure.pprint", "directive-table");
/*      */     const__385 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "file"), "clojure/pprint/cl_format.clj", RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "line"), Integer.valueOf(1334) });
/*      */     const__386 = (clojure.lang.Var)RT.var("clojure.core", "hash-map");
/*      */     const__387 = Character.valueOf('A');
/*      */     const__388 = (clojure.lang.Keyword)RT.keyword(null, "directive");
/*      */     const__389 = (clojure.lang.Var)RT.var("clojure.core", "array-map");
/*      */     const__390 = (clojure.lang.Keyword)RT.keyword(null, "mincol");
/*      */     const__393 = (clojure.lang.AFn)clojure.lang.Tuple.create(Long.valueOf(0L), RT.classForName("java.lang.Integer"));
/*      */     const__394 = (clojure.lang.Keyword)RT.keyword(null, "colinc");
/*      */     const__396 = (clojure.lang.AFn)clojure.lang.Tuple.create(Long.valueOf(1L), RT.classForName("java.lang.Integer"));
/*      */     const__397 = (clojure.lang.Keyword)RT.keyword(null, "minpad");
/*      */     const__398 = (clojure.lang.AFn)clojure.lang.Tuple.create(Long.valueOf(0L), RT.classForName("java.lang.Integer"));
/*      */     const__399 = (clojure.lang.Keyword)RT.keyword(null, "padchar");
/*      */   }
/*      */   
/*      */   public static void __init4()
/*      */   {
/*      */     const__402 = (clojure.lang.AFn)clojure.lang.Tuple.create(Character.valueOf(' '), RT.classForName("java.lang.Character"));
/*      */     const__403 = (clojure.lang.Keyword)RT.keyword(null, "flags");
/*      */     const__407 = (clojure.lang.AFn)clojure.lang.PersistentHashSet.create(new Object[] { RT.keyword(null, "colon"), RT.keyword(null, "at"), RT.keyword(null, "both") });
/*      */     const__408 = (clojure.lang.Keyword)RT.keyword(null, "bracket-info");
/*      */     const__409 = (clojure.lang.Keyword)RT.keyword(null, "generator-fn");
/*      */     const__410 = Character.valueOf('S');
/*      */     const__411 = (clojure.lang.AFn)clojure.lang.Tuple.create(Long.valueOf(0L), RT.classForName("java.lang.Integer"));
/*      */     const__412 = (clojure.lang.AFn)clojure.lang.Tuple.create(Long.valueOf(1L), RT.classForName("java.lang.Integer"));
/*      */     const__413 = (clojure.lang.AFn)clojure.lang.Tuple.create(Long.valueOf(0L), RT.classForName("java.lang.Integer"));
/*      */     const__414 = (clojure.lang.AFn)clojure.lang.Tuple.create(Character.valueOf(' '), RT.classForName("java.lang.Character"));
/*      */     const__415 = (clojure.lang.AFn)clojure.lang.PersistentHashSet.create(new Object[] { RT.keyword(null, "colon"), RT.keyword(null, "at"), RT.keyword(null, "both") });
/*      */     const__416 = Character.valueOf('D');
/*      */     const__417 = (clojure.lang.AFn)clojure.lang.Tuple.create(Long.valueOf(0L), RT.classForName("java.lang.Integer"));
/*      */     const__418 = (clojure.lang.AFn)clojure.lang.Tuple.create(Character.valueOf(' '), RT.classForName("java.lang.Character"));
/*      */     const__419 = (clojure.lang.Keyword)RT.keyword(null, "commachar");
/*      */     const__421 = (clojure.lang.AFn)clojure.lang.Tuple.create(Character.valueOf(','), RT.classForName("java.lang.Character"));
/*      */     const__422 = (clojure.lang.Keyword)RT.keyword(null, "commainterval");
/*      */     const__424 = (clojure.lang.AFn)clojure.lang.Tuple.create(Long.valueOf(3L), RT.classForName("java.lang.Integer"));
/*      */     const__425 = (clojure.lang.AFn)clojure.lang.PersistentHashSet.create(new Object[] { RT.keyword(null, "colon"), RT.keyword(null, "at"), RT.keyword(null, "both") });
/*      */     const__426 = Character.valueOf('B');
/*      */     const__427 = (clojure.lang.AFn)clojure.lang.Tuple.create(Long.valueOf(0L), RT.classForName("java.lang.Integer"));
/*      */     const__428 = (clojure.lang.AFn)clojure.lang.Tuple.create(Character.valueOf(' '), RT.classForName("java.lang.Character"));
/*      */     const__429 = (clojure.lang.AFn)clojure.lang.Tuple.create(Character.valueOf(','), RT.classForName("java.lang.Character"));
/*      */     const__430 = (clojure.lang.AFn)clojure.lang.Tuple.create(Long.valueOf(3L), RT.classForName("java.lang.Integer"));
/*      */     const__431 = (clojure.lang.AFn)clojure.lang.PersistentHashSet.create(new Object[] { RT.keyword(null, "colon"), RT.keyword(null, "at"), RT.keyword(null, "both") });
/*      */     const__432 = Character.valueOf('O');
/*      */     const__433 = (clojure.lang.AFn)clojure.lang.Tuple.create(Long.valueOf(0L), RT.classForName("java.lang.Integer"));
/*      */     const__434 = (clojure.lang.AFn)clojure.lang.Tuple.create(Character.valueOf(' '), RT.classForName("java.lang.Character"));
/*      */     const__435 = (clojure.lang.AFn)clojure.lang.Tuple.create(Character.valueOf(','), RT.classForName("java.lang.Character"));
/*      */     const__436 = (clojure.lang.AFn)clojure.lang.Tuple.create(Long.valueOf(3L), RT.classForName("java.lang.Integer"));
/*      */     const__437 = (clojure.lang.AFn)clojure.lang.PersistentHashSet.create(new Object[] { RT.keyword(null, "colon"), RT.keyword(null, "at"), RT.keyword(null, "both") });
/*      */     const__438 = Character.valueOf('X');
/*      */     const__439 = (clojure.lang.AFn)clojure.lang.Tuple.create(Long.valueOf(0L), RT.classForName("java.lang.Integer"));
/*      */     const__440 = (clojure.lang.AFn)clojure.lang.Tuple.create(Character.valueOf(' '), RT.classForName("java.lang.Character"));
/*      */     const__441 = (clojure.lang.AFn)clojure.lang.Tuple.create(Character.valueOf(','), RT.classForName("java.lang.Character"));
/*      */     const__442 = (clojure.lang.AFn)clojure.lang.Tuple.create(Long.valueOf(3L), RT.classForName("java.lang.Integer"));
/*      */     const__443 = (clojure.lang.AFn)clojure.lang.PersistentHashSet.create(new Object[] { RT.keyword(null, "colon"), RT.keyword(null, "at"), RT.keyword(null, "both") });
/*      */     const__444 = Character.valueOf('R');
/*      */     const__445 = (clojure.lang.Keyword)RT.keyword(null, "base");
/*      */     const__446 = (clojure.lang.AFn)clojure.lang.Tuple.create(null, RT.classForName("java.lang.Integer"));
/*      */     const__447 = (clojure.lang.AFn)clojure.lang.Tuple.create(Long.valueOf(0L), RT.classForName("java.lang.Integer"));
/*      */     const__448 = (clojure.lang.AFn)clojure.lang.Tuple.create(Character.valueOf(' '), RT.classForName("java.lang.Character"));
/*      */     const__449 = (clojure.lang.AFn)clojure.lang.Tuple.create(Character.valueOf(','), RT.classForName("java.lang.Character"));
/*      */     const__450 = (clojure.lang.AFn)clojure.lang.Tuple.create(Long.valueOf(3L), RT.classForName("java.lang.Integer"));
/*      */     const__451 = (clojure.lang.AFn)clojure.lang.PersistentHashSet.create(new Object[] { RT.keyword(null, "colon"), RT.keyword(null, "at"), RT.keyword(null, "both") });
/*      */     const__452 = Character.valueOf('P');
/*      */     const__453 = (clojure.lang.AFn)clojure.lang.PersistentHashSet.create(new Object[] { RT.keyword(null, "colon"), RT.keyword(null, "at"), RT.keyword(null, "both") });
/*      */     const__454 = Character.valueOf('C');
/*      */     const__455 = (clojure.lang.Keyword)RT.keyword(null, "char-format");
/*      */     const__456 = (clojure.lang.AFn)clojure.lang.Tuple.create(null, RT.classForName("java.lang.Character"));
/*      */     const__457 = (clojure.lang.AFn)clojure.lang.PersistentHashSet.create(new Object[] { RT.keyword(null, "colon"), RT.keyword(null, "at"), RT.keyword(null, "both") });
/*      */     const__458 = Character.valueOf('F');
/*      */     const__459 = (clojure.lang.Keyword)RT.keyword(null, "w");
/*      */     const__460 = (clojure.lang.AFn)clojure.lang.Tuple.create(null, RT.classForName("java.lang.Integer"));
/*      */     const__461 = (clojure.lang.Keyword)RT.keyword(null, "d");
/*      */     const__462 = (clojure.lang.AFn)clojure.lang.Tuple.create(null, RT.classForName("java.lang.Integer"));
/*      */     const__463 = (clojure.lang.Keyword)RT.keyword(null, "k");
/*      */     const__464 = (clojure.lang.AFn)clojure.lang.Tuple.create(Long.valueOf(0L), RT.classForName("java.lang.Integer"));
/*      */     const__465 = (clojure.lang.Keyword)RT.keyword(null, "overflowchar");
/*      */     const__466 = (clojure.lang.AFn)clojure.lang.Tuple.create(null, RT.classForName("java.lang.Character"));
/*      */     const__467 = (clojure.lang.AFn)clojure.lang.Tuple.create(Character.valueOf(' '), RT.classForName("java.lang.Character"));
/*      */     const__468 = (clojure.lang.AFn)clojure.lang.PersistentHashSet.create(new Object[] { RT.keyword(null, "at") });
/*      */     const__469 = Character.valueOf('E');
/*      */     const__470 = (clojure.lang.AFn)clojure.lang.Tuple.create(null, RT.classForName("java.lang.Integer"));
/*      */     const__471 = (clojure.lang.AFn)clojure.lang.Tuple.create(null, RT.classForName("java.lang.Integer"));
/*      */     const__472 = (clojure.lang.Keyword)RT.keyword(null, "e");
/*      */     const__473 = (clojure.lang.AFn)clojure.lang.Tuple.create(null, RT.classForName("java.lang.Integer"));
/*      */     const__474 = (clojure.lang.AFn)clojure.lang.Tuple.create(Long.valueOf(1L), RT.classForName("java.lang.Integer"));
/*      */     const__475 = (clojure.lang.AFn)clojure.lang.Tuple.create(null, RT.classForName("java.lang.Character"));
/*      */     const__476 = (clojure.lang.AFn)clojure.lang.Tuple.create(Character.valueOf(' '), RT.classForName("java.lang.Character"));
/*      */     const__477 = (clojure.lang.Keyword)RT.keyword(null, "exponentchar");
/*      */     const__478 = (clojure.lang.AFn)clojure.lang.Tuple.create(null, RT.classForName("java.lang.Character"));
/*      */     const__479 = (clojure.lang.AFn)clojure.lang.PersistentHashSet.create(new Object[] { RT.keyword(null, "at") });
/*      */     const__480 = Character.valueOf('G');
/*      */     const__481 = (clojure.lang.AFn)clojure.lang.Tuple.create(null, RT.classForName("java.lang.Integer"));
/*      */     const__482 = (clojure.lang.AFn)clojure.lang.Tuple.create(null, RT.classForName("java.lang.Integer"));
/*      */     const__483 = (clojure.lang.AFn)clojure.lang.Tuple.create(null, RT.classForName("java.lang.Integer"));
/*      */     const__484 = (clojure.lang.AFn)clojure.lang.Tuple.create(Long.valueOf(1L), RT.classForName("java.lang.Integer"));
/*      */     const__485 = (clojure.lang.AFn)clojure.lang.Tuple.create(null, RT.classForName("java.lang.Character"));
/*      */     const__486 = (clojure.lang.AFn)clojure.lang.Tuple.create(Character.valueOf(' '), RT.classForName("java.lang.Character"));
/*      */     const__487 = (clojure.lang.AFn)clojure.lang.Tuple.create(null, RT.classForName("java.lang.Character"));
/*      */     const__488 = (clojure.lang.AFn)clojure.lang.PersistentHashSet.create(new Object[] { RT.keyword(null, "at") });
/*      */     const__489 = Character.valueOf('$');
/*      */     const__490 = (clojure.lang.AFn)clojure.lang.Tuple.create(Long.valueOf(2L), RT.classForName("java.lang.Integer"));
/*      */     const__491 = (clojure.lang.Keyword)RT.keyword(null, "n");
/*      */     const__492 = (clojure.lang.AFn)clojure.lang.Tuple.create(Long.valueOf(1L), RT.classForName("java.lang.Integer"));
/*      */     const__493 = (clojure.lang.AFn)clojure.lang.Tuple.create(Long.valueOf(0L), RT.classForName("java.lang.Integer"));
/*      */     const__494 = (clojure.lang.AFn)clojure.lang.Tuple.create(Character.valueOf(' '), RT.classForName("java.lang.Character"));
/*      */     const__495 = (clojure.lang.AFn)clojure.lang.PersistentHashSet.create(new Object[] { RT.keyword(null, "colon"), RT.keyword(null, "at"), RT.keyword(null, "both") });
/*      */     const__496 = Character.valueOf('%');
/*      */     const__497 = (clojure.lang.Keyword)RT.keyword(null, "count");
/*      */     const__498 = (clojure.lang.AFn)clojure.lang.Tuple.create(Long.valueOf(1L), RT.classForName("java.lang.Integer"));
/*      */     const__499 = Character.valueOf('&');
/*      */   }
/*      */   
/*      */   public static void __init5()
/*      */   {
/*      */     const__500 = (clojure.lang.AFn)clojure.lang.Tuple.create(Long.valueOf(1L), RT.classForName("java.lang.Integer"));
/*      */     const__502 = (clojure.lang.AFn)clojure.lang.PersistentHashSet.create(new Object[] { RT.keyword(null, "pretty") });
/*      */     const__503 = Character.valueOf('|');
/*      */     const__504 = (clojure.lang.AFn)clojure.lang.Tuple.create(Long.valueOf(1L), RT.classForName("java.lang.Integer"));
/*      */     const__505 = Character.valueOf('~');
/*      */     const__506 = (clojure.lang.AFn)clojure.lang.Tuple.create(Long.valueOf(1L), RT.classForName("java.lang.Integer"));
/*      */     const__507 = Character.valueOf('\n');
/*      */     const__508 = (clojure.lang.AFn)clojure.lang.PersistentHashSet.create(new Object[] { RT.keyword(null, "colon"), RT.keyword(null, "at") });
/*      */     const__509 = Character.valueOf('T');
/*      */     const__510 = (clojure.lang.Keyword)RT.keyword(null, "colnum");
/*      */     const__511 = (clojure.lang.AFn)clojure.lang.Tuple.create(Long.valueOf(1L), RT.classForName("java.lang.Integer"));
/*      */     const__512 = (clojure.lang.AFn)clojure.lang.Tuple.create(Long.valueOf(1L), RT.classForName("java.lang.Integer"));
/*      */     const__513 = (clojure.lang.AFn)clojure.lang.PersistentHashSet.create(new Object[] { RT.keyword(null, "at"), RT.keyword(null, "pretty") });
/*      */     const__514 = Character.valueOf('*');
/*      */     const__515 = (clojure.lang.AFn)clojure.lang.Tuple.create(null, RT.classForName("java.lang.Integer"));
/*      */     const__516 = (clojure.lang.AFn)clojure.lang.PersistentHashSet.create(new Object[] { RT.keyword(null, "colon"), RT.keyword(null, "at") });
/*      */     const__517 = Character.valueOf('?');
/*      */     const__518 = (clojure.lang.AFn)clojure.lang.PersistentHashSet.create(new Object[] { RT.keyword(null, "at") });
/*      */     const__519 = Character.valueOf('(');
/*      */     const__520 = (clojure.lang.AFn)clojure.lang.PersistentHashSet.create(new Object[] { RT.keyword(null, "colon"), RT.keyword(null, "at"), RT.keyword(null, "both") });
/*      */     const__522 = Character.valueOf(')');
/*      */     const__525 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "right"), Character.valueOf(')'), RT.keyword(null, "allows-separator"), null, RT.keyword(null, "else"), null });
/*      */     const__526 = Character.valueOf('[');
/*      */     const__527 = (clojure.lang.Keyword)RT.keyword(null, "selector");
/*      */     const__528 = (clojure.lang.AFn)clojure.lang.Tuple.create(null, RT.classForName("java.lang.Integer"));
/*      */     const__529 = (clojure.lang.AFn)clojure.lang.PersistentHashSet.create(new Object[] { RT.keyword(null, "colon"), RT.keyword(null, "at") });
/*      */     const__530 = Character.valueOf(']');
/*      */     const__532 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "right"), Character.valueOf(']'), RT.keyword(null, "allows-separator"), Boolean.TRUE, RT.keyword(null, "else"), RT.keyword(null, "last") });
/*      */     const__533 = Character.valueOf(';');
/*      */     const__534 = (clojure.lang.Keyword)RT.keyword(null, "min-remaining");
/*      */     const__535 = (clojure.lang.AFn)clojure.lang.Tuple.create(null, RT.classForName("java.lang.Integer"));
/*      */     const__536 = (clojure.lang.Keyword)RT.keyword(null, "max-columns");
/*      */     const__537 = (clojure.lang.AFn)clojure.lang.Tuple.create(null, RT.classForName("java.lang.Integer"));
/*      */     const__538 = (clojure.lang.AFn)clojure.lang.PersistentHashSet.create(new Object[] { RT.keyword(null, "colon") });
/*      */     const__540 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "separator"), Boolean.TRUE });
/*      */     const__541 = Character.valueOf('{');
/*      */     const__542 = (clojure.lang.Keyword)RT.keyword(null, "max-iterations");
/*      */     const__543 = (clojure.lang.AFn)clojure.lang.Tuple.create(null, RT.classForName("java.lang.Integer"));
/*      */     const__544 = (clojure.lang.AFn)clojure.lang.PersistentHashSet.create(new Object[] { RT.keyword(null, "colon"), RT.keyword(null, "at"), RT.keyword(null, "both") });
/*      */     const__545 = Character.valueOf('}');
/*      */     const__546 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "right"), Character.valueOf('}'), RT.keyword(null, "allows-separator"), Boolean.FALSE });
/*      */     const__547 = (clojure.lang.AFn)clojure.lang.PersistentHashSet.create(new Object[] { RT.keyword(null, "colon") });
/*      */     const__548 = Character.valueOf('<');
/*      */     const__549 = (clojure.lang.AFn)clojure.lang.Tuple.create(Long.valueOf(0L), RT.classForName("java.lang.Integer"));
/*      */     const__550 = (clojure.lang.AFn)clojure.lang.Tuple.create(Long.valueOf(1L), RT.classForName("java.lang.Integer"));
/*      */     const__551 = (clojure.lang.AFn)clojure.lang.Tuple.create(Long.valueOf(0L), RT.classForName("java.lang.Integer"));
/*      */     const__552 = (clojure.lang.AFn)clojure.lang.Tuple.create(Character.valueOf(' '), RT.classForName("java.lang.Character"));
/*      */     const__553 = (clojure.lang.AFn)clojure.lang.PersistentHashSet.create(new Object[] { RT.keyword(null, "colon"), RT.keyword(null, "at"), RT.keyword(null, "both"), RT.keyword(null, "pretty") });
/*      */     const__554 = Character.valueOf('>');
/*      */     const__556 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "right"), Character.valueOf('>'), RT.keyword(null, "allows-separator"), Boolean.TRUE, RT.keyword(null, "else"), RT.keyword(null, "first") });
/*      */     const__557 = (clojure.lang.AFn)clojure.lang.PersistentHashSet.create(new Object[] { RT.keyword(null, "colon") });
/*      */     const__558 = Character.valueOf('^');
/*      */     const__559 = (clojure.lang.Keyword)RT.keyword(null, "arg1");
/*      */     const__560 = (clojure.lang.AFn)clojure.lang.Tuple.create(null, RT.classForName("java.lang.Integer"));
/*      */     const__561 = (clojure.lang.Keyword)RT.keyword(null, "arg2");
/*      */     const__562 = (clojure.lang.AFn)clojure.lang.Tuple.create(null, RT.classForName("java.lang.Integer"));
/*      */     const__563 = (clojure.lang.Keyword)RT.keyword(null, "arg3");
/*      */     const__564 = (clojure.lang.AFn)clojure.lang.Tuple.create(null, RT.classForName("java.lang.Integer"));
/*      */     const__565 = (clojure.lang.AFn)clojure.lang.PersistentHashSet.create(new Object[] { RT.keyword(null, "colon") });
/*      */     const__566 = Character.valueOf('W');
/*      */     const__567 = (clojure.lang.AFn)clojure.lang.PersistentHashSet.create(new Object[] { RT.keyword(null, "colon"), RT.keyword(null, "at"), RT.keyword(null, "both"), RT.keyword(null, "pretty") });
/*      */     const__568 = Character.valueOf('_');
/*      */     const__569 = (clojure.lang.AFn)clojure.lang.PersistentHashSet.create(new Object[] { RT.keyword(null, "colon"), RT.keyword(null, "at"), RT.keyword(null, "both") });
/*      */     const__570 = Character.valueOf('I');
/*      */     const__571 = (clojure.lang.AFn)clojure.lang.Tuple.create(Long.valueOf(0L), RT.classForName("java.lang.Integer"));
/*      */     const__572 = (clojure.lang.AFn)clojure.lang.PersistentHashSet.create(new Object[] { RT.keyword(null, "colon") });
/*      */     const__573 = (clojure.lang.Var)RT.var("clojure.pprint", "param-pattern");
/*      */     const__575 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "line"), Integer.valueOf(1620), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__576 = java.util.regex.Pattern.compile("^([vV]|#|('.)|([+-]?\\d+)|(?=,))");
/*      */     const__577 = (clojure.lang.Var)RT.var("clojure.pprint", "special-params");
/*      */     const__579 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "line"), Integer.valueOf(1622), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__582 = (clojure.lang.AFn)clojure.lang.PersistentHashSet.create(new Object[] { RT.keyword(null, "remaining-arg-count"), RT.keyword(null, "parameter-from-args") });
/*      */     const__583 = (clojure.lang.Var)RT.var("clojure.pprint", "extract-param");
/*      */     const__586 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "s"), clojure.lang.Symbol.intern(null, "offset"), clojure.lang.Symbol.intern(null, "saw-comma"))) })), RT.keyword(null, "line"), Integer.valueOf(1625), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__587 = (clojure.lang.Var)RT.var("clojure.pprint", "extract-params");
/*      */     const__590 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "s"), clojure.lang.Symbol.intern(null, "offset")) })), RT.keyword(null, "line"), Integer.valueOf(1640), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__591 = (clojure.lang.Var)RT.var("clojure.pprint", "translate-param");
/*      */     const__594 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Tuple.create(((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "p")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "tag"), clojure.lang.Symbol.intern(null, "String") })), clojure.lang.Symbol.intern(null, "offset"))) })), RT.keyword(null, "doc"), "Translate the string representation of a param to the internalized\n                                      representation", RT.keyword(null, "line"), Integer.valueOf(1643), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__595 = (clojure.lang.Var)RT.var("clojure.pprint", "flag-defs");
/*      */     const__597 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "line"), Integer.valueOf(1655), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */   }
/*      */   
/*      */   public static void __init6()
/*      */   {
/*      */     const__600 = (clojure.lang.AFn)RT.map(new Object[] { Character.valueOf(':'), RT.keyword(null, "colon"), Character.valueOf('@'), RT.keyword(null, "at") });
/*      */     const__601 = (clojure.lang.Var)RT.var("clojure.pprint", "extract-flags");
/*      */     const__604 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "s"), clojure.lang.Symbol.intern(null, "offset")) })), RT.keyword(null, "line"), Integer.valueOf(1658), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__605 = (clojure.lang.Var)RT.var("clojure.pprint", "check-flags");
/*      */     const__608 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "def"), clojure.lang.Symbol.intern(null, "flags")) })), RT.keyword(null, "line"), Integer.valueOf(1673), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__609 = (clojure.lang.Var)RT.var("clojure.pprint", "map-params");
/*      */     const__612 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "def"), clojure.lang.Symbol.intern(null, "params"), clojure.lang.Symbol.intern(null, "flags"), clojure.lang.Symbol.intern(null, "offset")) })), RT.keyword(null, "doc"), "Takes a directive definition and the list of actual parameters and\na map of flags and returns a map of the parameters and flags with defaults\nfilled in. We check to make sure that there are the right types and number\nof parameters as well.", RT.keyword(null, "line"), Integer.valueOf(1686), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__613 = (clojure.lang.Var)RT.var("clojure.pprint", "compile-directive");
/*      */     const__616 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "s"), clojure.lang.Symbol.intern(null, "offset")) })), RT.keyword(null, "line"), Integer.valueOf(1716), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__617 = (clojure.lang.Var)RT.var("clojure.pprint", "compile-raw-string");
/*      */     const__620 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "s"), clojure.lang.Symbol.intern(null, "offset")) })), RT.keyword(null, "line"), Integer.valueOf(1736), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__621 = (clojure.lang.Var)RT.var("clojure.pprint", "right-bracket");
/*      */     const__624 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "this")) })), RT.keyword(null, "line"), Integer.valueOf(1739), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__625 = (clojure.lang.Var)RT.var("clojure.pprint", "separator?");
/*      */     const__628 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "this")) })), RT.keyword(null, "line"), Integer.valueOf(1740), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__629 = (clojure.lang.Var)RT.var("clojure.pprint", "else-separator?");
/*      */     const__632 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "this")) })), RT.keyword(null, "line"), Integer.valueOf(1741), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__633 = (clojure.lang.Var)RT.var("clojure.pprint", "collect-clauses");
/*      */     const__635 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "declared"), Boolean.TRUE, RT.keyword(null, "line"), Integer.valueOf(1746), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__636 = (clojure.lang.Var)RT.var("clojure.pprint", "process-bracket");
/*      */     const__639 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "this"), clojure.lang.Symbol.intern(null, "remainder")) })), RT.keyword(null, "line"), Integer.valueOf(1748), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__640 = (clojure.lang.Var)RT.var("clojure.pprint", "process-clause");
/*      */     const__643 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "bracket-info"), clojure.lang.Symbol.intern(null, "offset"), clojure.lang.Symbol.intern(null, "remainder")) })), RT.keyword(null, "line"), Integer.valueOf(1757), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__646 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "bracket-info"), clojure.lang.Symbol.intern(null, "offset"), clojure.lang.Symbol.intern(null, "remainder")) })), RT.keyword(null, "line"), Integer.valueOf(1781), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__647 = (clojure.lang.Var)RT.var("clojure.pprint", "process-nesting");
/*      */     const__650 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "format")) })), RT.keyword(null, "doc"), "Take a linearly compiled format and process the bracket directives to give it \n   the appropriate tree structure", RT.keyword(null, "line"), Integer.valueOf(1830), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__653 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "format-str")) })), RT.keyword(null, "doc"), "Compiles format-str into a compiled format which can be used as an argument\nto cl-format just like a plain format string. Use this function for improved \nperformance when you're using the same format string repeatedly", RT.keyword(null, "line"), Integer.valueOf(1845), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__654 = (clojure.lang.Var)RT.var("clojure.pprint", "needs-pretty");
/*      */     const__657 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "format")) })), RT.keyword(null, "doc"), "determine whether a given compiled format has any directives that depend on the\ncolumn number or pretty printing", RT.keyword(null, "line"), Integer.valueOf(1866), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__660 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "stream"), clojure.lang.Symbol.intern(null, "format"), clojure.lang.Symbol.intern(null, "args")), clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "format"), clojure.lang.Symbol.intern(null, "args")) })), RT.keyword(null, "doc"), "Executes the format with the arguments.", RT.keyword(null, "skip-wiki"), Boolean.TRUE, RT.keyword(null, "line"), Integer.valueOf(1879), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__661 = (clojure.lang.Var)RT.var("clojure.pprint", "cached-compile");
/*      */     const__663 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "line"), Integer.valueOf(1914), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__664 = (clojure.lang.Var)RT.var("clojure.core", "memoize");
/*      */     const__665 = (clojure.lang.Var)RT.var("clojure.pprint", "formatter");
/*      */     const__668 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "format-in")) })), RT.keyword(null, "doc"), "Makes a function which can directly run format-in. The function is\nfn [stream & args] ... and returns nil unless the stream is nil (meaning \noutput to a string) in which case it returns the resulting string.\n\nformat-in can be either a control string or a previously compiled format.", RT.keyword(null, "added"), "1.2", RT.keyword(null, "line"), Integer.valueOf(1916), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */     const__669 = (clojure.lang.Var)RT.var("clojure.pprint", "formatter-out");
/*      */     const__672 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "format-in")) })), RT.keyword(null, "doc"), "Makes a function which can directly run format-in. The function is\nfn [& args] ... and returns nil. This version of the formatter macro is\ndesigned to be used with *out* set to an appropriate Writer. In particular,\nthis is meant to be used as part of a pretty printer dispatch method.\n\nformat-in can be either a control string or a previously compiled format.", RT.keyword(null, "added"), "1.2", RT.keyword(null, "line"), Integer.valueOf(1936), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/cl_format.clj" });
/*      */   }
/*      */   
/*      */   static
/*      */   {
/*      */     __init0();
/*      */     __init1();
/*      */     __init2();
/*      */     __init3();
/*      */     __init4();
/*      */     __init5();
/*      */     __init6();
/*      */     clojure.lang.Compiler.pushNSandLoader(RT.classForName("clojure.pprint.cl_format__init").getClassLoader());
/*      */     try
/*      */     {
/*      */       load();
/*      */       clojure.lang.Var.popThreadBindings();
/*      */     }
/*      */     finally
/*      */     {
/*      */       clojure.lang.Var.popThreadBindings();
/*      */       throw finally;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\pprint\cl_format__init.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */