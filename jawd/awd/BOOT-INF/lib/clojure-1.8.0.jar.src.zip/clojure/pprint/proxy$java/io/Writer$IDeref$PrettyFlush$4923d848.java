package clojure.pprint.proxy$java.io;

import clojure.lang.IDeref;
import clojure.lang.IPersistentCollection;
import clojure.lang.IPersistentMap;
import clojure.lang.IProxy;
import clojure.pprint.PrettyFlush;
import java.io.Writer;

public class Writer$IDeref$PrettyFlush$4923d848
  extends Writer
  implements IProxy, IDeref, PrettyFlush
{
  private volatile IPersistentMap __clojureFnMap;
  
  public Writer$IDeref$PrettyFlush$4923d848() {}
  
  public Writer$IDeref$PrettyFlush$4923d848(Object paramObject)
  {
    super(paramObject);
  }
  
  public void __initClojureFnMappings(IPersistentMap paramIPersistentMap)
  {
    this.__clojureFnMap = paramIPersistentMap;
  }
  
  public void __updateClojureFnMappings(IPersistentMap paramIPersistentMap)
  {
    this.__clojureFnMap = ((IPersistentMap)((IPersistentCollection)this.__clojureFnMap).cons(paramIPersistentMap));
  }
  
  public IPersistentMap __getClojureFnMappings()
  {
    return this.__clojureFnMap;
  }
  
  /* Error */
  public boolean equals(Object arg1)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 23	clojure/pprint/proxy$java/io/Writer$IDeref$PrettyFlush$4923d848:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 50
    //   6: invokestatic 56	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +22 -> 32
    //   13: checkcast 58	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: invokeinterface 61 3 0
    //   23: checkcast 63	java/lang/Boolean
    //   26: invokevirtual 67	java/lang/Boolean:booleanValue	()Z
    //   29: goto +9 -> 38
    //   32: pop
    //   33: aload_0
    //   34: aload_1
    //   35: invokespecial 69	java/io/Writer:equals	(Ljava/lang/Object;)Z
    //   38: ireturn
  }
  
  /* Error */
  public void write(int arg1)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 23	clojure/pprint/proxy$java/io/Writer$IDeref$PrettyFlush$4923d848:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 72
    //   6: invokestatic 56	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +20 -> 30
    //   13: checkcast 58	clojure/lang/IFn
    //   16: aload_0
    //   17: iload_1
    //   18: invokestatic 78	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   21: invokeinterface 61 3 0
    //   26: pop
    //   27: goto +9 -> 36
    //   30: pop
    //   31: aload_0
    //   32: iload_1
    //   33: invokespecial 80	java/io/Writer:write	(I)V
    //   36: return
  }
  
  /* Error */
  public String toString()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 23	clojure/pprint/proxy$java/io/Writer$IDeref$PrettyFlush$4923d848:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 83
    //   6: invokestatic 56	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +18 -> 28
    //   13: checkcast 58	clojure/lang/IFn
    //   16: aload_0
    //   17: invokeinterface 86 2 0
    //   22: checkcast 88	java/lang/String
    //   25: goto +8 -> 33
    //   28: pop
    //   29: aload_0
    //   30: invokespecial 90	java/io/Writer:toString	()Ljava/lang/String;
    //   33: areturn
  }
  
  /* Error */
  public Writer append(CharSequence arg1)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 23	clojure/pprint/proxy$java/io/Writer$IDeref$PrettyFlush$4923d848:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 91
    //   6: invokestatic 56	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +19 -> 29
    //   13: checkcast 58	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: invokeinterface 61 3 0
    //   23: checkcast 4	java/io/Writer
    //   26: goto +9 -> 35
    //   29: pop
    //   30: aload_0
    //   31: aload_1
    //   32: invokespecial 47	java/io/Writer:append	(Ljava/lang/CharSequence;)Ljava/io/Writer;
    //   35: areturn
  }
  
  /* Error */
  public Writer append(char arg1)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 23	clojure/pprint/proxy$java/io/Writer$IDeref$PrettyFlush$4923d848:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 91
    //   6: invokestatic 56	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +22 -> 32
    //   13: checkcast 58	clojure/lang/IFn
    //   16: aload_0
    //   17: iload_1
    //   18: invokestatic 96	java/lang/Character:valueOf	(C)Ljava/lang/Character;
    //   21: invokeinterface 61 3 0
    //   26: checkcast 4	java/io/Writer
    //   29: goto +9 -> 38
    //   32: pop
    //   33: aload_0
    //   34: iload_1
    //   35: invokespecial 43	java/io/Writer:append	(C)Ljava/io/Writer;
    //   38: areturn
  }
  
  /* Error */
  public void write(String arg1)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 23	clojure/pprint/proxy$java/io/Writer$IDeref$PrettyFlush$4923d848:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 72
    //   6: invokestatic 56	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +17 -> 27
    //   13: checkcast 58	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: invokeinterface 61 3 0
    //   23: pop
    //   24: goto +9 -> 33
    //   27: pop
    //   28: aload_0
    //   29: aload_1
    //   30: invokespecial 99	java/io/Writer:write	(Ljava/lang/String;)V
    //   33: return
  }
  
  /* Error */
  public void write(String arg1, int arg2, int arg3)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 23	clojure/pprint/proxy$java/io/Writer$IDeref$PrettyFlush$4923d848:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 72
    //   6: invokestatic 56	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +25 -> 35
    //   13: checkcast 58	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: iload_2
    //   19: invokestatic 78	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   22: iload_3
    //   23: invokestatic 78	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   26: invokeinterface 103 5 0
    //   31: pop
    //   32: goto +11 -> 43
    //   35: pop
    //   36: aload_0
    //   37: aload_1
    //   38: iload_2
    //   39: iload_3
    //   40: invokespecial 105	java/io/Writer:write	(Ljava/lang/String;II)V
    //   43: return
  }
  
  /* Error */
  public void write(char[] arg1)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 23	clojure/pprint/proxy$java/io/Writer$IDeref$PrettyFlush$4923d848:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 72
    //   6: invokestatic 56	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +17 -> 27
    //   13: checkcast 58	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: invokeinterface 61 3 0
    //   23: pop
    //   24: goto +9 -> 33
    //   27: pop
    //   28: aload_0
    //   29: aload_1
    //   30: invokespecial 108	java/io/Writer:write	([C)V
    //   33: return
  }
  
  /* Error */
  public int hashCode()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 23	clojure/pprint/proxy$java/io/Writer$IDeref$PrettyFlush$4923d848:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 111
    //   6: invokestatic 56	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +21 -> 31
    //   13: checkcast 58	clojure/lang/IFn
    //   16: aload_0
    //   17: invokeinterface 86 2 0
    //   22: checkcast 113	java/lang/Number
    //   25: invokevirtual 116	java/lang/Number:intValue	()I
    //   28: goto +8 -> 36
    //   31: pop
    //   32: aload_0
    //   33: invokespecial 118	java/io/Writer:hashCode	()I
    //   36: ireturn
  }
  
  /* Error */
  public Writer append(CharSequence arg1, int arg2, int arg3)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 23	clojure/pprint/proxy$java/io/Writer$IDeref$PrettyFlush$4923d848:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 91
    //   6: invokestatic 56	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +27 -> 37
    //   13: checkcast 58	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: iload_2
    //   19: invokestatic 78	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   22: iload_3
    //   23: invokestatic 78	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   26: invokeinterface 103 5 0
    //   31: checkcast 4	java/io/Writer
    //   34: goto +11 -> 45
    //   37: pop
    //   38: aload_0
    //   39: aload_1
    //   40: iload_2
    //   41: iload_3
    //   42: invokespecial 39	java/io/Writer:append	(Ljava/lang/CharSequence;II)Ljava/io/Writer;
    //   45: areturn
  }
  
  /* Error */
  public Object clone()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 23	clojure/pprint/proxy$java/io/Writer$IDeref$PrettyFlush$4923d848:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 121
    //   6: invokestatic 56	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +15 -> 25
    //   13: checkcast 58	clojure/lang/IFn
    //   16: aload_0
    //   17: invokeinterface 86 2 0
    //   22: goto +8 -> 30
    //   25: pop
    //   26: aload_0
    //   27: invokespecial 123	java/io/Writer:clone	()Ljava/lang/Object;
    //   30: areturn
  }
  
  /* Error */
  public Object deref()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 23	clojure/pprint/proxy$java/io/Writer$IDeref$PrettyFlush$4923d848:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 125
    //   6: invokestatic 56	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +15 -> 25
    //   13: checkcast 58	clojure/lang/IFn
    //   16: aload_0
    //   17: invokeinterface 86 2 0
    //   22: goto +14 -> 36
    //   25: pop
    //   26: new 127	java/lang/UnsupportedOperationException
    //   29: dup
    //   30: ldc 125
    //   32: invokespecial 129	java/lang/UnsupportedOperationException:<init>	(Ljava/lang/String;)V
    //   35: athrow
    //   36: areturn
  }
  
  /* Error */
  public void ppflush()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 23	clojure/pprint/proxy$java/io/Writer$IDeref$PrettyFlush$4923d848:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc -125
    //   6: invokestatic 56	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +16 -> 26
    //   13: checkcast 58	clojure/lang/IFn
    //   16: aload_0
    //   17: invokeinterface 86 2 0
    //   22: pop
    //   23: goto +14 -> 37
    //   26: pop
    //   27: new 127	java/lang/UnsupportedOperationException
    //   30: dup
    //   31: ldc -125
    //   33: invokespecial 129	java/lang/UnsupportedOperationException:<init>	(Ljava/lang/String;)V
    //   36: athrow
    //   37: return
  }
  
  /* Error */
  public void close()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 23	clojure/pprint/proxy$java/io/Writer$IDeref$PrettyFlush$4923d848:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc -123
    //   6: invokestatic 56	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +16 -> 26
    //   13: checkcast 58	clojure/lang/IFn
    //   16: aload_0
    //   17: invokeinterface 86 2 0
    //   22: pop
    //   23: goto +14 -> 37
    //   26: pop
    //   27: new 127	java/lang/UnsupportedOperationException
    //   30: dup
    //   31: ldc -123
    //   33: invokespecial 129	java/lang/UnsupportedOperationException:<init>	(Ljava/lang/String;)V
    //   36: athrow
    //   37: return
  }
  
  /* Error */
  public void flush()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 23	clojure/pprint/proxy$java/io/Writer$IDeref$PrettyFlush$4923d848:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc -121
    //   6: invokestatic 56	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +16 -> 26
    //   13: checkcast 58	clojure/lang/IFn
    //   16: aload_0
    //   17: invokeinterface 86 2 0
    //   22: pop
    //   23: goto +14 -> 37
    //   26: pop
    //   27: new 127	java/lang/UnsupportedOperationException
    //   30: dup
    //   31: ldc -121
    //   33: invokespecial 129	java/lang/UnsupportedOperationException:<init>	(Ljava/lang/String;)V
    //   36: athrow
    //   37: return
  }
  
  /* Error */
  public void write(char[] arg1, int arg2, int arg3)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 23	clojure/pprint/proxy$java/io/Writer$IDeref$PrettyFlush$4923d848:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 72
    //   6: invokestatic 56	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +25 -> 35
    //   13: checkcast 58	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: iload_2
    //   19: invokestatic 78	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   22: iload_3
    //   23: invokestatic 78	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   26: invokeinterface 103 5 0
    //   31: pop
    //   32: goto +14 -> 46
    //   35: pop
    //   36: new 127	java/lang/UnsupportedOperationException
    //   39: dup
    //   40: ldc 72
    //   42: invokespecial 129	java/lang/UnsupportedOperationException:<init>	(Ljava/lang/String;)V
    //   45: athrow
    //   46: return
  }
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\pprint\proxy$java\io\Writer$IDeref$PrettyFlush$4923d848.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */