/*     */ package clojure.pprint;
/*     */ 
/*     */ import clojure.lang.RT;
/*     */ 
/*     */ public class utilities__init {
/*     */   public static final clojure.lang.Var const__0;
/*     */   public static final clojure.lang.AFn const__1;
/*     */   public static final clojure.lang.Var const__2;
/*     */   public static final clojure.lang.AFn const__11;
/*     */   public static final clojure.lang.Var const__12;
/*     */   public static final clojure.lang.AFn const__15;
/*     */   public static final clojure.lang.Var const__16;
/*     */   public static final clojure.lang.AFn const__19;
/*     */   public static final clojure.lang.Var const__20;
/*     */   public static final clojure.lang.AFn const__23;
/*     */   public static final clojure.lang.Var const__24;
/*     */   
/*  18 */   public static void load() { clojure.lang.Var tmp20_17 = const__2;tmp20_17.setMeta((clojure.lang.IPersistentMap)const__11);tmp20_17.bindRoot(new clojure.pprint.map_passing_context()); clojure.lang.Var tmp44_41 = const__12;tmp44_41.setMeta((clojure.lang.IPersistentMap)const__15);tmp44_41.bindRoot(new clojure.pprint.consume()); clojure.lang.Var tmp68_65 = const__16;tmp68_65.setMeta((clojure.lang.IPersistentMap)const__19);tmp68_65.bindRoot(new clojure.pprint.consume_while()); clojure.lang.Var tmp92_89 = const__20;tmp92_89.setMeta((clojure.lang.IPersistentMap)const__23);tmp92_89.bindRoot(new clojure.pprint.unzip_map()); clojure.lang.Var tmp116_113 = const__24;tmp116_113.setMeta((clojure.lang.IPersistentMap)const__27);tmp116_113.bindRoot(new clojure.pprint.tuple_map()); clojure.lang.Var tmp140_137 = const__28;tmp140_137.setMeta((clojure.lang.IPersistentMap)const__31);tmp140_137.bindRoot(new clojure.pprint.rtrim()); clojure.lang.Var tmp164_161 = const__32;tmp164_161.setMeta((clojure.lang.IPersistentMap)const__35);tmp164_161.bindRoot(new clojure.pprint.ltrim()); clojure.lang.Var tmp188_185 = const__36;tmp188_185.setMeta((clojure.lang.IPersistentMap)const__39);tmp188_185.bindRoot(new clojure.pprint.prefix_count()); clojure.lang.Var tmp212_209 = const__40;tmp212_209.setMeta((clojure.lang.IPersistentMap)const__43);tmp212_209.bindRoot(new clojure.pprint.prerr()); clojure.lang.Var tmp236_233 = const__44;tmp236_233.setMeta((clojure.lang.IPersistentMap)const__47);tmp236_233.bindRoot(new clojure.pprint.prlabel());((clojure.lang.Var)const__44)
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 100 */       .setMacro();new clojure.pprint.fn__8205();
/*     */   }
/*     */   
/*     */   public static final clojure.lang.AFn const__27;
/*     */   public static final clojure.lang.Var const__28;
/*     */   public static final clojure.lang.AFn const__31;
/*     */   public static final clojure.lang.Var const__32;
/*     */   public static final clojure.lang.AFn const__35;
/*     */   public static final clojure.lang.Var const__36;
/*     */   public static final clojure.lang.AFn const__39;
/*     */   public static final clojure.lang.Var const__40;
/*     */   public static final clojure.lang.AFn const__43;
/*     */   public static final clojure.lang.Var const__44;
/*     */   public static final clojure.lang.AFn const__47;
/*     */   public static void __init0()
/*     */   {
/*     */     const__0 = (clojure.lang.Var)RT.var("clojure.core", "in-ns");
/*     */     const__1 = (clojure.lang.AFn)clojure.lang.Symbol.intern(null, "clojure.pprint");
/*     */     const__2 = (clojure.lang.Var)RT.var("clojure.pprint", "map-passing-context");
/*     */     const__11 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "func"), clojure.lang.Symbol.intern(null, "initial-context"), clojure.lang.Symbol.intern(null, "lis")) })), RT.keyword(null, "line"), Integer.valueOf(26), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/utilities.clj" });
/*     */     const__12 = (clojure.lang.Var)RT.var("clojure.pprint", "consume");
/*     */     const__15 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "func"), clojure.lang.Symbol.intern(null, "initial-context")) })), RT.keyword(null, "line"), Integer.valueOf(37), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/utilities.clj" });
/*     */     const__16 = (clojure.lang.Var)RT.var("clojure.pprint", "consume-while");
/*     */     const__19 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "func"), clojure.lang.Symbol.intern(null, "initial-context")) })), RT.keyword(null, "line"), Integer.valueOf(45), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/utilities.clj" });
/*     */     const__20 = (clojure.lang.Var)RT.var("clojure.pprint", "unzip-map");
/*     */     const__23 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "m")) })), RT.keyword(null, "line"), Integer.valueOf(53), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/utilities.clj" });
/*     */     const__24 = (clojure.lang.Var)RT.var("clojure.pprint", "tuple-map");
/*     */     const__27 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "m"), clojure.lang.Symbol.intern(null, "v1")) })), RT.keyword(null, "line"), Integer.valueOf(60), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/utilities.clj" });
/*     */     const__28 = (clojure.lang.Var)RT.var("clojure.pprint", "rtrim");
/*     */     const__31 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "s"), clojure.lang.Symbol.intern(null, "c")) })), RT.keyword(null, "line"), Integer.valueOf(64), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/utilities.clj" });
/*     */     const__32 = (clojure.lang.Var)RT.var("clojure.pprint", "ltrim");
/*     */     const__35 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "s"), clojure.lang.Symbol.intern(null, "c")) })), RT.keyword(null, "line"), Integer.valueOf(75), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/utilities.clj" });
/*     */     const__36 = (clojure.lang.Var)RT.var("clojure.pprint", "prefix-count");
/*     */     const__39 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "aseq"), clojure.lang.Symbol.intern(null, "val")) })), RT.keyword(null, "line"), Integer.valueOf(85), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/utilities.clj" });
/*     */     const__40 = (clojure.lang.Var)RT.var("clojure.pprint", "prerr");
/*     */     const__43 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "&"), clojure.lang.Symbol.intern(null, "args")) })), RT.keyword(null, "line"), Integer.valueOf(95), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/utilities.clj" });
/*     */     const__44 = (clojure.lang.Var)RT.var("clojure.pprint", "prlabel");
/*     */     const__47 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "prefix"), clojure.lang.Symbol.intern(null, "arg"), clojure.lang.Symbol.intern(null, "&"), clojure.lang.Symbol.intern(null, "more-args")) })), RT.keyword(null, "line"), Integer.valueOf(100), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/utilities.clj" });
/*     */   }
/*     */   
/*     */   static
/*     */   {
/*     */     __init0();
/*     */     clojure.lang.Compiler.pushNSandLoader(RT.classForName("clojure.pprint.utilities__init").getClassLoader());
/*     */     try
/*     */     {
/*     */       load();
/*     */       clojure.lang.Var.popThreadBindings();
/*     */     }
/*     */     finally
/*     */     {
/*     */       clojure.lang.Var.popThreadBindings();
/*     */       throw finally;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\pprint\utilities__init.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */