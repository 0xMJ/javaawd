/*     */ package clojure.pprint;
/*     */ 
/*     */ import clojure.lang.RT;
/*     */ 
/*     */ public class pretty_writer__init
/*     */ {
/*     */   public static final clojure.lang.Var const__0;
/*     */   public static final clojure.lang.AFn const__1;
/*     */   public static final clojure.lang.Var const__2;
/*     */   public static final clojure.lang.AFn const__9;
/*     */   public static final clojure.lang.Var const__10;
/*     */   public static final clojure.lang.Keyword const__11;
/*     */   public static final clojure.lang.AFn const__16;
/*     */   public static final clojure.lang.Var const__17;
/*     */   
/*     */   public static void load()
/*     */   {
/*  18 */     const__2.setMeta((clojure.lang.IPersistentMap)const__9); clojure.lang.Var tmp67_64 = const__10;tmp67_64.setMeta((clojure.lang.IPersistentMap)const__16);tmp67_64.bindRoot(new clojure.pprint.getf());((clojure.lang.Var)const__10)
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  37 */       .setMacro(); clojure.lang.Var tmp104_101 = const__17;tmp104_101.setMeta((clojure.lang.IPersistentMap)const__20);tmp104_101.bindRoot(new clojure.pprint.setf());((clojure.lang.Var)const__17)
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  43 */       .setMacro(); clojure.lang.Var tmp141_138 = const__21;tmp141_138.setMeta((clojure.lang.IPersistentMap)const__24);tmp141_138.bindRoot(new clojure.pprint.deftype());((clojure.lang.Var)const__21)
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  48 */       .setMacro(); clojure.lang.Var tmp178_175 = const__25;tmp178_175.setMeta((clojure.lang.IPersistentMap)const__28);tmp178_175.bindRoot(new clojure.pprint.write_to_base());((clojure.lang.Var)const__25)
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  58 */       .setMacro(); clojure.lang.Var tmp215_212 = const__29;tmp215_212.setMeta((clojure.lang.IPersistentMap)const__31);tmp215_212
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  70 */       .bindRoot(((clojure.lang.IFn)const__32.getRawRoot()).invoke(const__33, const__34, const__35, const__36, const__37, const__38, const__39, const__40, const__41, const__42)); clojure.lang.Var tmp276_273 = const__43;tmp276_273.setMeta((clojure.lang.IPersistentMap)const__46);tmp276_273.bindRoot(new clojure.pprint.ancestor_QMARK_()); clojure.lang.Var tmp300_297 = const__47;tmp300_297.setMeta((clojure.lang.IPersistentMap)const__49);tmp300_297
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  83 */       .bindRoot(((clojure.lang.IFn)const__32.getRawRoot()).invoke(const__33)); clojure.lang.Var tmp334_331 = const__50;tmp334_331.setMeta((clojure.lang.IPersistentMap)const__53);tmp334_331.bindRoot(new clojure.pprint.buffer_length()); clojure.lang.Var tmp358_355 = const__54;tmp358_355.setMeta((clojure.lang.IPersistentMap)const__56);tmp358_355
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  92 */       .bindRoot(((clojure.lang.IFn)const__32.getRawRoot()).invoke(const__57, const__58, const__59, const__60, const__61)); clojure.lang.Var tmp433_430 = const__64;tmp433_430.setMeta((clojure.lang.IPersistentMap)const__66);tmp433_430.bindRoot(new clojure.pprint.make_buffer_blob()); clojure.lang.Var tmp457_454 = const__67;tmp457_454.setMeta((clojure.lang.IPersistentMap)const__69);tmp457_454.bindRoot(new clojure.pprint.buffer_blob_QMARK_()); clojure.lang.Var tmp481_478 = const__70;tmp481_478.setMeta((clojure.lang.IPersistentMap)const__72);tmp481_478
/*     */     
/*     */ 
/*  95 */       .bindRoot(((clojure.lang.IFn)const__32.getRawRoot()).invoke(const__57, const__73, const__74, const__60, const__61)); clojure.lang.Var tmp556_553 = const__75;tmp556_553.setMeta((clojure.lang.IPersistentMap)const__77);tmp556_553.bindRoot(new clojure.pprint.make_nl_t()); clojure.lang.Var tmp580_577 = const__78;tmp580_577.setMeta((clojure.lang.IPersistentMap)const__80);tmp580_577.bindRoot(new clojure.pprint.nl_t_QMARK_()); clojure.lang.Var tmp604_601 = const__81;tmp604_601.setMeta((clojure.lang.IPersistentMap)const__83);tmp604_601
/*     */     
/*  97 */       .bindRoot(((clojure.lang.IFn)const__32.getRawRoot()).invoke(const__57, const__74, const__60, const__61)); clojure.lang.Var tmp676_673 = const__84;tmp676_673.setMeta((clojure.lang.IPersistentMap)const__86);tmp676_673.bindRoot(new clojure.pprint.make_start_block_t()); clojure.lang.Var tmp700_697 = const__87;tmp700_697.setMeta((clojure.lang.IPersistentMap)const__89);tmp700_697.bindRoot(new clojure.pprint.start_block_t_QMARK_()); clojure.lang.Var tmp724_721 = const__90;tmp724_721.setMeta((clojure.lang.IPersistentMap)const__92);tmp724_721
/*     */     
/*  99 */       .bindRoot(((clojure.lang.IFn)const__32.getRawRoot()).invoke(const__57, const__74, const__60, const__61)); clojure.lang.Var tmp796_793 = const__93;tmp796_793.setMeta((clojure.lang.IPersistentMap)const__95);tmp796_793.bindRoot(new clojure.pprint.make_end_block_t()); clojure.lang.Var tmp820_817 = const__96;tmp820_817.setMeta((clojure.lang.IPersistentMap)const__98);tmp820_817.bindRoot(new clojure.pprint.end_block_t_QMARK_()); clojure.lang.Var tmp844_841 = const__99;tmp844_841.setMeta((clojure.lang.IPersistentMap)const__101);tmp844_841
/*     */     
/* 101 */       .bindRoot(((clojure.lang.IFn)const__32.getRawRoot()).invoke(const__57, const__74, const__102, const__103, const__60, const__61)); clojure.lang.Var tmp922_919 = const__104;tmp922_919.setMeta((clojure.lang.IPersistentMap)const__106);tmp922_919.bindRoot(new clojure.pprint.make_indent_t()); clojure.lang.Var tmp946_943 = const__107;tmp946_943.setMeta((clojure.lang.IPersistentMap)const__109);tmp946_943.bindRoot(new clojure.pprint.indent_t_QMARK_()); clojure.lang.Var tmp970_967 = const__110;tmp970_967.setMeta((clojure.lang.IPersistentMap)const__112);tmp970_967
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 107 */       .bindRoot(((clojure.lang.IFn)const__113.getRawRoot()).invoke(new clojure.pprint.fn__8253()));const__114.setMeta((clojure.lang.IPersistentMap)const__116);new clojure.pprint.fn__8257();
/*     */     
/*     */ 
/*     */ 
/* 111 */     new clojure.pprint.fn__8263();
/* 112 */     new clojure.pprint.fn__8270();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 122 */     new clojure.pprint.fn__8275();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 127 */     new clojure.pprint.fn__8279();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 135 */     new clojure.pprint.fn__8282(); clojure.lang.Var 
/*     */     
/*     */ 
/* 138 */       tmp1161_1158 = const__123;tmp1161_1158.setMeta((clojure.lang.IPersistentMap)const__126);tmp1161_1158.bindRoot(new clojure.pprint.write_tokens()); clojure.lang.Var tmp1185_1182 = const__127;tmp1185_1182.setMeta((clojure.lang.IPersistentMap)const__130);tmp1185_1182.bindRoot(new clojure.pprint.tokens_fit_QMARK_()); clojure.lang.Var tmp1209_1206 = const__131;tmp1209_1206.setMeta((clojure.lang.IPersistentMap)const__134);tmp1209_1206.bindRoot(new clojure.pprint.linear_nl_QMARK_()); clojure.lang.Var tmp1233_1230 = const__135;tmp1233_1230.setMeta((clojure.lang.IPersistentMap)const__138);tmp1233_1230.bindRoot(new clojure.pprint.miser_nl_QMARK_());new clojure.pprint.fn__8311();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 186 */     new clojure.pprint.fn__8317();
/*     */     
/* 188 */     new clojure.pprint.fn__8319();
/*     */     
/*     */ 
/*     */ 
/* 192 */     new clojure.pprint.fn__8321();
/*     */     
/*     */ 
/*     */ 
/* 196 */     new clojure.pprint.fn__8325(); clojure.lang.Var 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 202 */       tmp1372_1369 = const__144;tmp1372_1369.setMeta((clojure.lang.IPersistentMap)const__147);tmp1372_1369.bindRoot(new clojure.pprint.get_section()); clojure.lang.Var tmp1396_1393 = const__148;tmp1396_1393.setMeta((clojure.lang.IPersistentMap)const__151);tmp1396_1393.bindRoot(new clojure.pprint.get_sub_section()); clojure.lang.Var tmp1420_1417 = const__152;tmp1420_1417.setMeta((clojure.lang.IPersistentMap)const__155);tmp1420_1417.bindRoot(new clojure.pprint.update_nl_state()); clojure.lang.Var tmp1444_1441 = const__114;tmp1444_1441.setMeta((clojure.lang.IPersistentMap)const__158);tmp1444_1441.bindRoot(new clojure.pprint.emit_nl()); clojure.lang.Var tmp1468_1465 = const__159;tmp1468_1465.setMeta((clojure.lang.IPersistentMap)const__162);tmp1468_1465.bindRoot(new clojure.pprint.split_at_newline());new clojure.pprint.fn__8351();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 253 */     new clojure.pprint.fn__8355();
/* 254 */     new clojure.pprint.fn__8357();
/*     */     
/* 256 */     new clojure.pprint.fn__8359(); clojure.lang.Var 
/*     */     
/* 258 */       tmp1582_1579 = const__165;tmp1582_1579.setMeta((clojure.lang.IPersistentMap)const__168);tmp1582_1579.bindRoot(new clojure.pprint.toks()); clojure.lang.Var tmp1606_1603 = const__169;tmp1606_1603.setMeta((clojure.lang.IPersistentMap)const__172);tmp1606_1603.bindRoot(new clojure.pprint.write_token_string()); clojure.lang.Var tmp1630_1627 = const__173;tmp1630_1627.setMeta((clojure.lang.IPersistentMap)const__176);tmp1630_1627.bindRoot(new clojure.pprint.write_line()); clojure.lang.Var tmp1654_1651 = const__177;tmp1654_1651.setMeta((clojure.lang.IPersistentMap)const__180);tmp1654_1651.bindRoot(new clojure.pprint.add_to_buffer()); clojure.lang.Var tmp1678_1675 = const__181;tmp1678_1675.setMeta((clojure.lang.IPersistentMap)const__184);tmp1678_1675.bindRoot(new clojure.pprint.write_buffered_output()); clojure.lang.Var tmp1702_1699 = const__185;tmp1702_1699.setMeta((clojure.lang.IPersistentMap)const__188);tmp1702_1699.bindRoot(new clojure.pprint.write_white_space()); clojure.lang.Var tmp1726_1723 = const__189;tmp1726_1723.setMeta((clojure.lang.IPersistentMap)const__192);tmp1726_1723.bindRoot(new clojure.pprint.write_initial_lines()); clojure.lang.Var tmp1750_1747 = const__193;tmp1750_1747.setMeta((clojure.lang.IPersistentMap)const__196);tmp1750_1747.bindRoot(new clojure.pprint.p_write_char()); clojure.lang.Var tmp1774_1771 = const__197;tmp1774_1771.setMeta((clojure.lang.IPersistentMap)const__200);tmp1774_1771.bindRoot(new clojure.pprint.pretty_writer()); clojure.lang.Var tmp1798_1795 = const__201;tmp1798_1795.setMeta((clojure.lang.IPersistentMap)const__204);tmp1798_1795.bindRoot(new clojure.pprint.start_block()); clojure.lang.Var tmp1822_1819 = const__205;tmp1822_1819.setMeta((clojure.lang.IPersistentMap)const__208);tmp1822_1819.bindRoot(new clojure.pprint.end_block()); clojure.lang.Var tmp1846_1843 = const__209;tmp1846_1843.setMeta((clojure.lang.IPersistentMap)const__212);tmp1846_1843.bindRoot(new clojure.pprint.nl()); clojure.lang.Var tmp1870_1867 = const__213;tmp1870_1867.setMeta((clojure.lang.IPersistentMap)const__216);tmp1870_1867.bindRoot(new clojure.pprint.indent()); clojure.lang.Var tmp1894_1891 = const__2;tmp1894_1891.setMeta((clojure.lang.IPersistentMap)const__219);tmp1894_1891.bindRoot(new clojure.pprint.get_miser_width()); clojure.lang.Var tmp1918_1915 = const__220;tmp1918_1915.setMeta((clojure.lang.IPersistentMap)const__223);tmp1918_1915.bindRoot(new clojure.pprint.set_miser_width()); clojure.lang.Var tmp1942_1939 = const__224;tmp1942_1939.setMeta((clojure.lang.IPersistentMap)const__227);tmp1942_1939.bindRoot(new clojure.pprint.set_logical_block_callback());
/*     */   }
/*     */   
/*     */   public static final clojure.lang.AFn const__20;
/*     */   public static final clojure.lang.Var const__21;
/*     */   public static final clojure.lang.AFn const__24;
/*     */   public static final clojure.lang.Var const__25;
/*     */   public static final clojure.lang.AFn const__28;
/*     */   public static final clojure.lang.Var const__29;
/*     */   public static final clojure.lang.AFn const__31;
/*     */   public static final clojure.lang.Var const__32;
/*     */   public static final clojure.lang.Keyword const__33;
/*     */   public static final clojure.lang.Keyword const__34;
/*     */   public static final clojure.lang.Keyword const__35;
/*     */   public static final clojure.lang.Keyword const__36;
/*     */   public static final clojure.lang.Keyword const__37;
/*     */   public static final clojure.lang.Keyword const__38;
/*     */   public static final clojure.lang.Keyword const__39;
/*     */   public static final clojure.lang.Keyword const__40;
/*     */   public static final clojure.lang.Keyword const__41;
/*     */   public static final clojure.lang.Keyword const__42;
/*     */   public static final clojure.lang.Var const__43;
/*     */   public static final clojure.lang.AFn const__46;
/*     */   public static final clojure.lang.Var const__47;
/*     */   public static final clojure.lang.AFn const__49;
/*     */   public static final clojure.lang.Var const__50;
/*     */   public static final clojure.lang.AFn const__53;
/*     */   public static final clojure.lang.Var const__54;
/*     */   public static final clojure.lang.AFn const__56;
/*     */   public static final clojure.lang.Keyword const__57;
/*     */   public static final clojure.lang.Keyword const__58;
/*     */   public static final clojure.lang.Keyword const__59;
/*     */   public static final clojure.lang.Keyword const__60;
/*     */   public static final clojure.lang.Keyword const__61;
/*     */   public static final clojure.lang.Var const__62;
/*     */   public static final clojure.lang.Var const__63;
/*     */   public static final clojure.lang.Var const__64;
/*     */   public static final clojure.lang.AFn const__66;
/*     */   public static final clojure.lang.Var const__67;
/*     */   public static final clojure.lang.AFn const__69;
/*     */   public static final clojure.lang.Var const__70;
/*     */   public static final clojure.lang.AFn const__72;
/*     */   public static final clojure.lang.Keyword const__73;
/*     */   public static final clojure.lang.Keyword const__74;
/*     */   public static final clojure.lang.Var const__75;
/*     */   public static final clojure.lang.AFn const__77;
/*     */   public static final clojure.lang.Var const__78;
/*     */   public static final clojure.lang.AFn const__80;
/*     */   public static final clojure.lang.Var const__81;
/*     */   public static final clojure.lang.AFn const__83;
/*     */   public static final clojure.lang.Var const__84;
/*     */   public static final clojure.lang.AFn const__86;
/*     */   public static final clojure.lang.Var const__87;
/*     */   public static final clojure.lang.AFn const__89;
/*     */   public static final clojure.lang.Var const__90;
/*     */   public static final clojure.lang.AFn const__92;
/*     */   public static final clojure.lang.Var const__93;
/*     */   public static final clojure.lang.AFn const__95;
/*     */   public static final clojure.lang.Var const__96;
/*     */   public static final clojure.lang.AFn const__98;
/*     */   public static final clojure.lang.Var const__99;
/*     */   public static final clojure.lang.AFn const__101;
/*     */   public static final clojure.lang.Keyword const__102;
/*     */   public static final clojure.lang.Keyword const__103;
/*     */   public static final clojure.lang.Var const__104;
/*     */   public static final clojure.lang.AFn const__106;
/*     */   public static final clojure.lang.Var const__107;
/*     */   public static final clojure.lang.AFn const__109;
/*     */   public static final clojure.lang.Var const__110;
/*     */   public static final clojure.lang.AFn const__112;
/*     */   public static final clojure.lang.Var const__113;
/*     */   public static final clojure.lang.Var const__114;
/*     */   public static final clojure.lang.AFn const__116;
/*     */   public static final clojure.lang.Var const__117;
/*     */   public static final clojure.lang.Keyword const__118;
/*     */   public static final clojure.lang.Keyword const__119;
/*     */   public static final clojure.lang.Keyword const__120;
/*     */   public static final clojure.lang.Keyword const__121;
/*     */   public static final clojure.lang.Keyword const__122;
/*     */   public static final clojure.lang.Var const__123;
/*     */   public static final clojure.lang.AFn const__126;
/*     */   public static final clojure.lang.Var const__127;
/*     */   public static final clojure.lang.AFn const__130;
/*     */   public static final clojure.lang.Var const__131;
/*     */   public static final clojure.lang.AFn const__134;
/*     */   public static final clojure.lang.Var const__135;
/*     */   public static final clojure.lang.AFn const__138;
/*     */   public static final clojure.lang.Var const__139;
/*     */   public static final clojure.lang.Keyword const__140;
/*     */   public static final clojure.lang.Keyword const__141;
/*     */   public static final clojure.lang.Keyword const__142;
/*     */   public static final clojure.lang.Keyword const__143;
/*     */   public static final clojure.lang.Var const__144;
/*     */   public static final clojure.lang.AFn const__147;
/*     */   public static final clojure.lang.Var const__148;
/*     */   public static final clojure.lang.AFn const__151;
/*     */   public static final clojure.lang.Var const__152;
/*     */   public static final clojure.lang.AFn const__155;
/*     */   public static final clojure.lang.AFn const__158;
/*     */   public static final clojure.lang.Var const__159;
/*     */   public static final clojure.lang.AFn const__162;
/*     */   public static final clojure.lang.Var const__163;
/*     */   public static final clojure.lang.Keyword const__164;
/*     */   public static final clojure.lang.Var const__165;
/*     */   public static final clojure.lang.AFn const__168;
/*     */   public static final clojure.lang.Var const__169;
/*     */   public static final clojure.lang.AFn const__172;
/*     */   public static final clojure.lang.Var const__173;
/*     */   public static final clojure.lang.AFn const__176;
/*     */   public static final clojure.lang.Var const__177;
/*     */   public static final clojure.lang.AFn const__180;
/*     */   public static final clojure.lang.Var const__181;
/*     */   public static final clojure.lang.AFn const__184;
/*     */   public static final clojure.lang.Var const__185;
/*     */   public static final clojure.lang.AFn const__188;
/*     */   public static final clojure.lang.Var const__189;
/*     */   public static final clojure.lang.AFn const__192;
/*     */   public static final clojure.lang.Var const__193;
/*     */   public static final clojure.lang.AFn const__196;
/*     */   public static final clojure.lang.Var const__197;
/*     */   public static final clojure.lang.AFn const__200;
/*     */   public static final clojure.lang.Var const__201;
/*     */   public static final clojure.lang.AFn const__204;
/*     */   public static final clojure.lang.Var const__205;
/*     */   public static final clojure.lang.AFn const__208;
/*     */   public static final clojure.lang.Var const__209;
/*     */   public static final clojure.lang.AFn const__212;
/*     */   public static final clojure.lang.Var const__213;
/*     */   public static final clojure.lang.AFn const__216;
/*     */   public static final clojure.lang.AFn const__219;
/*     */   public static final clojure.lang.Var const__220;
/*     */   public static final clojure.lang.AFn const__223;
/*     */   public static final clojure.lang.Var const__224;
/*     */   public static final clojure.lang.AFn const__227;
/*     */   public static void __init0()
/*     */   {
/*     */     const__0 = (clojure.lang.Var)RT.var("clojure.core", "in-ns");
/*     */     const__1 = (clojure.lang.AFn)clojure.lang.Symbol.intern(null, "clojure.pprint");
/*     */     const__2 = (clojure.lang.Var)RT.var("clojure.pprint", "get-miser-width");
/*     */     const__9 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "declared"), Boolean.TRUE, RT.keyword(null, "line"), Integer.valueOf(30), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pretty_writer.clj" });
/*     */     const__10 = (clojure.lang.Var)RT.var("clojure.pprint", "getf");
/*     */     const__11 = (clojure.lang.Keyword)RT.keyword(null, "private");
/*     */     const__16 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "sym")) })), RT.keyword(null, "doc"), "Get the value of the field named by the argument (which should be a keyword).", RT.keyword(null, "line"), Integer.valueOf(37), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pretty_writer.clj" });
/*     */     const__17 = (clojure.lang.Var)RT.var("clojure.pprint", "setf");
/*     */     const__20 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "sym"), clojure.lang.Symbol.intern(null, "new-val")) })), RT.keyword(null, "line"), Integer.valueOf(43), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pretty_writer.clj" });
/*     */     const__21 = (clojure.lang.Var)RT.var("clojure.pprint", "deftype");
/*     */     const__24 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "type-name"), clojure.lang.Symbol.intern(null, "&"), clojure.lang.Symbol.intern(null, "fields")) })), RT.keyword(null, "line"), Integer.valueOf(48), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pretty_writer.clj" });
/*     */     const__25 = (clojure.lang.Var)RT.var("clojure.pprint", "write-to-base");
/*     */     const__28 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "&"), clojure.lang.Symbol.intern(null, "args")) })), RT.keyword(null, "doc"), "Call .write on Writer (getf :base) with proper type-hinting to\n  avoid reflection.", RT.keyword(null, "line"), Integer.valueOf(58), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pretty_writer.clj" });
/*     */     const__29 = (clojure.lang.Var)RT.var("clojure.pprint", "logical-block");
/*     */     const__31 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "line"), Integer.valueOf(70), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pretty_writer.clj" });
/*     */     const__32 = (clojure.lang.Var)RT.var("clojure.core", "create-struct");
/*     */     const__33 = (clojure.lang.Keyword)RT.keyword(null, "parent");
/*     */     const__34 = (clojure.lang.Keyword)RT.keyword(null, "section");
/*     */     const__35 = (clojure.lang.Keyword)RT.keyword(null, "start-col");
/*     */     const__36 = (clojure.lang.Keyword)RT.keyword(null, "indent");
/*     */     const__37 = (clojure.lang.Keyword)RT.keyword(null, "done-nl");
/*     */     const__38 = (clojure.lang.Keyword)RT.keyword(null, "intra-block-nl");
/*     */     const__39 = (clojure.lang.Keyword)RT.keyword(null, "prefix");
/*     */     const__40 = (clojure.lang.Keyword)RT.keyword(null, "per-line-prefix");
/*     */     const__41 = (clojure.lang.Keyword)RT.keyword(null, "suffix");
/*     */     const__42 = (clojure.lang.Keyword)RT.keyword(null, "logical-block-callback");
/*     */     const__43 = (clojure.lang.Var)RT.var("clojure.pprint", "ancestor?");
/*     */     const__46 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "parent"), clojure.lang.Symbol.intern(null, "child")) })), RT.keyword(null, "line"), Integer.valueOf(76), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pretty_writer.clj" });
/*     */     const__47 = (clojure.lang.Var)RT.var("clojure.pprint", "section");
/*     */     const__49 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "line"), Integer.valueOf(83), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pretty_writer.clj" });
/*     */     const__50 = (clojure.lang.Var)RT.var("clojure.pprint", "buffer-length");
/*     */     const__53 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "l")) })), RT.keyword(null, "line"), Integer.valueOf(85), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pretty_writer.clj" });
/*     */     const__54 = (clojure.lang.Var)RT.var("clojure.pprint", "buffer-blob");
/*     */     const__56 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "line"), Integer.valueOf(92), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pretty_writer.clj" });
/*     */     const__57 = (clojure.lang.Keyword)RT.keyword(null, "type-tag");
/*     */     const__58 = (clojure.lang.Keyword)RT.keyword(null, "data");
/*     */     const__59 = (clojure.lang.Keyword)RT.keyword(null, "trailing-white-space");
/*     */     const__60 = (clojure.lang.Keyword)RT.keyword(null, "start-pos");
/*     */     const__61 = (clojure.lang.Keyword)RT.keyword(null, "end-pos");
/*     */     const__62 = (clojure.lang.Var)RT.var("clojure.core", "alter-meta!");
/*     */     const__63 = (clojure.lang.Var)RT.var("clojure.core", "assoc");
/*     */     const__64 = (clojure.lang.Var)RT.var("clojure.pprint", "make-buffer-blob");
/*     */     const__66 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "&"), clojure.lang.Symbol.intern(null, "vals__8236__auto__")) })), RT.keyword(null, "line"), Integer.valueOf(92), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pretty_writer.clj" });
/*     */     const__67 = (clojure.lang.Var)RT.var("clojure.pprint", "buffer-blob?");
/*     */     const__69 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "x__8237__auto__")) })), RT.keyword(null, "line"), Integer.valueOf(92), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pretty_writer.clj" });
/*     */     const__70 = (clojure.lang.Var)RT.var("clojure.pprint", "nl-t");
/*     */     const__72 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "line"), Integer.valueOf(95), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pretty_writer.clj" });
/*     */     const__73 = (clojure.lang.Keyword)RT.keyword(null, "type");
/*     */     const__74 = (clojure.lang.Keyword)RT.keyword(null, "logical-block");
/*     */     const__75 = (clojure.lang.Var)RT.var("clojure.pprint", "make-nl-t");
/*     */     const__77 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "&"), clojure.lang.Symbol.intern(null, "vals__8236__auto__")) })), RT.keyword(null, "line"), Integer.valueOf(95), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pretty_writer.clj" });
/*     */     const__78 = (clojure.lang.Var)RT.var("clojure.pprint", "nl-t?");
/*     */     const__80 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "x__8237__auto__")) })), RT.keyword(null, "line"), Integer.valueOf(95), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pretty_writer.clj" });
/*     */     const__81 = (clojure.lang.Var)RT.var("clojure.pprint", "start-block-t");
/*     */     const__83 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "line"), Integer.valueOf(97), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pretty_writer.clj" });
/*     */     const__84 = (clojure.lang.Var)RT.var("clojure.pprint", "make-start-block-t");
/*     */     const__86 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "&"), clojure.lang.Symbol.intern(null, "vals__8236__auto__")) })), RT.keyword(null, "line"), Integer.valueOf(97), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pretty_writer.clj" });
/*     */     const__87 = (clojure.lang.Var)RT.var("clojure.pprint", "start-block-t?");
/*     */     const__89 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "x__8237__auto__")) })), RT.keyword(null, "line"), Integer.valueOf(97), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pretty_writer.clj" });
/*     */     const__90 = (clojure.lang.Var)RT.var("clojure.pprint", "end-block-t");
/*     */     const__92 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "line"), Integer.valueOf(99), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pretty_writer.clj" });
/*     */     const__93 = (clojure.lang.Var)RT.var("clojure.pprint", "make-end-block-t");
/*     */     const__95 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "&"), clojure.lang.Symbol.intern(null, "vals__8236__auto__")) })), RT.keyword(null, "line"), Integer.valueOf(99), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pretty_writer.clj" });
/*     */     const__96 = (clojure.lang.Var)RT.var("clojure.pprint", "end-block-t?");
/*     */     const__98 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "x__8237__auto__")) })), RT.keyword(null, "line"), Integer.valueOf(99), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pretty_writer.clj" });
/*     */     const__99 = (clojure.lang.Var)RT.var("clojure.pprint", "indent-t");
/*     */   }
/*     */   
/*     */   public static void __init1()
/*     */   {
/*     */     const__101 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "line"), Integer.valueOf(101), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pretty_writer.clj" });
/*     */     const__102 = (clojure.lang.Keyword)RT.keyword(null, "relative-to");
/*     */     const__103 = (clojure.lang.Keyword)RT.keyword(null, "offset");
/*     */     const__104 = (clojure.lang.Var)RT.var("clojure.pprint", "make-indent-t");
/*     */     const__106 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "&"), clojure.lang.Symbol.intern(null, "vals__8236__auto__")) })), RT.keyword(null, "line"), Integer.valueOf(101), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pretty_writer.clj" });
/*     */     const__107 = (clojure.lang.Var)RT.var("clojure.pprint", "indent-t?");
/*     */     const__109 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "x__8237__auto__")) })), RT.keyword(null, "line"), Integer.valueOf(101), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pretty_writer.clj" });
/*     */     const__110 = (clojure.lang.Var)RT.var("clojure.pprint", "pp-newline");
/*     */     const__112 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "line"), Integer.valueOf(107), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pretty_writer.clj" });
/*     */     const__113 = (clojure.lang.Var)RT.var("clojure.core", "memoize");
/*     */     const__114 = (clojure.lang.Var)RT.var("clojure.pprint", "emit-nl");
/*     */     const__116 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "declared"), Boolean.TRUE, RT.keyword(null, "line"), Integer.valueOf(109), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pretty_writer.clj" });
/*     */     const__117 = (clojure.lang.Var)RT.var("clojure.pprint", "write-token");
/*     */     const__118 = (clojure.lang.Keyword)RT.keyword(null, "start-block-t");
/*     */     const__119 = (clojure.lang.Keyword)RT.keyword(null, "end-block-t");
/*     */     const__120 = (clojure.lang.Keyword)RT.keyword(null, "indent-t");
/*     */     const__121 = (clojure.lang.Keyword)RT.keyword(null, "buffer-blob");
/*     */     const__122 = (clojure.lang.Keyword)RT.keyword(null, "nl-t");
/*     */     const__123 = (clojure.lang.Var)RT.var("clojure.pprint", "write-tokens");
/*     */     const__126 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "this")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "tag"), clojure.lang.Symbol.intern(null, "Writer") })), clojure.lang.Symbol.intern(null, "tokens"), clojure.lang.Symbol.intern(null, "force-trailing-whitespace")) })), RT.keyword(null, "line"), Integer.valueOf(149), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pretty_writer.clj" });
/*     */     const__127 = (clojure.lang.Var)RT.var("clojure.pprint", "tokens-fit?");
/*     */     const__130 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "this")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "tag"), clojure.lang.Symbol.intern(null, "Writer") })), clojure.lang.Symbol.intern(null, "tokens")) })), RT.keyword(null, "line"), Integer.valueOf(167), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pretty_writer.clj" });
/*     */     const__131 = (clojure.lang.Var)RT.var("clojure.pprint", "linear-nl?");
/*     */     const__134 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "this"), clojure.lang.Symbol.intern(null, "lb"), clojure.lang.Symbol.intern(null, "section")) })), RT.keyword(null, "line"), Integer.valueOf(174), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pretty_writer.clj" });
/*     */     const__135 = (clojure.lang.Var)RT.var("clojure.pprint", "miser-nl?");
/*     */     const__138 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "this")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "tag"), clojure.lang.Symbol.intern(null, "Writer") })), clojure.lang.Symbol.intern(null, "lb"), clojure.lang.Symbol.intern(null, "section")) })), RT.keyword(null, "line"), Integer.valueOf(179), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pretty_writer.clj" });
/*     */     const__139 = (clojure.lang.Var)RT.var("clojure.pprint", "emit-nl?");
/*     */     const__140 = (clojure.lang.Keyword)RT.keyword(null, "linear");
/*     */     const__141 = (clojure.lang.Keyword)RT.keyword(null, "miser");
/*     */     const__142 = (clojure.lang.Keyword)RT.keyword(null, "fill");
/*     */     const__143 = (clojure.lang.Keyword)RT.keyword(null, "mandatory");
/*     */     const__144 = (clojure.lang.Var)RT.var("clojure.pprint", "get-section");
/*     */     const__147 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "buffer")) })), RT.keyword(null, "line"), Integer.valueOf(210), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pretty_writer.clj" });
/*     */     const__148 = (clojure.lang.Var)RT.var("clojure.pprint", "get-sub-section");
/*     */     const__151 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "buffer")) })), RT.keyword(null, "line"), Integer.valueOf(217), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pretty_writer.clj" });
/*     */     const__152 = (clojure.lang.Var)RT.var("clojure.pprint", "update-nl-state");
/*     */     const__155 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "lb")) })), RT.keyword(null, "line"), Integer.valueOf(225), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pretty_writer.clj" });
/*     */     const__158 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "this")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "tag"), clojure.lang.Symbol.intern(null, "Writer") })), clojure.lang.Symbol.intern(null, "nl")) })), RT.keyword(null, "line"), Integer.valueOf(235), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pretty_writer.clj" });
/*     */     const__159 = (clojure.lang.Var)RT.var("clojure.pprint", "split-at-newline");
/*     */     const__162 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "tokens")) })), RT.keyword(null, "line"), Integer.valueOf(247), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pretty_writer.clj" });
/*     */     const__163 = (clojure.lang.Var)RT.var("clojure.pprint", "tok");
/*     */     const__164 = (clojure.lang.Keyword)RT.keyword(null, "default");
/*     */     const__165 = (clojure.lang.Var)RT.var("clojure.pprint", "toks");
/*     */     const__168 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "toks")) })), RT.keyword(null, "line"), Integer.valueOf(260), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pretty_writer.clj" });
/*     */     const__169 = (clojure.lang.Var)RT.var("clojure.pprint", "write-token-string");
/*     */     const__172 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "this"), clojure.lang.Symbol.intern(null, "tokens")) })), RT.keyword(null, "line"), Integer.valueOf(265), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pretty_writer.clj" });
/*     */     const__173 = (clojure.lang.Var)RT.var("clojure.pprint", "write-line");
/*     */     const__176 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "this")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "tag"), clojure.lang.Symbol.intern(null, "Writer") }))) })), RT.keyword(null, "line"), Integer.valueOf(295), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pretty_writer.clj" });
/*     */     const__177 = (clojure.lang.Var)RT.var("clojure.pprint", "add-to-buffer");
/*     */     const__180 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "this")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "tag"), clojure.lang.Symbol.intern(null, "Writer") })), clojure.lang.Symbol.intern(null, "token")) })), RT.keyword(null, "line"), Integer.valueOf(308), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pretty_writer.clj" });
/*     */     const__181 = (clojure.lang.Var)RT.var("clojure.pprint", "write-buffered-output");
/*     */     const__184 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "this")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "tag"), clojure.lang.Symbol.intern(null, "Writer") }))) })), RT.keyword(null, "line"), Integer.valueOf(316), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pretty_writer.clj" });
/*     */     const__185 = (clojure.lang.Var)RT.var("clojure.pprint", "write-white-space");
/*     */     const__188 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "this")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "tag"), clojure.lang.Symbol.intern(null, "Writer") }))) })), RT.keyword(null, "line"), Integer.valueOf(323), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pretty_writer.clj" });
/*     */     const__189 = (clojure.lang.Var)RT.var("clojure.pprint", "write-initial-lines");
/*     */     const__192 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "this")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "tag"), clojure.lang.Symbol.intern(null, "Writer") })), ((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "s")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "tag"), clojure.lang.Symbol.intern(null, "String") }))) })), RT.keyword(null, "line"), Integer.valueOf(332), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pretty_writer.clj" });
/*     */     const__193 = (clojure.lang.Var)RT.var("clojure.pprint", "p-write-char");
/*     */     const__196 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "this")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "tag"), clojure.lang.Symbol.intern(null, "Writer") })), ((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "c")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "tag"), clojure.lang.Symbol.intern(null, "Integer") }))) })), RT.keyword(null, "line"), Integer.valueOf(359), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pretty_writer.clj" });
/*     */     const__197 = (clojure.lang.Var)RT.var("clojure.pprint", "pretty-writer");
/*     */   }
/*     */   
/*     */   public static void __init2()
/*     */   {
/*     */     const__200 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "writer"), clojure.lang.Symbol.intern(null, "max-columns"), clojure.lang.Symbol.intern(null, "miser-width")) })), RT.keyword(null, "line"), Integer.valueOf(378), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pretty_writer.clj" });
/*     */     const__201 = (clojure.lang.Var)RT.var("clojure.pprint", "start-block");
/*     */     const__204 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "this")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "tag"), clojure.lang.Symbol.intern(null, "Writer") })), ((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "prefix")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "tag"), clojure.lang.Symbol.intern(null, "String") })), ((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "per-line-prefix")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "tag"), clojure.lang.Symbol.intern(null, "String") })), ((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "suffix")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "tag"), clojure.lang.Symbol.intern(null, "String") }))) })), RT.keyword(null, "line"), Integer.valueOf(441), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pretty_writer.clj" });
/*     */     const__205 = (clojure.lang.Var)RT.var("clojure.pprint", "end-block");
/*     */     const__208 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "this")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "tag"), clojure.lang.Symbol.intern(null, "Writer") }))) })), RT.keyword(null, "line"), Integer.valueOf(463), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pretty_writer.clj" });
/*     */     const__209 = (clojure.lang.Var)RT.var("clojure.pprint", "nl");
/*     */     const__212 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "this")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "tag"), clojure.lang.Symbol.intern(null, "Writer") })), clojure.lang.Symbol.intern(null, "type")) })), RT.keyword(null, "line"), Integer.valueOf(479), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pretty_writer.clj" });
/*     */     const__213 = (clojure.lang.Var)RT.var("clojure.pprint", "indent");
/*     */     const__216 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "this")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "tag"), clojure.lang.Symbol.intern(null, "Writer") })), clojure.lang.Symbol.intern(null, "relative-to"), clojure.lang.Symbol.intern(null, "offset")) })), RT.keyword(null, "line"), Integer.valueOf(485), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pretty_writer.clj" });
/*     */     const__219 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "this")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "tag"), clojure.lang.Symbol.intern(null, "Writer") }))) })), RT.keyword(null, "line"), Integer.valueOf(498), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pretty_writer.clj" });
/*     */     const__220 = (clojure.lang.Var)RT.var("clojure.pprint", "set-miser-width");
/*     */     const__223 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "this")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "tag"), clojure.lang.Symbol.intern(null, "Writer") })), clojure.lang.Symbol.intern(null, "new-miser-width")) })), RT.keyword(null, "line"), Integer.valueOf(501), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pretty_writer.clj" });
/*     */     const__224 = (clojure.lang.Var)RT.var("clojure.pprint", "set-logical-block-callback");
/*     */     const__227 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "this")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "tag"), clojure.lang.Symbol.intern(null, "Writer") })), clojure.lang.Symbol.intern(null, "f")) })), RT.keyword(null, "line"), Integer.valueOf(504), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pretty_writer.clj" });
/*     */   }
/*     */   
/*     */   static
/*     */   {
/*     */     __init0();
/*     */     __init1();
/*     */     __init2();
/*     */     clojure.lang.Compiler.pushNSandLoader(RT.classForName("clojure.pprint.pretty_writer__init").getClassLoader());
/*     */     try
/*     */     {
/*     */       load();
/*     */       clojure.lang.Var.popThreadBindings();
/*     */     }
/*     */     finally
/*     */     {
/*     */       clojure.lang.Var.popThreadBindings();
/*     */       throw finally;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\pprint\pretty_writer__init.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */