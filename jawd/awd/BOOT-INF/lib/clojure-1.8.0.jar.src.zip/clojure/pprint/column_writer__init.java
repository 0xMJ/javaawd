/*    */ package clojure.pprint;
/*    */ 
/*    */ import clojure.lang.RT;
/*    */ 
/*    */ public class column_writer__init {
/*    */   public static final clojure.lang.Var const__0;
/*    */   public static final clojure.lang.AFn const__1;
/*    */   public static final clojure.lang.Var const__2;
/*    */   public static final clojure.lang.AFn const__10;
/*    */   public static final Object const__11;
/*    */   public static final clojure.lang.Var const__12;
/*    */   public static final clojure.lang.AFn const__16;
/*    */   public static final clojure.lang.Var const__17;
/*    */   public static final clojure.lang.AFn const__20;
/*    */   public static final clojure.lang.Var const__21;
/*    */   public static final clojure.lang.AFn const__24;
/*    */   
/* 18 */   public static void load() { clojure.lang.Var tmp58_55 = const__2.setDynamic(true);tmp58_55.setMeta((clojure.lang.IPersistentMap)const__10);tmp58_55.bindRoot(const__11); clojure.lang.Var tmp78_75 = const__12;tmp78_75.setMeta((clojure.lang.IPersistentMap)const__16);tmp78_75.bindRoot(new clojure.pprint.get_field()); clojure.lang.Var tmp102_99 = const__17;tmp102_99.setMeta((clojure.lang.IPersistentMap)const__20);tmp102_99.bindRoot(new clojure.pprint.set_field()); clojure.lang.Var tmp126_123 = const__21;tmp126_123.setMeta((clojure.lang.IPersistentMap)const__24);tmp126_123.bindRoot(new clojure.pprint.get_column()); clojure.lang.Var tmp150_147 = const__25;tmp150_147.setMeta((clojure.lang.IPersistentMap)const__28);tmp150_147.bindRoot(new clojure.pprint.get_line()); clojure.lang.Var tmp174_171 = const__29;tmp174_171.setMeta((clojure.lang.IPersistentMap)const__32);tmp174_171.bindRoot(new clojure.pprint.get_max_column()); clojure.lang.Var tmp198_195 = const__33;tmp198_195.setMeta((clojure.lang.IPersistentMap)const__36);tmp198_195.bindRoot(new clojure.pprint.set_max_column()); clojure.lang.Var tmp222_219 = const__37;tmp222_219.setMeta((clojure.lang.IPersistentMap)const__40);tmp222_219.bindRoot(new clojure.pprint.get_writer()); clojure.lang.Var tmp246_243 = const__41;tmp246_243.setMeta((clojure.lang.IPersistentMap)const__44);tmp246_243.bindRoot(new clojure.pprint.c_write_char()); clojure.lang.Var tmp270_267 = const__45;tmp270_267.setMeta((clojure.lang.IPersistentMap)const__48);tmp270_267.bindRoot(new clojure.pprint.column_writer());
/*    */   }
/*    */   
/*    */   public static final clojure.lang.Var const__25;
/*    */   public static final clojure.lang.AFn const__28;
/*    */   public static final clojure.lang.Var const__29;
/*    */   public static final clojure.lang.AFn const__32;
/*    */   public static final clojure.lang.Var const__33;
/*    */   public static final clojure.lang.AFn const__36;
/*    */   public static final clojure.lang.Var const__37;
/*    */   public static final clojure.lang.AFn const__40;
/*    */   public static final clojure.lang.Var const__41;
/*    */   public static final clojure.lang.AFn const__44;
/*    */   public static final clojure.lang.Var const__45;
/*    */   public static final clojure.lang.AFn const__48;
/*    */   public static void __init0()
/*    */   {
/*    */     const__0 = (clojure.lang.Var)RT.var("clojure.core", "in-ns");
/*    */     const__1 = (clojure.lang.AFn)clojure.lang.Symbol.intern(null, "clojure.pprint");
/*    */     const__2 = (clojure.lang.Var)RT.var("clojure.pprint", "*default-page-width*");
/*    */     const__10 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "dynamic"), Boolean.TRUE, RT.keyword(null, "line"), Integer.valueOf(23), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/column_writer.clj" });
/*    */     const__11 = Long.valueOf(72L);
/*    */     const__12 = (clojure.lang.Var)RT.var("clojure.pprint", "get-field");
/*    */     const__16 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "this")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "tag"), clojure.lang.Symbol.intern(null, "Writer") })), clojure.lang.Symbol.intern(null, "sym")) })), RT.keyword(null, "line"), Integer.valueOf(25), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/column_writer.clj" });
/*    */     const__17 = (clojure.lang.Var)RT.var("clojure.pprint", "set-field");
/*    */     const__20 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "this")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "tag"), clojure.lang.Symbol.intern(null, "Writer") })), clojure.lang.Symbol.intern(null, "sym"), clojure.lang.Symbol.intern(null, "new-val")) })), RT.keyword(null, "line"), Integer.valueOf(28), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/column_writer.clj" });
/*    */     const__21 = (clojure.lang.Var)RT.var("clojure.pprint", "get-column");
/*    */     const__24 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "this")) })), RT.keyword(null, "line"), Integer.valueOf(31), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/column_writer.clj" });
/*    */     const__25 = (clojure.lang.Var)RT.var("clojure.pprint", "get-line");
/*    */     const__28 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "this")) })), RT.keyword(null, "line"), Integer.valueOf(34), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/column_writer.clj" });
/*    */     const__29 = (clojure.lang.Var)RT.var("clojure.pprint", "get-max-column");
/*    */     const__32 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "this")) })), RT.keyword(null, "line"), Integer.valueOf(37), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/column_writer.clj" });
/*    */     const__33 = (clojure.lang.Var)RT.var("clojure.pprint", "set-max-column");
/*    */     const__36 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "this"), clojure.lang.Symbol.intern(null, "new-max")) })), RT.keyword(null, "line"), Integer.valueOf(40), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/column_writer.clj" });
/*    */     const__37 = (clojure.lang.Var)RT.var("clojure.pprint", "get-writer");
/*    */     const__40 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "this")) })), RT.keyword(null, "line"), Integer.valueOf(44), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/column_writer.clj" });
/*    */     const__41 = (clojure.lang.Var)RT.var("clojure.pprint", "c-write-char");
/*    */     const__44 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "this")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "tag"), clojure.lang.Symbol.intern(null, "Writer") })), ((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "c")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "tag"), clojure.lang.Symbol.intern(null, "Integer") }))) })), RT.keyword(null, "line"), Integer.valueOf(47), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/column_writer.clj" });
/*    */     const__45 = (clojure.lang.Var)RT.var("clojure.pprint", "column-writer");
/*    */     const__48 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "writer")), clojure.lang.Tuple.create(((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "writer")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "tag"), clojure.lang.Symbol.intern(null, "Writer") })), clojure.lang.Symbol.intern(null, "max-columns")) })), RT.keyword(null, "line"), Integer.valueOf(55), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/column_writer.clj" });
/*    */   }
/*    */   
/*    */   static
/*    */   {
/*    */     __init0();
/*    */     clojure.lang.Compiler.pushNSandLoader(RT.classForName("clojure.pprint.column_writer__init").getClassLoader());
/*    */     try
/*    */     {
/*    */       load();
/*    */       clojure.lang.Var.popThreadBindings();
/*    */     }
/*    */     finally
/*    */     {
/*    */       clojure.lang.Var.popThreadBindings();
/*    */       throw finally;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\pprint\column_writer__init.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */