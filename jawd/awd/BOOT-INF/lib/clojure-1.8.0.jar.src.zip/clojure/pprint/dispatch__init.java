/*     */ package clojure.pprint;
/*     */ 
/*     */ import clojure.lang.RT;
/*     */ import clojure.lang.Var;
/*     */ 
/*     */ public class dispatch__init
/*     */ {
/*     */   public static final Var const__0;
/*     */   public static final clojure.lang.AFn const__1;
/*     */   public static final Var const__2;
/*     */   public static final clojure.lang.AFn const__12;
/*     */   public static final Var const__13;
/*     */   public static final clojure.lang.AFn const__15;
/*     */   public static final clojure.lang.AFn const__20;
/*     */   
/*     */   public static void load()
/*     */   {
/*  18 */     Var tmp20_17 = const__2;tmp20_17.setMeta((clojure.lang.IPersistentMap)const__12);tmp20_17.bindRoot(new clojure.pprint.use_method()); Var tmp44_41 = const__13;tmp44_41.setMeta((clojure.lang.IPersistentMap)const__15);tmp44_41.bindRoot(const__20); Var tmp64_61 = const__21;tmp64_61.setMeta((clojure.lang.IPersistentMap)const__24);tmp64_61.bindRoot(new clojure.pprint.pprint_reader_macro()); Var tmp88_85 = const__25;tmp88_85.setMeta((clojure.lang.IPersistentMap)const__28);tmp88_85.bindRoot(new clojure.pprint.pprint_simple_list()); Var tmp112_109 = const__29;tmp112_109.setMeta((clojure.lang.IPersistentMap)const__32);tmp112_109.bindRoot(new clojure.pprint.pprint_list()); Var tmp136_133 = const__33;tmp136_133.setMeta((clojure.lang.IPersistentMap)const__36);tmp136_133.bindRoot(new clojure.pprint.pprint_vector()); Var tmp160_157 = const__37;tmp160_157.setMeta((clojure.lang.IPersistentMap)const__39);tmp160_157
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  91 */       .bindRoot(((clojure.lang.IFn)new clojure.pprint.fn__9072()).invoke()); Var tmp192_189 = const__40;tmp192_189.setMeta((clojure.lang.IPersistentMap)const__43);tmp192_189.bindRoot(new clojure.pprint.pprint_map()); Var tmp216_213 = const__44;tmp216_213.setMeta((clojure.lang.IPersistentMap)const__46);tmp216_213
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 109 */       .bindRoot(((clojure.lang.IFn)new clojure.pprint.fn__9086()).invoke()); Var tmp248_245 = const__47;tmp248_245.setMeta((clojure.lang.IPersistentMap)const__49);tmp248_245.bindRoot(const__50); Var tmp268_265 = const__51;tmp268_265.setMeta((clojure.lang.IPersistentMap)const__54);tmp268_265.bindRoot(new clojure.pprint.map_ref_type()); Var tmp292_289 = const__55;tmp292_289.setMeta((clojure.lang.IPersistentMap)const__58);tmp292_289.bindRoot(new clojure.pprint.pprint_ideref()); Var tmp316_313 = const__59;tmp316_313.setMeta((clojure.lang.IPersistentMap)const__61);tmp316_313
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 138 */       .bindRoot(((clojure.lang.IFn)new clojure.pprint.fn__9102()).invoke()); Var tmp348_345 = const__62;tmp348_345.setMeta((clojure.lang.IPersistentMap)const__65);tmp348_345.bindRoot(new clojure.pprint.pprint_simple_default());new clojure.pprint.fn__9111();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 161 */     const__76.setMeta((clojure.lang.IPersistentMap)const__79); Var tmp659_656 = const__80;tmp659_656.setMeta((clojure.lang.IPersistentMap)const__83);tmp659_656.bindRoot(new clojure.pprint.brackets()); Var tmp683_680 = const__84;tmp683_680.setMeta((clojure.lang.IPersistentMap)const__87);tmp683_680.bindRoot(new clojure.pprint.pprint_ns_reference()); Var tmp707_704 = const__88;tmp707_704.setMeta((clojure.lang.IPersistentMap)const__91);tmp707_704.bindRoot(new clojure.pprint.pprint_ns()); Var tmp731_728 = const__92;tmp731_728.setMeta((clojure.lang.IPersistentMap)const__94);tmp731_728
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 247 */       .bindRoot(((clojure.lang.IFn)new clojure.pprint.fn__9186()).invoke()); Var tmp763_760 = const__95;tmp763_760.setMeta((clojure.lang.IPersistentMap)const__98);tmp763_760.bindRoot(new clojure.pprint.single_defn()); Var tmp787_784 = const__99;tmp787_784.setMeta((clojure.lang.IPersistentMap)const__102);tmp787_784.bindRoot(new clojure.pprint.multi_defn()); Var tmp811_808 = const__103;tmp811_808.setMeta((clojure.lang.IPersistentMap)const__106);tmp811_808.bindRoot(new clojure.pprint.pprint_defn()); Var tmp835_832 = const__107;tmp835_832.setMeta((clojure.lang.IPersistentMap)const__110);tmp835_832.bindRoot(new clojure.pprint.pprint_binding_form()); Var tmp859_856 = const__111;tmp859_856.setMeta((clojure.lang.IPersistentMap)const__114);tmp859_856.bindRoot(new clojure.pprint.pprint_let()); Var tmp883_880 = const__115;tmp883_880.setMeta((clojure.lang.IPersistentMap)const__117);tmp883_880
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 324 */       .bindRoot(((clojure.lang.IFn)new clojure.pprint.fn__9259()).invoke()); Var tmp915_912 = const__118;tmp915_912.setMeta((clojure.lang.IPersistentMap)const__121);tmp915_912.bindRoot(new clojure.pprint.pprint_cond()); Var tmp939_936 = const__122;tmp939_936.setMeta((clojure.lang.IPersistentMap)const__125);tmp939_936.bindRoot(new clojure.pprint.pprint_condp()); Var tmp967_964 = const__126.setDynamic(true);tmp967_964.setMeta((clojure.lang.IPersistentMap)const__129);tmp967_964.bindRoot(clojure.lang.PersistentArrayMap.EMPTY); Var tmp987_984 = const__130;tmp987_984.setMeta((clojure.lang.IPersistentMap)const__133);tmp987_984.bindRoot(new clojure.pprint.pprint_anon_func()); Var tmp1011_1008 = const__76;tmp1011_1008.setMeta((clojure.lang.IPersistentMap)const__136);tmp1011_1008.bindRoot(new clojure.pprint.pprint_simple_code_list()); Var tmp1035_1032 = const__137;tmp1035_1032.setMeta((clojure.lang.IPersistentMap)const__140);tmp1035_1032.bindRoot(new clojure.pprint.two_forms()); Var tmp1059_1056 = const__141;tmp1059_1056.setMeta((clojure.lang.IPersistentMap)const__144);tmp1059_1056.bindRoot(new clojure.pprint.add_core_ns()); Var tmp1087_1084 = const__145.setDynamic(true);tmp1087_1084.setMeta((clojure.lang.IPersistentMap)const__147);tmp1087_1084
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 420 */       .bindRoot(((clojure.lang.IFn)const__137.getRawRoot()).invoke(
/* 421 */       ((clojure.lang.IFn)const__141.getRawRoot()).invoke(RT.mapUniqueKeys(new Object[] { const__148, const__92.getRawRoot(), const__149, const__130.getRawRoot(), const__150, const__111.getRawRoot(), const__151, const__115.getRawRoot(), const__152, const__122.getRawRoot(), const__153, const__92.getRawRoot(), const__154, const__103.getRawRoot(), const__155, const__103.getRawRoot(), const__156, const__111.getRawRoot(), const__157, const__92.getRawRoot(), const__158, const__111.getRawRoot(), const__159, const__115.getRawRoot(), const__160, const__115.getRawRoot(), const__161, const__92.getRawRoot(), const__162, const__115.getRawRoot(), const__163, const__111.getRawRoot(), const__164, const__111.getRawRoot(), const__165, const__92.getRawRoot(), const__166, const__111.getRawRoot(), const__167, const__88.getRawRoot(), const__168, const__111.getRawRoot(), const__169, const__118.getRawRoot(), const__170, const__111.getRawRoot(), const__171, const__103.getRawRoot(), const__172, const__103.getRawRoot(), const__173, const__92.getRawRoot(), const__174, const__92.getRawRoot(), const__175, const__111.getRawRoot(), const__176, const__111.getRawRoot(), const__177, const__92.getRawRoot() })))); Var tmp1644_1641 = const__178;tmp1644_1641.setMeta((clojure.lang.IPersistentMap)const__181);tmp1644_1641.bindRoot(new clojure.pprint.pprint_code_list()); Var tmp1668_1665 = const__182;tmp1668_1665.setMeta((clojure.lang.IPersistentMap)const__185);tmp1668_1665.bindRoot(new clojure.pprint.pprint_code_symbol());new clojure.pprint.fn__9325();
/*     */   }
/*     */   
/*     */   public static final Var const__21;
/*     */   public static final clojure.lang.AFn const__24;
/*     */   public static final Var const__25;
/*     */   public static final clojure.lang.AFn const__28;
/*     */   public static final Var const__29;
/*     */   public static final clojure.lang.AFn const__32;
/*     */   public static final Var const__33;
/*     */   public static final clojure.lang.AFn const__36;
/*     */   public static final Var const__37;
/*     */   public static final clojure.lang.AFn const__39;
/*     */   public static final Var const__40;
/*     */   public static final clojure.lang.AFn const__43;
/*     */   public static final Var const__44;
/*     */   public static final clojure.lang.AFn const__46;
/*     */   public static final Var const__47;
/*     */   public static final clojure.lang.AFn const__49;
/*     */   public static final clojure.lang.AFn const__50;
/*     */   public static final Var const__51;
/*     */   public static final clojure.lang.AFn const__54;
/*     */   public static final Var const__55;
/*     */   public static final clojure.lang.AFn const__58;
/*     */   public static final Var const__59;
/*     */   public static final clojure.lang.AFn const__61;
/*     */   public static final Var const__62;
/*     */   public static final clojure.lang.AFn const__65;
/*     */   public static final Var const__66;
/*     */   public static final Object const__67;
/*     */   public static final Object const__68;
/*     */   public static final Object const__69;
/*     */   public static final Object const__70;
/*     */   public static final Object const__71;
/*     */   public static final Object const__72;
/*     */   public static final Object const__73;
/*     */   public static final Var const__74;
/*     */   public static final clojure.lang.Keyword const__75;
/*     */   public static final Var const__76;
/*     */   public static final clojure.lang.AFn const__79;
/*     */   public static final Var const__80;
/*     */   public static final clojure.lang.AFn const__83;
/*     */   public static final Var const__84;
/*     */   public static final clojure.lang.AFn const__87;
/*     */   public static final Var const__88;
/*     */   public static final clojure.lang.AFn const__91;
/*     */   public static final Var const__92;
/*     */   public static final clojure.lang.AFn const__94;
/*     */   public static final Var const__95;
/*     */   public static final clojure.lang.AFn const__98;
/*     */   public static final Var const__99;
/*     */   public static final clojure.lang.AFn const__102;
/*     */   public static final Var const__103;
/*     */   public static final clojure.lang.AFn const__106;
/*     */   public static final Var const__107;
/*     */   public static final clojure.lang.AFn const__110;
/*     */   public static final Var const__111;
/*     */   public static final clojure.lang.AFn const__114;
/*     */   public static final Var const__115;
/*     */   public static final clojure.lang.AFn const__117;
/*     */   public static final Var const__118;
/*     */   public static final clojure.lang.AFn const__121;
/*     */   public static final Var const__122;
/*     */   public static final clojure.lang.AFn const__125;
/*     */   public static final Var const__126;
/*     */   public static final clojure.lang.AFn const__129;
/*     */   public static final Var const__130;
/*     */   public static final clojure.lang.AFn const__133;
/*     */   public static final clojure.lang.AFn const__136;
/*     */   public static final Var const__137;
/*     */   public static final clojure.lang.AFn const__140;
/*     */   public static final Var const__141;
/*     */   public static final clojure.lang.AFn const__144;
/*     */   public static final Var const__145;
/*     */   public static final clojure.lang.AFn const__147;
/*     */   public static final clojure.lang.AFn const__148;
/*     */   public static final clojure.lang.AFn const__149;
/*     */   public static final clojure.lang.AFn const__150;
/*     */   public static final clojure.lang.AFn const__151;
/*     */   public static final clojure.lang.AFn const__152;
/*     */   public static final clojure.lang.AFn const__153;
/*     */   public static final clojure.lang.AFn const__154;
/*     */   public static final clojure.lang.AFn const__155;
/*     */   public static final clojure.lang.AFn const__156;
/*     */   public static final clojure.lang.AFn const__157;
/*     */   public static final clojure.lang.AFn const__158;
/*     */   public static final clojure.lang.AFn const__159;
/*     */   public static final clojure.lang.AFn const__160;
/*     */   public static final clojure.lang.AFn const__161;
/*     */   public static final clojure.lang.AFn const__162;
/*     */   public static final clojure.lang.AFn const__163;
/*     */   public static final clojure.lang.AFn const__164;
/*     */   public static final clojure.lang.AFn const__165;
/*     */   public static final clojure.lang.AFn const__166;
/*     */   public static final clojure.lang.AFn const__167;
/*     */   public static final clojure.lang.AFn const__168;
/*     */   public static final clojure.lang.AFn const__169;
/*     */   public static final clojure.lang.AFn const__170;
/*     */   public static final clojure.lang.AFn const__171;
/*     */   public static final clojure.lang.AFn const__172;
/*     */   public static final clojure.lang.AFn const__173;
/*     */   public static final clojure.lang.AFn const__174;
/*     */   public static final clojure.lang.AFn const__175;
/*     */   public static final clojure.lang.AFn const__176;
/*     */   public static final clojure.lang.AFn const__177;
/*     */   public static final Var const__178;
/*     */   public static final clojure.lang.AFn const__181;
/*     */   public static final Var const__182;
/*     */   public static final clojure.lang.AFn const__185;
/*     */   public static final Var const__186;
/*     */   public static final Object const__187;
/*     */   public static final Var const__188;
/*     */   public static void __init0()
/*     */   {
/*     */     const__0 = (Var)RT.var("clojure.core", "in-ns");
/*     */     const__1 = (clojure.lang.AFn)clojure.lang.Symbol.intern(null, "clojure.pprint");
/*     */     const__2 = (Var)RT.var("clojure.pprint", "use-method");
/*     */     const__12 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "multifn")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "tag"), clojure.lang.Symbol.intern(null, "clojure.lang.MultiFn") })), clojure.lang.Symbol.intern(null, "dispatch-val"), clojure.lang.Symbol.intern(null, "func")) })), RT.keyword(null, "doc"), "Installs a function as a new method of multimethod associated with dispatch-value. ", RT.keyword(null, "line"), Integer.valueOf(20), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/dispatch.clj" });
/*     */     const__13 = (Var)RT.var("clojure.pprint", "reader-macros");
/*     */     const__15 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "line"), Integer.valueOf(45), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/dispatch.clj" });
/*     */     const__20 = (clojure.lang.AFn)RT.map(new Object[] { clojure.lang.Symbol.intern(null, "quote"), "'", clojure.lang.Symbol.intern("clojure.core", "deref"), "@", clojure.lang.Symbol.intern(null, "var"), "#'", clojure.lang.Symbol.intern("clojure.core", "unquote"), "~" });
/*     */     const__21 = (Var)RT.var("clojure.pprint", "pprint-reader-macro");
/*     */     const__24 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "alis")) })), RT.keyword(null, "line"), Integer.valueOf(49), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/dispatch.clj" });
/*     */     const__25 = (Var)RT.var("clojure.pprint", "pprint-simple-list");
/*     */     const__28 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "alis")) })), RT.keyword(null, "line"), Integer.valueOf(66), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/dispatch.clj" });
/*     */     const__29 = (Var)RT.var("clojure.pprint", "pprint-list");
/*     */     const__32 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "alis")) })), RT.keyword(null, "line"), Integer.valueOf(76), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/dispatch.clj" });
/*     */     const__33 = (Var)RT.var("clojure.pprint", "pprint-vector");
/*     */     const__36 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "avec")) })), RT.keyword(null, "line"), Integer.valueOf(81), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/dispatch.clj" });
/*     */     const__37 = (Var)RT.var("clojure.pprint", "pprint-array");
/*     */     const__39 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "line"), Integer.valueOf(91), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/dispatch.clj" });
/*     */     const__40 = (Var)RT.var("clojure.pprint", "pprint-map");
/*     */     const__43 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "amap")) })), RT.keyword(null, "line"), Integer.valueOf(94), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/dispatch.clj" });
/*     */     const__44 = (Var)RT.var("clojure.pprint", "pprint-set");
/*     */     const__46 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "line"), Integer.valueOf(109), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/dispatch.clj" });
/*     */     const__47 = (Var)RT.var("clojure.pprint", "type-map");
/*     */     const__49 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "line"), Integer.valueOf(111), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/dispatch.clj" });
/*     */     const__50 = (clojure.lang.AFn)RT.map(new Object[] { "core$future_call", "Future", "core$promise", "Promise" });
/*     */     const__51 = (Var)RT.var("clojure.pprint", "map-ref-type");
/*     */     const__54 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "name")) })), RT.keyword(null, "doc"), "Map ugly type names to something simpler", RT.keyword(null, "line"), Integer.valueOf(115), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/dispatch.clj" });
/*     */     const__55 = (Var)RT.var("clojure.pprint", "pprint-ideref");
/*     */     const__58 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "o")) })), RT.keyword(null, "line"), Integer.valueOf(122), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/dispatch.clj" });
/*     */     const__59 = (Var)RT.var("clojure.pprint", "pprint-pqueue");
/*     */     const__61 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "line"), Integer.valueOf(138), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/dispatch.clj" });
/*     */     const__62 = (Var)RT.var("clojure.pprint", "pprint-simple-default");
/*     */     const__65 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "obj")) })), RT.keyword(null, "line"), Integer.valueOf(140), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/dispatch.clj" });
/*     */     const__66 = (Var)RT.var("clojure.pprint", "simple-dispatch");
/*     */     const__67 = RT.classForName("clojure.lang.ISeq");
/*     */     const__68 = RT.classForName("clojure.lang.IPersistentVector");
/*     */     const__69 = RT.classForName("clojure.lang.IPersistentMap");
/*     */     const__70 = RT.classForName("clojure.lang.IPersistentSet");
/*     */     const__71 = RT.classForName("clojure.lang.PersistentQueue");
/*     */     const__72 = RT.classForName("clojure.lang.Var");
/*     */     const__73 = RT.classForName("clojure.lang.IDeref");
/*     */     const__74 = (Var)RT.var("clojure.core", "pr");
/*     */     const__75 = (clojure.lang.Keyword)RT.keyword(null, "default");
/*     */     const__76 = (Var)RT.var("clojure.pprint", "pprint-simple-code-list");
/*     */     const__79 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "declared"), Boolean.TRUE, RT.keyword(null, "line"), Integer.valueOf(167), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/dispatch.clj" });
/*     */     const__80 = (Var)RT.var("clojure.pprint", "brackets");
/*     */     const__83 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "form")) })), RT.keyword(null, "doc"), "Figure out which kind of brackets to use", RT.keyword(null, "line"), Integer.valueOf(175), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/dispatch.clj" });
/*     */     const__84 = (Var)RT.var("clojure.pprint", "pprint-ns-reference");
/*     */     const__87 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "reference")) })), RT.keyword(null, "doc"), "Pretty print a single reference (import, use, etc.) from a namespace decl", RT.keyword(null, "line"), Integer.valueOf(182), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/dispatch.clj" });
/*     */     const__88 = (Var)RT.var("clojure.pprint", "pprint-ns");
/*     */     const__91 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "alis")) })), RT.keyword(null, "doc"), "The pretty print dispatch chunk for the ns macro", RT.keyword(null, "line"), Integer.valueOf(216), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/dispatch.clj" });
/*     */     const__92 = (Var)RT.var("clojure.pprint", "pprint-hold-first");
/*     */     const__94 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "line"), Integer.valueOf(247), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/dispatch.clj" });
/*     */     const__95 = (Var)RT.var("clojure.pprint", "single-defn");
/*     */     const__98 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "alis"), clojure.lang.Symbol.intern(null, "has-doc-str?")) })), RT.keyword(null, "line"), Integer.valueOf(254), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/dispatch.clj" });
/*     */     const__99 = (Var)RT.var("clojure.pprint", "multi-defn");
/*     */   }
/*     */   
/*     */   public static void __init1()
/*     */   {
/*     */     const__102 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "alis"), clojure.lang.Symbol.intern(null, "has-doc-str?")) })), RT.keyword(null, "line"), Integer.valueOf(263), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/dispatch.clj" });
/*     */     const__103 = (Var)RT.var("clojure.pprint", "pprint-defn");
/*     */     const__106 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "alis")) })), RT.keyword(null, "line"), Integer.valueOf(269), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/dispatch.clj" });
/*     */     const__107 = (Var)RT.var("clojure.pprint", "pprint-binding-form");
/*     */     const__110 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "binding-vec")) })), RT.keyword(null, "line"), Integer.valueOf(294), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/dispatch.clj" });
/*     */     const__111 = (Var)RT.var("clojure.pprint", "pprint-let");
/*     */     const__114 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "alis")) })), RT.keyword(null, "line"), Integer.valueOf(309), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/dispatch.clj" });
/*     */     const__115 = (Var)RT.var("clojure.pprint", "pprint-if");
/*     */     const__117 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "line"), Integer.valueOf(324), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/dispatch.clj" });
/*     */     const__118 = (Var)RT.var("clojure.pprint", "pprint-cond");
/*     */     const__121 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "alis")) })), RT.keyword(null, "line"), Integer.valueOf(326), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/dispatch.clj" });
/*     */     const__122 = (Var)RT.var("clojure.pprint", "pprint-condp");
/*     */     const__125 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "alis")) })), RT.keyword(null, "line"), Integer.valueOf(346), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/dispatch.clj" });
/*     */     const__126 = (Var)RT.var("clojure.pprint", "*symbol-map*");
/*     */     const__129 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "dynamic"), Boolean.TRUE, RT.keyword(null, "line"), Integer.valueOf(366), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/dispatch.clj" });
/*     */     const__130 = (Var)RT.var("clojure.pprint", "pprint-anon-func");
/*     */     const__133 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "alis")) })), RT.keyword(null, "line"), Integer.valueOf(368), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/dispatch.clj" });
/*     */     const__136 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "alis")) })), RT.keyword(null, "line"), Integer.valueOf(390), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/dispatch.clj" });
/*     */     const__137 = (Var)RT.var("clojure.pprint", "two-forms");
/*     */     const__140 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "amap")) })), RT.keyword(null, "line"), Integer.valueOf(403), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/dispatch.clj" });
/*     */     const__141 = (Var)RT.var("clojure.pprint", "add-core-ns");
/*     */     const__144 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "amap")) })), RT.keyword(null, "line"), Integer.valueOf(410), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/dispatch.clj" });
/*     */     const__145 = (Var)RT.var("clojure.pprint", "*code-table*");
/*     */     const__147 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "dynamic"), Boolean.TRUE, RT.keyword(null, "line"), Integer.valueOf(419), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/dispatch.clj" });
/*     */     const__148 = (clojure.lang.AFn)clojure.lang.Symbol.intern(null, ".");
/*     */     const__149 = (clojure.lang.AFn)clojure.lang.Symbol.intern(null, "fn*");
/*     */     const__150 = (clojure.lang.AFn)clojure.lang.Symbol.intern(null, "when-first");
/*     */     const__151 = (clojure.lang.AFn)clojure.lang.Symbol.intern(null, "if");
/*     */     const__152 = (clojure.lang.AFn)clojure.lang.Symbol.intern(null, "condp");
/*     */     const__153 = (clojure.lang.AFn)clojure.lang.Symbol.intern(null, "..");
/*     */     const__154 = (clojure.lang.AFn)clojure.lang.Symbol.intern(null, "defmacro");
/*     */     const__155 = (clojure.lang.AFn)clojure.lang.Symbol.intern(null, "defn");
/*     */     const__156 = (clojure.lang.AFn)clojure.lang.Symbol.intern(null, "loop");
/*     */     const__157 = (clojure.lang.AFn)clojure.lang.Symbol.intern(null, "struct");
/*     */     const__158 = (clojure.lang.AFn)clojure.lang.Symbol.intern(null, "doseq");
/*     */     const__159 = (clojure.lang.AFn)clojure.lang.Symbol.intern(null, "if-not");
/*     */     const__160 = (clojure.lang.AFn)clojure.lang.Symbol.intern(null, "when-not");
/*     */     const__161 = (clojure.lang.AFn)clojure.lang.Symbol.intern(null, "def");
/*     */     const__162 = (clojure.lang.AFn)clojure.lang.Symbol.intern(null, "when");
/*     */     const__163 = (clojure.lang.AFn)clojure.lang.Symbol.intern(null, "with-open");
/*     */     const__164 = (clojure.lang.AFn)clojure.lang.Symbol.intern(null, "with-local-vars");
/*     */     const__165 = (clojure.lang.AFn)clojure.lang.Symbol.intern(null, "defonce");
/*     */     const__166 = (clojure.lang.AFn)clojure.lang.Symbol.intern(null, "when-let");
/*     */     const__167 = (clojure.lang.AFn)clojure.lang.Symbol.intern(null, "ns");
/*     */     const__168 = (clojure.lang.AFn)clojure.lang.Symbol.intern(null, "dotimes");
/*     */     const__169 = (clojure.lang.AFn)clojure.lang.Symbol.intern(null, "cond");
/*     */     const__170 = (clojure.lang.AFn)clojure.lang.Symbol.intern(null, "let");
/*     */     const__171 = (clojure.lang.AFn)clojure.lang.Symbol.intern(null, "fn");
/*     */     const__172 = (clojure.lang.AFn)clojure.lang.Symbol.intern(null, "defn-");
/*     */     const__173 = (clojure.lang.AFn)clojure.lang.Symbol.intern(null, "locking");
/*     */     const__174 = (clojure.lang.AFn)clojure.lang.Symbol.intern(null, "->");
/*     */     const__175 = (clojure.lang.AFn)clojure.lang.Symbol.intern(null, "if-let");
/*     */     const__176 = (clojure.lang.AFn)clojure.lang.Symbol.intern(null, "binding");
/*     */     const__177 = (clojure.lang.AFn)clojure.lang.Symbol.intern(null, "struct-map");
/*     */     const__178 = (Var)RT.var("clojure.pprint", "pprint-code-list");
/*     */     const__181 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "alis")) })), RT.keyword(null, "line"), Integer.valueOf(436), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/dispatch.clj" });
/*     */     const__182 = (Var)RT.var("clojure.pprint", "pprint-code-symbol");
/*     */     const__185 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "sym")) })), RT.keyword(null, "line"), Integer.valueOf(442), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/dispatch.clj" });
/*     */     const__186 = (Var)RT.var("clojure.pprint", "code-dispatch");
/*     */     const__187 = RT.classForName("clojure.lang.Symbol");
/*     */     const__188 = (Var)RT.var("clojure.pprint", "set-pprint-dispatch");
/*     */   }
/*     */   
/*     */   static
/*     */   {
/*     */     __init0();
/*     */     __init1();
/*     */     clojure.lang.Compiler.pushNSandLoader(RT.classForName("clojure.pprint.dispatch__init").getClassLoader());
/*     */     try
/*     */     {
/*     */       load();
/*     */       Var.popThreadBindings();
/*     */     }
/*     */     finally
/*     */     {
/*     */       Var.popThreadBindings();
/*     */       throw finally;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\pprint\dispatch__init.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */