package clojure.pprint;

public abstract interface PrettyFlush
{
  public abstract void ppflush();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\pprint\PrettyFlush.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */