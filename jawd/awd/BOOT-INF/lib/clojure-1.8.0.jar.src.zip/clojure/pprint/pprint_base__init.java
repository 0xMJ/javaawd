/*     */ package clojure.pprint;
/*     */ 
/*     */ import clojure.lang.RT;
/*     */ 
/*     */ public class pprint_base__init {
/*     */   public static final clojure.lang.Var const__0;
/*     */   public static final clojure.lang.AFn const__1;
/*     */   public static final clojure.lang.Var const__2;
/*     */   public static final clojure.lang.AFn const__11;
/*     */   public static final clojure.lang.Var const__12;
/*     */   public static final clojure.lang.AFn const__14;
/*     */   public static final Object const__15;
/*     */   public static final clojure.lang.Var const__16;
/*     */   public static final clojure.lang.AFn const__18;
/*     */   
/*     */   public static void load() {
/*  17 */     clojure.lang.Var tmp24_21 = const__2.setDynamic(true);tmp24_21.setMeta((clojure.lang.IPersistentMap)const__11);tmp24_21.bindRoot(Boolean.TRUE);new clojure.pprint.fn__8443(); clojure.lang.Var 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  34 */       tmp63_60 = const__12.setDynamic(true);tmp63_60.setMeta((clojure.lang.IPersistentMap)const__14);tmp63_60.bindRoot(const__15); clojure.lang.Var tmp87_84 = const__16.setDynamic(true);tmp87_84.setMeta((clojure.lang.IPersistentMap)const__18);tmp87_84.bindRoot(const__19); clojure.lang.Var tmp111_108 = const__20.setDynamic(true);tmp111_108.setMeta((clojure.lang.IPersistentMap)const__23);tmp111_108.bindRoot(null); clojure.lang.Var tmp133_130 = const__24.setDynamic(true);tmp133_130.setMeta((clojure.lang.IPersistentMap)const__26);tmp133_130.bindRoot(null); clojure.lang.Var tmp155_152 = const__27.setDynamic(true);tmp155_152.setMeta((clojure.lang.IPersistentMap)const__29);tmp155_152.bindRoot(null); clojure.lang.Var tmp177_174 = const__30.setDynamic(true);tmp177_174.setMeta((clojure.lang.IPersistentMap)const__32);tmp177_174.bindRoot(null); clojure.lang.Var tmp199_196 = const__33.setDynamic(true);tmp199_196.setMeta((clojure.lang.IPersistentMap)const__35);tmp199_196.bindRoot(null); clojure.lang.Var tmp221_218 = const__36.setDynamic(true);tmp221_218.setMeta((clojure.lang.IPersistentMap)const__38);tmp221_218.bindRoot(const__39); clojure.lang.Var tmp245_242 = const__40.setDynamic(true);tmp245_242.setMeta((clojure.lang.IPersistentMap)const__42);tmp245_242.bindRoot(const__43); clojure.lang.Var tmp269_266 = const__44.setDynamic(true);tmp269_266.setMeta((clojure.lang.IPersistentMap)const__46);tmp269_266.bindRoot(null);const__47.setMeta((clojure.lang.IPersistentMap)const__50); clojure.lang.Var tmp300_297 = const__51;tmp300_297.setMeta((clojure.lang.IPersistentMap)const__53);tmp300_297.bindRoot(const__54.get()); clojure.lang.Var tmp323_320 = const__55;tmp323_320.setMeta((clojure.lang.IPersistentMap)const__59);tmp323_320.bindRoot(new clojure.pprint.pr_with_base()); clojure.lang.Var tmp347_344 = const__60;tmp347_344.setMeta((clojure.lang.IPersistentMap)const__62);tmp347_344.bindRoot(const__87); clojure.lang.Var tmp367_364 = const__88;tmp367_364.setMeta((clojure.lang.IPersistentMap)const__91);tmp367_364.bindRoot(new clojure.pprint.binding_map());((clojure.lang.Var)const__88)
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 137 */       .setMacro(); clojure.lang.Var tmp404_401 = const__92;tmp404_401.setMeta((clojure.lang.IPersistentMap)const__95);tmp404_401.bindRoot(new clojure.pprint.table_ize()); clojure.lang.Var tmp428_425 = const__96;tmp428_425.setMeta((clojure.lang.IPersistentMap)const__99);tmp428_425.bindRoot(new clojure.pprint.pretty_writer_QMARK_()); clojure.lang.Var tmp452_449 = const__100;tmp452_449.setMeta((clojure.lang.IPersistentMap)const__103);tmp452_449.bindRoot(new clojure.pprint.make_pretty_writer()); clojure.lang.Var tmp476_473 = const__104;tmp476_473.setMeta((clojure.lang.IPersistentMap)const__107);tmp476_473.bindRoot(new clojure.pprint.with_pretty_writer());((clojure.lang.Var)const__104)
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 160 */       .setMacro(); clojure.lang.Var tmp513_510 = const__108;tmp513_510.setMeta((clojure.lang.IPersistentMap)const__111);tmp513_510.bindRoot(new clojure.pprint.write_out()); clojure.lang.Var tmp537_534 = const__112;tmp537_534.setMeta((clojure.lang.IPersistentMap)const__115);tmp537_534.bindRoot(new clojure.pprint.write()); clojure.lang.Var tmp561_558 = const__116;tmp561_558.setMeta((clojure.lang.IPersistentMap)const__119);tmp561_558.bindRoot(new clojure.pprint.pprint()); clojure.lang.Var tmp585_582 = const__120;tmp585_582.setMeta((clojure.lang.IPersistentMap)const__123);tmp585_582.bindRoot(new clojure.pprint.pp());((clojure.lang.Var)const__120)
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 254 */       .setMacro(); clojure.lang.Var tmp622_619 = const__124;tmp622_619.setMeta((clojure.lang.IPersistentMap)const__127);tmp622_619.bindRoot(new clojure.pprint.set_pprint_dispatch()); clojure.lang.Var tmp646_643 = const__128;tmp646_643.setMeta((clojure.lang.IPersistentMap)const__131);tmp646_643.bindRoot(new clojure.pprint.with_pprint_dispatch());((clojure.lang.Var)const__128)
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 274 */       .setMacro(); clojure.lang.Var tmp683_680 = const__132;tmp683_680.setMeta((clojure.lang.IPersistentMap)const__135);tmp683_680.bindRoot(new clojure.pprint.parse_lb_options()); clojure.lang.Var tmp707_704 = const__136;tmp707_704.setMeta((clojure.lang.IPersistentMap)const__139);tmp707_704.bindRoot(new clojure.pprint.check_enumerated_arg()); clojure.lang.Var tmp731_728 = const__140;tmp731_728.setMeta((clojure.lang.IPersistentMap)const__143);tmp731_728.bindRoot(new clojure.pprint.level_exceeded()); clojure.lang.Var tmp755_752 = const__144;tmp755_752.setMeta((clojure.lang.IPersistentMap)const__147);tmp755_752.bindRoot(new clojure.pprint.pprint_logical_block());((clojure.lang.Var)const__144)
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 302 */       .setMacro(); clojure.lang.Var tmp792_789 = const__148;tmp792_789.setMeta((clojure.lang.IPersistentMap)const__151);tmp792_789.bindRoot(new clojure.pprint.pprint_newline()); clojure.lang.Var tmp816_813 = const__152;tmp816_813.setMeta((clojure.lang.IPersistentMap)const__155);tmp816_813.bindRoot(new clojure.pprint.pprint_indent()); clojure.lang.Var tmp840_837 = const__156;tmp840_837.setMeta((clojure.lang.IPersistentMap)const__159);tmp840_837.bindRoot(new clojure.pprint.pprint_tab()); clojure.lang.Var tmp864_861 = const__160;tmp864_861.setMeta((clojure.lang.IPersistentMap)const__163);tmp864_861.bindRoot(new clojure.pprint.pll_mod_body()); clojure.lang.Var tmp888_885 = const__164;tmp888_885.setMeta((clojure.lang.IPersistentMap)const__167);tmp888_885.bindRoot(new clojure.pprint.print_length_loop());((clojure.lang.Var)const__164)
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 391 */       .setMacro();
/*     */   }
/*     */   
/*     */   public static final Object const__19;
/*     */   public static final clojure.lang.Var const__20;
/*     */   public static final clojure.lang.AFn const__23;
/*     */   public static final clojure.lang.Var const__24;
/*     */   public static final clojure.lang.AFn const__26;
/*     */   public static final clojure.lang.Var const__27;
/*     */   public static final clojure.lang.AFn const__29;
/*     */   public static final clojure.lang.Var const__30;
/*     */   public static final clojure.lang.AFn const__32;
/*     */   public static final clojure.lang.Var const__33;
/*     */   public static final clojure.lang.AFn const__35;
/*     */   public static final clojure.lang.Var const__36;
/*     */   public static final clojure.lang.AFn const__38;
/*     */   public static final Object const__39;
/*     */   public static final clojure.lang.Var const__40;
/*     */   public static final clojure.lang.AFn const__42;
/*     */   public static final Object const__43;
/*     */   public static final clojure.lang.Var const__44;
/*     */   public static final clojure.lang.AFn const__46;
/*     */   public static final clojure.lang.Var const__47;
/*     */   public static final clojure.lang.AFn const__50;
/*     */   public static final clojure.lang.Var const__51;
/*     */   public static final clojure.lang.AFn const__53;
/*     */   public static final clojure.lang.Var const__54;
/*     */   public static final clojure.lang.Var const__55;
/*     */   public static final clojure.lang.AFn const__59;
/*     */   public static final clojure.lang.Var const__60;
/*     */   public static final clojure.lang.AFn const__62;
/*     */   public static final clojure.lang.AFn const__87;
/*     */   public static final clojure.lang.Var const__88;
/*     */   public static final clojure.lang.AFn const__91;
/*     */   public static final clojure.lang.Var const__92;
/*     */   public static final clojure.lang.AFn const__95;
/*     */   public static final clojure.lang.Var const__96;
/*     */   public static final clojure.lang.AFn const__99;
/*     */   public static final clojure.lang.Var const__100;
/*     */   public static final clojure.lang.AFn const__103;
/*     */   public static final clojure.lang.Var const__104;
/*     */   public static final clojure.lang.AFn const__107;
/*     */   public static final clojure.lang.Var const__108;
/*     */   public static final clojure.lang.AFn const__111;
/*     */   public static final clojure.lang.Var const__112;
/*     */   public static final clojure.lang.AFn const__115;
/*     */   public static final clojure.lang.Var const__116;
/*     */   public static final clojure.lang.AFn const__119;
/*     */   public static final clojure.lang.Var const__120;
/*     */   public static final clojure.lang.AFn const__123;
/*     */   public static final clojure.lang.Var const__124;
/*     */   public static final clojure.lang.AFn const__127;
/*     */   public static final clojure.lang.Var const__128;
/*     */   public static final clojure.lang.AFn const__131;
/*     */   public static final clojure.lang.Var const__132;
/*     */   public static final clojure.lang.AFn const__135;
/*     */   public static final clojure.lang.Var const__136;
/*     */   public static final clojure.lang.AFn const__139;
/*     */   public static final clojure.lang.Var const__140;
/*     */   public static final clojure.lang.AFn const__143;
/*     */   public static final clojure.lang.Var const__144;
/*     */   public static final clojure.lang.AFn const__147;
/*     */   public static final clojure.lang.Var const__148;
/*     */   public static final clojure.lang.AFn const__151;
/*     */   public static final clojure.lang.Var const__152;
/*     */   public static final clojure.lang.AFn const__155;
/*     */   public static final clojure.lang.Var const__156;
/*     */   public static final clojure.lang.AFn const__159;
/*     */   public static final clojure.lang.Var const__160;
/*     */   public static final clojure.lang.AFn const__163;
/*     */   public static final clojure.lang.Var const__164;
/*     */   public static final clojure.lang.AFn const__167;
/*     */   public static void __init0()
/*     */   {
/*     */     const__0 = (clojure.lang.Var)RT.var("clojure.core", "in-ns");
/*     */     const__1 = (clojure.lang.AFn)clojure.lang.Symbol.intern(null, "clojure.pprint");
/*     */     const__2 = (clojure.lang.Var)RT.var("clojure.pprint", "*print-pretty*");
/*     */     const__11 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "doc"), "Bind to true if you want write to use pretty printing", RT.keyword(null, "added"), "1.2", RT.keyword(null, "dynamic"), Boolean.TRUE, RT.keyword(null, "line"), Integer.valueOf(30), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pprint_base.clj" });
/*     */     const__12 = (clojure.lang.Var)RT.var("clojure.pprint", "*print-right-margin*");
/*     */     const__14 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "doc"), "Pretty printing will try to avoid anything going beyond this column.\nSet it to nil to have pprint let the line be arbitrarily long. This will ignore all \nnon-mandatory newlines.", RT.keyword(null, "added"), "1.2", RT.keyword(null, "dynamic"), Boolean.TRUE, RT.keyword(null, "line"), Integer.valueOf(40), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pprint_base.clj" });
/*     */     const__15 = Long.valueOf(72L);
/*     */     const__16 = (clojure.lang.Var)RT.var("clojure.pprint", "*print-miser-width*");
/*     */     const__18 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "doc"), "The column at which to enter miser style. Depending on the dispatch table, \nmiser style add newlines in more places to try to keep lines short allowing for further \nlevels of nesting.", RT.keyword(null, "added"), "1.2", RT.keyword(null, "dynamic"), Boolean.TRUE, RT.keyword(null, "line"), Integer.valueOf(47), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pprint_base.clj" });
/*     */     const__19 = Long.valueOf(40L);
/*     */     const__20 = (clojure.lang.Var)RT.var("clojure.pprint", "*print-lines*");
/*     */     const__23 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "doc"), "Maximum number of lines to print in a pretty print instance (N.B. This is not yet used)", RT.keyword(null, "dynamic"), Boolean.TRUE, RT.keyword(null, "line"), Integer.valueOf(55), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pprint_base.clj" });
/*     */     const__24 = (clojure.lang.Var)RT.var("clojure.pprint", "*print-circle*");
/*     */     const__26 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "doc"), "Mark circular structures (N.B. This is not yet used)", RT.keyword(null, "dynamic"), Boolean.TRUE, RT.keyword(null, "line"), Integer.valueOf(61), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pprint_base.clj" });
/*     */     const__27 = (clojure.lang.Var)RT.var("clojure.pprint", "*print-shared*");
/*     */     const__29 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "doc"), "Mark repeated structures rather than repeat them (N.B. This is not yet used)", RT.keyword(null, "dynamic"), Boolean.TRUE, RT.keyword(null, "line"), Integer.valueOf(67), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pprint_base.clj" });
/*     */     const__30 = (clojure.lang.Var)RT.var("clojure.pprint", "*print-suppress-namespaces*");
/*     */     const__32 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "doc"), "Don't print namespaces with symbols. This is particularly useful when \npretty printing the results of macro expansions", RT.keyword(null, "added"), "1.2", RT.keyword(null, "dynamic"), Boolean.TRUE, RT.keyword(null, "line"), Integer.valueOf(72), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pprint_base.clj" });
/*     */     const__33 = (clojure.lang.Var)RT.var("clojure.pprint", "*print-radix*");
/*     */     const__35 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "doc"), "Print a radix specifier in front of integers and rationals. If *print-base* is 2, 8, \nor 16, then the radix specifier used is #b, #o, or #x, respectively. Otherwise the \nradix specifier is in the form #XXr where XX is the decimal value of *print-base* ", RT.keyword(null, "added"), "1.2", RT.keyword(null, "dynamic"), Boolean.TRUE, RT.keyword(null, "line"), Integer.valueOf(80), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pprint_base.clj" });
/*     */     const__36 = (clojure.lang.Var)RT.var("clojure.pprint", "*print-base*");
/*     */     const__38 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "doc"), "The base to use for printing integers and rationals.", RT.keyword(null, "added"), "1.2", RT.keyword(null, "dynamic"), Boolean.TRUE, RT.keyword(null, "line"), Integer.valueOf(87), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pprint_base.clj" });
/*     */     const__39 = Long.valueOf(10L);
/*     */     const__40 = (clojure.lang.Var)RT.var("clojure.pprint", "*current-level*");
/*     */     const__42 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "dynamic"), Boolean.TRUE, RT.keyword(null, "line"), Integer.valueOf(99), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pprint_base.clj" });
/*     */     const__43 = Long.valueOf(0L);
/*     */     const__44 = (clojure.lang.Var)RT.var("clojure.pprint", "*current-length*");
/*     */     const__46 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "dynamic"), Boolean.TRUE, RT.keyword(null, "line"), Integer.valueOf(101), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pprint_base.clj" });
/*     */     const__47 = (clojure.lang.Var)RT.var("clojure.pprint", "format-simple-number");
/*     */     const__50 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "declared"), Boolean.TRUE, RT.keyword(null, "line"), Integer.valueOf(109), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pprint_base.clj" });
/*     */     const__51 = (clojure.lang.Var)RT.var("clojure.pprint", "orig-pr");
/*     */     const__53 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "line"), Integer.valueOf(111), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pprint_base.clj" });
/*     */     const__54 = (clojure.lang.Var)RT.var("clojure.core", "pr");
/*     */     const__55 = (clojure.lang.Var)RT.var("clojure.pprint", "pr-with-base");
/*     */     const__59 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "x")) })), RT.keyword(null, "line"), Integer.valueOf(113), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pprint_base.clj" });
/*     */     const__60 = (clojure.lang.Var)RT.var("clojure.pprint", "write-option-table");
/*     */     const__62 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "line"), Integer.valueOf(118), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pprint_base.clj" });
/*     */     const__87 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "miser-width"), clojure.lang.Symbol.intern("clojure.pprint", "*print-miser-width*"), RT.keyword(null, "right-margin"), clojure.lang.Symbol.intern("clojure.pprint", "*print-right-margin*"), RT.keyword(null, "circle"), clojure.lang.Symbol.intern("clojure.pprint", "*print-circle*"), RT.keyword(null, "lines"), clojure.lang.Symbol.intern("clojure.pprint", "*print-lines*"), RT.keyword(null, "suppress-namespaces"), clojure.lang.Symbol.intern("clojure.pprint", "*print-suppress-namespaces*"), RT.keyword(null, "radix"), clojure.lang.Symbol.intern("clojure.pprint", "*print-radix*"), RT.keyword(null, "level"), clojure.lang.Symbol.intern("clojure.core", "*print-level*"), RT.keyword(null, "readably"), clojure.lang.Symbol.intern("clojure.core", "*print-readably*"), RT.keyword(null, "dispatch"), clojure.lang.Symbol.intern("clojure.pprint", "*print-pprint-dispatch*"), RT.keyword(null, "length"), clojure.lang.Symbol.intern("clojure.core", "*print-length*"), RT.keyword(null, "pretty"), clojure.lang.Symbol.intern("clojure.pprint", "*print-pretty*"), RT.keyword(null, "base"), clojure.lang.Symbol.intern("clojure.pprint", "*print-base*") });
/*     */     const__88 = (clojure.lang.Var)RT.var("clojure.pprint", "binding-map");
/*     */     const__91 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "amap"), clojure.lang.Symbol.intern(null, "&"), clojure.lang.Symbol.intern(null, "body")) })), RT.keyword(null, "line"), Integer.valueOf(137), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pprint_base.clj" });
/*     */     const__92 = (clojure.lang.Var)RT.var("clojure.pprint", "table-ize");
/*     */     const__95 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "t"), clojure.lang.Symbol.intern(null, "m")) })), RT.keyword(null, "line"), Integer.valueOf(146), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pprint_base.clj" });
/*     */     const__96 = (clojure.lang.Var)RT.var("clojure.pprint", "pretty-writer?");
/*     */     const__99 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "x")) })), RT.keyword(null, "doc"), "Return true iff x is a PrettyWriter", RT.keyword(null, "line"), Integer.valueOf(151), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pprint_base.clj" });
/*     */   }
/*     */   
/*     */   public static void __init1()
/*     */   {
/*     */     const__100 = (clojure.lang.Var)RT.var("clojure.pprint", "make-pretty-writer");
/*     */     const__103 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "base-writer"), clojure.lang.Symbol.intern(null, "right-margin"), clojure.lang.Symbol.intern(null, "miser-width")) })), RT.keyword(null, "doc"), "Wrap base-writer in a PrettyWriter with the specified right-margin and miser-width", RT.keyword(null, "line"), Integer.valueOf(155), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pprint_base.clj" });
/*     */     const__104 = (clojure.lang.Var)RT.var("clojure.pprint", "with-pretty-writer");
/*     */     const__107 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "base-writer"), clojure.lang.Symbol.intern(null, "&"), clojure.lang.Symbol.intern(null, "body")) })), RT.keyword(null, "line"), Integer.valueOf(160), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pprint_base.clj" });
/*     */     const__108 = (clojure.lang.Var)RT.var("clojure.pprint", "write-out");
/*     */     const__111 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "object")) })), RT.keyword(null, "doc"), "Write an object to *out* subject to the current bindings of the printer control \nvariables. Use the kw-args argument to override individual variables for this call (and \nany recursive calls).\n\n*out* must be a PrettyWriter if pretty printing is enabled. This is the responsibility\nof the caller.\n\nThis method is primarily intended for use by pretty print dispatch functions that \nalready know that the pretty printer will have set up their environment appropriately.\nNormal library clients should use the standard \"write\" interface. ", RT.keyword(null, "added"), "1.2", RT.keyword(null, "line"), Integer.valueOf(171), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pprint_base.clj" });
/*     */     const__112 = (clojure.lang.Var)RT.var("clojure.pprint", "write");
/*     */     const__115 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "object"), clojure.lang.Symbol.intern(null, "&"), clojure.lang.Symbol.intern(null, "kw-args")) })), RT.keyword(null, "doc"), "Write an object subject to the current bindings of the printer control variables.\nUse the kw-args argument to override individual variables for this call (and any \nrecursive calls). Returns the string result if :stream is nil or nil otherwise.\n\nThe following keyword arguments can be passed with values:\n  Keyword              Meaning                              Default value\n  :stream              Writer for output or nil             true (indicates *out*)\n  :base                Base to use for writing rationals    Current value of *print-base*\n  :circle*             If true, mark circular structures    Current value of *print-circle*\n  :length              Maximum elements to show in sublists Current value of *print-length*\n  :level               Maximum depth                        Current value of *print-level*\n  :lines*              Maximum lines of output              Current value of *print-lines*\n  :miser-width         Width to enter miser mode            Current value of *print-miser-width*\n  :dispatch            The pretty print dispatch function   Current value of *print-pprint-dispatch*\n  :pretty              If true, do pretty printing          Current value of *print-pretty*\n  :radix               If true, prepend a radix specifier   Current value of *print-radix*\n  :readably*           If true, print readably              Current value of *print-readably*\n  :right-margin        The column for the right margin      Current value of *print-right-margin*\n  :suppress-namespaces If true, no namespaces in symbols    Current value of *print-suppress-namespaces*\n\n  * = not yet supported\n", RT.keyword(null, "added"), "1.2", RT.keyword(null, "line"), Integer.valueOf(197), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pprint_base.clj" });
/*     */     const__116 = (clojure.lang.Var)RT.var("clojure.pprint", "pprint");
/*     */     const__119 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "object")), clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "object"), clojure.lang.Symbol.intern(null, "writer")) })), RT.keyword(null, "doc"), "Pretty print object to the optional output writer. If the writer is not provided, \nprint the object to the currently bound value of *out*.", RT.keyword(null, "added"), "1.2", RT.keyword(null, "line"), Integer.valueOf(241), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pprint_base.clj" });
/*     */     const__120 = (clojure.lang.Var)RT.var("clojure.pprint", "pp");
/*     */     const__123 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create() })), RT.keyword(null, "doc"), "A convenience macro that pretty prints the last thing output. This is\nexactly equivalent to (pprint *1).", RT.keyword(null, "added"), "1.2", RT.keyword(null, "line"), Integer.valueOf(254), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pprint_base.clj" });
/*     */     const__124 = (clojure.lang.Var)RT.var("clojure.pprint", "set-pprint-dispatch");
/*     */     const__127 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "function")) })), RT.keyword(null, "doc"), "Set the pretty print dispatch function to a function matching (fn [obj] ...)\nwhere obj is the object to pretty print. That function will be called with *out* set\nto a pretty printing writer to which it should do its printing.\n\nFor example functions, see simple-dispatch and code-dispatch in \nclojure.pprint.dispatch.clj.", RT.keyword(null, "added"), "1.2", RT.keyword(null, "line"), Integer.valueOf(260), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pprint_base.clj" });
/*     */     const__128 = (clojure.lang.Var)RT.var("clojure.pprint", "with-pprint-dispatch");
/*     */     const__131 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "function"), clojure.lang.Symbol.intern(null, "&"), clojure.lang.Symbol.intern(null, "body")) })), RT.keyword(null, "doc"), "Execute body with the pretty print dispatch function bound to function.", RT.keyword(null, "added"), "1.2", RT.keyword(null, "line"), Integer.valueOf(274), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pprint_base.clj" });
/*     */     const__132 = (clojure.lang.Var)RT.var("clojure.pprint", "parse-lb-options");
/*     */     const__135 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "opts"), clojure.lang.Symbol.intern(null, "body")) })), RT.keyword(null, "line"), Integer.valueOf(285), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pprint_base.clj" });
/*     */     const__136 = (clojure.lang.Var)RT.var("clojure.pprint", "check-enumerated-arg");
/*     */     const__139 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "arg"), clojure.lang.Symbol.intern(null, "choices")) })), RT.keyword(null, "line"), Integer.valueOf(292), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pprint_base.clj" });
/*     */     const__140 = (clojure.lang.Var)RT.var("clojure.pprint", "level-exceeded");
/*     */     const__143 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create() })), RT.keyword(null, "line"), Integer.valueOf(299), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pprint_base.clj" });
/*     */     const__144 = (clojure.lang.Var)RT.var("clojure.pprint", "pprint-logical-block");
/*     */     const__147 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "arglists"), clojure.lang.Tuple.create(clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "options*"), clojure.lang.Symbol.intern(null, "body"))), RT.keyword(null, "doc"), "Execute the body as a pretty printing logical block with output to *out* which \nmust be a pretty printing writer. When used from pprint or cl-format, this can be \nassumed. \n\nThis function is intended for use when writing custom dispatch functions.\n\nBefore the body, the caller can optionally specify options: :prefix, :per-line-prefix, \nand :suffix.", RT.keyword(null, "added"), "1.2", RT.keyword(null, "line"), Integer.valueOf(302), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pprint_base.clj" });
/*     */     const__148 = (clojure.lang.Var)RT.var("clojure.pprint", "pprint-newline");
/*     */     const__151 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "kind")) })), RT.keyword(null, "doc"), "Print a conditional newline to a pretty printing stream. kind specifies if the \nnewline is :linear, :miser, :fill, or :mandatory. \n\nThis function is intended for use when writing custom dispatch functions.\n\nOutput is sent to *out* which must be a pretty printing writer.", RT.keyword(null, "added"), "1.2", RT.keyword(null, "line"), Integer.valueOf(329), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pprint_base.clj" });
/*     */     const__152 = (clojure.lang.Var)RT.var("clojure.pprint", "pprint-indent");
/*     */     const__155 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "relative-to"), clojure.lang.Symbol.intern(null, "n")) })), RT.keyword(null, "doc"), "Create an indent at this point in the pretty printing stream. This defines how \nfollowing lines are indented. relative-to can be either :block or :current depending \nwhether the indent should be computed relative to the start of the logical block or\nthe current column position. n is an offset. \n\nThis function is intended for use when writing custom dispatch functions.\n\nOutput is sent to *out* which must be a pretty printing writer.", RT.keyword(null, "added"), "1.2", RT.keyword(null, "line"), Integer.valueOf(341), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pprint_base.clj" });
/*     */     const__156 = (clojure.lang.Var)RT.var("clojure.pprint", "pprint-tab");
/*     */     const__159 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "kind"), clojure.lang.Symbol.intern(null, "colnum"), clojure.lang.Symbol.intern(null, "colinc")) })), RT.keyword(null, "doc"), "Tab at this point in the pretty printing stream. kind specifies whether the tab\nis :line, :section, :line-relative, or :section-relative. \n\nColnum and colinc specify the target column and the increment to move the target\nforward if the output is already past the original target.\n\nThis function is intended for use when writing custom dispatch functions.\n\nOutput is sent to *out* which must be a pretty printing writer.\n\nTHIS FUNCTION IS NOT YET IMPLEMENTED.", RT.keyword(null, "added"), "1.2", RT.keyword(null, "line"), Integer.valueOf(356), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pprint_base.clj" });
/*     */     const__160 = (clojure.lang.Var)RT.var("clojure.pprint", "pll-mod-body");
/*     */     const__163 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "var-sym"), clojure.lang.Symbol.intern(null, "body")) })), RT.keyword(null, "line"), Integer.valueOf(380), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pprint_base.clj" });
/*     */     const__164 = (clojure.lang.Var)RT.var("clojure.pprint", "print-length-loop");
/*     */     const__167 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "bindings"), clojure.lang.Symbol.intern(null, "&"), clojure.lang.Symbol.intern(null, "body")) })), RT.keyword(null, "doc"), "A version of loop that iterates at most *print-length* times. This is designed \nfor use in pretty-printer dispatch functions.", RT.keyword(null, "added"), "1.3", RT.keyword(null, "line"), Integer.valueOf(391), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/pprint_base.clj" });
/*     */   }
/*     */   
/*     */   static
/*     */   {
/*     */     __init0();
/*     */     __init1();
/*     */     clojure.lang.Compiler.pushNSandLoader(RT.classForName("clojure.pprint.pprint_base__init").getClassLoader());
/*     */     try
/*     */     {
/*     */       load();
/*     */       clojure.lang.Var.popThreadBindings();
/*     */     }
/*     */     finally
/*     */     {
/*     */       clojure.lang.Var.popThreadBindings();
/*     */       throw finally;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\pprint\pprint_base__init.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */