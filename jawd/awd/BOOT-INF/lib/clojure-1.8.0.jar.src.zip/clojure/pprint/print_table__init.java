/*   */ package clojure.pprint;
/*   */ 
/*   */ import clojure.lang.RT;
/*   */ 
/*   */ public class print_table__init {
/*   */   public static final clojure.lang.Var const__0;
/*   */   public static final clojure.lang.AFn const__1;
/*   */   
/* 9 */   public static void load() { clojure.lang.Var tmp20_17 = const__2;tmp20_17.setMeta((clojure.lang.IPersistentMap)const__12);tmp20_17.bindRoot(new clojure.pprint.print_table());
/*   */   }
/*   */   
/*   */   public static final clojure.lang.Var const__2;
/*   */   public static final clojure.lang.AFn const__12;
/*   */   public static void __init0()
/*   */   {
/*   */     const__0 = (clojure.lang.Var)RT.var("clojure.core", "in-ns");
/*   */     const__1 = (clojure.lang.AFn)clojure.lang.Symbol.intern(null, "clojure.pprint");
/*   */     const__2 = (clojure.lang.Var)RT.var("clojure.pprint", "print-table");
/*   */     const__12 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "ks"), clojure.lang.Symbol.intern(null, "rows")), clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "rows")) })), RT.keyword(null, "doc"), "Prints a collection of maps in a textual table. Prints table headings\n   ks, and then a line of output for each row, corresponding to the keys\n   in ks. If ks are not specified, use the keys of the first item in rows.", RT.keyword(null, "added"), "1.3", RT.keyword(null, "line"), Integer.valueOf(11), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/pprint/print_table.clj" });
/*   */   }
/*   */   
/*   */   static
/*   */   {
/*   */     __init0();
/*   */     clojure.lang.Compiler.pushNSandLoader(RT.classForName("clojure.pprint.print_table__init").getClassLoader());
/*   */     try
/*   */     {
/*   */       load();
/*   */       clojure.lang.Var.popThreadBindings();
/*   */     }
/*   */     finally
/*   */     {
/*   */       clojure.lang.Var.popThreadBindings();
/*   */       throw finally;
/*   */     }
/*   */   }
/*   */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\pprint\print_table__init.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */