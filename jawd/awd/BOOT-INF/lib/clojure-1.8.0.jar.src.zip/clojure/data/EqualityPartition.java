package clojure.data;

public abstract interface EqualityPartition
{
  public abstract Object equality_partition();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\data\EqualityPartition.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */