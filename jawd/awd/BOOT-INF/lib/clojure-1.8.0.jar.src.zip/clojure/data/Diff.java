package clojure.data;

public abstract interface Diff
{
  public abstract Object diff_similar(Object paramObject);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\data\Diff.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */