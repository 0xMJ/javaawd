package clojure.instant.proxy$java.lang;

import clojure.lang.IPersistentCollection;
import clojure.lang.IPersistentMap;
import clojure.lang.IProxy;

public class ThreadLocal$ff19274a
  extends ThreadLocal
  implements IProxy
{
  private volatile IPersistentMap __clojureFnMap;
  
  public void __initClojureFnMappings(IPersistentMap paramIPersistentMap)
  {
    this.__clojureFnMap = paramIPersistentMap;
  }
  
  public void __updateClojureFnMappings(IPersistentMap paramIPersistentMap)
  {
    this.__clojureFnMap = ((IPersistentMap)((IPersistentCollection)this.__clojureFnMap).cons(paramIPersistentMap));
  }
  
  public IPersistentMap __getClojureFnMappings()
  {
    return this.__clojureFnMap;
  }
  
  /* Error */
  public Object get()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/instant/proxy$java/lang/ThreadLocal$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 30
    //   6: invokestatic 35	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +15 -> 25
    //   13: checkcast 37	clojure/lang/IFn
    //   16: aload_0
    //   17: invokeinterface 41 2 0
    //   22: goto +8 -> 30
    //   25: pop
    //   26: aload_0
    //   27: invokespecial 43	java/lang/ThreadLocal:get	()Ljava/lang/Object;
    //   30: areturn
  }
  
  /* Error */
  public void remove()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/instant/proxy$java/lang/ThreadLocal$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 45
    //   6: invokestatic 35	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +16 -> 26
    //   13: checkcast 37	clojure/lang/IFn
    //   16: aload_0
    //   17: invokeinterface 41 2 0
    //   22: pop
    //   23: goto +8 -> 31
    //   26: pop
    //   27: aload_0
    //   28: invokespecial 47	java/lang/ThreadLocal:remove	()V
    //   31: return
  }
  
  /* Error */
  public void set(Object arg1)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/instant/proxy$java/lang/ThreadLocal$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 50
    //   6: invokestatic 35	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +17 -> 27
    //   13: checkcast 37	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: invokeinterface 52 3 0
    //   23: pop
    //   24: goto +9 -> 33
    //   27: pop
    //   28: aload_0
    //   29: aload_1
    //   30: invokespecial 54	java/lang/ThreadLocal:set	(Ljava/lang/Object;)V
    //   33: return
  }
  
  /* Error */
  public Object initialValue()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/instant/proxy$java/lang/ThreadLocal$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 56
    //   6: invokestatic 35	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +15 -> 25
    //   13: checkcast 37	clojure/lang/IFn
    //   16: aload_0
    //   17: invokeinterface 41 2 0
    //   22: goto +8 -> 30
    //   25: pop
    //   26: aload_0
    //   27: invokespecial 58	java/lang/ThreadLocal:initialValue	()Ljava/lang/Object;
    //   30: areturn
  }
  
  /* Error */
  public boolean equals(Object arg1)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/instant/proxy$java/lang/ThreadLocal$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 61
    //   6: invokestatic 35	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +22 -> 32
    //   13: checkcast 37	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: invokeinterface 52 3 0
    //   23: checkcast 63	java/lang/Boolean
    //   26: invokevirtual 67	java/lang/Boolean:booleanValue	()Z
    //   29: goto +9 -> 38
    //   32: pop
    //   33: aload_0
    //   34: aload_1
    //   35: invokespecial 69	java/lang/ThreadLocal:equals	(Ljava/lang/Object;)Z
    //   38: ireturn
  }
  
  /* Error */
  public String toString()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/instant/proxy$java/lang/ThreadLocal$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 72
    //   6: invokestatic 35	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +18 -> 28
    //   13: checkcast 37	clojure/lang/IFn
    //   16: aload_0
    //   17: invokeinterface 41 2 0
    //   22: checkcast 74	java/lang/String
    //   25: goto +8 -> 33
    //   28: pop
    //   29: aload_0
    //   30: invokespecial 76	java/lang/ThreadLocal:toString	()Ljava/lang/String;
    //   33: areturn
  }
  
  /* Error */
  public int hashCode()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/instant/proxy$java/lang/ThreadLocal$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 79
    //   6: invokestatic 35	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +21 -> 31
    //   13: checkcast 37	clojure/lang/IFn
    //   16: aload_0
    //   17: invokeinterface 41 2 0
    //   22: checkcast 81	java/lang/Number
    //   25: invokevirtual 84	java/lang/Number:intValue	()I
    //   28: goto +8 -> 36
    //   31: pop
    //   32: aload_0
    //   33: invokespecial 86	java/lang/ThreadLocal:hashCode	()I
    //   36: ireturn
  }
  
  /* Error */
  public Object clone()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/instant/proxy$java/lang/ThreadLocal$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 88
    //   6: invokestatic 35	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +15 -> 25
    //   13: checkcast 37	clojure/lang/IFn
    //   16: aload_0
    //   17: invokeinterface 41 2 0
    //   22: goto +8 -> 30
    //   25: pop
    //   26: aload_0
    //   27: invokespecial 90	java/lang/ThreadLocal:clone	()Ljava/lang/Object;
    //   30: areturn
  }
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\instant\proxy$java\lang\ThreadLocal$ff19274a.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */