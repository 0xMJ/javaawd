/*      */ package clojure.asm;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ final class Frame
/*      */ {
/*      */   static final int DIM = -268435456;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int ARRAY_OF = 268435456;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int ELEMENT_OF = -268435456;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int KIND = 251658240;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int TOP_IF_LONG_OR_DOUBLE = 8388608;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int VALUE = 8388607;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int BASE_KIND = 267386880;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int BASE_VALUE = 1048575;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int BASE = 16777216;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int OBJECT = 24117248;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int UNINITIALIZED = 25165824;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int LOCAL = 33554432;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int STACK = 50331648;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int TOP = 16777216;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int BOOLEAN = 16777225;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int BYTE = 16777226;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int CHAR = 16777227;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int SHORT = 16777228;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int INTEGER = 16777217;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int FLOAT = 16777218;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int DOUBLE = 16777219;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int LONG = 16777220;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int NULL = 16777221;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int UNINITIALIZED_THIS = 16777222;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int[] SIZE;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Label owner;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   int[] inputLocals;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   int[] inputStack;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int[] outputLocals;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int[] outputStack;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int outputStackTop;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int initializationCount;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int[] initializations;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static
/*      */   {
/*  239 */     int[] b = new int['Ê'];
/*  240 */     String s = "EFFFFFFFFGGFFFGGFFFEEFGFGFEEEEEEEEEEEEEEEEEEEEDEDEDDDDDCDCDEEEEEEEEEEEEEEEEEEEEBABABBBBDCFFFGGGEDCDCDCDCDCDCDCDCDCDCEEEEDDDDDDDCDCDCEFEFDDEEFFDEDEEEBDDBBDDDDDDCCCCCCCCEFEDDDCDCDEEEEEEEEEEFEEEEEEDDEEDDEE";
/*      */     
/*      */ 
/*      */ 
/*  244 */     for (int i = 0; i < b.length; i++) {
/*  245 */       b[i] = (s.charAt(i) - 'E');
/*      */     }
/*  247 */     SIZE = b;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int get(int local)
/*      */   {
/*  531 */     if ((this.outputLocals == null) || (local >= this.outputLocals.length))
/*      */     {
/*      */ 
/*  534 */       return 0x2000000 | local;
/*      */     }
/*  536 */     int type = this.outputLocals[local];
/*  537 */     if (type == 0)
/*      */     {
/*      */ 
/*  540 */       type = this.outputLocals[local] = 0x2000000 | local;
/*      */     }
/*  542 */     return type;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void set(int local, int type)
/*      */   {
/*  556 */     if (this.outputLocals == null) {
/*  557 */       this.outputLocals = new int[10];
/*      */     }
/*  559 */     int n = this.outputLocals.length;
/*  560 */     if (local >= n) {
/*  561 */       int[] t = new int[Math.max(local + 1, 2 * n)];
/*  562 */       System.arraycopy(this.outputLocals, 0, t, 0, n);
/*  563 */       this.outputLocals = t;
/*      */     }
/*      */     
/*  566 */     this.outputLocals[local] = type;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void push(int type)
/*      */   {
/*  577 */     if (this.outputStack == null) {
/*  578 */       this.outputStack = new int[10];
/*      */     }
/*  580 */     int n = this.outputStack.length;
/*  581 */     if (this.outputStackTop >= n) {
/*  582 */       int[] t = new int[Math.max(this.outputStackTop + 1, 2 * n)];
/*  583 */       System.arraycopy(this.outputStack, 0, t, 0, n);
/*  584 */       this.outputStack = t;
/*      */     }
/*      */     
/*  587 */     this.outputStack[(this.outputStackTop++)] = type;
/*      */     
/*  589 */     int top = this.owner.inputStackTop + this.outputStackTop;
/*  590 */     if (top > this.owner.outputStackMax) {
/*  591 */       this.owner.outputStackMax = top;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void push(ClassWriter cw, String desc)
/*      */   {
/*  606 */     int type = type(cw, desc);
/*  607 */     if (type != 0) {
/*  608 */       push(type);
/*  609 */       if ((type == 16777220) || (type == 16777219)) {
/*  610 */         push(16777216);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static int type(ClassWriter cw, String desc)
/*      */   {
/*  626 */     int index = desc.charAt(0) == '(' ? desc.indexOf(')') + 1 : 0;
/*  627 */     String t; switch (desc.charAt(index)) {
/*      */     case 'V': 
/*  629 */       return 0;
/*      */     case 'B': 
/*      */     case 'C': 
/*      */     case 'I': 
/*      */     case 'S': 
/*      */     case 'Z': 
/*  635 */       return 16777217;
/*      */     case 'F': 
/*  637 */       return 16777218;
/*      */     case 'J': 
/*  639 */       return 16777220;
/*      */     case 'D': 
/*  641 */       return 16777219;
/*      */     
/*      */     case 'L': 
/*  644 */       t = desc.substring(index + 1, desc.length() - 1);
/*  645 */       return 0x1700000 | cw.addType(t);
/*      */     }
/*      */     
/*      */     
/*      */ 
/*  650 */     int dims = index + 1;
/*  651 */     while (desc.charAt(dims) == '[')
/*  652 */       dims++;
/*      */     int data;
/*  654 */     switch (desc.charAt(dims)) {
/*      */     case 'Z': 
/*  656 */       data = 16777225;
/*  657 */       break;
/*      */     case 'C': 
/*  659 */       data = 16777227;
/*  660 */       break;
/*      */     case 'B': 
/*  662 */       data = 16777226;
/*  663 */       break;
/*      */     case 'S': 
/*  665 */       data = 16777228;
/*  666 */       break;
/*      */     case 'I': 
/*  668 */       data = 16777217;
/*  669 */       break;
/*      */     case 'F': 
/*  671 */       data = 16777218;
/*  672 */       break;
/*      */     case 'J': 
/*  674 */       data = 16777220;
/*  675 */       break;
/*      */     case 'D': 
/*  677 */       data = 16777219;
/*  678 */       break;
/*      */     case 'E': case 'G': case 'H': case 'K': case 'L': case 'M': 
/*      */     case 'N': case 'O': case 'P': case 'Q': case 'R': case 'T': 
/*      */     case 'U': case 'V': case 'W': case 'X': case 'Y': default: 
/*  682 */       t = desc.substring(dims + 1, desc.length() - 1);
/*  683 */       data = 0x1700000 | cw.addType(t);
/*      */     }
/*  685 */     return dims - index << 28 | data;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int pop()
/*      */   {
/*  695 */     if (this.outputStackTop > 0) {
/*  696 */       return this.outputStack[(--this.outputStackTop)];
/*      */     }
/*      */     
/*  699 */     return 0x3000000 | ---this.owner.inputStackTop;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void pop(int elements)
/*      */   {
/*  710 */     if (this.outputStackTop >= elements) {
/*  711 */       this.outputStackTop -= elements;
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*  716 */       this.owner.inputStackTop -= elements - this.outputStackTop;
/*  717 */       this.outputStackTop = 0;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void pop(String desc)
/*      */   {
/*  730 */     char c = desc.charAt(0);
/*  731 */     if (c == '(') {
/*  732 */       pop((Type.getArgumentsAndReturnSizes(desc) >> 2) - 1);
/*  733 */     } else if ((c == 'J') || (c == 'D')) {
/*  734 */       pop(2);
/*      */     } else {
/*  736 */       pop(1);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void init(int var)
/*      */   {
/*  749 */     if (this.initializations == null) {
/*  750 */       this.initializations = new int[2];
/*      */     }
/*  752 */     int n = this.initializations.length;
/*  753 */     if (this.initializationCount >= n) {
/*  754 */       int[] t = new int[Math.max(this.initializationCount + 1, 2 * n)];
/*  755 */       System.arraycopy(this.initializations, 0, t, 0, n);
/*  756 */       this.initializations = t;
/*      */     }
/*      */     
/*  759 */     this.initializations[(this.initializationCount++)] = var;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int init(ClassWriter cw, int t)
/*      */   {
/*      */     int s;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  775 */     if (t == 16777222) {
/*  776 */       s = 0x1700000 | cw.addType(cw.thisName); } else { int s;
/*  777 */       if ((t & 0xFFF00000) == 25165824) {
/*  778 */         String type = cw.typeTable[(t & 0xFFFFF)].strVal1;
/*  779 */         s = 0x1700000 | cw.addType(type);
/*      */       } else {
/*  781 */         return t; } }
/*      */     int s;
/*  783 */     for (int j = 0; j < this.initializationCount; j++) {
/*  784 */       int u = this.initializations[j];
/*  785 */       int dim = u & 0xF0000000;
/*  786 */       int kind = u & 0xF000000;
/*  787 */       if (kind == 33554432) {
/*  788 */         u = dim + this.inputLocals[(u & 0x7FFFFF)];
/*  789 */       } else if (kind == 50331648) {
/*  790 */         u = dim + this.inputStack[(this.inputStack.length - (u & 0x7FFFFF))];
/*      */       }
/*  792 */       if (t == u) {
/*  793 */         return s;
/*      */       }
/*      */     }
/*  796 */     return t;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void initInputFrame(ClassWriter cw, int access, Type[] args, int maxLocals)
/*      */   {
/*  814 */     this.inputLocals = new int[maxLocals];
/*  815 */     this.inputStack = new int[0];
/*  816 */     int i = 0;
/*  817 */     if ((access & 0x8) == 0) {
/*  818 */       if ((access & 0x80000) == 0) {
/*  819 */         this.inputLocals[(i++)] = (0x1700000 | cw.addType(cw.thisName));
/*      */       } else {
/*  821 */         this.inputLocals[(i++)] = 16777222;
/*      */       }
/*      */     }
/*  824 */     for (int j = 0; j < args.length; j++) {
/*  825 */       int t = type(cw, args[j].getDescriptor());
/*  826 */       this.inputLocals[(i++)] = t;
/*  827 */       if ((t == 16777220) || (t == 16777219)) {
/*  828 */         this.inputLocals[(i++)] = 16777216;
/*      */       }
/*      */     }
/*  831 */     while (i < maxLocals) {
/*  832 */       this.inputLocals[(i++)] = 16777216;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void execute(int opcode, int arg, ClassWriter cw, Item item)
/*      */   {
/*      */     int t1;
/*      */     
/*      */ 
/*      */     int t2;
/*      */     
/*      */ 
/*      */     int t3;
/*      */     
/*      */ 
/*      */     String s;
/*      */     
/*  851 */     switch (opcode) {
/*      */     case 0: 
/*      */     case 116: 
/*      */     case 117: 
/*      */     case 118: 
/*      */     case 119: 
/*      */     case 145: 
/*      */     case 146: 
/*      */     case 147: 
/*      */     case 167: 
/*      */     case 177: 
/*      */       break;
/*      */     case 1: 
/*  864 */       push(16777221);
/*  865 */       break;
/*      */     case 2: 
/*      */     case 3: 
/*      */     case 4: 
/*      */     case 5: 
/*      */     case 6: 
/*      */     case 7: 
/*      */     case 8: 
/*      */     case 16: 
/*      */     case 17: 
/*      */     case 21: 
/*  876 */       push(16777217);
/*  877 */       break;
/*      */     case 9: 
/*      */     case 10: 
/*      */     case 22: 
/*  881 */       push(16777220);
/*  882 */       push(16777216);
/*  883 */       break;
/*      */     case 11: 
/*      */     case 12: 
/*      */     case 13: 
/*      */     case 23: 
/*  888 */       push(16777218);
/*  889 */       break;
/*      */     case 14: 
/*      */     case 15: 
/*      */     case 24: 
/*  893 */       push(16777219);
/*  894 */       push(16777216);
/*  895 */       break;
/*      */     case 18: 
/*  897 */       switch (item.type) {
/*      */       case 3: 
/*  899 */         push(16777217);
/*  900 */         break;
/*      */       case 5: 
/*  902 */         push(16777220);
/*  903 */         push(16777216);
/*  904 */         break;
/*      */       case 4: 
/*  906 */         push(16777218);
/*  907 */         break;
/*      */       case 6: 
/*  909 */         push(16777219);
/*  910 */         push(16777216);
/*  911 */         break;
/*      */       case 7: 
/*  913 */         push(0x1700000 | cw.addType("java/lang/Class"));
/*  914 */         break;
/*      */       case 8: 
/*  916 */         push(0x1700000 | cw.addType("java/lang/String"));
/*  917 */         break;
/*      */       case 16: 
/*  919 */         push(0x1700000 | cw.addType("java/lang/invoke/MethodType"));
/*  920 */         break;
/*      */       case 9: case 10: case 11: case 12: 
/*      */       case 13: case 14: case 15: default: 
/*  923 */         push(0x1700000 | cw.addType("java/lang/invoke/MethodHandle"));
/*      */       }
/*  925 */       break;
/*      */     case 25: 
/*  927 */       push(get(arg));
/*  928 */       break;
/*      */     case 46: 
/*      */     case 51: 
/*      */     case 52: 
/*      */     case 53: 
/*  933 */       pop(2);
/*  934 */       push(16777217);
/*  935 */       break;
/*      */     case 47: 
/*      */     case 143: 
/*  938 */       pop(2);
/*  939 */       push(16777220);
/*  940 */       push(16777216);
/*  941 */       break;
/*      */     case 48: 
/*  943 */       pop(2);
/*  944 */       push(16777218);
/*  945 */       break;
/*      */     case 49: 
/*      */     case 138: 
/*  948 */       pop(2);
/*  949 */       push(16777219);
/*  950 */       push(16777216);
/*  951 */       break;
/*      */     case 50: 
/*  953 */       pop(1);
/*  954 */       t1 = pop();
/*  955 */       push(-268435456 + t1);
/*  956 */       break;
/*      */     case 54: 
/*      */     case 56: 
/*      */     case 58: 
/*  960 */       t1 = pop();
/*  961 */       set(arg, t1);
/*  962 */       if (arg > 0) {
/*  963 */         t2 = get(arg - 1);
/*      */         
/*  965 */         if ((t2 == 16777220) || (t2 == 16777219)) {
/*  966 */           set(arg - 1, 16777216);
/*  967 */         } else if ((t2 & 0xF000000) != 16777216) {
/*  968 */           set(arg - 1, t2 | 0x800000);
/*      */         }
/*      */       }
/*      */       break;
/*      */     case 55: 
/*      */     case 57: 
/*  974 */       pop(1);
/*  975 */       t1 = pop();
/*  976 */       set(arg, t1);
/*  977 */       set(arg + 1, 16777216);
/*  978 */       if (arg > 0) {
/*  979 */         t2 = get(arg - 1);
/*      */         
/*  981 */         if ((t2 == 16777220) || (t2 == 16777219)) {
/*  982 */           set(arg - 1, 16777216);
/*  983 */         } else if ((t2 & 0xF000000) != 16777216) {
/*  984 */           set(arg - 1, t2 | 0x800000);
/*      */         }
/*      */       }
/*      */       break;
/*      */     case 79: 
/*      */     case 81: 
/*      */     case 83: 
/*      */     case 84: 
/*      */     case 85: 
/*      */     case 86: 
/*  994 */       pop(3);
/*  995 */       break;
/*      */     case 80: 
/*      */     case 82: 
/*  998 */       pop(4);
/*  999 */       break;
/*      */     case 87: 
/*      */     case 153: 
/*      */     case 154: 
/*      */     case 155: 
/*      */     case 156: 
/*      */     case 157: 
/*      */     case 158: 
/*      */     case 170: 
/*      */     case 171: 
/*      */     case 172: 
/*      */     case 174: 
/*      */     case 176: 
/*      */     case 191: 
/*      */     case 194: 
/*      */     case 195: 
/*      */     case 198: 
/*      */     case 199: 
/* 1017 */       pop(1);
/* 1018 */       break;
/*      */     case 88: 
/*      */     case 159: 
/*      */     case 160: 
/*      */     case 161: 
/*      */     case 162: 
/*      */     case 163: 
/*      */     case 164: 
/*      */     case 165: 
/*      */     case 166: 
/*      */     case 173: 
/*      */     case 175: 
/* 1030 */       pop(2);
/* 1031 */       break;
/*      */     case 89: 
/* 1033 */       t1 = pop();
/* 1034 */       push(t1);
/* 1035 */       push(t1);
/* 1036 */       break;
/*      */     case 90: 
/* 1038 */       t1 = pop();
/* 1039 */       t2 = pop();
/* 1040 */       push(t1);
/* 1041 */       push(t2);
/* 1042 */       push(t1);
/* 1043 */       break;
/*      */     case 91: 
/* 1045 */       t1 = pop();
/* 1046 */       t2 = pop();
/* 1047 */       t3 = pop();
/* 1048 */       push(t1);
/* 1049 */       push(t3);
/* 1050 */       push(t2);
/* 1051 */       push(t1);
/* 1052 */       break;
/*      */     case 92: 
/* 1054 */       t1 = pop();
/* 1055 */       t2 = pop();
/* 1056 */       push(t2);
/* 1057 */       push(t1);
/* 1058 */       push(t2);
/* 1059 */       push(t1);
/* 1060 */       break;
/*      */     case 93: 
/* 1062 */       t1 = pop();
/* 1063 */       t2 = pop();
/* 1064 */       t3 = pop();
/* 1065 */       push(t2);
/* 1066 */       push(t1);
/* 1067 */       push(t3);
/* 1068 */       push(t2);
/* 1069 */       push(t1);
/* 1070 */       break;
/*      */     case 94: 
/* 1072 */       t1 = pop();
/* 1073 */       t2 = pop();
/* 1074 */       t3 = pop();
/* 1075 */       int t4 = pop();
/* 1076 */       push(t2);
/* 1077 */       push(t1);
/* 1078 */       push(t4);
/* 1079 */       push(t3);
/* 1080 */       push(t2);
/* 1081 */       push(t1);
/* 1082 */       break;
/*      */     case 95: 
/* 1084 */       t1 = pop();
/* 1085 */       t2 = pop();
/* 1086 */       push(t1);
/* 1087 */       push(t2);
/* 1088 */       break;
/*      */     case 96: 
/*      */     case 100: 
/*      */     case 104: 
/*      */     case 108: 
/*      */     case 112: 
/*      */     case 120: 
/*      */     case 122: 
/*      */     case 124: 
/*      */     case 126: 
/*      */     case 128: 
/*      */     case 130: 
/*      */     case 136: 
/*      */     case 142: 
/*      */     case 149: 
/*      */     case 150: 
/* 1104 */       pop(2);
/* 1105 */       push(16777217);
/* 1106 */       break;
/*      */     case 97: 
/*      */     case 101: 
/*      */     case 105: 
/*      */     case 109: 
/*      */     case 113: 
/*      */     case 127: 
/*      */     case 129: 
/*      */     case 131: 
/* 1115 */       pop(4);
/* 1116 */       push(16777220);
/* 1117 */       push(16777216);
/* 1118 */       break;
/*      */     case 98: 
/*      */     case 102: 
/*      */     case 106: 
/*      */     case 110: 
/*      */     case 114: 
/*      */     case 137: 
/*      */     case 144: 
/* 1126 */       pop(2);
/* 1127 */       push(16777218);
/* 1128 */       break;
/*      */     case 99: 
/*      */     case 103: 
/*      */     case 107: 
/*      */     case 111: 
/*      */     case 115: 
/* 1134 */       pop(4);
/* 1135 */       push(16777219);
/* 1136 */       push(16777216);
/* 1137 */       break;
/*      */     case 121: 
/*      */     case 123: 
/*      */     case 125: 
/* 1141 */       pop(3);
/* 1142 */       push(16777220);
/* 1143 */       push(16777216);
/* 1144 */       break;
/*      */     case 132: 
/* 1146 */       set(arg, 16777217);
/* 1147 */       break;
/*      */     case 133: 
/*      */     case 140: 
/* 1150 */       pop(1);
/* 1151 */       push(16777220);
/* 1152 */       push(16777216);
/* 1153 */       break;
/*      */     case 134: 
/* 1155 */       pop(1);
/* 1156 */       push(16777218);
/* 1157 */       break;
/*      */     case 135: 
/*      */     case 141: 
/* 1160 */       pop(1);
/* 1161 */       push(16777219);
/* 1162 */       push(16777216);
/* 1163 */       break;
/*      */     case 139: 
/*      */     case 190: 
/*      */     case 193: 
/* 1167 */       pop(1);
/* 1168 */       push(16777217);
/* 1169 */       break;
/*      */     case 148: 
/*      */     case 151: 
/*      */     case 152: 
/* 1173 */       pop(4);
/* 1174 */       push(16777217);
/* 1175 */       break;
/*      */     case 168: 
/*      */     case 169: 
/* 1178 */       throw new RuntimeException("JSR/RET are not supported with computeFrames option");
/*      */     
/*      */     case 178: 
/* 1181 */       push(cw, item.strVal3);
/* 1182 */       break;
/*      */     case 179: 
/* 1184 */       pop(item.strVal3);
/* 1185 */       break;
/*      */     case 180: 
/* 1187 */       pop(1);
/* 1188 */       push(cw, item.strVal3);
/* 1189 */       break;
/*      */     case 181: 
/* 1191 */       pop(item.strVal3);
/* 1192 */       pop();
/* 1193 */       break;
/*      */     case 182: 
/*      */     case 183: 
/*      */     case 184: 
/*      */     case 185: 
/* 1198 */       pop(item.strVal3);
/* 1199 */       if (opcode != 184) {
/* 1200 */         t1 = pop();
/* 1201 */         if ((opcode == 183) && (item.strVal2.charAt(0) == '<'))
/*      */         {
/* 1203 */           init(t1);
/*      */         }
/*      */       }
/* 1206 */       push(cw, item.strVal3);
/* 1207 */       break;
/*      */     case 186: 
/* 1209 */       pop(item.strVal2);
/* 1210 */       push(cw, item.strVal2);
/* 1211 */       break;
/*      */     case 187: 
/* 1213 */       push(0x1800000 | cw.addUninitializedType(item.strVal1, arg));
/* 1214 */       break;
/*      */     case 188: 
/* 1216 */       pop();
/* 1217 */       switch (arg) {
/*      */       case 4: 
/* 1219 */         push(285212681);
/* 1220 */         break;
/*      */       case 5: 
/* 1222 */         push(285212683);
/* 1223 */         break;
/*      */       case 8: 
/* 1225 */         push(285212682);
/* 1226 */         break;
/*      */       case 9: 
/* 1228 */         push(285212684);
/* 1229 */         break;
/*      */       case 10: 
/* 1231 */         push(285212673);
/* 1232 */         break;
/*      */       case 6: 
/* 1234 */         push(285212674);
/* 1235 */         break;
/*      */       case 7: 
/* 1237 */         push(285212675);
/* 1238 */         break;
/*      */       
/*      */       default: 
/* 1241 */         push(285212676); }
/* 1242 */       break;
/*      */     
/*      */ 
/*      */     case 189: 
/* 1246 */       s = item.strVal1;
/* 1247 */       pop();
/* 1248 */       if (s.charAt(0) == '[') {
/* 1249 */         push(cw, '[' + s);
/*      */       } else {
/* 1251 */         push(0x11700000 | cw.addType(s));
/*      */       }
/* 1253 */       break;
/*      */     case 192: 
/* 1255 */       s = item.strVal1;
/* 1256 */       pop();
/* 1257 */       if (s.charAt(0) == '[') {
/* 1258 */         push(cw, s);
/*      */       } else {
/* 1260 */         push(0x1700000 | cw.addType(s));
/*      */       }
/* 1262 */       break;
/*      */     case 19: case 20: case 26: case 27: case 28: case 29: case 30: case 31: case 32: case 33: case 34: case 35: case 36: case 37: case 38: case 39: case 40: case 41: case 42: case 43: case 44: case 45: case 59: 
/*      */     case 60: case 61: case 62: case 63: case 64: case 65: case 66: case 67: case 68: case 69: case 70: case 71: case 72: case 73: case 74: case 75: case 76: case 77: case 78: case 196: case 197: default: 
/* 1265 */       pop(arg);
/* 1266 */       push(cw, item.strVal1);
/*      */     }
/*      */     
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   boolean merge(ClassWriter cw, Frame frame, int edge)
/*      */   {
/* 1287 */     boolean changed = false;
/*      */     
/*      */ 
/* 1290 */     int nLocal = this.inputLocals.length;
/* 1291 */     int nStack = this.inputStack.length;
/* 1292 */     if (frame.inputLocals == null) {
/* 1293 */       frame.inputLocals = new int[nLocal];
/* 1294 */       changed = true;
/*      */     }
/*      */     
/* 1297 */     for (int i = 0; i < nLocal; i++) { int t;
/* 1298 */       if ((this.outputLocals != null) && (i < this.outputLocals.length)) {
/* 1299 */         int s = this.outputLocals[i];
/* 1300 */         int t; if (s == 0) {
/* 1301 */           t = this.inputLocals[i];
/*      */         } else {
/* 1303 */           int dim = s & 0xF0000000;
/* 1304 */           int kind = s & 0xF000000;
/* 1305 */           int t; if (kind == 16777216) {
/* 1306 */             t = s; } else { int t;
/*      */             int t;
/* 1308 */             if (kind == 33554432) {
/* 1309 */               t = dim + this.inputLocals[(s & 0x7FFFFF)];
/*      */             } else {
/* 1311 */               t = dim + this.inputStack[(nStack - (s & 0x7FFFFF))];
/*      */             }
/* 1313 */             if (((s & 0x800000) != 0) && ((t == 16777220) || (t == 16777219)))
/*      */             {
/* 1315 */               t = 16777216;
/*      */             }
/*      */           }
/*      */         }
/*      */       } else {
/* 1320 */         t = this.inputLocals[i];
/*      */       }
/* 1322 */       if (this.initializations != null) {
/* 1323 */         t = init(cw, t);
/*      */       }
/* 1325 */       changed |= merge(cw, t, frame.inputLocals, i);
/*      */     }
/*      */     
/* 1328 */     if (edge > 0) {
/* 1329 */       for (i = 0; i < nLocal; i++) {
/* 1330 */         int t = this.inputLocals[i];
/* 1331 */         changed |= merge(cw, t, frame.inputLocals, i);
/*      */       }
/* 1333 */       if (frame.inputStack == null) {
/* 1334 */         frame.inputStack = new int[1];
/* 1335 */         changed = true;
/*      */       }
/* 1337 */       changed |= merge(cw, edge, frame.inputStack, 0);
/* 1338 */       return changed;
/*      */     }
/*      */     
/* 1341 */     int nInputStack = this.inputStack.length + this.owner.inputStackTop;
/* 1342 */     if (frame.inputStack == null) {
/* 1343 */       frame.inputStack = new int[nInputStack + this.outputStackTop];
/* 1344 */       changed = true;
/*      */     }
/*      */     
/* 1347 */     for (i = 0; i < nInputStack; i++) {
/* 1348 */       int t = this.inputStack[i];
/* 1349 */       if (this.initializations != null) {
/* 1350 */         t = init(cw, t);
/*      */       }
/* 1352 */       changed |= merge(cw, t, frame.inputStack, i);
/*      */     }
/* 1354 */     for (i = 0; i < this.outputStackTop; i++) {
/* 1355 */       int s = this.outputStack[i];
/* 1356 */       int dim = s & 0xF0000000;
/* 1357 */       int kind = s & 0xF000000;
/* 1358 */       int t; int t; if (kind == 16777216) {
/* 1359 */         t = s;
/*      */       } else { int t;
/* 1361 */         if (kind == 33554432) {
/* 1362 */           t = dim + this.inputLocals[(s & 0x7FFFFF)];
/*      */         } else {
/* 1364 */           t = dim + this.inputStack[(nStack - (s & 0x7FFFFF))];
/*      */         }
/* 1366 */         if (((s & 0x800000) != 0) && ((t == 16777220) || (t == 16777219)))
/*      */         {
/* 1368 */           t = 16777216;
/*      */         }
/*      */       }
/* 1371 */       if (this.initializations != null) {
/* 1372 */         t = init(cw, t);
/*      */       }
/* 1374 */       changed |= merge(cw, t, frame.inputStack, nInputStack + i);
/*      */     }
/* 1376 */     return changed;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static boolean merge(ClassWriter cw, int t, int[] types, int index)
/*      */   {
/* 1397 */     int u = types[index];
/* 1398 */     if (u == t)
/*      */     {
/* 1400 */       return false;
/*      */     }
/* 1402 */     if ((t & 0xFFFFFFF) == 16777221) {
/* 1403 */       if (u == 16777221) {
/* 1404 */         return false;
/*      */       }
/* 1406 */       t = 16777221;
/*      */     }
/* 1408 */     if (u == 0)
/*      */     {
/* 1410 */       types[index] = t;
/* 1411 */       return true; }
/*      */     int v;
/*      */     int v;
/* 1414 */     if (((u & 0xFF00000) == 24117248) || ((u & 0xF0000000) != 0))
/*      */     {
/* 1416 */       if (t == 16777221)
/*      */       {
/* 1418 */         return false; }
/* 1419 */       int v; if ((t & 0xFFF00000) == (u & 0xFFF00000)) { int v;
/* 1420 */         if ((u & 0xFF00000) == 24117248)
/*      */         {
/*      */ 
/*      */ 
/* 1424 */           v = t & 0xF0000000 | 0x1700000 | cw.getMergedType(t & 0xFFFFF, u & 0xFFFFF);
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/* 1429 */           v = 0x1700000 | cw.addType("java/lang/Object"); }
/*      */       } else { int v;
/* 1431 */         if (((t & 0xFF00000) == 24117248) || ((t & 0xF0000000) != 0))
/*      */         {
/*      */ 
/* 1434 */           v = 0x1700000 | cw.addType("java/lang/Object");
/*      */         }
/*      */         else
/* 1437 */           v = 16777216;
/*      */       } } else { int v;
/* 1439 */       if (u == 16777221)
/*      */       {
/*      */ 
/* 1442 */         v = ((t & 0xFF00000) == 24117248) || ((t & 0xF0000000) != 0) ? t : 16777216;
/*      */       }
/*      */       else
/* 1445 */         v = 16777216;
/*      */     }
/* 1447 */     if (u != v) {
/* 1448 */       types[index] = v;
/* 1449 */       return true;
/*      */     }
/* 1451 */     return false;
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\asm\Frame.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */