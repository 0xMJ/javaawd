/*     */ package clojure.asm.commons;
/*     */ 
/*     */ import clojure.asm.Type;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Method
/*     */ {
/*     */   private final String name;
/*     */   private final String desc;
/*  62 */   private static final Map<String, String> DESCRIPTORS = new HashMap();
/*  63 */   static { DESCRIPTORS.put("void", "V");
/*  64 */     DESCRIPTORS.put("byte", "B");
/*  65 */     DESCRIPTORS.put("char", "C");
/*  66 */     DESCRIPTORS.put("double", "D");
/*  67 */     DESCRIPTORS.put("float", "F");
/*  68 */     DESCRIPTORS.put("int", "I");
/*  69 */     DESCRIPTORS.put("long", "J");
/*  70 */     DESCRIPTORS.put("short", "S");
/*  71 */     DESCRIPTORS.put("boolean", "Z");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Method(String name, String desc)
/*     */   {
/*  83 */     this.name = name;
/*  84 */     this.desc = desc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Method(String name, Type returnType, Type[] argumentTypes)
/*     */   {
/*  99 */     this(name, Type.getMethodDescriptor(returnType, argumentTypes));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Method getMethod(java.lang.reflect.Method m)
/*     */   {
/* 111 */     return new Method(m.getName(), Type.getMethodDescriptor(m));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Method getMethod(Constructor<?> c)
/*     */   {
/* 123 */     return new Method("<init>", Type.getConstructorDescriptor(c));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Method getMethod(String method)
/*     */     throws IllegalArgumentException
/*     */   {
/* 144 */     return getMethod(method, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Method getMethod(String method, boolean defaultPackage)
/*     */     throws IllegalArgumentException
/*     */   {
/* 171 */     int space = method.indexOf(' ');
/* 172 */     int start = method.indexOf('(', space) + 1;
/* 173 */     int end = method.indexOf(')', start);
/* 174 */     if ((space == -1) || (start == -1) || (end == -1)) {
/* 175 */       throw new IllegalArgumentException();
/*     */     }
/* 177 */     String returnType = method.substring(0, space);
/* 178 */     String methodName = method.substring(space + 1, start - 1).trim();
/* 179 */     StringBuffer sb = new StringBuffer();
/* 180 */     sb.append('(');
/*     */     int p;
/*     */     do
/*     */     {
/* 184 */       p = method.indexOf(',', start);
/* 185 */       String s; String s; if (p == -1) {
/* 186 */         s = map(method.substring(start, end).trim(), defaultPackage);
/*     */       } else {
/* 188 */         s = map(method.substring(start, p).trim(), defaultPackage);
/* 189 */         start = p + 1;
/*     */       }
/* 191 */       sb.append(s);
/* 192 */     } while (p != -1);
/* 193 */     sb.append(')');
/* 194 */     sb.append(map(returnType, defaultPackage));
/* 195 */     return new Method(methodName, sb.toString());
/*     */   }
/*     */   
/*     */   private static String map(String type, boolean defaultPackage) {
/* 199 */     if ("".equals(type)) {
/* 200 */       return type;
/*     */     }
/*     */     
/* 203 */     StringBuffer sb = new StringBuffer();
/* 204 */     int index = 0;
/* 205 */     while ((index = type.indexOf("[]", index) + 1) > 0) {
/* 206 */       sb.append('[');
/*     */     }
/*     */     
/* 209 */     String t = type.substring(0, type.length() - sb.length() * 2);
/* 210 */     String desc = (String)DESCRIPTORS.get(t);
/* 211 */     if (desc != null) {
/* 212 */       sb.append(desc);
/*     */     } else {
/* 214 */       sb.append('L');
/* 215 */       if (t.indexOf('.') < 0) {
/* 216 */         if (!defaultPackage) {
/* 217 */           sb.append("java/lang/");
/*     */         }
/* 219 */         sb.append(t);
/*     */       } else {
/* 221 */         sb.append(t.replace('.', '/'));
/*     */       }
/* 223 */       sb.append(';');
/*     */     }
/* 225 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/* 234 */     return this.name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getDescriptor()
/*     */   {
/* 243 */     return this.desc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Type getReturnType()
/*     */   {
/* 252 */     return Type.getReturnType(this.desc);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Type[] getArgumentTypes()
/*     */   {
/* 261 */     return Type.getArgumentTypes(this.desc);
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 266 */     return this.name + this.desc;
/*     */   }
/*     */   
/*     */   public boolean equals(Object o)
/*     */   {
/* 271 */     if (!(o instanceof Method)) {
/* 272 */       return false;
/*     */     }
/* 274 */     Method other = (Method)o;
/* 275 */     return (this.name.equals(other.name)) && (this.desc.equals(other.desc));
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 280 */     return this.name.hashCode() ^ this.desc.hashCode();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\asm\commons\Method.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */