/*    */ package clojure.asm.commons;
/*    */ 
/*    */ import clojure.asm.ClassVisitor;
/*    */ import clojure.asm.MethodVisitor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StaticInitMerger
/*    */   extends ClassVisitor
/*    */ {
/*    */   private String name;
/*    */   private MethodVisitor clinit;
/*    */   private final String prefix;
/*    */   private int counter;
/*    */   
/*    */   public StaticInitMerger(String prefix, ClassVisitor cv)
/*    */   {
/* 52 */     this(262144, prefix, cv);
/*    */   }
/*    */   
/*    */   protected StaticInitMerger(int api, String prefix, ClassVisitor cv)
/*    */   {
/* 57 */     super(api, cv);
/* 58 */     this.prefix = prefix;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void visit(int version, int access, String name, String signature, String superName, String[] interfaces)
/*    */   {
/* 65 */     this.cv.visit(version, access, name, signature, superName, interfaces);
/* 66 */     this.name = name;
/*    */   }
/*    */   
/*    */ 
/*    */   public MethodVisitor visitMethod(int access, String name, String desc, String signature, String[] exceptions)
/*    */   {
/*    */     MethodVisitor mv;
/* 73 */     if ("<clinit>".equals(name)) {
/* 74 */       int a = 10;
/* 75 */       String n = this.prefix + this.counter++;
/* 76 */       MethodVisitor mv = this.cv.visitMethod(a, n, desc, signature, exceptions);
/*    */       
/* 78 */       if (this.clinit == null) {
/* 79 */         this.clinit = this.cv.visitMethod(a, name, desc, null, null);
/*    */       }
/* 81 */       this.clinit.visitMethodInsn(184, this.name, n, desc);
/*    */     } else {
/* 83 */       mv = this.cv.visitMethod(access, name, desc, signature, exceptions);
/*    */     }
/* 85 */     return mv;
/*    */   }
/*    */   
/*    */   public void visitEnd()
/*    */   {
/* 90 */     if (this.clinit != null) {
/* 91 */       this.clinit.visitInsn(177);
/* 92 */       this.clinit.visitMaxs(0, 0);
/*    */     }
/* 94 */     this.cv.visitEnd();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\asm\commons\StaticInitMerger.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */