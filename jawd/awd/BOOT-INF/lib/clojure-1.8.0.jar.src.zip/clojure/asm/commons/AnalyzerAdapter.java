/*     */ package clojure.asm.commons;
/*     */ 
/*     */ import clojure.asm.Handle;
/*     */ import clojure.asm.Label;
/*     */ import clojure.asm.MethodVisitor;
/*     */ import clojure.asm.Opcodes;
/*     */ import clojure.asm.Type;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnalyzerAdapter
/*     */   extends MethodVisitor
/*     */ {
/*     */   public List<Object> locals;
/*     */   public List<Object> stack;
/*     */   private List<Label> labels;
/*     */   public Map<Object, Object> uninitializedTypes;
/*     */   private int maxStack;
/*     */   private int maxLocals;
/*     */   private String owner;
/*     */   
/*     */   public AnalyzerAdapter(String owner, int access, String name, String desc, MethodVisitor mv)
/*     */   {
/* 142 */     this(262144, owner, access, name, desc, mv);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected AnalyzerAdapter(int api, String owner, int access, String name, String desc, MethodVisitor mv)
/*     */   {
/* 166 */     super(api, mv);
/* 167 */     this.owner = owner;
/* 168 */     this.locals = new ArrayList();
/* 169 */     this.stack = new ArrayList();
/* 170 */     this.uninitializedTypes = new HashMap();
/*     */     
/* 172 */     if ((access & 0x8) == 0) {
/* 173 */       if ("<init>".equals(name)) {
/* 174 */         this.locals.add(Opcodes.UNINITIALIZED_THIS);
/*     */       } else {
/* 176 */         this.locals.add(owner);
/*     */       }
/*     */     }
/* 179 */     Type[] types = Type.getArgumentTypes(desc);
/* 180 */     for (int i = 0; i < types.length; i++) {
/* 181 */       Type type = types[i];
/* 182 */       switch (type.getSort()) {
/*     */       case 1: 
/*     */       case 2: 
/*     */       case 3: 
/*     */       case 4: 
/*     */       case 5: 
/* 188 */         this.locals.add(Opcodes.INTEGER);
/* 189 */         break;
/*     */       case 6: 
/* 191 */         this.locals.add(Opcodes.FLOAT);
/* 192 */         break;
/*     */       case 7: 
/* 194 */         this.locals.add(Opcodes.LONG);
/* 195 */         this.locals.add(Opcodes.TOP);
/* 196 */         break;
/*     */       case 8: 
/* 198 */         this.locals.add(Opcodes.DOUBLE);
/* 199 */         this.locals.add(Opcodes.TOP);
/* 200 */         break;
/*     */       case 9: 
/* 202 */         this.locals.add(types[i].getDescriptor());
/* 203 */         break;
/*     */       
/*     */       default: 
/* 206 */         this.locals.add(types[i].getInternalName());
/*     */       }
/*     */       
/*     */     }
/*     */   }
/*     */   
/*     */   public void visitFrame(int type, int nLocal, Object[] local, int nStack, Object[] stack)
/*     */   {
/* 214 */     if (type != -1) {
/* 215 */       throw new IllegalStateException("ClassReader.accept() should be called with EXPAND_FRAMES flag");
/*     */     }
/*     */     
/*     */ 
/* 219 */     if (this.mv != null) {
/* 220 */       this.mv.visitFrame(type, nLocal, local, nStack, stack);
/*     */     }
/*     */     
/* 223 */     if (this.locals != null) {
/* 224 */       this.locals.clear();
/* 225 */       this.stack.clear();
/*     */     } else {
/* 227 */       this.locals = new ArrayList();
/* 228 */       this.stack = new ArrayList();
/*     */     }
/* 230 */     visitFrameTypes(nLocal, local, this.locals);
/* 231 */     visitFrameTypes(nStack, stack, this.stack);
/* 232 */     this.maxStack = Math.max(this.maxStack, this.stack.size());
/*     */   }
/*     */   
/*     */   private static void visitFrameTypes(int n, Object[] types, List<Object> result)
/*     */   {
/* 237 */     for (int i = 0; i < n; i++) {
/* 238 */       Object type = types[i];
/* 239 */       result.add(type);
/* 240 */       if ((type == Opcodes.LONG) || (type == Opcodes.DOUBLE)) {
/* 241 */         result.add(Opcodes.TOP);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void visitInsn(int opcode)
/*     */   {
/* 248 */     if (this.mv != null) {
/* 249 */       this.mv.visitInsn(opcode);
/*     */     }
/* 251 */     execute(opcode, 0, null);
/* 252 */     if (((opcode >= 172) && (opcode <= 177)) || (opcode == 191))
/*     */     {
/* 254 */       this.locals = null;
/* 255 */       this.stack = null;
/*     */     }
/*     */   }
/*     */   
/*     */   public void visitIntInsn(int opcode, int operand)
/*     */   {
/* 261 */     if (this.mv != null) {
/* 262 */       this.mv.visitIntInsn(opcode, operand);
/*     */     }
/* 264 */     execute(opcode, operand, null);
/*     */   }
/*     */   
/*     */   public void visitVarInsn(int opcode, int var)
/*     */   {
/* 269 */     if (this.mv != null) {
/* 270 */       this.mv.visitVarInsn(opcode, var);
/*     */     }
/* 272 */     execute(opcode, var, null);
/*     */   }
/*     */   
/*     */   public void visitTypeInsn(int opcode, String type)
/*     */   {
/* 277 */     if (opcode == 187) {
/* 278 */       if (this.labels == null) {
/* 279 */         Label l = new Label();
/* 280 */         this.labels = new ArrayList(3);
/* 281 */         this.labels.add(l);
/* 282 */         if (this.mv != null) {
/* 283 */           this.mv.visitLabel(l);
/*     */         }
/*     */       }
/* 286 */       for (int i = 0; i < this.labels.size(); i++) {
/* 287 */         this.uninitializedTypes.put(this.labels.get(i), type);
/*     */       }
/*     */     }
/* 290 */     if (this.mv != null) {
/* 291 */       this.mv.visitTypeInsn(opcode, type);
/*     */     }
/* 293 */     execute(opcode, 0, type);
/*     */   }
/*     */   
/*     */ 
/*     */   public void visitFieldInsn(int opcode, String owner, String name, String desc)
/*     */   {
/* 299 */     if (this.mv != null) {
/* 300 */       this.mv.visitFieldInsn(opcode, owner, name, desc);
/*     */     }
/* 302 */     execute(opcode, 0, desc);
/*     */   }
/*     */   
/*     */ 
/*     */   public void visitMethodInsn(int opcode, String owner, String name, String desc)
/*     */   {
/* 308 */     if (this.mv != null) {
/* 309 */       this.mv.visitMethodInsn(opcode, owner, name, desc);
/*     */     }
/* 311 */     if (this.locals == null) {
/* 312 */       this.labels = null;
/* 313 */       return;
/*     */     }
/* 315 */     pop(desc);
/* 316 */     if (opcode != 184) {
/* 317 */       Object t = pop();
/* 318 */       if ((opcode == 183) && (name.charAt(0) == '<')) { Object u;
/*     */         Object u;
/* 320 */         if (t == Opcodes.UNINITIALIZED_THIS) {
/* 321 */           u = this.owner;
/*     */         } else {
/* 323 */           u = this.uninitializedTypes.get(t);
/*     */         }
/* 325 */         for (int i = 0; i < this.locals.size(); i++) {
/* 326 */           if (this.locals.get(i) == t) {
/* 327 */             this.locals.set(i, u);
/*     */           }
/*     */         }
/* 330 */         for (int i = 0; i < this.stack.size(); i++) {
/* 331 */           if (this.stack.get(i) == t) {
/* 332 */             this.stack.set(i, u);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 337 */     pushDesc(desc);
/* 338 */     this.labels = null;
/*     */   }
/*     */   
/*     */ 
/*     */   public void visitInvokeDynamicInsn(String name, String desc, Handle bsm, Object... bsmArgs)
/*     */   {
/* 344 */     if (this.mv != null) {
/* 345 */       this.mv.visitInvokeDynamicInsn(name, desc, bsm, bsmArgs);
/*     */     }
/* 347 */     if (this.locals == null) {
/* 348 */       this.labels = null;
/* 349 */       return;
/*     */     }
/* 351 */     pop(desc);
/* 352 */     pushDesc(desc);
/* 353 */     this.labels = null;
/*     */   }
/*     */   
/*     */   public void visitJumpInsn(int opcode, Label label)
/*     */   {
/* 358 */     if (this.mv != null) {
/* 359 */       this.mv.visitJumpInsn(opcode, label);
/*     */     }
/* 361 */     execute(opcode, 0, null);
/* 362 */     if (opcode == 167) {
/* 363 */       this.locals = null;
/* 364 */       this.stack = null;
/*     */     }
/*     */   }
/*     */   
/*     */   public void visitLabel(Label label)
/*     */   {
/* 370 */     if (this.mv != null) {
/* 371 */       this.mv.visitLabel(label);
/*     */     }
/* 373 */     if (this.labels == null) {
/* 374 */       this.labels = new ArrayList(3);
/*     */     }
/* 376 */     this.labels.add(label);
/*     */   }
/*     */   
/*     */   public void visitLdcInsn(Object cst)
/*     */   {
/* 381 */     if (this.mv != null) {
/* 382 */       this.mv.visitLdcInsn(cst);
/*     */     }
/* 384 */     if (this.locals == null) {
/* 385 */       this.labels = null;
/* 386 */       return;
/*     */     }
/* 388 */     if ((cst instanceof Integer)) {
/* 389 */       push(Opcodes.INTEGER);
/* 390 */     } else if ((cst instanceof Long)) {
/* 391 */       push(Opcodes.LONG);
/* 392 */       push(Opcodes.TOP);
/* 393 */     } else if ((cst instanceof Float)) {
/* 394 */       push(Opcodes.FLOAT);
/* 395 */     } else if ((cst instanceof Double)) {
/* 396 */       push(Opcodes.DOUBLE);
/* 397 */       push(Opcodes.TOP);
/* 398 */     } else if ((cst instanceof String)) {
/* 399 */       push("java/lang/String");
/* 400 */     } else if ((cst instanceof Type)) {
/* 401 */       int sort = ((Type)cst).getSort();
/* 402 */       if ((sort == 10) || (sort == 9)) {
/* 403 */         push("java/lang/Class");
/* 404 */       } else if (sort == 11) {
/* 405 */         push("java/lang/invoke/MethodType");
/*     */       } else {
/* 407 */         throw new IllegalArgumentException();
/*     */       }
/* 409 */     } else if ((cst instanceof Handle)) {
/* 410 */       push("java/lang/invoke/MethodHandle");
/*     */     } else {
/* 412 */       throw new IllegalArgumentException();
/*     */     }
/* 414 */     this.labels = null;
/*     */   }
/*     */   
/*     */   public void visitIincInsn(int var, int increment)
/*     */   {
/* 419 */     if (this.mv != null) {
/* 420 */       this.mv.visitIincInsn(var, increment);
/*     */     }
/* 422 */     execute(132, var, null);
/*     */   }
/*     */   
/*     */ 
/*     */   public void visitTableSwitchInsn(int min, int max, Label dflt, Label... labels)
/*     */   {
/* 428 */     if (this.mv != null) {
/* 429 */       this.mv.visitTableSwitchInsn(min, max, dflt, labels);
/*     */     }
/* 431 */     execute(170, 0, null);
/* 432 */     this.locals = null;
/* 433 */     this.stack = null;
/*     */   }
/*     */   
/*     */ 
/*     */   public void visitLookupSwitchInsn(Label dflt, int[] keys, Label[] labels)
/*     */   {
/* 439 */     if (this.mv != null) {
/* 440 */       this.mv.visitLookupSwitchInsn(dflt, keys, labels);
/*     */     }
/* 442 */     execute(171, 0, null);
/* 443 */     this.locals = null;
/* 444 */     this.stack = null;
/*     */   }
/*     */   
/*     */   public void visitMultiANewArrayInsn(String desc, int dims)
/*     */   {
/* 449 */     if (this.mv != null) {
/* 450 */       this.mv.visitMultiANewArrayInsn(desc, dims);
/*     */     }
/* 452 */     execute(197, dims, desc);
/*     */   }
/*     */   
/*     */   public void visitMaxs(int maxStack, int maxLocals)
/*     */   {
/* 457 */     if (this.mv != null) {
/* 458 */       this.maxStack = Math.max(this.maxStack, maxStack);
/* 459 */       this.maxLocals = Math.max(this.maxLocals, maxLocals);
/* 460 */       this.mv.visitMaxs(this.maxStack, this.maxLocals);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private Object get(int local)
/*     */   {
/* 467 */     this.maxLocals = Math.max(this.maxLocals, local);
/* 468 */     return local < this.locals.size() ? this.locals.get(local) : Opcodes.TOP;
/*     */   }
/*     */   
/*     */   private void set(int local, Object type) {
/* 472 */     this.maxLocals = Math.max(this.maxLocals, local);
/* 473 */     while (local >= this.locals.size()) {
/* 474 */       this.locals.add(Opcodes.TOP);
/*     */     }
/* 476 */     this.locals.set(local, type);
/*     */   }
/*     */   
/*     */   private void push(Object type) {
/* 480 */     this.stack.add(type);
/* 481 */     this.maxStack = Math.max(this.maxStack, this.stack.size());
/*     */   }
/*     */   
/*     */   private void pushDesc(String desc) {
/* 485 */     int index = desc.charAt(0) == '(' ? desc.indexOf(')') + 1 : 0;
/* 486 */     switch (desc.charAt(index)) {
/*     */     case 'V': 
/*     */       
/*     */     case 'B': 
/*     */     case 'C': 
/*     */     case 'I': 
/*     */     case 'S': 
/*     */     case 'Z': 
/* 494 */       push(Opcodes.INTEGER);
/* 495 */       return;
/*     */     case 'F': 
/* 497 */       push(Opcodes.FLOAT);
/* 498 */       return;
/*     */     case 'J': 
/* 500 */       push(Opcodes.LONG);
/* 501 */       push(Opcodes.TOP);
/* 502 */       return;
/*     */     case 'D': 
/* 504 */       push(Opcodes.DOUBLE);
/* 505 */       push(Opcodes.TOP);
/* 506 */       return;
/*     */     case '[': 
/* 508 */       if (index == 0) {
/* 509 */         push(desc);
/*     */       } else {
/* 511 */         push(desc.substring(index, desc.length()));
/*     */       }
/* 513 */       break;
/*     */     case 'E': case 'G': case 'H': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': 
/*     */     case 'Q': case 'R': case 'T': case 'U': case 'W': case 'X': case 'Y': default: 
/* 516 */       if (index == 0) {
/* 517 */         push(desc.substring(1, desc.length() - 1));
/*     */       } else
/* 519 */         push(desc.substring(index + 1, desc.length() - 1));
/*     */       break;
/*     */     }
/*     */   }
/*     */   
/*     */   private Object pop() {
/* 525 */     return this.stack.remove(this.stack.size() - 1);
/*     */   }
/*     */   
/*     */   private void pop(int n) {
/* 529 */     int size = this.stack.size();
/* 530 */     int end = size - n;
/* 531 */     for (int i = size - 1; i >= end; i--) {
/* 532 */       this.stack.remove(i);
/*     */     }
/*     */   }
/*     */   
/*     */   private void pop(String desc) {
/* 537 */     char c = desc.charAt(0);
/* 538 */     if (c == '(') {
/* 539 */       int n = 0;
/* 540 */       Type[] types = Type.getArgumentTypes(desc);
/* 541 */       for (int i = 0; i < types.length; i++) {
/* 542 */         n += types[i].getSize();
/*     */       }
/* 544 */       pop(n);
/* 545 */     } else if ((c == 'J') || (c == 'D')) {
/* 546 */       pop(2);
/*     */     } else {
/* 548 */       pop(1);
/*     */     }
/*     */   }
/*     */   
/*     */   private void execute(int opcode, int iarg, String sarg) {
/* 553 */     if (this.locals == null) {
/* 554 */       this.labels = null; return; }
/*     */     Object t1;
/*     */     Object t2;
/*     */     Object t3;
/* 558 */     switch (opcode) {
/*     */     case 0: 
/*     */     case 116: 
/*     */     case 117: 
/*     */     case 118: 
/*     */     case 119: 
/*     */     case 145: 
/*     */     case 146: 
/*     */     case 147: 
/*     */     case 167: 
/*     */     case 177: 
/*     */       break;
/*     */     case 1: 
/* 571 */       push(Opcodes.NULL);
/* 572 */       break;
/*     */     case 2: 
/*     */     case 3: 
/*     */     case 4: 
/*     */     case 5: 
/*     */     case 6: 
/*     */     case 7: 
/*     */     case 8: 
/*     */     case 16: 
/*     */     case 17: 
/* 582 */       push(Opcodes.INTEGER);
/* 583 */       break;
/*     */     case 9: 
/*     */     case 10: 
/* 586 */       push(Opcodes.LONG);
/* 587 */       push(Opcodes.TOP);
/* 588 */       break;
/*     */     case 11: 
/*     */     case 12: 
/*     */     case 13: 
/* 592 */       push(Opcodes.FLOAT);
/* 593 */       break;
/*     */     case 14: 
/*     */     case 15: 
/* 596 */       push(Opcodes.DOUBLE);
/* 597 */       push(Opcodes.TOP);
/* 598 */       break;
/*     */     case 21: 
/*     */     case 23: 
/*     */     case 25: 
/* 602 */       push(get(iarg));
/* 603 */       break;
/*     */     case 22: 
/*     */     case 24: 
/* 606 */       push(get(iarg));
/* 607 */       push(Opcodes.TOP);
/* 608 */       break;
/*     */     case 46: 
/*     */     case 51: 
/*     */     case 52: 
/*     */     case 53: 
/* 613 */       pop(2);
/* 614 */       push(Opcodes.INTEGER);
/* 615 */       break;
/*     */     case 47: 
/*     */     case 143: 
/* 618 */       pop(2);
/* 619 */       push(Opcodes.LONG);
/* 620 */       push(Opcodes.TOP);
/* 621 */       break;
/*     */     case 48: 
/* 623 */       pop(2);
/* 624 */       push(Opcodes.FLOAT);
/* 625 */       break;
/*     */     case 49: 
/*     */     case 138: 
/* 628 */       pop(2);
/* 629 */       push(Opcodes.DOUBLE);
/* 630 */       push(Opcodes.TOP);
/* 631 */       break;
/*     */     case 50: 
/* 633 */       pop(1);
/* 634 */       t1 = pop();
/* 635 */       if ((t1 instanceof String)) {
/* 636 */         pushDesc(((String)t1).substring(1));
/*     */       } else {
/* 638 */         push("java/lang/Object");
/*     */       }
/* 640 */       break;
/*     */     case 54: 
/*     */     case 56: 
/*     */     case 58: 
/* 644 */       t1 = pop();
/* 645 */       set(iarg, t1);
/* 646 */       if (iarg > 0) {
/* 647 */         t2 = get(iarg - 1);
/* 648 */         if ((t2 == Opcodes.LONG) || (t2 == Opcodes.DOUBLE)) {
/* 649 */           set(iarg - 1, Opcodes.TOP);
/*     */         }
/*     */       }
/*     */       break;
/*     */     case 55: 
/*     */     case 57: 
/* 655 */       pop(1);
/* 656 */       t1 = pop();
/* 657 */       set(iarg, t1);
/* 658 */       set(iarg + 1, Opcodes.TOP);
/* 659 */       if (iarg > 0) {
/* 660 */         t2 = get(iarg - 1);
/* 661 */         if ((t2 == Opcodes.LONG) || (t2 == Opcodes.DOUBLE)) {
/* 662 */           set(iarg - 1, Opcodes.TOP);
/*     */         }
/*     */       }
/*     */       break;
/*     */     case 79: 
/*     */     case 81: 
/*     */     case 83: 
/*     */     case 84: 
/*     */     case 85: 
/*     */     case 86: 
/* 672 */       pop(3);
/* 673 */       break;
/*     */     case 80: 
/*     */     case 82: 
/* 676 */       pop(4);
/* 677 */       break;
/*     */     case 87: 
/*     */     case 153: 
/*     */     case 154: 
/*     */     case 155: 
/*     */     case 156: 
/*     */     case 157: 
/*     */     case 158: 
/*     */     case 170: 
/*     */     case 171: 
/*     */     case 172: 
/*     */     case 174: 
/*     */     case 176: 
/*     */     case 191: 
/*     */     case 194: 
/*     */     case 195: 
/*     */     case 198: 
/*     */     case 199: 
/* 695 */       pop(1);
/* 696 */       break;
/*     */     case 88: 
/*     */     case 159: 
/*     */     case 160: 
/*     */     case 161: 
/*     */     case 162: 
/*     */     case 163: 
/*     */     case 164: 
/*     */     case 165: 
/*     */     case 166: 
/*     */     case 173: 
/*     */     case 175: 
/* 708 */       pop(2);
/* 709 */       break;
/*     */     case 89: 
/* 711 */       t1 = pop();
/* 712 */       push(t1);
/* 713 */       push(t1);
/* 714 */       break;
/*     */     case 90: 
/* 716 */       t1 = pop();
/* 717 */       t2 = pop();
/* 718 */       push(t1);
/* 719 */       push(t2);
/* 720 */       push(t1);
/* 721 */       break;
/*     */     case 91: 
/* 723 */       t1 = pop();
/* 724 */       t2 = pop();
/* 725 */       t3 = pop();
/* 726 */       push(t1);
/* 727 */       push(t3);
/* 728 */       push(t2);
/* 729 */       push(t1);
/* 730 */       break;
/*     */     case 92: 
/* 732 */       t1 = pop();
/* 733 */       t2 = pop();
/* 734 */       push(t2);
/* 735 */       push(t1);
/* 736 */       push(t2);
/* 737 */       push(t1);
/* 738 */       break;
/*     */     case 93: 
/* 740 */       t1 = pop();
/* 741 */       t2 = pop();
/* 742 */       t3 = pop();
/* 743 */       push(t2);
/* 744 */       push(t1);
/* 745 */       push(t3);
/* 746 */       push(t2);
/* 747 */       push(t1);
/* 748 */       break;
/*     */     case 94: 
/* 750 */       t1 = pop();
/* 751 */       t2 = pop();
/* 752 */       t3 = pop();
/* 753 */       Object t4 = pop();
/* 754 */       push(t2);
/* 755 */       push(t1);
/* 756 */       push(t4);
/* 757 */       push(t3);
/* 758 */       push(t2);
/* 759 */       push(t1);
/* 760 */       break;
/*     */     case 95: 
/* 762 */       t1 = pop();
/* 763 */       t2 = pop();
/* 764 */       push(t1);
/* 765 */       push(t2);
/* 766 */       break;
/*     */     case 96: 
/*     */     case 100: 
/*     */     case 104: 
/*     */     case 108: 
/*     */     case 112: 
/*     */     case 120: 
/*     */     case 122: 
/*     */     case 124: 
/*     */     case 126: 
/*     */     case 128: 
/*     */     case 130: 
/*     */     case 136: 
/*     */     case 142: 
/*     */     case 149: 
/*     */     case 150: 
/* 782 */       pop(2);
/* 783 */       push(Opcodes.INTEGER);
/* 784 */       break;
/*     */     case 97: 
/*     */     case 101: 
/*     */     case 105: 
/*     */     case 109: 
/*     */     case 113: 
/*     */     case 127: 
/*     */     case 129: 
/*     */     case 131: 
/* 793 */       pop(4);
/* 794 */       push(Opcodes.LONG);
/* 795 */       push(Opcodes.TOP);
/* 796 */       break;
/*     */     case 98: 
/*     */     case 102: 
/*     */     case 106: 
/*     */     case 110: 
/*     */     case 114: 
/*     */     case 137: 
/*     */     case 144: 
/* 804 */       pop(2);
/* 805 */       push(Opcodes.FLOAT);
/* 806 */       break;
/*     */     case 99: 
/*     */     case 103: 
/*     */     case 107: 
/*     */     case 111: 
/*     */     case 115: 
/* 812 */       pop(4);
/* 813 */       push(Opcodes.DOUBLE);
/* 814 */       push(Opcodes.TOP);
/* 815 */       break;
/*     */     case 121: 
/*     */     case 123: 
/*     */     case 125: 
/* 819 */       pop(3);
/* 820 */       push(Opcodes.LONG);
/* 821 */       push(Opcodes.TOP);
/* 822 */       break;
/*     */     case 132: 
/* 824 */       set(iarg, Opcodes.INTEGER);
/* 825 */       break;
/*     */     case 133: 
/*     */     case 140: 
/* 828 */       pop(1);
/* 829 */       push(Opcodes.LONG);
/* 830 */       push(Opcodes.TOP);
/* 831 */       break;
/*     */     case 134: 
/* 833 */       pop(1);
/* 834 */       push(Opcodes.FLOAT);
/* 835 */       break;
/*     */     case 135: 
/*     */     case 141: 
/* 838 */       pop(1);
/* 839 */       push(Opcodes.DOUBLE);
/* 840 */       push(Opcodes.TOP);
/* 841 */       break;
/*     */     case 139: 
/*     */     case 190: 
/*     */     case 193: 
/* 845 */       pop(1);
/* 846 */       push(Opcodes.INTEGER);
/* 847 */       break;
/*     */     case 148: 
/*     */     case 151: 
/*     */     case 152: 
/* 851 */       pop(4);
/* 852 */       push(Opcodes.INTEGER);
/* 853 */       break;
/*     */     case 168: 
/*     */     case 169: 
/* 856 */       throw new RuntimeException("JSR/RET are not supported");
/*     */     case 178: 
/* 858 */       pushDesc(sarg);
/* 859 */       break;
/*     */     case 179: 
/* 861 */       pop(sarg);
/* 862 */       break;
/*     */     case 180: 
/* 864 */       pop(1);
/* 865 */       pushDesc(sarg);
/* 866 */       break;
/*     */     case 181: 
/* 868 */       pop(sarg);
/* 869 */       pop();
/* 870 */       break;
/*     */     case 187: 
/* 872 */       push(this.labels.get(0));
/* 873 */       break;
/*     */     case 188: 
/* 875 */       pop();
/* 876 */       switch (iarg) {
/*     */       case 4: 
/* 878 */         pushDesc("[Z");
/* 879 */         break;
/*     */       case 5: 
/* 881 */         pushDesc("[C");
/* 882 */         break;
/*     */       case 8: 
/* 884 */         pushDesc("[B");
/* 885 */         break;
/*     */       case 9: 
/* 887 */         pushDesc("[S");
/* 888 */         break;
/*     */       case 10: 
/* 890 */         pushDesc("[I");
/* 891 */         break;
/*     */       case 6: 
/* 893 */         pushDesc("[F");
/* 894 */         break;
/*     */       case 7: 
/* 896 */         pushDesc("[D");
/* 897 */         break;
/*     */       
/*     */       default: 
/* 900 */         pushDesc("[J"); }
/* 901 */       break;
/*     */     
/*     */ 
/*     */     case 189: 
/* 905 */       pop();
/* 906 */       pushDesc("[" + Type.getObjectType(sarg));
/* 907 */       break;
/*     */     case 192: 
/* 909 */       pop();
/* 910 */       pushDesc(Type.getObjectType(sarg).getDescriptor());
/* 911 */       break;
/*     */     case 18: case 19: case 20: case 26: case 27: case 28: case 29: case 30: case 31: case 32: case 33: case 34: case 35: case 36: case 37: case 38: case 39: case 40: case 41: case 42: case 43: case 44: case 45: case 59: case 60: case 61: 
/*     */     case 62: case 63: case 64: case 65: case 66: case 67: case 68: case 69: case 70: case 71: case 72: case 73: case 74: case 75: case 76: case 77: case 78: case 182: case 183: case 184: case 185: case 186: case 196: case 197: default: 
/* 914 */       pop(iarg);
/* 915 */       pushDesc(sarg);
/*     */     }
/*     */     
/* 918 */     this.labels = null;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\asm\commons\AnalyzerAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */