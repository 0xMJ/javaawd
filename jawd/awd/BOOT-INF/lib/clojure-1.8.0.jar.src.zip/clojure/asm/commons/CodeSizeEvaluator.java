/*     */ package clojure.asm.commons;
/*     */ 
/*     */ import clojure.asm.Handle;
/*     */ import clojure.asm.Label;
/*     */ import clojure.asm.MethodVisitor;
/*     */ import clojure.asm.Opcodes;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CodeSizeEvaluator
/*     */   extends MethodVisitor
/*     */   implements Opcodes
/*     */ {
/*     */   private int minSize;
/*     */   private int maxSize;
/*     */   
/*     */   public CodeSizeEvaluator(MethodVisitor mv)
/*     */   {
/*  49 */     this(262144, mv);
/*     */   }
/*     */   
/*     */   protected CodeSizeEvaluator(int api, MethodVisitor mv) {
/*  53 */     super(api, mv);
/*     */   }
/*     */   
/*     */   public int getMinSize() {
/*  57 */     return this.minSize;
/*     */   }
/*     */   
/*     */   public int getMaxSize() {
/*  61 */     return this.maxSize;
/*     */   }
/*     */   
/*     */   public void visitInsn(int opcode)
/*     */   {
/*  66 */     this.minSize += 1;
/*  67 */     this.maxSize += 1;
/*  68 */     if (this.mv != null) {
/*  69 */       this.mv.visitInsn(opcode);
/*     */     }
/*     */   }
/*     */   
/*     */   public void visitIntInsn(int opcode, int operand)
/*     */   {
/*  75 */     if (opcode == 17) {
/*  76 */       this.minSize += 3;
/*  77 */       this.maxSize += 3;
/*     */     } else {
/*  79 */       this.minSize += 2;
/*  80 */       this.maxSize += 2;
/*     */     }
/*  82 */     if (this.mv != null) {
/*  83 */       this.mv.visitIntInsn(opcode, operand);
/*     */     }
/*     */   }
/*     */   
/*     */   public void visitVarInsn(int opcode, int var)
/*     */   {
/*  89 */     if ((var < 4) && (opcode != 169)) {
/*  90 */       this.minSize += 1;
/*  91 */       this.maxSize += 1;
/*  92 */     } else if (var >= 256) {
/*  93 */       this.minSize += 4;
/*  94 */       this.maxSize += 4;
/*     */     } else {
/*  96 */       this.minSize += 2;
/*  97 */       this.maxSize += 2;
/*     */     }
/*  99 */     if (this.mv != null) {
/* 100 */       this.mv.visitVarInsn(opcode, var);
/*     */     }
/*     */   }
/*     */   
/*     */   public void visitTypeInsn(int opcode, String type)
/*     */   {
/* 106 */     this.minSize += 3;
/* 107 */     this.maxSize += 3;
/* 108 */     if (this.mv != null) {
/* 109 */       this.mv.visitTypeInsn(opcode, type);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void visitFieldInsn(int opcode, String owner, String name, String desc)
/*     */   {
/* 116 */     this.minSize += 3;
/* 117 */     this.maxSize += 3;
/* 118 */     if (this.mv != null) {
/* 119 */       this.mv.visitFieldInsn(opcode, owner, name, desc);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void visitMethodInsn(int opcode, String owner, String name, String desc)
/*     */   {
/* 126 */     if (opcode == 185) {
/* 127 */       this.minSize += 5;
/* 128 */       this.maxSize += 5;
/*     */     } else {
/* 130 */       this.minSize += 3;
/* 131 */       this.maxSize += 3;
/*     */     }
/* 133 */     if (this.mv != null) {
/* 134 */       this.mv.visitMethodInsn(opcode, owner, name, desc);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void visitInvokeDynamicInsn(String name, String desc, Handle bsm, Object... bsmArgs)
/*     */   {
/* 141 */     this.minSize += 5;
/* 142 */     this.maxSize += 5;
/* 143 */     if (this.mv != null) {
/* 144 */       this.mv.visitInvokeDynamicInsn(name, desc, bsm, bsmArgs);
/*     */     }
/*     */   }
/*     */   
/*     */   public void visitJumpInsn(int opcode, Label label)
/*     */   {
/* 150 */     this.minSize += 3;
/* 151 */     if ((opcode == 167) || (opcode == 168)) {
/* 152 */       this.maxSize += 5;
/*     */     } else {
/* 154 */       this.maxSize += 8;
/*     */     }
/* 156 */     if (this.mv != null) {
/* 157 */       this.mv.visitJumpInsn(opcode, label);
/*     */     }
/*     */   }
/*     */   
/*     */   public void visitLdcInsn(Object cst)
/*     */   {
/* 163 */     if (((cst instanceof Long)) || ((cst instanceof Double))) {
/* 164 */       this.minSize += 3;
/* 165 */       this.maxSize += 3;
/*     */     } else {
/* 167 */       this.minSize += 2;
/* 168 */       this.maxSize += 3;
/*     */     }
/* 170 */     if (this.mv != null) {
/* 171 */       this.mv.visitLdcInsn(cst);
/*     */     }
/*     */   }
/*     */   
/*     */   public void visitIincInsn(int var, int increment)
/*     */   {
/* 177 */     if ((var > 255) || (increment > 127) || (increment < -128)) {
/* 178 */       this.minSize += 6;
/* 179 */       this.maxSize += 6;
/*     */     } else {
/* 181 */       this.minSize += 3;
/* 182 */       this.maxSize += 3;
/*     */     }
/* 184 */     if (this.mv != null) {
/* 185 */       this.mv.visitIincInsn(var, increment);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void visitTableSwitchInsn(int min, int max, Label dflt, Label... labels)
/*     */   {
/* 192 */     this.minSize += 13 + labels.length * 4;
/* 193 */     this.maxSize += 16 + labels.length * 4;
/* 194 */     if (this.mv != null) {
/* 195 */       this.mv.visitTableSwitchInsn(min, max, dflt, labels);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void visitLookupSwitchInsn(Label dflt, int[] keys, Label[] labels)
/*     */   {
/* 202 */     this.minSize += 9 + keys.length * 8;
/* 203 */     this.maxSize += 12 + keys.length * 8;
/* 204 */     if (this.mv != null) {
/* 205 */       this.mv.visitLookupSwitchInsn(dflt, keys, labels);
/*     */     }
/*     */   }
/*     */   
/*     */   public void visitMultiANewArrayInsn(String desc, int dims)
/*     */   {
/* 211 */     this.minSize += 4;
/* 212 */     this.maxSize += 4;
/* 213 */     if (this.mv != null) {
/* 214 */       this.mv.visitMultiANewArrayInsn(desc, dims);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\asm\commons\CodeSizeEvaluator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */