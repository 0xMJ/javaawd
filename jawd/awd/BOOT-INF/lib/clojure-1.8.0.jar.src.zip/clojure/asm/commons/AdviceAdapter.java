/*     */ package clojure.asm.commons;
/*     */ 
/*     */ import clojure.asm.Handle;
/*     */ import clojure.asm.Label;
/*     */ import clojure.asm.MethodVisitor;
/*     */ import clojure.asm.Opcodes;
/*     */ import clojure.asm.Type;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AdviceAdapter
/*     */   extends GeneratorAdapter
/*     */   implements Opcodes
/*     */ {
/*  65 */   private static final Object THIS = new Object();
/*     */   
/*  67 */   private static final Object OTHER = new Object();
/*     */   
/*     */ 
/*     */ 
/*     */   protected int methodAccess;
/*     */   
/*     */ 
/*     */ 
/*     */   protected String methodDesc;
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean constructor;
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean superInitialized;
/*     */   
/*     */ 
/*     */ 
/*     */   private List<Object> stackFrame;
/*     */   
/*     */ 
/*     */ 
/*     */   private Map<Label, List<Object>> branches;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected AdviceAdapter(int api, MethodVisitor mv, int access, String name, String desc)
/*     */   {
/*  98 */     super(api, mv, access, name, desc);
/*  99 */     this.methodAccess = access;
/* 100 */     this.methodDesc = desc;
/* 101 */     this.constructor = "<init>".equals(name);
/*     */   }
/*     */   
/*     */   public void visitCode()
/*     */   {
/* 106 */     this.mv.visitCode();
/* 107 */     if (this.constructor) {
/* 108 */       this.stackFrame = new ArrayList();
/* 109 */       this.branches = new HashMap();
/*     */     } else {
/* 111 */       this.superInitialized = true;
/* 112 */       onMethodEnter();
/*     */     }
/*     */   }
/*     */   
/*     */   public void visitLabel(Label label)
/*     */   {
/* 118 */     this.mv.visitLabel(label);
/* 119 */     if ((this.constructor) && (this.branches != null)) {
/* 120 */       List<Object> frame = (List)this.branches.get(label);
/* 121 */       if (frame != null) {
/* 122 */         this.stackFrame = frame;
/* 123 */         this.branches.remove(label);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void visitInsn(int opcode)
/*     */   {
/* 130 */     if (this.constructor) {
/*     */       int s;
/* 132 */       switch (opcode) {
/*     */       case 177: 
/* 134 */         onMethodExit(opcode);
/* 135 */         break;
/*     */       case 172: 
/*     */       case 174: 
/*     */       case 176: 
/*     */       case 191: 
/* 140 */         popValue();
/* 141 */         onMethodExit(opcode);
/* 142 */         break;
/*     */       case 173: 
/*     */       case 175: 
/* 145 */         popValue();
/* 146 */         popValue();
/* 147 */         onMethodExit(opcode);
/* 148 */         break;
/*     */       case 0: 
/*     */       case 47: 
/*     */       case 49: 
/*     */       case 116: 
/*     */       case 117: 
/*     */       case 118: 
/*     */       case 119: 
/*     */       case 134: 
/*     */       case 138: 
/*     */       case 139: 
/*     */       case 143: 
/*     */       case 145: 
/*     */       case 146: 
/*     */       case 147: 
/*     */       case 190: 
/*     */         break;
/*     */       case 1: 
/*     */       case 2: 
/*     */       case 3: 
/*     */       case 4: 
/*     */       case 5: 
/*     */       case 6: 
/*     */       case 7: 
/*     */       case 8: 
/*     */       case 11: 
/*     */       case 12: 
/*     */       case 13: 
/*     */       case 133: 
/*     */       case 135: 
/*     */       case 140: 
/*     */       case 141: 
/* 180 */         pushValue(OTHER);
/* 181 */         break;
/*     */       case 9: 
/*     */       case 10: 
/*     */       case 14: 
/*     */       case 15: 
/* 186 */         pushValue(OTHER);
/* 187 */         pushValue(OTHER);
/* 188 */         break;
/*     */       case 46: 
/*     */       case 48: 
/*     */       case 50: 
/*     */       case 51: 
/*     */       case 52: 
/*     */       case 53: 
/*     */       case 87: 
/*     */       case 96: 
/*     */       case 98: 
/*     */       case 100: 
/*     */       case 102: 
/*     */       case 104: 
/*     */       case 106: 
/*     */       case 108: 
/*     */       case 110: 
/*     */       case 112: 
/*     */       case 114: 
/*     */       case 120: 
/*     */       case 121: 
/*     */       case 122: 
/*     */       case 123: 
/*     */       case 124: 
/*     */       case 125: 
/*     */       case 126: 
/*     */       case 128: 
/*     */       case 130: 
/*     */       case 136: 
/*     */       case 137: 
/*     */       case 142: 
/*     */       case 144: 
/*     */       case 149: 
/*     */       case 150: 
/*     */       case 194: 
/*     */       case 195: 
/* 223 */         popValue();
/* 224 */         break;
/*     */       case 88: 
/*     */       case 97: 
/*     */       case 99: 
/*     */       case 101: 
/*     */       case 103: 
/*     */       case 105: 
/*     */       case 107: 
/*     */       case 109: 
/*     */       case 111: 
/*     */       case 113: 
/*     */       case 115: 
/*     */       case 127: 
/*     */       case 129: 
/*     */       case 131: 
/* 239 */         popValue();
/* 240 */         popValue();
/* 241 */         break;
/*     */       case 79: 
/*     */       case 81: 
/*     */       case 83: 
/*     */       case 84: 
/*     */       case 85: 
/*     */       case 86: 
/*     */       case 148: 
/*     */       case 151: 
/*     */       case 152: 
/* 251 */         popValue();
/* 252 */         popValue();
/* 253 */         popValue();
/* 254 */         break;
/*     */       case 80: 
/*     */       case 82: 
/* 257 */         popValue();
/* 258 */         popValue();
/* 259 */         popValue();
/* 260 */         popValue();
/* 261 */         break;
/*     */       case 89: 
/* 263 */         pushValue(peekValue());
/* 264 */         break;
/*     */       case 90: 
/* 266 */         s = this.stackFrame.size();
/* 267 */         this.stackFrame.add(s - 2, this.stackFrame.get(s - 1));
/* 268 */         break;
/*     */       case 91: 
/* 270 */         s = this.stackFrame.size();
/* 271 */         this.stackFrame.add(s - 3, this.stackFrame.get(s - 1));
/* 272 */         break;
/*     */       case 92: 
/* 274 */         s = this.stackFrame.size();
/* 275 */         this.stackFrame.add(s - 2, this.stackFrame.get(s - 1));
/* 276 */         this.stackFrame.add(s - 2, this.stackFrame.get(s - 1));
/* 277 */         break;
/*     */       case 93: 
/* 279 */         s = this.stackFrame.size();
/* 280 */         this.stackFrame.add(s - 3, this.stackFrame.get(s - 1));
/* 281 */         this.stackFrame.add(s - 3, this.stackFrame.get(s - 1));
/* 282 */         break;
/*     */       case 94: 
/* 284 */         s = this.stackFrame.size();
/* 285 */         this.stackFrame.add(s - 4, this.stackFrame.get(s - 1));
/* 286 */         this.stackFrame.add(s - 4, this.stackFrame.get(s - 1));
/* 287 */         break;
/*     */       case 95: 
/* 289 */         s = this.stackFrame.size();
/* 290 */         this.stackFrame.add(s - 2, this.stackFrame.get(s - 1));
/* 291 */         this.stackFrame.remove(s);
/*     */       }
/*     */     }
/*     */     else {
/* 295 */       switch (opcode) {
/*     */       case 172: 
/*     */       case 173: 
/*     */       case 174: 
/*     */       case 175: 
/*     */       case 176: 
/*     */       case 177: 
/*     */       case 191: 
/* 303 */         onMethodExit(opcode);
/*     */       }
/*     */       
/*     */     }
/* 307 */     this.mv.visitInsn(opcode);
/*     */   }
/*     */   
/*     */   public void visitVarInsn(int opcode, int var)
/*     */   {
/* 312 */     super.visitVarInsn(opcode, var);
/* 313 */     if (this.constructor) {
/* 314 */       switch (opcode) {
/*     */       case 21: 
/*     */       case 23: 
/* 317 */         pushValue(OTHER);
/* 318 */         break;
/*     */       case 22: 
/*     */       case 24: 
/* 321 */         pushValue(OTHER);
/* 322 */         pushValue(OTHER);
/* 323 */         break;
/*     */       case 25: 
/* 325 */         pushValue(var == 0 ? THIS : OTHER);
/* 326 */         break;
/*     */       case 54: 
/*     */       case 56: 
/*     */       case 58: 
/* 330 */         popValue();
/* 331 */         break;
/*     */       case 55: 
/*     */       case 57: 
/* 334 */         popValue();
/* 335 */         popValue();
/*     */       }
/*     */       
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void visitFieldInsn(int opcode, String owner, String name, String desc)
/*     */   {
/* 344 */     this.mv.visitFieldInsn(opcode, owner, name, desc);
/* 345 */     if (this.constructor) {
/* 346 */       char c = desc.charAt(0);
/* 347 */       boolean longOrDouble = (c == 'J') || (c == 'D');
/* 348 */       switch (opcode) {
/*     */       case 178: 
/* 350 */         pushValue(OTHER);
/* 351 */         if (longOrDouble) {
/* 352 */           pushValue(OTHER);
/*     */         }
/*     */         break;
/*     */       case 179: 
/* 356 */         popValue();
/* 357 */         if (longOrDouble) {
/* 358 */           popValue();
/*     */         }
/*     */         break;
/*     */       case 181: 
/* 362 */         popValue();
/* 363 */         if (longOrDouble) {
/* 364 */           popValue();
/* 365 */           popValue();
/*     */         }
/*     */         break;
/*     */       case 180: 
/*     */       default: 
/* 370 */         if (longOrDouble) {
/* 371 */           pushValue(OTHER);
/*     */         }
/*     */         break;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void visitIntInsn(int opcode, int operand) {
/* 379 */     this.mv.visitIntInsn(opcode, operand);
/* 380 */     if ((this.constructor) && (opcode != 188)) {
/* 381 */       pushValue(OTHER);
/*     */     }
/*     */   }
/*     */   
/*     */   public void visitLdcInsn(Object cst)
/*     */   {
/* 387 */     this.mv.visitLdcInsn(cst);
/* 388 */     if (this.constructor) {
/* 389 */       pushValue(OTHER);
/* 390 */       if (((cst instanceof Double)) || ((cst instanceof Long))) {
/* 391 */         pushValue(OTHER);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void visitMultiANewArrayInsn(String desc, int dims)
/*     */   {
/* 398 */     this.mv.visitMultiANewArrayInsn(desc, dims);
/* 399 */     if (this.constructor) {
/* 400 */       for (int i = 0; i < dims; i++) {
/* 401 */         popValue();
/*     */       }
/* 403 */       pushValue(OTHER);
/*     */     }
/*     */   }
/*     */   
/*     */   public void visitTypeInsn(int opcode, String type)
/*     */   {
/* 409 */     this.mv.visitTypeInsn(opcode, type);
/*     */     
/* 411 */     if ((this.constructor) && (opcode == 187)) {
/* 412 */       pushValue(OTHER);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void visitMethodInsn(int opcode, String owner, String name, String desc)
/*     */   {
/* 419 */     this.mv.visitMethodInsn(opcode, owner, name, desc);
/* 420 */     if (this.constructor) {
/* 421 */       Type[] types = Type.getArgumentTypes(desc);
/* 422 */       for (int i = 0; i < types.length; i++) {
/* 423 */         popValue();
/* 424 */         if (types[i].getSize() == 2) {
/* 425 */           popValue();
/*     */         }
/*     */       }
/* 428 */       switch (opcode)
/*     */       {
/*     */ 
/*     */       case 182: 
/*     */       case 185: 
/* 433 */         popValue();
/* 434 */         break;
/*     */       case 183: 
/* 436 */         Object type = popValue();
/* 437 */         if ((type == THIS) && (!this.superInitialized)) {
/* 438 */           onMethodEnter();
/* 439 */           this.superInitialized = true;
/*     */           
/*     */ 
/* 442 */           this.constructor = false;
/*     */         }
/*     */         break;
/*     */       }
/*     */       
/* 447 */       Type returnType = Type.getReturnType(desc);
/* 448 */       if (returnType != Type.VOID_TYPE) {
/* 449 */         pushValue(OTHER);
/* 450 */         if (returnType.getSize() == 2) {
/* 451 */           pushValue(OTHER);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void visitInvokeDynamicInsn(String name, String desc, Handle bsm, Object... bsmArgs)
/*     */   {
/* 460 */     this.mv.visitInvokeDynamicInsn(name, desc, bsm, bsmArgs);
/* 461 */     if (this.constructor) {
/* 462 */       Type[] types = Type.getArgumentTypes(desc);
/* 463 */       for (int i = 0; i < types.length; i++) {
/* 464 */         popValue();
/* 465 */         if (types[i].getSize() == 2) {
/* 466 */           popValue();
/*     */         }
/*     */       }
/*     */       
/* 470 */       Type returnType = Type.getReturnType(desc);
/* 471 */       if (returnType != Type.VOID_TYPE) {
/* 472 */         pushValue(OTHER);
/* 473 */         if (returnType.getSize() == 2) {
/* 474 */           pushValue(OTHER);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void visitJumpInsn(int opcode, Label label)
/*     */   {
/* 482 */     this.mv.visitJumpInsn(opcode, label);
/* 483 */     if (this.constructor) {
/* 484 */       switch (opcode) {
/*     */       case 153: 
/*     */       case 154: 
/*     */       case 155: 
/*     */       case 156: 
/*     */       case 157: 
/*     */       case 158: 
/*     */       case 198: 
/*     */       case 199: 
/* 493 */         popValue();
/* 494 */         break;
/*     */       case 159: 
/*     */       case 160: 
/*     */       case 161: 
/*     */       case 162: 
/*     */       case 163: 
/*     */       case 164: 
/*     */       case 165: 
/*     */       case 166: 
/* 503 */         popValue();
/* 504 */         popValue();
/* 505 */         break;
/*     */       case 168: 
/* 507 */         pushValue(OTHER);
/*     */       }
/*     */       
/* 510 */       addBranch(label);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void visitLookupSwitchInsn(Label dflt, int[] keys, Label[] labels)
/*     */   {
/* 517 */     this.mv.visitLookupSwitchInsn(dflt, keys, labels);
/* 518 */     if (this.constructor) {
/* 519 */       popValue();
/* 520 */       addBranches(dflt, labels);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void visitTableSwitchInsn(int min, int max, Label dflt, Label... labels)
/*     */   {
/* 527 */     this.mv.visitTableSwitchInsn(min, max, dflt, labels);
/* 528 */     if (this.constructor) {
/* 529 */       popValue();
/* 530 */       addBranches(dflt, labels);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void visitTryCatchBlock(Label start, Label end, Label handler, String type)
/*     */   {
/* 537 */     super.visitTryCatchBlock(start, end, handler, type);
/* 538 */     if ((this.constructor) && (!this.branches.containsKey(handler))) {
/* 539 */       List<Object> stackFrame = new ArrayList();
/* 540 */       stackFrame.add(OTHER);
/* 541 */       this.branches.put(handler, stackFrame);
/*     */     }
/*     */   }
/*     */   
/*     */   private void addBranches(Label dflt, Label[] labels) {
/* 546 */     addBranch(dflt);
/* 547 */     for (int i = 0; i < labels.length; i++) {
/* 548 */       addBranch(labels[i]);
/*     */     }
/*     */   }
/*     */   
/*     */   private void addBranch(Label label) {
/* 553 */     if (this.branches.containsKey(label)) {
/* 554 */       return;
/*     */     }
/* 556 */     this.branches.put(label, new ArrayList(this.stackFrame));
/*     */   }
/*     */   
/*     */   private Object popValue() {
/* 560 */     return this.stackFrame.remove(this.stackFrame.size() - 1);
/*     */   }
/*     */   
/*     */   private Object peekValue() {
/* 564 */     return this.stackFrame.get(this.stackFrame.size() - 1);
/*     */   }
/*     */   
/*     */   private void pushValue(Object o) {
/* 568 */     this.stackFrame.add(o);
/*     */   }
/*     */   
/*     */   protected void onMethodEnter() {}
/*     */   
/*     */   protected void onMethodExit(int opcode) {}
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\asm\commons\AdviceAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */