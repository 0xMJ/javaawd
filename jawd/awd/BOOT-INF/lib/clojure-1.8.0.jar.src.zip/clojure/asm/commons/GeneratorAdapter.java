/*      */ package clojure.asm.commons;
/*      */ 
/*      */ import clojure.asm.ClassVisitor;
/*      */ import clojure.asm.Handle;
/*      */ import clojure.asm.Label;
/*      */ import clojure.asm.MethodVisitor;
/*      */ import clojure.asm.Type;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.List;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class GeneratorAdapter
/*      */   extends LocalVariablesSorter
/*      */ {
/*      */   private static final String CLDESC = "Ljava/lang/Class;";
/*   89 */   private static final Type BYTE_TYPE = Type.getObjectType("java/lang/Byte");
/*      */   
/*   91 */   private static final Type BOOLEAN_TYPE = Type.getObjectType("java/lang/Boolean");
/*      */   
/*      */ 
/*   94 */   private static final Type SHORT_TYPE = Type.getObjectType("java/lang/Short");
/*      */   
/*      */ 
/*   97 */   private static final Type CHARACTER_TYPE = Type.getObjectType("java/lang/Character");
/*      */   
/*      */ 
/*  100 */   private static final Type INTEGER_TYPE = Type.getObjectType("java/lang/Integer");
/*      */   
/*      */ 
/*  103 */   private static final Type FLOAT_TYPE = Type.getObjectType("java/lang/Float");
/*      */   
/*      */ 
/*  106 */   private static final Type LONG_TYPE = Type.getObjectType("java/lang/Long");
/*      */   
/*  108 */   private static final Type DOUBLE_TYPE = Type.getObjectType("java/lang/Double");
/*      */   
/*      */ 
/*  111 */   private static final Type NUMBER_TYPE = Type.getObjectType("java/lang/Number");
/*      */   
/*      */ 
/*  114 */   private static final Type OBJECT_TYPE = Type.getObjectType("java/lang/Object");
/*      */   
/*      */ 
/*  117 */   private static final Method BOOLEAN_VALUE = Method.getMethod("boolean booleanValue()");
/*      */   
/*      */ 
/*  120 */   private static final Method CHAR_VALUE = Method.getMethod("char charValue()");
/*      */   
/*      */ 
/*  123 */   private static final Method INT_VALUE = Method.getMethod("int intValue()");
/*      */   
/*  125 */   private static final Method FLOAT_VALUE = Method.getMethod("float floatValue()");
/*      */   
/*      */ 
/*  128 */   private static final Method LONG_VALUE = Method.getMethod("long longValue()");
/*      */   
/*      */ 
/*  131 */   private static final Method DOUBLE_VALUE = Method.getMethod("double doubleValue()");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int ADD = 96;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int SUB = 100;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int MUL = 104;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int DIV = 108;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int REM = 112;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int NEG = 116;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int SHL = 120;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int SHR = 122;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int USHR = 124;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int AND = 126;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int OR = 128;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int XOR = 130;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int EQ = 153;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int NE = 154;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int LT = 155;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int GE = 156;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int GT = 157;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int LE = 158;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private final int access;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private final Type returnType;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private final Type[] argumentTypes;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  242 */   private final List<Type> localTypes = new ArrayList();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public GeneratorAdapter(MethodVisitor mv, int access, String name, String desc)
/*      */   {
/*  261 */     this(262144, mv, access, name, desc);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected GeneratorAdapter(int api, MethodVisitor mv, int access, String name, String desc)
/*      */   {
/*  281 */     super(api, access, desc, mv);
/*  282 */     this.access = access;
/*  283 */     this.returnType = Type.getReturnType(desc);
/*  284 */     this.argumentTypes = Type.getArgumentTypes(desc);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public GeneratorAdapter(int access, Method method, MethodVisitor mv)
/*      */   {
/*  302 */     this(mv, access, null, method.getDescriptor());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public GeneratorAdapter(int access, Method method, String signature, Type[] exceptions, ClassVisitor cv)
/*      */   {
/*  326 */     this(access, method, cv.visitMethod(access, method.getName(), method.getDescriptor(), signature, getInternalNames(exceptions)));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static String[] getInternalNames(Type[] types)
/*      */   {
/*  339 */     if (types == null) {
/*  340 */       return null;
/*      */     }
/*  342 */     String[] names = new String[types.length];
/*  343 */     for (int i = 0; i < names.length; i++) {
/*  344 */       names[i] = types[i].getInternalName();
/*      */     }
/*  346 */     return names;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void push(boolean value)
/*      */   {
/*  360 */     push(value ? 1 : 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void push(int value)
/*      */   {
/*  370 */     if ((value >= -1) && (value <= 5)) {
/*  371 */       this.mv.visitInsn(3 + value);
/*  372 */     } else if ((value >= -128) && (value <= 127)) {
/*  373 */       this.mv.visitIntInsn(16, value);
/*  374 */     } else if ((value >= 32768) && (value <= 32767)) {
/*  375 */       this.mv.visitIntInsn(17, value);
/*      */     } else {
/*  377 */       this.mv.visitLdcInsn(new Integer(value));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void push(long value)
/*      */   {
/*  388 */     if ((value == 0L) || (value == 1L)) {
/*  389 */       this.mv.visitInsn(9 + (int)value);
/*      */     } else {
/*  391 */       this.mv.visitLdcInsn(new Long(value));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void push(float value)
/*      */   {
/*  402 */     int bits = Float.floatToIntBits(value);
/*  403 */     if ((bits == 0L) || (bits == 1065353216) || (bits == 1073741824)) {
/*  404 */       this.mv.visitInsn(11 + (int)value);
/*      */     } else {
/*  406 */       this.mv.visitLdcInsn(new Float(value));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void push(double value)
/*      */   {
/*  417 */     long bits = Double.doubleToLongBits(value);
/*  418 */     if ((bits == 0L) || (bits == 4607182418800017408L)) {
/*  419 */       this.mv.visitInsn(14 + (int)value);
/*      */     } else {
/*  421 */       this.mv.visitLdcInsn(new Double(value));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void push(String value)
/*      */   {
/*  432 */     if (value == null) {
/*  433 */       this.mv.visitInsn(1);
/*      */     } else {
/*  435 */       this.mv.visitLdcInsn(value);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void push(Type value)
/*      */   {
/*  446 */     if (value == null) {
/*  447 */       this.mv.visitInsn(1);
/*      */     } else {
/*  449 */       switch (value.getSort()) {
/*      */       case 1: 
/*  451 */         this.mv.visitFieldInsn(178, "java/lang/Boolean", "TYPE", "Ljava/lang/Class;");
/*      */         
/*  453 */         break;
/*      */       case 2: 
/*  455 */         this.mv.visitFieldInsn(178, "java/lang/Character", "TYPE", "Ljava/lang/Class;");
/*      */         
/*  457 */         break;
/*      */       case 3: 
/*  459 */         this.mv.visitFieldInsn(178, "java/lang/Byte", "TYPE", "Ljava/lang/Class;");
/*      */         
/*  461 */         break;
/*      */       case 4: 
/*  463 */         this.mv.visitFieldInsn(178, "java/lang/Short", "TYPE", "Ljava/lang/Class;");
/*      */         
/*  465 */         break;
/*      */       case 5: 
/*  467 */         this.mv.visitFieldInsn(178, "java/lang/Integer", "TYPE", "Ljava/lang/Class;");
/*      */         
/*  469 */         break;
/*      */       case 6: 
/*  471 */         this.mv.visitFieldInsn(178, "java/lang/Float", "TYPE", "Ljava/lang/Class;");
/*      */         
/*  473 */         break;
/*      */       case 7: 
/*  475 */         this.mv.visitFieldInsn(178, "java/lang/Long", "TYPE", "Ljava/lang/Class;");
/*      */         
/*  477 */         break;
/*      */       case 8: 
/*  479 */         this.mv.visitFieldInsn(178, "java/lang/Double", "TYPE", "Ljava/lang/Class;");
/*      */         
/*  481 */         break;
/*      */       default: 
/*  483 */         this.mv.visitLdcInsn(value);
/*      */       }
/*      */       
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void push(Handle handle)
/*      */   {
/*  495 */     this.mv.visitLdcInsn(handle);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int getArgIndex(int arg)
/*      */   {
/*  512 */     int index = (this.access & 0x8) == 0 ? 1 : 0;
/*  513 */     for (int i = 0; i < arg; i++) {
/*  514 */       index += this.argumentTypes[i].getSize();
/*      */     }
/*  516 */     return index;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void loadInsn(Type type, int index)
/*      */   {
/*  528 */     this.mv.visitVarInsn(type.getOpcode(21), index);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void storeInsn(Type type, int index)
/*      */   {
/*  541 */     this.mv.visitVarInsn(type.getOpcode(54), index);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void loadThis()
/*      */   {
/*  548 */     if ((this.access & 0x8) != 0) {
/*  549 */       throw new IllegalStateException("no 'this' pointer within static method");
/*      */     }
/*      */     
/*  552 */     this.mv.visitVarInsn(25, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void loadArg(int arg)
/*      */   {
/*  562 */     loadInsn(this.argumentTypes[arg], getArgIndex(arg));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void loadArgs(int arg, int count)
/*      */   {
/*  575 */     int index = getArgIndex(arg);
/*  576 */     for (int i = 0; i < count; i++) {
/*  577 */       Type t = this.argumentTypes[(arg + i)];
/*  578 */       loadInsn(t, index);
/*  579 */       index += t.getSize();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void loadArgs()
/*      */   {
/*  587 */     loadArgs(0, this.argumentTypes.length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void loadArgArray()
/*      */   {
/*  595 */     push(this.argumentTypes.length);
/*  596 */     newArray(OBJECT_TYPE);
/*  597 */     for (int i = 0; i < this.argumentTypes.length; i++) {
/*  598 */       dup();
/*  599 */       push(i);
/*  600 */       loadArg(i);
/*  601 */       box(this.argumentTypes[i]);
/*  602 */       arrayStore(OBJECT_TYPE);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void storeArg(int arg)
/*      */   {
/*  614 */     storeInsn(this.argumentTypes[arg], getArgIndex(arg));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Type getLocalType(int local)
/*      */   {
/*  630 */     return (Type)this.localTypes.get(local - this.firstLocal);
/*      */   }
/*      */   
/*      */   protected void setLocalType(int local, Type type)
/*      */   {
/*  635 */     int index = local - this.firstLocal;
/*  636 */     while (this.localTypes.size() < index + 1) {
/*  637 */       this.localTypes.add(null);
/*      */     }
/*  639 */     this.localTypes.set(index, type);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void loadLocal(int local)
/*      */   {
/*  650 */     loadInsn(getLocalType(local), local);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void loadLocal(int local, Type type)
/*      */   {
/*  663 */     setLocalType(local, type);
/*  664 */     loadInsn(type, local);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void storeLocal(int local)
/*      */   {
/*  676 */     storeInsn(getLocalType(local), local);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void storeLocal(int local, Type type)
/*      */   {
/*  690 */     setLocalType(local, type);
/*  691 */     storeInsn(type, local);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void arrayLoad(Type type)
/*      */   {
/*  701 */     this.mv.visitInsn(type.getOpcode(46));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void arrayStore(Type type)
/*      */   {
/*  711 */     this.mv.visitInsn(type.getOpcode(79));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void pop()
/*      */   {
/*  722 */     this.mv.visitInsn(87);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void pop2()
/*      */   {
/*  729 */     this.mv.visitInsn(88);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void dup()
/*      */   {
/*  736 */     this.mv.visitInsn(89);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void dup2()
/*      */   {
/*  743 */     this.mv.visitInsn(92);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void dupX1()
/*      */   {
/*  750 */     this.mv.visitInsn(90);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void dupX2()
/*      */   {
/*  757 */     this.mv.visitInsn(91);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void dup2X1()
/*      */   {
/*  764 */     this.mv.visitInsn(93);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void dup2X2()
/*      */   {
/*  771 */     this.mv.visitInsn(94);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void swap()
/*      */   {
/*  778 */     this.mv.visitInsn(95);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void swap(Type prev, Type type)
/*      */   {
/*  790 */     if (type.getSize() == 1) {
/*  791 */       if (prev.getSize() == 1) {
/*  792 */         swap();
/*      */       } else {
/*  794 */         dupX2();
/*  795 */         pop();
/*      */       }
/*      */     }
/*  798 */     else if (prev.getSize() == 1) {
/*  799 */       dup2X1();
/*  800 */       pop2();
/*      */     } else {
/*  802 */       dup2X2();
/*  803 */       pop2();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void math(int op, Type type)
/*      */   {
/*  823 */     this.mv.visitInsn(type.getOpcode(op));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void not()
/*      */   {
/*  831 */     this.mv.visitInsn(4);
/*  832 */     this.mv.visitInsn(130);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void iinc(int local, int amount)
/*      */   {
/*  844 */     this.mv.visitIincInsn(local, amount);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void cast(Type from, Type to)
/*      */   {
/*  857 */     if (from != to) {
/*  858 */       if (from == Type.DOUBLE_TYPE) {
/*  859 */         if (to == Type.FLOAT_TYPE) {
/*  860 */           this.mv.visitInsn(144);
/*  861 */         } else if (to == Type.LONG_TYPE) {
/*  862 */           this.mv.visitInsn(143);
/*      */         } else {
/*  864 */           this.mv.visitInsn(142);
/*  865 */           cast(Type.INT_TYPE, to);
/*      */         }
/*  867 */       } else if (from == Type.FLOAT_TYPE) {
/*  868 */         if (to == Type.DOUBLE_TYPE) {
/*  869 */           this.mv.visitInsn(141);
/*  870 */         } else if (to == Type.LONG_TYPE) {
/*  871 */           this.mv.visitInsn(140);
/*      */         } else {
/*  873 */           this.mv.visitInsn(139);
/*  874 */           cast(Type.INT_TYPE, to);
/*      */         }
/*  876 */       } else if (from == Type.LONG_TYPE) {
/*  877 */         if (to == Type.DOUBLE_TYPE) {
/*  878 */           this.mv.visitInsn(138);
/*  879 */         } else if (to == Type.FLOAT_TYPE) {
/*  880 */           this.mv.visitInsn(137);
/*      */         } else {
/*  882 */           this.mv.visitInsn(136);
/*  883 */           cast(Type.INT_TYPE, to);
/*      */         }
/*      */       }
/*  886 */       else if (to == Type.BYTE_TYPE) {
/*  887 */         this.mv.visitInsn(145);
/*  888 */       } else if (to == Type.CHAR_TYPE) {
/*  889 */         this.mv.visitInsn(146);
/*  890 */       } else if (to == Type.DOUBLE_TYPE) {
/*  891 */         this.mv.visitInsn(135);
/*  892 */       } else if (to == Type.FLOAT_TYPE) {
/*  893 */         this.mv.visitInsn(134);
/*  894 */       } else if (to == Type.LONG_TYPE) {
/*  895 */         this.mv.visitInsn(133);
/*  896 */       } else if (to == Type.SHORT_TYPE) {
/*  897 */         this.mv.visitInsn(147);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static Type getBoxedType(Type type)
/*      */   {
/*  908 */     switch (type.getSort()) {
/*      */     case 3: 
/*  910 */       return BYTE_TYPE;
/*      */     case 1: 
/*  912 */       return BOOLEAN_TYPE;
/*      */     case 4: 
/*  914 */       return SHORT_TYPE;
/*      */     case 2: 
/*  916 */       return CHARACTER_TYPE;
/*      */     case 5: 
/*  918 */       return INTEGER_TYPE;
/*      */     case 6: 
/*  920 */       return FLOAT_TYPE;
/*      */     case 7: 
/*  922 */       return LONG_TYPE;
/*      */     case 8: 
/*  924 */       return DOUBLE_TYPE;
/*      */     }
/*  926 */     return type;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void box(Type type)
/*      */   {
/*  937 */     if ((type.getSort() == 10) || (type.getSort() == 9)) {
/*  938 */       return;
/*      */     }
/*  940 */     if (type == Type.VOID_TYPE) {
/*  941 */       push((String)null);
/*      */     } else {
/*  943 */       Type boxed = getBoxedType(type);
/*  944 */       newInstance(boxed);
/*  945 */       if (type.getSize() == 2)
/*      */       {
/*  947 */         dupX2();
/*  948 */         dupX2();
/*  949 */         pop();
/*      */       }
/*      */       else {
/*  952 */         dupX1();
/*  953 */         swap();
/*      */       }
/*  955 */       invokeConstructor(boxed, new Method("<init>", Type.VOID_TYPE, new Type[] { type }));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void valueOf(Type type)
/*      */   {
/*  969 */     if ((type.getSort() == 10) || (type.getSort() == 9)) {
/*  970 */       return;
/*      */     }
/*  972 */     if (type == Type.VOID_TYPE) {
/*  973 */       push((String)null);
/*      */     } else {
/*  975 */       Type boxed = getBoxedType(type);
/*  976 */       invokeStatic(boxed, new Method("valueOf", boxed, new Type[] { type }));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void unbox(Type type)
/*      */   {
/*  989 */     Type t = NUMBER_TYPE;
/*  990 */     Method sig = null;
/*  991 */     switch (type.getSort()) {
/*      */     case 0: 
/*  993 */       return;
/*      */     case 2: 
/*  995 */       t = CHARACTER_TYPE;
/*  996 */       sig = CHAR_VALUE;
/*  997 */       break;
/*      */     case 1: 
/*  999 */       t = BOOLEAN_TYPE;
/* 1000 */       sig = BOOLEAN_VALUE;
/* 1001 */       break;
/*      */     case 8: 
/* 1003 */       sig = DOUBLE_VALUE;
/* 1004 */       break;
/*      */     case 6: 
/* 1006 */       sig = FLOAT_VALUE;
/* 1007 */       break;
/*      */     case 7: 
/* 1009 */       sig = LONG_VALUE;
/* 1010 */       break;
/*      */     case 3: 
/*      */     case 4: 
/*      */     case 5: 
/* 1014 */       sig = INT_VALUE;
/*      */     }
/* 1016 */     if (sig == null) {
/* 1017 */       checkCast(type);
/*      */     } else {
/* 1019 */       checkCast(t);
/* 1020 */       invokeVirtual(t, sig);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Label newLabel()
/*      */   {
/* 1034 */     return new Label();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void mark(Label label)
/*      */   {
/* 1044 */     this.mv.visitLabel(label);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Label mark()
/*      */   {
/* 1053 */     Label label = new Label();
/* 1054 */     this.mv.visitLabel(label);
/* 1055 */     return label;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void ifCmp(Type type, int mode, Label label)
/*      */   {
/* 1071 */     switch (type.getSort()) {
/*      */     case 7: 
/* 1073 */       this.mv.visitInsn(148);
/* 1074 */       break;
/*      */     case 8: 
/* 1076 */       this.mv.visitInsn((mode == 156) || (mode == 157) ? 151 : 152);
/*      */       
/* 1078 */       break;
/*      */     case 6: 
/* 1080 */       this.mv.visitInsn((mode == 156) || (mode == 157) ? 149 : 150);
/*      */       
/* 1082 */       break;
/*      */     case 9: 
/*      */     case 10: 
/* 1085 */       switch (mode) {
/*      */       case 153: 
/* 1087 */         this.mv.visitJumpInsn(165, label);
/* 1088 */         return;
/*      */       case 154: 
/* 1090 */         this.mv.visitJumpInsn(166, label);
/* 1091 */         return;
/*      */       }
/* 1093 */       throw new IllegalArgumentException("Bad comparison for type " + type);
/*      */     
/*      */     default: 
/* 1096 */       int intOp = -1;
/* 1097 */       switch (mode) {
/*      */       case 153: 
/* 1099 */         intOp = 159;
/* 1100 */         break;
/*      */       case 154: 
/* 1102 */         intOp = 160;
/* 1103 */         break;
/*      */       case 156: 
/* 1105 */         intOp = 162;
/* 1106 */         break;
/*      */       case 155: 
/* 1108 */         intOp = 161;
/* 1109 */         break;
/*      */       case 158: 
/* 1111 */         intOp = 164;
/* 1112 */         break;
/*      */       case 157: 
/* 1114 */         intOp = 163;
/*      */       }
/*      */       
/* 1117 */       this.mv.visitJumpInsn(intOp, label);
/* 1118 */       return;
/*      */     }
/* 1120 */     this.mv.visitJumpInsn(mode, label);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void ifICmp(int mode, Label label)
/*      */   {
/* 1134 */     ifCmp(Type.INT_TYPE, mode, label);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void ifZCmp(int mode, Label label)
/*      */   {
/* 1148 */     this.mv.visitJumpInsn(mode, label);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void ifNull(Label label)
/*      */   {
/* 1159 */     this.mv.visitJumpInsn(198, label);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void ifNonNull(Label label)
/*      */   {
/* 1170 */     this.mv.visitJumpInsn(199, label);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void goTo(Label label)
/*      */   {
/* 1180 */     this.mv.visitJumpInsn(167, label);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void ret(int local)
/*      */   {
/* 1191 */     this.mv.visitVarInsn(169, local);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void tableSwitch(int[] keys, TableSwitchGenerator generator)
/*      */   {
/*      */     float density;
/*      */     
/*      */ 
/*      */     float density;
/*      */     
/*      */ 
/* 1205 */     if (keys.length == 0) {
/* 1206 */       density = 0.0F;
/*      */     } else {
/* 1208 */       density = keys.length / (keys[(keys.length - 1)] - keys[0] + 1);
/*      */     }
/*      */     
/* 1211 */     tableSwitch(keys, generator, density >= 0.5F);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void tableSwitch(int[] keys, TableSwitchGenerator generator, boolean useTable)
/*      */   {
/* 1227 */     for (int i = 1; i < keys.length; i++) {
/* 1228 */       if (keys[i] < keys[(i - 1)]) {
/* 1229 */         throw new IllegalArgumentException("keys must be sorted ascending");
/*      */       }
/*      */     }
/*      */     
/* 1233 */     Label def = newLabel();
/* 1234 */     Label end = newLabel();
/* 1235 */     if (keys.length > 0) {
/* 1236 */       int len = keys.length;
/* 1237 */       int min = keys[0];
/* 1238 */       int max = keys[(len - 1)];
/* 1239 */       int range = max - min + 1;
/* 1240 */       if (useTable) {
/* 1241 */         Label[] labels = new Label[range];
/* 1242 */         Arrays.fill(labels, def);
/* 1243 */         for (int i = 0; i < len; i++) {
/* 1244 */           labels[(keys[i] - min)] = newLabel();
/*      */         }
/* 1246 */         this.mv.visitTableSwitchInsn(min, max, def, labels);
/* 1247 */         for (int i = 0; i < range; i++) {
/* 1248 */           Label label = labels[i];
/* 1249 */           if (label != def) {
/* 1250 */             mark(label);
/* 1251 */             generator.generateCase(i + min, end);
/*      */           }
/*      */         }
/*      */       } else {
/* 1255 */         Label[] labels = new Label[len];
/* 1256 */         for (int i = 0; i < len; i++) {
/* 1257 */           labels[i] = newLabel();
/*      */         }
/* 1259 */         this.mv.visitLookupSwitchInsn(def, keys, labels);
/* 1260 */         for (int i = 0; i < len; i++) {
/* 1261 */           mark(labels[i]);
/* 1262 */           generator.generateCase(keys[i], end);
/*      */         }
/*      */       }
/*      */     }
/* 1266 */     mark(def);
/* 1267 */     generator.generateDefault();
/* 1268 */     mark(end);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void returnValue()
/*      */   {
/* 1275 */     this.mv.visitInsn(this.returnType.getOpcode(172));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void fieldInsn(int opcode, Type ownerType, String name, Type fieldType)
/*      */   {
/* 1296 */     this.mv.visitFieldInsn(opcode, ownerType.getInternalName(), name, fieldType.getDescriptor());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void getStatic(Type owner, String name, Type type)
/*      */   {
/* 1312 */     fieldInsn(178, owner, name, type);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void putStatic(Type owner, String name, Type type)
/*      */   {
/* 1326 */     fieldInsn(179, owner, name, type);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void getField(Type owner, String name, Type type)
/*      */   {
/* 1341 */     fieldInsn(180, owner, name, type);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void putField(Type owner, String name, Type type)
/*      */   {
/* 1356 */     fieldInsn(181, owner, name, type);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void invokeInsn(int opcode, Type type, Method method)
/*      */   {
/* 1375 */     String owner = type.getSort() == 9 ? type.getDescriptor() : type.getInternalName();
/*      */     
/* 1377 */     this.mv.visitMethodInsn(opcode, owner, method.getName(), method.getDescriptor());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void invokeVirtual(Type owner, Method method)
/*      */   {
/* 1390 */     invokeInsn(182, owner, method);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void invokeConstructor(Type type, Method method)
/*      */   {
/* 1402 */     invokeInsn(183, type, method);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void invokeStatic(Type owner, Method method)
/*      */   {
/* 1414 */     invokeInsn(184, owner, method);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void invokeInterface(Type owner, Method method)
/*      */   {
/* 1426 */     invokeInsn(185, owner, method);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void invokeDynamic(String name, String desc, Handle bsm, Object... bsmArgs)
/*      */   {
/* 1447 */     this.mv.visitInvokeDynamicInsn(name, desc, bsm, bsmArgs);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void typeInsn(int opcode, Type type)
/*      */   {
/* 1463 */     this.mv.visitTypeInsn(opcode, type.getInternalName());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void newInstance(Type type)
/*      */   {
/* 1473 */     typeInsn(187, type);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void newArray(Type type)
/*      */   {
/*      */     int typ;
/*      */     
/*      */ 
/* 1484 */     switch (type.getSort()) {
/*      */     case 1: 
/* 1486 */       typ = 4;
/* 1487 */       break;
/*      */     case 2: 
/* 1489 */       typ = 5;
/* 1490 */       break;
/*      */     case 3: 
/* 1492 */       typ = 8;
/* 1493 */       break;
/*      */     case 4: 
/* 1495 */       typ = 9;
/* 1496 */       break;
/*      */     case 5: 
/* 1498 */       typ = 10;
/* 1499 */       break;
/*      */     case 6: 
/* 1501 */       typ = 6;
/* 1502 */       break;
/*      */     case 7: 
/* 1504 */       typ = 11;
/* 1505 */       break;
/*      */     case 8: 
/* 1507 */       typ = 7;
/* 1508 */       break;
/*      */     default: 
/* 1510 */       typeInsn(189, type);
/* 1511 */       return;
/*      */     }
/* 1513 */     this.mv.visitIntInsn(188, typ);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void arrayLength()
/*      */   {
/* 1524 */     this.mv.visitInsn(190);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void throwException()
/*      */   {
/* 1531 */     this.mv.visitInsn(191);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void throwException(Type type, String msg)
/*      */   {
/* 1544 */     newInstance(type);
/* 1545 */     dup();
/* 1546 */     push(msg);
/* 1547 */     invokeConstructor(type, Method.getMethod("void <init> (String)"));
/* 1548 */     throwException();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void checkCast(Type type)
/*      */   {
/* 1559 */     if (!type.equals(OBJECT_TYPE)) {
/* 1560 */       typeInsn(192, type);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void instanceOf(Type type)
/*      */   {
/* 1572 */     typeInsn(193, type);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void monitorEnter()
/*      */   {
/* 1579 */     this.mv.visitInsn(194);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void monitorExit()
/*      */   {
/* 1586 */     this.mv.visitInsn(195);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void endMethod()
/*      */   {
/* 1597 */     if ((this.access & 0x400) == 0) {
/* 1598 */       this.mv.visitMaxs(0, 0);
/*      */     }
/* 1600 */     this.mv.visitEnd();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void catchException(Label start, Label end, Type exception)
/*      */   {
/* 1616 */     if (exception == null) {
/* 1617 */       this.mv.visitTryCatchBlock(start, end, mark(), null);
/*      */     } else {
/* 1619 */       this.mv.visitTryCatchBlock(start, end, mark(), exception.getInternalName());
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\asm\commons\GeneratorAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */