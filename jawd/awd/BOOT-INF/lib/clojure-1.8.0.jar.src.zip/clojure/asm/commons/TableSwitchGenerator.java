package clojure.asm.commons;

import clojure.asm.Label;

public abstract interface TableSwitchGenerator
{
  public abstract void generateCase(int paramInt, Label paramLabel);
  
  public abstract void generateDefault();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\asm\commons\TableSwitchGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */