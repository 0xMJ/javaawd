/*     */ package clojure.asm.commons;
/*     */ 
/*     */ import clojure.asm.Label;
/*     */ import clojure.asm.MethodVisitor;
/*     */ import clojure.asm.Opcodes;
/*     */ import clojure.asm.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocalVariablesSorter
/*     */   extends MethodVisitor
/*     */ {
/*  51 */   private static final Type OBJECT_TYPE = Type.getObjectType("java/lang/Object");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  59 */   private int[] mapping = new int[40];
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  64 */   private Object[] newLocals = new Object[20];
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final int firstLocal;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int nextLocal;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean changed;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public LocalVariablesSorter(int access, String desc, MethodVisitor mv)
/*     */   {
/*  95 */     this(262144, access, desc, mv);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected LocalVariablesSorter(int api, int access, String desc, MethodVisitor mv)
/*     */   {
/* 113 */     super(api, mv);
/* 114 */     Type[] args = Type.getArgumentTypes(desc);
/* 115 */     this.nextLocal = ((0x8 & access) == 0 ? 1 : 0);
/* 116 */     for (int i = 0; i < args.length; i++) {
/* 117 */       this.nextLocal += args[i].getSize();
/*     */     }
/* 119 */     this.firstLocal = this.nextLocal;
/*     */   }
/*     */   
/*     */   public void visitVarInsn(int opcode, int var)
/*     */   {
/*     */     Type type;
/* 125 */     switch (opcode) {
/*     */     case 22: 
/*     */     case 55: 
/* 128 */       type = Type.LONG_TYPE;
/* 129 */       break;
/*     */     
/*     */     case 24: 
/*     */     case 57: 
/* 133 */       type = Type.DOUBLE_TYPE;
/* 134 */       break;
/*     */     
/*     */     case 23: 
/*     */     case 56: 
/* 138 */       type = Type.FLOAT_TYPE;
/* 139 */       break;
/*     */     
/*     */     case 21: 
/*     */     case 54: 
/* 143 */       type = Type.INT_TYPE;
/* 144 */       break;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     default: 
/* 150 */       type = OBJECT_TYPE;
/*     */     }
/*     */     
/* 153 */     this.mv.visitVarInsn(opcode, remap(var, type));
/*     */   }
/*     */   
/*     */   public void visitIincInsn(int var, int increment)
/*     */   {
/* 158 */     this.mv.visitIincInsn(remap(var, Type.INT_TYPE), increment);
/*     */   }
/*     */   
/*     */   public void visitMaxs(int maxStack, int maxLocals)
/*     */   {
/* 163 */     this.mv.visitMaxs(maxStack, this.nextLocal);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void visitLocalVariable(String name, String desc, String signature, Label start, Label end, int index)
/*     */   {
/* 170 */     int newIndex = remap(index, Type.getType(desc));
/* 171 */     this.mv.visitLocalVariable(name, desc, signature, start, end, newIndex);
/*     */   }
/*     */   
/*     */ 
/*     */   public void visitFrame(int type, int nLocal, Object[] local, int nStack, Object[] stack)
/*     */   {
/* 177 */     if (type != -1) {
/* 178 */       throw new IllegalStateException("ClassReader.accept() should be called with EXPAND_FRAMES flag");
/*     */     }
/*     */     
/*     */ 
/* 182 */     if (!this.changed) {
/* 183 */       this.mv.visitFrame(type, nLocal, local, nStack, stack);
/* 184 */       return;
/*     */     }
/*     */     
/*     */ 
/* 188 */     Object[] oldLocals = new Object[this.newLocals.length];
/* 189 */     System.arraycopy(this.newLocals, 0, oldLocals, 0, oldLocals.length);
/*     */     
/* 191 */     updateNewLocals(this.newLocals);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 196 */     int index = 0;
/* 197 */     for (int number = 0; 
/* 198 */         number < nLocal; number++) {
/* 199 */       Object t = local[number];
/* 200 */       int size = (t == Opcodes.LONG) || (t == Opcodes.DOUBLE) ? 2 : 1;
/* 201 */       if (t != Opcodes.TOP) {
/* 202 */         Type typ = OBJECT_TYPE;
/* 203 */         if (t == Opcodes.INTEGER) {
/* 204 */           typ = Type.INT_TYPE;
/* 205 */         } else if (t == Opcodes.FLOAT) {
/* 206 */           typ = Type.FLOAT_TYPE;
/* 207 */         } else if (t == Opcodes.LONG) {
/* 208 */           typ = Type.LONG_TYPE;
/* 209 */         } else if (t == Opcodes.DOUBLE) {
/* 210 */           typ = Type.DOUBLE_TYPE;
/* 211 */         } else if ((t instanceof String)) {
/* 212 */           typ = Type.getObjectType((String)t);
/*     */         }
/* 214 */         setFrameLocal(remap(index, typ), t);
/*     */       }
/* 216 */       index += size;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 221 */     index = 0;
/* 222 */     number = 0;
/* 223 */     for (int i = 0; index < this.newLocals.length; i++) {
/* 224 */       Object t = this.newLocals[(index++)];
/* 225 */       if ((t != null) && (t != Opcodes.TOP)) {
/* 226 */         this.newLocals[i] = t;
/* 227 */         number = i + 1;
/* 228 */         if ((t == Opcodes.LONG) || (t == Opcodes.DOUBLE)) {
/* 229 */           index++;
/*     */         }
/*     */       } else {
/* 232 */         this.newLocals[i] = Opcodes.TOP;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 237 */     this.mv.visitFrame(type, number, this.newLocals, nStack, stack);
/*     */     
/*     */ 
/* 240 */     this.newLocals = oldLocals;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int newLocal(Type type)
/*     */   {
/*     */     Object t;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 254 */     switch (type.getSort()) {
/*     */     case 1: 
/*     */     case 2: 
/*     */     case 3: 
/*     */     case 4: 
/*     */     case 5: 
/* 260 */       t = Opcodes.INTEGER;
/* 261 */       break;
/*     */     case 6: 
/* 263 */       t = Opcodes.FLOAT;
/* 264 */       break;
/*     */     case 7: 
/* 266 */       t = Opcodes.LONG;
/* 267 */       break;
/*     */     case 8: 
/* 269 */       t = Opcodes.DOUBLE;
/* 270 */       break;
/*     */     case 9: 
/* 272 */       t = type.getDescriptor();
/* 273 */       break;
/*     */     
/*     */     default: 
/* 276 */       t = type.getInternalName();
/*     */     }
/*     */     
/* 279 */     int local = newLocalMapping(type);
/* 280 */     setLocalType(local, type);
/* 281 */     setFrameLocal(local, t);
/* 282 */     return local;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void updateNewLocals(Object[] newLocals) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setLocalType(int local, Type type) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setFrameLocal(int local, Object type)
/*     */   {
/* 321 */     int l = this.newLocals.length;
/* 322 */     if (local >= l) {
/* 323 */       Object[] a = new Object[Math.max(2 * l, local + 1)];
/* 324 */       System.arraycopy(this.newLocals, 0, a, 0, l);
/* 325 */       this.newLocals = a;
/*     */     }
/* 327 */     this.newLocals[local] = type;
/*     */   }
/*     */   
/*     */   private int remap(int var, Type type) {
/* 331 */     if (var + type.getSize() <= this.firstLocal) {
/* 332 */       return var;
/*     */     }
/* 334 */     int key = 2 * var + type.getSize() - 1;
/* 335 */     int size = this.mapping.length;
/* 336 */     if (key >= size) {
/* 337 */       int[] newMapping = new int[Math.max(2 * size, key + 1)];
/* 338 */       System.arraycopy(this.mapping, 0, newMapping, 0, size);
/* 339 */       this.mapping = newMapping;
/*     */     }
/* 341 */     int value = this.mapping[key];
/* 342 */     if (value == 0) {
/* 343 */       value = newLocalMapping(type);
/* 344 */       setLocalType(value, type);
/* 345 */       this.mapping[key] = (value + 1);
/*     */     } else {
/* 347 */       value--;
/*     */     }
/* 349 */     if (value != var) {
/* 350 */       this.changed = true;
/*     */     }
/* 352 */     return value;
/*     */   }
/*     */   
/*     */   protected int newLocalMapping(Type type) {
/* 356 */     int local = this.nextLocal;
/* 357 */     this.nextLocal += type.getSize();
/* 358 */     return local;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\asm\commons\LocalVariablesSorter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */