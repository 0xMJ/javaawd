/*     */ package clojure.asm.commons;
/*     */ 
/*     */ import clojure.asm.ClassVisitor;
/*     */ import clojure.asm.FieldVisitor;
/*     */ import clojure.asm.MethodVisitor;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.DataOutput;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.security.MessageDigest;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SerialVersionUIDAdder
/*     */   extends ClassVisitor
/*     */ {
/*     */   private boolean computeSVUID;
/*     */   private boolean hasSVUID;
/*     */   private int access;
/*     */   private String name;
/*     */   private String[] interfaces;
/*     */   private Collection<Item> svuidFields;
/*     */   private boolean hasStaticInitializer;
/*     */   private Collection<Item> svuidConstructors;
/*     */   private Collection<Item> svuidMethods;
/*     */   
/*     */   public SerialVersionUIDAdder(ClassVisitor cv)
/*     */   {
/* 171 */     this(262144, cv);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected SerialVersionUIDAdder(int api, ClassVisitor cv)
/*     */   {
/* 185 */     super(api, cv);
/* 186 */     this.svuidFields = new ArrayList();
/* 187 */     this.svuidConstructors = new ArrayList();
/* 188 */     this.svuidMethods = new ArrayList();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void visit(int version, int access, String name, String signature, String superName, String[] interfaces)
/*     */   {
/* 203 */     this.computeSVUID = ((access & 0x200) == 0);
/*     */     
/* 205 */     if (this.computeSVUID) {
/* 206 */       this.name = name;
/* 207 */       this.access = access;
/* 208 */       this.interfaces = interfaces;
/*     */     }
/*     */     
/* 211 */     super.visit(version, access, name, signature, superName, interfaces);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MethodVisitor visitMethod(int access, String name, String desc, String signature, String[] exceptions)
/*     */   {
/* 221 */     if (this.computeSVUID) {
/* 222 */       if ("<clinit>".equals(name)) {
/* 223 */         this.hasStaticInitializer = true;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 232 */       int mods = access & 0xD3F;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 239 */       if ((access & 0x2) == 0) {
/* 240 */         if ("<init>".equals(name)) {
/* 241 */           this.svuidConstructors.add(new Item(name, mods, desc));
/* 242 */         } else if (!"<clinit>".equals(name)) {
/* 243 */           this.svuidMethods.add(new Item(name, mods, desc));
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 248 */     return super.visitMethod(access, name, desc, signature, exceptions);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FieldVisitor visitField(int access, String name, String desc, String signature, Object value)
/*     */   {
/* 258 */     if (this.computeSVUID) {
/* 259 */       if ("serialVersionUID".equals(name))
/*     */       {
/* 261 */         this.computeSVUID = false;
/* 262 */         this.hasSVUID = true;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 270 */       if (((access & 0x2) == 0) || ((access & 0x88) == 0))
/*     */       {
/* 272 */         int mods = access & 0xDF;
/*     */         
/*     */ 
/*     */ 
/* 276 */         this.svuidFields.add(new Item(name, mods, desc));
/*     */       }
/*     */     }
/*     */     
/* 280 */     return super.visitField(access, name, desc, signature, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void visitInnerClass(String aname, String outerName, String innerName, int attr_access)
/*     */   {
/* 293 */     if ((this.name != null) && (this.name.equals(aname))) {
/* 294 */       this.access = attr_access;
/*     */     }
/* 296 */     super.visitInnerClass(aname, outerName, innerName, attr_access);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void visitEnd()
/*     */   {
/* 305 */     if ((this.computeSVUID) && (!this.hasSVUID)) {
/*     */       try {
/* 307 */         addSVUID(computeSVUID());
/*     */       } catch (Throwable e) {
/* 309 */         throw new RuntimeException("Error while computing SVUID for " + this.name, e);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 314 */     super.visitEnd();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasSVUID()
/*     */   {
/* 328 */     return this.hasSVUID;
/*     */   }
/*     */   
/*     */   protected void addSVUID(long svuid) {
/* 332 */     FieldVisitor fv = super.visitField(24, "serialVersionUID", "J", null, new Long(svuid));
/*     */     
/*     */ 
/* 335 */     if (fv != null) {
/* 336 */       fv.visitEnd();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected long computeSVUID()
/*     */     throws IOException
/*     */   {
/* 349 */     DataOutputStream dos = null;
/* 350 */     long svuid = 0L;
/*     */     try
/*     */     {
/* 353 */       ByteArrayOutputStream bos = new ByteArrayOutputStream();
/* 354 */       dos = new DataOutputStream(bos);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 359 */       dos.writeUTF(this.name.replace('/', '.'));
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 364 */       dos.writeInt(this.access & 0x611);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 372 */       Arrays.sort(this.interfaces);
/* 373 */       for (int i = 0; i < this.interfaces.length; i++) {
/* 374 */         dos.writeUTF(this.interfaces[i].replace('/', '.'));
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 388 */       writeItems(this.svuidFields, dos, false);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 397 */       if (this.hasStaticInitializer) {
/* 398 */         dos.writeUTF("<clinit>");
/* 399 */         dos.writeInt(8);
/* 400 */         dos.writeUTF("()V");
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 409 */       writeItems(this.svuidConstructors, dos, true);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 417 */       writeItems(this.svuidMethods, dos, true);
/*     */       
/* 419 */       dos.flush();
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 426 */       byte[] hashBytes = computeSHAdigest(bos.toByteArray());
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 441 */       for (int i = Math.min(hashBytes.length, 8) - 1; i >= 0; i--) {
/* 442 */         svuid = svuid << 8 | hashBytes[i] & 0xFF;
/*     */       }
/*     */     }
/*     */     finally {
/* 446 */       if (dos != null) {
/* 447 */         dos.close();
/*     */       }
/*     */     }
/*     */     
/* 451 */     return svuid;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected byte[] computeSHAdigest(byte[] value)
/*     */   {
/*     */     try
/*     */     {
/* 463 */       return MessageDigest.getInstance("SHA").digest(value);
/*     */     } catch (Exception e) {
/* 465 */       throw new UnsupportedOperationException(e.toString());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void writeItems(Collection<Item> itemCollection, DataOutput dos, boolean dotted)
/*     */     throws IOException
/*     */   {
/* 483 */     int size = itemCollection.size();
/* 484 */     Item[] items = (Item[])itemCollection.toArray(new Item[size]);
/* 485 */     Arrays.sort(items);
/* 486 */     for (int i = 0; i < size; i++) {
/* 487 */       dos.writeUTF(items[i].name);
/* 488 */       dos.writeInt(items[i].access);
/* 489 */       dos.writeUTF(dotted ? items[i].desc.replace('/', '.') : items[i].desc);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static class Item
/*     */     implements Comparable<Item>
/*     */   {
/*     */     final String name;
/*     */     
/*     */     final int access;
/*     */     
/*     */     final String desc;
/*     */     
/*     */ 
/*     */     Item(String name, int access, String desc)
/*     */     {
/* 507 */       this.name = name;
/* 508 */       this.access = access;
/* 509 */       this.desc = desc;
/*     */     }
/*     */     
/*     */     public int compareTo(Item other) {
/* 513 */       int retVal = this.name.compareTo(other.name);
/* 514 */       if (retVal == 0) {
/* 515 */         retVal = this.desc.compareTo(other.desc);
/*     */       }
/* 517 */       return retVal;
/*     */     }
/*     */     
/*     */     public boolean equals(Object o)
/*     */     {
/* 522 */       if ((o instanceof Item)) {
/* 523 */         return compareTo((Item)o) == 0;
/*     */       }
/* 525 */       return false;
/*     */     }
/*     */     
/*     */     public int hashCode()
/*     */     {
/* 530 */       return (this.name + this.desc).hashCode();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\asm\commons\SerialVersionUIDAdder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */