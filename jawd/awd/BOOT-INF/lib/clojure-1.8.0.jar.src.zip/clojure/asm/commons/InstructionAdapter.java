/*      */ package clojure.asm.commons;
/*      */ 
/*      */ import clojure.asm.Handle;
/*      */ import clojure.asm.Label;
/*      */ import clojure.asm.MethodVisitor;
/*      */ import clojure.asm.Type;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class InstructionAdapter
/*      */   extends MethodVisitor
/*      */ {
/*   47 */   public static final Type OBJECT_TYPE = Type.getType("Ljava/lang/Object;");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public InstructionAdapter(MethodVisitor mv)
/*      */   {
/*   58 */     this(262144, mv);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected InstructionAdapter(int api, MethodVisitor mv)
/*      */   {
/*   71 */     super(api, mv);
/*      */   }
/*      */   
/*      */   public void visitInsn(int opcode)
/*      */   {
/*   76 */     switch (opcode) {
/*      */     case 0: 
/*   78 */       nop();
/*   79 */       break;
/*      */     case 1: 
/*   81 */       aconst(null);
/*   82 */       break;
/*      */     case 2: 
/*      */     case 3: 
/*      */     case 4: 
/*      */     case 5: 
/*      */     case 6: 
/*      */     case 7: 
/*      */     case 8: 
/*   90 */       iconst(opcode - 3);
/*   91 */       break;
/*      */     case 9: 
/*      */     case 10: 
/*   94 */       lconst(opcode - 9);
/*   95 */       break;
/*      */     case 11: 
/*      */     case 12: 
/*      */     case 13: 
/*   99 */       fconst(opcode - 11);
/*  100 */       break;
/*      */     case 14: 
/*      */     case 15: 
/*  103 */       dconst(opcode - 14);
/*  104 */       break;
/*      */     case 46: 
/*  106 */       aload(Type.INT_TYPE);
/*  107 */       break;
/*      */     case 47: 
/*  109 */       aload(Type.LONG_TYPE);
/*  110 */       break;
/*      */     case 48: 
/*  112 */       aload(Type.FLOAT_TYPE);
/*  113 */       break;
/*      */     case 49: 
/*  115 */       aload(Type.DOUBLE_TYPE);
/*  116 */       break;
/*      */     case 50: 
/*  118 */       aload(OBJECT_TYPE);
/*  119 */       break;
/*      */     case 51: 
/*  121 */       aload(Type.BYTE_TYPE);
/*  122 */       break;
/*      */     case 52: 
/*  124 */       aload(Type.CHAR_TYPE);
/*  125 */       break;
/*      */     case 53: 
/*  127 */       aload(Type.SHORT_TYPE);
/*  128 */       break;
/*      */     case 79: 
/*  130 */       astore(Type.INT_TYPE);
/*  131 */       break;
/*      */     case 80: 
/*  133 */       astore(Type.LONG_TYPE);
/*  134 */       break;
/*      */     case 81: 
/*  136 */       astore(Type.FLOAT_TYPE);
/*  137 */       break;
/*      */     case 82: 
/*  139 */       astore(Type.DOUBLE_TYPE);
/*  140 */       break;
/*      */     case 83: 
/*  142 */       astore(OBJECT_TYPE);
/*  143 */       break;
/*      */     case 84: 
/*  145 */       astore(Type.BYTE_TYPE);
/*  146 */       break;
/*      */     case 85: 
/*  148 */       astore(Type.CHAR_TYPE);
/*  149 */       break;
/*      */     case 86: 
/*  151 */       astore(Type.SHORT_TYPE);
/*  152 */       break;
/*      */     case 87: 
/*  154 */       pop();
/*  155 */       break;
/*      */     case 88: 
/*  157 */       pop2();
/*  158 */       break;
/*      */     case 89: 
/*  160 */       dup();
/*  161 */       break;
/*      */     case 90: 
/*  163 */       dupX1();
/*  164 */       break;
/*      */     case 91: 
/*  166 */       dupX2();
/*  167 */       break;
/*      */     case 92: 
/*  169 */       dup2();
/*  170 */       break;
/*      */     case 93: 
/*  172 */       dup2X1();
/*  173 */       break;
/*      */     case 94: 
/*  175 */       dup2X2();
/*  176 */       break;
/*      */     case 95: 
/*  178 */       swap();
/*  179 */       break;
/*      */     case 96: 
/*  181 */       add(Type.INT_TYPE);
/*  182 */       break;
/*      */     case 97: 
/*  184 */       add(Type.LONG_TYPE);
/*  185 */       break;
/*      */     case 98: 
/*  187 */       add(Type.FLOAT_TYPE);
/*  188 */       break;
/*      */     case 99: 
/*  190 */       add(Type.DOUBLE_TYPE);
/*  191 */       break;
/*      */     case 100: 
/*  193 */       sub(Type.INT_TYPE);
/*  194 */       break;
/*      */     case 101: 
/*  196 */       sub(Type.LONG_TYPE);
/*  197 */       break;
/*      */     case 102: 
/*  199 */       sub(Type.FLOAT_TYPE);
/*  200 */       break;
/*      */     case 103: 
/*  202 */       sub(Type.DOUBLE_TYPE);
/*  203 */       break;
/*      */     case 104: 
/*  205 */       mul(Type.INT_TYPE);
/*  206 */       break;
/*      */     case 105: 
/*  208 */       mul(Type.LONG_TYPE);
/*  209 */       break;
/*      */     case 106: 
/*  211 */       mul(Type.FLOAT_TYPE);
/*  212 */       break;
/*      */     case 107: 
/*  214 */       mul(Type.DOUBLE_TYPE);
/*  215 */       break;
/*      */     case 108: 
/*  217 */       div(Type.INT_TYPE);
/*  218 */       break;
/*      */     case 109: 
/*  220 */       div(Type.LONG_TYPE);
/*  221 */       break;
/*      */     case 110: 
/*  223 */       div(Type.FLOAT_TYPE);
/*  224 */       break;
/*      */     case 111: 
/*  226 */       div(Type.DOUBLE_TYPE);
/*  227 */       break;
/*      */     case 112: 
/*  229 */       rem(Type.INT_TYPE);
/*  230 */       break;
/*      */     case 113: 
/*  232 */       rem(Type.LONG_TYPE);
/*  233 */       break;
/*      */     case 114: 
/*  235 */       rem(Type.FLOAT_TYPE);
/*  236 */       break;
/*      */     case 115: 
/*  238 */       rem(Type.DOUBLE_TYPE);
/*  239 */       break;
/*      */     case 116: 
/*  241 */       neg(Type.INT_TYPE);
/*  242 */       break;
/*      */     case 117: 
/*  244 */       neg(Type.LONG_TYPE);
/*  245 */       break;
/*      */     case 118: 
/*  247 */       neg(Type.FLOAT_TYPE);
/*  248 */       break;
/*      */     case 119: 
/*  250 */       neg(Type.DOUBLE_TYPE);
/*  251 */       break;
/*      */     case 120: 
/*  253 */       shl(Type.INT_TYPE);
/*  254 */       break;
/*      */     case 121: 
/*  256 */       shl(Type.LONG_TYPE);
/*  257 */       break;
/*      */     case 122: 
/*  259 */       shr(Type.INT_TYPE);
/*  260 */       break;
/*      */     case 123: 
/*  262 */       shr(Type.LONG_TYPE);
/*  263 */       break;
/*      */     case 124: 
/*  265 */       ushr(Type.INT_TYPE);
/*  266 */       break;
/*      */     case 125: 
/*  268 */       ushr(Type.LONG_TYPE);
/*  269 */       break;
/*      */     case 126: 
/*  271 */       and(Type.INT_TYPE);
/*  272 */       break;
/*      */     case 127: 
/*  274 */       and(Type.LONG_TYPE);
/*  275 */       break;
/*      */     case 128: 
/*  277 */       or(Type.INT_TYPE);
/*  278 */       break;
/*      */     case 129: 
/*  280 */       or(Type.LONG_TYPE);
/*  281 */       break;
/*      */     case 130: 
/*  283 */       xor(Type.INT_TYPE);
/*  284 */       break;
/*      */     case 131: 
/*  286 */       xor(Type.LONG_TYPE);
/*  287 */       break;
/*      */     case 133: 
/*  289 */       cast(Type.INT_TYPE, Type.LONG_TYPE);
/*  290 */       break;
/*      */     case 134: 
/*  292 */       cast(Type.INT_TYPE, Type.FLOAT_TYPE);
/*  293 */       break;
/*      */     case 135: 
/*  295 */       cast(Type.INT_TYPE, Type.DOUBLE_TYPE);
/*  296 */       break;
/*      */     case 136: 
/*  298 */       cast(Type.LONG_TYPE, Type.INT_TYPE);
/*  299 */       break;
/*      */     case 137: 
/*  301 */       cast(Type.LONG_TYPE, Type.FLOAT_TYPE);
/*  302 */       break;
/*      */     case 138: 
/*  304 */       cast(Type.LONG_TYPE, Type.DOUBLE_TYPE);
/*  305 */       break;
/*      */     case 139: 
/*  307 */       cast(Type.FLOAT_TYPE, Type.INT_TYPE);
/*  308 */       break;
/*      */     case 140: 
/*  310 */       cast(Type.FLOAT_TYPE, Type.LONG_TYPE);
/*  311 */       break;
/*      */     case 141: 
/*  313 */       cast(Type.FLOAT_TYPE, Type.DOUBLE_TYPE);
/*  314 */       break;
/*      */     case 142: 
/*  316 */       cast(Type.DOUBLE_TYPE, Type.INT_TYPE);
/*  317 */       break;
/*      */     case 143: 
/*  319 */       cast(Type.DOUBLE_TYPE, Type.LONG_TYPE);
/*  320 */       break;
/*      */     case 144: 
/*  322 */       cast(Type.DOUBLE_TYPE, Type.FLOAT_TYPE);
/*  323 */       break;
/*      */     case 145: 
/*  325 */       cast(Type.INT_TYPE, Type.BYTE_TYPE);
/*  326 */       break;
/*      */     case 146: 
/*  328 */       cast(Type.INT_TYPE, Type.CHAR_TYPE);
/*  329 */       break;
/*      */     case 147: 
/*  331 */       cast(Type.INT_TYPE, Type.SHORT_TYPE);
/*  332 */       break;
/*      */     case 148: 
/*  334 */       lcmp();
/*  335 */       break;
/*      */     case 149: 
/*  337 */       cmpl(Type.FLOAT_TYPE);
/*  338 */       break;
/*      */     case 150: 
/*  340 */       cmpg(Type.FLOAT_TYPE);
/*  341 */       break;
/*      */     case 151: 
/*  343 */       cmpl(Type.DOUBLE_TYPE);
/*  344 */       break;
/*      */     case 152: 
/*  346 */       cmpg(Type.DOUBLE_TYPE);
/*  347 */       break;
/*      */     case 172: 
/*  349 */       areturn(Type.INT_TYPE);
/*  350 */       break;
/*      */     case 173: 
/*  352 */       areturn(Type.LONG_TYPE);
/*  353 */       break;
/*      */     case 174: 
/*  355 */       areturn(Type.FLOAT_TYPE);
/*  356 */       break;
/*      */     case 175: 
/*  358 */       areturn(Type.DOUBLE_TYPE);
/*  359 */       break;
/*      */     case 176: 
/*  361 */       areturn(OBJECT_TYPE);
/*  362 */       break;
/*      */     case 177: 
/*  364 */       areturn(Type.VOID_TYPE);
/*  365 */       break;
/*      */     case 190: 
/*  367 */       arraylength();
/*  368 */       break;
/*      */     case 191: 
/*  370 */       athrow();
/*  371 */       break;
/*      */     case 194: 
/*  373 */       monitorenter();
/*  374 */       break;
/*      */     case 195: 
/*  376 */       monitorexit();
/*  377 */       break;
/*      */     case 16: case 17: case 18: case 19: case 20: case 21: case 22: case 23: case 24: case 25: case 26: case 27: case 28: case 29: case 30: case 31: case 32: case 33: case 34: case 35: case 36: case 37: case 38: case 39: case 40: case 41: case 42: case 43: case 44: case 45: case 54: case 55: case 56: case 57: case 58: case 59: case 60: case 61: case 62: case 63: case 64: case 65: case 66: case 67: case 68: case 69: case 70: case 71: case 72: case 73: case 74: case 75: case 76: case 77: case 78: case 132: case 153: case 154: case 155: case 156: case 157: case 158: case 159: case 160: case 161: case 162: case 163: case 164: case 165: case 166: case 167: case 168: case 169: case 170: case 171: case 178: case 179: case 180: case 181: case 182: case 183: case 184: case 185: case 186: case 187: case 188: case 189: case 192: case 193: default: 
/*  379 */       throw new IllegalArgumentException();
/*      */     }
/*      */   }
/*      */   
/*      */   public void visitIntInsn(int opcode, int operand)
/*      */   {
/*  385 */     switch (opcode) {
/*      */     case 16: 
/*  387 */       iconst(operand);
/*  388 */       break;
/*      */     case 17: 
/*  390 */       iconst(operand);
/*  391 */       break;
/*      */     case 188: 
/*  393 */       switch (operand) {
/*      */       case 4: 
/*  395 */         newarray(Type.BOOLEAN_TYPE);
/*  396 */         break;
/*      */       case 5: 
/*  398 */         newarray(Type.CHAR_TYPE);
/*  399 */         break;
/*      */       case 8: 
/*  401 */         newarray(Type.BYTE_TYPE);
/*  402 */         break;
/*      */       case 9: 
/*  404 */         newarray(Type.SHORT_TYPE);
/*  405 */         break;
/*      */       case 10: 
/*  407 */         newarray(Type.INT_TYPE);
/*  408 */         break;
/*      */       case 6: 
/*  410 */         newarray(Type.FLOAT_TYPE);
/*  411 */         break;
/*      */       case 11: 
/*  413 */         newarray(Type.LONG_TYPE);
/*  414 */         break;
/*      */       case 7: 
/*  416 */         newarray(Type.DOUBLE_TYPE);
/*  417 */         break;
/*      */       default: 
/*  419 */         throw new IllegalArgumentException();
/*      */       }
/*      */       break;
/*      */     default: 
/*  423 */       throw new IllegalArgumentException();
/*      */     }
/*      */   }
/*      */   
/*      */   public void visitVarInsn(int opcode, int var)
/*      */   {
/*  429 */     switch (opcode) {
/*      */     case 21: 
/*  431 */       load(var, Type.INT_TYPE);
/*  432 */       break;
/*      */     case 22: 
/*  434 */       load(var, Type.LONG_TYPE);
/*  435 */       break;
/*      */     case 23: 
/*  437 */       load(var, Type.FLOAT_TYPE);
/*  438 */       break;
/*      */     case 24: 
/*  440 */       load(var, Type.DOUBLE_TYPE);
/*  441 */       break;
/*      */     case 25: 
/*  443 */       load(var, OBJECT_TYPE);
/*  444 */       break;
/*      */     case 54: 
/*  446 */       store(var, Type.INT_TYPE);
/*  447 */       break;
/*      */     case 55: 
/*  449 */       store(var, Type.LONG_TYPE);
/*  450 */       break;
/*      */     case 56: 
/*  452 */       store(var, Type.FLOAT_TYPE);
/*  453 */       break;
/*      */     case 57: 
/*  455 */       store(var, Type.DOUBLE_TYPE);
/*  456 */       break;
/*      */     case 58: 
/*  458 */       store(var, OBJECT_TYPE);
/*  459 */       break;
/*      */     case 169: 
/*  461 */       ret(var);
/*  462 */       break;
/*      */     default: 
/*  464 */       throw new IllegalArgumentException();
/*      */     }
/*      */   }
/*      */   
/*      */   public void visitTypeInsn(int opcode, String type)
/*      */   {
/*  470 */     Type t = Type.getObjectType(type);
/*  471 */     switch (opcode) {
/*      */     case 187: 
/*  473 */       anew(t);
/*  474 */       break;
/*      */     case 189: 
/*  476 */       newarray(t);
/*  477 */       break;
/*      */     case 192: 
/*  479 */       checkcast(t);
/*  480 */       break;
/*      */     case 193: 
/*  482 */       instanceOf(t);
/*  483 */       break;
/*      */     case 188: case 190: case 191: default: 
/*  485 */       throw new IllegalArgumentException();
/*      */     }
/*      */     
/*      */   }
/*      */   
/*      */   public void visitFieldInsn(int opcode, String owner, String name, String desc)
/*      */   {
/*  492 */     switch (opcode) {
/*      */     case 178: 
/*  494 */       getstatic(owner, name, desc);
/*  495 */       break;
/*      */     case 179: 
/*  497 */       putstatic(owner, name, desc);
/*  498 */       break;
/*      */     case 180: 
/*  500 */       getfield(owner, name, desc);
/*  501 */       break;
/*      */     case 181: 
/*  503 */       putfield(owner, name, desc);
/*  504 */       break;
/*      */     default: 
/*  506 */       throw new IllegalArgumentException();
/*      */     }
/*      */     
/*      */   }
/*      */   
/*      */   public void visitMethodInsn(int opcode, String owner, String name, String desc)
/*      */   {
/*  513 */     switch (opcode) {
/*      */     case 183: 
/*  515 */       invokespecial(owner, name, desc);
/*  516 */       break;
/*      */     case 182: 
/*  518 */       invokevirtual(owner, name, desc);
/*  519 */       break;
/*      */     case 184: 
/*  521 */       invokestatic(owner, name, desc);
/*  522 */       break;
/*      */     case 185: 
/*  524 */       invokeinterface(owner, name, desc);
/*  525 */       break;
/*      */     default: 
/*  527 */       throw new IllegalArgumentException();
/*      */     }
/*      */     
/*      */   }
/*      */   
/*      */   public void visitInvokeDynamicInsn(String name, String desc, Handle bsm, Object... bsmArgs)
/*      */   {
/*  534 */     invokedynamic(name, desc, bsm, bsmArgs);
/*      */   }
/*      */   
/*      */   public void visitJumpInsn(int opcode, Label label)
/*      */   {
/*  539 */     switch (opcode) {
/*      */     case 153: 
/*  541 */       ifeq(label);
/*  542 */       break;
/*      */     case 154: 
/*  544 */       ifne(label);
/*  545 */       break;
/*      */     case 155: 
/*  547 */       iflt(label);
/*  548 */       break;
/*      */     case 156: 
/*  550 */       ifge(label);
/*  551 */       break;
/*      */     case 157: 
/*  553 */       ifgt(label);
/*  554 */       break;
/*      */     case 158: 
/*  556 */       ifle(label);
/*  557 */       break;
/*      */     case 159: 
/*  559 */       ificmpeq(label);
/*  560 */       break;
/*      */     case 160: 
/*  562 */       ificmpne(label);
/*  563 */       break;
/*      */     case 161: 
/*  565 */       ificmplt(label);
/*  566 */       break;
/*      */     case 162: 
/*  568 */       ificmpge(label);
/*  569 */       break;
/*      */     case 163: 
/*  571 */       ificmpgt(label);
/*  572 */       break;
/*      */     case 164: 
/*  574 */       ificmple(label);
/*  575 */       break;
/*      */     case 165: 
/*  577 */       ifacmpeq(label);
/*  578 */       break;
/*      */     case 166: 
/*  580 */       ifacmpne(label);
/*  581 */       break;
/*      */     case 167: 
/*  583 */       goTo(label);
/*  584 */       break;
/*      */     case 168: 
/*  586 */       jsr(label);
/*  587 */       break;
/*      */     case 198: 
/*  589 */       ifnull(label);
/*  590 */       break;
/*      */     case 199: 
/*  592 */       ifnonnull(label);
/*  593 */       break;
/*      */     case 169: case 170: case 171: case 172: case 173: case 174: case 175: case 176: case 177: case 178: case 179: case 180: case 181: case 182: case 183: case 184: case 185: case 186: case 187: case 188: case 189: case 190: case 191: case 192: case 193: case 194: case 195: case 196: case 197: default: 
/*  595 */       throw new IllegalArgumentException();
/*      */     }
/*      */   }
/*      */   
/*      */   public void visitLabel(Label label)
/*      */   {
/*  601 */     mark(label);
/*      */   }
/*      */   
/*      */   public void visitLdcInsn(Object cst)
/*      */   {
/*  606 */     if ((cst instanceof Integer)) {
/*  607 */       int val = ((Integer)cst).intValue();
/*  608 */       iconst(val);
/*  609 */     } else if ((cst instanceof Byte)) {
/*  610 */       int val = ((Byte)cst).intValue();
/*  611 */       iconst(val);
/*  612 */     } else if ((cst instanceof Character)) {
/*  613 */       int val = ((Character)cst).charValue();
/*  614 */       iconst(val);
/*  615 */     } else if ((cst instanceof Short)) {
/*  616 */       int val = ((Short)cst).intValue();
/*  617 */       iconst(val);
/*  618 */     } else if ((cst instanceof Boolean)) {
/*  619 */       int val = ((Boolean)cst).booleanValue() ? 1 : 0;
/*  620 */       iconst(val);
/*  621 */     } else if ((cst instanceof Float)) {
/*  622 */       float val = ((Float)cst).floatValue();
/*  623 */       fconst(val);
/*  624 */     } else if ((cst instanceof Long)) {
/*  625 */       long val = ((Long)cst).longValue();
/*  626 */       lconst(val);
/*  627 */     } else if ((cst instanceof Double)) {
/*  628 */       double val = ((Double)cst).doubleValue();
/*  629 */       dconst(val);
/*  630 */     } else if ((cst instanceof String)) {
/*  631 */       aconst(cst);
/*  632 */     } else if ((cst instanceof Type)) {
/*  633 */       tconst((Type)cst);
/*  634 */     } else if ((cst instanceof Handle)) {
/*  635 */       hconst((Handle)cst);
/*      */     } else {
/*  637 */       throw new IllegalArgumentException();
/*      */     }
/*      */   }
/*      */   
/*      */   public void visitIincInsn(int var, int increment)
/*      */   {
/*  643 */     iinc(var, increment);
/*      */   }
/*      */   
/*      */ 
/*      */   public void visitTableSwitchInsn(int min, int max, Label dflt, Label... labels)
/*      */   {
/*  649 */     tableswitch(min, max, dflt, labels);
/*      */   }
/*      */   
/*      */ 
/*      */   public void visitLookupSwitchInsn(Label dflt, int[] keys, Label[] labels)
/*      */   {
/*  655 */     lookupswitch(dflt, keys, labels);
/*      */   }
/*      */   
/*      */   public void visitMultiANewArrayInsn(String desc, int dims)
/*      */   {
/*  660 */     multianewarray(desc, dims);
/*      */   }
/*      */   
/*      */ 
/*      */   public void nop()
/*      */   {
/*  666 */     this.mv.visitInsn(0);
/*      */   }
/*      */   
/*      */   public void aconst(Object cst) {
/*  670 */     if (cst == null) {
/*  671 */       this.mv.visitInsn(1);
/*      */     } else {
/*  673 */       this.mv.visitLdcInsn(cst);
/*      */     }
/*      */   }
/*      */   
/*      */   public void iconst(int cst) {
/*  678 */     if ((cst >= -1) && (cst <= 5)) {
/*  679 */       this.mv.visitInsn(3 + cst);
/*  680 */     } else if ((cst >= -128) && (cst <= 127)) {
/*  681 */       this.mv.visitIntInsn(16, cst);
/*  682 */     } else if ((cst >= 32768) && (cst <= 32767)) {
/*  683 */       this.mv.visitIntInsn(17, cst);
/*      */     } else {
/*  685 */       this.mv.visitLdcInsn(new Integer(cst));
/*      */     }
/*      */   }
/*      */   
/*      */   public void lconst(long cst) {
/*  690 */     if ((cst == 0L) || (cst == 1L)) {
/*  691 */       this.mv.visitInsn(9 + (int)cst);
/*      */     } else {
/*  693 */       this.mv.visitLdcInsn(new Long(cst));
/*      */     }
/*      */   }
/*      */   
/*      */   public void fconst(float cst) {
/*  698 */     int bits = Float.floatToIntBits(cst);
/*  699 */     if ((bits == 0L) || (bits == 1065353216) || (bits == 1073741824)) {
/*  700 */       this.mv.visitInsn(11 + (int)cst);
/*      */     } else {
/*  702 */       this.mv.visitLdcInsn(new Float(cst));
/*      */     }
/*      */   }
/*      */   
/*      */   public void dconst(double cst) {
/*  707 */     long bits = Double.doubleToLongBits(cst);
/*  708 */     if ((bits == 0L) || (bits == 4607182418800017408L)) {
/*  709 */       this.mv.visitInsn(14 + (int)cst);
/*      */     } else {
/*  711 */       this.mv.visitLdcInsn(new Double(cst));
/*      */     }
/*      */   }
/*      */   
/*      */   public void tconst(Type type) {
/*  716 */     this.mv.visitLdcInsn(type);
/*      */   }
/*      */   
/*      */   public void hconst(Handle handle) {
/*  720 */     this.mv.visitLdcInsn(handle);
/*      */   }
/*      */   
/*      */   public void load(int var, Type type) {
/*  724 */     this.mv.visitVarInsn(type.getOpcode(21), var);
/*      */   }
/*      */   
/*      */   public void aload(Type type) {
/*  728 */     this.mv.visitInsn(type.getOpcode(46));
/*      */   }
/*      */   
/*      */   public void store(int var, Type type) {
/*  732 */     this.mv.visitVarInsn(type.getOpcode(54), var);
/*      */   }
/*      */   
/*      */   public void astore(Type type) {
/*  736 */     this.mv.visitInsn(type.getOpcode(79));
/*      */   }
/*      */   
/*      */   public void pop() {
/*  740 */     this.mv.visitInsn(87);
/*      */   }
/*      */   
/*      */   public void pop2() {
/*  744 */     this.mv.visitInsn(88);
/*      */   }
/*      */   
/*      */   public void dup() {
/*  748 */     this.mv.visitInsn(89);
/*      */   }
/*      */   
/*      */   public void dup2() {
/*  752 */     this.mv.visitInsn(92);
/*      */   }
/*      */   
/*      */   public void dupX1() {
/*  756 */     this.mv.visitInsn(90);
/*      */   }
/*      */   
/*      */   public void dupX2() {
/*  760 */     this.mv.visitInsn(91);
/*      */   }
/*      */   
/*      */   public void dup2X1() {
/*  764 */     this.mv.visitInsn(93);
/*      */   }
/*      */   
/*      */   public void dup2X2() {
/*  768 */     this.mv.visitInsn(94);
/*      */   }
/*      */   
/*      */   public void swap() {
/*  772 */     this.mv.visitInsn(95);
/*      */   }
/*      */   
/*      */   public void add(Type type) {
/*  776 */     this.mv.visitInsn(type.getOpcode(96));
/*      */   }
/*      */   
/*      */   public void sub(Type type) {
/*  780 */     this.mv.visitInsn(type.getOpcode(100));
/*      */   }
/*      */   
/*      */   public void mul(Type type) {
/*  784 */     this.mv.visitInsn(type.getOpcode(104));
/*      */   }
/*      */   
/*      */   public void div(Type type) {
/*  788 */     this.mv.visitInsn(type.getOpcode(108));
/*      */   }
/*      */   
/*      */   public void rem(Type type) {
/*  792 */     this.mv.visitInsn(type.getOpcode(112));
/*      */   }
/*      */   
/*      */   public void neg(Type type) {
/*  796 */     this.mv.visitInsn(type.getOpcode(116));
/*      */   }
/*      */   
/*      */   public void shl(Type type) {
/*  800 */     this.mv.visitInsn(type.getOpcode(120));
/*      */   }
/*      */   
/*      */   public void shr(Type type) {
/*  804 */     this.mv.visitInsn(type.getOpcode(122));
/*      */   }
/*      */   
/*      */   public void ushr(Type type) {
/*  808 */     this.mv.visitInsn(type.getOpcode(124));
/*      */   }
/*      */   
/*      */   public void and(Type type) {
/*  812 */     this.mv.visitInsn(type.getOpcode(126));
/*      */   }
/*      */   
/*      */   public void or(Type type) {
/*  816 */     this.mv.visitInsn(type.getOpcode(128));
/*      */   }
/*      */   
/*      */   public void xor(Type type) {
/*  820 */     this.mv.visitInsn(type.getOpcode(130));
/*      */   }
/*      */   
/*      */   public void iinc(int var, int increment) {
/*  824 */     this.mv.visitIincInsn(var, increment);
/*      */   }
/*      */   
/*      */   public void cast(Type from, Type to) {
/*  828 */     if (from != to) {
/*  829 */       if (from == Type.DOUBLE_TYPE) {
/*  830 */         if (to == Type.FLOAT_TYPE) {
/*  831 */           this.mv.visitInsn(144);
/*  832 */         } else if (to == Type.LONG_TYPE) {
/*  833 */           this.mv.visitInsn(143);
/*      */         } else {
/*  835 */           this.mv.visitInsn(142);
/*  836 */           cast(Type.INT_TYPE, to);
/*      */         }
/*  838 */       } else if (from == Type.FLOAT_TYPE) {
/*  839 */         if (to == Type.DOUBLE_TYPE) {
/*  840 */           this.mv.visitInsn(141);
/*  841 */         } else if (to == Type.LONG_TYPE) {
/*  842 */           this.mv.visitInsn(140);
/*      */         } else {
/*  844 */           this.mv.visitInsn(139);
/*  845 */           cast(Type.INT_TYPE, to);
/*      */         }
/*  847 */       } else if (from == Type.LONG_TYPE) {
/*  848 */         if (to == Type.DOUBLE_TYPE) {
/*  849 */           this.mv.visitInsn(138);
/*  850 */         } else if (to == Type.FLOAT_TYPE) {
/*  851 */           this.mv.visitInsn(137);
/*      */         } else {
/*  853 */           this.mv.visitInsn(136);
/*  854 */           cast(Type.INT_TYPE, to);
/*      */         }
/*      */       }
/*  857 */       else if (to == Type.BYTE_TYPE) {
/*  858 */         this.mv.visitInsn(145);
/*  859 */       } else if (to == Type.CHAR_TYPE) {
/*  860 */         this.mv.visitInsn(146);
/*  861 */       } else if (to == Type.DOUBLE_TYPE) {
/*  862 */         this.mv.visitInsn(135);
/*  863 */       } else if (to == Type.FLOAT_TYPE) {
/*  864 */         this.mv.visitInsn(134);
/*  865 */       } else if (to == Type.LONG_TYPE) {
/*  866 */         this.mv.visitInsn(133);
/*  867 */       } else if (to == Type.SHORT_TYPE) {
/*  868 */         this.mv.visitInsn(147);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public void lcmp()
/*      */   {
/*  875 */     this.mv.visitInsn(148);
/*      */   }
/*      */   
/*      */   public void cmpl(Type type) {
/*  879 */     this.mv.visitInsn(type == Type.FLOAT_TYPE ? 149 : 151);
/*      */   }
/*      */   
/*      */   public void cmpg(Type type) {
/*  883 */     this.mv.visitInsn(type == Type.FLOAT_TYPE ? 150 : 152);
/*      */   }
/*      */   
/*      */   public void ifeq(Label label) {
/*  887 */     this.mv.visitJumpInsn(153, label);
/*      */   }
/*      */   
/*      */   public void ifne(Label label) {
/*  891 */     this.mv.visitJumpInsn(154, label);
/*      */   }
/*      */   
/*      */   public void iflt(Label label) {
/*  895 */     this.mv.visitJumpInsn(155, label);
/*      */   }
/*      */   
/*      */   public void ifge(Label label) {
/*  899 */     this.mv.visitJumpInsn(156, label);
/*      */   }
/*      */   
/*      */   public void ifgt(Label label) {
/*  903 */     this.mv.visitJumpInsn(157, label);
/*      */   }
/*      */   
/*      */   public void ifle(Label label) {
/*  907 */     this.mv.visitJumpInsn(158, label);
/*      */   }
/*      */   
/*      */   public void ificmpeq(Label label) {
/*  911 */     this.mv.visitJumpInsn(159, label);
/*      */   }
/*      */   
/*      */   public void ificmpne(Label label) {
/*  915 */     this.mv.visitJumpInsn(160, label);
/*      */   }
/*      */   
/*      */   public void ificmplt(Label label) {
/*  919 */     this.mv.visitJumpInsn(161, label);
/*      */   }
/*      */   
/*      */   public void ificmpge(Label label) {
/*  923 */     this.mv.visitJumpInsn(162, label);
/*      */   }
/*      */   
/*      */   public void ificmpgt(Label label) {
/*  927 */     this.mv.visitJumpInsn(163, label);
/*      */   }
/*      */   
/*      */   public void ificmple(Label label) {
/*  931 */     this.mv.visitJumpInsn(164, label);
/*      */   }
/*      */   
/*      */   public void ifacmpeq(Label label) {
/*  935 */     this.mv.visitJumpInsn(165, label);
/*      */   }
/*      */   
/*      */   public void ifacmpne(Label label) {
/*  939 */     this.mv.visitJumpInsn(166, label);
/*      */   }
/*      */   
/*      */   public void goTo(Label label) {
/*  943 */     this.mv.visitJumpInsn(167, label);
/*      */   }
/*      */   
/*      */   public void jsr(Label label) {
/*  947 */     this.mv.visitJumpInsn(168, label);
/*      */   }
/*      */   
/*      */   public void ret(int var) {
/*  951 */     this.mv.visitVarInsn(169, var);
/*      */   }
/*      */   
/*      */   public void tableswitch(int min, int max, Label dflt, Label... labels)
/*      */   {
/*  956 */     this.mv.visitTableSwitchInsn(min, max, dflt, labels);
/*      */   }
/*      */   
/*      */   public void lookupswitch(Label dflt, int[] keys, Label[] labels)
/*      */   {
/*  961 */     this.mv.visitLookupSwitchInsn(dflt, keys, labels);
/*      */   }
/*      */   
/*      */   public void areturn(Type t) {
/*  965 */     this.mv.visitInsn(t.getOpcode(172));
/*      */   }
/*      */   
/*      */   public void getstatic(String owner, String name, String desc)
/*      */   {
/*  970 */     this.mv.visitFieldInsn(178, owner, name, desc);
/*      */   }
/*      */   
/*      */   public void putstatic(String owner, String name, String desc)
/*      */   {
/*  975 */     this.mv.visitFieldInsn(179, owner, name, desc);
/*      */   }
/*      */   
/*      */   public void getfield(String owner, String name, String desc)
/*      */   {
/*  980 */     this.mv.visitFieldInsn(180, owner, name, desc);
/*      */   }
/*      */   
/*      */   public void putfield(String owner, String name, String desc)
/*      */   {
/*  985 */     this.mv.visitFieldInsn(181, owner, name, desc);
/*      */   }
/*      */   
/*      */   public void invokevirtual(String owner, String name, String desc)
/*      */   {
/*  990 */     this.mv.visitMethodInsn(182, owner, name, desc);
/*      */   }
/*      */   
/*      */   public void invokespecial(String owner, String name, String desc)
/*      */   {
/*  995 */     this.mv.visitMethodInsn(183, owner, name, desc);
/*      */   }
/*      */   
/*      */   public void invokestatic(String owner, String name, String desc)
/*      */   {
/* 1000 */     this.mv.visitMethodInsn(184, owner, name, desc);
/*      */   }
/*      */   
/*      */   public void invokeinterface(String owner, String name, String desc)
/*      */   {
/* 1005 */     this.mv.visitMethodInsn(185, owner, name, desc);
/*      */   }
/*      */   
/*      */   public void invokedynamic(String name, String desc, Handle bsm, Object[] bsmArgs)
/*      */   {
/* 1010 */     this.mv.visitInvokeDynamicInsn(name, desc, bsm, bsmArgs);
/*      */   }
/*      */   
/*      */   public void anew(Type type) {
/* 1014 */     this.mv.visitTypeInsn(187, type.getInternalName());
/*      */   }
/*      */   
/*      */   public void newarray(Type type) {
/*      */     int typ;
/* 1019 */     switch (type.getSort()) {
/*      */     case 1: 
/* 1021 */       typ = 4;
/* 1022 */       break;
/*      */     case 2: 
/* 1024 */       typ = 5;
/* 1025 */       break;
/*      */     case 3: 
/* 1027 */       typ = 8;
/* 1028 */       break;
/*      */     case 4: 
/* 1030 */       typ = 9;
/* 1031 */       break;
/*      */     case 5: 
/* 1033 */       typ = 10;
/* 1034 */       break;
/*      */     case 6: 
/* 1036 */       typ = 6;
/* 1037 */       break;
/*      */     case 7: 
/* 1039 */       typ = 11;
/* 1040 */       break;
/*      */     case 8: 
/* 1042 */       typ = 7;
/* 1043 */       break;
/*      */     default: 
/* 1045 */       this.mv.visitTypeInsn(189, type.getInternalName());
/* 1046 */       return;
/*      */     }
/* 1048 */     this.mv.visitIntInsn(188, typ);
/*      */   }
/*      */   
/*      */   public void arraylength() {
/* 1052 */     this.mv.visitInsn(190);
/*      */   }
/*      */   
/*      */   public void athrow() {
/* 1056 */     this.mv.visitInsn(191);
/*      */   }
/*      */   
/*      */   public void checkcast(Type type) {
/* 1060 */     this.mv.visitTypeInsn(192, type.getInternalName());
/*      */   }
/*      */   
/*      */   public void instanceOf(Type type) {
/* 1064 */     this.mv.visitTypeInsn(193, type.getInternalName());
/*      */   }
/*      */   
/*      */   public void monitorenter() {
/* 1068 */     this.mv.visitInsn(194);
/*      */   }
/*      */   
/*      */   public void monitorexit() {
/* 1072 */     this.mv.visitInsn(195);
/*      */   }
/*      */   
/*      */   public void multianewarray(String desc, int dims) {
/* 1076 */     this.mv.visitMultiANewArrayInsn(desc, dims);
/*      */   }
/*      */   
/*      */   public void ifnull(Label label) {
/* 1080 */     this.mv.visitJumpInsn(198, label);
/*      */   }
/*      */   
/*      */   public void ifnonnull(Label label) {
/* 1084 */     this.mv.visitJumpInsn(199, label);
/*      */   }
/*      */   
/*      */   public void mark(Label label) {
/* 1088 */     this.mv.visitLabel(label);
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\asm\commons\InstructionAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */