/*     */ package clojure.asm;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Label
/*     */ {
/*     */   static final int DEBUG = 1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static final int RESOLVED = 2;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static final int RESIZED = 4;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static final int PUSHED = 8;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static final int TARGET = 16;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static final int STORE = 32;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static final int REACHABLE = 64;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static final int JSR = 128;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static final int RET = 256;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static final int SUBROUTINE = 512;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static final int VISITED = 1024;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static final int VISITED2 = 2048;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object info;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int status;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int line;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int position;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int referenceCount;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int[] srcAndRefPositions;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int inputStackTop;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int outputStackMax;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Frame frame;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Label successor;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Edge successors;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Label next;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getOffset()
/*     */   {
/* 273 */     if ((this.status & 0x2) == 0) {
/* 274 */       throw new IllegalStateException("Label offset position has not been resolved yet");
/*     */     }
/*     */     
/* 277 */     return this.position;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void put(MethodWriter owner, ByteVector out, int source, boolean wideOffset)
/*     */   {
/* 301 */     if ((this.status & 0x2) == 0) {
/* 302 */       if (wideOffset) {
/* 303 */         addReference(-1 - source, out.length);
/* 304 */         out.putInt(-1);
/*     */       } else {
/* 306 */         addReference(source, out.length);
/* 307 */         out.putShort(-1);
/*     */       }
/*     */     }
/* 310 */     else if (wideOffset) {
/* 311 */       out.putInt(this.position - source);
/*     */     } else {
/* 313 */       out.putShort(this.position - source);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void addReference(int sourcePosition, int referencePosition)
/*     */   {
/* 333 */     if (this.srcAndRefPositions == null) {
/* 334 */       this.srcAndRefPositions = new int[6];
/*     */     }
/* 336 */     if (this.referenceCount >= this.srcAndRefPositions.length) {
/* 337 */       int[] a = new int[this.srcAndRefPositions.length + 6];
/* 338 */       System.arraycopy(this.srcAndRefPositions, 0, a, 0, this.srcAndRefPositions.length);
/*     */       
/* 340 */       this.srcAndRefPositions = a;
/*     */     }
/* 342 */     this.srcAndRefPositions[(this.referenceCount++)] = sourcePosition;
/* 343 */     this.srcAndRefPositions[(this.referenceCount++)] = referencePosition;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean resolve(MethodWriter owner, int position, byte[] data)
/*     */   {
/* 371 */     boolean needUpdate = false;
/* 372 */     this.status |= 0x2;
/* 373 */     this.position = position;
/* 374 */     int i = 0;
/* 375 */     while (i < this.referenceCount) {
/* 376 */       int source = this.srcAndRefPositions[(i++)];
/* 377 */       int reference = this.srcAndRefPositions[(i++)];
/*     */       
/* 379 */       if (source >= 0) {
/* 380 */         int offset = position - source;
/* 381 */         if ((offset < 32768) || (offset > 32767))
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 391 */           int opcode = data[(reference - 1)] & 0xFF;
/* 392 */           if (opcode <= 168)
/*     */           {
/* 394 */             data[(reference - 1)] = ((byte)(opcode + 49));
/*     */           }
/*     */           else {
/* 397 */             data[(reference - 1)] = ((byte)(opcode + 20));
/*     */           }
/* 399 */           needUpdate = true;
/*     */         }
/* 401 */         data[(reference++)] = ((byte)(offset >>> 8));
/* 402 */         data[reference] = ((byte)offset);
/*     */       } else {
/* 404 */         int offset = position + source + 1;
/* 405 */         data[(reference++)] = ((byte)(offset >>> 24));
/* 406 */         data[(reference++)] = ((byte)(offset >>> 16));
/* 407 */         data[(reference++)] = ((byte)(offset >>> 8));
/* 408 */         data[reference] = ((byte)offset);
/*     */       }
/*     */     }
/* 411 */     return needUpdate;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Label getFirst()
/*     */   {
/* 423 */     return this.frame == null ? this : this.frame.owner;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean inSubroutine(long id)
/*     */   {
/* 438 */     if ((this.status & 0x400) != 0) {
/* 439 */       return (this.srcAndRefPositions[((int)(id >>> 32))] & (int)id) != 0;
/*     */     }
/* 441 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean inSameSubroutine(Label block)
/*     */   {
/* 454 */     if (((this.status & 0x400) == 0) || ((block.status & 0x400) == 0)) {
/* 455 */       return false;
/*     */     }
/* 457 */     for (int i = 0; i < this.srcAndRefPositions.length; i++) {
/* 458 */       if ((this.srcAndRefPositions[i] & block.srcAndRefPositions[i]) != 0) {
/* 459 */         return true;
/*     */       }
/*     */     }
/* 462 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void addToSubroutine(long id, int nbSubroutines)
/*     */   {
/* 474 */     if ((this.status & 0x400) == 0) {
/* 475 */       this.status |= 0x400;
/* 476 */       this.srcAndRefPositions = new int[(nbSubroutines - 1) / 32 + 1];
/*     */     }
/* 478 */     this.srcAndRefPositions[((int)(id >>> 32))] |= (int)id;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void visitSubroutine(Label JSR, long id, int nbSubroutines)
/*     */   {
/* 499 */     Label stack = this;
/* 500 */     while (stack != null)
/*     */     {
/* 502 */       Label l = stack;
/* 503 */       stack = l.next;
/* 504 */       l.next = null;
/*     */       
/* 506 */       if (JSR != null) {
/* 507 */         if ((l.status & 0x800) != 0) {
/*     */           continue;
/*     */         }
/* 510 */         l.status |= 0x800;
/*     */         
/* 512 */         if (((l.status & 0x100) != 0) && 
/* 513 */           (!l.inSameSubroutine(JSR))) {
/* 514 */           Edge e = new Edge();
/* 515 */           e.info = l.inputStackTop;
/* 516 */           e.successor = JSR.successors.successor;
/* 517 */           e.next = l.successors;
/* 518 */           l.successors = e;
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 523 */         if (l.inSubroutine(id)) {
/*     */           continue;
/*     */         }
/*     */         
/* 527 */         l.addToSubroutine(id, nbSubroutines);
/*     */       }
/*     */       
/* 530 */       Edge e = l.successors;
/* 531 */       while (e != null)
/*     */       {
/*     */ 
/*     */ 
/* 535 */         if (((l.status & 0x80) == 0) || (e != l.successors.next))
/*     */         {
/* 537 */           if (e.successor.next == null) {
/* 538 */             e.successor.next = stack;
/* 539 */             stack = e.successor;
/*     */           }
/*     */         }
/* 542 */         e = e.next;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 558 */     return "L" + System.identityHashCode(this);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\asm\Label.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */