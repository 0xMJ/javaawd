/*     */ package clojure.asm;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FieldWriter
/*     */   extends FieldVisitor
/*     */ {
/*     */   private final ClassWriter cw;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final int access;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final int name;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final int desc;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int signature;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int value;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private AnnotationWriter anns;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private AnnotationWriter ianns;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Attribute attrs;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   FieldWriter(ClassWriter cw, int access, String name, String desc, String signature, Object value)
/*     */   {
/* 110 */     super(262144);
/* 111 */     if (cw.firstField == null) {
/* 112 */       cw.firstField = this;
/*     */     } else {
/* 114 */       cw.lastField.fv = this;
/*     */     }
/* 116 */     cw.lastField = this;
/* 117 */     this.cw = cw;
/* 118 */     this.access = access;
/* 119 */     this.name = cw.newUTF8(name);
/* 120 */     this.desc = cw.newUTF8(desc);
/* 121 */     if (signature != null) {
/* 122 */       this.signature = cw.newUTF8(signature);
/*     */     }
/* 124 */     if (value != null) {
/* 125 */       this.value = cw.newConstItem(value).index;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AnnotationVisitor visitAnnotation(String desc, boolean visible)
/*     */   {
/* 139 */     ByteVector bv = new ByteVector();
/*     */     
/* 141 */     bv.putShort(this.cw.newUTF8(desc)).putShort(0);
/* 142 */     AnnotationWriter aw = new AnnotationWriter(this.cw, true, bv, bv, 2);
/* 143 */     if (visible) {
/* 144 */       aw.next = this.anns;
/* 145 */       this.anns = aw;
/*     */     } else {
/* 147 */       aw.next = this.ianns;
/* 148 */       this.ianns = aw;
/*     */     }
/* 150 */     return aw;
/*     */   }
/*     */   
/*     */   public void visitAttribute(Attribute attr)
/*     */   {
/* 155 */     attr.next = this.attrs;
/* 156 */     this.attrs = attr;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void visitEnd() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int getSize()
/*     */   {
/* 173 */     int size = 8;
/* 174 */     if (this.value != 0) {
/* 175 */       this.cw.newUTF8("ConstantValue");
/* 176 */       size += 8;
/*     */     }
/* 178 */     if (((this.access & 0x1000) != 0) && (
/* 179 */       ((this.cw.version & 0xFFFF) < 49) || ((this.access & 0x40000) != 0)))
/*     */     {
/* 181 */       this.cw.newUTF8("Synthetic");
/* 182 */       size += 6;
/*     */     }
/*     */     
/* 185 */     if ((this.access & 0x20000) != 0) {
/* 186 */       this.cw.newUTF8("Deprecated");
/* 187 */       size += 6;
/*     */     }
/* 189 */     if (this.signature != 0) {
/* 190 */       this.cw.newUTF8("Signature");
/* 191 */       size += 8;
/*     */     }
/* 193 */     if (this.anns != null) {
/* 194 */       this.cw.newUTF8("RuntimeVisibleAnnotations");
/* 195 */       size += 8 + this.anns.getSize();
/*     */     }
/* 197 */     if (this.ianns != null) {
/* 198 */       this.cw.newUTF8("RuntimeInvisibleAnnotations");
/* 199 */       size += 8 + this.ianns.getSize();
/*     */     }
/* 201 */     if (this.attrs != null) {
/* 202 */       size += this.attrs.getSize(this.cw, null, 0, -1, -1);
/*     */     }
/* 204 */     return size;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void put(ByteVector out)
/*     */   {
/* 214 */     int FACTOR = 64;
/* 215 */     int mask = 0x60000 | (this.access & 0x40000) / 64;
/*     */     
/* 217 */     out.putShort(this.access & (mask ^ 0xFFFFFFFF)).putShort(this.name).putShort(this.desc);
/* 218 */     int attributeCount = 0;
/* 219 */     if (this.value != 0) {
/* 220 */       attributeCount++;
/*     */     }
/* 222 */     if (((this.access & 0x1000) != 0) && (
/* 223 */       ((this.cw.version & 0xFFFF) < 49) || ((this.access & 0x40000) != 0)))
/*     */     {
/* 225 */       attributeCount++;
/*     */     }
/*     */     
/* 228 */     if ((this.access & 0x20000) != 0) {
/* 229 */       attributeCount++;
/*     */     }
/* 231 */     if (this.signature != 0) {
/* 232 */       attributeCount++;
/*     */     }
/* 234 */     if (this.anns != null) {
/* 235 */       attributeCount++;
/*     */     }
/* 237 */     if (this.ianns != null) {
/* 238 */       attributeCount++;
/*     */     }
/* 240 */     if (this.attrs != null) {
/* 241 */       attributeCount += this.attrs.getCount();
/*     */     }
/* 243 */     out.putShort(attributeCount);
/* 244 */     if (this.value != 0) {
/* 245 */       out.putShort(this.cw.newUTF8("ConstantValue"));
/* 246 */       out.putInt(2).putShort(this.value);
/*     */     }
/* 248 */     if (((this.access & 0x1000) != 0) && (
/* 249 */       ((this.cw.version & 0xFFFF) < 49) || ((this.access & 0x40000) != 0)))
/*     */     {
/* 251 */       out.putShort(this.cw.newUTF8("Synthetic")).putInt(0);
/*     */     }
/*     */     
/* 254 */     if ((this.access & 0x20000) != 0) {
/* 255 */       out.putShort(this.cw.newUTF8("Deprecated")).putInt(0);
/*     */     }
/* 257 */     if (this.signature != 0) {
/* 258 */       out.putShort(this.cw.newUTF8("Signature"));
/* 259 */       out.putInt(2).putShort(this.signature);
/*     */     }
/* 261 */     if (this.anns != null) {
/* 262 */       out.putShort(this.cw.newUTF8("RuntimeVisibleAnnotations"));
/* 263 */       this.anns.put(out);
/*     */     }
/* 265 */     if (this.ianns != null) {
/* 266 */       out.putShort(this.cw.newUTF8("RuntimeInvisibleAnnotations"));
/* 267 */       this.ianns.put(out);
/*     */     }
/* 269 */     if (this.attrs != null) {
/* 270 */       this.attrs.put(this.cw, null, 0, -1, -1, out);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\asm\FieldWriter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */