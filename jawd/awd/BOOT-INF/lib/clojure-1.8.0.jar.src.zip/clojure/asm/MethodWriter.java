/*      */ package clojure.asm;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class MethodWriter
/*      */   extends MethodVisitor
/*      */ {
/*      */   static final int ACC_CONSTRUCTOR = 524288;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int SAME_FRAME = 0;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int SAME_LOCALS_1_STACK_ITEM_FRAME = 64;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int RESERVED = 128;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int SAME_LOCALS_1_STACK_ITEM_FRAME_EXTENDED = 247;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int CHOP_FRAME = 248;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int SAME_FRAME_EXTENDED = 251;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int APPEND_FRAME = 252;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int FULL_FRAME = 255;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int FRAMES = 0;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int MAXS = 1;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int NOTHING = 2;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final ClassWriter cw;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int access;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final int name;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final int desc;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final String descriptor;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   String signature;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   int classReaderOffset;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   int classReaderLength;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   int exceptionCount;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   int[] exceptions;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private ByteVector annd;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private AnnotationWriter anns;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private AnnotationWriter ianns;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private AnnotationWriter[] panns;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private AnnotationWriter[] ipanns;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int synthetics;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Attribute attrs;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  219 */   private ByteVector code = new ByteVector();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int maxStack;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int maxLocals;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int currentLocals;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int frameCount;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private ByteVector stackMap;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int previousFrameOffset;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int[] previousFrame;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int[] frame;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int handlerCount;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Handler firstHandler;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Handler lastHandler;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int localVarCount;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private ByteVector localVar;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int localVarTypeCount;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private ByteVector localVarType;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int lineNumberCount;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private ByteVector lineNumber;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Attribute cattrs;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean resize;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int subroutines;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final int compute;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Label labels;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Label previousBlock;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Label currentBlock;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int stackSize;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int maxStackSize;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   MethodWriter(ClassWriter cw, int access, String name, String desc, String signature, String[] exceptions, boolean computeMaxs, boolean computeFrames)
/*      */   {
/*  419 */     super(262144);
/*  420 */     if (cw.firstMethod == null) {
/*  421 */       cw.firstMethod = this;
/*      */     } else {
/*  423 */       cw.lastMethod.mv = this;
/*      */     }
/*  425 */     cw.lastMethod = this;
/*  426 */     this.cw = cw;
/*  427 */     this.access = access;
/*  428 */     if ("<init>".equals(name)) {
/*  429 */       this.access |= 0x80000;
/*      */     }
/*  431 */     this.name = cw.newUTF8(name);
/*  432 */     this.desc = cw.newUTF8(desc);
/*  433 */     this.descriptor = desc;
/*      */     
/*  435 */     this.signature = signature;
/*      */     
/*  437 */     if ((exceptions != null) && (exceptions.length > 0)) {
/*  438 */       this.exceptionCount = exceptions.length;
/*  439 */       this.exceptions = new int[this.exceptionCount];
/*  440 */       for (int i = 0; i < this.exceptionCount; i++) {
/*  441 */         this.exceptions[i] = cw.newClass(exceptions[i]);
/*      */       }
/*      */     }
/*  444 */     this.compute = (computeMaxs ? 1 : computeFrames ? 0 : 2);
/*  445 */     if ((computeMaxs) || (computeFrames))
/*      */     {
/*  447 */       int size = Type.getArgumentsAndReturnSizes(this.descriptor) >> 2;
/*  448 */       if ((access & 0x8) != 0) {
/*  449 */         size--;
/*      */       }
/*  451 */       this.maxLocals = size;
/*  452 */       this.currentLocals = size;
/*      */       
/*  454 */       this.labels = new Label();
/*  455 */       this.labels.status |= 0x8;
/*  456 */       visitLabel(this.labels);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public AnnotationVisitor visitAnnotationDefault()
/*      */   {
/*  469 */     this.annd = new ByteVector();
/*  470 */     return new AnnotationWriter(this.cw, false, this.annd, null, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public AnnotationVisitor visitAnnotation(String desc, boolean visible)
/*      */   {
/*  479 */     ByteVector bv = new ByteVector();
/*      */     
/*  481 */     bv.putShort(this.cw.newUTF8(desc)).putShort(0);
/*  482 */     AnnotationWriter aw = new AnnotationWriter(this.cw, true, bv, bv, 2);
/*  483 */     if (visible) {
/*  484 */       aw.next = this.anns;
/*  485 */       this.anns = aw;
/*      */     } else {
/*  487 */       aw.next = this.ianns;
/*  488 */       this.ianns = aw;
/*      */     }
/*  490 */     return aw;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public AnnotationVisitor visitParameterAnnotation(int parameter, String desc, boolean visible)
/*      */   {
/*  499 */     ByteVector bv = new ByteVector();
/*  500 */     if ("Ljava/lang/Synthetic;".equals(desc))
/*      */     {
/*      */ 
/*  503 */       this.synthetics = Math.max(this.synthetics, parameter + 1);
/*  504 */       return new AnnotationWriter(this.cw, false, bv, null, 0);
/*      */     }
/*      */     
/*  507 */     bv.putShort(this.cw.newUTF8(desc)).putShort(0);
/*  508 */     AnnotationWriter aw = new AnnotationWriter(this.cw, true, bv, bv, 2);
/*  509 */     if (visible) {
/*  510 */       if (this.panns == null) {
/*  511 */         this.panns = new AnnotationWriter[Type.getArgumentTypes(this.descriptor).length];
/*      */       }
/*  513 */       aw.next = this.panns[parameter];
/*  514 */       this.panns[parameter] = aw;
/*      */     } else {
/*  516 */       if (this.ipanns == null) {
/*  517 */         this.ipanns = new AnnotationWriter[Type.getArgumentTypes(this.descriptor).length];
/*      */       }
/*  519 */       aw.next = this.ipanns[parameter];
/*  520 */       this.ipanns[parameter] = aw;
/*      */     }
/*  522 */     return aw;
/*      */   }
/*      */   
/*      */   public void visitAttribute(Attribute attr)
/*      */   {
/*  527 */     if (attr.isCodeAttribute()) {
/*  528 */       attr.next = this.cattrs;
/*  529 */       this.cattrs = attr;
/*      */     } else {
/*  531 */       attr.next = this.attrs;
/*  532 */       this.attrs = attr;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void visitCode() {}
/*      */   
/*      */ 
/*      */   public void visitFrame(int type, int nLocal, Object[] local, int nStack, Object[] stack)
/*      */   {
/*  543 */     if (this.compute == 0) {
/*  544 */       return;
/*      */     }
/*      */     
/*  547 */     if (type == -1) {
/*  548 */       if (this.previousFrame == null) {
/*  549 */         visitImplicitFirstFrame();
/*      */       }
/*  551 */       this.currentLocals = nLocal;
/*  552 */       int frameIndex = startFrame(this.code.length, nLocal, nStack);
/*  553 */       for (int i = 0; i < nLocal; i++) {
/*  554 */         if ((local[i] instanceof String)) {
/*  555 */           this.frame[(frameIndex++)] = (0x1700000 | this.cw.addType((String)local[i]));
/*      */         }
/*  557 */         else if ((local[i] instanceof Integer)) {
/*  558 */           this.frame[(frameIndex++)] = ((Integer)local[i]).intValue();
/*      */         } else {
/*  560 */           this.frame[(frameIndex++)] = (0x1800000 | this.cw.addUninitializedType("", ((Label)local[i]).position));
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*  565 */       for (int i = 0; i < nStack; i++) {
/*  566 */         if ((stack[i] instanceof String)) {
/*  567 */           this.frame[(frameIndex++)] = (0x1700000 | this.cw.addType((String)stack[i]));
/*      */         }
/*  569 */         else if ((stack[i] instanceof Integer)) {
/*  570 */           this.frame[(frameIndex++)] = ((Integer)stack[i]).intValue();
/*      */         } else {
/*  572 */           this.frame[(frameIndex++)] = (0x1800000 | this.cw.addUninitializedType("", ((Label)stack[i]).position));
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*  577 */       endFrame();
/*      */     } else { int delta;
/*      */       int delta;
/*  580 */       if (this.stackMap == null) {
/*  581 */         this.stackMap = new ByteVector();
/*  582 */         delta = this.code.length;
/*      */       } else {
/*  584 */         delta = this.code.length - this.previousFrameOffset - 1;
/*  585 */         if (delta < 0) {
/*  586 */           if (type == 3) {
/*  587 */             return;
/*      */           }
/*  589 */           throw new IllegalStateException();
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*  594 */       switch (type) {
/*      */       case 0: 
/*  596 */         this.currentLocals = nLocal;
/*  597 */         this.stackMap.putByte(255).putShort(delta).putShort(nLocal);
/*  598 */         for (int i = 0; i < nLocal; i++) {
/*  599 */           writeFrameType(local[i]);
/*      */         }
/*  601 */         this.stackMap.putShort(nStack);
/*  602 */         for (int i = 0; i < nStack; i++) {
/*  603 */           writeFrameType(stack[i]);
/*      */         }
/*  605 */         break;
/*      */       case 1: 
/*  607 */         this.currentLocals += nLocal;
/*  608 */         this.stackMap.putByte(251 + nLocal).putShort(delta);
/*  609 */         for (int i = 0; i < nLocal; i++) {
/*  610 */           writeFrameType(local[i]);
/*      */         }
/*  612 */         break;
/*      */       case 2: 
/*  614 */         this.currentLocals -= nLocal;
/*  615 */         this.stackMap.putByte(251 - nLocal).putShort(delta);
/*  616 */         break;
/*      */       case 3: 
/*  618 */         if (delta < 64) {
/*  619 */           this.stackMap.putByte(delta);
/*      */         } else {
/*  621 */           this.stackMap.putByte(251).putShort(delta);
/*      */         }
/*  623 */         break;
/*      */       case 4: 
/*  625 */         if (delta < 64) {
/*  626 */           this.stackMap.putByte(64 + delta);
/*      */         } else {
/*  628 */           this.stackMap.putByte(247).putShort(delta);
/*      */         }
/*      */         
/*  631 */         writeFrameType(stack[0]);
/*      */       }
/*      */       
/*      */       
/*  635 */       this.previousFrameOffset = this.code.length;
/*  636 */       this.frameCount += 1;
/*      */     }
/*      */     
/*  639 */     this.maxStack = Math.max(this.maxStack, nStack);
/*  640 */     this.maxLocals = Math.max(this.maxLocals, this.currentLocals);
/*      */   }
/*      */   
/*      */ 
/*      */   public void visitInsn(int opcode)
/*      */   {
/*  646 */     this.code.putByte(opcode);
/*      */     
/*      */ 
/*  649 */     if (this.currentBlock != null) {
/*  650 */       if (this.compute == 0) {
/*  651 */         this.currentBlock.frame.execute(opcode, 0, null, null);
/*      */       }
/*      */       else {
/*  654 */         int size = this.stackSize + Frame.SIZE[opcode];
/*  655 */         if (size > this.maxStackSize) {
/*  656 */           this.maxStackSize = size;
/*      */         }
/*  658 */         this.stackSize = size;
/*      */       }
/*      */       
/*  661 */       if (((opcode >= 172) && (opcode <= 177)) || (opcode == 191))
/*      */       {
/*  663 */         noSuccessor();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void visitIntInsn(int opcode, int operand)
/*      */   {
/*  671 */     if (this.currentBlock != null) {
/*  672 */       if (this.compute == 0) {
/*  673 */         this.currentBlock.frame.execute(opcode, operand, null, null);
/*  674 */       } else if (opcode != 188)
/*      */       {
/*      */ 
/*  677 */         int size = this.stackSize + 1;
/*  678 */         if (size > this.maxStackSize) {
/*  679 */           this.maxStackSize = size;
/*      */         }
/*  681 */         this.stackSize = size;
/*      */       }
/*      */     }
/*      */     
/*  685 */     if (opcode == 17) {
/*  686 */       this.code.put12(opcode, operand);
/*      */     } else {
/*  688 */       this.code.put11(opcode, operand);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void visitVarInsn(int opcode, int var)
/*      */   {
/*  695 */     if (this.currentBlock != null) {
/*  696 */       if (this.compute == 0) {
/*  697 */         this.currentBlock.frame.execute(opcode, var, null, null);
/*      */ 
/*      */       }
/*  700 */       else if (opcode == 169)
/*      */       {
/*  702 */         this.currentBlock.status |= 0x100;
/*      */         
/*      */ 
/*  705 */         this.currentBlock.inputStackTop = this.stackSize;
/*  706 */         noSuccessor();
/*      */       } else {
/*  708 */         int size = this.stackSize + Frame.SIZE[opcode];
/*  709 */         if (size > this.maxStackSize) {
/*  710 */           this.maxStackSize = size;
/*      */         }
/*  712 */         this.stackSize = size;
/*      */       }
/*      */     }
/*      */     
/*  716 */     if (this.compute != 2) {
/*      */       int n;
/*      */       int n;
/*  719 */       if ((opcode == 22) || (opcode == 24) || (opcode == 55) || (opcode == 57))
/*      */       {
/*  721 */         n = var + 2;
/*      */       } else {
/*  723 */         n = var + 1;
/*      */       }
/*  725 */       if (n > this.maxLocals) {
/*  726 */         this.maxLocals = n;
/*      */       }
/*      */     }
/*      */     
/*  730 */     if ((var < 4) && (opcode != 169)) { int opt;
/*      */       int opt;
/*  732 */       if (opcode < 54)
/*      */       {
/*  734 */         opt = 26 + (opcode - 21 << 2) + var;
/*      */       }
/*      */       else {
/*  737 */         opt = 59 + (opcode - 54 << 2) + var;
/*      */       }
/*  739 */       this.code.putByte(opt);
/*  740 */     } else if (var >= 256) {
/*  741 */       this.code.putByte(196).put12(opcode, var);
/*      */     } else {
/*  743 */       this.code.put11(opcode, var);
/*      */     }
/*  745 */     if ((opcode >= 54) && (this.compute == 0) && (this.handlerCount > 0)) {
/*  746 */       visitLabel(new Label());
/*      */     }
/*      */   }
/*      */   
/*      */   public void visitTypeInsn(int opcode, String type)
/*      */   {
/*  752 */     Item i = this.cw.newClassItem(type);
/*      */     
/*  754 */     if (this.currentBlock != null) {
/*  755 */       if (this.compute == 0) {
/*  756 */         this.currentBlock.frame.execute(opcode, this.code.length, this.cw, i);
/*  757 */       } else if (opcode == 187)
/*      */       {
/*      */ 
/*  760 */         int size = this.stackSize + 1;
/*  761 */         if (size > this.maxStackSize) {
/*  762 */           this.maxStackSize = size;
/*      */         }
/*  764 */         this.stackSize = size;
/*      */       }
/*      */     }
/*      */     
/*  768 */     this.code.put12(opcode, i.index);
/*      */   }
/*      */   
/*      */ 
/*      */   public void visitFieldInsn(int opcode, String owner, String name, String desc)
/*      */   {
/*  774 */     Item i = this.cw.newFieldItem(owner, name, desc);
/*      */     
/*  776 */     if (this.currentBlock != null) {
/*  777 */       if (this.compute == 0) {
/*  778 */         this.currentBlock.frame.execute(opcode, 0, this.cw, i);
/*      */       }
/*      */       else
/*      */       {
/*  782 */         char c = desc.charAt(0);
/*  783 */         int size; switch (opcode) {
/*      */         case 178: 
/*  785 */           size = this.stackSize + ((c == 'D') || (c == 'J') ? 2 : 1);
/*  786 */           break;
/*      */         case 179: 
/*  788 */           size = this.stackSize + ((c == 'D') || (c == 'J') ? -2 : -1);
/*  789 */           break;
/*      */         case 180: 
/*  791 */           size = this.stackSize + ((c == 'D') || (c == 'J') ? 1 : 0);
/*  792 */           break;
/*      */         
/*      */         default: 
/*  795 */           size = this.stackSize + ((c == 'D') || (c == 'J') ? -3 : -2);
/*      */         }
/*      */         
/*      */         
/*  799 */         if (size > this.maxStackSize) {
/*  800 */           this.maxStackSize = size;
/*      */         }
/*  802 */         this.stackSize = size;
/*      */       }
/*      */     }
/*      */     
/*  806 */     this.code.put12(opcode, i.index);
/*      */   }
/*      */   
/*      */ 
/*      */   public void visitMethodInsn(int opcode, String owner, String name, String desc)
/*      */   {
/*  812 */     boolean itf = opcode == 185;
/*  813 */     Item i = this.cw.newMethodItem(owner, name, desc, itf);
/*  814 */     int argSize = i.intVal;
/*      */     
/*  816 */     if (this.currentBlock != null) {
/*  817 */       if (this.compute == 0) {
/*  818 */         this.currentBlock.frame.execute(opcode, 0, this.cw, i);
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*  828 */         if (argSize == 0)
/*      */         {
/*      */ 
/*  831 */           argSize = Type.getArgumentsAndReturnSizes(desc);
/*      */           
/*      */ 
/*  834 */           i.intVal = argSize; }
/*      */         int size;
/*      */         int size;
/*  837 */         if (opcode == 184) {
/*  838 */           size = this.stackSize - (argSize >> 2) + (argSize & 0x3) + 1;
/*      */         } else {
/*  840 */           size = this.stackSize - (argSize >> 2) + (argSize & 0x3);
/*      */         }
/*      */         
/*  843 */         if (size > this.maxStackSize) {
/*  844 */           this.maxStackSize = size;
/*      */         }
/*  846 */         this.stackSize = size;
/*      */       }
/*      */     }
/*      */     
/*  850 */     if (itf) {
/*  851 */       if (argSize == 0) {
/*  852 */         argSize = Type.getArgumentsAndReturnSizes(desc);
/*  853 */         i.intVal = argSize;
/*      */       }
/*  855 */       this.code.put12(185, i.index).put11(argSize >> 2, 0);
/*      */     } else {
/*  857 */       this.code.put12(opcode, i.index);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void visitInvokeDynamicInsn(String name, String desc, Handle bsm, Object... bsmArgs)
/*      */   {
/*  864 */     Item i = this.cw.newInvokeDynamicItem(name, desc, bsm, bsmArgs);
/*  865 */     int argSize = i.intVal;
/*      */     
/*  867 */     if (this.currentBlock != null) {
/*  868 */       if (this.compute == 0) {
/*  869 */         this.currentBlock.frame.execute(186, 0, this.cw, i);
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*  879 */         if (argSize == 0)
/*      */         {
/*      */ 
/*  882 */           argSize = Type.getArgumentsAndReturnSizes(desc);
/*      */           
/*      */ 
/*  885 */           i.intVal = argSize;
/*      */         }
/*  887 */         int size = this.stackSize - (argSize >> 2) + (argSize & 0x3) + 1;
/*      */         
/*      */ 
/*  890 */         if (size > this.maxStackSize) {
/*  891 */           this.maxStackSize = size;
/*      */         }
/*  893 */         this.stackSize = size;
/*      */       }
/*      */     }
/*      */     
/*  897 */     this.code.put12(186, i.index);
/*  898 */     this.code.putShort(0);
/*      */   }
/*      */   
/*      */   public void visitJumpInsn(int opcode, Label label)
/*      */   {
/*  903 */     Label nextInsn = null;
/*      */     
/*  905 */     if (this.currentBlock != null) {
/*  906 */       if (this.compute == 0) {
/*  907 */         this.currentBlock.frame.execute(opcode, 0, null, null);
/*      */         
/*  909 */         label.getFirst().status |= 0x10;
/*      */         
/*  911 */         addSuccessor(0, label);
/*  912 */         if (opcode != 167)
/*      */         {
/*  914 */           nextInsn = new Label();
/*      */         }
/*      */       }
/*  917 */       else if (opcode == 168) {
/*  918 */         if ((label.status & 0x200) == 0) {
/*  919 */           label.status |= 0x200;
/*  920 */           this.subroutines += 1;
/*      */         }
/*  922 */         this.currentBlock.status |= 0x80;
/*  923 */         addSuccessor(this.stackSize + 1, label);
/*      */         
/*  925 */         nextInsn = new Label();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*  936 */         this.stackSize += Frame.SIZE[opcode];
/*  937 */         addSuccessor(this.stackSize, label);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  942 */     if (((label.status & 0x2) != 0) && (label.position - this.code.length < 32768))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  951 */       if (opcode == 167) {
/*  952 */         this.code.putByte(200);
/*  953 */       } else if (opcode == 168) {
/*  954 */         this.code.putByte(201);
/*      */       }
/*      */       else
/*      */       {
/*  958 */         if (nextInsn != null) {
/*  959 */           nextInsn.status |= 0x10;
/*      */         }
/*  961 */         this.code.putByte(opcode <= 166 ? (opcode + 1 ^ 0x1) - 1 : opcode ^ 0x1);
/*      */         
/*  963 */         this.code.putShort(8);
/*  964 */         this.code.putByte(200);
/*      */       }
/*  966 */       label.put(this, this.code, this.code.length - 1, true);
/*      */ 
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*      */ 
/*      */ 
/*  974 */       this.code.putByte(opcode);
/*  975 */       label.put(this, this.code, this.code.length - 1, false);
/*      */     }
/*  977 */     if (this.currentBlock != null) {
/*  978 */       if (nextInsn != null)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*  983 */         visitLabel(nextInsn);
/*      */       }
/*  985 */       if (opcode == 167) {
/*  986 */         noSuccessor();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void visitLabel(Label label)
/*      */   {
/*  994 */     this.resize |= label.resolve(this, this.code.length, this.code.data);
/*      */     
/*  996 */     if ((label.status & 0x1) != 0) {
/*  997 */       return;
/*      */     }
/*  999 */     if (this.compute == 0) {
/* 1000 */       if (this.currentBlock != null) {
/* 1001 */         if (label.position == this.currentBlock.position)
/*      */         {
/* 1003 */           this.currentBlock.status |= label.status & 0x10;
/* 1004 */           label.frame = this.currentBlock.frame;
/* 1005 */           return;
/*      */         }
/*      */         
/* 1008 */         addSuccessor(0, label);
/*      */       }
/*      */       
/* 1011 */       this.currentBlock = label;
/* 1012 */       if (label.frame == null) {
/* 1013 */         label.frame = new Frame();
/* 1014 */         label.frame.owner = label;
/*      */       }
/*      */       
/* 1017 */       if (this.previousBlock != null) {
/* 1018 */         if (label.position == this.previousBlock.position) {
/* 1019 */           this.previousBlock.status |= label.status & 0x10;
/* 1020 */           label.frame = this.previousBlock.frame;
/* 1021 */           this.currentBlock = this.previousBlock;
/* 1022 */           return;
/*      */         }
/* 1024 */         this.previousBlock.successor = label;
/*      */       }
/* 1026 */       this.previousBlock = label;
/* 1027 */     } else if (this.compute == 1) {
/* 1028 */       if (this.currentBlock != null)
/*      */       {
/* 1030 */         this.currentBlock.outputStackMax = this.maxStackSize;
/* 1031 */         addSuccessor(this.stackSize, label);
/*      */       }
/*      */       
/* 1034 */       this.currentBlock = label;
/*      */       
/* 1036 */       this.stackSize = 0;
/* 1037 */       this.maxStackSize = 0;
/*      */       
/* 1039 */       if (this.previousBlock != null) {
/* 1040 */         this.previousBlock.successor = label;
/*      */       }
/* 1042 */       this.previousBlock = label;
/*      */     }
/*      */   }
/*      */   
/*      */   public void visitLdcInsn(Object cst)
/*      */   {
/* 1048 */     Item i = this.cw.newConstItem(cst);
/*      */     
/* 1050 */     if (this.currentBlock != null) {
/* 1051 */       if (this.compute == 0) {
/* 1052 */         this.currentBlock.frame.execute(18, 0, this.cw, i);
/*      */       } else {
/*      */         int size;
/*      */         int size;
/* 1056 */         if ((i.type == 5) || (i.type == 6)) {
/* 1057 */           size = this.stackSize + 2;
/*      */         } else {
/* 1059 */           size = this.stackSize + 1;
/*      */         }
/*      */         
/* 1062 */         if (size > this.maxStackSize) {
/* 1063 */           this.maxStackSize = size;
/*      */         }
/* 1065 */         this.stackSize = size;
/*      */       }
/*      */     }
/*      */     
/* 1069 */     int index = i.index;
/* 1070 */     if ((i.type == 5) || (i.type == 6)) {
/* 1071 */       this.code.put12(20, index);
/* 1072 */     } else if (index >= 256) {
/* 1073 */       this.code.put12(19, index);
/*      */     } else {
/* 1075 */       this.code.put11(18, index);
/*      */     }
/*      */   }
/*      */   
/*      */   public void visitIincInsn(int var, int increment)
/*      */   {
/* 1081 */     if ((this.currentBlock != null) && 
/* 1082 */       (this.compute == 0)) {
/* 1083 */       this.currentBlock.frame.execute(132, var, null, null);
/*      */     }
/*      */     
/* 1086 */     if (this.compute != 2)
/*      */     {
/* 1088 */       int n = var + 1;
/* 1089 */       if (n > this.maxLocals) {
/* 1090 */         this.maxLocals = n;
/*      */       }
/*      */     }
/*      */     
/* 1094 */     if ((var > 255) || (increment > 127) || (increment < -128)) {
/* 1095 */       this.code.putByte(196).put12(132, var).putShort(increment);
/*      */     }
/*      */     else {
/* 1098 */       this.code.putByte(132).put11(var, increment);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void visitTableSwitchInsn(int min, int max, Label dflt, Label... labels)
/*      */   {
/* 1106 */     int source = this.code.length;
/* 1107 */     this.code.putByte(170);
/* 1108 */     this.code.putByteArray(null, 0, (4 - this.code.length % 4) % 4);
/* 1109 */     dflt.put(this, this.code, source, true);
/* 1110 */     this.code.putInt(min).putInt(max);
/* 1111 */     for (int i = 0; i < labels.length; i++) {
/* 1112 */       labels[i].put(this, this.code, source, true);
/*      */     }
/*      */     
/* 1115 */     visitSwitchInsn(dflt, labels);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void visitLookupSwitchInsn(Label dflt, int[] keys, Label[] labels)
/*      */   {
/* 1122 */     int source = this.code.length;
/* 1123 */     this.code.putByte(171);
/* 1124 */     this.code.putByteArray(null, 0, (4 - this.code.length % 4) % 4);
/* 1125 */     dflt.put(this, this.code, source, true);
/* 1126 */     this.code.putInt(labels.length);
/* 1127 */     for (int i = 0; i < labels.length; i++) {
/* 1128 */       this.code.putInt(keys[i]);
/* 1129 */       labels[i].put(this, this.code, source, true);
/*      */     }
/*      */     
/* 1132 */     visitSwitchInsn(dflt, labels);
/*      */   }
/*      */   
/*      */   private void visitSwitchInsn(Label dflt, Label[] labels)
/*      */   {
/* 1137 */     if (this.currentBlock != null) {
/* 1138 */       if (this.compute == 0) {
/* 1139 */         this.currentBlock.frame.execute(171, 0, null, null);
/*      */         
/* 1141 */         addSuccessor(0, dflt);
/* 1142 */         dflt.getFirst().status |= 0x10;
/* 1143 */         for (int i = 0; i < labels.length; i++) {
/* 1144 */           addSuccessor(0, labels[i]);
/* 1145 */           labels[i].getFirst().status |= 0x10;
/*      */         }
/*      */       }
/*      */       else {
/* 1149 */         this.stackSize -= 1;
/*      */         
/* 1151 */         addSuccessor(this.stackSize, dflt);
/* 1152 */         for (int i = 0; i < labels.length; i++) {
/* 1153 */           addSuccessor(this.stackSize, labels[i]);
/*      */         }
/*      */       }
/*      */       
/* 1157 */       noSuccessor();
/*      */     }
/*      */   }
/*      */   
/*      */   public void visitMultiANewArrayInsn(String desc, int dims)
/*      */   {
/* 1163 */     Item i = this.cw.newClassItem(desc);
/*      */     
/* 1165 */     if (this.currentBlock != null) {
/* 1166 */       if (this.compute == 0) {
/* 1167 */         this.currentBlock.frame.execute(197, dims, this.cw, i);
/*      */       }
/*      */       else
/*      */       {
/* 1171 */         this.stackSize += 1 - dims;
/*      */       }
/*      */     }
/*      */     
/* 1175 */     this.code.put12(197, i.index).putByte(dims);
/*      */   }
/*      */   
/*      */ 
/*      */   public void visitTryCatchBlock(Label start, Label end, Label handler, String type)
/*      */   {
/* 1181 */     this.handlerCount += 1;
/* 1182 */     Handler h = new Handler();
/* 1183 */     h.start = start;
/* 1184 */     h.end = end;
/* 1185 */     h.handler = handler;
/* 1186 */     h.desc = type;
/* 1187 */     h.type = (type != null ? this.cw.newClass(type) : 0);
/* 1188 */     if (this.lastHandler == null) {
/* 1189 */       this.firstHandler = h;
/*      */     } else {
/* 1191 */       this.lastHandler.next = h;
/*      */     }
/* 1193 */     this.lastHandler = h;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void visitLocalVariable(String name, String desc, String signature, Label start, Label end, int index)
/*      */   {
/* 1200 */     if (signature != null) {
/* 1201 */       if (this.localVarType == null) {
/* 1202 */         this.localVarType = new ByteVector();
/*      */       }
/* 1204 */       this.localVarTypeCount += 1;
/* 1205 */       this.localVarType.putShort(start.position).putShort(end.position - start.position).putShort(this.cw.newUTF8(name)).putShort(this.cw.newUTF8(signature)).putShort(index);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1210 */     if (this.localVar == null) {
/* 1211 */       this.localVar = new ByteVector();
/*      */     }
/* 1213 */     this.localVarCount += 1;
/* 1214 */     this.localVar.putShort(start.position).putShort(end.position - start.position).putShort(this.cw.newUTF8(name)).putShort(this.cw.newUTF8(desc)).putShort(index);
/*      */     
/*      */ 
/*      */ 
/* 1218 */     if (this.compute != 2)
/*      */     {
/* 1220 */       char c = desc.charAt(0);
/* 1221 */       int n = index + ((c == 'J') || (c == 'D') ? 2 : 1);
/* 1222 */       if (n > this.maxLocals) {
/* 1223 */         this.maxLocals = n;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public void visitLineNumber(int line, Label start)
/*      */   {
/* 1230 */     if (this.lineNumber == null) {
/* 1231 */       this.lineNumber = new ByteVector();
/*      */     }
/* 1233 */     this.lineNumberCount += 1;
/* 1234 */     this.lineNumber.putShort(start.position);
/* 1235 */     this.lineNumber.putShort(line);
/*      */   }
/*      */   
/*      */   public void visitMaxs(int maxStack, int maxLocals)
/*      */   {
/* 1240 */     if (this.compute == 0)
/*      */     {
/* 1242 */       Handler handler = this.firstHandler;
/* 1243 */       while (handler != null) {
/* 1244 */         Label l = handler.start.getFirst();
/* 1245 */         Label h = handler.handler.getFirst();
/* 1246 */         Label e = handler.end.getFirst();
/*      */         
/* 1248 */         String t = handler.desc == null ? "java/lang/Throwable" : handler.desc;
/*      */         
/* 1250 */         int kind = 0x1700000 | this.cw.addType(t);
/*      */         
/* 1252 */         h.status |= 0x10;
/*      */         
/* 1254 */         while (l != e)
/*      */         {
/* 1256 */           Edge b = new Edge();
/* 1257 */           b.info = kind;
/* 1258 */           b.successor = h;
/*      */           
/* 1260 */           b.next = l.successors;
/* 1261 */           l.successors = b;
/*      */           
/* 1263 */           l = l.successor;
/*      */         }
/* 1265 */         handler = handler.next;
/*      */       }
/*      */       
/*      */ 
/* 1269 */       Frame f = this.labels.frame;
/* 1270 */       Type[] args = Type.getArgumentTypes(this.descriptor);
/* 1271 */       f.initInputFrame(this.cw, this.access, args, this.maxLocals);
/* 1272 */       visitFrame(f);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1280 */       int max = 0;
/* 1281 */       Label changed = this.labels;
/* 1282 */       while (changed != null)
/*      */       {
/* 1284 */         Label l = changed;
/* 1285 */         changed = changed.next;
/* 1286 */         l.next = null;
/* 1287 */         f = l.frame;
/*      */         
/* 1289 */         if ((l.status & 0x10) != 0) {
/* 1290 */           l.status |= 0x20;
/*      */         }
/*      */         
/* 1293 */         l.status |= 0x40;
/*      */         
/* 1295 */         int blockMax = f.inputStack.length + l.outputStackMax;
/* 1296 */         if (blockMax > max) {
/* 1297 */           max = blockMax;
/*      */         }
/*      */         
/* 1300 */         Edge e = l.successors;
/* 1301 */         while (e != null) {
/* 1302 */           Label n = e.successor.getFirst();
/* 1303 */           boolean change = f.merge(this.cw, n.frame, e.info);
/* 1304 */           if ((change) && (n.next == null))
/*      */           {
/*      */ 
/* 1307 */             n.next = changed;
/* 1308 */             changed = n;
/*      */           }
/* 1310 */           e = e.next;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 1315 */       Label l = this.labels;
/* 1316 */       while (l != null) {
/* 1317 */         f = l.frame;
/* 1318 */         if ((l.status & 0x20) != 0) {
/* 1319 */           visitFrame(f);
/*      */         }
/* 1321 */         if ((l.status & 0x40) == 0)
/*      */         {
/* 1323 */           Label k = l.successor;
/* 1324 */           int start = l.position;
/* 1325 */           int end = (k == null ? this.code.length : k.position) - 1;
/*      */           
/* 1327 */           if (end >= start) {
/* 1328 */             max = Math.max(max, 1);
/*      */             
/* 1330 */             for (int i = start; i < end; i++) {
/* 1331 */               this.code.data[i] = 0;
/*      */             }
/* 1333 */             this.code.data[end] = -65;
/*      */             
/* 1335 */             int frameIndex = startFrame(start, 0, 1);
/* 1336 */             this.frame[frameIndex] = (0x1700000 | this.cw.addType("java/lang/Throwable"));
/*      */             
/* 1338 */             endFrame();
/*      */             
/*      */ 
/* 1341 */             this.firstHandler = Handler.remove(this.firstHandler, l, k);
/*      */           }
/*      */         }
/* 1344 */         l = l.successor;
/*      */       }
/*      */       
/* 1347 */       handler = this.firstHandler;
/* 1348 */       this.handlerCount = 0;
/* 1349 */       while (handler != null) {
/* 1350 */         this.handlerCount += 1;
/* 1351 */         handler = handler.next;
/*      */       }
/*      */       
/* 1354 */       this.maxStack = max;
/* 1355 */     } else if (this.compute == 1)
/*      */     {
/* 1357 */       Handler handler = this.firstHandler;
/* 1358 */       while (handler != null) {
/* 1359 */         Label l = handler.start;
/* 1360 */         Label h = handler.handler;
/* 1361 */         Label e = handler.end;
/*      */         
/* 1363 */         while (l != e)
/*      */         {
/* 1365 */           Edge b = new Edge();
/* 1366 */           b.info = Integer.MAX_VALUE;
/* 1367 */           b.successor = h;
/*      */           
/* 1369 */           if ((l.status & 0x80) == 0) {
/* 1370 */             b.next = l.successors;
/* 1371 */             l.successors = b;
/*      */ 
/*      */           }
/*      */           else
/*      */           {
/* 1376 */             b.next = l.successors.next.next;
/* 1377 */             l.successors.next.next = b;
/*      */           }
/*      */           
/* 1380 */           l = l.successor;
/*      */         }
/* 1382 */         handler = handler.next;
/*      */       }
/*      */       
/* 1385 */       if (this.subroutines > 0)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1392 */         int id = 0;
/* 1393 */         this.labels.visitSubroutine(null, 1L, this.subroutines);
/*      */         
/* 1395 */         Label l = this.labels;
/* 1396 */         while (l != null) {
/* 1397 */           if ((l.status & 0x80) != 0)
/*      */           {
/* 1399 */             Label subroutine = l.successors.next.successor;
/*      */             
/* 1401 */             if ((subroutine.status & 0x400) == 0)
/*      */             {
/* 1403 */               id++;
/* 1404 */               subroutine.visitSubroutine(null, id / 32L << 32 | 1L << id % 32, this.subroutines);
/*      */             }
/*      */           }
/*      */           
/* 1408 */           l = l.successor;
/*      */         }
/*      */         
/* 1411 */         l = this.labels;
/* 1412 */         while (l != null) {
/* 1413 */           if ((l.status & 0x80) != 0) {
/* 1414 */             Label L = this.labels;
/* 1415 */             while (L != null) {
/* 1416 */               L.status &= 0xF7FF;
/* 1417 */               L = L.successor;
/*      */             }
/*      */             
/* 1420 */             Label subroutine = l.successors.next.successor;
/* 1421 */             subroutine.visitSubroutine(l, 0L, this.subroutines);
/*      */           }
/* 1423 */           l = l.successor;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1437 */       int max = 0;
/* 1438 */       Label stack = this.labels;
/* 1439 */       while (stack != null)
/*      */       {
/* 1441 */         Label l = stack;
/* 1442 */         stack = stack.next;
/*      */         
/* 1444 */         int start = l.inputStackTop;
/* 1445 */         int blockMax = start + l.outputStackMax;
/*      */         
/* 1447 */         if (blockMax > max) {
/* 1448 */           max = blockMax;
/*      */         }
/*      */         
/* 1451 */         Edge b = l.successors;
/* 1452 */         if ((l.status & 0x80) != 0)
/*      */         {
/* 1454 */           b = b.next;
/*      */         }
/* 1456 */         while (b != null) {
/* 1457 */           l = b.successor;
/*      */           
/* 1459 */           if ((l.status & 0x8) == 0)
/*      */           {
/* 1461 */             l.inputStackTop = (b.info == Integer.MAX_VALUE ? 1 : start + b.info);
/*      */             
/*      */ 
/* 1464 */             l.status |= 0x8;
/* 1465 */             l.next = stack;
/* 1466 */             stack = l;
/*      */           }
/* 1468 */           b = b.next;
/*      */         }
/*      */       }
/* 1471 */       this.maxStack = Math.max(maxStack, max);
/*      */     } else {
/* 1473 */       this.maxStack = maxStack;
/* 1474 */       this.maxLocals = maxLocals;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void visitEnd() {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void addSuccessor(int info, Label successor)
/*      */   {
/* 1496 */     Edge b = new Edge();
/* 1497 */     b.info = info;
/* 1498 */     b.successor = successor;
/*      */     
/* 1500 */     b.next = this.currentBlock.successors;
/* 1501 */     this.currentBlock.successors = b;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void noSuccessor()
/*      */   {
/* 1509 */     if (this.compute == 0) {
/* 1510 */       Label l = new Label();
/* 1511 */       l.frame = new Frame();
/* 1512 */       l.frame.owner = l;
/* 1513 */       l.resolve(this, this.code.length, this.code.data);
/* 1514 */       this.previousBlock.successor = l;
/* 1515 */       this.previousBlock = l;
/*      */     } else {
/* 1517 */       this.currentBlock.outputStackMax = this.maxStackSize;
/*      */     }
/* 1519 */     this.currentBlock = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void visitFrame(Frame f)
/*      */   {
/* 1534 */     int nTop = 0;
/* 1535 */     int nLocal = 0;
/* 1536 */     int nStack = 0;
/* 1537 */     int[] locals = f.inputLocals;
/* 1538 */     int[] stacks = f.inputStack;
/*      */     
/*      */ 
/* 1541 */     for (int i = 0; i < locals.length; i++) {
/* 1542 */       int t = locals[i];
/* 1543 */       if (t == 16777216) {
/* 1544 */         nTop++;
/*      */       } else {
/* 1546 */         nLocal += nTop + 1;
/* 1547 */         nTop = 0;
/*      */       }
/* 1549 */       if ((t == 16777220) || (t == 16777219)) {
/* 1550 */         i++;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1555 */     for (i = 0; i < stacks.length; i++) {
/* 1556 */       int t = stacks[i];
/* 1557 */       nStack++;
/* 1558 */       if ((t == 16777220) || (t == 16777219)) {
/* 1559 */         i++;
/*      */       }
/*      */     }
/*      */     
/* 1563 */     int frameIndex = startFrame(f.owner.position, nLocal, nStack);
/* 1564 */     for (i = 0; nLocal > 0; nLocal--) {
/* 1565 */       int t = locals[i];
/* 1566 */       this.frame[(frameIndex++)] = t;
/* 1567 */       if ((t == 16777220) || (t == 16777219)) {
/* 1568 */         i++;
/*      */       }
/* 1564 */       i++;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1571 */     for (i = 0; i < stacks.length; i++) {
/* 1572 */       int t = stacks[i];
/* 1573 */       this.frame[(frameIndex++)] = t;
/* 1574 */       if ((t == 16777220) || (t == 16777219)) {
/* 1575 */         i++;
/*      */       }
/*      */     }
/* 1578 */     endFrame();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void visitImplicitFirstFrame()
/*      */   {
/* 1586 */     int frameIndex = startFrame(0, this.descriptor.length() + 1, 0);
/* 1587 */     if ((this.access & 0x8) == 0) {
/* 1588 */       if ((this.access & 0x80000) == 0) {
/* 1589 */         this.frame[(frameIndex++)] = (0x1700000 | this.cw.addType(this.cw.thisName));
/*      */       } else {
/* 1591 */         this.frame[(frameIndex++)] = 6;
/*      */       }
/*      */     }
/* 1594 */     int i = 1;
/*      */     for (;;) {
/* 1596 */       int j = i;
/* 1597 */       switch (this.descriptor.charAt(i++)) {
/*      */       case 'B': 
/*      */       case 'C': 
/*      */       case 'I': 
/*      */       case 'S': 
/*      */       case 'Z': 
/* 1603 */         this.frame[(frameIndex++)] = 1;
/* 1604 */         break;
/*      */       case 'F': 
/* 1606 */         this.frame[(frameIndex++)] = 2;
/* 1607 */         break;
/*      */       case 'J': 
/* 1609 */         this.frame[(frameIndex++)] = 4;
/* 1610 */         break;
/*      */       case 'D': 
/* 1612 */         this.frame[(frameIndex++)] = 3;
/* 1613 */         break;
/*      */       case '[': 
/* 1615 */         while (this.descriptor.charAt(i) == '[') {
/* 1616 */           i++;
/*      */         }
/* 1618 */         if (this.descriptor.charAt(i) == 'L') {
/* 1619 */           i++;
/* 1620 */           while (this.descriptor.charAt(i) != ';') {
/* 1621 */             i++;
/*      */           }
/*      */         }
/* 1624 */         this.frame[(frameIndex++)] = (0x1700000 | this.cw.addType(this.descriptor.substring(j, ++i)));
/*      */         
/* 1626 */         break;
/*      */       case 'L': 
/* 1628 */         while (this.descriptor.charAt(i) != ';') {
/* 1629 */           i++;
/*      */         }
/* 1631 */         this.frame[(frameIndex++)] = (0x1700000 | this.cw.addType(this.descriptor.substring(j + 1, i++)));
/*      */         
/* 1633 */         break;
/*      */       case 'E': case 'G': case 'H': case 'K': case 'M': case 'N': case 'O': case 'P': case 'Q': case 'R': case 'T': case 'U': case 'V': case 'W': case 'X': case 'Y': default: 
/*      */         break label409; }
/*      */     }
/*      */     label409:
/* 1638 */     this.frame[1] = (frameIndex - 3);
/* 1639 */     endFrame();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int startFrame(int offset, int nLocal, int nStack)
/*      */   {
/* 1654 */     int n = 3 + nLocal + nStack;
/* 1655 */     if ((this.frame == null) || (this.frame.length < n)) {
/* 1656 */       this.frame = new int[n];
/*      */     }
/* 1658 */     this.frame[0] = offset;
/* 1659 */     this.frame[1] = nLocal;
/* 1660 */     this.frame[2] = nStack;
/* 1661 */     return 3;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void endFrame()
/*      */   {
/* 1669 */     if (this.previousFrame != null) {
/* 1670 */       if (this.stackMap == null) {
/* 1671 */         this.stackMap = new ByteVector();
/*      */       }
/* 1673 */       writeFrame();
/* 1674 */       this.frameCount += 1;
/*      */     }
/* 1676 */     this.previousFrame = this.frame;
/* 1677 */     this.frame = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void writeFrame()
/*      */   {
/* 1685 */     int clocalsSize = this.frame[1];
/* 1686 */     int cstackSize = this.frame[2];
/* 1687 */     if ((this.cw.version & 0xFFFF) < 50) {
/* 1688 */       this.stackMap.putShort(this.frame[0]).putShort(clocalsSize);
/* 1689 */       writeFrameTypes(3, 3 + clocalsSize);
/* 1690 */       this.stackMap.putShort(cstackSize);
/* 1691 */       writeFrameTypes(3 + clocalsSize, 3 + clocalsSize + cstackSize);
/* 1692 */       return;
/*      */     }
/* 1694 */     int localsSize = this.previousFrame[1];
/* 1695 */     int type = 255;
/* 1696 */     int k = 0;
/*      */     int delta;
/* 1698 */     int delta; if (this.frameCount == 0) {
/* 1699 */       delta = this.frame[0];
/*      */     } else {
/* 1701 */       delta = this.frame[0] - this.previousFrame[0] - 1;
/*      */     }
/* 1703 */     if (cstackSize == 0) {
/* 1704 */       k = clocalsSize - localsSize;
/* 1705 */       switch (k) {
/*      */       case -3: 
/*      */       case -2: 
/*      */       case -1: 
/* 1709 */         type = 248;
/* 1710 */         localsSize = clocalsSize;
/* 1711 */         break;
/*      */       case 0: 
/* 1713 */         type = delta < 64 ? 0 : 251;
/* 1714 */         break;
/*      */       case 1: 
/*      */       case 2: 
/*      */       case 3: 
/* 1718 */         type = 252;
/*      */       }
/*      */     }
/* 1721 */     else if ((clocalsSize == localsSize) && (cstackSize == 1)) {
/* 1722 */       type = delta < 63 ? 64 : 247;
/*      */     }
/*      */     
/* 1725 */     if (type != 255)
/*      */     {
/* 1727 */       int l = 3;
/* 1728 */       for (int j = 0; j < localsSize; j++) {
/* 1729 */         if (this.frame[l] != this.previousFrame[l]) {
/* 1730 */           type = 255;
/* 1731 */           break;
/*      */         }
/* 1733 */         l++;
/*      */       }
/*      */     }
/* 1736 */     switch (type) {
/*      */     case 0: 
/* 1738 */       this.stackMap.putByte(delta);
/* 1739 */       break;
/*      */     case 64: 
/* 1741 */       this.stackMap.putByte(64 + delta);
/* 1742 */       writeFrameTypes(3 + clocalsSize, 4 + clocalsSize);
/* 1743 */       break;
/*      */     case 247: 
/* 1745 */       this.stackMap.putByte(247).putShort(delta);
/*      */       
/* 1747 */       writeFrameTypes(3 + clocalsSize, 4 + clocalsSize);
/* 1748 */       break;
/*      */     case 251: 
/* 1750 */       this.stackMap.putByte(251).putShort(delta);
/* 1751 */       break;
/*      */     case 248: 
/* 1753 */       this.stackMap.putByte(251 + k).putShort(delta);
/* 1754 */       break;
/*      */     case 252: 
/* 1756 */       this.stackMap.putByte(251 + k).putShort(delta);
/* 1757 */       writeFrameTypes(3 + localsSize, 3 + clocalsSize);
/* 1758 */       break;
/*      */     
/*      */     default: 
/* 1761 */       this.stackMap.putByte(255).putShort(delta).putShort(clocalsSize);
/* 1762 */       writeFrameTypes(3, 3 + clocalsSize);
/* 1763 */       this.stackMap.putShort(cstackSize);
/* 1764 */       writeFrameTypes(3 + clocalsSize, 3 + clocalsSize + cstackSize);
/*      */     }
/*      */     
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void writeFrameTypes(int start, int end)
/*      */   {
/* 1780 */     for (int i = start; i < end; i++) {
/* 1781 */       int t = this.frame[i];
/* 1782 */       int d = t & 0xF0000000;
/* 1783 */       if (d == 0) {
/* 1784 */         int v = t & 0xFFFFF;
/* 1785 */         switch (t & 0xFF00000) {
/*      */         case 24117248: 
/* 1787 */           this.stackMap.putByte(7).putShort(this.cw.newClass(this.cw.typeTable[v].strVal1));
/*      */           
/* 1789 */           break;
/*      */         case 25165824: 
/* 1791 */           this.stackMap.putByte(8).putShort(this.cw.typeTable[v].intVal);
/* 1792 */           break;
/*      */         default: 
/* 1794 */           this.stackMap.putByte(v);
/*      */         }
/*      */       } else {
/* 1797 */         StringBuffer buf = new StringBuffer();
/* 1798 */         d >>= 28;
/* 1799 */         while (d-- > 0) {
/* 1800 */           buf.append('[');
/*      */         }
/* 1802 */         if ((t & 0xFF00000) == 24117248) {
/* 1803 */           buf.append('L');
/* 1804 */           buf.append(this.cw.typeTable[(t & 0xFFFFF)].strVal1);
/* 1805 */           buf.append(';');
/*      */         } else {
/* 1807 */           switch (t & 0xF) {
/*      */           case 1: 
/* 1809 */             buf.append('I');
/* 1810 */             break;
/*      */           case 2: 
/* 1812 */             buf.append('F');
/* 1813 */             break;
/*      */           case 3: 
/* 1815 */             buf.append('D');
/* 1816 */             break;
/*      */           case 9: 
/* 1818 */             buf.append('Z');
/* 1819 */             break;
/*      */           case 10: 
/* 1821 */             buf.append('B');
/* 1822 */             break;
/*      */           case 11: 
/* 1824 */             buf.append('C');
/* 1825 */             break;
/*      */           case 12: 
/* 1827 */             buf.append('S');
/* 1828 */             break;
/*      */           case 4: case 5: case 6: case 7: case 8: default: 
/* 1830 */             buf.append('J');
/*      */           }
/*      */         }
/* 1833 */         this.stackMap.putByte(7).putShort(this.cw.newClass(buf.toString()));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void writeFrameType(Object type) {
/* 1839 */     if ((type instanceof String)) {
/* 1840 */       this.stackMap.putByte(7).putShort(this.cw.newClass((String)type));
/* 1841 */     } else if ((type instanceof Integer)) {
/* 1842 */       this.stackMap.putByte(((Integer)type).intValue());
/*      */     } else {
/* 1844 */       this.stackMap.putByte(8).putShort(((Label)type).position);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final int getSize()
/*      */   {
/* 1858 */     if (this.classReaderOffset != 0) {
/* 1859 */       return 6 + this.classReaderLength;
/*      */     }
/* 1861 */     if (this.resize)
/*      */     {
/*      */ 
/* 1864 */       resizeInstructions();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1869 */     int size = 8;
/* 1870 */     if (this.code.length > 0) {
/* 1871 */       if (this.code.length > 65536) {
/* 1872 */         throw new RuntimeException("Method code too large!");
/*      */       }
/* 1874 */       this.cw.newUTF8("Code");
/* 1875 */       size += 18 + this.code.length + 8 * this.handlerCount;
/* 1876 */       if (this.localVar != null) {
/* 1877 */         this.cw.newUTF8("LocalVariableTable");
/* 1878 */         size += 8 + this.localVar.length;
/*      */       }
/* 1880 */       if (this.localVarType != null) {
/* 1881 */         this.cw.newUTF8("LocalVariableTypeTable");
/* 1882 */         size += 8 + this.localVarType.length;
/*      */       }
/* 1884 */       if (this.lineNumber != null) {
/* 1885 */         this.cw.newUTF8("LineNumberTable");
/* 1886 */         size += 8 + this.lineNumber.length;
/*      */       }
/* 1888 */       if (this.stackMap != null) {
/* 1889 */         boolean zip = (this.cw.version & 0xFFFF) >= 50;
/* 1890 */         this.cw.newUTF8(zip ? "StackMapTable" : "StackMap");
/* 1891 */         size += 8 + this.stackMap.length;
/*      */       }
/* 1893 */       if (this.cattrs != null) {
/* 1894 */         size += this.cattrs.getSize(this.cw, this.code.data, this.code.length, this.maxStack, this.maxLocals);
/*      */       }
/*      */     }
/*      */     
/* 1898 */     if (this.exceptionCount > 0) {
/* 1899 */       this.cw.newUTF8("Exceptions");
/* 1900 */       size += 8 + 2 * this.exceptionCount;
/*      */     }
/* 1902 */     if (((this.access & 0x1000) != 0) && (
/* 1903 */       ((this.cw.version & 0xFFFF) < 49) || ((this.access & 0x40000) != 0)))
/*      */     {
/* 1905 */       this.cw.newUTF8("Synthetic");
/* 1906 */       size += 6;
/*      */     }
/*      */     
/* 1909 */     if ((this.access & 0x20000) != 0) {
/* 1910 */       this.cw.newUTF8("Deprecated");
/* 1911 */       size += 6;
/*      */     }
/* 1913 */     if (this.signature != null) {
/* 1914 */       this.cw.newUTF8("Signature");
/* 1915 */       this.cw.newUTF8(this.signature);
/* 1916 */       size += 8;
/*      */     }
/* 1918 */     if (this.annd != null) {
/* 1919 */       this.cw.newUTF8("AnnotationDefault");
/* 1920 */       size += 6 + this.annd.length;
/*      */     }
/* 1922 */     if (this.anns != null) {
/* 1923 */       this.cw.newUTF8("RuntimeVisibleAnnotations");
/* 1924 */       size += 8 + this.anns.getSize();
/*      */     }
/* 1926 */     if (this.ianns != null) {
/* 1927 */       this.cw.newUTF8("RuntimeInvisibleAnnotations");
/* 1928 */       size += 8 + this.ianns.getSize();
/*      */     }
/* 1930 */     if (this.panns != null) {
/* 1931 */       this.cw.newUTF8("RuntimeVisibleParameterAnnotations");
/* 1932 */       size += 7 + 2 * (this.panns.length - this.synthetics);
/* 1933 */       for (int i = this.panns.length - 1; i >= this.synthetics; i--) {
/* 1934 */         size += (this.panns[i] == null ? 0 : this.panns[i].getSize());
/*      */       }
/*      */     }
/* 1937 */     if (this.ipanns != null) {
/* 1938 */       this.cw.newUTF8("RuntimeInvisibleParameterAnnotations");
/* 1939 */       size += 7 + 2 * (this.ipanns.length - this.synthetics);
/* 1940 */       for (int i = this.ipanns.length - 1; i >= this.synthetics; i--) {
/* 1941 */         size += (this.ipanns[i] == null ? 0 : this.ipanns[i].getSize());
/*      */       }
/*      */     }
/* 1944 */     if (this.attrs != null) {
/* 1945 */       size += this.attrs.getSize(this.cw, null, 0, -1, -1);
/*      */     }
/* 1947 */     return size;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final void put(ByteVector out)
/*      */   {
/* 1958 */     int FACTOR = 64;
/* 1959 */     int mask = 0xE0000 | (this.access & 0x40000) / 64;
/*      */     
/*      */ 
/* 1962 */     out.putShort(this.access & (mask ^ 0xFFFFFFFF)).putShort(this.name).putShort(this.desc);
/* 1963 */     if (this.classReaderOffset != 0) {
/* 1964 */       out.putByteArray(this.cw.cr.b, this.classReaderOffset, this.classReaderLength);
/* 1965 */       return;
/*      */     }
/* 1967 */     int attributeCount = 0;
/* 1968 */     if (this.code.length > 0) {
/* 1969 */       attributeCount++;
/*      */     }
/* 1971 */     if (this.exceptionCount > 0) {
/* 1972 */       attributeCount++;
/*      */     }
/* 1974 */     if (((this.access & 0x1000) != 0) && (
/* 1975 */       ((this.cw.version & 0xFFFF) < 49) || ((this.access & 0x40000) != 0)))
/*      */     {
/* 1977 */       attributeCount++;
/*      */     }
/*      */     
/* 1980 */     if ((this.access & 0x20000) != 0) {
/* 1981 */       attributeCount++;
/*      */     }
/* 1983 */     if (this.signature != null) {
/* 1984 */       attributeCount++;
/*      */     }
/* 1986 */     if (this.annd != null) {
/* 1987 */       attributeCount++;
/*      */     }
/* 1989 */     if (this.anns != null) {
/* 1990 */       attributeCount++;
/*      */     }
/* 1992 */     if (this.ianns != null) {
/* 1993 */       attributeCount++;
/*      */     }
/* 1995 */     if (this.panns != null) {
/* 1996 */       attributeCount++;
/*      */     }
/* 1998 */     if (this.ipanns != null) {
/* 1999 */       attributeCount++;
/*      */     }
/* 2001 */     if (this.attrs != null) {
/* 2002 */       attributeCount += this.attrs.getCount();
/*      */     }
/* 2004 */     out.putShort(attributeCount);
/* 2005 */     if (this.code.length > 0) {
/* 2006 */       int size = 12 + this.code.length + 8 * this.handlerCount;
/* 2007 */       if (this.localVar != null) {
/* 2008 */         size += 8 + this.localVar.length;
/*      */       }
/* 2010 */       if (this.localVarType != null) {
/* 2011 */         size += 8 + this.localVarType.length;
/*      */       }
/* 2013 */       if (this.lineNumber != null) {
/* 2014 */         size += 8 + this.lineNumber.length;
/*      */       }
/* 2016 */       if (this.stackMap != null) {
/* 2017 */         size += 8 + this.stackMap.length;
/*      */       }
/* 2019 */       if (this.cattrs != null) {
/* 2020 */         size += this.cattrs.getSize(this.cw, this.code.data, this.code.length, this.maxStack, this.maxLocals);
/*      */       }
/*      */       
/* 2023 */       out.putShort(this.cw.newUTF8("Code")).putInt(size);
/* 2024 */       out.putShort(this.maxStack).putShort(this.maxLocals);
/* 2025 */       out.putInt(this.code.length).putByteArray(this.code.data, 0, this.code.length);
/* 2026 */       out.putShort(this.handlerCount);
/* 2027 */       if (this.handlerCount > 0) {
/* 2028 */         Handler h = this.firstHandler;
/* 2029 */         while (h != null) {
/* 2030 */           out.putShort(h.start.position).putShort(h.end.position).putShort(h.handler.position).putShort(h.type);
/*      */           
/* 2032 */           h = h.next;
/*      */         }
/*      */       }
/* 2035 */       attributeCount = 0;
/* 2036 */       if (this.localVar != null) {
/* 2037 */         attributeCount++;
/*      */       }
/* 2039 */       if (this.localVarType != null) {
/* 2040 */         attributeCount++;
/*      */       }
/* 2042 */       if (this.lineNumber != null) {
/* 2043 */         attributeCount++;
/*      */       }
/* 2045 */       if (this.stackMap != null) {
/* 2046 */         attributeCount++;
/*      */       }
/* 2048 */       if (this.cattrs != null) {
/* 2049 */         attributeCount += this.cattrs.getCount();
/*      */       }
/* 2051 */       out.putShort(attributeCount);
/* 2052 */       if (this.localVar != null) {
/* 2053 */         out.putShort(this.cw.newUTF8("LocalVariableTable"));
/* 2054 */         out.putInt(this.localVar.length + 2).putShort(this.localVarCount);
/* 2055 */         out.putByteArray(this.localVar.data, 0, this.localVar.length);
/*      */       }
/* 2057 */       if (this.localVarType != null) {
/* 2058 */         out.putShort(this.cw.newUTF8("LocalVariableTypeTable"));
/* 2059 */         out.putInt(this.localVarType.length + 2).putShort(this.localVarTypeCount);
/* 2060 */         out.putByteArray(this.localVarType.data, 0, this.localVarType.length);
/*      */       }
/* 2062 */       if (this.lineNumber != null) {
/* 2063 */         out.putShort(this.cw.newUTF8("LineNumberTable"));
/* 2064 */         out.putInt(this.lineNumber.length + 2).putShort(this.lineNumberCount);
/* 2065 */         out.putByteArray(this.lineNumber.data, 0, this.lineNumber.length);
/*      */       }
/* 2067 */       if (this.stackMap != null) {
/* 2068 */         boolean zip = (this.cw.version & 0xFFFF) >= 50;
/* 2069 */         out.putShort(this.cw.newUTF8(zip ? "StackMapTable" : "StackMap"));
/* 2070 */         out.putInt(this.stackMap.length + 2).putShort(this.frameCount);
/* 2071 */         out.putByteArray(this.stackMap.data, 0, this.stackMap.length);
/*      */       }
/* 2073 */       if (this.cattrs != null) {
/* 2074 */         this.cattrs.put(this.cw, this.code.data, this.code.length, this.maxLocals, this.maxStack, out);
/*      */       }
/*      */     }
/* 2077 */     if (this.exceptionCount > 0) {
/* 2078 */       out.putShort(this.cw.newUTF8("Exceptions")).putInt(2 * this.exceptionCount + 2);
/*      */       
/* 2080 */       out.putShort(this.exceptionCount);
/* 2081 */       for (int i = 0; i < this.exceptionCount; i++) {
/* 2082 */         out.putShort(this.exceptions[i]);
/*      */       }
/*      */     }
/* 2085 */     if (((this.access & 0x1000) != 0) && (
/* 2086 */       ((this.cw.version & 0xFFFF) < 49) || ((this.access & 0x40000) != 0)))
/*      */     {
/* 2088 */       out.putShort(this.cw.newUTF8("Synthetic")).putInt(0);
/*      */     }
/*      */     
/* 2091 */     if ((this.access & 0x20000) != 0) {
/* 2092 */       out.putShort(this.cw.newUTF8("Deprecated")).putInt(0);
/*      */     }
/* 2094 */     if (this.signature != null) {
/* 2095 */       out.putShort(this.cw.newUTF8("Signature")).putInt(2).putShort(this.cw.newUTF8(this.signature));
/*      */     }
/*      */     
/* 2098 */     if (this.annd != null) {
/* 2099 */       out.putShort(this.cw.newUTF8("AnnotationDefault"));
/* 2100 */       out.putInt(this.annd.length);
/* 2101 */       out.putByteArray(this.annd.data, 0, this.annd.length);
/*      */     }
/* 2103 */     if (this.anns != null) {
/* 2104 */       out.putShort(this.cw.newUTF8("RuntimeVisibleAnnotations"));
/* 2105 */       this.anns.put(out);
/*      */     }
/* 2107 */     if (this.ianns != null) {
/* 2108 */       out.putShort(this.cw.newUTF8("RuntimeInvisibleAnnotations"));
/* 2109 */       this.ianns.put(out);
/*      */     }
/* 2111 */     if (this.panns != null) {
/* 2112 */       out.putShort(this.cw.newUTF8("RuntimeVisibleParameterAnnotations"));
/* 2113 */       AnnotationWriter.put(this.panns, this.synthetics, out);
/*      */     }
/* 2115 */     if (this.ipanns != null) {
/* 2116 */       out.putShort(this.cw.newUTF8("RuntimeInvisibleParameterAnnotations"));
/* 2117 */       AnnotationWriter.put(this.ipanns, this.synthetics, out);
/*      */     }
/* 2119 */     if (this.attrs != null) {
/* 2120 */       this.attrs.put(this.cw, null, 0, -1, -1, out);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void resizeInstructions()
/*      */   {
/* 2146 */     byte[] b = this.code.data;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2174 */     int[] allIndexes = new int[0];
/* 2175 */     int[] allSizes = new int[0];
/*      */     
/*      */ 
/*      */ 
/* 2179 */     boolean[] resize = new boolean[this.code.length];
/*      */     
/*      */ 
/* 2182 */     int state = 3;
/*      */     int label;
/* 2184 */     do { if (state == 3) {
/* 2185 */         state = 2;
/*      */       }
/* 2187 */       u = 0;
/* 2188 */       while (u < b.length) {
/* 2189 */         int opcode = b[u] & 0xFF;
/* 2190 */         int insert = 0;
/*      */         int newOffset;
/* 2192 */         switch (ClassWriter.TYPE[opcode]) {
/*      */         case 0: 
/*      */         case 4: 
/* 2195 */           u++;
/* 2196 */           break;
/*      */         case 9:  int label;
/* 2198 */           if (opcode > 201)
/*      */           {
/*      */ 
/*      */ 
/* 2202 */             opcode = opcode < 218 ? opcode - 49 : opcode - 20;
/* 2203 */             label = u + readUnsignedShort(b, u + 1);
/*      */           } else {
/* 2205 */             label = u + readShort(b, u + 1);
/*      */           }
/* 2207 */           newOffset = getNewOffset(allIndexes, allSizes, u, label);
/* 2208 */           if ((newOffset < 32768) || (newOffset > 32767))
/*      */           {
/* 2210 */             if (resize[u] == 0) {
/* 2211 */               if ((opcode == 167) || (opcode == 168))
/*      */               {
/*      */ 
/*      */ 
/* 2215 */                 insert = 2;
/*      */ 
/*      */ 
/*      */               }
/*      */               else
/*      */               {
/*      */ 
/*      */ 
/* 2223 */                 insert = 5;
/*      */               }
/* 2225 */               resize[u] = true;
/*      */             }
/*      */           }
/* 2228 */           u += 3;
/* 2229 */           break;
/*      */         case 10: 
/* 2231 */           u += 5;
/* 2232 */           break;
/*      */         case 14: 
/* 2234 */           if (state == 1)
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2242 */             newOffset = getNewOffset(allIndexes, allSizes, 0, u);
/* 2243 */             insert = -(newOffset & 0x3);
/* 2244 */           } else if (resize[u] == 0)
/*      */           {
/*      */ 
/*      */ 
/* 2248 */             insert = u & 0x3;
/* 2249 */             resize[u] = true;
/*      */           }
/*      */           
/* 2252 */           u = u + 4 - (u & 0x3);
/* 2253 */           u += 4 * (readInt(b, u + 8) - readInt(b, u + 4) + 1) + 12;
/* 2254 */           break;
/*      */         case 15: 
/* 2256 */           if (state == 1)
/*      */           {
/* 2258 */             int newOffset = getNewOffset(allIndexes, allSizes, 0, u);
/* 2259 */             insert = -(newOffset & 0x3);
/* 2260 */           } else if (resize[u] == 0)
/*      */           {
/* 2262 */             insert = u & 0x3;
/* 2263 */             resize[u] = true;
/*      */           }
/*      */           
/* 2266 */           u = u + 4 - (u & 0x3);
/* 2267 */           u += 8 * readInt(b, u + 4) + 8;
/* 2268 */           break;
/*      */         case 17: 
/* 2270 */           opcode = b[(u + 1)] & 0xFF;
/* 2271 */           if (opcode == 132) {
/* 2272 */             u += 6;
/*      */           } else {
/* 2274 */             u += 4;
/*      */           }
/* 2276 */           break;
/*      */         case 1: 
/*      */         case 3: 
/*      */         case 11: 
/* 2280 */           u += 2;
/* 2281 */           break;
/*      */         case 2: 
/*      */         case 5: 
/*      */         case 6: 
/*      */         case 12: 
/*      */         case 13: 
/* 2287 */           u += 3;
/* 2288 */           break;
/*      */         case 7: 
/*      */         case 8: 
/* 2291 */           u += 5;
/* 2292 */           break;
/*      */         case 16: 
/*      */         default: 
/* 2295 */           u += 4;
/*      */         }
/*      */         
/* 2298 */         if (insert != 0)
/*      */         {
/*      */ 
/* 2301 */           int[] newIndexes = new int[allIndexes.length + 1];
/* 2302 */           int[] newSizes = new int[allSizes.length + 1];
/* 2303 */           System.arraycopy(allIndexes, 0, newIndexes, 0, allIndexes.length);
/*      */           
/* 2305 */           System.arraycopy(allSizes, 0, newSizes, 0, allSizes.length);
/* 2306 */           newIndexes[allIndexes.length] = u;
/* 2307 */           newSizes[allSizes.length] = insert;
/* 2308 */           allIndexes = newIndexes;
/* 2309 */           allSizes = newSizes;
/* 2310 */           if (insert > 0) {
/* 2311 */             state = 3;
/*      */           }
/*      */         }
/*      */       }
/* 2315 */       if (state < 3) {
/* 2316 */         state--;
/*      */       }
/* 2318 */     } while (state != 0);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2324 */     ByteVector newCode = new ByteVector(this.code.length);
/*      */     
/* 2326 */     int u = 0;
/* 2327 */     int label; int newOffset; while (u < this.code.length) {
/* 2328 */       int opcode = b[u] & 0xFF;
/* 2329 */       int v; int j; switch (ClassWriter.TYPE[opcode]) {
/*      */       case 0: 
/*      */       case 4: 
/* 2332 */         newCode.putByte(opcode);
/* 2333 */         u++;
/* 2334 */         break;
/*      */       case 9: 
/* 2336 */         if (opcode > 201)
/*      */         {
/*      */ 
/*      */ 
/* 2340 */           opcode = opcode < 218 ? opcode - 49 : opcode - 20;
/* 2341 */           label = u + readUnsignedShort(b, u + 1);
/*      */         } else {
/* 2343 */           label = u + readShort(b, u + 1);
/*      */         }
/* 2345 */         newOffset = getNewOffset(allIndexes, allSizes, u, label);
/* 2346 */         if (resize[u] != 0)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2352 */           if (opcode == 167) {
/* 2353 */             newCode.putByte(200);
/* 2354 */           } else if (opcode == 168) {
/* 2355 */             newCode.putByte(201);
/*      */           } else {
/* 2357 */             newCode.putByte(opcode <= 166 ? (opcode + 1 ^ 0x1) - 1 : opcode ^ 0x1);
/*      */             
/* 2359 */             newCode.putShort(8);
/* 2360 */             newCode.putByte(200);
/*      */             
/* 2362 */             newOffset -= 3;
/*      */           }
/* 2364 */           newCode.putInt(newOffset);
/*      */         } else {
/* 2366 */           newCode.putByte(opcode);
/* 2367 */           newCode.putShort(newOffset);
/*      */         }
/* 2369 */         u += 3;
/* 2370 */         break;
/*      */       case 10: 
/* 2372 */         label = u + readInt(b, u + 1);
/* 2373 */         newOffset = getNewOffset(allIndexes, allSizes, u, label);
/* 2374 */         newCode.putByte(opcode);
/* 2375 */         newCode.putInt(newOffset);
/* 2376 */         u += 5;
/* 2377 */         break;
/*      */       
/*      */       case 14: 
/* 2380 */         v = u;
/* 2381 */         u = u + 4 - (v & 0x3);
/*      */         
/* 2383 */         newCode.putByte(170);
/* 2384 */         newCode.putByteArray(null, 0, (4 - newCode.length % 4) % 4);
/* 2385 */         label = v + readInt(b, u);
/* 2386 */         u += 4;
/* 2387 */         newOffset = getNewOffset(allIndexes, allSizes, v, label);
/* 2388 */         newCode.putInt(newOffset);
/* 2389 */         j = readInt(b, u);
/* 2390 */         u += 4;
/* 2391 */         newCode.putInt(j);
/* 2392 */         j = readInt(b, u) - j + 1;
/* 2393 */         u += 4;
/* 2394 */         newCode.putInt(readInt(b, u - 4));
/* 2395 */       case 15: case 17: case 1: case 3: case 11: case 2: case 5: case 6: case 12: case 13: case 7: case 8: case 16: default:  while (j > 0) {
/* 2396 */           label = v + readInt(b, u);
/* 2397 */           u += 4;
/* 2398 */           newOffset = getNewOffset(allIndexes, allSizes, v, label);
/* 2399 */           newCode.putInt(newOffset);j--; continue;
/*      */           
/*      */ 
/*      */ 
/*      */ 
/* 2404 */           v = u;
/* 2405 */           u = u + 4 - (v & 0x3);
/*      */           
/* 2407 */           newCode.putByte(171);
/* 2408 */           newCode.putByteArray(null, 0, (4 - newCode.length % 4) % 4);
/* 2409 */           label = v + readInt(b, u);
/* 2410 */           u += 4;
/* 2411 */           newOffset = getNewOffset(allIndexes, allSizes, v, label);
/* 2412 */           newCode.putInt(newOffset);
/* 2413 */           j = readInt(b, u);
/* 2414 */           u += 4;
/* 2415 */           newCode.putInt(j);
/* 2416 */           while (j > 0) {
/* 2417 */             newCode.putInt(readInt(b, u));
/* 2418 */             u += 4;
/* 2419 */             label = v + readInt(b, u);
/* 2420 */             u += 4;
/* 2421 */             newOffset = getNewOffset(allIndexes, allSizes, v, label);
/* 2422 */             newCode.putInt(newOffset);j--; continue;
/*      */             
/*      */ 
/*      */ 
/* 2426 */             opcode = b[(u + 1)] & 0xFF;
/* 2427 */             if (opcode == 132) {
/* 2428 */               newCode.putByteArray(b, u, 6);
/* 2429 */               u += 6;
/*      */             } else {
/* 2431 */               newCode.putByteArray(b, u, 4);
/* 2432 */               u += 4;
/*      */               
/* 2434 */               break;
/*      */               
/*      */ 
/*      */ 
/* 2438 */               newCode.putByteArray(b, u, 2);
/* 2439 */               u += 2;
/* 2440 */               break;
/*      */               
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2446 */               newCode.putByteArray(b, u, 3);
/* 2447 */               u += 3;
/* 2448 */               break;
/*      */               
/*      */ 
/* 2451 */               newCode.putByteArray(b, u, 5);
/* 2452 */               u += 5;
/* 2453 */               break;
/*      */               
/*      */ 
/* 2456 */               newCode.putByteArray(b, u, 4);
/* 2457 */               u += 4;
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 2463 */     if (this.frameCount > 0) {
/* 2464 */       if (this.compute == 0) {
/* 2465 */         this.frameCount = 0;
/* 2466 */         this.stackMap = null;
/* 2467 */         this.previousFrame = null;
/* 2468 */         this.frame = null;
/* 2469 */         Frame f = new Frame();
/* 2470 */         f.owner = this.labels;
/* 2471 */         Type[] args = Type.getArgumentTypes(this.descriptor);
/* 2472 */         f.initInputFrame(this.cw, this.access, args, this.maxLocals);
/* 2473 */         visitFrame(f);
/* 2474 */         Label l = this.labels;
/* 2475 */         while (l != null)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/* 2480 */           u = l.position - 3;
/* 2481 */           if (((l.status & 0x20) != 0) || ((u >= 0) && (resize[u] != 0))) {
/* 2482 */             getNewOffset(allIndexes, allSizes, l);
/*      */             
/* 2484 */             visitFrame(l.frame);
/*      */           }
/* 2486 */           l = l.successor;
/*      */ 
/*      */ 
/*      */ 
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2503 */         this.cw.invalidFrames = true;
/*      */       }
/*      */     }
/*      */     
/* 2507 */     Handler h = this.firstHandler;
/* 2508 */     while (h != null) {
/* 2509 */       getNewOffset(allIndexes, allSizes, h.start);
/* 2510 */       getNewOffset(allIndexes, allSizes, h.end);
/* 2511 */       getNewOffset(allIndexes, allSizes, h.handler);
/* 2512 */       h = h.next;
/*      */     }
/*      */     
/*      */ 
/* 2516 */     for (int i = 0; i < 2; i++) {
/* 2517 */       ByteVector bv = i == 0 ? this.localVar : this.localVarType;
/* 2518 */       if (bv != null) {
/* 2519 */         b = bv.data;
/* 2520 */         u = 0;
/* 2521 */         while (u < bv.length) {
/* 2522 */           label = readUnsignedShort(b, u);
/* 2523 */           newOffset = getNewOffset(allIndexes, allSizes, 0, label);
/* 2524 */           writeShort(b, u, newOffset);
/* 2525 */           label += readUnsignedShort(b, u + 2);
/* 2526 */           newOffset = getNewOffset(allIndexes, allSizes, 0, label) - newOffset;
/*      */           
/* 2528 */           writeShort(b, u + 2, newOffset);
/* 2529 */           u += 10;
/*      */         }
/*      */       }
/*      */     }
/* 2533 */     if (this.lineNumber != null) {
/* 2534 */       b = this.lineNumber.data;
/* 2535 */       u = 0;
/* 2536 */       while (u < this.lineNumber.length) {
/* 2537 */         writeShort(b, u, getNewOffset(allIndexes, allSizes, 0, readUnsignedShort(b, u)));
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 2542 */         u += 4;
/*      */       }
/*      */     }
/*      */     
/* 2546 */     Attribute attr = this.cattrs;
/* 2547 */     while (attr != null) {
/* 2548 */       Label[] labels = attr.getLabels();
/* 2549 */       if (labels != null) {
/* 2550 */         for (i = labels.length - 1; i >= 0; i--) {
/* 2551 */           getNewOffset(allIndexes, allSizes, labels[i]);
/*      */         }
/*      */       }
/* 2554 */       attr = attr.next;
/*      */     }
/*      */     
/*      */ 
/* 2558 */     this.code = newCode;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static int readUnsignedShort(byte[] b, int index)
/*      */   {
/* 2571 */     return (b[index] & 0xFF) << 8 | b[(index + 1)] & 0xFF;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static short readShort(byte[] b, int index)
/*      */   {
/* 2584 */     return (short)((b[index] & 0xFF) << 8 | b[(index + 1)] & 0xFF);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static int readInt(byte[] b, int index)
/*      */   {
/* 2597 */     return (b[index] & 0xFF) << 24 | (b[(index + 1)] & 0xFF) << 16 | (b[(index + 2)] & 0xFF) << 8 | b[(index + 3)] & 0xFF;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static void writeShort(byte[] b, int index, int s)
/*      */   {
/* 2612 */     b[index] = ((byte)(s >>> 8));
/* 2613 */     b[(index + 1)] = ((byte)s);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static int getNewOffset(int[] indexes, int[] sizes, int begin, int end)
/*      */   {
/* 2645 */     int offset = end - begin;
/* 2646 */     for (int i = 0; i < indexes.length; i++) {
/* 2647 */       if ((begin < indexes[i]) && (indexes[i] <= end))
/*      */       {
/* 2649 */         offset += sizes[i];
/* 2650 */       } else if ((end < indexes[i]) && (indexes[i] <= begin))
/*      */       {
/* 2652 */         offset -= sizes[i];
/*      */       }
/*      */     }
/* 2655 */     return offset;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static void getNewOffset(int[] indexes, int[] sizes, Label label)
/*      */   {
/* 2680 */     if ((label.status & 0x4) == 0) {
/* 2681 */       label.position = getNewOffset(indexes, sizes, 0, label.position);
/* 2682 */       label.status |= 0x4;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\asm\MethodWriter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */