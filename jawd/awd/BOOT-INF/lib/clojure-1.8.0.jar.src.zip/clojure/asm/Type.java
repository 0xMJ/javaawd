/*     */ package clojure.asm;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Type
/*     */ {
/*     */   public static final int VOID = 0;
/*     */   public static final int BOOLEAN = 1;
/*     */   public static final int CHAR = 2;
/*     */   public static final int BYTE = 3;
/*     */   public static final int SHORT = 4;
/*     */   public static final int INT = 5;
/*     */   public static final int FLOAT = 6;
/*     */   public static final int LONG = 7;
/*     */   public static final int DOUBLE = 8;
/*     */   public static final int ARRAY = 9;
/*     */   public static final int OBJECT = 10;
/*     */   public static final int METHOD = 11;
/* 107 */   public static final Type VOID_TYPE = new Type(0, null, 1443168256, 1);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 113 */   public static final Type BOOLEAN_TYPE = new Type(1, null, 1509950721, 1);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 119 */   public static final Type CHAR_TYPE = new Type(2, null, 1124075009, 1);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 125 */   public static final Type BYTE_TYPE = new Type(3, null, 1107297537, 1);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 131 */   public static final Type SHORT_TYPE = new Type(4, null, 1392510721, 1);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 137 */   public static final Type INT_TYPE = new Type(5, null, 1224736769, 1);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 143 */   public static final Type FLOAT_TYPE = new Type(6, null, 1174536705, 1);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 149 */   public static final Type LONG_TYPE = new Type(7, null, 1241579778, 1);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 155 */   public static final Type DOUBLE_TYPE = new Type(8, null, 1141048066, 1);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final int sort;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final char[] buf;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final int off;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final int len;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Type(int sort, char[] buf, int off, int len)
/*     */   {
/* 203 */     this.sort = sort;
/* 204 */     this.buf = buf;
/* 205 */     this.off = off;
/* 206 */     this.len = len;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Type getType(String typeDescriptor)
/*     */   {
/* 217 */     return getType(typeDescriptor.toCharArray(), 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Type getObjectType(String internalName)
/*     */   {
/* 228 */     char[] buf = internalName.toCharArray();
/* 229 */     return new Type(buf[0] == '[' ? 9 : 10, buf, 0, buf.length);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Type getMethodType(String methodDescriptor)
/*     */   {
/* 241 */     return getType(methodDescriptor.toCharArray(), 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Type getMethodType(Type returnType, Type... argumentTypes)
/*     */   {
/* 257 */     return getType(getMethodDescriptor(returnType, argumentTypes));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Type getType(Class<?> c)
/*     */   {
/* 268 */     if (c.isPrimitive()) {
/* 269 */       if (c == Integer.TYPE)
/* 270 */         return INT_TYPE;
/* 271 */       if (c == Void.TYPE)
/* 272 */         return VOID_TYPE;
/* 273 */       if (c == Boolean.TYPE)
/* 274 */         return BOOLEAN_TYPE;
/* 275 */       if (c == Byte.TYPE)
/* 276 */         return BYTE_TYPE;
/* 277 */       if (c == Character.TYPE)
/* 278 */         return CHAR_TYPE;
/* 279 */       if (c == Short.TYPE)
/* 280 */         return SHORT_TYPE;
/* 281 */       if (c == Double.TYPE)
/* 282 */         return DOUBLE_TYPE;
/* 283 */       if (c == Float.TYPE) {
/* 284 */         return FLOAT_TYPE;
/*     */       }
/* 286 */       return LONG_TYPE;
/*     */     }
/*     */     
/* 289 */     return getType(getDescriptor(c));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Type getType(Constructor<?> c)
/*     */   {
/* 301 */     return getType(getConstructorDescriptor(c));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Type getType(Method m)
/*     */   {
/* 312 */     return getType(getMethodDescriptor(m));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Type[] getArgumentTypes(String methodDescriptor)
/*     */   {
/* 325 */     char[] buf = methodDescriptor.toCharArray();
/* 326 */     int off = 1;
/* 327 */     int size = 0;
/*     */     for (;;) {
/* 329 */       char car = buf[(off++)];
/* 330 */       if (car == ')')
/*     */         break;
/* 332 */       if (car == 'L') {
/* 333 */         while (buf[(off++)] != ';') {}
/*     */         
/* 335 */         size++;
/* 336 */       } else if (car != '[') {
/* 337 */         size++;
/*     */       }
/*     */     }
/* 340 */     Type[] args = new Type[size];
/* 341 */     off = 1;
/* 342 */     size = 0;
/* 343 */     while (buf[off] != ')') {
/* 344 */       args[size] = getType(buf, off);
/* 345 */       off += args[size].len + (args[size].sort == 10 ? 2 : 0);
/* 346 */       size++;
/*     */     }
/* 348 */     return args;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Type[] getArgumentTypes(Method method)
/*     */   {
/* 361 */     Class<?>[] classes = method.getParameterTypes();
/* 362 */     Type[] types = new Type[classes.length];
/* 363 */     for (int i = classes.length - 1; i >= 0; i--) {
/* 364 */       types[i] = getType(classes[i]);
/*     */     }
/* 366 */     return types;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Type getReturnType(String methodDescriptor)
/*     */   {
/* 379 */     char[] buf = methodDescriptor.toCharArray();
/* 380 */     return getType(buf, methodDescriptor.indexOf(')') + 1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Type getReturnType(Method method)
/*     */   {
/* 393 */     return getType(method.getReturnType());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int getArgumentsAndReturnSizes(String desc)
/*     */   {
/* 408 */     int n = 1;
/* 409 */     int c = 1;
/*     */     for (;;) {
/* 411 */       char car = desc.charAt(c++);
/* 412 */       if (car == ')') {
/* 413 */         car = desc.charAt(c);
/* 414 */         return n << 2 | ((car == 'D') || (car == 'J') ? 2 : car == 'V' ? 0 : 1);
/*     */       }
/* 416 */       if (car == 'L') {
/* 417 */         while (desc.charAt(c++) != ';') {}
/*     */         
/* 419 */         n++;
/* 420 */       } else if (car == '[') {
/* 421 */         while ((car = desc.charAt(c)) == '[') {
/* 422 */           c++;
/*     */         }
/* 424 */         if ((car == 'D') || (car == 'J')) {
/* 425 */           n--;
/*     */         }
/* 427 */       } else if ((car == 'D') || (car == 'J')) {
/* 428 */         n += 2;
/*     */       } else {
/* 430 */         n++;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Type getType(char[] buf, int off)
/*     */   {
/*     */     int len;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 448 */     switch (buf[off]) {
/*     */     case 'V': 
/* 450 */       return VOID_TYPE;
/*     */     case 'Z': 
/* 452 */       return BOOLEAN_TYPE;
/*     */     case 'C': 
/* 454 */       return CHAR_TYPE;
/*     */     case 'B': 
/* 456 */       return BYTE_TYPE;
/*     */     case 'S': 
/* 458 */       return SHORT_TYPE;
/*     */     case 'I': 
/* 460 */       return INT_TYPE;
/*     */     case 'F': 
/* 462 */       return FLOAT_TYPE;
/*     */     case 'J': 
/* 464 */       return LONG_TYPE;
/*     */     case 'D': 
/* 466 */       return DOUBLE_TYPE;
/*     */     case '[': 
/* 468 */       len = 1;
/* 469 */       while (buf[(off + len)] == '[') {
/* 470 */         len++;
/*     */       }
/* 472 */       if (buf[(off + len)] == 'L') {
/* 473 */         len++;
/* 474 */         while (buf[(off + len)] != ';') {
/* 475 */           len++;
/*     */         }
/*     */       }
/* 478 */       return new Type(9, buf, off, len + 1);
/*     */     case 'L': 
/* 480 */       len = 1;
/* 481 */       while (buf[(off + len)] != ';') {
/* 482 */         len++;
/*     */       }
/* 484 */       return new Type(10, buf, off + 1, len - 1);
/*     */     }
/*     */     
/* 487 */     return new Type(11, buf, off, buf.length - off);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getSort()
/*     */   {
/* 505 */     return this.sort;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getDimensions()
/*     */   {
/* 515 */     int i = 1;
/* 516 */     while (this.buf[(this.off + i)] == '[') {
/* 517 */       i++;
/*     */     }
/* 519 */     return i;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Type getElementType()
/*     */   {
/* 529 */     return getType(this.buf, this.off + getDimensions());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getClassName()
/*     */   {
/* 539 */     switch (this.sort) {
/*     */     case 0: 
/* 541 */       return "void";
/*     */     case 1: 
/* 543 */       return "boolean";
/*     */     case 2: 
/* 545 */       return "char";
/*     */     case 3: 
/* 547 */       return "byte";
/*     */     case 4: 
/* 549 */       return "short";
/*     */     case 5: 
/* 551 */       return "int";
/*     */     case 6: 
/* 553 */       return "float";
/*     */     case 7: 
/* 555 */       return "long";
/*     */     case 8: 
/* 557 */       return "double";
/*     */     case 9: 
/* 559 */       StringBuffer b = new StringBuffer(getElementType().getClassName());
/* 560 */       for (int i = getDimensions(); i > 0; i--) {
/* 561 */         b.append("[]");
/*     */       }
/* 563 */       return b.toString();
/*     */     case 10: 
/* 565 */       return new String(this.buf, this.off, this.len).replace('/', '.');
/*     */     }
/* 567 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getInternalName()
/*     */   {
/* 580 */     return new String(this.buf, this.off, this.len);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Type[] getArgumentTypes()
/*     */   {
/* 590 */     return getArgumentTypes(getDescriptor());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Type getReturnType()
/*     */   {
/* 600 */     return getReturnType(getDescriptor());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getArgumentsAndReturnSizes()
/*     */   {
/* 614 */     return getArgumentsAndReturnSizes(getDescriptor());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getDescriptor()
/*     */   {
/* 627 */     StringBuffer buf = new StringBuffer();
/* 628 */     getDescriptor(buf);
/* 629 */     return buf.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getMethodDescriptor(Type returnType, Type... argumentTypes)
/*     */   {
/* 645 */     StringBuffer buf = new StringBuffer();
/* 646 */     buf.append('(');
/* 647 */     for (int i = 0; i < argumentTypes.length; i++) {
/* 648 */       argumentTypes[i].getDescriptor(buf);
/*     */     }
/* 650 */     buf.append(')');
/* 651 */     returnType.getDescriptor(buf);
/* 652 */     return buf.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void getDescriptor(StringBuffer buf)
/*     */   {
/* 663 */     if (this.buf == null)
/*     */     {
/*     */ 
/* 666 */       buf.append((char)((this.off & 0xFF000000) >>> 24));
/* 667 */     } else if (this.sort == 10) {
/* 668 */       buf.append('L');
/* 669 */       buf.append(this.buf, this.off, this.len);
/* 670 */       buf.append(';');
/*     */     } else {
/* 672 */       buf.append(this.buf, this.off, this.len);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getInternalName(Class<?> c)
/*     */   {
/* 691 */     return c.getName().replace('.', '/');
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getDescriptor(Class<?> c)
/*     */   {
/* 702 */     StringBuffer buf = new StringBuffer();
/* 703 */     getDescriptor(buf, c);
/* 704 */     return buf.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getConstructorDescriptor(Constructor<?> c)
/*     */   {
/* 715 */     Class<?>[] parameters = c.getParameterTypes();
/* 716 */     StringBuffer buf = new StringBuffer();
/* 717 */     buf.append('(');
/* 718 */     for (int i = 0; i < parameters.length; i++) {
/* 719 */       getDescriptor(buf, parameters[i]);
/*     */     }
/* 721 */     return ")V";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getMethodDescriptor(Method m)
/*     */   {
/* 732 */     Class<?>[] parameters = m.getParameterTypes();
/* 733 */     StringBuffer buf = new StringBuffer();
/* 734 */     buf.append('(');
/* 735 */     for (int i = 0; i < parameters.length; i++) {
/* 736 */       getDescriptor(buf, parameters[i]);
/*     */     }
/* 738 */     buf.append(')');
/* 739 */     getDescriptor(buf, m.getReturnType());
/* 740 */     return buf.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void getDescriptor(StringBuffer buf, Class<?> c)
/*     */   {
/* 752 */     Class<?> d = c;
/*     */     for (;;) {
/* 754 */       if (d.isPrimitive()) { char car;
/*     */         char car;
/* 756 */         if (d == Integer.TYPE) {
/* 757 */           car = 'I'; } else { char car;
/* 758 */           if (d == Void.TYPE) {
/* 759 */             car = 'V'; } else { char car;
/* 760 */             if (d == Boolean.TYPE) {
/* 761 */               car = 'Z'; } else { char car;
/* 762 */               if (d == Byte.TYPE) {
/* 763 */                 car = 'B'; } else { char car;
/* 764 */                 if (d == Character.TYPE) {
/* 765 */                   car = 'C'; } else { char car;
/* 766 */                   if (d == Short.TYPE) {
/* 767 */                     car = 'S'; } else { char car;
/* 768 */                     if (d == Double.TYPE) {
/* 769 */                       car = 'D'; } else { char car;
/* 770 */                       if (d == Float.TYPE) {
/* 771 */                         car = 'F';
/*     */                       } else
/* 773 */                         car = 'J';
/*     */                     } } } } } } }
/* 775 */         buf.append(car);
/* 776 */         return; }
/* 777 */       if (!d.isArray()) break;
/* 778 */       buf.append('[');
/* 779 */       d = d.getComponentType();
/*     */     }
/* 781 */     buf.append('L');
/* 782 */     String name = d.getName();
/* 783 */     int len = name.length();
/* 784 */     for (int i = 0; i < len; i++) {
/* 785 */       char car = name.charAt(i);
/* 786 */       buf.append(car == '.' ? '/' : car);
/*     */     }
/* 788 */     buf.append(';');
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getSize()
/*     */   {
/* 807 */     return this.buf == null ? this.off & 0xFF : 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getOpcode(int opcode)
/*     */   {
/* 823 */     if ((opcode == 46) || (opcode == 79))
/*     */     {
/*     */ 
/* 826 */       return opcode + (this.buf == null ? (this.off & 0xFF00) >> 8 : 4);
/*     */     }
/*     */     
/*     */ 
/* 830 */     return opcode + (this.buf == null ? (this.off & 0xFF0000) >> 16 : 4);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/* 847 */     if (this == o) {
/* 848 */       return true;
/*     */     }
/* 850 */     if (!(o instanceof Type)) {
/* 851 */       return false;
/*     */     }
/* 853 */     Type t = (Type)o;
/* 854 */     if (this.sort != t.sort) {
/* 855 */       return false;
/*     */     }
/* 857 */     if (this.sort >= 9) {
/* 858 */       if (this.len != t.len) {
/* 859 */         return false;
/*     */       }
/* 861 */       int i = this.off;int j = t.off; for (int end = i + this.len; i < end; j++) {
/* 862 */         if (this.buf[i] != t.buf[j]) {
/* 863 */           return false;
/*     */         }
/* 861 */         i++;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 867 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 877 */     int hc = 13 * this.sort;
/* 878 */     if (this.sort >= 9) {
/* 879 */       int i = this.off; for (int end = i + this.len; i < end; i++) {
/* 880 */         hc = 17 * (hc + this.buf[i]);
/*     */       }
/*     */     }
/* 883 */     return hc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 893 */     return getDescriptor();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\asm\Type.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */