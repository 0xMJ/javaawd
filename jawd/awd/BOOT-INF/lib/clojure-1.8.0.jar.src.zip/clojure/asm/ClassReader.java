/*      */ package clojure.asm;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ClassReader
/*      */ {
/*      */   static final boolean SIGNATURES = true;
/*      */   static final boolean ANNOTATIONS = true;
/*      */   static final boolean FRAMES = true;
/*      */   static final boolean WRITER = true;
/*      */   static final boolean RESIZE = true;
/*      */   public static final int SKIP_CODE = 1;
/*      */   public static final int SKIP_DEBUG = 2;
/*      */   public static final int SKIP_FRAMES = 4;
/*      */   public static final int EXPAND_FRAMES = 8;
/*      */   public final byte[] b;
/*      */   private final int[] items;
/*      */   private final String[] strings;
/*      */   private final int maxStringLength;
/*      */   public final int header;
/*      */   
/*      */   public ClassReader(byte[] b)
/*      */   {
/*  153 */     this(b, 0, b.length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ClassReader(byte[] b, int off, int len)
/*      */   {
/*  167 */     this.b = b;
/*      */     
/*  169 */     if (readShort(off + 6) > 51) {
/*  170 */       throw new IllegalArgumentException();
/*      */     }
/*      */     
/*  173 */     this.items = new int[readUnsignedShort(off + 8)];
/*  174 */     int n = this.items.length;
/*  175 */     this.strings = new String[n];
/*  176 */     int max = 0;
/*  177 */     int index = off + 10;
/*  178 */     for (int i = 1; i < n; i++) {
/*  179 */       this.items[i] = (index + 1);
/*      */       int size;
/*  181 */       switch (b[index]) {
/*      */       case 3: 
/*      */       case 4: 
/*      */       case 9: 
/*      */       case 10: 
/*      */       case 11: 
/*      */       case 12: 
/*      */       case 18: 
/*  189 */         size = 5;
/*  190 */         break;
/*      */       case 5: 
/*      */       case 6: 
/*  193 */         size = 9;
/*  194 */         i++;
/*  195 */         break;
/*      */       case 1: 
/*  197 */         size = 3 + readUnsignedShort(index + 1);
/*  198 */         if (size > max) {
/*  199 */           max = size;
/*      */         }
/*      */         break;
/*      */       case 15: 
/*  203 */         size = 4;
/*  204 */         break;
/*      */       case 2: case 7: 
/*      */       case 8: case 13: 
/*      */       case 14: case 16: 
/*      */       case 17: default: 
/*  209 */         size = 3;
/*      */       }
/*      */       
/*  212 */       index += size;
/*      */     }
/*  214 */     this.maxStringLength = max;
/*      */     
/*  216 */     this.header = index;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getAccess()
/*      */   {
/*  229 */     return readUnsignedShort(this.header);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getClassName()
/*      */   {
/*  241 */     return readClass(this.header + 2, new char[this.maxStringLength]);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSuperName()
/*      */   {
/*  255 */     return readClass(this.header + 4, new char[this.maxStringLength]);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String[] getInterfaces()
/*      */   {
/*  268 */     int index = this.header + 6;
/*  269 */     int n = readUnsignedShort(index);
/*  270 */     String[] interfaces = new String[n];
/*  271 */     if (n > 0) {
/*  272 */       char[] buf = new char[this.maxStringLength];
/*  273 */       for (int i = 0; i < n; i++) {
/*  274 */         index += 2;
/*  275 */         interfaces[i] = readClass(index, buf);
/*      */       }
/*      */     }
/*  278 */     return interfaces;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void copyPool(ClassWriter classWriter)
/*      */   {
/*  289 */     char[] buf = new char[this.maxStringLength];
/*  290 */     int ll = this.items.length;
/*  291 */     Item[] items2 = new Item[ll];
/*  292 */     for (int i = 1; i < ll; i++) {
/*  293 */       int index = this.items[i];
/*  294 */       int tag = this.b[(index - 1)];
/*  295 */       Item item = new Item(i);
/*      */       int nameType;
/*  297 */       switch (tag) {
/*      */       case 9: 
/*      */       case 10: 
/*      */       case 11: 
/*  301 */         nameType = this.items[readUnsignedShort(index + 2)];
/*  302 */         item.set(tag, readClass(index, buf), readUTF8(nameType, buf), readUTF8(nameType + 2, buf));
/*      */         
/*  304 */         break;
/*      */       case 3: 
/*  306 */         item.set(readInt(index));
/*  307 */         break;
/*      */       case 4: 
/*  309 */         item.set(Float.intBitsToFloat(readInt(index)));
/*  310 */         break;
/*      */       case 12: 
/*  312 */         item.set(tag, readUTF8(index, buf), readUTF8(index + 2, buf), null);
/*      */         
/*  314 */         break;
/*      */       case 5: 
/*  316 */         item.set(readLong(index));
/*  317 */         i++;
/*  318 */         break;
/*      */       case 6: 
/*  320 */         item.set(Double.longBitsToDouble(readLong(index)));
/*  321 */         i++;
/*  322 */         break;
/*      */       case 1: 
/*  324 */         String s = this.strings[i];
/*  325 */         if (s == null) {
/*  326 */           index = this.items[i];
/*  327 */           s = this.strings[i] = readUTF(index + 2, readUnsignedShort(index), buf);
/*      */         }
/*      */         
/*  330 */         item.set(tag, s, null, null);
/*  331 */         break;
/*      */       
/*      */       case 15: 
/*  334 */         int fieldOrMethodRef = this.items[readUnsignedShort(index + 1)];
/*  335 */         nameType = this.items[readUnsignedShort(fieldOrMethodRef + 2)];
/*  336 */         item.set(20 + readByte(index), readClass(fieldOrMethodRef, buf), readUTF8(nameType, buf), readUTF8(nameType + 2, buf));
/*      */         
/*      */ 
/*  339 */         break;
/*      */       
/*      */       case 18: 
/*  342 */         if (classWriter.bootstrapMethods == null) {
/*  343 */           copyBootstrapMethods(classWriter, items2, buf);
/*      */         }
/*  345 */         nameType = this.items[readUnsignedShort(index + 2)];
/*  346 */         item.set(readUTF8(nameType, buf), readUTF8(nameType + 2, buf), readUnsignedShort(index));
/*      */         
/*  348 */         break;
/*      */       case 2: case 7: 
/*      */       case 8: case 13: 
/*      */       case 14: case 16: 
/*      */       case 17: default: 
/*  353 */         item.set(tag, readUTF8(index, buf), null, null);
/*      */       }
/*      */       
/*      */       
/*  357 */       int index2 = item.hashCode % items2.length;
/*  358 */       item.next = items2[index2];
/*  359 */       items2[index2] = item;
/*      */     }
/*      */     
/*  362 */     int off = this.items[1] - 1;
/*  363 */     classWriter.pool.putByteArray(this.b, off, this.header - off);
/*  364 */     classWriter.items = items2;
/*  365 */     classWriter.threshold = ((int)(0.75D * ll));
/*  366 */     classWriter.index = ll;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void copyBootstrapMethods(ClassWriter classWriter, Item[] items, char[] c)
/*      */   {
/*  379 */     int u = getAttributes();
/*  380 */     boolean found = false;
/*  381 */     for (int i = readUnsignedShort(u); i > 0; i--) {
/*  382 */       String attrName = readUTF8(u + 2, c);
/*  383 */       if ("BootstrapMethods".equals(attrName)) {
/*  384 */         found = true;
/*  385 */         break;
/*      */       }
/*  387 */       u += 6 + readInt(u + 4);
/*      */     }
/*  389 */     if (!found) {
/*  390 */       return;
/*      */     }
/*      */     
/*  393 */     int boostrapMethodCount = readUnsignedShort(u + 8);
/*  394 */     int j = 0; for (int v = u + 10; j < boostrapMethodCount; j++) {
/*  395 */       int position = v - u - 10;
/*  396 */       int hashCode = readConst(readUnsignedShort(v), c).hashCode();
/*  397 */       for (int k = readUnsignedShort(v + 2); k > 0; k--) {
/*  398 */         hashCode ^= readConst(readUnsignedShort(v + 4), c).hashCode();
/*  399 */         v += 2;
/*      */       }
/*  401 */       v += 4;
/*  402 */       Item item = new Item(j);
/*  403 */       item.set(position, hashCode & 0x7FFFFFFF);
/*  404 */       int index = item.hashCode % items.length;
/*  405 */       item.next = items[index];
/*  406 */       items[index] = item;
/*      */     }
/*  408 */     int attrSize = readInt(u + 4);
/*  409 */     ByteVector bootstrapMethods = new ByteVector(attrSize + 62);
/*  410 */     bootstrapMethods.putByteArray(this.b, u + 10, attrSize - 2);
/*  411 */     classWriter.bootstrapMethodsCount = boostrapMethodCount;
/*  412 */     classWriter.bootstrapMethods = bootstrapMethods;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ClassReader(InputStream is)
/*      */     throws IOException
/*      */   {
/*  424 */     this(readClass(is, false));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ClassReader(String name)
/*      */     throws IOException
/*      */   {
/*  436 */     this(readClass(ClassLoader.getSystemResourceAsStream(name.replace('.', '/') + ".class"), true));
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   private static byte[] readClass(InputStream is, boolean close)
/*      */     throws IOException
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: ifnonnull +13 -> 14
/*      */     //   4: new 59	java/io/IOException
/*      */     //   7: dup
/*      */     //   8: ldc 60
/*      */     //   10: invokespecial 61	java/io/IOException:<init>	(Ljava/lang/String;)V
/*      */     //   13: athrow
/*      */     //   14: aload_0
/*      */     //   15: invokevirtual 62	java/io/InputStream:available	()I
/*      */     //   18: newarray <illegal type>
/*      */     //   20: astore_2
/*      */     //   21: iconst_0
/*      */     //   22: istore_3
/*      */     //   23: aload_0
/*      */     //   24: aload_2
/*      */     //   25: iload_3
/*      */     //   26: aload_2
/*      */     //   27: arraylength
/*      */     //   28: iload_3
/*      */     //   29: isub
/*      */     //   30: invokevirtual 63	java/io/InputStream:read	([BII)I
/*      */     //   33: istore 4
/*      */     //   35: iload 4
/*      */     //   37: iconst_m1
/*      */     //   38: if_icmpne +40 -> 78
/*      */     //   41: iload_3
/*      */     //   42: aload_2
/*      */     //   43: arraylength
/*      */     //   44: if_icmpge +20 -> 64
/*      */     //   47: iload_3
/*      */     //   48: newarray <illegal type>
/*      */     //   50: astore 5
/*      */     //   52: aload_2
/*      */     //   53: iconst_0
/*      */     //   54: aload 5
/*      */     //   56: iconst_0
/*      */     //   57: iload_3
/*      */     //   58: invokestatic 64	java/lang/System:arraycopy	(Ljava/lang/Object;ILjava/lang/Object;II)V
/*      */     //   61: aload 5
/*      */     //   63: astore_2
/*      */     //   64: aload_2
/*      */     //   65: astore 5
/*      */     //   67: iload_1
/*      */     //   68: ifeq +7 -> 75
/*      */     //   71: aload_0
/*      */     //   72: invokevirtual 65	java/io/InputStream:close	()V
/*      */     //   75: aload 5
/*      */     //   77: areturn
/*      */     //   78: iload_3
/*      */     //   79: iload 4
/*      */     //   81: iadd
/*      */     //   82: istore_3
/*      */     //   83: iload_3
/*      */     //   84: aload_2
/*      */     //   85: arraylength
/*      */     //   86: if_icmpne +60 -> 146
/*      */     //   89: aload_0
/*      */     //   90: invokevirtual 66	java/io/InputStream:read	()I
/*      */     //   93: istore 5
/*      */     //   95: iload 5
/*      */     //   97: ifge +17 -> 114
/*      */     //   100: aload_2
/*      */     //   101: astore 6
/*      */     //   103: iload_1
/*      */     //   104: ifeq +7 -> 111
/*      */     //   107: aload_0
/*      */     //   108: invokevirtual 65	java/io/InputStream:close	()V
/*      */     //   111: aload 6
/*      */     //   113: areturn
/*      */     //   114: aload_2
/*      */     //   115: arraylength
/*      */     //   116: sipush 1000
/*      */     //   119: iadd
/*      */     //   120: newarray <illegal type>
/*      */     //   122: astore 6
/*      */     //   124: aload_2
/*      */     //   125: iconst_0
/*      */     //   126: aload 6
/*      */     //   128: iconst_0
/*      */     //   129: iload_3
/*      */     //   130: invokestatic 64	java/lang/System:arraycopy	(Ljava/lang/Object;ILjava/lang/Object;II)V
/*      */     //   133: aload 6
/*      */     //   135: iload_3
/*      */     //   136: iinc 3 1
/*      */     //   139: iload 5
/*      */     //   141: i2b
/*      */     //   142: bastore
/*      */     //   143: aload 6
/*      */     //   145: astore_2
/*      */     //   146: goto -123 -> 23
/*      */     //   149: astore 7
/*      */     //   151: iload_1
/*      */     //   152: ifeq +7 -> 159
/*      */     //   155: aload_0
/*      */     //   156: invokevirtual 65	java/io/InputStream:close	()V
/*      */     //   159: aload 7
/*      */     //   161: athrow
/*      */     // Line number table:
/*      */     //   Java source line #454	-> byte code offset #0
/*      */     //   Java source line #455	-> byte code offset #4
/*      */     //   Java source line #458	-> byte code offset #14
/*      */     //   Java source line #459	-> byte code offset #21
/*      */     //   Java source line #461	-> byte code offset #23
/*      */     //   Java source line #462	-> byte code offset #35
/*      */     //   Java source line #463	-> byte code offset #41
/*      */     //   Java source line #464	-> byte code offset #47
/*      */     //   Java source line #465	-> byte code offset #52
/*      */     //   Java source line #466	-> byte code offset #61
/*      */     //   Java source line #468	-> byte code offset #64
/*      */     //   Java source line #483	-> byte code offset #67
/*      */     //   Java source line #484	-> byte code offset #71
/*      */     //   Java source line #470	-> byte code offset #78
/*      */     //   Java source line #471	-> byte code offset #83
/*      */     //   Java source line #472	-> byte code offset #89
/*      */     //   Java source line #473	-> byte code offset #95
/*      */     //   Java source line #474	-> byte code offset #100
/*      */     //   Java source line #483	-> byte code offset #103
/*      */     //   Java source line #484	-> byte code offset #107
/*      */     //   Java source line #476	-> byte code offset #114
/*      */     //   Java source line #477	-> byte code offset #124
/*      */     //   Java source line #478	-> byte code offset #133
/*      */     //   Java source line #479	-> byte code offset #143
/*      */     //   Java source line #481	-> byte code offset #146
/*      */     //   Java source line #483	-> byte code offset #149
/*      */     //   Java source line #484	-> byte code offset #155
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	162	0	is	InputStream
/*      */     //   0	162	1	close	boolean
/*      */     //   20	126	2	b	byte[]
/*      */     //   22	114	3	len	int
/*      */     //   33	47	4	n	int
/*      */     //   50	26	5	c	byte[]
/*      */     //   93	47	5	last	int
/*      */     //   101	11	6	arrayOfByte1	byte[]
/*      */     //   122	22	6	c	byte[]
/*      */     //   149	11	7	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   14	67	149	finally
/*      */     //   78	103	149	finally
/*      */     //   114	151	149	finally
/*      */   }
/*      */   
/*      */   public void accept(ClassVisitor classVisitor, int flags)
/*      */   {
/*  506 */     accept(classVisitor, new Attribute[0], flags);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void accept(ClassVisitor classVisitor, Attribute[] attrs, int flags)
/*      */   {
/*  532 */     int u = this.header;
/*  533 */     char[] c = new char[this.maxStringLength];
/*      */     
/*  535 */     Context context = new Context();
/*  536 */     context.attrs = attrs;
/*  537 */     context.flags = flags;
/*  538 */     context.buffer = c;
/*      */     
/*      */ 
/*  541 */     int access = readUnsignedShort(u);
/*  542 */     String name = readClass(u + 2, c);
/*  543 */     String superClass = readClass(u + 4, c);
/*  544 */     String[] interfaces = new String[readUnsignedShort(u + 6)];
/*  545 */     u += 8;
/*  546 */     for (int i = 0; i < interfaces.length; i++) {
/*  547 */       interfaces[i] = readClass(u, c);
/*  548 */       u += 2;
/*      */     }
/*      */     
/*      */ 
/*  552 */     String signature = null;
/*  553 */     String sourceFile = null;
/*  554 */     String sourceDebug = null;
/*  555 */     String enclosingOwner = null;
/*  556 */     String enclosingName = null;
/*  557 */     String enclosingDesc = null;
/*  558 */     int anns = 0;
/*  559 */     int ianns = 0;
/*  560 */     int innerClasses = 0;
/*  561 */     Attribute attributes = null;
/*      */     
/*  563 */     u = getAttributes();
/*  564 */     for (int i = readUnsignedShort(u); i > 0; i--) {
/*  565 */       String attrName = readUTF8(u + 2, c);
/*      */       
/*      */ 
/*  568 */       if ("SourceFile".equals(attrName)) {
/*  569 */         sourceFile = readUTF8(u + 8, c);
/*  570 */       } else if ("InnerClasses".equals(attrName)) {
/*  571 */         innerClasses = u + 8;
/*  572 */       } else if ("EnclosingMethod".equals(attrName)) {
/*  573 */         enclosingOwner = readClass(u + 8, c);
/*  574 */         int item = readUnsignedShort(u + 10);
/*  575 */         if (item != 0) {
/*  576 */           enclosingName = readUTF8(this.items[item], c);
/*  577 */           enclosingDesc = readUTF8(this.items[item] + 2, c);
/*      */         }
/*  579 */       } else if ("Signature".equals(attrName)) {
/*  580 */         signature = readUTF8(u + 8, c);
/*  581 */       } else if ("RuntimeVisibleAnnotations".equals(attrName))
/*      */       {
/*  583 */         anns = u + 8;
/*  584 */       } else if ("Deprecated".equals(attrName)) {
/*  585 */         access |= 0x20000;
/*  586 */       } else if ("Synthetic".equals(attrName)) {
/*  587 */         access |= 0x41000;
/*      */       }
/*  589 */       else if ("SourceDebugExtension".equals(attrName)) {
/*  590 */         int len = readInt(u + 4);
/*  591 */         sourceDebug = readUTF(u + 8, len, new char[len]);
/*  592 */       } else if ("RuntimeInvisibleAnnotations".equals(attrName))
/*      */       {
/*  594 */         ianns = u + 8;
/*  595 */       } else if ("BootstrapMethods".equals(attrName)) {
/*  596 */         int[] bootstrapMethods = new int[readUnsignedShort(u + 8)];
/*  597 */         int j = 0; for (int v = u + 10; j < bootstrapMethods.length; j++) {
/*  598 */           bootstrapMethods[j] = v;
/*  599 */           v += (2 + readUnsignedShort(v + 2) << 1);
/*      */         }
/*  601 */         context.bootstrapMethods = bootstrapMethods;
/*      */       } else {
/*  603 */         Attribute attr = readAttribute(attrs, attrName, u + 8, readInt(u + 4), c, -1, null);
/*      */         
/*  605 */         if (attr != null) {
/*  606 */           attr.next = attributes;
/*  607 */           attributes = attr;
/*      */         }
/*      */       }
/*  610 */       u += 6 + readInt(u + 4);
/*      */     }
/*      */     
/*      */ 
/*  614 */     classVisitor.visit(readInt(this.items[1] - 7), access, name, signature, superClass, interfaces);
/*      */     
/*      */ 
/*      */ 
/*  618 */     if (((flags & 0x2) == 0) && ((sourceFile != null) || (sourceDebug != null)))
/*      */     {
/*  620 */       classVisitor.visitSource(sourceFile, sourceDebug);
/*      */     }
/*      */     
/*      */ 
/*  624 */     if (enclosingOwner != null) {
/*  625 */       classVisitor.visitOuterClass(enclosingOwner, enclosingName, enclosingDesc);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  630 */     if (anns != 0) {
/*  631 */       int i = readUnsignedShort(anns); for (int v = anns + 2; i > 0; i--) {
/*  632 */         v = readAnnotationValues(v + 2, c, true, classVisitor.visitAnnotation(readUTF8(v, c), true));
/*      */       }
/*      */     }
/*      */     
/*  636 */     if (ianns != 0) {
/*  637 */       int i = readUnsignedShort(ianns); for (int v = ianns + 2; i > 0; i--) {
/*  638 */         v = readAnnotationValues(v + 2, c, true, classVisitor.visitAnnotation(readUTF8(v, c), false));
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  644 */     while (attributes != null) {
/*  645 */       Attribute attr = attributes.next;
/*  646 */       attributes.next = null;
/*  647 */       classVisitor.visitAttribute(attributes);
/*  648 */       attributes = attr;
/*      */     }
/*      */     
/*      */ 
/*  652 */     if (innerClasses != 0) {
/*  653 */       int v = innerClasses + 2;
/*  654 */       for (int i = readUnsignedShort(innerClasses); i > 0; i--) {
/*  655 */         classVisitor.visitInnerClass(readClass(v, c), readClass(v + 2, c), readUTF8(v + 4, c), readUnsignedShort(v + 6));
/*      */         
/*      */ 
/*  658 */         v += 8;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  663 */     u = this.header + 10 + 2 * interfaces.length;
/*  664 */     for (int i = readUnsignedShort(u - 2); i > 0; i--) {
/*  665 */       u = readField(classVisitor, context, u);
/*      */     }
/*  667 */     u += 2;
/*  668 */     for (int i = readUnsignedShort(u - 2); i > 0; i--) {
/*  669 */       u = readMethod(classVisitor, context, u);
/*      */     }
/*      */     
/*      */ 
/*  673 */     classVisitor.visitEnd();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int readField(ClassVisitor classVisitor, Context context, int u)
/*      */   {
/*  690 */     char[] c = context.buffer;
/*  691 */     int access = readUnsignedShort(u);
/*  692 */     String name = readUTF8(u + 2, c);
/*  693 */     String desc = readUTF8(u + 4, c);
/*  694 */     u += 6;
/*      */     
/*      */ 
/*  697 */     String signature = null;
/*  698 */     int anns = 0;
/*  699 */     int ianns = 0;
/*  700 */     Object value = null;
/*  701 */     Attribute attributes = null;
/*      */     
/*  703 */     for (int i = readUnsignedShort(u); i > 0; i--) {
/*  704 */       String attrName = readUTF8(u + 2, c);
/*      */       
/*      */ 
/*  707 */       if ("ConstantValue".equals(attrName)) {
/*  708 */         int item = readUnsignedShort(u + 8);
/*  709 */         value = item == 0 ? null : readConst(item, c);
/*  710 */       } else if ("Signature".equals(attrName)) {
/*  711 */         signature = readUTF8(u + 8, c);
/*  712 */       } else if ("Deprecated".equals(attrName)) {
/*  713 */         access |= 0x20000;
/*  714 */       } else if ("Synthetic".equals(attrName)) {
/*  715 */         access |= 0x41000;
/*      */       }
/*  717 */       else if ("RuntimeVisibleAnnotations".equals(attrName))
/*      */       {
/*  719 */         anns = u + 8;
/*  720 */       } else if ("RuntimeInvisibleAnnotations".equals(attrName))
/*      */       {
/*  722 */         ianns = u + 8;
/*      */       } else {
/*  724 */         Attribute attr = readAttribute(context.attrs, attrName, u + 8, readInt(u + 4), c, -1, null);
/*      */         
/*  726 */         if (attr != null) {
/*  727 */           attr.next = attributes;
/*  728 */           attributes = attr;
/*      */         }
/*      */       }
/*  731 */       u += 6 + readInt(u + 4);
/*      */     }
/*  733 */     u += 2;
/*      */     
/*      */ 
/*  736 */     FieldVisitor fv = classVisitor.visitField(access, name, desc, signature, value);
/*      */     
/*  738 */     if (fv == null) {
/*  739 */       return u;
/*      */     }
/*      */     
/*      */ 
/*  743 */     if (anns != 0) {
/*  744 */       int i = readUnsignedShort(anns); for (int v = anns + 2; i > 0; i--) {
/*  745 */         v = readAnnotationValues(v + 2, c, true, fv.visitAnnotation(readUTF8(v, c), true));
/*      */       }
/*      */     }
/*      */     
/*  749 */     if (ianns != 0) {
/*  750 */       int i = readUnsignedShort(ianns); for (int v = ianns + 2; i > 0; i--) {
/*  751 */         v = readAnnotationValues(v + 2, c, true, fv.visitAnnotation(readUTF8(v, c), false));
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  757 */     while (attributes != null) {
/*  758 */       Attribute attr = attributes.next;
/*  759 */       attributes.next = null;
/*  760 */       fv.visitAttribute(attributes);
/*  761 */       attributes = attr;
/*      */     }
/*      */     
/*      */ 
/*  765 */     fv.visitEnd();
/*      */     
/*  767 */     return u;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int readMethod(ClassVisitor classVisitor, Context context, int u)
/*      */   {
/*  784 */     char[] c = context.buffer;
/*  785 */     int access = readUnsignedShort(u);
/*  786 */     String name = readUTF8(u + 2, c);
/*  787 */     String desc = readUTF8(u + 4, c);
/*  788 */     u += 6;
/*      */     
/*      */ 
/*  791 */     int code = 0;
/*  792 */     int exception = 0;
/*  793 */     String[] exceptions = null;
/*  794 */     String signature = null;
/*  795 */     int anns = 0;
/*  796 */     int ianns = 0;
/*  797 */     int dann = 0;
/*  798 */     int mpanns = 0;
/*  799 */     int impanns = 0;
/*  800 */     int firstAttribute = u;
/*  801 */     Attribute attributes = null;
/*      */     
/*  803 */     for (int i = readUnsignedShort(u); i > 0; i--) {
/*  804 */       String attrName = readUTF8(u + 2, c);
/*      */       
/*      */ 
/*  807 */       if ("Code".equals(attrName)) {
/*  808 */         if ((context.flags & 0x1) == 0) {
/*  809 */           code = u + 8;
/*      */         }
/*  811 */       } else if ("Exceptions".equals(attrName)) {
/*  812 */         exceptions = new String[readUnsignedShort(u + 8)];
/*  813 */         exception = u + 10;
/*  814 */         for (int j = 0; j < exceptions.length; j++) {
/*  815 */           exceptions[j] = readClass(exception, c);
/*  816 */           exception += 2;
/*      */         }
/*  818 */       } else if ("Signature".equals(attrName)) {
/*  819 */         signature = readUTF8(u + 8, c);
/*  820 */       } else if ("Deprecated".equals(attrName)) {
/*  821 */         access |= 0x20000;
/*  822 */       } else if ("RuntimeVisibleAnnotations".equals(attrName))
/*      */       {
/*  824 */         anns = u + 8;
/*  825 */       } else if ("AnnotationDefault".equals(attrName)) {
/*  826 */         dann = u + 8;
/*  827 */       } else if ("Synthetic".equals(attrName)) {
/*  828 */         access |= 0x41000;
/*      */       }
/*  830 */       else if ("RuntimeInvisibleAnnotations".equals(attrName))
/*      */       {
/*  832 */         ianns = u + 8;
/*  833 */       } else if ("RuntimeVisibleParameterAnnotations".equals(attrName))
/*      */       {
/*  835 */         mpanns = u + 8;
/*  836 */       } else if ("RuntimeInvisibleParameterAnnotations".equals(attrName))
/*      */       {
/*  838 */         impanns = u + 8;
/*      */       } else {
/*  840 */         Attribute attr = readAttribute(context.attrs, attrName, u + 8, readInt(u + 4), c, -1, null);
/*      */         
/*  842 */         if (attr != null) {
/*  843 */           attr.next = attributes;
/*  844 */           attributes = attr;
/*      */         }
/*      */       }
/*  847 */       u += 6 + readInt(u + 4);
/*      */     }
/*  849 */     u += 2;
/*      */     
/*      */ 
/*  852 */     MethodVisitor mv = classVisitor.visitMethod(access, name, desc, signature, exceptions);
/*      */     
/*  854 */     if (mv == null) {
/*  855 */       return u;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  868 */     if ((mv instanceof MethodWriter)) {
/*  869 */       MethodWriter mw = (MethodWriter)mv;
/*  870 */       if ((mw.cw.cr == this) && (signature == mw.signature)) {
/*  871 */         boolean sameExceptions = false;
/*  872 */         if (exceptions == null) {
/*  873 */           sameExceptions = mw.exceptionCount == 0;
/*  874 */         } else if (exceptions.length == mw.exceptionCount) {
/*  875 */           sameExceptions = true;
/*  876 */           for (int j = exceptions.length - 1; j >= 0; j--) {
/*  877 */             exception -= 2;
/*  878 */             if (mw.exceptions[j] != readUnsignedShort(exception)) {
/*  879 */               sameExceptions = false;
/*  880 */               break;
/*      */             }
/*      */           }
/*      */         }
/*  884 */         if (sameExceptions)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  890 */           mw.classReaderOffset = firstAttribute;
/*  891 */           mw.classReaderLength = (u - firstAttribute);
/*  892 */           return u;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  898 */     if (dann != 0) {
/*  899 */       AnnotationVisitor dv = mv.visitAnnotationDefault();
/*  900 */       readAnnotationValue(dann, c, null, dv);
/*  901 */       if (dv != null) {
/*  902 */         dv.visitEnd();
/*      */       }
/*      */     }
/*  905 */     if (anns != 0) {
/*  906 */       int i = readUnsignedShort(anns); for (int v = anns + 2; i > 0; i--) {
/*  907 */         v = readAnnotationValues(v + 2, c, true, mv.visitAnnotation(readUTF8(v, c), true));
/*      */       }
/*      */     }
/*      */     
/*  911 */     if (ianns != 0) {
/*  912 */       int i = readUnsignedShort(ianns); for (int v = ianns + 2; i > 0; i--) {
/*  913 */         v = readAnnotationValues(v + 2, c, true, mv.visitAnnotation(readUTF8(v, c), false));
/*      */       }
/*      */     }
/*      */     
/*  917 */     if (mpanns != 0) {
/*  918 */       readParameterAnnotations(mpanns, desc, c, true, mv);
/*      */     }
/*  920 */     if (impanns != 0) {
/*  921 */       readParameterAnnotations(impanns, desc, c, false, mv);
/*      */     }
/*      */     
/*      */ 
/*  925 */     while (attributes != null) {
/*  926 */       Attribute attr = attributes.next;
/*  927 */       attributes.next = null;
/*  928 */       mv.visitAttribute(attributes);
/*  929 */       attributes = attr;
/*      */     }
/*      */     
/*      */ 
/*  933 */     if (code != 0) {
/*  934 */       context.access = access;
/*  935 */       context.name = name;
/*  936 */       context.desc = desc;
/*  937 */       mv.visitCode();
/*  938 */       readCode(mv, context, code);
/*      */     }
/*      */     
/*      */ 
/*  942 */     mv.visitEnd();
/*      */     
/*  944 */     return u;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void readCode(MethodVisitor mv, Context context, int u)
/*      */   {
/*  959 */     byte[] b = this.b;
/*  960 */     char[] c = context.buffer;
/*  961 */     int maxStack = readUnsignedShort(u);
/*  962 */     int maxLocals = readUnsignedShort(u + 2);
/*  963 */     int codeLength = readInt(u + 4);
/*  964 */     u += 8;
/*      */     
/*      */ 
/*  967 */     int codeStart = u;
/*  968 */     int codeEnd = u + codeLength;
/*  969 */     Label[] labels = new Label[codeLength + 2];
/*  970 */     readLabel(codeLength + 1, labels);
/*  971 */     while (u < codeEnd) {
/*  972 */       int offset = u - codeStart;
/*  973 */       int opcode = b[u] & 0xFF;
/*  974 */       switch (ClassWriter.TYPE[opcode]) {
/*      */       case 0: 
/*      */       case 4: 
/*  977 */         u++;
/*  978 */         break;
/*      */       case 9: 
/*  980 */         readLabel(offset + readShort(u + 1), labels);
/*  981 */         u += 3;
/*  982 */         break;
/*      */       case 10: 
/*  984 */         readLabel(offset + readInt(u + 1), labels);
/*  985 */         u += 5;
/*  986 */         break;
/*      */       case 17: 
/*  988 */         opcode = b[(u + 1)] & 0xFF;
/*  989 */         if (opcode == 132) {
/*  990 */           u += 6;
/*      */         } else {
/*  992 */           u += 4;
/*      */         }
/*  994 */         break;
/*      */       
/*      */       case 14: 
/*  997 */         u = u + 4 - (offset & 0x3);
/*      */         
/*  999 */         readLabel(offset + readInt(u), labels);
/* 1000 */         for (int i = readInt(u + 8) - readInt(u + 4) + 1; i > 0; i--) {
/* 1001 */           readLabel(offset + readInt(u + 12), labels);
/* 1002 */           u += 4;
/*      */         }
/* 1004 */         u += 12;
/* 1005 */         break;
/*      */       
/*      */       case 15: 
/* 1008 */         u = u + 4 - (offset & 0x3);
/*      */         
/* 1010 */         readLabel(offset + readInt(u), labels);
/* 1011 */         for (int i = readInt(u + 4); i > 0; i--) {
/* 1012 */           readLabel(offset + readInt(u + 12), labels);
/* 1013 */           u += 8;
/*      */         }
/* 1015 */         u += 8;
/* 1016 */         break;
/*      */       case 1: 
/*      */       case 3: 
/*      */       case 11: 
/* 1020 */         u += 2;
/* 1021 */         break;
/*      */       case 2: 
/*      */       case 5: 
/*      */       case 6: 
/*      */       case 12: 
/*      */       case 13: 
/* 1027 */         u += 3;
/* 1028 */         break;
/*      */       case 7: 
/*      */       case 8: 
/* 1031 */         u += 5;
/* 1032 */         break;
/*      */       case 16: 
/*      */       default: 
/* 1035 */         u += 4;
/*      */       }
/*      */       
/*      */     }
/*      */     
/*      */ 
/* 1041 */     for (int i = readUnsignedShort(u); i > 0; i--) {
/* 1042 */       Label start = readLabel(readUnsignedShort(u + 2), labels);
/* 1043 */       Label end = readLabel(readUnsignedShort(u + 4), labels);
/* 1044 */       Label handler = readLabel(readUnsignedShort(u + 6), labels);
/* 1045 */       String type = readUTF8(this.items[readUnsignedShort(u + 8)], c);
/* 1046 */       mv.visitTryCatchBlock(start, end, handler, type);
/* 1047 */       u += 8;
/*      */     }
/* 1049 */     u += 2;
/*      */     
/*      */ 
/* 1052 */     int varTable = 0;
/* 1053 */     int varTypeTable = 0;
/* 1054 */     boolean zip = true;
/* 1055 */     boolean unzip = (context.flags & 0x8) != 0;
/* 1056 */     int stackMap = 0;
/* 1057 */     int stackMapSize = 0;
/* 1058 */     int frameCount = 0;
/* 1059 */     Context frame = null;
/* 1060 */     Attribute attributes = null;
/*      */     
/* 1062 */     for (int i = readUnsignedShort(u); i > 0; i--) {
/* 1063 */       String attrName = readUTF8(u + 2, c);
/* 1064 */       if ("LocalVariableTable".equals(attrName)) {
/* 1065 */         if ((context.flags & 0x2) == 0) {
/* 1066 */           varTable = u + 8;
/* 1067 */           int j = readUnsignedShort(u + 8); for (int v = u; j > 0; j--) {
/* 1068 */             int label = readUnsignedShort(v + 10);
/* 1069 */             if (labels[label] == null) {
/* 1070 */               readLabel(label, labels).status |= 0x1;
/*      */             }
/* 1072 */             label += readUnsignedShort(v + 12);
/* 1073 */             if (labels[label] == null) {
/* 1074 */               readLabel(label, labels).status |= 0x1;
/*      */             }
/* 1076 */             v += 10;
/*      */           }
/*      */         }
/* 1079 */       } else if ("LocalVariableTypeTable".equals(attrName)) {
/* 1080 */         varTypeTable = u + 8;
/* 1081 */       } else if ("LineNumberTable".equals(attrName)) {
/* 1082 */         if ((context.flags & 0x2) == 0) {
/* 1083 */           int j = readUnsignedShort(u + 8); for (int v = u; j > 0; j--) {
/* 1084 */             int label = readUnsignedShort(v + 10);
/* 1085 */             if (labels[label] == null) {
/* 1086 */               readLabel(label, labels).status |= 0x1;
/*      */             }
/* 1088 */             labels[label].line = readUnsignedShort(v + 12);
/* 1089 */             v += 4;
/*      */           }
/*      */         }
/* 1092 */       } else if ("StackMapTable".equals(attrName)) {
/* 1093 */         if ((context.flags & 0x4) == 0) {
/* 1094 */           stackMap = u + 10;
/* 1095 */           stackMapSize = readInt(u + 4);
/* 1096 */           frameCount = readUnsignedShort(u + 8);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/* 1116 */       else if ("StackMap".equals(attrName)) {
/* 1117 */         if ((context.flags & 0x4) == 0) {
/* 1118 */           zip = false;
/* 1119 */           stackMap = u + 10;
/* 1120 */           stackMapSize = readInt(u + 4);
/* 1121 */           frameCount = readUnsignedShort(u + 8);
/*      */ 
/*      */         }
/*      */         
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/* 1129 */         for (int j = 0; j < context.attrs.length; j++) {
/* 1130 */           if (context.attrs[j].type.equals(attrName)) {
/* 1131 */             Attribute attr = context.attrs[j].read(this, u + 8, readInt(u + 4), c, codeStart - 8, labels);
/*      */             
/* 1133 */             if (attr != null) {
/* 1134 */               attr.next = attributes;
/* 1135 */               attributes = attr;
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/* 1140 */       u += 6 + readInt(u + 4);
/*      */     }
/* 1142 */     u += 2;
/*      */     
/*      */ 
/* 1145 */     if (stackMap != 0)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1151 */       frame = context;
/* 1152 */       frame.offset = -1;
/* 1153 */       frame.mode = 0;
/* 1154 */       frame.localCount = 0;
/* 1155 */       frame.localDiff = 0;
/* 1156 */       frame.stackCount = 0;
/* 1157 */       frame.local = new Object[maxLocals];
/* 1158 */       frame.stack = new Object[maxStack];
/* 1159 */       if (unzip) {
/* 1160 */         getImplicitFrame(context);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1173 */       for (int i = stackMap; i < stackMap + stackMapSize - 2; i++) {
/* 1174 */         if (b[i] == 8) {
/* 1175 */           int v = readUnsignedShort(i + 1);
/* 1176 */           if ((v >= 0) && (v < codeLength) && 
/* 1177 */             ((b[(codeStart + v)] & 0xFF) == 187)) {
/* 1178 */             readLabel(v, labels);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1186 */     u = codeStart;
/* 1187 */     while (u < codeEnd) {
/* 1188 */       int offset = u - codeStart;
/*      */       
/*      */ 
/* 1191 */       Label l = labels[offset];
/* 1192 */       if (l != null) {
/* 1193 */         mv.visitLabel(l);
/* 1194 */         if (((context.flags & 0x2) == 0) && (l.line > 0)) {
/* 1195 */           mv.visitLineNumber(l.line, l);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1201 */       while ((frame != null) && ((frame.offset == offset) || (frame.offset == -1)))
/*      */       {
/*      */ 
/* 1204 */         if (frame.offset != -1) {
/* 1205 */           if ((!zip) || (unzip)) {
/* 1206 */             mv.visitFrame(-1, frame.localCount, frame.local, frame.stackCount, frame.stack);
/*      */           }
/*      */           else {
/* 1209 */             mv.visitFrame(frame.mode, frame.localDiff, frame.local, frame.stackCount, frame.stack);
/*      */           }
/*      */         }
/*      */         
/* 1213 */         if (frameCount > 0) {
/* 1214 */           stackMap = readFrame(stackMap, zip, unzip, labels, frame);
/* 1215 */           frameCount--;
/*      */         } else {
/* 1217 */           frame = null;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 1222 */       int opcode = b[u] & 0xFF;
/* 1223 */       switch (ClassWriter.TYPE[opcode]) {
/*      */       case 0: 
/* 1225 */         mv.visitInsn(opcode);
/* 1226 */         u++;
/* 1227 */         break;
/*      */       case 4: 
/* 1229 */         if (opcode > 54) {
/* 1230 */           opcode -= 59;
/* 1231 */           mv.visitVarInsn(54 + (opcode >> 2), opcode & 0x3);
/*      */         }
/*      */         else {
/* 1234 */           opcode -= 26;
/* 1235 */           mv.visitVarInsn(21 + (opcode >> 2), opcode & 0x3);
/*      */         }
/* 1237 */         u++;
/* 1238 */         break;
/*      */       case 9: 
/* 1240 */         mv.visitJumpInsn(opcode, labels[(offset + readShort(u + 1))]);
/* 1241 */         u += 3;
/* 1242 */         break;
/*      */       case 10: 
/* 1244 */         mv.visitJumpInsn(opcode - 33, labels[(offset + readInt(u + 1))]);
/* 1245 */         u += 5;
/* 1246 */         break;
/*      */       case 17: 
/* 1248 */         opcode = b[(u + 1)] & 0xFF;
/* 1249 */         if (opcode == 132) {
/* 1250 */           mv.visitIincInsn(readUnsignedShort(u + 2), readShort(u + 4));
/* 1251 */           u += 6;
/*      */         } else {
/* 1253 */           mv.visitVarInsn(opcode, readUnsignedShort(u + 2));
/* 1254 */           u += 4;
/*      */         }
/* 1256 */         break;
/*      */       
/*      */       case 14: 
/* 1259 */         u = u + 4 - (offset & 0x3);
/*      */         
/* 1261 */         int label = offset + readInt(u);
/* 1262 */         int min = readInt(u + 4);
/* 1263 */         int max = readInt(u + 8);
/* 1264 */         Label[] table = new Label[max - min + 1];
/* 1265 */         u += 12;
/* 1266 */         for (int i = 0; i < table.length; i++) {
/* 1267 */           table[i] = labels[(offset + readInt(u))];
/* 1268 */           u += 4;
/*      */         }
/* 1270 */         mv.visitTableSwitchInsn(min, max, labels[label], table);
/* 1271 */         break;
/*      */       
/*      */ 
/*      */       case 15: 
/* 1275 */         u = u + 4 - (offset & 0x3);
/*      */         
/* 1277 */         int label = offset + readInt(u);
/* 1278 */         int len = readInt(u + 4);
/* 1279 */         int[] keys = new int[len];
/* 1280 */         Label[] values = new Label[len];
/* 1281 */         u += 8;
/* 1282 */         for (int i = 0; i < len; i++) {
/* 1283 */           keys[i] = readInt(u);
/* 1284 */           values[i] = labels[(offset + readInt(u + 4))];
/* 1285 */           u += 8;
/*      */         }
/* 1287 */         mv.visitLookupSwitchInsn(labels[label], keys, values);
/* 1288 */         break;
/*      */       
/*      */       case 3: 
/* 1291 */         mv.visitVarInsn(opcode, b[(u + 1)] & 0xFF);
/* 1292 */         u += 2;
/* 1293 */         break;
/*      */       case 1: 
/* 1295 */         mv.visitIntInsn(opcode, b[(u + 1)]);
/* 1296 */         u += 2;
/* 1297 */         break;
/*      */       case 2: 
/* 1299 */         mv.visitIntInsn(opcode, readShort(u + 1));
/* 1300 */         u += 3;
/* 1301 */         break;
/*      */       case 11: 
/* 1303 */         mv.visitLdcInsn(readConst(b[(u + 1)] & 0xFF, c));
/* 1304 */         u += 2;
/* 1305 */         break;
/*      */       case 12: 
/* 1307 */         mv.visitLdcInsn(readConst(readUnsignedShort(u + 1), c));
/* 1308 */         u += 3;
/* 1309 */         break;
/*      */       case 6: 
/*      */       case 7: 
/* 1312 */         int cpIndex = this.items[readUnsignedShort(u + 1)];
/* 1313 */         String iowner = readClass(cpIndex, c);
/* 1314 */         cpIndex = this.items[readUnsignedShort(cpIndex + 2)];
/* 1315 */         String iname = readUTF8(cpIndex, c);
/* 1316 */         String idesc = readUTF8(cpIndex + 2, c);
/* 1317 */         if (opcode < 182) {
/* 1318 */           mv.visitFieldInsn(opcode, iowner, iname, idesc);
/*      */         } else {
/* 1320 */           mv.visitMethodInsn(opcode, iowner, iname, idesc);
/*      */         }
/* 1322 */         if (opcode == 185) {
/* 1323 */           u += 5;
/*      */         } else {
/* 1325 */           u += 3;
/*      */         }
/* 1327 */         break;
/*      */       
/*      */       case 8: 
/* 1330 */         int cpIndex = this.items[readUnsignedShort(u + 1)];
/* 1331 */         int bsmIndex = context.bootstrapMethods[readUnsignedShort(cpIndex)];
/* 1332 */         Handle bsm = (Handle)readConst(readUnsignedShort(bsmIndex), c);
/* 1333 */         int bsmArgCount = readUnsignedShort(bsmIndex + 2);
/* 1334 */         Object[] bsmArgs = new Object[bsmArgCount];
/* 1335 */         bsmIndex += 4;
/* 1336 */         for (int i = 0; i < bsmArgCount; i++) {
/* 1337 */           bsmArgs[i] = readConst(readUnsignedShort(bsmIndex), c);
/* 1338 */           bsmIndex += 2;
/*      */         }
/* 1340 */         cpIndex = this.items[readUnsignedShort(cpIndex + 2)];
/* 1341 */         String iname = readUTF8(cpIndex, c);
/* 1342 */         String idesc = readUTF8(cpIndex + 2, c);
/* 1343 */         mv.visitInvokeDynamicInsn(iname, idesc, bsm, bsmArgs);
/* 1344 */         u += 5;
/* 1345 */         break;
/*      */       
/*      */       case 5: 
/* 1348 */         mv.visitTypeInsn(opcode, readClass(u + 1, c));
/* 1349 */         u += 3;
/* 1350 */         break;
/*      */       case 13: 
/* 1352 */         mv.visitIincInsn(b[(u + 1)] & 0xFF, b[(u + 2)]);
/* 1353 */         u += 3;
/* 1354 */         break;
/*      */       case 16: 
/*      */       default: 
/* 1357 */         mv.visitMultiANewArrayInsn(readClass(u + 1, c), b[(u + 3)] & 0xFF);
/* 1358 */         u += 4;
/*      */       }
/*      */       
/*      */     }
/* 1362 */     if (labels[codeLength] != null) {
/* 1363 */       mv.visitLabel(labels[codeLength]);
/*      */     }
/*      */     
/*      */ 
/* 1367 */     if (((context.flags & 0x2) == 0) && (varTable != 0)) {
/* 1368 */       int[] typeTable = null;
/* 1369 */       int i; if (varTypeTable != 0) {
/* 1370 */         u = varTypeTable + 2;
/* 1371 */         typeTable = new int[readUnsignedShort(varTypeTable) * 3];
/* 1372 */         for (i = typeTable.length; i > 0;) {
/* 1373 */           typeTable[(--i)] = (u + 6);
/* 1374 */           typeTable[(--i)] = readUnsignedShort(u + 8);
/* 1375 */           typeTable[(--i)] = readUnsignedShort(u);
/* 1376 */           u += 10;
/*      */         }
/*      */       }
/* 1379 */       u = varTable + 2;
/* 1380 */       for (int i = readUnsignedShort(varTable); i > 0; i--) {
/* 1381 */         int start = readUnsignedShort(u);
/* 1382 */         int length = readUnsignedShort(u + 2);
/* 1383 */         int index = readUnsignedShort(u + 8);
/* 1384 */         String vsignature = null;
/* 1385 */         if (typeTable != null) {
/* 1386 */           for (int j = 0; j < typeTable.length; j += 3) {
/* 1387 */             if ((typeTable[j] == start) && (typeTable[(j + 1)] == index)) {
/* 1388 */               vsignature = readUTF8(typeTable[(j + 2)], c);
/* 1389 */               break;
/*      */             }
/*      */           }
/*      */         }
/* 1393 */         mv.visitLocalVariable(readUTF8(u + 4, c), readUTF8(u + 6, c), vsignature, labels[start], labels[(start + length)], index);
/*      */         
/*      */ 
/* 1396 */         u += 10;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1401 */     while (attributes != null) {
/* 1402 */       Attribute attr = attributes.next;
/* 1403 */       attributes.next = null;
/* 1404 */       mv.visitAttribute(attributes);
/* 1405 */       attributes = attr;
/*      */     }
/*      */     
/*      */ 
/* 1409 */     mv.visitMaxs(maxStack, maxLocals);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void readParameterAnnotations(int v, String desc, char[] buf, boolean visible, MethodVisitor mv)
/*      */   {
/* 1432 */     int n = this.b[(v++)] & 0xFF;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1439 */     int synthetics = Type.getArgumentTypes(desc).length - n;
/*      */     
/* 1441 */     for (int i = 0; i < synthetics; i++)
/*      */     {
/* 1443 */       AnnotationVisitor av = mv.visitParameterAnnotation(i, "Ljava/lang/Synthetic;", false);
/* 1444 */       if (av != null) {
/* 1445 */         av.visitEnd();
/*      */       }
/*      */     }
/* 1448 */     for (; i < n + synthetics; i++) {
/* 1449 */       int j = readUnsignedShort(v);
/* 1450 */       v += 2;
/* 1451 */       for (; j > 0; j--) {
/* 1452 */         AnnotationVisitor av = mv.visitParameterAnnotation(i, readUTF8(v, buf), visible);
/* 1453 */         v = readAnnotationValues(v + 2, buf, true, av);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int readAnnotationValues(int v, char[] buf, boolean named, AnnotationVisitor av)
/*      */   {
/* 1477 */     int i = readUnsignedShort(v);
/* 1478 */     v += 2;
/* 1479 */     if (named) {
/* 1480 */       for (; i > 0; i--) {
/* 1481 */         v = readAnnotationValue(v + 2, buf, readUTF8(v, buf), av);
/*      */       }
/*      */     }
/* 1484 */     for (; i > 0; i--) {
/* 1485 */       v = readAnnotationValue(v, buf, null, av);
/*      */     }
/*      */     
/* 1488 */     if (av != null) {
/* 1489 */       av.visitEnd();
/*      */     }
/* 1491 */     return v;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int readAnnotationValue(int v, char[] buf, String name, AnnotationVisitor av)
/*      */   {
/* 1513 */     if (av == null) {
/* 1514 */       switch (this.b[v] & 0xFF) {
/*      */       case 101: 
/* 1516 */         return v + 5;
/*      */       case 64: 
/* 1518 */         return readAnnotationValues(v + 3, buf, true, null);
/*      */       case 91: 
/* 1520 */         return readAnnotationValues(v + 1, buf, false, null);
/*      */       }
/* 1522 */       return v + 3;
/*      */     }
/*      */     
/* 1525 */     switch (this.b[(v++)] & 0xFF) {
/*      */     case 68: 
/*      */     case 70: 
/*      */     case 73: 
/*      */     case 74: 
/* 1530 */       av.visit(name, readConst(readUnsignedShort(v), buf));
/* 1531 */       v += 2;
/* 1532 */       break;
/*      */     case 66: 
/* 1534 */       av.visit(name, new Byte((byte)readInt(this.items[readUnsignedShort(v)])));
/*      */       
/* 1536 */       v += 2;
/* 1537 */       break;
/*      */     case 90: 
/* 1539 */       av.visit(name, readInt(this.items[readUnsignedShort(v)]) == 0 ? Boolean.FALSE : Boolean.TRUE);
/*      */       
/*      */ 
/* 1542 */       v += 2;
/* 1543 */       break;
/*      */     case 83: 
/* 1545 */       av.visit(name, new Short((short)readInt(this.items[readUnsignedShort(v)])));
/*      */       
/* 1547 */       v += 2;
/* 1548 */       break;
/*      */     case 67: 
/* 1550 */       av.visit(name, new Character((char)readInt(this.items[readUnsignedShort(v)])));
/*      */       
/* 1552 */       v += 2;
/* 1553 */       break;
/*      */     case 115: 
/* 1555 */       av.visit(name, readUTF8(v, buf));
/* 1556 */       v += 2;
/* 1557 */       break;
/*      */     case 101: 
/* 1559 */       av.visitEnum(name, readUTF8(v, buf), readUTF8(v + 2, buf));
/* 1560 */       v += 4;
/* 1561 */       break;
/*      */     case 99: 
/* 1563 */       av.visit(name, Type.getType(readUTF8(v, buf)));
/* 1564 */       v += 2;
/* 1565 */       break;
/*      */     case 64: 
/* 1567 */       v = readAnnotationValues(v + 2, buf, true, av.visitAnnotation(name, readUTF8(v, buf)));
/*      */       
/* 1569 */       break;
/*      */     case 91: 
/* 1571 */       int size = readUnsignedShort(v);
/* 1572 */       v += 2;
/* 1573 */       if (size == 0) {
/* 1574 */         return readAnnotationValues(v - 2, buf, false, av.visitArray(name));
/*      */       }
/*      */       int i;
/* 1577 */       switch (this.b[(v++)] & 0xFF) {
/*      */       case 66: 
/* 1579 */         byte[] bv = new byte[size];
/* 1580 */         for (i = 0; i < size; i++) {
/* 1581 */           bv[i] = ((byte)readInt(this.items[readUnsignedShort(v)]));
/* 1582 */           v += 3;
/*      */         }
/* 1584 */         av.visit(name, bv);
/* 1585 */         v--;
/* 1586 */         break;
/*      */       case 90: 
/* 1588 */         boolean[] zv = new boolean[size];
/* 1589 */         for (i = 0; i < size; i++) {
/* 1590 */           zv[i] = (readInt(this.items[readUnsignedShort(v)]) != 0 ? 1 : false);
/* 1591 */           v += 3;
/*      */         }
/* 1593 */         av.visit(name, zv);
/* 1594 */         v--;
/* 1595 */         break;
/*      */       case 83: 
/* 1597 */         short[] sv = new short[size];
/* 1598 */         for (i = 0; i < size; i++) {
/* 1599 */           sv[i] = ((short)readInt(this.items[readUnsignedShort(v)]));
/* 1600 */           v += 3;
/*      */         }
/* 1602 */         av.visit(name, sv);
/* 1603 */         v--;
/* 1604 */         break;
/*      */       case 67: 
/* 1606 */         char[] cv = new char[size];
/* 1607 */         for (i = 0; i < size; i++) {
/* 1608 */           cv[i] = ((char)readInt(this.items[readUnsignedShort(v)]));
/* 1609 */           v += 3;
/*      */         }
/* 1611 */         av.visit(name, cv);
/* 1612 */         v--;
/* 1613 */         break;
/*      */       case 73: 
/* 1615 */         int[] iv = new int[size];
/* 1616 */         for (i = 0; i < size; i++) {
/* 1617 */           iv[i] = readInt(this.items[readUnsignedShort(v)]);
/* 1618 */           v += 3;
/*      */         }
/* 1620 */         av.visit(name, iv);
/* 1621 */         v--;
/* 1622 */         break;
/*      */       case 74: 
/* 1624 */         long[] lv = new long[size];
/* 1625 */         for (i = 0; i < size; i++) {
/* 1626 */           lv[i] = readLong(this.items[readUnsignedShort(v)]);
/* 1627 */           v += 3;
/*      */         }
/* 1629 */         av.visit(name, lv);
/* 1630 */         v--;
/* 1631 */         break;
/*      */       case 70: 
/* 1633 */         float[] fv = new float[size];
/* 1634 */         for (i = 0; i < size; i++) {
/* 1635 */           fv[i] = Float.intBitsToFloat(readInt(this.items[readUnsignedShort(v)]));
/*      */           
/* 1637 */           v += 3;
/*      */         }
/* 1639 */         av.visit(name, fv);
/* 1640 */         v--;
/* 1641 */         break;
/*      */       case 68: 
/* 1643 */         double[] dv = new double[size];
/* 1644 */         for (i = 0; i < size; i++) {
/* 1645 */           dv[i] = Double.longBitsToDouble(readLong(this.items[readUnsignedShort(v)]));
/*      */           
/* 1647 */           v += 3;
/*      */         }
/* 1649 */         av.visit(name, dv);
/* 1650 */         v--;
/* 1651 */         break;
/*      */       case 69: case 71: case 72: case 75: case 76: case 77: case 78: case 79: case 80: case 81: case 82: case 84: case 85: case 86: case 87: case 88: case 89: default: 
/* 1653 */         v = readAnnotationValues(v - 3, buf, false, av.visitArray(name));
/*      */       }
/*      */       break; }
/* 1656 */     return v;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void getImplicitFrame(Context frame)
/*      */   {
/* 1667 */     String desc = frame.desc;
/* 1668 */     Object[] locals = frame.local;
/* 1669 */     int local = 0;
/* 1670 */     if ((frame.access & 0x8) == 0) {
/* 1671 */       if ("<init>".equals(frame.name)) {
/* 1672 */         locals[(local++)] = Opcodes.UNINITIALIZED_THIS;
/*      */       } else {
/* 1674 */         locals[(local++)] = readClass(this.header + 2, frame.buffer);
/*      */       }
/*      */     }
/* 1677 */     int i = 1;
/*      */     for (;;) {
/* 1679 */       int j = i;
/* 1680 */       switch (desc.charAt(i++)) {
/*      */       case 'B': 
/*      */       case 'C': 
/*      */       case 'I': 
/*      */       case 'S': 
/*      */       case 'Z': 
/* 1686 */         locals[(local++)] = Opcodes.INTEGER;
/* 1687 */         break;
/*      */       case 'F': 
/* 1689 */         locals[(local++)] = Opcodes.FLOAT;
/* 1690 */         break;
/*      */       case 'J': 
/* 1692 */         locals[(local++)] = Opcodes.LONG;
/* 1693 */         break;
/*      */       case 'D': 
/* 1695 */         locals[(local++)] = Opcodes.DOUBLE;
/* 1696 */         break;
/*      */       case '[': 
/* 1698 */         while (desc.charAt(i) == '[') {
/* 1699 */           i++;
/*      */         }
/* 1701 */         if (desc.charAt(i) == 'L') {
/* 1702 */           i++;
/* 1703 */           while (desc.charAt(i) != ';') {
/* 1704 */             i++;
/*      */           }
/*      */         }
/* 1707 */         locals[(local++)] = desc.substring(j, ++i);
/* 1708 */         break;
/*      */       case 'L': 
/* 1710 */         while (desc.charAt(i) != ';') {
/* 1711 */           i++;
/*      */         }
/* 1713 */         locals[(local++)] = desc.substring(j + 1, i++);
/* 1714 */         break;
/*      */       case 'E': case 'G': case 'H': case 'K': case 'M': case 'N': case 'O': case 'P': case 'Q': case 'R': case 'T': case 'U': case 'V': case 'W': case 'X': case 'Y': default: 
/*      */         break label371; }
/*      */     }
/*      */     label371:
/* 1719 */     frame.localCount = local;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int readFrame(int stackMap, boolean zip, boolean unzip, Label[] labels, Context frame)
/*      */   {
/* 1742 */     char[] c = frame.buffer;
/*      */     int tag;
/*      */     int tag;
/* 1745 */     if (zip) {
/* 1746 */       tag = this.b[(stackMap++)] & 0xFF;
/*      */     } else {
/* 1748 */       tag = 255;
/* 1749 */       frame.offset = -1;
/*      */     }
/* 1751 */     frame.localDiff = 0;
/* 1752 */     int delta; if (tag < 64) {
/* 1753 */       int delta = tag;
/* 1754 */       frame.mode = 3;
/* 1755 */       frame.stackCount = 0;
/* 1756 */     } else if (tag < 128) {
/* 1757 */       int delta = tag - 64;
/* 1758 */       stackMap = readFrameType(frame.stack, 0, stackMap, c, labels);
/* 1759 */       frame.mode = 4;
/* 1760 */       frame.stackCount = 1;
/*      */     } else {
/* 1762 */       delta = readUnsignedShort(stackMap);
/* 1763 */       stackMap += 2;
/* 1764 */       if (tag == 247) {
/* 1765 */         stackMap = readFrameType(frame.stack, 0, stackMap, c, labels);
/* 1766 */         frame.mode = 4;
/* 1767 */         frame.stackCount = 1;
/* 1768 */       } else if ((tag >= 248) && (tag < 251))
/*      */       {
/* 1770 */         frame.mode = 2;
/* 1771 */         frame.localDiff = (251 - tag);
/* 1772 */         frame.localCount -= frame.localDiff;
/* 1773 */         frame.stackCount = 0;
/* 1774 */       } else if (tag == 251) {
/* 1775 */         frame.mode = 3;
/* 1776 */         frame.stackCount = 0;
/* 1777 */       } else if (tag < 255) {
/* 1778 */         int local = unzip ? frame.localCount : 0;
/* 1779 */         for (int i = tag - 251; i > 0; i--) {
/* 1780 */           stackMap = readFrameType(frame.local, local++, stackMap, c, labels);
/*      */         }
/*      */         
/* 1783 */         frame.mode = 1;
/* 1784 */         frame.localDiff = (tag - 251);
/* 1785 */         frame.localCount += frame.localDiff;
/* 1786 */         frame.stackCount = 0;
/*      */       } else {
/* 1788 */         frame.mode = 0;
/* 1789 */         int n = readUnsignedShort(stackMap);
/* 1790 */         stackMap += 2;
/* 1791 */         frame.localDiff = n;
/* 1792 */         frame.localCount = n;
/* 1793 */         for (int local = 0; n > 0; n--) {
/* 1794 */           stackMap = readFrameType(frame.local, local++, stackMap, c, labels);
/*      */         }
/*      */         
/* 1797 */         n = readUnsignedShort(stackMap);
/* 1798 */         stackMap += 2;
/* 1799 */         frame.stackCount = n;
/* 1800 */         for (int stack = 0; n > 0; n--) {
/* 1801 */           stackMap = readFrameType(frame.stack, stack++, stackMap, c, labels);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 1806 */     frame.offset += delta + 1;
/* 1807 */     readLabel(frame.offset, labels);
/* 1808 */     return stackMap;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int readFrameType(Object[] frame, int index, int v, char[] buf, Label[] labels)
/*      */   {
/* 1832 */     int type = this.b[(v++)] & 0xFF;
/* 1833 */     switch (type) {
/*      */     case 0: 
/* 1835 */       frame[index] = Opcodes.TOP;
/* 1836 */       break;
/*      */     case 1: 
/* 1838 */       frame[index] = Opcodes.INTEGER;
/* 1839 */       break;
/*      */     case 2: 
/* 1841 */       frame[index] = Opcodes.FLOAT;
/* 1842 */       break;
/*      */     case 3: 
/* 1844 */       frame[index] = Opcodes.DOUBLE;
/* 1845 */       break;
/*      */     case 4: 
/* 1847 */       frame[index] = Opcodes.LONG;
/* 1848 */       break;
/*      */     case 5: 
/* 1850 */       frame[index] = Opcodes.NULL;
/* 1851 */       break;
/*      */     case 6: 
/* 1853 */       frame[index] = Opcodes.UNINITIALIZED_THIS;
/* 1854 */       break;
/*      */     case 7: 
/* 1856 */       frame[index] = readClass(v, buf);
/* 1857 */       v += 2;
/* 1858 */       break;
/*      */     default: 
/* 1860 */       frame[index] = readLabel(readUnsignedShort(v), labels);
/* 1861 */       v += 2;
/*      */     }
/* 1863 */     return v;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Label readLabel(int offset, Label[] labels)
/*      */   {
/* 1880 */     if (labels[offset] == null) {
/* 1881 */       labels[offset] = new Label();
/*      */     }
/* 1883 */     return labels[offset];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int getAttributes()
/*      */   {
/* 1893 */     int u = this.header + 8 + readUnsignedShort(this.header + 6) * 2;
/*      */     
/* 1895 */     for (int i = readUnsignedShort(u); i > 0; i--) {
/* 1896 */       for (int j = readUnsignedShort(u + 8); j > 0; j--) {
/* 1897 */         u += 6 + readInt(u + 12);
/*      */       }
/* 1899 */       u += 8;
/*      */     }
/* 1901 */     u += 2;
/* 1902 */     for (int i = readUnsignedShort(u); i > 0; i--) {
/* 1903 */       for (int j = readUnsignedShort(u + 8); j > 0; j--) {
/* 1904 */         u += 6 + readInt(u + 12);
/*      */       }
/* 1906 */       u += 8;
/*      */     }
/*      */     
/* 1909 */     return u + 2;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Attribute readAttribute(Attribute[] attrs, String type, int off, int len, char[] buf, int codeOff, Label[] labels)
/*      */   {
/* 1948 */     for (int i = 0; i < attrs.length; i++) {
/* 1949 */       if (attrs[i].type.equals(type)) {
/* 1950 */         return attrs[i].read(this, off, len, buf, codeOff, labels);
/*      */       }
/*      */     }
/* 1953 */     return new Attribute(type).read(this, off, len, null, -1, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getItemCount()
/*      */   {
/* 1966 */     return this.items.length;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getItem(int item)
/*      */   {
/* 1980 */     return this.items[item];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMaxStringLength()
/*      */   {
/* 1991 */     return this.maxStringLength;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int readByte(int index)
/*      */   {
/* 2004 */     return this.b[index] & 0xFF;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int readUnsignedShort(int index)
/*      */   {
/* 2017 */     byte[] b = this.b;
/* 2018 */     return (b[index] & 0xFF) << 8 | b[(index + 1)] & 0xFF;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public short readShort(int index)
/*      */   {
/* 2031 */     byte[] b = this.b;
/* 2032 */     return (short)((b[index] & 0xFF) << 8 | b[(index + 1)] & 0xFF);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int readInt(int index)
/*      */   {
/* 2045 */     byte[] b = this.b;
/* 2046 */     return (b[index] & 0xFF) << 24 | (b[(index + 1)] & 0xFF) << 16 | (b[(index + 2)] & 0xFF) << 8 | b[(index + 3)] & 0xFF;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long readLong(int index)
/*      */   {
/* 2060 */     long l1 = readInt(index);
/* 2061 */     long l0 = readInt(index + 4) & 0xFFFFFFFF;
/* 2062 */     return l1 << 32 | l0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String readUTF8(int index, char[] buf)
/*      */   {
/* 2079 */     int item = readUnsignedShort(index);
/* 2080 */     if ((index == 0) || (item == 0)) {
/* 2081 */       return null;
/*      */     }
/* 2083 */     String s = this.strings[item];
/* 2084 */     if (s != null) {
/* 2085 */       return s;
/*      */     }
/* 2087 */     index = this.items[item];
/* 2088 */     return this.strings[item] = readUTF(index + 2, readUnsignedShort(index), buf);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String readUTF(int index, int utfLen, char[] buf)
/*      */   {
/* 2104 */     int endIndex = index + utfLen;
/* 2105 */     byte[] b = this.b;
/* 2106 */     int strLen = 0;
/*      */     
/* 2108 */     int st = 0;
/* 2109 */     char cc = '\000';
/* 2110 */     while (index < endIndex) {
/* 2111 */       int c = b[(index++)];
/* 2112 */       switch (st) {
/*      */       case 0: 
/* 2114 */         c &= 0xFF;
/* 2115 */         if (c < 128) {
/* 2116 */           buf[(strLen++)] = ((char)c);
/* 2117 */         } else if ((c < 224) && (c > 191)) {
/* 2118 */           cc = (char)(c & 0x1F);
/* 2119 */           st = 1;
/*      */         } else {
/* 2121 */           cc = (char)(c & 0xF);
/* 2122 */           st = 2;
/*      */         }
/* 2124 */         break;
/*      */       
/*      */       case 1: 
/* 2127 */         buf[(strLen++)] = ((char)(cc << '\006' | c & 0x3F));
/* 2128 */         st = 0;
/* 2129 */         break;
/*      */       
/*      */       case 2: 
/* 2132 */         cc = (char)(cc << '\006' | c & 0x3F);
/* 2133 */         st = 1;
/*      */       }
/*      */       
/*      */     }
/* 2137 */     return new String(buf, 0, strLen);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String readClass(int index, char[] buf)
/*      */   {
/* 2157 */     return readUTF8(this.items[readUnsignedShort(index)], buf);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object readConst(int item, char[] buf)
/*      */   {
/* 2175 */     int index = this.items[item];
/* 2176 */     switch (this.b[(index - 1)]) {
/*      */     case 3: 
/* 2178 */       return new Integer(readInt(index));
/*      */     case 4: 
/* 2180 */       return new Float(Float.intBitsToFloat(readInt(index)));
/*      */     case 5: 
/* 2182 */       return new Long(readLong(index));
/*      */     case 6: 
/* 2184 */       return new Double(Double.longBitsToDouble(readLong(index)));
/*      */     case 7: 
/* 2186 */       return Type.getObjectType(readUTF8(index, buf));
/*      */     case 8: 
/* 2188 */       return readUTF8(index, buf);
/*      */     case 16: 
/* 2190 */       return Type.getMethodType(readUTF8(index, buf));
/*      */     }
/* 2192 */     int tag = readByte(index);
/* 2193 */     int[] items = this.items;
/* 2194 */     int cpIndex = items[readUnsignedShort(index + 1)];
/* 2195 */     String owner = readClass(cpIndex, buf);
/* 2196 */     cpIndex = items[readUnsignedShort(cpIndex + 2)];
/* 2197 */     String name = readUTF8(cpIndex, buf);
/* 2198 */     String desc = readUTF8(cpIndex + 2, buf);
/* 2199 */     return new Handle(tag, owner, name, desc);
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\asm\ClassReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */