/*      */ package clojure.asm;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ClassWriter
/*      */   extends ClassVisitor
/*      */ {
/*      */   public static final int COMPUTE_MAXS = 1;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int COMPUTE_FRAMES = 2;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int ACC_SYNTHETIC_ATTRIBUTE = 262144;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int TO_ACC_SYNTHETIC = 64;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int NOARG_INSN = 0;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int SBYTE_INSN = 1;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int SHORT_INSN = 2;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int VAR_INSN = 3;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int IMPLVAR_INSN = 4;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int TYPE_INSN = 5;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int FIELDORMETH_INSN = 6;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int ITFMETH_INSN = 7;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int INDYMETH_INSN = 8;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int LABEL_INSN = 9;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int LABELW_INSN = 10;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int LDC_INSN = 11;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int LDCW_INSN = 12;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int IINC_INSN = 13;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int TABL_INSN = 14;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int LOOK_INSN = 15;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int MANA_INSN = 16;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int WIDE_INSN = 17;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final byte[] TYPE;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int CLASS = 7;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int FIELD = 9;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int METH = 10;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int IMETH = 11;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int STR = 8;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int INT = 3;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int FLOAT = 4;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int LONG = 5;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int DOUBLE = 6;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int NAME_TYPE = 12;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int UTF8 = 1;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int MTYPE = 16;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int HANDLE = 15;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int INDY = 18;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int HANDLE_BASE = 20;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int TYPE_NORMAL = 30;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int TYPE_UNINIT = 31;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int TYPE_MERGED = 32;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int BSM = 33;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   ClassReader cr;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   int version;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   int index;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final ByteVector pool;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Item[] items;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   int threshold;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final Item key;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final Item key2;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final Item key3;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   final Item key4;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Item[] typeTable;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private short typeCount;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int access;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int name;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   String thisName;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int signature;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int superName;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int interfaceCount;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int[] interfaces;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int sourceFile;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private ByteVector sourceDebug;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int enclosingMethodOwner;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int enclosingMethod;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private AnnotationWriter anns;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private AnnotationWriter ianns;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Attribute attrs;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int innerClassesCount;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private ByteVector innerClasses;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   int bootstrapMethodsCount;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   ByteVector bootstrapMethods;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   FieldWriter firstField;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   FieldWriter lastField;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   MethodWriter firstMethod;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   MethodWriter lastMethod;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final boolean computeMaxs;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final boolean computeFrames;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   boolean invalidFrames;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static
/*      */   {
/*  506 */     byte[] b = new byte['Ü'];
/*  507 */     String s = "AAAAAAAAAAAAAAAABCLMMDDDDDEEEEEEEEEEEEEEEEEEEEAAAAAAAADDDDDEEEEEEEEEEEEEEEEEEEEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAANAAAAAAAAAAAAAAAAAAAAJJJJJJJJJJJJJJJJDOPAAAAAAGGGGGGGHIFBFAAFFAARQJJKKJJJJJJJJJJJJJJJJJJ";
/*      */     
/*      */ 
/*      */ 
/*  511 */     for (int i = 0; i < b.length; i++) {
/*  512 */       b[i] = ((byte)(s.charAt(i) - 'A'));
/*      */     }
/*  514 */     TYPE = b;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ClassWriter(int flags)
/*      */   {
/*  598 */     super(262144);
/*  599 */     this.index = 1;
/*  600 */     this.pool = new ByteVector();
/*  601 */     this.items = new Item['Ā'];
/*  602 */     this.threshold = ((int)(0.75D * this.items.length));
/*  603 */     this.key = new Item();
/*  604 */     this.key2 = new Item();
/*  605 */     this.key3 = new Item();
/*  606 */     this.key4 = new Item();
/*  607 */     this.computeMaxs = ((flags & 0x1) != 0);
/*  608 */     this.computeFrames = ((flags & 0x2) != 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ClassWriter(ClassReader classReader, int flags)
/*      */   {
/*  644 */     this(flags);
/*  645 */     classReader.copyPool(this);
/*  646 */     this.cr = classReader;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final void visit(int version, int access, String name, String signature, String superName, String[] interfaces)
/*      */   {
/*  657 */     this.version = version;
/*  658 */     this.access = access;
/*  659 */     this.name = newClass(name);
/*  660 */     this.thisName = name;
/*  661 */     if (signature != null) {
/*  662 */       this.signature = newUTF8(signature);
/*      */     }
/*  664 */     this.superName = (superName == null ? 0 : newClass(superName));
/*  665 */     if ((interfaces != null) && (interfaces.length > 0)) {
/*  666 */       this.interfaceCount = interfaces.length;
/*  667 */       this.interfaces = new int[this.interfaceCount];
/*  668 */       for (int i = 0; i < this.interfaceCount; i++) {
/*  669 */         this.interfaces[i] = newClass(interfaces[i]);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public final void visitSource(String file, String debug)
/*      */   {
/*  676 */     if (file != null) {
/*  677 */       this.sourceFile = newUTF8(file);
/*      */     }
/*  679 */     if (debug != null) {
/*  680 */       this.sourceDebug = new ByteVector().putUTF8(debug);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public final void visitOuterClass(String owner, String name, String desc)
/*      */   {
/*  687 */     this.enclosingMethodOwner = newClass(owner);
/*  688 */     if ((name != null) && (desc != null)) {
/*  689 */       this.enclosingMethod = newNameType(name, desc);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final AnnotationVisitor visitAnnotation(String desc, boolean visible)
/*      */   {
/*  699 */     ByteVector bv = new ByteVector();
/*      */     
/*  701 */     bv.putShort(newUTF8(desc)).putShort(0);
/*  702 */     AnnotationWriter aw = new AnnotationWriter(this, true, bv, bv, 2);
/*  703 */     if (visible) {
/*  704 */       aw.next = this.anns;
/*  705 */       this.anns = aw;
/*      */     } else {
/*  707 */       aw.next = this.ianns;
/*  708 */       this.ianns = aw;
/*      */     }
/*  710 */     return aw;
/*      */   }
/*      */   
/*      */   public final void visitAttribute(Attribute attr)
/*      */   {
/*  715 */     attr.next = this.attrs;
/*  716 */     this.attrs = attr;
/*      */   }
/*      */   
/*      */ 
/*      */   public final void visitInnerClass(String name, String outerName, String innerName, int access)
/*      */   {
/*  722 */     if (this.innerClasses == null) {
/*  723 */       this.innerClasses = new ByteVector();
/*      */     }
/*  725 */     this.innerClassesCount += 1;
/*  726 */     this.innerClasses.putShort(name == null ? 0 : newClass(name));
/*  727 */     this.innerClasses.putShort(outerName == null ? 0 : newClass(outerName));
/*  728 */     this.innerClasses.putShort(innerName == null ? 0 : newUTF8(innerName));
/*  729 */     this.innerClasses.putShort(access);
/*      */   }
/*      */   
/*      */ 
/*      */   public final FieldVisitor visitField(int access, String name, String desc, String signature, Object value)
/*      */   {
/*  735 */     return new FieldWriter(this, access, name, desc, signature, value);
/*      */   }
/*      */   
/*      */ 
/*      */   public final MethodVisitor visitMethod(int access, String name, String desc, String signature, String[] exceptions)
/*      */   {
/*  741 */     return new MethodWriter(this, access, name, desc, signature, exceptions, this.computeMaxs, this.computeFrames);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public byte[] toByteArray()
/*      */   {
/*  759 */     if (this.index > 65535) {
/*  760 */       throw new RuntimeException("Class file too large!");
/*      */     }
/*      */     
/*  763 */     int size = 24 + 2 * this.interfaceCount;
/*  764 */     int nbFields = 0;
/*  765 */     FieldWriter fb = this.firstField;
/*  766 */     while (fb != null) {
/*  767 */       nbFields++;
/*  768 */       size += fb.getSize();
/*  769 */       fb = (FieldWriter)fb.fv;
/*      */     }
/*  771 */     int nbMethods = 0;
/*  772 */     MethodWriter mb = this.firstMethod;
/*  773 */     while (mb != null) {
/*  774 */       nbMethods++;
/*  775 */       size += mb.getSize();
/*  776 */       mb = (MethodWriter)mb.mv;
/*      */     }
/*  778 */     int attributeCount = 0;
/*  779 */     if (this.bootstrapMethods != null)
/*      */     {
/*      */ 
/*  782 */       attributeCount++;
/*  783 */       size += 8 + this.bootstrapMethods.length;
/*  784 */       newUTF8("BootstrapMethods");
/*      */     }
/*  786 */     if (this.signature != 0) {
/*  787 */       attributeCount++;
/*  788 */       size += 8;
/*  789 */       newUTF8("Signature");
/*      */     }
/*  791 */     if (this.sourceFile != 0) {
/*  792 */       attributeCount++;
/*  793 */       size += 8;
/*  794 */       newUTF8("SourceFile");
/*      */     }
/*  796 */     if (this.sourceDebug != null) {
/*  797 */       attributeCount++;
/*  798 */       size += this.sourceDebug.length + 4;
/*  799 */       newUTF8("SourceDebugExtension");
/*      */     }
/*  801 */     if (this.enclosingMethodOwner != 0) {
/*  802 */       attributeCount++;
/*  803 */       size += 10;
/*  804 */       newUTF8("EnclosingMethod");
/*      */     }
/*  806 */     if ((this.access & 0x20000) != 0) {
/*  807 */       attributeCount++;
/*  808 */       size += 6;
/*  809 */       newUTF8("Deprecated");
/*      */     }
/*  811 */     if (((this.access & 0x1000) != 0) && (
/*  812 */       ((this.version & 0xFFFF) < 49) || ((this.access & 0x40000) != 0)))
/*      */     {
/*  814 */       attributeCount++;
/*  815 */       size += 6;
/*  816 */       newUTF8("Synthetic");
/*      */     }
/*      */     
/*  819 */     if (this.innerClasses != null) {
/*  820 */       attributeCount++;
/*  821 */       size += 8 + this.innerClasses.length;
/*  822 */       newUTF8("InnerClasses");
/*      */     }
/*  824 */     if (this.anns != null) {
/*  825 */       attributeCount++;
/*  826 */       size += 8 + this.anns.getSize();
/*  827 */       newUTF8("RuntimeVisibleAnnotations");
/*      */     }
/*  829 */     if (this.ianns != null) {
/*  830 */       attributeCount++;
/*  831 */       size += 8 + this.ianns.getSize();
/*  832 */       newUTF8("RuntimeInvisibleAnnotations");
/*      */     }
/*  834 */     if (this.attrs != null) {
/*  835 */       attributeCount += this.attrs.getCount();
/*  836 */       size += this.attrs.getSize(this, null, 0, -1, -1);
/*      */     }
/*  838 */     size += this.pool.length;
/*      */     
/*      */ 
/*  841 */     ByteVector out = new ByteVector(size);
/*  842 */     out.putInt(-889275714).putInt(this.version);
/*  843 */     out.putShort(this.index).putByteArray(this.pool.data, 0, this.pool.length);
/*  844 */     int mask = 0x60000 | (this.access & 0x40000) / 64;
/*      */     
/*  846 */     out.putShort(this.access & (mask ^ 0xFFFFFFFF)).putShort(this.name).putShort(this.superName);
/*  847 */     out.putShort(this.interfaceCount);
/*  848 */     for (int i = 0; i < this.interfaceCount; i++) {
/*  849 */       out.putShort(this.interfaces[i]);
/*      */     }
/*  851 */     out.putShort(nbFields);
/*  852 */     fb = this.firstField;
/*  853 */     while (fb != null) {
/*  854 */       fb.put(out);
/*  855 */       fb = (FieldWriter)fb.fv;
/*      */     }
/*  857 */     out.putShort(nbMethods);
/*  858 */     mb = this.firstMethod;
/*  859 */     while (mb != null) {
/*  860 */       mb.put(out);
/*  861 */       mb = (MethodWriter)mb.mv;
/*      */     }
/*  863 */     out.putShort(attributeCount);
/*  864 */     if (this.bootstrapMethods != null) {
/*  865 */       out.putShort(newUTF8("BootstrapMethods"));
/*  866 */       out.putInt(this.bootstrapMethods.length + 2).putShort(this.bootstrapMethodsCount);
/*      */       
/*  868 */       out.putByteArray(this.bootstrapMethods.data, 0, this.bootstrapMethods.length);
/*      */     }
/*  870 */     if (this.signature != 0) {
/*  871 */       out.putShort(newUTF8("Signature")).putInt(2).putShort(this.signature);
/*      */     }
/*  873 */     if (this.sourceFile != 0) {
/*  874 */       out.putShort(newUTF8("SourceFile")).putInt(2).putShort(this.sourceFile);
/*      */     }
/*  876 */     if (this.sourceDebug != null) {
/*  877 */       int len = this.sourceDebug.length - 2;
/*  878 */       out.putShort(newUTF8("SourceDebugExtension")).putInt(len);
/*  879 */       out.putByteArray(this.sourceDebug.data, 2, len);
/*      */     }
/*  881 */     if (this.enclosingMethodOwner != 0) {
/*  882 */       out.putShort(newUTF8("EnclosingMethod")).putInt(4);
/*  883 */       out.putShort(this.enclosingMethodOwner).putShort(this.enclosingMethod);
/*      */     }
/*  885 */     if ((this.access & 0x20000) != 0) {
/*  886 */       out.putShort(newUTF8("Deprecated")).putInt(0);
/*      */     }
/*  888 */     if (((this.access & 0x1000) != 0) && (
/*  889 */       ((this.version & 0xFFFF) < 49) || ((this.access & 0x40000) != 0)))
/*      */     {
/*  891 */       out.putShort(newUTF8("Synthetic")).putInt(0);
/*      */     }
/*      */     
/*  894 */     if (this.innerClasses != null) {
/*  895 */       out.putShort(newUTF8("InnerClasses"));
/*  896 */       out.putInt(this.innerClasses.length + 2).putShort(this.innerClassesCount);
/*  897 */       out.putByteArray(this.innerClasses.data, 0, this.innerClasses.length);
/*      */     }
/*  899 */     if (this.anns != null) {
/*  900 */       out.putShort(newUTF8("RuntimeVisibleAnnotations"));
/*  901 */       this.anns.put(out);
/*      */     }
/*  903 */     if (this.ianns != null) {
/*  904 */       out.putShort(newUTF8("RuntimeInvisibleAnnotations"));
/*  905 */       this.ianns.put(out);
/*      */     }
/*  907 */     if (this.attrs != null) {
/*  908 */       this.attrs.put(this, null, 0, -1, -1, out);
/*      */     }
/*  910 */     if (this.invalidFrames) {
/*  911 */       ClassWriter cw = new ClassWriter(2);
/*  912 */       new ClassReader(out.data).accept(cw, 4);
/*  913 */       return cw.toByteArray();
/*      */     }
/*  915 */     return out.data;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Item newConstItem(Object cst)
/*      */   {
/*  934 */     if ((cst instanceof Integer)) {
/*  935 */       int val = ((Integer)cst).intValue();
/*  936 */       return newInteger(val); }
/*  937 */     if ((cst instanceof Byte)) {
/*  938 */       int val = ((Byte)cst).intValue();
/*  939 */       return newInteger(val); }
/*  940 */     if ((cst instanceof Character)) {
/*  941 */       int val = ((Character)cst).charValue();
/*  942 */       return newInteger(val); }
/*  943 */     if ((cst instanceof Short)) {
/*  944 */       int val = ((Short)cst).intValue();
/*  945 */       return newInteger(val); }
/*  946 */     if ((cst instanceof Boolean)) {
/*  947 */       int val = ((Boolean)cst).booleanValue() ? 1 : 0;
/*  948 */       return newInteger(val); }
/*  949 */     if ((cst instanceof Float)) {
/*  950 */       float val = ((Float)cst).floatValue();
/*  951 */       return newFloat(val); }
/*  952 */     if ((cst instanceof Long)) {
/*  953 */       long val = ((Long)cst).longValue();
/*  954 */       return newLong(val); }
/*  955 */     if ((cst instanceof Double)) {
/*  956 */       double val = ((Double)cst).doubleValue();
/*  957 */       return newDouble(val); }
/*  958 */     if ((cst instanceof String))
/*  959 */       return newString((String)cst);
/*  960 */     if ((cst instanceof Type)) {
/*  961 */       Type t = (Type)cst;
/*  962 */       int s = t.getSort();
/*  963 */       if (s == 10)
/*  964 */         return newClassItem(t.getInternalName());
/*  965 */       if (s == 11) {
/*  966 */         return newMethodTypeItem(t.getDescriptor());
/*      */       }
/*  968 */       return newClassItem(t.getDescriptor());
/*      */     }
/*  970 */     if ((cst instanceof Handle)) {
/*  971 */       Handle h = (Handle)cst;
/*  972 */       return newHandleItem(h.tag, h.owner, h.name, h.desc);
/*      */     }
/*  974 */     throw new IllegalArgumentException("value " + cst);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int newConst(Object cst)
/*      */   {
/*  992 */     return newConstItem(cst).index;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int newUTF8(String value)
/*      */   {
/* 1006 */     this.key.set(1, value, null, null);
/* 1007 */     Item result = get(this.key);
/* 1008 */     if (result == null) {
/* 1009 */       this.pool.putByte(1).putUTF8(value);
/* 1010 */       result = new Item(this.index++, this.key);
/* 1011 */       put(result);
/*      */     }
/* 1013 */     return result.index;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Item newClassItem(String value)
/*      */   {
/* 1027 */     this.key2.set(7, value, null, null);
/* 1028 */     Item result = get(this.key2);
/* 1029 */     if (result == null) {
/* 1030 */       this.pool.put12(7, newUTF8(value));
/* 1031 */       result = new Item(this.index++, this.key2);
/* 1032 */       put(result);
/*      */     }
/* 1034 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int newClass(String value)
/*      */   {
/* 1048 */     return newClassItem(value).index;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Item newMethodTypeItem(String methodDesc)
/*      */   {
/* 1062 */     this.key2.set(16, methodDesc, null, null);
/* 1063 */     Item result = get(this.key2);
/* 1064 */     if (result == null) {
/* 1065 */       this.pool.put12(16, newUTF8(methodDesc));
/* 1066 */       result = new Item(this.index++, this.key2);
/* 1067 */       put(result);
/*      */     }
/* 1069 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int newMethodType(String methodDesc)
/*      */   {
/* 1084 */     return newMethodTypeItem(methodDesc).index;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Item newHandleItem(int tag, String owner, String name, String desc)
/*      */   {
/* 1111 */     this.key4.set(20 + tag, owner, name, desc);
/* 1112 */     Item result = get(this.key4);
/* 1113 */     if (result == null) {
/* 1114 */       if (tag <= 4) {
/* 1115 */         put112(15, tag, newField(owner, name, desc));
/*      */       } else {
/* 1117 */         put112(15, tag, newMethod(owner, name, desc, tag == 9));
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1122 */       result = new Item(this.index++, this.key4);
/* 1123 */       put(result);
/*      */     }
/* 1125 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int newHandle(int tag, String owner, String name, String desc)
/*      */   {
/* 1153 */     return newHandleItem(tag, owner, name, desc).index;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Item newInvokeDynamicItem(String name, String desc, Handle bsm, Object... bsmArgs)
/*      */   {
/* 1176 */     ByteVector bootstrapMethods = this.bootstrapMethods;
/* 1177 */     if (bootstrapMethods == null) {
/* 1178 */       bootstrapMethods = this.bootstrapMethods = new ByteVector();
/*      */     }
/*      */     
/* 1181 */     int position = bootstrapMethods.length;
/*      */     
/* 1183 */     int hashCode = bsm.hashCode();
/* 1184 */     bootstrapMethods.putShort(newHandle(bsm.tag, bsm.owner, bsm.name, bsm.desc));
/*      */     
/*      */ 
/* 1187 */     int argsLength = bsmArgs.length;
/* 1188 */     bootstrapMethods.putShort(argsLength);
/*      */     
/* 1190 */     for (int i = 0; i < argsLength; i++) {
/* 1191 */       Object bsmArg = bsmArgs[i];
/* 1192 */       hashCode ^= bsmArg.hashCode();
/* 1193 */       bootstrapMethods.putShort(newConst(bsmArg));
/*      */     }
/*      */     
/* 1196 */     byte[] data = bootstrapMethods.data;
/* 1197 */     int length = 2 + argsLength << 1;
/* 1198 */     hashCode &= 0x7FFFFFFF;
/* 1199 */     Item result = this.items[(hashCode % this.items.length)];
/* 1200 */     label246: while (result != null) {
/* 1201 */       if ((result.type != 33) || (result.hashCode != hashCode)) {
/* 1202 */         result = result.next;
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/* 1208 */         int resultPosition = result.intVal;
/* 1209 */         for (int p = 0;; p++) { if (p >= length) break label246;
/* 1210 */           if (data[(position + p)] != data[(resultPosition + p)]) {
/* 1211 */             result = result.next;
/* 1212 */             break;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */     int bootstrapMethodIndex;
/* 1219 */     if (result != null) {
/* 1220 */       int bootstrapMethodIndex = result.index;
/* 1221 */       bootstrapMethods.length = position;
/*      */     } else {
/* 1223 */       bootstrapMethodIndex = this.bootstrapMethodsCount++;
/* 1224 */       result = new Item(bootstrapMethodIndex);
/* 1225 */       result.set(position, hashCode);
/* 1226 */       put(result);
/*      */     }
/*      */     
/*      */ 
/* 1230 */     this.key3.set(name, desc, bootstrapMethodIndex);
/* 1231 */     result = get(this.key3);
/* 1232 */     if (result == null) {
/* 1233 */       put122(18, bootstrapMethodIndex, newNameType(name, desc));
/* 1234 */       result = new Item(this.index++, this.key3);
/* 1235 */       put(result);
/*      */     }
/* 1237 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int newInvokeDynamic(String name, String desc, Handle bsm, Object... bsmArgs)
/*      */   {
/* 1260 */     return newInvokeDynamicItem(name, desc, bsm, bsmArgs).index;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Item newFieldItem(String owner, String name, String desc)
/*      */   {
/* 1276 */     this.key3.set(9, owner, name, desc);
/* 1277 */     Item result = get(this.key3);
/* 1278 */     if (result == null) {
/* 1279 */       put122(9, newClass(owner), newNameType(name, desc));
/* 1280 */       result = new Item(this.index++, this.key3);
/* 1281 */       put(result);
/*      */     }
/* 1283 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int newField(String owner, String name, String desc)
/*      */   {
/* 1301 */     return newFieldItem(owner, name, desc).index;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Item newMethodItem(String owner, String name, String desc, boolean itf)
/*      */   {
/* 1320 */     int type = itf ? 11 : 10;
/* 1321 */     this.key3.set(type, owner, name, desc);
/* 1322 */     Item result = get(this.key3);
/* 1323 */     if (result == null) {
/* 1324 */       put122(type, newClass(owner), newNameType(name, desc));
/* 1325 */       result = new Item(this.index++, this.key3);
/* 1326 */       put(result);
/*      */     }
/* 1328 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int newMethod(String owner, String name, String desc, boolean itf)
/*      */   {
/* 1349 */     return newMethodItem(owner, name, desc, itf).index;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Item newInteger(int value)
/*      */   {
/* 1361 */     this.key.set(value);
/* 1362 */     Item result = get(this.key);
/* 1363 */     if (result == null) {
/* 1364 */       this.pool.putByte(3).putInt(value);
/* 1365 */       result = new Item(this.index++, this.key);
/* 1366 */       put(result);
/*      */     }
/* 1368 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Item newFloat(float value)
/*      */   {
/* 1380 */     this.key.set(value);
/* 1381 */     Item result = get(this.key);
/* 1382 */     if (result == null) {
/* 1383 */       this.pool.putByte(4).putInt(this.key.intVal);
/* 1384 */       result = new Item(this.index++, this.key);
/* 1385 */       put(result);
/*      */     }
/* 1387 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Item newLong(long value)
/*      */   {
/* 1399 */     this.key.set(value);
/* 1400 */     Item result = get(this.key);
/* 1401 */     if (result == null) {
/* 1402 */       this.pool.putByte(5).putLong(value);
/* 1403 */       result = new Item(this.index, this.key);
/* 1404 */       this.index += 2;
/* 1405 */       put(result);
/*      */     }
/* 1407 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Item newDouble(double value)
/*      */   {
/* 1419 */     this.key.set(value);
/* 1420 */     Item result = get(this.key);
/* 1421 */     if (result == null) {
/* 1422 */       this.pool.putByte(6).putLong(this.key.longVal);
/* 1423 */       result = new Item(this.index, this.key);
/* 1424 */       this.index += 2;
/* 1425 */       put(result);
/*      */     }
/* 1427 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Item newString(String value)
/*      */   {
/* 1439 */     this.key2.set(8, value, null, null);
/* 1440 */     Item result = get(this.key2);
/* 1441 */     if (result == null) {
/* 1442 */       this.pool.put12(8, newUTF8(value));
/* 1443 */       result = new Item(this.index++, this.key2);
/* 1444 */       put(result);
/*      */     }
/* 1446 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int newNameType(String name, String desc)
/*      */   {
/* 1462 */     return newNameTypeItem(name, desc).index;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Item newNameTypeItem(String name, String desc)
/*      */   {
/* 1476 */     this.key2.set(12, name, desc, null);
/* 1477 */     Item result = get(this.key2);
/* 1478 */     if (result == null) {
/* 1479 */       put122(12, newUTF8(name), newUTF8(desc));
/* 1480 */       result = new Item(this.index++, this.key2);
/* 1481 */       put(result);
/*      */     }
/* 1483 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   int addType(String type)
/*      */   {
/* 1495 */     this.key.set(30, type, null, null);
/* 1496 */     Item result = get(this.key);
/* 1497 */     if (result == null) {
/* 1498 */       result = addType(this.key);
/*      */     }
/* 1500 */     return result.index;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   int addUninitializedType(String type, int offset)
/*      */   {
/* 1516 */     this.key.type = 31;
/* 1517 */     this.key.intVal = offset;
/* 1518 */     this.key.strVal1 = type;
/* 1519 */     this.key.hashCode = (0x7FFFFFFF & 31 + type.hashCode() + offset);
/* 1520 */     Item result = get(this.key);
/* 1521 */     if (result == null) {
/* 1522 */       result = addType(this.key);
/*      */     }
/* 1524 */     return result.index;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Item addType(Item item)
/*      */   {
/* 1536 */     this.typeCount = ((short)(this.typeCount + 1));
/* 1537 */     Item result = new Item(this.typeCount, this.key);
/* 1538 */     put(result);
/* 1539 */     if (this.typeTable == null) {
/* 1540 */       this.typeTable = new Item[16];
/*      */     }
/* 1542 */     if (this.typeCount == this.typeTable.length) {
/* 1543 */       Item[] newTable = new Item[2 * this.typeTable.length];
/* 1544 */       System.arraycopy(this.typeTable, 0, newTable, 0, this.typeTable.length);
/* 1545 */       this.typeTable = newTable;
/*      */     }
/* 1547 */     this.typeTable[this.typeCount] = result;
/* 1548 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   int getMergedType(int type1, int type2)
/*      */   {
/* 1564 */     this.key2.type = 32;
/* 1565 */     this.key2.longVal = (type1 | type2 << 32);
/* 1566 */     this.key2.hashCode = (0x7FFFFFFF & 32 + type1 + type2);
/* 1567 */     Item result = get(this.key2);
/* 1568 */     if (result == null) {
/* 1569 */       String t = this.typeTable[type1].strVal1;
/* 1570 */       String u = this.typeTable[type2].strVal1;
/* 1571 */       this.key2.intVal = addType(getCommonSuperClass(t, u));
/* 1572 */       result = new Item(0, this.key2);
/* 1573 */       put(result);
/*      */     }
/* 1575 */     return result.intVal;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String getCommonSuperClass(String type1, String type2)
/*      */   {
/* 1596 */     ClassLoader classLoader = getClass().getClassLoader();
/*      */     Class<?> c;
/* 1598 */     Class<?> d; try { c = Class.forName(type1.replace('/', '.'), false, classLoader);
/* 1599 */       d = Class.forName(type2.replace('/', '.'), false, classLoader);
/*      */     } catch (Exception e) {
/* 1601 */       throw new RuntimeException(e.toString());
/*      */     }
/* 1603 */     if (c.isAssignableFrom(d)) {
/* 1604 */       return type1;
/*      */     }
/* 1606 */     if (d.isAssignableFrom(c)) {
/* 1607 */       return type2;
/*      */     }
/* 1609 */     if ((c.isInterface()) || (d.isInterface())) {
/* 1610 */       return "java/lang/Object";
/*      */     }
/*      */     do {
/* 1613 */       c = c.getSuperclass();
/* 1614 */     } while (!c.isAssignableFrom(d));
/* 1615 */     return c.getName().replace('.', '/');
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Item get(Item key)
/*      */   {
/* 1629 */     Item i = this.items[(key.hashCode % this.items.length)];
/* 1630 */     while ((i != null) && ((i.type != key.type) || (!key.isEqualTo(i)))) {
/* 1631 */       i = i.next;
/*      */     }
/* 1633 */     return i;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void put(Item i)
/*      */   {
/* 1644 */     if (this.index + this.typeCount > this.threshold) {
/* 1645 */       int ll = this.items.length;
/* 1646 */       int nl = ll * 2 + 1;
/* 1647 */       Item[] newItems = new Item[nl];
/* 1648 */       for (int l = ll - 1; l >= 0; l--) {
/* 1649 */         Item j = this.items[l];
/* 1650 */         while (j != null) {
/* 1651 */           int index = j.hashCode % newItems.length;
/* 1652 */           Item k = j.next;
/* 1653 */           j.next = newItems[index];
/* 1654 */           newItems[index] = j;
/* 1655 */           j = k;
/*      */         }
/*      */       }
/* 1658 */       this.items = newItems;
/* 1659 */       this.threshold = ((int)(nl * 0.75D));
/*      */     }
/* 1661 */     int index = i.hashCode % this.items.length;
/* 1662 */     i.next = this.items[index];
/* 1663 */     this.items[index] = i;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void put122(int b, int s1, int s2)
/*      */   {
/* 1677 */     this.pool.put12(b, s1).putShort(s2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void put112(int b1, int b2, int s)
/*      */   {
/* 1691 */     this.pool.put11(b1, b2).putShort(s);
/*      */   }
/*      */   
/*      */   public final void visitEnd() {}
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\asm\ClassWriter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */