/*     */ package clojure.asm;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ByteVector
/*     */ {
/*     */   byte[] data;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int length;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ByteVector()
/*     */   {
/*  55 */     this.data = new byte[64];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ByteVector(int initialSize)
/*     */   {
/*  66 */     this.data = new byte[initialSize];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ByteVector putByte(int b)
/*     */   {
/*  78 */     int length = this.length;
/*  79 */     if (length + 1 > this.data.length) {
/*  80 */       enlarge(1);
/*     */     }
/*  82 */     this.data[(length++)] = ((byte)b);
/*  83 */     this.length = length;
/*  84 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   ByteVector put11(int b1, int b2)
/*     */   {
/*  98 */     int length = this.length;
/*  99 */     if (length + 2 > this.data.length) {
/* 100 */       enlarge(2);
/*     */     }
/* 102 */     byte[] data = this.data;
/* 103 */     data[(length++)] = ((byte)b1);
/* 104 */     data[(length++)] = ((byte)b2);
/* 105 */     this.length = length;
/* 106 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ByteVector putShort(int s)
/*     */   {
/* 118 */     int length = this.length;
/* 119 */     if (length + 2 > this.data.length) {
/* 120 */       enlarge(2);
/*     */     }
/* 122 */     byte[] data = this.data;
/* 123 */     data[(length++)] = ((byte)(s >>> 8));
/* 124 */     data[(length++)] = ((byte)s);
/* 125 */     this.length = length;
/* 126 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   ByteVector put12(int b, int s)
/*     */   {
/* 140 */     int length = this.length;
/* 141 */     if (length + 3 > this.data.length) {
/* 142 */       enlarge(3);
/*     */     }
/* 144 */     byte[] data = this.data;
/* 145 */     data[(length++)] = ((byte)b);
/* 146 */     data[(length++)] = ((byte)(s >>> 8));
/* 147 */     data[(length++)] = ((byte)s);
/* 148 */     this.length = length;
/* 149 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ByteVector putInt(int i)
/*     */   {
/* 161 */     int length = this.length;
/* 162 */     if (length + 4 > this.data.length) {
/* 163 */       enlarge(4);
/*     */     }
/* 165 */     byte[] data = this.data;
/* 166 */     data[(length++)] = ((byte)(i >>> 24));
/* 167 */     data[(length++)] = ((byte)(i >>> 16));
/* 168 */     data[(length++)] = ((byte)(i >>> 8));
/* 169 */     data[(length++)] = ((byte)i);
/* 170 */     this.length = length;
/* 171 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ByteVector putLong(long l)
/*     */   {
/* 183 */     int length = this.length;
/* 184 */     if (length + 8 > this.data.length) {
/* 185 */       enlarge(8);
/*     */     }
/* 187 */     byte[] data = this.data;
/* 188 */     int i = (int)(l >>> 32);
/* 189 */     data[(length++)] = ((byte)(i >>> 24));
/* 190 */     data[(length++)] = ((byte)(i >>> 16));
/* 191 */     data[(length++)] = ((byte)(i >>> 8));
/* 192 */     data[(length++)] = ((byte)i);
/* 193 */     i = (int)l;
/* 194 */     data[(length++)] = ((byte)(i >>> 24));
/* 195 */     data[(length++)] = ((byte)(i >>> 16));
/* 196 */     data[(length++)] = ((byte)(i >>> 8));
/* 197 */     data[(length++)] = ((byte)i);
/* 198 */     this.length = length;
/* 199 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ByteVector putUTF8(String s)
/*     */   {
/* 211 */     int charLength = s.length();
/* 212 */     int len = this.length;
/* 213 */     if (len + 2 + charLength > this.data.length) {
/* 214 */       enlarge(2 + charLength);
/*     */     }
/* 216 */     byte[] data = this.data;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 223 */     data[(len++)] = ((byte)(charLength >>> 8));
/* 224 */     data[(len++)] = ((byte)charLength);
/* 225 */     for (int i = 0; i < charLength; i++) {
/* 226 */       char c = s.charAt(i);
/* 227 */       if ((c >= '\001') && (c <= '')) {
/* 228 */         data[(len++)] = ((byte)c);
/*     */       } else {
/* 230 */         int byteLength = i;
/* 231 */         for (int j = i; j < charLength; j++) {
/* 232 */           c = s.charAt(j);
/* 233 */           if ((c >= '\001') && (c <= '')) {
/* 234 */             byteLength++;
/* 235 */           } else if (c > '߿') {
/* 236 */             byteLength += 3;
/*     */           } else {
/* 238 */             byteLength += 2;
/*     */           }
/*     */         }
/* 241 */         data[this.length] = ((byte)(byteLength >>> 8));
/* 242 */         data[(this.length + 1)] = ((byte)byteLength);
/* 243 */         if (this.length + 2 + byteLength > data.length) {
/* 244 */           this.length = len;
/* 245 */           enlarge(2 + byteLength);
/* 246 */           data = this.data;
/*     */         }
/* 248 */         for (int j = i; j < charLength; j++) {
/* 249 */           c = s.charAt(j);
/* 250 */           if ((c >= '\001') && (c <= '')) {
/* 251 */             data[(len++)] = ((byte)c);
/* 252 */           } else if (c > '߿') {
/* 253 */             data[(len++)] = ((byte)(0xE0 | c >> '\f' & 0xF));
/* 254 */             data[(len++)] = ((byte)(0x80 | c >> '\006' & 0x3F));
/* 255 */             data[(len++)] = ((byte)(0x80 | c & 0x3F));
/*     */           } else {
/* 257 */             data[(len++)] = ((byte)(0xC0 | c >> '\006' & 0x1F));
/* 258 */             data[(len++)] = ((byte)(0x80 | c & 0x3F));
/*     */           }
/*     */         }
/* 261 */         break;
/*     */       }
/*     */     }
/* 264 */     this.length = len;
/* 265 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ByteVector putByteArray(byte[] b, int off, int len)
/*     */   {
/* 282 */     if (this.length + len > this.data.length) {
/* 283 */       enlarge(len);
/*     */     }
/* 285 */     if (b != null) {
/* 286 */       System.arraycopy(b, off, this.data, this.length, len);
/*     */     }
/* 288 */     this.length += len;
/* 289 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void enlarge(int size)
/*     */   {
/* 300 */     int length1 = 2 * this.data.length;
/* 301 */     int length2 = this.length + size;
/* 302 */     byte[] newData = new byte[length1 > length2 ? length1 : length2];
/* 303 */     System.arraycopy(this.data, 0, newData, 0, this.length);
/* 304 */     this.data = newData;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\asm\ByteVector.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */