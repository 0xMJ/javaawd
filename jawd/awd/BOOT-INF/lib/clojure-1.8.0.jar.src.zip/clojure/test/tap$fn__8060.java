/*     */ package clojure.test;
/*     */ 
/*     */ import clojure.lang.AFunction;
/*     */ import clojure.lang.ILookupThunk;
/*     */ import clojure.lang.KeywordLookupSite;
/*     */ import clojure.lang.RT;
/*     */ import clojure.lang.Var;
/*     */ 
/*     */ public final class tap$fn__8060
/*     */   extends AFunction
/*     */ {
/*     */   /* Error */
/*     */   public static Object invokeStatic(Object data)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: iconst_2
/*     */     //   1: anewarray 13	java/lang/Object
/*     */     //   4: dup
/*     */     //   5: iconst_0
/*     */     //   6: getstatic 17	clojure/test/tap$fn__8060:const__2	Lclojure/lang/Var;
/*     */     //   9: aastore
/*     */     //   10: dup
/*     */     //   11: iconst_1
/*     */     //   12: getstatic 20	clojure/test/tap$fn__8060:const__3	Lclojure/lang/Var;
/*     */     //   15: invokevirtual 26	clojure/lang/Var:get	()Ljava/lang/Object;
/*     */     //   18: aastore
/*     */     //   19: invokestatic 32	clojure/lang/ArraySeq:create	([Ljava/lang/Object;)Lclojure/lang/ArraySeq;
/*     */     //   22: invokestatic 37	clojure/core$hash_map:invokeStatic	(Lclojure/lang/ISeq;)Ljava/lang/Object;
/*     */     //   25: invokestatic 41	clojure/core$push_thread_bindings:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   28: pop
/*     */     //   29: getstatic 45	clojure/test/tap$fn__8060:__thunk__0__	Lclojure/lang/ILookupThunk;
/*     */     //   32: dup
/*     */     //   33: aload_0
/*     */     //   34: dup_x2
/*     */     //   35: invokeinterface 49 2 0
/*     */     //   40: dup_x2
/*     */     //   41: if_acmpeq +7 -> 48
/*     */     //   44: pop
/*     */     //   45: goto +25 -> 70
/*     */     //   48: swap
/*     */     //   49: pop
/*     */     //   50: dup
/*     */     //   51: getstatic 53	clojure/test/tap$fn__8060:__site__0__	Lclojure/lang/KeywordLookupSite;
/*     */     //   54: swap
/*     */     //   55: invokeinterface 59 2 0
/*     */     //   60: dup
/*     */     //   61: putstatic 45	clojure/test/tap$fn__8060:__thunk__0__	Lclojure/lang/ILookupThunk;
/*     */     //   64: swap
/*     */     //   65: invokeinterface 49 2 0
/*     */     //   70: getstatic 62	clojure/test/tap$fn__8060:__thunk__1__	Lclojure/lang/ILookupThunk;
/*     */     //   73: dup
/*     */     //   74: aload_0
/*     */     //   75: dup_x2
/*     */     //   76: invokeinterface 49 2 0
/*     */     //   81: dup_x2
/*     */     //   82: if_acmpeq +7 -> 89
/*     */     //   85: pop
/*     */     //   86: goto +25 -> 111
/*     */     //   89: swap
/*     */     //   90: pop
/*     */     //   91: dup
/*     */     //   92: getstatic 65	clojure/test/tap$fn__8060:__site__1__	Lclojure/lang/KeywordLookupSite;
/*     */     //   95: swap
/*     */     //   96: invokeinterface 59 2 0
/*     */     //   101: dup
/*     */     //   102: putstatic 62	clojure/test/tap$fn__8060:__thunk__1__	Lclojure/lang/ILookupThunk;
/*     */     //   105: swap
/*     */     //   106: invokeinterface 49 2 0
/*     */     //   111: invokestatic 71	clojure/lang/Numbers:add	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Number;
/*     */     //   114: getstatic 74	clojure/test/tap$fn__8060:__thunk__2__	Lclojure/lang/ILookupThunk;
/*     */     //   117: dup
/*     */     //   118: aload_0
/*     */     //   119: aconst_null
/*     */     //   120: astore_0
/*     */     //   121: dup_x2
/*     */     //   122: invokeinterface 49 2 0
/*     */     //   127: dup_x2
/*     */     //   128: if_acmpeq +7 -> 135
/*     */     //   131: pop
/*     */     //   132: goto +25 -> 157
/*     */     //   135: swap
/*     */     //   136: pop
/*     */     //   137: dup
/*     */     //   138: getstatic 77	clojure/test/tap$fn__8060:__site__2__	Lclojure/lang/KeywordLookupSite;
/*     */     //   141: swap
/*     */     //   142: invokeinterface 59 2 0
/*     */     //   147: dup
/*     */     //   148: putstatic 74	clojure/test/tap$fn__8060:__thunk__2__	Lclojure/lang/ILookupThunk;
/*     */     //   151: swap
/*     */     //   152: invokeinterface 49 2 0
/*     */     //   157: invokestatic 71	clojure/lang/Numbers:add	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Number;
/*     */     //   160: invokestatic 80	clojure/test/tap$print_tap_plan:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   163: astore_1
/*     */     //   164: invokestatic 84	clojure/core$pop_thread_bindings:invokeStatic	()Ljava/lang/Object;
/*     */     //   167: pop
/*     */     //   168: goto +10 -> 178
/*     */     //   171: astore_2
/*     */     //   172: invokestatic 84	clojure/core$pop_thread_bindings:invokeStatic	()Ljava/lang/Object;
/*     */     //   175: pop
/*     */     //   176: aload_2
/*     */     //   177: athrow
/*     */     //   178: aload_1
/*     */     //   179: areturn
/*     */     // Line number table:
/*     */     //   Java source line #112	-> byte code offset #0
/*     */     //   Java source line #114	-> byte code offset #29
/*     */     //   Java source line #114	-> byte code offset #34
/*     */     //   Java source line #114	-> byte code offset #70
/*     */     //   Java source line #114	-> byte code offset #75
/*     */     //   Java source line #114	-> byte code offset #111
/*     */     //   Java source line #114	-> byte code offset #114
/*     */     //   Java source line #114	-> byte code offset #121
/*     */     //   Java source line #114	-> byte code offset #157
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	179	0	data	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   29	164	171	finally
/*     */   }
/*     */   
/*     */   public Object invoke(Object paramObject)
/*     */   {
/* 112 */     paramObject = null;return invokeStatic(paramObject); } static ILookupThunk __thunk__2__ = __site__2__ = new KeywordLookupSite(RT.keyword(null, "error")); static final KeywordLookupSite __site__2__; static ILookupThunk __thunk__1__ = __site__1__ = new KeywordLookupSite(RT.keyword(null, "fail")); static final KeywordLookupSite __site__1__; static ILookupThunk __thunk__0__ = __site__0__ = new KeywordLookupSite(RT.keyword(null, "pass")); static final KeywordLookupSite __site__0__; public static final Var const__3 = (Var)RT.var("clojure.test", "*test-out*"); public static final Var const__2 = (Var)RT.var("clojure.core", "*out*");
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\test\tap$fn__8060.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */