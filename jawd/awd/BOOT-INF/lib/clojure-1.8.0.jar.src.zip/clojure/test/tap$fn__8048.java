/*    */ package clojure.test;
/*    */ 
/*    */ import clojure.lang.AFunction;
/*    */ import clojure.lang.RT;
/*    */ import clojure.lang.Var;
/*    */ 
/*    */ public final class tap$fn__8048
/*    */   extends AFunction
/*    */ {
/*    */   /* Error */
/*    */   public static Object invokeStatic(Object data)
/*    */   {
/*    */     // Byte code:
/*    */     //   0: iconst_2
/*    */     //   1: anewarray 13	java/lang/Object
/*    */     //   4: dup
/*    */     //   5: iconst_0
/*    */     //   6: getstatic 17	clojure/test/tap$fn__8048:const__2	Lclojure/lang/Var;
/*    */     //   9: aastore
/*    */     //   10: dup
/*    */     //   11: iconst_1
/*    */     //   12: getstatic 20	clojure/test/tap$fn__8048:const__3	Lclojure/lang/Var;
/*    */     //   15: invokevirtual 26	clojure/lang/Var:get	()Ljava/lang/Object;
/*    */     //   18: aastore
/*    */     //   19: invokestatic 32	clojure/lang/ArraySeq:create	([Ljava/lang/Object;)Lclojure/lang/ArraySeq;
/*    */     //   22: invokestatic 37	clojure/core$hash_map:invokeStatic	(Lclojure/lang/ISeq;)Ljava/lang/Object;
/*    */     //   25: invokestatic 41	clojure/core$push_thread_bindings:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   28: pop
/*    */     //   29: iconst_1
/*    */     //   30: anewarray 13	java/lang/Object
/*    */     //   33: dup
/*    */     //   34: iconst_0
/*    */     //   35: aload_0
/*    */     //   36: aconst_null
/*    */     //   37: astore_0
/*    */     //   38: aastore
/*    */     //   39: invokestatic 32	clojure/lang/ArraySeq:create	([Ljava/lang/Object;)Lclojure/lang/ArraySeq;
/*    */     //   42: invokestatic 44	clojure/core$pr_str:invokeStatic	(Lclojure/lang/ISeq;)Ljava/lang/Object;
/*    */     //   45: invokestatic 47	clojure/test/tap$print_tap_diagnostic:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   48: astore_1
/*    */     //   49: invokestatic 51	clojure/core$pop_thread_bindings:invokeStatic	()Ljava/lang/Object;
/*    */     //   52: pop
/*    */     //   53: goto +10 -> 63
/*    */     //   56: astore_2
/*    */     //   57: invokestatic 51	clojure/core$pop_thread_bindings:invokeStatic	()Ljava/lang/Object;
/*    */     //   60: pop
/*    */     //   61: aload_2
/*    */     //   62: athrow
/*    */     //   63: aload_1
/*    */     //   64: areturn
/*    */     // Line number table:
/*    */     //   Java source line #74	-> byte code offset #0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	signature
/*    */     //   0	64	0	data	Object
/*    */     //   48	16	1	localObject1	Object
/*    */     //   56	6	2	localObject2	Object
/*    */     // Exception table:
/*    */     //   from	to	target	type
/*    */     //   29	49	56	finally
/*    */   }
/*    */   
/*    */   public Object invoke(Object paramObject)
/*    */   {
/* 74 */     paramObject = null;return invokeStatic(paramObject); } public static final Var const__3 = (Var)RT.var("clojure.test", "*test-out*"); public static final Var const__2 = (Var)RT.var("clojure.core", "*out*");
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\test\tap$fn__8048.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */