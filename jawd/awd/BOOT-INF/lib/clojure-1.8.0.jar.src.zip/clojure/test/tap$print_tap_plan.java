/*    */ package clojure.test;
/*    */ 
/*    */ import clojure.core.println;
/*    */ import clojure.core.str;
/*    */ import clojure.lang.AFunction;
/*    */ import clojure.lang.ArraySeq;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class tap$print_tap_plan
/*    */   extends AFunction
/*    */ {
/*    */   public Object invoke(Object paramObject)
/*    */   {
/* 45 */     paramObject = null;return invokeStatic(paramObject); } public static Object invokeStatic(Object n) { Object[] tmp4_1 = new Object[1]; Object[] tmp12_9 = new Object[1];n = null;tmp12_9[0] = n;tmp4_1[0] = core.str.invokeStatic("1..", ArraySeq.create(tmp12_9));return core.println.invokeStatic(ArraySeq.create(tmp4_1));
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\test\tap$print_tap_plan.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */