/*    */ package clojure.test;
/*    */ 
/*    */ import clojure.lang.AFunction;
/*    */ import clojure.lang.IFn;
/*    */ import clojure.lang.RT;
/*    */ import clojure.lang.Var;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class junit$escape_xml$fn__8071
/*    */   extends AFunction
/*    */ {
/*    */   public Object invoke(Object p1__8070_SHARP_)
/*    */   {
/* 46 */     p1__8070_SHARP_ = null;return ((IFn)const__0.getRawRoot()).invoke(p1__8070_SHARP_, p1__8070_SHARP_); } public static final Var const__0 = (Var)RT.var("clojure.test.junit", "escape-xml-map");
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\test\junit$escape_xml$fn__8071.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */