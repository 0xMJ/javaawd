/*     */ package clojure.test;
/*     */ 
/*     */ import clojure.lang.AFunction;
/*     */ import clojure.lang.Keyword;
/*     */ import clojure.lang.RT;
/*     */ import clojure.lang.Var;
/*     */ 
/*     */ public final class junit$message_el
/*     */   extends AFunction
/*     */ {
/*     */   /* Error */
/*     */   public static Object invokeStatic(Object tag, Object message, Object expected_str, Object actual_str)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: invokestatic 16	clojure/test/junit$indent:invokeStatic	()Ljava/lang/Object;
/*     */     //   3: pop
/*     */     //   4: aload_0
/*     */     //   5: getstatic 22	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   8: iconst_1
/*     */     //   9: anewarray 24	java/lang/Object
/*     */     //   12: dup
/*     */     //   13: iconst_0
/*     */     //   14: aload_1
/*     */     //   15: dup
/*     */     //   16: ifnull +29 -> 45
/*     */     //   19: getstatic 22	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   22: if_acmpeq +24 -> 46
/*     */     //   25: iconst_2
/*     */     //   26: anewarray 24	java/lang/Object
/*     */     //   29: dup
/*     */     //   30: iconst_0
/*     */     //   31: getstatic 28	clojure/test/junit$message_el:const__2	Lclojure/lang/Keyword;
/*     */     //   34: aastore
/*     */     //   35: dup
/*     */     //   36: iconst_1
/*     */     //   37: aload_1
/*     */     //   38: aastore
/*     */     //   39: invokestatic 34	clojure/lang/RT:mapUniqueKeys	([Ljava/lang/Object;)Lclojure/lang/IPersistentMap;
/*     */     //   42: goto +7 -> 49
/*     */     //   45: pop
/*     */     //   46: getstatic 40	clojure/lang/PersistentArrayMap:EMPTY	Lclojure/lang/PersistentArrayMap;
/*     */     //   49: aastore
/*     */     //   50: invokestatic 46	clojure/lang/ArraySeq:create	([Ljava/lang/Object;)Lclojure/lang/ArraySeq;
/*     */     //   53: invokestatic 51	clojure/test/junit$start_element:invokeStatic	(Ljava/lang/Object;Ljava/lang/Object;Lclojure/lang/ISeq;)Ljava/lang/Object;
/*     */     //   56: pop
/*     */     //   57: getstatic 55	clojure/test/junit$message_el:const__5	Ljava/lang/Object;
/*     */     //   60: invokestatic 60	clojure/test$file_position:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   63: astore 4
/*     */     //   65: aload 4
/*     */     //   67: lconst_0
/*     */     //   68: invokestatic 64	clojure/lang/RT:intCast	(J)I
/*     */     //   71: aconst_null
/*     */     //   72: invokestatic 68	clojure/lang/RT:nth	(Ljava/lang/Object;ILjava/lang/Object;)Ljava/lang/Object;
/*     */     //   75: astore 5
/*     */     //   77: aload 4
/*     */     //   79: aconst_null
/*     */     //   80: astore 4
/*     */     //   82: lconst_1
/*     */     //   83: invokestatic 64	clojure/lang/RT:intCast	(J)I
/*     */     //   86: aconst_null
/*     */     //   87: invokestatic 68	clojure/lang/RT:nth	(Ljava/lang/Object;ILjava/lang/Object;)Ljava/lang/Object;
/*     */     //   90: astore 6
/*     */     //   92: getstatic 72	clojure/test/junit$message_el:const__10	Lclojure/lang/Var;
/*     */     //   95: invokevirtual 77	clojure/lang/Var:getRawRoot	()Ljava/lang/Object;
/*     */     //   98: ldc 79
/*     */     //   100: ldc 81
/*     */     //   102: iconst_1
/*     */     //   103: anewarray 24	java/lang/Object
/*     */     //   106: dup
/*     */     //   107: iconst_0
/*     */     //   108: aload_2
/*     */     //   109: aconst_null
/*     */     //   110: astore_2
/*     */     //   111: aastore
/*     */     //   112: invokestatic 46	clojure/lang/ArraySeq:create	([Ljava/lang/Object;)Lclojure/lang/ArraySeq;
/*     */     //   115: invokestatic 86	clojure/core$str:invokeStatic	(Ljava/lang/Object;Lclojure/lang/ISeq;)Ljava/lang/Object;
/*     */     //   118: ldc 88
/*     */     //   120: iconst_1
/*     */     //   121: anewarray 24	java/lang/Object
/*     */     //   124: dup
/*     */     //   125: iconst_0
/*     */     //   126: aload_3
/*     */     //   127: aconst_null
/*     */     //   128: astore_3
/*     */     //   129: aastore
/*     */     //   130: invokestatic 46	clojure/lang/ArraySeq:create	([Ljava/lang/Object;)Lclojure/lang/ArraySeq;
/*     */     //   133: invokestatic 86	clojure/core$str:invokeStatic	(Ljava/lang/Object;Lclojure/lang/ISeq;)Ljava/lang/Object;
/*     */     //   136: ldc 90
/*     */     //   138: iconst_3
/*     */     //   139: anewarray 24	java/lang/Object
/*     */     //   142: dup
/*     */     //   143: iconst_0
/*     */     //   144: aload 5
/*     */     //   146: aconst_null
/*     */     //   147: astore 5
/*     */     //   149: aastore
/*     */     //   150: dup
/*     */     //   151: iconst_1
/*     */     //   152: ldc 92
/*     */     //   154: aastore
/*     */     //   155: dup
/*     */     //   156: iconst_2
/*     */     //   157: aload 6
/*     */     //   159: aconst_null
/*     */     //   160: astore 6
/*     */     //   162: aastore
/*     */     //   163: invokestatic 46	clojure/lang/ArraySeq:create	([Ljava/lang/Object;)Lclojure/lang/ArraySeq;
/*     */     //   166: invokestatic 86	clojure/core$str:invokeStatic	(Ljava/lang/Object;Lclojure/lang/ISeq;)Ljava/lang/Object;
/*     */     //   169: invokestatic 97	clojure/lang/Tuple:create	(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Lclojure/lang/IPersistentVector;
/*     */     //   172: invokestatic 102	clojure/core$interpose:invokeStatic	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   175: invokestatic 105	clojure/core$apply:invokeStatic	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   178: astore 7
/*     */     //   180: aload_1
/*     */     //   181: dup
/*     */     //   182: ifnull +38 -> 220
/*     */     //   185: getstatic 22	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   188: if_acmpeq +33 -> 221
/*     */     //   191: aload_1
/*     */     //   192: aconst_null
/*     */     //   193: astore_1
/*     */     //   194: iconst_2
/*     */     //   195: anewarray 24	java/lang/Object
/*     */     //   198: dup
/*     */     //   199: iconst_0
/*     */     //   200: ldc 79
/*     */     //   202: aastore
/*     */     //   203: dup
/*     */     //   204: iconst_1
/*     */     //   205: aload 7
/*     */     //   207: aconst_null
/*     */     //   208: astore 7
/*     */     //   210: aastore
/*     */     //   211: invokestatic 46	clojure/lang/ArraySeq:create	([Ljava/lang/Object;)Lclojure/lang/ArraySeq;
/*     */     //   214: invokestatic 86	clojure/core$str:invokeStatic	(Ljava/lang/Object;Lclojure/lang/ISeq;)Ljava/lang/Object;
/*     */     //   217: goto +9 -> 226
/*     */     //   220: pop
/*     */     //   221: aload 7
/*     */     //   223: aconst_null
/*     */     //   224: astore 7
/*     */     //   226: invokestatic 112	clojure/test/junit$element_content:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   229: pop
/*     */     //   230: aload_0
/*     */     //   231: aconst_null
/*     */     //   232: astore_0
/*     */     //   233: getstatic 22	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   236: invokestatic 115	clojure/test/junit$finish_element:invokeStatic	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   239: pop
/*     */     //   240: getstatic 118	clojure/test/junit$message_el:const__13	Lclojure/lang/Var;
/*     */     //   243: invokevirtual 77	clojure/lang/Var:getRawRoot	()Ljava/lang/Object;
/*     */     //   246: checkcast 120	clojure/lang/IFn
/*     */     //   249: invokeinterface 123 1 0
/*     */     //   254: areturn
/*     */     // Line number table:
/*     */     //   Java source line #113	-> byte code offset #0
/*     */     //   Java source line #116	-> byte code offset #14
/*     */     //   Java source line #118	-> byte code offset #72
/*     */     //   Java source line #118	-> byte code offset #87
/*     */     //   Java source line #124	-> byte code offset #180
/*     */     //   Java source line #126	-> byte code offset #246
/*     */     //   Java source line #126	-> byte code offset #249
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	254	0	tag	Object
/*     */     //   0	254	1	message	Object
/*     */     //   0	254	2	expected_str	Object
/*     */     //   0	254	3	actual_str	Object
/*     */     //   65	161	4	vec__8100	Object
/*     */     //   77	149	5	file	Object
/*     */     //   92	134	6	line	Object
/*     */     //   180	46	7	detail	Object
/*     */   }
/*     */   
/*     */   public Object invoke(Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4)
/*     */   {
/* 113 */     paramObject1 = null;paramObject2 = null;paramObject3 = null;paramObject4 = null;return invokeStatic(paramObject1, paramObject2, paramObject3, paramObject4); } public static final Var const__13 = (Var)RT.var("clojure.core", "println"); public static final Var const__10 = (Var)RT.var("clojure.core", "str"); public static final Object const__5 = Long.valueOf(5L); public static final Keyword const__2 = (Keyword)RT.keyword(null, "message");
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\test\junit$message_el.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */