/*     */ package clojure.test;
/*     */ 
/*     */ import clojure.lang.AFn;
/*     */ import clojure.lang.AFunction;
/*     */ import clojure.lang.Keyword;
/*     */ import clojure.lang.RT;
/*     */ import clojure.lang.Var;
/*     */ 
/*     */ public final class junit$fn__8107
/*     */   extends AFunction
/*     */ {
/*     */   /* Error */
/*     */   public static Object invokeStatic()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: getstatic 15	clojure/test/junit$fn__8107:const__0	Lclojure/lang/Var;
/*     */     //   3: iconst_1
/*     */     //   4: invokevirtual 21	clojure/lang/Var:setDynamic	(Z)Lclojure/lang/Var;
/*     */     //   7: dup
/*     */     //   8: getstatic 25	clojure/test/junit$fn__8107:const__7	Lclojure/lang/AFn;
/*     */     //   11: checkcast 27	clojure/lang/IPersistentMap
/*     */     //   14: invokevirtual 31	clojure/lang/Var:setMeta	(Lclojure/lang/IPersistentMap;)V
/*     */     //   17: astore_0
/*     */     //   18: aload_0
/*     */     //   19: checkcast 17	clojure/lang/Var
/*     */     //   22: invokevirtual 35	clojure/lang/Var:hasRoot	()Z
/*     */     //   25: istore_1
/*     */     //   26: iload_1
/*     */     //   27: ifeq +16 -> 43
/*     */     //   30: aload_0
/*     */     //   31: aconst_null
/*     */     //   32: astore_0
/*     */     //   33: invokestatic 40	clojure/core$deref:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   36: instanceof 42
/*     */     //   39: goto +5 -> 44
/*     */     //   42: pop
/*     */     //   43: iload_1
/*     */     //   44: ifeq +8 -> 52
/*     */     //   47: aconst_null
/*     */     //   48: goto +52 -> 100
/*     */     //   51: pop
/*     */     //   52: getstatic 15	clojure/test/junit$fn__8107:const__0	Lclojure/lang/Var;
/*     */     //   55: iconst_1
/*     */     //   56: invokevirtual 21	clojure/lang/Var:setDynamic	(Z)Lclojure/lang/Var;
/*     */     //   59: dup
/*     */     //   60: getstatic 47	clojure/test/junit$fn__8107:const__12	Lclojure/lang/AFn;
/*     */     //   63: checkcast 27	clojure/lang/IPersistentMap
/*     */     //   66: invokevirtual 31	clojure/lang/Var:setMeta	(Lclojure/lang/IPersistentMap;)V
/*     */     //   69: dup
/*     */     //   70: new 42	clojure/lang/MultiFn
/*     */     //   73: dup
/*     */     //   74: ldc 49
/*     */     //   76: checkcast 51	java/lang/String
/*     */     //   79: getstatic 55	clojure/test/junit$fn__8107:const__13	Lclojure/lang/Keyword;
/*     */     //   82: checkcast 57	clojure/lang/IFn
/*     */     //   85: getstatic 60	clojure/test/junit$fn__8107:const__14	Lclojure/lang/Keyword;
/*     */     //   88: getstatic 63	clojure/test/junit$fn__8107:const__15	Lclojure/lang/Var;
/*     */     //   91: checkcast 65	clojure/lang/IRef
/*     */     //   94: invokespecial 68	clojure/lang/MultiFn:<init>	(Ljava/lang/String;Lclojure/lang/IFn;Ljava/lang/Object;Lclojure/lang/IRef;)V
/*     */     //   97: invokevirtual 72	clojure/lang/Var:bindRoot	(Ljava/lang/Object;)V
/*     */     //   100: areturn
/*     */     // Line number table:
/*     */     //   Java source line #142	-> byte code offset #0
/*     */     //   Java source line #142	-> byte code offset #18
/*     */     //   Java source line #142	-> byte code offset #22
/*     */     //   Java source line #142	-> byte code offset #26
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   18	82	0	v__4645__auto__8110	Object
/*     */     //   26	18	1	and__4467__auto__8109	boolean
/*     */   }
/*     */   
/* 142 */   public Object invoke() { return invokeStatic(); } public static final Var const__15 = (Var)RT.var("clojure.core", "global-hierarchy"); public static final Keyword const__14 = (Keyword)RT.keyword(null, "default"); public static final Keyword const__13 = (Keyword)RT.keyword(null, "type"); public static final AFn const__12 = (AFn)RT.map(new Object[] { RT.keyword(null, "dynamic"), Boolean.TRUE, RT.keyword(null, "line"), Integer.valueOf(142), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/test/junit.clj" }); public static final AFn const__7 = (AFn)RT.map(new Object[] { RT.keyword(null, "dynamic"), Boolean.TRUE, RT.keyword(null, "line"), Integer.valueOf(142), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/test/junit.clj" }); public static final Var const__0 = (Var)RT.var("clojure.test.junit", "junit-report");
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\test\junit$fn__8107.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */