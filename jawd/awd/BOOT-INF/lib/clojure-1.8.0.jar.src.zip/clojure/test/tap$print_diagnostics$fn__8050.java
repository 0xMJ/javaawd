/*    */ package clojure.test;
/*    */ 
/*    */ import clojure.lang.AFunction;
/*    */ import clojure.lang.ILookupThunk;
/*    */ import clojure.lang.KeywordLookupSite;
/*    */ import clojure.lang.RT;
/*    */ import clojure.lang.Var;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class tap$print_diagnostics$fn__8050
/*    */   extends AFunction
/*    */ {
/*    */   public tap$print_diagnostics$fn__8050(Object paramObject1, Object paramObject2)
/*    */   {
/* 89 */     this.data = paramObject1;this.s__5244__auto__ = paramObject2; } static ILookupThunk __thunk__2__ = __site__2__ = new KeywordLookupSite(RT.keyword(null, "actual")); static final KeywordLookupSite __site__2__; static ILookupThunk __thunk__1__ = __site__1__ = new KeywordLookupSite(RT.keyword(null, "actual")); static final KeywordLookupSite __site__1__; static ILookupThunk __thunk__0__ = __site__0__ = new KeywordLookupSite(RT.keyword(null, "actual")); static final KeywordLookupSite __site__0__; public static final Var const__4 = (Var)RT.var("clojure.test", "*stack-trace-depth*");
/*    */   Object s__5244__auto__;
/*    */   Object data;
/*    */   
/*    */   /* Error */
/*    */   public Object invoke()
/*    */   {
/*    */     // Byte code:
/*    */     //   0: getstatic 23	clojure/test/tap$print_diagnostics$fn__8050:__thunk__0__	Lclojure/lang/ILookupThunk;
/*    */     //   3: dup
/*    */     //   4: aload_0
/*    */     //   5: getfield 15	clojure/test/tap$print_diagnostics$fn__8050:data	Ljava/lang/Object;
/*    */     //   8: dup_x2
/*    */     //   9: invokeinterface 29 2 0
/*    */     //   14: dup_x2
/*    */     //   15: if_acmpeq +7 -> 22
/*    */     //   18: pop
/*    */     //   19: goto +25 -> 44
/*    */     //   22: swap
/*    */     //   23: pop
/*    */     //   24: dup
/*    */     //   25: getstatic 33	clojure/test/tap$print_diagnostics$fn__8050:__site__0__	Lclojure/lang/KeywordLookupSite;
/*    */     //   28: swap
/*    */     //   29: invokeinterface 39 2 0
/*    */     //   34: dup
/*    */     //   35: putstatic 23	clojure/test/tap$print_diagnostics$fn__8050:__thunk__0__	Lclojure/lang/ILookupThunk;
/*    */     //   38: swap
/*    */     //   39: invokeinterface 29 2 0
/*    */     //   44: instanceof 41
/*    */     //   47: ifeq +61 -> 108
/*    */     //   50: getstatic 44	clojure/test/tap$print_diagnostics$fn__8050:__thunk__1__	Lclojure/lang/ILookupThunk;
/*    */     //   53: dup
/*    */     //   54: aload_0
/*    */     //   55: getfield 15	clojure/test/tap$print_diagnostics$fn__8050:data	Ljava/lang/Object;
/*    */     //   58: dup_x2
/*    */     //   59: invokeinterface 29 2 0
/*    */     //   64: dup_x2
/*    */     //   65: if_acmpeq +7 -> 72
/*    */     //   68: pop
/*    */     //   69: goto +25 -> 94
/*    */     //   72: swap
/*    */     //   73: pop
/*    */     //   74: dup
/*    */     //   75: getstatic 47	clojure/test/tap$print_diagnostics$fn__8050:__site__1__	Lclojure/lang/KeywordLookupSite;
/*    */     //   78: swap
/*    */     //   79: invokeinterface 39 2 0
/*    */     //   84: dup
/*    */     //   85: putstatic 44	clojure/test/tap$print_diagnostics$fn__8050:__thunk__1__	Lclojure/lang/ILookupThunk;
/*    */     //   88: swap
/*    */     //   89: invokeinterface 29 2 0
/*    */     //   94: getstatic 51	clojure/test/tap$print_diagnostics$fn__8050:const__4	Lclojure/lang/Var;
/*    */     //   97: invokevirtual 55	clojure/lang/Var:get	()Ljava/lang/Object;
/*    */     //   100: invokestatic 61	clojure/stacktrace$print_cause_trace:invokeStatic	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   103: pop
/*    */     //   104: goto +62 -> 166
/*    */     //   107: pop
/*    */     //   108: iconst_1
/*    */     //   109: anewarray 63	java/lang/Object
/*    */     //   112: dup
/*    */     //   113: iconst_0
/*    */     //   114: getstatic 66	clojure/test/tap$print_diagnostics$fn__8050:__thunk__2__	Lclojure/lang/ILookupThunk;
/*    */     //   117: dup
/*    */     //   118: aload_0
/*    */     //   119: getfield 15	clojure/test/tap$print_diagnostics$fn__8050:data	Ljava/lang/Object;
/*    */     //   122: dup_x2
/*    */     //   123: invokeinterface 29 2 0
/*    */     //   128: dup_x2
/*    */     //   129: if_acmpeq +7 -> 136
/*    */     //   132: pop
/*    */     //   133: goto +25 -> 158
/*    */     //   136: swap
/*    */     //   137: pop
/*    */     //   138: dup
/*    */     //   139: getstatic 69	clojure/test/tap$print_diagnostics$fn__8050:__site__2__	Lclojure/lang/KeywordLookupSite;
/*    */     //   142: swap
/*    */     //   143: invokeinterface 39 2 0
/*    */     //   148: dup
/*    */     //   149: putstatic 66	clojure/test/tap$print_diagnostics$fn__8050:__thunk__2__	Lclojure/lang/ILookupThunk;
/*    */     //   152: swap
/*    */     //   153: invokeinterface 29 2 0
/*    */     //   158: aastore
/*    */     //   159: invokestatic 75	clojure/lang/ArraySeq:create	([Ljava/lang/Object;)Lclojure/lang/ArraySeq;
/*    */     //   162: invokestatic 80	clojure/core$prn:invokeStatic	(Lclojure/lang/ISeq;)Ljava/lang/Object;
/*    */     //   165: pop
/*    */     //   166: aload_0
/*    */     //   167: getfield 17	clojure/test/tap$print_diagnostics$fn__8050:s__5244__auto__	Ljava/lang/Object;
/*    */     //   170: invokestatic 84	clojure/core$str:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   173: astore_1
/*    */     //   174: invokestatic 88	clojure/core$pop_thread_bindings:invokeStatic	()Ljava/lang/Object;
/*    */     //   177: pop
/*    */     //   178: goto +10 -> 188
/*    */     //   181: astore_2
/*    */     //   182: invokestatic 88	clojure/core$pop_thread_bindings:invokeStatic	()Ljava/lang/Object;
/*    */     //   185: pop
/*    */     //   186: aload_2
/*    */     //   187: athrow
/*    */     //   188: aload_1
/*    */     //   189: areturn
/*    */     // Line number table:
/*    */     //   Java source line #89	-> byte code offset #0
/*    */     //   Java source line #90	-> byte code offset #0
/*    */     //   Java source line #90	-> byte code offset #0
/*    */     //   Java source line #90	-> byte code offset #8
/*    */     //   Java source line #91	-> byte code offset #50
/*    */     //   Java source line #91	-> byte code offset #58
/*    */     //   Java source line #92	-> byte code offset #114
/*    */     //   Java source line #92	-> byte code offset #122
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	signature
/*    */     //   0	189	0	this	Object
/*    */     // Exception table:
/*    */     //   from	to	target	type
/*    */     //   0	174	181	finally
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\test\tap$print_diagnostics$fn__8050.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */