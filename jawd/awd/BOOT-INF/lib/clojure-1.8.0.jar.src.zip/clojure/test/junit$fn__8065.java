/*    */ package clojure.test;
/*    */ 
/*    */ import clojure.core.deref;
/*    */ import clojure.lang.AFn;
/*    */ import clojure.lang.AFunction;
/*    */ import clojure.lang.ArraySeq;
/*    */ import clojure.lang.IObj;
/*    */ import clojure.lang.IPersistentMap;
/*    */ import clojure.lang.RT;
/*    */ import clojure.lang.Symbol;
/*    */ import clojure.lang.Var;
/*    */ 
/*    */ 
/*    */ public final class junit$fn__8065
/*    */   extends AFunction
/*    */ {
/* 17 */   public Object invoke() { return invokeStatic(); } public static Object invokeStatic() { return clojure.core.commute.invokeStatic(core.deref.invokeStatic(const__2), const__3.getRawRoot(), ArraySeq.create(new Object[] { const__4 })); } public static final AFn const__4 = (AFn)((IObj)Symbol.intern(null, "clojure.test.junit")).withMeta((IPersistentMap)RT.map(new Object[] { RT.keyword(null, "doc"), "clojure.test extension for JUnit-compatible XML output.\n\n  JUnit (http://junit.org/) is the most popular unit-testing library\n  for Java.  As such, tool support for JUnit output formats is\n  common.  By producing compatible output from tests, this tool\n  support can be exploited.\n\n  To use, wrap any calls to clojure.test/run-tests in the\n  with-junit-output macro, like this:\n\n    (use 'clojure.test)\n    (use 'clojure.test.junit)\n\n    (with-junit-output\n      (run-tests 'my.cool.library))\n\n  To write the output to a file, rebind clojure.test/*test-out* to\n  your own PrintWriter (perhaps opened using\n  clojure.java.io/writer).", RT.keyword(null, "author"), "Jason Sankey" })); public static final Var const__3 = (Var)RT.var("clojure.core", "conj"); public static final Var const__2 = (Var)RT.var("clojure.core", "*loaded-libs*");
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\test\junit$fn__8065.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */