/*    */ package clojure.test;
/*    */ 
/*    */ import clojure.lang.AFunction;
/*    */ import clojure.lang.Keyword;
/*    */ import clojure.lang.RT;
/*    */ 
/*    */ public final class junit$suite_attrs
/*    */   extends AFunction
/*    */ {
/*    */   /* Error */
/*    */   public static Object invokeStatic(Object package, Object classname)
/*    */   {
/*    */     // Byte code:
/*    */     //   0: iconst_2
/*    */     //   1: anewarray 13	java/lang/Object
/*    */     //   4: dup
/*    */     //   5: iconst_0
/*    */     //   6: getstatic 17	clojure/test/junit$suite_attrs:const__0	Lclojure/lang/Keyword;
/*    */     //   9: aastore
/*    */     //   10: dup
/*    */     //   11: iconst_1
/*    */     //   12: aload_1
/*    */     //   13: aconst_null
/*    */     //   14: astore_1
/*    */     //   15: aastore
/*    */     //   16: invokestatic 23	clojure/lang/RT:mapUniqueKeys	([Ljava/lang/Object;)Lclojure/lang/IPersistentMap;
/*    */     //   19: astore_2
/*    */     //   20: aload_0
/*    */     //   21: dup
/*    */     //   22: ifnull +24 -> 46
/*    */     //   25: getstatic 29	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*    */     //   28: if_acmpeq +19 -> 47
/*    */     //   31: aload_2
/*    */     //   32: aconst_null
/*    */     //   33: astore_2
/*    */     //   34: getstatic 32	clojure/test/junit$suite_attrs:const__2	Lclojure/lang/Keyword;
/*    */     //   37: aload_0
/*    */     //   38: aconst_null
/*    */     //   39: astore_0
/*    */     //   40: invokestatic 37	clojure/core$assoc__4371:invokeStatic	(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   43: goto +7 -> 50
/*    */     //   46: pop
/*    */     //   47: aload_2
/*    */     //   48: aconst_null
/*    */     //   49: astore_2
/*    */     //   50: areturn
/*    */     // Line number table:
/*    */     //   Java source line #97	-> byte code offset #0
/*    */     //   Java source line #100	-> byte code offset #20
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	signature
/*    */     //   0	50	0	package	Object
/*    */     //   0	50	1	classname	Object
/*    */     //   20	30	2	attrs	Object
/*    */   }
/*    */   
/*    */   public Object invoke(Object paramObject1, Object paramObject2)
/*    */   {
/* 97 */     paramObject1 = null;paramObject2 = null;return invokeStatic(paramObject1, paramObject2); } public static final Keyword const__2 = (Keyword)RT.keyword(null, "package"); public static final Keyword const__0 = (Keyword)RT.keyword(null, "name");
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\test\junit$suite_attrs.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */