/*     */ package clojure.test;
/*     */ 
/*     */ import clojure.lang.AFunction;
/*     */ import clojure.lang.ILookupThunk;
/*     */ import clojure.lang.KeywordLookupSite;
/*     */ import clojure.lang.RT;
/*     */ import clojure.lang.Var;
/*     */ 
/*     */ public final class junit$fn__8111
/*     */   extends AFunction
/*     */ {
/*     */   /* Error */
/*     */   public static Object invokeStatic(Object m)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: iconst_2
/*     */     //   1: anewarray 13	java/lang/Object
/*     */     //   4: dup
/*     */     //   5: iconst_0
/*     */     //   6: getstatic 17	clojure/test/junit$fn__8111:const__2	Lclojure/lang/Var;
/*     */     //   9: aastore
/*     */     //   10: dup
/*     */     //   11: iconst_1
/*     */     //   12: getstatic 20	clojure/test/junit$fn__8111:const__3	Lclojure/lang/Var;
/*     */     //   15: invokevirtual 26	clojure/lang/Var:get	()Ljava/lang/Object;
/*     */     //   18: aastore
/*     */     //   19: invokestatic 32	clojure/lang/ArraySeq:create	([Ljava/lang/Object;)Lclojure/lang/ArraySeq;
/*     */     //   22: invokestatic 37	clojure/core$hash_map:invokeStatic	(Lclojure/lang/ISeq;)Ljava/lang/Object;
/*     */     //   25: invokestatic 41	clojure/core$push_thread_bindings:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   28: pop
/*     */     //   29: getstatic 45	clojure/test/junit$fn__8111:__thunk__0__	Lclojure/lang/ILookupThunk;
/*     */     //   32: dup
/*     */     //   33: aload_0
/*     */     //   34: aconst_null
/*     */     //   35: astore_0
/*     */     //   36: dup_x2
/*     */     //   37: invokeinterface 49 2 0
/*     */     //   42: dup_x2
/*     */     //   43: if_acmpeq +7 -> 50
/*     */     //   46: pop
/*     */     //   47: goto +25 -> 72
/*     */     //   50: swap
/*     */     //   51: pop
/*     */     //   52: dup
/*     */     //   53: getstatic 53	clojure/test/junit$fn__8111:__site__0__	Lclojure/lang/KeywordLookupSite;
/*     */     //   56: swap
/*     */     //   57: invokeinterface 59 2 0
/*     */     //   62: dup
/*     */     //   63: putstatic 45	clojure/test/junit$fn__8111:__thunk__0__	Lclojure/lang/ILookupThunk;
/*     */     //   66: swap
/*     */     //   67: invokeinterface 49 2 0
/*     */     //   72: invokestatic 62	clojure/core$ns_name:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   75: invokestatic 65	clojure/core$name:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   78: invokestatic 68	clojure/test/junit$start_suite:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   81: astore_1
/*     */     //   82: invokestatic 72	clojure/core$pop_thread_bindings:invokeStatic	()Ljava/lang/Object;
/*     */     //   85: pop
/*     */     //   86: goto +10 -> 96
/*     */     //   89: astore_2
/*     */     //   90: invokestatic 72	clojure/core$pop_thread_bindings:invokeStatic	()Ljava/lang/Object;
/*     */     //   93: pop
/*     */     //   94: aload_2
/*     */     //   95: athrow
/*     */     //   96: aload_1
/*     */     //   97: areturn
/*     */     // Line number table:
/*     */     //   Java source line #144	-> byte code offset #0
/*     */     //   Java source line #146	-> byte code offset #29
/*     */     //   Java source line #146	-> byte code offset #36
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	97	0	m	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   29	82	89	finally
/*     */   }
/*     */   
/*     */   public Object invoke(Object paramObject)
/*     */   {
/* 144 */     paramObject = null;return invokeStatic(paramObject); } static ILookupThunk __thunk__0__ = __site__0__ = new KeywordLookupSite(RT.keyword(null, "ns")); static final KeywordLookupSite __site__0__; public static final Var const__3 = (Var)RT.var("clojure.test", "*test-out*"); public static final Var const__2 = (Var)RT.var("clojure.core", "*out*");
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\test\junit$fn__8111.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */