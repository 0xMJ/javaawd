/*    */ package clojure.test;
/*    */ 
/*    */ import clojure.lang.AFn;
/*    */ import clojure.lang.AFunction;
/*    */ import clojure.lang.RT;
/*    */ import clojure.lang.Symbol;
/*    */ import clojure.lang.Tuple;
/*    */ import clojure.lang.Var;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class tap$loading__5569__auto____8030
/*    */   extends AFunction
/*    */ {
/* 23 */   public static final AFn const__4 = (AFn)Tuple.create(Symbol.intern(null, "clojure.stacktrace"), RT.keyword(null, "as"), Symbol.intern(null, "stack")); public static final AFn const__3 = (AFn)Tuple.create(Symbol.intern(null, "clojure.test"), RT.keyword(null, "as"), Symbol.intern(null, "t")); public static final AFn const__1 = (AFn)Symbol.intern(null, "clojure.core"); public static final Var const__0 = (Var)RT.var("clojure.core", "refer");
/*    */   
/*    */   /* Error */
/*    */   public Object invoke()
/*    */   {
/*    */     // Byte code:
/*    */     //   0: iconst_2
/*    */     //   1: anewarray 13	java/lang/Object
/*    */     //   4: dup
/*    */     //   5: iconst_0
/*    */     //   6: getstatic 19	clojure/lang/Compiler:LOADER	Lclojure/lang/Var;
/*    */     //   9: aastore
/*    */     //   10: dup
/*    */     //   11: iconst_1
/*    */     //   12: aload_0
/*    */     //   13: invokevirtual 23	java/lang/Object:getClass	()Ljava/lang/Class;
/*    */     //   16: checkcast 25	java/lang/Class
/*    */     //   19: invokevirtual 29	java/lang/Class:getClassLoader	()Ljava/lang/ClassLoader;
/*    */     //   22: aastore
/*    */     //   23: invokestatic 35	clojure/lang/RT:mapUniqueKeys	([Ljava/lang/Object;)Lclojure/lang/IPersistentMap;
/*    */     //   26: checkcast 37	clojure/lang/Associative
/*    */     //   29: invokestatic 43	clojure/lang/Var:pushThreadBindings	(Lclojure/lang/Associative;)V
/*    */     //   32: getstatic 46	clojure/test/tap$loading__5569__auto____8030:const__0	Lclojure/lang/Var;
/*    */     //   35: invokevirtual 49	clojure/lang/Var:getRawRoot	()Ljava/lang/Object;
/*    */     //   38: checkcast 51	clojure/lang/IFn
/*    */     //   41: getstatic 55	clojure/test/tap$loading__5569__auto____8030:const__1	Lclojure/lang/AFn;
/*    */     //   44: invokeinterface 58 2 0
/*    */     //   49: pop
/*    */     //   50: iconst_2
/*    */     //   51: anewarray 13	java/lang/Object
/*    */     //   54: dup
/*    */     //   55: iconst_0
/*    */     //   56: getstatic 61	clojure/test/tap$loading__5569__auto____8030:const__3	Lclojure/lang/AFn;
/*    */     //   59: aastore
/*    */     //   60: dup
/*    */     //   61: iconst_1
/*    */     //   62: getstatic 64	clojure/test/tap$loading__5569__auto____8030:const__4	Lclojure/lang/AFn;
/*    */     //   65: aastore
/*    */     //   66: invokestatic 70	clojure/lang/ArraySeq:create	([Ljava/lang/Object;)Lclojure/lang/ArraySeq;
/*    */     //   69: invokestatic 76	clojure/core$require:invokeStatic	(Lclojure/lang/ISeq;)Ljava/lang/Object;
/*    */     //   72: astore_1
/*    */     //   73: invokestatic 79	clojure/lang/Var:popThreadBindings	()V
/*    */     //   76: goto +9 -> 85
/*    */     //   79: astore_2
/*    */     //   80: invokestatic 79	clojure/lang/Var:popThreadBindings	()V
/*    */     //   83: aload_2
/*    */     //   84: athrow
/*    */     //   85: aload_1
/*    */     //   86: areturn
/*    */     // Line number table:
/*    */     //   Java source line #23	-> byte code offset #0
/*    */     //   Java source line #23	-> byte code offset #6
/*    */     //   Java source line #23	-> byte code offset #13
/*    */     //   Java source line #23	-> byte code offset #19
/*    */     //   Java source line #23	-> byte code offset #29
/*    */     //   Java source line #23	-> byte code offset #38
/*    */     //   Java source line #23	-> byte code offset #44
/*    */     //   Java source line #23	-> byte code offset #73
/*    */     //   Java source line #23	-> byte code offset #80
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	signature
/*    */     //   0	86	0	this	Object
/*    */     //   72	14	1	localObject1	Object
/*    */     //   79	5	2	localObject2	Object
/*    */     // Exception table:
/*    */     //   from	to	target	type
/*    */     //   32	73	79	finally
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\test\tap$loading__5569__auto____8030.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */