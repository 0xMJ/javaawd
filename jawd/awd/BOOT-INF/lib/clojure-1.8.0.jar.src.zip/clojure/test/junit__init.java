/*     */ package clojure.test;
/*     */ 
/*     */ import clojure.lang.RT;
/*     */ import clojure.lang.Var;
/*     */ 
/*     */ public class junit__init
/*     */ {
/*     */   public static final Var const__0;
/*     */   public static final clojure.lang.AFn const__1;
/*     */   public static final clojure.lang.AFn const__4;
/*     */   public static final clojure.lang.AFn const__5;
/*     */   public static final Var const__6;
/*     */   public static final clojure.lang.AFn const__13;
/*     */   
/*     */   public static void load()
/*     */   {
/*  17 */     if (((clojure.lang.Symbol)const__1).equals(const__5)) { tmpTernaryOp = null; break label88; ((clojure.lang.IFn)new junit.loading__5569__auto____8063()).invoke(); } else { clojure.lang.LockingTransaction.runInTransaction((java.util.concurrent.Callable)new junit.fn__8065()); } label88: tmp91_88 = const__6; tmp91_88.setMeta((clojure.lang.IPersistentMap)const__13);tmp91_88
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  44 */       .bindRoot(((clojure.lang.IFn)const__14.getRawRoot()).invoke("'<>\"&", ((clojure.lang.IFn)const__15.getRawRoot()).invoke(new junit.fn__8068(), const__16))); Var tmp148_145 = const__17;tmp148_145.setMeta((clojure.lang.IPersistentMap)const__21);tmp148_145.bindRoot(new junit.escape_xml());const__22.setDynamic(true).setMeta((clojure.lang.IPersistentMap)const__25);const__26.setDynamic(true).setMeta((clojure.lang.IPersistentMap)const__28); Var tmp206_203 = const__29;tmp206_203.setMeta((clojure.lang.IPersistentMap)const__32);tmp206_203.bindRoot(new junit.indent()); Var tmp230_227 = const__33;tmp230_227.setMeta((clojure.lang.IPersistentMap)const__36);tmp230_227.bindRoot(new junit.start_element()); Var tmp254_251 = const__37;tmp254_251.setMeta((clojure.lang.IPersistentMap)const__40);tmp254_251.bindRoot(new junit.element_content()); Var tmp278_275 = const__41;tmp278_275.setMeta((clojure.lang.IPersistentMap)const__44);tmp278_275.bindRoot(new junit.finish_element()); Var tmp302_299 = const__45;tmp302_299.setMeta((clojure.lang.IPersistentMap)const__48);tmp302_299.bindRoot(new junit.test_name()); Var tmp326_323 = const__49;tmp326_323.setMeta((clojure.lang.IPersistentMap)const__52);tmp326_323.bindRoot(new junit.package_class()); Var tmp350_347 = const__53;tmp350_347.setMeta((clojure.lang.IPersistentMap)const__56);tmp350_347.bindRoot(new junit.start_case()); Var tmp374_371 = const__57;tmp374_371.setMeta((clojure.lang.IPersistentMap)const__60);tmp374_371.bindRoot(new junit.finish_case()); Var tmp398_395 = const__61;tmp398_395.setMeta((clojure.lang.IPersistentMap)const__64);tmp398_395.bindRoot(new junit.suite_attrs()); Var tmp422_419 = const__65;tmp422_419.setMeta((clojure.lang.IPersistentMap)const__68);tmp422_419.bindRoot(new junit.start_suite()); Var tmp446_443 = const__69;tmp446_443.setMeta((clojure.lang.IPersistentMap)const__72);tmp446_443.bindRoot(new junit.finish_suite()); Var tmp470_467 = const__73;tmp470_467.setMeta((clojure.lang.IPersistentMap)const__76);tmp470_467.bindRoot(new junit.message_el()); Var tmp494_491 = const__77;tmp494_491.setMeta((clojure.lang.IPersistentMap)const__80);tmp494_491.bindRoot(new junit.failure_el()); Var tmp518_515 = const__81;tmp518_515.setMeta((clojure.lang.IPersistentMap)const__84);tmp518_515.bindRoot(new junit.error_el());new junit.fn__8107();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 142 */     new junit.fn__8111();
/*     */     
/* 144 */     new junit.fn__8113();
/*     */     
/*     */ 
/*     */ 
/* 148 */     new junit.fn__8115();
/*     */     
/*     */ 
/*     */ 
/* 152 */     new junit.fn__8117();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 158 */     new junit.fn__8119();
/*     */     
/*     */ 
/*     */ 
/* 162 */     new junit.fn__8121();
/*     */     
/*     */ 
/*     */ 
/* 166 */     new junit.fn__8123();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 173 */     new junit.fn__8125(); Var 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 180 */       tmp757_754 = const__94;tmp757_754.setMeta((clojure.lang.IPersistentMap)const__98);tmp757_754.bindRoot(new junit.with_junit_output());((Var)const__94)
/*     */     
/* 182 */       .setMacro();
/*     */   }
/*     */   
/*     */   public static final Var const__14;
/*     */   public static final Var const__15;
/*     */   public static final clojure.lang.AFn const__16;
/*     */   public static final Var const__17;
/*     */   public static final clojure.lang.AFn const__21;
/*     */   public static final Var const__22;
/*     */   public static final clojure.lang.AFn const__25;
/*     */   public static final Var const__26;
/*     */   public static final clojure.lang.AFn const__28;
/*     */   public static final Var const__29;
/*     */   public static final clojure.lang.AFn const__32;
/*     */   public static final Var const__33;
/*     */   public static final clojure.lang.AFn const__36;
/*     */   public static final Var const__37;
/*     */   public static final clojure.lang.AFn const__40;
/*     */   public static final Var const__41;
/*     */   public static final clojure.lang.AFn const__44;
/*     */   public static final Var const__45;
/*     */   public static final clojure.lang.AFn const__48;
/*     */   public static final Var const__49;
/*     */   public static final clojure.lang.AFn const__52;
/*     */   public static final Var const__53;
/*     */   public static final clojure.lang.AFn const__56;
/*     */   public static final Var const__57;
/*     */   public static final clojure.lang.AFn const__60;
/*     */   public static final Var const__61;
/*     */   public static final clojure.lang.AFn const__64;
/*     */   public static final Var const__65;
/*     */   public static final clojure.lang.AFn const__68;
/*     */   public static final Var const__69;
/*     */   public static final clojure.lang.AFn const__72;
/*     */   public static final Var const__73;
/*     */   public static final clojure.lang.AFn const__76;
/*     */   public static final Var const__77;
/*     */   public static final clojure.lang.AFn const__80;
/*     */   public static final Var const__81;
/*     */   public static final clojure.lang.AFn const__84;
/*     */   public static final Var const__85;
/*     */   public static final clojure.lang.Keyword const__86;
/*     */   public static final clojure.lang.Keyword const__87;
/*     */   public static final clojure.lang.Keyword const__88;
/*     */   public static final clojure.lang.Keyword const__89;
/*     */   public static final clojure.lang.Keyword const__90;
/*     */   public static final clojure.lang.Keyword const__91;
/*     */   public static final clojure.lang.Keyword const__92;
/*     */   public static final clojure.lang.Keyword const__93;
/*     */   public static final Var const__94;
/*     */   public static final clojure.lang.AFn const__98;
/*     */   public static void __init0()
/*     */   {
/*     */     const__0 = (Var)RT.var("clojure.core", "in-ns");
/*     */     const__1 = (clojure.lang.AFn)((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "clojure.test.junit")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "doc"), "clojure.test extension for JUnit-compatible XML output.\n\n  JUnit (http://junit.org/) is the most popular unit-testing library\n  for Java.  As such, tool support for JUnit output formats is\n  common.  By producing compatible output from tests, this tool\n  support can be exploited.\n\n  To use, wrap any calls to clojure.test/run-tests in the\n  with-junit-output macro, like this:\n\n    (use 'clojure.test)\n    (use 'clojure.test.junit)\n\n    (with-junit-output\n      (run-tests 'my.cool.library))\n\n  To write the output to a file, rebind clojure.test/*test-out* to\n  your own PrintWriter (perhaps opened using\n  clojure.java.io/writer).", RT.keyword(null, "author"), "Jason Sankey" }));
/*     */     const__4 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "doc"), "clojure.test extension for JUnit-compatible XML output.\n\n  JUnit (http://junit.org/) is the most popular unit-testing library\n  for Java.  As such, tool support for JUnit output formats is\n  common.  By producing compatible output from tests, this tool\n  support can be exploited.\n\n  To use, wrap any calls to clojure.test/run-tests in the\n  with-junit-output macro, like this:\n\n    (use 'clojure.test)\n    (use 'clojure.test.junit)\n\n    (with-junit-output\n      (run-tests 'my.cool.library))\n\n  To write the output to a file, rebind clojure.test/*test-out* to\n  your own PrintWriter (perhaps opened using\n  clojure.java.io/writer).", RT.keyword(null, "author"), "Jason Sankey" });
/*     */     const__5 = (clojure.lang.AFn)clojure.lang.Symbol.intern(null, "clojure.core");
/*     */     const__6 = (Var)RT.var("clojure.test.junit", "escape-xml-map");
/*     */     const__13 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "line"), Integer.valueOf(42), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/test/junit.clj" });
/*     */     const__14 = (Var)RT.var("clojure.core", "zipmap");
/*     */     const__15 = (Var)RT.var("clojure.core", "map");
/*     */     const__16 = (clojure.lang.AFn)clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "apos"), clojure.lang.Symbol.intern(null, "lt"), clojure.lang.Symbol.intern(null, "gt"), clojure.lang.Symbol.intern(null, "quot"), clojure.lang.Symbol.intern(null, "amp"));
/*     */     const__17 = (Var)RT.var("clojure.test.junit", "escape-xml");
/*     */     const__21 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "text")) })), RT.keyword(null, "line"), Integer.valueOf(45), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/test/junit.clj" });
/*     */     const__22 = (Var)RT.var("clojure.test.junit", "*var-context*");
/*     */     const__25 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "dynamic"), Boolean.TRUE, RT.keyword(null, "line"), Integer.valueOf(48), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/test/junit.clj" });
/*     */     const__26 = (Var)RT.var("clojure.test.junit", "*depth*");
/*     */     const__28 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "dynamic"), Boolean.TRUE, RT.keyword(null, "line"), Integer.valueOf(49), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/test/junit.clj" });
/*     */     const__29 = (Var)RT.var("clojure.test.junit", "indent");
/*     */     const__32 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create() })), RT.keyword(null, "line"), Integer.valueOf(51), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/test/junit.clj" });
/*     */     const__33 = (Var)RT.var("clojure.test.junit", "start-element");
/*     */     const__36 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "tag"), clojure.lang.Symbol.intern(null, "pretty"), clojure.lang.Symbol.intern(null, "&"), clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "attrs"))) })), RT.keyword(null, "line"), Integer.valueOf(55), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/test/junit.clj" });
/*     */     const__37 = (Var)RT.var("clojure.test.junit", "element-content");
/*     */     const__40 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "content")) })), RT.keyword(null, "line"), Integer.valueOf(66), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/test/junit.clj" });
/*     */     const__41 = (Var)RT.var("clojure.test.junit", "finish-element");
/*     */     const__44 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "tag"), clojure.lang.Symbol.intern(null, "pretty")) })), RT.keyword(null, "line"), Integer.valueOf(70), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/test/junit.clj" });
/*     */     const__45 = (Var)RT.var("clojure.test.junit", "test-name");
/*     */     const__48 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "vars")) })), RT.keyword(null, "line"), Integer.valueOf(77), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/test/junit.clj" });
/*     */     const__49 = (Var)RT.var("clojure.test.junit", "package-class");
/*     */     const__52 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "name")) })), RT.keyword(null, "line"), Integer.valueOf(82), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/test/junit.clj" });
/*     */     const__53 = (Var)RT.var("clojure.test.junit", "start-case");
/*     */     const__56 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "name"), clojure.lang.Symbol.intern(null, "classname")) })), RT.keyword(null, "line"), Integer.valueOf(89), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/test/junit.clj" });
/*     */     const__57 = (Var)RT.var("clojure.test.junit", "finish-case");
/*     */     const__60 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create() })), RT.keyword(null, "line"), Integer.valueOf(93), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/test/junit.clj" });
/*     */     const__61 = (Var)RT.var("clojure.test.junit", "suite-attrs");
/*     */     const__64 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "package"), clojure.lang.Symbol.intern(null, "classname")) })), RT.keyword(null, "line"), Integer.valueOf(97), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/test/junit.clj" });
/*     */     const__65 = (Var)RT.var("clojure.test.junit", "start-suite");
/*     */     const__68 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "name")) })), RT.keyword(null, "line"), Integer.valueOf(104), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/test/junit.clj" });
/*     */     const__69 = (Var)RT.var("clojure.test.junit", "finish-suite");
/*     */     const__72 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create() })), RT.keyword(null, "line"), Integer.valueOf(109), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/test/junit.clj" });
/*     */     const__73 = (Var)RT.var("clojure.test.junit", "message-el");
/*     */     const__76 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "tag"), clojure.lang.Symbol.intern(null, "message"), clojure.lang.Symbol.intern(null, "expected-str"), clojure.lang.Symbol.intern(null, "actual-str")) })), RT.keyword(null, "line"), Integer.valueOf(113), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/test/junit.clj" });
/*     */     const__77 = (Var)RT.var("clojure.test.junit", "failure-el");
/*     */     const__80 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "message"), clojure.lang.Symbol.intern(null, "expected"), clojure.lang.Symbol.intern(null, "actual")) })), RT.keyword(null, "line"), Integer.valueOf(128), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/test/junit.clj" });
/*     */     const__81 = (Var)RT.var("clojure.test.junit", "error-el");
/*     */     const__84 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "message"), clojure.lang.Symbol.intern(null, "expected"), clojure.lang.Symbol.intern(null, "actual")) })), RT.keyword(null, "line"), Integer.valueOf(132), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/test/junit.clj" });
/*     */     const__85 = (Var)RT.var("clojure.test.junit", "junit-report");
/*     */     const__86 = (clojure.lang.Keyword)RT.keyword(null, "begin-test-ns");
/*     */     const__87 = (clojure.lang.Keyword)RT.keyword(null, "end-test-ns");
/*     */     const__88 = (clojure.lang.Keyword)RT.keyword(null, "begin-test-var");
/*     */     const__89 = (clojure.lang.Keyword)RT.keyword(null, "end-test-var");
/*     */     const__90 = (clojure.lang.Keyword)RT.keyword(null, "pass");
/*     */     const__91 = (clojure.lang.Keyword)RT.keyword(null, "fail");
/*     */     const__92 = (clojure.lang.Keyword)RT.keyword(null, "error");
/*     */     const__93 = (clojure.lang.Keyword)RT.keyword(null, "default");
/*     */     const__94 = (Var)RT.var("clojure.test.junit", "with-junit-output");
/*     */     const__98 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "&"), clojure.lang.Symbol.intern(null, "body")) })), RT.keyword(null, "doc"), "Execute body with modified test-is reporting functions that write\n  JUnit-compatible XML output.", RT.keyword(null, "added"), "1.1", RT.keyword(null, "line"), Integer.valueOf(182), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/test/junit.clj" });
/*     */   }
/*     */   
/*     */   static
/*     */   {
/*     */     __init0();
/*     */     clojure.lang.Compiler.pushNSandLoader(RT.classForName("clojure.test.junit__init").getClassLoader());
/*     */     try
/*     */     {
/*     */       load();
/*     */       Var.popThreadBindings();
/*     */     }
/*     */     finally
/*     */     {
/*     */       Var.popThreadBindings();
/*     */       throw finally;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\test\junit__init.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */