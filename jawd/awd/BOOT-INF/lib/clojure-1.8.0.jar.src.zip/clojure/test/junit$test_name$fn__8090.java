/*    */ package clojure.test;
/*    */ 
/*    */ import clojure.lang.AFunction;
/*    */ import clojure.lang.ILookupThunk;
/*    */ import clojure.lang.KeywordLookupSite;
/*    */ import clojure.lang.RT;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class junit$test_name$fn__8090
/*    */   extends AFunction
/*    */ {
/*    */   static final KeywordLookupSite __site__0__;
/* 80 */   static ILookupThunk __thunk__0__ = __site__0__ = new KeywordLookupSite(RT.keyword(null, "name"));
/*    */   
/*    */   /* Error */
/*    */   public Object invoke(Object p1__8089_SHARP_)
/*    */   {
/*    */     // Byte code:
/*    */     //   0: getstatic 15	clojure/test/junit$test_name$fn__8090:__thunk__0__	Lclojure/lang/ILookupThunk;
/*    */     //   3: dup
/*    */     //   4: aload_1
/*    */     //   5: aconst_null
/*    */     //   6: astore_1
/*    */     //   7: invokestatic 20	clojure/core$meta__4373:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   10: dup_x2
/*    */     //   11: invokeinterface 25 2 0
/*    */     //   16: dup_x2
/*    */     //   17: if_acmpeq +7 -> 24
/*    */     //   20: pop
/*    */     //   21: goto +25 -> 46
/*    */     //   24: swap
/*    */     //   25: pop
/*    */     //   26: dup
/*    */     //   27: getstatic 29	clojure/test/junit$test_name$fn__8090:__site__0__	Lclojure/lang/KeywordLookupSite;
/*    */     //   30: swap
/*    */     //   31: invokeinterface 35 2 0
/*    */     //   36: dup
/*    */     //   37: putstatic 15	clojure/test/junit$test_name$fn__8090:__thunk__0__	Lclojure/lang/ILookupThunk;
/*    */     //   40: swap
/*    */     //   41: invokeinterface 25 2 0
/*    */     //   46: areturn
/*    */     // Line number table:
/*    */     //   Java source line #80	-> byte code offset #0
/*    */     //   Java source line #80	-> byte code offset #0
/*    */     //   Java source line #80	-> byte code offset #10
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	signature
/*    */     //   0	46	0	this	Object
/*    */     //   0	46	1	p1__8089_SHARP_	Object
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\test\junit$test_name$fn__8090.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */