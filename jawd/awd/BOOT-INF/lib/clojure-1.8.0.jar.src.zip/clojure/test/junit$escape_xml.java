/*    */ package clojure.test;
/*    */ 
/*    */ import clojure.core.apply;
/*    */ import clojure.core.map;
/*    */ import clojure.lang.AFunction;
/*    */ import clojure.lang.RT;
/*    */ import clojure.lang.Var;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class junit$escape_xml
/*    */   extends AFunction
/*    */ {
/*    */   public Object invoke(Object paramObject)
/*    */   {
/* 45 */     paramObject = null;return invokeStatic(paramObject); } public static Object invokeStatic(Object text) { text = null;return core.apply.invokeStatic(const__1.getRawRoot(), core.map.invokeStatic(new junit.escape_xml.fn__8071(), text)); } public static final Var const__1 = (Var)RT.var("clojure.core", "str");
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\test\junit$escape_xml.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */