/*    */ package clojure.test;
/*    */ 
/*    */ import clojure.core.commute;
/*    */ import clojure.core.deref;
/*    */ import clojure.lang.AFn;
/*    */ import clojure.lang.AFunction;
/*    */ import clojure.lang.ArraySeq;
/*    */ import clojure.lang.IObj;
/*    */ import clojure.lang.IPersistentMap;
/*    */ import clojure.lang.RT;
/*    */ import clojure.lang.Symbol;
/*    */ import clojure.lang.Var;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class tap$fn__8032
/*    */   extends AFunction
/*    */ {
/* 23 */   public Object invoke() { return invokeStatic(); } public static Object invokeStatic() { return core.commute.invokeStatic(core.deref.invokeStatic(const__2), const__3.getRawRoot(), ArraySeq.create(new Object[] { const__4 })); } public static final AFn const__4 = (AFn)((IObj)Symbol.intern(null, "clojure.test.tap")).withMeta((IPersistentMap)RT.map(new Object[] { RT.keyword(null, "doc"), "clojure.test extensions for the Test Anything Protocol (TAP)\n\n  TAP is a simple text-based syntax for reporting test results.  TAP\n  was originally developed for Perl, and now has implementations in\n  several languages.  For more information on TAP, see\n  http://testanything.org/ and\n  http://search.cpan.org/~petdance/TAP-1.0.0/TAP.pm\n\n  To use this library, wrap any calls to\n  clojure.test/run-tests in the with-tap-output macro,\n  like this:\n\n    (use 'clojure.test)\n    (use 'clojure.test.tap)\n\n    (with-tap-output\n     (run-tests 'my.cool.library))", RT.keyword(null, "author"), "Stuart Sierra" })); public static final Var const__3 = (Var)RT.var("clojure.core", "conj"); public static final Var const__2 = (Var)RT.var("clojure.core", "*loaded-libs*");
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\test\tap$fn__8032.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */