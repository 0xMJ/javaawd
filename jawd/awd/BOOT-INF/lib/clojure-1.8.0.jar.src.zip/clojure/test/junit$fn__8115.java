/*     */ package clojure.test;
/*     */ 
/*     */ import clojure.lang.AFunction;
/*     */ import clojure.lang.ILookupThunk;
/*     */ import clojure.lang.KeywordLookupSite;
/*     */ import clojure.lang.RT;
/*     */ import clojure.lang.Var;
/*     */ 
/*     */ public final class junit$fn__8115
/*     */   extends AFunction
/*     */ {
/*     */   /* Error */
/*     */   public static Object invokeStatic(Object m)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: iconst_2
/*     */     //   1: anewarray 13	java/lang/Object
/*     */     //   4: dup
/*     */     //   5: iconst_0
/*     */     //   6: getstatic 17	clojure/test/junit$fn__8115:const__2	Lclojure/lang/Var;
/*     */     //   9: aastore
/*     */     //   10: dup
/*     */     //   11: iconst_1
/*     */     //   12: getstatic 20	clojure/test/junit$fn__8115:const__3	Lclojure/lang/Var;
/*     */     //   15: invokevirtual 26	clojure/lang/Var:get	()Ljava/lang/Object;
/*     */     //   18: aastore
/*     */     //   19: invokestatic 32	clojure/lang/ArraySeq:create	([Ljava/lang/Object;)Lclojure/lang/ArraySeq;
/*     */     //   22: invokestatic 37	clojure/core$hash_map:invokeStatic	(Lclojure/lang/ISeq;)Ljava/lang/Object;
/*     */     //   25: invokestatic 41	clojure/core$push_thread_bindings:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   28: pop
/*     */     //   29: getstatic 45	clojure/test/junit$fn__8115:__thunk__0__	Lclojure/lang/ILookupThunk;
/*     */     //   32: dup
/*     */     //   33: aload_0
/*     */     //   34: aconst_null
/*     */     //   35: astore_0
/*     */     //   36: dup_x2
/*     */     //   37: invokeinterface 49 2 0
/*     */     //   42: dup_x2
/*     */     //   43: if_acmpeq +7 -> 50
/*     */     //   46: pop
/*     */     //   47: goto +25 -> 72
/*     */     //   50: swap
/*     */     //   51: pop
/*     */     //   52: dup
/*     */     //   53: getstatic 53	clojure/test/junit$fn__8115:__site__0__	Lclojure/lang/KeywordLookupSite;
/*     */     //   56: swap
/*     */     //   57: invokeinterface 59 2 0
/*     */     //   62: dup
/*     */     //   63: putstatic 45	clojure/test/junit$fn__8115:__thunk__0__	Lclojure/lang/ILookupThunk;
/*     */     //   66: swap
/*     */     //   67: invokeinterface 49 2 0
/*     */     //   72: astore_1
/*     */     //   73: iconst_2
/*     */     //   74: anewarray 13	java/lang/Object
/*     */     //   77: dup
/*     */     //   78: iconst_0
/*     */     //   79: getstatic 62	clojure/test/junit$fn__8115:const__5	Lclojure/lang/Var;
/*     */     //   82: aastore
/*     */     //   83: dup
/*     */     //   84: iconst_1
/*     */     //   85: getstatic 62	clojure/test/junit$fn__8115:const__5	Lclojure/lang/Var;
/*     */     //   88: invokevirtual 26	clojure/lang/Var:get	()Ljava/lang/Object;
/*     */     //   91: aload_1
/*     */     //   92: invokestatic 67	clojure/core$conj__4345:invokeStatic	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   95: aastore
/*     */     //   96: invokestatic 32	clojure/lang/ArraySeq:create	([Ljava/lang/Object;)Lclojure/lang/ArraySeq;
/*     */     //   99: invokestatic 37	clojure/core$hash_map:invokeStatic	(Lclojure/lang/ISeq;)Ljava/lang/Object;
/*     */     //   102: invokestatic 41	clojure/core$push_thread_bindings:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   105: pop
/*     */     //   106: getstatic 62	clojure/test/junit$fn__8115:const__5	Lclojure/lang/Var;
/*     */     //   109: invokevirtual 26	clojure/lang/Var:get	()Ljava/lang/Object;
/*     */     //   112: invokestatic 70	clojure/test/junit$test_name:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   115: getstatic 73	clojure/test/junit$fn__8115:__thunk__1__	Lclojure/lang/ILookupThunk;
/*     */     //   118: dup
/*     */     //   119: aload_1
/*     */     //   120: aconst_null
/*     */     //   121: astore_1
/*     */     //   122: invokestatic 76	clojure/core$meta__4373:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   125: dup_x2
/*     */     //   126: invokeinterface 49 2 0
/*     */     //   131: dup_x2
/*     */     //   132: if_acmpeq +7 -> 139
/*     */     //   135: pop
/*     */     //   136: goto +25 -> 161
/*     */     //   139: swap
/*     */     //   140: pop
/*     */     //   141: dup
/*     */     //   142: getstatic 79	clojure/test/junit$fn__8115:__site__1__	Lclojure/lang/KeywordLookupSite;
/*     */     //   145: swap
/*     */     //   146: invokeinterface 59 2 0
/*     */     //   151: dup
/*     */     //   152: putstatic 73	clojure/test/junit$fn__8115:__thunk__1__	Lclojure/lang/ILookupThunk;
/*     */     //   155: swap
/*     */     //   156: invokeinterface 49 2 0
/*     */     //   161: invokestatic 82	clojure/core$ns_name:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   164: invokestatic 85	clojure/core$name:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   167: invokestatic 88	clojure/test/junit$start_case:invokeStatic	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   170: astore_2
/*     */     //   171: invokestatic 92	clojure/core$pop_thread_bindings:invokeStatic	()Ljava/lang/Object;
/*     */     //   174: pop
/*     */     //   175: goto +10 -> 185
/*     */     //   178: astore_3
/*     */     //   179: invokestatic 92	clojure/core$pop_thread_bindings:invokeStatic	()Ljava/lang/Object;
/*     */     //   182: pop
/*     */     //   183: aload_3
/*     */     //   184: athrow
/*     */     //   185: aload_2
/*     */     //   186: astore 4
/*     */     //   188: invokestatic 92	clojure/core$pop_thread_bindings:invokeStatic	()Ljava/lang/Object;
/*     */     //   191: pop
/*     */     //   192: goto +12 -> 204
/*     */     //   195: astore 5
/*     */     //   197: invokestatic 92	clojure/core$pop_thread_bindings:invokeStatic	()Ljava/lang/Object;
/*     */     //   200: pop
/*     */     //   201: aload 5
/*     */     //   203: athrow
/*     */     //   204: aload 4
/*     */     //   206: areturn
/*     */     // Line number table:
/*     */     //   Java source line #152	-> byte code offset #0
/*     */     //   Java source line #154	-> byte code offset #29
/*     */     //   Java source line #154	-> byte code offset #36
/*     */     //   Java source line #156	-> byte code offset #115
/*     */     //   Java source line #156	-> byte code offset #125
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	206	0	m	Object
/*     */     //   73	113	1	var	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   106	171	178	finally
/*     */     //   29	188	195	finally
/*     */   }
/*     */   
/*     */   public Object invoke(Object paramObject)
/*     */   {
/* 152 */     paramObject = null;return invokeStatic(paramObject); } static ILookupThunk __thunk__1__ = __site__1__ = new KeywordLookupSite(RT.keyword(null, "ns")); static final KeywordLookupSite __site__1__; static ILookupThunk __thunk__0__ = __site__0__ = new KeywordLookupSite(RT.keyword(null, "var")); static final KeywordLookupSite __site__0__; public static final Var const__5 = (Var)RT.var("clojure.test.junit", "*var-context*"); public static final Var const__3 = (Var)RT.var("clojure.test", "*test-out*"); public static final Var const__2 = (Var)RT.var("clojure.core", "*out*");
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\test\junit$fn__8115.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */