/*    */ package clojure.test;
/*    */ 
/*    */ import clojure.lang.AFn;
/*    */ import clojure.lang.AFunction;
/*    */ import clojure.lang.ArraySeq;
/*    */ import clojure.lang.Keyword;
/*    */ import clojure.lang.RT;
/*    */ import clojure.lang.Symbol;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class junit$start_case
/*    */   extends AFunction
/*    */ {
/*    */   public Object invoke(Object paramObject1, Object paramObject2)
/*    */   {
/* 89 */     paramObject1 = null;paramObject2 = null;return invokeStatic(paramObject1, paramObject2); } public static Object invokeStatic(Object name, Object classname) { Object[] tmp10_7 = new Object[1];name = null;{ const__2 }[1] = name; Object[] tmp28_22 = tmp22_16;tmp28_22[2] = const__3; Object[] tmp34_28 = tmp28_22;classname = null;tmp34_28[3] = classname;tmp10_7[0] = RT.mapUniqueKeys(tmp34_28);return junit.start_element.invokeStatic(const__1, Boolean.TRUE, ArraySeq.create(tmp10_7)); } public static final Keyword const__3 = (Keyword)RT.keyword(null, "classname"); public static final Keyword const__2 = (Keyword)RT.keyword(null, "name"); public static final AFn const__1 = (AFn)Symbol.intern(null, "testcase");
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\test\junit$start_case.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */