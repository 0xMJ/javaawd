/*     */ package clojure.test;
/*     */ 
/*     */ import clojure.lang.AFunction;
/*     */ import clojure.lang.RT;
/*     */ import clojure.lang.Var;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class junit$error_el$fn__8103
/*     */   extends AFunction
/*     */ {
/*     */   Object actual;
/*     */   Object s__5244__auto__;
/*     */   
/*     */   public junit$error_el$fn__8103(Object paramObject1, Object paramObject2)
/*     */   {
/* 138 */     this.actual = paramObject1;this.s__5244__auto__ = paramObject2; } public static final Var const__1 = (Var)RT.var("clojure.test", "*stack-trace-depth*");
/*     */   
/*     */   /* Error */
/*     */   public Object invoke()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 15	clojure/test/junit$error_el$fn__8103:actual	Ljava/lang/Object;
/*     */     //   4: getstatic 23	clojure/test/junit$error_el$fn__8103:const__1	Lclojure/lang/Var;
/*     */     //   7: invokevirtual 28	clojure/lang/Var:get	()Ljava/lang/Object;
/*     */     //   10: invokestatic 34	clojure/stacktrace$print_cause_trace:invokeStatic	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   13: pop
/*     */     //   14: aload_0
/*     */     //   15: getfield 17	clojure/test/junit$error_el$fn__8103:s__5244__auto__	Ljava/lang/Object;
/*     */     //   18: invokestatic 39	clojure/core$str:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   21: astore_1
/*     */     //   22: invokestatic 43	clojure/core$pop_thread_bindings:invokeStatic	()Ljava/lang/Object;
/*     */     //   25: pop
/*     */     //   26: goto +10 -> 36
/*     */     //   29: astore_2
/*     */     //   30: invokestatic 43	clojure/core$pop_thread_bindings:invokeStatic	()Ljava/lang/Object;
/*     */     //   33: pop
/*     */     //   34: aload_2
/*     */     //   35: athrow
/*     */     //   36: aload_1
/*     */     //   37: areturn
/*     */     // Line number table:
/*     */     //   Java source line #138	-> byte code offset #0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	37	0	this	Object
/*     */     //   21	16	1	localObject1	Object
/*     */     //   29	6	2	localObject2	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   0	22	29	finally
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\test\junit$error_el$fn__8103.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */