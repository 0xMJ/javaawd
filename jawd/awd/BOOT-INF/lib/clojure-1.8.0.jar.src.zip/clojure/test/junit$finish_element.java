/*    */ package clojure.test;
/*    */ 
/*    */ import clojure.lang.AFunction;
/*    */ import clojure.lang.RT;
/*    */ import clojure.lang.Var;
/*    */ 
/*    */ public final class junit$finish_element
/*    */   extends AFunction
/*    */ {
/*    */   /* Error */
/*    */   public static Object invokeStatic(Object tag, Object pretty)
/*    */   {
/*    */     // Byte code:
/*    */     //   0: getstatic 15	clojure/test/junit$finish_element:const__0	Lclojure/lang/Var;
/*    */     //   3: getstatic 15	clojure/test/junit$finish_element:const__0	Lclojure/lang/Var;
/*    */     //   6: invokevirtual 21	clojure/lang/Var:get	()Ljava/lang/Object;
/*    */     //   9: invokestatic 27	clojure/lang/Numbers:dec	(Ljava/lang/Object;)Ljava/lang/Number;
/*    */     //   12: invokevirtual 31	clojure/lang/Var:set	(Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   15: pop
/*    */     //   16: aload_1
/*    */     //   17: dup
/*    */     //   18: ifnull +16 -> 34
/*    */     //   21: getstatic 37	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*    */     //   24: if_acmpeq +11 -> 35
/*    */     //   27: invokestatic 41	clojure/test/junit$indent:invokeStatic	()Ljava/lang/Object;
/*    */     //   30: pop
/*    */     //   31: goto +6 -> 37
/*    */     //   34: pop
/*    */     //   35: aconst_null
/*    */     //   36: pop
/*    */     //   37: iconst_1
/*    */     //   38: anewarray 43	java/lang/Object
/*    */     //   41: dup
/*    */     //   42: iconst_0
/*    */     //   43: ldc 45
/*    */     //   45: iconst_2
/*    */     //   46: anewarray 43	java/lang/Object
/*    */     //   49: dup
/*    */     //   50: iconst_0
/*    */     //   51: aload_0
/*    */     //   52: aconst_null
/*    */     //   53: astore_0
/*    */     //   54: aastore
/*    */     //   55: dup
/*    */     //   56: iconst_1
/*    */     //   57: ldc 47
/*    */     //   59: aastore
/*    */     //   60: invokestatic 53	clojure/lang/ArraySeq:create	([Ljava/lang/Object;)Lclojure/lang/ArraySeq;
/*    */     //   63: invokestatic 58	clojure/core$str:invokeStatic	(Ljava/lang/Object;Lclojure/lang/ISeq;)Ljava/lang/Object;
/*    */     //   66: aastore
/*    */     //   67: invokestatic 53	clojure/lang/ArraySeq:create	([Ljava/lang/Object;)Lclojure/lang/ArraySeq;
/*    */     //   70: invokestatic 63	clojure/core$print:invokeStatic	(Lclojure/lang/ISeq;)Ljava/lang/Object;
/*    */     //   73: pop
/*    */     //   74: aload_1
/*    */     //   75: aconst_null
/*    */     //   76: astore_1
/*    */     //   77: dup
/*    */     //   78: ifnull +26 -> 104
/*    */     //   81: getstatic 37	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*    */     //   84: if_acmpeq +21 -> 105
/*    */     //   87: getstatic 66	clojure/test/junit$finish_element:const__5	Lclojure/lang/Var;
/*    */     //   90: invokevirtual 69	clojure/lang/Var:getRawRoot	()Ljava/lang/Object;
/*    */     //   93: checkcast 71	clojure/lang/IFn
/*    */     //   96: invokeinterface 74 1 0
/*    */     //   101: goto +5 -> 106
/*    */     //   104: pop
/*    */     //   105: aconst_null
/*    */     //   106: areturn
/*    */     // Line number table:
/*    */     //   Java source line #70	-> byte code offset #0
/*    */     //   Java source line #72	-> byte code offset #9
/*    */     //   Java source line #73	-> byte code offset #16
/*    */     //   Java source line #75	-> byte code offset #74
/*    */     //   Java source line #75	-> byte code offset #93
/*    */     //   Java source line #75	-> byte code offset #96
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	signature
/*    */     //   0	106	0	tag	Object
/*    */     //   0	106	1	pretty	Object
/*    */   }
/*    */   
/*    */   public Object invoke(Object paramObject1, Object paramObject2)
/*    */   {
/* 70 */     paramObject1 = null;paramObject2 = null;return invokeStatic(paramObject1, paramObject2); } public static final Var const__5 = (Var)RT.var("clojure.core", "println"); public static final Var const__0 = (Var)RT.var("clojure.test.junit", "*depth*");
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\test\junit$finish_element.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */