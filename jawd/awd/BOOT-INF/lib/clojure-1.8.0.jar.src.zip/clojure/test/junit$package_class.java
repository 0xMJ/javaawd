/*    */ package clojure.test;
/*    */ 
/*    */ import clojure.lang.AFunction;
/*    */ 
/*    */ public final class junit$package_class
/*    */   extends AFunction
/*    */ {
/*    */   /* Error */
/*    */   public static Object invokeStatic(Object name)
/*    */   {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: ldc 13
/*    */     //   3: iconst_1
/*    */     //   4: anewarray 15	java/lang/Object
/*    */     //   7: dup
/*    */     //   8: iconst_0
/*    */     //   9: ldc 17
/*    */     //   11: aastore
/*    */     //   12: invokestatic 23	clojure/lang/Reflector:invokeInstanceMethod	(Ljava/lang/Object;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   15: astore_1
/*    */     //   16: aload_1
/*    */     //   17: lconst_0
/*    */     //   18: invokestatic 29	clojure/lang/Numbers:lt	(Ljava/lang/Object;J)Z
/*    */     //   21: ifeq +14 -> 35
/*    */     //   24: aconst_null
/*    */     //   25: aload_0
/*    */     //   26: aconst_null
/*    */     //   27: astore_0
/*    */     //   28: invokestatic 35	clojure/lang/Tuple:create	(Ljava/lang/Object;Ljava/lang/Object;)Lclojure/lang/IPersistentVector;
/*    */     //   31: goto +49 -> 80
/*    */     //   34: pop
/*    */     //   35: aload_0
/*    */     //   36: ldc 37
/*    */     //   38: iconst_2
/*    */     //   39: anewarray 15	java/lang/Object
/*    */     //   42: dup
/*    */     //   43: iconst_0
/*    */     //   44: getstatic 41	clojure/test/junit$package_class:const__1	Ljava/lang/Object;
/*    */     //   47: aastore
/*    */     //   48: dup
/*    */     //   49: iconst_1
/*    */     //   50: aload_1
/*    */     //   51: aastore
/*    */     //   52: invokestatic 23	clojure/lang/Reflector:invokeInstanceMethod	(Ljava/lang/Object;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   55: aload_0
/*    */     //   56: aconst_null
/*    */     //   57: astore_0
/*    */     //   58: ldc 37
/*    */     //   60: iconst_1
/*    */     //   61: anewarray 15	java/lang/Object
/*    */     //   64: dup
/*    */     //   65: iconst_0
/*    */     //   66: aload_1
/*    */     //   67: aconst_null
/*    */     //   68: astore_1
/*    */     //   69: lconst_1
/*    */     //   70: invokestatic 45	clojure/lang/Numbers:add	(Ljava/lang/Object;J)Ljava/lang/Number;
/*    */     //   73: aastore
/*    */     //   74: invokestatic 23	clojure/lang/Reflector:invokeInstanceMethod	(Ljava/lang/Object;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   77: invokestatic 35	clojure/lang/Tuple:create	(Ljava/lang/Object;Ljava/lang/Object;)Lclojure/lang/IPersistentVector;
/*    */     //   80: areturn
/*    */     // Line number table:
/*    */     //   Java source line #82	-> byte code offset #0
/*    */     //   Java source line #84	-> byte code offset #12
/*    */     //   Java source line #85	-> byte code offset #16
/*    */     //   Java source line #85	-> byte code offset #18
/*    */     //   Java source line #87	-> byte code offset #52
/*    */     //   Java source line #87	-> byte code offset #70
/*    */     //   Java source line #87	-> byte code offset #74
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	signature
/*    */     //   0	80	0	name	Object
/*    */     //   16	64	1	i	Object
/*    */   }
/*    */   
/*    */   public Object invoke(Object paramObject)
/*    */   {
/* 82 */     paramObject = null;return invokeStatic(paramObject); } public static final Object const__1 = Long.valueOf(0L);
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\test\junit$package_class.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */