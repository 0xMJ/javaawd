/*     */ package clojure.test;
/*     */ 
/*     */ import clojure.lang.AFunction;
/*     */ import clojure.lang.ILookupThunk;
/*     */ import clojure.lang.Keyword;
/*     */ import clojure.lang.KeywordLookupSite;
/*     */ import clojure.lang.RT;
/*     */ import clojure.lang.Var;
/*     */ 
/*     */ public final class junit$fn__8123
/*     */   extends AFunction
/*     */ {
/*     */   /* Error */
/*     */   public static Object invokeStatic(Object m)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: iconst_2
/*     */     //   1: anewarray 13	java/lang/Object
/*     */     //   4: dup
/*     */     //   5: iconst_0
/*     */     //   6: getstatic 17	clojure/test/junit$fn__8123:const__2	Lclojure/lang/Var;
/*     */     //   9: aastore
/*     */     //   10: dup
/*     */     //   11: iconst_1
/*     */     //   12: getstatic 20	clojure/test/junit$fn__8123:const__3	Lclojure/lang/Var;
/*     */     //   15: invokevirtual 26	clojure/lang/Var:get	()Ljava/lang/Object;
/*     */     //   18: aastore
/*     */     //   19: invokestatic 32	clojure/lang/ArraySeq:create	([Ljava/lang/Object;)Lclojure/lang/ArraySeq;
/*     */     //   22: invokestatic 37	clojure/core$hash_map:invokeStatic	(Lclojure/lang/ISeq;)Ljava/lang/Object;
/*     */     //   25: invokestatic 41	clojure/core$push_thread_bindings:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   28: pop
/*     */     //   29: getstatic 45	clojure/test/junit$fn__8123:const__5	Lclojure/lang/Keyword;
/*     */     //   32: invokestatic 48	clojure/test$inc_report_counter:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   35: pop
/*     */     //   36: getstatic 52	clojure/test/junit$fn__8123:__thunk__0__	Lclojure/lang/ILookupThunk;
/*     */     //   39: dup
/*     */     //   40: aload_0
/*     */     //   41: dup_x2
/*     */     //   42: invokeinterface 56 2 0
/*     */     //   47: dup_x2
/*     */     //   48: if_acmpeq +7 -> 55
/*     */     //   51: pop
/*     */     //   52: goto +25 -> 77
/*     */     //   55: swap
/*     */     //   56: pop
/*     */     //   57: dup
/*     */     //   58: getstatic 60	clojure/test/junit$fn__8123:__site__0__	Lclojure/lang/KeywordLookupSite;
/*     */     //   61: swap
/*     */     //   62: invokeinterface 66 2 0
/*     */     //   67: dup
/*     */     //   68: putstatic 52	clojure/test/junit$fn__8123:__thunk__0__	Lclojure/lang/ILookupThunk;
/*     */     //   71: swap
/*     */     //   72: invokeinterface 56 2 0
/*     */     //   77: getstatic 69	clojure/test/junit$fn__8123:__thunk__1__	Lclojure/lang/ILookupThunk;
/*     */     //   80: dup
/*     */     //   81: aload_0
/*     */     //   82: dup_x2
/*     */     //   83: invokeinterface 56 2 0
/*     */     //   88: dup_x2
/*     */     //   89: if_acmpeq +7 -> 96
/*     */     //   92: pop
/*     */     //   93: goto +25 -> 118
/*     */     //   96: swap
/*     */     //   97: pop
/*     */     //   98: dup
/*     */     //   99: getstatic 72	clojure/test/junit$fn__8123:__site__1__	Lclojure/lang/KeywordLookupSite;
/*     */     //   102: swap
/*     */     //   103: invokeinterface 66 2 0
/*     */     //   108: dup
/*     */     //   109: putstatic 69	clojure/test/junit$fn__8123:__thunk__1__	Lclojure/lang/ILookupThunk;
/*     */     //   112: swap
/*     */     //   113: invokeinterface 56 2 0
/*     */     //   118: getstatic 75	clojure/test/junit$fn__8123:__thunk__2__	Lclojure/lang/ILookupThunk;
/*     */     //   121: dup
/*     */     //   122: aload_0
/*     */     //   123: aconst_null
/*     */     //   124: astore_0
/*     */     //   125: dup_x2
/*     */     //   126: invokeinterface 56 2 0
/*     */     //   131: dup_x2
/*     */     //   132: if_acmpeq +7 -> 139
/*     */     //   135: pop
/*     */     //   136: goto +25 -> 161
/*     */     //   139: swap
/*     */     //   140: pop
/*     */     //   141: dup
/*     */     //   142: getstatic 78	clojure/test/junit$fn__8123:__site__2__	Lclojure/lang/KeywordLookupSite;
/*     */     //   145: swap
/*     */     //   146: invokeinterface 66 2 0
/*     */     //   151: dup
/*     */     //   152: putstatic 75	clojure/test/junit$fn__8123:__thunk__2__	Lclojure/lang/ILookupThunk;
/*     */     //   155: swap
/*     */     //   156: invokeinterface 56 2 0
/*     */     //   161: invokestatic 83	clojure/test/junit$error_el:invokeStatic	(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   164: astore_1
/*     */     //   165: invokestatic 87	clojure/core$pop_thread_bindings:invokeStatic	()Ljava/lang/Object;
/*     */     //   168: pop
/*     */     //   169: goto +10 -> 179
/*     */     //   172: astore_2
/*     */     //   173: invokestatic 87	clojure/core$pop_thread_bindings:invokeStatic	()Ljava/lang/Object;
/*     */     //   176: pop
/*     */     //   177: aload_2
/*     */     //   178: athrow
/*     */     //   179: aload_1
/*     */     //   180: areturn
/*     */     // Line number table:
/*     */     //   Java source line #173	-> byte code offset #0
/*     */     //   Java source line #176	-> byte code offset #36
/*     */     //   Java source line #176	-> byte code offset #41
/*     */     //   Java source line #177	-> byte code offset #77
/*     */     //   Java source line #177	-> byte code offset #82
/*     */     //   Java source line #178	-> byte code offset #118
/*     */     //   Java source line #178	-> byte code offset #125
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	180	0	m	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   29	165	172	finally
/*     */   }
/*     */   
/*     */   public Object invoke(Object paramObject)
/*     */   {
/* 173 */     paramObject = null;return invokeStatic(paramObject); } static ILookupThunk __thunk__2__ = __site__2__ = new KeywordLookupSite(RT.keyword(null, "actual")); static final KeywordLookupSite __site__2__; static ILookupThunk __thunk__1__ = __site__1__ = new KeywordLookupSite(RT.keyword(null, "expected")); static final KeywordLookupSite __site__1__; static ILookupThunk __thunk__0__ = __site__0__ = new KeywordLookupSite(RT.keyword(null, "message")); static final KeywordLookupSite __site__0__; public static final Keyword const__5 = (Keyword)RT.keyword(null, "error"); public static final Var const__3 = (Var)RT.var("clojure.test", "*test-out*"); public static final Var const__2 = (Var)RT.var("clojure.core", "*out*");
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\test\junit$fn__8123.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */