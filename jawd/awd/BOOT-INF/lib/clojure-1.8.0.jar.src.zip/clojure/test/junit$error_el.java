/*     */ package clojure.test;
/*     */ 
/*     */ import clojure.lang.AFn;
/*     */ import clojure.lang.AFunction;
/*     */ import clojure.lang.RT;
/*     */ import clojure.lang.Symbol;
/*     */ import clojure.lang.Var;
/*     */ 
/*     */ public final class junit$error_el
/*     */   extends AFunction
/*     */ {
/*     */   /* Error */
/*     */   public static Object invokeStatic(Object message, Object expected, Object actual)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: getstatic 15	clojure/test/junit$error_el:const__1	Lclojure/lang/AFn;
/*     */     //   3: aload_0
/*     */     //   4: aconst_null
/*     */     //   5: astore_0
/*     */     //   6: iconst_1
/*     */     //   7: anewarray 17	java/lang/Object
/*     */     //   10: dup
/*     */     //   11: iconst_0
/*     */     //   12: aload_1
/*     */     //   13: aconst_null
/*     */     //   14: astore_1
/*     */     //   15: aastore
/*     */     //   16: invokestatic 23	clojure/lang/ArraySeq:create	([Ljava/lang/Object;)Lclojure/lang/ArraySeq;
/*     */     //   19: invokestatic 28	clojure/core$pr_str:invokeStatic	(Lclojure/lang/ISeq;)Ljava/lang/Object;
/*     */     //   22: aload_2
/*     */     //   23: instanceof 30
/*     */     //   26: ifeq +60 -> 86
/*     */     //   29: new 32	java/io/StringWriter
/*     */     //   32: dup
/*     */     //   33: invokespecial 33	java/io/StringWriter:<init>	()V
/*     */     //   36: astore_3
/*     */     //   37: iconst_2
/*     */     //   38: anewarray 17	java/lang/Object
/*     */     //   41: dup
/*     */     //   42: iconst_0
/*     */     //   43: getstatic 37	clojure/test/junit$error_el:const__7	Lclojure/lang/Var;
/*     */     //   46: aastore
/*     */     //   47: dup
/*     */     //   48: iconst_1
/*     */     //   49: aload_3
/*     */     //   50: aastore
/*     */     //   51: invokestatic 23	clojure/lang/ArraySeq:create	([Ljava/lang/Object;)Lclojure/lang/ArraySeq;
/*     */     //   54: invokestatic 40	clojure/core$hash_map:invokeStatic	(Lclojure/lang/ISeq;)Ljava/lang/Object;
/*     */     //   57: invokestatic 45	clojure/core$push_thread_bindings:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   60: pop
/*     */     //   61: new 47	clojure/test/junit$error_el$fn__8103
/*     */     //   64: dup
/*     */     //   65: aload_2
/*     */     //   66: aconst_null
/*     */     //   67: astore_2
/*     */     //   68: aload_3
/*     */     //   69: aconst_null
/*     */     //   70: astore_3
/*     */     //   71: invokespecial 50	clojure/test/junit$error_el$fn__8103:<init>	(Ljava/lang/Object;Ljava/lang/Object;)V
/*     */     //   74: checkcast 52	clojure/lang/IFn
/*     */     //   77: invokeinterface 56 1 0
/*     */     //   82: goto +20 -> 102
/*     */     //   85: pop
/*     */     //   86: iconst_1
/*     */     //   87: anewarray 17	java/lang/Object
/*     */     //   90: dup
/*     */     //   91: iconst_0
/*     */     //   92: aload_2
/*     */     //   93: aconst_null
/*     */     //   94: astore_2
/*     */     //   95: aastore
/*     */     //   96: invokestatic 23	clojure/lang/ArraySeq:create	([Ljava/lang/Object;)Lclojure/lang/ArraySeq;
/*     */     //   99: invokestatic 61	clojure/core$prn:invokeStatic	(Lclojure/lang/ISeq;)Ljava/lang/Object;
/*     */     //   102: invokestatic 66	clojure/test/junit$message_el:invokeStatic	(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   105: areturn
/*     */     // Line number table:
/*     */     //   Java source line #132	-> byte code offset #0
/*     */     //   Java source line #137	-> byte code offset #22
/*     */     //   Java source line #138	-> byte code offset #74
/*     */     //   Java source line #138	-> byte code offset #77
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	105	0	message	Object
/*     */     //   0	105	1	expected	Object
/*     */     //   0	105	2	actual	Object
/*     */     //   37	45	3	s__5244__auto__8106	Object
/*     */   }
/*     */   
/*     */   public Object invoke(Object paramObject1, Object paramObject2, Object paramObject3)
/*     */   {
/* 132 */     paramObject1 = null;paramObject2 = null;paramObject3 = null;return invokeStatic(paramObject1, paramObject2, paramObject3); } public static final Var const__7 = (Var)RT.var("clojure.core", "*out*"); public static final AFn const__1 = (AFn)Symbol.intern(null, "error");
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\test\junit$error_el.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */