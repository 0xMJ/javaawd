/*    */ package clojure.test;
/*    */ 
/*    */ import clojure.lang.AFunction;
/*    */ import clojure.lang.RT;
/*    */ import clojure.lang.Var;
/*    */ 
/*    */ public final class junit$indent
/*    */   extends AFunction
/*    */ {
/*    */   /* Error */
/*    */   public static Object invokeStatic()
/*    */   {
/*    */     // Byte code:
/*    */     //   0: getstatic 15	clojure/test/junit$indent:const__2	Lclojure/lang/Var;
/*    */     //   3: invokevirtual 20	clojure/lang/Var:get	()Ljava/lang/Object;
/*    */     //   6: ldc2_w 21
/*    */     //   9: invokestatic 28	clojure/lang/Numbers:multiply	(Ljava/lang/Object;J)Ljava/lang/Number;
/*    */     //   12: invokestatic 34	clojure/lang/RT:longCast	(Ljava/lang/Object;)J
/*    */     //   15: lstore_0
/*    */     //   16: lconst_0
/*    */     //   17: lstore_2
/*    */     //   18: lload_2
/*    */     //   19: lload_0
/*    */     //   20: lcmp
/*    */     //   21: ifge +30 -> 51
/*    */     //   24: iconst_1
/*    */     //   25: anewarray 36	java/lang/Object
/*    */     //   28: dup
/*    */     //   29: iconst_0
/*    */     //   30: ldc 38
/*    */     //   32: aastore
/*    */     //   33: invokestatic 44	clojure/lang/ArraySeq:create	([Ljava/lang/Object;)Lclojure/lang/ArraySeq;
/*    */     //   36: invokestatic 49	clojure/core$print:invokeStatic	(Lclojure/lang/ISeq;)Ljava/lang/Object;
/*    */     //   39: pop
/*    */     //   40: lload_2
/*    */     //   41: lconst_1
/*    */     //   42: ladd
/*    */     //   43: lstore_2
/*    */     //   44: goto -26 -> 18
/*    */     //   47: goto +5 -> 52
/*    */     //   50: pop
/*    */     //   51: aconst_null
/*    */     //   52: areturn
/*    */     // Line number table:
/*    */     //   Java source line #51	-> byte code offset #0
/*    */     //   Java source line #53	-> byte code offset #9
/*    */     //   Java source line #53	-> byte code offset #12
/*    */     //   Java source line #53	-> byte code offset #18
/*    */     //   Java source line #53	-> byte code offset #18
/*    */     //   Java source line #53	-> byte code offset #41
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	signature
/*    */     //   16	36	0	n__4940__auto__8075	long
/*    */     //   18	34	2	n	long
/*    */   }
/*    */   
/* 51 */   public Object invoke() { return invokeStatic(); } public static final Var const__2 = (Var)RT.var("clojure.test.junit", "*depth*");
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\test\junit$indent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */