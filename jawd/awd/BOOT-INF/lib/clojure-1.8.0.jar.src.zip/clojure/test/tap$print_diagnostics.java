/*    */ package clojure.test;
/*    */ 
/*    */ import clojure.lang.AFunction;
/*    */ import clojure.lang.ILookupThunk;
/*    */ import clojure.lang.Keyword;
/*    */ import clojure.lang.KeywordLookupSite;
/*    */ import clojure.lang.RT;
/*    */ import clojure.lang.Var;
/*    */ 
/*    */ public final class tap$print_diagnostics
/*    */   extends AFunction
/*    */ {
/*    */   /* Error */
/*    */   public static Object invokeStatic(Object data)
/*    */   {
/*    */     // Byte code:
/*    */     //   0: getstatic 15	clojure/test/tap$print_diagnostics:const__1	Lclojure/lang/Var;
/*    */     //   3: invokevirtual 21	clojure/lang/Var:get	()Ljava/lang/Object;
/*    */     //   6: invokestatic 25	clojure/core$seq__4357:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   9: dup
/*    */     //   10: ifnull +19 -> 29
/*    */     //   13: getstatic 31	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*    */     //   16: if_acmpeq +14 -> 30
/*    */     //   19: invokestatic 35	clojure/test$testing_contexts_str:invokeStatic	()Ljava/lang/Object;
/*    */     //   22: invokestatic 38	clojure/test/tap$print_tap_diagnostic:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   25: pop
/*    */     //   26: goto +6 -> 32
/*    */     //   29: pop
/*    */     //   30: aconst_null
/*    */     //   31: pop
/*    */     //   32: getstatic 42	clojure/test/tap$print_diagnostics:__thunk__0__	Lclojure/lang/ILookupThunk;
/*    */     //   35: dup
/*    */     //   36: aload_0
/*    */     //   37: dup_x2
/*    */     //   38: invokeinterface 46 2 0
/*    */     //   43: dup_x2
/*    */     //   44: if_acmpeq +7 -> 51
/*    */     //   47: pop
/*    */     //   48: goto +25 -> 73
/*    */     //   51: swap
/*    */     //   52: pop
/*    */     //   53: dup
/*    */     //   54: getstatic 50	clojure/test/tap$print_diagnostics:__site__0__	Lclojure/lang/KeywordLookupSite;
/*    */     //   57: swap
/*    */     //   58: invokeinterface 56 2 0
/*    */     //   63: dup
/*    */     //   64: putstatic 42	clojure/test/tap$print_diagnostics:__thunk__0__	Lclojure/lang/ILookupThunk;
/*    */     //   67: swap
/*    */     //   68: invokeinterface 46 2 0
/*    */     //   73: dup
/*    */     //   74: ifnull +57 -> 131
/*    */     //   77: getstatic 31	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*    */     //   80: if_acmpeq +52 -> 132
/*    */     //   83: getstatic 59	clojure/test/tap$print_diagnostics:__thunk__1__	Lclojure/lang/ILookupThunk;
/*    */     //   86: dup
/*    */     //   87: aload_0
/*    */     //   88: dup_x2
/*    */     //   89: invokeinterface 46 2 0
/*    */     //   94: dup_x2
/*    */     //   95: if_acmpeq +7 -> 102
/*    */     //   98: pop
/*    */     //   99: goto +25 -> 124
/*    */     //   102: swap
/*    */     //   103: pop
/*    */     //   104: dup
/*    */     //   105: getstatic 62	clojure/test/tap$print_diagnostics:__site__1__	Lclojure/lang/KeywordLookupSite;
/*    */     //   108: swap
/*    */     //   109: invokeinterface 56 2 0
/*    */     //   114: dup
/*    */     //   115: putstatic 59	clojure/test/tap$print_diagnostics:__thunk__1__	Lclojure/lang/ILookupThunk;
/*    */     //   118: swap
/*    */     //   119: invokeinterface 46 2 0
/*    */     //   124: invokestatic 38	clojure/test/tap$print_tap_diagnostic:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   127: pop
/*    */     //   128: goto +6 -> 134
/*    */     //   131: pop
/*    */     //   132: aconst_null
/*    */     //   133: pop
/*    */     //   134: ldc 64
/*    */     //   136: iconst_1
/*    */     //   137: anewarray 66	java/lang/Object
/*    */     //   140: dup
/*    */     //   141: iconst_0
/*    */     //   142: iconst_1
/*    */     //   143: anewarray 66	java/lang/Object
/*    */     //   146: dup
/*    */     //   147: iconst_0
/*    */     //   148: getstatic 69	clojure/test/tap$print_diagnostics:__thunk__2__	Lclojure/lang/ILookupThunk;
/*    */     //   151: dup
/*    */     //   152: aload_0
/*    */     //   153: dup_x2
/*    */     //   154: invokeinterface 46 2 0
/*    */     //   159: dup_x2
/*    */     //   160: if_acmpeq +7 -> 167
/*    */     //   163: pop
/*    */     //   164: goto +25 -> 189
/*    */     //   167: swap
/*    */     //   168: pop
/*    */     //   169: dup
/*    */     //   170: getstatic 72	clojure/test/tap$print_diagnostics:__site__2__	Lclojure/lang/KeywordLookupSite;
/*    */     //   173: swap
/*    */     //   174: invokeinterface 56 2 0
/*    */     //   179: dup
/*    */     //   180: putstatic 69	clojure/test/tap$print_diagnostics:__thunk__2__	Lclojure/lang/ILookupThunk;
/*    */     //   183: swap
/*    */     //   184: invokeinterface 46 2 0
/*    */     //   189: aastore
/*    */     //   190: invokestatic 78	clojure/lang/ArraySeq:create	([Ljava/lang/Object;)Lclojure/lang/ArraySeq;
/*    */     //   193: invokestatic 83	clojure/core$pr_str:invokeStatic	(Lclojure/lang/ISeq;)Ljava/lang/Object;
/*    */     //   196: aastore
/*    */     //   197: invokestatic 78	clojure/lang/ArraySeq:create	([Ljava/lang/Object;)Lclojure/lang/ArraySeq;
/*    */     //   200: invokestatic 88	clojure/core$str:invokeStatic	(Ljava/lang/Object;Lclojure/lang/ISeq;)Ljava/lang/Object;
/*    */     //   203: invokestatic 38	clojure/test/tap$print_tap_diagnostic:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   206: pop
/*    */     //   207: getstatic 92	clojure/test/tap$print_diagnostics:const__9	Lclojure/lang/Keyword;
/*    */     //   210: getstatic 95	clojure/test/tap$print_diagnostics:__thunk__3__	Lclojure/lang/ILookupThunk;
/*    */     //   213: dup
/*    */     //   214: aload_0
/*    */     //   215: dup_x2
/*    */     //   216: invokeinterface 46 2 0
/*    */     //   221: dup_x2
/*    */     //   222: if_acmpeq +7 -> 229
/*    */     //   225: pop
/*    */     //   226: goto +25 -> 251
/*    */     //   229: swap
/*    */     //   230: pop
/*    */     //   231: dup
/*    */     //   232: getstatic 98	clojure/test/tap$print_diagnostics:__site__3__	Lclojure/lang/KeywordLookupSite;
/*    */     //   235: swap
/*    */     //   236: invokeinterface 56 2 0
/*    */     //   241: dup
/*    */     //   242: putstatic 95	clojure/test/tap$print_diagnostics:__thunk__3__	Lclojure/lang/ILookupThunk;
/*    */     //   245: swap
/*    */     //   246: invokeinterface 46 2 0
/*    */     //   251: invokestatic 104	clojure/lang/Util:equiv	(Ljava/lang/Object;Ljava/lang/Object;)Z
/*    */     //   254: ifeq +81 -> 335
/*    */     //   257: ldc 106
/*    */     //   259: iconst_1
/*    */     //   260: anewarray 66	java/lang/Object
/*    */     //   263: dup
/*    */     //   264: iconst_0
/*    */     //   265: iconst_1
/*    */     //   266: anewarray 66	java/lang/Object
/*    */     //   269: dup
/*    */     //   270: iconst_0
/*    */     //   271: getstatic 109	clojure/test/tap$print_diagnostics:__thunk__4__	Lclojure/lang/ILookupThunk;
/*    */     //   274: dup
/*    */     //   275: aload_0
/*    */     //   276: aconst_null
/*    */     //   277: astore_0
/*    */     //   278: dup_x2
/*    */     //   279: invokeinterface 46 2 0
/*    */     //   284: dup_x2
/*    */     //   285: if_acmpeq +7 -> 292
/*    */     //   288: pop
/*    */     //   289: goto +25 -> 314
/*    */     //   292: swap
/*    */     //   293: pop
/*    */     //   294: dup
/*    */     //   295: getstatic 112	clojure/test/tap$print_diagnostics:__site__4__	Lclojure/lang/KeywordLookupSite;
/*    */     //   298: swap
/*    */     //   299: invokeinterface 56 2 0
/*    */     //   304: dup
/*    */     //   305: putstatic 109	clojure/test/tap$print_diagnostics:__thunk__4__	Lclojure/lang/ILookupThunk;
/*    */     //   308: swap
/*    */     //   309: invokeinterface 46 2 0
/*    */     //   314: aastore
/*    */     //   315: invokestatic 78	clojure/lang/ArraySeq:create	([Ljava/lang/Object;)Lclojure/lang/ArraySeq;
/*    */     //   318: invokestatic 83	clojure/core$pr_str:invokeStatic	(Lclojure/lang/ISeq;)Ljava/lang/Object;
/*    */     //   321: aastore
/*    */     //   322: invokestatic 78	clojure/lang/ArraySeq:create	([Ljava/lang/Object;)Lclojure/lang/ArraySeq;
/*    */     //   325: invokestatic 88	clojure/core$str:invokeStatic	(Ljava/lang/Object;Lclojure/lang/ISeq;)Ljava/lang/Object;
/*    */     //   328: invokestatic 38	clojure/test/tap$print_tap_diagnostic:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   331: goto +75 -> 406
/*    */     //   334: pop
/*    */     //   335: ldc 106
/*    */     //   337: iconst_1
/*    */     //   338: anewarray 66	java/lang/Object
/*    */     //   341: dup
/*    */     //   342: iconst_0
/*    */     //   343: new 114	java/io/StringWriter
/*    */     //   346: dup
/*    */     //   347: invokespecial 115	java/io/StringWriter:<init>	()V
/*    */     //   350: astore_1
/*    */     //   351: iconst_2
/*    */     //   352: anewarray 66	java/lang/Object
/*    */     //   355: dup
/*    */     //   356: iconst_0
/*    */     //   357: getstatic 118	clojure/test/tap$print_diagnostics:const__14	Lclojure/lang/Var;
/*    */     //   360: aastore
/*    */     //   361: dup
/*    */     //   362: iconst_1
/*    */     //   363: aload_1
/*    */     //   364: aastore
/*    */     //   365: invokestatic 78	clojure/lang/ArraySeq:create	([Ljava/lang/Object;)Lclojure/lang/ArraySeq;
/*    */     //   368: invokestatic 121	clojure/core$hash_map:invokeStatic	(Lclojure/lang/ISeq;)Ljava/lang/Object;
/*    */     //   371: invokestatic 124	clojure/core$push_thread_bindings:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   374: pop
/*    */     //   375: new 126	clojure/test/tap$print_diagnostics$fn__8050
/*    */     //   378: dup
/*    */     //   379: aload_0
/*    */     //   380: aconst_null
/*    */     //   381: astore_0
/*    */     //   382: aload_1
/*    */     //   383: aconst_null
/*    */     //   384: astore_1
/*    */     //   385: invokespecial 129	clojure/test/tap$print_diagnostics$fn__8050:<init>	(Ljava/lang/Object;Ljava/lang/Object;)V
/*    */     //   388: checkcast 131	clojure/lang/IFn
/*    */     //   391: invokeinterface 134 1 0
/*    */     //   396: aastore
/*    */     //   397: invokestatic 78	clojure/lang/ArraySeq:create	([Ljava/lang/Object;)Lclojure/lang/ArraySeq;
/*    */     //   400: invokestatic 88	clojure/core$str:invokeStatic	(Ljava/lang/Object;Lclojure/lang/ISeq;)Ljava/lang/Object;
/*    */     //   403: invokestatic 38	clojure/test/tap$print_tap_diagnostic:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   406: areturn
/*    */     // Line number table:
/*    */     //   Java source line #78	-> byte code offset #0
/*    */     //   Java source line #79	-> byte code offset #0
/*    */     //   Java source line #81	-> byte code offset #32
/*    */     //   Java source line #81	-> byte code offset #32
/*    */     //   Java source line #81	-> byte code offset #37
/*    */     //   Java source line #82	-> byte code offset #83
/*    */     //   Java source line #82	-> byte code offset #88
/*    */     //   Java source line #83	-> byte code offset #148
/*    */     //   Java source line #83	-> byte code offset #153
/*    */     //   Java source line #84	-> byte code offset #207
/*    */     //   Java source line #84	-> byte code offset #210
/*    */     //   Java source line #84	-> byte code offset #215
/*    */     //   Java source line #84	-> byte code offset #251
/*    */     //   Java source line #85	-> byte code offset #271
/*    */     //   Java source line #85	-> byte code offset #278
/*    */     //   Java source line #89	-> byte code offset #388
/*    */     //   Java source line #89	-> byte code offset #391
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	signature
/*    */     //   0	406	0	data	Object
/*    */     //   351	45	1	s__5244__auto__8053	Object
/*    */   }
/*    */   
/*    */   public Object invoke(Object paramObject)
/*    */   {
/* 78 */     paramObject = null;return invokeStatic(paramObject); } static ILookupThunk __thunk__4__ = __site__4__ = new KeywordLookupSite(RT.keyword(null, "actual")); static final KeywordLookupSite __site__4__; static ILookupThunk __thunk__3__ = __site__3__ = new KeywordLookupSite(RT.keyword(null, "type")); static final KeywordLookupSite __site__3__; static ILookupThunk __thunk__2__ = __site__2__ = new KeywordLookupSite(RT.keyword(null, "expected")); static final KeywordLookupSite __site__2__; static ILookupThunk __thunk__1__ = __site__1__ = new KeywordLookupSite(RT.keyword(null, "message")); static final KeywordLookupSite __site__1__; static ILookupThunk __thunk__0__ = __site__0__ = new KeywordLookupSite(RT.keyword(null, "message")); static final KeywordLookupSite __site__0__; public static final Var const__14 = (Var)RT.var("clojure.core", "*out*"); public static final Keyword const__9 = (Keyword)RT.keyword(null, "pass"); public static final Var const__1 = (Var)RT.var("clojure.test", "*testing-contexts*");
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\test\tap$print_diagnostics.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */