/*    */ package clojure.test;
/*    */ 
/*    */ import clojure.core.print;
/*    */ import clojure.lang.AFunction;
/*    */ import clojure.lang.ArraySeq;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class junit$element_content
/*    */   extends AFunction
/*    */ {
/*    */   public Object invoke(Object paramObject)
/*    */   {
/* 66 */     paramObject = null;return invokeStatic(paramObject); } public static Object invokeStatic(Object content) { Object[] tmp4_1 = new Object[1];content = null;tmp4_1[0] = junit.escape_xml.invokeStatic(content);return core.print.invokeStatic(ArraySeq.create(tmp4_1));
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\test\junit$element_content.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */