/*     */ package clojure.test;
/*     */ 
/*     */ import clojure.core.apply;
/*     */ import clojure.core.concat;
/*     */ import clojure.core.seq__4357;
/*     */ import clojure.lang.AFn;
/*     */ import clojure.lang.ArraySeq;
/*     */ import clojure.lang.ISeq;
/*     */ import clojure.lang.PersistentList.Primordial;
/*     */ import clojure.lang.RT;
/*     */ import clojure.lang.RestFn;
/*     */ import clojure.lang.Symbol;
/*     */ import clojure.lang.Var;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class junit$with_junit_output
/*     */   extends RestFn
/*     */ {
/*     */   public int getRequiredArity()
/*     */   {
/*     */     return 2;
/*     */   }
/*     */   
/*     */   public Object doInvoke(Object paramObject1, Object paramObject2, Object paramObject3)
/*     */   {
/* 182 */     paramObject1 = null;paramObject2 = null;paramObject3 = null;return invokeStatic(paramObject1, paramObject2, (ISeq)paramObject3); } public static Object invokeStatic(Object _AMPERSAND_form, Object _AMPERSAND_env, ISeq body) { Object[] tmp336_333 = new Object[1]; Object[] tmp358_355 = new Object[1]; Object[] tmp386_383 = new Object[1];body = null;tmp386_383[0] = core.seq__4357.invokeStatic(core.concat.invokeStatic(PersistentList.Primordial.invokeStatic(ArraySeq.create(new Object[] { const__17 })), body));tmp358_355[0] = core.apply.invokeStatic(const__5.getRawRoot(), core.seq__4357.invokeStatic(core.concat.invokeStatic(PersistentList.Primordial.invokeStatic(ArraySeq.create(new Object[] { const__16 })), PersistentList.Primordial.invokeStatic(ArraySeq.create(tmp386_383)))));tmp336_333[0] = core.seq__4357.invokeStatic(core.concat.invokeStatic(PersistentList.Primordial.invokeStatic(ArraySeq.create(new Object[] { const__15 })), PersistentList.Primordial.invokeStatic(ArraySeq.create(tmp358_355)), ArraySeq.create(new Object[] { PersistentList.Primordial.invokeStatic(ArraySeq.create(new Object[] { core.seq__4357.invokeStatic(core.concat.invokeStatic(PersistentList.Primordial.invokeStatic(ArraySeq.create(new Object[] { const__18 })), PersistentList.Primordial.invokeStatic(ArraySeq.create(new Object[] { core.seq__4357.invokeStatic(core.concat.invokeStatic(PersistentList.Primordial.invokeStatic(ArraySeq.create(new Object[] { const__19 })), PersistentList.Primordial.invokeStatic(ArraySeq.create(new Object[] { "</testsuites>" })))) })))) })), PersistentList.Primordial.invokeStatic(ArraySeq.create(new Object[] { const__16 })) })));{ PersistentList.Primordial.invokeStatic(ArraySeq.create(new Object[] { core.seq__4357.invokeStatic(core.concat.invokeStatic(PersistentList.Primordial.invokeStatic(ArraySeq.create(new Object[] { const__12 })), PersistentList.Primordial.invokeStatic(ArraySeq.create(new Object[] { core.seq__4357.invokeStatic(core.concat.invokeStatic(PersistentList.Primordial.invokeStatic(ArraySeq.create(new Object[] { const__13 })), PersistentList.Primordial.invokeStatic(ArraySeq.create(new Object[] { "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" })))) })), ArraySeq.create(new Object[] { PersistentList.Primordial.invokeStatic(ArraySeq.create(new Object[] { core.seq__4357.invokeStatic(core.concat.invokeStatic(PersistentList.Primordial.invokeStatic(ArraySeq.create(new Object[] { const__14 })), PersistentList.Primordial.invokeStatic(ArraySeq.create(new Object[] { "<testsuites>" })))) })) }))) })) }[1] = PersistentList.Primordial.invokeStatic(ArraySeq.create(tmp336_333));return core.seq__4357.invokeStatic(core.concat.invokeStatic(PersistentList.Primordial.invokeStatic(ArraySeq.create(new Object[] { const__3 })), PersistentList.Primordial.invokeStatic(ArraySeq.create(new Object[] { core.apply.invokeStatic(const__5.getRawRoot(), core.seq__4357.invokeStatic(core.concat.invokeStatic(PersistentList.Primordial.invokeStatic(ArraySeq.create(new Object[] { const__6 })), PersistentList.Primordial.invokeStatic(ArraySeq.create(new Object[] { const__7 })), ArraySeq.create(new Object[] { PersistentList.Primordial.invokeStatic(ArraySeq.create(new Object[] { const__8 })), PersistentList.Primordial.invokeStatic(ArraySeq.create(new Object[] { core.seq__4357.invokeStatic(core.concat.invokeStatic(PersistentList.Primordial.invokeStatic(ArraySeq.create(new Object[] { const__9 })))) })), PersistentList.Primordial.invokeStatic(ArraySeq.create(new Object[] { const__10 })), PersistentList.Primordial.invokeStatic(ArraySeq.create(new Object[] { const__11 })) })))) })), ArraySeq.create(tmp330_182))); } public static final AFn const__19 = (AFn)Symbol.intern("clojure.core", "println"); public static final AFn const__18 = (AFn)Symbol.intern("clojure.test", "with-test-out"); public static final AFn const__17 = (AFn)Symbol.intern(null, "do"); public static final AFn const__16 = (AFn)Symbol.intern(null, "result__8127__auto__"); public static final AFn const__15 = (AFn)Symbol.intern("clojure.core", "let"); public static final AFn const__14 = (AFn)Symbol.intern("clojure.core", "println"); public static final AFn const__13 = (AFn)Symbol.intern("clojure.core", "println"); public static final AFn const__12 = (AFn)Symbol.intern("clojure.test", "with-test-out"); public static final Object const__11 = Long.valueOf(1L); public static final AFn const__10 = (AFn)Symbol.intern("clojure.test.junit", "*depth*"); public static final AFn const__9 = (AFn)Symbol.intern("clojure.core", "list"); public static final AFn const__8 = (AFn)Symbol.intern("clojure.test.junit", "*var-context*"); public static final AFn const__7 = (AFn)Symbol.intern("clojure.test.junit", "junit-report"); public static final AFn const__6 = (AFn)Symbol.intern("clojure.test", "report"); public static final Var const__5 = (Var)RT.var("clojure.core", "vector"); public static final AFn const__3 = (AFn)Symbol.intern("clojure.core", "binding");
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\test\junit$with_junit_output.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */