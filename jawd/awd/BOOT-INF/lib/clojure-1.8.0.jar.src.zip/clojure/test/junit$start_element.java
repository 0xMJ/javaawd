/*    */ package clojure.test;
/*    */ 
/*    */ import clojure.lang.ISeq;
/*    */ import clojure.lang.RT;
/*    */ import clojure.lang.RestFn;
/*    */ import clojure.lang.Var;
/*    */ 
/*    */ public final class junit$start_element
/*    */   extends RestFn
/*    */ {
/*    */   /* Error */
/*    */   public static Object invokeStatic(Object tag, Object pretty, ISeq p__8076)
/*    */   {
/*    */     // Byte code:
/*    */     //   0: aload_2
/*    */     //   1: aconst_null
/*    */     //   2: astore_2
/*    */     //   3: astore_3
/*    */     //   4: aload_3
/*    */     //   5: aconst_null
/*    */     //   6: astore_3
/*    */     //   7: lconst_0
/*    */     //   8: invokestatic 17	clojure/lang/RT:intCast	(J)I
/*    */     //   11: aconst_null
/*    */     //   12: invokestatic 21	clojure/lang/RT:nth	(Ljava/lang/Object;ILjava/lang/Object;)Ljava/lang/Object;
/*    */     //   15: astore 4
/*    */     //   17: aload_1
/*    */     //   18: dup
/*    */     //   19: ifnull +16 -> 35
/*    */     //   22: getstatic 27	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*    */     //   25: if_acmpeq +11 -> 36
/*    */     //   28: invokestatic 32	clojure/test/junit$indent:invokeStatic	()Ljava/lang/Object;
/*    */     //   31: pop
/*    */     //   32: goto +6 -> 38
/*    */     //   35: pop
/*    */     //   36: aconst_null
/*    */     //   37: pop
/*    */     //   38: iconst_1
/*    */     //   39: anewarray 34	java/lang/Object
/*    */     //   42: dup
/*    */     //   43: iconst_0
/*    */     //   44: ldc 36
/*    */     //   46: iconst_1
/*    */     //   47: anewarray 34	java/lang/Object
/*    */     //   50: dup
/*    */     //   51: iconst_0
/*    */     //   52: aload_0
/*    */     //   53: aconst_null
/*    */     //   54: astore_0
/*    */     //   55: aastore
/*    */     //   56: invokestatic 42	clojure/lang/ArraySeq:create	([Ljava/lang/Object;)Lclojure/lang/ArraySeq;
/*    */     //   59: invokestatic 47	clojure/core$str:invokeStatic	(Ljava/lang/Object;Lclojure/lang/ISeq;)Ljava/lang/Object;
/*    */     //   62: aastore
/*    */     //   63: invokestatic 42	clojure/lang/ArraySeq:create	([Ljava/lang/Object;)Lclojure/lang/ArraySeq;
/*    */     //   66: invokestatic 52	clojure/core$print:invokeStatic	(Lclojure/lang/ISeq;)Ljava/lang/Object;
/*    */     //   69: pop
/*    */     //   70: aload 4
/*    */     //   72: invokestatic 57	clojure/core$seq__4357:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   75: dup
/*    */     //   76: ifnull +385 -> 461
/*    */     //   79: getstatic 27	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*    */     //   82: if_acmpeq +380 -> 462
/*    */     //   85: aload 4
/*    */     //   87: aconst_null
/*    */     //   88: astore 4
/*    */     //   90: invokestatic 57	clojure/core$seq__4357:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   93: astore 5
/*    */     //   95: aconst_null
/*    */     //   96: astore 6
/*    */     //   98: lconst_0
/*    */     //   99: lstore 7
/*    */     //   101: lconst_0
/*    */     //   102: lstore 9
/*    */     //   104: lload 9
/*    */     //   106: lload 7
/*    */     //   108: lcmp
/*    */     //   109: ifge +136 -> 245
/*    */     //   112: aload 6
/*    */     //   114: checkcast 59	clojure/lang/Indexed
/*    */     //   117: lload 9
/*    */     //   119: invokestatic 17	clojure/lang/RT:intCast	(J)I
/*    */     //   122: invokeinterface 62 2 0
/*    */     //   127: astore 11
/*    */     //   129: aload 11
/*    */     //   131: lconst_0
/*    */     //   132: invokestatic 17	clojure/lang/RT:intCast	(J)I
/*    */     //   135: aconst_null
/*    */     //   136: invokestatic 21	clojure/lang/RT:nth	(Ljava/lang/Object;ILjava/lang/Object;)Ljava/lang/Object;
/*    */     //   139: astore 12
/*    */     //   141: aload 11
/*    */     //   143: aconst_null
/*    */     //   144: astore 11
/*    */     //   146: lconst_1
/*    */     //   147: invokestatic 17	clojure/lang/RT:intCast	(J)I
/*    */     //   150: aconst_null
/*    */     //   151: invokestatic 21	clojure/lang/RT:nth	(Ljava/lang/Object;ILjava/lang/Object;)Ljava/lang/Object;
/*    */     //   154: astore 13
/*    */     //   156: iconst_1
/*    */     //   157: anewarray 34	java/lang/Object
/*    */     //   160: dup
/*    */     //   161: iconst_0
/*    */     //   162: ldc 64
/*    */     //   164: iconst_4
/*    */     //   165: anewarray 34	java/lang/Object
/*    */     //   168: dup
/*    */     //   169: iconst_0
/*    */     //   170: aload 12
/*    */     //   172: aconst_null
/*    */     //   173: astore 12
/*    */     //   175: invokestatic 67	clojure/core$name:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   178: aastore
/*    */     //   179: dup
/*    */     //   180: iconst_1
/*    */     //   181: ldc 69
/*    */     //   183: aastore
/*    */     //   184: dup
/*    */     //   185: iconst_2
/*    */     //   186: aload 13
/*    */     //   188: aconst_null
/*    */     //   189: astore 13
/*    */     //   191: invokestatic 72	clojure/test/junit$escape_xml:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   194: aastore
/*    */     //   195: dup
/*    */     //   196: iconst_3
/*    */     //   197: ldc 74
/*    */     //   199: aastore
/*    */     //   200: invokestatic 42	clojure/lang/ArraySeq:create	([Ljava/lang/Object;)Lclojure/lang/ArraySeq;
/*    */     //   203: invokestatic 47	clojure/core$str:invokeStatic	(Ljava/lang/Object;Lclojure/lang/ISeq;)Ljava/lang/Object;
/*    */     //   206: aastore
/*    */     //   207: invokestatic 42	clojure/lang/ArraySeq:create	([Ljava/lang/Object;)Lclojure/lang/ArraySeq;
/*    */     //   210: invokestatic 52	clojure/core$print:invokeStatic	(Lclojure/lang/ISeq;)Ljava/lang/Object;
/*    */     //   213: pop
/*    */     //   214: aload 5
/*    */     //   216: aconst_null
/*    */     //   217: astore 5
/*    */     //   219: aload 6
/*    */     //   221: aconst_null
/*    */     //   222: astore 6
/*    */     //   224: lload 7
/*    */     //   226: lload 9
/*    */     //   228: lconst_1
/*    */     //   229: ladd
/*    */     //   230: lstore 9
/*    */     //   232: lstore 7
/*    */     //   234: astore 6
/*    */     //   236: astore 5
/*    */     //   238: goto -134 -> 104
/*    */     //   241: goto +217 -> 458
/*    */     //   244: pop
/*    */     //   245: aload 5
/*    */     //   247: aconst_null
/*    */     //   248: astore 5
/*    */     //   250: invokestatic 57	clojure/core$seq__4357:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   253: astore 11
/*    */     //   255: aload 11
/*    */     //   257: dup
/*    */     //   258: ifnull +197 -> 455
/*    */     //   261: getstatic 27	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*    */     //   264: if_acmpeq +192 -> 456
/*    */     //   267: aload 11
/*    */     //   269: aconst_null
/*    */     //   270: astore 11
/*    */     //   272: astore 12
/*    */     //   274: aload 12
/*    */     //   276: invokestatic 81	clojure/core$chunked_seq_QMARK_:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   279: dup
/*    */     //   280: ifnull +57 -> 337
/*    */     //   283: getstatic 27	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*    */     //   286: if_acmpeq +52 -> 338
/*    */     //   289: aload 12
/*    */     //   291: invokestatic 84	clojure/core$chunk_first:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   294: astore 13
/*    */     //   296: aload 12
/*    */     //   298: aconst_null
/*    */     //   299: astore 12
/*    */     //   301: invokestatic 87	clojure/core$chunk_rest:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   304: aload 13
/*    */     //   306: aload 13
/*    */     //   308: aconst_null
/*    */     //   309: astore 13
/*    */     //   311: invokestatic 91	clojure/lang/RT:count	(Ljava/lang/Object;)I
/*    */     //   314: invokestatic 94	clojure/lang/RT:intCast	(I)I
/*    */     //   317: i2l
/*    */     //   318: lconst_0
/*    */     //   319: invokestatic 17	clojure/lang/RT:intCast	(J)I
/*    */     //   322: i2l
/*    */     //   323: lstore 9
/*    */     //   325: lstore 7
/*    */     //   327: astore 6
/*    */     //   329: astore 5
/*    */     //   331: goto -227 -> 104
/*    */     //   334: goto +118 -> 452
/*    */     //   337: pop
/*    */     //   338: aload 12
/*    */     //   340: invokestatic 98	clojure/core$first__4339:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   343: astore 13
/*    */     //   345: aload 13
/*    */     //   347: lconst_0
/*    */     //   348: invokestatic 17	clojure/lang/RT:intCast	(J)I
/*    */     //   351: aconst_null
/*    */     //   352: invokestatic 21	clojure/lang/RT:nth	(Ljava/lang/Object;ILjava/lang/Object;)Ljava/lang/Object;
/*    */     //   355: astore 14
/*    */     //   357: aload 13
/*    */     //   359: aconst_null
/*    */     //   360: astore 13
/*    */     //   362: lconst_1
/*    */     //   363: invokestatic 17	clojure/lang/RT:intCast	(J)I
/*    */     //   366: aconst_null
/*    */     //   367: invokestatic 21	clojure/lang/RT:nth	(Ljava/lang/Object;ILjava/lang/Object;)Ljava/lang/Object;
/*    */     //   370: astore 15
/*    */     //   372: iconst_1
/*    */     //   373: anewarray 34	java/lang/Object
/*    */     //   376: dup
/*    */     //   377: iconst_0
/*    */     //   378: ldc 64
/*    */     //   380: iconst_4
/*    */     //   381: anewarray 34	java/lang/Object
/*    */     //   384: dup
/*    */     //   385: iconst_0
/*    */     //   386: aload 14
/*    */     //   388: aconst_null
/*    */     //   389: astore 14
/*    */     //   391: invokestatic 67	clojure/core$name:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   394: aastore
/*    */     //   395: dup
/*    */     //   396: iconst_1
/*    */     //   397: ldc 69
/*    */     //   399: aastore
/*    */     //   400: dup
/*    */     //   401: iconst_2
/*    */     //   402: aload 15
/*    */     //   404: aconst_null
/*    */     //   405: astore 15
/*    */     //   407: invokestatic 72	clojure/test/junit$escape_xml:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   410: aastore
/*    */     //   411: dup
/*    */     //   412: iconst_3
/*    */     //   413: ldc 74
/*    */     //   415: aastore
/*    */     //   416: invokestatic 42	clojure/lang/ArraySeq:create	([Ljava/lang/Object;)Lclojure/lang/ArraySeq;
/*    */     //   419: invokestatic 47	clojure/core$str:invokeStatic	(Ljava/lang/Object;Lclojure/lang/ISeq;)Ljava/lang/Object;
/*    */     //   422: aastore
/*    */     //   423: invokestatic 42	clojure/lang/ArraySeq:create	([Ljava/lang/Object;)Lclojure/lang/ArraySeq;
/*    */     //   426: invokestatic 52	clojure/core$print:invokeStatic	(Lclojure/lang/ISeq;)Ljava/lang/Object;
/*    */     //   429: pop
/*    */     //   430: aload 12
/*    */     //   432: aconst_null
/*    */     //   433: astore 12
/*    */     //   435: invokestatic 101	clojure/core$next__4341:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   438: aconst_null
/*    */     //   439: lconst_0
/*    */     //   440: lconst_0
/*    */     //   441: lstore 9
/*    */     //   443: lstore 7
/*    */     //   445: astore 6
/*    */     //   447: astore 5
/*    */     //   449: goto -345 -> 104
/*    */     //   452: goto +6 -> 458
/*    */     //   455: pop
/*    */     //   456: aconst_null
/*    */     //   457: pop
/*    */     //   458: goto +6 -> 464
/*    */     //   461: pop
/*    */     //   462: aconst_null
/*    */     //   463: pop
/*    */     //   464: iconst_1
/*    */     //   465: anewarray 34	java/lang/Object
/*    */     //   468: dup
/*    */     //   469: iconst_0
/*    */     //   470: ldc 110
/*    */     //   472: aastore
/*    */     //   473: invokestatic 42	clojure/lang/ArraySeq:create	([Ljava/lang/Object;)Lclojure/lang/ArraySeq;
/*    */     //   476: invokestatic 52	clojure/core$print:invokeStatic	(Lclojure/lang/ISeq;)Ljava/lang/Object;
/*    */     //   479: pop
/*    */     //   480: aload_1
/*    */     //   481: aconst_null
/*    */     //   482: astore_1
/*    */     //   483: dup
/*    */     //   484: ifnull +27 -> 511
/*    */     //   487: getstatic 27	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*    */     //   490: if_acmpeq +22 -> 512
/*    */     //   493: getstatic 114	clojure/test/junit$start_element:const__18	Lclojure/lang/Var;
/*    */     //   496: invokevirtual 119	clojure/lang/Var:getRawRoot	()Ljava/lang/Object;
/*    */     //   499: checkcast 121	clojure/lang/IFn
/*    */     //   502: invokeinterface 124 1 0
/*    */     //   507: pop
/*    */     //   508: goto +6 -> 514
/*    */     //   511: pop
/*    */     //   512: aconst_null
/*    */     //   513: pop
/*    */     //   514: getstatic 127	clojure/test/junit$start_element:const__19	Lclojure/lang/Var;
/*    */     //   517: getstatic 127	clojure/test/junit$start_element:const__19	Lclojure/lang/Var;
/*    */     //   520: invokevirtual 130	clojure/lang/Var:get	()Ljava/lang/Object;
/*    */     //   523: invokestatic 136	clojure/lang/Numbers:inc	(Ljava/lang/Object;)Ljava/lang/Number;
/*    */     //   526: invokevirtual 139	clojure/lang/Var:set	(Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   529: areturn
/*    */     // Line number table:
/*    */     //   Java source line #55	-> byte code offset #0
/*    */     //   Java source line #55	-> byte code offset #12
/*    */     //   Java source line #57	-> byte code offset #17
/*    */     //   Java source line #59	-> byte code offset #70
/*    */     //   Java source line #60	-> byte code offset #104
/*    */     //   Java source line #60	-> byte code offset #104
/*    */     //   Java source line #60	-> byte code offset #122
/*    */     //   Java source line #60	-> byte code offset #136
/*    */     //   Java source line #60	-> byte code offset #151
/*    */     //   Java source line #60	-> byte code offset #228
/*    */     //   Java source line #60	-> byte code offset #255
/*    */     //   Java source line #60	-> byte code offset #274
/*    */     //   Java source line #60	-> byte code offset #311
/*    */     //   Java source line #60	-> byte code offset #314
/*    */     //   Java source line #60	-> byte code offset #319
/*    */     //   Java source line #60	-> byte code offset #352
/*    */     //   Java source line #60	-> byte code offset #367
/*    */     //   Java source line #63	-> byte code offset #480
/*    */     //   Java source line #63	-> byte code offset #499
/*    */     //   Java source line #63	-> byte code offset #502
/*    */     //   Java source line #64	-> byte code offset #523
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	signature
/*    */     //   0	529	0	tag	Object
/*    */     //   0	529	1	pretty	Object
/*    */     //   0	529	2	p__8076	ISeq
/*    */     //   4	525	3	vec__8077	Object
/*    */     //   17	512	4	attrs	Object
/*    */     //   95	363	5	seq_8078	Object
/*    */     //   98	360	6	chunk_8079	Object
/*    */     //   101	357	7	count_8080	long
/*    */     //   104	354	9	i_8081	long
/*    */     //   129	112	11	vec__8082	Object
/*    */     //   255	203	11	temp__4657__auto__8086	Object
/*    */     //   141	100	12	key	Object
/*    */     //   274	178	12	seq_8078	Object
/*    */     //   156	85	13	value	Object
/*    */     //   296	38	13	c__4917__auto__8085	Object
/*    */     //   345	107	13	vec__8083	Object
/*    */     //   357	95	14	key	Object
/*    */     //   372	80	15	value	Object
/*    */   }
/*    */   
/*    */   public Object doInvoke(Object paramObject1, Object paramObject2, Object paramObject3)
/*    */   {
/* 55 */     paramObject1 = null;paramObject2 = null;paramObject3 = null;return invokeStatic(paramObject1, paramObject2, (ISeq)paramObject3); } public static final Var const__19 = (Var)RT.var("clojure.test.junit", "*depth*"); public static final Var const__18 = (Var)RT.var("clojure.core", "println");
/*    */   
/*    */   public int getRequiredArity()
/*    */   {
/*    */     return 2;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\test\junit$start_element.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */