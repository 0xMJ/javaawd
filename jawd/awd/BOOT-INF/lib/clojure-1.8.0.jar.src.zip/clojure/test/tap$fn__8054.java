/*    */ package clojure.test;
/*    */ 
/*    */ import clojure.lang.AFunction;
/*    */ import clojure.lang.Keyword;
/*    */ import clojure.lang.RT;
/*    */ import clojure.lang.Var;
/*    */ 
/*    */ public final class tap$fn__8054
/*    */   extends AFunction
/*    */ {
/*    */   /* Error */
/*    */   public static Object invokeStatic(Object data)
/*    */   {
/*    */     // Byte code:
/*    */     //   0: iconst_2
/*    */     //   1: anewarray 13	java/lang/Object
/*    */     //   4: dup
/*    */     //   5: iconst_0
/*    */     //   6: getstatic 17	clojure/test/tap$fn__8054:const__2	Lclojure/lang/Var;
/*    */     //   9: aastore
/*    */     //   10: dup
/*    */     //   11: iconst_1
/*    */     //   12: getstatic 20	clojure/test/tap$fn__8054:const__3	Lclojure/lang/Var;
/*    */     //   15: invokevirtual 26	clojure/lang/Var:get	()Ljava/lang/Object;
/*    */     //   18: aastore
/*    */     //   19: invokestatic 32	clojure/lang/ArraySeq:create	([Ljava/lang/Object;)Lclojure/lang/ArraySeq;
/*    */     //   22: invokestatic 37	clojure/core$hash_map:invokeStatic	(Lclojure/lang/ISeq;)Ljava/lang/Object;
/*    */     //   25: invokestatic 41	clojure/core$push_thread_bindings:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   28: pop
/*    */     //   29: getstatic 45	clojure/test/tap$fn__8054:const__5	Lclojure/lang/Keyword;
/*    */     //   32: invokestatic 48	clojure/test$inc_report_counter:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   35: pop
/*    */     //   36: aload_0
/*    */     //   37: invokestatic 51	clojure/test$testing_vars_str:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   40: invokestatic 54	clojure/test/tap$print_tap_pass:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   43: pop
/*    */     //   44: aload_0
/*    */     //   45: aconst_null
/*    */     //   46: astore_0
/*    */     //   47: invokestatic 57	clojure/test/tap$print_diagnostics:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   50: astore_1
/*    */     //   51: invokestatic 61	clojure/core$pop_thread_bindings:invokeStatic	()Ljava/lang/Object;
/*    */     //   54: pop
/*    */     //   55: goto +10 -> 65
/*    */     //   58: astore_2
/*    */     //   59: invokestatic 61	clojure/core$pop_thread_bindings:invokeStatic	()Ljava/lang/Object;
/*    */     //   62: pop
/*    */     //   63: aload_2
/*    */     //   64: athrow
/*    */     //   65: aload_1
/*    */     //   66: areturn
/*    */     // Line number table:
/*    */     //   Java source line #94	-> byte code offset #0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	signature
/*    */     //   0	66	0	data	Object
/*    */     //   50	16	1	localObject1	Object
/*    */     //   58	6	2	localObject2	Object
/*    */     // Exception table:
/*    */     //   from	to	target	type
/*    */     //   29	51	58	finally
/*    */   }
/*    */   
/*    */   public Object invoke(Object paramObject)
/*    */   {
/* 94 */     paramObject = null;return invokeStatic(paramObject); } public static final Keyword const__5 = (Keyword)RT.keyword(null, "pass"); public static final Var const__3 = (Var)RT.var("clojure.test", "*test-out*"); public static final Var const__2 = (Var)RT.var("clojure.core", "*out*");
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\test\tap$fn__8054.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */