/*     */ package clojure.test;
/*     */ 
/*     */ import clojure.lang.AFn;
/*     */ import clojure.lang.AFunction;
/*     */ import clojure.lang.ArraySeq;
/*     */ import clojure.lang.RT;
/*     */ import clojure.lang.Symbol;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class junit$start_suite
/*     */   extends AFunction
/*     */ {
/*     */   public Object invoke(Object paramObject)
/*     */   {
/* 104 */     paramObject = null;return invokeStatic(paramObject); } public static final AFn const__5 = (AFn)Symbol.intern(null, "testsuite"); public static Object invokeStatic(Object name) { name = null;Object vec__8097 = junit.package_class.invokeStatic(name);
/*     */     
/* 106 */     Object package = RT.nth(vec__8097, RT.intCast(0L), null);vec__8097 = null;Object classname = RT.nth(vec__8097, RT.intCast(1L), null); Object[] tmp39_36 = new Object[1];package = null;classname = null;tmp39_36[0] = junit.suite_attrs.invokeStatic(package, classname);return junit.start_element.invokeStatic(const__5, Boolean.TRUE, ArraySeq.create(tmp39_36));
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\test\junit$start_suite.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */