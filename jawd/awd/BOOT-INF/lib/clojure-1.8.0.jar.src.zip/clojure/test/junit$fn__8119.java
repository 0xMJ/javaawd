/*     */ package clojure.test;
/*     */ 
/*     */ import clojure.lang.AFunction;
/*     */ import clojure.lang.Keyword;
/*     */ import clojure.lang.RT;
/*     */ import clojure.lang.Var;
/*     */ 
/*     */ public final class junit$fn__8119
/*     */   extends AFunction
/*     */ {
/*     */   /* Error */
/*     */   public static Object invokeStatic(Object m)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: iconst_2
/*     */     //   1: anewarray 13	java/lang/Object
/*     */     //   4: dup
/*     */     //   5: iconst_0
/*     */     //   6: getstatic 17	clojure/test/junit$fn__8119:const__2	Lclojure/lang/Var;
/*     */     //   9: aastore
/*     */     //   10: dup
/*     */     //   11: iconst_1
/*     */     //   12: getstatic 20	clojure/test/junit$fn__8119:const__3	Lclojure/lang/Var;
/*     */     //   15: invokevirtual 26	clojure/lang/Var:get	()Ljava/lang/Object;
/*     */     //   18: aastore
/*     */     //   19: invokestatic 32	clojure/lang/ArraySeq:create	([Ljava/lang/Object;)Lclojure/lang/ArraySeq;
/*     */     //   22: invokestatic 37	clojure/core$hash_map:invokeStatic	(Lclojure/lang/ISeq;)Ljava/lang/Object;
/*     */     //   25: invokestatic 41	clojure/core$push_thread_bindings:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   28: pop
/*     */     //   29: getstatic 45	clojure/test/junit$fn__8119:const__5	Lclojure/lang/Keyword;
/*     */     //   32: invokestatic 48	clojure/test$inc_report_counter:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   35: astore_1
/*     */     //   36: invokestatic 52	clojure/core$pop_thread_bindings:invokeStatic	()Ljava/lang/Object;
/*     */     //   39: pop
/*     */     //   40: goto +10 -> 50
/*     */     //   43: astore_2
/*     */     //   44: invokestatic 52	clojure/core$pop_thread_bindings:invokeStatic	()Ljava/lang/Object;
/*     */     //   47: pop
/*     */     //   48: aload_2
/*     */     //   49: athrow
/*     */     //   50: aload_1
/*     */     //   51: areturn
/*     */     // Line number table:
/*     */     //   Java source line #162	-> byte code offset #0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	51	0	m	Object
/*     */     //   35	16	1	localObject1	Object
/*     */     //   43	6	2	localObject2	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   29	36	43	finally
/*     */   }
/*     */   
/*     */   public Object invoke(Object paramObject)
/*     */   {
/* 162 */     paramObject = null;return invokeStatic(paramObject); } public static final Keyword const__5 = (Keyword)RT.keyword(null, "pass"); public static final Var const__3 = (Var)RT.var("clojure.test", "*test-out*"); public static final Var const__2 = (Var)RT.var("clojure.core", "*out*");
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\test\junit$fn__8119.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */