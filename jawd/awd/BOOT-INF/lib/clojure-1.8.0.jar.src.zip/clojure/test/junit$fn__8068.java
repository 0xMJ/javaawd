/*    */ package clojure.test;
/*    */ 
/*    */ import clojure.core.str;
/*    */ import clojure.lang.AFunction;
/*    */ import clojure.lang.ArraySeq;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class junit$fn__8068
/*    */   extends AFunction
/*    */ {
/*    */   public Object invoke(Object paramObject)
/*    */   {
/* 44 */     paramObject = null;return invokeStatic(paramObject); } public static Object invokeStatic(Object p1__8067_SHARP_) { Object[] tmp7_4 = new Object[2];p1__8067_SHARP_ = null;tmp7_4[0] = p1__8067_SHARP_; Object[] tmp13_7 = tmp7_4;tmp13_7[1] = const__2;return core.str.invokeStatic(const__1, ArraySeq.create(tmp13_7)); } public static final Object const__2 = Character.valueOf(';'); public static final Object const__1 = Character.valueOf('&');
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\test\junit$fn__8068.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */