/*     */ package clojure.lang;
/*     */ 
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Atom
/*     */   extends ARef
/*     */   implements IAtom
/*     */ {
/*     */   final AtomicReference state;
/*     */   
/*     */   public Atom(Object state)
/*     */   {
/*  21 */     this.state = new AtomicReference(state);
/*     */   }
/*     */   
/*     */   public Atom(Object state, IPersistentMap meta) {
/*  25 */     super(meta);
/*  26 */     this.state = new AtomicReference(state);
/*     */   }
/*     */   
/*     */   public Object deref() {
/*  30 */     return this.state.get();
/*     */   }
/*     */   
/*     */   public Object swap(IFn f)
/*     */   {
/*     */     for (;;) {
/*  36 */       Object v = deref();
/*  37 */       Object newv = f.invoke(v);
/*  38 */       validate(newv);
/*  39 */       if (this.state.compareAndSet(v, newv))
/*     */       {
/*  41 */         notifyWatches(v, newv);
/*  42 */         return newv;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public Object swap(IFn f, Object arg)
/*     */   {
/*     */     for (;;) {
/*  50 */       Object v = deref();
/*  51 */       Object newv = f.invoke(v, arg);
/*  52 */       validate(newv);
/*  53 */       if (this.state.compareAndSet(v, newv))
/*     */       {
/*  55 */         notifyWatches(v, newv);
/*  56 */         return newv;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public Object swap(IFn f, Object arg1, Object arg2)
/*     */   {
/*     */     for (;;) {
/*  64 */       Object v = deref();
/*  65 */       Object newv = f.invoke(v, arg1, arg2);
/*  66 */       validate(newv);
/*  67 */       if (this.state.compareAndSet(v, newv))
/*     */       {
/*  69 */         notifyWatches(v, newv);
/*  70 */         return newv;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public Object swap(IFn f, Object x, Object y, ISeq args)
/*     */   {
/*     */     for (;;) {
/*  78 */       Object v = deref();
/*  79 */       Object newv = f.applyTo(RT.listStar(v, x, y, args));
/*  80 */       validate(newv);
/*  81 */       if (this.state.compareAndSet(v, newv))
/*     */       {
/*  83 */         notifyWatches(v, newv);
/*  84 */         return newv;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean compareAndSet(Object oldv, Object newv) {
/*  90 */     validate(newv);
/*  91 */     boolean ret = this.state.compareAndSet(oldv, newv);
/*  92 */     if (ret)
/*  93 */       notifyWatches(oldv, newv);
/*  94 */     return ret;
/*     */   }
/*     */   
/*     */   public Object reset(Object newval) {
/*  98 */     Object oldval = this.state.get();
/*  99 */     validate(newval);
/* 100 */     this.state.set(newval);
/* 101 */     notifyWatches(oldval, newval);
/* 102 */     return newval;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\Atom.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */