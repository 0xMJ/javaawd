/*    */ package clojure.lang;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ChunkBuffer
/*    */   implements Counted
/*    */ {
/*    */   Object[] buffer;
/*    */   
/*    */ 
/*    */ 
/*    */   int end;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public ChunkBuffer(int capacity)
/*    */   {
/* 20 */     this.buffer = new Object[capacity];
/* 21 */     this.end = 0;
/*    */   }
/*    */   
/*    */   public void add(Object o) {
/* 25 */     this.buffer[(this.end++)] = o;
/*    */   }
/*    */   
/*    */   public IChunk chunk() {
/* 29 */     ArrayChunk ret = new ArrayChunk(this.buffer, 0, this.end);
/* 30 */     this.buffer = null;
/* 31 */     return ret;
/*    */   }
/*    */   
/*    */   public int count() {
/* 35 */     return this.end;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\ChunkBuffer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */