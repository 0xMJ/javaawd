package clojure.lang;

public abstract interface IBlockingDeref
{
  public abstract Object deref(long paramLong, Object paramObject);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\IBlockingDeref.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */