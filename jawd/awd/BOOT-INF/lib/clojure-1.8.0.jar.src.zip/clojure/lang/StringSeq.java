/*    */ package clojure.lang;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StringSeq
/*    */   extends ASeq
/*    */   implements IndexedSeq
/*    */ {
/*    */   public final CharSequence s;
/*    */   
/*    */ 
/*    */ 
/*    */   public final int i;
/*    */   
/*    */ 
/*    */ 
/*    */   public static StringSeq create(CharSequence s)
/*    */   {
/* 20 */     if (s.length() == 0)
/* 21 */       return null;
/* 22 */     return new StringSeq(null, s, 0);
/*    */   }
/*    */   
/*    */   StringSeq(IPersistentMap meta, CharSequence s, int i) {
/* 26 */     super(meta);
/* 27 */     this.s = s;
/* 28 */     this.i = i;
/*    */   }
/*    */   
/*    */   public Obj withMeta(IPersistentMap meta) {
/* 32 */     if (meta == meta())
/* 33 */       return this;
/* 34 */     return new StringSeq(meta, this.s, this.i);
/*    */   }
/*    */   
/*    */   public Object first() {
/* 38 */     return Character.valueOf(this.s.charAt(this.i));
/*    */   }
/*    */   
/*    */   public ISeq next() {
/* 42 */     if (this.i + 1 < this.s.length())
/* 43 */       return new StringSeq(this._meta, this.s, this.i + 1);
/* 44 */     return null;
/*    */   }
/*    */   
/*    */   public int index() {
/* 48 */     return this.i;
/*    */   }
/*    */   
/*    */   public int count() {
/* 52 */     return this.s.length() - this.i;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\StringSeq.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */