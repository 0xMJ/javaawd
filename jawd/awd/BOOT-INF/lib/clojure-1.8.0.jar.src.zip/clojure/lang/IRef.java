package clojure.lang;

public abstract interface IRef
  extends IDeref
{
  public abstract void setValidator(IFn paramIFn);
  
  public abstract IFn getValidator();
  
  public abstract IPersistentMap getWatches();
  
  public abstract IRef addWatch(Object paramObject, IFn paramIFn);
  
  public abstract IRef removeWatch(Object paramObject);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\IRef.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */