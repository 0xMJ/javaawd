/*    */ package clojure.lang;
/*    */ 
/*    */ import java.lang.ref.Reference;
/*    */ import java.lang.ref.ReferenceQueue;
/*    */ import java.lang.ref.SoftReference;
/*    */ import java.net.URL;
/*    */ import java.net.URLClassLoader;
/*    */ import java.util.HashMap;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DynamicClassLoader
/*    */   extends URLClassLoader
/*    */ {
/* 25 */   HashMap<Integer, Object[]> constantVals = new HashMap();
/* 26 */   static ConcurrentHashMap<String, Reference<Class>> classCache = new ConcurrentHashMap();
/*    */   
/*    */ 
/* 29 */   static final URL[] EMPTY_URLS = new URL[0];
/*    */   
/* 31 */   static final ReferenceQueue rq = new ReferenceQueue();
/*    */   
/*    */   public DynamicClassLoader()
/*    */   {
/* 35 */     super(EMPTY_URLS, (Thread.currentThread().getContextClassLoader() == null) || (Thread.currentThread().getContextClassLoader() == ClassLoader.getSystemClassLoader()) ? Compiler.class.getClassLoader() : Thread.currentThread().getContextClassLoader());
/*    */   }
/*    */   
/*    */ 
/*    */   public DynamicClassLoader(ClassLoader parent)
/*    */   {
/* 41 */     super(EMPTY_URLS, parent);
/*    */   }
/*    */   
/*    */   public Class defineClass(String name, byte[] bytes, Object srcForm) {
/* 45 */     Util.clearCache(rq, classCache);
/* 46 */     Class c = defineClass(name, bytes, 0, bytes.length);
/* 47 */     classCache.put(name, new SoftReference(c, rq));
/* 48 */     return c;
/*    */   }
/*    */   
/*    */   static Class<?> findInMemoryClass(String name) {
/* 52 */     Reference<Class> cr = (Reference)classCache.get(name);
/* 53 */     if (cr != null)
/*    */     {
/* 55 */       Class c = (Class)cr.get();
/* 56 */       if (c != null) {
/* 57 */         return c;
/*    */       }
/* 59 */       classCache.remove(name, cr);
/*    */     }
/* 61 */     return null;
/*    */   }
/*    */   
/*    */   protected Class<?> findClass(String name) throws ClassNotFoundException {
/* 65 */     Class c = findInMemoryClass(name);
/* 66 */     if (c != null) {
/* 67 */       return c;
/*    */     }
/* 69 */     return super.findClass(name);
/*    */   }
/*    */   
/*    */   protected synchronized Class<?> loadClass(String name, boolean resolve) throws ClassNotFoundException {
/* 73 */     Class c = findLoadedClass(name);
/* 74 */     if (c == null) {
/* 75 */       c = findInMemoryClass(name);
/* 76 */       if (c == null)
/* 77 */         c = super.loadClass(name, false);
/*    */     }
/* 79 */     if (resolve)
/* 80 */       resolveClass(c);
/* 81 */     return c;
/*    */   }
/*    */   
/*    */   public void registerConstants(int id, Object[] val) {
/* 85 */     this.constantVals.put(Integer.valueOf(id), val);
/*    */   }
/*    */   
/*    */   public Object[] getConstants(int id) {
/* 89 */     return (Object[])this.constantVals.get(Integer.valueOf(id));
/*    */   }
/*    */   
/*    */   public void addURL(URL url) {
/* 93 */     super.addURL(url);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\DynamicClassLoader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */