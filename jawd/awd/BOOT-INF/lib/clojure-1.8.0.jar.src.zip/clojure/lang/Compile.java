/*    */ package clojure.lang;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStreamWriter;
/*    */ import java.io.PrintWriter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Compile
/*    */ {
/*    */   private static final String PATH_PROP = "clojure.compile.path";
/*    */   private static final String REFLECTION_WARNING_PROP = "clojure.compile.warn-on-reflection";
/*    */   private static final String UNCHECKED_MATH_PROP = "clojure.compile.unchecked-math";
/* 29 */   private static final Var compile_path = RT.var("clojure.core", "*compile-path*");
/* 30 */   private static final Var compile = RT.var("clojure.core", "compile");
/* 31 */   private static final Var warn_on_reflection = RT.var("clojure.core", "*warn-on-reflection*");
/* 32 */   private static final Var unchecked_math = RT.var("clojure.core", "*unchecked-math*");
/*    */   
/*    */   public static void main(String[] args) throws IOException
/*    */   {
/* 36 */     OutputStreamWriter out = (OutputStreamWriter)RT.OUT.deref();
/* 37 */     PrintWriter err = RT.errPrintWriter();
/* 38 */     String path = System.getProperty("clojure.compile.path");
/* 39 */     int count = args.length;
/*    */     
/* 41 */     if (path == null)
/*    */     {
/* 43 */       err.println("ERROR: Must set system property clojure.compile.path\nto the location for compiled .class files.\nThis directory must also be on your CLASSPATH.");
/*    */       
/*    */ 
/* 46 */       System.exit(1);
/*    */     }
/*    */     
/* 49 */     boolean warnOnReflection = System.getProperty("clojure.compile.warn-on-reflection", "false").equals("true");
/* 50 */     String uncheckedMathProp = System.getProperty("clojure.compile.unchecked-math");
/* 51 */     Object uncheckedMath = Boolean.FALSE;
/* 52 */     if ("true".equals(uncheckedMathProp)) {
/* 53 */       uncheckedMath = Boolean.TRUE;
/* 54 */     } else if ("warn-on-boxed".equals(uncheckedMathProp)) {
/* 55 */       uncheckedMath = Keyword.intern("warn-on-boxed");
/*    */     }
/*    */     try
/*    */     {
/* 59 */       Var.pushThreadBindings(RT.map(new Object[] { compile_path, path, warn_on_reflection, Boolean.valueOf(warnOnReflection), unchecked_math, uncheckedMath }));
/*    */       
/*    */ 
/*    */ 
/* 63 */       for (String lib : args)
/*    */       {
/* 65 */         out.write("Compiling " + lib + " to " + path + "\n");
/* 66 */         out.flush();
/* 67 */         compile.invoke(Symbol.intern(lib));
/*    */       }
/*    */       return;
/*    */     }
/*    */     finally {
/* 72 */       Var.popThreadBindings();
/*    */       try
/*    */       {
/* 75 */         out.flush();
/*    */       }
/*    */       catch (IOException e)
/*    */       {
/* 79 */         e.printStackTrace(err);
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\Compile.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */