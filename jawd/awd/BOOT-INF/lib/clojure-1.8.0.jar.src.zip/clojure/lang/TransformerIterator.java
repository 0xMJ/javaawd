/*     */ package clojure.lang;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Queue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TransformerIterator
/*     */   implements Iterator
/*     */ {
/*  23 */   private static final Buffer EMPTY = new Empty(null);
/*  24 */   private static final Object NONE = new Object();
/*     */   
/*     */   private final Iterator sourceIter;
/*     */   
/*     */   private final IFn xf;
/*     */   
/*     */   private final boolean multi;
/*     */   
/*  32 */   private volatile Buffer buffer = EMPTY;
/*  33 */   private volatile Object next = NONE;
/*  34 */   private volatile boolean completed = false;
/*     */   
/*     */   private TransformerIterator(IFn xform, Iterator sourceIter, boolean multi) {
/*  37 */     this.sourceIter = sourceIter;
/*  38 */     this.xf = ((IFn)xform.invoke(new AFn() {
/*     */       public Object invoke() {
/*  40 */         return null;
/*     */       }
/*     */       
/*     */       public Object invoke(Object acc) {
/*  44 */         return acc;
/*     */       }
/*     */       
/*     */       public Object invoke(Object acc, Object o) {
/*  48 */         TransformerIterator.this.buffer = TransformerIterator.this.buffer.add(o);
/*  49 */         return acc;
/*     */       }
/*  51 */     }));
/*  52 */     this.multi = multi;
/*     */   }
/*     */   
/*     */   public static Iterator create(IFn xform, Iterator source) {
/*  56 */     return new TransformerIterator(xform, source, false);
/*     */   }
/*     */   
/*     */   public static Iterator createMulti(IFn xform, List sources) {
/*  60 */     Iterator[] iters = new Iterator[sources.size()];
/*  61 */     for (int i = 0; i < sources.size(); i++)
/*  62 */       iters[i] = ((Iterator)sources.get(i));
/*  63 */     return new TransformerIterator(xform, new MultiIterator(iters), true);
/*     */   }
/*     */   
/*     */   private boolean step() {
/*  67 */     if (this.next != NONE) {
/*  68 */       return true;
/*     */     }
/*  70 */     while (this.next == NONE) {
/*  71 */       if (this.buffer.isEmpty()) {
/*  72 */         if (this.completed)
/*  73 */           return false;
/*  74 */         if (this.sourceIter.hasNext()) {
/*  75 */           Object iter = null;
/*  76 */           if (this.multi) {
/*  77 */             iter = this.xf.applyTo(RT.cons(null, this.sourceIter.next()));
/*     */           } else {
/*  79 */             iter = this.xf.invoke(null, this.sourceIter.next());
/*     */           }
/*  81 */           if (RT.isReduced(iter)) {
/*  82 */             this.xf.invoke(null);
/*  83 */             this.completed = true;
/*     */           }
/*     */         } else {
/*  86 */           this.xf.invoke(null);
/*  87 */           this.completed = true;
/*     */         }
/*     */       } else {
/*  90 */         this.next = this.buffer.remove();
/*     */       }
/*     */     }
/*  93 */     return true;
/*     */   }
/*     */   
/*     */   public boolean hasNext() {
/*  97 */     return step();
/*     */   }
/*     */   
/*     */   public Object next() {
/* 101 */     if (hasNext()) {
/* 102 */       Object ret = this.next;
/* 103 */       this.next = NONE;
/* 104 */       return ret;
/*     */     }
/* 106 */     throw new NoSuchElementException();
/*     */   }
/*     */   
/*     */ 
/* 110 */   public void remove() { throw new UnsupportedOperationException(); }
/*     */   
/*     */   private static abstract interface Buffer {
/*     */     public abstract Buffer add(Object paramObject);
/*     */     
/*     */     public abstract Object remove();
/*     */     
/*     */     public abstract boolean isEmpty();
/*     */   }
/*     */   
/*     */   private static class Empty implements TransformerIterator.Buffer {
/* 121 */     public TransformerIterator.Buffer add(Object o) { return new TransformerIterator.Single(o); }
/*     */     
/*     */     public Object remove()
/*     */     {
/* 125 */       throw new IllegalStateException("Removing object from empty buffer");
/*     */     }
/*     */     
/*     */     public boolean isEmpty() {
/* 129 */       return true;
/*     */     }
/*     */     
/*     */     public String toString() {
/* 133 */       return "Empty";
/*     */     }
/*     */   }
/*     */   
/*     */   private static class Single implements TransformerIterator.Buffer {
/*     */     private volatile Object val;
/*     */     
/*     */     public Single(Object o) {
/* 141 */       this.val = o;
/*     */     }
/*     */     
/*     */     public TransformerIterator.Buffer add(Object o) {
/* 145 */       if (this.val == TransformerIterator.NONE) {
/* 146 */         this.val = o;
/* 147 */         return this;
/*     */       }
/* 149 */       return new TransformerIterator.Many(this.val, o);
/*     */     }
/*     */     
/*     */     public Object remove()
/*     */     {
/* 154 */       if (this.val == TransformerIterator.NONE) {
/* 155 */         throw new IllegalStateException("Removing object from empty buffer");
/*     */       }
/* 157 */       Object ret = this.val;
/* 158 */       this.val = TransformerIterator.NONE;
/* 159 */       return ret;
/*     */     }
/*     */     
/*     */     public boolean isEmpty() {
/* 163 */       return this.val == TransformerIterator.NONE;
/*     */     }
/*     */     
/*     */     public String toString() {
/* 167 */       return "Single: " + this.val;
/*     */     }
/*     */   }
/*     */   
/*     */   private static class Many implements TransformerIterator.Buffer {
/* 172 */     private final Queue vals = new LinkedList();
/*     */     
/*     */     public Many(Object o1, Object o2) {
/* 175 */       this.vals.add(o1);
/* 176 */       this.vals.add(o2);
/*     */     }
/*     */     
/*     */     public TransformerIterator.Buffer add(Object o) {
/* 180 */       this.vals.add(o);
/* 181 */       return this;
/*     */     }
/*     */     
/*     */     public Object remove() {
/* 185 */       return this.vals.remove();
/*     */     }
/*     */     
/*     */     public boolean isEmpty() {
/* 189 */       return this.vals.isEmpty();
/*     */     }
/*     */     
/*     */     public String toString() {
/* 193 */       return "Many: " + this.vals.toString();
/*     */     }
/*     */   }
/*     */   
/*     */   private static class MultiIterator implements Iterator {
/*     */     private final Iterator[] iters;
/*     */     
/*     */     public MultiIterator(Iterator[] iters) {
/* 201 */       this.iters = iters;
/*     */     }
/*     */     
/*     */     public boolean hasNext() {
/* 205 */       for (Iterator iter : this.iters)
/* 206 */         if (!iter.hasNext())
/* 207 */           return false;
/* 208 */       return true;
/*     */     }
/*     */     
/*     */     public Object next() {
/* 212 */       Object[] nexts = new Object[this.iters.length];
/* 213 */       for (int i = 0; i < this.iters.length; i++)
/* 214 */         nexts[i] = this.iters[i].next();
/* 215 */       return new ArraySeq(nexts, 0);
/*     */     }
/*     */     
/*     */     public void remove() {
/* 219 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\TransformerIterator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */