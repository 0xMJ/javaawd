/*     */ package clojure.lang;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Murmur3
/*     */ {
/*     */   private static final int seed = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final int C1 = -862048943;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final int C2 = 461845907;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int hashInt(int input)
/*     */   {
/*  51 */     if (input == 0) return 0;
/*  52 */     int k1 = mixK1(input);
/*  53 */     int h1 = mixH1(0, k1);
/*     */     
/*  55 */     return fmix(h1, 4);
/*     */   }
/*     */   
/*     */   public static int hashLong(long input) {
/*  59 */     if (input == 0L) return 0;
/*  60 */     int low = (int)input;
/*  61 */     int high = (int)(input >>> 32);
/*     */     
/*  63 */     int k1 = mixK1(low);
/*  64 */     int h1 = mixH1(0, k1);
/*     */     
/*  66 */     k1 = mixK1(high);
/*  67 */     h1 = mixH1(h1, k1);
/*     */     
/*  69 */     return fmix(h1, 8);
/*     */   }
/*     */   
/*     */   public static int hashUnencodedChars(CharSequence input) {
/*  73 */     int h1 = 0;
/*     */     
/*     */ 
/*  76 */     for (int i = 1; i < input.length(); i += 2)
/*     */     {
/*  78 */       int k1 = input.charAt(i - 1) | input.charAt(i) << '\020';
/*  79 */       k1 = mixK1(k1);
/*  80 */       h1 = mixH1(h1, k1);
/*     */     }
/*     */     
/*     */ 
/*  84 */     if ((input.length() & 0x1) == 1)
/*     */     {
/*  86 */       int k1 = input.charAt(input.length() - 1);
/*  87 */       k1 = mixK1(k1);
/*  88 */       h1 ^= k1;
/*     */     }
/*     */     
/*  91 */     return fmix(h1, 2 * input.length());
/*     */   }
/*     */   
/*     */   public static int mixCollHash(int hash, int count) {
/*  95 */     int h1 = 0;
/*  96 */     int k1 = mixK1(hash);
/*  97 */     h1 = mixH1(h1, k1);
/*  98 */     return fmix(h1, count);
/*     */   }
/*     */   
/*     */   public static int hashOrdered(Iterable xs) {
/* 102 */     int n = 0;
/* 103 */     int hash = 1;
/*     */     
/* 105 */     for (Object x : xs)
/*     */     {
/* 107 */       hash = 31 * hash + Util.hasheq(x);
/* 108 */       n++;
/*     */     }
/*     */     
/* 111 */     return mixCollHash(hash, n);
/*     */   }
/*     */   
/*     */   public static int hashUnordered(Iterable xs) {
/* 115 */     int hash = 0;
/* 116 */     int n = 0;
/* 117 */     for (Object x : xs)
/*     */     {
/* 119 */       hash += Util.hasheq(x);
/* 120 */       n++;
/*     */     }
/*     */     
/* 123 */     return mixCollHash(hash, n);
/*     */   }
/*     */   
/*     */   private static int mixK1(int k1) {
/* 127 */     k1 *= -862048943;
/* 128 */     k1 = Integer.rotateLeft(k1, 15);
/* 129 */     k1 *= 461845907;
/* 130 */     return k1;
/*     */   }
/*     */   
/*     */   private static int mixH1(int h1, int k1) {
/* 134 */     h1 ^= k1;
/* 135 */     h1 = Integer.rotateLeft(h1, 13);
/* 136 */     h1 = h1 * 5 + -430675100;
/* 137 */     return h1;
/*     */   }
/*     */   
/*     */   private static int fmix(int h1, int length)
/*     */   {
/* 142 */     h1 ^= length;
/* 143 */     h1 ^= h1 >>> 16;
/* 144 */     h1 *= -2048144789;
/* 145 */     h1 ^= h1 >>> 13;
/* 146 */     h1 *= -1028477387;
/* 147 */     h1 ^= h1 >>> 16;
/* 148 */     return h1;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\Murmur3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */