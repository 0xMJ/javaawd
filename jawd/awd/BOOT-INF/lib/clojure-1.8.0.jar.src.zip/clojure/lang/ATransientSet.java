/*    */ package clojure.lang;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ATransientSet
/*    */   extends AFn
/*    */   implements ITransientSet
/*    */ {
/*    */   volatile ITransientMap impl;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   ATransientSet(ITransientMap impl)
/*    */   {
/* 19 */     this.impl = impl;
/*    */   }
/*    */   
/*    */   public int count() {
/* 23 */     return this.impl.count();
/*    */   }
/*    */   
/*    */   public ITransientSet conj(Object val) {
/* 27 */     ITransientMap m = this.impl.assoc(val, val);
/* 28 */     if (m != this.impl) this.impl = m;
/* 29 */     return this;
/*    */   }
/*    */   
/*    */   public boolean contains(Object key) {
/* 33 */     return this != this.impl.valAt(key, this);
/*    */   }
/*    */   
/*    */   public ITransientSet disjoin(Object key) {
/* 37 */     ITransientMap m = this.impl.without(key);
/* 38 */     if (m != this.impl) this.impl = m;
/* 39 */     return this;
/*    */   }
/*    */   
/*    */   public Object get(Object key) {
/* 43 */     return this.impl.valAt(key);
/*    */   }
/*    */   
/*    */   public Object invoke(Object key, Object notFound) {
/* 47 */     return this.impl.valAt(key, notFound);
/*    */   }
/*    */   
/*    */   public Object invoke(Object key) {
/* 51 */     return this.impl.valAt(key);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\ATransientSet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */