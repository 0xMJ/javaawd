/*    */ package clojure.lang;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.NoSuchElementException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SeqIterator
/*    */   implements Iterator
/*    */ {
/* 20 */   static final Object START = new Object();
/*    */   Object seq;
/*    */   Object next;
/*    */   
/*    */   public SeqIterator(Object o) {
/* 25 */     this.seq = START;
/* 26 */     this.next = o;
/*    */   }
/*    */   
/*    */   public SeqIterator(ISeq o)
/*    */   {
/* 31 */     this.seq = START;
/* 32 */     this.next = o;
/*    */   }
/*    */   
/*    */   public boolean hasNext() {
/* 36 */     if (this.seq == START) {
/* 37 */       this.seq = null;
/* 38 */       this.next = RT.seq(this.next);
/*    */     }
/* 40 */     else if (this.seq == this.next) {
/* 41 */       this.next = RT.next(this.seq); }
/* 42 */     return this.next != null;
/*    */   }
/*    */   
/*    */   public Object next() throws NoSuchElementException {
/* 46 */     if (!hasNext())
/* 47 */       throw new NoSuchElementException();
/* 48 */     this.seq = this.next;
/* 49 */     return RT.first(this.next);
/*    */   }
/*    */   
/*    */   public void remove() {
/* 53 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\SeqIterator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */