/*    */ package clojure.lang;
/*    */ 
/*    */ import org.xml.sax.Attributes;
/*    */ import org.xml.sax.ContentHandler;
/*    */ import org.xml.sax.Locator;
/*    */ import org.xml.sax.SAXException;
/*    */ import org.xml.sax.helpers.DefaultHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XMLHandler
/*    */   extends DefaultHandler
/*    */ {
/*    */   ContentHandler h;
/*    */   
/*    */   public XMLHandler(ContentHandler h)
/*    */   {
/* 26 */     this.h = h;
/*    */   }
/*    */   
/*    */   public void setDocumentLocator(Locator locator) {
/* 30 */     this.h.setDocumentLocator(locator);
/*    */   }
/*    */   
/*    */   public void startDocument() throws SAXException {
/* 34 */     this.h.startDocument();
/*    */   }
/*    */   
/*    */   public void endDocument() throws SAXException {
/* 38 */     this.h.endDocument();
/*    */   }
/*    */   
/*    */   public void startPrefixMapping(String prefix, String uri) throws SAXException {
/* 42 */     this.h.startPrefixMapping(prefix, uri);
/*    */   }
/*    */   
/*    */   public void endPrefixMapping(String prefix) throws SAXException {
/* 46 */     this.h.endPrefixMapping(prefix);
/*    */   }
/*    */   
/*    */   public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
/* 50 */     this.h.startElement(uri, localName, qName, atts);
/*    */   }
/*    */   
/*    */   public void endElement(String uri, String localName, String qName) throws SAXException {
/* 54 */     this.h.endElement(uri, localName, qName);
/*    */   }
/*    */   
/*    */   public void characters(char[] ch, int start, int length) throws SAXException {
/* 58 */     this.h.characters(ch, start, length);
/*    */   }
/*    */   
/*    */   public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
/* 62 */     this.h.ignorableWhitespace(ch, start, length);
/*    */   }
/*    */   
/*    */   public void processingInstruction(String target, String data) throws SAXException {
/* 66 */     this.h.processingInstruction(target, data);
/*    */   }
/*    */   
/*    */   public void skippedEntity(String name) throws SAXException {
/* 70 */     this.h.skippedEntity(name);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\XMLHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */