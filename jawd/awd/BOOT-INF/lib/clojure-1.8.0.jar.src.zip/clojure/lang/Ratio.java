/*    */ package clojure.lang;
/*    */ 
/*    */ import java.math.BigDecimal;
/*    */ import java.math.BigInteger;
/*    */ import java.math.MathContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Ratio
/*    */   extends Number
/*    */   implements Comparable
/*    */ {
/*    */   public final BigInteger numerator;
/*    */   public final BigInteger denominator;
/*    */   
/*    */   public Ratio(BigInteger numerator, BigInteger denominator)
/*    */   {
/* 24 */     this.numerator = numerator;
/* 25 */     this.denominator = denominator;
/*    */   }
/*    */   
/*    */   public boolean equals(Object arg0) {
/* 29 */     return (arg0 != null) && ((arg0 instanceof Ratio)) && (((Ratio)arg0).numerator.equals(this.numerator)) && (((Ratio)arg0).denominator.equals(this.denominator));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 36 */     return this.numerator.hashCode() ^ this.denominator.hashCode();
/*    */   }
/*    */   
/*    */   public String toString() {
/* 40 */     return this.numerator.toString() + "/" + this.denominator.toString();
/*    */   }
/*    */   
/*    */   public int intValue() {
/* 44 */     return (int)doubleValue();
/*    */   }
/*    */   
/*    */   public long longValue() {
/* 48 */     return bigIntegerValue().longValue();
/*    */   }
/*    */   
/*    */   public float floatValue() {
/* 52 */     return (float)doubleValue();
/*    */   }
/*    */   
/*    */   public double doubleValue() {
/* 56 */     return decimalValue(MathContext.DECIMAL64).doubleValue();
/*    */   }
/*    */   
/*    */   public BigDecimal decimalValue() {
/* 60 */     return decimalValue(MathContext.UNLIMITED);
/*    */   }
/*    */   
/*    */   public BigDecimal decimalValue(MathContext mc) {
/* 64 */     BigDecimal numerator = new BigDecimal(this.numerator);
/* 65 */     BigDecimal denominator = new BigDecimal(this.denominator);
/*    */     
/* 67 */     return numerator.divide(denominator, mc);
/*    */   }
/*    */   
/*    */   public BigInteger bigIntegerValue() {
/* 71 */     return this.numerator.divide(this.denominator);
/*    */   }
/*    */   
/*    */   public int compareTo(Object o) {
/* 75 */     Number other = (Number)o;
/* 76 */     return Numbers.compare(this, other);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\Ratio.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */