/*    */ package clojure.lang;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AMapEntry
/*    */   extends APersistentVector
/*    */   implements IMapEntry
/*    */ {
/*    */   public Object nth(int i)
/*    */   {
/* 20 */     if (i == 0)
/* 21 */       return key();
/* 22 */     if (i == 1) {
/* 23 */       return val();
/*    */     }
/* 25 */     throw new IndexOutOfBoundsException();
/*    */   }
/*    */   
/*    */   private IPersistentVector asVector() {
/* 29 */     return LazilyPersistentVector.createOwning(new Object[] { key(), val() });
/*    */   }
/*    */   
/*    */   public IPersistentVector assocN(int i, Object val) {
/* 33 */     return asVector().assocN(i, val);
/*    */   }
/*    */   
/*    */   public int count() {
/* 37 */     return 2;
/*    */   }
/*    */   
/*    */   public ISeq seq() {
/* 41 */     return asVector().seq();
/*    */   }
/*    */   
/*    */   public IPersistentVector cons(Object o) {
/* 45 */     return asVector().cons(o);
/*    */   }
/*    */   
/*    */   public IPersistentCollection empty() {
/* 49 */     return null;
/*    */   }
/*    */   
/*    */   public IPersistentStack pop() {
/* 53 */     return LazilyPersistentVector.createOwning(new Object[] { key() });
/*    */   }
/*    */   
/*    */   public Object setValue(Object value) {
/* 57 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\AMapEntry.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */