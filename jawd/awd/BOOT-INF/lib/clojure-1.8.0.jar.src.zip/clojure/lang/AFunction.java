/*    */ package clojure.lang;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Comparator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AFunction
/*    */   extends AFn
/*    */   implements IObj, Comparator, Fn, Serializable
/*    */ {
/*    */   public volatile MethodImplCache __methodImplCache;
/*    */   
/*    */   public IPersistentMap meta()
/*    */   {
/* 23 */     return null;
/*    */   }
/*    */   
/*    */   public IObj withMeta(final IPersistentMap meta) {
/* 27 */     new RestFn() {
/*    */       protected Object doInvoke(Object args) {
/* 29 */         return AFunction.this.applyTo((ISeq)args);
/*    */       }
/*    */       
/*    */       public IPersistentMap meta() {
/* 33 */         return meta;
/*    */       }
/*    */       
/*    */       public IObj withMeta(IPersistentMap meta) {
/* 37 */         return AFunction.this.withMeta(meta);
/*    */       }
/*    */       
/*    */       public int getRequiredArity() {
/* 41 */         return 0;
/*    */       }
/*    */     };
/*    */   }
/*    */   
/*    */   public int compare(Object o1, Object o2) {
/* 47 */     Object o = invoke(o1, o2);
/*    */     
/* 49 */     if ((o instanceof Boolean))
/*    */     {
/* 51 */       if (RT.booleanCast(o))
/* 52 */         return -1;
/* 53 */       return RT.booleanCast(invoke(o2, o1)) ? 1 : 0;
/*    */     }
/*    */     
/* 56 */     Number n = (Number)o;
/* 57 */     return n.intValue();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\AFunction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */