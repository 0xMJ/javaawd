/*      */ package clojure.lang;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.PrintStream;
/*      */ import java.io.PushbackReader;
/*      */ import java.io.Reader;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.util.ArrayList;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.regex.Matcher;
/*      */ import java.util.regex.Pattern;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class LispReader
/*      */ {
/*   42 */   static final Symbol QUOTE = Symbol.intern("quote");
/*   43 */   static final Symbol THE_VAR = Symbol.intern("var");
/*      */   
/*   45 */   static Symbol UNQUOTE = Symbol.intern("clojure.core", "unquote");
/*   46 */   static Symbol UNQUOTE_SPLICING = Symbol.intern("clojure.core", "unquote-splicing");
/*   47 */   static Symbol CONCAT = Symbol.intern("clojure.core", "concat");
/*   48 */   static Symbol SEQ = Symbol.intern("clojure.core", "seq");
/*   49 */   static Symbol LIST = Symbol.intern("clojure.core", "list");
/*   50 */   static Symbol APPLY = Symbol.intern("clojure.core", "apply");
/*   51 */   static Symbol HASHMAP = Symbol.intern("clojure.core", "hash-map");
/*   52 */   static Symbol HASHSET = Symbol.intern("clojure.core", "hash-set");
/*   53 */   static Symbol VECTOR = Symbol.intern("clojure.core", "vector");
/*   54 */   static Symbol WITH_META = Symbol.intern("clojure.core", "with-meta");
/*   55 */   static Symbol META = Symbol.intern("clojure.core", "meta");
/*   56 */   static Symbol DEREF = Symbol.intern("clojure.core", "deref");
/*   57 */   static Symbol READ_COND = Symbol.intern("clojure.core", "read-cond");
/*   58 */   static Symbol READ_COND_SPLICING = Symbol.intern("clojure.core", "read-cond-splicing");
/*   59 */   static Keyword UNKNOWN = Keyword.intern(null, "unknown");
/*      */   
/*      */ 
/*   62 */   static IFn[] macros = new IFn['Ā'];
/*   63 */   static IFn[] dispatchMacros = new IFn['Ā'];
/*      */   
/*   65 */   static Pattern symbolPat = Pattern.compile("[:]?([\\D&&[^/]].*/)?(/|[\\D&&[^/]][^/]*)");
/*      */   
/*      */ 
/*   68 */   static Pattern intPat = Pattern.compile("([-+]?)(?:(0)|([1-9][0-9]*)|0[xX]([0-9A-Fa-f]+)|0([0-7]+)|([1-9][0-9]?)[rR]([0-9A-Za-z]+)|0[0-9]+)(N)?");
/*      */   
/*      */ 
/*   71 */   static Pattern ratioPat = Pattern.compile("([-+]?[0-9]+)/([0-9]+)");
/*   72 */   static Pattern floatPat = Pattern.compile("([-+]?[0-9]+(\\.[0-9]*)?([eE][-+]?[0-9]+)?)(M)?");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   79 */   static Var GENSYM_ENV = Var.create(null).setDynamic();
/*      */   
/*   81 */   static Var ARG_ENV = Var.create(null).setDynamic();
/*   82 */   static IFn ctorReader = new CtorReader();
/*      */   
/*      */ 
/*   85 */   static Var READ_COND_ENV = Var.create(null).setDynamic();
/*      */   
/*      */   static
/*      */   {
/*   89 */     macros[34] = new StringReader();
/*   90 */     macros[59] = new CommentReader();
/*   91 */     macros[39] = new WrappingReader(QUOTE);
/*   92 */     macros[64] = new WrappingReader(DEREF);
/*   93 */     macros[94] = new MetaReader();
/*   94 */     macros[96] = new SyntaxQuoteReader();
/*   95 */     macros[126] = new UnquoteReader();
/*   96 */     macros[40] = new ListReader();
/*   97 */     macros[41] = new UnmatchedDelimiterReader();
/*   98 */     macros[91] = new VectorReader();
/*   99 */     macros[93] = new UnmatchedDelimiterReader();
/*  100 */     macros[123] = new MapReader();
/*  101 */     macros[125] = new UnmatchedDelimiterReader();
/*      */     
/*  103 */     macros[92] = new CharacterReader();
/*  104 */     macros[37] = new ArgReader();
/*  105 */     macros[35] = new DispatchReader();
/*      */     
/*      */ 
/*  108 */     dispatchMacros[94] = new MetaReader();
/*  109 */     dispatchMacros[39] = new VarReader();
/*  110 */     dispatchMacros[34] = new RegexReader();
/*  111 */     dispatchMacros[40] = new FnReader();
/*  112 */     dispatchMacros[123] = new SetReader();
/*  113 */     dispatchMacros[61] = new EvalReader();
/*  114 */     dispatchMacros[33] = new CommentReader();
/*  115 */     dispatchMacros[60] = new UnreadableReader();
/*  116 */     dispatchMacros[95] = new DiscardReader();
/*  117 */     dispatchMacros[63] = new ConditionalReader();
/*      */   }
/*      */   
/*      */   static boolean isWhitespace(int ch) {
/*  121 */     return (Character.isWhitespace(ch)) || (ch == 44);
/*      */   }
/*      */   
/*      */   static void unread(PushbackReader r, int ch) {
/*  125 */     if (ch != -1)
/*      */       try
/*      */       {
/*  128 */         r.unread(ch);
/*      */       }
/*      */       catch (IOException e)
/*      */       {
/*  132 */         throw Util.sneakyThrow(e);
/*      */       }
/*      */   }
/*      */   
/*      */   public static class ReaderException extends RuntimeException {
/*      */     final int line;
/*      */     final int column;
/*      */     
/*      */     public ReaderException(int line, int column, Throwable cause) {
/*  141 */       super();
/*  142 */       this.line = line;
/*  143 */       this.column = column;
/*      */     }
/*      */   }
/*      */   
/*      */   public static int read1(Reader r)
/*      */   {
/*      */     try {
/*  150 */       return r.read();
/*      */     }
/*      */     catch (IOException e)
/*      */     {
/*  154 */       throw Util.sneakyThrow(e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*  159 */   public static final Keyword OPT_EOF = Keyword.intern(null, "eof");
/*  160 */   public static final Keyword OPT_FEATURES = Keyword.intern(null, "features");
/*  161 */   public static final Keyword OPT_READ_COND = Keyword.intern(null, "read-cond");
/*      */   
/*      */ 
/*  164 */   public static final Keyword EOFTHROW = Keyword.intern(null, "eofthrow");
/*      */   
/*      */ 
/*  167 */   private static final Keyword PLATFORM_KEY = Keyword.intern(null, "clj");
/*  168 */   private static final Object PLATFORM_FEATURES = PersistentHashSet.create(new Object[] { PLATFORM_KEY });
/*      */   
/*      */ 
/*  171 */   public static final Keyword COND_ALLOW = Keyword.intern(null, "allow");
/*  172 */   public static final Keyword COND_PRESERVE = Keyword.intern(null, "preserve");
/*      */   
/*      */   public static Object read(PushbackReader r, Object opts) {
/*  175 */     boolean eofIsError = true;
/*  176 */     Object eofValue = null;
/*  177 */     if ((opts != null) && ((opts instanceof IPersistentMap)))
/*      */     {
/*  179 */       Object eof = ((IPersistentMap)opts).valAt(OPT_EOF, EOFTHROW);
/*  180 */       if (!EOFTHROW.equals(eof)) {
/*  181 */         eofIsError = false;
/*  182 */         eofValue = eof;
/*      */       }
/*      */     }
/*  185 */     return read(r, eofIsError, eofValue, false, opts);
/*      */   }
/*      */   
/*      */   public static Object read(PushbackReader r, boolean eofIsError, Object eofValue, boolean isRecursive)
/*      */   {
/*  190 */     return read(r, eofIsError, eofValue, isRecursive, PersistentHashMap.EMPTY);
/*      */   }
/*      */   
/*      */ 
/*      */   public static Object read(PushbackReader r, boolean eofIsError, Object eofValue, boolean isRecursive, Object opts)
/*      */   {
/*  196 */     return read(r, eofIsError, eofValue, null, null, isRecursive, opts, null);
/*      */   }
/*      */   
/*      */   private static Object read(PushbackReader r, boolean eofIsError, Object eofValue, boolean isRecursive, Object opts, Object pendingForms) {
/*  200 */     return read(r, eofIsError, eofValue, null, null, isRecursive, opts, ensurePending(pendingForms));
/*      */   }
/*      */   
/*      */   private static Object ensurePending(Object pendingForms) {
/*  204 */     if (pendingForms == null) {
/*  205 */       return new LinkedList();
/*      */     }
/*  207 */     return pendingForms;
/*      */   }
/*      */   
/*      */   private static Object installPlatformFeature(Object opts) {
/*  211 */     if (opts == null) {
/*  212 */       return RT.mapUniqueKeys(new Object[] { OPT_FEATURES, PLATFORM_FEATURES });
/*      */     }
/*  214 */     IPersistentMap mopts = (IPersistentMap)opts;
/*  215 */     Object features = mopts.valAt(OPT_FEATURES);
/*  216 */     if (features == null) {
/*  217 */       return mopts.assoc(OPT_FEATURES, PLATFORM_FEATURES);
/*      */     }
/*  219 */     return mopts.assoc(OPT_FEATURES, RT.conj((IPersistentSet)features, PLATFORM_KEY));
/*      */   }
/*      */   
/*      */ 
/*      */   private static Object read(PushbackReader r, boolean eofIsError, Object eofValue, Character returnOn, Object returnOnValue, boolean isRecursive, Object opts, Object pendingForms)
/*      */   {
/*  225 */     if (RT.READEVAL.deref() == UNKNOWN) {
/*  226 */       throw Util.runtimeException("Reading disallowed - *read-eval* bound to :unknown");
/*      */     }
/*  228 */     opts = installPlatformFeature(opts);
/*      */     try
/*      */     {
/*      */       int ch;
/*      */       Object ret;
/*      */       do
/*      */       {
/*  235 */         if (((pendingForms instanceof List)) && (!((List)pendingForms).isEmpty())) {
/*  236 */           return ((List)pendingForms).remove(0);
/*      */         }
/*  238 */         ch = read1(r);
/*      */         
/*  240 */         while (isWhitespace(ch)) {
/*  241 */           ch = read1(r);
/*      */         }
/*  243 */         if (ch == -1)
/*      */         {
/*  245 */           if (eofIsError)
/*  246 */             throw Util.runtimeException("EOF while reading");
/*  247 */           return eofValue;
/*      */         }
/*      */         
/*  250 */         if ((returnOn != null) && (returnOn.charValue() == ch)) {
/*  251 */           return returnOnValue;
/*      */         }
/*      */         
/*  254 */         if (Character.isDigit(ch))
/*      */         {
/*  256 */           return readNumber(r, (char)ch);
/*      */         }
/*      */         
/*      */ 
/*  260 */         IFn macroFn = getMacro(ch);
/*  261 */         if (macroFn == null)
/*      */           break;
/*  263 */         ret = macroFn.invoke(r, Character.valueOf((char)ch), opts, pendingForms);
/*      */       }
/*  265 */       while (ret == r);
/*      */       
/*  267 */       return ret;
/*      */       
/*      */ 
/*  270 */       if ((ch == 43) || (ch == 45))
/*      */       {
/*  272 */         int ch2 = read1(r);
/*  273 */         if (Character.isDigit(ch2))
/*      */         {
/*  275 */           unread(r, ch2);
/*  276 */           return readNumber(r, (char)ch);
/*      */         }
/*      */         
/*  279 */         unread(r, ch2);
/*      */       }
/*      */       
/*  282 */       String token = readToken(r, (char)ch);
/*  283 */       return interpretToken(token);
/*      */ 
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  288 */       if ((isRecursive) || (!(r instanceof LineNumberingPushbackReader)))
/*  289 */         throw Util.sneakyThrow(e);
/*  290 */       LineNumberingPushbackReader rdr = (LineNumberingPushbackReader)r;
/*      */       
/*  292 */       throw new ReaderException(rdr.getLineNumber(), rdr.getColumnNumber(), e);
/*      */     }
/*      */   }
/*      */   
/*      */   private static String readToken(PushbackReader r, char initch) {
/*  297 */     StringBuilder sb = new StringBuilder();
/*  298 */     sb.append(initch);
/*      */     
/*      */     for (;;)
/*      */     {
/*  302 */       int ch = read1(r);
/*  303 */       if ((ch == -1) || (isWhitespace(ch)) || (isTerminatingMacro(ch)))
/*      */       {
/*  305 */         unread(r, ch);
/*  306 */         return sb.toString();
/*      */       }
/*  308 */       sb.append((char)ch);
/*      */     }
/*      */   }
/*      */   
/*      */   private static Object readNumber(PushbackReader r, char initch) {
/*  313 */     StringBuilder sb = new StringBuilder();
/*  314 */     sb.append(initch);
/*      */     
/*      */     for (;;)
/*      */     {
/*  318 */       int ch = read1(r);
/*  319 */       if ((ch == -1) || (isWhitespace(ch)) || (isMacro(ch)))
/*      */       {
/*  321 */         unread(r, ch);
/*  322 */         break;
/*      */       }
/*  324 */       sb.append((char)ch);
/*      */     }
/*      */     
/*  327 */     String s = sb.toString();
/*  328 */     Object n = matchNumber(s);
/*  329 */     if (n == null)
/*  330 */       throw new NumberFormatException("Invalid number: " + s);
/*  331 */     return n;
/*      */   }
/*      */   
/*      */   private static int readUnicodeChar(String token, int offset, int length, int base) {
/*  335 */     if (token.length() != offset + length)
/*  336 */       throw new IllegalArgumentException("Invalid unicode character: \\" + token);
/*  337 */     int uc = 0;
/*  338 */     for (int i = offset; i < offset + length; i++)
/*      */     {
/*  340 */       int d = Character.digit(token.charAt(i), base);
/*  341 */       if (d == -1)
/*  342 */         throw new IllegalArgumentException("Invalid digit: " + token.charAt(i));
/*  343 */       uc = uc * base + d;
/*      */     }
/*  345 */     return (char)uc;
/*      */   }
/*      */   
/*      */   private static int readUnicodeChar(PushbackReader r, int initch, int base, int length, boolean exact) {
/*  349 */     int uc = Character.digit(initch, base);
/*  350 */     if (uc == -1)
/*  351 */       throw new IllegalArgumentException("Invalid digit: " + (char)initch);
/*  352 */     for (int i = 1; 
/*  353 */         i < length; i++)
/*      */     {
/*  355 */       int ch = read1(r);
/*  356 */       if ((ch == -1) || (isWhitespace(ch)) || (isMacro(ch)))
/*      */       {
/*  358 */         unread(r, ch);
/*  359 */         break;
/*      */       }
/*  361 */       int d = Character.digit(ch, base);
/*  362 */       if (d == -1)
/*  363 */         throw new IllegalArgumentException("Invalid digit: " + (char)ch);
/*  364 */       uc = uc * base + d;
/*      */     }
/*  366 */     if ((i != length) && (exact))
/*  367 */       throw new IllegalArgumentException("Invalid character length: " + i + ", should be: " + length);
/*  368 */     return uc;
/*      */   }
/*      */   
/*      */   private static Object interpretToken(String s) {
/*  372 */     if (s.equals("nil"))
/*      */     {
/*  374 */       return null;
/*      */     }
/*  376 */     if (s.equals("true"))
/*      */     {
/*  378 */       return RT.T;
/*      */     }
/*  380 */     if (s.equals("false"))
/*      */     {
/*  382 */       return RT.F;
/*      */     }
/*  384 */     Object ret = null;
/*      */     
/*  386 */     ret = matchSymbol(s);
/*  387 */     if (ret != null) {
/*  388 */       return ret;
/*      */     }
/*  390 */     throw Util.runtimeException("Invalid token: " + s);
/*      */   }
/*      */   
/*      */   private static Object matchSymbol(String s)
/*      */   {
/*  395 */     Matcher m = symbolPat.matcher(s);
/*  396 */     if (m.matches())
/*      */     {
/*  398 */       int gc = m.groupCount();
/*  399 */       String ns = m.group(1);
/*  400 */       String name = m.group(2);
/*  401 */       if (((ns != null) && (ns.endsWith(":/"))) || (name.endsWith(":")) || (s.indexOf("::", 1) != -1))
/*      */       {
/*      */ 
/*  404 */         return null; }
/*  405 */       if (s.startsWith("::"))
/*      */       {
/*  407 */         Symbol ks = Symbol.intern(s.substring(2));
/*      */         Namespace kns;
/*  409 */         Namespace kns; if (ks.ns != null) {
/*  410 */           kns = Compiler.namespaceFor(ks);
/*      */         } else {
/*  412 */           kns = Compiler.currentNS();
/*      */         }
/*  414 */         if (kns != null) {
/*  415 */           return Keyword.intern(kns.name.name, ks.name);
/*      */         }
/*  417 */         return null;
/*      */       }
/*  419 */       boolean isKeyword = s.charAt(0) == ':';
/*  420 */       Symbol sym = Symbol.intern(s.substring(isKeyword ? 1 : 0));
/*  421 */       if (isKeyword)
/*  422 */         return Keyword.intern(sym);
/*  423 */       return sym;
/*      */     }
/*  425 */     return null;
/*      */   }
/*      */   
/*      */   private static Object matchNumber(String s)
/*      */   {
/*  430 */     Matcher m = intPat.matcher(s);
/*  431 */     if (m.matches())
/*      */     {
/*  433 */       if (m.group(2) != null)
/*      */       {
/*  435 */         if (m.group(8) != null)
/*  436 */           return BigInt.ZERO;
/*  437 */         return Numbers.num(0L);
/*      */       }
/*  439 */       boolean negate = m.group(1).equals("-");
/*      */       
/*  441 */       int radix = 10;
/*  442 */       String n; if ((n = m.group(3)) != null) {
/*  443 */         radix = 10;
/*  444 */       } else if ((n = m.group(4)) != null) {
/*  445 */         radix = 16;
/*  446 */       } else if ((n = m.group(5)) != null) {
/*  447 */         radix = 8;
/*  448 */       } else if ((n = m.group(7)) != null)
/*  449 */         radix = Integer.parseInt(m.group(6));
/*  450 */       if (n == null)
/*  451 */         return null;
/*  452 */       BigInteger bn = new BigInteger(n, radix);
/*  453 */       if (negate)
/*  454 */         bn = bn.negate();
/*  455 */       if (m.group(8) != null)
/*  456 */         return BigInt.fromBigInteger(bn);
/*  457 */       return bn.bitLength() < 64 ? Numbers.num(bn.longValue()) : BigInt.fromBigInteger(bn);
/*      */     }
/*      */     
/*      */ 
/*  461 */     m = floatPat.matcher(s);
/*  462 */     if (m.matches())
/*      */     {
/*  464 */       if (m.group(4) != null)
/*  465 */         return new BigDecimal(m.group(1));
/*  466 */       return Double.valueOf(Double.parseDouble(s));
/*      */     }
/*  468 */     m = ratioPat.matcher(s);
/*  469 */     if (m.matches())
/*      */     {
/*  471 */       String numerator = m.group(1);
/*  472 */       if (numerator.startsWith("+")) { numerator = numerator.substring(1);
/*      */       }
/*  474 */       return Numbers.divide(Numbers.reduceBigInt(BigInt.fromBigInteger(new BigInteger(numerator))), Numbers.reduceBigInt(BigInt.fromBigInteger(new BigInteger(m.group(2)))));
/*      */     }
/*      */     
/*  477 */     return null;
/*      */   }
/*      */   
/*      */   private static IFn getMacro(int ch) {
/*  481 */     if (ch < macros.length)
/*  482 */       return macros[ch];
/*  483 */     return null;
/*      */   }
/*      */   
/*      */   private static boolean isMacro(int ch) {
/*  487 */     return (ch < macros.length) && (macros[ch] != null);
/*      */   }
/*      */   
/*      */   private static boolean isTerminatingMacro(int ch) {
/*  491 */     return (ch != 35) && (ch != 39) && (ch != 37) && (isMacro(ch));
/*      */   }
/*      */   
/*      */   public static class RegexReader extends AFn {
/*  495 */     static LispReader.StringReader stringrdr = new LispReader.StringReader();
/*      */     
/*      */     public Object invoke(Object reader, Object doublequote, Object opts, Object pendingForms) {
/*  498 */       StringBuilder sb = new StringBuilder();
/*  499 */       Reader r = (Reader)reader;
/*  500 */       for (int ch = LispReader.read1(r); ch != 34; ch = LispReader.read1(r))
/*      */       {
/*  502 */         if (ch == -1)
/*  503 */           throw Util.runtimeException("EOF while reading regex");
/*  504 */         sb.append((char)ch);
/*  505 */         if (ch == 92)
/*      */         {
/*  507 */           ch = LispReader.read1(r);
/*  508 */           if (ch == -1)
/*  509 */             throw Util.runtimeException("EOF while reading regex");
/*  510 */           sb.append((char)ch);
/*      */         }
/*      */       }
/*  513 */       return Pattern.compile(sb.toString());
/*      */     }
/*      */   }
/*      */   
/*      */   public static class StringReader extends AFn {
/*      */     public Object invoke(Object reader, Object doublequote, Object opts, Object pendingForms) {
/*  519 */       StringBuilder sb = new StringBuilder();
/*  520 */       Reader r = (Reader)reader;
/*      */       
/*  522 */       for (int ch = LispReader.read1(r); ch != 34; ch = LispReader.read1(r))
/*      */       {
/*  524 */         if (ch == -1)
/*  525 */           throw Util.runtimeException("EOF while reading string");
/*  526 */         if (ch == 92)
/*      */         {
/*  528 */           ch = LispReader.read1(r);
/*  529 */           if (ch == -1)
/*  530 */             throw Util.runtimeException("EOF while reading string");
/*  531 */           switch (ch)
/*      */           {
/*      */           case 116: 
/*  534 */             ch = 9;
/*  535 */             break;
/*      */           case 114: 
/*  537 */             ch = 13;
/*  538 */             break;
/*      */           case 110: 
/*  540 */             ch = 10;
/*  541 */             break;
/*      */           case 92: 
/*      */             break;
/*      */           case 34: 
/*      */             break;
/*      */           case 98: 
/*  547 */             ch = 8;
/*  548 */             break;
/*      */           case 102: 
/*  550 */             ch = 12;
/*  551 */             break;
/*      */           
/*      */           case 117: 
/*  554 */             ch = LispReader.read1(r);
/*  555 */             if (Character.digit(ch, 16) == -1)
/*  556 */               throw Util.runtimeException("Invalid unicode escape: \\u" + (char)ch);
/*  557 */             ch = LispReader.readUnicodeChar((PushbackReader)r, ch, 16, 4, true);
/*  558 */             break;
/*      */           
/*      */ 
/*      */           default: 
/*  562 */             if (Character.isDigit(ch))
/*      */             {
/*  564 */               ch = LispReader.readUnicodeChar((PushbackReader)r, ch, 8, 3, false);
/*  565 */               if (ch > 255) {
/*  566 */                 throw Util.runtimeException("Octal escape sequence must be in range [0, 377].");
/*      */               }
/*      */             } else {
/*  569 */               throw Util.runtimeException("Unsupported escape character: \\" + (char)ch);
/*      */             }
/*      */             break; }
/*      */         }
/*  573 */         sb.append((char)ch);
/*      */       }
/*  575 */       return sb.toString();
/*      */     }
/*      */   }
/*      */   
/*      */   public static class CommentReader extends AFn {
/*      */     public Object invoke(Object reader, Object semicolon, Object opts, Object pendingForms) {
/*  581 */       Reader r = (Reader)reader;
/*      */       int ch;
/*      */       do
/*      */       {
/*  585 */         ch = LispReader.read1(r);
/*  586 */       } while ((ch != -1) && (ch != 10) && (ch != 13));
/*  587 */       return r;
/*      */     }
/*      */   }
/*      */   
/*      */   public static class DiscardReader extends AFn
/*      */   {
/*      */     public Object invoke(Object reader, Object underscore, Object opts, Object pendingForms) {
/*  594 */       PushbackReader r = (PushbackReader)reader;
/*  595 */       LispReader.read(r, true, null, true, opts, LispReader.access$100(pendingForms));
/*  596 */       return r;
/*      */     }
/*      */   }
/*      */   
/*      */   public static class WrappingReader extends AFn {
/*      */     final Symbol sym;
/*      */     
/*      */     public WrappingReader(Symbol sym) {
/*  604 */       this.sym = sym;
/*      */     }
/*      */     
/*      */     public Object invoke(Object reader, Object quote, Object opts, Object pendingForms) {
/*  608 */       PushbackReader r = (PushbackReader)reader;
/*  609 */       Object o = LispReader.read(r, true, null, true, opts, LispReader.access$100(pendingForms));
/*  610 */       return RT.list(this.sym, o);
/*      */     }
/*      */   }
/*      */   
/*      */   public static class DeprecatedWrappingReader extends AFn
/*      */   {
/*      */     final Symbol sym;
/*      */     final String macro;
/*      */     
/*      */     public DeprecatedWrappingReader(Symbol sym, String macro) {
/*  620 */       this.sym = sym;
/*  621 */       this.macro = macro;
/*      */     }
/*      */     
/*      */     public Object invoke(Object reader, Object quote, Object opts, Object pendingForms) {
/*  625 */       System.out.println("WARNING: reader macro " + this.macro + " is deprecated; use " + this.sym.getName() + " instead");
/*      */       
/*      */ 
/*  628 */       PushbackReader r = (PushbackReader)reader;
/*  629 */       Object o = LispReader.read(r, true, null, true, opts, LispReader.access$100(pendingForms));
/*  630 */       return RT.list(this.sym, o);
/*      */     }
/*      */   }
/*      */   
/*      */   public static class VarReader extends AFn
/*      */   {
/*      */     public Object invoke(Object reader, Object quote, Object opts, Object pendingForms) {
/*  637 */       PushbackReader r = (PushbackReader)reader;
/*  638 */       Object o = LispReader.read(r, true, null, true, opts, LispReader.access$100(pendingForms));
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  645 */       return RT.list(LispReader.THE_VAR, o);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static class DispatchReader
/*      */     extends AFn
/*      */   {
/*      */     public Object invoke(Object reader, Object hash, Object opts, Object pendingForms)
/*      */     {
/*  675 */       int ch = LispReader.read1((Reader)reader);
/*  676 */       if (ch == -1)
/*  677 */         throw Util.runtimeException("EOF while reading character");
/*  678 */       IFn fn = LispReader.dispatchMacros[ch];
/*      */       
/*      */ 
/*  681 */       if (fn == null) {
/*  682 */         LispReader.unread((PushbackReader)reader, ch);
/*  683 */         pendingForms = LispReader.ensurePending(pendingForms);
/*  684 */         Object result = LispReader.ctorReader.invoke(reader, Integer.valueOf(ch), opts, pendingForms);
/*      */         
/*  686 */         if (result != null) {
/*  687 */           return result;
/*      */         }
/*  689 */         throw Util.runtimeException(String.format("No dispatch macro for: %c", new Object[] { Character.valueOf((char)ch) }));
/*      */       }
/*  691 */       return fn.invoke(reader, Integer.valueOf(ch), opts, pendingForms);
/*      */     }
/*      */   }
/*      */   
/*      */   static Symbol garg(int n) {
/*  696 */     return Symbol.intern(null, (n == -1 ? "rest" : new StringBuilder().append("p").append(n).toString()) + "__" + RT.nextID() + "#");
/*      */   }
/*      */   
/*      */   public static class FnReader extends AFn {
/*      */     public Object invoke(Object reader, Object lparen, Object opts, Object pendingForms) {
/*  701 */       PushbackReader r = (PushbackReader)reader;
/*  702 */       if (LispReader.ARG_ENV.deref() != null) {
/*  703 */         throw new IllegalStateException("Nested #()s are not allowed");
/*      */       }
/*      */       try {
/*  706 */         Var.pushThreadBindings(RT.map(new Object[] { LispReader.ARG_ENV, PersistentTreeMap.EMPTY }));
/*      */         
/*  708 */         LispReader.unread(r, 40);
/*  709 */         Object form = LispReader.read(r, true, null, true, opts, LispReader.access$100(pendingForms));
/*      */         
/*  711 */         PersistentVector args = PersistentVector.EMPTY;
/*  712 */         PersistentTreeMap argsyms = (PersistentTreeMap)LispReader.ARG_ENV.deref();
/*  713 */         ISeq rargs = argsyms.rseq();
/*  714 */         int higharg; if (rargs != null)
/*      */         {
/*  716 */           higharg = ((Integer)((Map.Entry)rargs.first()).getKey()).intValue();
/*  717 */           if (higharg > 0)
/*      */           {
/*  719 */             for (int i = 1; i <= higharg; i++)
/*      */             {
/*  721 */               Object sym = argsyms.valAt(Integer.valueOf(i));
/*  722 */               if (sym == null)
/*  723 */                 sym = LispReader.garg(i);
/*  724 */               args = args.cons(sym);
/*      */             }
/*      */           }
/*  727 */           Object restsym = argsyms.valAt(Integer.valueOf(-1));
/*  728 */           if (restsym != null)
/*      */           {
/*  730 */             args = args.cons(Compiler._AMP_);
/*  731 */             args = args.cons(restsym);
/*      */           }
/*      */         }
/*  734 */         return RT.list(Compiler.FN, args, form);
/*      */       }
/*      */       finally
/*      */       {
/*  738 */         Var.popThreadBindings();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   static Symbol registerArg(int n) {
/*  744 */     PersistentTreeMap argsyms = (PersistentTreeMap)ARG_ENV.deref();
/*  745 */     if (argsyms == null)
/*      */     {
/*  747 */       throw new IllegalStateException("arg literal not in #()");
/*      */     }
/*  749 */     Symbol ret = (Symbol)argsyms.valAt(Integer.valueOf(n));
/*  750 */     if (ret == null)
/*      */     {
/*  752 */       ret = garg(n);
/*  753 */       ARG_ENV.set(argsyms.assoc(Integer.valueOf(n), ret));
/*      */     }
/*  755 */     return ret;
/*      */   }
/*      */   
/*      */   static class ArgReader extends AFn {
/*      */     public Object invoke(Object reader, Object pct, Object opts, Object pendingForms) {
/*  760 */       PushbackReader r = (PushbackReader)reader;
/*  761 */       if (LispReader.ARG_ENV.deref() == null)
/*      */       {
/*  763 */         return LispReader.interpretToken(LispReader.access$300(r, '%'));
/*      */       }
/*  765 */       int ch = LispReader.read1(r);
/*  766 */       LispReader.unread(r, ch);
/*      */       
/*  768 */       if ((ch == -1) || (LispReader.isWhitespace(ch)) || (LispReader.isTerminatingMacro(ch)))
/*      */       {
/*  770 */         return LispReader.registerArg(1);
/*      */       }
/*  772 */       Object n = LispReader.read(r, true, null, true, opts, LispReader.access$100(pendingForms));
/*  773 */       if (n.equals(Compiler._AMP_))
/*  774 */         return LispReader.registerArg(-1);
/*  775 */       if (!(n instanceof Number))
/*  776 */         throw new IllegalStateException("arg literal must be %, %& or %integer");
/*  777 */       return LispReader.registerArg(((Number)n).intValue());
/*      */     }
/*      */   }
/*      */   
/*      */   public static class MetaReader extends AFn {
/*      */     public Object invoke(Object reader, Object caret, Object opts, Object pendingForms) {
/*  783 */       PushbackReader r = (PushbackReader)reader;
/*  784 */       int line = -1;
/*  785 */       int column = -1;
/*  786 */       if ((r instanceof LineNumberingPushbackReader))
/*      */       {
/*  788 */         line = ((LineNumberingPushbackReader)r).getLineNumber();
/*  789 */         column = ((LineNumberingPushbackReader)r).getColumnNumber() - 1;
/*      */       }
/*  791 */       pendingForms = LispReader.ensurePending(pendingForms);
/*  792 */       Object meta = LispReader.read(r, true, null, true, opts, pendingForms);
/*  793 */       if (((meta instanceof Symbol)) || ((meta instanceof String))) {
/*  794 */         meta = RT.map(new Object[] { RT.TAG_KEY, meta });
/*  795 */       } else if ((meta instanceof Keyword)) {
/*  796 */         meta = RT.map(new Object[] { meta, RT.T });
/*  797 */       } else if (!(meta instanceof IPersistentMap)) {
/*  798 */         throw new IllegalArgumentException("Metadata must be Symbol,Keyword,String or Map");
/*      */       }
/*  800 */       Object o = LispReader.read(r, true, null, true, opts, pendingForms);
/*  801 */       if ((o instanceof IMeta))
/*      */       {
/*  803 */         if ((line != -1) && ((o instanceof ISeq)))
/*      */         {
/*  805 */           meta = ((IPersistentMap)meta).assoc(RT.LINE_KEY, Integer.valueOf(line)).assoc(RT.COLUMN_KEY, Integer.valueOf(column));
/*      */         }
/*  807 */         if ((o instanceof IReference))
/*      */         {
/*  809 */           ((IReference)o).resetMeta((IPersistentMap)meta);
/*  810 */           return o;
/*      */         }
/*  812 */         Object ometa = RT.meta(o);
/*  813 */         for (ISeq s = RT.seq(meta); s != null; s = s.next()) {
/*  814 */           IMapEntry kv = (IMapEntry)s.first();
/*  815 */           ometa = RT.assoc(ometa, kv.getKey(), kv.getValue());
/*      */         }
/*  817 */         return ((IObj)o).withMeta((IPersistentMap)ometa);
/*      */       }
/*      */       
/*  820 */       throw new IllegalArgumentException("Metadata can only be applied to IMetas");
/*      */     }
/*      */   }
/*      */   
/*      */   public static class SyntaxQuoteReader extends AFn
/*      */   {
/*      */     public Object invoke(Object reader, Object backquote, Object opts, Object pendingForms) {
/*  827 */       PushbackReader r = (PushbackReader)reader;
/*      */       try
/*      */       {
/*  830 */         Var.pushThreadBindings(RT.map(new Object[] { LispReader.GENSYM_ENV, PersistentHashMap.EMPTY }));
/*      */         
/*      */ 
/*  833 */         Object form = LispReader.read(r, true, null, true, opts, LispReader.access$100(pendingForms));
/*  834 */         return syntaxQuote(form);
/*      */       }
/*      */       finally
/*      */       {
/*  838 */         Var.popThreadBindings();
/*      */       }
/*      */     }
/*      */     
/*      */     static Object syntaxQuote(Object form) { Object ret;
/*      */       Object ret;
/*  844 */       if (Compiler.isSpecial(form)) {
/*  845 */         ret = RT.list(Compiler.QUOTE, form); } else { Object ret;
/*  846 */         if ((form instanceof Symbol))
/*      */         {
/*  848 */           Symbol sym = (Symbol)form;
/*  849 */           if ((sym.ns == null) && (sym.name.endsWith("#")))
/*      */           {
/*  851 */             IPersistentMap gmap = (IPersistentMap)LispReader.GENSYM_ENV.deref();
/*  852 */             if (gmap == null)
/*  853 */               throw new IllegalStateException("Gensym literal not in syntax-quote");
/*  854 */             Symbol gs = (Symbol)gmap.valAt(sym);
/*  855 */             if (gs == null) {
/*  856 */               LispReader.GENSYM_ENV.set(gmap.assoc(sym, gs = Symbol.intern(null, sym.name.substring(0, sym.name.length() - 1) + "__" + RT.nextID() + "__auto__")));
/*      */             }
/*      */             
/*  859 */             sym = gs;
/*      */           }
/*  861 */           else if ((sym.ns == null) && (sym.name.endsWith(".")))
/*      */           {
/*  863 */             Symbol csym = Symbol.intern(null, sym.name.substring(0, sym.name.length() - 1));
/*  864 */             csym = Compiler.resolveSymbol(csym);
/*  865 */             sym = Symbol.intern(null, csym.name.concat("."));
/*      */           }
/*  867 */           else if ((sym.ns != null) || (!sym.name.startsWith(".")))
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  873 */             Object maybeClass = null;
/*  874 */             if (sym.ns != null) {
/*  875 */               maybeClass = Compiler.currentNS().getMapping(Symbol.intern(null, sym.ns));
/*      */             }
/*  877 */             if ((maybeClass instanceof Class))
/*      */             {
/*      */ 
/*  880 */               sym = Symbol.intern(((Class)maybeClass).getName(), sym.name);
/*      */             }
/*      */             else
/*      */             {
/*  884 */               sym = Compiler.resolveSymbol(sym); }
/*      */           }
/*  886 */           ret = RT.list(Compiler.QUOTE, sym);
/*      */         } else {
/*  888 */           if (LispReader.isUnquote(form))
/*  889 */             return RT.second(form);
/*  890 */           if (LispReader.isUnquoteSplicing(form))
/*  891 */             throw new IllegalStateException("splice not in list");
/*  892 */           if ((form instanceof IPersistentCollection)) {
/*      */             Object ret;
/*  894 */             if ((form instanceof IRecord)) {
/*  895 */               ret = form; } else { Object ret;
/*  896 */               if ((form instanceof IPersistentMap))
/*      */               {
/*  898 */                 IPersistentVector keyvals = flattenMap(form);
/*  899 */                 ret = RT.list(LispReader.APPLY, LispReader.HASHMAP, RT.list(LispReader.SEQ, RT.cons(LispReader.CONCAT, sqExpandList(keyvals.seq()))));
/*      */               } else { Object ret;
/*  901 */                 if ((form instanceof IPersistentVector))
/*      */                 {
/*  903 */                   ret = RT.list(LispReader.APPLY, LispReader.VECTOR, RT.list(LispReader.SEQ, RT.cons(LispReader.CONCAT, sqExpandList(((IPersistentVector)form).seq()))));
/*      */                 } else { Object ret;
/*  905 */                   if ((form instanceof IPersistentSet))
/*      */                   {
/*  907 */                     ret = RT.list(LispReader.APPLY, LispReader.HASHSET, RT.list(LispReader.SEQ, RT.cons(LispReader.CONCAT, sqExpandList(((IPersistentSet)form).seq()))));
/*      */                   } else { Object ret;
/*  909 */                     if (((form instanceof ISeq)) || ((form instanceof IPersistentList)))
/*      */                     {
/*  911 */                       ISeq seq = RT.seq(form);
/*  912 */                       Object ret; if (seq == null) {
/*  913 */                         ret = RT.cons(LispReader.LIST, null);
/*      */                       } else {
/*  915 */                         ret = RT.list(LispReader.SEQ, RT.cons(LispReader.CONCAT, sqExpandList(seq)));
/*      */                       }
/*      */                     } else {
/*  918 */                       throw new UnsupportedOperationException("Unknown Collection type");
/*      */                     } } } } } } else { Object ret;
/*  920 */             if (((form instanceof Keyword)) || ((form instanceof Number)) || ((form instanceof Character)) || ((form instanceof String)))
/*      */             {
/*      */ 
/*      */ 
/*  924 */               ret = form;
/*      */             } else
/*  926 */               ret = RT.list(Compiler.QUOTE, form);
/*      */           } } }
/*  928 */       if (((form instanceof IObj)) && (RT.meta(form) != null))
/*      */       {
/*      */ 
/*  931 */         IPersistentMap newMeta = ((IObj)form).meta().without(RT.LINE_KEY).without(RT.COLUMN_KEY);
/*  932 */         if (newMeta.count() > 0)
/*  933 */           return RT.list(LispReader.WITH_META, ret, syntaxQuote(((IObj)form).meta()));
/*      */       }
/*  935 */       return ret;
/*      */     }
/*      */     
/*      */     private static ISeq sqExpandList(ISeq seq) {
/*  939 */       PersistentVector ret = PersistentVector.EMPTY;
/*  940 */       for (; seq != null; seq = seq.next())
/*      */       {
/*  942 */         Object item = seq.first();
/*  943 */         if (LispReader.isUnquote(item)) {
/*  944 */           ret = ret.cons(RT.list(LispReader.LIST, RT.second(item)));
/*  945 */         } else if (LispReader.isUnquoteSplicing(item)) {
/*  946 */           ret = ret.cons(RT.second(item));
/*      */         } else
/*  948 */           ret = ret.cons(RT.list(LispReader.LIST, syntaxQuote(item)));
/*      */       }
/*  950 */       return ret.seq();
/*      */     }
/*      */     
/*      */     private static IPersistentVector flattenMap(Object form) {
/*  954 */       IPersistentVector keyvals = PersistentVector.EMPTY;
/*  955 */       for (ISeq s = RT.seq(form); s != null; s = s.next())
/*      */       {
/*  957 */         IMapEntry e = (IMapEntry)s.first();
/*  958 */         keyvals = keyvals.cons(e.key());
/*  959 */         keyvals = keyvals.cons(e.val());
/*      */       }
/*  961 */       return keyvals;
/*      */     }
/*      */   }
/*      */   
/*      */   static boolean isUnquoteSplicing(Object form)
/*      */   {
/*  967 */     return ((form instanceof ISeq)) && (Util.equals(RT.first(form), UNQUOTE_SPLICING));
/*      */   }
/*      */   
/*      */   static boolean isUnquote(Object form) {
/*  971 */     return ((form instanceof ISeq)) && (Util.equals(RT.first(form), UNQUOTE));
/*      */   }
/*      */   
/*      */   static class UnquoteReader extends AFn {
/*      */     public Object invoke(Object reader, Object comma, Object opts, Object pendingForms) {
/*  976 */       PushbackReader r = (PushbackReader)reader;
/*  977 */       int ch = LispReader.read1(r);
/*  978 */       if (ch == -1)
/*  979 */         throw Util.runtimeException("EOF while reading character");
/*  980 */       pendingForms = LispReader.ensurePending(pendingForms);
/*  981 */       if (ch == 64)
/*      */       {
/*  983 */         Object o = LispReader.read(r, true, null, true, opts, pendingForms);
/*  984 */         return RT.list(LispReader.UNQUOTE_SPLICING, o);
/*      */       }
/*      */       
/*      */ 
/*  988 */       LispReader.unread(r, ch);
/*  989 */       Object o = LispReader.read(r, true, null, true, opts, pendingForms);
/*  990 */       return RT.list(LispReader.UNQUOTE, o);
/*      */     }
/*      */   }
/*      */   
/*      */   public static class CharacterReader extends AFn
/*      */   {
/*      */     public Object invoke(Object reader, Object backslash, Object opts, Object pendingForms)
/*      */     {
/*  998 */       PushbackReader r = (PushbackReader)reader;
/*  999 */       int ch = LispReader.read1(r);
/* 1000 */       if (ch == -1)
/* 1001 */         throw Util.runtimeException("EOF while reading character");
/* 1002 */       String token = LispReader.readToken(r, (char)ch);
/* 1003 */       if (token.length() == 1)
/* 1004 */         return Character.valueOf(token.charAt(0));
/* 1005 */       if (token.equals("newline"))
/* 1006 */         return Character.valueOf('\n');
/* 1007 */       if (token.equals("space"))
/* 1008 */         return Character.valueOf(' ');
/* 1009 */       if (token.equals("tab"))
/* 1010 */         return Character.valueOf('\t');
/* 1011 */       if (token.equals("backspace"))
/* 1012 */         return Character.valueOf('\b');
/* 1013 */       if (token.equals("formfeed"))
/* 1014 */         return Character.valueOf('\f');
/* 1015 */       if (token.equals("return"))
/* 1016 */         return Character.valueOf('\r');
/* 1017 */       if (token.startsWith("u"))
/*      */       {
/* 1019 */         char c = (char)LispReader.readUnicodeChar(token, 1, 4, 16);
/* 1020 */         if ((c >= 55296) && (c <= 57343))
/* 1021 */           throw Util.runtimeException("Invalid character constant: \\u" + Integer.toString(c, 16));
/* 1022 */         return Character.valueOf(c);
/*      */       }
/* 1024 */       if (token.startsWith("o"))
/*      */       {
/* 1026 */         int len = token.length() - 1;
/* 1027 */         if (len > 3)
/* 1028 */           throw Util.runtimeException("Invalid octal escape sequence length: " + len);
/* 1029 */         int uc = LispReader.readUnicodeChar(token, 1, len, 8);
/* 1030 */         if (uc > 255)
/* 1031 */           throw Util.runtimeException("Octal escape sequence must be in range [0, 377].");
/* 1032 */         return Character.valueOf((char)uc);
/*      */       }
/* 1034 */       throw Util.runtimeException("Unsupported character: \\" + token);
/*      */     }
/*      */   }
/*      */   
/*      */   public static class ListReader extends AFn
/*      */   {
/*      */     public Object invoke(Object reader, Object leftparen, Object opts, Object pendingForms) {
/* 1041 */       PushbackReader r = (PushbackReader)reader;
/* 1042 */       int line = -1;
/* 1043 */       int column = -1;
/* 1044 */       if ((r instanceof LineNumberingPushbackReader))
/*      */       {
/* 1046 */         line = ((LineNumberingPushbackReader)r).getLineNumber();
/* 1047 */         column = ((LineNumberingPushbackReader)r).getColumnNumber() - 1;
/*      */       }
/* 1049 */       List list = LispReader.readDelimitedList(')', r, true, opts, LispReader.ensurePending(pendingForms));
/* 1050 */       if (list.isEmpty())
/* 1051 */         return PersistentList.EMPTY;
/* 1052 */       IObj s = (IObj)PersistentList.create(list);
/*      */       
/* 1054 */       if (line != -1)
/*      */       {
/* 1056 */         return s.withMeta(RT.map(new Object[] { RT.LINE_KEY, Integer.valueOf(line), RT.COLUMN_KEY, Integer.valueOf(column) }));
/*      */       }
/*      */       
/* 1059 */       return s;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static class EvalReader
/*      */     extends AFn
/*      */   {
/*      */     public Object invoke(Object reader, Object eq, Object opts, Object pendingForms)
/*      */     {
/* 1098 */       if (!RT.booleanCast(RT.READEVAL.deref()))
/*      */       {
/* 1100 */         throw Util.runtimeException("EvalReader not allowed when *read-eval* is false.");
/*      */       }
/*      */       
/* 1103 */       PushbackReader r = (PushbackReader)reader;
/* 1104 */       Object o = LispReader.read(r, true, null, true, opts, LispReader.access$100(pendingForms));
/* 1105 */       if ((o instanceof Symbol))
/*      */       {
/* 1107 */         return RT.classForName(o.toString());
/*      */       }
/* 1109 */       if ((o instanceof IPersistentList))
/*      */       {
/* 1111 */         Symbol fs = (Symbol)RT.first(o);
/* 1112 */         if (fs.equals(LispReader.THE_VAR))
/*      */         {
/* 1114 */           Symbol vs = (Symbol)RT.second(o);
/* 1115 */           return RT.var(vs.ns, vs.name);
/*      */         }
/* 1117 */         if (fs.name.endsWith("."))
/*      */         {
/* 1119 */           Object[] args = RT.toArray(RT.next(o));
/* 1120 */           return Reflector.invokeConstructor(RT.classForName(fs.name.substring(0, fs.name.length() - 1)), args);
/*      */         }
/* 1122 */         if (Compiler.namesStaticMember(fs))
/*      */         {
/* 1124 */           Object[] args = RT.toArray(RT.next(o));
/* 1125 */           return Reflector.invokeStaticMethod(fs.ns, fs.name, args);
/*      */         }
/* 1127 */         Object v = Compiler.maybeResolveIn(Compiler.currentNS(), fs);
/* 1128 */         if ((v instanceof Var))
/*      */         {
/* 1130 */           return ((IFn)v).applyTo(RT.next(o));
/*      */         }
/* 1132 */         throw Util.runtimeException("Can't resolve " + fs);
/*      */       }
/*      */       
/* 1135 */       throw new IllegalArgumentException("Unsupported #= form");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static class VectorReader
/*      */     extends AFn
/*      */   {
/*      */     public Object invoke(Object reader, Object leftparen, Object opts, Object pendingForms)
/*      */     {
/* 1149 */       PushbackReader r = (PushbackReader)reader;
/* 1150 */       return LazilyPersistentVector.create(LispReader.readDelimitedList(']', r, true, opts, LispReader.ensurePending(pendingForms)));
/*      */     }
/*      */   }
/*      */   
/*      */   public static class MapReader extends AFn
/*      */   {
/*      */     public Object invoke(Object reader, Object leftparen, Object opts, Object pendingForms) {
/* 1157 */       PushbackReader r = (PushbackReader)reader;
/* 1158 */       Object[] a = LispReader.readDelimitedList('}', r, true, opts, LispReader.ensurePending(pendingForms)).toArray();
/* 1159 */       if ((a.length & 0x1) == 1)
/* 1160 */         throw Util.runtimeException("Map literal must contain an even number of forms");
/* 1161 */       return RT.map(a);
/*      */     }
/*      */   }
/*      */   
/*      */   public static class SetReader extends AFn
/*      */   {
/*      */     public Object invoke(Object reader, Object leftbracket, Object opts, Object pendingForms) {
/* 1168 */       PushbackReader r = (PushbackReader)reader;
/* 1169 */       return PersistentHashSet.createWithCheck(LispReader.readDelimitedList('}', r, true, opts, LispReader.ensurePending(pendingForms)));
/*      */     }
/*      */   }
/*      */   
/*      */   public static class UnmatchedDelimiterReader extends AFn
/*      */   {
/*      */     public Object invoke(Object reader, Object rightdelim, Object opts, Object pendingForms) {
/* 1176 */       throw Util.runtimeException("Unmatched delimiter: " + rightdelim);
/*      */     }
/*      */   }
/*      */   
/*      */   public static class UnreadableReader extends AFn
/*      */   {
/*      */     public Object invoke(Object reader, Object leftangle, Object opts, Object pendingForms) {
/* 1183 */       throw Util.runtimeException("Unreadable form");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/* 1188 */   private static final Object READ_EOF = new Object();
/* 1189 */   private static final Object READ_FINISHED = new Object();
/*      */   
/*      */   public static List readDelimitedList(char delim, PushbackReader r, boolean isRecursive, Object opts, Object pendingForms) {
/* 1192 */     int firstline = (r instanceof LineNumberingPushbackReader) ? ((LineNumberingPushbackReader)r).getLineNumber() : -1;
/*      */     
/*      */ 
/*      */ 
/* 1196 */     ArrayList a = new ArrayList();
/*      */     
/*      */     for (;;)
/*      */     {
/* 1200 */       Object form = read(r, false, READ_EOF, Character.valueOf(delim), READ_FINISHED, isRecursive, opts, pendingForms);
/*      */       
/* 1202 */       if (form == READ_EOF) {
/* 1203 */         if (firstline < 0) {
/* 1204 */           throw Util.runtimeException("EOF while reading");
/*      */         }
/* 1206 */         throw Util.runtimeException("EOF while reading, starting at line " + firstline); }
/* 1207 */       if (form == READ_FINISHED) {
/* 1208 */         return a;
/*      */       }
/*      */       
/* 1211 */       a.add(form);
/*      */     }
/*      */   }
/*      */   
/*      */   public static class CtorReader extends AFn {
/*      */     public Object invoke(Object reader, Object firstChar, Object opts, Object pendingForms) {
/* 1217 */       PushbackReader r = (PushbackReader)reader;
/* 1218 */       pendingForms = LispReader.ensurePending(pendingForms);
/* 1219 */       Object name = LispReader.read(r, true, null, false, opts, pendingForms);
/* 1220 */       if (!(name instanceof Symbol))
/* 1221 */         throw new RuntimeException("Reader tag must be a symbol");
/* 1222 */       Symbol sym = (Symbol)name;
/* 1223 */       Object form = LispReader.read(r, true, null, true, opts, pendingForms);
/*      */       
/* 1225 */       if ((LispReader.isPreserveReadCond(opts)) || (RT.suppressRead())) {
/* 1226 */         return TaggedLiteral.create(sym, form);
/*      */       }
/* 1228 */       return sym.getName().contains(".") ? readRecord(form, sym, opts, pendingForms) : readTagged(form, sym, opts, pendingForms);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     private Object readTagged(Object o, Symbol tag, Object opts, Object pendingForms)
/*      */     {
/* 1235 */       ILookup data_readers = (ILookup)RT.DATA_READERS.deref();
/* 1236 */       IFn data_reader = (IFn)RT.get(data_readers, tag);
/* 1237 */       if (data_reader == null) {
/* 1238 */         data_readers = (ILookup)RT.DEFAULT_DATA_READERS.deref();
/* 1239 */         data_reader = (IFn)RT.get(data_readers, tag);
/* 1240 */         if (data_reader == null) {
/* 1241 */           IFn default_reader = (IFn)RT.DEFAULT_DATA_READER_FN.deref();
/* 1242 */           if (default_reader != null) {
/* 1243 */             return default_reader.invoke(tag, o);
/*      */           }
/* 1245 */           throw new RuntimeException("No reader function for tag " + tag.toString());
/*      */         }
/*      */       }
/*      */       
/* 1249 */       return data_reader.invoke(o);
/*      */     }
/*      */     
/*      */     private Object readRecord(Object form, Symbol recordName, Object opts, Object pendingForms) {
/* 1253 */       boolean readeval = RT.booleanCast(RT.READEVAL.deref());
/*      */       
/* 1255 */       if (!readeval)
/*      */       {
/* 1257 */         throw Util.runtimeException("Record construction syntax can only be used when *read-eval* == true");
/*      */       }
/*      */       
/* 1260 */       Class recordClass = RT.classForNameNonLoading(recordName.toString());
/*      */       
/*      */ 
/* 1263 */       boolean shortForm = true;
/*      */       
/* 1265 */       if ((form instanceof IPersistentMap)) {
/* 1266 */         shortForm = false;
/* 1267 */       } else if ((form instanceof IPersistentVector)) {
/* 1268 */         shortForm = true;
/*      */       } else {
/* 1270 */         throw Util.runtimeException("Unreadable constructor form starting with \"#" + recordName + "\"");
/*      */       }
/*      */       
/* 1273 */       Object ret = null;
/* 1274 */       Constructor[] allctors = recordClass.getConstructors();
/*      */       
/* 1276 */       if (shortForm)
/*      */       {
/* 1278 */         IPersistentVector recordEntries = (IPersistentVector)form;
/* 1279 */         boolean ctorFound = false;
/* 1280 */         for (Constructor ctor : allctors) {
/* 1281 */           if (ctor.getParameterTypes().length == recordEntries.count())
/* 1282 */             ctorFound = true;
/*      */         }
/* 1284 */         if (!ctorFound) {
/* 1285 */           throw Util.runtimeException("Unexpected number of constructor arguments to " + recordClass.toString() + ": got " + recordEntries.count());
/*      */         }
/* 1287 */         ret = Reflector.invokeConstructor(recordClass, RT.toArray(recordEntries));
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/* 1292 */         IPersistentMap vals = (IPersistentMap)form;
/* 1293 */         for (ISeq s = RT.keys(vals); s != null; s = s.next())
/*      */         {
/* 1295 */           if (!(s.first() instanceof Keyword))
/* 1296 */             throw Util.runtimeException("Unreadable defrecord form: key must be of type clojure.lang.Keyword, got " + s.first().toString());
/*      */         }
/* 1298 */         ret = Reflector.invokeStaticMethod(recordClass, "create", new Object[] { vals });
/*      */       }
/*      */       
/* 1301 */       return ret;
/*      */     }
/*      */   }
/*      */   
/*      */   static boolean isPreserveReadCond(Object opts) {
/* 1306 */     if ((RT.booleanCast(READ_COND_ENV.deref())) && ((opts instanceof IPersistentMap)))
/*      */     {
/* 1308 */       Object readCond = ((IPersistentMap)opts).valAt(OPT_READ_COND);
/* 1309 */       return COND_PRESERVE.equals(readCond);
/*      */     }
/*      */     
/* 1312 */     return false;
/*      */   }
/*      */   
/*      */   public static class ConditionalReader extends AFn
/*      */   {
/* 1317 */     private static final Object READ_STARTED = new Object();
/* 1318 */     public static final Keyword DEFAULT_FEATURE = Keyword.intern(null, "default");
/* 1319 */     public static final IPersistentSet RESERVED_FEATURES = RT.set(new Object[] { Keyword.intern(null, "else"), Keyword.intern(null, "none") });
/*      */     
/*      */     public static boolean hasFeature(Object feature, Object opts)
/*      */     {
/* 1323 */       if (!(feature instanceof Keyword)) {
/* 1324 */         throw Util.runtimeException("Feature should be a keyword: " + feature);
/*      */       }
/* 1326 */       if (DEFAULT_FEATURE.equals(feature)) {
/* 1327 */         return true;
/*      */       }
/* 1329 */       IPersistentSet custom = (IPersistentSet)((IPersistentMap)opts).valAt(LispReader.OPT_FEATURES);
/* 1330 */       return (custom != null) && (custom.contains(feature));
/*      */     }
/*      */     
/*      */     public static Object readCondDelimited(PushbackReader r, boolean splicing, Object opts, Object pendingForms) {
/* 1334 */       Object result = READ_STARTED;
/*      */       
/* 1336 */       boolean toplevel = pendingForms == null;
/* 1337 */       pendingForms = LispReader.ensurePending(pendingForms);
/*      */       
/* 1339 */       int firstline = (r instanceof LineNumberingPushbackReader) ? ((LineNumberingPushbackReader)r).getLineNumber() : -1;
/*      */       
/*      */ 
/*      */       for (;;)
/*      */       {
/* 1344 */         if (result == READ_STARTED)
/*      */         {
/* 1346 */           Object form = LispReader.read(r, false, LispReader.READ_EOF, Character.valueOf(')'), LispReader.READ_FINISHED, true, opts, pendingForms);
/*      */           
/* 1348 */           if (form == LispReader.READ_EOF) {
/* 1349 */             if (firstline < 0) {
/* 1350 */               throw Util.runtimeException("EOF while reading");
/*      */             }
/* 1352 */             throw Util.runtimeException("EOF while reading, starting at line " + firstline); }
/* 1353 */           if (form == LispReader.READ_FINISHED) {
/*      */             break;
/*      */           }
/*      */           
/* 1357 */           if (RESERVED_FEATURES.contains(form)) {
/* 1358 */             throw Util.runtimeException("Feature name " + form + " is reserved.");
/*      */           }
/* 1360 */           if (hasFeature(form, opts))
/*      */           {
/*      */ 
/*      */ 
/* 1364 */             form = LispReader.read(r, false, LispReader.READ_EOF, Character.valueOf(')'), LispReader.READ_FINISHED, true, opts, pendingForms);
/*      */             
/* 1366 */             if (form == LispReader.READ_EOF) {
/* 1367 */               if (firstline < 0) {
/* 1368 */                 throw Util.runtimeException("EOF while reading");
/*      */               }
/* 1370 */               throw Util.runtimeException("EOF while reading, starting at line " + firstline); }
/* 1371 */             if (form == LispReader.READ_FINISHED) {
/* 1372 */               if (firstline < 0) {
/* 1373 */                 throw Util.runtimeException("read-cond requires an even number of forms.");
/*      */               }
/* 1375 */               throw Util.runtimeException("read-cond starting on line " + firstline + " requires an even number of forms");
/*      */             }
/* 1377 */             result = form;
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */         try
/*      */         {
/* 1384 */           Var.pushThreadBindings(RT.map(new Object[] { RT.SUPPRESS_READ, RT.T }));
/* 1385 */           Object form = LispReader.read(r, false, LispReader.READ_EOF, Character.valueOf(')'), LispReader.READ_FINISHED, true, opts, pendingForms);
/*      */           
/* 1387 */           if (form == LispReader.READ_EOF) {
/* 1388 */             if (firstline < 0) {
/* 1389 */               throw Util.runtimeException("EOF while reading");
/*      */             }
/* 1391 */             throw Util.runtimeException("EOF while reading, starting at line " + firstline); }
/* 1392 */           if (form == LispReader.READ_FINISHED)
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/* 1397 */             Var.popThreadBindings(); break; } } finally { Var.popThreadBindings();
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 1402 */       if (result == READ_STARTED) {
/* 1403 */         return r;
/*      */       }
/* 1405 */       if (splicing) {
/* 1406 */         if (!(result instanceof List)) {
/* 1407 */           throw Util.runtimeException("Spliced form list in read-cond-splicing must implement java.util.List");
/*      */         }
/* 1409 */         if (toplevel) {
/* 1410 */           throw Util.runtimeException("Reader conditional splicing not allowed at the top level.");
/*      */         }
/* 1412 */         ((List)pendingForms).addAll(0, (List)result);
/*      */         
/* 1414 */         return r;
/*      */       }
/* 1416 */       return result;
/*      */     }
/*      */     
/*      */     private static void checkConditionalAllowed(Object opts)
/*      */     {
/* 1421 */       IPersistentMap mopts = (IPersistentMap)opts;
/* 1422 */       if ((opts == null) || ((!LispReader.COND_ALLOW.equals(mopts.valAt(LispReader.OPT_READ_COND))) && (!LispReader.COND_PRESERVE.equals(mopts.valAt(LispReader.OPT_READ_COND)))))
/*      */       {
/* 1424 */         throw Util.runtimeException("Conditional read not allowed"); }
/*      */     }
/*      */     
/*      */     public Object invoke(Object reader, Object mode, Object opts, Object pendingForms) {
/* 1428 */       checkConditionalAllowed(opts);
/*      */       
/* 1430 */       PushbackReader r = (PushbackReader)reader;
/* 1431 */       int ch = LispReader.read1(r);
/* 1432 */       if (ch == -1) {
/* 1433 */         throw Util.runtimeException("EOF while reading character");
/*      */       }
/* 1435 */       boolean splicing = false;
/*      */       
/* 1437 */       if (ch == 64) {
/* 1438 */         splicing = true;
/* 1439 */         ch = LispReader.read1(r);
/*      */       }
/*      */       
/* 1442 */       while (LispReader.isWhitespace(ch)) {
/* 1443 */         ch = LispReader.read1(r);
/*      */       }
/* 1445 */       if (ch == -1) {
/* 1446 */         throw Util.runtimeException("EOF while reading character");
/*      */       }
/* 1448 */       if (ch != 40) {
/* 1449 */         throw Util.runtimeException("read-cond body must be a list");
/*      */       }
/*      */       try {
/* 1452 */         Var.pushThreadBindings(RT.map(new Object[] { LispReader.READ_COND_ENV, RT.T }));
/*      */         IFn listReader;
/* 1454 */         if (LispReader.isPreserveReadCond(opts)) {
/* 1455 */           listReader = LispReader.getMacro(ch);
/* 1456 */           Object form = listReader.invoke(r, Integer.valueOf(ch), opts, LispReader.ensurePending(pendingForms));
/*      */           
/* 1458 */           return ReaderConditional.create(form, splicing);
/*      */         }
/* 1460 */         return readCondDelimited(r, splicing, opts, pendingForms);
/*      */       }
/*      */       finally {
/* 1463 */         Var.popThreadBindings();
/*      */       }
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\LispReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */