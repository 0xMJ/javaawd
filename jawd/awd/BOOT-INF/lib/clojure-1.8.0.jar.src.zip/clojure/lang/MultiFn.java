/*     */ package clojure.lang;
/*     */ 
/*     */ import java.util.Map.Entry;
/*     */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*     */ import java.util.concurrent.locks.ReentrantReadWriteLock.ReadLock;
/*     */ import java.util.concurrent.locks.ReentrantReadWriteLock.WriteLock;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MultiFn
/*     */   extends AFn
/*     */ {
/*     */   public final IFn dispatchFn;
/*     */   public final Object defaultDispatchVal;
/*     */   public final IRef hierarchy;
/*     */   final String name;
/*     */   final ReentrantReadWriteLock rw;
/*     */   volatile IPersistentMap methodTable;
/*     */   volatile IPersistentMap preferTable;
/*     */   volatile IPersistentMap methodCache;
/*     */   volatile Object cachedHierarchy;
/*  29 */   static final Var assoc = RT.var("clojure.core", "assoc");
/*  30 */   static final Var dissoc = RT.var("clojure.core", "dissoc");
/*  31 */   static final Var isa = RT.var("clojure.core", "isa?");
/*  32 */   static final Var parents = RT.var("clojure.core", "parents");
/*     */   
/*     */   public MultiFn(String name, IFn dispatchFn, Object defaultDispatchVal, IRef hierarchy) {
/*  35 */     this.rw = new ReentrantReadWriteLock();
/*  36 */     this.name = name;
/*  37 */     this.dispatchFn = dispatchFn;
/*  38 */     this.defaultDispatchVal = defaultDispatchVal;
/*  39 */     this.methodTable = PersistentHashMap.EMPTY;
/*  40 */     this.methodCache = getMethodTable();
/*  41 */     this.preferTable = PersistentHashMap.EMPTY;
/*  42 */     this.hierarchy = hierarchy;
/*  43 */     this.cachedHierarchy = null;
/*     */   }
/*     */   
/*     */   public MultiFn reset() {
/*  47 */     this.rw.writeLock().lock();
/*     */     try {
/*  49 */       this.methodTable = (this.methodCache = this.preferTable = PersistentHashMap.EMPTY);
/*  50 */       this.cachedHierarchy = null;
/*  51 */       return this;
/*     */     }
/*     */     finally {
/*  54 */       this.rw.writeLock().unlock();
/*     */     }
/*     */   }
/*     */   
/*     */   public MultiFn addMethod(Object dispatchVal, IFn method) {
/*  59 */     this.rw.writeLock().lock();
/*     */     try {
/*  61 */       this.methodTable = getMethodTable().assoc(dispatchVal, method);
/*  62 */       resetCache();
/*  63 */       return this;
/*     */     }
/*     */     finally {
/*  66 */       this.rw.writeLock().unlock();
/*     */     }
/*     */   }
/*     */   
/*     */   public MultiFn removeMethod(Object dispatchVal) {
/*  71 */     this.rw.writeLock().lock();
/*     */     try
/*     */     {
/*  74 */       this.methodTable = getMethodTable().without(dispatchVal);
/*  75 */       resetCache();
/*  76 */       return this;
/*     */     }
/*     */     finally
/*     */     {
/*  80 */       this.rw.writeLock().unlock();
/*     */     }
/*     */   }
/*     */   
/*     */   public MultiFn preferMethod(Object dispatchValX, Object dispatchValY) {
/*  85 */     this.rw.writeLock().lock();
/*     */     try
/*     */     {
/*  88 */       if (prefers(dispatchValY, dispatchValX)) {
/*  89 */         throw new IllegalStateException(String.format("Preference conflict in multimethod '%s': %s is already preferred to %s", new Object[] { this.name, dispatchValY, dispatchValX }));
/*     */       }
/*     */       
/*  92 */       this.preferTable = getPreferTable().assoc(dispatchValX, RT.conj((IPersistentCollection)RT.get(getPreferTable(), dispatchValX, PersistentHashSet.EMPTY), dispatchValY));
/*     */       
/*     */ 
/*     */ 
/*  96 */       resetCache();
/*  97 */       return this;
/*     */     }
/*     */     finally
/*     */     {
/* 101 */       this.rw.writeLock().unlock();
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean prefers(Object x, Object y) {
/* 106 */     IPersistentSet xprefs = (IPersistentSet)getPreferTable().valAt(x);
/* 107 */     if ((xprefs != null) && (xprefs.contains(y)))
/* 108 */       return true;
/* 109 */     for (ISeq ps = RT.seq(parents.invoke(y)); ps != null; ps = ps.next())
/*     */     {
/* 111 */       if (prefers(x, ps.first()))
/* 112 */         return true;
/*     */     }
/* 114 */     for (ISeq ps = RT.seq(parents.invoke(x)); ps != null; ps = ps.next())
/*     */     {
/* 116 */       if (prefers(ps.first(), y))
/* 117 */         return true;
/*     */     }
/* 119 */     return false;
/*     */   }
/*     */   
/*     */   private boolean isA(Object x, Object y) {
/* 123 */     return RT.booleanCast(isa.invoke(this.hierarchy.deref(), x, y));
/*     */   }
/*     */   
/*     */   private boolean dominates(Object x, Object y) {
/* 127 */     return (prefers(x, y)) || (isA(x, y));
/*     */   }
/*     */   
/*     */   private IPersistentMap resetCache() {
/* 131 */     this.rw.writeLock().lock();
/*     */     try
/*     */     {
/* 134 */       this.methodCache = getMethodTable();
/* 135 */       this.cachedHierarchy = this.hierarchy.deref();
/* 136 */       return this.methodCache;
/*     */     }
/*     */     finally
/*     */     {
/* 140 */       this.rw.writeLock().unlock();
/*     */     }
/*     */   }
/*     */   
/*     */   public IFn getMethod(Object dispatchVal) {
/* 145 */     if (this.cachedHierarchy != this.hierarchy.deref())
/* 146 */       resetCache();
/* 147 */     IFn targetFn = (IFn)this.methodCache.valAt(dispatchVal);
/* 148 */     if (targetFn != null)
/* 149 */       return targetFn;
/* 150 */     return findAndCacheBestMethod(dispatchVal);
/*     */   }
/*     */   
/*     */   private IFn getFn(Object dispatchVal) {
/* 154 */     IFn targetFn = getMethod(dispatchVal);
/* 155 */     if (targetFn == null) {
/* 156 */       throw new IllegalArgumentException(String.format("No method in multimethod '%s' for dispatch value: %s", new Object[] { this.name, dispatchVal }));
/*     */     }
/* 158 */     return targetFn;
/*     */   }
/*     */   
/*     */   private IFn findAndCacheBestMethod(Object dispatchVal) {
/* 162 */     this.rw.readLock().lock();
/*     */     
/* 164 */     IPersistentMap mt = this.methodTable;
/* 165 */     IPersistentMap pt = this.preferTable;
/* 166 */     Object ch = this.cachedHierarchy;
/*     */     Map.Entry bestEntry;
/*     */     Object bestValue;
/* 169 */     try { bestEntry = null;
/* 170 */       for (Object o : getMethodTable())
/*     */       {
/* 172 */         Map.Entry e = (Map.Entry)o;
/* 173 */         if (isA(dispatchVal, e.getKey()))
/*     */         {
/* 175 */           if ((bestEntry == null) || (dominates(e.getKey(), bestEntry.getKey())))
/* 176 */             bestEntry = e;
/* 177 */           if (!dominates(bestEntry.getKey(), e.getKey())) {
/* 178 */             throw new IllegalArgumentException(String.format("Multiple methods in multimethod '%s' match dispatch value: %s -> %s and %s, and neither is preferred", new Object[] { this.name, dispatchVal, e.getKey(), bestEntry.getKey() }));
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 184 */       if (bestEntry == null)
/*     */       {
/* 186 */         Object bestValue = this.methodTable.valAt(this.defaultDispatchVal);
/* 187 */         if (bestValue == null) {
/* 188 */           return null;
/*     */         }
/*     */       } else {
/* 191 */         bestValue = bestEntry.getValue();
/*     */       }
/*     */     }
/*     */     finally {
/* 195 */       this.rw.readLock().unlock();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 200 */     this.rw.writeLock().lock();
/*     */     try
/*     */     {
/* 203 */       if ((mt == this.methodTable) && (pt == this.preferTable) && (ch == this.cachedHierarchy) && (this.cachedHierarchy == this.hierarchy.deref()))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 209 */         this.methodCache = this.methodCache.assoc(dispatchVal, bestValue);
/* 210 */         return (IFn)bestValue;
/*     */       }
/*     */       
/*     */ 
/* 214 */       resetCache();
/* 215 */       return findAndCacheBestMethod(dispatchVal);
/*     */ 
/*     */     }
/*     */     finally
/*     */     {
/* 220 */       this.rw.writeLock().unlock();
/*     */     }
/*     */   }
/*     */   
/*     */   public Object invoke() {
/* 225 */     return getFn(this.dispatchFn.invoke()).invoke();
/*     */   }
/*     */   
/*     */   public Object invoke(Object arg1) {
/* 229 */     return getFn(this.dispatchFn.invoke(arg1)).invoke(Util.ret1(arg1, arg1 = null));
/*     */   }
/*     */   
/*     */   public Object invoke(Object arg1, Object arg2) {
/* 233 */     return getFn(this.dispatchFn.invoke(arg1, arg2)).invoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null));
/*     */   }
/*     */   
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3)
/*     */   {
/* 238 */     return getFn(this.dispatchFn.invoke(arg1, arg2, arg3)).invoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null));
/*     */   }
/*     */   
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4)
/*     */   {
/* 243 */     return getFn(this.dispatchFn.invoke(arg1, arg2, arg3, arg4)).invoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5)
/*     */   {
/* 251 */     return getFn(this.dispatchFn.invoke(arg1, arg2, arg3, arg4, arg5)).invoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6)
/*     */   {
/* 260 */     return getFn(this.dispatchFn.invoke(arg1, arg2, arg3, arg4, arg5, arg6)).invoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7)
/*     */   {
/* 271 */     return getFn(this.dispatchFn.invoke(arg1, arg2, arg3, arg4, arg5, arg6, arg7)).invoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8)
/*     */   {
/* 283 */     return getFn(this.dispatchFn.invoke(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8)).invoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9)
/*     */   {
/* 296 */     return getFn(this.dispatchFn.invoke(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9)).invoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10)
/*     */   {
/* 310 */     return getFn(this.dispatchFn.invoke(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10)).invoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11)
/*     */   {
/* 325 */     return getFn(this.dispatchFn.invoke(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11)).invoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12)
/*     */   {
/* 341 */     return getFn(this.dispatchFn.invoke(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12)).invoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12, Object arg13)
/*     */   {
/* 358 */     return getFn(this.dispatchFn.invoke(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13)).invoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12, Object arg13, Object arg14)
/*     */   {
/* 377 */     return getFn(this.dispatchFn.invoke(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14)).invoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12, Object arg13, Object arg14, Object arg15)
/*     */   {
/* 398 */     return getFn(this.dispatchFn.invoke(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15)).invoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12, Object arg13, Object arg14, Object arg15, Object arg16)
/*     */   {
/* 421 */     return getFn(this.dispatchFn.invoke(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16)).invoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12, Object arg13, Object arg14, Object arg15, Object arg16, Object arg17)
/*     */   {
/* 445 */     return getFn(this.dispatchFn.invoke(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17)).invoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12, Object arg13, Object arg14, Object arg15, Object arg16, Object arg17, Object arg18)
/*     */   {
/* 470 */     return getFn(this.dispatchFn.invoke(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18)).invoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12, Object arg13, Object arg14, Object arg15, Object arg16, Object arg17, Object arg18, Object arg19)
/*     */   {
/* 496 */     return getFn(this.dispatchFn.invoke(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19)).invoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null), Util.ret1(arg19, arg19 = null));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12, Object arg13, Object arg14, Object arg15, Object arg16, Object arg17, Object arg18, Object arg19, Object arg20)
/*     */   {
/* 524 */     return getFn(this.dispatchFn.invoke(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20)).invoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null), Util.ret1(arg19, arg19 = null), Util.ret1(arg20, arg20 = null));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12, Object arg13, Object arg14, Object arg15, Object arg16, Object arg17, Object arg18, Object arg19, Object arg20, Object... args)
/*     */   {
/* 553 */     return getFn(this.dispatchFn.invoke(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, args)).invoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null), Util.ret1(arg19, arg19 = null), Util.ret1(arg20, arg20 = null), args);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public IPersistentMap getMethodTable()
/*     */   {
/* 580 */     return this.methodTable;
/*     */   }
/*     */   
/*     */   public IPersistentMap getPreferTable() {
/* 584 */     return this.preferTable;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\MultiFn.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */