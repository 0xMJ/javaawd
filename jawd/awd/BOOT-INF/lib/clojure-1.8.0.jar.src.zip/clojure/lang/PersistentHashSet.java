/*     */ package clojure.lang;
/*     */ 
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PersistentHashSet
/*     */   extends APersistentSet
/*     */   implements IObj, IEditableCollection
/*     */ {
/*  19 */   public static final PersistentHashSet EMPTY = new PersistentHashSet(null, PersistentHashMap.EMPTY);
/*     */   final IPersistentMap _meta;
/*     */   
/*     */   public static PersistentHashSet create(Object... init)
/*     */   {
/*  24 */     ITransientSet ret = (ITransientSet)EMPTY.asTransient();
/*  25 */     for (int i = 0; i < init.length; i++)
/*     */     {
/*  27 */       ret = (ITransientSet)ret.conj(init[i]);
/*     */     }
/*  29 */     return (PersistentHashSet)ret.persistent();
/*     */   }
/*     */   
/*     */   public static PersistentHashSet create(List init) {
/*  33 */     ITransientSet ret = (ITransientSet)EMPTY.asTransient();
/*  34 */     for (Object key : init)
/*     */     {
/*  36 */       ret = (ITransientSet)ret.conj(key);
/*     */     }
/*  38 */     return (PersistentHashSet)ret.persistent();
/*     */   }
/*     */   
/*     */   public static PersistentHashSet create(ISeq items) {
/*  42 */     ITransientSet ret = (ITransientSet)EMPTY.asTransient();
/*  43 */     for (; items != null; items = items.next())
/*     */     {
/*  45 */       ret = (ITransientSet)ret.conj(items.first());
/*     */     }
/*  47 */     return (PersistentHashSet)ret.persistent();
/*     */   }
/*     */   
/*     */   public static PersistentHashSet createWithCheck(Object... init) {
/*  51 */     ITransientSet ret = (ITransientSet)EMPTY.asTransient();
/*  52 */     for (int i = 0; i < init.length; i++)
/*     */     {
/*  54 */       ret = (ITransientSet)ret.conj(init[i]);
/*  55 */       if (ret.count() != i + 1)
/*  56 */         throw new IllegalArgumentException("Duplicate key: " + init[i]);
/*     */     }
/*  58 */     return (PersistentHashSet)ret.persistent();
/*     */   }
/*     */   
/*     */   public static PersistentHashSet createWithCheck(List init) {
/*  62 */     ITransientSet ret = (ITransientSet)EMPTY.asTransient();
/*  63 */     int i = 0;
/*  64 */     for (Object key : init)
/*     */     {
/*  66 */       ret = (ITransientSet)ret.conj(key);
/*  67 */       if (ret.count() != i + 1)
/*  68 */         throw new IllegalArgumentException("Duplicate key: " + key);
/*  69 */       i++;
/*     */     }
/*  71 */     return (PersistentHashSet)ret.persistent();
/*     */   }
/*     */   
/*     */   public static PersistentHashSet createWithCheck(ISeq items) {
/*  75 */     ITransientSet ret = (ITransientSet)EMPTY.asTransient();
/*  76 */     for (int i = 0; items != null; i++)
/*     */     {
/*  78 */       ret = (ITransientSet)ret.conj(items.first());
/*  79 */       if (ret.count() != i + 1) {
/*  80 */         throw new IllegalArgumentException("Duplicate key: " + items.first());
/*     */       }
/*  76 */       items = items.next();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  82 */     return (PersistentHashSet)ret.persistent();
/*     */   }
/*     */   
/*     */   PersistentHashSet(IPersistentMap meta, IPersistentMap impl) {
/*  86 */     super(impl);
/*  87 */     this._meta = meta;
/*     */   }
/*     */   
/*     */   public IPersistentSet disjoin(Object key) {
/*  91 */     if (contains(key))
/*  92 */       return new PersistentHashSet(meta(), this.impl.without(key));
/*  93 */     return this;
/*     */   }
/*     */   
/*     */   public IPersistentSet cons(Object o) {
/*  97 */     if (contains(o))
/*  98 */       return this;
/*  99 */     return new PersistentHashSet(meta(), this.impl.assoc(o, o));
/*     */   }
/*     */   
/*     */   public IPersistentCollection empty() {
/* 103 */     return EMPTY.withMeta(meta());
/*     */   }
/*     */   
/*     */   public PersistentHashSet withMeta(IPersistentMap meta) {
/* 107 */     return new PersistentHashSet(meta, this.impl);
/*     */   }
/*     */   
/*     */   public ITransientCollection asTransient() {
/* 111 */     return new TransientHashSet(((PersistentHashMap)this.impl).asTransient());
/*     */   }
/*     */   
/*     */   public IPersistentMap meta() {
/* 115 */     return this._meta;
/*     */   }
/*     */   
/*     */   static final class TransientHashSet extends ATransientSet {
/*     */     TransientHashSet(ITransientMap impl) {
/* 120 */       super();
/*     */     }
/*     */     
/*     */     public IPersistentCollection persistent() {
/* 124 */       return new PersistentHashSet(null, this.impl.persistent());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\PersistentHashSet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */