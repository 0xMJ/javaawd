/*     */ package clojure.lang;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Reflector
/*     */ {
/*     */   public static Object invokeInstanceMethod(Object target, String methodName, Object[] args)
/*     */   {
/*  26 */     Class c = target.getClass();
/*  27 */     List methods = getMethods(c, args.length, methodName, false);
/*  28 */     return invokeMatchingMethod(methodName, methods, target, args);
/*     */   }
/*     */   
/*     */   private static Throwable getCauseOrElse(Exception e) {
/*  32 */     if (e.getCause() != null)
/*  33 */       return e.getCause();
/*  34 */     return e;
/*     */   }
/*     */   
/*     */   private static RuntimeException throwCauseOrElseException(Exception e) {
/*  38 */     if (e.getCause() != null)
/*  39 */       throw Util.sneakyThrow(e.getCause());
/*  40 */     throw Util.sneakyThrow(e);
/*     */   }
/*     */   
/*     */   private static String noMethodReport(String methodName, Object target) {
/*  44 */     return "No matching method found: " + methodName + (target == null ? "" : new StringBuilder().append(" for ").append(target.getClass()).toString());
/*     */   }
/*     */   
/*     */   static Object invokeMatchingMethod(String methodName, List methods, Object target, Object[] args)
/*     */   {
/*  49 */     Method m = null;
/*  50 */     Object[] boxedArgs = null;
/*  51 */     if (methods.isEmpty())
/*     */     {
/*  53 */       throw new IllegalArgumentException(noMethodReport(methodName, target));
/*     */     }
/*  55 */     if (methods.size() == 1)
/*     */     {
/*  57 */       m = (Method)methods.get(0);
/*  58 */       boxedArgs = boxArgs(m.getParameterTypes(), args);
/*     */     }
/*     */     else
/*     */     {
/*  62 */       Method foundm = null;
/*  63 */       for (Iterator i = methods.iterator(); i.hasNext();)
/*     */       {
/*  65 */         m = (Method)i.next();
/*     */         
/*  67 */         Class[] params = m.getParameterTypes();
/*  68 */         if (isCongruent(params, args))
/*     */         {
/*  70 */           if ((foundm == null) || (Compiler.subsumes(params, foundm.getParameterTypes())))
/*     */           {
/*  72 */             foundm = m;
/*  73 */             boxedArgs = boxArgs(params, args);
/*     */           }
/*     */         }
/*     */       }
/*  77 */       m = foundm;
/*     */     }
/*  79 */     if (m == null) {
/*  80 */       throw new IllegalArgumentException(noMethodReport(methodName, target));
/*     */     }
/*  82 */     if (!Modifier.isPublic(m.getDeclaringClass().getModifiers()))
/*     */     {
/*     */ 
/*  85 */       Method oldm = m;
/*  86 */       m = getAsMethodOfPublicBase(target.getClass(), m);
/*  87 */       if (m == null) {
/*  88 */         throw new IllegalArgumentException("Can't call public method of non-public class: " + oldm.toString());
/*     */       }
/*     */     }
/*     */     try
/*     */     {
/*  93 */       return prepRet(m.getReturnType(), m.invoke(target, boxedArgs));
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*  97 */       throw Util.sneakyThrow(getCauseOrElse(e));
/*     */     }
/*     */   }
/*     */   
/*     */   public static Method getAsMethodOfPublicBase(Class c, Method m)
/*     */   {
/* 103 */     for (Class iface : c.getInterfaces())
/*     */     {
/* 105 */       for (Method im : iface.getMethods())
/*     */       {
/* 107 */         if (isMatch(im, m))
/*     */         {
/* 109 */           return im;
/*     */         }
/*     */       }
/*     */     }
/* 113 */     Class sc = c.getSuperclass();
/* 114 */     if (sc == null)
/* 115 */       return null;
/* 116 */     for (Method scm : sc.getMethods())
/*     */     {
/* 118 */       if (isMatch(scm, m))
/*     */       {
/* 120 */         return scm;
/*     */       }
/*     */     }
/* 123 */     return getAsMethodOfPublicBase(sc, m);
/*     */   }
/*     */   
/*     */   public static boolean isMatch(Method lhs, Method rhs) {
/* 127 */     if ((!lhs.getName().equals(rhs.getName())) || (!Modifier.isPublic(lhs.getDeclaringClass().getModifiers())))
/*     */     {
/*     */ 
/* 130 */       return false;
/*     */     }
/*     */     
/* 133 */     Class[] types1 = lhs.getParameterTypes();
/* 134 */     Class[] types2 = rhs.getParameterTypes();
/* 135 */     if (types1.length != types2.length) {
/* 136 */       return false;
/*     */     }
/* 138 */     boolean match = true;
/* 139 */     for (int i = 0; i < types1.length; i++)
/*     */     {
/* 141 */       if (!types1[i].isAssignableFrom(types2[i]))
/*     */       {
/* 143 */         match = false;
/* 144 */         break;
/*     */       }
/*     */     }
/* 147 */     return match;
/*     */   }
/*     */   
/*     */   public static Object invokeConstructor(Class c, Object[] args)
/*     */   {
/*     */     try {
/* 153 */       Constructor[] allctors = c.getConstructors();
/* 154 */       ArrayList ctors = new ArrayList();
/* 155 */       for (int i = 0; i < allctors.length; i++)
/*     */       {
/* 157 */         Constructor ctor = allctors[i];
/* 158 */         if (ctor.getParameterTypes().length == args.length)
/* 159 */           ctors.add(ctor);
/*     */       }
/* 161 */       if (ctors.isEmpty())
/*     */       {
/* 163 */         throw new IllegalArgumentException("No matching ctor found for " + c);
/*     */       }
/*     */       
/* 166 */       if (ctors.size() == 1)
/*     */       {
/* 168 */         Constructor ctor = (Constructor)ctors.get(0);
/* 169 */         return ctor.newInstance(boxArgs(ctor.getParameterTypes(), args));
/*     */       }
/*     */       
/*     */ 
/* 173 */       for (Iterator iterator = ctors.iterator(); iterator.hasNext();)
/*     */       {
/* 175 */         Constructor ctor = (Constructor)iterator.next();
/* 176 */         Class[] params = ctor.getParameterTypes();
/* 177 */         if (isCongruent(params, args))
/*     */         {
/* 179 */           Object[] boxedArgs = boxArgs(params, args);
/* 180 */           return ctor.newInstance(boxedArgs);
/*     */         }
/*     */       }
/* 183 */       throw new IllegalArgumentException("No matching ctor found for " + c);
/*     */ 
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */ 
/* 189 */       throw Util.sneakyThrow(getCauseOrElse(e));
/*     */     }
/*     */   }
/*     */   
/*     */   public static Object invokeStaticMethodVariadic(String className, String methodName, Object... args) {
/* 194 */     return invokeStaticMethod(className, methodName, args);
/*     */   }
/*     */   
/*     */   public static Object invokeStaticMethod(String className, String methodName, Object[] args)
/*     */   {
/* 199 */     Class c = RT.classForName(className);
/* 200 */     return invokeStaticMethod(c, methodName, args);
/*     */   }
/*     */   
/*     */   public static Object invokeStaticMethod(Class c, String methodName, Object[] args) {
/* 204 */     if (methodName.equals("new"))
/* 205 */       return invokeConstructor(c, args);
/* 206 */     List methods = getMethods(c, args.length, methodName, true);
/* 207 */     return invokeMatchingMethod(methodName, methods, null, args);
/*     */   }
/*     */   
/*     */   public static Object getStaticField(String className, String fieldName) {
/* 211 */     Class c = RT.classForName(className);
/* 212 */     return getStaticField(c, fieldName);
/*     */   }
/*     */   
/*     */ 
/*     */   public static Object getStaticField(Class c, String fieldName)
/*     */   {
/* 218 */     Field f = getField(c, fieldName, true);
/* 219 */     if (f != null)
/*     */     {
/*     */       try
/*     */       {
/* 223 */         return prepRet(f.getType(), f.get(null));
/*     */       }
/*     */       catch (IllegalAccessException e)
/*     */       {
/* 227 */         throw Util.sneakyThrow(e);
/*     */       }
/*     */     }
/* 230 */     throw new IllegalArgumentException("No matching field found: " + fieldName + " for " + c);
/*     */   }
/*     */   
/*     */   public static Object setStaticField(String className, String fieldName, Object val)
/*     */   {
/* 235 */     Class c = RT.classForName(className);
/* 236 */     return setStaticField(c, fieldName, val);
/*     */   }
/*     */   
/*     */   public static Object setStaticField(Class c, String fieldName, Object val) {
/* 240 */     Field f = getField(c, fieldName, true);
/* 241 */     if (f != null)
/*     */     {
/*     */       try
/*     */       {
/* 245 */         f.set(null, boxArg(f.getType(), val));
/*     */       }
/*     */       catch (IllegalAccessException e)
/*     */       {
/* 249 */         throw Util.sneakyThrow(e);
/*     */       }
/* 251 */       return val;
/*     */     }
/* 253 */     throw new IllegalArgumentException("No matching field found: " + fieldName + " for " + c);
/*     */   }
/*     */   
/*     */   public static Object getInstanceField(Object target, String fieldName)
/*     */   {
/* 258 */     Class c = target.getClass();
/* 259 */     Field f = getField(c, fieldName, false);
/* 260 */     if (f != null)
/*     */     {
/*     */       try
/*     */       {
/* 264 */         return prepRet(f.getType(), f.get(target));
/*     */       }
/*     */       catch (IllegalAccessException e)
/*     */       {
/* 268 */         throw Util.sneakyThrow(e);
/*     */       }
/*     */     }
/* 271 */     throw new IllegalArgumentException("No matching field found: " + fieldName + " for " + target.getClass());
/*     */   }
/*     */   
/*     */   public static Object setInstanceField(Object target, String fieldName, Object val)
/*     */   {
/* 276 */     Class c = target.getClass();
/* 277 */     Field f = getField(c, fieldName, false);
/* 278 */     if (f != null)
/*     */     {
/*     */       try
/*     */       {
/* 282 */         f.set(target, boxArg(f.getType(), val));
/*     */       }
/*     */       catch (IllegalAccessException e)
/*     */       {
/* 286 */         throw Util.sneakyThrow(e);
/*     */       }
/* 288 */       return val;
/*     */     }
/* 290 */     throw new IllegalArgumentException("No matching field found: " + fieldName + " for " + target.getClass());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static Object invokeNoArgInstanceMember(Object target, String name)
/*     */   {
/* 297 */     return invokeNoArgInstanceMember(target, name, false);
/*     */   }
/*     */   
/*     */   public static Object invokeNoArgInstanceMember(Object target, String name, boolean requireField) {
/* 301 */     Class c = target.getClass();
/*     */     
/* 303 */     if (requireField) {
/* 304 */       Field f = getField(c, name, false);
/* 305 */       if (f != null) {
/* 306 */         return getInstanceField(target, name);
/*     */       }
/* 308 */       throw new IllegalArgumentException("No matching field found: " + name + " for " + target.getClass());
/*     */     }
/*     */     
/* 311 */     List meths = getMethods(c, 0, name, false);
/* 312 */     if (meths.size() > 0) {
/* 313 */       return invokeMatchingMethod(name, meths, target, RT.EMPTY_ARRAY);
/*     */     }
/* 315 */     return getInstanceField(target, name);
/*     */   }
/*     */   
/*     */ 
/*     */   public static Object invokeInstanceMember(Object target, String name)
/*     */   {
/* 321 */     Class c = target.getClass();
/* 322 */     Field f = getField(c, name, false);
/* 323 */     if (f != null)
/*     */     {
/*     */       try
/*     */       {
/* 327 */         return prepRet(f.getType(), f.get(target));
/*     */       }
/*     */       catch (IllegalAccessException e)
/*     */       {
/* 331 */         throw Util.sneakyThrow(e);
/*     */       }
/*     */     }
/* 334 */     return invokeInstanceMethod(target, name, RT.EMPTY_ARRAY);
/*     */   }
/*     */   
/*     */   public static Object invokeInstanceMember(String name, Object target, Object arg1)
/*     */   {
/* 339 */     Class c = target.getClass();
/* 340 */     Field f = getField(c, name, false);
/* 341 */     if (f != null)
/*     */     {
/*     */       try
/*     */       {
/* 345 */         f.set(target, boxArg(f.getType(), arg1));
/*     */       }
/*     */       catch (IllegalAccessException e)
/*     */       {
/* 349 */         throw Util.sneakyThrow(e);
/*     */       }
/* 351 */       return arg1;
/*     */     }
/* 353 */     return invokeInstanceMethod(target, name, new Object[] { arg1 });
/*     */   }
/*     */   
/*     */   public static Object invokeInstanceMember(String name, Object target, Object... args) {
/* 357 */     return invokeInstanceMethod(target, name, args);
/*     */   }
/*     */   
/*     */   public static Field getField(Class c, String name, boolean getStatics)
/*     */   {
/* 362 */     Field[] allfields = c.getFields();
/* 363 */     for (int i = 0; i < allfields.length; i++)
/*     */     {
/* 365 */       if ((name.equals(allfields[i].getName())) && (Modifier.isStatic(allfields[i].getModifiers()) == getStatics))
/*     */       {
/* 367 */         return allfields[i]; }
/*     */     }
/* 369 */     return null;
/*     */   }
/*     */   
/*     */   public static List getMethods(Class c, int arity, String name, boolean getStatics) {
/* 373 */     Method[] allmethods = c.getMethods();
/* 374 */     ArrayList methods = new ArrayList();
/* 375 */     ArrayList bridgeMethods = new ArrayList();
/* 376 */     for (int i = 0; i < allmethods.length; i++)
/*     */     {
/* 378 */       Method method = allmethods[i];
/* 379 */       if ((name.equals(method.getName())) && (Modifier.isStatic(method.getModifiers()) == getStatics) && (method.getParameterTypes().length == arity))
/*     */       {
/*     */ 
/*     */         try
/*     */         {
/*     */ 
/* 385 */           if ((method.isBridge()) && (c.getMethod(method.getName(), method.getParameterTypes()).equals(method)))
/*     */           {
/*     */ 
/* 388 */             bridgeMethods.add(method);
/*     */           } else {
/* 390 */             methods.add(method);
/*     */           }
/*     */         }
/*     */         catch (NoSuchMethodException e) {}
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 405 */     if (methods.isEmpty()) {
/* 406 */       methods.addAll(bridgeMethods);
/*     */     }
/* 408 */     if ((!getStatics) && (c.isInterface()))
/*     */     {
/* 410 */       allmethods = Object.class.getMethods();
/* 411 */       for (int i = 0; i < allmethods.length; i++)
/*     */       {
/* 413 */         if ((name.equals(allmethods[i].getName())) && (Modifier.isStatic(allmethods[i].getModifiers()) == getStatics) && (allmethods[i].getParameterTypes().length == arity))
/*     */         {
/*     */ 
/*     */ 
/* 417 */           methods.add(allmethods[i]);
/*     */         }
/*     */       }
/*     */     }
/* 421 */     return methods;
/*     */   }
/*     */   
/*     */   static Object boxArg(Class paramType, Object arg)
/*     */   {
/* 426 */     if (!paramType.isPrimitive())
/* 427 */       return paramType.cast(arg);
/* 428 */     if (paramType == Boolean.TYPE)
/* 429 */       return Boolean.class.cast(arg);
/* 430 */     if (paramType == Character.TYPE)
/* 431 */       return Character.class.cast(arg);
/* 432 */     if ((arg instanceof Number))
/*     */     {
/* 434 */       Number n = (Number)arg;
/* 435 */       if (paramType == Integer.TYPE)
/* 436 */         return Integer.valueOf(n.intValue());
/* 437 */       if (paramType == Float.TYPE)
/* 438 */         return Float.valueOf(n.floatValue());
/* 439 */       if (paramType == Double.TYPE)
/* 440 */         return Double.valueOf(n.doubleValue());
/* 441 */       if (paramType == Long.TYPE)
/* 442 */         return Long.valueOf(n.longValue());
/* 443 */       if (paramType == Short.TYPE)
/* 444 */         return Short.valueOf(n.shortValue());
/* 445 */       if (paramType == Byte.TYPE)
/* 446 */         return Byte.valueOf(n.byteValue());
/*     */     }
/* 448 */     throw new IllegalArgumentException("Unexpected param type, expected: " + paramType + ", given: " + arg.getClass().getName());
/*     */   }
/*     */   
/*     */   static Object[] boxArgs(Class[] params, Object[] args)
/*     */   {
/* 453 */     if (params.length == 0)
/* 454 */       return null;
/* 455 */     Object[] ret = new Object[params.length];
/* 456 */     for (int i = 0; i < params.length; i++)
/*     */     {
/* 458 */       Object arg = args[i];
/* 459 */       Class paramType = params[i];
/* 460 */       ret[i] = boxArg(paramType, arg);
/*     */     }
/* 462 */     return ret;
/*     */   }
/*     */   
/*     */   public static boolean paramArgTypeMatch(Class paramType, Class argType) {
/* 466 */     if (argType == null)
/* 467 */       return !paramType.isPrimitive();
/* 468 */     if ((paramType == argType) || (paramType.isAssignableFrom(argType)))
/* 469 */       return true;
/* 470 */     if (paramType == Integer.TYPE) {
/* 471 */       return (argType == Integer.class) || (argType == Long.TYPE) || (argType == Long.class) || (argType == Short.TYPE) || (argType == Byte.TYPE);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 476 */     if (paramType == Float.TYPE) {
/* 477 */       return (argType == Float.class) || (argType == Double.TYPE);
/*     */     }
/* 479 */     if (paramType == Double.TYPE) {
/* 480 */       return (argType == Double.class) || (argType == Float.TYPE);
/*     */     }
/* 482 */     if (paramType == Long.TYPE) {
/* 483 */       return (argType == Long.class) || (argType == Integer.TYPE) || (argType == Short.TYPE) || (argType == Byte.TYPE);
/*     */     }
/*     */     
/*     */ 
/* 487 */     if (paramType == Character.TYPE)
/* 488 */       return argType == Character.class;
/* 489 */     if (paramType == Short.TYPE)
/* 490 */       return argType == Short.class;
/* 491 */     if (paramType == Byte.TYPE)
/* 492 */       return argType == Byte.class;
/* 493 */     if (paramType == Boolean.TYPE)
/* 494 */       return argType == Boolean.class;
/* 495 */     return false;
/*     */   }
/*     */   
/*     */   static boolean isCongruent(Class[] params, Object[] args) {
/* 499 */     boolean ret = false;
/* 500 */     if (args == null)
/* 501 */       return params.length == 0;
/* 502 */     if (params.length == args.length)
/*     */     {
/* 504 */       ret = true;
/* 505 */       for (int i = 0; (ret) && (i < params.length); i++)
/*     */       {
/* 507 */         Object arg = args[i];
/* 508 */         Class argType = arg == null ? null : arg.getClass();
/* 509 */         Class paramType = params[i];
/* 510 */         ret = paramArgTypeMatch(paramType, argType);
/*     */       }
/*     */     }
/* 513 */     return ret;
/*     */   }
/*     */   
/*     */   public static Object prepRet(Class c, Object x) {
/* 517 */     if ((!c.isPrimitive()) && (c != Boolean.class))
/* 518 */       return x;
/* 519 */     if ((x instanceof Boolean)) {
/* 520 */       return ((Boolean)x).booleanValue() ? Boolean.TRUE : Boolean.FALSE;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 527 */     return x;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\Reflector.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */