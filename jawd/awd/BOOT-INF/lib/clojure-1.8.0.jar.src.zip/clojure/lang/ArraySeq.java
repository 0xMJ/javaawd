/*     */ package clojure.lang;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ArraySeq
/*     */   extends ASeq
/*     */   implements IndexedSeq, IReduce
/*     */ {
/*     */   public final Object[] array;
/*     */   final int i;
/*     */   
/*     */   public static ArraySeq create()
/*     */   {
/*  23 */     return null;
/*     */   }
/*     */   
/*     */   public static ArraySeq create(Object... array) {
/*  27 */     if ((array == null) || (array.length == 0))
/*  28 */       return null;
/*  29 */     return new ArraySeq(array, 0);
/*     */   }
/*     */   
/*     */   static ISeq createFromObject(Object array) {
/*  33 */     if ((array == null) || (Array.getLength(array) == 0))
/*  34 */       return null;
/*  35 */     Class aclass = array.getClass();
/*  36 */     if (aclass == int[].class)
/*  37 */       return new ArraySeq_int(null, (int[])array, 0);
/*  38 */     if (aclass == float[].class)
/*  39 */       return new ArraySeq_float(null, (float[])array, 0);
/*  40 */     if (aclass == double[].class)
/*  41 */       return new ArraySeq_double(null, (double[])array, 0);
/*  42 */     if (aclass == long[].class)
/*  43 */       return new ArraySeq_long(null, (long[])array, 0);
/*  44 */     if (aclass == byte[].class)
/*  45 */       return new ArraySeq_byte(null, (byte[])array, 0);
/*  46 */     if (aclass == char[].class)
/*  47 */       return new ArraySeq_char(null, (char[])array, 0);
/*  48 */     if (aclass == short[].class)
/*  49 */       return new ArraySeq_short(null, (short[])array, 0);
/*  50 */     if (aclass == boolean[].class)
/*  51 */       return new ArraySeq_boolean(null, (boolean[])array, 0);
/*  52 */     return new ArraySeq(array, 0);
/*     */   }
/*     */   
/*     */   ArraySeq(Object array, int i) {
/*  56 */     this.i = i;
/*  57 */     this.array = ((Object[])array);
/*     */   }
/*     */   
/*     */   ArraySeq(IPersistentMap meta, Object array, int i)
/*     */   {
/*  62 */     super(meta);
/*  63 */     this.i = i;
/*  64 */     this.array = ((Object[])array);
/*     */   }
/*     */   
/*     */   public Object first() {
/*  68 */     if (this.array != null)
/*  69 */       return this.array[this.i];
/*  70 */     return null;
/*     */   }
/*     */   
/*     */   public ISeq next() {
/*  74 */     if ((this.array != null) && (this.i + 1 < this.array.length))
/*  75 */       return new ArraySeq(this.array, this.i + 1);
/*  76 */     return null;
/*     */   }
/*     */   
/*     */   public int count() {
/*  80 */     if (this.array != null)
/*  81 */       return this.array.length - this.i;
/*  82 */     return 0;
/*     */   }
/*     */   
/*     */   public int index() {
/*  86 */     return this.i;
/*     */   }
/*     */   
/*     */   public ArraySeq withMeta(IPersistentMap meta) {
/*  90 */     return new ArraySeq(meta, this.array, this.i);
/*     */   }
/*     */   
/*     */   public Object reduce(IFn f) {
/*  94 */     if (this.array != null) {
/*  95 */       Object ret = this.array[this.i];
/*  96 */       for (int x = this.i + 1; x < this.array.length; x++)
/*     */       {
/*  98 */         ret = f.invoke(ret, this.array[x]);
/*  99 */         if (RT.isReduced(ret))
/* 100 */           return ((IDeref)ret).deref();
/*     */       }
/* 102 */       return ret;
/*     */     }
/* 104 */     return null;
/*     */   }
/*     */   
/*     */   public Object reduce(IFn f, Object start) {
/* 108 */     if (this.array != null) {
/* 109 */       Object ret = f.invoke(start, this.array[this.i]);
/* 110 */       for (int x = this.i + 1; x < this.array.length; x++)
/*     */       {
/* 112 */         if (RT.isReduced(ret))
/* 113 */           return ((IDeref)ret).deref();
/* 114 */         ret = f.invoke(ret, this.array[x]);
/*     */       }
/* 116 */       if (RT.isReduced(ret))
/* 117 */         return ((IDeref)ret).deref();
/* 118 */       return ret;
/*     */     }
/* 120 */     return null;
/*     */   }
/*     */   
/*     */   public int indexOf(Object o) {
/* 124 */     if (this.array != null)
/* 125 */       for (int j = this.i; j < this.array.length; j++)
/* 126 */         if (Util.equals(o, this.array[j])) return j - this.i;
/* 127 */     return -1;
/*     */   }
/*     */   
/*     */   public int lastIndexOf(Object o) {
/* 131 */     if (this.array != null) {
/* 132 */       if (o == null) {
/* 133 */         for (int j = this.array.length - 1; j >= this.i; j--)
/* 134 */           if (this.array[j] == null) return j - this.i;
/*     */       } else {
/* 136 */         for (int j = this.array.length - 1; j >= this.i; j--)
/* 137 */           if (o.equals(this.array[j])) return j - this.i;
/*     */       }
/*     */     }
/* 140 */     return -1;
/*     */   }
/*     */   
/*     */   public static class ArraySeq_int extends ASeq implements IndexedSeq, IReduce
/*     */   {
/*     */     public final int[] array;
/*     */     final int i;
/*     */     
/*     */     ArraySeq_int(IPersistentMap meta, int[] array, int i)
/*     */     {
/* 150 */       super();
/* 151 */       this.array = array;
/* 152 */       this.i = i;
/*     */     }
/*     */     
/*     */     public Object first() {
/* 156 */       return Integer.valueOf(this.array[this.i]);
/*     */     }
/*     */     
/*     */     public ISeq next() {
/* 160 */       if (this.i + 1 < this.array.length)
/* 161 */         return new ArraySeq_int(meta(), this.array, this.i + 1);
/* 162 */       return null;
/*     */     }
/*     */     
/*     */     public int count() {
/* 166 */       return this.array.length - this.i;
/*     */     }
/*     */     
/*     */     public int index() {
/* 170 */       return this.i;
/*     */     }
/*     */     
/*     */     public ArraySeq_int withMeta(IPersistentMap meta) {
/* 174 */       return new ArraySeq_int(meta, this.array, this.i);
/*     */     }
/*     */     
/*     */     public Object reduce(IFn f) {
/* 178 */       Object ret = Integer.valueOf(this.array[this.i]);
/* 179 */       for (int x = this.i + 1; x < this.array.length; x++)
/*     */       {
/* 181 */         ret = f.invoke(ret, Integer.valueOf(this.array[x]));
/* 182 */         if (RT.isReduced(ret))
/* 183 */           return ((IDeref)ret).deref();
/*     */       }
/* 185 */       return ret;
/*     */     }
/*     */     
/*     */     public Object reduce(IFn f, Object start) {
/* 189 */       Object ret = f.invoke(start, Integer.valueOf(this.array[this.i]));
/* 190 */       for (int x = this.i + 1; x < this.array.length; x++)
/*     */       {
/* 192 */         if (RT.isReduced(ret))
/* 193 */           return ((IDeref)ret).deref();
/* 194 */         ret = f.invoke(ret, Integer.valueOf(this.array[x]));
/*     */       }
/* 196 */       if (RT.isReduced(ret))
/* 197 */         return ((IDeref)ret).deref();
/* 198 */       return ret;
/*     */     }
/*     */     
/*     */     public int indexOf(Object o) {
/* 202 */       if ((o instanceof Number)) {
/* 203 */         int k = ((Number)o).intValue();
/* 204 */         for (int j = this.i; j < this.array.length; j++) {
/* 205 */           if (k == this.array[j]) return j - this.i;
/*     */         }
/*     */       }
/* 208 */       return -1;
/*     */     }
/*     */     
/*     */     public int lastIndexOf(Object o) {
/* 212 */       if ((o instanceof Number)) {
/* 213 */         int k = ((Number)o).intValue();
/* 214 */         for (int j = this.array.length - 1; j >= this.i; j--) {
/* 215 */           if (k == this.array[j]) return j - this.i;
/*     */         }
/*     */       }
/* 218 */       return -1;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class ArraySeq_float extends ASeq implements IndexedSeq, IReduce
/*     */   {
/*     */     public final float[] array;
/*     */     final int i;
/*     */     
/*     */     ArraySeq_float(IPersistentMap meta, float[] array, int i) {
/* 228 */       super();
/* 229 */       this.array = array;
/* 230 */       this.i = i;
/*     */     }
/*     */     
/*     */     public Object first() {
/* 234 */       return Numbers.num(this.array[this.i]);
/*     */     }
/*     */     
/*     */     public ISeq next() {
/* 238 */       if (this.i + 1 < this.array.length)
/* 239 */         return new ArraySeq_float(meta(), this.array, this.i + 1);
/* 240 */       return null;
/*     */     }
/*     */     
/*     */     public int count() {
/* 244 */       return this.array.length - this.i;
/*     */     }
/*     */     
/*     */     public int index() {
/* 248 */       return this.i;
/*     */     }
/*     */     
/*     */     public ArraySeq_float withMeta(IPersistentMap meta) {
/* 252 */       return new ArraySeq_float(meta, this.array, this.i);
/*     */     }
/*     */     
/*     */     public Object reduce(IFn f) {
/* 256 */       Object ret = Numbers.num(this.array[this.i]);
/* 257 */       for (int x = this.i + 1; x < this.array.length; x++)
/*     */       {
/* 259 */         ret = f.invoke(ret, Numbers.num(this.array[x]));
/* 260 */         if (RT.isReduced(ret))
/* 261 */           return ((IDeref)ret).deref();
/*     */       }
/* 263 */       return ret;
/*     */     }
/*     */     
/*     */     public Object reduce(IFn f, Object start) {
/* 267 */       Object ret = f.invoke(start, Numbers.num(this.array[this.i]));
/* 268 */       for (int x = this.i + 1; x < this.array.length; x++)
/*     */       {
/* 270 */         if (RT.isReduced(ret))
/* 271 */           return ((IDeref)ret).deref();
/* 272 */         ret = f.invoke(ret, Numbers.num(this.array[x]));
/*     */       }
/* 274 */       if (RT.isReduced(ret))
/* 275 */         return ((IDeref)ret).deref();
/* 276 */       return ret;
/*     */     }
/*     */     
/*     */     public int indexOf(Object o) {
/* 280 */       if ((o instanceof Number)) {
/* 281 */         float f = ((Number)o).floatValue();
/* 282 */         for (int j = this.i; j < this.array.length; j++)
/* 283 */           if (f == this.array[j]) return j - this.i;
/*     */       }
/* 285 */       return -1;
/*     */     }
/*     */     
/*     */     public int lastIndexOf(Object o) {
/* 289 */       if ((o instanceof Number)) {
/* 290 */         float f = ((Number)o).floatValue();
/* 291 */         for (int j = this.array.length - 1; j >= this.i; j--)
/* 292 */           if (f == this.array[j]) return j - this.i;
/*     */       }
/* 294 */       return -1;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class ArraySeq_double extends ASeq implements IndexedSeq, IReduce {
/*     */     public final double[] array;
/*     */     final int i;
/*     */     
/*     */     ArraySeq_double(IPersistentMap meta, double[] array, int i) {
/* 303 */       super();
/* 304 */       this.array = array;
/* 305 */       this.i = i;
/*     */     }
/*     */     
/*     */     public Object first() {
/* 309 */       return Double.valueOf(this.array[this.i]);
/*     */     }
/*     */     
/*     */     public ISeq next() {
/* 313 */       if (this.i + 1 < this.array.length)
/* 314 */         return new ArraySeq_double(meta(), this.array, this.i + 1);
/* 315 */       return null;
/*     */     }
/*     */     
/*     */     public int count() {
/* 319 */       return this.array.length - this.i;
/*     */     }
/*     */     
/*     */     public int index() {
/* 323 */       return this.i;
/*     */     }
/*     */     
/*     */     public ArraySeq_double withMeta(IPersistentMap meta) {
/* 327 */       return new ArraySeq_double(meta, this.array, this.i);
/*     */     }
/*     */     
/*     */     public Object reduce(IFn f) {
/* 331 */       Object ret = Double.valueOf(this.array[this.i]);
/* 332 */       for (int x = this.i + 1; x < this.array.length; x++)
/*     */       {
/* 334 */         ret = f.invoke(ret, Double.valueOf(this.array[x]));
/* 335 */         if (RT.isReduced(ret))
/* 336 */           return ((IDeref)ret).deref();
/*     */       }
/* 338 */       return ret;
/*     */     }
/*     */     
/*     */     public Object reduce(IFn f, Object start) {
/* 342 */       Object ret = f.invoke(start, Double.valueOf(this.array[this.i]));
/* 343 */       for (int x = this.i + 1; x < this.array.length; x++)
/*     */       {
/* 345 */         if (RT.isReduced(ret))
/* 346 */           return ((IDeref)ret).deref();
/* 347 */         ret = f.invoke(ret, Double.valueOf(this.array[x]));
/*     */       }
/* 349 */       if (RT.isReduced(ret))
/* 350 */         return ((IDeref)ret).deref();
/* 351 */       return ret;
/*     */     }
/*     */     
/*     */     public int indexOf(Object o) {
/* 355 */       if ((o instanceof Number)) {
/* 356 */         double d = ((Number)o).doubleValue();
/* 357 */         for (int j = this.i; j < this.array.length; j++) {
/* 358 */           if (d == this.array[j]) return j - this.i;
/*     */         }
/*     */       }
/* 361 */       return -1;
/*     */     }
/*     */     
/*     */     public int lastIndexOf(Object o) {
/* 365 */       if ((o instanceof Number)) {
/* 366 */         double d = ((Number)o).doubleValue();
/* 367 */         for (int j = this.array.length - 1; j >= this.i; j--) {
/* 368 */           if (d == this.array[j]) return j - this.i;
/*     */         }
/*     */       }
/* 371 */       return -1;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class ArraySeq_long extends ASeq implements IndexedSeq, IReduce {
/*     */     public final long[] array;
/*     */     final int i;
/*     */     
/*     */     ArraySeq_long(IPersistentMap meta, long[] array, int i) {
/* 380 */       super();
/* 381 */       this.array = array;
/* 382 */       this.i = i;
/*     */     }
/*     */     
/*     */     public Object first() {
/* 386 */       return Numbers.num(this.array[this.i]);
/*     */     }
/*     */     
/*     */     public ISeq next() {
/* 390 */       if (this.i + 1 < this.array.length)
/* 391 */         return new ArraySeq_long(meta(), this.array, this.i + 1);
/* 392 */       return null;
/*     */     }
/*     */     
/*     */     public int count() {
/* 396 */       return this.array.length - this.i;
/*     */     }
/*     */     
/*     */     public int index() {
/* 400 */       return this.i;
/*     */     }
/*     */     
/*     */     public ArraySeq_long withMeta(IPersistentMap meta) {
/* 404 */       return new ArraySeq_long(meta, this.array, this.i);
/*     */     }
/*     */     
/*     */     public Object reduce(IFn f) {
/* 408 */       Object ret = Numbers.num(this.array[this.i]);
/* 409 */       for (int x = this.i + 1; x < this.array.length; x++)
/*     */       {
/* 411 */         ret = f.invoke(ret, Numbers.num(this.array[x]));
/* 412 */         if (RT.isReduced(ret))
/* 413 */           return ((IDeref)ret).deref();
/*     */       }
/* 415 */       return ret;
/*     */     }
/*     */     
/*     */     public Object reduce(IFn f, Object start) {
/* 419 */       Object ret = f.invoke(start, Numbers.num(this.array[this.i]));
/* 420 */       for (int x = this.i + 1; x < this.array.length; x++)
/*     */       {
/* 422 */         if (RT.isReduced(ret))
/* 423 */           return ((IDeref)ret).deref();
/* 424 */         ret = f.invoke(ret, Numbers.num(this.array[x]));
/*     */       }
/* 426 */       if (RT.isReduced(ret))
/* 427 */         return ((IDeref)ret).deref();
/* 428 */       return ret;
/*     */     }
/*     */     
/*     */     public int indexOf(Object o) {
/* 432 */       if ((o instanceof Number)) {
/* 433 */         long l = ((Number)o).longValue();
/* 434 */         for (int j = this.i; j < this.array.length; j++) {
/* 435 */           if (l == this.array[j]) return j - this.i;
/*     */         }
/*     */       }
/* 438 */       return -1;
/*     */     }
/*     */     
/*     */     public int lastIndexOf(Object o) {
/* 442 */       if ((o instanceof Number)) {
/* 443 */         long l = ((Number)o).longValue();
/* 444 */         for (int j = this.array.length - 1; j >= this.i; j--) {
/* 445 */           if (l == this.array[j]) return j - this.i;
/*     */         }
/*     */       }
/* 448 */       return -1;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class ArraySeq_byte extends ASeq implements IndexedSeq, IReduce {
/*     */     public final byte[] array;
/*     */     final int i;
/*     */     
/*     */     ArraySeq_byte(IPersistentMap meta, byte[] array, int i) {
/* 457 */       super();
/* 458 */       this.array = array;
/* 459 */       this.i = i;
/*     */     }
/*     */     
/*     */     public Object first() {
/* 463 */       return Byte.valueOf(this.array[this.i]);
/*     */     }
/*     */     
/*     */     public ISeq next() {
/* 467 */       if (this.i + 1 < this.array.length)
/* 468 */         return new ArraySeq_byte(meta(), this.array, this.i + 1);
/* 469 */       return null;
/*     */     }
/*     */     
/*     */     public int count() {
/* 473 */       return this.array.length - this.i;
/*     */     }
/*     */     
/*     */     public int index() {
/* 477 */       return this.i;
/*     */     }
/*     */     
/*     */     public ArraySeq_byte withMeta(IPersistentMap meta) {
/* 481 */       return new ArraySeq_byte(meta, this.array, this.i);
/*     */     }
/*     */     
/*     */     public Object reduce(IFn f) {
/* 485 */       Object ret = Byte.valueOf(this.array[this.i]);
/* 486 */       for (int x = this.i + 1; x < this.array.length; x++)
/*     */       {
/* 488 */         ret = f.invoke(ret, Byte.valueOf(this.array[x]));
/* 489 */         if (RT.isReduced(ret))
/* 490 */           return ((IDeref)ret).deref();
/*     */       }
/* 492 */       return ret;
/*     */     }
/*     */     
/*     */     public Object reduce(IFn f, Object start) {
/* 496 */       Object ret = f.invoke(start, Byte.valueOf(this.array[this.i]));
/* 497 */       for (int x = this.i + 1; x < this.array.length; x++)
/*     */       {
/* 499 */         if (RT.isReduced(ret))
/* 500 */           return ((IDeref)ret).deref();
/* 501 */         ret = f.invoke(ret, Byte.valueOf(this.array[x]));
/*     */       }
/* 503 */       if (RT.isReduced(ret))
/* 504 */         return ((IDeref)ret).deref();
/* 505 */       return ret;
/*     */     }
/*     */     
/*     */     public int indexOf(Object o) {
/* 509 */       if ((o instanceof Byte)) {
/* 510 */         byte b = ((Byte)o).byteValue();
/* 511 */         for (int j = this.i; j < this.array.length; j++)
/* 512 */           if (b == this.array[j]) return j - this.i;
/*     */       }
/* 514 */       if (o == null) {
/* 515 */         return -1;
/*     */       }
/* 517 */       for (int j = this.i; j < this.array.length; j++)
/* 518 */         if (o.equals(Byte.valueOf(this.array[j]))) return j - this.i;
/* 519 */       return -1;
/*     */     }
/*     */     
/*     */     public int lastIndexOf(Object o) {
/* 523 */       if ((o instanceof Byte)) {
/* 524 */         byte b = ((Byte)o).byteValue();
/* 525 */         for (int j = this.array.length - 1; j >= this.i; j--)
/* 526 */           if (b == this.array[j]) return j - this.i;
/*     */       }
/* 528 */       if (o == null) {
/* 529 */         return -1;
/*     */       }
/* 531 */       for (int j = this.array.length - 1; j >= this.i; j--)
/* 532 */         if (o.equals(Byte.valueOf(this.array[j]))) return j - this.i;
/* 533 */       return -1;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class ArraySeq_char extends ASeq implements IndexedSeq, IReduce {
/*     */     public final char[] array;
/*     */     final int i;
/*     */     
/*     */     ArraySeq_char(IPersistentMap meta, char[] array, int i) {
/* 542 */       super();
/* 543 */       this.array = array;
/* 544 */       this.i = i;
/*     */     }
/*     */     
/*     */     public Object first() {
/* 548 */       return Character.valueOf(this.array[this.i]);
/*     */     }
/*     */     
/*     */     public ISeq next() {
/* 552 */       if (this.i + 1 < this.array.length)
/* 553 */         return new ArraySeq_char(meta(), this.array, this.i + 1);
/* 554 */       return null;
/*     */     }
/*     */     
/*     */     public int count() {
/* 558 */       return this.array.length - this.i;
/*     */     }
/*     */     
/*     */     public int index() {
/* 562 */       return this.i;
/*     */     }
/*     */     
/*     */     public ArraySeq_char withMeta(IPersistentMap meta) {
/* 566 */       return new ArraySeq_char(meta, this.array, this.i);
/*     */     }
/*     */     
/*     */     public Object reduce(IFn f) {
/* 570 */       Object ret = Character.valueOf(this.array[this.i]);
/* 571 */       for (int x = this.i + 1; x < this.array.length; x++)
/*     */       {
/* 573 */         ret = f.invoke(ret, Character.valueOf(this.array[x]));
/* 574 */         if (RT.isReduced(ret))
/* 575 */           return ((IDeref)ret).deref();
/*     */       }
/* 577 */       return ret;
/*     */     }
/*     */     
/*     */     public Object reduce(IFn f, Object start) {
/* 581 */       Object ret = f.invoke(start, Character.valueOf(this.array[this.i]));
/* 582 */       for (int x = this.i + 1; x < this.array.length; x++)
/*     */       {
/* 584 */         if (RT.isReduced(ret))
/* 585 */           return ((IDeref)ret).deref();
/* 586 */         ret = f.invoke(ret, Character.valueOf(this.array[x]));
/*     */       }
/* 588 */       if (RT.isReduced(ret))
/* 589 */         return ((IDeref)ret).deref();
/* 590 */       return ret;
/*     */     }
/*     */     
/*     */     public int indexOf(Object o) {
/* 594 */       if ((o instanceof Character)) {
/* 595 */         char c = ((Character)o).charValue();
/* 596 */         for (int j = this.i; j < this.array.length; j++)
/* 597 */           if (c == this.array[j]) return j - this.i;
/*     */       }
/* 599 */       if (o == null) {
/* 600 */         return -1;
/*     */       }
/* 602 */       for (int j = this.i; j < this.array.length; j++)
/* 603 */         if (o.equals(Character.valueOf(this.array[j]))) return j - this.i;
/* 604 */       return -1;
/*     */     }
/*     */     
/*     */     public int lastIndexOf(Object o) {
/* 608 */       if ((o instanceof Character)) {
/* 609 */         char c = ((Character)o).charValue();
/* 610 */         for (int j = this.array.length - 1; j >= this.i; j--)
/* 611 */           if (c == this.array[j]) return j - this.i;
/*     */       }
/* 613 */       if (o == null) {
/* 614 */         return -1;
/*     */       }
/* 616 */       for (int j = this.array.length - 1; j >= this.i; j--)
/* 617 */         if (o.equals(Character.valueOf(this.array[j]))) return j - this.i;
/* 618 */       return -1;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class ArraySeq_short extends ASeq implements IndexedSeq, IReduce {
/*     */     public final short[] array;
/*     */     final int i;
/*     */     
/*     */     ArraySeq_short(IPersistentMap meta, short[] array, int i) {
/* 627 */       super();
/* 628 */       this.array = array;
/* 629 */       this.i = i;
/*     */     }
/*     */     
/*     */     public Object first() {
/* 633 */       return Short.valueOf(this.array[this.i]);
/*     */     }
/*     */     
/*     */     public ISeq next() {
/* 637 */       if (this.i + 1 < this.array.length)
/* 638 */         return new ArraySeq_short(meta(), this.array, this.i + 1);
/* 639 */       return null;
/*     */     }
/*     */     
/*     */     public int count() {
/* 643 */       return this.array.length - this.i;
/*     */     }
/*     */     
/*     */     public int index() {
/* 647 */       return this.i;
/*     */     }
/*     */     
/*     */     public ArraySeq_short withMeta(IPersistentMap meta) {
/* 651 */       return new ArraySeq_short(meta, this.array, this.i);
/*     */     }
/*     */     
/*     */     public Object reduce(IFn f) {
/* 655 */       Object ret = Short.valueOf(this.array[this.i]);
/* 656 */       for (int x = this.i + 1; x < this.array.length; x++)
/*     */       {
/* 658 */         ret = f.invoke(ret, Short.valueOf(this.array[x]));
/* 659 */         if (RT.isReduced(ret))
/* 660 */           return ((IDeref)ret).deref();
/*     */       }
/* 662 */       return ret;
/*     */     }
/*     */     
/*     */     public Object reduce(IFn f, Object start) {
/* 666 */       Object ret = f.invoke(start, Short.valueOf(this.array[this.i]));
/* 667 */       for (int x = this.i + 1; x < this.array.length; x++)
/*     */       {
/* 669 */         if (RT.isReduced(ret))
/* 670 */           return ((IDeref)ret).deref();
/* 671 */         ret = f.invoke(ret, Short.valueOf(this.array[x]));
/*     */       }
/* 673 */       if (RT.isReduced(ret))
/* 674 */         return ((IDeref)ret).deref();
/* 675 */       return ret;
/*     */     }
/*     */     
/*     */     public int indexOf(Object o) {
/* 679 */       if ((o instanceof Short)) {
/* 680 */         short s = ((Short)o).shortValue();
/* 681 */         for (int j = this.i; j < this.array.length; j++)
/* 682 */           if (s == this.array[j]) return j - this.i;
/*     */       }
/* 684 */       if (o == null) {
/* 685 */         return -1;
/*     */       }
/* 687 */       for (int j = this.i; j < this.array.length; j++)
/* 688 */         if (o.equals(Short.valueOf(this.array[j]))) return j - this.i;
/* 689 */       return -1;
/*     */     }
/*     */     
/*     */     public int lastIndexOf(Object o) {
/* 693 */       if ((o instanceof Short)) {
/* 694 */         short s = ((Short)o).shortValue();
/* 695 */         for (int j = this.array.length - 1; j >= this.i; j--)
/* 696 */           if (s == this.array[j]) return j - this.i;
/*     */       }
/* 698 */       if (o == null) {
/* 699 */         return -1;
/*     */       }
/* 701 */       for (int j = this.array.length - 1; j >= this.i; j--)
/* 702 */         if (o.equals(Short.valueOf(this.array[j]))) return j - this.i;
/* 703 */       return -1;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class ArraySeq_boolean extends ASeq implements IndexedSeq, IReduce {
/*     */     public final boolean[] array;
/*     */     final int i;
/*     */     
/*     */     ArraySeq_boolean(IPersistentMap meta, boolean[] array, int i) {
/* 712 */       super();
/* 713 */       this.array = array;
/* 714 */       this.i = i;
/*     */     }
/*     */     
/*     */     public Object first() {
/* 718 */       return Boolean.valueOf(this.array[this.i]);
/*     */     }
/*     */     
/*     */     public ISeq next() {
/* 722 */       if (this.i + 1 < this.array.length)
/* 723 */         return new ArraySeq_boolean(meta(), this.array, this.i + 1);
/* 724 */       return null;
/*     */     }
/*     */     
/*     */     public int count() {
/* 728 */       return this.array.length - this.i;
/*     */     }
/*     */     
/*     */     public int index() {
/* 732 */       return this.i;
/*     */     }
/*     */     
/*     */     public ArraySeq_boolean withMeta(IPersistentMap meta) {
/* 736 */       return new ArraySeq_boolean(meta, this.array, this.i);
/*     */     }
/*     */     
/*     */     public Object reduce(IFn f) {
/* 740 */       Object ret = Boolean.valueOf(this.array[this.i]);
/* 741 */       for (int x = this.i + 1; x < this.array.length; x++)
/*     */       {
/* 743 */         ret = f.invoke(ret, Boolean.valueOf(this.array[x]));
/* 744 */         if (RT.isReduced(ret))
/* 745 */           return ((IDeref)ret).deref();
/*     */       }
/* 747 */       return ret;
/*     */     }
/*     */     
/*     */     public Object reduce(IFn f, Object start) {
/* 751 */       Object ret = f.invoke(start, Boolean.valueOf(this.array[this.i]));
/* 752 */       for (int x = this.i + 1; x < this.array.length; x++)
/*     */       {
/* 754 */         if (RT.isReduced(ret))
/* 755 */           return ((IDeref)ret).deref();
/* 756 */         ret = f.invoke(ret, Boolean.valueOf(this.array[x]));
/*     */       }
/* 758 */       if (RT.isReduced(ret))
/* 759 */         return ((IDeref)ret).deref();
/* 760 */       return ret;
/*     */     }
/*     */     
/*     */     public int indexOf(Object o) {
/* 764 */       if ((o instanceof Boolean)) {
/* 765 */         boolean b = ((Boolean)o).booleanValue();
/* 766 */         for (int j = this.i; j < this.array.length; j++)
/* 767 */           if (b == this.array[j]) return j - this.i;
/*     */       }
/* 769 */       if (o == null) {
/* 770 */         return -1;
/*     */       }
/* 772 */       for (int j = this.i; j < this.array.length; j++)
/* 773 */         if (o.equals(Boolean.valueOf(this.array[j]))) return j - this.i;
/* 774 */       return -1;
/*     */     }
/*     */     
/*     */     public int lastIndexOf(Object o) {
/* 778 */       if ((o instanceof Boolean)) {
/* 779 */         boolean b = ((Boolean)o).booleanValue();
/* 780 */         for (int j = this.array.length - 1; j >= this.i; j--)
/* 781 */           if (b == this.array[j]) return j - this.i;
/*     */       }
/* 783 */       if (o == null) {
/* 784 */         return -1;
/*     */       }
/* 786 */       for (int j = this.array.length - 1; j >= this.i; j--)
/* 787 */         if (o.equals(Boolean.valueOf(this.array[j]))) return j - this.i;
/* 788 */       return -1;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\ArraySeq.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */