package clojure.lang;

public abstract interface ITransientMap
  extends ITransientAssociative, Counted
{
  public abstract ITransientMap assoc(Object paramObject1, Object paramObject2);
  
  public abstract ITransientMap without(Object paramObject);
  
  public abstract IPersistentMap persistent();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\ITransientMap.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */