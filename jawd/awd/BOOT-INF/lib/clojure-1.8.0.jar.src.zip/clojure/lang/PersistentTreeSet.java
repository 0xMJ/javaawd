/*    */ package clojure.lang;
/*    */ 
/*    */ import java.util.Comparator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PersistentTreeSet
/*    */   extends APersistentSet
/*    */   implements IObj, Reversible, Sorted
/*    */ {
/* 18 */   public static final PersistentTreeSet EMPTY = new PersistentTreeSet(null, PersistentTreeMap.EMPTY);
/*    */   final IPersistentMap _meta;
/*    */   
/*    */   public static PersistentTreeSet create(ISeq items)
/*    */   {
/* 23 */     PersistentTreeSet ret = EMPTY;
/* 24 */     for (; items != null; items = items.next())
/*    */     {
/* 26 */       ret = (PersistentTreeSet)ret.cons(items.first());
/*    */     }
/* 28 */     return ret;
/*    */   }
/*    */   
/*    */   public static PersistentTreeSet create(Comparator comp, ISeq items) {
/* 32 */     PersistentTreeSet ret = new PersistentTreeSet(null, new PersistentTreeMap(null, comp));
/* 33 */     for (; items != null; items = items.next())
/*    */     {
/* 35 */       ret = (PersistentTreeSet)ret.cons(items.first());
/*    */     }
/* 37 */     return ret;
/*    */   }
/*    */   
/*    */   PersistentTreeSet(IPersistentMap meta, IPersistentMap impl) {
/* 41 */     super(impl);
/* 42 */     this._meta = meta;
/*    */   }
/*    */   
/*    */   public IPersistentSet disjoin(Object key) {
/* 46 */     if (contains(key))
/* 47 */       return new PersistentTreeSet(meta(), this.impl.without(key));
/* 48 */     return this;
/*    */   }
/*    */   
/*    */   public IPersistentSet cons(Object o) {
/* 52 */     if (contains(o))
/* 53 */       return this;
/* 54 */     return new PersistentTreeSet(meta(), this.impl.assoc(o, o));
/*    */   }
/*    */   
/*    */   public IPersistentCollection empty() {
/* 58 */     return new PersistentTreeSet(meta(), (PersistentTreeMap)this.impl.empty());
/*    */   }
/*    */   
/*    */   public ISeq rseq() {
/* 62 */     return APersistentMap.KeySeq.create(((Reversible)this.impl).rseq());
/*    */   }
/*    */   
/*    */   public PersistentTreeSet withMeta(IPersistentMap meta) {
/* 66 */     return new PersistentTreeSet(meta, this.impl);
/*    */   }
/*    */   
/*    */   public Comparator comparator() {
/* 70 */     return ((Sorted)this.impl).comparator();
/*    */   }
/*    */   
/*    */   public Object entryKey(Object entry) {
/* 74 */     return entry;
/*    */   }
/*    */   
/*    */   public ISeq seq(boolean ascending) {
/* 78 */     PersistentTreeMap m = (PersistentTreeMap)this.impl;
/* 79 */     return RT.keys(m.seq(ascending));
/*    */   }
/*    */   
/*    */   public ISeq seqFrom(Object key, boolean ascending) {
/* 83 */     PersistentTreeMap m = (PersistentTreeMap)this.impl;
/* 84 */     return RT.keys(m.seqFrom(key, ascending));
/*    */   }
/*    */   
/*    */   public IPersistentMap meta() {
/* 88 */     return this._meta;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\PersistentTreeSet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */