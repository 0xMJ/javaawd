/*    */ package clojure.lang;
/*    */ 
/*    */ import java.util.Map.Entry;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ATransientMap
/*    */   extends AFn
/*    */   implements ITransientMap
/*    */ {
/*    */   abstract void ensureEditable();
/*    */   
/*    */   abstract ITransientMap doAssoc(Object paramObject1, Object paramObject2);
/*    */   
/*    */   abstract ITransientMap doWithout(Object paramObject);
/*    */   
/*    */   abstract Object doValAt(Object paramObject1, Object paramObject2);
/*    */   
/*    */   abstract int doCount();
/*    */   
/*    */   abstract IPersistentMap doPersistent();
/*    */   
/*    */   public ITransientMap conj(Object o)
/*    */   {
/* 26 */     ensureEditable();
/* 27 */     if ((o instanceof Map.Entry))
/*    */     {
/* 29 */       Map.Entry e = (Map.Entry)o;
/*    */       
/* 31 */       return assoc(e.getKey(), e.getValue());
/*    */     }
/* 33 */     if ((o instanceof IPersistentVector))
/*    */     {
/* 35 */       IPersistentVector v = (IPersistentVector)o;
/* 36 */       if (v.count() != 2)
/* 37 */         throw new IllegalArgumentException("Vector arg to map conj must be a pair");
/* 38 */       return assoc(v.nth(0), v.nth(1));
/*    */     }
/*    */     
/* 41 */     ITransientMap ret = this;
/* 42 */     for (ISeq es = RT.seq(o); es != null; es = es.next())
/*    */     {
/* 44 */       Map.Entry e = (Map.Entry)es.first();
/* 45 */       ret = ret.assoc(e.getKey(), e.getValue());
/*    */     }
/* 47 */     return ret;
/*    */   }
/*    */   
/*    */   public final Object invoke(Object arg1) {
/* 51 */     return valAt(arg1);
/*    */   }
/*    */   
/*    */   public final Object invoke(Object arg1, Object notFound) {
/* 55 */     return valAt(arg1, notFound);
/*    */   }
/*    */   
/*    */   public final Object valAt(Object key) {
/* 59 */     return valAt(key, null);
/*    */   }
/*    */   
/*    */   public final ITransientMap assoc(Object key, Object val) {
/* 63 */     ensureEditable();
/* 64 */     return doAssoc(key, val);
/*    */   }
/*    */   
/*    */   public final ITransientMap without(Object key) {
/* 68 */     ensureEditable();
/* 69 */     return doWithout(key);
/*    */   }
/*    */   
/*    */   public final IPersistentMap persistent() {
/* 73 */     ensureEditable();
/* 74 */     return doPersistent();
/*    */   }
/*    */   
/*    */   public final Object valAt(Object key, Object notFound) {
/* 78 */     ensureEditable();
/* 79 */     return doValAt(key, notFound);
/*    */   }
/*    */   
/*    */   public final int count() {
/* 83 */     ensureEditable();
/* 84 */     return doCount();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\ATransientMap.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */