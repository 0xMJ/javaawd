/*     */ package clojure.lang;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.NoSuchElementException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PersistentQueue
/*     */   extends Obj
/*     */   implements IPersistentList, Collection, Counted, IHashEq
/*     */ {
/*  27 */   public static final PersistentQueue EMPTY = new PersistentQueue(null, 0, null, null);
/*     */   
/*     */   final int cnt;
/*     */   
/*     */   final ISeq f;
/*     */   
/*     */   final PersistentVector r;
/*  34 */   int _hash = -1;
/*  35 */   int _hasheq = -1;
/*     */   
/*     */   PersistentQueue(IPersistentMap meta, int cnt, ISeq f, PersistentVector r) {
/*  38 */     super(meta);
/*  39 */     this.cnt = cnt;
/*  40 */     this.f = f;
/*  41 */     this.r = r;
/*     */   }
/*     */   
/*     */   public boolean equiv(Object obj)
/*     */   {
/*  46 */     if (!(obj instanceof Sequential))
/*  47 */       return false;
/*  48 */     ISeq ms = RT.seq(obj);
/*  49 */     for (ISeq s = seq(); s != null; ms = ms.next())
/*     */     {
/*  51 */       if ((ms == null) || (!Util.equiv(s.first(), ms.first()))) {
/*  52 */         return false;
/*     */       }
/*  49 */       s = s.next();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  54 */     return ms == null;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/*  60 */     if (!(obj instanceof Sequential))
/*  61 */       return false;
/*  62 */     ISeq ms = RT.seq(obj);
/*  63 */     for (ISeq s = seq(); s != null; ms = ms.next())
/*     */     {
/*  65 */       if ((ms == null) || (!Util.equals(s.first(), ms.first()))) {
/*  66 */         return false;
/*     */       }
/*  63 */       s = s.next();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  68 */     return ms == null;
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/*  73 */     if (this._hash == -1)
/*     */     {
/*  75 */       int hash = 1;
/*  76 */       for (ISeq s = seq(); s != null; s = s.next())
/*     */       {
/*  78 */         hash = 31 * hash + (s.first() == null ? 0 : s.first().hashCode());
/*     */       }
/*  80 */       this._hash = hash;
/*     */     }
/*  82 */     return this._hash;
/*     */   }
/*     */   
/*     */   public int hasheq() {
/*  86 */     if (this._hasheq == -1)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  94 */       this._hasheq = Murmur3.hashOrdered(this);
/*     */     }
/*  96 */     return this._hasheq;
/*     */   }
/*     */   
/*     */   public Object peek() {
/* 100 */     return RT.first(this.f);
/*     */   }
/*     */   
/*     */   public PersistentQueue pop() {
/* 104 */     if (this.f == null) {
/* 105 */       return this;
/*     */     }
/* 107 */     ISeq f1 = this.f.next();
/* 108 */     PersistentVector r1 = this.r;
/* 109 */     if (f1 == null)
/*     */     {
/* 111 */       f1 = RT.seq(this.r);
/* 112 */       r1 = null;
/*     */     }
/* 114 */     return new PersistentQueue(meta(), this.cnt - 1, f1, r1);
/*     */   }
/*     */   
/*     */   public int count() {
/* 118 */     return this.cnt;
/*     */   }
/*     */   
/*     */   public ISeq seq() {
/* 122 */     if (this.f == null)
/* 123 */       return null;
/* 124 */     return new Seq(this.f, RT.seq(this.r));
/*     */   }
/*     */   
/*     */   public PersistentQueue cons(Object o) {
/* 128 */     if (this.f == null) {
/* 129 */       return new PersistentQueue(meta(), this.cnt + 1, RT.list(o), null);
/*     */     }
/* 131 */     return new PersistentQueue(meta(), this.cnt + 1, this.f, (this.r != null ? this.r : PersistentVector.EMPTY).cons(o));
/*     */   }
/*     */   
/*     */   public IPersistentCollection empty() {
/* 135 */     return EMPTY.withMeta(meta());
/*     */   }
/*     */   
/*     */   public PersistentQueue withMeta(IPersistentMap meta) {
/* 139 */     return new PersistentQueue(meta, this.cnt, this.f, this.r);
/*     */   }
/*     */   
/*     */   static class Seq extends ASeq {
/*     */     final ISeq f;
/*     */     final ISeq rseq;
/*     */     
/*     */     Seq(ISeq f, ISeq rseq) {
/* 147 */       this.f = f;
/* 148 */       this.rseq = rseq;
/*     */     }
/*     */     
/*     */     Seq(IPersistentMap meta, ISeq f, ISeq rseq) {
/* 152 */       super();
/* 153 */       this.f = f;
/* 154 */       this.rseq = rseq;
/*     */     }
/*     */     
/*     */     public Object first() {
/* 158 */       return this.f.first();
/*     */     }
/*     */     
/*     */     public ISeq next() {
/* 162 */       ISeq f1 = this.f.next();
/* 163 */       ISeq r1 = this.rseq;
/* 164 */       if (f1 == null)
/*     */       {
/* 166 */         if (this.rseq == null)
/* 167 */           return null;
/* 168 */         f1 = this.rseq;
/* 169 */         r1 = null;
/*     */       }
/* 171 */       return new Seq(f1, r1);
/*     */     }
/*     */     
/*     */     public int count() {
/* 175 */       return RT.count(this.f) + RT.count(this.rseq);
/*     */     }
/*     */     
/*     */     public Seq withMeta(IPersistentMap meta) {
/* 179 */       return new Seq(meta, this.f, this.rseq);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public Object[] toArray()
/*     */   {
/* 186 */     return RT.seqToArray(seq());
/*     */   }
/*     */   
/*     */   public boolean add(Object o) {
/* 190 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public boolean remove(Object o) {
/* 194 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public boolean addAll(Collection c) {
/* 198 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void clear() {
/* 202 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public boolean retainAll(Collection c) {
/* 206 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public boolean removeAll(Collection c) {
/* 210 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public boolean containsAll(Collection c) {
/* 214 */     for (Object o : c)
/*     */     {
/* 216 */       if (contains(o))
/* 217 */         return true;
/*     */     }
/* 219 */     return false;
/*     */   }
/*     */   
/*     */   public Object[] toArray(Object[] a) {
/* 223 */     return RT.seqToPassedArray(seq(), a);
/*     */   }
/*     */   
/*     */   public int size() {
/* 227 */     return count();
/*     */   }
/*     */   
/*     */   public boolean isEmpty() {
/* 231 */     return count() == 0;
/*     */   }
/*     */   
/*     */   public boolean contains(Object o) {
/* 235 */     for (ISeq s = seq(); s != null; s = s.next())
/*     */     {
/* 237 */       if (Util.equiv(s.first(), o))
/* 238 */         return true;
/*     */     }
/* 240 */     return false;
/*     */   }
/*     */   
/*     */   public Iterator iterator() {
/* 244 */     new Iterator() {
/* 245 */       private ISeq fseq = PersistentQueue.this.f;
/* 246 */       private final Iterator riter = PersistentQueue.this.r != null ? PersistentQueue.this.r.iterator() : null;
/*     */       
/*     */       public boolean hasNext() {
/* 249 */         return ((this.fseq != null) && (this.fseq.seq() != null)) || ((this.riter != null) && (this.riter.hasNext()));
/*     */       }
/*     */       
/*     */       public Object next() {
/* 253 */         if (this.fseq != null)
/*     */         {
/* 255 */           Object ret = this.fseq.first();
/* 256 */           this.fseq = this.fseq.next();
/* 257 */           return ret;
/*     */         }
/* 259 */         if ((this.riter != null) && (this.riter.hasNext())) {
/* 260 */           return this.riter.next();
/*     */         }
/* 262 */         throw new NoSuchElementException();
/*     */       }
/*     */       
/*     */       public void remove() {
/* 266 */         throw new UnsupportedOperationException();
/*     */       }
/*     */     };
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\PersistentQueue.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */