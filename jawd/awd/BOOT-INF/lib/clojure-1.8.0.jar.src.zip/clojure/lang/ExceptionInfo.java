/*    */ package clojure.lang;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExceptionInfo
/*    */   extends RuntimeException
/*    */   implements IExceptionInfo
/*    */ {
/*    */   public final IPersistentMap data;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ExceptionInfo(String s, IPersistentMap data)
/*    */   {
/* 22 */     this(s, data, null);
/*    */   }
/*    */   
/*    */   public ExceptionInfo(String s, IPersistentMap data, Throwable throwable)
/*    */   {
/* 27 */     super(s, throwable);
/* 28 */     if (data != null) {
/* 29 */       this.data = data;
/*    */     } else {
/* 31 */       throw new IllegalArgumentException("Additional data must be non-nil.");
/*    */     }
/*    */   }
/*    */   
/*    */   public IPersistentMap getData() {
/* 36 */     return this.data;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 40 */     return "clojure.lang.ExceptionInfo: " + getMessage() + " " + this.data.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\ExceptionInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */