/*    */ package clojure.lang;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReaderConditional
/*    */   implements ILookup
/*    */ {
/* 15 */   public static final Keyword FORM_KW = Keyword.intern("form");
/* 16 */   public static final Keyword SPLICING_KW = Keyword.intern("splicing?");
/*    */   public final Object form;
/*    */   public final Boolean splicing;
/*    */   
/*    */   public static ReaderConditional create(Object form, boolean splicing)
/*    */   {
/* 22 */     return new ReaderConditional(form, splicing);
/*    */   }
/*    */   
/*    */   private ReaderConditional(Object form, boolean splicing) {
/* 26 */     this.form = form;
/* 27 */     this.splicing = Boolean.valueOf(splicing);
/*    */   }
/*    */   
/*    */   public Object valAt(Object key)
/*    */   {
/* 32 */     return valAt(key, null);
/*    */   }
/*    */   
/*    */   public Object valAt(Object key, Object notFound) {
/* 36 */     if (FORM_KW.equals(key))
/* 37 */       return this.form;
/* 38 */     if (SPLICING_KW.equals(key)) {
/* 39 */       return this.splicing;
/*    */     }
/* 41 */     return notFound;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public boolean equals(Object o)
/*    */   {
/* 48 */     if (this == o) return true;
/* 49 */     if ((o == null) || (getClass() != o.getClass())) { return false;
/*    */     }
/* 51 */     ReaderConditional that = (ReaderConditional)o;
/*    */     
/* 53 */     if (this.form != null ? !this.form.equals(that.form) : that.form != null) return false;
/* 54 */     if (this.splicing != null ? !this.splicing.equals(that.splicing) : that.splicing != null)
/* 55 */       return false;
/* 56 */     return true;
/*    */   }
/*    */   
/*    */   public int hashCode()
/*    */   {
/* 61 */     int result = Util.hash(this.form);
/* 62 */     result = 31 * result + Util.hash(this.splicing);
/* 63 */     return result;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\ReaderConditional.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */