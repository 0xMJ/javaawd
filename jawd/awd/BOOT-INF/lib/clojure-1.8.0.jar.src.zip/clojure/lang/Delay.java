/*    */ package clojure.lang;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Delay
/*    */   implements IDeref, IPending
/*    */ {
/*    */   Object val;
/*    */   
/*    */ 
/*    */   Throwable exception;
/*    */   
/*    */ 
/*    */   IFn fn;
/*    */   
/*    */ 
/*    */ 
/*    */   public Delay(IFn fn)
/*    */   {
/* 21 */     this.fn = fn;
/* 22 */     this.val = null;
/* 23 */     this.exception = null;
/*    */   }
/*    */   
/*    */   public static Object force(Object x) {
/* 27 */     return (x instanceof Delay) ? ((Delay)x).deref() : x;
/*    */   }
/*    */   
/*    */ 
/*    */   public synchronized Object deref()
/*    */   {
/* 33 */     if (this.fn != null)
/*    */     {
/*    */       try
/*    */       {
/* 37 */         this.val = this.fn.invoke();
/*    */       }
/*    */       catch (Throwable t)
/*    */       {
/* 41 */         this.exception = t;
/*    */       }
/* 43 */       this.fn = null;
/*    */     }
/* 45 */     if (this.exception != null)
/* 46 */       throw Util.sneakyThrow(this.exception);
/* 47 */     return this.val;
/*    */   }
/*    */   
/*    */   public synchronized boolean isRealized() {
/* 51 */     return this.fn == null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\Delay.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */