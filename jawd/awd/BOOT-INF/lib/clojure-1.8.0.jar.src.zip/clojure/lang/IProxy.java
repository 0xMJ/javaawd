package clojure.lang;

public abstract interface IProxy
{
  public abstract void __initClojureFnMappings(IPersistentMap paramIPersistentMap);
  
  public abstract void __updateClojureFnMappings(IPersistentMap paramIPersistentMap);
  
  public abstract IPersistentMap __getClojureFnMappings();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\IProxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */