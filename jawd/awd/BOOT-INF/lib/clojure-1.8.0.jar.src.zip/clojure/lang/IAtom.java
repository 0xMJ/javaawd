package clojure.lang;

public abstract interface IAtom
{
  public abstract Object swap(IFn paramIFn);
  
  public abstract Object swap(IFn paramIFn, Object paramObject);
  
  public abstract Object swap(IFn paramIFn, Object paramObject1, Object paramObject2);
  
  public abstract Object swap(IFn paramIFn, Object paramObject1, Object paramObject2, ISeq paramISeq);
  
  public abstract boolean compareAndSet(Object paramObject1, Object paramObject2);
  
  public abstract Object reset(Object paramObject);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\IAtom.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */