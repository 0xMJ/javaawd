/*    */ package clojure.lang;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Tuple
/*    */ {
/*    */   static final int MAX_SIZE = 6;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 22 */   public static IPersistentVector create() { return PersistentVector.EMPTY; }
/*    */   
/* 24 */   public static IPersistentVector create(Object v0) { return RT.vector(new Object[] { v0 }); }
/*    */   
/* 26 */   public static IPersistentVector create(Object v0, Object v1) { return RT.vector(new Object[] { v0, v1 }); }
/*    */   
/* 28 */   public static IPersistentVector create(Object v0, Object v1, Object v2) { return RT.vector(new Object[] { v0, v1, v2 }); }
/*    */   
/* 30 */   public static IPersistentVector create(Object v0, Object v1, Object v2, Object v3) { return RT.vector(new Object[] { v0, v1, v2, v3 }); }
/*    */   
/* 32 */   public static IPersistentVector create(Object v0, Object v1, Object v2, Object v3, Object v4) { return RT.vector(new Object[] { v0, v1, v2, v3, v4 }); }
/*    */   
/* 34 */   public static IPersistentVector create(Object v0, Object v1, Object v2, Object v3, Object v4, Object v5) { return RT.vector(new Object[] { v0, v1, v2, v3, v4, v5 }); }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\Tuple.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */