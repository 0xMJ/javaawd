/*     */ package clojure.lang;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.Iterator;
/*     */ import java.util.NoSuchElementException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ArrayIter
/*     */   implements Iterator
/*     */ {
/*     */   final Object[] array;
/*     */   int i;
/*  20 */   public static Iterator EMPTY_ITERATOR = new Iterator() {
/*  21 */     public boolean hasNext() { return false; }
/*  22 */     public Object next() { throw new NoSuchElementException(); }
/*  23 */     public void remove() { throw new UnsupportedOperationException("remove() not supported"); }
/*     */   };
/*     */   
/*     */   public static Iterator create() {
/*  27 */     return EMPTY_ITERATOR;
/*     */   }
/*     */   
/*     */   public static Iterator create(Object... array) {
/*  31 */     if ((array == null) || (array.length == 0))
/*  32 */       return EMPTY_ITERATOR;
/*  33 */     return new ArrayIter(array, 0);
/*     */   }
/*     */   
/*     */   public static Iterator createFromObject(Object array) {
/*  37 */     if ((array == null) || (Array.getLength(array) == 0))
/*  38 */       return EMPTY_ITERATOR;
/*  39 */     Class aclass = array.getClass();
/*  40 */     if (aclass == int[].class)
/*  41 */       return new ArrayIter_int((int[])array, 0);
/*  42 */     if (aclass == float[].class)
/*  43 */       return new ArrayIter_float((float[])array, 0);
/*  44 */     if (aclass == double[].class)
/*  45 */       return new ArrayIter_double((double[])array, 0);
/*  46 */     if (aclass == long[].class)
/*  47 */       return new ArrayIter_long((long[])array, 0);
/*  48 */     if (aclass == byte[].class)
/*  49 */       return new ArrayIter_byte((byte[])array, 0);
/*  50 */     if (aclass == char[].class)
/*  51 */       return new ArrayIter_char((char[])array, 0);
/*  52 */     if (aclass == short[].class)
/*  53 */       return new ArrayIter_short((short[])array, 0);
/*  54 */     if (aclass == boolean[].class)
/*  55 */       return new ArrayIter_boolean((boolean[])array, 0);
/*  56 */     return new ArrayIter(array, 0);
/*     */   }
/*     */   
/*     */   ArrayIter(Object array, int i) {
/*  60 */     this.i = i;
/*  61 */     this.array = ((Object[])array);
/*     */   }
/*     */   
/*     */   public boolean hasNext() {
/*  65 */     return (this.array != null) && (this.i < this.array.length);
/*     */   }
/*     */   
/*     */   public Object next() {
/*  69 */     if ((this.array != null) && (this.i < this.array.length))
/*  70 */       return this.array[(this.i++)];
/*  71 */     throw new NoSuchElementException();
/*     */   }
/*     */   
/*     */   public void remove() {
/*  75 */     throw new UnsupportedOperationException("remove() not supported");
/*     */   }
/*     */   
/*     */   public static class ArrayIter_int implements Iterator<Long>
/*     */   {
/*     */     final int[] array;
/*     */     int i;
/*     */     
/*     */     ArrayIter_int(int[] array, int i)
/*     */     {
/*  85 */       this.array = array;
/*  86 */       this.i = i;
/*     */     }
/*     */     
/*     */     public boolean hasNext() {
/*  90 */       return (this.array != null) && (this.i < this.array.length);
/*     */     }
/*     */     
/*     */     public Long next() {
/*  94 */       if ((this.array != null) && (this.i < this.array.length))
/*  95 */         return Long.valueOf(this.array[(this.i++)]);
/*  96 */       throw new NoSuchElementException();
/*     */     }
/*     */     
/*     */     public void remove() {
/* 100 */       throw new UnsupportedOperationException("remove() not supported");
/*     */     }
/*     */   }
/*     */   
/*     */   public static class ArrayIter_float implements Iterator<Double> {
/*     */     final float[] array;
/*     */     int i;
/*     */     
/*     */     ArrayIter_float(float[] array, int i) {
/* 109 */       this.array = array;
/* 110 */       this.i = i;
/*     */     }
/*     */     
/*     */     public boolean hasNext() {
/* 114 */       return (this.array != null) && (this.i < this.array.length);
/*     */     }
/*     */     
/*     */     public Double next() {
/* 118 */       if ((this.array != null) && (this.i < this.array.length))
/* 119 */         return Double.valueOf(this.array[(this.i++)]);
/* 120 */       throw new NoSuchElementException();
/*     */     }
/*     */     
/*     */     public void remove() {
/* 124 */       throw new UnsupportedOperationException("remove() not supported");
/*     */     }
/*     */   }
/*     */   
/*     */   public static class ArrayIter_double implements Iterator<Double> {
/*     */     final double[] array;
/*     */     int i;
/*     */     
/*     */     ArrayIter_double(double[] array, int i) {
/* 133 */       this.array = array;
/* 134 */       this.i = i;
/*     */     }
/*     */     
/*     */     public boolean hasNext() {
/* 138 */       return (this.array != null) && (this.i < this.array.length);
/*     */     }
/*     */     
/*     */     public Double next() {
/* 142 */       if ((this.array != null) && (this.i < this.array.length))
/* 143 */         return Double.valueOf(this.array[(this.i++)]);
/* 144 */       throw new NoSuchElementException();
/*     */     }
/*     */     
/*     */     public void remove() {
/* 148 */       throw new UnsupportedOperationException("remove() not supported");
/*     */     }
/*     */   }
/*     */   
/*     */   public static class ArrayIter_long implements Iterator<Long>
/*     */   {
/*     */     final long[] array;
/*     */     int i;
/*     */     
/*     */     ArrayIter_long(long[] array, int i) {
/* 158 */       this.array = array;
/* 159 */       this.i = i;
/*     */     }
/*     */     
/*     */     public boolean hasNext() {
/* 163 */       return (this.array != null) && (this.i < this.array.length);
/*     */     }
/*     */     
/*     */     public Long next() {
/* 167 */       if ((this.array != null) && (this.i < this.array.length))
/* 168 */         return Long.valueOf(this.array[(this.i++)]);
/* 169 */       throw new NoSuchElementException();
/*     */     }
/*     */     
/*     */     public void remove() {
/* 173 */       throw new UnsupportedOperationException("remove() not supported");
/*     */     }
/*     */   }
/*     */   
/*     */   public static class ArrayIter_byte implements Iterator<Byte>
/*     */   {
/*     */     final byte[] array;
/*     */     int i;
/*     */     
/*     */     ArrayIter_byte(byte[] array, int i) {
/* 183 */       this.array = array;
/* 184 */       this.i = i;
/*     */     }
/*     */     
/*     */     public boolean hasNext() {
/* 188 */       return (this.array != null) && (this.i < this.array.length);
/*     */     }
/*     */     
/*     */     public Byte next() {
/* 192 */       if ((this.array != null) && (this.i < this.array.length))
/* 193 */         return Byte.valueOf(this.array[(this.i++)]);
/* 194 */       throw new NoSuchElementException();
/*     */     }
/*     */     
/*     */     public void remove() {
/* 198 */       throw new UnsupportedOperationException("remove() not supported");
/*     */     }
/*     */   }
/*     */   
/*     */   public static class ArrayIter_char implements Iterator<Character>
/*     */   {
/*     */     final char[] array;
/*     */     int i;
/*     */     
/*     */     ArrayIter_char(char[] array, int i) {
/* 208 */       this.array = array;
/* 209 */       this.i = i;
/*     */     }
/*     */     
/*     */     public boolean hasNext() {
/* 213 */       return (this.array != null) && (this.i < this.array.length);
/*     */     }
/*     */     
/*     */     public Character next() {
/* 217 */       if ((this.array != null) && (this.i < this.array.length))
/* 218 */         return Character.valueOf(this.array[(this.i++)]);
/* 219 */       throw new NoSuchElementException();
/*     */     }
/*     */     
/*     */     public void remove() {
/* 223 */       throw new UnsupportedOperationException("remove() not supported");
/*     */     }
/*     */   }
/*     */   
/*     */   public static class ArrayIter_short implements Iterator<Long>
/*     */   {
/*     */     final short[] array;
/*     */     int i;
/*     */     
/*     */     ArrayIter_short(short[] array, int i) {
/* 233 */       this.array = array;
/* 234 */       this.i = i;
/*     */     }
/*     */     
/*     */     public boolean hasNext() {
/* 238 */       return (this.array != null) && (this.i < this.array.length);
/*     */     }
/*     */     
/*     */     public Long next() {
/* 242 */       if ((this.array != null) && (this.i < this.array.length))
/* 243 */         return Long.valueOf(this.array[(this.i++)]);
/* 244 */       throw new NoSuchElementException();
/*     */     }
/*     */     
/*     */     public void remove() {
/* 248 */       throw new UnsupportedOperationException("remove() not supported");
/*     */     }
/*     */   }
/*     */   
/*     */   public static class ArrayIter_boolean implements Iterator<Boolean>
/*     */   {
/*     */     final boolean[] array;
/*     */     int i;
/*     */     
/*     */     ArrayIter_boolean(boolean[] array, int i) {
/* 258 */       this.array = array;
/* 259 */       this.i = i;
/*     */     }
/*     */     
/*     */     public boolean hasNext() {
/* 263 */       return (this.array != null) && (this.i < this.array.length);
/*     */     }
/*     */     
/*     */     public Boolean next() {
/* 267 */       if ((this.array != null) && (this.i < this.array.length))
/* 268 */         return Boolean.valueOf(this.array[(this.i++)]);
/* 269 */       throw new NoSuchElementException();
/*     */     }
/*     */     
/*     */     public void remove() {
/* 273 */       throw new UnsupportedOperationException("remove() not supported");
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\ArrayIter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */