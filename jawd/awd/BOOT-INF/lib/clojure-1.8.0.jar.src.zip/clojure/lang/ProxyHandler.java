/*    */ package clojure.lang;
/*    */ 
/*    */ import java.lang.reflect.InvocationHandler;
/*    */ import java.lang.reflect.Method;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ProxyHandler
/*    */   implements InvocationHandler
/*    */ {
/*    */   final IPersistentMap fns;
/*    */   
/*    */   public ProxyHandler(IPersistentMap fns)
/*    */   {
/* 24 */     this.fns = fns;
/*    */   }
/*    */   
/*    */   public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
/* 28 */     Class rt = method.getReturnType();
/* 29 */     IFn fn = (IFn)this.fns.valAt(method.getName());
/* 30 */     if (fn == null)
/*    */     {
/* 32 */       if (rt == Void.TYPE)
/* 33 */         return null;
/* 34 */       if (method.getName().equals("equals"))
/*    */       {
/* 36 */         return Boolean.valueOf(proxy == args[0]);
/*    */       }
/* 38 */       if (method.getName().equals("hashCode"))
/*    */       {
/* 40 */         return Integer.valueOf(System.identityHashCode(proxy));
/*    */       }
/* 42 */       if (method.getName().equals("toString"))
/*    */       {
/* 44 */         return "Proxy: " + System.identityHashCode(proxy);
/*    */       }
/* 46 */       throw new UnsupportedOperationException();
/*    */     }
/* 48 */     Object ret = fn.applyTo(ArraySeq.create(args));
/* 49 */     if (rt == Void.TYPE)
/* 50 */       return null;
/* 51 */     if (rt.isPrimitive())
/*    */     {
/* 53 */       if (rt == Character.TYPE)
/* 54 */         return ret;
/* 55 */       if (rt == Integer.TYPE)
/* 56 */         return Integer.valueOf(((Number)ret).intValue());
/* 57 */       if (rt == Long.TYPE)
/* 58 */         return Long.valueOf(((Number)ret).longValue());
/* 59 */       if (rt == Float.TYPE)
/* 60 */         return Float.valueOf(((Number)ret).floatValue());
/* 61 */       if (rt == Double.TYPE)
/* 62 */         return Double.valueOf(((Number)ret).doubleValue());
/* 63 */       if ((rt == Boolean.TYPE) && (!(ret instanceof Boolean)))
/* 64 */         return ret == null ? Boolean.FALSE : Boolean.TRUE;
/* 65 */       if (rt == Byte.TYPE)
/* 66 */         return Byte.valueOf((byte)((Number)ret).intValue());
/* 67 */       if (rt == Short.TYPE)
/* 68 */         return Short.valueOf((short)((Number)ret).intValue());
/*    */     }
/* 70 */     return ret;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\ProxyHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */