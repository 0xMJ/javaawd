/*    */ package clojure.lang;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ArrayChunk
/*    */   implements IChunk, Serializable
/*    */ {
/*    */   final Object[] array;
/*    */   final int off;
/*    */   final int end;
/*    */   
/*    */   public ArrayChunk(Object[] array)
/*    */   {
/* 24 */     this(array, 0, array.length);
/*    */   }
/*    */   
/*    */   public ArrayChunk(Object[] array, int off) {
/* 28 */     this(array, off, array.length);
/*    */   }
/*    */   
/*    */   public ArrayChunk(Object[] array, int off, int end) {
/* 32 */     this.array = array;
/* 33 */     this.off = off;
/* 34 */     this.end = end;
/*    */   }
/*    */   
/*    */   public Object nth(int i) {
/* 38 */     return this.array[(this.off + i)];
/*    */   }
/*    */   
/*    */   public Object nth(int i, Object notFound) {
/* 42 */     if ((i >= 0) && (i < count()))
/* 43 */       return nth(i);
/* 44 */     return notFound;
/*    */   }
/*    */   
/*    */   public int count() {
/* 48 */     return this.end - this.off;
/*    */   }
/*    */   
/*    */   public IChunk dropFirst() {
/* 52 */     if (this.off == this.end)
/* 53 */       throw new IllegalStateException("dropFirst of empty chunk");
/* 54 */     return new ArrayChunk(this.array, this.off + 1, this.end);
/*    */   }
/*    */   
/*    */   public Object reduce(IFn f, Object start) {
/* 58 */     Object ret = f.invoke(start, this.array[this.off]);
/* 59 */     if (RT.isReduced(ret))
/* 60 */       return ret;
/* 61 */     for (int x = this.off + 1; x < this.end; x++)
/*    */     {
/* 63 */       ret = f.invoke(ret, this.array[x]);
/* 64 */       if (RT.isReduced(ret))
/* 65 */         return ret;
/*    */     }
/* 67 */     return ret;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\ArrayChunk.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */