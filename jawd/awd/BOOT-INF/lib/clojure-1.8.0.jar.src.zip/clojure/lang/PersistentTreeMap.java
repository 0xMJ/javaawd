/*     */ package clojure.lang;
/*     */ 
/*     */ import java.util.Comparator;
/*     */ import java.util.EmptyStackException;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Stack;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PersistentTreeMap
/*     */   extends APersistentMap
/*     */   implements IObj, Reversible, Sorted, IKVReduce
/*     */ {
/*     */   public final Comparator comp;
/*     */   public final Node tree;
/*     */   public final int _count;
/*     */   final IPersistentMap _meta;
/*  32 */   public static final PersistentTreeMap EMPTY = new PersistentTreeMap();
/*     */   
/*     */   public static IPersistentMap create(Map other) {
/*  35 */     IPersistentMap ret = EMPTY;
/*  36 */     for (Object o : other.entrySet())
/*     */     {
/*  38 */       Map.Entry e = (Map.Entry)o;
/*  39 */       ret = ret.assoc(e.getKey(), e.getValue());
/*     */     }
/*  41 */     return ret;
/*     */   }
/*     */   
/*     */   public PersistentTreeMap() {
/*  45 */     this(RT.DEFAULT_COMPARATOR);
/*     */   }
/*     */   
/*     */   public PersistentTreeMap withMeta(IPersistentMap meta) {
/*  49 */     return new PersistentTreeMap(meta, this.comp, this.tree, this._count);
/*     */   }
/*     */   
/*     */   private PersistentTreeMap(Comparator comp) {
/*  53 */     this(null, comp);
/*     */   }
/*     */   
/*     */   public PersistentTreeMap(IPersistentMap meta, Comparator comp)
/*     */   {
/*  58 */     this.comp = comp;
/*  59 */     this._meta = meta;
/*  60 */     this.tree = null;
/*  61 */     this._count = 0;
/*     */   }
/*     */   
/*     */   PersistentTreeMap(IPersistentMap meta, Comparator comp, Node tree, int _count) {
/*  65 */     this._meta = meta;
/*  66 */     this.comp = comp;
/*  67 */     this.tree = tree;
/*  68 */     this._count = _count;
/*     */   }
/*     */   
/*     */   public static PersistentTreeMap create(ISeq items) {
/*  72 */     IPersistentMap ret = EMPTY;
/*  73 */     for (; items != null; items = items.next().next())
/*     */     {
/*  75 */       if (items.next() == null)
/*  76 */         throw new IllegalArgumentException(String.format("No value supplied for key: %s", new Object[] { items.first() }));
/*  77 */       ret = ret.assoc(items.first(), RT.second(items));
/*     */     }
/*  79 */     return (PersistentTreeMap)ret;
/*     */   }
/*     */   
/*     */   public static PersistentTreeMap create(Comparator comp, ISeq items) {
/*  83 */     IPersistentMap ret = new PersistentTreeMap(comp);
/*  84 */     for (; items != null; items = items.next().next())
/*     */     {
/*  86 */       if (items.next() == null)
/*  87 */         throw new IllegalArgumentException(String.format("No value supplied for key: %s", new Object[] { items.first() }));
/*  88 */       ret = ret.assoc(items.first(), RT.second(items));
/*     */     }
/*  90 */     return (PersistentTreeMap)ret;
/*     */   }
/*     */   
/*     */   public boolean containsKey(Object key) {
/*  94 */     return entryAt(key) != null;
/*     */   }
/*     */   
/*     */   public PersistentTreeMap assocEx(Object key, Object val) {
/*  98 */     Box found = new Box(null);
/*  99 */     Node t = add(this.tree, key, val, found);
/* 100 */     if (t == null)
/*     */     {
/* 102 */       throw Util.runtimeException("Key already present");
/*     */     }
/* 104 */     return new PersistentTreeMap(this.comp, t.blacken(), this._count + 1, meta());
/*     */   }
/*     */   
/*     */   public PersistentTreeMap assoc(Object key, Object val) {
/* 108 */     Box found = new Box(null);
/* 109 */     Node t = add(this.tree, key, val, found);
/* 110 */     if (t == null)
/*     */     {
/* 112 */       Node foundNode = (Node)found.val;
/* 113 */       if (foundNode.val() == val)
/* 114 */         return this;
/* 115 */       return new PersistentTreeMap(this.comp, replace(this.tree, key, val), this._count, meta());
/*     */     }
/* 117 */     return new PersistentTreeMap(this.comp, t.blacken(), this._count + 1, meta());
/*     */   }
/*     */   
/*     */   public PersistentTreeMap without(Object key)
/*     */   {
/* 122 */     Box found = new Box(null);
/* 123 */     Node t = remove(this.tree, key, found);
/* 124 */     if (t == null)
/*     */     {
/* 126 */       if (found.val == null) {
/* 127 */         return this;
/*     */       }
/* 129 */       return new PersistentTreeMap(meta(), this.comp);
/*     */     }
/* 131 */     return new PersistentTreeMap(this.comp, t.blacken(), this._count - 1, meta());
/*     */   }
/*     */   
/*     */   public ISeq seq() {
/* 135 */     if (this._count > 0)
/* 136 */       return Seq.create(this.tree, true, this._count);
/* 137 */     return null;
/*     */   }
/*     */   
/*     */   public IPersistentCollection empty() {
/* 141 */     return new PersistentTreeMap(meta(), this.comp);
/*     */   }
/*     */   
/*     */   public ISeq rseq() {
/* 145 */     if (this._count > 0)
/* 146 */       return Seq.create(this.tree, false, this._count);
/* 147 */     return null;
/*     */   }
/*     */   
/*     */   public Comparator comparator() {
/* 151 */     return this.comp;
/*     */   }
/*     */   
/*     */   public Object entryKey(Object entry) {
/* 155 */     return ((IMapEntry)entry).key();
/*     */   }
/*     */   
/*     */   public ISeq seq(boolean ascending) {
/* 159 */     if (this._count > 0)
/* 160 */       return Seq.create(this.tree, ascending, this._count);
/* 161 */     return null;
/*     */   }
/*     */   
/*     */   public ISeq seqFrom(Object key, boolean ascending) {
/* 165 */     if (this._count > 0)
/*     */     {
/* 167 */       ISeq stack = null;
/* 168 */       Node t = this.tree;
/* 169 */       while (t != null)
/*     */       {
/* 171 */         int c = doCompare(key, t.key);
/* 172 */         if (c == 0)
/*     */         {
/* 174 */           stack = RT.cons(t, stack);
/* 175 */           return new Seq(stack, ascending);
/*     */         }
/* 177 */         if (ascending)
/*     */         {
/* 179 */           if (c < 0)
/*     */           {
/* 181 */             stack = RT.cons(t, stack);
/* 182 */             t = t.left();
/*     */           }
/*     */           else {
/* 185 */             t = t.right();
/*     */           }
/*     */           
/*     */         }
/* 189 */         else if (c > 0)
/*     */         {
/* 191 */           stack = RT.cons(t, stack);
/* 192 */           t = t.right();
/*     */         }
/*     */         else {
/* 195 */           t = t.left();
/*     */         }
/*     */       }
/* 198 */       if (stack != null)
/* 199 */         return new Seq(stack, ascending);
/*     */     }
/* 201 */     return null;
/*     */   }
/*     */   
/*     */   public NodeIterator iterator() {
/* 205 */     return new NodeIterator(this.tree, true);
/*     */   }
/*     */   
/*     */   public Object kvreduce(IFn f, Object init) {
/* 209 */     if (this.tree != null)
/* 210 */       init = this.tree.kvreduce(f, init);
/* 211 */     if (RT.isReduced(init))
/* 212 */       init = ((IDeref)init).deref();
/* 213 */     return init;
/*     */   }
/*     */   
/*     */   public NodeIterator reverseIterator()
/*     */   {
/* 218 */     return new NodeIterator(this.tree, false);
/*     */   }
/*     */   
/*     */   public Iterator keys() {
/* 222 */     return keys(iterator());
/*     */   }
/*     */   
/*     */   public Iterator vals() {
/* 226 */     return vals(iterator());
/*     */   }
/*     */   
/*     */   public Iterator keys(NodeIterator it) {
/* 230 */     return new KeyIterator(it);
/*     */   }
/*     */   
/*     */   public Iterator vals(NodeIterator it) {
/* 234 */     return new ValIterator(it);
/*     */   }
/*     */   
/*     */   public Object minKey() {
/* 238 */     Node t = min();
/* 239 */     return t != null ? t.key : null;
/*     */   }
/*     */   
/*     */   public Node min() {
/* 243 */     Node t = this.tree;
/* 244 */     if (t != null)
/*     */     {
/* 246 */       while (t.left() != null)
/* 247 */         t = t.left();
/*     */     }
/* 249 */     return t;
/*     */   }
/*     */   
/*     */   public Object maxKey() {
/* 253 */     Node t = max();
/* 254 */     return t != null ? t.key : null;
/*     */   }
/*     */   
/*     */   public Node max() {
/* 258 */     Node t = this.tree;
/* 259 */     if (t != null)
/*     */     {
/* 261 */       while (t.right() != null)
/* 262 */         t = t.right();
/*     */     }
/* 264 */     return t;
/*     */   }
/*     */   
/*     */   public int depth() {
/* 268 */     return depth(this.tree);
/*     */   }
/*     */   
/*     */   int depth(Node t) {
/* 272 */     if (t == null)
/* 273 */       return 0;
/* 274 */     return 1 + Math.max(depth(t.left()), depth(t.right()));
/*     */   }
/*     */   
/*     */   public Object valAt(Object key, Object notFound) {
/* 278 */     Node n = entryAt(key);
/* 279 */     return n != null ? n.val() : notFound;
/*     */   }
/*     */   
/*     */   public Object valAt(Object key) {
/* 283 */     return valAt(key, null);
/*     */   }
/*     */   
/*     */   public int capacity() {
/* 287 */     return this._count;
/*     */   }
/*     */   
/*     */   public int count() {
/* 291 */     return this._count;
/*     */   }
/*     */   
/*     */   public Node entryAt(Object key) {
/* 295 */     Node t = this.tree;
/* 296 */     while (t != null)
/*     */     {
/* 298 */       int c = doCompare(key, t.key);
/* 299 */       if (c == 0)
/* 300 */         return t;
/* 301 */       if (c < 0) {
/* 302 */         t = t.left();
/*     */       } else
/* 304 */         t = t.right();
/*     */     }
/* 306 */     return t;
/*     */   }
/*     */   
/*     */   public int doCompare(Object k1, Object k2)
/*     */   {
/* 311 */     return this.comp.compare(k1, k2);
/*     */   }
/*     */   
/*     */   Node add(Node t, Object key, Object val, Box found)
/*     */   {
/* 316 */     if (t == null)
/*     */     {
/* 318 */       if (val == null)
/* 319 */         return new Red(key);
/* 320 */       return new RedVal(key, val);
/*     */     }
/* 322 */     int c = doCompare(key, t.key);
/* 323 */     if (c == 0)
/*     */     {
/* 325 */       found.val = t;
/* 326 */       return null;
/*     */     }
/* 328 */     Node ins = c < 0 ? add(t.left(), key, val, found) : add(t.right(), key, val, found);
/* 329 */     if (ins == null)
/* 330 */       return null;
/* 331 */     if (c < 0)
/* 332 */       return t.addLeft(ins);
/* 333 */     return t.addRight(ins);
/*     */   }
/*     */   
/*     */   Node remove(Node t, Object key, Box found) {
/* 337 */     if (t == null)
/* 338 */       return null;
/* 339 */     int c = doCompare(key, t.key);
/* 340 */     if (c == 0)
/*     */     {
/* 342 */       found.val = t;
/* 343 */       return append(t.left(), t.right());
/*     */     }
/* 345 */     Node del = c < 0 ? remove(t.left(), key, found) : remove(t.right(), key, found);
/* 346 */     if ((del == null) && (found.val == null))
/* 347 */       return null;
/* 348 */     if (c < 0)
/*     */     {
/* 350 */       if ((t.left() instanceof Black)) {
/* 351 */         return balanceLeftDel(t.key, t.val(), del, t.right());
/*     */       }
/* 353 */       return red(t.key, t.val(), del, t.right());
/*     */     }
/* 355 */     if ((t.right() instanceof Black))
/* 356 */       return balanceRightDel(t.key, t.val(), t.left(), del);
/* 357 */     return red(t.key, t.val(), t.left(), del);
/*     */   }
/*     */   
/*     */ 
/*     */   static Node append(Node left, Node right)
/*     */   {
/* 363 */     if (left == null)
/* 364 */       return right;
/* 365 */     if (right == null)
/* 366 */       return left;
/* 367 */     if ((left instanceof Red))
/*     */     {
/* 369 */       if ((right instanceof Red))
/*     */       {
/* 371 */         Node app = append(left.right(), right.left());
/* 372 */         if ((app instanceof Red)) {
/* 373 */           return red(app.key, app.val(), red(left.key, left.val(), left.left(), app.left()), red(right.key, right.val(), app.right(), right.right()));
/*     */         }
/*     */         
/*     */ 
/* 377 */         return red(left.key, left.val(), left.left(), red(right.key, right.val(), app, right.right()));
/*     */       }
/*     */       
/* 380 */       return red(left.key, left.val(), left.left(), append(left.right(), right));
/*     */     }
/* 382 */     if ((right instanceof Red)) {
/* 383 */       return red(right.key, right.val(), append(left, right.left()), right.right());
/*     */     }
/*     */     
/* 386 */     Node app = append(left.right(), right.left());
/* 387 */     if ((app instanceof Red)) {
/* 388 */       return red(app.key, app.val(), black(left.key, left.val(), left.left(), app.left()), black(right.key, right.val(), app.right(), right.right()));
/*     */     }
/*     */     
/*     */ 
/* 392 */     return balanceLeftDel(left.key, left.val(), left.left(), black(right.key, right.val(), app, right.right()));
/*     */   }
/*     */   
/*     */   static Node balanceLeftDel(Object key, Object val, Node del, Node right)
/*     */   {
/* 397 */     if ((del instanceof Red))
/* 398 */       return red(key, val, del.blacken(), right);
/* 399 */     if ((right instanceof Black))
/* 400 */       return rightBalance(key, val, del, right.redden());
/* 401 */     if (((right instanceof Red)) && ((right.left() instanceof Black))) {
/* 402 */       return red(right.left().key, right.left().val(), black(key, val, del, right.left().left()), rightBalance(right.key, right.val(), right.left().right(), right.right().redden()));
/*     */     }
/*     */     
/*     */ 
/* 406 */     throw new UnsupportedOperationException("Invariant violation");
/*     */   }
/*     */   
/*     */   static Node balanceRightDel(Object key, Object val, Node left, Node del) {
/* 410 */     if ((del instanceof Red))
/* 411 */       return red(key, val, left, del.blacken());
/* 412 */     if ((left instanceof Black))
/* 413 */       return leftBalance(key, val, left.redden(), del);
/* 414 */     if (((left instanceof Red)) && ((left.right() instanceof Black))) {
/* 415 */       return red(left.right().key, left.right().val(), leftBalance(left.key, left.val(), left.left().redden(), left.right().left()), black(key, val, left.right().right(), del));
/*     */     }
/*     */     
/*     */ 
/* 419 */     throw new UnsupportedOperationException("Invariant violation");
/*     */   }
/*     */   
/*     */   static Node leftBalance(Object key, Object val, Node ins, Node right) {
/* 423 */     if (((ins instanceof Red)) && ((ins.left() instanceof Red)))
/* 424 */       return red(ins.key, ins.val(), ins.left().blacken(), black(key, val, ins.right(), right));
/* 425 */     if (((ins instanceof Red)) && ((ins.right() instanceof Red))) {
/* 426 */       return red(ins.right().key, ins.right().val(), black(ins.key, ins.val(), ins.left(), ins.right().left()), black(key, val, ins.right().right(), right));
/*     */     }
/*     */     
/*     */ 
/* 430 */     return black(key, val, ins, right);
/*     */   }
/*     */   
/*     */   static Node rightBalance(Object key, Object val, Node left, Node ins)
/*     */   {
/* 435 */     if (((ins instanceof Red)) && ((ins.right() instanceof Red)))
/* 436 */       return red(ins.key, ins.val(), black(key, val, left, ins.left()), ins.right().blacken());
/* 437 */     if (((ins instanceof Red)) && ((ins.left() instanceof Red))) {
/* 438 */       return red(ins.left().key, ins.left().val(), black(key, val, left, ins.left().left()), black(ins.key, ins.val(), ins.left().right(), ins.right()));
/*     */     }
/*     */     
/*     */ 
/* 442 */     return black(key, val, left, ins);
/*     */   }
/*     */   
/*     */   Node replace(Node t, Object key, Object val) {
/* 446 */     int c = doCompare(key, t.key);
/* 447 */     return t.replace(t.key, c == 0 ? val : t.val(), c < 0 ? replace(t.left(), key, val) : t.left(), c > 0 ? replace(t.right(), key, val) : t.right());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   PersistentTreeMap(Comparator comp, Node tree, int count, IPersistentMap meta)
/*     */   {
/* 454 */     this._meta = meta;
/* 455 */     this.comp = comp;
/* 456 */     this.tree = tree;
/* 457 */     this._count = count;
/*     */   }
/*     */   
/*     */   static Red red(Object key, Object val, Node left, Node right) {
/* 461 */     if ((left == null) && (right == null))
/*     */     {
/* 463 */       if (val == null)
/* 464 */         return new Red(key);
/* 465 */       return new RedVal(key, val);
/*     */     }
/* 467 */     if (val == null)
/* 468 */       return new RedBranch(key, left, right);
/* 469 */     return new RedBranchVal(key, val, left, right);
/*     */   }
/*     */   
/*     */   static Black black(Object key, Object val, Node left, Node right) {
/* 473 */     if ((left == null) && (right == null))
/*     */     {
/* 475 */       if (val == null)
/* 476 */         return new Black(key);
/* 477 */       return new BlackVal(key, val);
/*     */     }
/* 479 */     if (val == null)
/* 480 */       return new BlackBranch(key, left, right);
/* 481 */     return new BlackBranchVal(key, val, left, right);
/*     */   }
/*     */   
/*     */   public IPersistentMap meta() {
/* 485 */     return this._meta;
/*     */   }
/*     */   
/*     */   static abstract class Node extends AMapEntry {
/*     */     final Object key;
/*     */     
/*     */     Node(Object key) {
/* 492 */       this.key = key;
/*     */     }
/*     */     
/*     */     public Object key() {
/* 496 */       return this.key;
/*     */     }
/*     */     
/*     */     public Object val() {
/* 500 */       return null;
/*     */     }
/*     */     
/*     */     public Object getKey() {
/* 504 */       return key();
/*     */     }
/*     */     
/*     */     public Object getValue() {
/* 508 */       return val();
/*     */     }
/*     */     
/*     */     Node left() {
/* 512 */       return null;
/*     */     }
/*     */     
/*     */     Node right() {
/* 516 */       return null;
/*     */     }
/*     */     
/*     */     abstract Node addLeft(Node paramNode);
/*     */     
/*     */     abstract Node addRight(Node paramNode);
/*     */     
/*     */     abstract Node removeLeft(Node paramNode);
/*     */     
/*     */     abstract Node removeRight(Node paramNode);
/*     */     
/*     */     abstract Node blacken();
/*     */     
/*     */     abstract Node redden();
/*     */     
/*     */     Node balanceLeft(Node parent) {
/* 532 */       return PersistentTreeMap.black(parent.key, parent.val(), this, parent.right());
/*     */     }
/*     */     
/*     */     Node balanceRight(Node parent) {
/* 536 */       return PersistentTreeMap.black(parent.key, parent.val(), parent.left(), this);
/*     */     }
/*     */     
/*     */     abstract Node replace(Object paramObject1, Object paramObject2, Node paramNode1, Node paramNode2);
/*     */     
/*     */     public Object kvreduce(IFn f, Object init) {
/* 542 */       if (left() != null) {
/* 543 */         init = left().kvreduce(f, init);
/* 544 */         if (RT.isReduced(init))
/* 545 */           return init;
/*     */       }
/* 547 */       init = f.invoke(init, key(), val());
/* 548 */       if (RT.isReduced(init)) {
/* 549 */         return init;
/*     */       }
/* 551 */       if (right() != null) {
/* 552 */         init = right().kvreduce(f, init);
/*     */       }
/* 554 */       return init;
/*     */     }
/*     */   }
/*     */   
/*     */   static class Black extends PersistentTreeMap.Node
/*     */   {
/*     */     public Black(Object key)
/*     */     {
/* 562 */       super();
/*     */     }
/*     */     
/*     */     PersistentTreeMap.Node addLeft(PersistentTreeMap.Node ins) {
/* 566 */       return ins.balanceLeft(this);
/*     */     }
/*     */     
/*     */     PersistentTreeMap.Node addRight(PersistentTreeMap.Node ins) {
/* 570 */       return ins.balanceRight(this);
/*     */     }
/*     */     
/*     */     PersistentTreeMap.Node removeLeft(PersistentTreeMap.Node del) {
/* 574 */       return PersistentTreeMap.balanceLeftDel(this.key, val(), del, right());
/*     */     }
/*     */     
/*     */     PersistentTreeMap.Node removeRight(PersistentTreeMap.Node del) {
/* 578 */       return PersistentTreeMap.balanceRightDel(this.key, val(), left(), del);
/*     */     }
/*     */     
/*     */     PersistentTreeMap.Node blacken() {
/* 582 */       return this;
/*     */     }
/*     */     
/*     */     PersistentTreeMap.Node redden() {
/* 586 */       return new PersistentTreeMap.Red(this.key);
/*     */     }
/*     */     
/*     */     PersistentTreeMap.Node replace(Object key, Object val, PersistentTreeMap.Node left, PersistentTreeMap.Node right) {
/* 590 */       return PersistentTreeMap.black(key, val, left, right);
/*     */     }
/*     */   }
/*     */   
/*     */   static class BlackVal extends PersistentTreeMap.Black
/*     */   {
/*     */     final Object val;
/*     */     
/*     */     public BlackVal(Object key, Object val) {
/* 599 */       super();
/* 600 */       this.val = val;
/*     */     }
/*     */     
/*     */     public Object val() {
/* 604 */       return this.val;
/*     */     }
/*     */     
/*     */     PersistentTreeMap.Node redden() {
/* 608 */       return new PersistentTreeMap.RedVal(this.key, this.val);
/*     */     }
/*     */   }
/*     */   
/*     */   static class BlackBranch extends PersistentTreeMap.Black
/*     */   {
/*     */     final PersistentTreeMap.Node left;
/*     */     final PersistentTreeMap.Node right;
/*     */     
/*     */     public BlackBranch(Object key, PersistentTreeMap.Node left, PersistentTreeMap.Node right)
/*     */     {
/* 619 */       super();
/* 620 */       this.left = left;
/* 621 */       this.right = right;
/*     */     }
/*     */     
/*     */     public PersistentTreeMap.Node left() {
/* 625 */       return this.left;
/*     */     }
/*     */     
/*     */     public PersistentTreeMap.Node right() {
/* 629 */       return this.right;
/*     */     }
/*     */     
/*     */     PersistentTreeMap.Node redden() {
/* 633 */       return new PersistentTreeMap.RedBranch(this.key, this.left, this.right);
/*     */     }
/*     */   }
/*     */   
/*     */   static class BlackBranchVal extends PersistentTreeMap.BlackBranch
/*     */   {
/*     */     final Object val;
/*     */     
/*     */     public BlackBranchVal(Object key, Object val, PersistentTreeMap.Node left, PersistentTreeMap.Node right) {
/* 642 */       super(left, right);
/* 643 */       this.val = val;
/*     */     }
/*     */     
/*     */     public Object val() {
/* 647 */       return this.val;
/*     */     }
/*     */     
/*     */     PersistentTreeMap.Node redden() {
/* 651 */       return new PersistentTreeMap.RedBranchVal(this.key, this.val, this.left, this.right);
/*     */     }
/*     */   }
/*     */   
/*     */   static class Red extends PersistentTreeMap.Node
/*     */   {
/*     */     public Red(Object key) {
/* 658 */       super();
/*     */     }
/*     */     
/*     */     PersistentTreeMap.Node addLeft(PersistentTreeMap.Node ins) {
/* 662 */       return PersistentTreeMap.red(this.key, val(), ins, right());
/*     */     }
/*     */     
/*     */     PersistentTreeMap.Node addRight(PersistentTreeMap.Node ins) {
/* 666 */       return PersistentTreeMap.red(this.key, val(), left(), ins);
/*     */     }
/*     */     
/*     */     PersistentTreeMap.Node removeLeft(PersistentTreeMap.Node del) {
/* 670 */       return PersistentTreeMap.red(this.key, val(), del, right());
/*     */     }
/*     */     
/*     */     PersistentTreeMap.Node removeRight(PersistentTreeMap.Node del) {
/* 674 */       return PersistentTreeMap.red(this.key, val(), left(), del);
/*     */     }
/*     */     
/*     */     PersistentTreeMap.Node blacken() {
/* 678 */       return new PersistentTreeMap.Black(this.key);
/*     */     }
/*     */     
/*     */     PersistentTreeMap.Node redden() {
/* 682 */       throw new UnsupportedOperationException("Invariant violation");
/*     */     }
/*     */     
/*     */     PersistentTreeMap.Node replace(Object key, Object val, PersistentTreeMap.Node left, PersistentTreeMap.Node right) {
/* 686 */       return PersistentTreeMap.red(key, val, left, right);
/*     */     }
/*     */   }
/*     */   
/*     */   static class RedVal extends PersistentTreeMap.Red
/*     */   {
/*     */     final Object val;
/*     */     
/*     */     public RedVal(Object key, Object val) {
/* 695 */       super();
/* 696 */       this.val = val;
/*     */     }
/*     */     
/*     */     public Object val() {
/* 700 */       return this.val;
/*     */     }
/*     */     
/*     */     PersistentTreeMap.Node blacken() {
/* 704 */       return new PersistentTreeMap.BlackVal(this.key, this.val);
/*     */     }
/*     */   }
/*     */   
/*     */   static class RedBranch extends PersistentTreeMap.Red
/*     */   {
/*     */     final PersistentTreeMap.Node left;
/*     */     final PersistentTreeMap.Node right;
/*     */     
/*     */     public RedBranch(Object key, PersistentTreeMap.Node left, PersistentTreeMap.Node right)
/*     */     {
/* 715 */       super();
/* 716 */       this.left = left;
/* 717 */       this.right = right;
/*     */     }
/*     */     
/*     */     public PersistentTreeMap.Node left() {
/* 721 */       return this.left;
/*     */     }
/*     */     
/*     */     public PersistentTreeMap.Node right() {
/* 725 */       return this.right;
/*     */     }
/*     */     
/*     */     PersistentTreeMap.Node balanceLeft(PersistentTreeMap.Node parent) {
/* 729 */       if ((this.left instanceof PersistentTreeMap.Red))
/* 730 */         return PersistentTreeMap.red(this.key, val(), this.left.blacken(), PersistentTreeMap.black(parent.key, parent.val(), this.right, parent.right()));
/* 731 */       if ((this.right instanceof PersistentTreeMap.Red)) {
/* 732 */         return PersistentTreeMap.red(this.right.key, this.right.val(), PersistentTreeMap.black(this.key, val(), this.left, this.right.left()), PersistentTreeMap.black(parent.key, parent.val(), this.right.right(), parent.right()));
/*     */       }
/*     */       
/* 735 */       return super.balanceLeft(parent);
/*     */     }
/*     */     
/*     */     PersistentTreeMap.Node balanceRight(PersistentTreeMap.Node parent)
/*     */     {
/* 740 */       if ((this.right instanceof PersistentTreeMap.Red))
/* 741 */         return PersistentTreeMap.red(this.key, val(), PersistentTreeMap.black(parent.key, parent.val(), parent.left(), this.left), this.right.blacken());
/* 742 */       if ((this.left instanceof PersistentTreeMap.Red)) {
/* 743 */         return PersistentTreeMap.red(this.left.key, this.left.val(), PersistentTreeMap.black(parent.key, parent.val(), parent.left(), this.left.left()), PersistentTreeMap.black(this.key, val(), this.left.right(), this.right));
/*     */       }
/*     */       
/* 746 */       return super.balanceRight(parent);
/*     */     }
/*     */     
/*     */     PersistentTreeMap.Node blacken() {
/* 750 */       return new PersistentTreeMap.BlackBranch(this.key, this.left, this.right);
/*     */     }
/*     */   }
/*     */   
/*     */   static class RedBranchVal extends PersistentTreeMap.RedBranch
/*     */   {
/*     */     final Object val;
/*     */     
/*     */     public RedBranchVal(Object key, Object val, PersistentTreeMap.Node left, PersistentTreeMap.Node right)
/*     */     {
/* 760 */       super(left, right);
/* 761 */       this.val = val;
/*     */     }
/*     */     
/*     */     public Object val() {
/* 765 */       return this.val;
/*     */     }
/*     */     
/*     */     PersistentTreeMap.Node blacken() {
/* 769 */       return new PersistentTreeMap.BlackBranchVal(this.key, this.val, this.left, this.right);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class Seq extends ASeq
/*     */   {
/*     */     final ISeq stack;
/*     */     final boolean asc;
/*     */     final int cnt;
/*     */     
/*     */     public Seq(ISeq stack, boolean asc) {
/* 780 */       this.stack = stack;
/* 781 */       this.asc = asc;
/* 782 */       this.cnt = -1;
/*     */     }
/*     */     
/*     */     public Seq(ISeq stack, boolean asc, int cnt) {
/* 786 */       this.stack = stack;
/* 787 */       this.asc = asc;
/* 788 */       this.cnt = cnt;
/*     */     }
/*     */     
/*     */     Seq(IPersistentMap meta, ISeq stack, boolean asc, int cnt) {
/* 792 */       super();
/* 793 */       this.stack = stack;
/* 794 */       this.asc = asc;
/* 795 */       this.cnt = cnt;
/*     */     }
/*     */     
/*     */     static Seq create(PersistentTreeMap.Node t, boolean asc, int cnt) {
/* 799 */       return new Seq(push(t, null, asc), asc, cnt);
/*     */     }
/*     */     
/*     */     static ISeq push(PersistentTreeMap.Node t, ISeq stack, boolean asc) {
/* 803 */       while (t != null)
/*     */       {
/* 805 */         stack = RT.cons(t, stack);
/* 806 */         t = asc ? t.left() : t.right();
/*     */       }
/* 808 */       return stack;
/*     */     }
/*     */     
/*     */     public Object first() {
/* 812 */       return this.stack.first();
/*     */     }
/*     */     
/*     */     public ISeq next() {
/* 816 */       PersistentTreeMap.Node t = (PersistentTreeMap.Node)this.stack.first();
/* 817 */       ISeq nextstack = push(this.asc ? t.right() : t.left(), this.stack.next(), this.asc);
/* 818 */       if (nextstack != null)
/*     */       {
/* 820 */         return new Seq(nextstack, this.asc, this.cnt - 1);
/*     */       }
/* 822 */       return null;
/*     */     }
/*     */     
/*     */     public int count() {
/* 826 */       if (this.cnt < 0)
/* 827 */         return super.count();
/* 828 */       return this.cnt;
/*     */     }
/*     */     
/*     */     public Obj withMeta(IPersistentMap meta) {
/* 832 */       return new Seq(meta, this.stack, this.asc, this.cnt);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class NodeIterator implements Iterator {
/* 837 */     Stack stack = new Stack();
/*     */     boolean asc;
/*     */     
/*     */     NodeIterator(PersistentTreeMap.Node t, boolean asc) {
/* 841 */       this.asc = asc;
/* 842 */       push(t);
/*     */     }
/*     */     
/*     */     void push(PersistentTreeMap.Node t) {
/* 846 */       while (t != null)
/*     */       {
/* 848 */         this.stack.push(t);
/* 849 */         t = this.asc ? t.left() : t.right();
/*     */       }
/*     */     }
/*     */     
/*     */     public boolean hasNext() {
/* 854 */       return !this.stack.isEmpty();
/*     */     }
/*     */     
/*     */     public Object next() {
/*     */       try {
/* 859 */         PersistentTreeMap.Node t = (PersistentTreeMap.Node)this.stack.pop();
/* 860 */         push(this.asc ? t.right() : t.left());
/* 861 */         return t;
/*     */       } catch (EmptyStackException e) {
/* 863 */         throw new NoSuchElementException();
/*     */       }
/*     */     }
/*     */     
/*     */     public void remove() {
/* 868 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */   
/*     */   static class KeyIterator implements Iterator {
/*     */     PersistentTreeMap.NodeIterator it;
/*     */     
/*     */     KeyIterator(PersistentTreeMap.NodeIterator it) {
/* 876 */       this.it = it;
/*     */     }
/*     */     
/*     */     public boolean hasNext() {
/* 880 */       return this.it.hasNext();
/*     */     }
/*     */     
/*     */     public Object next() {
/* 884 */       return ((PersistentTreeMap.Node)this.it.next()).key;
/*     */     }
/*     */     
/*     */     public void remove() {
/* 888 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */   
/*     */   static class ValIterator implements Iterator {
/*     */     PersistentTreeMap.NodeIterator it;
/*     */     
/*     */     ValIterator(PersistentTreeMap.NodeIterator it) {
/* 896 */       this.it = it;
/*     */     }
/*     */     
/*     */     public boolean hasNext() {
/* 900 */       return this.it.hasNext();
/*     */     }
/*     */     
/*     */     public Object next() {
/* 904 */       return ((PersistentTreeMap.Node)this.it.next()).val();
/*     */     }
/*     */     
/*     */     public void remove() {
/* 908 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\PersistentTreeMap.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */