/*    */ package clojure.lang;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class RecordIterator
/*    */   implements Iterator
/*    */ {
/* 19 */   int i = 0;
/*    */   final int basecnt;
/*    */   final ILookup rec;
/*    */   final IPersistentVector basefields;
/*    */   final Iterator extmap;
/*    */   
/*    */   public RecordIterator(ILookup rec, IPersistentVector basefields, Iterator extmap) {
/* 26 */     this.rec = rec;
/* 27 */     this.basefields = basefields;
/* 28 */     this.basecnt = basefields.count();
/* 29 */     this.extmap = extmap;
/*    */   }
/*    */   
/*    */   public boolean hasNext() {
/* 33 */     if (this.i < this.basecnt) {
/* 34 */       return true;
/*    */     }
/* 36 */     return this.extmap.hasNext();
/*    */   }
/*    */   
/*    */   public Object next()
/*    */   {
/* 41 */     if (this.i < this.basecnt) {
/* 42 */       Object k = this.basefields.nth(this.i);
/* 43 */       this.i += 1;
/* 44 */       return MapEntry.create(k, this.rec.valAt(k));
/*    */     }
/* 46 */     return this.extmap.next();
/*    */   }
/*    */   
/*    */   public void remove()
/*    */   {
/* 51 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\RecordIterator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */