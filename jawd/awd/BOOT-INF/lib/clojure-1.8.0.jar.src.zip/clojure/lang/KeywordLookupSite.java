/*    */ package clojure.lang;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class KeywordLookupSite
/*    */   implements ILookupSite, ILookupThunk
/*    */ {
/*    */   final Keyword k;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public KeywordLookupSite(Keyword k)
/*    */   {
/* 20 */     this.k = k;
/*    */   }
/*    */   
/*    */   public ILookupThunk fault(Object target) {
/* 24 */     if ((target instanceof IKeywordLookup))
/*    */     {
/* 26 */       return install(target);
/*    */     }
/* 28 */     if ((target instanceof ILookup))
/*    */     {
/* 30 */       return ilookupThunk(target.getClass());
/*    */     }
/* 32 */     return this;
/*    */   }
/*    */   
/*    */   public Object get(Object target) {
/* 36 */     if (((target instanceof IKeywordLookup)) || ((target instanceof ILookup)))
/* 37 */       return this;
/* 38 */     return RT.get(target, this.k);
/*    */   }
/*    */   
/*    */   private ILookupThunk ilookupThunk(final Class c) {
/* 42 */     new ILookupThunk() {
/*    */       public Object get(Object target) {
/* 44 */         if ((target != null) && (target.getClass() == c))
/* 45 */           return ((ILookup)target).valAt(KeywordLookupSite.this.k);
/* 46 */         return this;
/*    */       }
/*    */     };
/*    */   }
/*    */   
/*    */   private ILookupThunk install(Object target) {
/* 52 */     ILookupThunk t = ((IKeywordLookup)target).getLookupThunk(this.k);
/* 53 */     if (t != null)
/* 54 */       return t;
/* 55 */     return ilookupThunk(target.getClass());
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\KeywordLookupSite.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */