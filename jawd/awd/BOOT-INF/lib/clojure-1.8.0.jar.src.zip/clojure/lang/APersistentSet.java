/*     */ package clojure.lang;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class APersistentSet
/*     */   extends AFn
/*     */   implements IPersistentSet, Collection, Set, Serializable, IHashEq
/*     */ {
/*  21 */   int _hash = -1;
/*  22 */   int _hasheq = -1;
/*     */   final IPersistentMap impl;
/*     */   
/*     */   protected APersistentSet(IPersistentMap impl) {
/*  26 */     this.impl = impl;
/*     */   }
/*     */   
/*     */   public String toString() {
/*  30 */     return RT.printString(this);
/*     */   }
/*     */   
/*     */   public boolean contains(Object key) {
/*  34 */     return this.impl.containsKey(key);
/*     */   }
/*     */   
/*     */   public Object get(Object key) {
/*  38 */     return this.impl.valAt(key);
/*     */   }
/*     */   
/*     */   public int count() {
/*  42 */     return this.impl.count();
/*     */   }
/*     */   
/*     */   public ISeq seq() {
/*  46 */     return RT.keys(this.impl);
/*     */   }
/*     */   
/*     */   public Object invoke(Object arg1) {
/*  50 */     return get(arg1);
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj) {
/*  54 */     return setEquals(this, obj);
/*     */   }
/*     */   
/*     */   public static boolean setEquals(IPersistentSet s1, Object obj) {
/*  58 */     if (s1 == obj) return true;
/*  59 */     if (!(obj instanceof Set))
/*  60 */       return false;
/*  61 */     Set m = (Set)obj;
/*     */     
/*  63 */     if (m.size() != s1.count()) {
/*  64 */       return false;
/*     */     }
/*  66 */     for (Object aM : m)
/*     */     {
/*  68 */       if (!s1.contains(aM)) {
/*  69 */         return false;
/*     */       }
/*     */     }
/*  72 */     return true;
/*     */   }
/*     */   
/*     */   public boolean equiv(Object obj) {
/*  76 */     if (!(obj instanceof Set)) {
/*  77 */       return false;
/*     */     }
/*  79 */     Set m = (Set)obj;
/*     */     
/*  81 */     if (m.size() != size()) {
/*  82 */       return false;
/*     */     }
/*  84 */     for (Object aM : m)
/*     */     {
/*  86 */       if (!contains(aM)) {
/*  87 */         return false;
/*     */       }
/*     */     }
/*  90 */     return true;
/*     */   }
/*     */   
/*     */   public int hashCode() {
/*  94 */     if (this._hash == -1)
/*     */     {
/*     */ 
/*  97 */       int hash = 0;
/*  98 */       for (ISeq s = seq(); s != null; s = s.next())
/*     */       {
/* 100 */         Object e = s.first();
/*     */         
/* 102 */         hash += Util.hash(e);
/*     */       }
/* 104 */       this._hash = hash;
/*     */     }
/* 106 */     return this._hash;
/*     */   }
/*     */   
/*     */   public int hasheq() {
/* 110 */     if (this._hasheq == -1)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 118 */       this._hasheq = Murmur3.hashUnordered(this);
/*     */     }
/* 120 */     return this._hasheq;
/*     */   }
/*     */   
/*     */   public Object[] toArray() {
/* 124 */     return RT.seqToArray(seq());
/*     */   }
/*     */   
/*     */   public boolean add(Object o) {
/* 128 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public boolean remove(Object o) {
/* 132 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public boolean addAll(Collection c) {
/* 136 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void clear() {
/* 140 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public boolean retainAll(Collection c) {
/* 144 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public boolean removeAll(Collection c) {
/* 148 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public boolean containsAll(Collection c) {
/* 152 */     for (Object o : c)
/*     */     {
/* 154 */       if (!contains(o))
/* 155 */         return false;
/*     */     }
/* 157 */     return true;
/*     */   }
/*     */   
/*     */   public Object[] toArray(Object[] a) {
/* 161 */     return RT.seqToPassedArray(seq(), a);
/*     */   }
/*     */   
/*     */   public int size() {
/* 165 */     return count();
/*     */   }
/*     */   
/*     */   public boolean isEmpty() {
/* 169 */     return count() == 0;
/*     */   }
/*     */   
/*     */   public Iterator iterator() {
/* 173 */     if ((this.impl instanceof IMapIterable))
/* 174 */       return ((IMapIterable)this.impl).keyIterator();
/* 175 */     new Iterator() {
/* 176 */       private final Iterator iter = APersistentSet.this.impl.iterator();
/*     */       
/*     */       public boolean hasNext() {
/* 179 */         return this.iter.hasNext();
/*     */       }
/*     */       
/*     */       public Object next() {
/* 183 */         return ((IMapEntry)this.iter.next()).key();
/*     */       }
/*     */       
/*     */       public void remove() {
/* 187 */         throw new UnsupportedOperationException();
/*     */       }
/*     */     };
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\APersistentSet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */