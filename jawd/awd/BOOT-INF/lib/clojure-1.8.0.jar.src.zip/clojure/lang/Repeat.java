/*    */ package clojure.lang;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Repeat
/*    */   extends ASeq
/*    */   implements IReduce
/*    */ {
/*    */   private static final long INFINITE = -1L;
/*    */   
/*    */ 
/*    */   private final long count;
/*    */   
/*    */ 
/*    */   private final Object val;
/*    */   
/*    */ 
/*    */   private volatile ISeq _next;
/*    */   
/*    */ 
/*    */ 
/*    */   private Repeat(long count, Object val)
/*    */   {
/* 24 */     this.count = count;
/* 25 */     this.val = val;
/*    */   }
/*    */   
/*    */   private Repeat(IPersistentMap meta, long count, Object val) {
/* 29 */     super(meta);
/* 30 */     this.count = count;
/* 31 */     this.val = val;
/*    */   }
/*    */   
/*    */   public static Repeat create(Object val) {
/* 35 */     return new Repeat(-1L, val);
/*    */   }
/*    */   
/*    */   public static ISeq create(long count, Object val) {
/* 39 */     if (count <= 0L)
/* 40 */       return PersistentList.EMPTY;
/* 41 */     return new Repeat(count, val);
/*    */   }
/*    */   
/*    */   public Object first() {
/* 45 */     return this.val;
/*    */   }
/*    */   
/*    */   public ISeq next() {
/* 49 */     if (this._next == null) {
/* 50 */       if (this.count > 1L) {
/* 51 */         this._next = new Repeat(this.count - 1L, this.val);
/* 52 */       } else if (this.count == -1L)
/* 53 */         this._next = this;
/*    */     }
/* 55 */     return this._next;
/*    */   }
/*    */   
/*    */   public Repeat withMeta(IPersistentMap meta) {
/* 59 */     return new Repeat(meta, this.count, this.val);
/*    */   }
/*    */   
/*    */   public Object reduce(IFn f) {
/* 63 */     Object ret = this.val;
/* 64 */     if (this.count == -1L) {
/*    */       do {
/* 66 */         ret = f.invoke(ret, this.val);
/* 67 */       } while (!RT.isReduced(ret));
/* 68 */       return ((IDeref)ret).deref();
/*    */     }
/*    */     
/* 71 */     for (long i = 1L; i < this.count; i += 1L) {
/* 72 */       ret = f.invoke(ret, this.val);
/* 73 */       if (RT.isReduced(ret))
/* 74 */         return ((IDeref)ret).deref();
/*    */     }
/* 76 */     return ret;
/*    */   }
/*    */   
/*    */   public Object reduce(IFn f, Object start)
/*    */   {
/* 81 */     Object ret = start;
/* 82 */     if (this.count == -1L) {
/*    */       do {
/* 84 */         ret = f.invoke(ret, this.val);
/* 85 */       } while (!RT.isReduced(ret));
/* 86 */       return ((IDeref)ret).deref();
/*    */     }
/*    */     
/* 89 */     for (long i = 0L; i < this.count; i += 1L) {
/* 90 */       ret = f.invoke(ret, this.val);
/* 91 */       if (RT.isReduced(ret))
/* 92 */         return ((IDeref)ret).deref();
/*    */     }
/* 94 */     return ret;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\Repeat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */