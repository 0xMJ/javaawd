/*     */ package clojure.lang;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Iterator;
/*     */ import java.util.NoSuchElementException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LongRange
/*     */   extends ASeq
/*     */   implements Counted, IChunkedSeq, IReduce
/*     */ {
/*     */   private static final int CHUNK_SIZE = 32;
/*     */   final long start;
/*     */   final long end;
/*     */   final long step;
/*     */   final BoundsCheck boundsCheck;
/*     */   private volatile LongChunk _chunk;
/*     */   private volatile ISeq _chunkNext;
/*     */   private volatile ISeq _next;
/*     */   
/*     */   private static BoundsCheck positiveStep(long end)
/*     */   {
/*  40 */     new BoundsCheck() {
/*     */       public boolean exceededBounds(long val) {
/*  42 */         return val >= this.val$end;
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */   private static BoundsCheck negativeStep(long end) {
/*  48 */     new BoundsCheck() {
/*     */       public boolean exceededBounds(long val) {
/*  50 */         return val <= this.val$end;
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */   private LongRange(long start, long end, long step, BoundsCheck boundsCheck) {
/*  56 */     this.start = start;
/*  57 */     this.end = end;
/*  58 */     this.step = step;
/*  59 */     this.boundsCheck = boundsCheck;
/*     */   }
/*     */   
/*     */   private LongRange(long start, long end, long step, BoundsCheck boundsCheck, LongChunk chunk, ISeq chunkNext) {
/*  63 */     this.start = start;
/*  64 */     this.end = end;
/*  65 */     this.step = step;
/*  66 */     this.boundsCheck = boundsCheck;
/*  67 */     this._chunk = chunk;
/*  68 */     this._chunkNext = chunkNext;
/*     */   }
/*     */   
/*     */   private LongRange(IPersistentMap meta, long start, long end, long step, BoundsCheck boundsCheck, LongChunk chunk, ISeq chunkNext) {
/*  72 */     super(meta);
/*  73 */     this.start = start;
/*  74 */     this.end = end;
/*  75 */     this.step = step;
/*  76 */     this.boundsCheck = boundsCheck;
/*  77 */     this._chunk = chunk;
/*  78 */     this._chunkNext = chunkNext;
/*     */   }
/*     */   
/*     */   public static ISeq create(long end) {
/*  82 */     if (end > 0L)
/*  83 */       return new LongRange(0L, end, 1L, positiveStep(end));
/*  84 */     return PersistentList.EMPTY;
/*     */   }
/*     */   
/*     */   public static ISeq create(long start, long end) {
/*  88 */     if (start >= end)
/*  89 */       return PersistentList.EMPTY;
/*  90 */     return new LongRange(start, end, 1L, positiveStep(end));
/*     */   }
/*     */   
/*     */   public static ISeq create(long start, long end, long step) {
/*  94 */     if (step > 0L) {
/*  95 */       if (end <= start) return PersistentList.EMPTY;
/*  96 */       return new LongRange(start, end, step, positiveStep(end)); }
/*  97 */     if (step < 0L) {
/*  98 */       if (end >= start) return PersistentList.EMPTY;
/*  99 */       return new LongRange(start, end, step, negativeStep(end));
/*     */     }
/* 101 */     if (end == start) return PersistentList.EMPTY;
/* 102 */     return Repeat.create(Long.valueOf(start));
/*     */   }
/*     */   
/*     */   public Obj withMeta(IPersistentMap meta)
/*     */   {
/* 107 */     if (meta == this._meta)
/* 108 */       return this;
/* 109 */     return new LongRange(meta, this.start, this.end, this.step, this.boundsCheck, this._chunk, this._chunkNext);
/*     */   }
/*     */   
/*     */   public Object first() {
/* 113 */     return Long.valueOf(this.start);
/*     */   }
/*     */   
/*     */   public void forceChunk() {
/* 117 */     if (this._chunk != null)
/*     */       return;
/*     */     long count;
/*     */     try {
/* 121 */       count = rangeCount(this.start, this.end, this.step);
/*     */ 
/*     */     }
/*     */     catch (ArithmeticException e)
/*     */     {
/* 126 */       count = steppingCount(this.start, this.end, this.step);
/*     */     }
/*     */     
/* 129 */     if (count > 32L) {
/* 130 */       long nextStart = this.start + this.step * 32L;
/* 131 */       this._chunk = new LongChunk(this.start, this.step, 32);
/* 132 */       this._chunkNext = new LongRange(nextStart, this.end, this.step, this.boundsCheck);
/*     */     } else {
/* 134 */       this._chunk = new LongChunk(this.start, this.step, (int)count);
/*     */     }
/*     */   }
/*     */   
/*     */   public ISeq next() {
/* 139 */     if (this._next != null) {
/* 140 */       return this._next;
/*     */     }
/* 142 */     forceChunk();
/* 143 */     if (this._chunk.count() > 1) {
/* 144 */       LongChunk smallerChunk = this._chunk.dropFirst();
/* 145 */       this._next = new LongRange(smallerChunk.first(), this.end, this.step, this.boundsCheck, smallerChunk, this._chunkNext);
/* 146 */       return this._next;
/*     */     }
/* 148 */     return chunkedNext();
/*     */   }
/*     */   
/*     */   public IChunk chunkedFirst() {
/* 152 */     forceChunk();
/* 153 */     return this._chunk;
/*     */   }
/*     */   
/*     */   public ISeq chunkedNext() {
/* 157 */     return chunkedMore().seq();
/*     */   }
/*     */   
/*     */   public ISeq chunkedMore() {
/* 161 */     forceChunk();
/* 162 */     if (this._chunkNext == null)
/* 163 */       return PersistentList.EMPTY;
/* 164 */     return this._chunkNext;
/*     */   }
/*     */   
/*     */ 
/*     */   long steppingCount(long start, long end, long step)
/*     */   {
/* 170 */     long count = 1L;
/* 171 */     long s = start;
/* 172 */     for (;;) { if (count <= 32L) {
/*     */         try {
/* 174 */           s = Numbers.add(s, step);
/* 175 */           if (!this.boundsCheck.exceededBounds(s))
/*     */           {
/*     */ 
/* 178 */             count += 1L;
/*     */           }
/*     */         } catch (ArithmeticException e) {}
/*     */       }
/*     */     }
/* 183 */     return count;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   long rangeCount(long start, long end, long step)
/*     */   {
/* 191 */     return Numbers.add(Numbers.add(Numbers.minus(end, start), step), this.step > 0L ? -1L : 1L) / step;
/*     */   }
/*     */   
/*     */   public int count() {
/*     */     try {
/* 196 */       long c = rangeCount(this.start, this.end, this.step);
/* 197 */       if (c > 2147483647L) {
/* 198 */         return Numbers.throwIntOverflow();
/*     */       }
/* 200 */       return (int)c;
/*     */     }
/*     */     catch (ArithmeticException e)
/*     */     {
/* 204 */       Iterator iter = iterator();
/* 205 */       long count = 0L;
/* 206 */       while (iter.hasNext()) {
/* 207 */         iter.next();
/* 208 */         count += 1L;
/*     */       }
/*     */       
/* 211 */       if (count > 2147483647L) {
/* 212 */         return Numbers.throwIntOverflow();
/*     */       }
/* 214 */       return (int)count;
/*     */     }
/*     */   }
/*     */   
/*     */   public Object reduce(IFn f) {
/* 219 */     Object acc = Long.valueOf(this.start);
/* 220 */     long i = this.start + this.step;
/* 221 */     while (!this.boundsCheck.exceededBounds(i)) {
/* 222 */       acc = f.invoke(acc, Long.valueOf(i));
/* 223 */       if ((acc instanceof Reduced)) return ((Reduced)acc).deref();
/* 224 */       i += this.step;
/*     */     }
/* 226 */     return acc;
/*     */   }
/*     */   
/*     */   public Object reduce(IFn f, Object val) {
/* 230 */     Object acc = val;
/* 231 */     long i = this.start;
/*     */     do {
/* 233 */       acc = f.invoke(acc, Long.valueOf(i));
/* 234 */       if (RT.isReduced(acc)) return ((Reduced)acc).deref();
/* 235 */       i += this.step;
/* 236 */     } while (!this.boundsCheck.exceededBounds(i));
/* 237 */     return acc;
/*     */   }
/*     */   
/*     */ 
/* 241 */   public Iterator iterator() { return new LongRangeIterator(); }
/*     */   
/*     */   private static abstract interface BoundsCheck extends Serializable { public abstract boolean exceededBounds(long paramLong);
/*     */   }
/*     */   
/*     */   class LongRangeIterator implements Iterator { private long next;
/*     */     private boolean hasNext;
/*     */     
/* 249 */     public LongRangeIterator() { this.next = LongRange.this.start;
/* 250 */       this.hasNext = true;
/*     */     }
/*     */     
/*     */     public boolean hasNext() {
/* 254 */       return this.hasNext;
/*     */     }
/*     */     
/*     */     public Object next() {
/* 258 */       if (this.hasNext) {
/* 259 */         long ret = this.next;
/*     */         try {
/* 261 */           this.next = Numbers.add(this.next, LongRange.this.step);
/* 262 */           this.hasNext = (!LongRange.this.boundsCheck.exceededBounds(this.next));
/*     */         } catch (ArithmeticException e) {
/* 264 */           this.hasNext = false;
/*     */         }
/* 266 */         return Long.valueOf(ret);
/*     */       }
/* 268 */       throw new NoSuchElementException();
/*     */     }
/*     */     
/*     */     public void remove()
/*     */     {
/* 273 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */   
/*     */   private static class LongChunk implements IChunk, Serializable {
/*     */     final long start;
/*     */     final long step;
/*     */     final int count;
/*     */     
/*     */     public LongChunk(long start, long step, int count) {
/* 283 */       this.start = start;
/* 284 */       this.step = step;
/* 285 */       this.count = count;
/*     */     }
/*     */     
/*     */     public long first() {
/* 289 */       return this.start;
/*     */     }
/*     */     
/*     */     public Object nth(int i) {
/* 293 */       return Long.valueOf(this.start + i * this.step);
/*     */     }
/*     */     
/*     */     public Object nth(int i, Object notFound) {
/* 297 */       if ((i >= 0) && (i < this.count))
/* 298 */         return Long.valueOf(this.start + i * this.step);
/* 299 */       return notFound;
/*     */     }
/*     */     
/*     */     public int count() {
/* 303 */       return this.count;
/*     */     }
/*     */     
/*     */     public LongChunk dropFirst() {
/* 307 */       if (this.count <= 1)
/* 308 */         throw new IllegalStateException("dropFirst of empty chunk");
/* 309 */       return new LongChunk(this.start + this.step, this.step, this.count - 1);
/*     */     }
/*     */     
/*     */     public Object reduce(IFn f, Object init) {
/* 313 */       long x = this.start;
/* 314 */       Object ret = init;
/* 315 */       for (int i = 0; i < this.count; i++) {
/* 316 */         ret = f.invoke(ret, Long.valueOf(x));
/* 317 */         if (RT.isReduced(ret))
/* 318 */           return ret;
/* 319 */         x += this.step;
/*     */       }
/* 321 */       return ret;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\LongRange.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */