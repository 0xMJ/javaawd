/*     */ package clojure.lang;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Iterator;
/*     */ import java.util.NoSuchElementException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Range
/*     */   extends ASeq
/*     */   implements IChunkedSeq, IReduce
/*     */ {
/*     */   private static final int CHUNK_SIZE = 32;
/*     */   final Object end;
/*     */   final Object start;
/*     */   final Object step;
/*     */   final BoundsCheck boundsCheck;
/*     */   private volatile IChunk _chunk;
/*     */   private volatile ISeq _chunkNext;
/*     */   private volatile ISeq _next;
/*     */   
/*     */   private static BoundsCheck positiveStep(Object end)
/*     */   {
/*  38 */     new BoundsCheck() {
/*     */       public boolean exceededBounds(Object val) {
/*  40 */         return Numbers.gte(val, this.val$end);
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */   private static BoundsCheck negativeStep(Object end) {
/*  46 */     new BoundsCheck() {
/*     */       public boolean exceededBounds(Object val) {
/*  48 */         return Numbers.lte(val, this.val$end);
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */   private Range(Object start, Object end, Object step, BoundsCheck boundsCheck) {
/*  54 */     this.end = end;
/*  55 */     this.start = start;
/*  56 */     this.step = step;
/*  57 */     this.boundsCheck = boundsCheck;
/*     */   }
/*     */   
/*     */   private Range(Object start, Object end, Object step, BoundsCheck boundsCheck, IChunk chunk, ISeq chunkNext) {
/*  61 */     this.end = end;
/*  62 */     this.start = start;
/*  63 */     this.step = step;
/*  64 */     this.boundsCheck = boundsCheck;
/*  65 */     this._chunk = chunk;
/*  66 */     this._chunkNext = chunkNext;
/*     */   }
/*     */   
/*     */   private Range(IPersistentMap meta, Object start, Object end, Object step, BoundsCheck boundsCheck, IChunk chunk, ISeq chunkNext) {
/*  70 */     super(meta);
/*  71 */     this.end = end;
/*  72 */     this.start = start;
/*  73 */     this.step = step;
/*  74 */     this.boundsCheck = boundsCheck;
/*  75 */     this._chunk = chunk;
/*  76 */     this._chunkNext = chunkNext;
/*     */   }
/*     */   
/*     */   public static ISeq create(Object end) {
/*  80 */     if (Numbers.isPos(end))
/*  81 */       return new Range(Long.valueOf(0L), end, Long.valueOf(1L), positiveStep(end));
/*  82 */     return PersistentList.EMPTY;
/*     */   }
/*     */   
/*     */   public static ISeq create(Object start, Object end) {
/*  86 */     return create(start, end, Long.valueOf(1L));
/*     */   }
/*     */   
/*     */   public static ISeq create(Object start, Object end, Object step) {
/*  90 */     if (((Numbers.isPos(step)) && (Numbers.gt(start, end))) || ((Numbers.isNeg(step)) && (Numbers.gt(end, start))) || (Numbers.equiv(start, end)))
/*     */     {
/*     */ 
/*  93 */       return PersistentList.EMPTY; }
/*  94 */     if (Numbers.isZero(step))
/*  95 */       return Repeat.create(start);
/*  96 */     return new Range(start, end, step, Numbers.isPos(step) ? positiveStep(end) : negativeStep(end));
/*     */   }
/*     */   
/*     */   public Obj withMeta(IPersistentMap meta) {
/* 100 */     if (meta == this._meta)
/* 101 */       return this;
/* 102 */     return new Range(meta, this.end, this.start, this.step, this.boundsCheck, this._chunk, this._chunkNext);
/*     */   }
/*     */   
/*     */   public Object first() {
/* 106 */     return this.start;
/*     */   }
/*     */   
/*     */   public void forceChunk() {
/* 110 */     if (this._chunk != null) { return;
/*     */     }
/* 112 */     Object[] arr = new Object[32];
/* 113 */     int n = 0;
/* 114 */     Object val = this.start;
/* 115 */     while (n < 32) {
/* 116 */       arr[(n++)] = val;
/* 117 */       val = Numbers.addP(val, this.step);
/* 118 */       if (this.boundsCheck.exceededBounds(val))
/*     */       {
/* 120 */         this._chunk = new ArrayChunk(arr, 0, n);
/* 121 */         return;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 126 */     if (this.boundsCheck.exceededBounds(val)) {
/* 127 */       this._chunk = new ArrayChunk(arr, 0, 32);
/* 128 */       return;
/*     */     }
/*     */     
/*     */ 
/* 132 */     this._chunk = new ArrayChunk(arr, 0, 32);
/* 133 */     this._chunkNext = new Range(val, this.end, this.step, this.boundsCheck);
/*     */   }
/*     */   
/*     */   public ISeq next() {
/* 137 */     if (this._next != null) {
/* 138 */       return this._next;
/*     */     }
/* 140 */     forceChunk();
/* 141 */     if (this._chunk.count() > 1) {
/* 142 */       IChunk smallerChunk = this._chunk.dropFirst();
/* 143 */       this._next = new Range(smallerChunk.nth(0), this.end, this.step, this.boundsCheck, smallerChunk, this._chunkNext);
/* 144 */       return this._next;
/*     */     }
/* 146 */     return chunkedNext();
/*     */   }
/*     */   
/*     */   public IChunk chunkedFirst() {
/* 150 */     forceChunk();
/* 151 */     return this._chunk;
/*     */   }
/*     */   
/*     */   public ISeq chunkedNext() {
/* 155 */     return chunkedMore().seq();
/*     */   }
/*     */   
/*     */   public ISeq chunkedMore() {
/* 159 */     forceChunk();
/* 160 */     if (this._chunkNext == null)
/* 161 */       return PersistentList.EMPTY;
/* 162 */     return this._chunkNext;
/*     */   }
/*     */   
/*     */   public Object reduce(IFn f) {
/* 166 */     Object acc = this.start;
/* 167 */     Number i = Numbers.addP(this.start, this.step);
/* 168 */     while (!this.boundsCheck.exceededBounds(i)) {
/* 169 */       acc = f.invoke(acc, i);
/* 170 */       if (RT.isReduced(acc)) return ((Reduced)acc).deref();
/* 171 */       i = Numbers.addP(i, this.step);
/*     */     }
/* 173 */     return acc;
/*     */   }
/*     */   
/*     */   public Object reduce(IFn f, Object val) {
/* 177 */     Object acc = val;
/* 178 */     Object i = this.start;
/* 179 */     while (!this.boundsCheck.exceededBounds(i)) {
/* 180 */       acc = f.invoke(acc, i);
/* 181 */       if (RT.isReduced(acc)) return ((Reduced)acc).deref();
/* 182 */       i = Numbers.addP(i, this.step);
/*     */     }
/* 184 */     return acc;
/*     */   }
/*     */   
/*     */   public Iterator iterator() {
/* 188 */     return new RangeIterator();
/*     */   }
/*     */   
/*     */   private class RangeIterator implements Iterator {
/*     */     private Object next;
/*     */     
/*     */     public RangeIterator() {
/* 195 */       this.next = Range.this.start;
/*     */     }
/*     */     
/*     */     public boolean hasNext() {
/* 199 */       return !Range.this.boundsCheck.exceededBounds(this.next);
/*     */     }
/*     */     
/*     */     public Object next() {
/* 203 */       if (hasNext()) {
/* 204 */         Object ret = this.next;
/* 205 */         this.next = Numbers.addP(this.next, Range.this.step);
/* 206 */         return ret;
/*     */       }
/* 208 */       throw new NoSuchElementException();
/*     */     }
/*     */     
/*     */     public void remove()
/*     */     {
/* 213 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */   
/*     */   private static abstract interface BoundsCheck
/*     */     extends Serializable
/*     */   {
/*     */     public abstract boolean exceededBounds(Object paramObject);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\Range.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */