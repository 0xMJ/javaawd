/*     */ package clojure.lang;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.TreeMap;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.CountDownLatch;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*     */ import java.util.concurrent.locks.ReentrantReadWriteLock.ReadLock;
/*     */ import java.util.concurrent.locks.ReentrantReadWriteLock.WriteLock;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LockingTransaction
/*     */ {
/*     */   public static final int RETRY_LIMIT = 10000;
/*     */   public static final int LOCK_WAIT_MSECS = 100;
/*     */   public static final long BARGE_WAIT_NANOS = 10000000L;
/*     */   static final int RUNNING = 0;
/*     */   static final int COMMITTING = 1;
/*     */   static final int RETRY = 2;
/*     */   static final int KILLED = 3;
/*     */   static final int COMMITTED = 4;
/*  36 */   static final ThreadLocal<LockingTransaction> transaction = new ThreadLocal();
/*     */   
/*     */   static class RetryEx extends Error
/*     */   {}
/*     */   
/*     */   static class AbortException extends Exception
/*     */   {}
/*     */   
/*     */   public static class Info
/*     */   {
/*     */     final AtomicInteger status;
/*     */     final long startPoint;
/*     */     final CountDownLatch latch;
/*     */     
/*     */     public Info(int status, long startPoint)
/*     */     {
/*  52 */       this.status = new AtomicInteger(status);
/*  53 */       this.startPoint = startPoint;
/*  54 */       this.latch = new CountDownLatch(1);
/*     */     }
/*     */     
/*     */     public boolean running() {
/*  58 */       int s = this.status.get();
/*  59 */       return (s == 0) || (s == 1);
/*     */     }
/*     */   }
/*     */   
/*     */   static class CFn {
/*     */     final IFn fn;
/*     */     final ISeq args;
/*     */     
/*     */     public CFn(IFn fn, ISeq args) {
/*  68 */       this.fn = fn;
/*  69 */       this.args = args;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*  74 */   private static final AtomicLong lastPoint = new AtomicLong();
/*     */   Info info;
/*     */   
/*  77 */   void getReadPoint() { this.readPoint = lastPoint.incrementAndGet(); }
/*     */   
/*     */   long readPoint;
/*     */   
/*  81 */   long getCommitPoint() { return lastPoint.incrementAndGet(); }
/*     */   
/*     */   long startPoint;
/*     */   
/*  85 */   void stop(int status) { if (this.info != null)
/*     */     {
/*  87 */       synchronized (this.info)
/*     */       {
/*  89 */         this.info.status.set(status);
/*  90 */         this.info.latch.countDown();
/*     */       }
/*  92 */       this.info = null;
/*  93 */       this.vals.clear();
/*  94 */       this.sets.clear();
/*  95 */       this.commutes.clear();
/*     */     } }
/*     */   
/*     */   long startTime;
/*     */   final RetryEx retryex;
/*     */   final ArrayList<Agent.Action> actions;
/*     */   final HashMap<Ref, Object> vals;
/*     */   final HashSet<Ref> sets;
/*     */   final TreeMap<Ref, ArrayList<CFn>> commutes;
/*     */   final HashSet<Ref> ensures;
/* 105 */   public LockingTransaction() { this.retryex = new RetryEx();
/* 106 */     this.actions = new ArrayList();
/* 107 */     this.vals = new HashMap();
/* 108 */     this.sets = new HashSet();
/* 109 */     this.commutes = new TreeMap();
/*     */     
/* 111 */     this.ensures = new HashSet();
/*     */   }
/*     */   
/*     */   void tryWriteLock(Ref ref)
/*     */   {
/*     */     try {
/* 117 */       if (!ref.lock.writeLock().tryLock(100L, TimeUnit.MILLISECONDS)) {
/* 118 */         throw this.retryex;
/*     */       }
/*     */     }
/*     */     catch (InterruptedException e) {
/* 122 */       throw this.retryex;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   Object lock(Ref ref)
/*     */   {
/* 129 */     releaseIfEnsured(ref);
/*     */     
/* 131 */     boolean unlocked = true;
/*     */     try
/*     */     {
/* 134 */       tryWriteLock(ref);
/* 135 */       unlocked = false;
/*     */       
/* 137 */       if ((ref.tvals != null) && (ref.tvals.point > this.readPoint))
/* 138 */         throw this.retryex;
/* 139 */       Info refinfo = ref.tinfo;
/*     */       
/*     */       Object localObject1;
/* 142 */       if ((refinfo != null) && (refinfo != this.info) && (refinfo.running()))
/*     */       {
/* 144 */         if (!barge(refinfo))
/*     */         {
/* 146 */           ref.lock.writeLock().unlock();
/* 147 */           unlocked = true;
/* 148 */           return blockAndBail(refinfo);
/*     */         }
/*     */       }
/* 151 */       ref.tinfo = this.info;
/* 152 */       return ref.tvals == null ? null : ref.tvals.val;
/*     */     }
/*     */     finally
/*     */     {
/* 156 */       if (!unlocked) {
/* 157 */         ref.lock.writeLock().unlock();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private Object blockAndBail(Info refinfo) {
/* 163 */     stop(2);
/*     */     try
/*     */     {
/* 166 */       refinfo.latch.await(100L, TimeUnit.MILLISECONDS);
/*     */     }
/*     */     catch (InterruptedException e) {}
/*     */     
/*     */ 
/*     */ 
/* 172 */     throw this.retryex;
/*     */   }
/*     */   
/*     */   private void releaseIfEnsured(Ref ref) {
/* 176 */     if (this.ensures.contains(ref))
/*     */     {
/* 178 */       this.ensures.remove(ref);
/* 179 */       ref.lock.readLock().unlock();
/*     */     }
/*     */   }
/*     */   
/*     */   void abort() throws LockingTransaction.AbortException {
/* 184 */     stop(3);
/* 185 */     throw new AbortException();
/*     */   }
/*     */   
/*     */   private boolean bargeTimeElapsed() {
/* 189 */     return System.nanoTime() - this.startTime > 10000000L;
/*     */   }
/*     */   
/*     */   private boolean barge(Info refinfo) {
/* 193 */     boolean barged = false;
/*     */     
/*     */ 
/* 196 */     if ((bargeTimeElapsed()) && (this.startPoint < refinfo.startPoint))
/*     */     {
/* 198 */       barged = refinfo.status.compareAndSet(0, 3);
/* 199 */       if (barged)
/* 200 */         refinfo.latch.countDown();
/*     */     }
/* 202 */     return barged;
/*     */   }
/*     */   
/*     */   static LockingTransaction getEx() {
/* 206 */     LockingTransaction t = (LockingTransaction)transaction.get();
/* 207 */     if ((t == null) || (t.info == null))
/* 208 */       throw new IllegalStateException("No transaction running");
/* 209 */     return t;
/*     */   }
/*     */   
/*     */   public static boolean isRunning() {
/* 213 */     return getRunning() != null;
/*     */   }
/*     */   
/*     */   static LockingTransaction getRunning() {
/* 217 */     LockingTransaction t = (LockingTransaction)transaction.get();
/* 218 */     if ((t == null) || (t.info == null))
/* 219 */       return null;
/* 220 */     return t;
/*     */   }
/*     */   
/*     */   public static Object runInTransaction(Callable fn) throws Exception {
/* 224 */     LockingTransaction t = (LockingTransaction)transaction.get();
/*     */     Object ret;
/* 226 */     if (t == null) {
/* 227 */       transaction.set(t = new LockingTransaction());
/*     */       try {
/* 229 */         ret = t.run(fn);
/*     */       } finally { Object ret;
/* 231 */         transaction.remove();
/*     */       }
/*     */     } else { Object ret;
/* 234 */       if (t.info != null) {
/* 235 */         ret = fn.call();
/*     */       } else {
/* 237 */         ret = t.run(fn);
/*     */       }
/*     */     }
/*     */     
/* 241 */     return ret;
/*     */   }
/*     */   
/*     */   static class Notify {
/*     */     public final Ref ref;
/*     */     public final Object oldval;
/*     */     public final Object newval;
/*     */     
/*     */     Notify(Ref ref, Object oldval, Object newval) {
/* 250 */       this.ref = ref;
/* 251 */       this.oldval = oldval;
/* 252 */       this.newval = newval;
/*     */     }
/*     */   }
/*     */   
/*     */   Object run(Callable fn) throws Exception {
/* 257 */     boolean done = false;
/* 258 */     Object ret = null;
/* 259 */     ArrayList<Ref> locked = new ArrayList();
/* 260 */     ArrayList<Notify> notify = new ArrayList();
/*     */     
/* 262 */     for (int i = 0; (!done) && (i < 10000); i++)
/*     */     {
/*     */       try
/*     */       {
/* 266 */         getReadPoint();
/* 267 */         if (i == 0)
/*     */         {
/* 269 */           this.startPoint = this.readPoint;
/* 270 */           this.startTime = System.nanoTime();
/*     */         }
/* 272 */         this.info = new Info(0, this.startPoint);
/* 273 */         ret = fn.call();
/*     */         
/* 275 */         if (this.info.status.compareAndSet(0, 1))
/*     */         {
/* 277 */           for (Map.Entry<Ref, ArrayList<CFn>> e : this.commutes.entrySet())
/*     */           {
/* 279 */             ref = (Ref)e.getKey();
/* 280 */             if (!this.sets.contains(ref))
/*     */             {
/* 282 */               boolean wasEnsured = this.ensures.contains(ref);
/*     */               
/* 284 */               releaseIfEnsured(ref);
/* 285 */               tryWriteLock(ref);
/* 286 */               locked.add(ref);
/* 287 */               if ((wasEnsured) && (ref.tvals != null) && (ref.tvals.point > this.readPoint)) {
/* 288 */                 throw this.retryex;
/*     */               }
/* 290 */               Info refinfo = ref.tinfo;
/* 291 */               if ((refinfo != null) && (refinfo != this.info) && (refinfo.running()))
/*     */               {
/* 293 */                 if (!barge(refinfo))
/* 294 */                   throw this.retryex;
/*     */               }
/* 296 */               Object val = ref.tvals == null ? null : ref.tvals.val;
/* 297 */               this.vals.put(ref, val);
/* 298 */               for (CFn f : (ArrayList)e.getValue())
/*     */               {
/* 300 */                 this.vals.put(ref, f.fn.applyTo(RT.cons(this.vals.get(ref), f.args))); }
/*     */             } }
/*     */           Ref ref;
/* 303 */           for (Ref ref : this.sets)
/*     */           {
/* 305 */             tryWriteLock(ref);
/* 306 */             locked.add(ref);
/*     */           }
/*     */           
/*     */ 
/* 310 */           for (Map.Entry<Ref, Object> e : this.vals.entrySet())
/*     */           {
/* 312 */             Ref ref = (Ref)e.getKey();
/* 313 */             ref.validate(ref.getValidator(), e.getValue());
/*     */           }
/*     */           
/*     */ 
/*     */ 
/* 318 */           long commitPoint = getCommitPoint();
/* 319 */           for (Map.Entry<Ref, Object> e : this.vals.entrySet())
/*     */           {
/* 321 */             Ref ref = (Ref)e.getKey();
/* 322 */             Object oldval = ref.tvals == null ? null : ref.tvals.val;
/* 323 */             Object newval = e.getValue();
/* 324 */             int hcount = ref.histCount();
/*     */             
/* 326 */             if (ref.tvals == null)
/*     */             {
/* 328 */               ref.tvals = new Ref.TVal(newval, commitPoint);
/*     */             }
/* 330 */             else if (((ref.faults.get() > 0) && (hcount < ref.maxHistory)) || (hcount < ref.minHistory))
/*     */             {
/*     */ 
/* 333 */               ref.tvals = new Ref.TVal(newval, commitPoint, ref.tvals);
/* 334 */               ref.faults.set(0);
/*     */             }
/*     */             else
/*     */             {
/* 338 */               ref.tvals = ref.tvals.next;
/* 339 */               ref.tvals.val = newval;
/* 340 */               ref.tvals.point = commitPoint;
/*     */             }
/* 342 */             if (ref.getWatches().count() > 0) {
/* 343 */               notify.add(new Notify(ref, oldval, newval));
/*     */             }
/*     */           }
/* 346 */           done = true;
/* 347 */           this.info.status.set(4); } } catch (RetryEx retry) {}finally { int k;
/*     */         Iterator i$;
/*     */         Ref r;
/*     */         Iterator i$;
/*     */         Notify n;
/*     */         Iterator i$;
/*     */         Agent.Action action;
/*     */         int k;
/*     */         Iterator i$;
/* 356 */         Ref r; Iterator i$; Notify n; Iterator i$; Agent.Action action; for (int k = locked.size() - 1; k >= 0; k--)
/*     */         {
/* 358 */           ((Ref)locked.get(k)).lock.writeLock().unlock();
/*     */         }
/* 360 */         locked.clear();
/* 361 */         for (Ref r : this.ensures)
/*     */         {
/* 363 */           r.lock.readLock().unlock();
/*     */         }
/* 365 */         this.ensures.clear();
/* 366 */         stop(done ? 4 : 2);
/*     */         try
/*     */         {
/* 369 */           if (done)
/*     */           {
/* 371 */             for (Notify n : notify)
/*     */             {
/* 373 */               n.ref.notifyWatches(n.oldval, n.newval);
/*     */             }
/* 375 */             for (Agent.Action action : this.actions)
/*     */             {
/* 377 */               Agent.dispatchAction(action);
/*     */             }
/*     */           }
/*     */         }
/*     */         finally
/*     */         {
/* 383 */           notify.clear();
/* 384 */           this.actions.clear();
/*     */         }
/*     */       }
/*     */     }
/* 388 */     if (!done)
/* 389 */       throw Util.runtimeException("Transaction failed after reaching retry limit");
/* 390 */     return ret;
/*     */   }
/*     */   
/*     */   public void enqueue(Agent.Action action) {
/* 394 */     this.actions.add(action);
/*     */   }
/*     */   
/*     */   Object doGet(Ref ref) {
/* 398 */     if (!this.info.running())
/* 399 */       throw this.retryex;
/* 400 */     if (this.vals.containsKey(ref)) {
/* 401 */       return this.vals.get(ref);
/*     */     }
/*     */     try {
/* 404 */       ref.lock.readLock().lock();
/* 405 */       if (ref.tvals == null)
/* 406 */         throw new IllegalStateException(ref.toString() + " is unbound.");
/* 407 */       Ref.TVal ver = ref.tvals;
/*     */       do
/*     */       {
/* 410 */         if (ver.point <= this.readPoint)
/* 411 */           return ver.val;
/* 412 */       } while ((ver = ver.prior) != ref.tvals);
/*     */     }
/*     */     finally
/*     */     {
/* 416 */       ref.lock.readLock().unlock();
/*     */     }
/*     */     
/* 419 */     ref.faults.incrementAndGet();
/* 420 */     throw this.retryex;
/*     */   }
/*     */   
/*     */   Object doSet(Ref ref, Object val)
/*     */   {
/* 425 */     if (!this.info.running())
/* 426 */       throw this.retryex;
/* 427 */     if (this.commutes.containsKey(ref))
/* 428 */       throw new IllegalStateException("Can't set after commute");
/* 429 */     if (!this.sets.contains(ref))
/*     */     {
/* 431 */       this.sets.add(ref);
/* 432 */       lock(ref);
/*     */     }
/* 434 */     this.vals.put(ref, val);
/* 435 */     return val;
/*     */   }
/*     */   
/*     */   void doEnsure(Ref ref) {
/* 439 */     if (!this.info.running())
/* 440 */       throw this.retryex;
/* 441 */     if (this.ensures.contains(ref))
/* 442 */       return;
/* 443 */     ref.lock.readLock().lock();
/*     */     
/*     */ 
/* 446 */     if ((ref.tvals != null) && (ref.tvals.point > this.readPoint)) {
/* 447 */       ref.lock.readLock().unlock();
/* 448 */       throw this.retryex;
/*     */     }
/*     */     
/* 451 */     Info refinfo = ref.tinfo;
/*     */     
/*     */ 
/* 454 */     if ((refinfo != null) && (refinfo.running()))
/*     */     {
/* 456 */       ref.lock.readLock().unlock();
/*     */       
/* 458 */       if (refinfo != this.info)
/*     */       {
/* 460 */         blockAndBail(refinfo);
/*     */       }
/*     */     }
/*     */     else {
/* 464 */       this.ensures.add(ref);
/*     */     }
/*     */   }
/*     */   
/* 468 */   Object doCommute(Ref ref, IFn fn, ISeq args) { if (!this.info.running())
/* 469 */       throw this.retryex;
/* 470 */     if (!this.vals.containsKey(ref))
/*     */     {
/* 472 */       Object val = null;
/*     */       try
/*     */       {
/* 475 */         ref.lock.readLock().lock();
/* 476 */         val = ref.tvals == null ? null : ref.tvals.val;
/*     */       }
/*     */       finally
/*     */       {
/* 480 */         ref.lock.readLock().unlock();
/*     */       }
/* 482 */       this.vals.put(ref, val);
/*     */     }
/* 484 */     ArrayList<CFn> fns = (ArrayList)this.commutes.get(ref);
/* 485 */     if (fns == null)
/* 486 */       this.commutes.put(ref, fns = new ArrayList());
/* 487 */     fns.add(new CFn(fn, args));
/* 488 */     Object ret = fn.applyTo(RT.cons(this.vals.get(ref), args));
/* 489 */     this.vals.put(ref, ret);
/* 490 */     return ret;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\LockingTransaction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */