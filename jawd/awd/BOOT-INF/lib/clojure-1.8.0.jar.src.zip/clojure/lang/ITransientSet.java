package clojure.lang;

public abstract interface ITransientSet
  extends ITransientCollection, Counted
{
  public abstract ITransientSet disjoin(Object paramObject);
  
  public abstract boolean contains(Object paramObject);
  
  public abstract Object get(Object paramObject);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\ITransientSet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */