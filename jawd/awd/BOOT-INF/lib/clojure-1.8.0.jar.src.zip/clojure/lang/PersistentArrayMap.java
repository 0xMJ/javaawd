/*     */ package clojure.lang;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.NoSuchElementException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PersistentArrayMap
/*     */   extends APersistentMap
/*     */   implements IObj, IEditableCollection, IMapIterable, IKVReduce
/*     */ {
/*     */   final Object[] array;
/*     */   static final int HASHTABLE_THRESHOLD = 16;
/*  35 */   public static final PersistentArrayMap EMPTY = new PersistentArrayMap();
/*     */   private final IPersistentMap _meta;
/*     */   
/*     */   public static IPersistentMap create(Map other) {
/*  39 */     ITransientMap ret = EMPTY.asTransient();
/*  40 */     for (Object o : other.entrySet())
/*     */     {
/*  42 */       Map.Entry e = (Map.Entry)o;
/*  43 */       ret = ret.assoc(e.getKey(), e.getValue());
/*     */     }
/*  45 */     return ret.persistent();
/*     */   }
/*     */   
/*     */   protected PersistentArrayMap() {
/*  49 */     this.array = new Object[0];
/*  50 */     this._meta = null;
/*     */   }
/*     */   
/*     */   public PersistentArrayMap withMeta(IPersistentMap meta) {
/*  54 */     return new PersistentArrayMap(meta, this.array);
/*     */   }
/*     */   
/*     */   PersistentArrayMap create(Object... init) {
/*  58 */     return new PersistentArrayMap(meta(), init);
/*     */   }
/*     */   
/*     */   IPersistentMap createHT(Object[] init) {
/*  62 */     return PersistentHashMap.create(meta(), init);
/*     */   }
/*     */   
/*     */   public static PersistentArrayMap createWithCheck(Object[] init) {
/*  66 */     for (int i = 0; i < init.length; i += 2)
/*     */     {
/*  68 */       for (int j = i + 2; j < init.length; j += 2)
/*     */       {
/*  70 */         if (equalKey(init[i], init[j]))
/*  71 */           throw new IllegalArgumentException("Duplicate key: " + init[i]);
/*     */       }
/*     */     }
/*  74 */     return new PersistentArrayMap(init);
/*     */   }
/*     */   
/*     */   public static PersistentArrayMap createAsIfByAssoc(Object[] init) {
/*  78 */     if ((init.length & 0x1) == 1) {
/*  79 */       throw new IllegalArgumentException(String.format("No value supplied for key: %s", new Object[] { init[(init.length - 1)] }));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  84 */     int n = 0;
/*  85 */     for (int i = 0; i < init.length; i += 2)
/*     */     {
/*  87 */       boolean duplicateKey = false;
/*  88 */       for (int j = 0; j < i; j += 2)
/*     */       {
/*  90 */         if (equalKey(init[i], init[j]))
/*     */         {
/*  92 */           duplicateKey = true;
/*  93 */           break;
/*     */         }
/*     */       }
/*  96 */       if (!duplicateKey)
/*  97 */         n += 2;
/*     */     }
/*  99 */     if (n < init.length)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 106 */       Object[] nodups = new Object[n];
/* 107 */       int m = 0;
/* 108 */       for (int i = 0; i < init.length; i += 2)
/*     */       {
/* 110 */         boolean duplicateKey = false;
/* 111 */         for (int j = 0; j < m; j += 2)
/*     */         {
/* 113 */           if (equalKey(init[i], nodups[j]))
/*     */           {
/* 115 */             duplicateKey = true;
/* 116 */             break;
/*     */           }
/*     */         }
/* 119 */         if (!duplicateKey)
/*     */         {
/*     */ 
/* 122 */           for (int j = init.length - 2; j >= i; j -= 2)
/*     */           {
/* 124 */             if (equalKey(init[i], init[j])) {
/*     */               break;
/*     */             }
/*     */           }
/*     */           
/* 129 */           nodups[m] = init[i];
/* 130 */           nodups[(m + 1)] = init[(j + 1)];
/* 131 */           m += 2;
/*     */         }
/*     */       }
/* 134 */       if (m != n)
/* 135 */         throw new IllegalArgumentException("Internal error: m=" + m);
/* 136 */       init = nodups;
/*     */     }
/* 138 */     return new PersistentArrayMap(init);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public PersistentArrayMap(Object[] init)
/*     */   {
/* 146 */     this.array = init;
/* 147 */     this._meta = null;
/*     */   }
/*     */   
/*     */   public PersistentArrayMap(IPersistentMap meta, Object[] init)
/*     */   {
/* 152 */     this._meta = meta;
/* 153 */     this.array = init;
/*     */   }
/*     */   
/*     */   public int count() {
/* 157 */     return this.array.length / 2;
/*     */   }
/*     */   
/*     */   public boolean containsKey(Object key) {
/* 161 */     return indexOf(key) >= 0;
/*     */   }
/*     */   
/*     */   public IMapEntry entryAt(Object key) {
/* 165 */     int i = indexOf(key);
/* 166 */     if (i >= 0)
/* 167 */       return MapEntry.create(this.array[i], this.array[(i + 1)]);
/* 168 */     return null;
/*     */   }
/*     */   
/*     */   public IPersistentMap assocEx(Object key, Object val) {
/* 172 */     int i = indexOf(key);
/*     */     
/* 174 */     if (i >= 0)
/*     */     {
/* 176 */       throw Util.runtimeException("Key already present");
/*     */     }
/*     */     
/*     */ 
/* 180 */     if (this.array.length > 16)
/* 181 */       return createHT(this.array).assocEx(key, val);
/* 182 */     Object[] newArray = new Object[this.array.length + 2];
/* 183 */     if (this.array.length > 0)
/* 184 */       System.arraycopy(this.array, 0, newArray, 2, this.array.length);
/* 185 */     newArray[0] = key;
/* 186 */     newArray[1] = val;
/*     */     
/* 188 */     return create(newArray);
/*     */   }
/*     */   
/*     */   public IPersistentMap assoc(Object key, Object val) {
/* 192 */     int i = indexOf(key);
/*     */     Object[] newArray;
/* 194 */     if (i >= 0)
/*     */     {
/* 196 */       if (this.array[(i + 1)] == val)
/* 197 */         return this;
/* 198 */       Object[] newArray = (Object[])this.array.clone();
/* 199 */       newArray[(i + 1)] = val;
/*     */     }
/*     */     else
/*     */     {
/* 203 */       if (this.array.length > 16)
/* 204 */         return createHT(this.array).assoc(key, val);
/* 205 */       newArray = new Object[this.array.length + 2];
/* 206 */       if (this.array.length > 0)
/* 207 */         System.arraycopy(this.array, 0, newArray, 0, this.array.length);
/* 208 */       newArray[(newArray.length - 2)] = key;
/* 209 */       newArray[(newArray.length - 1)] = val;
/*     */     }
/* 211 */     return create(newArray);
/*     */   }
/*     */   
/*     */   public IPersistentMap without(Object key) {
/* 215 */     int i = indexOf(key);
/* 216 */     if (i >= 0)
/*     */     {
/* 218 */       int newlen = this.array.length - 2;
/* 219 */       if (newlen == 0)
/* 220 */         return empty();
/* 221 */       Object[] newArray = new Object[newlen];
/* 222 */       System.arraycopy(this.array, 0, newArray, 0, i);
/* 223 */       System.arraycopy(this.array, i + 2, newArray, i, newlen - i);
/* 224 */       return create(newArray);
/*     */     }
/*     */     
/* 227 */     return this;
/*     */   }
/*     */   
/*     */   public IPersistentMap empty() {
/* 231 */     return EMPTY.withMeta(meta());
/*     */   }
/*     */   
/*     */   public final Object valAt(Object key, Object notFound) {
/* 235 */     int i = indexOf(key);
/* 236 */     if (i >= 0)
/* 237 */       return this.array[(i + 1)];
/* 238 */     return notFound;
/*     */   }
/*     */   
/*     */   public Object valAt(Object key) {
/* 242 */     return valAt(key, null);
/*     */   }
/*     */   
/*     */   public int capacity() {
/* 246 */     return count();
/*     */   }
/*     */   
/*     */   private int indexOfObject(Object key) {
/* 250 */     Util.EquivPred ep = Util.equivPred(key);
/* 251 */     for (int i = 0; i < this.array.length; i += 2)
/*     */     {
/* 253 */       if (ep.equiv(key, this.array[i]))
/* 254 */         return i;
/*     */     }
/* 256 */     return -1;
/*     */   }
/*     */   
/*     */   private int indexOf(Object key) {
/* 260 */     if ((key instanceof Keyword))
/*     */     {
/* 262 */       for (int i = 0; i < this.array.length; i += 2)
/*     */       {
/* 264 */         if (key == this.array[i])
/* 265 */           return i;
/*     */       }
/* 267 */       return -1;
/*     */     }
/*     */     
/* 270 */     return indexOfObject(key);
/*     */   }
/*     */   
/*     */   static boolean equalKey(Object k1, Object k2) {
/* 274 */     if ((k1 instanceof Keyword))
/* 275 */       return k1 == k2;
/* 276 */     return Util.equiv(k1, k2);
/*     */   }
/*     */   
/*     */   public Iterator iterator() {
/* 280 */     return new Iter(this.array, APersistentMap.MAKE_ENTRY);
/*     */   }
/*     */   
/*     */   public Iterator keyIterator() {
/* 284 */     return new Iter(this.array, APersistentMap.MAKE_KEY);
/*     */   }
/*     */   
/*     */   public Iterator valIterator() {
/* 288 */     return new Iter(this.array, APersistentMap.MAKE_VAL);
/*     */   }
/*     */   
/*     */   public ISeq seq() {
/* 292 */     if (this.array.length > 0)
/* 293 */       return new Seq(this.array, 0);
/* 294 */     return null;
/*     */   }
/*     */   
/*     */   public IPersistentMap meta() {
/* 298 */     return this._meta;
/*     */   }
/*     */   
/*     */   static class Seq extends ASeq implements Counted {
/*     */     final Object[] array;
/*     */     final int i;
/*     */     
/*     */     Seq(Object[] array, int i) {
/* 306 */       this.array = array;
/* 307 */       this.i = i;
/*     */     }
/*     */     
/*     */     public Seq(IPersistentMap meta, Object[] array, int i) {
/* 311 */       super();
/* 312 */       this.array = array;
/* 313 */       this.i = i;
/*     */     }
/*     */     
/*     */     public Object first() {
/* 317 */       return MapEntry.create(this.array[this.i], this.array[(this.i + 1)]);
/*     */     }
/*     */     
/*     */     public ISeq next() {
/* 321 */       if (this.i + 2 < this.array.length)
/* 322 */         return new Seq(this.array, this.i + 2);
/* 323 */       return null;
/*     */     }
/*     */     
/*     */     public int count() {
/* 327 */       return (this.array.length - this.i) / 2;
/*     */     }
/*     */     
/*     */     public Obj withMeta(IPersistentMap meta) {
/* 331 */       return new Seq(meta, this.array, this.i);
/*     */     }
/*     */   }
/*     */   
/*     */   static class Iter implements Iterator
/*     */   {
/*     */     IFn f;
/*     */     Object[] array;
/*     */     int i;
/*     */     
/*     */     Iter(Object[] array, IFn f) {
/* 342 */       this(array, -2, f);
/*     */     }
/*     */     
/*     */     Iter(Object[] array, int i, IFn f)
/*     */     {
/* 347 */       this.array = array;
/* 348 */       this.i = i;
/* 349 */       this.f = f;
/*     */     }
/*     */     
/*     */     public boolean hasNext() {
/* 353 */       return this.i < this.array.length - 2;
/*     */     }
/*     */     
/*     */     public Object next() {
/*     */       try {
/* 358 */         this.i += 2;
/* 359 */         return this.f.invoke(this.array[this.i], this.array[(this.i + 1)]);
/*     */       } catch (IndexOutOfBoundsException e) {
/* 361 */         throw new NoSuchElementException();
/*     */       }
/*     */     }
/*     */     
/*     */     public void remove() {
/* 366 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */   
/*     */   public Object kvreduce(IFn f, Object init)
/*     */   {
/* 372 */     for (int i = 0; i < this.array.length; i += 2) {
/* 373 */       init = f.invoke(init, this.array[i], this.array[(i + 1)]);
/* 374 */       if (RT.isReduced(init))
/* 375 */         return ((IDeref)init).deref();
/*     */     }
/* 377 */     return init;
/*     */   }
/*     */   
/*     */   public ITransientMap asTransient() {
/* 381 */     return new TransientArrayMap(this.array);
/*     */   }
/*     */   
/*     */   static final class TransientArrayMap extends ATransientMap {
/*     */     volatile int len;
/*     */     final Object[] array;
/*     */     volatile Thread owner;
/*     */     
/*     */     public TransientArrayMap(Object[] array) {
/* 390 */       this.owner = Thread.currentThread();
/* 391 */       this.array = new Object[Math.max(16, array.length)];
/* 392 */       System.arraycopy(array, 0, this.array, 0, array.length);
/* 393 */       this.len = array.length;
/*     */     }
/*     */     
/*     */     private int indexOf(Object key) {
/* 397 */       for (int i = 0; i < this.len; i += 2)
/*     */       {
/* 399 */         if (PersistentArrayMap.equalKey(this.array[i], key))
/* 400 */           return i;
/*     */       }
/* 402 */       return -1;
/*     */     }
/*     */     
/*     */     ITransientMap doAssoc(Object key, Object val) {
/* 406 */       int i = indexOf(key);
/* 407 */       if (i >= 0)
/*     */       {
/* 409 */         if (this.array[(i + 1)] != val) {
/* 410 */           this.array[(i + 1)] = val;
/*     */         }
/*     */       }
/*     */       else {
/* 414 */         if (this.len >= this.array.length)
/* 415 */           return PersistentHashMap.create(this.array).asTransient().assoc(key, val);
/* 416 */         this.array[(this.len++)] = key;
/* 417 */         this.array[(this.len++)] = val;
/*     */       }
/* 419 */       return this;
/*     */     }
/*     */     
/*     */     ITransientMap doWithout(Object key) {
/* 423 */       int i = indexOf(key);
/* 424 */       if (i >= 0)
/*     */       {
/* 426 */         if (this.len >= 2)
/*     */         {
/* 428 */           this.array[i] = this.array[(this.len - 2)];
/* 429 */           this.array[(i + 1)] = this.array[(this.len - 1)];
/*     */         }
/* 431 */         this.len -= 2;
/*     */       }
/* 433 */       return this;
/*     */     }
/*     */     
/*     */     Object doValAt(Object key, Object notFound) {
/* 437 */       int i = indexOf(key);
/* 438 */       if (i >= 0)
/* 439 */         return this.array[(i + 1)];
/* 440 */       return notFound;
/*     */     }
/*     */     
/*     */     int doCount() {
/* 444 */       return this.len / 2;
/*     */     }
/*     */     
/*     */     IPersistentMap doPersistent() {
/* 448 */       ensureEditable();
/* 449 */       this.owner = null;
/* 450 */       Object[] a = new Object[this.len];
/* 451 */       System.arraycopy(this.array, 0, a, 0, this.len);
/* 452 */       return new PersistentArrayMap(a);
/*     */     }
/*     */     
/*     */     void ensureEditable() {
/* 456 */       if (this.owner == null) {
/* 457 */         throw new IllegalAccessError("Transient used after persistent! call");
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\PersistentArrayMap.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */