/*     */ package clojure.lang;
/*     */ 
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Var
/*     */   extends ARef
/*     */   implements IFn, IRef, Settable
/*     */ {
/*     */   static class TBox
/*     */   {
/*     */     volatile Object val;
/*     */     final Thread thread;
/*     */     
/*     */     public TBox(Thread t, Object val)
/*     */     {
/*  26 */       this.thread = t;
/*  27 */       this.val = val;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class Unbound extends AFn {
/*     */     public final Var v;
/*     */     
/*     */     public Unbound(Var v) {
/*  35 */       this.v = v;
/*     */     }
/*     */     
/*     */     public String toString() {
/*  39 */       return "Unbound: " + this.v;
/*     */     }
/*     */     
/*     */     public Object throwArity(int n) {
/*  43 */       throw new IllegalStateException("Attempting to call unbound fn: " + this.v);
/*     */     }
/*     */   }
/*     */   
/*     */   static class Frame {
/*  48 */     static final Frame TOP = new Frame(PersistentHashMap.EMPTY, null);
/*     */     
/*     */     Associative bindings;
/*     */     
/*     */     Frame prev;
/*     */     
/*     */ 
/*     */     public Frame(Associative bindings, Frame prev)
/*     */     {
/*  57 */       this.bindings = bindings;
/*  58 */       this.prev = prev;
/*     */     }
/*     */     
/*     */     protected Object clone() {
/*  62 */       return new Frame(this.bindings, null);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*  67 */   static final ThreadLocal<Frame> dvals = new ThreadLocal()
/*     */   {
/*     */     protected Var.Frame initialValue() {
/*  70 */       return Var.Frame.TOP;
/*     */     }
/*     */   };
/*     */   
/*  74 */   public static volatile int rev = 0;
/*     */   
/*  76 */   static Keyword privateKey = Keyword.intern(null, "private");
/*  77 */   static IPersistentMap privateMeta = new PersistentArrayMap(new Object[] { privateKey, Boolean.TRUE });
/*  78 */   static Keyword macroKey = Keyword.intern(null, "macro");
/*  79 */   static Keyword nameKey = Keyword.intern(null, "name");
/*  80 */   static Keyword nsKey = Keyword.intern(null, "ns");
/*     */   
/*     */ 
/*     */   volatile Object root;
/*     */   
/*  85 */   volatile boolean dynamic = false;
/*     */   
/*     */   final transient AtomicBoolean threadBound;
/*     */   public final Symbol sym;
/*     */   public final Namespace ns;
/*     */   
/*     */   public static Object getThreadBindingFrame()
/*     */   {
/*  93 */     return dvals.get();
/*     */   }
/*     */   
/*     */   public static Object cloneThreadBindingFrame() {
/*  97 */     return ((Frame)dvals.get()).clone();
/*     */   }
/*     */   
/*     */   public static void resetThreadBindingFrame(Object frame) {
/* 101 */     dvals.set((Frame)frame);
/*     */   }
/*     */   
/*     */   public Var setDynamic() {
/* 105 */     this.dynamic = true;
/* 106 */     return this;
/*     */   }
/*     */   
/*     */   public Var setDynamic(boolean b) {
/* 110 */     this.dynamic = b;
/* 111 */     return this;
/*     */   }
/*     */   
/*     */   public final boolean isDynamic() {
/* 115 */     return this.dynamic;
/*     */   }
/*     */   
/*     */   public static Var intern(Namespace ns, Symbol sym, Object root) {
/* 119 */     return intern(ns, sym, root, true);
/*     */   }
/*     */   
/*     */   public static Var intern(Namespace ns, Symbol sym, Object root, boolean replaceRoot) {
/* 123 */     Var dvout = ns.intern(sym);
/* 124 */     if ((!dvout.hasRoot()) || (replaceRoot))
/* 125 */       dvout.bindRoot(root);
/* 126 */     return dvout;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 131 */     if (this.ns != null)
/* 132 */       return "#'" + this.ns.name + "/" + this.sym;
/* 133 */     return "#<Var: " + (this.sym != null ? this.sym.toString() : "--unnamed--") + ">";
/*     */   }
/*     */   
/*     */   public static Var find(Symbol nsQualifiedSym) {
/* 137 */     if (nsQualifiedSym.ns == null)
/* 138 */       throw new IllegalArgumentException("Symbol must be namespace-qualified");
/* 139 */     Namespace ns = Namespace.find(Symbol.intern(nsQualifiedSym.ns));
/* 140 */     if (ns == null)
/* 141 */       throw new IllegalArgumentException("No such namespace: " + nsQualifiedSym.ns);
/* 142 */     return ns.findInternedVar(Symbol.intern(nsQualifiedSym.name));
/*     */   }
/*     */   
/*     */   public static Var intern(Symbol nsName, Symbol sym) {
/* 146 */     Namespace ns = Namespace.findOrCreate(nsName);
/* 147 */     return intern(ns, sym);
/*     */   }
/*     */   
/*     */   public static Var internPrivate(String nsName, String sym) {
/* 151 */     Namespace ns = Namespace.findOrCreate(Symbol.intern(nsName));
/* 152 */     Var ret = intern(ns, Symbol.intern(sym));
/* 153 */     ret.setMeta(privateMeta);
/* 154 */     return ret;
/*     */   }
/*     */   
/*     */   public static Var intern(Namespace ns, Symbol sym) {
/* 158 */     return ns.intern(sym);
/*     */   }
/*     */   
/*     */   public static Var create()
/*     */   {
/* 163 */     return new Var(null, null);
/*     */   }
/*     */   
/*     */   public static Var create(Object root) {
/* 167 */     return new Var(null, null, root);
/*     */   }
/*     */   
/*     */   Var(Namespace ns, Symbol sym) {
/* 171 */     this.ns = ns;
/* 172 */     this.sym = sym;
/* 173 */     this.threadBound = new AtomicBoolean(false);
/* 174 */     this.root = new Unbound(this);
/* 175 */     setMeta(PersistentHashMap.EMPTY);
/*     */   }
/*     */   
/*     */   Var(Namespace ns, Symbol sym, Object root) {
/* 179 */     this(ns, sym);
/* 180 */     this.root = root;
/* 181 */     rev += 1;
/*     */   }
/*     */   
/*     */   public boolean isBound() {
/* 185 */     return (hasRoot()) || ((this.threadBound.get()) && (((Frame)dvals.get()).bindings.containsKey(this)));
/*     */   }
/*     */   
/*     */   public final Object get() {
/* 189 */     if (!this.threadBound.get())
/* 190 */       return this.root;
/* 191 */     return deref();
/*     */   }
/*     */   
/*     */   public final Object deref() {
/* 195 */     TBox b = getThreadBinding();
/* 196 */     if (b != null)
/* 197 */       return b.val;
/* 198 */     return this.root;
/*     */   }
/*     */   
/*     */   public void setValidator(IFn vf) {
/* 202 */     if (hasRoot())
/* 203 */       validate(vf, this.root);
/* 204 */     this.validator = vf;
/*     */   }
/*     */   
/*     */   public Object alter(IFn fn, ISeq args) {
/* 208 */     set(fn.applyTo(RT.cons(deref(), args)));
/* 209 */     return this;
/*     */   }
/*     */   
/*     */   public Object set(Object val) {
/* 213 */     validate(getValidator(), val);
/* 214 */     TBox b = getThreadBinding();
/* 215 */     if (b != null)
/*     */     {
/* 217 */       if (Thread.currentThread() != b.thread)
/* 218 */         throw new IllegalStateException(String.format("Can't set!: %s from non-binding thread", new Object[] { this.sym }));
/* 219 */       return b.val = val;
/*     */     }
/* 221 */     throw new IllegalStateException(String.format("Can't change/establish root binding of: %s with set", new Object[] { this.sym }));
/*     */   }
/*     */   
/*     */   public Object doSet(Object val) {
/* 225 */     return set(val);
/*     */   }
/*     */   
/*     */   public Object doReset(Object val) {
/* 229 */     bindRoot(val);
/* 230 */     return val;
/*     */   }
/*     */   
/*     */   public void setMeta(IPersistentMap m)
/*     */   {
/* 235 */     resetMeta(m.assoc(nameKey, this.sym).assoc(nsKey, this.ns));
/*     */   }
/*     */   
/*     */   public void setMacro() {
/* 239 */     alterMeta(assoc, RT.list(macroKey, RT.T));
/*     */   }
/*     */   
/*     */   public boolean isMacro() {
/* 243 */     return RT.booleanCast(meta().valAt(macroKey));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isPublic()
/*     */   {
/* 251 */     return !RT.booleanCast(meta().valAt(privateKey));
/*     */   }
/*     */   
/*     */   public final Object getRawRoot() {
/* 255 */     return this.root;
/*     */   }
/*     */   
/*     */   public Object getTag() {
/* 259 */     return meta().valAt(RT.TAG_KEY);
/*     */   }
/*     */   
/*     */   public void setTag(Symbol tag) {
/* 263 */     alterMeta(assoc, RT.list(RT.TAG_KEY, tag));
/*     */   }
/*     */   
/*     */   public final boolean hasRoot() {
/* 267 */     return !(this.root instanceof Unbound);
/*     */   }
/*     */   
/*     */   public synchronized void bindRoot(Object root)
/*     */   {
/* 272 */     validate(getValidator(), root);
/* 273 */     Object oldroot = this.root;
/* 274 */     this.root = root;
/* 275 */     rev += 1;
/* 276 */     alterMeta(dissoc, RT.list(macroKey));
/* 277 */     notifyWatches(oldroot, this.root);
/*     */   }
/*     */   
/*     */   synchronized void swapRoot(Object root) {
/* 281 */     validate(getValidator(), root);
/* 282 */     Object oldroot = this.root;
/* 283 */     this.root = root;
/* 284 */     rev += 1;
/* 285 */     notifyWatches(oldroot, root);
/*     */   }
/*     */   
/*     */   public synchronized void unbindRoot() {
/* 289 */     this.root = new Unbound(this);
/* 290 */     rev += 1;
/*     */   }
/*     */   
/*     */   public synchronized void commuteRoot(IFn fn) {
/* 294 */     Object newRoot = fn.invoke(this.root);
/* 295 */     validate(getValidator(), newRoot);
/* 296 */     Object oldroot = this.root;
/* 297 */     this.root = newRoot;
/* 298 */     rev += 1;
/* 299 */     notifyWatches(oldroot, newRoot);
/*     */   }
/*     */   
/*     */   public synchronized Object alterRoot(IFn fn, ISeq args) {
/* 303 */     Object newRoot = fn.applyTo(RT.cons(this.root, args));
/* 304 */     validate(getValidator(), newRoot);
/* 305 */     Object oldroot = this.root;
/* 306 */     this.root = newRoot;
/* 307 */     rev += 1;
/* 308 */     notifyWatches(oldroot, newRoot);
/* 309 */     return newRoot;
/*     */   }
/*     */   
/*     */   public static void pushThreadBindings(Associative bindings) {
/* 313 */     Frame f = (Frame)dvals.get();
/* 314 */     Associative bmap = f.bindings;
/* 315 */     for (ISeq bs = bindings.seq(); bs != null; bs = bs.next())
/*     */     {
/* 317 */       IMapEntry e = (IMapEntry)bs.first();
/* 318 */       Var v = (Var)e.key();
/* 319 */       if (!v.dynamic)
/* 320 */         throw new IllegalStateException(String.format("Can't dynamically bind non-dynamic var: %s/%s", new Object[] { v.ns, v.sym }));
/* 321 */       v.validate(v.getValidator(), e.val());
/* 322 */       v.threadBound.set(true);
/* 323 */       bmap = bmap.assoc(v, new TBox(Thread.currentThread(), e.val()));
/*     */     }
/* 325 */     dvals.set(new Frame(bmap, f));
/*     */   }
/*     */   
/*     */   public static void popThreadBindings() {
/* 329 */     Frame f = ((Frame)dvals.get()).prev;
/* 330 */     if (f == null)
/* 331 */       throw new IllegalStateException("Pop without matching push");
/* 332 */     if (f == Frame.TOP) {
/* 333 */       dvals.remove();
/*     */     } else {
/* 335 */       dvals.set(f);
/*     */     }
/*     */   }
/*     */   
/*     */   public static Associative getThreadBindings() {
/* 340 */     Frame f = (Frame)dvals.get();
/* 341 */     IPersistentMap ret = PersistentHashMap.EMPTY;
/* 342 */     for (ISeq bs = f.bindings.seq(); bs != null; bs = bs.next())
/*     */     {
/* 344 */       IMapEntry e = (IMapEntry)bs.first();
/* 345 */       Var v = (Var)e.key();
/* 346 */       TBox b = (TBox)e.val();
/* 347 */       ret = ret.assoc(v, b.val);
/*     */     }
/* 349 */     return ret;
/*     */   }
/*     */   
/*     */   public final TBox getThreadBinding() {
/* 353 */     if (this.threadBound.get())
/*     */     {
/* 355 */       IMapEntry e = ((Frame)dvals.get()).bindings.entryAt(this);
/* 356 */       if (e != null)
/* 357 */         return (TBox)e.val();
/*     */     }
/* 359 */     return null;
/*     */   }
/*     */   
/*     */   public final IFn fn() {
/* 363 */     return (IFn)deref();
/*     */   }
/*     */   
/*     */   public Object call() {
/* 367 */     return invoke();
/*     */   }
/*     */   
/*     */   public void run() {
/* 371 */     invoke();
/*     */   }
/*     */   
/*     */   public Object invoke() {
/* 375 */     return fn().invoke();
/*     */   }
/*     */   
/*     */   public Object invoke(Object arg1) {
/* 379 */     return fn().invoke(Util.ret1(arg1, arg1 = null));
/*     */   }
/*     */   
/*     */   public Object invoke(Object arg1, Object arg2) {
/* 383 */     return fn().invoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null));
/*     */   }
/*     */   
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3)
/*     */   {
/* 388 */     return fn().invoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null));
/*     */   }
/*     */   
/*     */ 
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4)
/*     */   {
/* 394 */     return fn().invoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5)
/*     */   {
/* 401 */     return fn().invoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6)
/*     */   {
/* 409 */     return fn().invoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7)
/*     */   {
/* 419 */     return fn().invoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8)
/*     */   {
/* 430 */     return fn().invoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9)
/*     */   {
/* 442 */     return fn().invoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10)
/*     */   {
/* 455 */     return fn().invoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11)
/*     */   {
/* 469 */     return fn().invoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12)
/*     */   {
/* 484 */     return fn().invoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12, Object arg13)
/*     */   {
/* 501 */     return fn().invoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12, Object arg13, Object arg14)
/*     */   {
/* 519 */     return fn().invoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12, Object arg13, Object arg14, Object arg15)
/*     */   {
/* 538 */     return fn().invoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12, Object arg13, Object arg14, Object arg15, Object arg16)
/*     */   {
/* 558 */     return fn().invoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12, Object arg13, Object arg14, Object arg15, Object arg16, Object arg17)
/*     */   {
/* 579 */     return fn().invoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12, Object arg13, Object arg14, Object arg15, Object arg16, Object arg17, Object arg18)
/*     */   {
/* 601 */     return fn().invoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12, Object arg13, Object arg14, Object arg15, Object arg16, Object arg17, Object arg18, Object arg19)
/*     */   {
/* 624 */     return fn().invoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null), Util.ret1(arg19, arg19 = null));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12, Object arg13, Object arg14, Object arg15, Object arg16, Object arg17, Object arg18, Object arg19, Object arg20)
/*     */   {
/* 649 */     return fn().invoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null), Util.ret1(arg19, arg19 = null), Util.ret1(arg20, arg20 = null));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12, Object arg13, Object arg14, Object arg15, Object arg16, Object arg17, Object arg18, Object arg19, Object arg20, Object... args)
/*     */   {
/* 676 */     return fn().invoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null), Util.ret1(arg19, arg19 = null), Util.ret1(arg20, arg20 = null), (Object[])Util.ret1(args, args = null));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object applyTo(ISeq arglist)
/*     */   {
/* 700 */     return AFn.applyToHelper(this, arglist);
/*     */   }
/*     */   
/* 703 */   static IFn assoc = new AFn()
/*     */   {
/*     */     public Object invoke(Object m, Object k, Object v) {
/* 706 */       return RT.assoc(m, k, v);
/*     */     }
/*     */   };
/* 709 */   static IFn dissoc = new AFn()
/*     */   {
/*     */     public Object invoke(Object c, Object k) {
/* 712 */       return RT.dissoc(c, k);
/*     */     }
/*     */   };
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\Var.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */