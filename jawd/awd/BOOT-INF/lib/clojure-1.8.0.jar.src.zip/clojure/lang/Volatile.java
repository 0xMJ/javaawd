/*    */ package clojure.lang;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Volatile
/*    */   implements IDeref
/*    */ {
/*    */   volatile Object val;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Volatile(Object val)
/*    */   {
/* 18 */     this.val = val;
/*    */   }
/*    */   
/*    */   public Object deref() {
/* 22 */     return this.val;
/*    */   }
/*    */   
/*    */   public Object reset(Object newval) {
/* 26 */     return this.val = newval;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\Volatile.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */