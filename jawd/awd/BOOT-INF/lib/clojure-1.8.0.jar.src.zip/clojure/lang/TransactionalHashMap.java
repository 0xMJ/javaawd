/*     */ package clojure.lang;
/*     */ 
/*     */ import java.util.AbstractMap;
/*     */ import java.util.AbstractSet;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ 
/*     */ public class TransactionalHashMap<K, V>
/*     */   extends AbstractMap<K, V> implements ConcurrentMap<K, V>
/*     */ {
/*     */   final Ref[] bins;
/*     */   
/*     */   IPersistentMap mapAt(int bin)
/*     */   {
/*  22 */     return (IPersistentMap)this.bins[bin].deref();
/*     */   }
/*     */   
/*     */   final int binFor(Object k)
/*     */   {
/*  27 */     int h = k.hashCode();
/*  28 */     h ^= h >>> 20 ^ h >>> 12;
/*  29 */     h ^= h >>> 7 ^ h >>> 4;
/*  30 */     return h % this.bins.length;
/*     */   }
/*     */   
/*     */   Map.Entry entryAt(Object k)
/*     */   {
/*  35 */     return mapAt(binFor(k)).entryAt(k);
/*     */   }
/*     */   
/*     */   public TransactionalHashMap() {
/*  39 */     this(421);
/*     */   }
/*     */   
/*     */   public TransactionalHashMap(int nBins) {
/*  43 */     this.bins = new Ref[nBins];
/*  44 */     for (int i = 0; i < nBins; i++)
/*  45 */       this.bins[i] = new Ref(PersistentHashMap.EMPTY);
/*     */   }
/*     */   
/*     */   public TransactionalHashMap(Map<? extends K, ? extends V> m) {
/*  49 */     this(m.size());
/*  50 */     putAll(m);
/*     */   }
/*     */   
/*     */   public int size() {
/*  54 */     int n = 0;
/*  55 */     for (int i = 0; i < this.bins.length; i++)
/*     */     {
/*  57 */       n += mapAt(i).count();
/*     */     }
/*  59 */     return n;
/*     */   }
/*     */   
/*     */   public boolean isEmpty() {
/*  63 */     return size() == 0;
/*     */   }
/*     */   
/*     */   public boolean containsKey(Object k) {
/*  67 */     return entryAt(k) != null;
/*     */   }
/*     */   
/*     */   public V get(Object k) {
/*  71 */     Map.Entry e = entryAt(k);
/*  72 */     if (e != null)
/*  73 */       return (V)e.getValue();
/*  74 */     return null;
/*     */   }
/*     */   
/*     */   public V put(K k, V v) {
/*  78 */     Ref r = this.bins[binFor(k)];
/*  79 */     IPersistentMap map = (IPersistentMap)r.deref();
/*  80 */     Object ret = map.valAt(k);
/*  81 */     r.set(map.assoc(k, v));
/*  82 */     return (V)ret;
/*     */   }
/*     */   
/*     */   public V remove(Object k) {
/*  86 */     Ref r = this.bins[binFor(k)];
/*  87 */     IPersistentMap map = (IPersistentMap)r.deref();
/*  88 */     Object ret = map.valAt(k);
/*  89 */     r.set(map.without(k));
/*  90 */     return (V)ret;
/*     */   }
/*     */   
/*     */   public void putAll(Map<? extends K, ? extends V> map) {
/*  94 */     for (Iterator i = map.entrySet().iterator(); i.hasNext();)
/*     */     {
/*  96 */       Map.Entry<K, V> e = (Map.Entry)i.next();
/*  97 */       put(e.getKey(), e.getValue());
/*     */     }
/*     */   }
/*     */   
/*     */   public void clear() {
/* 102 */     for (int i = 0; i < this.bins.length; i++)
/*     */     {
/* 104 */       Ref r = this.bins[i];
/* 105 */       IPersistentMap map = (IPersistentMap)r.deref();
/* 106 */       if (map.count() > 0)
/*     */       {
/* 108 */         r.set(PersistentHashMap.EMPTY);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public Set<Map.Entry<K, V>> entrySet() {
/* 114 */     final ArrayList<Map.Entry<K, V>> entries = new ArrayList(this.bins.length);
/* 115 */     for (int i = 0; i < this.bins.length; i++)
/*     */     {
/* 117 */       IPersistentMap map = mapAt(i);
/* 118 */       if (map.count() > 0)
/* 119 */         entries.addAll((Collection)RT.seq(map));
/*     */     }
/* 121 */     new AbstractSet() {
/*     */       public Iterator iterator() {
/* 123 */         return Collections.unmodifiableList(entries).iterator();
/*     */       }
/*     */       
/*     */       public int size() {
/* 127 */         return entries.size();
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */   public V putIfAbsent(K k, V v) {
/* 133 */     Ref r = this.bins[binFor(k)];
/* 134 */     IPersistentMap map = (IPersistentMap)r.deref();
/* 135 */     Map.Entry e = map.entryAt(k);
/* 136 */     if (e == null)
/*     */     {
/* 138 */       r.set(map.assoc(k, v));
/* 139 */       return null;
/*     */     }
/*     */     
/* 142 */     return (V)e.getValue();
/*     */   }
/*     */   
/*     */   public boolean remove(Object k, Object v) {
/* 146 */     Ref r = this.bins[binFor(k)];
/* 147 */     IPersistentMap map = (IPersistentMap)r.deref();
/* 148 */     Map.Entry e = map.entryAt(k);
/* 149 */     if ((e != null) && (e.getValue().equals(v)))
/*     */     {
/* 151 */       r.set(map.without(k));
/* 152 */       return true;
/*     */     }
/* 154 */     return false;
/*     */   }
/*     */   
/*     */   public boolean replace(K k, V oldv, V newv) {
/* 158 */     Ref r = this.bins[binFor(k)];
/* 159 */     IPersistentMap map = (IPersistentMap)r.deref();
/* 160 */     Map.Entry e = map.entryAt(k);
/* 161 */     if ((e != null) && (e.getValue().equals(oldv)))
/*     */     {
/* 163 */       r.set(map.assoc(k, newv));
/* 164 */       return true;
/*     */     }
/* 166 */     return false;
/*     */   }
/*     */   
/*     */   public V replace(K k, V v) {
/* 170 */     Ref r = this.bins[binFor(k)];
/* 171 */     IPersistentMap map = (IPersistentMap)r.deref();
/* 172 */     Map.Entry e = map.entryAt(k);
/* 173 */     if (e != null)
/*     */     {
/* 175 */       r.set(map.assoc(k, v));
/* 176 */       return (V)e.getValue();
/*     */     }
/* 178 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\TransactionalHashMap.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */