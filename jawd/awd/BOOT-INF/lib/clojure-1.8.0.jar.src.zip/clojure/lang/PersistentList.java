/*     */ package clojure.lang;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ import java.util.NoSuchElementException;
/*     */ 
/*     */ public class PersistentList
/*     */   extends ASeq implements IPersistentList, IReduce, List, Counted
/*     */ {
/*     */   private final Object _first;
/*     */   private final IPersistentList _rest;
/*     */   private final int _count;
/*     */   
/*     */   public static class Primordial
/*     */     extends RestFn
/*     */   {
/*     */     public final int getRequiredArity()
/*     */     {
/*  24 */       return 0;
/*     */     }
/*     */     
/*     */     protected final Object doInvoke(Object args) {
/*  28 */       if ((args instanceof ArraySeq))
/*     */       {
/*  30 */         Object[] argsarray = ((ArraySeq)args).array;
/*  31 */         IPersistentList ret = PersistentList.EMPTY;
/*  32 */         for (int i = argsarray.length - 1; i >= ((ArraySeq)args).i; i--)
/*  33 */           ret = (IPersistentList)ret.cons(argsarray[i]);
/*  34 */         return ret;
/*     */       }
/*  36 */       LinkedList list = new LinkedList();
/*  37 */       for (ISeq s = RT.seq(args); s != null; s = s.next())
/*  38 */         list.add(s.first());
/*  39 */       return PersistentList.create(list);
/*     */     }
/*     */     
/*     */     public static Object invokeStatic(ISeq args) {
/*  43 */       if ((args instanceof ArraySeq))
/*     */       {
/*  45 */         Object[] argsarray = ((ArraySeq)args).array;
/*  46 */         IPersistentList ret = PersistentList.EMPTY;
/*  47 */         for (int i = argsarray.length - 1; i >= 0; i--)
/*  48 */           ret = (IPersistentList)ret.cons(argsarray[i]);
/*  49 */         return ret;
/*     */       }
/*  51 */       LinkedList list = new LinkedList();
/*  52 */       for (ISeq s = RT.seq(args); s != null; s = s.next())
/*  53 */         list.add(s.first());
/*  54 */       return PersistentList.create(list);
/*     */     }
/*     */     
/*     */     public IObj withMeta(IPersistentMap meta) {
/*  58 */       throw new UnsupportedOperationException();
/*     */     }
/*     */     
/*     */     public IPersistentMap meta() {
/*  62 */       return null;
/*     */     }
/*     */   }
/*     */   
/*  66 */   public static IFn creator = new Primordial();
/*     */   
/*  68 */   public static final EmptyList EMPTY = new EmptyList(null);
/*     */   
/*     */   public PersistentList(Object first) {
/*  71 */     this._first = first;
/*  72 */     this._rest = null;
/*     */     
/*  74 */     this._count = 1;
/*     */   }
/*     */   
/*     */   PersistentList(IPersistentMap meta, Object _first, IPersistentList _rest, int _count) {
/*  78 */     super(meta);
/*  79 */     this._first = _first;
/*  80 */     this._rest = _rest;
/*  81 */     this._count = _count;
/*     */   }
/*     */   
/*     */   public static IPersistentList create(List init) {
/*  85 */     IPersistentList ret = EMPTY;
/*  86 */     for (ListIterator i = init.listIterator(init.size()); i.hasPrevious();)
/*     */     {
/*  88 */       ret = (IPersistentList)ret.cons(i.previous());
/*     */     }
/*  90 */     return ret;
/*     */   }
/*     */   
/*     */   public Object first() {
/*  94 */     return this._first;
/*     */   }
/*     */   
/*     */   public ISeq next() {
/*  98 */     if (this._count == 1)
/*  99 */       return null;
/* 100 */     return (ISeq)this._rest;
/*     */   }
/*     */   
/*     */   public Object peek() {
/* 104 */     return first();
/*     */   }
/*     */   
/*     */   public IPersistentList pop() {
/* 108 */     if (this._rest == null)
/* 109 */       return EMPTY.withMeta(this._meta);
/* 110 */     return this._rest;
/*     */   }
/*     */   
/*     */   public int count() {
/* 114 */     return this._count;
/*     */   }
/*     */   
/*     */   public PersistentList cons(Object o) {
/* 118 */     return new PersistentList(meta(), o, this, this._count + 1);
/*     */   }
/*     */   
/*     */   public IPersistentCollection empty() {
/* 122 */     return EMPTY.withMeta(meta());
/*     */   }
/*     */   
/*     */   public PersistentList withMeta(IPersistentMap meta) {
/* 126 */     if (meta != this._meta)
/* 127 */       return new PersistentList(meta, this._first, this._rest, this._count);
/* 128 */     return this;
/*     */   }
/*     */   
/*     */   public Object reduce(IFn f) {
/* 132 */     Object ret = first();
/* 133 */     for (ISeq s = next(); s != null; s = s.next()) {
/* 134 */       ret = f.invoke(ret, s.first());
/* 135 */       if (RT.isReduced(ret)) return ((IDeref)ret).deref();
/*     */     }
/* 137 */     return ret;
/*     */   }
/*     */   
/*     */   public Object reduce(IFn f, Object start) {
/* 141 */     Object ret = f.invoke(start, first());
/* 142 */     for (ISeq s = next(); s != null; s = s.next()) {
/* 143 */       if (RT.isReduced(ret)) return ((IDeref)ret).deref();
/* 144 */       ret = f.invoke(ret, s.first());
/*     */     }
/* 146 */     if (RT.isReduced(ret)) return ((IDeref)ret).deref();
/* 147 */     return ret;
/*     */   }
/*     */   
/*     */   static class EmptyList extends Obj implements IPersistentList, List, ISeq, Counted, IHashEq
/*     */   {
/* 152 */     static final int hasheq = Murmur3.hashOrdered(Collections.EMPTY_LIST);
/*     */     
/*     */     public int hashCode() {
/* 155 */       return 1;
/*     */     }
/*     */     
/*     */     public int hasheq() {
/* 159 */       return hasheq;
/*     */     }
/*     */     
/*     */     public String toString() {
/* 163 */       return "()";
/*     */     }
/*     */     
/*     */     public boolean equals(Object o) {
/* 167 */       return (((o instanceof Sequential)) || ((o instanceof List))) && (RT.seq(o) == null);
/*     */     }
/*     */     
/*     */     public boolean equiv(Object o) {
/* 171 */       return equals(o);
/*     */     }
/*     */     
/*     */     EmptyList(IPersistentMap meta) {
/* 175 */       super();
/*     */     }
/*     */     
/*     */     public Object first() {
/* 179 */       return null;
/*     */     }
/*     */     
/*     */     public ISeq next() {
/* 183 */       return null;
/*     */     }
/*     */     
/*     */     public ISeq more() {
/* 187 */       return this;
/*     */     }
/*     */     
/*     */     public PersistentList cons(Object o) {
/* 191 */       return new PersistentList(meta(), o, null, 1);
/*     */     }
/*     */     
/*     */     public IPersistentCollection empty() {
/* 195 */       return this;
/*     */     }
/*     */     
/*     */     public EmptyList withMeta(IPersistentMap meta) {
/* 199 */       if (meta != meta())
/* 200 */         return new EmptyList(meta);
/* 201 */       return this;
/*     */     }
/*     */     
/*     */     public Object peek() {
/* 205 */       return null;
/*     */     }
/*     */     
/*     */     public IPersistentList pop() {
/* 209 */       throw new IllegalStateException("Can't pop empty list");
/*     */     }
/*     */     
/*     */     public int count() {
/* 213 */       return 0;
/*     */     }
/*     */     
/*     */     public ISeq seq() {
/* 217 */       return null;
/*     */     }
/*     */     
/*     */     public int size()
/*     */     {
/* 222 */       return 0;
/*     */     }
/*     */     
/*     */     public boolean isEmpty() {
/* 226 */       return true;
/*     */     }
/*     */     
/*     */     public boolean contains(Object o) {
/* 230 */       return false;
/*     */     }
/*     */     
/*     */     public Iterator iterator() {
/* 234 */       new Iterator()
/*     */       {
/*     */         public boolean hasNext() {
/* 237 */           return false;
/*     */         }
/*     */         
/*     */         public Object next() {
/* 241 */           throw new NoSuchElementException();
/*     */         }
/*     */         
/*     */         public void remove() {
/* 245 */           throw new UnsupportedOperationException();
/*     */         }
/*     */       };
/*     */     }
/*     */     
/*     */     public Object[] toArray() {
/* 251 */       return RT.EMPTY_ARRAY;
/*     */     }
/*     */     
/*     */     public boolean add(Object o) {
/* 255 */       throw new UnsupportedOperationException();
/*     */     }
/*     */     
/*     */     public boolean remove(Object o) {
/* 259 */       throw new UnsupportedOperationException();
/*     */     }
/*     */     
/*     */     public boolean addAll(Collection collection) {
/* 263 */       throw new UnsupportedOperationException();
/*     */     }
/*     */     
/*     */     public void clear() {
/* 267 */       throw new UnsupportedOperationException();
/*     */     }
/*     */     
/*     */     public boolean retainAll(Collection collection) {
/* 271 */       throw new UnsupportedOperationException();
/*     */     }
/*     */     
/*     */     public boolean removeAll(Collection collection) {
/* 275 */       throw new UnsupportedOperationException();
/*     */     }
/*     */     
/*     */     public boolean containsAll(Collection collection) {
/* 279 */       return collection.isEmpty();
/*     */     }
/*     */     
/*     */     public Object[] toArray(Object[] objects) {
/* 283 */       if (objects.length > 0)
/* 284 */         objects[0] = null;
/* 285 */       return objects;
/*     */     }
/*     */     
/*     */     private List reify()
/*     */     {
/* 290 */       return Collections.unmodifiableList(new ArrayList(this));
/*     */     }
/*     */     
/*     */     public List subList(int fromIndex, int toIndex) {
/* 294 */       return reify().subList(fromIndex, toIndex);
/*     */     }
/*     */     
/*     */     public Object set(int index, Object element) {
/* 298 */       throw new UnsupportedOperationException();
/*     */     }
/*     */     
/*     */     public Object remove(int index) {
/* 302 */       throw new UnsupportedOperationException();
/*     */     }
/*     */     
/*     */     public int indexOf(Object o) {
/* 306 */       ISeq s = seq();
/* 307 */       for (int i = 0; s != null; i++)
/*     */       {
/* 309 */         if (Util.equiv(s.first(), o)) {
/* 310 */           return i;
/*     */         }
/* 307 */         s = s.next();
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 312 */       return -1;
/*     */     }
/*     */     
/*     */     public int lastIndexOf(Object o) {
/* 316 */       return reify().lastIndexOf(o);
/*     */     }
/*     */     
/*     */     public ListIterator listIterator() {
/* 320 */       return reify().listIterator();
/*     */     }
/*     */     
/*     */     public ListIterator listIterator(int index) {
/* 324 */       return reify().listIterator(index);
/*     */     }
/*     */     
/*     */     public Object get(int index) {
/* 328 */       return RT.nth(this, index);
/*     */     }
/*     */     
/*     */     public void add(int index, Object element) {
/* 332 */       throw new UnsupportedOperationException();
/*     */     }
/*     */     
/*     */     public boolean addAll(int index, Collection c) {
/* 336 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\PersistentList.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */