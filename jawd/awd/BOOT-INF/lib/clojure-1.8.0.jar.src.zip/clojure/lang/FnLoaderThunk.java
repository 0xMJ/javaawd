/*    */ package clojure.lang;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FnLoaderThunk
/*    */   extends RestFn
/*    */ {
/*    */   final Var v;
/*    */   
/*    */ 
/*    */   final ClassLoader loader;
/*    */   
/*    */ 
/*    */   final String fnClassName;
/*    */   
/*    */ 
/*    */   IFn fn;
/*    */   
/*    */ 
/*    */ 
/*    */   public FnLoaderThunk(Var v, String fnClassName)
/*    */   {
/* 23 */     this.v = v;
/* 24 */     this.loader = ((ClassLoader)RT.FN_LOADER_VAR.get());
/* 25 */     this.fnClassName = fnClassName;
/* 26 */     this.fn = null;
/*    */   }
/*    */   
/*    */   public Object invoke(Object arg1) {
/* 30 */     load();
/* 31 */     return this.fn.invoke(arg1);
/*    */   }
/*    */   
/*    */   public Object invoke(Object arg1, Object arg2) {
/* 35 */     load();
/* 36 */     return this.fn.invoke(arg1, arg2);
/*    */   }
/*    */   
/*    */   public Object invoke(Object arg1, Object arg2, Object arg3) {
/* 40 */     load();
/* 41 */     return this.fn.invoke(arg1, arg2, arg3);
/*    */   }
/*    */   
/*    */   protected Object doInvoke(Object args) {
/* 45 */     load();
/* 46 */     return this.fn.applyTo((ISeq)args);
/*    */   }
/*    */   
/*    */   private void load() {
/* 50 */     if (this.fn == null)
/*    */     {
/*    */       try
/*    */       {
/* 54 */         this.fn = ((IFn)Class.forName(this.fnClassName, true, this.loader).newInstance());
/*    */       }
/*    */       catch (Exception e)
/*    */       {
/* 58 */         throw Util.sneakyThrow(e);
/*    */       }
/* 60 */       this.v.root = this.fn;
/*    */     }
/*    */   }
/*    */   
/*    */   public int getRequiredArity() {
/* 65 */     return 0;
/*    */   }
/*    */   
/*    */   public IObj withMeta(IPersistentMap meta) {
/* 69 */     return this;
/*    */   }
/*    */   
/*    */   public IPersistentMap meta() {
/* 73 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\FnLoaderThunk.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */