/*      */ package clojure.lang;
/*      */ 
/*      */ import java.io.Serializable;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.NoSuchElementException;
/*      */ import java.util.concurrent.Callable;
/*      */ import java.util.concurrent.atomic.AtomicReference;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class PersistentHashMap
/*      */   extends APersistentMap
/*      */   implements IEditableCollection, IObj, IMapIterable, IKVReduce
/*      */ {
/*      */   final int count;
/*      */   final INode root;
/*      */   final boolean hasNull;
/*      */   final Object nullValue;
/*      */   final IPersistentMap _meta;
/*   36 */   public static final PersistentHashMap EMPTY = new PersistentHashMap(0, null, false, null);
/*   37 */   private static final Object NOT_FOUND = new Object();
/*      */   
/*      */   public static IPersistentMap create(Map other) {
/*   40 */     ITransientMap ret = EMPTY.asTransient();
/*   41 */     for (Object o : other.entrySet())
/*      */     {
/*   43 */       Map.Entry e = (Map.Entry)o;
/*   44 */       ret = ret.assoc(e.getKey(), e.getValue());
/*      */     }
/*   46 */     return ret.persistent();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static PersistentHashMap create(Object... init)
/*      */   {
/*   53 */     ITransientMap ret = EMPTY.asTransient();
/*   54 */     for (int i = 0; i < init.length; i += 2)
/*      */     {
/*   56 */       ret = ret.assoc(init[i], init[(i + 1)]);
/*      */     }
/*   58 */     return (PersistentHashMap)ret.persistent();
/*      */   }
/*      */   
/*      */   public static PersistentHashMap createWithCheck(Object... init) {
/*   62 */     ITransientMap ret = EMPTY.asTransient();
/*   63 */     for (int i = 0; i < init.length; i += 2)
/*      */     {
/*   65 */       ret = ret.assoc(init[i], init[(i + 1)]);
/*   66 */       if (ret.count() != i / 2 + 1)
/*   67 */         throw new IllegalArgumentException("Duplicate key: " + init[i]);
/*      */     }
/*   69 */     return (PersistentHashMap)ret.persistent();
/*      */   }
/*      */   
/*      */   public static PersistentHashMap create(ISeq items) {
/*   73 */     ITransientMap ret = EMPTY.asTransient();
/*   74 */     for (; items != null; items = items.next().next())
/*      */     {
/*   76 */       if (items.next() == null)
/*   77 */         throw new IllegalArgumentException(String.format("No value supplied for key: %s", new Object[] { items.first() }));
/*   78 */       ret = ret.assoc(items.first(), RT.second(items));
/*      */     }
/*   80 */     return (PersistentHashMap)ret.persistent();
/*      */   }
/*      */   
/*      */   public static PersistentHashMap createWithCheck(ISeq items) {
/*   84 */     ITransientMap ret = EMPTY.asTransient();
/*   85 */     for (int i = 0; items != null; i++)
/*      */     {
/*   87 */       if (items.next() == null)
/*   88 */         throw new IllegalArgumentException(String.format("No value supplied for key: %s", new Object[] { items.first() }));
/*   89 */       ret = ret.assoc(items.first(), RT.second(items));
/*   90 */       if (ret.count() != i + 1) {
/*   91 */         throw new IllegalArgumentException("Duplicate key: " + items.first());
/*      */       }
/*   85 */       items = items.next().next();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   93 */     return (PersistentHashMap)ret.persistent();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static PersistentHashMap create(IPersistentMap meta, Object... init)
/*      */   {
/*  100 */     return create(init).withMeta(meta);
/*      */   }
/*      */   
/*      */   PersistentHashMap(int count, INode root, boolean hasNull, Object nullValue) {
/*  104 */     this.count = count;
/*  105 */     this.root = root;
/*  106 */     this.hasNull = hasNull;
/*  107 */     this.nullValue = nullValue;
/*  108 */     this._meta = null;
/*      */   }
/*      */   
/*      */   public PersistentHashMap(IPersistentMap meta, int count, INode root, boolean hasNull, Object nullValue) {
/*  112 */     this._meta = meta;
/*  113 */     this.count = count;
/*  114 */     this.root = root;
/*  115 */     this.hasNull = hasNull;
/*  116 */     this.nullValue = nullValue;
/*      */   }
/*      */   
/*      */   static int hash(Object k) {
/*  120 */     return Util.hasheq(k);
/*      */   }
/*      */   
/*      */   public boolean containsKey(Object key) {
/*  124 */     if (key == null)
/*  125 */       return this.hasNull;
/*  126 */     return this.root.find(0, hash(key), key, NOT_FOUND) != NOT_FOUND;
/*      */   }
/*      */   
/*      */   public IMapEntry entryAt(Object key) {
/*  130 */     if (key == null)
/*  131 */       return this.hasNull ? MapEntry.create(null, this.nullValue) : null;
/*  132 */     return this.root != null ? this.root.find(0, hash(key), key) : null;
/*      */   }
/*      */   
/*      */   public IPersistentMap assoc(Object key, Object val) {
/*  136 */     if (key == null) {
/*  137 */       if ((this.hasNull) && (val == this.nullValue))
/*  138 */         return this;
/*  139 */       return new PersistentHashMap(meta(), this.hasNull ? this.count : this.count + 1, this.root, true, val);
/*      */     }
/*  141 */     Box addedLeaf = new Box(null);
/*  142 */     INode newroot = (this.root == null ? BitmapIndexedNode.EMPTY : this.root).assoc(0, hash(key), key, val, addedLeaf);
/*      */     
/*  144 */     if (newroot == this.root)
/*  145 */       return this;
/*  146 */     return new PersistentHashMap(meta(), addedLeaf.val == null ? this.count : this.count + 1, newroot, this.hasNull, this.nullValue);
/*      */   }
/*      */   
/*      */   public Object valAt(Object key, Object notFound) {
/*  150 */     if (key == null)
/*  151 */       return this.hasNull ? this.nullValue : notFound;
/*  152 */     return this.root != null ? this.root.find(0, hash(key), key, notFound) : notFound;
/*      */   }
/*      */   
/*      */   public Object valAt(Object key) {
/*  156 */     return valAt(key, null);
/*      */   }
/*      */   
/*      */   public IPersistentMap assocEx(Object key, Object val) {
/*  160 */     if (containsKey(key))
/*  161 */       throw Util.runtimeException("Key already present");
/*  162 */     return assoc(key, val);
/*      */   }
/*      */   
/*      */   public IPersistentMap without(Object key) {
/*  166 */     if (key == null)
/*  167 */       return this.hasNull ? new PersistentHashMap(meta(), this.count - 1, this.root, false, null) : this;
/*  168 */     if (this.root == null)
/*  169 */       return this;
/*  170 */     INode newroot = this.root.without(0, hash(key), key);
/*  171 */     if (newroot == this.root)
/*  172 */       return this;
/*  173 */     return new PersistentHashMap(meta(), this.count - 1, newroot, this.hasNull, this.nullValue);
/*      */   }
/*      */   
/*  176 */   static final Iterator EMPTY_ITER = new Iterator() {
/*      */     public boolean hasNext() {
/*  178 */       return false;
/*      */     }
/*      */     
/*      */     public Object next() {
/*  182 */       throw new NoSuchElementException();
/*      */     }
/*      */     
/*      */     public void remove() {
/*  186 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   };
/*      */   
/*      */   private Iterator iterator(final IFn f) {
/*  191 */     final Iterator rootIter = this.root == null ? EMPTY_ITER : this.root.iterator(f);
/*  192 */     if (this.hasNull) {
/*  193 */       new Iterator() {
/*  194 */         private boolean seen = false;
/*      */         
/*  196 */         public boolean hasNext() { if (!this.seen) {
/*  197 */             return true;
/*      */           }
/*  199 */           return rootIter.hasNext();
/*      */         }
/*      */         
/*      */         public Object next() {
/*  203 */           if (!this.seen) {
/*  204 */             this.seen = true;
/*  205 */             return f.invoke(null, PersistentHashMap.this.nullValue);
/*      */           }
/*  207 */           return rootIter.next();
/*      */         }
/*      */         
/*      */         public void remove() {
/*  211 */           throw new UnsupportedOperationException();
/*      */         }
/*      */       };
/*      */     }
/*      */     
/*  216 */     return rootIter;
/*      */   }
/*      */   
/*      */   public Iterator iterator() {
/*  220 */     return iterator(APersistentMap.MAKE_ENTRY);
/*      */   }
/*      */   
/*      */   public Iterator keyIterator() {
/*  224 */     return iterator(APersistentMap.MAKE_KEY);
/*      */   }
/*      */   
/*      */   public Iterator valIterator() {
/*  228 */     return iterator(APersistentMap.MAKE_VAL);
/*      */   }
/*      */   
/*      */   public Object kvreduce(IFn f, Object init) {
/*  232 */     init = this.hasNull ? f.invoke(init, null, this.nullValue) : init;
/*  233 */     if (RT.isReduced(init))
/*  234 */       return ((IDeref)init).deref();
/*  235 */     if (this.root != null) {
/*  236 */       init = this.root.kvreduce(f, init);
/*  237 */       if (RT.isReduced(init)) {
/*  238 */         return ((IDeref)init).deref();
/*      */       }
/*  240 */       return init;
/*      */     }
/*  242 */     return init;
/*      */   }
/*      */   
/*      */ 
/*      */   public Object fold(long n, final IFn combinef, final IFn reducef, IFn fjinvoke, final IFn fjtask, final IFn fjfork, final IFn fjjoin)
/*      */   {
/*  248 */     Callable top = new Callable() {
/*      */       public Object call() throws Exception {
/*  250 */         Object ret = combinef.invoke();
/*  251 */         if (PersistentHashMap.this.root != null)
/*  252 */           ret = combinef.invoke(ret, PersistentHashMap.this.root.fold(combinef, reducef, fjtask, fjfork, fjjoin));
/*  253 */         return PersistentHashMap.this.hasNull ? combinef.invoke(ret, reducef.invoke(combinef.invoke(), null, PersistentHashMap.this.nullValue)) : ret;
/*      */       }
/*      */       
/*      */ 
/*  257 */     };
/*  258 */     return fjinvoke.invoke(top);
/*      */   }
/*      */   
/*      */   public int count() {
/*  262 */     return this.count;
/*      */   }
/*      */   
/*      */   public ISeq seq() {
/*  266 */     ISeq s = this.root != null ? this.root.nodeSeq() : null;
/*  267 */     return this.hasNull ? new Cons(MapEntry.create(null, this.nullValue), s) : s;
/*      */   }
/*      */   
/*      */   public IPersistentCollection empty() {
/*  271 */     return EMPTY.withMeta(meta());
/*      */   }
/*      */   
/*      */   static int mask(int hash, int shift)
/*      */   {
/*  276 */     return hash >>> shift & 0x1F;
/*      */   }
/*      */   
/*      */   public PersistentHashMap withMeta(IPersistentMap meta) {
/*  280 */     return new PersistentHashMap(meta, this.count, this.root, this.hasNull, this.nullValue);
/*      */   }
/*      */   
/*      */   public TransientHashMap asTransient() {
/*  284 */     return new TransientHashMap(this);
/*      */   }
/*      */   
/*      */   public IPersistentMap meta() {
/*  288 */     return this._meta;
/*      */   }
/*      */   
/*      */   static final class TransientHashMap extends ATransientMap {
/*      */     final AtomicReference<Thread> edit;
/*      */     volatile PersistentHashMap.INode root;
/*      */     volatile int count;
/*      */     volatile boolean hasNull;
/*      */     volatile Object nullValue;
/*  297 */     final Box leafFlag = new Box(null);
/*      */     
/*      */     TransientHashMap(PersistentHashMap m)
/*      */     {
/*  301 */       this(new AtomicReference(Thread.currentThread()), m.root, m.count, m.hasNull, m.nullValue);
/*      */     }
/*      */     
/*      */     TransientHashMap(AtomicReference<Thread> edit, PersistentHashMap.INode root, int count, boolean hasNull, Object nullValue) {
/*  305 */       this.edit = edit;
/*  306 */       this.root = root;
/*  307 */       this.count = count;
/*  308 */       this.hasNull = hasNull;
/*  309 */       this.nullValue = nullValue;
/*      */     }
/*      */     
/*      */     ITransientMap doAssoc(Object key, Object val) {
/*  313 */       if (key == null) {
/*  314 */         if (this.nullValue != val)
/*  315 */           this.nullValue = val;
/*  316 */         if (!this.hasNull) {
/*  317 */           this.count += 1;
/*  318 */           this.hasNull = true;
/*      */         }
/*  320 */         return this;
/*      */       }
/*      */       
/*  323 */       this.leafFlag.val = null;
/*  324 */       PersistentHashMap.INode n = (this.root == null ? PersistentHashMap.BitmapIndexedNode.EMPTY : this.root).assoc(this.edit, 0, PersistentHashMap.hash(key), key, val, this.leafFlag);
/*      */       
/*  326 */       if (n != this.root)
/*  327 */         this.root = n;
/*  328 */       if (this.leafFlag.val != null) this.count += 1;
/*  329 */       return this;
/*      */     }
/*      */     
/*      */     ITransientMap doWithout(Object key) {
/*  333 */       if (key == null) {
/*  334 */         if (!this.hasNull) return this;
/*  335 */         this.hasNull = false;
/*  336 */         this.nullValue = null;
/*  337 */         this.count -= 1;
/*  338 */         return this;
/*      */       }
/*  340 */       if (this.root == null) { return this;
/*      */       }
/*  342 */       this.leafFlag.val = null;
/*  343 */       PersistentHashMap.INode n = this.root.without(this.edit, 0, PersistentHashMap.hash(key), key, this.leafFlag);
/*  344 */       if (n != this.root)
/*  345 */         this.root = n;
/*  346 */       if (this.leafFlag.val != null) this.count -= 1;
/*  347 */       return this;
/*      */     }
/*      */     
/*      */     IPersistentMap doPersistent() {
/*  351 */       this.edit.set(null);
/*  352 */       return new PersistentHashMap(this.count, this.root, this.hasNull, this.nullValue);
/*      */     }
/*      */     
/*      */     Object doValAt(Object key, Object notFound) {
/*  356 */       if (key == null) {
/*  357 */         if (this.hasNull) {
/*  358 */           return this.nullValue;
/*      */         }
/*  360 */         return notFound; }
/*  361 */       if (this.root == null)
/*  362 */         return notFound;
/*  363 */       return this.root.find(0, PersistentHashMap.hash(key), key, notFound);
/*      */     }
/*      */     
/*      */     int doCount() {
/*  367 */       return this.count;
/*      */     }
/*      */     
/*      */     void ensureEditable() {
/*  371 */       if (this.edit.get() == null) {
/*  372 */         throw new IllegalAccessError("Transient used after persistent! call");
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   static abstract interface INode extends Serializable {
/*      */     public abstract INode assoc(int paramInt1, int paramInt2, Object paramObject1, Object paramObject2, Box paramBox);
/*      */     
/*      */     public abstract INode without(int paramInt1, int paramInt2, Object paramObject);
/*      */     
/*      */     public abstract IMapEntry find(int paramInt1, int paramInt2, Object paramObject);
/*      */     
/*      */     public abstract Object find(int paramInt1, int paramInt2, Object paramObject1, Object paramObject2);
/*      */     
/*      */     public abstract ISeq nodeSeq();
/*      */     
/*      */     public abstract INode assoc(AtomicReference<Thread> paramAtomicReference, int paramInt1, int paramInt2, Object paramObject1, Object paramObject2, Box paramBox);
/*      */     
/*      */     public abstract INode without(AtomicReference<Thread> paramAtomicReference, int paramInt1, int paramInt2, Object paramObject, Box paramBox);
/*      */     
/*      */     public abstract Object kvreduce(IFn paramIFn, Object paramObject);
/*      */     
/*      */     public abstract Object fold(IFn paramIFn1, IFn paramIFn2, IFn paramIFn3, IFn paramIFn4, IFn paramIFn5);
/*      */     
/*      */     public abstract Iterator iterator(IFn paramIFn);
/*      */   }
/*      */   
/*      */   static final class ArrayNode implements PersistentHashMap.INode {
/*      */     int count;
/*      */     final PersistentHashMap.INode[] array;
/*      */     final AtomicReference<Thread> edit;
/*      */     
/*      */     ArrayNode(AtomicReference<Thread> edit, int count, PersistentHashMap.INode[] array) {
/*  405 */       this.array = array;
/*  406 */       this.edit = edit;
/*  407 */       this.count = count;
/*      */     }
/*      */     
/*      */     public PersistentHashMap.INode assoc(int shift, int hash, Object key, Object val, Box addedLeaf) {
/*  411 */       int idx = PersistentHashMap.mask(hash, shift);
/*  412 */       PersistentHashMap.INode node = this.array[idx];
/*  413 */       if (node == null)
/*  414 */         return new ArrayNode(null, this.count + 1, PersistentHashMap.cloneAndSet(this.array, idx, PersistentHashMap.BitmapIndexedNode.EMPTY.assoc(shift + 5, hash, key, val, addedLeaf)));
/*  415 */       PersistentHashMap.INode n = node.assoc(shift + 5, hash, key, val, addedLeaf);
/*  416 */       if (n == node)
/*  417 */         return this;
/*  418 */       return new ArrayNode(null, this.count, PersistentHashMap.cloneAndSet(this.array, idx, n));
/*      */     }
/*      */     
/*      */     public PersistentHashMap.INode without(int shift, int hash, Object key) {
/*  422 */       int idx = PersistentHashMap.mask(hash, shift);
/*  423 */       PersistentHashMap.INode node = this.array[idx];
/*  424 */       if (node == null)
/*  425 */         return this;
/*  426 */       PersistentHashMap.INode n = node.without(shift + 5, hash, key);
/*  427 */       if (n == node)
/*  428 */         return this;
/*  429 */       if (n == null) {
/*  430 */         if (this.count <= 8)
/*  431 */           return pack(null, idx);
/*  432 */         return new ArrayNode(null, this.count - 1, PersistentHashMap.cloneAndSet(this.array, idx, n));
/*      */       }
/*  434 */       return new ArrayNode(null, this.count, PersistentHashMap.cloneAndSet(this.array, idx, n));
/*      */     }
/*      */     
/*      */     public IMapEntry find(int shift, int hash, Object key) {
/*  438 */       int idx = PersistentHashMap.mask(hash, shift);
/*  439 */       PersistentHashMap.INode node = this.array[idx];
/*  440 */       if (node == null)
/*  441 */         return null;
/*  442 */       return node.find(shift + 5, hash, key);
/*      */     }
/*      */     
/*      */     public Object find(int shift, int hash, Object key, Object notFound) {
/*  446 */       int idx = PersistentHashMap.mask(hash, shift);
/*  447 */       PersistentHashMap.INode node = this.array[idx];
/*  448 */       if (node == null)
/*  449 */         return notFound;
/*  450 */       return node.find(shift + 5, hash, key, notFound);
/*      */     }
/*      */     
/*      */     public ISeq nodeSeq() {
/*  454 */       return Seq.create(this.array);
/*      */     }
/*      */     
/*      */     public Iterator iterator(IFn f) {
/*  458 */       return new Iter(this.array, f, null);
/*      */     }
/*      */     
/*      */     public Object kvreduce(IFn f, Object init) {
/*  462 */       for (PersistentHashMap.INode node : this.array) {
/*  463 */         if (node != null) {
/*  464 */           init = node.kvreduce(f, init);
/*  465 */           if (RT.isReduced(init))
/*  466 */             return init;
/*      */         }
/*      */       }
/*  469 */       return init;
/*      */     }
/*      */     
/*      */     public Object fold(final IFn combinef, final IFn reducef, final IFn fjtask, final IFn fjfork, final IFn fjjoin)
/*      */     {
/*  474 */       List<Callable> tasks = new ArrayList();
/*  475 */       for (final PersistentHashMap.INode node : this.array) {
/*  476 */         if (node != null) {
/*  477 */           tasks.add(new Callable() {
/*      */             public Object call() throws Exception {
/*  479 */               return node.fold(combinef, reducef, fjtask, fjfork, fjjoin);
/*      */             }
/*      */           });
/*      */         }
/*      */       }
/*      */       
/*  485 */       return foldTasks(tasks, combinef, fjtask, fjfork, fjjoin);
/*      */     }
/*      */     
/*      */ 
/*      */     public static Object foldTasks(List<Callable> tasks, final IFn combinef, final IFn fjtask, final IFn fjfork, final IFn fjjoin)
/*      */     {
/*  491 */       if (tasks.isEmpty()) {
/*  492 */         return combinef.invoke();
/*      */       }
/*  494 */       if (tasks.size() == 1) {
/*  495 */         Object ret = null;
/*      */         try
/*      */         {
/*  498 */           return ((Callable)tasks.get(0)).call();
/*      */         }
/*      */         catch (Exception e)
/*      */         {
/*  502 */           throw Util.sneakyThrow(e);
/*      */         }
/*      */       }
/*      */       
/*  506 */       List<Callable> t1 = tasks.subList(0, tasks.size() / 2);
/*  507 */       List<Callable> t2 = tasks.subList(tasks.size() / 2, tasks.size());
/*      */       
/*  509 */       Object forked = fjfork.invoke(fjtask.invoke(new Callable() {
/*      */         public Object call() throws Exception {
/*  511 */           return PersistentHashMap.ArrayNode.foldTasks(this.val$t2, combinef, fjtask, fjfork, fjjoin);
/*      */         }
/*      */         
/*  514 */       }));
/*  515 */       return combinef.invoke(foldTasks(t1, combinef, fjtask, fjfork, fjjoin), fjjoin.invoke(forked));
/*      */     }
/*      */     
/*      */     private ArrayNode ensureEditable(AtomicReference<Thread> edit)
/*      */     {
/*  520 */       if (this.edit == edit)
/*  521 */         return this;
/*  522 */       return new ArrayNode(edit, this.count, (PersistentHashMap.INode[])this.array.clone());
/*      */     }
/*      */     
/*      */     private ArrayNode editAndSet(AtomicReference<Thread> edit, int i, PersistentHashMap.INode n) {
/*  526 */       ArrayNode editable = ensureEditable(edit);
/*  527 */       editable.array[i] = n;
/*  528 */       return editable;
/*      */     }
/*      */     
/*      */     private PersistentHashMap.INode pack(AtomicReference<Thread> edit, int idx)
/*      */     {
/*  533 */       Object[] newArray = new Object[2 * (this.count - 1)];
/*  534 */       int j = 1;
/*  535 */       int bitmap = 0;
/*  536 */       for (int i = 0; i < idx; i++)
/*  537 */         if (this.array[i] != null) {
/*  538 */           newArray[j] = this.array[i];
/*  539 */           bitmap |= 1 << i;
/*  540 */           j += 2;
/*      */         }
/*  542 */       for (int i = idx + 1; i < this.array.length; i++)
/*  543 */         if (this.array[i] != null) {
/*  544 */           newArray[j] = this.array[i];
/*  545 */           bitmap |= 1 << i;
/*  546 */           j += 2;
/*      */         }
/*  548 */       return new PersistentHashMap.BitmapIndexedNode(edit, bitmap, newArray);
/*      */     }
/*      */     
/*      */     public PersistentHashMap.INode assoc(AtomicReference<Thread> edit, int shift, int hash, Object key, Object val, Box addedLeaf) {
/*  552 */       int idx = PersistentHashMap.mask(hash, shift);
/*  553 */       PersistentHashMap.INode node = this.array[idx];
/*  554 */       if (node == null) {
/*  555 */         ArrayNode editable = editAndSet(edit, idx, PersistentHashMap.BitmapIndexedNode.EMPTY.assoc(edit, shift + 5, hash, key, val, addedLeaf));
/*  556 */         editable.count += 1;
/*  557 */         return editable;
/*      */       }
/*  559 */       PersistentHashMap.INode n = node.assoc(edit, shift + 5, hash, key, val, addedLeaf);
/*  560 */       if (n == node)
/*  561 */         return this;
/*  562 */       return editAndSet(edit, idx, n);
/*      */     }
/*      */     
/*      */     public PersistentHashMap.INode without(AtomicReference<Thread> edit, int shift, int hash, Object key, Box removedLeaf) {
/*  566 */       int idx = PersistentHashMap.mask(hash, shift);
/*  567 */       PersistentHashMap.INode node = this.array[idx];
/*  568 */       if (node == null)
/*  569 */         return this;
/*  570 */       PersistentHashMap.INode n = node.without(edit, shift + 5, hash, key, removedLeaf);
/*  571 */       if (n == node)
/*  572 */         return this;
/*  573 */       if (n == null) {
/*  574 */         if (this.count <= 8)
/*  575 */           return pack(edit, idx);
/*  576 */         ArrayNode editable = editAndSet(edit, idx, n);
/*  577 */         editable.count -= 1;
/*  578 */         return editable;
/*      */       }
/*  580 */       return editAndSet(edit, idx, n);
/*      */     }
/*      */     
/*      */     static class Seq extends ASeq {
/*      */       final PersistentHashMap.INode[] nodes;
/*      */       final int i;
/*      */       final ISeq s;
/*      */       
/*      */       static ISeq create(PersistentHashMap.INode[] nodes) {
/*  589 */         return create(null, nodes, 0, null);
/*      */       }
/*      */       
/*      */       private static ISeq create(IPersistentMap meta, PersistentHashMap.INode[] nodes, int i, ISeq s) {
/*  593 */         if (s != null)
/*  594 */           return new Seq(meta, nodes, i, s);
/*  595 */         for (int j = i; j < nodes.length; j++)
/*  596 */           if (nodes[j] != null) {
/*  597 */             ISeq ns = nodes[j].nodeSeq();
/*  598 */             if (ns != null)
/*  599 */               return new Seq(meta, nodes, j + 1, ns);
/*      */           }
/*  601 */         return null;
/*      */       }
/*      */       
/*      */       private Seq(IPersistentMap meta, PersistentHashMap.INode[] nodes, int i, ISeq s) {
/*  605 */         super();
/*  606 */         this.nodes = nodes;
/*  607 */         this.i = i;
/*  608 */         this.s = s;
/*      */       }
/*      */       
/*      */       public Obj withMeta(IPersistentMap meta) {
/*  612 */         return new Seq(meta, this.nodes, this.i, this.s);
/*      */       }
/*      */       
/*      */       public Object first() {
/*  616 */         return this.s.first();
/*      */       }
/*      */       
/*      */       public ISeq next() {
/*  620 */         return create(null, this.nodes, this.i, this.s.next());
/*      */       }
/*      */     }
/*      */     
/*      */     static class Iter implements Iterator
/*      */     {
/*      */       private final PersistentHashMap.INode[] array;
/*      */       private final IFn f;
/*  628 */       private int i = 0;
/*      */       private Iterator nestedIter;
/*      */       
/*      */       private Iter(PersistentHashMap.INode[] array, IFn f) {
/*  632 */         this.array = array;
/*  633 */         this.f = f;
/*      */       }
/*      */       
/*      */       public boolean hasNext()
/*      */       {
/*      */         for (;;) {
/*  639 */           if (this.nestedIter != null) {
/*  640 */             if (this.nestedIter.hasNext()) {
/*  641 */               return true;
/*      */             }
/*  643 */             this.nestedIter = null;
/*      */           }
/*  645 */           if (this.i >= this.array.length)
/*      */             break;
/*  647 */           PersistentHashMap.INode node = this.array[(this.i++)];
/*  648 */           if (node != null) {
/*  649 */             this.nestedIter = node.iterator(this.f);
/*      */           }
/*      */         }
/*  652 */         return false;
/*      */       }
/*      */       
/*      */       public Object next()
/*      */       {
/*  657 */         if (hasNext()) {
/*  658 */           return this.nestedIter.next();
/*      */         }
/*  660 */         throw new NoSuchElementException();
/*      */       }
/*      */       
/*      */       public void remove() {
/*  664 */         throw new UnsupportedOperationException();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   static final class BitmapIndexedNode implements PersistentHashMap.INode {
/*  670 */     static final BitmapIndexedNode EMPTY = new BitmapIndexedNode(null, 0, new Object[0]);
/*      */     int bitmap;
/*      */     Object[] array;
/*      */     final AtomicReference<Thread> edit;
/*      */     
/*      */     final int index(int bit)
/*      */     {
/*  677 */       return Integer.bitCount(this.bitmap & bit - 1);
/*      */     }
/*      */     
/*      */     BitmapIndexedNode(AtomicReference<Thread> edit, int bitmap, Object[] array) {
/*  681 */       this.bitmap = bitmap;
/*  682 */       this.array = array;
/*  683 */       this.edit = edit;
/*      */     }
/*      */     
/*      */     public PersistentHashMap.INode assoc(int shift, int hash, Object key, Object val, Box addedLeaf) {
/*  687 */       int bit = PersistentHashMap.bitpos(hash, shift);
/*  688 */       int idx = index(bit);
/*  689 */       if ((this.bitmap & bit) != 0) {
/*  690 */         Object keyOrNull = this.array[(2 * idx)];
/*  691 */         Object valOrNode = this.array[(2 * idx + 1)];
/*  692 */         if (keyOrNull == null) {
/*  693 */           PersistentHashMap.INode n = ((PersistentHashMap.INode)valOrNode).assoc(shift + 5, hash, key, val, addedLeaf);
/*  694 */           if (n == valOrNode)
/*  695 */             return this;
/*  696 */           return new BitmapIndexedNode(null, this.bitmap, PersistentHashMap.cloneAndSet(this.array, 2 * idx + 1, n));
/*      */         }
/*  698 */         if (Util.equiv(key, keyOrNull)) {
/*  699 */           if (val == valOrNode)
/*  700 */             return this;
/*  701 */           return new BitmapIndexedNode(null, this.bitmap, PersistentHashMap.cloneAndSet(this.array, 2 * idx + 1, val));
/*      */         }
/*  703 */         addedLeaf.val = addedLeaf;
/*  704 */         return new BitmapIndexedNode(null, this.bitmap, PersistentHashMap.cloneAndSet(this.array, 2 * idx, null, 2 * idx + 1, PersistentHashMap.access$400(shift + 5, keyOrNull, valOrNode, hash, key, val)));
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  709 */       int n = Integer.bitCount(this.bitmap);
/*  710 */       if (n >= 16) {
/*  711 */         PersistentHashMap.INode[] nodes = new PersistentHashMap.INode[32];
/*  712 */         int jdx = PersistentHashMap.mask(hash, shift);
/*  713 */         nodes[jdx] = EMPTY.assoc(shift + 5, hash, key, val, addedLeaf);
/*  714 */         int j = 0;
/*  715 */         for (int i = 0; i < 32; i++)
/*  716 */           if ((this.bitmap >>> i & 0x1) != 0) {
/*  717 */             if (this.array[j] == null) {
/*  718 */               nodes[i] = ((PersistentHashMap.INode)this.array[(j + 1)]);
/*      */             } else
/*  720 */               nodes[i] = EMPTY.assoc(shift + 5, PersistentHashMap.hash(this.array[j]), this.array[j], this.array[(j + 1)], addedLeaf);
/*  721 */             j += 2;
/*      */           }
/*  723 */         return new PersistentHashMap.ArrayNode(null, n + 1, nodes);
/*      */       }
/*  725 */       Object[] newArray = new Object[2 * (n + 1)];
/*  726 */       System.arraycopy(this.array, 0, newArray, 0, 2 * idx);
/*  727 */       newArray[(2 * idx)] = key;
/*  728 */       addedLeaf.val = addedLeaf;
/*  729 */       newArray[(2 * idx + 1)] = val;
/*  730 */       System.arraycopy(this.array, 2 * idx, newArray, 2 * (idx + 1), 2 * (n - idx));
/*  731 */       return new BitmapIndexedNode(null, this.bitmap | bit, newArray);
/*      */     }
/*      */     
/*      */ 
/*      */     public PersistentHashMap.INode without(int shift, int hash, Object key)
/*      */     {
/*  737 */       int bit = PersistentHashMap.bitpos(hash, shift);
/*  738 */       if ((this.bitmap & bit) == 0)
/*  739 */         return this;
/*  740 */       int idx = index(bit);
/*  741 */       Object keyOrNull = this.array[(2 * idx)];
/*  742 */       Object valOrNode = this.array[(2 * idx + 1)];
/*  743 */       if (keyOrNull == null) {
/*  744 */         PersistentHashMap.INode n = ((PersistentHashMap.INode)valOrNode).without(shift + 5, hash, key);
/*  745 */         if (n == valOrNode)
/*  746 */           return this;
/*  747 */         if (n != null)
/*  748 */           return new BitmapIndexedNode(null, this.bitmap, PersistentHashMap.cloneAndSet(this.array, 2 * idx + 1, n));
/*  749 */         if (this.bitmap == bit)
/*  750 */           return null;
/*  751 */         return new BitmapIndexedNode(null, this.bitmap ^ bit, PersistentHashMap.removePair(this.array, idx));
/*      */       }
/*  753 */       if (Util.equiv(key, keyOrNull))
/*      */       {
/*  755 */         return new BitmapIndexedNode(null, this.bitmap ^ bit, PersistentHashMap.removePair(this.array, idx)); }
/*  756 */       return this;
/*      */     }
/*      */     
/*      */     public IMapEntry find(int shift, int hash, Object key) {
/*  760 */       int bit = PersistentHashMap.bitpos(hash, shift);
/*  761 */       if ((this.bitmap & bit) == 0)
/*  762 */         return null;
/*  763 */       int idx = index(bit);
/*  764 */       Object keyOrNull = this.array[(2 * idx)];
/*  765 */       Object valOrNode = this.array[(2 * idx + 1)];
/*  766 */       if (keyOrNull == null)
/*  767 */         return ((PersistentHashMap.INode)valOrNode).find(shift + 5, hash, key);
/*  768 */       if (Util.equiv(key, keyOrNull))
/*  769 */         return MapEntry.create(keyOrNull, valOrNode);
/*  770 */       return null;
/*      */     }
/*      */     
/*      */     public Object find(int shift, int hash, Object key, Object notFound) {
/*  774 */       int bit = PersistentHashMap.bitpos(hash, shift);
/*  775 */       if ((this.bitmap & bit) == 0)
/*  776 */         return notFound;
/*  777 */       int idx = index(bit);
/*  778 */       Object keyOrNull = this.array[(2 * idx)];
/*  779 */       Object valOrNode = this.array[(2 * idx + 1)];
/*  780 */       if (keyOrNull == null)
/*  781 */         return ((PersistentHashMap.INode)valOrNode).find(shift + 5, hash, key, notFound);
/*  782 */       if (Util.equiv(key, keyOrNull))
/*  783 */         return valOrNode;
/*  784 */       return notFound;
/*      */     }
/*      */     
/*      */     public ISeq nodeSeq() {
/*  788 */       return PersistentHashMap.NodeSeq.create(this.array);
/*      */     }
/*      */     
/*      */     public Iterator iterator(IFn f) {
/*  792 */       return new PersistentHashMap.NodeIter(this.array, f);
/*      */     }
/*      */     
/*      */     public Object kvreduce(IFn f, Object init) {
/*  796 */       return PersistentHashMap.NodeSeq.kvreduce(this.array, f, init);
/*      */     }
/*      */     
/*      */     public Object fold(IFn combinef, IFn reducef, IFn fjtask, IFn fjfork, IFn fjjoin) {
/*  800 */       return PersistentHashMap.NodeSeq.kvreduce(this.array, reducef, combinef.invoke());
/*      */     }
/*      */     
/*      */     private BitmapIndexedNode ensureEditable(AtomicReference<Thread> edit) {
/*  804 */       if (this.edit == edit)
/*  805 */         return this;
/*  806 */       int n = Integer.bitCount(this.bitmap);
/*  807 */       Object[] newArray = new Object[n >= 0 ? 2 * (n + 1) : 4];
/*  808 */       System.arraycopy(this.array, 0, newArray, 0, 2 * n);
/*  809 */       return new BitmapIndexedNode(edit, this.bitmap, newArray);
/*      */     }
/*      */     
/*      */     private BitmapIndexedNode editAndSet(AtomicReference<Thread> edit, int i, Object a) {
/*  813 */       BitmapIndexedNode editable = ensureEditable(edit);
/*  814 */       editable.array[i] = a;
/*  815 */       return editable;
/*      */     }
/*      */     
/*      */     private BitmapIndexedNode editAndSet(AtomicReference<Thread> edit, int i, Object a, int j, Object b) {
/*  819 */       BitmapIndexedNode editable = ensureEditable(edit);
/*  820 */       editable.array[i] = a;
/*  821 */       editable.array[j] = b;
/*  822 */       return editable;
/*      */     }
/*      */     
/*      */     private BitmapIndexedNode editAndRemovePair(AtomicReference<Thread> edit, int bit, int i) {
/*  826 */       if (this.bitmap == bit)
/*  827 */         return null;
/*  828 */       BitmapIndexedNode editable = ensureEditable(edit);
/*  829 */       editable.bitmap ^= bit;
/*  830 */       System.arraycopy(editable.array, 2 * (i + 1), editable.array, 2 * i, editable.array.length - 2 * (i + 1));
/*  831 */       editable.array[(editable.array.length - 2)] = null;
/*  832 */       editable.array[(editable.array.length - 1)] = null;
/*  833 */       return editable;
/*      */     }
/*      */     
/*      */     public PersistentHashMap.INode assoc(AtomicReference<Thread> edit, int shift, int hash, Object key, Object val, Box addedLeaf) {
/*  837 */       int bit = PersistentHashMap.bitpos(hash, shift);
/*  838 */       int idx = index(bit);
/*  839 */       if ((this.bitmap & bit) != 0) {
/*  840 */         Object keyOrNull = this.array[(2 * idx)];
/*  841 */         Object valOrNode = this.array[(2 * idx + 1)];
/*  842 */         if (keyOrNull == null) {
/*  843 */           PersistentHashMap.INode n = ((PersistentHashMap.INode)valOrNode).assoc(edit, shift + 5, hash, key, val, addedLeaf);
/*  844 */           if (n == valOrNode)
/*  845 */             return this;
/*  846 */           return editAndSet(edit, 2 * idx + 1, n);
/*      */         }
/*  848 */         if (Util.equiv(key, keyOrNull)) {
/*  849 */           if (val == valOrNode)
/*  850 */             return this;
/*  851 */           return editAndSet(edit, 2 * idx + 1, val);
/*      */         }
/*  853 */         addedLeaf.val = addedLeaf;
/*  854 */         return editAndSet(edit, 2 * idx, null, 2 * idx + 1, PersistentHashMap.createNode(edit, shift + 5, keyOrNull, valOrNode, hash, key, val));
/*      */       }
/*      */       
/*  857 */       int n = Integer.bitCount(this.bitmap);
/*  858 */       if (n * 2 < this.array.length) {
/*  859 */         addedLeaf.val = addedLeaf;
/*  860 */         BitmapIndexedNode editable = ensureEditable(edit);
/*  861 */         System.arraycopy(editable.array, 2 * idx, editable.array, 2 * (idx + 1), 2 * (n - idx));
/*  862 */         editable.array[(2 * idx)] = key;
/*  863 */         editable.array[(2 * idx + 1)] = val;
/*  864 */         editable.bitmap |= bit;
/*  865 */         return editable;
/*      */       }
/*  867 */       if (n >= 16) {
/*  868 */         PersistentHashMap.INode[] nodes = new PersistentHashMap.INode[32];
/*  869 */         int jdx = PersistentHashMap.mask(hash, shift);
/*  870 */         nodes[jdx] = EMPTY.assoc(edit, shift + 5, hash, key, val, addedLeaf);
/*  871 */         int j = 0;
/*  872 */         for (int i = 0; i < 32; i++)
/*  873 */           if ((this.bitmap >>> i & 0x1) != 0) {
/*  874 */             if (this.array[j] == null) {
/*  875 */               nodes[i] = ((PersistentHashMap.INode)this.array[(j + 1)]);
/*      */             } else
/*  877 */               nodes[i] = EMPTY.assoc(edit, shift + 5, PersistentHashMap.hash(this.array[j]), this.array[j], this.array[(j + 1)], addedLeaf);
/*  878 */             j += 2;
/*      */           }
/*  880 */         return new PersistentHashMap.ArrayNode(edit, n + 1, nodes);
/*      */       }
/*  882 */       Object[] newArray = new Object[2 * (n + 4)];
/*  883 */       System.arraycopy(this.array, 0, newArray, 0, 2 * idx);
/*  884 */       newArray[(2 * idx)] = key;
/*  885 */       addedLeaf.val = addedLeaf;
/*  886 */       newArray[(2 * idx + 1)] = val;
/*  887 */       System.arraycopy(this.array, 2 * idx, newArray, 2 * (idx + 1), 2 * (n - idx));
/*  888 */       BitmapIndexedNode editable = ensureEditable(edit);
/*  889 */       editable.array = newArray;
/*  890 */       editable.bitmap |= bit;
/*  891 */       return editable;
/*      */     }
/*      */     
/*      */ 
/*      */     public PersistentHashMap.INode without(AtomicReference<Thread> edit, int shift, int hash, Object key, Box removedLeaf)
/*      */     {
/*  897 */       int bit = PersistentHashMap.bitpos(hash, shift);
/*  898 */       if ((this.bitmap & bit) == 0)
/*  899 */         return this;
/*  900 */       int idx = index(bit);
/*  901 */       Object keyOrNull = this.array[(2 * idx)];
/*  902 */       Object valOrNode = this.array[(2 * idx + 1)];
/*  903 */       if (keyOrNull == null) {
/*  904 */         PersistentHashMap.INode n = ((PersistentHashMap.INode)valOrNode).without(edit, shift + 5, hash, key, removedLeaf);
/*  905 */         if (n == valOrNode)
/*  906 */           return this;
/*  907 */         if (n != null)
/*  908 */           return editAndSet(edit, 2 * idx + 1, n);
/*  909 */         if (this.bitmap == bit)
/*  910 */           return null;
/*  911 */         return editAndRemovePair(edit, bit, idx);
/*      */       }
/*  913 */       if (Util.equiv(key, keyOrNull)) {
/*  914 */         removedLeaf.val = removedLeaf;
/*      */         
/*  916 */         return editAndRemovePair(edit, bit, idx);
/*      */       }
/*  918 */       return this;
/*      */     }
/*      */   }
/*      */   
/*      */   static final class HashCollisionNode implements PersistentHashMap.INode
/*      */   {
/*      */     final int hash;
/*      */     int count;
/*      */     Object[] array;
/*      */     final AtomicReference<Thread> edit;
/*      */     
/*      */     HashCollisionNode(AtomicReference<Thread> edit, int hash, int count, Object... array) {
/*  930 */       this.edit = edit;
/*  931 */       this.hash = hash;
/*  932 */       this.count = count;
/*  933 */       this.array = array;
/*      */     }
/*      */     
/*      */     public PersistentHashMap.INode assoc(int shift, int hash, Object key, Object val, Box addedLeaf) {
/*  937 */       if (hash == this.hash) {
/*  938 */         int idx = findIndex(key);
/*  939 */         if (idx != -1) {
/*  940 */           if (this.array[(idx + 1)] == val)
/*  941 */             return this;
/*  942 */           return new HashCollisionNode(null, hash, this.count, PersistentHashMap.cloneAndSet(this.array, idx + 1, val));
/*      */         }
/*  944 */         Object[] newArray = new Object[2 * (this.count + 1)];
/*  945 */         System.arraycopy(this.array, 0, newArray, 0, 2 * this.count);
/*  946 */         newArray[(2 * this.count)] = key;
/*  947 */         newArray[(2 * this.count + 1)] = val;
/*  948 */         addedLeaf.val = addedLeaf;
/*  949 */         return new HashCollisionNode(this.edit, hash, this.count + 1, newArray);
/*      */       }
/*      */       
/*  952 */       return new PersistentHashMap.BitmapIndexedNode(null, PersistentHashMap.bitpos(this.hash, shift), new Object[] { null, this }).assoc(shift, hash, key, val, addedLeaf);
/*      */     }
/*      */     
/*      */     public PersistentHashMap.INode without(int shift, int hash, Object key)
/*      */     {
/*  957 */       int idx = findIndex(key);
/*  958 */       if (idx == -1)
/*  959 */         return this;
/*  960 */       if (this.count == 1)
/*  961 */         return null;
/*  962 */       return new HashCollisionNode(null, hash, this.count - 1, PersistentHashMap.removePair(this.array, idx / 2));
/*      */     }
/*      */     
/*      */     public IMapEntry find(int shift, int hash, Object key) {
/*  966 */       int idx = findIndex(key);
/*  967 */       if (idx < 0)
/*  968 */         return null;
/*  969 */       if (Util.equiv(key, this.array[idx]))
/*  970 */         return MapEntry.create(this.array[idx], this.array[(idx + 1)]);
/*  971 */       return null;
/*      */     }
/*      */     
/*      */     public Object find(int shift, int hash, Object key, Object notFound) {
/*  975 */       int idx = findIndex(key);
/*  976 */       if (idx < 0)
/*  977 */         return notFound;
/*  978 */       if (Util.equiv(key, this.array[idx]))
/*  979 */         return this.array[(idx + 1)];
/*  980 */       return notFound;
/*      */     }
/*      */     
/*      */     public ISeq nodeSeq() {
/*  984 */       return PersistentHashMap.NodeSeq.create(this.array);
/*      */     }
/*      */     
/*      */     public Iterator iterator(IFn f) {
/*  988 */       return new PersistentHashMap.NodeIter(this.array, f);
/*      */     }
/*      */     
/*      */     public Object kvreduce(IFn f, Object init) {
/*  992 */       return PersistentHashMap.NodeSeq.kvreduce(this.array, f, init);
/*      */     }
/*      */     
/*      */     public Object fold(IFn combinef, IFn reducef, IFn fjtask, IFn fjfork, IFn fjjoin) {
/*  996 */       return PersistentHashMap.NodeSeq.kvreduce(this.array, reducef, combinef.invoke());
/*      */     }
/*      */     
/*      */     public int findIndex(Object key) {
/* 1000 */       for (int i = 0; i < 2 * this.count; i += 2)
/*      */       {
/* 1002 */         if (Util.equiv(key, this.array[i]))
/* 1003 */           return i;
/*      */       }
/* 1005 */       return -1;
/*      */     }
/*      */     
/*      */     private HashCollisionNode ensureEditable(AtomicReference<Thread> edit) {
/* 1009 */       if (this.edit == edit)
/* 1010 */         return this;
/* 1011 */       Object[] newArray = new Object[2 * (this.count + 1)];
/* 1012 */       System.arraycopy(this.array, 0, newArray, 0, 2 * this.count);
/* 1013 */       return new HashCollisionNode(edit, this.hash, this.count, newArray);
/*      */     }
/*      */     
/*      */     private HashCollisionNode ensureEditable(AtomicReference<Thread> edit, int count, Object[] array) {
/* 1017 */       if (this.edit == edit) {
/* 1018 */         this.array = array;
/* 1019 */         this.count = count;
/* 1020 */         return this;
/*      */       }
/* 1022 */       return new HashCollisionNode(edit, this.hash, count, array);
/*      */     }
/*      */     
/*      */     private HashCollisionNode editAndSet(AtomicReference<Thread> edit, int i, Object a) {
/* 1026 */       HashCollisionNode editable = ensureEditable(edit);
/* 1027 */       editable.array[i] = a;
/* 1028 */       return editable;
/*      */     }
/*      */     
/*      */     private HashCollisionNode editAndSet(AtomicReference<Thread> edit, int i, Object a, int j, Object b) {
/* 1032 */       HashCollisionNode editable = ensureEditable(edit);
/* 1033 */       editable.array[i] = a;
/* 1034 */       editable.array[j] = b;
/* 1035 */       return editable;
/*      */     }
/*      */     
/*      */     public PersistentHashMap.INode assoc(AtomicReference<Thread> edit, int shift, int hash, Object key, Object val, Box addedLeaf)
/*      */     {
/* 1040 */       if (hash == this.hash) {
/* 1041 */         int idx = findIndex(key);
/* 1042 */         if (idx != -1) {
/* 1043 */           if (this.array[(idx + 1)] == val)
/* 1044 */             return this;
/* 1045 */           return editAndSet(edit, idx + 1, val);
/*      */         }
/* 1047 */         if (this.array.length > 2 * this.count) {
/* 1048 */           addedLeaf.val = addedLeaf;
/* 1049 */           HashCollisionNode editable = editAndSet(edit, 2 * this.count, key, 2 * this.count + 1, val);
/* 1050 */           editable.count += 1;
/* 1051 */           return editable;
/*      */         }
/* 1053 */         Object[] newArray = new Object[this.array.length + 2];
/* 1054 */         System.arraycopy(this.array, 0, newArray, 0, this.array.length);
/* 1055 */         newArray[this.array.length] = key;
/* 1056 */         newArray[(this.array.length + 1)] = val;
/* 1057 */         addedLeaf.val = addedLeaf;
/* 1058 */         return ensureEditable(edit, this.count + 1, newArray);
/*      */       }
/*      */       
/* 1061 */       return new PersistentHashMap.BitmapIndexedNode(edit, PersistentHashMap.bitpos(this.hash, shift), new Object[] { null, this, null, null }).assoc(edit, shift, hash, key, val, addedLeaf);
/*      */     }
/*      */     
/*      */     public PersistentHashMap.INode without(AtomicReference<Thread> edit, int shift, int hash, Object key, Box removedLeaf)
/*      */     {
/* 1066 */       int idx = findIndex(key);
/* 1067 */       if (idx == -1)
/* 1068 */         return this;
/* 1069 */       removedLeaf.val = removedLeaf;
/* 1070 */       if (this.count == 1)
/* 1071 */         return null;
/* 1072 */       HashCollisionNode editable = ensureEditable(edit);
/* 1073 */       editable.array[idx] = editable.array[(2 * this.count - 2)];
/* 1074 */       editable.array[(idx + 1)] = editable.array[(2 * this.count - 1)];
/* 1075 */       editable.array[(2 * this.count - 2)] = (editable.array[(2 * this.count - 1)] = null);
/* 1076 */       editable.count -= 1;
/* 1077 */       return editable;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static INode[] cloneAndSet(INode[] array, int i, INode a)
/*      */   {
/* 1169 */     INode[] clone = (INode[])array.clone();
/* 1170 */     clone[i] = a;
/* 1171 */     return clone;
/*      */   }
/*      */   
/*      */   private static Object[] cloneAndSet(Object[] array, int i, Object a) {
/* 1175 */     Object[] clone = (Object[])array.clone();
/* 1176 */     clone[i] = a;
/* 1177 */     return clone;
/*      */   }
/*      */   
/*      */   private static Object[] cloneAndSet(Object[] array, int i, Object a, int j, Object b) {
/* 1181 */     Object[] clone = (Object[])array.clone();
/* 1182 */     clone[i] = a;
/* 1183 */     clone[j] = b;
/* 1184 */     return clone;
/*      */   }
/*      */   
/*      */   private static Object[] removePair(Object[] array, int i) {
/* 1188 */     Object[] newArray = new Object[array.length - 2];
/* 1189 */     System.arraycopy(array, 0, newArray, 0, 2 * i);
/* 1190 */     System.arraycopy(array, 2 * (i + 1), newArray, 2 * i, newArray.length - 2 * i);
/* 1191 */     return newArray;
/*      */   }
/*      */   
/*      */   private static INode createNode(int shift, Object key1, Object val1, int key2hash, Object key2, Object val2) {
/* 1195 */     int key1hash = hash(key1);
/* 1196 */     if (key1hash == key2hash)
/* 1197 */       return new HashCollisionNode(null, key1hash, 2, new Object[] { key1, val1, key2, val2 });
/* 1198 */     Box addedLeaf = new Box(null);
/* 1199 */     AtomicReference<Thread> edit = new AtomicReference();
/* 1200 */     return BitmapIndexedNode.EMPTY.assoc(edit, shift, key1hash, key1, val1, addedLeaf).assoc(edit, shift, key2hash, key2, val2, addedLeaf);
/*      */   }
/*      */   
/*      */ 
/*      */   private static INode createNode(AtomicReference<Thread> edit, int shift, Object key1, Object val1, int key2hash, Object key2, Object val2)
/*      */   {
/* 1206 */     int key1hash = hash(key1);
/* 1207 */     if (key1hash == key2hash)
/* 1208 */       return new HashCollisionNode(null, key1hash, 2, new Object[] { key1, val1, key2, val2 });
/* 1209 */     Box addedLeaf = new Box(null);
/* 1210 */     return BitmapIndexedNode.EMPTY.assoc(edit, shift, key1hash, key1, val1, addedLeaf).assoc(edit, shift, key2hash, key2, val2, addedLeaf);
/*      */   }
/*      */   
/*      */ 
/*      */   private static int bitpos(int hash, int shift)
/*      */   {
/* 1216 */     return 1 << mask(hash, shift);
/*      */   }
/*      */   
/*      */   static final class NodeIter implements Iterator {
/* 1220 */     private static final Object NULL = new Object();
/*      */     final Object[] array;
/*      */     final IFn f;
/* 1223 */     private int i = 0;
/* 1224 */     private Object nextEntry = NULL;
/*      */     private Iterator nextIter;
/*      */     
/*      */     NodeIter(Object[] array, IFn f) {
/* 1228 */       this.array = array;
/* 1229 */       this.f = f;
/*      */     }
/*      */     
/*      */     private boolean advance() {
/* 1233 */       while (this.i < this.array.length)
/*      */       {
/* 1235 */         Object key = this.array[this.i];
/* 1236 */         Object nodeOrVal = this.array[(this.i + 1)];
/* 1237 */         this.i += 2;
/* 1238 */         if (key != null)
/*      */         {
/* 1240 */           this.nextEntry = this.f.invoke(key, nodeOrVal);
/* 1241 */           return true;
/*      */         }
/* 1243 */         if (nodeOrVal != null)
/*      */         {
/* 1245 */           Iterator iter = ((PersistentHashMap.INode)nodeOrVal).iterator(this.f);
/* 1246 */           if ((iter != null) && (iter.hasNext()))
/*      */           {
/* 1248 */             this.nextIter = iter;
/* 1249 */             return true;
/*      */           }
/*      */         }
/*      */       }
/* 1253 */       return false;
/*      */     }
/*      */     
/*      */     public boolean hasNext() {
/* 1257 */       if ((this.nextEntry != NULL) || (this.nextIter != null))
/* 1258 */         return true;
/* 1259 */       return advance();
/*      */     }
/*      */     
/*      */     public Object next() {
/* 1263 */       Object ret = this.nextEntry;
/* 1264 */       if (ret != NULL)
/*      */       {
/* 1266 */         this.nextEntry = NULL;
/* 1267 */         return ret;
/*      */       }
/* 1269 */       if (this.nextIter != null)
/*      */       {
/* 1271 */         ret = this.nextIter.next();
/* 1272 */         if (!this.nextIter.hasNext())
/* 1273 */           this.nextIter = null;
/* 1274 */         return ret;
/*      */       }
/* 1276 */       if (advance())
/* 1277 */         return next();
/* 1278 */       throw new NoSuchElementException();
/*      */     }
/*      */     
/*      */     public void remove() {
/* 1282 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */   
/*      */   static final class NodeSeq extends ASeq {
/*      */     final Object[] array;
/*      */     final int i;
/*      */     final ISeq s;
/*      */     
/*      */     NodeSeq(Object[] array, int i) {
/* 1292 */       this(null, array, i, null);
/*      */     }
/*      */     
/*      */     static ISeq create(Object[] array) {
/* 1296 */       return create(array, 0, null);
/*      */     }
/*      */     
/*      */     public static Object kvreduce(Object[] array, IFn f, Object init) {
/* 1300 */       for (int i = 0; i < array.length; i += 2)
/*      */       {
/* 1302 */         if (array[i] != null) {
/* 1303 */           init = f.invoke(init, array[i], array[(i + 1)]);
/*      */         }
/*      */         else {
/* 1306 */           PersistentHashMap.INode node = (PersistentHashMap.INode)array[(i + 1)];
/* 1307 */           if (node != null)
/* 1308 */             init = node.kvreduce(f, init);
/*      */         }
/* 1310 */         if (RT.isReduced(init))
/* 1311 */           return init;
/*      */       }
/* 1313 */       return init;
/*      */     }
/*      */     
/*      */     private static ISeq create(Object[] array, int i, ISeq s) {
/* 1317 */       if (s != null)
/* 1318 */         return new NodeSeq(null, array, i, s);
/* 1319 */       for (int j = i; j < array.length; j += 2) {
/* 1320 */         if (array[j] != null)
/* 1321 */           return new NodeSeq(null, array, j, null);
/* 1322 */         PersistentHashMap.INode node = (PersistentHashMap.INode)array[(j + 1)];
/* 1323 */         if (node != null) {
/* 1324 */           ISeq nodeSeq = node.nodeSeq();
/* 1325 */           if (nodeSeq != null)
/* 1326 */             return new NodeSeq(null, array, j + 2, nodeSeq);
/*      */         }
/*      */       }
/* 1329 */       return null;
/*      */     }
/*      */     
/*      */     NodeSeq(IPersistentMap meta, Object[] array, int i, ISeq s) {
/* 1333 */       super();
/* 1334 */       this.array = array;
/* 1335 */       this.i = i;
/* 1336 */       this.s = s;
/*      */     }
/*      */     
/*      */     public Obj withMeta(IPersistentMap meta) {
/* 1340 */       return new NodeSeq(meta, this.array, this.i, this.s);
/*      */     }
/*      */     
/*      */     public Object first() {
/* 1344 */       if (this.s != null)
/* 1345 */         return this.s.first();
/* 1346 */       return MapEntry.create(this.array[this.i], this.array[(this.i + 1)]);
/*      */     }
/*      */     
/*      */     public ISeq next() {
/* 1350 */       if (this.s != null)
/* 1351 */         return create(this.array, this.i, this.s.next());
/* 1352 */       return create(this.array, this.i + 2, null);
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\PersistentHashMap.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */