/*     */ package clojure.lang;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.NoSuchElementException;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PersistentStructMap
/*     */   extends APersistentMap
/*     */   implements IObj
/*     */ {
/*     */   final Def def;
/*     */   final Object[] vals;
/*     */   final IPersistentMap ext;
/*     */   final IPersistentMap _meta;
/*     */   
/*     */   public static class Def
/*     */     implements Serializable
/*     */   {
/*     */     final ISeq keys;
/*     */     final IPersistentMap keyslots;
/*     */     
/*     */     Def(ISeq keys, IPersistentMap keyslots)
/*     */     {
/*  27 */       this.keys = keys;
/*  28 */       this.keyslots = keyslots;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Def createSlotMap(ISeq keys)
/*     */   {
/*  39 */     if (keys == null)
/*  40 */       throw new IllegalArgumentException("Must supply keys");
/*  41 */     int c = RT.count(keys);
/*  42 */     Object[] v = new Object[2 * c];
/*  43 */     int i = 0;
/*  44 */     for (ISeq s = keys; s != null; i++)
/*     */     {
/*  46 */       v[(2 * i)] = s.first();
/*  47 */       v[(2 * i + 1)] = Integer.valueOf(i);s = s.next();
/*     */     }
/*     */     
/*  49 */     return new Def(keys, RT.map(v));
/*     */   }
/*     */   
/*     */   public static PersistentStructMap create(Def def, ISeq keyvals) {
/*  53 */     Object[] vals = new Object[def.keyslots.count()];
/*  54 */     IPersistentMap ext = PersistentHashMap.EMPTY;
/*  55 */     for (; keyvals != null; keyvals = keyvals.next().next())
/*     */     {
/*  57 */       if (keyvals.next() == null)
/*  58 */         throw new IllegalArgumentException(String.format("No value supplied for key: %s", new Object[] { keyvals.first() }));
/*  59 */       Object k = keyvals.first();
/*  60 */       Object v = RT.second(keyvals);
/*  61 */       Map.Entry e = def.keyslots.entryAt(k);
/*  62 */       if (e != null) {
/*  63 */         vals[((Integer)e.getValue()).intValue()] = v;
/*     */       } else
/*  65 */         ext = ext.assoc(k, v);
/*     */     }
/*  67 */     return new PersistentStructMap(null, def, vals, ext);
/*     */   }
/*     */   
/*     */   public static PersistentStructMap construct(Def def, ISeq valseq) {
/*  71 */     Object[] vals = new Object[def.keyslots.count()];
/*  72 */     IPersistentMap ext = PersistentHashMap.EMPTY;
/*  73 */     for (int i = 0; (i < vals.length) && (valseq != null); i++)
/*     */     {
/*  75 */       vals[i] = valseq.first();valseq = valseq.next();
/*     */     }
/*  77 */     if (valseq != null)
/*  78 */       throw new IllegalArgumentException("Too many arguments to struct constructor");
/*  79 */     return new PersistentStructMap(null, def, vals, ext);
/*     */   }
/*     */   
/*     */   public static IFn getAccessor(Def def, Object key) {
/*  83 */     Map.Entry e = def.keyslots.entryAt(key);
/*  84 */     if (e != null)
/*     */     {
/*  86 */       final int i = ((Integer)e.getValue()).intValue();
/*  87 */       new AFn() {
/*     */         public Object invoke(Object arg1) {
/*  89 */           PersistentStructMap m = (PersistentStructMap)arg1;
/*  90 */           if (m.def != this.val$def)
/*  91 */             throw Util.runtimeException("Accessor/struct mismatch");
/*  92 */           return m.vals[i];
/*     */         }
/*     */       };
/*     */     }
/*  96 */     throw new IllegalArgumentException("Not a key of struct");
/*     */   }
/*     */   
/*     */   protected PersistentStructMap(IPersistentMap meta, Def def, Object[] vals, IPersistentMap ext) {
/* 100 */     this._meta = meta;
/* 101 */     this.ext = ext;
/* 102 */     this.def = def;
/* 103 */     this.vals = vals;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected PersistentStructMap makeNew(IPersistentMap meta, Def def, Object[] vals, IPersistentMap ext)
/*     */   {
/* 114 */     return new PersistentStructMap(meta, def, vals, ext);
/*     */   }
/*     */   
/*     */   public IObj withMeta(IPersistentMap meta) {
/* 118 */     if (meta == this._meta)
/* 119 */       return this;
/* 120 */     return makeNew(meta, this.def, this.vals, this.ext);
/*     */   }
/*     */   
/*     */   public IPersistentMap meta() {
/* 124 */     return this._meta;
/*     */   }
/*     */   
/*     */   public boolean containsKey(Object key) {
/* 128 */     return (this.def.keyslots.containsKey(key)) || (this.ext.containsKey(key));
/*     */   }
/*     */   
/*     */   public IMapEntry entryAt(Object key) {
/* 132 */     Map.Entry e = this.def.keyslots.entryAt(key);
/* 133 */     if (e != null)
/*     */     {
/* 135 */       return MapEntry.create(e.getKey(), this.vals[((Integer)e.getValue()).intValue()]);
/*     */     }
/* 137 */     return this.ext.entryAt(key);
/*     */   }
/*     */   
/*     */   public IPersistentMap assoc(Object key, Object val) {
/* 141 */     Map.Entry e = this.def.keyslots.entryAt(key);
/* 142 */     if (e != null)
/*     */     {
/* 144 */       int i = ((Integer)e.getValue()).intValue();
/* 145 */       Object[] newVals = (Object[])this.vals.clone();
/* 146 */       newVals[i] = val;
/* 147 */       return makeNew(this._meta, this.def, newVals, this.ext);
/*     */     }
/* 149 */     return makeNew(this._meta, this.def, this.vals, this.ext.assoc(key, val));
/*     */   }
/*     */   
/*     */   public Object valAt(Object key) {
/* 153 */     Integer i = (Integer)this.def.keyslots.valAt(key);
/* 154 */     if (i != null)
/*     */     {
/* 156 */       return this.vals[i.intValue()];
/*     */     }
/* 158 */     return this.ext.valAt(key);
/*     */   }
/*     */   
/*     */   public Object valAt(Object key, Object notFound) {
/* 162 */     Integer i = (Integer)this.def.keyslots.valAt(key);
/* 163 */     if (i != null)
/*     */     {
/* 165 */       return this.vals[i.intValue()];
/*     */     }
/* 167 */     return this.ext.valAt(key, notFound);
/*     */   }
/*     */   
/*     */   public IPersistentMap assocEx(Object key, Object val) {
/* 171 */     if (containsKey(key))
/* 172 */       throw Util.runtimeException("Key already present");
/* 173 */     return assoc(key, val);
/*     */   }
/*     */   
/*     */   public IPersistentMap without(Object key) {
/* 177 */     Map.Entry e = this.def.keyslots.entryAt(key);
/* 178 */     if (e != null)
/* 179 */       throw Util.runtimeException("Can't remove struct key");
/* 180 */     IPersistentMap newExt = this.ext.without(key);
/* 181 */     if (newExt == this.ext)
/* 182 */       return this;
/* 183 */     return makeNew(this._meta, this.def, this.vals, newExt);
/*     */   }
/*     */   
/*     */   public Iterator iterator() {
/* 187 */     new Iterator() {
/* 188 */       private ISeq ks = PersistentStructMap.this.def.keys;
/* 189 */       private Iterator extIter = PersistentStructMap.this.ext == null ? null : PersistentStructMap.this.ext.iterator();
/*     */       
/*     */       public boolean hasNext() {
/* 192 */         return ((this.ks != null) && (this.ks.seq() != null)) || ((this.extIter != null) && (this.extIter.hasNext()));
/*     */       }
/*     */       
/*     */       public Object next() {
/* 196 */         if (this.ks != null)
/*     */         {
/* 198 */           Object key = this.ks.first();
/* 199 */           this.ks = this.ks.next();
/* 200 */           return PersistentStructMap.this.entryAt(key);
/*     */         }
/* 202 */         if ((this.extIter != null) && (this.extIter.hasNext())) {
/* 203 */           return this.extIter.next();
/*     */         }
/* 205 */         throw new NoSuchElementException();
/*     */       }
/*     */       
/*     */       public void remove() {
/* 209 */         throw new UnsupportedOperationException();
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */   public int count() {
/* 215 */     return this.vals.length + RT.count(this.ext);
/*     */   }
/*     */   
/*     */   public ISeq seq() {
/* 219 */     return new Seq(null, this.def.keys, this.vals, 0, this.ext);
/*     */   }
/*     */   
/*     */   public IPersistentCollection empty() {
/* 223 */     return construct(this.def, null);
/*     */   }
/*     */   
/*     */   static class Seq extends ASeq
/*     */   {
/*     */     final int i;
/*     */     final ISeq keys;
/*     */     final Object[] vals;
/*     */     final IPersistentMap ext;
/*     */     
/*     */     public Seq(IPersistentMap meta, ISeq keys, Object[] vals, int i, IPersistentMap ext) {
/* 234 */       super();
/* 235 */       this.i = i;
/* 236 */       this.keys = keys;
/* 237 */       this.vals = vals;
/* 238 */       this.ext = ext;
/*     */     }
/*     */     
/*     */     public Obj withMeta(IPersistentMap meta) {
/* 242 */       if (meta != this._meta)
/* 243 */         return new Seq(meta, this.keys, this.vals, this.i, this.ext);
/* 244 */       return this;
/*     */     }
/*     */     
/*     */     public Object first() {
/* 248 */       return MapEntry.create(this.keys.first(), this.vals[this.i]);
/*     */     }
/*     */     
/*     */     public ISeq next() {
/* 252 */       if (this.i + 1 < this.vals.length)
/* 253 */         return new Seq(this._meta, this.keys.next(), this.vals, this.i + 1, this.ext);
/* 254 */       return this.ext.seq();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\PersistentStructMap.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */