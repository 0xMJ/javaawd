package clojure.lang;

import java.util.Map.Entry;

public abstract interface IMapEntry
  extends Map.Entry
{
  public abstract Object key();
  
  public abstract Object val();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\IMapEntry.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */