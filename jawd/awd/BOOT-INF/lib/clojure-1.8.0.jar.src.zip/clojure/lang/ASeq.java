/*     */ package clojure.lang;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ 
/*     */ 
/*     */ public abstract class ASeq
/*     */   extends Obj
/*     */   implements ISeq, Sequential, List, Serializable, IHashEq
/*     */ {
/*     */   transient int _hash;
/*     */   transient int _hasheq;
/*     */   
/*     */   public String toString()
/*     */   {
/*  21 */     return RT.printString(this);
/*     */   }
/*     */   
/*     */   public IPersistentCollection empty() {
/*  25 */     return PersistentList.EMPTY;
/*     */   }
/*     */   
/*     */   protected ASeq(IPersistentMap meta) {
/*  29 */     super(meta);
/*     */   }
/*     */   
/*     */ 
/*     */   protected ASeq() {}
/*     */   
/*     */ 
/*     */   public boolean equiv(Object obj)
/*     */   {
/*  38 */     if ((!(obj instanceof Sequential)) && (!(obj instanceof List)))
/*  39 */       return false;
/*  40 */     ISeq ms = RT.seq(obj);
/*  41 */     for (ISeq s = seq(); s != null; ms = ms.next())
/*     */     {
/*  43 */       if ((ms == null) || (!Util.equiv(s.first(), ms.first()))) {
/*  44 */         return false;
/*     */       }
/*  41 */       s = s.next();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  46 */     return ms == null;
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/*  51 */     if (this == obj) return true;
/*  52 */     if ((!(obj instanceof Sequential)) && (!(obj instanceof List)))
/*  53 */       return false;
/*  54 */     ISeq ms = RT.seq(obj);
/*  55 */     for (ISeq s = seq(); s != null; ms = ms.next())
/*     */     {
/*  57 */       if ((ms == null) || (!Util.equals(s.first(), ms.first()))) {
/*  58 */         return false;
/*     */       }
/*  55 */       s = s.next();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  60 */     return ms == null;
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/*  65 */     if (this._hash == 0)
/*     */     {
/*  67 */       int hash = 1;
/*  68 */       for (ISeq s = seq(); s != null; s = s.next())
/*     */       {
/*  70 */         hash = 31 * hash + (s.first() == null ? 0 : s.first().hashCode());
/*     */       }
/*  72 */       this._hash = hash;
/*     */     }
/*  74 */     return this._hash;
/*     */   }
/*     */   
/*     */   public int hasheq() {
/*  78 */     if (this._hasheq == 0)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  86 */       this._hasheq = Murmur3.hashOrdered(this);
/*     */     }
/*  88 */     return this._hasheq;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int count()
/*     */   {
/* 115 */     int i = 1;
/* 116 */     for (ISeq s = next(); s != null; i++) {
/* 117 */       if ((s instanceof Counted)) {
/* 118 */         return i + s.count();
/*     */       }
/* 116 */       s = s.next();
/*     */     }
/*     */     
/* 119 */     return i;
/*     */   }
/*     */   
/*     */   public final ISeq seq() {
/* 123 */     return this;
/*     */   }
/*     */   
/*     */   public ISeq cons(Object o) {
/* 127 */     return new Cons(o, this);
/*     */   }
/*     */   
/*     */   public ISeq more() {
/* 131 */     ISeq s = next();
/* 132 */     if (s == null)
/* 133 */       return PersistentList.EMPTY;
/* 134 */     return s;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object[] toArray()
/*     */   {
/* 147 */     return RT.seqToArray(seq());
/*     */   }
/*     */   
/*     */   public boolean add(Object o) {
/* 151 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public boolean remove(Object o) {
/* 155 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public boolean addAll(Collection c) {
/* 159 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void clear() {
/* 163 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public boolean retainAll(Collection c) {
/* 167 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public boolean removeAll(Collection c) {
/* 171 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public boolean containsAll(Collection c) {
/* 175 */     for (Object o : c)
/*     */     {
/* 177 */       if (!contains(o))
/* 178 */         return false;
/*     */     }
/* 180 */     return true;
/*     */   }
/*     */   
/*     */   public Object[] toArray(Object[] a) {
/* 184 */     return RT.seqToPassedArray(seq(), a);
/*     */   }
/*     */   
/*     */   public int size() {
/* 188 */     return count();
/*     */   }
/*     */   
/*     */   public boolean isEmpty() {
/* 192 */     return seq() == null;
/*     */   }
/*     */   
/*     */   public boolean contains(Object o) {
/* 196 */     for (ISeq s = seq(); s != null; s = s.next())
/*     */     {
/* 198 */       if (Util.equiv(s.first(), o))
/* 199 */         return true;
/*     */     }
/* 201 */     return false;
/*     */   }
/*     */   
/*     */   public Iterator iterator()
/*     */   {
/* 206 */     return new SeqIterator(this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private List reify()
/*     */   {
/* 213 */     return Collections.unmodifiableList(new ArrayList(this));
/*     */   }
/*     */   
/*     */   public List subList(int fromIndex, int toIndex) {
/* 217 */     return reify().subList(fromIndex, toIndex);
/*     */   }
/*     */   
/*     */   public Object set(int index, Object element) {
/* 221 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public Object remove(int index) {
/* 225 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public int indexOf(Object o) {
/* 229 */     ISeq s = seq();
/* 230 */     for (int i = 0; s != null; i++)
/*     */     {
/* 232 */       if (Util.equiv(s.first(), o)) {
/* 233 */         return i;
/*     */       }
/* 230 */       s = s.next();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 235 */     return -1;
/*     */   }
/*     */   
/*     */   public int lastIndexOf(Object o) {
/* 239 */     return reify().lastIndexOf(o);
/*     */   }
/*     */   
/*     */   public ListIterator listIterator() {
/* 243 */     return reify().listIterator();
/*     */   }
/*     */   
/*     */   public ListIterator listIterator(int index) {
/* 247 */     return reify().listIterator(index);
/*     */   }
/*     */   
/*     */   public Object get(int index) {
/* 251 */     return RT.nth(this, index);
/*     */   }
/*     */   
/*     */   public void add(int index, Object element) {
/* 255 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public boolean addAll(int index, Collection c) {
/* 259 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\ASeq.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */