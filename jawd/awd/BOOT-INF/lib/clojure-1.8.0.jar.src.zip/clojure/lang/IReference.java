package clojure.lang;

public abstract interface IReference
  extends IMeta
{
  public abstract IPersistentMap alterMeta(IFn paramIFn, ISeq paramISeq);
  
  public abstract IPersistentMap resetMeta(IPersistentMap paramIPersistentMap);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\IReference.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */