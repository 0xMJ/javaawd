/*     */ package clojure.lang;
/*     */ 
/*     */ import java.io.ObjectStreamException;
/*     */ import java.io.Serializable;
/*     */ import java.lang.ref.Reference;
/*     */ import java.lang.ref.ReferenceQueue;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Keyword
/*     */   implements IFn, Comparable, Named, Serializable, IHashEq
/*     */ {
/*  26 */   private static ConcurrentHashMap<Symbol, Reference<Keyword>> table = new ConcurrentHashMap();
/*  27 */   static final ReferenceQueue rq = new ReferenceQueue();
/*     */   public final Symbol sym;
/*     */   final int hasheq;
/*     */   transient String _str;
/*     */   
/*     */   public static Keyword intern(Symbol sym) {
/*  33 */     Keyword k = null;
/*  34 */     Reference<Keyword> existingRef = (Reference)table.get(sym);
/*  35 */     if (existingRef == null)
/*     */     {
/*  37 */       Util.clearCache(rq, table);
/*  38 */       if (sym.meta() != null)
/*  39 */         sym = (Symbol)sym.withMeta(null);
/*  40 */       k = new Keyword(sym);
/*  41 */       existingRef = (Reference)table.putIfAbsent(sym, new WeakReference(k, rq));
/*     */     }
/*  43 */     if (existingRef == null)
/*  44 */       return k;
/*  45 */     Keyword existingk = (Keyword)existingRef.get();
/*  46 */     if (existingk != null) {
/*  47 */       return existingk;
/*     */     }
/*  49 */     table.remove(sym, existingRef);
/*  50 */     return intern(sym);
/*     */   }
/*     */   
/*     */   public static Keyword intern(String ns, String name) {
/*  54 */     return intern(Symbol.intern(ns, name));
/*     */   }
/*     */   
/*     */   public static Keyword intern(String nsname) {
/*  58 */     return intern(Symbol.intern(nsname));
/*     */   }
/*     */   
/*     */   private Keyword(Symbol sym) {
/*  62 */     this.sym = sym;
/*  63 */     this.hasheq = (sym.hasheq() + -1640531527);
/*     */   }
/*     */   
/*     */   public static Keyword find(Symbol sym) {
/*  67 */     Reference<Keyword> ref = (Reference)table.get(sym);
/*  68 */     if (ref != null) {
/*  69 */       return (Keyword)ref.get();
/*     */     }
/*  71 */     return null;
/*     */   }
/*     */   
/*     */   public static Keyword find(String ns, String name) {
/*  75 */     return find(Symbol.intern(ns, name));
/*     */   }
/*     */   
/*     */   public static Keyword find(String nsname) {
/*  79 */     return find(Symbol.intern(nsname));
/*     */   }
/*     */   
/*     */   public final int hashCode() {
/*  83 */     return this.sym.hashCode() + -1640531527;
/*     */   }
/*     */   
/*     */   public int hasheq() {
/*  87 */     return this.hasheq;
/*     */   }
/*     */   
/*     */   public String toString() {
/*  91 */     if (this._str == null)
/*  92 */       this._str = (":" + this.sym);
/*  93 */     return this._str;
/*     */   }
/*     */   
/*     */   public Object throwArity() {
/*  97 */     throw new IllegalArgumentException("Wrong number of args passed to keyword: " + toString());
/*     */   }
/*     */   
/*     */   public Object call()
/*     */   {
/* 102 */     return throwArity();
/*     */   }
/*     */   
/*     */   public void run() {
/* 106 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public Object invoke() {
/* 110 */     return throwArity();
/*     */   }
/*     */   
/*     */   public int compareTo(Object o) {
/* 114 */     return this.sym.compareTo(((Keyword)o).sym);
/*     */   }
/*     */   
/*     */   public String getNamespace()
/*     */   {
/* 119 */     return this.sym.getNamespace();
/*     */   }
/*     */   
/*     */   public String getName() {
/* 123 */     return this.sym.getName();
/*     */   }
/*     */   
/*     */   private Object readResolve() throws ObjectStreamException {
/* 127 */     return intern(this.sym);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final Object invoke(Object obj)
/*     */   {
/* 138 */     if ((obj instanceof ILookup))
/* 139 */       return ((ILookup)obj).valAt(this);
/* 140 */     return RT.get(obj, this);
/*     */   }
/*     */   
/*     */   public final Object invoke(Object obj, Object notFound) {
/* 144 */     if ((obj instanceof ILookup))
/* 145 */       return ((ILookup)obj).valAt(this, notFound);
/* 146 */     return RT.get(obj, this, notFound);
/*     */   }
/*     */   
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3) {
/* 150 */     return throwArity();
/*     */   }
/*     */   
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4) {
/* 154 */     return throwArity();
/*     */   }
/*     */   
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5) {
/* 158 */     return throwArity();
/*     */   }
/*     */   
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6) {
/* 162 */     return throwArity();
/*     */   }
/*     */   
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7)
/*     */   {
/* 167 */     return throwArity();
/*     */   }
/*     */   
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8)
/*     */   {
/* 172 */     return throwArity();
/*     */   }
/*     */   
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9)
/*     */   {
/* 177 */     return throwArity();
/*     */   }
/*     */   
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10)
/*     */   {
/* 182 */     return throwArity();
/*     */   }
/*     */   
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11)
/*     */   {
/* 187 */     return throwArity();
/*     */   }
/*     */   
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12)
/*     */   {
/* 192 */     return throwArity();
/*     */   }
/*     */   
/*     */ 
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12, Object arg13)
/*     */   {
/* 198 */     return throwArity();
/*     */   }
/*     */   
/*     */ 
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12, Object arg13, Object arg14)
/*     */   {
/* 204 */     return throwArity();
/*     */   }
/*     */   
/*     */ 
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12, Object arg13, Object arg14, Object arg15)
/*     */   {
/* 210 */     return throwArity();
/*     */   }
/*     */   
/*     */ 
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12, Object arg13, Object arg14, Object arg15, Object arg16)
/*     */   {
/* 216 */     return throwArity();
/*     */   }
/*     */   
/*     */ 
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12, Object arg13, Object arg14, Object arg15, Object arg16, Object arg17)
/*     */   {
/* 222 */     return throwArity();
/*     */   }
/*     */   
/*     */ 
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12, Object arg13, Object arg14, Object arg15, Object arg16, Object arg17, Object arg18)
/*     */   {
/* 228 */     return throwArity();
/*     */   }
/*     */   
/*     */ 
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12, Object arg13, Object arg14, Object arg15, Object arg16, Object arg17, Object arg18, Object arg19)
/*     */   {
/* 234 */     return throwArity();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12, Object arg13, Object arg14, Object arg15, Object arg16, Object arg17, Object arg18, Object arg19, Object arg20)
/*     */   {
/* 241 */     return throwArity();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12, Object arg13, Object arg14, Object arg15, Object arg16, Object arg17, Object arg18, Object arg19, Object arg20, Object... args)
/*     */   {
/* 249 */     return throwArity();
/*     */   }
/*     */   
/*     */   public Object applyTo(ISeq arglist)
/*     */   {
/* 254 */     return AFn.applyToHelper(this, arglist);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\Keyword.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */