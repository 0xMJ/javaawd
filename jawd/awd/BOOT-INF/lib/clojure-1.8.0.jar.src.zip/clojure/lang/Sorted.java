package clojure.lang;

import java.util.Comparator;

public abstract interface Sorted
{
  public abstract Comparator comparator();
  
  public abstract Object entryKey(Object paramObject);
  
  public abstract ISeq seq(boolean paramBoolean);
  
  public abstract ISeq seqFrom(Object paramObject, boolean paramBoolean);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\Sorted.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */