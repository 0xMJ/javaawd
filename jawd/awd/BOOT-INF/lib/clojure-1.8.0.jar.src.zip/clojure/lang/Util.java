/*     */ package clojure.lang;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.ref.Reference;
/*     */ import java.lang.ref.ReferenceQueue;
/*     */ import java.math.BigInteger;
/*     */ import java.util.Collection;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Util
/*     */ {
/*     */   public static boolean equiv(Object k1, Object k2)
/*     */   {
/*  25 */     if (k1 == k2)
/*  26 */       return true;
/*  27 */     if (k1 != null)
/*     */     {
/*  29 */       if (((k1 instanceof Number)) && ((k2 instanceof Number)))
/*  30 */         return Numbers.equal((Number)k1, (Number)k2);
/*  31 */       if (((k1 instanceof IPersistentCollection)) || ((k2 instanceof IPersistentCollection)))
/*  32 */         return pcequiv(k1, k2);
/*  33 */       return k1.equals(k2);
/*     */     }
/*  35 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  42 */   static EquivPred equivNull = new EquivPred() {
/*     */     public boolean equiv(Object k1, Object k2) {
/*  44 */       return k2 == null;
/*     */     }
/*     */   };
/*     */   
/*  48 */   static EquivPred equivEquals = new EquivPred() {
/*     */     public boolean equiv(Object k1, Object k2) {
/*  50 */       return k1.equals(k2);
/*     */     }
/*     */   };
/*     */   
/*  54 */   static EquivPred equivNumber = new EquivPred() {
/*     */     public boolean equiv(Object k1, Object k2) {
/*  56 */       if ((k2 instanceof Number))
/*  57 */         return Numbers.equal((Number)k1, (Number)k2);
/*  58 */       return false;
/*     */     }
/*     */   };
/*     */   
/*  62 */   static EquivPred equivColl = new EquivPred() {
/*     */     public boolean equiv(Object k1, Object k2) {
/*  64 */       if (((k1 instanceof IPersistentCollection)) || ((k2 instanceof IPersistentCollection)))
/*  65 */         return Util.pcequiv(k1, k2);
/*  66 */       return k1.equals(k2);
/*     */     }
/*     */   };
/*     */   
/*     */   public static EquivPred equivPred(Object k1) {
/*  71 */     if (k1 == null)
/*  72 */       return equivNull;
/*  73 */     if ((k1 instanceof Number))
/*  74 */       return equivNumber;
/*  75 */     if (((k1 instanceof String)) || ((k1 instanceof Symbol)))
/*  76 */       return equivEquals;
/*  77 */     if (((k1 instanceof Collection)) || ((k1 instanceof Map)))
/*  78 */       return equivColl;
/*  79 */     return equivEquals;
/*     */   }
/*     */   
/*     */   public static boolean equiv(long k1, long k2) {
/*  83 */     return k1 == k2;
/*     */   }
/*     */   
/*     */   public static boolean equiv(Object k1, long k2) {
/*  87 */     return equiv(k1, Long.valueOf(k2));
/*     */   }
/*     */   
/*     */   public static boolean equiv(long k1, Object k2) {
/*  91 */     return equiv(Long.valueOf(k1), k2);
/*     */   }
/*     */   
/*     */   public static boolean equiv(double k1, double k2) {
/*  95 */     return k1 == k2;
/*     */   }
/*     */   
/*     */   public static boolean equiv(Object k1, double k2) {
/*  99 */     return equiv(k1, Double.valueOf(k2));
/*     */   }
/*     */   
/*     */   public static boolean equiv(double k1, Object k2) {
/* 103 */     return equiv(Double.valueOf(k1), k2);
/*     */   }
/*     */   
/*     */   public static boolean equiv(boolean k1, boolean k2) {
/* 107 */     return k1 == k2;
/*     */   }
/*     */   
/*     */   public static boolean equiv(Object k1, boolean k2) {
/* 111 */     return equiv(k1, Boolean.valueOf(k2));
/*     */   }
/*     */   
/*     */   public static boolean equiv(boolean k1, Object k2) {
/* 115 */     return equiv(Boolean.valueOf(k1), k2);
/*     */   }
/*     */   
/*     */   public static boolean equiv(char c1, char c2) {
/* 119 */     return c1 == c2;
/*     */   }
/*     */   
/*     */   public static boolean pcequiv(Object k1, Object k2) {
/* 123 */     if ((k1 instanceof IPersistentCollection))
/* 124 */       return ((IPersistentCollection)k1).equiv(k2);
/* 125 */     return ((IPersistentCollection)k2).equiv(k1);
/*     */   }
/*     */   
/*     */   public static boolean equals(Object k1, Object k2) {
/* 129 */     if (k1 == k2)
/* 130 */       return true;
/* 131 */     return (k1 != null) && (k1.equals(k2));
/*     */   }
/*     */   
/*     */   public static boolean identical(Object k1, Object k2) {
/* 135 */     return k1 == k2;
/*     */   }
/*     */   
/*     */   public static Class classOf(Object x) {
/* 139 */     if (x != null)
/* 140 */       return x.getClass();
/* 141 */     return null;
/*     */   }
/*     */   
/*     */   public static int compare(Object k1, Object k2) {
/* 145 */     if (k1 == k2)
/* 146 */       return 0;
/* 147 */     if (k1 != null)
/*     */     {
/* 149 */       if (k2 == null)
/* 150 */         return 1;
/* 151 */       if ((k1 instanceof Number))
/* 152 */         return Numbers.compare((Number)k1, (Number)k2);
/* 153 */       return ((Comparable)k1).compareTo(k2);
/*     */     }
/* 155 */     return -1;
/*     */   }
/*     */   
/*     */   public static int hash(Object o) {
/* 159 */     if (o == null)
/* 160 */       return 0;
/* 161 */     return o.hashCode();
/*     */   }
/*     */   
/*     */   public static int hasheq(Object o) {
/* 165 */     if (o == null)
/* 166 */       return 0;
/* 167 */     if ((o instanceof IHashEq))
/* 168 */       return dohasheq((IHashEq)o);
/* 169 */     if ((o instanceof Number))
/* 170 */       return Numbers.hasheq((Number)o);
/* 171 */     if ((o instanceof String))
/* 172 */       return Murmur3.hashInt(o.hashCode());
/* 173 */     return o.hashCode();
/*     */   }
/*     */   
/*     */   private static int dohasheq(IHashEq o) {
/* 177 */     return o.hasheq();
/*     */   }
/*     */   
/*     */   public static int hashCombine(int seed, int hash)
/*     */   {
/* 182 */     seed ^= hash + -1640531527 + (seed << 6) + (seed >> 2);
/* 183 */     return seed;
/*     */   }
/*     */   
/*     */   public static boolean isPrimitive(Class c) {
/* 187 */     return (c != null) && (c.isPrimitive()) && (c != Void.TYPE);
/*     */   }
/*     */   
/*     */   public static boolean isInteger(Object x) {
/* 191 */     return ((x instanceof Integer)) || ((x instanceof Long)) || ((x instanceof BigInt)) || ((x instanceof BigInteger));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static Object ret1(Object ret, Object nil)
/*     */   {
/* 198 */     return ret;
/*     */   }
/*     */   
/*     */   public static ISeq ret1(ISeq ret, Object nil) {
/* 202 */     return ret;
/*     */   }
/*     */   
/*     */   public static <K, V> void clearCache(ReferenceQueue rq, ConcurrentHashMap<K, Reference<V>> cache)
/*     */   {
/* 207 */     if (rq.poll() != null)
/*     */     {
/* 209 */       while (rq.poll() != null) {}
/*     */       
/* 211 */       for (Map.Entry<K, Reference<V>> e : cache.entrySet())
/*     */       {
/* 213 */         Reference<V> val = (Reference)e.getValue();
/* 214 */         if ((val != null) && (val.get() == null))
/* 215 */           cache.remove(e.getKey(), val);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public static RuntimeException runtimeException(String s) {
/* 221 */     return new RuntimeException(s);
/*     */   }
/*     */   
/*     */   public static RuntimeException runtimeException(String s, Throwable e) {
/* 225 */     return new RuntimeException(s, e);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static RuntimeException sneakyThrow(Throwable t)
/*     */   {
/* 236 */     if (t == null)
/* 237 */       throw new NullPointerException();
/* 238 */     sneakyThrow0(t);
/* 239 */     return null;
/*     */   }
/*     */   
/*     */   private static <T extends Throwable> void sneakyThrow0(Throwable t) throws Throwable
/*     */   {
/* 244 */     throw t;
/*     */   }
/*     */   
/*     */   public static Object loadWithClass(String scriptbase, Class<?> loadFrom) throws IOException, ClassNotFoundException {
/* 248 */     Var.pushThreadBindings(RT.map(new Object[] { Compiler.LOADER, loadFrom.getClassLoader() }));
/*     */     try {
/* 250 */       return RT.var("clojure.core", "load").invoke(scriptbase);
/*     */     }
/*     */     finally
/*     */     {
/* 254 */       Var.popThreadBindings();
/*     */     }
/*     */   }
/*     */   
/*     */   public static abstract interface EquivPred
/*     */   {
/*     */     public abstract boolean equiv(Object paramObject1, Object paramObject2);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\Util.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */