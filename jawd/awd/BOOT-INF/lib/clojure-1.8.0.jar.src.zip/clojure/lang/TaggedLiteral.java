/*    */ package clojure.lang;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TaggedLiteral
/*    */   implements ILookup
/*    */ {
/* 15 */   public static final Keyword TAG_KW = Keyword.intern("tag");
/* 16 */   public static final Keyword FORM_KW = Keyword.intern("form");
/*    */   public final Symbol tag;
/*    */   public final Object form;
/*    */   
/*    */   public static TaggedLiteral create(Symbol tag, Object form)
/*    */   {
/* 22 */     return new TaggedLiteral(tag, form);
/*    */   }
/*    */   
/*    */   private TaggedLiteral(Symbol tag, Object form) {
/* 26 */     this.tag = tag;
/* 27 */     this.form = form;
/*    */   }
/*    */   
/*    */   public Object valAt(Object key) {
/* 31 */     return valAt(key, null);
/*    */   }
/*    */   
/*    */   public Object valAt(Object key, Object notFound) {
/* 35 */     if (FORM_KW.equals(key))
/* 36 */       return this.form;
/* 37 */     if (TAG_KW.equals(key)) {
/* 38 */       return this.tag;
/*    */     }
/* 40 */     return notFound;
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean equals(Object o)
/*    */   {
/* 46 */     if (this == o) return true;
/* 47 */     if ((o == null) || (getClass() != o.getClass())) { return false;
/*    */     }
/* 49 */     TaggedLiteral that = (TaggedLiteral)o;
/*    */     
/* 51 */     if (this.form != null ? !this.form.equals(that.form) : that.form != null) return false;
/* 52 */     if (this.tag != null ? !this.tag.equals(that.tag) : that.tag != null) { return false;
/*    */     }
/* 54 */     return true;
/*    */   }
/*    */   
/*    */   public int hashCode()
/*    */   {
/* 59 */     int result = Util.hash(this.tag);
/* 60 */     result = 31 * result + Util.hash(this.form);
/* 61 */     return result;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\TaggedLiteral.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */