package clojure.lang;

public abstract interface IEditableCollection
{
  public abstract ITransientCollection asTransient();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\IEditableCollection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */