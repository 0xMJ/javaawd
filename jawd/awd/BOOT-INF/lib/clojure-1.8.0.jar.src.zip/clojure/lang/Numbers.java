/*      */ package clojure.lang;
/*      */ 
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.math.MathContext;
/*      */ 
/*      */ 
/*      */ public class Numbers
/*      */ {
/*      */   static abstract interface Ops
/*      */   {
/*      */     public abstract Ops combine(Ops paramOps);
/*      */     
/*      */     public abstract Ops opsWith(Numbers.LongOps paramLongOps);
/*      */     
/*      */     public abstract Ops opsWith(Numbers.DoubleOps paramDoubleOps);
/*      */     
/*      */     public abstract Ops opsWith(Numbers.RatioOps paramRatioOps);
/*      */     
/*      */     public abstract Ops opsWith(Numbers.BigIntOps paramBigIntOps);
/*      */     
/*      */     public abstract Ops opsWith(Numbers.BigDecimalOps paramBigDecimalOps);
/*      */     
/*      */     public abstract boolean isZero(Number paramNumber);
/*      */     
/*      */     public abstract boolean isPos(Number paramNumber);
/*      */     
/*      */     public abstract boolean isNeg(Number paramNumber);
/*      */     
/*      */     public abstract Number add(Number paramNumber1, Number paramNumber2);
/*      */     
/*      */     public abstract Number addP(Number paramNumber1, Number paramNumber2);
/*      */     
/*      */     public abstract Number multiply(Number paramNumber1, Number paramNumber2);
/*      */     
/*      */     public abstract Number multiplyP(Number paramNumber1, Number paramNumber2);
/*      */     
/*      */     public abstract Number divide(Number paramNumber1, Number paramNumber2);
/*      */     
/*      */     public abstract Number quotient(Number paramNumber1, Number paramNumber2);
/*      */     
/*      */     public abstract Number remainder(Number paramNumber1, Number paramNumber2);
/*      */     
/*      */     public abstract boolean equiv(Number paramNumber1, Number paramNumber2);
/*      */     
/*      */     public abstract boolean lt(Number paramNumber1, Number paramNumber2);
/*      */     
/*      */     public abstract boolean lte(Number paramNumber1, Number paramNumber2);
/*      */     
/*      */     public abstract boolean gte(Number paramNumber1, Number paramNumber2);
/*      */     
/*      */     public abstract Number negate(Number paramNumber);
/*      */     
/*      */     public abstract Number negateP(Number paramNumber);
/*      */     
/*      */     public abstract Number inc(Number paramNumber);
/*      */     
/*      */     public abstract Number incP(Number paramNumber);
/*      */     
/*      */     public abstract Number dec(Number paramNumber);
/*      */     
/*      */     public abstract Number decP(Number paramNumber);
/*      */   }
/*      */   
/*      */   static abstract class OpsP
/*      */     implements Numbers.Ops
/*      */   {
/*      */     public Number addP(Number x, Number y)
/*      */     {
/*   70 */       return add(x, y);
/*      */     }
/*      */     
/*      */     public Number multiplyP(Number x, Number y) {
/*   74 */       return multiply(x, y);
/*      */     }
/*      */     
/*      */     public Number negateP(Number x) {
/*   78 */       return negate(x);
/*      */     }
/*      */     
/*      */     public Number incP(Number x) {
/*   82 */       return inc(x);
/*      */     }
/*      */     
/*      */     public Number decP(Number x) {
/*   86 */       return dec(x);
/*      */     }
/*      */   }
/*      */   
/*      */   public static boolean isZero(Object x)
/*      */   {
/*   92 */     return ops(x).isZero((Number)x);
/*      */   }
/*      */   
/*      */   public static boolean isPos(Object x) {
/*   96 */     return ops(x).isPos((Number)x);
/*      */   }
/*      */   
/*      */   public static boolean isNeg(Object x) {
/*  100 */     return ops(x).isNeg((Number)x);
/*      */   }
/*      */   
/*      */   public static Number minus(Object x) {
/*  104 */     return ops(x).negate((Number)x);
/*      */   }
/*      */   
/*      */   public static Number minusP(Object x) {
/*  108 */     return ops(x).negateP((Number)x);
/*      */   }
/*      */   
/*      */   public static Number inc(Object x) {
/*  112 */     return ops(x).inc((Number)x);
/*      */   }
/*      */   
/*      */   public static Number incP(Object x) {
/*  116 */     return ops(x).incP((Number)x);
/*      */   }
/*      */   
/*      */   public static Number dec(Object x) {
/*  120 */     return ops(x).dec((Number)x);
/*      */   }
/*      */   
/*      */   public static Number decP(Object x) {
/*  124 */     return ops(x).decP((Number)x);
/*      */   }
/*      */   
/*      */   public static Number add(Object x, Object y) {
/*  128 */     return ops(x).combine(ops(y)).add((Number)x, (Number)y);
/*      */   }
/*      */   
/*      */   public static Number addP(Object x, Object y) {
/*  132 */     return ops(x).combine(ops(y)).addP((Number)x, (Number)y);
/*      */   }
/*      */   
/*      */   public static Number minus(Object x, Object y) {
/*  136 */     Ops yops = ops(y);
/*  137 */     return ops(x).combine(yops).add((Number)x, yops.negate((Number)y));
/*      */   }
/*      */   
/*      */   public static Number minusP(Object x, Object y) {
/*  141 */     Ops yops = ops(y);
/*  142 */     Number negativeY = yops.negateP((Number)y);
/*  143 */     Ops negativeYOps = ops(negativeY);
/*  144 */     return ops(x).combine(negativeYOps).addP((Number)x, negativeY);
/*      */   }
/*      */   
/*      */   public static Number multiply(Object x, Object y) {
/*  148 */     return ops(x).combine(ops(y)).multiply((Number)x, (Number)y);
/*      */   }
/*      */   
/*      */   public static Number multiplyP(Object x, Object y) {
/*  152 */     return ops(x).combine(ops(y)).multiplyP((Number)x, (Number)y);
/*      */   }
/*      */   
/*      */   public static Number divide(Object x, Object y) {
/*  156 */     Ops yops = ops(y);
/*  157 */     if (yops.isZero((Number)y))
/*  158 */       throw new ArithmeticException("Divide by zero");
/*  159 */     return ops(x).combine(yops).divide((Number)x, (Number)y);
/*      */   }
/*      */   
/*      */   public static Number quotient(Object x, Object y) {
/*  163 */     Ops yops = ops(y);
/*  164 */     if (yops.isZero((Number)y))
/*  165 */       throw new ArithmeticException("Divide by zero");
/*  166 */     return ops(x).combine(yops).quotient((Number)x, (Number)y);
/*      */   }
/*      */   
/*      */   public static Number remainder(Object x, Object y) {
/*  170 */     Ops yops = ops(y);
/*  171 */     if (yops.isZero((Number)y))
/*  172 */       throw new ArithmeticException("Divide by zero");
/*  173 */     return ops(x).combine(yops).remainder((Number)x, (Number)y);
/*      */   }
/*      */   
/*      */   public static double quotient(double n, double d) {
/*  177 */     if (d == 0.0D) {
/*  178 */       throw new ArithmeticException("Divide by zero");
/*      */     }
/*  180 */     double q = n / d;
/*  181 */     if ((q <= 9.223372036854776E18D) && (q >= -9.223372036854776E18D))
/*      */     {
/*  183 */       return q;
/*      */     }
/*      */     
/*      */ 
/*  187 */     return new BigDecimal(q).toBigInteger().doubleValue();
/*      */   }
/*      */   
/*      */   public static double remainder(double n, double d)
/*      */   {
/*  192 */     if (d == 0.0D) {
/*  193 */       throw new ArithmeticException("Divide by zero");
/*      */     }
/*  195 */     double q = n / d;
/*  196 */     if ((q <= 9.223372036854776E18D) && (q >= -9.223372036854776E18D))
/*      */     {
/*  198 */       return n - q * d;
/*      */     }
/*      */     
/*      */ 
/*  202 */     Number bq = new BigDecimal(q).toBigInteger();
/*  203 */     return n - bq.doubleValue() * d;
/*      */   }
/*      */   
/*      */   public static boolean equiv(Object x, Object y)
/*      */   {
/*  208 */     return equiv((Number)x, (Number)y);
/*      */   }
/*      */   
/*      */   public static boolean equiv(Number x, Number y) {
/*  212 */     return ops(x).combine(ops(y)).equiv(x, y);
/*      */   }
/*      */   
/*      */   public static boolean equal(Number x, Number y) {
/*  216 */     return (category(x) == category(y)) && (ops(x).combine(ops(y)).equiv(x, y));
/*      */   }
/*      */   
/*      */   public static boolean lt(Object x, Object y)
/*      */   {
/*  221 */     return ops(x).combine(ops(y)).lt((Number)x, (Number)y);
/*      */   }
/*      */   
/*      */   public static boolean lte(Object x, Object y) {
/*  225 */     return ops(x).combine(ops(y)).lte((Number)x, (Number)y);
/*      */   }
/*      */   
/*      */   public static boolean gt(Object x, Object y) {
/*  229 */     return ops(x).combine(ops(y)).lt((Number)y, (Number)x);
/*      */   }
/*      */   
/*      */   public static boolean gte(Object x, Object y) {
/*  233 */     return ops(x).combine(ops(y)).gte((Number)x, (Number)y);
/*      */   }
/*      */   
/*      */   public static int compare(Number x, Number y) {
/*  237 */     Ops ops = ops(x).combine(ops(y));
/*  238 */     if (ops.lt(x, y))
/*  239 */       return -1;
/*  240 */     if (ops.lt(y, x))
/*  241 */       return 1;
/*  242 */     return 0;
/*      */   }
/*      */   
/*      */   @WarnBoxedMath(false)
/*      */   static BigInt toBigInt(Object x) {
/*  247 */     if ((x instanceof BigInt))
/*  248 */       return (BigInt)x;
/*  249 */     if ((x instanceof BigInteger)) {
/*  250 */       return BigInt.fromBigInteger((BigInteger)x);
/*      */     }
/*  252 */     return BigInt.fromLong(((Number)x).longValue());
/*      */   }
/*      */   
/*      */   @WarnBoxedMath(false)
/*      */   static BigInteger toBigInteger(Object x) {
/*  257 */     if ((x instanceof BigInteger))
/*  258 */       return (BigInteger)x;
/*  259 */     if ((x instanceof BigInt)) {
/*  260 */       return ((BigInt)x).toBigInteger();
/*      */     }
/*  262 */     return BigInteger.valueOf(((Number)x).longValue());
/*      */   }
/*      */   
/*      */   @WarnBoxedMath(false)
/*      */   static BigDecimal toBigDecimal(Object x) {
/*  267 */     if ((x instanceof BigDecimal))
/*  268 */       return (BigDecimal)x;
/*  269 */     if ((x instanceof BigInt))
/*      */     {
/*  271 */       BigInt bi = (BigInt)x;
/*  272 */       if (bi.bipart == null) {
/*  273 */         return BigDecimal.valueOf(bi.lpart);
/*      */       }
/*  275 */       return new BigDecimal(bi.bipart);
/*      */     }
/*  277 */     if ((x instanceof BigInteger))
/*  278 */       return new BigDecimal((BigInteger)x);
/*  279 */     if ((x instanceof Double))
/*  280 */       return new BigDecimal(((Number)x).doubleValue());
/*  281 */     if ((x instanceof Float))
/*  282 */       return new BigDecimal(((Number)x).doubleValue());
/*  283 */     if ((x instanceof Ratio))
/*      */     {
/*  285 */       Ratio r = (Ratio)x;
/*  286 */       return (BigDecimal)divide(new BigDecimal(r.numerator), r.denominator);
/*      */     }
/*      */     
/*  289 */     return BigDecimal.valueOf(((Number)x).longValue());
/*      */   }
/*      */   
/*      */   @WarnBoxedMath(false)
/*      */   public static Ratio toRatio(Object x) {
/*  294 */     if ((x instanceof Ratio))
/*  295 */       return (Ratio)x;
/*  296 */     if ((x instanceof BigDecimal))
/*      */     {
/*  298 */       BigDecimal bx = (BigDecimal)x;
/*  299 */       BigInteger bv = bx.unscaledValue();
/*  300 */       int scale = bx.scale();
/*  301 */       if (scale < 0) {
/*  302 */         return new Ratio(bv.multiply(BigInteger.TEN.pow(-scale)), BigInteger.ONE);
/*      */       }
/*  304 */       return new Ratio(bv, BigInteger.TEN.pow(scale));
/*      */     }
/*  306 */     return new Ratio(toBigInteger(x), BigInteger.ONE);
/*      */   }
/*      */   
/*      */   @WarnBoxedMath(false)
/*      */   public static Number rationalize(Number x) {
/*  311 */     if (((x instanceof Float)) || ((x instanceof Double)))
/*  312 */       return rationalize(BigDecimal.valueOf(x.doubleValue()));
/*  313 */     if ((x instanceof BigDecimal))
/*      */     {
/*  315 */       BigDecimal bx = (BigDecimal)x;
/*  316 */       BigInteger bv = bx.unscaledValue();
/*  317 */       int scale = bx.scale();
/*  318 */       if (scale < 0) {
/*  319 */         return BigInt.fromBigInteger(bv.multiply(BigInteger.TEN.pow(-scale)));
/*      */       }
/*  321 */       return divide(bv, BigInteger.TEN.pow(scale));
/*      */     }
/*  323 */     return x;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @WarnBoxedMath(false)
/*      */   public static Number reduceBigInt(BigInt val)
/*      */   {
/*  344 */     if (val.bipart == null) {
/*  345 */       return num(val.lpart);
/*      */     }
/*  347 */     return val.bipart;
/*      */   }
/*      */   
/*      */   public static Number divide(BigInteger n, BigInteger d) {
/*  351 */     if (d.equals(BigInteger.ZERO))
/*  352 */       throw new ArithmeticException("Divide by zero");
/*  353 */     BigInteger gcd = n.gcd(d);
/*  354 */     if (gcd.equals(BigInteger.ZERO))
/*  355 */       return BigInt.ZERO;
/*  356 */     n = n.divide(gcd);
/*  357 */     d = d.divide(gcd);
/*  358 */     if (d.equals(BigInteger.ONE))
/*  359 */       return BigInt.fromBigInteger(n);
/*  360 */     if (d.equals(BigInteger.ONE.negate()))
/*  361 */       return BigInt.fromBigInteger(n.negate());
/*  362 */     return new Ratio(d.signum() < 0 ? n.negate() : n, d.signum() < 0 ? d.negate() : d);
/*      */   }
/*      */   
/*      */   public static int shiftLeftInt(int x, int n)
/*      */   {
/*  367 */     return x << n;
/*      */   }
/*      */   
/*      */   public static long shiftLeft(Object x, Object y) {
/*  371 */     return shiftLeft(bitOpsCast(x), bitOpsCast(y));
/*      */   }
/*      */   
/*  374 */   public static long shiftLeft(Object x, long y) { return shiftLeft(bitOpsCast(x), y); }
/*      */   
/*      */   public static long shiftLeft(long x, Object y) {
/*  377 */     return shiftLeft(x, bitOpsCast(y));
/*      */   }
/*      */   
/*  380 */   public static long shiftLeft(long x, long n) { return x << (int)n; }
/*      */   
/*      */   public static int shiftRightInt(int x, int n)
/*      */   {
/*  384 */     return x >> n;
/*      */   }
/*      */   
/*      */   public static long shiftRight(Object x, Object y) {
/*  388 */     return shiftRight(bitOpsCast(x), bitOpsCast(y));
/*      */   }
/*      */   
/*  391 */   public static long shiftRight(Object x, long y) { return shiftRight(bitOpsCast(x), y); }
/*      */   
/*      */   public static long shiftRight(long x, Object y) {
/*  394 */     return shiftRight(x, bitOpsCast(y));
/*      */   }
/*      */   
/*  397 */   public static long shiftRight(long x, long n) { return x >> (int)n; }
/*      */   
/*      */   public static int unsignedShiftRightInt(int x, int n)
/*      */   {
/*  401 */     return x >>> n;
/*      */   }
/*      */   
/*      */   public static long unsignedShiftRight(Object x, Object y) {
/*  405 */     return unsignedShiftRight(bitOpsCast(x), bitOpsCast(y));
/*      */   }
/*      */   
/*  408 */   public static long unsignedShiftRight(Object x, long y) { return unsignedShiftRight(bitOpsCast(x), y); }
/*      */   
/*      */   public static long unsignedShiftRight(long x, Object y) {
/*  411 */     return unsignedShiftRight(x, bitOpsCast(y));
/*      */   }
/*      */   
/*  414 */   public static long unsignedShiftRight(long x, long n) { return x >>> (int)n; }
/*      */   
/*      */   static final class LongOps implements Numbers.Ops
/*      */   {
/*      */     public Numbers.Ops combine(Numbers.Ops y) {
/*  419 */       return y.opsWith(this);
/*      */     }
/*      */     
/*      */     public final Numbers.Ops opsWith(LongOps x) {
/*  423 */       return this;
/*      */     }
/*      */     
/*      */     public final Numbers.Ops opsWith(Numbers.DoubleOps x) {
/*  427 */       return Numbers.DOUBLE_OPS;
/*      */     }
/*      */     
/*      */     public final Numbers.Ops opsWith(Numbers.RatioOps x) {
/*  431 */       return Numbers.RATIO_OPS;
/*      */     }
/*      */     
/*      */     public final Numbers.Ops opsWith(Numbers.BigIntOps x) {
/*  435 */       return Numbers.BIGINT_OPS;
/*      */     }
/*      */     
/*      */     public final Numbers.Ops opsWith(Numbers.BigDecimalOps x) {
/*  439 */       return Numbers.BIGDECIMAL_OPS;
/*      */     }
/*      */     
/*      */     public boolean isZero(Number x) {
/*  443 */       return x.longValue() == 0L;
/*      */     }
/*      */     
/*      */     public boolean isPos(Number x) {
/*  447 */       return x.longValue() > 0L;
/*      */     }
/*      */     
/*      */     public boolean isNeg(Number x) {
/*  451 */       return x.longValue() < 0L;
/*      */     }
/*      */     
/*      */     public final Number add(Number x, Number y) {
/*  455 */       return Numbers.num(Numbers.add(x.longValue(), y.longValue()));
/*      */     }
/*      */     
/*      */     public final Number addP(Number x, Number y) {
/*  459 */       long lx = x.longValue();long ly = y.longValue();
/*  460 */       long ret = lx + ly;
/*  461 */       if (((ret ^ lx) < 0L) && ((ret ^ ly) < 0L))
/*  462 */         return Numbers.BIGINT_OPS.add(x, y);
/*  463 */       return Numbers.num(ret);
/*      */     }
/*      */     
/*      */     public final Number multiply(Number x, Number y) {
/*  467 */       return Numbers.num(Numbers.multiply(x.longValue(), y.longValue()));
/*      */     }
/*      */     
/*      */     public final Number multiplyP(Number x, Number y) {
/*  471 */       long lx = x.longValue();long ly = y.longValue();
/*  472 */       if ((lx == Long.MIN_VALUE) && (ly < 0L))
/*  473 */         return Numbers.BIGINT_OPS.multiply(x, y);
/*  474 */       long ret = lx * ly;
/*  475 */       if ((ly != 0L) && (ret / ly != lx))
/*  476 */         return Numbers.BIGINT_OPS.multiply(x, y);
/*  477 */       return Numbers.num(ret);
/*      */     }
/*      */     
/*  480 */     static long gcd(long u, long v) { while (v != 0L)
/*      */       {
/*  482 */         long r = u % v;
/*  483 */         u = v;
/*  484 */         v = r;
/*      */       }
/*  486 */       return u;
/*      */     }
/*      */     
/*      */     public Number divide(Number x, Number y) {
/*  490 */       long n = x.longValue();
/*  491 */       long val = y.longValue();
/*  492 */       long gcd = gcd(n, val);
/*  493 */       if (gcd == 0L) {
/*  494 */         return Numbers.num(0L);
/*      */       }
/*  496 */       n /= gcd;
/*  497 */       long d = val / gcd;
/*  498 */       if (d == 1L)
/*  499 */         return Numbers.num(n);
/*  500 */       if (d < 0L)
/*      */       {
/*  502 */         n = -n;
/*  503 */         d = -d;
/*      */       }
/*  505 */       return new Ratio(BigInteger.valueOf(n), BigInteger.valueOf(d));
/*      */     }
/*      */     
/*      */     public Number quotient(Number x, Number y) {
/*  509 */       return Numbers.num(x.longValue() / y.longValue());
/*      */     }
/*      */     
/*      */     public Number remainder(Number x, Number y) {
/*  513 */       return Numbers.num(x.longValue() % y.longValue());
/*      */     }
/*      */     
/*      */     public boolean equiv(Number x, Number y) {
/*  517 */       return x.longValue() == y.longValue();
/*      */     }
/*      */     
/*      */     public boolean lt(Number x, Number y) {
/*  521 */       return x.longValue() < y.longValue();
/*      */     }
/*      */     
/*      */     public boolean lte(Number x, Number y) {
/*  525 */       return x.longValue() <= y.longValue();
/*      */     }
/*      */     
/*      */     public boolean gte(Number x, Number y) {
/*  529 */       return x.longValue() >= y.longValue();
/*      */     }
/*      */     
/*      */     public final Number negate(Number x)
/*      */     {
/*  534 */       long val = x.longValue();
/*  535 */       return Numbers.num(Numbers.minus(val));
/*      */     }
/*      */     
/*      */     public final Number negateP(Number x) {
/*  539 */       long val = x.longValue();
/*  540 */       if (val > Long.MIN_VALUE)
/*  541 */         return Numbers.num(-val);
/*  542 */       return BigInt.fromBigInteger(BigInteger.valueOf(val).negate());
/*      */     }
/*      */     
/*  545 */     public Number inc(Number x) { long val = x.longValue();
/*  546 */       return Numbers.num(Numbers.inc(val));
/*      */     }
/*      */     
/*      */     public Number incP(Number x) {
/*  550 */       long val = x.longValue();
/*  551 */       if (val < Long.MAX_VALUE)
/*  552 */         return Numbers.num(val + 1L);
/*  553 */       return Numbers.BIGINT_OPS.inc(x);
/*      */     }
/*      */     
/*      */     public Number dec(Number x) {
/*  557 */       long val = x.longValue();
/*  558 */       return Numbers.num(Numbers.dec(val));
/*      */     }
/*      */     
/*      */     public Number decP(Number x) {
/*  562 */       long val = x.longValue();
/*  563 */       if (val > Long.MIN_VALUE)
/*  564 */         return Numbers.num(val - 1L);
/*  565 */       return Numbers.BIGINT_OPS.dec(x);
/*      */     }
/*      */   }
/*      */   
/*      */   static final class DoubleOps extends Numbers.OpsP {
/*      */     public Numbers.Ops combine(Numbers.Ops y) {
/*  571 */       return y.opsWith(this);
/*      */     }
/*      */     
/*      */     public final Numbers.Ops opsWith(Numbers.LongOps x) {
/*  575 */       return this;
/*      */     }
/*      */     
/*      */     public final Numbers.Ops opsWith(DoubleOps x) {
/*  579 */       return this;
/*      */     }
/*      */     
/*      */     public final Numbers.Ops opsWith(Numbers.RatioOps x) {
/*  583 */       return this;
/*      */     }
/*      */     
/*      */     public final Numbers.Ops opsWith(Numbers.BigIntOps x) {
/*  587 */       return this;
/*      */     }
/*      */     
/*      */     public final Numbers.Ops opsWith(Numbers.BigDecimalOps x) {
/*  591 */       return this;
/*      */     }
/*      */     
/*      */     public boolean isZero(Number x) {
/*  595 */       return x.doubleValue() == 0.0D;
/*      */     }
/*      */     
/*      */     public boolean isPos(Number x) {
/*  599 */       return x.doubleValue() > 0.0D;
/*      */     }
/*      */     
/*      */     public boolean isNeg(Number x) {
/*  603 */       return x.doubleValue() < 0.0D;
/*      */     }
/*      */     
/*      */     public final Number add(Number x, Number y) {
/*  607 */       return Double.valueOf(x.doubleValue() + y.doubleValue());
/*      */     }
/*      */     
/*      */     public final Number multiply(Number x, Number y) {
/*  611 */       return Double.valueOf(x.doubleValue() * y.doubleValue());
/*      */     }
/*      */     
/*      */     public Number divide(Number x, Number y) {
/*  615 */       return Double.valueOf(x.doubleValue() / y.doubleValue());
/*      */     }
/*      */     
/*      */     public Number quotient(Number x, Number y) {
/*  619 */       return Double.valueOf(Numbers.quotient(x.doubleValue(), y.doubleValue()));
/*      */     }
/*      */     
/*      */     public Number remainder(Number x, Number y) {
/*  623 */       return Double.valueOf(Numbers.remainder(x.doubleValue(), y.doubleValue()));
/*      */     }
/*      */     
/*      */     public boolean equiv(Number x, Number y) {
/*  627 */       return x.doubleValue() == y.doubleValue();
/*      */     }
/*      */     
/*      */     public boolean lt(Number x, Number y) {
/*  631 */       return x.doubleValue() < y.doubleValue();
/*      */     }
/*      */     
/*      */     public boolean lte(Number x, Number y) {
/*  635 */       return x.doubleValue() <= y.doubleValue();
/*      */     }
/*      */     
/*      */     public boolean gte(Number x, Number y) {
/*  639 */       return x.doubleValue() >= y.doubleValue();
/*      */     }
/*      */     
/*      */     public final Number negate(Number x)
/*      */     {
/*  644 */       return Double.valueOf(-x.doubleValue());
/*      */     }
/*      */     
/*      */     public Number inc(Number x) {
/*  648 */       return Double.valueOf(x.doubleValue() + 1.0D);
/*      */     }
/*      */     
/*      */     public Number dec(Number x) {
/*  652 */       return Double.valueOf(x.doubleValue() - 1.0D);
/*      */     }
/*      */   }
/*      */   
/*      */   static final class RatioOps extends Numbers.OpsP {
/*      */     public Numbers.Ops combine(Numbers.Ops y) {
/*  658 */       return y.opsWith(this);
/*      */     }
/*      */     
/*      */     public final Numbers.Ops opsWith(Numbers.LongOps x) {
/*  662 */       return this;
/*      */     }
/*      */     
/*      */     public final Numbers.Ops opsWith(Numbers.DoubleOps x) {
/*  666 */       return Numbers.DOUBLE_OPS;
/*      */     }
/*      */     
/*      */     public final Numbers.Ops opsWith(RatioOps x) {
/*  670 */       return this;
/*      */     }
/*      */     
/*      */     public final Numbers.Ops opsWith(Numbers.BigIntOps x) {
/*  674 */       return this;
/*      */     }
/*      */     
/*      */     public final Numbers.Ops opsWith(Numbers.BigDecimalOps x) {
/*  678 */       return Numbers.BIGDECIMAL_OPS;
/*      */     }
/*      */     
/*      */     public boolean isZero(Number x) {
/*  682 */       Ratio r = (Ratio)x;
/*  683 */       return r.numerator.signum() == 0;
/*      */     }
/*      */     
/*      */     public boolean isPos(Number x) {
/*  687 */       Ratio r = (Ratio)x;
/*  688 */       return r.numerator.signum() > 0;
/*      */     }
/*      */     
/*      */     public boolean isNeg(Number x) {
/*  692 */       Ratio r = (Ratio)x;
/*  693 */       return r.numerator.signum() < 0;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     static Number normalizeRet(Number ret, Number x, Number y)
/*      */     {
/*  701 */       return ret;
/*      */     }
/*      */     
/*      */     public final Number add(Number x, Number y) {
/*  705 */       Ratio rx = Numbers.toRatio(x);
/*  706 */       Ratio ry = Numbers.toRatio(y);
/*  707 */       Number ret = divide(ry.numerator.multiply(rx.denominator).add(rx.numerator.multiply(ry.denominator)), ry.denominator.multiply(rx.denominator));
/*      */       
/*      */ 
/*  710 */       return normalizeRet(ret, x, y);
/*      */     }
/*      */     
/*      */     public final Number multiply(Number x, Number y) {
/*  714 */       Ratio rx = Numbers.toRatio(x);
/*  715 */       Ratio ry = Numbers.toRatio(y);
/*  716 */       Number ret = Numbers.divide(ry.numerator.multiply(rx.numerator), ry.denominator.multiply(rx.denominator));
/*      */       
/*  718 */       return normalizeRet(ret, x, y);
/*      */     }
/*      */     
/*      */     public Number divide(Number x, Number y) {
/*  722 */       Ratio rx = Numbers.toRatio(x);
/*  723 */       Ratio ry = Numbers.toRatio(y);
/*  724 */       Number ret = Numbers.divide(ry.denominator.multiply(rx.numerator), ry.numerator.multiply(rx.denominator));
/*      */       
/*  726 */       return normalizeRet(ret, x, y);
/*      */     }
/*      */     
/*      */     public Number quotient(Number x, Number y) {
/*  730 */       Ratio rx = Numbers.toRatio(x);
/*  731 */       Ratio ry = Numbers.toRatio(y);
/*  732 */       BigInteger q = rx.numerator.multiply(ry.denominator).divide(rx.denominator.multiply(ry.numerator));
/*      */       
/*  734 */       return normalizeRet(BigInt.fromBigInteger(q), x, y);
/*      */     }
/*      */     
/*      */     public Number remainder(Number x, Number y) {
/*  738 */       Ratio rx = Numbers.toRatio(x);
/*  739 */       Ratio ry = Numbers.toRatio(y);
/*  740 */       BigInteger q = rx.numerator.multiply(ry.denominator).divide(rx.denominator.multiply(ry.numerator));
/*      */       
/*  742 */       Number ret = Numbers.minus(x, Numbers.multiply(q, y));
/*  743 */       return normalizeRet(ret, x, y);
/*      */     }
/*      */     
/*      */     public boolean equiv(Number x, Number y) {
/*  747 */       Ratio rx = Numbers.toRatio(x);
/*  748 */       Ratio ry = Numbers.toRatio(y);
/*  749 */       return (rx.numerator.equals(ry.numerator)) && (rx.denominator.equals(ry.denominator));
/*      */     }
/*      */     
/*      */     public boolean lt(Number x, Number y)
/*      */     {
/*  754 */       Ratio rx = Numbers.toRatio(x);
/*  755 */       Ratio ry = Numbers.toRatio(y);
/*  756 */       return Numbers.lt(rx.numerator.multiply(ry.denominator), ry.numerator.multiply(rx.denominator));
/*      */     }
/*      */     
/*      */     public boolean lte(Number x, Number y) {
/*  760 */       Ratio rx = Numbers.toRatio(x);
/*  761 */       Ratio ry = Numbers.toRatio(y);
/*  762 */       return Numbers.lte(rx.numerator.multiply(ry.denominator), ry.numerator.multiply(rx.denominator));
/*      */     }
/*      */     
/*      */     public boolean gte(Number x, Number y) {
/*  766 */       Ratio rx = Numbers.toRatio(x);
/*  767 */       Ratio ry = Numbers.toRatio(y);
/*  768 */       return Numbers.gte(rx.numerator.multiply(ry.denominator), ry.numerator.multiply(rx.denominator));
/*      */     }
/*      */     
/*      */     public final Number negate(Number x)
/*      */     {
/*  773 */       Ratio r = (Ratio)x;
/*  774 */       return new Ratio(r.numerator.negate(), r.denominator);
/*      */     }
/*      */     
/*      */     public Number inc(Number x) {
/*  778 */       return Numbers.add(x, 1L);
/*      */     }
/*      */     
/*      */     public Number dec(Number x) {
/*  782 */       return Numbers.add(x, -1L);
/*      */     }
/*      */   }
/*      */   
/*      */   static final class BigIntOps extends Numbers.OpsP
/*      */   {
/*      */     public Numbers.Ops combine(Numbers.Ops y) {
/*  789 */       return y.opsWith(this);
/*      */     }
/*      */     
/*      */     public final Numbers.Ops opsWith(Numbers.LongOps x) {
/*  793 */       return this;
/*      */     }
/*      */     
/*      */     public final Numbers.Ops opsWith(Numbers.DoubleOps x) {
/*  797 */       return Numbers.DOUBLE_OPS;
/*      */     }
/*      */     
/*      */     public final Numbers.Ops opsWith(Numbers.RatioOps x) {
/*  801 */       return Numbers.RATIO_OPS;
/*      */     }
/*      */     
/*      */     public final Numbers.Ops opsWith(BigIntOps x) {
/*  805 */       return this;
/*      */     }
/*      */     
/*      */     public final Numbers.Ops opsWith(Numbers.BigDecimalOps x) {
/*  809 */       return Numbers.BIGDECIMAL_OPS;
/*      */     }
/*      */     
/*      */     public boolean isZero(Number x) {
/*  813 */       BigInt bx = Numbers.toBigInt(x);
/*  814 */       if (bx.bipart == null)
/*  815 */         return bx.lpart == 0L;
/*  816 */       return bx.bipart.signum() == 0;
/*      */     }
/*      */     
/*      */     public boolean isPos(Number x) {
/*  820 */       BigInt bx = Numbers.toBigInt(x);
/*  821 */       if (bx.bipart == null)
/*  822 */         return bx.lpart > 0L;
/*  823 */       return bx.bipart.signum() > 0;
/*      */     }
/*      */     
/*      */     public boolean isNeg(Number x) {
/*  827 */       BigInt bx = Numbers.toBigInt(x);
/*  828 */       if (bx.bipart == null)
/*  829 */         return bx.lpart < 0L;
/*  830 */       return bx.bipart.signum() < 0;
/*      */     }
/*      */     
/*      */     public final Number add(Number x, Number y) {
/*  834 */       return Numbers.toBigInt(x).add(Numbers.toBigInt(y));
/*      */     }
/*      */     
/*      */     public final Number multiply(Number x, Number y) {
/*  838 */       return Numbers.toBigInt(x).multiply(Numbers.toBigInt(y));
/*      */     }
/*      */     
/*      */     public Number divide(Number x, Number y) {
/*  842 */       return Numbers.divide(Numbers.toBigInteger(x), Numbers.toBigInteger(y));
/*      */     }
/*      */     
/*      */     public Number quotient(Number x, Number y) {
/*  846 */       return Numbers.toBigInt(x).quotient(Numbers.toBigInt(y));
/*      */     }
/*      */     
/*      */     public Number remainder(Number x, Number y) {
/*  850 */       return Numbers.toBigInt(x).remainder(Numbers.toBigInt(y));
/*      */     }
/*      */     
/*      */     public boolean equiv(Number x, Number y) {
/*  854 */       return Numbers.toBigInt(x).equals(Numbers.toBigInt(y));
/*      */     }
/*      */     
/*      */     public boolean lt(Number x, Number y) {
/*  858 */       return Numbers.toBigInt(x).lt(Numbers.toBigInt(y));
/*      */     }
/*      */     
/*      */     public boolean lte(Number x, Number y) {
/*  862 */       return Numbers.toBigInteger(x).compareTo(Numbers.toBigInteger(y)) <= 0;
/*      */     }
/*      */     
/*      */     public boolean gte(Number x, Number y) {
/*  866 */       return Numbers.toBigInteger(x).compareTo(Numbers.toBigInteger(y)) >= 0;
/*      */     }
/*      */     
/*      */     public final Number negate(Number x)
/*      */     {
/*  871 */       return BigInt.fromBigInteger(Numbers.toBigInteger(x).negate());
/*      */     }
/*      */     
/*      */     public Number inc(Number x) {
/*  875 */       BigInteger bx = Numbers.toBigInteger(x);
/*  876 */       return BigInt.fromBigInteger(bx.add(BigInteger.ONE));
/*      */     }
/*      */     
/*      */     public Number dec(Number x) {
/*  880 */       BigInteger bx = Numbers.toBigInteger(x);
/*  881 */       return BigInt.fromBigInteger(bx.subtract(BigInteger.ONE));
/*      */     }
/*      */   }
/*      */   
/*      */   static final class BigDecimalOps extends Numbers.OpsP
/*      */   {
/*  887 */     static final Var MATH_CONTEXT = RT.MATH_CONTEXT;
/*      */     
/*      */     public Numbers.Ops combine(Numbers.Ops y) {
/*  890 */       return y.opsWith(this);
/*      */     }
/*      */     
/*      */     public final Numbers.Ops opsWith(Numbers.LongOps x) {
/*  894 */       return this;
/*      */     }
/*      */     
/*      */     public final Numbers.Ops opsWith(Numbers.DoubleOps x) {
/*  898 */       return Numbers.DOUBLE_OPS;
/*      */     }
/*      */     
/*      */     public final Numbers.Ops opsWith(Numbers.RatioOps x) {
/*  902 */       return this;
/*      */     }
/*      */     
/*      */     public final Numbers.Ops opsWith(Numbers.BigIntOps x) {
/*  906 */       return this;
/*      */     }
/*      */     
/*      */     public final Numbers.Ops opsWith(BigDecimalOps x) {
/*  910 */       return this;
/*      */     }
/*      */     
/*      */     public boolean isZero(Number x) {
/*  914 */       BigDecimal bx = (BigDecimal)x;
/*  915 */       return bx.signum() == 0;
/*      */     }
/*      */     
/*      */     public boolean isPos(Number x) {
/*  919 */       BigDecimal bx = (BigDecimal)x;
/*  920 */       return bx.signum() > 0;
/*      */     }
/*      */     
/*      */     public boolean isNeg(Number x) {
/*  924 */       BigDecimal bx = (BigDecimal)x;
/*  925 */       return bx.signum() < 0;
/*      */     }
/*      */     
/*      */     public final Number add(Number x, Number y) {
/*  929 */       MathContext mc = (MathContext)MATH_CONTEXT.deref();
/*  930 */       return mc == null ? Numbers.toBigDecimal(x).add(Numbers.toBigDecimal(y)) : Numbers.toBigDecimal(x).add(Numbers.toBigDecimal(y), mc);
/*      */     }
/*      */     
/*      */ 
/*      */     public final Number multiply(Number x, Number y)
/*      */     {
/*  936 */       MathContext mc = (MathContext)MATH_CONTEXT.deref();
/*  937 */       return mc == null ? Numbers.toBigDecimal(x).multiply(Numbers.toBigDecimal(y)) : Numbers.toBigDecimal(x).multiply(Numbers.toBigDecimal(y), mc);
/*      */     }
/*      */     
/*      */ 
/*      */     public Number divide(Number x, Number y)
/*      */     {
/*  943 */       MathContext mc = (MathContext)MATH_CONTEXT.deref();
/*  944 */       return mc == null ? Numbers.toBigDecimal(x).divide(Numbers.toBigDecimal(y)) : Numbers.toBigDecimal(x).divide(Numbers.toBigDecimal(y), mc);
/*      */     }
/*      */     
/*      */ 
/*      */     public Number quotient(Number x, Number y)
/*      */     {
/*  950 */       MathContext mc = (MathContext)MATH_CONTEXT.deref();
/*  951 */       return mc == null ? Numbers.toBigDecimal(x).divideToIntegralValue(Numbers.toBigDecimal(y)) : Numbers.toBigDecimal(x).divideToIntegralValue(Numbers.toBigDecimal(y), mc);
/*      */     }
/*      */     
/*      */ 
/*      */     public Number remainder(Number x, Number y)
/*      */     {
/*  957 */       MathContext mc = (MathContext)MATH_CONTEXT.deref();
/*  958 */       return mc == null ? Numbers.toBigDecimal(x).remainder(Numbers.toBigDecimal(y)) : Numbers.toBigDecimal(x).remainder(Numbers.toBigDecimal(y), mc);
/*      */     }
/*      */     
/*      */ 
/*      */     public boolean equiv(Number x, Number y)
/*      */     {
/*  964 */       return Numbers.toBigDecimal(x).compareTo(Numbers.toBigDecimal(y)) == 0;
/*      */     }
/*      */     
/*      */     public boolean lt(Number x, Number y) {
/*  968 */       return Numbers.toBigDecimal(x).compareTo(Numbers.toBigDecimal(y)) < 0;
/*      */     }
/*      */     
/*      */     public boolean lte(Number x, Number y) {
/*  972 */       return Numbers.toBigDecimal(x).compareTo(Numbers.toBigDecimal(y)) <= 0;
/*      */     }
/*      */     
/*      */     public boolean gte(Number x, Number y) {
/*  976 */       return Numbers.toBigDecimal(x).compareTo(Numbers.toBigDecimal(y)) >= 0;
/*      */     }
/*      */     
/*      */     public final Number negate(Number x)
/*      */     {
/*  981 */       MathContext mc = (MathContext)MATH_CONTEXT.deref();
/*  982 */       return mc == null ? ((BigDecimal)x).negate() : ((BigDecimal)x).negate(mc);
/*      */     }
/*      */     
/*      */ 
/*      */     public Number inc(Number x)
/*      */     {
/*  988 */       MathContext mc = (MathContext)MATH_CONTEXT.deref();
/*  989 */       BigDecimal bx = (BigDecimal)x;
/*  990 */       return mc == null ? bx.add(BigDecimal.ONE) : bx.add(BigDecimal.ONE, mc);
/*      */     }
/*      */     
/*      */ 
/*      */     public Number dec(Number x)
/*      */     {
/*  996 */       MathContext mc = (MathContext)MATH_CONTEXT.deref();
/*  997 */       BigDecimal bx = (BigDecimal)x;
/*  998 */       return mc == null ? bx.subtract(BigDecimal.ONE) : bx.subtract(BigDecimal.ONE, mc);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/* 1004 */   static final LongOps LONG_OPS = new LongOps();
/* 1005 */   static final DoubleOps DOUBLE_OPS = new DoubleOps();
/* 1006 */   static final RatioOps RATIO_OPS = new RatioOps();
/* 1007 */   static final BigIntOps BIGINT_OPS = new BigIntOps();
/* 1008 */   static final BigDecimalOps BIGDECIMAL_OPS = new BigDecimalOps();
/*      */   
/* 1010 */   public static enum Category { INTEGER,  FLOATING,  DECIMAL,  RATIO;
/*      */     
/*      */     private Category() {} }
/* 1013 */   static Ops ops(Object x) { Class xc = x.getClass();
/*      */     
/* 1015 */     if (xc == Long.class)
/* 1016 */       return LONG_OPS;
/* 1017 */     if (xc == Double.class)
/* 1018 */       return DOUBLE_OPS;
/* 1019 */     if (xc == Integer.class)
/* 1020 */       return LONG_OPS;
/* 1021 */     if (xc == Float.class)
/* 1022 */       return DOUBLE_OPS;
/* 1023 */     if (xc == BigInt.class)
/* 1024 */       return BIGINT_OPS;
/* 1025 */     if (xc == BigInteger.class)
/* 1026 */       return BIGINT_OPS;
/* 1027 */     if (xc == Ratio.class)
/* 1028 */       return RATIO_OPS;
/* 1029 */     if (xc == BigDecimal.class) {
/* 1030 */       return BIGDECIMAL_OPS;
/*      */     }
/* 1032 */     return LONG_OPS;
/*      */   }
/*      */   
/*      */   @WarnBoxedMath(false)
/*      */   static int hasheq(Number x) {
/* 1037 */     Class xc = x.getClass();
/*      */     
/* 1039 */     if ((xc == Long.class) || (xc == Integer.class) || (xc == Short.class) || (xc == Byte.class) || ((xc == BigInteger.class) && (lte(x, Long.MAX_VALUE)) && (gte(x, Long.MIN_VALUE))))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1045 */       long lpart = x.longValue();
/* 1046 */       return Murmur3.hashLong(lpart);
/*      */     }
/*      */     
/* 1049 */     if (xc == BigDecimal.class)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1056 */       if (isZero(x)) {
/* 1057 */         return BigDecimal.ZERO.hashCode();
/*      */       }
/*      */       
/* 1060 */       BigDecimal tmp = ((BigDecimal)x).stripTrailingZeros();
/* 1061 */       return tmp.hashCode();
/*      */     }
/*      */     
/* 1064 */     return x.hashCode();
/*      */   }
/*      */   
/*      */   static Category category(Object x) {
/* 1068 */     Class xc = x.getClass();
/*      */     
/* 1070 */     if (xc == Integer.class)
/* 1071 */       return Category.INTEGER;
/* 1072 */     if (xc == Double.class)
/* 1073 */       return Category.FLOATING;
/* 1074 */     if (xc == Long.class)
/* 1075 */       return Category.INTEGER;
/* 1076 */     if (xc == Float.class)
/* 1077 */       return Category.FLOATING;
/* 1078 */     if (xc == BigInt.class)
/* 1079 */       return Category.INTEGER;
/* 1080 */     if (xc == Ratio.class)
/* 1081 */       return Category.RATIO;
/* 1082 */     if (xc == BigDecimal.class) {
/* 1083 */       return Category.DECIMAL;
/*      */     }
/* 1085 */     return Category.INTEGER;
/*      */   }
/*      */   
/*      */   static long bitOpsCast(Object x) {
/* 1089 */     Class xc = x.getClass();
/*      */     
/* 1091 */     if ((xc == Long.class) || (xc == Integer.class) || (xc == Short.class) || (xc == Byte.class))
/*      */     {
/*      */ 
/*      */ 
/* 1095 */       return RT.longCast(x);
/*      */     }
/* 1097 */     throw new IllegalArgumentException("bit operation not supported for: " + xc);
/*      */   }
/*      */   
/*      */   @WarnBoxedMath(false)
/*      */   public static float[] float_array(int size, Object init) {
/* 1102 */     float[] ret = new float[size];
/* 1103 */     if ((init instanceof Number))
/*      */     {
/* 1105 */       float f = ((Number)init).floatValue();
/* 1106 */       for (int i = 0; i < ret.length; i++) {
/* 1107 */         ret[i] = f;
/*      */       }
/*      */     }
/*      */     else {
/* 1111 */       ISeq s = RT.seq(init);
/* 1112 */       for (int i = 0; (i < size) && (s != null); s = s.next()) {
/* 1113 */         ret[i] = ((Number)s.first()).floatValue();i++;
/*      */       } }
/* 1115 */     return ret;
/*      */   }
/*      */   
/*      */   @WarnBoxedMath(false)
/*      */   public static float[] float_array(Object sizeOrSeq) {
/* 1120 */     if ((sizeOrSeq instanceof Number)) {
/* 1121 */       return new float[((Number)sizeOrSeq).intValue()];
/*      */     }
/*      */     
/* 1124 */     ISeq s = RT.seq(sizeOrSeq);
/* 1125 */     int size = RT.count(s);
/* 1126 */     float[] ret = new float[size];
/* 1127 */     for (int i = 0; (i < size) && (s != null); s = s.next()) {
/* 1128 */       ret[i] = ((Number)s.first()).floatValue();i++; }
/* 1129 */     return ret;
/*      */   }
/*      */   
/*      */   @WarnBoxedMath(false)
/*      */   public static double[] double_array(int size, Object init)
/*      */   {
/* 1135 */     double[] ret = new double[size];
/* 1136 */     if ((init instanceof Number))
/*      */     {
/* 1138 */       double f = ((Number)init).doubleValue();
/* 1139 */       for (int i = 0; i < ret.length; i++) {
/* 1140 */         ret[i] = f;
/*      */       }
/*      */     }
/*      */     else {
/* 1144 */       ISeq s = RT.seq(init);
/* 1145 */       for (int i = 0; (i < size) && (s != null); s = s.next()) {
/* 1146 */         ret[i] = ((Number)s.first()).doubleValue();i++;
/*      */       } }
/* 1148 */     return ret;
/*      */   }
/*      */   
/*      */   @WarnBoxedMath(false)
/*      */   public static double[] double_array(Object sizeOrSeq) {
/* 1153 */     if ((sizeOrSeq instanceof Number)) {
/* 1154 */       return new double[((Number)sizeOrSeq).intValue()];
/*      */     }
/*      */     
/* 1157 */     ISeq s = RT.seq(sizeOrSeq);
/* 1158 */     int size = RT.count(s);
/* 1159 */     double[] ret = new double[size];
/* 1160 */     for (int i = 0; (i < size) && (s != null); s = s.next()) {
/* 1161 */       ret[i] = ((Number)s.first()).doubleValue();i++; }
/* 1162 */     return ret;
/*      */   }
/*      */   
/*      */   @WarnBoxedMath(false)
/*      */   public static int[] int_array(int size, Object init)
/*      */   {
/* 1168 */     int[] ret = new int[size];
/* 1169 */     if ((init instanceof Number))
/*      */     {
/* 1171 */       int f = ((Number)init).intValue();
/* 1172 */       for (int i = 0; i < ret.length; i++) {
/* 1173 */         ret[i] = f;
/*      */       }
/*      */     }
/*      */     else {
/* 1177 */       ISeq s = RT.seq(init);
/* 1178 */       for (int i = 0; (i < size) && (s != null); s = s.next()) {
/* 1179 */         ret[i] = ((Number)s.first()).intValue();i++;
/*      */       } }
/* 1181 */     return ret;
/*      */   }
/*      */   
/*      */   @WarnBoxedMath(false)
/*      */   public static int[] int_array(Object sizeOrSeq) {
/* 1186 */     if ((sizeOrSeq instanceof Number)) {
/* 1187 */       return new int[((Number)sizeOrSeq).intValue()];
/*      */     }
/*      */     
/* 1190 */     ISeq s = RT.seq(sizeOrSeq);
/* 1191 */     int size = RT.count(s);
/* 1192 */     int[] ret = new int[size];
/* 1193 */     for (int i = 0; (i < size) && (s != null); s = s.next()) {
/* 1194 */       ret[i] = ((Number)s.first()).intValue();i++; }
/* 1195 */     return ret;
/*      */   }
/*      */   
/*      */   @WarnBoxedMath(false)
/*      */   public static long[] long_array(int size, Object init)
/*      */   {
/* 1201 */     long[] ret = new long[size];
/* 1202 */     if ((init instanceof Number))
/*      */     {
/* 1204 */       long f = ((Number)init).longValue();
/* 1205 */       for (int i = 0; i < ret.length; i++) {
/* 1206 */         ret[i] = f;
/*      */       }
/*      */     }
/*      */     else {
/* 1210 */       ISeq s = RT.seq(init);
/* 1211 */       for (int i = 0; (i < size) && (s != null); s = s.next()) {
/* 1212 */         ret[i] = ((Number)s.first()).longValue();i++;
/*      */       } }
/* 1214 */     return ret;
/*      */   }
/*      */   
/*      */   @WarnBoxedMath(false)
/*      */   public static long[] long_array(Object sizeOrSeq) {
/* 1219 */     if ((sizeOrSeq instanceof Number)) {
/* 1220 */       return new long[((Number)sizeOrSeq).intValue()];
/*      */     }
/*      */     
/* 1223 */     ISeq s = RT.seq(sizeOrSeq);
/* 1224 */     int size = RT.count(s);
/* 1225 */     long[] ret = new long[size];
/* 1226 */     for (int i = 0; (i < size) && (s != null); s = s.next()) {
/* 1227 */       ret[i] = ((Number)s.first()).longValue();i++; }
/* 1228 */     return ret;
/*      */   }
/*      */   
/*      */   @WarnBoxedMath(false)
/*      */   public static short[] short_array(int size, Object init)
/*      */   {
/* 1234 */     short[] ret = new short[size];
/* 1235 */     if ((init instanceof Short))
/*      */     {
/* 1237 */       short s = ((Short)init).shortValue();
/* 1238 */       for (int i = 0; i < ret.length; i++) {
/* 1239 */         ret[i] = s;
/*      */       }
/*      */     }
/*      */     else {
/* 1243 */       ISeq s = RT.seq(init);
/* 1244 */       for (int i = 0; (i < size) && (s != null); s = s.next()) {
/* 1245 */         ret[i] = ((Number)s.first()).shortValue();i++;
/*      */       } }
/* 1247 */     return ret;
/*      */   }
/*      */   
/*      */   @WarnBoxedMath(false)
/*      */   public static short[] short_array(Object sizeOrSeq) {
/* 1252 */     if ((sizeOrSeq instanceof Number)) {
/* 1253 */       return new short[((Number)sizeOrSeq).intValue()];
/*      */     }
/*      */     
/* 1256 */     ISeq s = RT.seq(sizeOrSeq);
/* 1257 */     int size = RT.count(s);
/* 1258 */     short[] ret = new short[size];
/* 1259 */     for (int i = 0; (i < size) && (s != null); s = s.next()) {
/* 1260 */       ret[i] = ((Number)s.first()).shortValue();i++; }
/* 1261 */     return ret;
/*      */   }
/*      */   
/*      */   @WarnBoxedMath(false)
/*      */   public static char[] char_array(int size, Object init)
/*      */   {
/* 1267 */     char[] ret = new char[size];
/* 1268 */     if ((init instanceof Character))
/*      */     {
/* 1270 */       char c = ((Character)init).charValue();
/* 1271 */       for (int i = 0; i < ret.length; i++) {
/* 1272 */         ret[i] = c;
/*      */       }
/*      */     }
/*      */     else {
/* 1276 */       ISeq s = RT.seq(init);
/* 1277 */       for (int i = 0; (i < size) && (s != null); s = s.next()) {
/* 1278 */         ret[i] = ((Character)s.first()).charValue();i++;
/*      */       } }
/* 1280 */     return ret;
/*      */   }
/*      */   
/*      */   @WarnBoxedMath(false)
/*      */   public static char[] char_array(Object sizeOrSeq) {
/* 1285 */     if ((sizeOrSeq instanceof Number)) {
/* 1286 */       return new char[((Number)sizeOrSeq).intValue()];
/*      */     }
/*      */     
/* 1289 */     ISeq s = RT.seq(sizeOrSeq);
/* 1290 */     int size = RT.count(s);
/* 1291 */     char[] ret = new char[size];
/* 1292 */     for (int i = 0; (i < size) && (s != null); s = s.next()) {
/* 1293 */       ret[i] = ((Character)s.first()).charValue();i++; }
/* 1294 */     return ret;
/*      */   }
/*      */   
/*      */   @WarnBoxedMath(false)
/*      */   public static byte[] byte_array(int size, Object init)
/*      */   {
/* 1300 */     byte[] ret = new byte[size];
/* 1301 */     if ((init instanceof Byte))
/*      */     {
/* 1303 */       byte b = ((Byte)init).byteValue();
/* 1304 */       for (int i = 0; i < ret.length; i++) {
/* 1305 */         ret[i] = b;
/*      */       }
/*      */     }
/*      */     else {
/* 1309 */       ISeq s = RT.seq(init);
/* 1310 */       for (int i = 0; (i < size) && (s != null); s = s.next()) {
/* 1311 */         ret[i] = ((Number)s.first()).byteValue();i++;
/*      */       } }
/* 1313 */     return ret;
/*      */   }
/*      */   
/*      */   @WarnBoxedMath(false)
/*      */   public static byte[] byte_array(Object sizeOrSeq) {
/* 1318 */     if ((sizeOrSeq instanceof Number)) {
/* 1319 */       return new byte[((Number)sizeOrSeq).intValue()];
/*      */     }
/*      */     
/* 1322 */     ISeq s = RT.seq(sizeOrSeq);
/* 1323 */     int size = RT.count(s);
/* 1324 */     byte[] ret = new byte[size];
/* 1325 */     for (int i = 0; (i < size) && (s != null); s = s.next()) {
/* 1326 */       ret[i] = ((Number)s.first()).byteValue();i++; }
/* 1327 */     return ret;
/*      */   }
/*      */   
/*      */   @WarnBoxedMath(false)
/*      */   public static boolean[] boolean_array(int size, Object init)
/*      */   {
/* 1333 */     boolean[] ret = new boolean[size];
/* 1334 */     if ((init instanceof Boolean))
/*      */     {
/* 1336 */       boolean b = ((Boolean)init).booleanValue();
/* 1337 */       for (int i = 0; i < ret.length; i++) {
/* 1338 */         ret[i] = b;
/*      */       }
/*      */     }
/*      */     else {
/* 1342 */       ISeq s = RT.seq(init);
/* 1343 */       for (int i = 0; (i < size) && (s != null); s = s.next()) {
/* 1344 */         ret[i] = ((Boolean)s.first()).booleanValue();i++;
/*      */       } }
/* 1346 */     return ret;
/*      */   }
/*      */   
/*      */   @WarnBoxedMath(false)
/*      */   public static boolean[] boolean_array(Object sizeOrSeq) {
/* 1351 */     if ((sizeOrSeq instanceof Number)) {
/* 1352 */       return new boolean[((Number)sizeOrSeq).intValue()];
/*      */     }
/*      */     
/* 1355 */     ISeq s = RT.seq(sizeOrSeq);
/* 1356 */     int size = RT.count(s);
/* 1357 */     boolean[] ret = new boolean[size];
/* 1358 */     for (int i = 0; (i < size) && (s != null); s = s.next()) {
/* 1359 */       ret[i] = ((Boolean)s.first()).booleanValue();i++; }
/* 1360 */     return ret;
/*      */   }
/*      */   
/*      */   @WarnBoxedMath(false)
/*      */   public static boolean[] booleans(Object array)
/*      */   {
/* 1366 */     return (boolean[])array;
/*      */   }
/*      */   
/*      */   @WarnBoxedMath(false)
/*      */   public static byte[] bytes(Object array) {
/* 1371 */     return (byte[])array;
/*      */   }
/*      */   
/*      */   @WarnBoxedMath(false)
/*      */   public static char[] chars(Object array) {
/* 1376 */     return (char[])array;
/*      */   }
/*      */   
/*      */   @WarnBoxedMath(false)
/*      */   public static short[] shorts(Object array) {
/* 1381 */     return (short[])array;
/*      */   }
/*      */   
/*      */   @WarnBoxedMath(false)
/*      */   public static float[] floats(Object array) {
/* 1386 */     return (float[])array;
/*      */   }
/*      */   
/*      */   @WarnBoxedMath(false)
/*      */   public static double[] doubles(Object array) {
/* 1391 */     return (double[])array;
/*      */   }
/*      */   
/*      */   @WarnBoxedMath(false)
/*      */   public static int[] ints(Object array) {
/* 1396 */     return (int[])array;
/*      */   }
/*      */   
/*      */   @WarnBoxedMath(false)
/*      */   public static long[] longs(Object array) {
/* 1401 */     return (long[])array;
/*      */   }
/*      */   
/*      */   public static Number num(Object x) {
/* 1405 */     return (Number)x;
/*      */   }
/*      */   
/*      */   public static Number num(float x) {
/* 1409 */     return Float.valueOf(x);
/*      */   }
/*      */   
/*      */   public static Number num(double x) {
/* 1413 */     return Double.valueOf(x);
/*      */   }
/*      */   
/*      */   public static double add(double x, double y) {
/* 1417 */     return x + y;
/*      */   }
/*      */   
/*      */   public static double addP(double x, double y) {
/* 1421 */     return x + y;
/*      */   }
/*      */   
/*      */   public static double minus(double x, double y) {
/* 1425 */     return x - y;
/*      */   }
/*      */   
/*      */   public static double minusP(double x, double y) {
/* 1429 */     return x - y;
/*      */   }
/*      */   
/*      */   public static double minus(double x) {
/* 1433 */     return -x;
/*      */   }
/*      */   
/*      */   public static double minusP(double x) {
/* 1437 */     return -x;
/*      */   }
/*      */   
/*      */   public static double inc(double x) {
/* 1441 */     return x + 1.0D;
/*      */   }
/*      */   
/*      */   public static double incP(double x) {
/* 1445 */     return x + 1.0D;
/*      */   }
/*      */   
/*      */   public static double dec(double x) {
/* 1449 */     return x - 1.0D;
/*      */   }
/*      */   
/*      */   public static double decP(double x) {
/* 1453 */     return x - 1.0D;
/*      */   }
/*      */   
/*      */   public static double multiply(double x, double y) {
/* 1457 */     return x * y;
/*      */   }
/*      */   
/*      */   public static double multiplyP(double x, double y) {
/* 1461 */     return x * y;
/*      */   }
/*      */   
/*      */   public static double divide(double x, double y) {
/* 1465 */     return x / y;
/*      */   }
/*      */   
/*      */   public static boolean equiv(double x, double y) {
/* 1469 */     return x == y;
/*      */   }
/*      */   
/*      */   public static boolean lt(double x, double y) {
/* 1473 */     return x < y;
/*      */   }
/*      */   
/*      */   public static boolean lte(double x, double y) {
/* 1477 */     return x <= y;
/*      */   }
/*      */   
/*      */   public static boolean gt(double x, double y) {
/* 1481 */     return x > y;
/*      */   }
/*      */   
/*      */   public static boolean gte(double x, double y) {
/* 1485 */     return x >= y;
/*      */   }
/*      */   
/*      */   public static boolean isPos(double x) {
/* 1489 */     return x > 0.0D;
/*      */   }
/*      */   
/*      */   public static boolean isNeg(double x) {
/* 1493 */     return x < 0.0D;
/*      */   }
/*      */   
/*      */   public static boolean isZero(double x) {
/* 1497 */     return x == 0.0D;
/*      */   }
/*      */   
/*      */   static int throwIntOverflow() {
/* 1501 */     throw new ArithmeticException("integer overflow");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int unchecked_int_add(int x, int y)
/*      */   {
/* 1509 */     return x + y;
/*      */   }
/*      */   
/*      */   public static int unchecked_int_subtract(int x, int y) {
/* 1513 */     return x - y;
/*      */   }
/*      */   
/*      */   public static int unchecked_int_negate(int x) {
/* 1517 */     return -x;
/*      */   }
/*      */   
/*      */   public static int unchecked_int_inc(int x) {
/* 1521 */     return x + 1;
/*      */   }
/*      */   
/*      */   public static int unchecked_int_dec(int x) {
/* 1525 */     return x - 1;
/*      */   }
/*      */   
/*      */   public static int unchecked_int_multiply(int x, int y) {
/* 1529 */     return x * y;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static long not(Object x)
/*      */   {
/* 1544 */     return not(bitOpsCast(x));
/*      */   }
/*      */   
/* 1547 */   public static long not(long x) { return x ^ 0xFFFFFFFFFFFFFFFF; }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static long and(Object x, Object y)
/*      */   {
/* 1554 */     return and(bitOpsCast(x), bitOpsCast(y));
/*      */   }
/*      */   
/* 1557 */   public static long and(Object x, long y) { return and(bitOpsCast(x), y); }
/*      */   
/*      */   public static long and(long x, Object y) {
/* 1560 */     return and(x, bitOpsCast(y));
/*      */   }
/*      */   
/* 1563 */   public static long and(long x, long y) { return x & y; }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static long or(Object x, Object y)
/*      */   {
/* 1571 */     return or(bitOpsCast(x), bitOpsCast(y));
/*      */   }
/*      */   
/* 1574 */   public static long or(Object x, long y) { return or(bitOpsCast(x), y); }
/*      */   
/*      */   public static long or(long x, Object y) {
/* 1577 */     return or(x, bitOpsCast(y));
/*      */   }
/*      */   
/* 1580 */   public static long or(long x, long y) { return x | y; }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static long xor(Object x, Object y)
/*      */   {
/* 1588 */     return xor(bitOpsCast(x), bitOpsCast(y));
/*      */   }
/*      */   
/* 1591 */   public static long xor(Object x, long y) { return xor(bitOpsCast(x), y); }
/*      */   
/*      */   public static long xor(long x, Object y) {
/* 1594 */     return xor(x, bitOpsCast(y));
/*      */   }
/*      */   
/* 1597 */   public static long xor(long x, long y) { return x ^ y; }
/*      */   
/*      */   public static long andNot(Object x, Object y)
/*      */   {
/* 1601 */     return andNot(bitOpsCast(x), bitOpsCast(y));
/*      */   }
/*      */   
/* 1604 */   public static long andNot(Object x, long y) { return andNot(bitOpsCast(x), y); }
/*      */   
/*      */   public static long andNot(long x, Object y) {
/* 1607 */     return andNot(x, bitOpsCast(y));
/*      */   }
/*      */   
/* 1610 */   public static long andNot(long x, long y) { return x & (y ^ 0xFFFFFFFFFFFFFFFF); }
/*      */   
/*      */   public static long clearBit(Object x, Object y)
/*      */   {
/* 1614 */     return clearBit(bitOpsCast(x), bitOpsCast(y));
/*      */   }
/*      */   
/* 1617 */   public static long clearBit(Object x, long y) { return clearBit(bitOpsCast(x), y); }
/*      */   
/*      */   public static long clearBit(long x, Object y) {
/* 1620 */     return clearBit(x, bitOpsCast(y));
/*      */   }
/*      */   
/* 1623 */   public static long clearBit(long x, long n) { return x & (1L << (int)n ^ 0xFFFFFFFFFFFFFFFF); }
/*      */   
/*      */   public static long setBit(Object x, Object y)
/*      */   {
/* 1627 */     return setBit(bitOpsCast(x), bitOpsCast(y));
/*      */   }
/*      */   
/* 1630 */   public static long setBit(Object x, long y) { return setBit(bitOpsCast(x), y); }
/*      */   
/*      */   public static long setBit(long x, Object y) {
/* 1633 */     return setBit(x, bitOpsCast(y));
/*      */   }
/*      */   
/* 1636 */   public static long setBit(long x, long n) { return x | 1L << (int)n; }
/*      */   
/*      */   public static long flipBit(Object x, Object y)
/*      */   {
/* 1640 */     return flipBit(bitOpsCast(x), bitOpsCast(y));
/*      */   }
/*      */   
/* 1643 */   public static long flipBit(Object x, long y) { return flipBit(bitOpsCast(x), y); }
/*      */   
/*      */   public static long flipBit(long x, Object y) {
/* 1646 */     return flipBit(x, bitOpsCast(y));
/*      */   }
/*      */   
/* 1649 */   public static long flipBit(long x, long n) { return x ^ 1L << (int)n; }
/*      */   
/*      */   public static boolean testBit(Object x, Object y)
/*      */   {
/* 1653 */     return testBit(bitOpsCast(x), bitOpsCast(y));
/*      */   }
/*      */   
/* 1656 */   public static boolean testBit(Object x, long y) { return testBit(bitOpsCast(x), y); }
/*      */   
/*      */   public static boolean testBit(long x, Object y) {
/* 1659 */     return testBit(x, bitOpsCast(y));
/*      */   }
/*      */   
/* 1662 */   public static boolean testBit(long x, long n) { return (x & 1L << (int)n) != 0L; }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int unchecked_int_divide(int x, int y)
/*      */   {
/* 1698 */     return x / y;
/*      */   }
/*      */   
/*      */   public static int unchecked_int_remainder(int x, int y) {
/* 1702 */     return x % y;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Number num(long x)
/*      */   {
/* 1738 */     return Long.valueOf(x);
/*      */   }
/*      */   
/* 1741 */   public static long unchecked_add(long x, long y) { return x + y; }
/* 1742 */   public static long unchecked_minus(long x, long y) { return x - y; }
/* 1743 */   public static long unchecked_multiply(long x, long y) { return x * y; }
/* 1744 */   public static long unchecked_minus(long x) { return -x; }
/* 1745 */   public static long unchecked_inc(long x) { return x + 1L; }
/* 1746 */   public static long unchecked_dec(long x) { return x - 1L; }
/*      */   
/* 1748 */   public static Number unchecked_add(Object x, Object y) { return add(x, y); }
/* 1749 */   public static Number unchecked_minus(Object x, Object y) { return minus(x, y); }
/* 1750 */   public static Number unchecked_multiply(Object x, Object y) { return multiply(x, y); }
/* 1751 */   public static Number unchecked_minus(Object x) { return minus(x); }
/* 1752 */   public static Number unchecked_inc(Object x) { return inc(x); }
/* 1753 */   public static Number unchecked_dec(Object x) { return dec(x); }
/*      */   
/* 1755 */   public static double unchecked_add(double x, double y) { return add(x, y); }
/* 1756 */   public static double unchecked_minus(double x, double y) { return minus(x, y); }
/* 1757 */   public static double unchecked_multiply(double x, double y) { return multiply(x, y); }
/* 1758 */   public static double unchecked_minus(double x) { return minus(x); }
/* 1759 */   public static double unchecked_inc(double x) { return inc(x); }
/* 1760 */   public static double unchecked_dec(double x) { return dec(x); }
/*      */   
/* 1762 */   public static double unchecked_add(double x, Object y) { return add(x, y); }
/* 1763 */   public static double unchecked_minus(double x, Object y) { return minus(x, y); }
/* 1764 */   public static double unchecked_multiply(double x, Object y) { return multiply(x, y); }
/* 1765 */   public static double unchecked_add(Object x, double y) { return add(x, y); }
/* 1766 */   public static double unchecked_minus(Object x, double y) { return minus(x, y); }
/* 1767 */   public static double unchecked_multiply(Object x, double y) { return multiply(x, y); }
/*      */   
/* 1769 */   public static double unchecked_add(double x, long y) { return add(x, y); }
/* 1770 */   public static double unchecked_minus(double x, long y) { return minus(x, y); }
/* 1771 */   public static double unchecked_multiply(double x, long y) { return multiply(x, y); }
/* 1772 */   public static double unchecked_add(long x, double y) { return add(x, y); }
/* 1773 */   public static double unchecked_minus(long x, double y) { return minus(x, y); }
/* 1774 */   public static double unchecked_multiply(long x, double y) { return multiply(x, y); }
/*      */   
/* 1776 */   public static Number unchecked_add(long x, Object y) { return add(x, y); }
/* 1777 */   public static Number unchecked_minus(long x, Object y) { return minus(x, y); }
/* 1778 */   public static Number unchecked_multiply(long x, Object y) { return multiply(x, y); }
/* 1779 */   public static Number unchecked_add(Object x, long y) { return add(x, y); }
/* 1780 */   public static Number unchecked_minus(Object x, long y) { return minus(x, y); }
/* 1781 */   public static Number unchecked_multiply(Object x, long y) { return multiply(x, y); }
/*      */   
/* 1783 */   public static Number quotient(double x, Object y) { return quotient(Double.valueOf(x), y); }
/* 1784 */   public static Number quotient(Object x, double y) { return quotient(x, Double.valueOf(y)); }
/* 1785 */   public static Number quotient(long x, Object y) { return quotient(Long.valueOf(x), y); }
/* 1786 */   public static Number quotient(Object x, long y) { return quotient(x, Long.valueOf(y)); }
/* 1787 */   public static double quotient(double x, long y) { return quotient(x, y); }
/* 1788 */   public static double quotient(long x, double y) { return quotient(x, y); }
/*      */   
/* 1790 */   public static Number remainder(double x, Object y) { return remainder(Double.valueOf(x), y); }
/* 1791 */   public static Number remainder(Object x, double y) { return remainder(x, Double.valueOf(y)); }
/* 1792 */   public static Number remainder(long x, Object y) { return remainder(Long.valueOf(x), y); }
/* 1793 */   public static Number remainder(Object x, long y) { return remainder(x, Long.valueOf(y)); }
/* 1794 */   public static double remainder(double x, long y) { return remainder(x, y); }
/* 1795 */   public static double remainder(long x, double y) { return remainder(x, y); }
/*      */   
/*      */   public static long add(long x, long y) {
/* 1798 */     long ret = x + y;
/* 1799 */     if (((ret ^ x) < 0L) && ((ret ^ y) < 0L))
/* 1800 */       return throwIntOverflow();
/* 1801 */     return ret;
/*      */   }
/*      */   
/*      */   public static Number addP(long x, long y) {
/* 1805 */     long ret = x + y;
/* 1806 */     if (((ret ^ x) < 0L) && ((ret ^ y) < 0L))
/* 1807 */       return addP(Long.valueOf(x), Long.valueOf(y));
/* 1808 */     return num(ret);
/*      */   }
/*      */   
/*      */   public static long minus(long x, long y) {
/* 1812 */     long ret = x - y;
/* 1813 */     if (((ret ^ x) < 0L) && ((ret ^ y ^ 0xFFFFFFFFFFFFFFFF) < 0L))
/* 1814 */       return throwIntOverflow();
/* 1815 */     return ret;
/*      */   }
/*      */   
/*      */   public static Number minusP(long x, long y) {
/* 1819 */     long ret = x - y;
/* 1820 */     if (((ret ^ x) < 0L) && ((ret ^ y ^ 0xFFFFFFFFFFFFFFFF) < 0L))
/* 1821 */       return minusP(Long.valueOf(x), Long.valueOf(y));
/* 1822 */     return num(ret);
/*      */   }
/*      */   
/*      */   public static long minus(long x) {
/* 1826 */     if (x == Long.MIN_VALUE)
/* 1827 */       return throwIntOverflow();
/* 1828 */     return -x;
/*      */   }
/*      */   
/*      */   public static Number minusP(long x) {
/* 1832 */     if (x == Long.MIN_VALUE)
/* 1833 */       return BigInt.fromBigInteger(BigInteger.valueOf(x).negate());
/* 1834 */     return num(-x);
/*      */   }
/*      */   
/*      */   public static long inc(long x) {
/* 1838 */     if (x == Long.MAX_VALUE)
/* 1839 */       return throwIntOverflow();
/* 1840 */     return x + 1L;
/*      */   }
/*      */   
/*      */   public static Number incP(long x) {
/* 1844 */     if (x == Long.MAX_VALUE)
/* 1845 */       return BIGINT_OPS.inc(Long.valueOf(x));
/* 1846 */     return num(x + 1L);
/*      */   }
/*      */   
/*      */   public static long dec(long x) {
/* 1850 */     if (x == Long.MIN_VALUE)
/* 1851 */       return throwIntOverflow();
/* 1852 */     return x - 1L;
/*      */   }
/*      */   
/*      */   public static Number decP(long x) {
/* 1856 */     if (x == Long.MIN_VALUE)
/* 1857 */       return BIGINT_OPS.dec(Long.valueOf(x));
/* 1858 */     return num(x - 1L);
/*      */   }
/*      */   
/*      */   public static long multiply(long x, long y)
/*      */   {
/* 1863 */     if ((x == Long.MIN_VALUE) && (y < 0L))
/* 1864 */       return throwIntOverflow();
/* 1865 */     long ret = x * y;
/* 1866 */     if ((y != 0L) && (ret / y != x))
/* 1867 */       return throwIntOverflow();
/* 1868 */     return ret;
/*      */   }
/*      */   
/*      */   public static Number multiplyP(long x, long y) {
/* 1872 */     if ((x == Long.MIN_VALUE) && (y < 0L))
/* 1873 */       return multiplyP(Long.valueOf(x), Long.valueOf(y));
/* 1874 */     long ret = x * y;
/* 1875 */     if ((y != 0L) && (ret / y != x))
/* 1876 */       return multiplyP(Long.valueOf(x), Long.valueOf(y));
/* 1877 */     return num(ret);
/*      */   }
/*      */   
/*      */   public static long quotient(long x, long y) {
/* 1881 */     return x / y;
/*      */   }
/*      */   
/*      */   public static long remainder(long x, long y) {
/* 1885 */     return x % y;
/*      */   }
/*      */   
/*      */   public static boolean equiv(long x, long y) {
/* 1889 */     return x == y;
/*      */   }
/*      */   
/*      */   public static boolean lt(long x, long y) {
/* 1893 */     return x < y;
/*      */   }
/*      */   
/*      */   public static boolean lte(long x, long y) {
/* 1897 */     return x <= y;
/*      */   }
/*      */   
/*      */   public static boolean gt(long x, long y) {
/* 1901 */     return x > y;
/*      */   }
/*      */   
/*      */   public static boolean gte(long x, long y) {
/* 1905 */     return x >= y;
/*      */   }
/*      */   
/*      */   public static boolean isPos(long x) {
/* 1909 */     return x > 0L;
/*      */   }
/*      */   
/*      */   public static boolean isNeg(long x) {
/* 1913 */     return x < 0L;
/*      */   }
/*      */   
/*      */   public static boolean isZero(long x) {
/* 1917 */     return x == 0L;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Number add(long x, Object y)
/*      */   {
/* 3640 */     return add(Long.valueOf(x), y);
/*      */   }
/*      */   
/*      */   public static Number add(Object x, long y) {
/* 3644 */     return add(x, Long.valueOf(y));
/*      */   }
/*      */   
/*      */   public static Number addP(long x, Object y) {
/* 3648 */     return addP(Long.valueOf(x), y);
/*      */   }
/*      */   
/*      */   public static Number addP(Object x, long y) {
/* 3652 */     return addP(x, Long.valueOf(y));
/*      */   }
/*      */   
/*      */   public static double add(double x, Object y) {
/* 3656 */     return add(x, ((Number)y).doubleValue());
/*      */   }
/*      */   
/*      */   public static double add(Object x, double y) {
/* 3660 */     return add(((Number)x).doubleValue(), y);
/*      */   }
/*      */   
/*      */   public static double add(double x, long y) {
/* 3664 */     return x + y;
/*      */   }
/*      */   
/*      */   public static double add(long x, double y) {
/* 3668 */     return x + y;
/*      */   }
/*      */   
/*      */   public static double addP(double x, Object y) {
/* 3672 */     return addP(x, ((Number)y).doubleValue());
/*      */   }
/*      */   
/*      */   public static double addP(Object x, double y) {
/* 3676 */     return addP(((Number)x).doubleValue(), y);
/*      */   }
/*      */   
/*      */   public static double addP(double x, long y) {
/* 3680 */     return x + y;
/*      */   }
/*      */   
/*      */   public static double addP(long x, double y) {
/* 3684 */     return x + y;
/*      */   }
/*      */   
/*      */   public static Number minus(long x, Object y) {
/* 3688 */     return minus(Long.valueOf(x), y);
/*      */   }
/*      */   
/*      */   public static Number minus(Object x, long y) {
/* 3692 */     return minus(x, Long.valueOf(y));
/*      */   }
/*      */   
/*      */   public static Number minusP(long x, Object y) {
/* 3696 */     return minusP(Long.valueOf(x), y);
/*      */   }
/*      */   
/*      */   public static Number minusP(Object x, long y) {
/* 3700 */     return minusP(x, Long.valueOf(y));
/*      */   }
/*      */   
/*      */   public static double minus(double x, Object y) {
/* 3704 */     return minus(x, ((Number)y).doubleValue());
/*      */   }
/*      */   
/*      */   public static double minus(Object x, double y) {
/* 3708 */     return minus(((Number)x).doubleValue(), y);
/*      */   }
/*      */   
/*      */   public static double minus(double x, long y) {
/* 3712 */     return x - y;
/*      */   }
/*      */   
/*      */   public static double minus(long x, double y) {
/* 3716 */     return x - y;
/*      */   }
/*      */   
/*      */   public static double minusP(double x, Object y) {
/* 3720 */     return minus(x, ((Number)y).doubleValue());
/*      */   }
/*      */   
/*      */   public static double minusP(Object x, double y) {
/* 3724 */     return minus(((Number)x).doubleValue(), y);
/*      */   }
/*      */   
/*      */   public static double minusP(double x, long y) {
/* 3728 */     return x - y;
/*      */   }
/*      */   
/*      */   public static double minusP(long x, double y) {
/* 3732 */     return x - y;
/*      */   }
/*      */   
/*      */   public static Number multiply(long x, Object y) {
/* 3736 */     return multiply(Long.valueOf(x), y);
/*      */   }
/*      */   
/*      */   public static Number multiply(Object x, long y) {
/* 3740 */     return multiply(x, Long.valueOf(y));
/*      */   }
/*      */   
/*      */   public static Number multiplyP(long x, Object y) {
/* 3744 */     return multiplyP(Long.valueOf(x), y);
/*      */   }
/*      */   
/*      */   public static Number multiplyP(Object x, long y) {
/* 3748 */     return multiplyP(x, Long.valueOf(y));
/*      */   }
/*      */   
/*      */   public static double multiply(double x, Object y) {
/* 3752 */     return multiply(x, ((Number)y).doubleValue());
/*      */   }
/*      */   
/*      */   public static double multiply(Object x, double y) {
/* 3756 */     return multiply(((Number)x).doubleValue(), y);
/*      */   }
/*      */   
/*      */   public static double multiply(double x, long y) {
/* 3760 */     return x * y;
/*      */   }
/*      */   
/*      */   public static double multiply(long x, double y) {
/* 3764 */     return x * y;
/*      */   }
/*      */   
/*      */   public static double multiplyP(double x, Object y) {
/* 3768 */     return multiplyP(x, ((Number)y).doubleValue());
/*      */   }
/*      */   
/*      */   public static double multiplyP(Object x, double y) {
/* 3772 */     return multiplyP(((Number)x).doubleValue(), y);
/*      */   }
/*      */   
/*      */   public static double multiplyP(double x, long y) {
/* 3776 */     return x * y;
/*      */   }
/*      */   
/*      */   public static double multiplyP(long x, double y) {
/* 3780 */     return x * y;
/*      */   }
/*      */   
/*      */   public static Number divide(long x, Object y) {
/* 3784 */     return divide(Long.valueOf(x), y);
/*      */   }
/*      */   
/*      */   public static Number divide(Object x, long y) {
/* 3788 */     return divide(x, Long.valueOf(y));
/*      */   }
/*      */   
/*      */   public static double divide(double x, Object y) {
/* 3792 */     return x / ((Number)y).doubleValue();
/*      */   }
/*      */   
/*      */   public static double divide(Object x, double y) {
/* 3796 */     return ((Number)x).doubleValue() / y;
/*      */   }
/*      */   
/*      */   public static double divide(double x, long y) {
/* 3800 */     return x / y;
/*      */   }
/*      */   
/*      */   public static double divide(long x, double y) {
/* 3804 */     return x / y;
/*      */   }
/*      */   
/*      */   public static Number divide(long x, long y) {
/* 3808 */     return divide(Long.valueOf(x), Long.valueOf(y));
/*      */   }
/*      */   
/*      */   public static boolean lt(long x, Object y) {
/* 3812 */     return lt(Long.valueOf(x), y);
/*      */   }
/*      */   
/*      */   public static boolean lt(Object x, long y) {
/* 3816 */     return lt(x, Long.valueOf(y));
/*      */   }
/*      */   
/*      */   public static boolean lt(double x, Object y) {
/* 3820 */     return x < ((Number)y).doubleValue();
/*      */   }
/*      */   
/*      */   public static boolean lt(Object x, double y) {
/* 3824 */     return ((Number)x).doubleValue() < y;
/*      */   }
/*      */   
/*      */   public static boolean lt(double x, long y) {
/* 3828 */     return x < y;
/*      */   }
/*      */   
/*      */   public static boolean lt(long x, double y) {
/* 3832 */     return x < y;
/*      */   }
/*      */   
/*      */   public static boolean lte(long x, Object y) {
/* 3836 */     return lte(Long.valueOf(x), y);
/*      */   }
/*      */   
/*      */   public static boolean lte(Object x, long y) {
/* 3840 */     return lte(x, Long.valueOf(y));
/*      */   }
/*      */   
/*      */   public static boolean lte(double x, Object y) {
/* 3844 */     return x <= ((Number)y).doubleValue();
/*      */   }
/*      */   
/*      */   public static boolean lte(Object x, double y) {
/* 3848 */     return ((Number)x).doubleValue() <= y;
/*      */   }
/*      */   
/*      */   public static boolean lte(double x, long y) {
/* 3852 */     return x <= y;
/*      */   }
/*      */   
/*      */   public static boolean lte(long x, double y) {
/* 3856 */     return x <= y;
/*      */   }
/*      */   
/*      */   public static boolean gt(long x, Object y) {
/* 3860 */     return gt(Long.valueOf(x), y);
/*      */   }
/*      */   
/*      */   public static boolean gt(Object x, long y) {
/* 3864 */     return gt(x, Long.valueOf(y));
/*      */   }
/*      */   
/*      */   public static boolean gt(double x, Object y) {
/* 3868 */     return x > ((Number)y).doubleValue();
/*      */   }
/*      */   
/*      */   public static boolean gt(Object x, double y) {
/* 3872 */     return ((Number)x).doubleValue() > y;
/*      */   }
/*      */   
/*      */   public static boolean gt(double x, long y) {
/* 3876 */     return x > y;
/*      */   }
/*      */   
/*      */   public static boolean gt(long x, double y) {
/* 3880 */     return x > y;
/*      */   }
/*      */   
/*      */   public static boolean gte(long x, Object y) {
/* 3884 */     return gte(Long.valueOf(x), y);
/*      */   }
/*      */   
/*      */   public static boolean gte(Object x, long y) {
/* 3888 */     return gte(x, Long.valueOf(y));
/*      */   }
/*      */   
/*      */   public static boolean gte(double x, Object y) {
/* 3892 */     return x >= ((Number)y).doubleValue();
/*      */   }
/*      */   
/*      */   public static boolean gte(Object x, double y) {
/* 3896 */     return ((Number)x).doubleValue() >= y;
/*      */   }
/*      */   
/*      */   public static boolean gte(double x, long y) {
/* 3900 */     return x >= y;
/*      */   }
/*      */   
/*      */   public static boolean gte(long x, double y) {
/* 3904 */     return x >= y;
/*      */   }
/*      */   
/*      */   public static boolean equiv(long x, Object y) {
/* 3908 */     return equiv(Long.valueOf(x), y);
/*      */   }
/*      */   
/*      */   public static boolean equiv(Object x, long y) {
/* 3912 */     return equiv(x, Long.valueOf(y));
/*      */   }
/*      */   
/*      */   public static boolean equiv(double x, Object y) {
/* 3916 */     return x == ((Number)y).doubleValue();
/*      */   }
/*      */   
/*      */   public static boolean equiv(Object x, double y) {
/* 3920 */     return ((Number)x).doubleValue() == y;
/*      */   }
/*      */   
/*      */   public static boolean equiv(double x, long y) {
/* 3924 */     return x == y;
/*      */   }
/*      */   
/*      */   public static boolean equiv(long x, double y) {
/* 3928 */     return x == y;
/*      */   }
/*      */   
/*      */   static boolean isNaN(Object x)
/*      */   {
/* 3933 */     return (((x instanceof Double)) && (((Double)x).isNaN())) || (((x instanceof Float)) && (((Float)x).isNaN()));
/*      */   }
/*      */   
/*      */   public static double max(double x, double y)
/*      */   {
/* 3938 */     return Math.max(x, y);
/*      */   }
/*      */   
/*      */   public static Object max(double x, long y) {
/* 3942 */     if (Double.isNaN(x)) {
/* 3943 */       return Double.valueOf(x);
/*      */     }
/* 3945 */     if (x > y) {
/* 3946 */       return Double.valueOf(x);
/*      */     }
/* 3948 */     return Long.valueOf(y);
/*      */   }
/*      */   
/*      */   public static Object max(double x, Object y)
/*      */   {
/* 3953 */     if (Double.isNaN(x))
/* 3954 */       return Double.valueOf(x);
/* 3955 */     if (isNaN(y)) {
/* 3956 */       return y;
/*      */     }
/* 3958 */     if (x > ((Number)y).doubleValue()) {
/* 3959 */       return Double.valueOf(x);
/*      */     }
/* 3961 */     return y;
/*      */   }
/*      */   
/*      */   public static Object max(long x, double y)
/*      */   {
/* 3966 */     if (Double.isNaN(y)) {
/* 3967 */       return Double.valueOf(y);
/*      */     }
/* 3969 */     if (x > y) {
/* 3970 */       return Long.valueOf(x);
/*      */     }
/* 3972 */     return Double.valueOf(y);
/*      */   }
/*      */   
/*      */ 
/*      */   public static long max(long x, long y)
/*      */   {
/* 3978 */     if (x > y) {
/* 3979 */       return x;
/*      */     }
/* 3981 */     return y;
/*      */   }
/*      */   
/*      */ 
/*      */   public static Object max(long x, Object y)
/*      */   {
/* 3987 */     if (isNaN(y)) {
/* 3988 */       return y;
/*      */     }
/* 3990 */     if (gt(x, y)) {
/* 3991 */       return Long.valueOf(x);
/*      */     }
/* 3993 */     return y;
/*      */   }
/*      */   
/*      */   public static Object max(Object x, long y)
/*      */   {
/* 3998 */     if (isNaN(x)) {
/* 3999 */       return x;
/*      */     }
/* 4001 */     if (gt(x, y)) {
/* 4002 */       return x;
/*      */     }
/* 4004 */     return Long.valueOf(y);
/*      */   }
/*      */   
/*      */   public static Object max(Object x, double y)
/*      */   {
/* 4009 */     if (isNaN(x))
/* 4010 */       return x;
/* 4011 */     if (Double.isNaN(y)) {
/* 4012 */       return Double.valueOf(y);
/*      */     }
/* 4014 */     if (((Number)x).doubleValue() > y) {
/* 4015 */       return x;
/*      */     }
/* 4017 */     return Double.valueOf(y);
/*      */   }
/*      */   
/*      */   public static Object max(Object x, Object y)
/*      */   {
/* 4022 */     if (isNaN(x))
/* 4023 */       return x;
/* 4024 */     if (isNaN(y)) {
/* 4025 */       return y;
/*      */     }
/* 4027 */     if (gt(x, y)) {
/* 4028 */       return x;
/*      */     }
/* 4030 */     return y;
/*      */   }
/*      */   
/*      */ 
/*      */   public static double min(double x, double y)
/*      */   {
/* 4036 */     return Math.min(x, y);
/*      */   }
/*      */   
/*      */   public static Object min(double x, long y) {
/* 4040 */     if (Double.isNaN(x)) {
/* 4041 */       return Double.valueOf(x);
/*      */     }
/* 4043 */     if (x < y) {
/* 4044 */       return Double.valueOf(x);
/*      */     }
/* 4046 */     return Long.valueOf(y);
/*      */   }
/*      */   
/*      */   public static Object min(double x, Object y)
/*      */   {
/* 4051 */     if (Double.isNaN(x))
/* 4052 */       return Double.valueOf(x);
/* 4053 */     if (isNaN(y)) {
/* 4054 */       return y;
/*      */     }
/* 4056 */     if (x < ((Number)y).doubleValue()) {
/* 4057 */       return Double.valueOf(x);
/*      */     }
/* 4059 */     return y;
/*      */   }
/*      */   
/*      */   public static Object min(long x, double y)
/*      */   {
/* 4064 */     if (Double.isNaN(y)) {
/* 4065 */       return Double.valueOf(y);
/*      */     }
/* 4067 */     if (x < y) {
/* 4068 */       return Long.valueOf(x);
/*      */     }
/* 4070 */     return Double.valueOf(y);
/*      */   }
/*      */   
/*      */ 
/*      */   public static long min(long x, long y)
/*      */   {
/* 4076 */     if (x < y) {
/* 4077 */       return x;
/*      */     }
/* 4079 */     return y;
/*      */   }
/*      */   
/*      */   public static Object min(long x, Object y)
/*      */   {
/* 4084 */     if (isNaN(y)) {
/* 4085 */       return y;
/*      */     }
/* 4087 */     if (lt(x, y)) {
/* 4088 */       return Long.valueOf(x);
/*      */     }
/* 4090 */     return y;
/*      */   }
/*      */   
/*      */   public static Object min(Object x, long y)
/*      */   {
/* 4095 */     if (isNaN(x)) {
/* 4096 */       return x;
/*      */     }
/* 4098 */     if (lt(x, y)) {
/* 4099 */       return x;
/*      */     }
/* 4101 */     return Long.valueOf(y);
/*      */   }
/*      */   
/*      */   public static Object min(Object x, double y)
/*      */   {
/* 4106 */     if (isNaN(x))
/* 4107 */       return x;
/* 4108 */     if (Double.isNaN(y)) {
/* 4109 */       return Double.valueOf(y);
/*      */     }
/* 4111 */     if (((Number)x).doubleValue() < y) {
/* 4112 */       return x;
/*      */     }
/* 4114 */     return Double.valueOf(y);
/*      */   }
/*      */   
/*      */   public static Object min(Object x, Object y)
/*      */   {
/* 4119 */     if (isNaN(x))
/* 4120 */       return x;
/* 4121 */     if (isNaN(y)) {
/* 4122 */       return y;
/*      */     }
/* 4124 */     if (lt(x, y)) {
/* 4125 */       return x;
/*      */     }
/* 4127 */     return y;
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\Numbers.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */