/*     */ package clojure.lang;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.RandomAccess;
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class APersistentVector
/*     */   extends AFn
/*     */   implements IPersistentVector, Iterable, List, RandomAccess, Comparable, Serializable, IHashEq
/*     */ {
/*     */   int _hash;
/*     */   int _hasheq;
/*     */   
/*     */   public APersistentVector()
/*     */   {
/*  22 */     this._hash = -1;
/*  23 */     this._hasheq = -1;
/*     */   }
/*     */   
/*  26 */   public String toString() { return RT.printString(this); }
/*     */   
/*     */   public ISeq seq()
/*     */   {
/*  30 */     if (count() > 0)
/*  31 */       return new Seq(this, 0);
/*  32 */     return null;
/*     */   }
/*     */   
/*     */   public ISeq rseq() {
/*  36 */     if (count() > 0)
/*  37 */       return new RSeq(this, count() - 1);
/*  38 */     return null;
/*     */   }
/*     */   
/*     */   static boolean doEquals(IPersistentVector v, Object obj) {
/*  42 */     if ((obj instanceof IPersistentVector))
/*     */     {
/*  44 */       IPersistentVector ov = (IPersistentVector)obj;
/*  45 */       if (ov.count() != v.count())
/*  46 */         return false;
/*  47 */       for (int i = 0; i < v.count(); i++)
/*     */       {
/*  49 */         if (!Util.equals(v.nth(i), ov.nth(i)))
/*  50 */           return false;
/*     */       }
/*  52 */       return true;
/*     */     }
/*  54 */     if ((obj instanceof List))
/*     */     {
/*  56 */       Collection ma = (Collection)obj;
/*  57 */       if ((ma.size() != v.count()) || (ma.hashCode() != v.hashCode()))
/*  58 */         return false;
/*  59 */       Iterator i1 = ((List)v).iterator();Iterator i2 = ma.iterator();
/*  60 */       while (i1.hasNext())
/*     */       {
/*  62 */         if (!Util.equals(i1.next(), i2.next()))
/*  63 */           return false;
/*     */       }
/*  65 */       return true;
/*     */     }
/*     */     
/*     */ 
/*  69 */     if (!(obj instanceof Sequential))
/*  70 */       return false;
/*  71 */     ISeq ms = RT.seq(obj);
/*  72 */     for (int i = 0; i < v.count(); ms = ms.next())
/*     */     {
/*  74 */       if ((ms == null) || (!Util.equals(v.nth(i), ms.first()))) {
/*  75 */         return false;
/*     */       }
/*  72 */       i++;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  77 */     if (ms != null) {
/*  78 */       return false;
/*     */     }
/*     */     
/*  81 */     return true;
/*     */   }
/*     */   
/*     */   static boolean doEquiv(IPersistentVector v, Object obj)
/*     */   {
/*  86 */     if ((obj instanceof IPersistentVector))
/*     */     {
/*  88 */       IPersistentVector ov = (IPersistentVector)obj;
/*  89 */       if (ov.count() != v.count())
/*  90 */         return false;
/*  91 */       for (int i = 0; i < v.count(); i++)
/*     */       {
/*  93 */         if (!Util.equiv(v.nth(i), ov.nth(i)))
/*  94 */           return false;
/*     */       }
/*  96 */       return true;
/*     */     }
/*  98 */     if ((obj instanceof List))
/*     */     {
/* 100 */       Collection ma = (Collection)obj;
/* 101 */       if (ma.size() != v.count())
/* 102 */         return false;
/* 103 */       Iterator i1 = ((List)v).iterator();Iterator i2 = ma.iterator();
/* 104 */       while (i1.hasNext())
/*     */       {
/* 106 */         if (!Util.equiv(i1.next(), i2.next()))
/* 107 */           return false;
/*     */       }
/* 109 */       return true;
/*     */     }
/*     */     
/*     */ 
/* 113 */     if (!(obj instanceof Sequential))
/* 114 */       return false;
/* 115 */     ISeq ms = RT.seq(obj);
/* 116 */     for (int i = 0; i < v.count(); ms = ms.next())
/*     */     {
/* 118 */       if ((ms == null) || (!Util.equiv(v.nth(i), ms.first()))) {
/* 119 */         return false;
/*     */       }
/* 116 */       i++;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 121 */     if (ms != null) {
/* 122 */       return false;
/*     */     }
/*     */     
/* 125 */     return true;
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/* 130 */     if (obj == this)
/* 131 */       return true;
/* 132 */     return doEquals(this, obj);
/*     */   }
/*     */   
/*     */   public boolean equiv(Object obj) {
/* 136 */     if (obj == this)
/* 137 */       return true;
/* 138 */     return doEquiv(this, obj);
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 142 */     if (this._hash == -1)
/*     */     {
/* 144 */       int hash = 1;
/* 145 */       for (int i = 0; i < count(); i++)
/*     */       {
/* 147 */         Object obj = nth(i);
/* 148 */         hash = 31 * hash + (obj == null ? 0 : obj.hashCode());
/*     */       }
/* 150 */       this._hash = hash;
/*     */     }
/* 152 */     return this._hash;
/*     */   }
/*     */   
/*     */   public int hasheq() {
/* 156 */     if (this._hasheq == -1)
/*     */     {
/* 158 */       int hash = 1;
/*     */       
/* 160 */       for (int n = 0; n < count(); n++)
/*     */       {
/* 162 */         hash = 31 * hash + Util.hasheq(nth(n));
/*     */       }
/*     */       
/* 165 */       this._hasheq = Murmur3.mixCollHash(hash, n);
/*     */     }
/* 167 */     return this._hasheq;
/*     */   }
/*     */   
/*     */   public Object get(int index) {
/* 171 */     return nth(index);
/*     */   }
/*     */   
/*     */   public Object nth(int i, Object notFound) {
/* 175 */     if ((i >= 0) && (i < count()))
/* 176 */       return nth(i);
/* 177 */     return notFound;
/*     */   }
/*     */   
/*     */   public Object remove(int i) {
/* 181 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public int indexOf(Object o) {
/* 185 */     for (int i = 0; i < count(); i++)
/* 186 */       if (Util.equiv(nth(i), o))
/* 187 */         return i;
/* 188 */     return -1;
/*     */   }
/*     */   
/*     */   public int lastIndexOf(Object o) {
/* 192 */     for (int i = count() - 1; i >= 0; i--)
/* 193 */       if (Util.equiv(nth(i), o))
/* 194 */         return i;
/* 195 */     return -1;
/*     */   }
/*     */   
/*     */   public ListIterator listIterator() {
/* 199 */     return listIterator(0);
/*     */   }
/*     */   
/*     */   public ListIterator listIterator(final int index) {
/* 203 */     new ListIterator() {
/* 204 */       int nexti = index;
/*     */       
/*     */       public boolean hasNext() {
/* 207 */         return this.nexti < APersistentVector.this.count();
/*     */       }
/*     */       
/*     */       public Object next() {
/* 211 */         if (this.nexti < APersistentVector.this.count()) {
/* 212 */           return APersistentVector.this.nth(this.nexti++);
/*     */         }
/* 214 */         throw new NoSuchElementException();
/*     */       }
/*     */       
/*     */       public boolean hasPrevious() {
/* 218 */         return this.nexti > 0;
/*     */       }
/*     */       
/*     */       public Object previous() {
/* 222 */         if (this.nexti > 0) {
/* 223 */           return APersistentVector.this.nth(--this.nexti);
/*     */         }
/* 225 */         throw new NoSuchElementException();
/*     */       }
/*     */       
/*     */       public int nextIndex() {
/* 229 */         return this.nexti;
/*     */       }
/*     */       
/*     */       public int previousIndex() {
/* 233 */         return this.nexti - 1;
/*     */       }
/*     */       
/*     */       public void remove() {
/* 237 */         throw new UnsupportedOperationException();
/*     */       }
/*     */       
/*     */       public void set(Object o) {
/* 241 */         throw new UnsupportedOperationException();
/*     */       }
/*     */       
/*     */       public void add(Object o) {
/* 245 */         throw new UnsupportedOperationException();
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */   Iterator rangedIterator(final int start, final int end) {
/* 251 */     new Iterator() {
/* 252 */       int i = start;
/*     */       
/*     */       public boolean hasNext() {
/* 255 */         return this.i < end;
/*     */       }
/*     */       
/*     */       public Object next() {
/* 259 */         if (this.i < end) {
/* 260 */           return APersistentVector.this.nth(this.i++);
/*     */         }
/* 262 */         throw new NoSuchElementException();
/*     */       }
/*     */       
/*     */       public void remove() {
/* 266 */         throw new UnsupportedOperationException();
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */   public List subList(int fromIndex, int toIndex) {
/* 272 */     return (List)RT.subvec(this, fromIndex, toIndex);
/*     */   }
/*     */   
/*     */   public Object set(int i, Object o)
/*     */   {
/* 277 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void add(int i, Object o) {
/* 281 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public boolean addAll(int i, Collection c) {
/* 285 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public Object invoke(Object arg1)
/*     */   {
/* 290 */     if (Util.isInteger(arg1))
/* 291 */       return nth(((Number)arg1).intValue());
/* 292 */     throw new IllegalArgumentException("Key must be integer");
/*     */   }
/*     */   
/*     */   public Iterator iterator()
/*     */   {
/* 297 */     new Iterator() {
/* 298 */       int i = 0;
/*     */       
/*     */       public boolean hasNext() {
/* 301 */         return this.i < APersistentVector.this.count();
/*     */       }
/*     */       
/*     */       public Object next() {
/* 305 */         if (this.i < APersistentVector.this.count())
/* 306 */           return APersistentVector.this.nth(this.i++);
/* 307 */         throw new NoSuchElementException();
/*     */       }
/*     */       
/*     */       public void remove() {
/* 311 */         throw new UnsupportedOperationException();
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */   public Object peek() {
/* 317 */     if (count() > 0)
/* 318 */       return nth(count() - 1);
/* 319 */     return null;
/*     */   }
/*     */   
/*     */   public boolean containsKey(Object key) {
/* 323 */     if (!Util.isInteger(key))
/* 324 */       return false;
/* 325 */     int i = ((Number)key).intValue();
/* 326 */     return (i >= 0) && (i < count());
/*     */   }
/*     */   
/*     */   public IMapEntry entryAt(Object key) {
/* 330 */     if (Util.isInteger(key))
/*     */     {
/* 332 */       int i = ((Number)key).intValue();
/* 333 */       if ((i >= 0) && (i < count()))
/* 334 */         return MapEntry.create(key, nth(i));
/*     */     }
/* 336 */     return null;
/*     */   }
/*     */   
/*     */   public IPersistentVector assoc(Object key, Object val) {
/* 340 */     if (Util.isInteger(key))
/*     */     {
/* 342 */       int i = ((Number)key).intValue();
/* 343 */       return assocN(i, val);
/*     */     }
/* 345 */     throw new IllegalArgumentException("Key must be integer");
/*     */   }
/*     */   
/*     */   public Object valAt(Object key, Object notFound) {
/* 349 */     if (Util.isInteger(key))
/*     */     {
/* 351 */       int i = ((Number)key).intValue();
/* 352 */       if ((i >= 0) && (i < count()))
/* 353 */         return nth(i);
/*     */     }
/* 355 */     return notFound;
/*     */   }
/*     */   
/*     */   public Object valAt(Object key) {
/* 359 */     return valAt(key, null);
/*     */   }
/*     */   
/*     */ 
/*     */   public Object[] toArray()
/*     */   {
/* 365 */     Object[] ret = new Object[count()];
/* 366 */     for (int i = 0; i < count(); i++)
/* 367 */       ret[i] = nth(i);
/* 368 */     return ret;
/*     */   }
/*     */   
/*     */   public boolean add(Object o) {
/* 372 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public boolean remove(Object o) {
/* 376 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public boolean addAll(Collection c) {
/* 380 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void clear() {
/* 384 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public boolean retainAll(Collection c) {
/* 388 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public boolean removeAll(Collection c) {
/* 392 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public boolean containsAll(Collection c) {
/* 396 */     for (Object o : c)
/*     */     {
/* 398 */       if (!contains(o))
/* 399 */         return false;
/*     */     }
/* 401 */     return true;
/*     */   }
/*     */   
/*     */   public Object[] toArray(Object[] a) {
/* 405 */     return RT.seqToPassedArray(seq(), a);
/*     */   }
/*     */   
/*     */   public int size() {
/* 409 */     return count();
/*     */   }
/*     */   
/*     */   public boolean isEmpty() {
/* 413 */     return count() == 0;
/*     */   }
/*     */   
/*     */   public boolean contains(Object o) {
/* 417 */     for (ISeq s = seq(); s != null; s = s.next())
/*     */     {
/* 419 */       if (Util.equiv(s.first(), o))
/* 420 */         return true;
/*     */     }
/* 422 */     return false;
/*     */   }
/*     */   
/*     */   public int length() {
/* 426 */     return count();
/*     */   }
/*     */   
/*     */   public int compareTo(Object o) {
/* 430 */     IPersistentVector v = (IPersistentVector)o;
/* 431 */     if (count() < v.count())
/* 432 */       return -1;
/* 433 */     if (count() > v.count())
/* 434 */       return 1;
/* 435 */     for (int i = 0; i < count(); i++)
/*     */     {
/* 437 */       int c = Util.compare(nth(i), v.nth(i));
/* 438 */       if (c != 0)
/* 439 */         return c;
/*     */     }
/* 441 */     return 0;
/*     */   }
/*     */   
/*     */   static class Seq extends ASeq implements IndexedSeq, IReduce
/*     */   {
/*     */     final IPersistentVector v;
/*     */     final int i;
/*     */     
/*     */     public Seq(IPersistentVector v, int i)
/*     */     {
/* 451 */       this.v = v;
/* 452 */       this.i = i;
/*     */     }
/*     */     
/*     */     Seq(IPersistentMap meta, IPersistentVector v, int i) {
/* 456 */       super();
/* 457 */       this.v = v;
/* 458 */       this.i = i;
/*     */     }
/*     */     
/*     */     public Object first() {
/* 462 */       return this.v.nth(this.i);
/*     */     }
/*     */     
/*     */     public ISeq next() {
/* 466 */       if (this.i + 1 < this.v.count())
/* 467 */         return new Seq(this.v, this.i + 1);
/* 468 */       return null;
/*     */     }
/*     */     
/*     */     public int index() {
/* 472 */       return this.i;
/*     */     }
/*     */     
/*     */     public int count() {
/* 476 */       return this.v.count() - this.i;
/*     */     }
/*     */     
/*     */     public Seq withMeta(IPersistentMap meta) {
/* 480 */       return new Seq(meta, this.v, this.i);
/*     */     }
/*     */     
/*     */     public Object reduce(IFn f) {
/* 484 */       Object ret = this.v.nth(this.i);
/* 485 */       for (int x = this.i + 1; x < this.v.count(); x++) {
/* 486 */         ret = f.invoke(ret, this.v.nth(x));
/* 487 */         if (RT.isReduced(ret)) return ((IDeref)ret).deref();
/*     */       }
/* 489 */       return ret;
/*     */     }
/*     */     
/*     */     public Object reduce(IFn f, Object start) {
/* 493 */       Object ret = f.invoke(start, this.v.nth(this.i));
/* 494 */       for (int x = this.i + 1; x < this.v.count(); x++) {
/* 495 */         if (RT.isReduced(ret)) return ((IDeref)ret).deref();
/* 496 */         ret = f.invoke(ret, this.v.nth(x));
/*     */       }
/* 498 */       if (RT.isReduced(ret)) return ((IDeref)ret).deref();
/* 499 */       return ret;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class RSeq extends ASeq implements IndexedSeq, Counted {
/*     */     final IPersistentVector v;
/*     */     final int i;
/*     */     
/*     */     public RSeq(IPersistentVector vector, int i) {
/* 508 */       this.v = vector;
/* 509 */       this.i = i;
/*     */     }
/*     */     
/*     */     RSeq(IPersistentMap meta, IPersistentVector v, int i) {
/* 513 */       super();
/* 514 */       this.v = v;
/* 515 */       this.i = i;
/*     */     }
/*     */     
/*     */     public Object first() {
/* 519 */       return this.v.nth(this.i);
/*     */     }
/*     */     
/*     */     public ISeq next() {
/* 523 */       if (this.i > 0)
/* 524 */         return new RSeq(this.v, this.i - 1);
/* 525 */       return null;
/*     */     }
/*     */     
/*     */     public int index() {
/* 529 */       return this.i;
/*     */     }
/*     */     
/*     */     public int count() {
/* 533 */       return this.i + 1;
/*     */     }
/*     */     
/*     */     public RSeq withMeta(IPersistentMap meta) {
/* 537 */       return new RSeq(meta, this.v, this.i);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class SubVector extends APersistentVector implements IObj
/*     */   {
/*     */     public final IPersistentVector v;
/*     */     public final int start;
/*     */     public final int end;
/*     */     final IPersistentMap _meta;
/*     */     
/*     */     public SubVector(IPersistentMap meta, IPersistentVector v, int start, int end)
/*     */     {
/* 550 */       this._meta = meta;
/*     */       
/* 552 */       if ((v instanceof SubVector))
/*     */       {
/* 554 */         SubVector sv = (SubVector)v;
/* 555 */         start += sv.start;
/* 556 */         end += sv.start;
/* 557 */         v = sv.v;
/*     */       }
/* 559 */       this.v = v;
/* 560 */       this.start = start;
/* 561 */       this.end = end;
/*     */     }
/*     */     
/*     */     public Iterator iterator() {
/* 565 */       if ((this.v instanceof APersistentVector)) {
/* 566 */         return ((APersistentVector)this.v).rangedIterator(this.start, this.end);
/*     */       }
/* 568 */       return super.iterator();
/*     */     }
/*     */     
/*     */     public Object nth(int i) {
/* 572 */       if ((this.start + i >= this.end) || (i < 0))
/* 573 */         throw new IndexOutOfBoundsException();
/* 574 */       return this.v.nth(this.start + i);
/*     */     }
/*     */     
/*     */     public IPersistentVector assocN(int i, Object val) {
/* 578 */       if (this.start + i > this.end)
/* 579 */         throw new IndexOutOfBoundsException();
/* 580 */       if (this.start + i == this.end)
/* 581 */         return cons(val);
/* 582 */       return new SubVector(this._meta, this.v.assocN(this.start + i, val), this.start, this.end);
/*     */     }
/*     */     
/*     */     public int count() {
/* 586 */       return this.end - this.start;
/*     */     }
/*     */     
/*     */     public IPersistentVector cons(Object o) {
/* 590 */       return new SubVector(this._meta, this.v.assocN(this.end, o), this.start, this.end + 1);
/*     */     }
/*     */     
/*     */     public IPersistentCollection empty() {
/* 594 */       return PersistentVector.EMPTY.withMeta(meta());
/*     */     }
/*     */     
/*     */     public IPersistentStack pop() {
/* 598 */       if (this.end - 1 == this.start)
/*     */       {
/* 600 */         return PersistentVector.EMPTY;
/*     */       }
/* 602 */       return new SubVector(this._meta, this.v, this.start, this.end - 1);
/*     */     }
/*     */     
/*     */     public SubVector withMeta(IPersistentMap meta) {
/* 606 */       if (meta == this._meta)
/* 607 */         return this;
/* 608 */       return new SubVector(meta, this.v, this.start, this.end);
/*     */     }
/*     */     
/*     */     public IPersistentMap meta() {
/* 612 */       return this._meta;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\APersistentVector.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */