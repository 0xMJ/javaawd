/*     */ package clojure.lang;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AFn
/*     */   implements IFn
/*     */ {
/*     */   public Object call()
/*     */   {
/*  18 */     return invoke();
/*     */   }
/*     */   
/*     */   public void run() {
/*  22 */     invoke();
/*     */   }
/*     */   
/*     */ 
/*     */   public Object invoke()
/*     */   {
/*  28 */     return throwArity(0);
/*     */   }
/*     */   
/*     */   public Object invoke(Object arg1) {
/*  32 */     return throwArity(1);
/*     */   }
/*     */   
/*     */   public Object invoke(Object arg1, Object arg2) {
/*  36 */     return throwArity(2);
/*     */   }
/*     */   
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3) {
/*  40 */     return throwArity(3);
/*     */   }
/*     */   
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4) {
/*  44 */     return throwArity(4);
/*     */   }
/*     */   
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5) {
/*  48 */     return throwArity(5);
/*     */   }
/*     */   
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6) {
/*  52 */     return throwArity(6);
/*     */   }
/*     */   
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7)
/*     */   {
/*  57 */     return throwArity(7);
/*     */   }
/*     */   
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8)
/*     */   {
/*  62 */     return throwArity(8);
/*     */   }
/*     */   
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9)
/*     */   {
/*  67 */     return throwArity(9);
/*     */   }
/*     */   
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10)
/*     */   {
/*  72 */     return throwArity(10);
/*     */   }
/*     */   
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11)
/*     */   {
/*  77 */     return throwArity(11);
/*     */   }
/*     */   
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12)
/*     */   {
/*  82 */     return throwArity(12);
/*     */   }
/*     */   
/*     */ 
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12, Object arg13)
/*     */   {
/*  88 */     return throwArity(13);
/*     */   }
/*     */   
/*     */ 
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12, Object arg13, Object arg14)
/*     */   {
/*  94 */     return throwArity(14);
/*     */   }
/*     */   
/*     */ 
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12, Object arg13, Object arg14, Object arg15)
/*     */   {
/* 100 */     return throwArity(15);
/*     */   }
/*     */   
/*     */ 
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12, Object arg13, Object arg14, Object arg15, Object arg16)
/*     */   {
/* 106 */     return throwArity(16);
/*     */   }
/*     */   
/*     */ 
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12, Object arg13, Object arg14, Object arg15, Object arg16, Object arg17)
/*     */   {
/* 112 */     return throwArity(17);
/*     */   }
/*     */   
/*     */ 
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12, Object arg13, Object arg14, Object arg15, Object arg16, Object arg17, Object arg18)
/*     */   {
/* 118 */     return throwArity(18);
/*     */   }
/*     */   
/*     */ 
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12, Object arg13, Object arg14, Object arg15, Object arg16, Object arg17, Object arg18, Object arg19)
/*     */   {
/* 124 */     return throwArity(19);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12, Object arg13, Object arg14, Object arg15, Object arg16, Object arg17, Object arg18, Object arg19, Object arg20)
/*     */   {
/* 131 */     return throwArity(20);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12, Object arg13, Object arg14, Object arg15, Object arg16, Object arg17, Object arg18, Object arg19, Object arg20, Object... args)
/*     */   {
/* 140 */     return throwArity(21);
/*     */   }
/*     */   
/*     */   public Object applyTo(ISeq arglist) {
/* 144 */     return applyToHelper(this, Util.ret1(arglist, arglist = null));
/*     */   }
/*     */   
/*     */   public static Object applyToHelper(IFn ifn, ISeq arglist) {
/* 148 */     switch (RT.boundedLength(arglist, 20))
/*     */     {
/*     */     case 0: 
/* 151 */       arglist = null;
/* 152 */       return ifn.invoke();
/*     */     case 1: 
/* 154 */       return ifn.invoke(Util.ret1(arglist.first(), arglist = null));
/*     */     case 2: 
/* 156 */       return ifn.invoke(arglist.first(), Util.ret1((arglist = arglist.next()).first(), arglist = null));
/*     */     
/*     */ 
/*     */     case 3: 
/* 160 */       return ifn.invoke(arglist.first(), (arglist = arglist.next()).first(), Util.ret1((arglist = arglist.next()).first(), arglist = null));
/*     */     
/*     */ 
/*     */ 
/*     */     case 4: 
/* 165 */       return ifn.invoke(arglist.first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), Util.ret1((arglist = arglist.next()).first(), arglist = null));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     case 5: 
/* 171 */       return ifn.invoke(arglist.first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), Util.ret1((arglist = arglist.next()).first(), arglist = null));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     case 6: 
/* 178 */       return ifn.invoke(arglist.first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), Util.ret1((arglist = arglist.next()).first(), arglist = null));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     case 7: 
/* 186 */       return ifn.invoke(arglist.first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), Util.ret1((arglist = arglist.next()).first(), arglist = null));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     case 8: 
/* 195 */       return ifn.invoke(arglist.first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), Util.ret1((arglist = arglist.next()).first(), arglist = null));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     case 9: 
/* 205 */       return ifn.invoke(arglist.first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), Util.ret1((arglist = arglist.next()).first(), arglist = null));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     case 10: 
/* 216 */       return ifn.invoke(arglist.first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), Util.ret1((arglist = arglist.next()).first(), arglist = null));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     case 11: 
/* 228 */       return ifn.invoke(arglist.first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), Util.ret1((arglist = arglist.next()).first(), arglist = null));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     case 12: 
/* 241 */       return ifn.invoke(arglist.first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), Util.ret1((arglist = arglist.next()).first(), arglist = null));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     case 13: 
/* 255 */       return ifn.invoke(arglist.first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), Util.ret1((arglist = arglist.next()).first(), arglist = null));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     case 14: 
/* 270 */       return ifn.invoke(arglist.first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), Util.ret1((arglist = arglist.next()).first(), arglist = null));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     case 15: 
/* 286 */       return ifn.invoke(arglist.first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), Util.ret1((arglist = arglist.next()).first(), arglist = null));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     case 16: 
/* 303 */       return ifn.invoke(arglist.first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), Util.ret1((arglist = arglist.next()).first(), arglist = null));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     case 17: 
/* 321 */       return ifn.invoke(arglist.first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), Util.ret1((arglist = arglist.next()).first(), arglist = null));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     case 18: 
/* 340 */       return ifn.invoke(arglist.first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), Util.ret1((arglist = arglist.next()).first(), arglist = null));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     case 19: 
/* 360 */       return ifn.invoke(arglist.first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), Util.ret1((arglist = arglist.next()).first(), arglist = null));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     case 20: 
/* 381 */       return ifn.invoke(arglist.first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), Util.ret1((arglist = arglist.next()).first(), arglist = null));
/*     */     }
/*     */     
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 403 */     return ifn.invoke(arglist.first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), (arglist = arglist.next()).first(), RT.seqToArray(Util.ret1(arglist.next(), arglist = null)));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object throwArity(int n)
/*     */   {
/* 428 */     String name = getClass().getSimpleName();
/* 429 */     throw new ArityException(n, Compiler.demunge(name));
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\AFn.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */