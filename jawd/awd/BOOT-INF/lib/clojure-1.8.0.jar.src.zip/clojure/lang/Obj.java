/*    */ package clojure.lang;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Obj
/*    */   implements IObj, Serializable
/*    */ {
/*    */   final IPersistentMap _meta;
/*    */   
/*    */   public Obj(IPersistentMap meta)
/*    */   {
/* 22 */     this._meta = meta;
/*    */   }
/*    */   
/*    */   public Obj() {
/* 26 */     this._meta = null;
/*    */   }
/*    */   
/*    */   public final IPersistentMap meta() {
/* 30 */     return this._meta;
/*    */   }
/*    */   
/*    */   public abstract Obj withMeta(IPersistentMap paramIPersistentMap);
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\Obj.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */