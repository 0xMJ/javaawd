/*     */ package clojure.lang;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.PushbackReader;
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EdnReader
/*     */ {
/*  25 */   static IFn[] macros = new IFn['Ā'];
/*  26 */   static IFn[] dispatchMacros = new IFn['Ā'];
/*  27 */   static Pattern symbolPat = Pattern.compile("[:]?([\\D&&[^/]].*/)?(/|[\\D&&[^/]][^/]*)");
/*  28 */   static Pattern intPat = Pattern.compile("([-+]?)(?:(0)|([1-9][0-9]*)|0[xX]([0-9A-Fa-f]+)|0([0-7]+)|([1-9][0-9]?)[rR]([0-9A-Za-z]+)|0[0-9]+)(N)?");
/*     */   
/*     */ 
/*  31 */   static Pattern ratioPat = Pattern.compile("([-+]?[0-9]+)/([0-9]+)");
/*  32 */   static Pattern floatPat = Pattern.compile("([-+]?[0-9]+(\\.[0-9]*)?([eE][-+]?[0-9]+)?)(M)?");
/*     */   
/*  34 */   static IFn taggedReader = new TaggedReader();
/*     */   
/*     */   static
/*     */   {
/*  38 */     macros[34] = new StringReader();
/*  39 */     macros[59] = new CommentReader();
/*  40 */     macros[94] = new MetaReader();
/*  41 */     macros[40] = new ListReader();
/*  42 */     macros[41] = new UnmatchedDelimiterReader();
/*  43 */     macros[91] = new VectorReader();
/*  44 */     macros[93] = new UnmatchedDelimiterReader();
/*  45 */     macros[123] = new MapReader();
/*  46 */     macros[125] = new UnmatchedDelimiterReader();
/*  47 */     macros[92] = new CharacterReader();
/*  48 */     macros[35] = new DispatchReader();
/*     */     
/*     */ 
/*  51 */     dispatchMacros[94] = new MetaReader();
/*     */     
/*  53 */     dispatchMacros[123] = new SetReader();
/*  54 */     dispatchMacros[60] = new UnreadableReader();
/*  55 */     dispatchMacros[95] = new DiscardReader();
/*     */   }
/*     */   
/*     */   static boolean nonConstituent(int ch) {
/*  59 */     return (ch == 64) || (ch == 96) || (ch == 126);
/*     */   }
/*     */   
/*     */   public static Object readString(String s, IPersistentMap opts) {
/*  63 */     PushbackReader r = new PushbackReader(new StringReader(s));
/*  64 */     return read(r, opts);
/*     */   }
/*     */   
/*     */   static boolean isWhitespace(int ch) {
/*  68 */     return (Character.isWhitespace(ch)) || (ch == 44);
/*     */   }
/*     */   
/*     */   static void unread(PushbackReader r, int ch) {
/*  72 */     if (ch != -1)
/*     */       try
/*     */       {
/*  75 */         r.unread(ch);
/*     */       }
/*     */       catch (IOException e)
/*     */       {
/*  79 */         throw Util.sneakyThrow(e);
/*     */       }
/*     */   }
/*     */   
/*     */   public static class ReaderException extends RuntimeException {
/*     */     final int line;
/*     */     final int column;
/*     */     
/*     */     public ReaderException(int line, int column, Throwable cause) {
/*  88 */       super();
/*  89 */       this.line = line;
/*  90 */       this.column = column;
/*     */     }
/*     */   }
/*     */   
/*     */   public static int read1(Reader r)
/*     */   {
/*     */     try {
/*  97 */       return r.read();
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 101 */       throw Util.sneakyThrow(e);
/*     */     }
/*     */   }
/*     */   
/* 105 */   static final Keyword EOF = Keyword.intern(null, "eof");
/*     */   
/*     */   public static Object read(PushbackReader r, IPersistentMap opts) {
/* 108 */     return read(r, !opts.containsKey(EOF), opts.valAt(EOF), false, opts);
/*     */   }
/*     */   
/*     */   public static Object read(PushbackReader r, boolean eofIsError, Object eofValue, boolean isRecursive, Object opts)
/*     */   {
/*     */     try
/*     */     {
/*     */       int ch;
/*     */       Object ret;
/*     */       do
/*     */       {
/* 119 */         ch = read1(r);
/*     */         
/* 121 */         while (isWhitespace(ch)) {
/* 122 */           ch = read1(r);
/*     */         }
/* 124 */         if (ch == -1)
/*     */         {
/* 126 */           if (eofIsError)
/* 127 */             throw Util.runtimeException("EOF while reading");
/* 128 */           return eofValue;
/*     */         }
/*     */         
/* 131 */         if (Character.isDigit(ch))
/*     */         {
/* 133 */           Object n = readNumber(r, (char)ch);
/* 134 */           if (RT.suppressRead())
/* 135 */             return null;
/* 136 */           return n;
/*     */         }
/*     */         
/* 139 */         IFn macroFn = getMacro(ch);
/* 140 */         if (macroFn == null)
/*     */           break;
/* 142 */         ret = macroFn.invoke(r, Character.valueOf((char)ch), opts);
/* 143 */         if (RT.suppressRead()) {
/* 144 */           return null;
/*     */         }
/* 146 */       } while (ret == r);
/*     */       
/* 148 */       return ret;
/*     */       
/*     */ 
/* 151 */       if ((ch == 43) || (ch == 45))
/*     */       {
/* 153 */         int ch2 = read1(r);
/* 154 */         if (Character.isDigit(ch2))
/*     */         {
/* 156 */           unread(r, ch2);
/* 157 */           Object n = readNumber(r, (char)ch);
/* 158 */           if (RT.suppressRead())
/* 159 */             return null;
/* 160 */           return n;
/*     */         }
/* 162 */         unread(r, ch2);
/*     */       }
/*     */       
/* 165 */       String token = readToken(r, (char)ch, true);
/* 166 */       if (RT.suppressRead())
/* 167 */         return null;
/* 168 */       return interpretToken(token);
/*     */ 
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 173 */       if ((isRecursive) || (!(r instanceof LineNumberingPushbackReader)))
/* 174 */         throw Util.sneakyThrow(e);
/* 175 */       LineNumberingPushbackReader rdr = (LineNumberingPushbackReader)r;
/*     */       
/* 177 */       throw new ReaderException(rdr.getLineNumber(), rdr.getColumnNumber(), e);
/*     */     }
/*     */   }
/*     */   
/*     */   private static String readToken(PushbackReader r, char initch, boolean leadConstituent) {
/* 182 */     StringBuilder sb = new StringBuilder();
/* 183 */     if ((leadConstituent) && (nonConstituent(initch))) {
/* 184 */       throw Util.runtimeException("Invalid leading character: " + initch);
/*     */     }
/* 186 */     sb.append(initch);
/*     */     
/*     */     for (;;)
/*     */     {
/* 190 */       int ch = read1(r);
/*     */       
/* 192 */       if ((ch == -1) || (isWhitespace(ch)) || (isTerminatingMacro(ch)))
/*     */       {
/* 194 */         unread(r, ch);
/* 195 */         return sb.toString();
/*     */       }
/* 197 */       if (nonConstituent(ch))
/* 198 */         throw Util.runtimeException("Invalid constituent character: " + (char)ch);
/* 199 */       sb.append((char)ch);
/*     */     }
/*     */   }
/*     */   
/*     */   private static Object readNumber(PushbackReader r, char initch) {
/* 204 */     StringBuilder sb = new StringBuilder();
/* 205 */     sb.append(initch);
/*     */     
/*     */     for (;;)
/*     */     {
/* 209 */       int ch = read1(r);
/* 210 */       if ((ch == -1) || (isWhitespace(ch)) || (isMacro(ch)))
/*     */       {
/* 212 */         unread(r, ch);
/* 213 */         break;
/*     */       }
/* 215 */       sb.append((char)ch);
/*     */     }
/*     */     
/* 218 */     String s = sb.toString();
/* 219 */     Object n = matchNumber(s);
/* 220 */     if (n == null)
/* 221 */       throw new NumberFormatException("Invalid number: " + s);
/* 222 */     return n;
/*     */   }
/*     */   
/*     */   private static int readUnicodeChar(String token, int offset, int length, int base) {
/* 226 */     if (token.length() != offset + length)
/* 227 */       throw new IllegalArgumentException("Invalid unicode character: \\" + token);
/* 228 */     int uc = 0;
/* 229 */     for (int i = offset; i < offset + length; i++)
/*     */     {
/* 231 */       int d = Character.digit(token.charAt(i), base);
/* 232 */       if (d == -1)
/* 233 */         throw new IllegalArgumentException("Invalid digit: " + token.charAt(i));
/* 234 */       uc = uc * base + d;
/*     */     }
/* 236 */     return (char)uc;
/*     */   }
/*     */   
/*     */   private static int readUnicodeChar(PushbackReader r, int initch, int base, int length, boolean exact) {
/* 240 */     int uc = Character.digit(initch, base);
/* 241 */     if (uc == -1)
/* 242 */       throw new IllegalArgumentException("Invalid digit: " + (char)initch);
/* 243 */     for (int i = 1; 
/* 244 */         i < length; i++)
/*     */     {
/* 246 */       int ch = read1(r);
/* 247 */       if ((ch == -1) || (isWhitespace(ch)) || (isMacro(ch)))
/*     */       {
/* 249 */         unread(r, ch);
/* 250 */         break;
/*     */       }
/* 252 */       int d = Character.digit(ch, base);
/* 253 */       if (d == -1)
/* 254 */         throw new IllegalArgumentException("Invalid digit: " + (char)ch);
/* 255 */       uc = uc * base + d;
/*     */     }
/* 257 */     if ((i != length) && (exact))
/* 258 */       throw new IllegalArgumentException("Invalid character length: " + i + ", should be: " + length);
/* 259 */     return uc;
/*     */   }
/*     */   
/*     */   private static Object interpretToken(String s) {
/* 263 */     if (s.equals("nil"))
/*     */     {
/* 265 */       return null;
/*     */     }
/* 267 */     if (s.equals("true"))
/*     */     {
/* 269 */       return RT.T;
/*     */     }
/* 271 */     if (s.equals("false"))
/*     */     {
/* 273 */       return RT.F;
/*     */     }
/*     */     
/* 276 */     Object ret = null;
/*     */     
/* 278 */     ret = matchSymbol(s);
/* 279 */     if (ret != null) {
/* 280 */       return ret;
/*     */     }
/* 282 */     throw Util.runtimeException("Invalid token: " + s);
/*     */   }
/*     */   
/*     */   private static Object matchSymbol(String s)
/*     */   {
/* 287 */     Matcher m = symbolPat.matcher(s);
/* 288 */     if (m.matches())
/*     */     {
/* 290 */       int gc = m.groupCount();
/* 291 */       String ns = m.group(1);
/* 292 */       String name = m.group(2);
/* 293 */       if (((ns != null) && (ns.endsWith(":/"))) || (name.endsWith(":")) || (s.indexOf("::", 1) != -1))
/*     */       {
/*     */ 
/* 296 */         return null; }
/* 297 */       if (s.startsWith("::"))
/*     */       {
/* 299 */         return null;
/*     */       }
/* 301 */       boolean isKeyword = s.charAt(0) == ':';
/* 302 */       Symbol sym = Symbol.intern(s.substring(isKeyword ? 1 : 0));
/* 303 */       if (isKeyword)
/* 304 */         return Keyword.intern(sym);
/* 305 */       return sym;
/*     */     }
/* 307 */     return null;
/*     */   }
/*     */   
/*     */   private static Object matchNumber(String s)
/*     */   {
/* 312 */     Matcher m = intPat.matcher(s);
/* 313 */     if (m.matches())
/*     */     {
/* 315 */       if (m.group(2) != null)
/*     */       {
/* 317 */         if (m.group(8) != null)
/* 318 */           return BigInt.ZERO;
/* 319 */         return Numbers.num(0L);
/*     */       }
/* 321 */       boolean negate = m.group(1).equals("-");
/*     */       
/* 323 */       int radix = 10;
/* 324 */       String n; if ((n = m.group(3)) != null) {
/* 325 */         radix = 10;
/* 326 */       } else if ((n = m.group(4)) != null) {
/* 327 */         radix = 16;
/* 328 */       } else if ((n = m.group(5)) != null) {
/* 329 */         radix = 8;
/* 330 */       } else if ((n = m.group(7)) != null)
/* 331 */         radix = Integer.parseInt(m.group(6));
/* 332 */       if (n == null)
/* 333 */         return null;
/* 334 */       BigInteger bn = new BigInteger(n, radix);
/* 335 */       if (negate)
/* 336 */         bn = bn.negate();
/* 337 */       if (m.group(8) != null)
/* 338 */         return BigInt.fromBigInteger(bn);
/* 339 */       return bn.bitLength() < 64 ? Numbers.num(bn.longValue()) : BigInt.fromBigInteger(bn);
/*     */     }
/*     */     
/*     */ 
/* 343 */     m = floatPat.matcher(s);
/* 344 */     if (m.matches())
/*     */     {
/* 346 */       if (m.group(4) != null)
/* 347 */         return new BigDecimal(m.group(1));
/* 348 */       return Double.valueOf(Double.parseDouble(s));
/*     */     }
/* 350 */     m = ratioPat.matcher(s);
/* 351 */     if (m.matches())
/*     */     {
/* 353 */       String numerator = m.group(1);
/* 354 */       if (numerator.startsWith("+")) { numerator = numerator.substring(1);
/*     */       }
/* 356 */       return Numbers.divide(Numbers.reduceBigInt(BigInt.fromBigInteger(new BigInteger(numerator))), Numbers.reduceBigInt(BigInt.fromBigInteger(new BigInteger(m.group(2)))));
/*     */     }
/*     */     
/* 359 */     return null;
/*     */   }
/*     */   
/*     */   private static IFn getMacro(int ch) {
/* 363 */     if (ch < macros.length)
/* 364 */       return macros[ch];
/* 365 */     return null;
/*     */   }
/*     */   
/*     */   private static boolean isMacro(int ch) {
/* 369 */     return (ch < macros.length) && (macros[ch] != null);
/*     */   }
/*     */   
/*     */   private static boolean isTerminatingMacro(int ch) {
/* 373 */     return (ch != 35) && (ch != 39) && (isMacro(ch));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class StringReader
/*     */     extends AFn
/*     */   {
/*     */     public Object invoke(Object reader, Object doublequote, Object opts)
/*     */     {
/* 404 */       StringBuilder sb = new StringBuilder();
/* 405 */       Reader r = (Reader)reader;
/*     */       
/* 407 */       for (int ch = EdnReader.read1(r); ch != 34; ch = EdnReader.read1(r))
/*     */       {
/* 409 */         if (ch == -1)
/* 410 */           throw Util.runtimeException("EOF while reading string");
/* 411 */         if (ch == 92)
/*     */         {
/* 413 */           ch = EdnReader.read1(r);
/* 414 */           if (ch == -1)
/* 415 */             throw Util.runtimeException("EOF while reading string");
/* 416 */           switch (ch)
/*     */           {
/*     */           case 116: 
/* 419 */             ch = 9;
/* 420 */             break;
/*     */           case 114: 
/* 422 */             ch = 13;
/* 423 */             break;
/*     */           case 110: 
/* 425 */             ch = 10;
/* 426 */             break;
/*     */           case 92: 
/*     */             break;
/*     */           case 34: 
/*     */             break;
/*     */           case 98: 
/* 432 */             ch = 8;
/* 433 */             break;
/*     */           case 102: 
/* 435 */             ch = 12;
/* 436 */             break;
/*     */           
/*     */           case 117: 
/* 439 */             ch = EdnReader.read1(r);
/* 440 */             if (Character.digit(ch, 16) == -1)
/* 441 */               throw Util.runtimeException("Invalid unicode escape: \\u" + (char)ch);
/* 442 */             ch = EdnReader.readUnicodeChar((PushbackReader)r, ch, 16, 4, true);
/* 443 */             break;
/*     */           
/*     */ 
/*     */           default: 
/* 447 */             if (Character.isDigit(ch))
/*     */             {
/* 449 */               ch = EdnReader.readUnicodeChar((PushbackReader)r, ch, 8, 3, false);
/* 450 */               if (ch > 255) {
/* 451 */                 throw Util.runtimeException("Octal escape sequence must be in range [0, 377].");
/*     */               }
/*     */             } else {
/* 454 */               throw Util.runtimeException("Unsupported escape character: \\" + (char)ch);
/*     */             }
/*     */             break; }
/*     */         }
/* 458 */         sb.append((char)ch);
/*     */       }
/* 460 */       return sb.toString();
/*     */     }
/*     */   }
/*     */   
/*     */   public static class CommentReader extends AFn {
/*     */     public Object invoke(Object reader, Object semicolon, Object opts) {
/* 466 */       Reader r = (Reader)reader;
/*     */       int ch;
/*     */       do
/*     */       {
/* 470 */         ch = EdnReader.read1(r);
/* 471 */       } while ((ch != -1) && (ch != 10) && (ch != 13));
/* 472 */       return r;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class DiscardReader extends AFn
/*     */   {
/*     */     public Object invoke(Object reader, Object underscore, Object opts) {
/* 479 */       PushbackReader r = (PushbackReader)reader;
/* 480 */       EdnReader.read(r, true, null, true, opts);
/* 481 */       return r;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class DispatchReader extends AFn {
/*     */     public Object invoke(Object reader, Object hash, Object opts) {
/* 487 */       int ch = EdnReader.read1((Reader)reader);
/* 488 */       if (ch == -1)
/* 489 */         throw Util.runtimeException("EOF while reading character");
/* 490 */       IFn fn = EdnReader.dispatchMacros[ch];
/*     */       
/* 492 */       if (fn == null)
/*     */       {
/* 494 */         if (Character.isLetter(ch))
/*     */         {
/* 496 */           EdnReader.unread((PushbackReader)reader, ch);
/* 497 */           return EdnReader.taggedReader.invoke(reader, Integer.valueOf(ch), opts);
/*     */         }
/*     */         
/* 500 */         throw Util.runtimeException(String.format("No dispatch macro for: %c", new Object[] { Character.valueOf((char)ch) }));
/*     */       }
/* 502 */       return fn.invoke(reader, Integer.valueOf(ch), opts);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class MetaReader extends AFn {
/*     */     public Object invoke(Object reader, Object caret, Object opts) {
/* 508 */       PushbackReader r = (PushbackReader)reader;
/* 509 */       int line = -1;
/* 510 */       int column = -1;
/* 511 */       if ((r instanceof LineNumberingPushbackReader))
/*     */       {
/* 513 */         line = ((LineNumberingPushbackReader)r).getLineNumber();
/* 514 */         column = ((LineNumberingPushbackReader)r).getColumnNumber() - 1;
/*     */       }
/* 516 */       Object meta = EdnReader.read(r, true, null, true, opts);
/* 517 */       if (((meta instanceof Symbol)) || ((meta instanceof String))) {
/* 518 */         meta = RT.map(new Object[] { RT.TAG_KEY, meta });
/* 519 */       } else if ((meta instanceof Keyword)) {
/* 520 */         meta = RT.map(new Object[] { meta, RT.T });
/* 521 */       } else if (!(meta instanceof IPersistentMap)) {
/* 522 */         throw new IllegalArgumentException("Metadata must be Symbol,Keyword,String or Map");
/*     */       }
/* 524 */       Object o = EdnReader.read(r, true, null, true, opts);
/* 525 */       if ((o instanceof IMeta))
/*     */       {
/* 527 */         if ((line != -1) && ((o instanceof ISeq)))
/*     */         {
/* 529 */           meta = ((IPersistentMap)meta).assoc(RT.LINE_KEY, Integer.valueOf(line)).assoc(RT.COLUMN_KEY, Integer.valueOf(column));
/*     */         }
/* 531 */         if ((o instanceof IReference))
/*     */         {
/* 533 */           ((IReference)o).resetMeta((IPersistentMap)meta);
/* 534 */           return o;
/*     */         }
/* 536 */         Object ometa = RT.meta(o);
/* 537 */         for (ISeq s = RT.seq(meta); s != null; s = s.next()) {
/* 538 */           IMapEntry kv = (IMapEntry)s.first();
/* 539 */           ometa = RT.assoc(ometa, kv.getKey(), kv.getValue());
/*     */         }
/* 541 */         return ((IObj)o).withMeta((IPersistentMap)ometa);
/*     */       }
/*     */       
/* 544 */       throw new IllegalArgumentException("Metadata can only be applied to IMetas");
/*     */     }
/*     */   }
/*     */   
/*     */   public static class CharacterReader extends AFn
/*     */   {
/*     */     public Object invoke(Object reader, Object backslash, Object opts) {
/* 551 */       PushbackReader r = (PushbackReader)reader;
/* 552 */       int ch = EdnReader.read1(r);
/* 553 */       if (ch == -1)
/* 554 */         throw Util.runtimeException("EOF while reading character");
/* 555 */       String token = EdnReader.readToken(r, (char)ch, false);
/* 556 */       if (token.length() == 1)
/* 557 */         return Character.valueOf(token.charAt(0));
/* 558 */       if (token.equals("newline"))
/* 559 */         return Character.valueOf('\n');
/* 560 */       if (token.equals("space"))
/* 561 */         return Character.valueOf(' ');
/* 562 */       if (token.equals("tab"))
/* 563 */         return Character.valueOf('\t');
/* 564 */       if (token.equals("backspace"))
/* 565 */         return Character.valueOf('\b');
/* 566 */       if (token.equals("formfeed"))
/* 567 */         return Character.valueOf('\f');
/* 568 */       if (token.equals("return"))
/* 569 */         return Character.valueOf('\r');
/* 570 */       if (token.startsWith("u"))
/*     */       {
/* 572 */         char c = (char)EdnReader.readUnicodeChar(token, 1, 4, 16);
/* 573 */         if ((c >= 55296) && (c <= 57343))
/* 574 */           throw Util.runtimeException("Invalid character constant: \\u" + Integer.toString(c, 16));
/* 575 */         return Character.valueOf(c);
/*     */       }
/* 577 */       if (token.startsWith("o"))
/*     */       {
/* 579 */         int len = token.length() - 1;
/* 580 */         if (len > 3)
/* 581 */           throw Util.runtimeException("Invalid octal escape sequence length: " + len);
/* 582 */         int uc = EdnReader.readUnicodeChar(token, 1, len, 8);
/* 583 */         if (uc > 255)
/* 584 */           throw Util.runtimeException("Octal escape sequence must be in range [0, 377].");
/* 585 */         return Character.valueOf((char)uc);
/*     */       }
/* 587 */       throw Util.runtimeException("Unsupported character: \\" + token);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class ListReader extends AFn
/*     */   {
/*     */     public Object invoke(Object reader, Object leftparen, Object opts) {
/* 594 */       PushbackReader r = (PushbackReader)reader;
/* 595 */       int line = -1;
/* 596 */       int column = -1;
/* 597 */       if ((r instanceof LineNumberingPushbackReader))
/*     */       {
/* 599 */         line = ((LineNumberingPushbackReader)r).getLineNumber();
/* 600 */         column = ((LineNumberingPushbackReader)r).getColumnNumber() - 1;
/*     */       }
/* 602 */       List list = EdnReader.readDelimitedList(')', r, true, opts);
/* 603 */       if (list.isEmpty())
/* 604 */         return PersistentList.EMPTY;
/* 605 */       IObj s = (IObj)PersistentList.create(list);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 612 */       return s;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class VectorReader extends AFn
/*     */   {
/*     */     public Object invoke(Object reader, Object leftparen, Object opts) {
/* 619 */       PushbackReader r = (PushbackReader)reader;
/* 620 */       return LazilyPersistentVector.create(EdnReader.readDelimitedList(']', r, true, opts));
/*     */     }
/*     */   }
/*     */   
/*     */   public static class MapReader extends AFn
/*     */   {
/*     */     public Object invoke(Object reader, Object leftparen, Object opts) {
/* 627 */       PushbackReader r = (PushbackReader)reader;
/* 628 */       Object[] a = EdnReader.readDelimitedList('}', r, true, opts).toArray();
/* 629 */       if ((a.length & 0x1) == 1)
/* 630 */         throw Util.runtimeException("Map literal must contain an even number of forms");
/* 631 */       return RT.map(a);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class SetReader extends AFn
/*     */   {
/*     */     public Object invoke(Object reader, Object leftbracket, Object opts) {
/* 638 */       PushbackReader r = (PushbackReader)reader;
/* 639 */       return PersistentHashSet.createWithCheck(EdnReader.readDelimitedList('}', r, true, opts));
/*     */     }
/*     */   }
/*     */   
/*     */   public static class UnmatchedDelimiterReader extends AFn
/*     */   {
/*     */     public Object invoke(Object reader, Object rightdelim, Object opts) {
/* 646 */       throw Util.runtimeException("Unmatched delimiter: " + rightdelim);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class UnreadableReader extends AFn
/*     */   {
/*     */     public Object invoke(Object reader, Object leftangle, Object opts) {
/* 653 */       throw Util.runtimeException("Unreadable form");
/*     */     }
/*     */   }
/*     */   
/*     */   public static List readDelimitedList(char delim, PushbackReader r, boolean isRecursive, Object opts) {
/* 658 */     int firstline = (r instanceof LineNumberingPushbackReader) ? ((LineNumberingPushbackReader)r).getLineNumber() : -1;
/*     */     
/*     */ 
/*     */ 
/* 662 */     ArrayList a = new ArrayList();
/*     */     
/*     */     for (;;)
/*     */     {
/* 666 */       int ch = read1(r);
/*     */       
/* 668 */       while (isWhitespace(ch)) {
/* 669 */         ch = read1(r);
/*     */       }
/* 671 */       if (ch == -1)
/*     */       {
/* 673 */         if (firstline < 0) {
/* 674 */           throw Util.runtimeException("EOF while reading");
/*     */         }
/* 676 */         throw Util.runtimeException("EOF while reading, starting at line " + firstline);
/*     */       }
/*     */       
/* 679 */       if (ch == delim) {
/*     */         break;
/*     */       }
/* 682 */       IFn macroFn = getMacro(ch);
/* 683 */       if (macroFn != null)
/*     */       {
/* 685 */         Object mret = macroFn.invoke(r, Character.valueOf((char)ch), opts);
/*     */         
/* 687 */         if (mret != r) {
/* 688 */           a.add(mret);
/*     */         }
/*     */       }
/*     */       else {
/* 692 */         unread(r, ch);
/*     */         
/* 694 */         Object o = read(r, true, null, isRecursive, opts);
/* 695 */         if (o != r) {
/* 696 */           a.add(o);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 701 */     return a;
/*     */   }
/*     */   
/*     */   public static class TaggedReader extends AFn {
/*     */     public Object invoke(Object reader, Object firstChar, Object opts) {
/* 706 */       PushbackReader r = (PushbackReader)reader;
/* 707 */       Object name = EdnReader.read(r, true, null, false, opts);
/* 708 */       if (!(name instanceof Symbol))
/* 709 */         throw new RuntimeException("Reader tag must be a symbol");
/* 710 */       Symbol sym = (Symbol)name;
/* 711 */       return readTagged(r, sym, (IPersistentMap)opts);
/*     */     }
/*     */     
/* 714 */     static Keyword READERS = Keyword.intern(null, "readers");
/* 715 */     static Keyword DEFAULT = Keyword.intern(null, "default");
/*     */     
/*     */     private Object readTagged(PushbackReader reader, Symbol tag, IPersistentMap opts) {
/* 718 */       Object o = EdnReader.read(reader, true, null, true, opts);
/*     */       
/* 720 */       ILookup readers = (ILookup)RT.get(opts, READERS);
/* 721 */       IFn dataReader = (IFn)RT.get(readers, tag);
/* 722 */       if (dataReader == null)
/* 723 */         dataReader = (IFn)RT.get(RT.DEFAULT_DATA_READERS.deref(), tag);
/* 724 */       if (dataReader == null) {
/* 725 */         IFn defaultReader = (IFn)RT.get(opts, DEFAULT);
/* 726 */         if (defaultReader != null) {
/* 727 */           return defaultReader.invoke(tag, o);
/*     */         }
/* 729 */         throw new RuntimeException("No reader function for tag " + tag.toString());
/*     */       }
/*     */       
/* 732 */       return dataReader.invoke(o);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\EdnReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */