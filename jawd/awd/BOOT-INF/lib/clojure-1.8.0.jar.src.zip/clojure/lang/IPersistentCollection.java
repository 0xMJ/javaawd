package clojure.lang;

public abstract interface IPersistentCollection
  extends Seqable
{
  public abstract int count();
  
  public abstract IPersistentCollection cons(Object paramObject);
  
  public abstract IPersistentCollection empty();
  
  public abstract boolean equiv(Object paramObject);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\IPersistentCollection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */