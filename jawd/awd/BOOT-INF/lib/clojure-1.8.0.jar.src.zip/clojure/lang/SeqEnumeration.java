/*    */ package clojure.lang;
/*    */ 
/*    */ import java.util.Enumeration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SeqEnumeration
/*    */   implements Enumeration
/*    */ {
/*    */   ISeq seq;
/*    */   
/*    */   public SeqEnumeration(ISeq seq)
/*    */   {
/* 21 */     this.seq = seq;
/*    */   }
/*    */   
/*    */   public boolean hasMoreElements() {
/* 25 */     return this.seq != null;
/*    */   }
/*    */   
/*    */   public Object nextElement() {
/* 29 */     Object ret = RT.first(this.seq);
/* 30 */     this.seq = RT.next(this.seq);
/* 31 */     return ret;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\SeqEnumeration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */