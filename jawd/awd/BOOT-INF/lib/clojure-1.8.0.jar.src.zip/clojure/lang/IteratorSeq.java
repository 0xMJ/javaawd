/*    */ package clojure.lang;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.NotSerializableException;
/*    */ import java.io.ObjectOutputStream;
/*    */ import java.util.Iterator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IteratorSeq
/*    */   extends ASeq
/*    */ {
/*    */   final Iterator iter;
/*    */   final State state;
/*    */   
/*    */   public static IteratorSeq create(Iterator iter)
/*    */   {
/* 27 */     if (iter.hasNext())
/* 28 */       return new IteratorSeq(iter);
/* 29 */     return null;
/*    */   }
/*    */   
/*    */   IteratorSeq(Iterator iter) {
/* 33 */     this.iter = iter;
/* 34 */     this.state = new State();
/* 35 */     this.state.val = this.state;
/* 36 */     this.state._rest = this.state;
/*    */   }
/*    */   
/*    */   IteratorSeq(IPersistentMap meta, Iterator iter, State state) {
/* 40 */     super(meta);
/* 41 */     this.iter = iter;
/* 42 */     this.state = state;
/*    */   }
/*    */   
/*    */   public Object first() {
/* 46 */     if (this.state.val == this.state)
/* 47 */       synchronized (this.state)
/*    */       {
/* 49 */         if (this.state.val == this.state)
/* 50 */           this.state.val = this.iter.next();
/*    */       }
/* 52 */     return this.state.val;
/*    */   }
/*    */   
/*    */   public ISeq next() {
/* 56 */     if (this.state._rest == this.state)
/* 57 */       synchronized (this.state)
/*    */       {
/* 59 */         if (this.state._rest == this.state)
/*    */         {
/* 61 */           first();
/* 62 */           this.state._rest = create(this.iter);
/*    */         }
/*    */       }
/* 65 */     return (ISeq)this.state._rest;
/*    */   }
/*    */   
/*    */   public IteratorSeq withMeta(IPersistentMap meta) {
/* 69 */     return new IteratorSeq(meta, this.iter, this.state);
/*    */   }
/*    */   
/*    */   private void writeObject(ObjectOutputStream out) throws IOException {
/* 73 */     throw new NotSerializableException(getClass().getName());
/*    */   }
/*    */   
/*    */   static class State
/*    */   {
/*    */     volatile Object val;
/*    */     volatile Object _rest;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\IteratorSeq.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */