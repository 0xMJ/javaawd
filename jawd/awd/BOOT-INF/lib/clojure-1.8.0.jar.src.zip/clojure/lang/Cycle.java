/*    */ package clojure.lang;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Cycle
/*    */   extends ASeq
/*    */   implements IReduce, IPending
/*    */ {
/*    */   private final ISeq all;
/*    */   
/*    */ 
/*    */   private final ISeq prev;
/*    */   
/*    */ 
/*    */   private volatile ISeq _current;
/*    */   
/*    */ 
/*    */   private volatile ISeq _next;
/*    */   
/*    */ 
/*    */   private Cycle(ISeq all, ISeq prev, ISeq current)
/*    */   {
/* 23 */     this.all = all;
/* 24 */     this.prev = prev;
/* 25 */     this._current = current;
/*    */   }
/*    */   
/*    */   private Cycle(IPersistentMap meta, ISeq all, ISeq prev, ISeq current, ISeq next) {
/* 29 */     super(meta);
/* 30 */     this.all = all;
/* 31 */     this.prev = prev;
/* 32 */     this._current = current;
/* 33 */     this._next = next;
/*    */   }
/*    */   
/*    */   public static ISeq create(ISeq vals) {
/* 37 */     if (vals == null)
/* 38 */       return PersistentList.EMPTY;
/* 39 */     return new Cycle(vals, null, vals);
/*    */   }
/*    */   
/*    */   private ISeq current()
/*    */   {
/* 44 */     if (this._current == null) {
/* 45 */       ISeq current = this.prev.next();
/* 46 */       this._current = (current == null ? this.all : current);
/*    */     }
/* 48 */     return this._current;
/*    */   }
/*    */   
/*    */   public boolean isRealized() {
/* 52 */     return this._current != null;
/*    */   }
/*    */   
/*    */   public Object first() {
/* 56 */     return current().first();
/*    */   }
/*    */   
/*    */   public ISeq next() {
/* 60 */     if (this._next == null)
/* 61 */       this._next = new Cycle(this.all, current(), null);
/* 62 */     return this._next;
/*    */   }
/*    */   
/*    */   public Cycle withMeta(IPersistentMap meta) {
/* 66 */     return new Cycle(meta, this.all, this.prev, this._current, this._next);
/*    */   }
/*    */   
/*    */   public Object reduce(IFn f) {
/* 70 */     ISeq s = current();
/* 71 */     Object ret = s.first();
/*    */     do {
/* 73 */       s = s.next();
/* 74 */       if (s == null)
/* 75 */         s = this.all;
/* 76 */       ret = f.invoke(ret, s.first());
/* 77 */     } while (!RT.isReduced(ret));
/* 78 */     return ((IDeref)ret).deref();
/*    */   }
/*    */   
/*    */   public Object reduce(IFn f, Object start)
/*    */   {
/* 83 */     Object ret = start;
/* 84 */     ISeq s = current();
/*    */     for (;;) {
/* 86 */       ret = f.invoke(ret, s.first());
/* 87 */       if (RT.isReduced(ret))
/* 88 */         return ((IDeref)ret).deref();
/* 89 */       s = s.next();
/* 90 */       if (s == null) {
/* 91 */         s = this.all;
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\Cycle.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */