/*     */ package clojure.lang;
/*     */ 
/*     */ import java.io.ObjectStreamException;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Symbol
/*     */   extends AFn
/*     */   implements IObj, Comparable, Named, Serializable, IHashEq
/*     */ {
/*     */   final String ns;
/*     */   final String name;
/*     */   private int _hasheq;
/*     */   final IPersistentMap _meta;
/*     */   transient String _str;
/*     */   
/*     */   public String toString()
/*     */   {
/*  27 */     if (this._str == null) {
/*  28 */       if (this.ns != null) {
/*  29 */         this._str = (this.ns + "/" + this.name);
/*     */       } else
/*  31 */         this._str = this.name;
/*     */     }
/*  33 */     return this._str;
/*     */   }
/*     */   
/*     */   public String getNamespace() {
/*  37 */     return this.ns;
/*     */   }
/*     */   
/*     */   public String getName() {
/*  41 */     return this.name;
/*     */   }
/*     */   
/*     */ 
/*     */   public static Symbol create(String ns, String name)
/*     */   {
/*  47 */     return intern(ns, name);
/*     */   }
/*     */   
/*     */   public static Symbol create(String nsname) {
/*  51 */     return intern(nsname);
/*     */   }
/*     */   
/*     */   public static Symbol intern(String ns, String name) {
/*  55 */     return new Symbol(ns, name);
/*     */   }
/*     */   
/*     */   public static Symbol intern(String nsname) {
/*  59 */     int i = nsname.indexOf('/');
/*  60 */     if ((i == -1) || (nsname.equals("/"))) {
/*  61 */       return new Symbol(null, nsname);
/*     */     }
/*  63 */     return new Symbol(nsname.substring(0, i), nsname.substring(i + 1));
/*     */   }
/*     */   
/*     */   private Symbol(String ns_interned, String name_interned) {
/*  67 */     this.name = name_interned;
/*  68 */     this.ns = ns_interned;
/*  69 */     this._meta = null;
/*     */   }
/*     */   
/*     */   public boolean equals(Object o) {
/*  73 */     if (this == o)
/*  74 */       return true;
/*  75 */     if (!(o instanceof Symbol)) {
/*  76 */       return false;
/*     */     }
/*  78 */     Symbol symbol = (Symbol)o;
/*     */     
/*  80 */     return (Util.equals(this.ns, symbol.ns)) && (this.name.equals(symbol.name));
/*     */   }
/*     */   
/*     */   public int hashCode() {
/*  84 */     return Util.hashCombine(this.name.hashCode(), Util.hash(this.ns));
/*     */   }
/*     */   
/*     */   public int hasheq() {
/*  88 */     if (this._hasheq == 0) {
/*  89 */       this._hasheq = Util.hashCombine(Murmur3.hashUnencodedChars(this.name), Util.hash(this.ns));
/*     */     }
/*  91 */     return this._hasheq;
/*     */   }
/*     */   
/*     */   public IObj withMeta(IPersistentMap meta) {
/*  95 */     return new Symbol(meta, this.ns, this.name);
/*     */   }
/*     */   
/*     */   private Symbol(IPersistentMap meta, String ns, String name) {
/*  99 */     this.name = name;
/* 100 */     this.ns = ns;
/* 101 */     this._meta = meta;
/*     */   }
/*     */   
/*     */   public int compareTo(Object o) {
/* 105 */     Symbol s = (Symbol)o;
/* 106 */     if (equals(o))
/* 107 */       return 0;
/* 108 */     if ((this.ns == null) && (s.ns != null))
/* 109 */       return -1;
/* 110 */     if (this.ns != null)
/*     */     {
/* 112 */       if (s.ns == null)
/* 113 */         return 1;
/* 114 */       int nsc = this.ns.compareTo(s.ns);
/* 115 */       if (nsc != 0)
/* 116 */         return nsc;
/*     */     }
/* 118 */     return this.name.compareTo(s.name);
/*     */   }
/*     */   
/*     */   private Object readResolve() throws ObjectStreamException {
/* 122 */     return intern(this.ns, this.name);
/*     */   }
/*     */   
/*     */   public Object invoke(Object obj) {
/* 126 */     return RT.get(obj, this);
/*     */   }
/*     */   
/*     */   public Object invoke(Object obj, Object notFound) {
/* 130 */     return RT.get(obj, this, notFound);
/*     */   }
/*     */   
/*     */   public IPersistentMap meta() {
/* 134 */     return this._meta;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\Symbol.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */