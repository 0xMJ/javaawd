/*    */ package clojure.lang;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ChunkedCons
/*    */   extends ASeq
/*    */   implements IChunkedSeq
/*    */ {
/*    */   final IChunk chunk;
/*    */   
/*    */ 
/*    */ 
/*    */   final ISeq _more;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   ChunkedCons(IPersistentMap meta, IChunk chunk, ISeq more)
/*    */   {
/* 21 */     super(meta);
/* 22 */     this.chunk = chunk;
/* 23 */     this._more = more;
/*    */   }
/*    */   
/*    */   public ChunkedCons(IChunk chunk, ISeq more) {
/* 27 */     this(null, chunk, more);
/*    */   }
/*    */   
/*    */   public Obj withMeta(IPersistentMap meta) {
/* 31 */     if (meta != this._meta)
/* 32 */       return new ChunkedCons(meta, this.chunk, this._more);
/* 33 */     return this;
/*    */   }
/*    */   
/*    */   public Object first() {
/* 37 */     return this.chunk.nth(0);
/*    */   }
/*    */   
/*    */   public ISeq next() {
/* 41 */     if (this.chunk.count() > 1)
/* 42 */       return new ChunkedCons(this.chunk.dropFirst(), this._more);
/* 43 */     return chunkedNext();
/*    */   }
/*    */   
/*    */   public ISeq more() {
/* 47 */     if (this.chunk.count() > 1)
/* 48 */       return new ChunkedCons(this.chunk.dropFirst(), this._more);
/* 49 */     if (this._more == null)
/* 50 */       return PersistentList.EMPTY;
/* 51 */     return this._more;
/*    */   }
/*    */   
/*    */   public IChunk chunkedFirst() {
/* 55 */     return this.chunk;
/*    */   }
/*    */   
/*    */   public ISeq chunkedNext() {
/* 59 */     return chunkedMore().seq();
/*    */   }
/*    */   
/*    */   public ISeq chunkedMore() {
/* 63 */     if (this._more == null)
/* 64 */       return PersistentList.EMPTY;
/* 65 */     return this._more;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\ChunkedCons.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */