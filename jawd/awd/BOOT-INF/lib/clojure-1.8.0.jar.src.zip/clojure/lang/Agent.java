/*     */ package clojure.lang;
/*     */ 
/*     */ import java.util.concurrent.Executor;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Agent
/*     */   extends ARef
/*     */ {
/*     */   static class ActionQueue
/*     */   {
/*     */     public final IPersistentStack q;
/*     */     public final Throwable error;
/*  27 */     static final ActionQueue EMPTY = new ActionQueue(PersistentQueue.EMPTY, null);
/*     */     
/*     */     public ActionQueue(IPersistentStack q, Throwable error)
/*     */     {
/*  31 */       this.q = q;
/*  32 */       this.error = error;
/*     */     }
/*     */   }
/*     */   
/*  36 */   static final Keyword CONTINUE = Keyword.intern(null, "continue");
/*  37 */   static final Keyword FAIL = Keyword.intern(null, "fail");
/*     */   
/*     */   volatile Object state;
/*  40 */   AtomicReference<ActionQueue> aq = new AtomicReference(ActionQueue.EMPTY);
/*     */   
/*  42 */   volatile Keyword errorMode = CONTINUE;
/*  43 */   volatile IFn errorHandler = null;
/*     */   
/*  45 */   private static final AtomicLong sendThreadPoolCounter = new AtomicLong(0L);
/*     */   
/*  47 */   private static final AtomicLong sendOffThreadPoolCounter = new AtomicLong(0L);
/*     */   
/*  49 */   public static volatile ExecutorService pooledExecutor = Executors.newFixedThreadPool(2 + Runtime.getRuntime().availableProcessors(), createThreadFactory("clojure-agent-send-pool-%d", sendThreadPoolCounter));
/*     */   
/*     */ 
/*     */ 
/*  53 */   public static volatile ExecutorService soloExecutor = Executors.newCachedThreadPool(createThreadFactory("clojure-agent-send-off-pool-%d", sendOffThreadPoolCounter));
/*     */   
/*     */ 
/*  56 */   static final ThreadLocal<IPersistentVector> nested = new ThreadLocal();
/*     */   
/*     */   private static ThreadFactory createThreadFactory(String format, final AtomicLong threadPoolCounter) {
/*  59 */     new ThreadFactory() {
/*     */       public Thread newThread(Runnable runnable) {
/*  61 */         Thread thread = new Thread(runnable);
/*  62 */         thread.setName(String.format(this.val$format, new Object[] { Long.valueOf(threadPoolCounter.getAndIncrement()) }));
/*  63 */         return thread;
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */   public static void shutdown() {
/*  69 */     soloExecutor.shutdown();
/*  70 */     pooledExecutor.shutdown();
/*     */   }
/*     */   
/*     */   static class Action implements Runnable
/*     */   {
/*     */     final Agent agent;
/*     */     final IFn fn;
/*     */     final ISeq args;
/*     */     final Executor exec;
/*     */     
/*     */     public Action(Agent agent, IFn fn, ISeq args, Executor exec) {
/*  81 */       this.agent = agent;
/*  82 */       this.args = args;
/*  83 */       this.fn = fn;
/*  84 */       this.exec = exec;
/*     */     }
/*     */     
/*     */     void execute()
/*     */     {
/*     */       try {
/*  90 */         this.exec.execute(this);
/*     */       }
/*     */       catch (Throwable error)
/*     */       {
/*  94 */         if (this.agent.errorHandler != null)
/*     */         {
/*     */           try
/*     */           {
/*  98 */             this.agent.errorHandler.invoke(this.agent, error);
/*     */           }
/*     */           catch (Throwable e) {}
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     static void doRun(Action action)
/*     */     {
/*     */       try {
/* 108 */         Agent.nested.set(PersistentVector.EMPTY);
/*     */         
/* 110 */         Throwable error = null;
/*     */         try
/*     */         {
/* 113 */           Object oldval = action.agent.state;
/* 114 */           Object newval = action.fn.applyTo(RT.cons(action.agent.state, action.args));
/* 115 */           action.agent.setState(newval);
/* 116 */           action.agent.notifyWatches(oldval, newval);
/*     */         }
/*     */         catch (Throwable e)
/*     */         {
/* 120 */           error = e;
/*     */         }
/*     */         
/* 123 */         if (error == null)
/*     */         {
/* 125 */           Agent.releasePendingSends();
/*     */         }
/*     */         else
/*     */         {
/* 129 */           Agent.nested.set(null);
/* 130 */           if (action.agent.errorHandler != null)
/*     */           {
/*     */             try
/*     */             {
/* 134 */               action.agent.errorHandler.invoke(action.agent, error);
/*     */             }
/*     */             catch (Throwable e) {}
/*     */           }
/* 138 */           if (action.agent.errorMode == Agent.CONTINUE)
/*     */           {
/* 140 */             error = null;
/*     */           }
/*     */         }
/*     */         
/* 144 */         boolean popped = false;
/* 145 */         Agent.ActionQueue next = null;
/* 146 */         while (!popped)
/*     */         {
/* 148 */           Agent.ActionQueue prior = (Agent.ActionQueue)action.agent.aq.get();
/* 149 */           next = new Agent.ActionQueue(prior.q.pop(), error);
/* 150 */           popped = action.agent.aq.compareAndSet(prior, next);
/*     */         }
/*     */         
/* 153 */         if ((error == null) && (next.q.count() > 0)) {
/* 154 */           ((Action)next.q.peek()).execute();
/*     */         }
/*     */       }
/*     */       finally {
/* 158 */         Agent.nested.set(null);
/*     */       }
/*     */     }
/*     */     
/*     */     public void run() {
/* 163 */       doRun(this);
/*     */     }
/*     */   }
/*     */   
/*     */   public Agent(Object state) {
/* 168 */     this(state, null);
/*     */   }
/*     */   
/*     */   public Agent(Object state, IPersistentMap meta) {
/* 172 */     super(meta);
/* 173 */     setState(state);
/*     */   }
/*     */   
/*     */   boolean setState(Object newState) {
/* 177 */     validate(newState);
/* 178 */     boolean ret = this.state != newState;
/* 179 */     this.state = newState;
/* 180 */     return ret;
/*     */   }
/*     */   
/*     */   public Object deref() {
/* 184 */     return this.state;
/*     */   }
/*     */   
/*     */   public Throwable getError() {
/* 188 */     return ((ActionQueue)this.aq.get()).error;
/*     */   }
/*     */   
/*     */   public void setErrorMode(Keyword k) {
/* 192 */     this.errorMode = k;
/*     */   }
/*     */   
/*     */   public Keyword getErrorMode() {
/* 196 */     return this.errorMode;
/*     */   }
/*     */   
/*     */   public void setErrorHandler(IFn f) {
/* 200 */     this.errorHandler = f;
/*     */   }
/*     */   
/*     */   public IFn getErrorHandler() {
/* 204 */     return this.errorHandler;
/*     */   }
/*     */   
/*     */   public synchronized Object restart(Object newState, boolean clearActions) {
/* 208 */     if (getError() == null)
/*     */     {
/* 210 */       throw Util.runtimeException("Agent does not need a restart");
/*     */     }
/* 212 */     validate(newState);
/* 213 */     this.state = newState;
/*     */     
/* 215 */     if (clearActions) {
/* 216 */       this.aq.set(ActionQueue.EMPTY);
/*     */     }
/*     */     else {
/* 219 */       boolean restarted = false;
/* 220 */       ActionQueue prior = null;
/* 221 */       while (!restarted)
/*     */       {
/* 223 */         prior = (ActionQueue)this.aq.get();
/* 224 */         restarted = this.aq.compareAndSet(prior, new ActionQueue(prior.q, null));
/*     */       }
/*     */       
/* 227 */       if (prior.q.count() > 0) {
/* 228 */         ((Action)prior.q.peek()).execute();
/*     */       }
/*     */     }
/* 231 */     return newState;
/*     */   }
/*     */   
/*     */   public Object dispatch(IFn fn, ISeq args, Executor exec) {
/* 235 */     Throwable error = getError();
/* 236 */     if (error != null)
/*     */     {
/* 238 */       throw Util.runtimeException("Agent is failed, needs restart", error);
/*     */     }
/* 240 */     Action action = new Action(this, fn, args, exec);
/* 241 */     dispatchAction(action);
/*     */     
/* 243 */     return this;
/*     */   }
/*     */   
/*     */   static void dispatchAction(Action action) {
/* 247 */     LockingTransaction trans = LockingTransaction.getRunning();
/* 248 */     if (trans != null) {
/* 249 */       trans.enqueue(action);
/* 250 */     } else if (nested.get() != null)
/*     */     {
/* 252 */       nested.set(((IPersistentVector)nested.get()).cons(action));
/*     */     }
/*     */     else
/* 255 */       action.agent.enqueue(action);
/*     */   }
/*     */   
/*     */   void enqueue(Action action) {
/* 259 */     boolean queued = false;
/* 260 */     ActionQueue prior = null;
/* 261 */     while (!queued)
/*     */     {
/* 263 */       prior = (ActionQueue)this.aq.get();
/* 264 */       queued = this.aq.compareAndSet(prior, new ActionQueue((IPersistentStack)prior.q.cons(action), prior.error));
/*     */     }
/*     */     
/* 267 */     if ((prior.q.count() == 0) && (prior.error == null))
/* 268 */       action.execute();
/*     */   }
/*     */   
/*     */   public int getQueueCount() {
/* 272 */     return ((ActionQueue)this.aq.get()).q.count();
/*     */   }
/*     */   
/*     */   public static int releasePendingSends() {
/* 276 */     IPersistentVector sends = (IPersistentVector)nested.get();
/* 277 */     if (sends == null)
/* 278 */       return 0;
/* 279 */     for (int i = 0; i < sends.count(); i++)
/*     */     {
/* 281 */       Action a = (Action)sends.valAt(Integer.valueOf(i));
/* 282 */       a.agent.enqueue(a);
/*     */     }
/* 284 */     nested.set(PersistentVector.EMPTY);
/* 285 */     return sends.count();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\Agent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */