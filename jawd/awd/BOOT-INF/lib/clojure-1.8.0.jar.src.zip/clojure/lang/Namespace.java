/*     */ package clojure.lang;
/*     */ 
/*     */ import java.io.ObjectStreamException;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.Serializable;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Namespace
/*     */   extends AReference
/*     */   implements Serializable
/*     */ {
/*     */   public final Symbol name;
/*  22 */   final transient AtomicReference<IPersistentMap> mappings = new AtomicReference();
/*  23 */   final transient AtomicReference<IPersistentMap> aliases = new AtomicReference();
/*     */   
/*  25 */   static final ConcurrentHashMap<Symbol, Namespace> namespaces = new ConcurrentHashMap();
/*     */   
/*     */   public String toString() {
/*  28 */     return this.name.toString();
/*     */   }
/*     */   
/*     */   Namespace(Symbol name) {
/*  32 */     super(name.meta());
/*  33 */     this.name = name;
/*  34 */     this.mappings.set(RT.DEFAULT_IMPORTS);
/*  35 */     this.aliases.set(RT.map(new Object[0]));
/*     */   }
/*     */   
/*     */   public static ISeq all() {
/*  39 */     return RT.seq(namespaces.values());
/*     */   }
/*     */   
/*     */   public Symbol getName() {
/*  43 */     return this.name;
/*     */   }
/*     */   
/*     */   public IPersistentMap getMappings() {
/*  47 */     return (IPersistentMap)this.mappings.get();
/*     */   }
/*     */   
/*     */   public Var intern(Symbol sym) {
/*  51 */     if (sym.ns != null)
/*     */     {
/*  53 */       throw new IllegalArgumentException("Can't intern namespace-qualified symbol");
/*     */     }
/*  55 */     IPersistentMap map = getMappings();
/*     */     
/*  57 */     Var v = null;
/*  58 */     Object o; while ((o = map.valAt(sym)) == null)
/*     */     {
/*  60 */       if (v == null)
/*  61 */         v = new Var(this, sym);
/*  62 */       IPersistentMap newMap = map.assoc(sym, v);
/*  63 */       this.mappings.compareAndSet(map, newMap);
/*  64 */       map = getMappings();
/*     */     }
/*  66 */     if (((o instanceof Var)) && (((Var)o).ns == this)) {
/*  67 */       return (Var)o;
/*     */     }
/*  69 */     if (v == null) {
/*  70 */       v = new Var(this, sym);
/*     */     }
/*  72 */     warnOrFailOnReplace(sym, o, v);
/*     */     
/*     */ 
/*  75 */     while (!this.mappings.compareAndSet(map, map.assoc(sym, v))) {
/*  76 */       map = getMappings();
/*     */     }
/*  78 */     return v;
/*     */   }
/*     */   
/*     */   private void warnOrFailOnReplace(Symbol sym, Object o, Object v) {
/*  82 */     if ((o instanceof Var))
/*     */     {
/*  84 */       Namespace ns = ((Var)o).ns;
/*  85 */       if ((ns == this) || (((v instanceof Var)) && (((Var)v).ns == RT.CLOJURE_NS)))
/*  86 */         return;
/*  87 */       if (ns != RT.CLOJURE_NS)
/*  88 */         throw new IllegalStateException(sym + " already refers to: " + o + " in namespace: " + this.name);
/*     */     }
/*  90 */     RT.errPrintWriter().println("WARNING: " + sym + " already refers to: " + o + " in namespace: " + this.name + ", being replaced by: " + v);
/*     */   }
/*     */   
/*     */   Object reference(Symbol sym, Object val)
/*     */   {
/*  95 */     if (sym.ns != null)
/*     */     {
/*  97 */       throw new IllegalArgumentException("Can't intern namespace-qualified symbol");
/*     */     }
/*  99 */     IPersistentMap map = getMappings();
/*     */     Object o;
/* 101 */     while ((o = map.valAt(sym)) == null)
/*     */     {
/* 103 */       IPersistentMap newMap = map.assoc(sym, val);
/* 104 */       this.mappings.compareAndSet(map, newMap);
/* 105 */       map = getMappings();
/*     */     }
/* 107 */     if (o == val) {
/* 108 */       return o;
/*     */     }
/* 110 */     warnOrFailOnReplace(sym, o, val);
/*     */     
/* 112 */     while (!this.mappings.compareAndSet(map, map.assoc(sym, val))) {
/* 113 */       map = getMappings();
/*     */     }
/* 115 */     return val;
/*     */   }
/*     */   
/*     */   public static boolean areDifferentInstancesOfSameClassName(Class cls1, Class cls2)
/*     */   {
/* 120 */     return (cls1 != cls2) && (cls1.getName().equals(cls2.getName()));
/*     */   }
/*     */   
/*     */   Class referenceClass(Symbol sym, Class val) {
/* 124 */     if (sym.ns != null)
/*     */     {
/* 126 */       throw new IllegalArgumentException("Can't intern namespace-qualified symbol");
/*     */     }
/* 128 */     IPersistentMap map = getMappings();
/* 129 */     Class c = (Class)map.valAt(sym);
/* 130 */     while ((c == null) || (areDifferentInstancesOfSameClassName(c, val)))
/*     */     {
/* 132 */       IPersistentMap newMap = map.assoc(sym, val);
/* 133 */       this.mappings.compareAndSet(map, newMap);
/* 134 */       map = getMappings();
/* 135 */       c = (Class)map.valAt(sym);
/*     */     }
/* 137 */     if (c == val) {
/* 138 */       return c;
/*     */     }
/* 140 */     throw new IllegalStateException(sym + " already refers to: " + c + " in namespace: " + this.name);
/*     */   }
/*     */   
/*     */   public void unmap(Symbol sym) {
/* 144 */     if (sym.ns != null)
/*     */     {
/* 146 */       throw new IllegalArgumentException("Can't unintern namespace-qualified symbol");
/*     */     }
/* 148 */     IPersistentMap map = getMappings();
/* 149 */     while (map.containsKey(sym))
/*     */     {
/* 151 */       IPersistentMap newMap = map.without(sym);
/* 152 */       this.mappings.compareAndSet(map, newMap);
/* 153 */       map = getMappings();
/*     */     }
/*     */   }
/*     */   
/*     */   public Class importClass(Symbol sym, Class c) {
/* 158 */     return referenceClass(sym, c);
/*     */   }
/*     */   
/*     */   public Class importClass(Class c)
/*     */   {
/* 163 */     String n = c.getName();
/* 164 */     return importClass(Symbol.intern(n.substring(n.lastIndexOf('.') + 1)), c);
/*     */   }
/*     */   
/*     */   public Var refer(Symbol sym, Var var) {
/* 168 */     return (Var)reference(sym, var);
/*     */   }
/*     */   
/*     */   public static Namespace findOrCreate(Symbol name)
/*     */   {
/* 173 */     Namespace ns = (Namespace)namespaces.get(name);
/* 174 */     if (ns != null)
/* 175 */       return ns;
/* 176 */     Namespace newns = new Namespace(name);
/* 177 */     ns = (Namespace)namespaces.putIfAbsent(name, newns);
/* 178 */     return ns == null ? newns : ns;
/*     */   }
/*     */   
/*     */   public static Namespace remove(Symbol name) {
/* 182 */     if (name.equals(RT.CLOJURE_NS.name))
/* 183 */       throw new IllegalArgumentException("Cannot remove clojure namespace");
/* 184 */     return (Namespace)namespaces.remove(name);
/*     */   }
/*     */   
/*     */   public static Namespace find(Symbol name) {
/* 188 */     return (Namespace)namespaces.get(name);
/*     */   }
/*     */   
/*     */   public Object getMapping(Symbol name) {
/* 192 */     return ((IPersistentMap)this.mappings.get()).valAt(name);
/*     */   }
/*     */   
/*     */   public Var findInternedVar(Symbol symbol) {
/* 196 */     Object o = ((IPersistentMap)this.mappings.get()).valAt(symbol);
/* 197 */     if ((o != null) && ((o instanceof Var)) && (((Var)o).ns == this))
/* 198 */       return (Var)o;
/* 199 */     return null;
/*     */   }
/*     */   
/*     */   public IPersistentMap getAliases()
/*     */   {
/* 204 */     return (IPersistentMap)this.aliases.get();
/*     */   }
/*     */   
/*     */   public Namespace lookupAlias(Symbol alias) {
/* 208 */     IPersistentMap map = getAliases();
/* 209 */     return (Namespace)map.valAt(alias);
/*     */   }
/*     */   
/*     */   public void addAlias(Symbol alias, Namespace ns) {
/* 213 */     if ((alias == null) || (ns == null))
/* 214 */       throw new NullPointerException("Expecting Symbol + Namespace");
/* 215 */     IPersistentMap map = getAliases();
/* 216 */     while (!map.containsKey(alias))
/*     */     {
/* 218 */       IPersistentMap newMap = map.assoc(alias, ns);
/* 219 */       this.aliases.compareAndSet(map, newMap);
/* 220 */       map = getAliases();
/*     */     }
/*     */     
/* 223 */     if (!map.valAt(alias).equals(ns)) {
/* 224 */       throw new IllegalStateException("Alias " + alias + " already exists in namespace " + this.name + ", aliasing " + map.valAt(alias));
/*     */     }
/*     */   }
/*     */   
/*     */   public void removeAlias(Symbol alias) {
/* 229 */     IPersistentMap map = getAliases();
/* 230 */     while (map.containsKey(alias))
/*     */     {
/* 232 */       IPersistentMap newMap = map.without(alias);
/* 233 */       this.aliases.compareAndSet(map, newMap);
/* 234 */       map = getAliases();
/*     */     }
/*     */   }
/*     */   
/*     */   private Object readResolve()
/*     */     throws ObjectStreamException
/*     */   {
/* 241 */     return findOrCreate(this.name);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\Namespace.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */