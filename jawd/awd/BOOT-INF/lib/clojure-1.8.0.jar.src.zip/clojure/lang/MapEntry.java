/*    */ package clojure.lang;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MapEntry
/*    */   extends AMapEntry
/*    */ {
/*    */   final Object _key;
/*    */   
/*    */ 
/*    */ 
/*    */   final Object _val;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public static MapEntry create(Object key, Object val)
/*    */   {
/* 20 */     return new MapEntry(key, val);
/*    */   }
/*    */   
/*    */   public MapEntry(Object key, Object val) {
/* 24 */     this._key = key;
/* 25 */     this._val = val;
/*    */   }
/*    */   
/*    */   public Object key() {
/* 29 */     return this._key;
/*    */   }
/*    */   
/*    */   public Object val() {
/* 33 */     return this._val;
/*    */   }
/*    */   
/*    */   public Object getKey() {
/* 37 */     return key();
/*    */   }
/*    */   
/*    */   public Object getValue() {
/* 41 */     return val();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\MapEntry.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */