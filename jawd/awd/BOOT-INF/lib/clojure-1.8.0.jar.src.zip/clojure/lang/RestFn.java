/*      */ package clojure.lang;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class RestFn
/*      */   extends AFunction
/*      */ {
/*      */   public abstract int getRequiredArity();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Object doInvoke(Object args)
/*      */   {
/*   16 */     return null;
/*      */   }
/*      */   
/*      */   protected Object doInvoke(Object arg1, Object args) {
/*   20 */     return null;
/*      */   }
/*      */   
/*      */   protected Object doInvoke(Object arg1, Object arg2, Object args) {
/*   24 */     return null;
/*      */   }
/*      */   
/*      */   protected Object doInvoke(Object arg1, Object arg2, Object arg3, Object args) {
/*   28 */     return null;
/*      */   }
/*      */   
/*      */   protected Object doInvoke(Object arg1, Object arg2, Object arg3, Object arg4, Object args) {
/*   32 */     return null;
/*      */   }
/*      */   
/*      */   protected Object doInvoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object args)
/*      */   {
/*   37 */     return null;
/*      */   }
/*      */   
/*      */   protected Object doInvoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object args)
/*      */   {
/*   42 */     return null;
/*      */   }
/*      */   
/*      */   protected Object doInvoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object args)
/*      */   {
/*   47 */     return null;
/*      */   }
/*      */   
/*      */   protected Object doInvoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object args)
/*      */   {
/*   52 */     return null;
/*      */   }
/*      */   
/*      */   protected Object doInvoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object args)
/*      */   {
/*   57 */     return null;
/*      */   }
/*      */   
/*      */   protected Object doInvoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object args)
/*      */   {
/*   62 */     return null;
/*      */   }
/*      */   
/*      */   protected Object doInvoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object args)
/*      */   {
/*   67 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */   protected Object doInvoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12, Object args)
/*      */   {
/*   73 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */   protected Object doInvoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12, Object arg13, Object args)
/*      */   {
/*   79 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */   protected Object doInvoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12, Object arg13, Object arg14, Object args)
/*      */   {
/*   85 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */   protected Object doInvoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12, Object arg13, Object arg14, Object arg15, Object args)
/*      */   {
/*   91 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */   protected Object doInvoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12, Object arg13, Object arg14, Object arg15, Object arg16, Object args)
/*      */   {
/*   97 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */   protected Object doInvoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12, Object arg13, Object arg14, Object arg15, Object arg16, Object arg17, Object args)
/*      */   {
/*  103 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected Object doInvoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12, Object arg13, Object arg14, Object arg15, Object arg16, Object arg17, Object arg18, Object args)
/*      */   {
/*  110 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Object doInvoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12, Object arg13, Object arg14, Object arg15, Object arg16, Object arg17, Object arg18, Object arg19, Object args)
/*      */   {
/*  118 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected Object doInvoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12, Object arg13, Object arg14, Object arg15, Object arg16, Object arg17, Object arg18, Object arg19, Object arg20, Object args)
/*      */   {
/*  125 */     return null;
/*      */   }
/*      */   
/*      */   public Object applyTo(ISeq args)
/*      */   {
/*  130 */     if (RT.boundedLength(args, getRequiredArity()) <= getRequiredArity())
/*      */     {
/*  132 */       return AFn.applyToHelper(this, Util.ret1(args, args = null));
/*      */     }
/*  134 */     switch (getRequiredArity())
/*      */     {
/*      */     case 0: 
/*  137 */       return doInvoke(Util.ret1(args, args = null));
/*      */     case 1: 
/*  139 */       return doInvoke(args.first(), Util.ret1(args.next(), args = null));
/*      */     
/*      */     case 2: 
/*  142 */       return doInvoke(args.first(), (args = args.next()).first(), Util.ret1(args.next(), args = null));
/*      */     
/*      */ 
/*      */     case 3: 
/*  146 */       return doInvoke(args.first(), (args = args.next()).first(), (args = args.next()).first(), Util.ret1(args.next(), args = null));
/*      */     
/*      */ 
/*      */ 
/*      */     case 4: 
/*  151 */       return doInvoke(args.first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), Util.ret1(args.next(), args = null));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     case 5: 
/*  157 */       return doInvoke(args.first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), Util.ret1(args.next(), args = null));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 6: 
/*  164 */       return doInvoke(args.first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), Util.ret1(args.next(), args = null));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 7: 
/*  172 */       return doInvoke(args.first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), Util.ret1(args.next(), args = null));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 8: 
/*  181 */       return doInvoke(args.first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), Util.ret1(args.next(), args = null));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 9: 
/*  191 */       return doInvoke(args.first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), Util.ret1(args.next(), args = null));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 10: 
/*  202 */       return doInvoke(args.first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), Util.ret1(args.next(), args = null));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 11: 
/*  214 */       return doInvoke(args.first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), Util.ret1(args.next(), args = null));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 12: 
/*  227 */       return doInvoke(args.first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), Util.ret1(args.next(), args = null));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 13: 
/*  241 */       return doInvoke(args.first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), Util.ret1(args.next(), args = null));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 14: 
/*  256 */       return doInvoke(args.first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), Util.ret1(args.next(), args = null));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 15: 
/*  272 */       return doInvoke(args.first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), Util.ret1(args.next(), args = null));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 16: 
/*  289 */       return doInvoke(args.first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), Util.ret1(args.next(), args = null));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 17: 
/*  307 */       return doInvoke(args.first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), Util.ret1(args.next(), args = null));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 18: 
/*  326 */       return doInvoke(args.first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), Util.ret1(args.next(), args = null));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 19: 
/*  346 */       return doInvoke(args.first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), Util.ret1(args.next(), args = null));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 20: 
/*  367 */       return doInvoke(args.first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), (args = args.next()).first(), Util.ret1(args.next(), args = null));
/*      */     }
/*      */     
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  390 */     return throwArity(-1);
/*      */   }
/*      */   
/*      */   public Object invoke() {
/*  394 */     switch (getRequiredArity())
/*      */     {
/*      */     case 0: 
/*  397 */       return doInvoke(null);
/*      */     }
/*  399 */     return throwArity(0);
/*      */   }
/*      */   
/*      */ 
/*      */   public Object invoke(Object arg1)
/*      */   {
/*  405 */     switch (getRequiredArity())
/*      */     {
/*      */     case 0: 
/*  408 */       return doInvoke(ArraySeq.create(new Object[] { Util.ret1(arg1, arg1 = null) }));
/*      */     case 1: 
/*  410 */       return doInvoke(Util.ret1(arg1, arg1 = null), null);
/*      */     }
/*  412 */     return throwArity(1);
/*      */   }
/*      */   
/*      */ 
/*      */   public Object invoke(Object arg1, Object arg2)
/*      */   {
/*  418 */     switch (getRequiredArity())
/*      */     {
/*      */     case 0: 
/*  421 */       return doInvoke(ArraySeq.create(new Object[] { Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null) }));
/*      */     case 1: 
/*  423 */       return doInvoke(Util.ret1(arg1, arg1 = null), ArraySeq.create(new Object[] { Util.ret1(arg2, arg2 = null) }));
/*      */     case 2: 
/*  425 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), null);
/*      */     }
/*  427 */     return throwArity(2);
/*      */   }
/*      */   
/*      */ 
/*      */   public Object invoke(Object arg1, Object arg2, Object arg3)
/*      */   {
/*  433 */     switch (getRequiredArity())
/*      */     {
/*      */     case 0: 
/*  436 */       return doInvoke(ArraySeq.create(new Object[] { Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null) }));
/*      */     
/*      */     case 1: 
/*  439 */       return doInvoke(Util.ret1(arg1, arg1 = null), ArraySeq.create(new Object[] { Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null) }));
/*      */     
/*      */     case 2: 
/*  442 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), ArraySeq.create(new Object[] { Util.ret1(arg3, arg3 = null) }));
/*      */     
/*      */     case 3: 
/*  445 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), null);
/*      */     }
/*      */     
/*  448 */     return throwArity(3);
/*      */   }
/*      */   
/*      */ 
/*      */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4)
/*      */   {
/*  454 */     switch (getRequiredArity())
/*      */     {
/*      */     case 0: 
/*  457 */       return doInvoke(ArraySeq.create(new Object[] { Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null) }));
/*      */     
/*      */     case 1: 
/*  460 */       return doInvoke(Util.ret1(arg1, arg1 = null), ArraySeq.create(new Object[] { Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null) }));
/*      */     
/*      */ 
/*      */     case 2: 
/*  464 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), ArraySeq.create(new Object[] { Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null) }));
/*      */     
/*      */     case 3: 
/*  467 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), ArraySeq.create(new Object[] { Util.ret1(arg4, arg4 = null) }));
/*      */     
/*      */     case 4: 
/*  470 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), null);
/*      */     }
/*      */     
/*  473 */     return throwArity(4);
/*      */   }
/*      */   
/*      */ 
/*      */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5)
/*      */   {
/*  479 */     switch (getRequiredArity())
/*      */     {
/*      */     case 0: 
/*  482 */       return doInvoke(ArraySeq.create(new Object[] { Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null) }));
/*      */     
/*      */ 
/*      */     case 1: 
/*  486 */       return doInvoke(Util.ret1(arg1, arg1 = null), ArraySeq.create(new Object[] { Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null) }));
/*      */     
/*      */ 
/*      */     case 2: 
/*  490 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), ArraySeq.create(new Object[] { Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null) }));
/*      */     
/*      */ 
/*      */     case 3: 
/*  494 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), ArraySeq.create(new Object[] { Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null) }));
/*      */     
/*      */     case 4: 
/*  497 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), ArraySeq.create(new Object[] { Util.ret1(arg5, arg5 = null) }));
/*      */     
/*      */     case 5: 
/*  500 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), null);
/*      */     }
/*      */     
/*  503 */     return throwArity(5);
/*      */   }
/*      */   
/*      */ 
/*      */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6)
/*      */   {
/*  509 */     switch (getRequiredArity())
/*      */     {
/*      */     case 0: 
/*  512 */       return doInvoke(ArraySeq.create(new Object[] { Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null) }));
/*      */     
/*      */ 
/*      */     case 1: 
/*  516 */       return doInvoke(Util.ret1(arg1, arg1 = null), ArraySeq.create(new Object[] { Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */     case 2: 
/*  521 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), ArraySeq.create(new Object[] { Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null) }));
/*      */     
/*      */ 
/*      */     case 3: 
/*  525 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), ArraySeq.create(new Object[] { Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null) }));
/*      */     
/*      */ 
/*      */     case 4: 
/*  529 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), ArraySeq.create(new Object[] { Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null) }));
/*      */     
/*      */ 
/*      */     case 5: 
/*  533 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), ArraySeq.create(new Object[] { Util.ret1(arg6, arg6 = null) }));
/*      */     
/*      */ 
/*      */     case 6: 
/*  537 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), null);
/*      */     }
/*      */     
/*      */     
/*  541 */     return throwArity(6);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7)
/*      */   {
/*  548 */     switch (getRequiredArity())
/*      */     {
/*      */     case 0: 
/*  551 */       return doInvoke(ArraySeq.create(new Object[] { Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 1: 
/*  559 */       return doInvoke(Util.ret1(arg1, arg1 = null), ArraySeq.create(new Object[] { Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 2: 
/*  566 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), ArraySeq.create(new Object[] { Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 3: 
/*  573 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), ArraySeq.create(new Object[] { Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 4: 
/*  580 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), ArraySeq.create(new Object[] { Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 5: 
/*  587 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), ArraySeq.create(new Object[] { Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 6: 
/*  594 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), ArraySeq.create(new Object[] { Util.ret1(arg7, arg7 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 7: 
/*  601 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), null);
/*      */     }
/*      */     
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  609 */     return throwArity(7);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8)
/*      */   {
/*  616 */     switch (getRequiredArity())
/*      */     {
/*      */     case 0: 
/*  619 */       return doInvoke(ArraySeq.create(new Object[] { Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 1: 
/*  628 */       return doInvoke(Util.ret1(arg1, arg1 = null), ArraySeq.create(new Object[] { Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 2: 
/*  636 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), ArraySeq.create(new Object[] { Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 3: 
/*  644 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), ArraySeq.create(new Object[] { Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 4: 
/*  652 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), ArraySeq.create(new Object[] { Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 5: 
/*  660 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), ArraySeq.create(new Object[] { Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 6: 
/*  668 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), ArraySeq.create(new Object[] { Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 7: 
/*  676 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), ArraySeq.create(new Object[] { Util.ret1(arg8, arg8 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 8: 
/*  684 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), null);
/*      */     }
/*      */     
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  693 */     return throwArity(8);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9)
/*      */   {
/*  700 */     switch (getRequiredArity())
/*      */     {
/*      */     case 0: 
/*  703 */       return doInvoke(ArraySeq.create(new Object[] { Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 1: 
/*  713 */       return doInvoke(Util.ret1(arg1, arg1 = null), ArraySeq.create(new Object[] { Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 2: 
/*  722 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), ArraySeq.create(new Object[] { Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 3: 
/*  731 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), ArraySeq.create(new Object[] { Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 4: 
/*  740 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), ArraySeq.create(new Object[] { Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 5: 
/*  749 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), ArraySeq.create(new Object[] { Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 6: 
/*  758 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), ArraySeq.create(new Object[] { Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 7: 
/*  767 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), ArraySeq.create(new Object[] { Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 8: 
/*  776 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), ArraySeq.create(new Object[] { Util.ret1(arg9, arg9 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 9: 
/*  785 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), null);
/*      */     }
/*      */     
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  795 */     return throwArity(9);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10)
/*      */   {
/*  802 */     switch (getRequiredArity())
/*      */     {
/*      */     case 0: 
/*  805 */       return doInvoke(ArraySeq.create(new Object[] { Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 1: 
/*  816 */       return doInvoke(Util.ret1(arg1, arg1 = null), ArraySeq.create(new Object[] { Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 2: 
/*  826 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), ArraySeq.create(new Object[] { Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 3: 
/*  836 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), ArraySeq.create(new Object[] { Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 4: 
/*  846 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), ArraySeq.create(new Object[] { Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 5: 
/*  856 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), ArraySeq.create(new Object[] { Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 6: 
/*  866 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), ArraySeq.create(new Object[] { Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 7: 
/*  876 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), ArraySeq.create(new Object[] { Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 8: 
/*  886 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), ArraySeq.create(new Object[] { Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 9: 
/*  896 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), ArraySeq.create(new Object[] { Util.ret1(arg10, arg10 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 10: 
/*  908 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), null);
/*      */     }
/*      */     
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  920 */     return throwArity(10);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11)
/*      */   {
/*  927 */     switch (getRequiredArity())
/*      */     {
/*      */     case 0: 
/*  930 */       return doInvoke(ArraySeq.create(new Object[] { Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 1: 
/*  943 */       return doInvoke(Util.ret1(arg1, arg1 = null), ArraySeq.create(new Object[] { Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 2: 
/*  956 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), ArraySeq.create(new Object[] { Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 3: 
/*  969 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), ArraySeq.create(new Object[] { Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 4: 
/*  982 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), ArraySeq.create(new Object[] { Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 5: 
/*  995 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), ArraySeq.create(new Object[] { Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 6: 
/* 1008 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), ArraySeq.create(new Object[] { Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 7: 
/* 1021 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), ArraySeq.create(new Object[] { Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 8: 
/* 1034 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), ArraySeq.create(new Object[] { Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 9: 
/* 1047 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), ArraySeq.create(new Object[] { Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 10: 
/* 1060 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), ArraySeq.create(new Object[] { Util.ret1(arg11, arg11 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 11: 
/* 1073 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), null);
/*      */     }
/*      */     
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1086 */     return throwArity(11);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12)
/*      */   {
/* 1093 */     switch (getRequiredArity())
/*      */     {
/*      */     case 0: 
/* 1096 */       return doInvoke(ArraySeq.create(new Object[] { Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 1: 
/* 1110 */       return doInvoke(Util.ret1(arg1, arg1 = null), ArraySeq.create(new Object[] { Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 2: 
/* 1124 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), ArraySeq.create(new Object[] { Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 3: 
/* 1138 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), ArraySeq.create(new Object[] { Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 4: 
/* 1152 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), ArraySeq.create(new Object[] { Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 5: 
/* 1166 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), ArraySeq.create(new Object[] { Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 6: 
/* 1180 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), ArraySeq.create(new Object[] { Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 7: 
/* 1194 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), ArraySeq.create(new Object[] { Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 8: 
/* 1208 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), ArraySeq.create(new Object[] { Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 9: 
/* 1222 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), ArraySeq.create(new Object[] { Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 10: 
/* 1236 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), ArraySeq.create(new Object[] { Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 11: 
/* 1250 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), ArraySeq.create(new Object[] { Util.ret1(arg12, arg12 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 12: 
/* 1264 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), null);
/*      */     }
/*      */     
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1278 */     return throwArity(12);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12, Object arg13)
/*      */   {
/* 1286 */     switch (getRequiredArity())
/*      */     {
/*      */     case 0: 
/* 1289 */       return doInvoke(ArraySeq.create(new Object[] { Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 1: 
/* 1305 */       return doInvoke(Util.ret1(arg1, arg1 = null), ArraySeq.create(new Object[] { Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 2: 
/* 1321 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), ArraySeq.create(new Object[] { Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 3: 
/* 1337 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), ArraySeq.create(new Object[] { Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 4: 
/* 1353 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), ArraySeq.create(new Object[] { Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 5: 
/* 1369 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), ArraySeq.create(new Object[] { Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 6: 
/* 1385 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), ArraySeq.create(new Object[] { Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 7: 
/* 1401 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), ArraySeq.create(new Object[] { Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 8: 
/* 1417 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), ArraySeq.create(new Object[] { Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 9: 
/* 1433 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), ArraySeq.create(new Object[] { Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 10: 
/* 1449 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), ArraySeq.create(new Object[] { Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 11: 
/* 1465 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), ArraySeq.create(new Object[] { Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 12: 
/* 1481 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), ArraySeq.create(new Object[] { Util.ret1(arg13, arg13 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 13: 
/* 1497 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), null);
/*      */     }
/*      */     
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1512 */     return throwArity(13);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12, Object arg13, Object arg14)
/*      */   {
/* 1520 */     switch (getRequiredArity())
/*      */     {
/*      */     case 0: 
/* 1523 */       return doInvoke(ArraySeq.create(new Object[] { Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 1: 
/* 1540 */       return doInvoke(Util.ret1(arg1, arg1 = null), ArraySeq.create(new Object[] { Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 2: 
/* 1557 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), ArraySeq.create(new Object[] { Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 3: 
/* 1574 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), ArraySeq.create(new Object[] { Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 4: 
/* 1591 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), ArraySeq.create(new Object[] { Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 5: 
/* 1608 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), ArraySeq.create(new Object[] { Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 6: 
/* 1625 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), ArraySeq.create(new Object[] { Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 7: 
/* 1642 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), ArraySeq.create(new Object[] { Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 8: 
/* 1659 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), ArraySeq.create(new Object[] { Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 9: 
/* 1676 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), ArraySeq.create(new Object[] { Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 10: 
/* 1693 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), ArraySeq.create(new Object[] { Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 11: 
/* 1710 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), ArraySeq.create(new Object[] { Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 12: 
/* 1727 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), ArraySeq.create(new Object[] { Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 13: 
/* 1744 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), ArraySeq.create(new Object[] { Util.ret1(arg14, arg14 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 14: 
/* 1761 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), null);
/*      */     }
/*      */     
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1778 */     return throwArity(14);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12, Object arg13, Object arg14, Object arg15)
/*      */   {
/* 1786 */     switch (getRequiredArity())
/*      */     {
/*      */     case 0: 
/* 1789 */       return doInvoke(ArraySeq.create(new Object[] { Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 1: 
/* 1807 */       return doInvoke(Util.ret1(arg1, arg1 = null), ArraySeq.create(new Object[] { Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 2: 
/* 1825 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), ArraySeq.create(new Object[] { Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 3: 
/* 1843 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), ArraySeq.create(new Object[] { Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 4: 
/* 1861 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), ArraySeq.create(new Object[] { Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 5: 
/* 1879 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), ArraySeq.create(new Object[] { Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 6: 
/* 1897 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), ArraySeq.create(new Object[] { Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 7: 
/* 1915 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), ArraySeq.create(new Object[] { Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 8: 
/* 1933 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), ArraySeq.create(new Object[] { Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 9: 
/* 1951 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), ArraySeq.create(new Object[] { Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 10: 
/* 1969 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), ArraySeq.create(new Object[] { Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 11: 
/* 1987 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), ArraySeq.create(new Object[] { Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 12: 
/* 2005 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), ArraySeq.create(new Object[] { Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 13: 
/* 2023 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), ArraySeq.create(new Object[] { Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 14: 
/* 2041 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), ArraySeq.create(new Object[] { Util.ret1(arg15, arg15 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 15: 
/* 2059 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), null);
/*      */     }
/*      */     
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2077 */     return throwArity(15);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12, Object arg13, Object arg14, Object arg15, Object arg16)
/*      */   {
/* 2085 */     switch (getRequiredArity())
/*      */     {
/*      */     case 0: 
/* 2088 */       return doInvoke(ArraySeq.create(new Object[] { Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 1: 
/* 2107 */       return doInvoke(Util.ret1(arg1, arg1 = null), ArraySeq.create(new Object[] { Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 2: 
/* 2126 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), ArraySeq.create(new Object[] { Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 3: 
/* 2145 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), ArraySeq.create(new Object[] { Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 4: 
/* 2164 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), ArraySeq.create(new Object[] { Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 5: 
/* 2183 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), ArraySeq.create(new Object[] { Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 6: 
/* 2202 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), ArraySeq.create(new Object[] { Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 7: 
/* 2221 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), ArraySeq.create(new Object[] { Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 8: 
/* 2240 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), ArraySeq.create(new Object[] { Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 9: 
/* 2259 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), ArraySeq.create(new Object[] { Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 10: 
/* 2278 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), ArraySeq.create(new Object[] { Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 11: 
/* 2297 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), ArraySeq.create(new Object[] { Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 12: 
/* 2316 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), ArraySeq.create(new Object[] { Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 13: 
/* 2335 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), ArraySeq.create(new Object[] { Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 14: 
/* 2354 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), ArraySeq.create(new Object[] { Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 15: 
/* 2373 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), ArraySeq.create(new Object[] { Util.ret1(arg16, arg16 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 16: 
/* 2392 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), null);
/*      */     }
/*      */     
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2411 */     return throwArity(16);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12, Object arg13, Object arg14, Object arg15, Object arg16, Object arg17)
/*      */   {
/* 2419 */     switch (getRequiredArity())
/*      */     {
/*      */     case 0: 
/* 2422 */       return doInvoke(ArraySeq.create(new Object[] { Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 1: 
/* 2442 */       return doInvoke(Util.ret1(arg1, arg1 = null), ArraySeq.create(new Object[] { Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 2: 
/* 2462 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), ArraySeq.create(new Object[] { Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 3: 
/* 2482 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), ArraySeq.create(new Object[] { Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 4: 
/* 2502 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), ArraySeq.create(new Object[] { Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 5: 
/* 2522 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), ArraySeq.create(new Object[] { Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 6: 
/* 2542 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), ArraySeq.create(new Object[] { Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 7: 
/* 2562 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), ArraySeq.create(new Object[] { Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 8: 
/* 2582 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), ArraySeq.create(new Object[] { Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 9: 
/* 2602 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), ArraySeq.create(new Object[] { Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 10: 
/* 2622 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), ArraySeq.create(new Object[] { Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 11: 
/* 2642 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), ArraySeq.create(new Object[] { Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 12: 
/* 2662 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), ArraySeq.create(new Object[] { Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 13: 
/* 2682 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), ArraySeq.create(new Object[] { Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 14: 
/* 2702 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), ArraySeq.create(new Object[] { Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 15: 
/* 2722 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), ArraySeq.create(new Object[] { Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 16: 
/* 2742 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), ArraySeq.create(new Object[] { Util.ret1(arg17, arg17 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 17: 
/* 2762 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), null);
/*      */     }
/*      */     
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2782 */     return throwArity(17);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12, Object arg13, Object arg14, Object arg15, Object arg16, Object arg17, Object arg18)
/*      */   {
/* 2790 */     switch (getRequiredArity())
/*      */     {
/*      */     case 0: 
/* 2793 */       return doInvoke(ArraySeq.create(new Object[] { Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 1: 
/* 2814 */       return doInvoke(Util.ret1(arg1, arg1 = null), ArraySeq.create(new Object[] { Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 2: 
/* 2835 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), ArraySeq.create(new Object[] { Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 3: 
/* 2856 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), ArraySeq.create(new Object[] { Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 4: 
/* 2877 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), ArraySeq.create(new Object[] { Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 5: 
/* 2898 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), ArraySeq.create(new Object[] { Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 6: 
/* 2919 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), ArraySeq.create(new Object[] { Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 7: 
/* 2941 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), ArraySeq.create(new Object[] { Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 8: 
/* 2962 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), ArraySeq.create(new Object[] { Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 9: 
/* 2983 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), ArraySeq.create(new Object[] { Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 10: 
/* 3004 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), ArraySeq.create(new Object[] { Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 11: 
/* 3025 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), ArraySeq.create(new Object[] { Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 12: 
/* 3046 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), ArraySeq.create(new Object[] { Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 13: 
/* 3067 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), ArraySeq.create(new Object[] { Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 14: 
/* 3088 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), ArraySeq.create(new Object[] { Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 15: 
/* 3109 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), ArraySeq.create(new Object[] { Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 16: 
/* 3130 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), ArraySeq.create(new Object[] { Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 17: 
/* 3151 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), ArraySeq.create(new Object[] { Util.ret1(arg18, arg18 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 18: 
/* 3172 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null), null);
/*      */     }
/*      */     
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3193 */     return throwArity(18);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12, Object arg13, Object arg14, Object arg15, Object arg16, Object arg17, Object arg18, Object arg19)
/*      */   {
/* 3201 */     switch (getRequiredArity())
/*      */     {
/*      */     case 0: 
/* 3204 */       return doInvoke(ArraySeq.create(new Object[] { Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null), Util.ret1(arg19, arg19 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 1: 
/* 3226 */       ISeq packed = PersistentList.EMPTY;
/* 3227 */       return doInvoke(Util.ret1(arg1, arg1 = null), ArraySeq.create(new Object[] { Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null), Util.ret1(arg19, arg19 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 2: 
/* 3247 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), ArraySeq.create(new Object[] { Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null), Util.ret1(arg19, arg19 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 3: 
/* 3269 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), ArraySeq.create(new Object[] { Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null), Util.ret1(arg19, arg19 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 4: 
/* 3291 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), ArraySeq.create(new Object[] { Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null), Util.ret1(arg19, arg19 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 5: 
/* 3313 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), ArraySeq.create(new Object[] { Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null), Util.ret1(arg19, arg19 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 6: 
/* 3336 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), ArraySeq.create(new Object[] { Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null), Util.ret1(arg19, arg19 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 7: 
/* 3359 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), ArraySeq.create(new Object[] { Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null), Util.ret1(arg19, arg19 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 8: 
/* 3382 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), ArraySeq.create(new Object[] { Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null), Util.ret1(arg19, arg19 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 9: 
/* 3405 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), ArraySeq.create(new Object[] { Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null), Util.ret1(arg19, arg19 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 10: 
/* 3427 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), ArraySeq.create(new Object[] { Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null), Util.ret1(arg19, arg19 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 11: 
/* 3449 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), ArraySeq.create(new Object[] { Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null), Util.ret1(arg19, arg19 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 12: 
/* 3471 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), ArraySeq.create(new Object[] { Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null), Util.ret1(arg19, arg19 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 13: 
/* 3493 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), ArraySeq.create(new Object[] { Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null), Util.ret1(arg19, arg19 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 14: 
/* 3515 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), ArraySeq.create(new Object[] { Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null), Util.ret1(arg19, arg19 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 15: 
/* 3537 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), ArraySeq.create(new Object[] { Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null), Util.ret1(arg19, arg19 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 16: 
/* 3559 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), ArraySeq.create(new Object[] { Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null), Util.ret1(arg19, arg19 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 17: 
/* 3581 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), ArraySeq.create(new Object[] { Util.ret1(arg18, arg18 = null), Util.ret1(arg19, arg19 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 18: 
/* 3603 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null), ArraySeq.create(new Object[] { Util.ret1(arg19, arg19 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 19: 
/* 3625 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null), Util.ret1(arg19, arg19 = null), null);
/*      */     }
/*      */     
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3647 */     return throwArity(19);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12, Object arg13, Object arg14, Object arg15, Object arg16, Object arg17, Object arg18, Object arg19, Object arg20)
/*      */   {
/* 3656 */     switch (getRequiredArity())
/*      */     {
/*      */     case 0: 
/* 3659 */       return doInvoke(ArraySeq.create(new Object[] { Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null), Util.ret1(arg19, arg19 = null), Util.ret1(arg20, arg20 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 1: 
/* 3682 */       return doInvoke(Util.ret1(arg1, arg1 = null), ArraySeq.create(new Object[] { Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null), Util.ret1(arg19, arg19 = null), Util.ret1(arg20, arg20 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 2: 
/* 3705 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), ArraySeq.create(new Object[] { Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null), Util.ret1(arg19, arg19 = null), Util.ret1(arg20, arg20 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 3: 
/* 3728 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), ArraySeq.create(new Object[] { Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null), Util.ret1(arg19, arg19 = null), Util.ret1(arg20, arg20 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 4: 
/* 3736 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), ArraySeq.create(new Object[] { Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null), Util.ret1(arg19, arg19 = null), Util.ret1(arg20, arg20 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 5: 
/* 3744 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), ArraySeq.create(new Object[] { Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null), Util.ret1(arg19, arg19 = null), Util.ret1(arg20, arg20 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 6: 
/* 3754 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), ArraySeq.create(new Object[] { Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null), Util.ret1(arg19, arg19 = null), Util.ret1(arg20, arg20 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 7: 
/* 3762 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), ArraySeq.create(new Object[] { Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null), Util.ret1(arg19, arg19 = null), Util.ret1(arg20, arg20 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 8: 
/* 3772 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), ArraySeq.create(new Object[] { Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null), Util.ret1(arg19, arg19 = null), Util.ret1(arg20, arg20 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 9: 
/* 3782 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), ArraySeq.create(new Object[] { Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null), Util.ret1(arg19, arg19 = null), Util.ret1(arg20, arg20 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 10: 
/* 3790 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), ArraySeq.create(new Object[] { Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null), Util.ret1(arg19, arg19 = null), Util.ret1(arg20, arg20 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 11: 
/* 3799 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), ArraySeq.create(new Object[] { Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null), Util.ret1(arg19, arg19 = null), Util.ret1(arg20, arg20 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 12: 
/* 3809 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), ArraySeq.create(new Object[] { Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null), Util.ret1(arg19, arg19 = null), Util.ret1(arg20, arg20 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 13: 
/* 3817 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), ArraySeq.create(new Object[] { Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null), Util.ret1(arg19, arg19 = null), Util.ret1(arg20, arg20 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 14: 
/* 3826 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), ArraySeq.create(new Object[] { Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null), Util.ret1(arg19, arg19 = null), Util.ret1(arg20, arg20 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 15: 
/* 3834 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), ArraySeq.create(new Object[] { Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null), Util.ret1(arg19, arg19 = null), Util.ret1(arg20, arg20 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 16: 
/* 3842 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), ArraySeq.create(new Object[] { Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null), Util.ret1(arg19, arg19 = null), Util.ret1(arg20, arg20 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 17: 
/* 3850 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), ArraySeq.create(new Object[] { Util.ret1(arg18, arg18 = null), Util.ret1(arg19, arg19 = null), Util.ret1(arg20, arg20 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 18: 
/* 3858 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null), ArraySeq.create(new Object[] { Util.ret1(arg19, arg19 = null), Util.ret1(arg20, arg20 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 19: 
/* 3866 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null), Util.ret1(arg19, arg19 = null), ArraySeq.create(new Object[] { Util.ret1(arg20, arg20 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 20: 
/* 3874 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null), Util.ret1(arg19, arg19 = null), Util.ret1(arg20, arg20 = null), null);
/*      */     }
/*      */     
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3882 */     return throwArity(20);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12, Object arg13, Object arg14, Object arg15, Object arg16, Object arg17, Object arg18, Object arg19, Object arg20, Object... args)
/*      */   {
/* 3891 */     switch (getRequiredArity())
/*      */     {
/*      */     case 0: 
/* 3894 */       return doInvoke(ontoArrayPrepend(args, new Object[] { Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null), Util.ret1(arg19, arg19 = null), Util.ret1(arg20, arg20 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 1: 
/* 3902 */       return doInvoke(Util.ret1(arg1, arg1 = null), ontoArrayPrepend(args, new Object[] { Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null), Util.ret1(arg19, arg19 = null), Util.ret1(arg20, arg20 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 2: 
/* 3913 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), ontoArrayPrepend(args, new Object[] { Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null), Util.ret1(arg19, arg19 = null), Util.ret1(arg20, arg20 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 3: 
/* 3924 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), ontoArrayPrepend(args, new Object[] { Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null), Util.ret1(arg19, arg19 = null), Util.ret1(arg20, arg20 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 4: 
/* 3932 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), ontoArrayPrepend(args, new Object[] { Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null), Util.ret1(arg19, arg19 = null), Util.ret1(arg20, arg20 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 5: 
/* 3940 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), ontoArrayPrepend(args, new Object[] { Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null), Util.ret1(arg19, arg19 = null), Util.ret1(arg20, arg20 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 6: 
/* 3950 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), ontoArrayPrepend(args, new Object[] { Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null), Util.ret1(arg19, arg19 = null), Util.ret1(arg20, arg20 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 7: 
/* 3958 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), ontoArrayPrepend(args, new Object[] { Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null), Util.ret1(arg19, arg19 = null), Util.ret1(arg20, arg20 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 8: 
/* 3968 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), ontoArrayPrepend(args, new Object[] { Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null), Util.ret1(arg19, arg19 = null), Util.ret1(arg20, arg20 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 9: 
/* 3977 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), ontoArrayPrepend(args, new Object[] { Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null), Util.ret1(arg19, arg19 = null), Util.ret1(arg20, arg20 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 10: 
/* 3985 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), ontoArrayPrepend(args, new Object[] { Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null), Util.ret1(arg19, arg19 = null), Util.ret1(arg20, arg20 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 11: 
/* 3994 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), ontoArrayPrepend(args, new Object[] { Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null), Util.ret1(arg19, arg19 = null), Util.ret1(arg20, arg20 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 12: 
/* 4004 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), ontoArrayPrepend(args, new Object[] { Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null), Util.ret1(arg19, arg19 = null), Util.ret1(arg20, arg20 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 13: 
/* 4013 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), ontoArrayPrepend(args, new Object[] { Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null), Util.ret1(arg19, arg19 = null), Util.ret1(arg20, arg20 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 14: 
/* 4022 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), ontoArrayPrepend(args, new Object[] { Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null), Util.ret1(arg19, arg19 = null), Util.ret1(arg20, arg20 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 15: 
/* 4030 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), ontoArrayPrepend(args, new Object[] { Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null), Util.ret1(arg19, arg19 = null), Util.ret1(arg20, arg20 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 16: 
/* 4038 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), ontoArrayPrepend(args, new Object[] { Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null), Util.ret1(arg19, arg19 = null), Util.ret1(arg20, arg20 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 17: 
/* 4046 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), ontoArrayPrepend(args, new Object[] { Util.ret1(arg18, arg18 = null), Util.ret1(arg19, arg19 = null), Util.ret1(arg20, arg20 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 18: 
/* 4054 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null), ontoArrayPrepend(args, new Object[] { Util.ret1(arg19, arg19 = null), Util.ret1(arg20, arg20 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 19: 
/* 4062 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null), Util.ret1(arg19, arg19 = null), ontoArrayPrepend(args, new Object[] { Util.ret1(arg20, arg20 = null) }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 20: 
/* 4070 */       return doInvoke(Util.ret1(arg1, arg1 = null), Util.ret1(arg2, arg2 = null), Util.ret1(arg3, arg3 = null), Util.ret1(arg4, arg4 = null), Util.ret1(arg5, arg5 = null), Util.ret1(arg6, arg6 = null), Util.ret1(arg7, arg7 = null), Util.ret1(arg8, arg8 = null), Util.ret1(arg9, arg9 = null), Util.ret1(arg10, arg10 = null), Util.ret1(arg11, arg11 = null), Util.ret1(arg12, arg12 = null), Util.ret1(arg13, arg13 = null), Util.ret1(arg14, arg14 = null), Util.ret1(arg15, arg15 = null), Util.ret1(arg16, arg16 = null), Util.ret1(arg17, arg17 = null), Util.ret1(arg18, arg18 = null), Util.ret1(arg19, arg19 = null), Util.ret1(arg20, arg20 = null), ArraySeq.create(args));
/*      */     }
/*      */     
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4078 */     return throwArity(21);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected static ISeq ontoArrayPrepend(Object[] array, Object... args)
/*      */   {
/* 4085 */     ISeq ret = ArraySeq.create(array);
/* 4086 */     for (int i = args.length - 1; i >= 0; i--)
/* 4087 */       ret = RT.cons(args[i], ret);
/* 4088 */     return ret;
/*      */   }
/*      */   
/*      */   protected static ISeq findKey(Object key, ISeq args) {
/* 4092 */     while (args != null)
/*      */     {
/* 4094 */       if (key == args.first())
/* 4095 */         return args.next();
/* 4096 */       args = RT.next(args);
/* 4097 */       args = RT.next(args);
/*      */     }
/* 4099 */     return null;
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\RestFn.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */