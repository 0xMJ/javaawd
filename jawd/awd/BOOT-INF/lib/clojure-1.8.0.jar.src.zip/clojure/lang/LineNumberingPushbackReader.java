/*    */ package clojure.lang;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.LineNumberReader;
/*    */ import java.io.PushbackReader;
/*    */ import java.io.Reader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LineNumberingPushbackReader
/*    */   extends PushbackReader
/*    */ {
/*    */   private static final int newline = 10;
/* 28 */   private boolean _atLineStart = true;
/*    */   private boolean _prev;
/* 30 */   private int _columnNumber = 1;
/*    */   
/*    */   public LineNumberingPushbackReader(Reader r) {
/* 33 */     super(new LineNumberReader(r));
/*    */   }
/*    */   
/*    */   public LineNumberingPushbackReader(Reader r, int size) {
/* 37 */     super(new LineNumberReader(r, size));
/*    */   }
/*    */   
/*    */   public int getLineNumber() {
/* 41 */     return ((LineNumberReader)this.in).getLineNumber() + 1;
/*    */   }
/*    */   
/* 44 */   public void setLineNumber(int line) { ((LineNumberReader)this.in).setLineNumber(line - 1); }
/*    */   
/*    */   public int getColumnNumber() {
/* 47 */     return this._columnNumber;
/*    */   }
/*    */   
/*    */   public int read() throws IOException {
/* 51 */     int c = super.read();
/* 52 */     this._prev = this._atLineStart;
/* 53 */     if ((c == 10) || (c == -1))
/*    */     {
/* 55 */       this._atLineStart = true;
/* 56 */       this._columnNumber = 1;
/*    */     }
/*    */     else
/*    */     {
/* 60 */       this._atLineStart = false;
/* 61 */       this._columnNumber += 1;
/*    */     }
/* 63 */     return c;
/*    */   }
/*    */   
/*    */   public void unread(int c) throws IOException {
/* 67 */     super.unread(c);
/* 68 */     this._atLineStart = this._prev;
/* 69 */     this._columnNumber -= 1;
/*    */   }
/*    */   
/*    */   public String readLine() throws IOException {
/* 73 */     int c = read();
/*    */     String line;
/* 75 */     switch (c) {
/*    */     case -1: 
/* 77 */       line = null;
/* 78 */       break;
/*    */     case 10: 
/* 80 */       line = "";
/* 81 */       break;
/*    */     default: 
/* 83 */       String first = String.valueOf((char)c);
/* 84 */       String rest = ((LineNumberReader)this.in).readLine();
/* 85 */       line = first + rest;
/* 86 */       this._prev = false;
/* 87 */       this._atLineStart = true;
/* 88 */       this._columnNumber = 1;
/*    */     }
/*    */     
/* 91 */     return line;
/*    */   }
/*    */   
/*    */   public boolean atLineStart() {
/* 95 */     return this._atLineStart;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\LineNumberingPushbackReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */