package clojure.lang;

public abstract interface Associative
  extends IPersistentCollection, ILookup
{
  public abstract boolean containsKey(Object paramObject);
  
  public abstract IMapEntry entryAt(Object paramObject);
  
  public abstract Associative assoc(Object paramObject1, Object paramObject2);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\Associative.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */