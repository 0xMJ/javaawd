/*    */ package clojure.lang;
/*    */ 
/*    */ import java.util.Map.Entry;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ARef
/*    */   extends AReference
/*    */   implements IRef
/*    */ {
/* 18 */   protected volatile IFn validator = null;
/* 19 */   private volatile IPersistentMap watches = PersistentHashMap.EMPTY;
/*    */   
/*    */ 
/*    */   public ARef() {}
/*    */   
/*    */   public ARef(IPersistentMap meta)
/*    */   {
/* 26 */     super(meta);
/*    */   }
/*    */   
/*    */   void validate(IFn vf, Object val)
/*    */   {
/*    */     try {
/* 32 */       if ((vf != null) && (!RT.booleanCast(vf.invoke(val)))) {
/* 33 */         throw new IllegalStateException("Invalid reference state");
/*    */       }
/*    */     }
/*    */     catch (RuntimeException re) {
/* 37 */       throw re;
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/* 41 */       throw new IllegalStateException("Invalid reference state", e);
/*    */     }
/*    */   }
/*    */   
/*    */   void validate(Object val) {
/* 46 */     validate(this.validator, val);
/*    */   }
/*    */   
/*    */   public void setValidator(IFn vf) {
/* 50 */     validate(vf, deref());
/* 51 */     this.validator = vf;
/*    */   }
/*    */   
/*    */   public IFn getValidator() {
/* 55 */     return this.validator;
/*    */   }
/*    */   
/*    */   public IPersistentMap getWatches() {
/* 59 */     return this.watches;
/*    */   }
/*    */   
/*    */   public synchronized IRef addWatch(Object key, IFn callback) {
/* 63 */     this.watches = this.watches.assoc(key, callback);
/* 64 */     return this;
/*    */   }
/*    */   
/*    */   public synchronized IRef removeWatch(Object key) {
/* 68 */     this.watches = this.watches.without(key);
/* 69 */     return this;
/*    */   }
/*    */   
/*    */   public void notifyWatches(Object oldval, Object newval) {
/* 73 */     IPersistentMap ws = this.watches;
/* 74 */     if (ws.count() > 0)
/*    */     {
/* 76 */       for (ISeq s = ws.seq(); s != null; s = s.next())
/*    */       {
/* 78 */         Map.Entry e = (Map.Entry)s.first();
/* 79 */         IFn fn = (IFn)e.getValue();
/* 80 */         if (fn != null) {
/* 81 */           fn.invoke(e.getKey(), this, oldval, newval);
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\ARef.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */