/*     */ package clojure.lang;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PersistentVector
/*     */   extends APersistentVector
/*     */   implements IObj, IEditableCollection, IReduce, IKVReduce
/*     */ {
/*     */   public static class Node
/*     */     implements Serializable
/*     */   {
/*     */     public final transient AtomicReference<Thread> edit;
/*     */     public final Object[] array;
/*     */     
/*     */     public Node(AtomicReference<Thread> edit, Object[] array)
/*     */     {
/*  29 */       this.edit = edit;
/*  30 */       this.array = array;
/*     */     }
/*     */     
/*     */     Node(AtomicReference<Thread> edit) {
/*  34 */       this.edit = edit;
/*  35 */       this.array = new Object[32];
/*     */     }
/*     */   }
/*     */   
/*  39 */   static final AtomicReference<Thread> NOEDIT = new AtomicReference(null);
/*  40 */   public static final Node EMPTY_NODE = new Node(NOEDIT, new Object[32]);
/*     */   
/*     */   final int cnt;
/*     */   
/*     */   public final int shift;
/*     */   
/*     */   public final Node root;
/*     */   public final Object[] tail;
/*     */   final IPersistentMap _meta;
/*  49 */   public static final PersistentVector EMPTY = new PersistentVector(0, 5, EMPTY_NODE, new Object[0]);
/*     */   
/*  51 */   private static final IFn TRANSIENT_VECTOR_CONJ = new AFn() {
/*     */     public Object invoke(Object coll, Object val) {
/*  53 */       return ((ITransientVector)coll).conj(val);
/*     */     }
/*     */     
/*  56 */     public Object invoke(Object coll) { return coll; }
/*     */   };
/*     */   
/*     */   public static PersistentVector adopt(Object[] items)
/*     */   {
/*  61 */     return new PersistentVector(items.length, 5, EMPTY_NODE, items);
/*     */   }
/*     */   
/*     */   public static PersistentVector create(IReduceInit items) {
/*  65 */     TransientVector ret = EMPTY.asTransient();
/*  66 */     items.reduce(TRANSIENT_VECTOR_CONJ, ret);
/*  67 */     return ret.persistent();
/*     */   }
/*     */   
/*     */   public static PersistentVector create(ISeq items) {
/*  71 */     Object[] arr = new Object[32];
/*  72 */     int i = 0;
/*  73 */     for (; (items != null) && (i < 32); items = items.next()) {
/*  74 */       arr[(i++)] = items.first();
/*     */     }
/*  76 */     if (items != null) {
/*  77 */       PersistentVector start = new PersistentVector(32, 5, EMPTY_NODE, arr);
/*  78 */       TransientVector ret = start.asTransient();
/*  79 */       for (; items != null; items = items.next())
/*  80 */         ret = ret.conj(items.first());
/*  81 */       return ret.persistent(); }
/*  82 */     if (i == 32) {
/*  83 */       return new PersistentVector(32, 5, EMPTY_NODE, arr);
/*     */     }
/*  85 */     Object[] arr2 = new Object[i];
/*  86 */     System.arraycopy(arr, 0, arr2, 0, i);
/*  87 */     return new PersistentVector(i, 5, EMPTY_NODE, arr2);
/*     */   }
/*     */   
/*     */   public static PersistentVector create(List list)
/*     */   {
/*  92 */     int size = list.size();
/*  93 */     if (size <= 32) {
/*  94 */       return new PersistentVector(size, 5, EMPTY_NODE, list.toArray());
/*     */     }
/*  96 */     TransientVector ret = EMPTY.asTransient();
/*  97 */     for (int i = 0; i < size; i++)
/*  98 */       ret = ret.conj(list.get(i));
/*  99 */     return ret.persistent();
/*     */   }
/*     */   
/*     */   public static PersistentVector create(Iterable items)
/*     */   {
/* 104 */     if ((items instanceof ArrayList)) {
/* 105 */       return create((ArrayList)items);
/*     */     }
/* 107 */     Iterator iter = items.iterator();
/* 108 */     TransientVector ret = EMPTY.asTransient();
/* 109 */     while (iter.hasNext())
/* 110 */       ret = ret.conj(iter.next());
/* 111 */     return ret.persistent();
/*     */   }
/*     */   
/*     */   public static PersistentVector create(Object... items) {
/* 115 */     TransientVector ret = EMPTY.asTransient();
/* 116 */     for (Object item : items)
/* 117 */       ret = ret.conj(item);
/* 118 */     return ret.persistent();
/*     */   }
/*     */   
/*     */   PersistentVector(int cnt, int shift, Node root, Object[] tail) {
/* 122 */     this._meta = null;
/* 123 */     this.cnt = cnt;
/* 124 */     this.shift = shift;
/* 125 */     this.root = root;
/* 126 */     this.tail = tail;
/*     */   }
/*     */   
/*     */   PersistentVector(IPersistentMap meta, int cnt, int shift, Node root, Object[] tail)
/*     */   {
/* 131 */     this._meta = meta;
/* 132 */     this.cnt = cnt;
/* 133 */     this.shift = shift;
/* 134 */     this.root = root;
/* 135 */     this.tail = tail;
/*     */   }
/*     */   
/*     */   public TransientVector asTransient() {
/* 139 */     return new TransientVector(this);
/*     */   }
/*     */   
/*     */   final int tailoff() {
/* 143 */     if (this.cnt < 32)
/* 144 */       return 0;
/* 145 */     return this.cnt - 1 >>> 5 << 5;
/*     */   }
/*     */   
/*     */   public Object[] arrayFor(int i) {
/* 149 */     if ((i >= 0) && (i < this.cnt))
/*     */     {
/* 151 */       if (i >= tailoff())
/* 152 */         return this.tail;
/* 153 */       Node node = this.root;
/* 154 */       for (int level = this.shift; level > 0; level -= 5)
/* 155 */         node = (Node)node.array[(i >>> level & 0x1F)];
/* 156 */       return node.array;
/*     */     }
/* 158 */     throw new IndexOutOfBoundsException();
/*     */   }
/*     */   
/*     */   public Object nth(int i) {
/* 162 */     Object[] node = arrayFor(i);
/* 163 */     return node[(i & 0x1F)];
/*     */   }
/*     */   
/*     */   public Object nth(int i, Object notFound) {
/* 167 */     if ((i >= 0) && (i < this.cnt))
/* 168 */       return nth(i);
/* 169 */     return notFound;
/*     */   }
/*     */   
/*     */   public PersistentVector assocN(int i, Object val) {
/* 173 */     if ((i >= 0) && (i < this.cnt))
/*     */     {
/* 175 */       if (i >= tailoff())
/*     */       {
/* 177 */         Object[] newTail = new Object[this.tail.length];
/* 178 */         System.arraycopy(this.tail, 0, newTail, 0, this.tail.length);
/* 179 */         newTail[(i & 0x1F)] = val;
/*     */         
/* 181 */         return new PersistentVector(meta(), this.cnt, this.shift, this.root, newTail);
/*     */       }
/*     */       
/* 184 */       return new PersistentVector(meta(), this.cnt, this.shift, doAssoc(this.shift, this.root, i, val), this.tail);
/*     */     }
/* 186 */     if (i == this.cnt)
/* 187 */       return cons(val);
/* 188 */     throw new IndexOutOfBoundsException();
/*     */   }
/*     */   
/*     */   private static Node doAssoc(int level, Node node, int i, Object val) {
/* 192 */     Node ret = new Node(node.edit, (Object[])node.array.clone());
/* 193 */     if (level == 0)
/*     */     {
/* 195 */       ret.array[(i & 0x1F)] = val;
/*     */     }
/*     */     else
/*     */     {
/* 199 */       int subidx = i >>> level & 0x1F;
/* 200 */       ret.array[subidx] = doAssoc(level - 5, (Node)node.array[subidx], i, val);
/*     */     }
/* 202 */     return ret;
/*     */   }
/*     */   
/*     */   public int count() {
/* 206 */     return this.cnt;
/*     */   }
/*     */   
/*     */   public PersistentVector withMeta(IPersistentMap meta) {
/* 210 */     return new PersistentVector(meta, this.cnt, this.shift, this.root, this.tail);
/*     */   }
/*     */   
/*     */   public IPersistentMap meta() {
/* 214 */     return this._meta;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public PersistentVector cons(Object val)
/*     */   {
/* 221 */     if (this.cnt - tailoff() < 32)
/*     */     {
/* 223 */       Object[] newTail = new Object[this.tail.length + 1];
/* 224 */       System.arraycopy(this.tail, 0, newTail, 0, this.tail.length);
/* 225 */       newTail[this.tail.length] = val;
/* 226 */       return new PersistentVector(meta(), this.cnt + 1, this.shift, this.root, newTail);
/*     */     }
/*     */     
/*     */ 
/* 230 */     Node tailnode = new Node(this.root.edit, this.tail);
/* 231 */     int newshift = this.shift;
/*     */     Node newroot;
/* 233 */     if (this.cnt >>> 5 > 1 << this.shift)
/*     */     {
/* 235 */       Node newroot = new Node(this.root.edit);
/* 236 */       newroot.array[0] = this.root;
/* 237 */       newroot.array[1] = newPath(this.root.edit, this.shift, tailnode);
/* 238 */       newshift += 5;
/*     */     }
/*     */     else {
/* 241 */       newroot = pushTail(this.shift, this.root, tailnode); }
/* 242 */     return new PersistentVector(meta(), this.cnt + 1, newshift, newroot, new Object[] { val });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private Node pushTail(int level, Node parent, Node tailnode)
/*     */   {
/* 250 */     int subidx = this.cnt - 1 >>> level & 0x1F;
/* 251 */     Node ret = new Node(parent.edit, (Object[])parent.array.clone());
/*     */     Node nodeToInsert;
/* 253 */     Node nodeToInsert; if (level == 5)
/*     */     {
/* 255 */       nodeToInsert = tailnode;
/*     */     }
/*     */     else
/*     */     {
/* 259 */       Node child = (Node)parent.array[subidx];
/* 260 */       nodeToInsert = child != null ? pushTail(level - 5, child, tailnode) : newPath(this.root.edit, level - 5, tailnode);
/*     */     }
/*     */     
/*     */ 
/* 264 */     ret.array[subidx] = nodeToInsert;
/* 265 */     return ret;
/*     */   }
/*     */   
/*     */   private static Node newPath(AtomicReference<Thread> edit, int level, Node node) {
/* 269 */     if (level == 0)
/* 270 */       return node;
/* 271 */     Node ret = new Node(edit);
/* 272 */     ret.array[0] = newPath(edit, level - 5, node);
/* 273 */     return ret;
/*     */   }
/*     */   
/*     */   public IChunkedSeq chunkedSeq() {
/* 277 */     if (count() == 0)
/* 278 */       return null;
/* 279 */     return new ChunkedSeq(this, 0, 0);
/*     */   }
/*     */   
/*     */   public ISeq seq() {
/* 283 */     return chunkedSeq();
/*     */   }
/*     */   
/*     */   Iterator rangedIterator(final int start, final int end)
/*     */   {
/* 288 */     new Iterator() {
/* 289 */       int i = start;
/* 290 */       int base = this.i - this.i % 32;
/* 291 */       Object[] array = start < PersistentVector.this.count() ? PersistentVector.this.arrayFor(this.i) : null;
/*     */       
/*     */       public boolean hasNext() {
/* 294 */         return this.i < end;
/*     */       }
/*     */       
/*     */       public Object next() {
/* 298 */         if (this.i < end) {
/* 299 */           if (this.i - this.base == 32) {
/* 300 */             this.array = PersistentVector.this.arrayFor(this.i);
/* 301 */             this.base += 32;
/*     */           }
/* 303 */           return this.array[(this.i++ & 0x1F)];
/*     */         }
/* 305 */         throw new NoSuchElementException();
/*     */       }
/*     */       
/*     */       public void remove()
/*     */       {
/* 310 */         throw new UnsupportedOperationException();
/*     */       }
/*     */     };
/*     */   }
/*     */   
/* 315 */   public Iterator iterator() { return rangedIterator(0, count()); }
/*     */   
/*     */   public Object reduce(IFn f) {
/*     */     Object init;
/* 319 */     if (this.cnt > 0) {
/* 320 */       init = arrayFor(0)[0];
/*     */     } else
/* 322 */       return f.invoke();
/* 323 */     Object init; int step = 0;
/* 324 */     for (int i = 0; i < this.cnt; i += step) {
/* 325 */       Object[] array = arrayFor(i);
/* 326 */       for (int j = i == 0 ? 1 : 0; j < array.length; j++) {
/* 327 */         init = f.invoke(init, array[j]);
/* 328 */         if (RT.isReduced(init))
/* 329 */           return ((IDeref)init).deref();
/*     */       }
/* 331 */       step = array.length;
/*     */     }
/* 333 */     return init;
/*     */   }
/*     */   
/*     */   public Object reduce(IFn f, Object init) {
/* 337 */     int step = 0;
/* 338 */     for (int i = 0; i < this.cnt; i += step) {
/* 339 */       Object[] array = arrayFor(i);
/* 340 */       for (int j = 0; j < array.length; j++) {
/* 341 */         init = f.invoke(init, array[j]);
/* 342 */         if (RT.isReduced(init))
/* 343 */           return ((IDeref)init).deref();
/*     */       }
/* 345 */       step = array.length;
/*     */     }
/* 347 */     return init;
/*     */   }
/*     */   
/*     */   public Object kvreduce(IFn f, Object init) {
/* 351 */     int step = 0;
/* 352 */     for (int i = 0; i < this.cnt; i += step) {
/* 353 */       Object[] array = arrayFor(i);
/* 354 */       for (int j = 0; j < array.length; j++) {
/* 355 */         init = f.invoke(init, Integer.valueOf(j + i), array[j]);
/* 356 */         if (RT.isReduced(init))
/* 357 */           return ((IDeref)init).deref();
/*     */       }
/* 359 */       step = array.length;
/*     */     }
/* 361 */     return init;
/*     */   }
/*     */   
/*     */   public static final class ChunkedSeq extends ASeq implements IChunkedSeq, Counted
/*     */   {
/*     */     public final PersistentVector vec;
/*     */     final Object[] node;
/*     */     final int i;
/*     */     public final int offset;
/*     */     
/*     */     public ChunkedSeq(PersistentVector vec, int i, int offset) {
/* 372 */       this.vec = vec;
/* 373 */       this.i = i;
/* 374 */       this.offset = offset;
/* 375 */       this.node = vec.arrayFor(i);
/*     */     }
/*     */     
/*     */     ChunkedSeq(IPersistentMap meta, PersistentVector vec, Object[] node, int i, int offset) {
/* 379 */       super();
/* 380 */       this.vec = vec;
/* 381 */       this.node = node;
/* 382 */       this.i = i;
/* 383 */       this.offset = offset;
/*     */     }
/*     */     
/*     */     ChunkedSeq(PersistentVector vec, Object[] node, int i, int offset) {
/* 387 */       this.vec = vec;
/* 388 */       this.node = node;
/* 389 */       this.i = i;
/* 390 */       this.offset = offset;
/*     */     }
/*     */     
/*     */     public IChunk chunkedFirst() {
/* 394 */       return new ArrayChunk(this.node, this.offset);
/*     */     }
/*     */     
/*     */     public ISeq chunkedNext() {
/* 398 */       if (this.i + this.node.length < this.vec.cnt)
/* 399 */         return new ChunkedSeq(this.vec, this.i + this.node.length, 0);
/* 400 */       return null;
/*     */     }
/*     */     
/*     */     public ISeq chunkedMore() {
/* 404 */       ISeq s = chunkedNext();
/* 405 */       if (s == null)
/* 406 */         return PersistentList.EMPTY;
/* 407 */       return s;
/*     */     }
/*     */     
/*     */     public Obj withMeta(IPersistentMap meta) {
/* 411 */       if (meta == this._meta)
/* 412 */         return this;
/* 413 */       return new ChunkedSeq(meta, this.vec, this.node, this.i, this.offset);
/*     */     }
/*     */     
/*     */     public Object first() {
/* 417 */       return this.node[this.offset];
/*     */     }
/*     */     
/*     */     public ISeq next() {
/* 421 */       if (this.offset + 1 < this.node.length)
/* 422 */         return new ChunkedSeq(this.vec, this.node, this.i, this.offset + 1);
/* 423 */       return chunkedNext();
/*     */     }
/*     */     
/*     */     public int count() {
/* 427 */       return this.vec.cnt - (this.i + this.offset);
/*     */     }
/*     */   }
/*     */   
/*     */   public IPersistentCollection empty() {
/* 432 */     return EMPTY.withMeta(meta());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PersistentVector pop()
/*     */   {
/* 467 */     if (this.cnt == 0)
/* 468 */       throw new IllegalStateException("Can't pop empty vector");
/* 469 */     if (this.cnt == 1) {
/* 470 */       return EMPTY.withMeta(meta());
/*     */     }
/* 472 */     if (this.cnt - tailoff() > 1)
/*     */     {
/* 474 */       Object[] newTail = new Object[this.tail.length - 1];
/* 475 */       System.arraycopy(this.tail, 0, newTail, 0, newTail.length);
/* 476 */       return new PersistentVector(meta(), this.cnt - 1, this.shift, this.root, newTail);
/*     */     }
/* 478 */     Object[] newtail = arrayFor(this.cnt - 2);
/*     */     
/* 480 */     Node newroot = popTail(this.shift, this.root);
/* 481 */     int newshift = this.shift;
/* 482 */     if (newroot == null)
/*     */     {
/* 484 */       newroot = EMPTY_NODE;
/*     */     }
/* 486 */     if ((this.shift > 5) && (newroot.array[1] == null))
/*     */     {
/* 488 */       newroot = (Node)newroot.array[0];
/* 489 */       newshift -= 5;
/*     */     }
/* 491 */     return new PersistentVector(meta(), this.cnt - 1, newshift, newroot, newtail);
/*     */   }
/*     */   
/*     */   private Node popTail(int level, Node node) {
/* 495 */     int subidx = this.cnt - 2 >>> level & 0x1F;
/* 496 */     if (level > 5)
/*     */     {
/* 498 */       Node newchild = popTail(level - 5, (Node)node.array[subidx]);
/* 499 */       if ((newchild == null) && (subidx == 0)) {
/* 500 */         return null;
/*     */       }
/*     */       
/* 503 */       Node ret = new Node(this.root.edit, (Object[])node.array.clone());
/* 504 */       ret.array[subidx] = newchild;
/* 505 */       return ret;
/*     */     }
/*     */     
/* 508 */     if (subidx == 0) {
/* 509 */       return null;
/*     */     }
/*     */     
/* 512 */     Node ret = new Node(this.root.edit, (Object[])node.array.clone());
/* 513 */     ret.array[subidx] = null;
/* 514 */     return ret;
/*     */   }
/*     */   
/*     */   static final class TransientVector extends AFn implements ITransientVector, Counted
/*     */   {
/*     */     volatile int cnt;
/*     */     volatile int shift;
/*     */     volatile PersistentVector.Node root;
/*     */     volatile Object[] tail;
/*     */     
/*     */     TransientVector(int cnt, int shift, PersistentVector.Node root, Object[] tail) {
/* 525 */       this.cnt = cnt;
/* 526 */       this.shift = shift;
/* 527 */       this.root = root;
/* 528 */       this.tail = tail;
/*     */     }
/*     */     
/*     */     TransientVector(PersistentVector v) {
/* 532 */       this(v.cnt, v.shift, editableRoot(v.root), editableTail(v.tail));
/*     */     }
/*     */     
/*     */     public int count() {
/* 536 */       ensureEditable();
/* 537 */       return this.cnt;
/*     */     }
/*     */     
/*     */     PersistentVector.Node ensureEditable(PersistentVector.Node node) {
/* 541 */       if (node.edit == this.root.edit)
/* 542 */         return node;
/* 543 */       return new PersistentVector.Node(this.root.edit, (Object[])node.array.clone());
/*     */     }
/*     */     
/*     */     void ensureEditable() {
/* 547 */       if (this.root.edit.get() == null) {
/* 548 */         throw new IllegalAccessError("Transient used after persistent! call");
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */     static PersistentVector.Node editableRoot(PersistentVector.Node node)
/*     */     {
/* 555 */       return new PersistentVector.Node(new AtomicReference(Thread.currentThread()), (Object[])node.array.clone());
/*     */     }
/*     */     
/*     */     public PersistentVector persistent() {
/* 559 */       ensureEditable();
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 565 */       this.root.edit.set(null);
/* 566 */       Object[] trimmedTail = new Object[this.cnt - tailoff()];
/* 567 */       System.arraycopy(this.tail, 0, trimmedTail, 0, trimmedTail.length);
/* 568 */       return new PersistentVector(this.cnt, this.shift, this.root, trimmedTail);
/*     */     }
/*     */     
/*     */     static Object[] editableTail(Object[] tl) {
/* 572 */       Object[] ret = new Object[32];
/* 573 */       System.arraycopy(tl, 0, ret, 0, tl.length);
/* 574 */       return ret;
/*     */     }
/*     */     
/*     */     public TransientVector conj(Object val) {
/* 578 */       ensureEditable();
/* 579 */       int i = this.cnt;
/*     */       
/* 581 */       if (i - tailoff() < 32)
/*     */       {
/* 583 */         this.tail[(i & 0x1F)] = val;
/* 584 */         this.cnt += 1;
/* 585 */         return this;
/*     */       }
/*     */       
/*     */ 
/* 589 */       PersistentVector.Node tailnode = new PersistentVector.Node(this.root.edit, this.tail);
/* 590 */       this.tail = new Object[32];
/* 591 */       this.tail[0] = val;
/* 592 */       int newshift = this.shift;
/*     */       PersistentVector.Node newroot;
/* 594 */       if (this.cnt >>> 5 > 1 << this.shift)
/*     */       {
/* 596 */         PersistentVector.Node newroot = new PersistentVector.Node(this.root.edit);
/* 597 */         newroot.array[0] = this.root;
/* 598 */         newroot.array[1] = PersistentVector.newPath(this.root.edit, this.shift, tailnode);
/* 599 */         newshift += 5;
/*     */       }
/*     */       else {
/* 602 */         newroot = pushTail(this.shift, this.root, tailnode); }
/* 603 */       this.root = newroot;
/* 604 */       this.shift = newshift;
/* 605 */       this.cnt += 1;
/* 606 */       return this;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private PersistentVector.Node pushTail(int level, PersistentVector.Node parent, PersistentVector.Node tailnode)
/*     */     {
/* 614 */       parent = ensureEditable(parent);
/* 615 */       int subidx = this.cnt - 1 >>> level & 0x1F;
/* 616 */       PersistentVector.Node ret = parent;
/*     */       PersistentVector.Node nodeToInsert;
/* 618 */       PersistentVector.Node nodeToInsert; if (level == 5)
/*     */       {
/* 620 */         nodeToInsert = tailnode;
/*     */       }
/*     */       else
/*     */       {
/* 624 */         PersistentVector.Node child = (PersistentVector.Node)parent.array[subidx];
/* 625 */         nodeToInsert = child != null ? pushTail(level - 5, child, tailnode) : PersistentVector.newPath(this.root.edit, level - 5, tailnode);
/*     */       }
/*     */       
/*     */ 
/* 629 */       ret.array[subidx] = nodeToInsert;
/* 630 */       return ret;
/*     */     }
/*     */     
/*     */     private final int tailoff() {
/* 634 */       if (this.cnt < 32)
/* 635 */         return 0;
/* 636 */       return this.cnt - 1 >>> 5 << 5;
/*     */     }
/*     */     
/*     */     private Object[] arrayFor(int i) {
/* 640 */       if ((i >= 0) && (i < this.cnt))
/*     */       {
/* 642 */         if (i >= tailoff())
/* 643 */           return this.tail;
/* 644 */         PersistentVector.Node node = this.root;
/* 645 */         for (int level = this.shift; level > 0; level -= 5)
/* 646 */           node = (PersistentVector.Node)node.array[(i >>> level & 0x1F)];
/* 647 */         return node.array;
/*     */       }
/* 649 */       throw new IndexOutOfBoundsException();
/*     */     }
/*     */     
/*     */     private Object[] editableArrayFor(int i) {
/* 653 */       if ((i >= 0) && (i < this.cnt))
/*     */       {
/* 655 */         if (i >= tailoff())
/* 656 */           return this.tail;
/* 657 */         PersistentVector.Node node = this.root;
/* 658 */         for (int level = this.shift; level > 0; level -= 5)
/* 659 */           node = ensureEditable((PersistentVector.Node)node.array[(i >>> level & 0x1F)]);
/* 660 */         return node.array;
/*     */       }
/* 662 */       throw new IndexOutOfBoundsException();
/*     */     }
/*     */     
/*     */     public Object valAt(Object key)
/*     */     {
/* 667 */       return valAt(key, null);
/*     */     }
/*     */     
/*     */     public Object valAt(Object key, Object notFound) {
/* 671 */       ensureEditable();
/* 672 */       if (Util.isInteger(key))
/*     */       {
/* 674 */         int i = ((Number)key).intValue();
/* 675 */         if ((i >= 0) && (i < this.cnt))
/* 676 */           return nth(i);
/*     */       }
/* 678 */       return notFound;
/*     */     }
/*     */     
/*     */     public Object invoke(Object arg1)
/*     */     {
/* 683 */       if (Util.isInteger(arg1))
/* 684 */         return nth(((Number)arg1).intValue());
/* 685 */       throw new IllegalArgumentException("Key must be integer");
/*     */     }
/*     */     
/*     */     public Object nth(int i) {
/* 689 */       ensureEditable();
/* 690 */       Object[] node = arrayFor(i);
/* 691 */       return node[(i & 0x1F)];
/*     */     }
/*     */     
/*     */     public Object nth(int i, Object notFound) {
/* 695 */       if ((i >= 0) && (i < count()))
/* 696 */         return nth(i);
/* 697 */       return notFound;
/*     */     }
/*     */     
/*     */     public TransientVector assocN(int i, Object val) {
/* 701 */       ensureEditable();
/* 702 */       if ((i >= 0) && (i < this.cnt))
/*     */       {
/* 704 */         if (i >= tailoff())
/*     */         {
/* 706 */           this.tail[(i & 0x1F)] = val;
/* 707 */           return this;
/*     */         }
/*     */         
/* 710 */         this.root = doAssoc(this.shift, this.root, i, val);
/* 711 */         return this;
/*     */       }
/* 713 */       if (i == this.cnt)
/* 714 */         return conj(val);
/* 715 */       throw new IndexOutOfBoundsException();
/*     */     }
/*     */     
/*     */     public TransientVector assoc(Object key, Object val)
/*     */     {
/* 720 */       if (Util.isInteger(key))
/*     */       {
/* 722 */         int i = ((Number)key).intValue();
/* 723 */         return assocN(i, val);
/*     */       }
/* 725 */       throw new IllegalArgumentException("Key must be integer");
/*     */     }
/*     */     
/*     */     private PersistentVector.Node doAssoc(int level, PersistentVector.Node node, int i, Object val) {
/* 729 */       node = ensureEditable(node);
/* 730 */       PersistentVector.Node ret = node;
/* 731 */       if (level == 0)
/*     */       {
/* 733 */         ret.array[(i & 0x1F)] = val;
/*     */       }
/*     */       else
/*     */       {
/* 737 */         int subidx = i >>> level & 0x1F;
/* 738 */         ret.array[subidx] = doAssoc(level - 5, (PersistentVector.Node)node.array[subidx], i, val);
/*     */       }
/* 740 */       return ret;
/*     */     }
/*     */     
/*     */     public TransientVector pop() {
/* 744 */       ensureEditable();
/* 745 */       if (this.cnt == 0)
/* 746 */         throw new IllegalStateException("Can't pop empty vector");
/* 747 */       if (this.cnt == 1)
/*     */       {
/* 749 */         this.cnt = 0;
/* 750 */         return this;
/*     */       }
/* 752 */       int i = this.cnt - 1;
/*     */       
/* 754 */       if ((i & 0x1F) > 0)
/*     */       {
/* 756 */         this.cnt -= 1;
/* 757 */         return this;
/*     */       }
/*     */       
/* 760 */       Object[] newtail = editableArrayFor(this.cnt - 2);
/*     */       
/* 762 */       PersistentVector.Node newroot = popTail(this.shift, this.root);
/* 763 */       int newshift = this.shift;
/* 764 */       if (newroot == null)
/*     */       {
/* 766 */         newroot = new PersistentVector.Node(this.root.edit);
/*     */       }
/* 768 */       if ((this.shift > 5) && (newroot.array[1] == null))
/*     */       {
/* 770 */         newroot = ensureEditable((PersistentVector.Node)newroot.array[0]);
/* 771 */         newshift -= 5;
/*     */       }
/* 773 */       this.root = newroot;
/* 774 */       this.shift = newshift;
/* 775 */       this.cnt -= 1;
/* 776 */       this.tail = newtail;
/* 777 */       return this;
/*     */     }
/*     */     
/*     */     private PersistentVector.Node popTail(int level, PersistentVector.Node node) {
/* 781 */       node = ensureEditable(node);
/* 782 */       int subidx = this.cnt - 2 >>> level & 0x1F;
/* 783 */       if (level > 5)
/*     */       {
/* 785 */         PersistentVector.Node newchild = popTail(level - 5, (PersistentVector.Node)node.array[subidx]);
/* 786 */         if ((newchild == null) && (subidx == 0)) {
/* 787 */           return null;
/*     */         }
/*     */         
/* 790 */         PersistentVector.Node ret = node;
/* 791 */         ret.array[subidx] = newchild;
/* 792 */         return ret;
/*     */       }
/*     */       
/* 795 */       if (subidx == 0) {
/* 796 */         return null;
/*     */       }
/*     */       
/* 799 */       PersistentVector.Node ret = node;
/* 800 */       ret.array[subidx] = null;
/* 801 */       return ret;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\PersistentVector.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */