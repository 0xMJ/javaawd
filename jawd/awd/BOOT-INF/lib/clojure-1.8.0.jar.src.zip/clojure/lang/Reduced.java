/*    */ package clojure.lang;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Reduced
/*    */   implements IDeref
/*    */ {
/*    */   Object val;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public Reduced(Object val)
/*    */   {
/* 17 */     this.val = val;
/*    */   }
/*    */   
/*    */   public Object deref() {
/* 21 */     return this.val;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\Reduced.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */