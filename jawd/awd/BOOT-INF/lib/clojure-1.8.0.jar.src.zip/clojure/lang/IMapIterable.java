package clojure.lang;

import java.util.Iterator;

public abstract interface IMapIterable
{
  public abstract Iterator keyIterator();
  
  public abstract Iterator valIterator();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\IMapIterable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */