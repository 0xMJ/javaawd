package clojure.lang;

public abstract interface Reversible
{
  public abstract ISeq rseq();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\Reversible.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */