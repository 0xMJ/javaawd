/*    */ package clojure.lang;
/*    */ 
/*    */ import java.util.Collection;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LazilyPersistentVector
/*    */ {
/*    */   public static IPersistentVector createOwning(Object... items)
/*    */   {
/* 25 */     if (items.length <= 32)
/* 26 */       return new PersistentVector(items.length, 5, PersistentVector.EMPTY_NODE, items);
/* 27 */     return PersistentVector.create(items);
/*    */   }
/*    */   
/*    */   static int fcount(Object c) {
/* 31 */     if ((c instanceof Counted))
/* 32 */       return ((Counted)c).count();
/* 33 */     return ((Collection)c).size();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public static IPersistentVector create(Object obj)
/*    */   {
/* 41 */     if ((obj instanceof IReduceInit))
/* 42 */       return PersistentVector.create((IReduceInit)obj);
/* 43 */     if ((obj instanceof ISeq))
/* 44 */       return PersistentVector.create(RT.seq(obj));
/* 45 */     if ((obj instanceof Iterable)) {
/* 46 */       return PersistentVector.create((Iterable)obj);
/*    */     }
/* 48 */     return createOwning(RT.toArray(obj));
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\LazilyPersistentVector.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */