/*      */ package clojure.lang;
/*      */ 
/*      */ import java.io.FileNotFoundException;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.InputStreamReader;
/*      */ import java.io.OutputStreamWriter;
/*      */ import java.io.PrintWriter;
/*      */ import java.io.PushbackReader;
/*      */ import java.io.Reader;
/*      */ import java.io.StringWriter;
/*      */ import java.io.Writer;
/*      */ import java.lang.reflect.Array;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.net.JarURLConnection;
/*      */ import java.net.URL;
/*      */ import java.net.URLConnection;
/*      */ import java.nio.charset.Charset;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.RandomAccess;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.atomic.AtomicInteger;
/*      */ import java.util.regex.Matcher;
/*      */ import java.util.regex.Pattern;
/*      */ 
/*      */ public class RT
/*      */ {
/*   34 */   public static final Boolean T = Boolean.TRUE;
/*   35 */   public static final Boolean F = Boolean.FALSE;
/*      */   
/*      */   public static final String LOADER_SUFFIX = "__init";
/*      */   
/*   39 */   static final IPersistentMap DEFAULT_IMPORTS = map(new Object[] { Symbol.intern("Boolean"), Boolean.class, Symbol.intern("Byte"), Byte.class, Symbol.intern("Character"), Character.class, Symbol.intern("Class"), Class.class, Symbol.intern("ClassLoader"), ClassLoader.class, Symbol.intern("Compiler"), Compiler.class, Symbol.intern("Double"), Double.class, Symbol.intern("Enum"), Enum.class, Symbol.intern("Float"), Float.class, Symbol.intern("InheritableThreadLocal"), InheritableThreadLocal.class, Symbol.intern("Integer"), Integer.class, Symbol.intern("Long"), Long.class, Symbol.intern("Math"), Math.class, Symbol.intern("Number"), Number.class, Symbol.intern("Object"), Object.class, Symbol.intern("Package"), Package.class, Symbol.intern("Process"), Process.class, Symbol.intern("ProcessBuilder"), ProcessBuilder.class, Symbol.intern("Runtime"), Runtime.class, Symbol.intern("RuntimePermission"), RuntimePermission.class, Symbol.intern("SecurityManager"), SecurityManager.class, Symbol.intern("Short"), Short.class, Symbol.intern("StackTraceElement"), StackTraceElement.class, Symbol.intern("StrictMath"), StrictMath.class, Symbol.intern("String"), String.class, Symbol.intern("StringBuffer"), StringBuffer.class, Symbol.intern("StringBuilder"), StringBuilder.class, Symbol.intern("System"), System.class, Symbol.intern("Thread"), Thread.class, Symbol.intern("ThreadGroup"), ThreadGroup.class, Symbol.intern("ThreadLocal"), ThreadLocal.class, Symbol.intern("Throwable"), Throwable.class, Symbol.intern("Void"), Void.class, Symbol.intern("Appendable"), Appendable.class, Symbol.intern("CharSequence"), CharSequence.class, Symbol.intern("Cloneable"), Cloneable.class, Symbol.intern("Comparable"), Comparable.class, Symbol.intern("Iterable"), Iterable.class, Symbol.intern("Readable"), Readable.class, Symbol.intern("Runnable"), Runnable.class, Symbol.intern("Callable"), java.util.concurrent.Callable.class, Symbol.intern("BigInteger"), BigInteger.class, Symbol.intern("BigDecimal"), BigDecimal.class, Symbol.intern("ArithmeticException"), ArithmeticException.class, Symbol.intern("ArrayIndexOutOfBoundsException"), ArrayIndexOutOfBoundsException.class, Symbol.intern("ArrayStoreException"), ArrayStoreException.class, Symbol.intern("ClassCastException"), ClassCastException.class, Symbol.intern("ClassNotFoundException"), ClassNotFoundException.class, Symbol.intern("CloneNotSupportedException"), CloneNotSupportedException.class, Symbol.intern("EnumConstantNotPresentException"), EnumConstantNotPresentException.class, Symbol.intern("Exception"), Exception.class, Symbol.intern("IllegalAccessException"), IllegalAccessException.class, Symbol.intern("IllegalArgumentException"), IllegalArgumentException.class, Symbol.intern("IllegalMonitorStateException"), IllegalMonitorStateException.class, Symbol.intern("IllegalStateException"), IllegalStateException.class, Symbol.intern("IllegalThreadStateException"), IllegalThreadStateException.class, Symbol.intern("IndexOutOfBoundsException"), IndexOutOfBoundsException.class, Symbol.intern("InstantiationException"), InstantiationException.class, Symbol.intern("InterruptedException"), InterruptedException.class, Symbol.intern("NegativeArraySizeException"), NegativeArraySizeException.class, Symbol.intern("NoSuchFieldException"), NoSuchFieldException.class, Symbol.intern("NoSuchMethodException"), NoSuchMethodException.class, Symbol.intern("NullPointerException"), NullPointerException.class, Symbol.intern("NumberFormatException"), NumberFormatException.class, Symbol.intern("RuntimeException"), RuntimeException.class, Symbol.intern("SecurityException"), SecurityException.class, Symbol.intern("StringIndexOutOfBoundsException"), StringIndexOutOfBoundsException.class, Symbol.intern("TypeNotPresentException"), TypeNotPresentException.class, Symbol.intern("UnsupportedOperationException"), UnsupportedOperationException.class, Symbol.intern("AbstractMethodError"), AbstractMethodError.class, Symbol.intern("AssertionError"), AssertionError.class, Symbol.intern("ClassCircularityError"), ClassCircularityError.class, Symbol.intern("ClassFormatError"), ClassFormatError.class, Symbol.intern("Error"), Error.class, Symbol.intern("ExceptionInInitializerError"), ExceptionInInitializerError.class, Symbol.intern("IllegalAccessError"), IllegalAccessError.class, Symbol.intern("IncompatibleClassChangeError"), IncompatibleClassChangeError.class, Symbol.intern("InstantiationError"), InstantiationError.class, Symbol.intern("InternalError"), InternalError.class, Symbol.intern("LinkageError"), LinkageError.class, Symbol.intern("NoClassDefFoundError"), NoClassDefFoundError.class, Symbol.intern("NoSuchFieldError"), NoSuchFieldError.class, Symbol.intern("NoSuchMethodError"), NoSuchMethodError.class, Symbol.intern("OutOfMemoryError"), OutOfMemoryError.class, Symbol.intern("StackOverflowError"), StackOverflowError.class, Symbol.intern("ThreadDeath"), ThreadDeath.class, Symbol.intern("UnknownError"), UnknownError.class, Symbol.intern("UnsatisfiedLinkError"), UnsatisfiedLinkError.class, Symbol.intern("UnsupportedClassVersionError"), UnsupportedClassVersionError.class, Symbol.intern("VerifyError"), VerifyError.class, Symbol.intern("VirtualMachineError"), VirtualMachineError.class, Symbol.intern("Thread$UncaughtExceptionHandler"), Thread.UncaughtExceptionHandler.class, Symbol.intern("Thread$State"), Thread.State.class, Symbol.intern("Deprecated"), Deprecated.class, Symbol.intern("Override"), Override.class, Symbol.intern("SuppressWarnings"), SuppressWarnings.class });
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  170 */   public static Charset UTF8 = Charset.forName("UTF-8");
/*      */   
/*      */   static Object readTrueFalseUnknown(String s) {
/*  173 */     if (s.equals("true"))
/*  174 */       return Boolean.TRUE;
/*  175 */     if (s.equals("false"))
/*  176 */       return Boolean.FALSE;
/*  177 */     return Keyword.intern(null, "unknown");
/*      */   }
/*      */   
/*  180 */   public static final Namespace CLOJURE_NS = Namespace.findOrCreate(Symbol.intern("clojure.core"));
/*      */   
/*  182 */   public static final Var OUT = Var.intern(CLOJURE_NS, Symbol.intern("*out*"), new OutputStreamWriter(System.out)).setDynamic();
/*      */   
/*  184 */   public static final Var IN = Var.intern(CLOJURE_NS, Symbol.intern("*in*"), new LineNumberingPushbackReader(new InputStreamReader(System.in))).setDynamic();
/*      */   
/*      */ 
/*  187 */   public static final Var ERR = Var.intern(CLOJURE_NS, Symbol.intern("*err*"), new PrintWriter(new OutputStreamWriter(System.err), true)).setDynamic();
/*      */   
/*      */ 
/*  190 */   static final Keyword TAG_KEY = Keyword.intern(null, "tag");
/*  191 */   static final Keyword CONST_KEY = Keyword.intern(null, "const");
/*  192 */   public static final Var AGENT = Var.intern(CLOJURE_NS, Symbol.intern("*agent*"), null).setDynamic();
/*  193 */   static Object readeval = readTrueFalseUnknown(System.getProperty("clojure.read.eval", "true"));
/*  194 */   public static final Var READEVAL = Var.intern(CLOJURE_NS, Symbol.intern("*read-eval*"), readeval).setDynamic();
/*  195 */   public static final Var DATA_READERS = Var.intern(CLOJURE_NS, Symbol.intern("*data-readers*"), map(new Object[0])).setDynamic();
/*  196 */   public static final Var DEFAULT_DATA_READER_FN = Var.intern(CLOJURE_NS, Symbol.intern("*default-data-reader-fn*"), map(new Object[0])).setDynamic();
/*  197 */   public static final Var DEFAULT_DATA_READERS = Var.intern(CLOJURE_NS, Symbol.intern("default-data-readers"), map(new Object[0]));
/*  198 */   public static final Var SUPPRESS_READ = Var.intern(CLOJURE_NS, Symbol.intern("*suppress-read*"), null).setDynamic();
/*  199 */   public static final Var ASSERT = Var.intern(CLOJURE_NS, Symbol.intern("*assert*"), T).setDynamic();
/*  200 */   public static final Var MATH_CONTEXT = Var.intern(CLOJURE_NS, Symbol.intern("*math-context*"), null).setDynamic();
/*  201 */   static Keyword LINE_KEY = Keyword.intern(null, "line");
/*  202 */   static Keyword COLUMN_KEY = Keyword.intern(null, "column");
/*  203 */   static Keyword FILE_KEY = Keyword.intern(null, "file");
/*  204 */   static Keyword DECLARED_KEY = Keyword.intern(null, "declared");
/*  205 */   static Keyword DOC_KEY = Keyword.intern(null, "doc");
/*  206 */   public static final Var USE_CONTEXT_CLASSLOADER = Var.intern(CLOJURE_NS, Symbol.intern("*use-context-classloader*"), T).setDynamic();
/*      */   
/*      */ 
/*  209 */   public static final Var UNCHECKED_MATH = Var.intern(Namespace.findOrCreate(Symbol.intern("clojure.core")), Symbol.intern("*unchecked-math*"), Boolean.FALSE).setDynamic();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  215 */   static final Symbol LOAD_FILE = Symbol.intern("load-file");
/*  216 */   static final Symbol IN_NAMESPACE = Symbol.intern("in-ns");
/*  217 */   static final Symbol NAMESPACE = Symbol.intern("ns");
/*  218 */   static final Symbol IDENTICAL = Symbol.intern("identical?");
/*  219 */   static final Var CMD_LINE_ARGS = Var.intern(CLOJURE_NS, Symbol.intern("*command-line-args*"), null).setDynamic();
/*      */   
/*  221 */   public static final Var CURRENT_NS = Var.intern(CLOJURE_NS, Symbol.intern("*ns*"), CLOJURE_NS).setDynamic();
/*      */   
/*      */ 
/*  224 */   static final Var FLUSH_ON_NEWLINE = Var.intern(CLOJURE_NS, Symbol.intern("*flush-on-newline*"), T).setDynamic();
/*  225 */   static final Var PRINT_META = Var.intern(CLOJURE_NS, Symbol.intern("*print-meta*"), F).setDynamic();
/*  226 */   static final Var PRINT_READABLY = Var.intern(CLOJURE_NS, Symbol.intern("*print-readably*"), T).setDynamic();
/*  227 */   static final Var PRINT_DUP = Var.intern(CLOJURE_NS, Symbol.intern("*print-dup*"), F).setDynamic();
/*  228 */   static final Var WARN_ON_REFLECTION = Var.intern(CLOJURE_NS, Symbol.intern("*warn-on-reflection*"), F).setDynamic();
/*  229 */   static final Var ALLOW_UNRESOLVED_VARS = Var.intern(CLOJURE_NS, Symbol.intern("*allow-unresolved-vars*"), F).setDynamic();
/*      */   
/*  231 */   static final Var IN_NS_VAR = Var.intern(CLOJURE_NS, Symbol.intern("in-ns"), F);
/*  232 */   static final Var NS_VAR = Var.intern(CLOJURE_NS, Symbol.intern("ns"), F);
/*  233 */   static final Var FN_LOADER_VAR = Var.intern(CLOJURE_NS, Symbol.intern("*fn-loader*"), null).setDynamic();
/*  234 */   static final Var PRINT_INITIALIZED = Var.intern(CLOJURE_NS, Symbol.intern("print-initialized"));
/*  235 */   static final Var PR_ON = Var.intern(CLOJURE_NS, Symbol.intern("pr-on"));
/*      */   
/*  237 */   static final IFn inNamespace = new AFn() {
/*      */     public Object invoke(Object arg1) {
/*  239 */       Symbol nsname = (Symbol)arg1;
/*  240 */       Namespace ns = Namespace.findOrCreate(nsname);
/*  241 */       RT.CURRENT_NS.set(ns);
/*  242 */       return ns;
/*      */     }
/*      */   };
/*      */   
/*  246 */   static final IFn bootNamespace = new AFn() {
/*      */     public Object invoke(Object __form, Object __env, Object arg1) {
/*  248 */       Symbol nsname = (Symbol)arg1;
/*  249 */       Namespace ns = Namespace.findOrCreate(nsname);
/*  250 */       RT.CURRENT_NS.set(ns);
/*  251 */       return ns;
/*      */     }
/*      */   };
/*      */   
/*      */   public static List<String> processCommandLine(String[] args) {
/*  256 */     List<String> arglist = java.util.Arrays.asList(args);
/*  257 */     int split = arglist.indexOf("--");
/*  258 */     if (split >= 0) {
/*  259 */       CMD_LINE_ARGS.bindRoot(seq(arglist.subList(split + 1, args.length)));
/*  260 */       return arglist.subList(0, split);
/*      */     }
/*  262 */     return arglist;
/*      */   }
/*      */   
/*      */   public static PrintWriter errPrintWriter()
/*      */   {
/*  267 */     Writer w = (Writer)ERR.deref();
/*  268 */     if ((w instanceof PrintWriter)) {
/*  269 */       return (PrintWriter)w;
/*      */     }
/*  271 */     return new PrintWriter(w);
/*      */   }
/*      */   
/*      */ 
/*  275 */   public static final Object[] EMPTY_ARRAY = new Object[0];
/*  276 */   public static final java.util.Comparator DEFAULT_COMPARATOR = new DefaultComparator(null);
/*      */   
/*      */   private static final class DefaultComparator implements java.util.Comparator, java.io.Serializable {
/*      */     public int compare(Object o1, Object o2) {
/*  280 */       return Util.compare(o1, o2);
/*      */     }
/*      */     
/*      */     private Object readResolve()
/*      */       throws java.io.ObjectStreamException
/*      */     {
/*  286 */       return RT.DEFAULT_COMPARATOR;
/*      */     }
/*      */   }
/*      */   
/*  290 */   static AtomicInteger id = new AtomicInteger(1);
/*      */   private static final int CHUNK_SIZE = 32;
/*      */   
/*  293 */   public static void addURL(Object url) throws java.net.MalformedURLException { URL u = (url instanceof String) ? new URL((String)url) : (URL)url;
/*  294 */     ClassLoader ccl = Thread.currentThread().getContextClassLoader();
/*  295 */     if ((ccl instanceof DynamicClassLoader)) {
/*  296 */       ((DynamicClassLoader)ccl).addURL(u);
/*      */     } else
/*  298 */       throw new IllegalAccessError("Context classloader is not a DynamicClassLoader");
/*      */   }
/*      */   
/*      */   static {
/*  302 */     Keyword arglistskw = Keyword.intern(null, "arglists");
/*  303 */     Symbol namesym = Symbol.intern("name");
/*  304 */     OUT.setTag(Symbol.intern("java.io.Writer"));
/*  305 */     CURRENT_NS.setTag(Symbol.intern("clojure.lang.Namespace"));
/*  306 */     AGENT.setMeta(map(new Object[] { DOC_KEY, "The agent currently running an action on this thread, else nil" }));
/*  307 */     AGENT.setTag(Symbol.intern("clojure.lang.Agent"));
/*  308 */     MATH_CONTEXT.setTag(Symbol.intern("java.math.MathContext"));
/*  309 */     Var nv = Var.intern(CLOJURE_NS, NAMESPACE, bootNamespace);
/*  310 */     nv.setMacro();
/*      */     
/*  312 */     Var v = Var.intern(CLOJURE_NS, IN_NAMESPACE, inNamespace);
/*  313 */     v.setMeta(map(new Object[] { DOC_KEY, "Sets *ns* to the namespace named by the symbol, creating it if needed.", arglistskw, list(vector(new Object[] { namesym })) }));
/*      */     
/*  315 */     v = Var.intern(CLOJURE_NS, LOAD_FILE, new AFn()
/*      */     {
/*      */       public Object invoke(Object arg1)
/*      */       {
/*      */         try {
/*  320 */           return Compiler.loadFile((String)arg1);
/*      */         }
/*      */         catch (IOException e)
/*      */         {
/*  324 */           throw Util.sneakyThrow(e);
/*      */         }
/*      */       }
/*  327 */     });
/*  328 */     v.setMeta(map(new Object[] { DOC_KEY, "Sequentially read and evaluate the set of forms contained in the file.", arglistskw, list(vector(new Object[] { namesym })) }));
/*      */     try
/*      */     {
/*  331 */       doInit();
/*      */     }
/*      */     catch (Exception e) {
/*  334 */       throw Util.sneakyThrow(e);
/*      */     }
/*      */   }
/*      */   
/*      */   public static Keyword keyword(String ns, String name) {
/*  339 */     return Keyword.intern(Symbol.intern(ns, name));
/*      */   }
/*      */   
/*      */   public static Var var(String ns, String name) {
/*  343 */     return Var.intern(Namespace.findOrCreate(Symbol.intern(null, ns)), Symbol.intern(null, name));
/*      */   }
/*      */   
/*      */   public static Var var(String ns, String name, Object init) {
/*  347 */     return Var.intern(Namespace.findOrCreate(Symbol.intern(null, ns)), Symbol.intern(null, name), init);
/*      */   }
/*      */   
/*      */   public static void loadResourceScript(String name) throws IOException {
/*  351 */     loadResourceScript(name, true);
/*      */   }
/*      */   
/*      */   public static void maybeLoadResourceScript(String name) throws IOException {
/*  355 */     loadResourceScript(name, false);
/*      */   }
/*      */   
/*      */   public static void loadResourceScript(String name, boolean failIfNotFound) throws IOException {
/*  359 */     loadResourceScript(RT.class, name, failIfNotFound);
/*      */   }
/*      */   
/*      */   public static void loadResourceScript(Class c, String name) throws IOException {
/*  363 */     loadResourceScript(c, name, true);
/*      */   }
/*      */   
/*      */   public static void loadResourceScript(Class c, String name, boolean failIfNotFound) throws IOException {
/*  367 */     int slash = name.lastIndexOf('/');
/*  368 */     String file = slash >= 0 ? name.substring(slash + 1) : name;
/*  369 */     InputStream ins = resourceAsStream(baseLoader(), name);
/*  370 */     if (ins != null) {
/*      */       try {
/*  372 */         Compiler.load(new InputStreamReader(ins, UTF8), name, file);
/*      */       }
/*      */       finally {
/*  375 */         ins.close();
/*      */       }
/*      */       
/*  378 */     } else if (failIfNotFound) {
/*  379 */       throw new FileNotFoundException("Could not locate Clojure resource on classpath: " + name);
/*      */     }
/*      */   }
/*      */   
/*      */   public static void init() {
/*  384 */     errPrintWriter().println("No need to call RT.init() anymore");
/*      */   }
/*      */   
/*      */   public static long lastModified(URL url, String libfile) throws IOException {
/*  388 */     URLConnection connection = url.openConnection();
/*      */     try { long l;
/*  390 */       if (url.getProtocol().equals("jar")) { InputStream ins;
/*  391 */         return ((JarURLConnection)connection).getJarFile().getEntry(libfile).getTime(); }
/*      */       InputStream ins;
/*  393 */       return connection.getLastModified();
/*      */     }
/*      */     finally {
/*  396 */       InputStream ins = connection.getInputStream();
/*  397 */       if (ins != null)
/*  398 */         ins.close();
/*      */     }
/*      */   }
/*      */   
/*      */   static void compile(String cljfile) throws IOException {
/*  403 */     InputStream ins = resourceAsStream(baseLoader(), cljfile);
/*  404 */     if (ins != null) {
/*      */       try {
/*  406 */         Compiler.compile(new InputStreamReader(ins, UTF8), cljfile, cljfile.substring(1 + cljfile.lastIndexOf("/")));
/*      */       }
/*      */       finally
/*      */       {
/*  410 */         ins.close();
/*      */       }
/*      */       
/*      */     }
/*      */     else
/*  415 */       throw new FileNotFoundException("Could not locate Clojure resource on classpath: " + cljfile);
/*      */   }
/*      */   
/*      */   public static void load(String scriptbase) throws IOException, ClassNotFoundException {
/*  419 */     load(scriptbase, true);
/*      */   }
/*      */   
/*      */   public static void load(String scriptbase, boolean failIfNotFound) throws IOException, ClassNotFoundException {
/*  423 */     String classfile = scriptbase + "__init" + ".class";
/*  424 */     String cljfile = scriptbase + ".clj";
/*  425 */     String scriptfile = cljfile;
/*  426 */     URL classURL = getResource(baseLoader(), classfile);
/*  427 */     URL cljURL = getResource(baseLoader(), scriptfile);
/*  428 */     if (cljURL == null) {
/*  429 */       scriptfile = scriptbase + ".cljc";
/*  430 */       cljURL = getResource(baseLoader(), scriptfile);
/*      */     }
/*  432 */     boolean loaded = false;
/*      */     
/*  434 */     if (((classURL != null) && ((cljURL == null) || (lastModified(classURL, classfile) > lastModified(cljURL, scriptfile)))) || (classURL == null))
/*      */     {
/*      */       try
/*      */       {
/*      */ 
/*  439 */         Var.pushThreadBindings(mapUniqueKeys(new Object[] { CURRENT_NS, CURRENT_NS.deref(), WARN_ON_REFLECTION, WARN_ON_REFLECTION.deref(), UNCHECKED_MATH, UNCHECKED_MATH.deref() }));
/*      */         
/*      */ 
/*      */ 
/*  443 */         loaded = loadClassForName(scriptbase.replace('/', '.') + "__init") != null;
/*      */       }
/*      */       finally {
/*  446 */         Var.popThreadBindings();
/*      */       }
/*      */     }
/*  449 */     if ((!loaded) && (cljURL != null)) {
/*  450 */       if (booleanCast(Compiler.COMPILE_FILES.deref())) {
/*  451 */         compile(scriptfile);
/*      */       } else {
/*  453 */         loadResourceScript(RT.class, scriptfile);
/*      */       }
/*  455 */     } else if ((!loaded) && (failIfNotFound)) {
/*  456 */       throw new FileNotFoundException(String.format("Could not locate %s or %s on classpath.%s", new Object[] { classfile, cljfile, scriptbase.contains("_") ? " Please check that namespaces with dashes use underscores in the Clojure file name." : "" }));
/*      */     }
/*      */   }
/*      */   
/*      */   static void doInit() throws ClassNotFoundException, IOException {
/*  461 */     load("clojure/core");
/*      */     
/*  463 */     Var.pushThreadBindings(mapUniqueKeys(new Object[] { CURRENT_NS, CURRENT_NS.deref(), WARN_ON_REFLECTION, WARN_ON_REFLECTION.deref(), UNCHECKED_MATH, UNCHECKED_MATH.deref() }));
/*      */     
/*      */ 
/*      */     try
/*      */     {
/*  468 */       Symbol USER = Symbol.intern("user");
/*  469 */       Symbol CLOJURE = Symbol.intern("clojure.core");
/*      */       
/*  471 */       Var in_ns = var("clojure.core", "in-ns");
/*  472 */       Var refer = var("clojure.core", "refer");
/*  473 */       in_ns.invoke(USER);
/*  474 */       refer.invoke(CLOJURE);
/*  475 */       maybeLoadResourceScript("user.clj");
/*      */       
/*      */ 
/*  478 */       Var require = var("clojure.core", "require");
/*  479 */       Symbol SERVER = Symbol.intern("clojure.core.server");
/*  480 */       require.invoke(SERVER);
/*  481 */       Var start_servers = var("clojure.core.server", "start-servers");
/*  482 */       start_servers.invoke(System.getProperties());
/*      */     }
/*      */     finally {
/*  485 */       Var.popThreadBindings();
/*      */     }
/*      */   }
/*      */   
/*      */   public static int nextID() {
/*  490 */     return id.getAndIncrement();
/*      */   }
/*      */   
/*      */   public static void loadLibrary(String libname)
/*      */   {
/*  495 */     System.loadLibrary(libname);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static ISeq chunkIteratorSeq(Iterator iter)
/*      */   {
/*  503 */     if (iter.hasNext()) {
/*  504 */       new LazySeq(new AFn() {
/*      */         public Object invoke() {
/*  506 */           Object[] arr = new Object[32];
/*  507 */           int n = 0;
/*  508 */           while ((this.val$iter.hasNext()) && (n < 32))
/*  509 */             arr[(n++)] = this.val$iter.next();
/*  510 */           return new ChunkedCons(new ArrayChunk(arr, 0, n), RT.chunkIteratorSeq(this.val$iter));
/*      */         }
/*      */       });
/*      */     }
/*  514 */     return null;
/*      */   }
/*      */   
/*      */   public static ISeq seq(Object coll) {
/*  518 */     if ((coll instanceof ASeq))
/*  519 */       return (ASeq)coll;
/*  520 */     if ((coll instanceof LazySeq)) {
/*  521 */       return ((LazySeq)coll).seq();
/*      */     }
/*  523 */     return seqFrom(coll);
/*      */   }
/*      */   
/*      */   static ISeq seqFrom(Object coll) {
/*  527 */     if ((coll instanceof Seqable))
/*  528 */       return ((Seqable)coll).seq();
/*  529 */     if (coll == null)
/*  530 */       return null;
/*  531 */     if ((coll instanceof Iterable))
/*  532 */       return chunkIteratorSeq(((Iterable)coll).iterator());
/*  533 */     if (coll.getClass().isArray())
/*  534 */       return ArraySeq.createFromObject(coll);
/*  535 */     if ((coll instanceof CharSequence))
/*  536 */       return StringSeq.create((CharSequence)coll);
/*  537 */     if ((coll instanceof Map)) {
/*  538 */       return seq(((Map)coll).entrySet());
/*      */     }
/*  540 */     Class c = coll.getClass();
/*  541 */     Class sc = c.getSuperclass();
/*  542 */     throw new IllegalArgumentException("Don't know how to create ISeq from: " + c.getName());
/*      */   }
/*      */   
/*      */   public static Iterator iter(Object coll)
/*      */   {
/*  547 */     if ((coll instanceof Iterable))
/*  548 */       return ((Iterable)coll).iterator();
/*  549 */     if (coll == null)
/*  550 */       new Iterator() {
/*      */         public boolean hasNext() {
/*  552 */           return false;
/*      */         }
/*      */         
/*      */         public Object next() {
/*  556 */           throw new java.util.NoSuchElementException();
/*      */         }
/*      */         
/*      */         public void remove() {
/*  560 */           throw new UnsupportedOperationException();
/*      */         }
/*      */       };
/*  563 */     if ((coll instanceof Map)) {
/*  564 */       return ((Map)coll).entrySet().iterator();
/*      */     }
/*  566 */     if ((coll instanceof String)) {
/*  567 */       String s = (String)coll;
/*  568 */       new Iterator() {
/*  569 */         int i = 0;
/*      */         
/*      */         public boolean hasNext() {
/*  572 */           return this.i < this.val$s.length();
/*      */         }
/*      */         
/*      */         public Object next() {
/*  576 */           return Character.valueOf(this.val$s.charAt(this.i++));
/*      */         }
/*      */         
/*      */         public void remove() {
/*  580 */           throw new UnsupportedOperationException();
/*      */         }
/*      */       };
/*      */     }
/*  584 */     if (coll.getClass().isArray()) {
/*  585 */       return ArrayIter.createFromObject(coll);
/*      */     }
/*      */     
/*  588 */     return iter(seq(coll));
/*      */   }
/*      */   
/*      */   public static Object seqOrElse(Object o) {
/*  592 */     return seq(o) == null ? null : o;
/*      */   }
/*      */   
/*      */   public static ISeq keys(Object coll) {
/*  596 */     if ((coll instanceof IPersistentMap)) {
/*  597 */       return APersistentMap.KeySeq.createFromMap((IPersistentMap)coll);
/*      */     }
/*  599 */     return APersistentMap.KeySeq.create(seq(coll));
/*      */   }
/*      */   
/*      */   public static ISeq vals(Object coll) {
/*  603 */     if ((coll instanceof IPersistentMap)) {
/*  604 */       return APersistentMap.ValSeq.createFromMap((IPersistentMap)coll);
/*      */     }
/*  606 */     return APersistentMap.ValSeq.create(seq(coll));
/*      */   }
/*      */   
/*      */   public static IPersistentMap meta(Object x) {
/*  610 */     if ((x instanceof IMeta))
/*  611 */       return ((IMeta)x).meta();
/*  612 */     return null;
/*      */   }
/*      */   
/*      */   public static int count(Object o) {
/*  616 */     if ((o instanceof Counted))
/*  617 */       return ((Counted)o).count();
/*  618 */     return countFrom(Util.ret1(o, o = null));
/*      */   }
/*      */   
/*      */   static int countFrom(Object o) {
/*  622 */     if (o == null)
/*  623 */       return 0;
/*  624 */     if ((o instanceof IPersistentCollection)) {
/*  625 */       ISeq s = seq(o);
/*  626 */       o = null;
/*  627 */       int i = 0;
/*  628 */       for (; s != null; s = s.next()) {
/*  629 */         if ((s instanceof Counted))
/*  630 */           return i + s.count();
/*  631 */         i++;
/*      */       }
/*  633 */       return i;
/*      */     }
/*  635 */     if ((o instanceof CharSequence))
/*  636 */       return ((CharSequence)o).length();
/*  637 */     if ((o instanceof Collection))
/*  638 */       return ((Collection)o).size();
/*  639 */     if ((o instanceof Map))
/*  640 */       return ((Map)o).size();
/*  641 */     if ((o instanceof Map.Entry))
/*  642 */       return 2;
/*  643 */     if (o.getClass().isArray()) {
/*  644 */       return Array.getLength(o);
/*      */     }
/*  646 */     throw new UnsupportedOperationException("count not supported on this type: " + o.getClass().getSimpleName());
/*      */   }
/*      */   
/*      */   public static IPersistentCollection conj(IPersistentCollection coll, Object x) {
/*  650 */     if (coll == null)
/*  651 */       return new PersistentList(x);
/*  652 */     return coll.cons(x);
/*      */   }
/*      */   
/*      */   public static ISeq cons(Object x, Object coll)
/*      */   {
/*  657 */     if (coll == null)
/*  658 */       return new PersistentList(x);
/*  659 */     if ((coll instanceof ISeq)) {
/*  660 */       return new Cons(x, (ISeq)coll);
/*      */     }
/*  662 */     return new Cons(x, seq(coll));
/*      */   }
/*      */   
/*      */   public static Object first(Object x) {
/*  666 */     if ((x instanceof ISeq))
/*  667 */       return ((ISeq)x).first();
/*  668 */     ISeq seq = seq(x);
/*  669 */     if (seq == null)
/*  670 */       return null;
/*  671 */     return seq.first();
/*      */   }
/*      */   
/*      */   public static Object second(Object x) {
/*  675 */     return first(next(x));
/*      */   }
/*      */   
/*      */   public static Object third(Object x) {
/*  679 */     return first(next(next(x)));
/*      */   }
/*      */   
/*      */   public static Object fourth(Object x) {
/*  683 */     return first(next(next(next(x))));
/*      */   }
/*      */   
/*      */   public static ISeq next(Object x) {
/*  687 */     if ((x instanceof ISeq))
/*  688 */       return ((ISeq)x).next();
/*  689 */     ISeq seq = seq(x);
/*  690 */     if (seq == null)
/*  691 */       return null;
/*  692 */     return seq.next();
/*      */   }
/*      */   
/*      */   public static ISeq more(Object x) {
/*  696 */     if ((x instanceof ISeq))
/*  697 */       return ((ISeq)x).more();
/*  698 */     ISeq seq = seq(x);
/*  699 */     if (seq == null)
/*  700 */       return PersistentList.EMPTY;
/*  701 */     return seq.more();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Object peek(Object x)
/*      */   {
/*  722 */     if (x == null)
/*  723 */       return null;
/*  724 */     return ((IPersistentStack)x).peek();
/*      */   }
/*      */   
/*      */   public static Object pop(Object x) {
/*  728 */     if (x == null)
/*  729 */       return null;
/*  730 */     return ((IPersistentStack)x).pop();
/*      */   }
/*      */   
/*      */   public static Object get(Object coll, Object key) {
/*  734 */     if ((coll instanceof ILookup))
/*  735 */       return ((ILookup)coll).valAt(key);
/*  736 */     return getFrom(coll, key);
/*      */   }
/*      */   
/*      */   static Object getFrom(Object coll, Object key) {
/*  740 */     if (coll == null)
/*  741 */       return null;
/*  742 */     if ((coll instanceof Map)) {
/*  743 */       Map m = (Map)coll;
/*  744 */       return m.get(key);
/*      */     }
/*  746 */     if ((coll instanceof IPersistentSet)) {
/*  747 */       IPersistentSet set = (IPersistentSet)coll;
/*  748 */       return set.get(key);
/*      */     }
/*  750 */     if (((key instanceof Number)) && (((coll instanceof String)) || (coll.getClass().isArray()))) {
/*  751 */       int n = ((Number)key).intValue();
/*  752 */       if ((n >= 0) && (n < count(coll)))
/*  753 */         return nth(coll, n);
/*  754 */       return null;
/*      */     }
/*      */     
/*  757 */     return null;
/*      */   }
/*      */   
/*      */   public static Object get(Object coll, Object key, Object notFound) {
/*  761 */     if ((coll instanceof ILookup))
/*  762 */       return ((ILookup)coll).valAt(key, notFound);
/*  763 */     return getFrom(coll, key, notFound);
/*      */   }
/*      */   
/*      */   static Object getFrom(Object coll, Object key, Object notFound) {
/*  767 */     if (coll == null)
/*  768 */       return notFound;
/*  769 */     if ((coll instanceof Map)) {
/*  770 */       Map m = (Map)coll;
/*  771 */       if (m.containsKey(key))
/*  772 */         return m.get(key);
/*  773 */       return notFound;
/*      */     }
/*  775 */     if ((coll instanceof IPersistentSet)) {
/*  776 */       IPersistentSet set = (IPersistentSet)coll;
/*  777 */       if (set.contains(key))
/*  778 */         return set.get(key);
/*  779 */       return notFound;
/*      */     }
/*  781 */     if (((key instanceof Number)) && (((coll instanceof String)) || (coll.getClass().isArray()))) {
/*  782 */       int n = ((Number)key).intValue();
/*  783 */       return (n >= 0) && (n < count(coll)) ? nth(coll, n) : notFound;
/*      */     }
/*  785 */     return notFound;
/*      */   }
/*      */   
/*      */   public static Associative assoc(Object coll, Object key, Object val)
/*      */   {
/*  790 */     if (coll == null)
/*  791 */       return new PersistentArrayMap(new Object[] { key, val });
/*  792 */     return ((Associative)coll).assoc(key, val);
/*      */   }
/*      */   
/*      */   public static Object contains(Object coll, Object key) {
/*  796 */     if (coll == null)
/*  797 */       return F;
/*  798 */     if ((coll instanceof Associative))
/*  799 */       return ((Associative)coll).containsKey(key) ? T : F;
/*  800 */     if ((coll instanceof IPersistentSet))
/*  801 */       return ((IPersistentSet)coll).contains(key) ? T : F;
/*  802 */     if ((coll instanceof Map)) {
/*  803 */       Map m = (Map)coll;
/*  804 */       return m.containsKey(key) ? T : F;
/*      */     }
/*  806 */     if ((coll instanceof Set)) {
/*  807 */       Set s = (Set)coll;
/*  808 */       return s.contains(key) ? T : F;
/*      */     }
/*  810 */     if (((key instanceof Number)) && (((coll instanceof String)) || (coll.getClass().isArray()))) {
/*  811 */       int n = ((Number)key).intValue();
/*  812 */       return Boolean.valueOf((n >= 0) && (n < count(coll)));
/*      */     }
/*  814 */     throw new IllegalArgumentException("contains? not supported on type: " + coll.getClass().getName());
/*      */   }
/*      */   
/*      */   public static Object find(Object coll, Object key) {
/*  818 */     if (coll == null)
/*  819 */       return null;
/*  820 */     if ((coll instanceof Associative)) {
/*  821 */       return ((Associative)coll).entryAt(key);
/*      */     }
/*  823 */     Map m = (Map)coll;
/*  824 */     if (m.containsKey(key))
/*  825 */       return MapEntry.create(key, m.get(key));
/*  826 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static ISeq findKey(Keyword key, ISeq keyvals)
/*      */   {
/*  834 */     while (keyvals != null) {
/*  835 */       ISeq r = keyvals.next();
/*  836 */       if (r == null)
/*  837 */         throw Util.runtimeException("Malformed keyword argslist");
/*  838 */       if (keyvals.first() == key)
/*  839 */         return r;
/*  840 */       keyvals = r.next();
/*      */     }
/*  842 */     return null;
/*      */   }
/*      */   
/*      */   public static Object dissoc(Object coll, Object key) {
/*  846 */     if (coll == null)
/*  847 */       return null;
/*  848 */     return ((IPersistentMap)coll).without(key);
/*      */   }
/*      */   
/*      */   public static Object nth(Object coll, int n) {
/*  852 */     if ((coll instanceof Indexed))
/*  853 */       return ((Indexed)coll).nth(n);
/*  854 */     return nthFrom(Util.ret1(coll, coll = null), n);
/*      */   }
/*      */   
/*      */   static Object nthFrom(Object coll, int n) {
/*  858 */     if (coll == null)
/*  859 */       return null;
/*  860 */     if ((coll instanceof CharSequence))
/*  861 */       return Character.valueOf(((CharSequence)coll).charAt(n));
/*  862 */     if (coll.getClass().isArray())
/*  863 */       return Reflector.prepRet(coll.getClass().getComponentType(), Array.get(coll, n));
/*  864 */     if ((coll instanceof RandomAccess))
/*  865 */       return ((List)coll).get(n);
/*  866 */     if ((coll instanceof Matcher)) {
/*  867 */       return ((Matcher)coll).group(n);
/*      */     }
/*  869 */     if ((coll instanceof Map.Entry)) {
/*  870 */       Map.Entry e = (Map.Entry)coll;
/*  871 */       if (n == 0)
/*  872 */         return e.getKey();
/*  873 */       if (n == 1)
/*  874 */         return e.getValue();
/*  875 */       throw new IndexOutOfBoundsException();
/*      */     }
/*      */     
/*  878 */     if ((coll instanceof Sequential)) {
/*  879 */       ISeq seq = seq(coll);
/*  880 */       coll = null;
/*  881 */       for (int i = 0; (i <= n) && (seq != null); seq = seq.next()) {
/*  882 */         if (i == n) {
/*  883 */           return seq.first();
/*      */         }
/*  881 */         i++;
/*      */       }
/*      */       
/*      */ 
/*  885 */       throw new IndexOutOfBoundsException();
/*      */     }
/*      */     
/*  888 */     throw new UnsupportedOperationException("nth not supported on this type: " + coll.getClass().getSimpleName());
/*      */   }
/*      */   
/*      */   public static Object nth(Object coll, int n, Object notFound)
/*      */   {
/*  893 */     if ((coll instanceof Indexed)) {
/*  894 */       Indexed v = (Indexed)coll;
/*  895 */       return v.nth(n, notFound);
/*      */     }
/*  897 */     return nthFrom(coll, n, notFound);
/*      */   }
/*      */   
/*      */   static Object nthFrom(Object coll, int n, Object notFound) {
/*  901 */     if (coll == null)
/*  902 */       return notFound;
/*  903 */     if (n < 0) {
/*  904 */       return notFound;
/*      */     }
/*  906 */     if ((coll instanceof CharSequence)) {
/*  907 */       CharSequence s = (CharSequence)coll;
/*  908 */       if (n < s.length())
/*  909 */         return Character.valueOf(s.charAt(n));
/*  910 */       return notFound;
/*      */     }
/*  912 */     if (coll.getClass().isArray()) {
/*  913 */       if (n < Array.getLength(coll))
/*  914 */         return Reflector.prepRet(coll.getClass().getComponentType(), Array.get(coll, n));
/*  915 */       return notFound;
/*      */     }
/*  917 */     if ((coll instanceof RandomAccess)) {
/*  918 */       List list = (List)coll;
/*  919 */       if (n < list.size())
/*  920 */         return list.get(n);
/*  921 */       return notFound;
/*      */     }
/*  923 */     if ((coll instanceof Matcher)) {
/*  924 */       Matcher m = (Matcher)coll;
/*  925 */       if (n < m.groupCount())
/*  926 */         return m.group(n);
/*  927 */       return notFound;
/*      */     }
/*  929 */     if ((coll instanceof Map.Entry)) {
/*  930 */       Map.Entry e = (Map.Entry)coll;
/*  931 */       if (n == 0)
/*  932 */         return e.getKey();
/*  933 */       if (n == 1)
/*  934 */         return e.getValue();
/*  935 */       return notFound;
/*      */     }
/*  937 */     if ((coll instanceof Sequential)) {
/*  938 */       ISeq seq = seq(coll);
/*  939 */       coll = null;
/*  940 */       for (int i = 0; (i <= n) && (seq != null); seq = seq.next()) {
/*  941 */         if (i == n) {
/*  942 */           return seq.first();
/*      */         }
/*  940 */         i++;
/*      */       }
/*      */       
/*      */ 
/*  944 */       return notFound;
/*      */     }
/*      */     
/*  947 */     throw new UnsupportedOperationException("nth not supported on this type: " + coll.getClass().getSimpleName());
/*      */   }
/*      */   
/*      */   public static Object assocN(int n, Object val, Object coll)
/*      */   {
/*  952 */     if (coll == null)
/*  953 */       return null;
/*  954 */     if ((coll instanceof IPersistentVector))
/*  955 */       return ((IPersistentVector)coll).assocN(n, val);
/*  956 */     if ((coll instanceof Object[]))
/*      */     {
/*  958 */       Object[] array = (Object[])coll;
/*  959 */       array[n] = val;
/*  960 */       return array;
/*      */     }
/*      */     
/*  963 */     return null;
/*      */   }
/*      */   
/*      */   static boolean hasTag(Object o, Object tag) {
/*  967 */     return Util.equals(tag, get(meta(o), TAG_KEY));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static Object box(Object x)
/*      */   {
/*  974 */     return x;
/*      */   }
/*      */   
/*      */   public static Character box(char x) {
/*  978 */     return Character.valueOf(x);
/*      */   }
/*      */   
/*      */   public static Object box(boolean x) {
/*  982 */     return x ? T : F;
/*      */   }
/*      */   
/*      */   public static Object box(Boolean x) {
/*  986 */     return x;
/*      */   }
/*      */   
/*      */   public static Number box(byte x) {
/*  990 */     return Byte.valueOf(x);
/*      */   }
/*      */   
/*      */   public static Number box(short x) {
/*  994 */     return Short.valueOf(x);
/*      */   }
/*      */   
/*      */   public static Number box(int x) {
/*  998 */     return Integer.valueOf(x);
/*      */   }
/*      */   
/*      */   public static Number box(long x) {
/* 1002 */     return Long.valueOf(x);
/*      */   }
/*      */   
/*      */   public static Number box(float x) {
/* 1006 */     return Float.valueOf(x);
/*      */   }
/*      */   
/*      */   public static Number box(double x) {
/* 1010 */     return Double.valueOf(x);
/*      */   }
/*      */   
/*      */   public static char charCast(Object x) {
/* 1014 */     if ((x instanceof Character)) {
/* 1015 */       return ((Character)x).charValue();
/*      */     }
/* 1017 */     long n = ((Number)x).longValue();
/* 1018 */     if ((n < 0L) || (n > 65535L)) {
/* 1019 */       throw new IllegalArgumentException("Value out of range for char: " + x);
/*      */     }
/* 1021 */     return (char)(int)n;
/*      */   }
/*      */   
/*      */   public static char charCast(byte x) {
/* 1025 */     char i = (char)x;
/* 1026 */     if (i != x)
/* 1027 */       throw new IllegalArgumentException("Value out of range for char: " + x);
/* 1028 */     return i;
/*      */   }
/*      */   
/*      */   public static char charCast(short x) {
/* 1032 */     char i = (char)x;
/* 1033 */     if (i != x)
/* 1034 */       throw new IllegalArgumentException("Value out of range for char: " + x);
/* 1035 */     return i;
/*      */   }
/*      */   
/*      */   public static char charCast(char x) {
/* 1039 */     return x;
/*      */   }
/*      */   
/*      */   public static char charCast(int x) {
/* 1043 */     char i = (char)x;
/* 1044 */     if (i != x)
/* 1045 */       throw new IllegalArgumentException("Value out of range for char: " + x);
/* 1046 */     return i;
/*      */   }
/*      */   
/*      */   public static char charCast(long x) {
/* 1050 */     char i = (char)(int)x;
/* 1051 */     if (i != x)
/* 1052 */       throw new IllegalArgumentException("Value out of range for char: " + x);
/* 1053 */     return i;
/*      */   }
/*      */   
/*      */   public static char charCast(float x) {
/* 1057 */     if ((x >= 0.0F) && (x <= 65535.0F))
/* 1058 */       return (char)(int)x;
/* 1059 */     throw new IllegalArgumentException("Value out of range for char: " + x);
/*      */   }
/*      */   
/*      */   public static char charCast(double x) {
/* 1063 */     if ((x >= 0.0D) && (x <= 65535.0D))
/* 1064 */       return (char)(int)x;
/* 1065 */     throw new IllegalArgumentException("Value out of range for char: " + x);
/*      */   }
/*      */   
/*      */   public static boolean booleanCast(Object x) {
/* 1069 */     if ((x instanceof Boolean))
/* 1070 */       return ((Boolean)x).booleanValue();
/* 1071 */     return x != null;
/*      */   }
/*      */   
/*      */   public static boolean booleanCast(boolean x) {
/* 1075 */     return x;
/*      */   }
/*      */   
/*      */   public static byte byteCast(Object x) {
/* 1079 */     if ((x instanceof Byte))
/* 1080 */       return ((Byte)x).byteValue();
/* 1081 */     long n = longCast(x);
/* 1082 */     if ((n < -128L) || (n > 127L)) {
/* 1083 */       throw new IllegalArgumentException("Value out of range for byte: " + x);
/*      */     }
/* 1085 */     return (byte)(int)n;
/*      */   }
/*      */   
/*      */   public static byte byteCast(byte x) {
/* 1089 */     return x;
/*      */   }
/*      */   
/*      */   public static byte byteCast(short x) {
/* 1093 */     byte i = (byte)x;
/* 1094 */     if (i != x)
/* 1095 */       throw new IllegalArgumentException("Value out of range for byte: " + x);
/* 1096 */     return i;
/*      */   }
/*      */   
/*      */   public static byte byteCast(int x) {
/* 1100 */     byte i = (byte)x;
/* 1101 */     if (i != x)
/* 1102 */       throw new IllegalArgumentException("Value out of range for byte: " + x);
/* 1103 */     return i;
/*      */   }
/*      */   
/*      */   public static byte byteCast(long x) {
/* 1107 */     byte i = (byte)(int)x;
/* 1108 */     if (i != x)
/* 1109 */       throw new IllegalArgumentException("Value out of range for byte: " + x);
/* 1110 */     return i;
/*      */   }
/*      */   
/*      */   public static byte byteCast(float x) {
/* 1114 */     if ((x >= -128.0F) && (x <= 127.0F))
/* 1115 */       return (byte)(int)x;
/* 1116 */     throw new IllegalArgumentException("Value out of range for byte: " + x);
/*      */   }
/*      */   
/*      */   public static byte byteCast(double x) {
/* 1120 */     if ((x >= -128.0D) && (x <= 127.0D))
/* 1121 */       return (byte)(int)x;
/* 1122 */     throw new IllegalArgumentException("Value out of range for byte: " + x);
/*      */   }
/*      */   
/*      */   public static short shortCast(Object x) {
/* 1126 */     if ((x instanceof Short))
/* 1127 */       return ((Short)x).shortValue();
/* 1128 */     long n = longCast(x);
/* 1129 */     if ((n < -32768L) || (n > 32767L)) {
/* 1130 */       throw new IllegalArgumentException("Value out of range for short: " + x);
/*      */     }
/* 1132 */     return (short)(int)n;
/*      */   }
/*      */   
/*      */   public static short shortCast(byte x) {
/* 1136 */     return (short)x;
/*      */   }
/*      */   
/*      */   public static short shortCast(short x) {
/* 1140 */     return x;
/*      */   }
/*      */   
/*      */   public static short shortCast(int x) {
/* 1144 */     short i = (short)x;
/* 1145 */     if (i != x)
/* 1146 */       throw new IllegalArgumentException("Value out of range for short: " + x);
/* 1147 */     return i;
/*      */   }
/*      */   
/*      */   public static short shortCast(long x) {
/* 1151 */     short i = (short)(int)x;
/* 1152 */     if (i != x)
/* 1153 */       throw new IllegalArgumentException("Value out of range for short: " + x);
/* 1154 */     return i;
/*      */   }
/*      */   
/*      */   public static short shortCast(float x) {
/* 1158 */     if ((x >= -32768.0F) && (x <= 32767.0F))
/* 1159 */       return (short)(int)x;
/* 1160 */     throw new IllegalArgumentException("Value out of range for short: " + x);
/*      */   }
/*      */   
/*      */   public static short shortCast(double x) {
/* 1164 */     if ((x >= -32768.0D) && (x <= 32767.0D))
/* 1165 */       return (short)(int)x;
/* 1166 */     throw new IllegalArgumentException("Value out of range for short: " + x);
/*      */   }
/*      */   
/*      */   public static int intCast(Object x) {
/* 1170 */     if ((x instanceof Integer))
/* 1171 */       return ((Integer)x).intValue();
/* 1172 */     if ((x instanceof Number))
/*      */     {
/* 1174 */       long n = longCast(x);
/* 1175 */       return intCast(n);
/*      */     }
/* 1177 */     return ((Character)x).charValue();
/*      */   }
/*      */   
/*      */   public static int intCast(char x) {
/* 1181 */     return x;
/*      */   }
/*      */   
/*      */   public static int intCast(byte x) {
/* 1185 */     return x;
/*      */   }
/*      */   
/*      */   public static int intCast(short x) {
/* 1189 */     return x;
/*      */   }
/*      */   
/*      */   public static int intCast(int x) {
/* 1193 */     return x;
/*      */   }
/*      */   
/*      */   public static int intCast(float x) {
/* 1197 */     if ((x < -2.14748365E9F) || (x > 2.14748365E9F))
/* 1198 */       throw new IllegalArgumentException("Value out of range for int: " + x);
/* 1199 */     return (int)x;
/*      */   }
/*      */   
/*      */   public static int intCast(long x) {
/* 1203 */     int i = (int)x;
/* 1204 */     if (i != x)
/* 1205 */       throw new IllegalArgumentException("Value out of range for int: " + x);
/* 1206 */     return i;
/*      */   }
/*      */   
/*      */   public static int intCast(double x) {
/* 1210 */     if ((x < -2.147483648E9D) || (x > 2.147483647E9D))
/* 1211 */       throw new IllegalArgumentException("Value out of range for int: " + x);
/* 1212 */     return (int)x;
/*      */   }
/*      */   
/*      */   public static long longCast(Object x) {
/* 1216 */     if (((x instanceof Integer)) || ((x instanceof Long)))
/* 1217 */       return ((Number)x).longValue();
/* 1218 */     if ((x instanceof BigInt))
/*      */     {
/* 1220 */       BigInt bi = (BigInt)x;
/* 1221 */       if (bi.bipart == null) {
/* 1222 */         return bi.lpart;
/*      */       }
/* 1224 */       throw new IllegalArgumentException("Value out of range for long: " + x);
/*      */     }
/* 1226 */     if ((x instanceof BigInteger))
/*      */     {
/* 1228 */       BigInteger bi = (BigInteger)x;
/* 1229 */       if (bi.bitLength() < 64) {
/* 1230 */         return bi.longValue();
/*      */       }
/* 1232 */       throw new IllegalArgumentException("Value out of range for long: " + x);
/*      */     }
/* 1234 */     if (((x instanceof Byte)) || ((x instanceof Short)))
/* 1235 */       return ((Number)x).longValue();
/* 1236 */     if ((x instanceof Ratio))
/* 1237 */       return longCast(((Ratio)x).bigIntegerValue());
/* 1238 */     if ((x instanceof Character)) {
/* 1239 */       return longCast(((Character)x).charValue());
/*      */     }
/* 1241 */     return longCast(((Number)x).doubleValue());
/*      */   }
/*      */   
/*      */   public static long longCast(byte x) {
/* 1245 */     return x;
/*      */   }
/*      */   
/*      */   public static long longCast(short x) {
/* 1249 */     return x;
/*      */   }
/*      */   
/*      */   public static long longCast(int x) {
/* 1253 */     return x;
/*      */   }
/*      */   
/*      */   public static long longCast(float x) {
/* 1257 */     if ((x < -9.223372E18F) || (x > 9.223372E18F))
/* 1258 */       throw new IllegalArgumentException("Value out of range for long: " + x);
/* 1259 */     return x;
/*      */   }
/*      */   
/*      */   public static long longCast(long x) {
/* 1263 */     return x;
/*      */   }
/*      */   
/*      */   public static long longCast(double x) {
/* 1267 */     if ((x < -9.223372036854776E18D) || (x > 9.223372036854776E18D))
/* 1268 */       throw new IllegalArgumentException("Value out of range for long: " + x);
/* 1269 */     return x;
/*      */   }
/*      */   
/*      */   public static float floatCast(Object x) {
/* 1273 */     if ((x instanceof Float)) {
/* 1274 */       return ((Float)x).floatValue();
/*      */     }
/* 1276 */     double n = ((Number)x).doubleValue();
/* 1277 */     if ((n < -3.4028234663852886E38D) || (n > 3.4028234663852886E38D)) {
/* 1278 */       throw new IllegalArgumentException("Value out of range for float: " + x);
/*      */     }
/* 1280 */     return (float)n;
/*      */   }
/*      */   
/*      */   public static float floatCast(byte x)
/*      */   {
/* 1285 */     return x;
/*      */   }
/*      */   
/*      */   public static float floatCast(short x) {
/* 1289 */     return x;
/*      */   }
/*      */   
/*      */   public static float floatCast(int x) {
/* 1293 */     return x;
/*      */   }
/*      */   
/*      */   public static float floatCast(float x) {
/* 1297 */     return x;
/*      */   }
/*      */   
/*      */   public static float floatCast(long x) {
/* 1301 */     return (float)x;
/*      */   }
/*      */   
/*      */   public static float floatCast(double x) {
/* 1305 */     if ((x < -3.4028234663852886E38D) || (x > 3.4028234663852886E38D)) {
/* 1306 */       throw new IllegalArgumentException("Value out of range for float: " + x);
/*      */     }
/* 1308 */     return (float)x;
/*      */   }
/*      */   
/*      */   public static double doubleCast(Object x) {
/* 1312 */     return ((Number)x).doubleValue();
/*      */   }
/*      */   
/*      */   public static double doubleCast(byte x) {
/* 1316 */     return x;
/*      */   }
/*      */   
/*      */   public static double doubleCast(short x) {
/* 1320 */     return x;
/*      */   }
/*      */   
/*      */   public static double doubleCast(int x) {
/* 1324 */     return x;
/*      */   }
/*      */   
/*      */   public static double doubleCast(float x) {
/* 1328 */     return x;
/*      */   }
/*      */   
/*      */   public static double doubleCast(long x) {
/* 1332 */     return x;
/*      */   }
/*      */   
/*      */   public static double doubleCast(double x) {
/* 1336 */     return x;
/*      */   }
/*      */   
/*      */   public static byte uncheckedByteCast(Object x) {
/* 1340 */     return ((Number)x).byteValue();
/*      */   }
/*      */   
/*      */   public static byte uncheckedByteCast(byte x) {
/* 1344 */     return x;
/*      */   }
/*      */   
/*      */   public static byte uncheckedByteCast(short x) {
/* 1348 */     return (byte)x;
/*      */   }
/*      */   
/*      */   public static byte uncheckedByteCast(int x) {
/* 1352 */     return (byte)x;
/*      */   }
/*      */   
/*      */   public static byte uncheckedByteCast(long x) {
/* 1356 */     return (byte)(int)x;
/*      */   }
/*      */   
/*      */   public static byte uncheckedByteCast(float x) {
/* 1360 */     return (byte)(int)x;
/*      */   }
/*      */   
/*      */   public static byte uncheckedByteCast(double x) {
/* 1364 */     return (byte)(int)x;
/*      */   }
/*      */   
/*      */   public static short uncheckedShortCast(Object x) {
/* 1368 */     return ((Number)x).shortValue();
/*      */   }
/*      */   
/*      */   public static short uncheckedShortCast(byte x) {
/* 1372 */     return (short)x;
/*      */   }
/*      */   
/*      */   public static short uncheckedShortCast(short x) {
/* 1376 */     return x;
/*      */   }
/*      */   
/*      */   public static short uncheckedShortCast(int x) {
/* 1380 */     return (short)x;
/*      */   }
/*      */   
/*      */   public static short uncheckedShortCast(long x) {
/* 1384 */     return (short)(int)x;
/*      */   }
/*      */   
/*      */   public static short uncheckedShortCast(float x) {
/* 1388 */     return (short)(int)x;
/*      */   }
/*      */   
/*      */   public static short uncheckedShortCast(double x) {
/* 1392 */     return (short)(int)x;
/*      */   }
/*      */   
/*      */   public static char uncheckedCharCast(Object x) {
/* 1396 */     if ((x instanceof Character))
/* 1397 */       return ((Character)x).charValue();
/* 1398 */     return (char)(int)((Number)x).longValue();
/*      */   }
/*      */   
/*      */   public static char uncheckedCharCast(byte x) {
/* 1402 */     return (char)x;
/*      */   }
/*      */   
/*      */   public static char uncheckedCharCast(short x) {
/* 1406 */     return (char)x;
/*      */   }
/*      */   
/*      */   public static char uncheckedCharCast(char x) {
/* 1410 */     return x;
/*      */   }
/*      */   
/*      */   public static char uncheckedCharCast(int x) {
/* 1414 */     return (char)x;
/*      */   }
/*      */   
/*      */   public static char uncheckedCharCast(long x) {
/* 1418 */     return (char)(int)x;
/*      */   }
/*      */   
/*      */   public static char uncheckedCharCast(float x) {
/* 1422 */     return (char)(int)x;
/*      */   }
/*      */   
/*      */   public static char uncheckedCharCast(double x) {
/* 1426 */     return (char)(int)x;
/*      */   }
/*      */   
/*      */   public static int uncheckedIntCast(Object x) {
/* 1430 */     if ((x instanceof Number))
/* 1431 */       return ((Number)x).intValue();
/* 1432 */     return ((Character)x).charValue();
/*      */   }
/*      */   
/*      */   public static int uncheckedIntCast(byte x) {
/* 1436 */     return x;
/*      */   }
/*      */   
/*      */   public static int uncheckedIntCast(short x) {
/* 1440 */     return x;
/*      */   }
/*      */   
/*      */   public static int uncheckedIntCast(char x) {
/* 1444 */     return x;
/*      */   }
/*      */   
/*      */   public static int uncheckedIntCast(int x) {
/* 1448 */     return x;
/*      */   }
/*      */   
/*      */   public static int uncheckedIntCast(long x) {
/* 1452 */     return (int)x;
/*      */   }
/*      */   
/*      */   public static int uncheckedIntCast(float x) {
/* 1456 */     return (int)x;
/*      */   }
/*      */   
/*      */   public static int uncheckedIntCast(double x) {
/* 1460 */     return (int)x;
/*      */   }
/*      */   
/*      */   public static long uncheckedLongCast(Object x) {
/* 1464 */     return ((Number)x).longValue();
/*      */   }
/*      */   
/*      */   public static long uncheckedLongCast(byte x) {
/* 1468 */     return x;
/*      */   }
/*      */   
/*      */   public static long uncheckedLongCast(short x) {
/* 1472 */     return x;
/*      */   }
/*      */   
/*      */   public static long uncheckedLongCast(int x) {
/* 1476 */     return x;
/*      */   }
/*      */   
/*      */   public static long uncheckedLongCast(long x) {
/* 1480 */     return x;
/*      */   }
/*      */   
/*      */   public static long uncheckedLongCast(float x) {
/* 1484 */     return x;
/*      */   }
/*      */   
/*      */   public static long uncheckedLongCast(double x) {
/* 1488 */     return x;
/*      */   }
/*      */   
/*      */   public static float uncheckedFloatCast(Object x) {
/* 1492 */     return ((Number)x).floatValue();
/*      */   }
/*      */   
/*      */   public static float uncheckedFloatCast(byte x) {
/* 1496 */     return x;
/*      */   }
/*      */   
/*      */   public static float uncheckedFloatCast(short x) {
/* 1500 */     return x;
/*      */   }
/*      */   
/*      */   public static float uncheckedFloatCast(int x) {
/* 1504 */     return x;
/*      */   }
/*      */   
/*      */   public static float uncheckedFloatCast(long x) {
/* 1508 */     return (float)x;
/*      */   }
/*      */   
/*      */   public static float uncheckedFloatCast(float x) {
/* 1512 */     return x;
/*      */   }
/*      */   
/*      */   public static float uncheckedFloatCast(double x) {
/* 1516 */     return (float)x;
/*      */   }
/*      */   
/*      */   public static double uncheckedDoubleCast(Object x) {
/* 1520 */     return ((Number)x).doubleValue();
/*      */   }
/*      */   
/*      */   public static double uncheckedDoubleCast(byte x) {
/* 1524 */     return x;
/*      */   }
/*      */   
/*      */   public static double uncheckedDoubleCast(short x) {
/* 1528 */     return x;
/*      */   }
/*      */   
/*      */   public static double uncheckedDoubleCast(int x) {
/* 1532 */     return x;
/*      */   }
/*      */   
/*      */   public static double uncheckedDoubleCast(long x) {
/* 1536 */     return x;
/*      */   }
/*      */   
/*      */   public static double uncheckedDoubleCast(float x) {
/* 1540 */     return x;
/*      */   }
/*      */   
/*      */   public static double uncheckedDoubleCast(double x) {
/* 1544 */     return x;
/*      */   }
/*      */   
/*      */   public static IPersistentMap map(Object... init) {
/* 1548 */     if (init == null)
/* 1549 */       return PersistentArrayMap.EMPTY;
/* 1550 */     if (init.length <= 16)
/* 1551 */       return PersistentArrayMap.createWithCheck(init);
/* 1552 */     return PersistentHashMap.createWithCheck(init);
/*      */   }
/*      */   
/*      */   public static IPersistentMap mapUniqueKeys(Object... init) {
/* 1556 */     if (init == null)
/* 1557 */       return PersistentArrayMap.EMPTY;
/* 1558 */     if (init.length <= 16)
/* 1559 */       return new PersistentArrayMap(init);
/* 1560 */     return PersistentHashMap.create(init);
/*      */   }
/*      */   
/*      */   public static IPersistentSet set(Object... init) {
/* 1564 */     return PersistentHashSet.createWithCheck(init);
/*      */   }
/*      */   
/*      */   public static IPersistentVector vector(Object... init) {
/* 1568 */     return LazilyPersistentVector.createOwning(init);
/*      */   }
/*      */   
/*      */   public static IPersistentVector subvec(IPersistentVector v, int start, int end) {
/* 1572 */     if ((end < start) || (start < 0) || (end > v.count()))
/* 1573 */       throw new IndexOutOfBoundsException();
/* 1574 */     if (start == end)
/* 1575 */       return PersistentVector.EMPTY;
/* 1576 */     return new APersistentVector.SubVector(null, v, start, end);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static ISeq list()
/*      */   {
/* 1585 */     return null;
/*      */   }
/*      */   
/*      */   public static ISeq list(Object arg1) {
/* 1589 */     return new PersistentList(arg1);
/*      */   }
/*      */   
/*      */   public static ISeq list(Object arg1, Object arg2) {
/* 1593 */     return listStar(arg1, arg2, null);
/*      */   }
/*      */   
/*      */   public static ISeq list(Object arg1, Object arg2, Object arg3) {
/* 1597 */     return listStar(arg1, arg2, arg3, null);
/*      */   }
/*      */   
/*      */   public static ISeq list(Object arg1, Object arg2, Object arg3, Object arg4) {
/* 1601 */     return listStar(arg1, arg2, arg3, arg4, null);
/*      */   }
/*      */   
/*      */   public static ISeq list(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5) {
/* 1605 */     return listStar(arg1, arg2, arg3, arg4, arg5, null);
/*      */   }
/*      */   
/*      */   public static ISeq listStar(Object arg1, ISeq rest) {
/* 1609 */     return cons(arg1, rest);
/*      */   }
/*      */   
/*      */   public static ISeq listStar(Object arg1, Object arg2, ISeq rest) {
/* 1613 */     return cons(arg1, cons(arg2, rest));
/*      */   }
/*      */   
/*      */   public static ISeq listStar(Object arg1, Object arg2, Object arg3, ISeq rest) {
/* 1617 */     return cons(arg1, cons(arg2, cons(arg3, rest)));
/*      */   }
/*      */   
/*      */   public static ISeq listStar(Object arg1, Object arg2, Object arg3, Object arg4, ISeq rest) {
/* 1621 */     return cons(arg1, cons(arg2, cons(arg3, cons(arg4, rest))));
/*      */   }
/*      */   
/*      */   public static ISeq listStar(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, ISeq rest) {
/* 1625 */     return cons(arg1, cons(arg2, cons(arg3, cons(arg4, cons(arg5, rest)))));
/*      */   }
/*      */   
/*      */   public static ISeq arrayToList(Object[] a) {
/* 1629 */     ISeq ret = null;
/* 1630 */     for (int i = a.length - 1; i >= 0; i--)
/* 1631 */       ret = cons(a[i], ret);
/* 1632 */     return ret;
/*      */   }
/*      */   
/*      */   public static Object[] object_array(Object sizeOrSeq) {
/* 1636 */     if ((sizeOrSeq instanceof Number)) {
/* 1637 */       return new Object[((Number)sizeOrSeq).intValue()];
/*      */     }
/*      */     
/* 1640 */     ISeq s = seq(sizeOrSeq);
/* 1641 */     int size = count(s);
/* 1642 */     Object[] ret = new Object[size];
/* 1643 */     for (int i = 0; (i < size) && (s != null); s = s.next()) {
/* 1644 */       ret[i] = s.first();i++; }
/* 1645 */     return ret;
/*      */   }
/*      */   
/*      */   public static Object[] toArray(Object coll)
/*      */   {
/* 1650 */     if (coll == null)
/* 1651 */       return EMPTY_ARRAY;
/* 1652 */     if ((coll instanceof Object[]))
/* 1653 */       return (Object[])coll;
/* 1654 */     if ((coll instanceof Collection))
/* 1655 */       return ((Collection)coll).toArray();
/* 1656 */     if ((coll instanceof Iterable)) {
/* 1657 */       ArrayList ret = new ArrayList();
/* 1658 */       for (Object o : (Iterable)coll)
/* 1659 */         ret.add(o);
/* 1660 */       return ret.toArray(); }
/* 1661 */     if ((coll instanceof Map))
/* 1662 */       return ((Map)coll).entrySet().toArray();
/* 1663 */     if ((coll instanceof String)) {
/* 1664 */       char[] chars = ((String)coll).toCharArray();
/* 1665 */       Object[] ret = new Object[chars.length];
/* 1666 */       for (int i = 0; i < chars.length; i++)
/* 1667 */         ret[i] = Character.valueOf(chars[i]);
/* 1668 */       return ret;
/*      */     }
/* 1670 */     if (coll.getClass().isArray()) {
/* 1671 */       ISeq s = seq(coll);
/* 1672 */       Object[] ret = new Object[count(s)];
/* 1673 */       for (int i = 0; i < ret.length; s = s.next()) {
/* 1674 */         ret[i] = s.first();i++; }
/* 1675 */       return ret;
/*      */     }
/*      */     
/* 1678 */     throw Util.runtimeException("Unable to convert: " + coll.getClass() + " to Object[]");
/*      */   }
/*      */   
/*      */   public static Object[] seqToArray(ISeq seq) {
/* 1682 */     int len = length(seq);
/* 1683 */     Object[] ret = new Object[len];
/* 1684 */     for (int i = 0; seq != null; seq = seq.next()) {
/* 1685 */       ret[i] = seq.first();i++; }
/* 1686 */     return ret;
/*      */   }
/*      */   
/*      */   public static Object[] seqToPassedArray(ISeq seq, Object[] passed)
/*      */   {
/* 1691 */     Object[] dest = passed;
/* 1692 */     int len = count(seq);
/* 1693 */     if (len > dest.length) {
/* 1694 */       dest = (Object[])Array.newInstance(passed.getClass().getComponentType(), len);
/*      */     }
/* 1696 */     for (int i = 0; seq != null; seq = seq.next()) {
/* 1697 */       dest[i] = seq.first();i++; }
/* 1698 */     if (len < passed.length) {
/* 1699 */       dest[len] = null;
/*      */     }
/* 1701 */     return dest;
/*      */   }
/*      */   
/*      */   public static Object seqToTypedArray(ISeq seq) {
/* 1705 */     Class type = (seq != null) && (seq.first() != null) ? seq.first().getClass() : Object.class;
/* 1706 */     return seqToTypedArray(type, seq);
/*      */   }
/*      */   
/*      */   public static Object seqToTypedArray(Class type, ISeq seq) {
/* 1710 */     Object ret = Array.newInstance(type, length(seq));
/* 1711 */     if (type == Integer.TYPE) {
/* 1712 */       for (int i = 0; seq != null; seq = seq.next()) {
/* 1713 */         Array.set(ret, i, Integer.valueOf(intCast(seq.first())));i++;
/*      */       }
/* 1715 */     } else if (type == Byte.TYPE) {
/* 1716 */       for (int i = 0; seq != null; seq = seq.next()) {
/* 1717 */         Array.set(ret, i, Byte.valueOf(byteCast(seq.first())));i++;
/*      */       }
/* 1719 */     } else if (type == Float.TYPE) {
/* 1720 */       for (int i = 0; seq != null; seq = seq.next()) {
/* 1721 */         Array.set(ret, i, Float.valueOf(floatCast(seq.first())));i++;
/*      */       }
/* 1723 */     } else if (type == Short.TYPE) {
/* 1724 */       for (int i = 0; seq != null; seq = seq.next()) {
/* 1725 */         Array.set(ret, i, Short.valueOf(shortCast(seq.first())));i++;
/*      */       }
/* 1727 */     } else if (type == Character.TYPE) {
/* 1728 */       for (int i = 0; seq != null; seq = seq.next()) {
/* 1729 */         Array.set(ret, i, Character.valueOf(charCast(seq.first())));i++;
/*      */       }
/*      */     } else {
/* 1732 */       for (int i = 0; seq != null; seq = seq.next()) {
/* 1733 */         Array.set(ret, i, seq.first());i++;
/*      */       }
/*      */     }
/* 1736 */     return ret;
/*      */   }
/*      */   
/*      */   public static int length(ISeq list) {
/* 1740 */     int i = 0;
/* 1741 */     for (ISeq c = list; c != null; c = c.next()) {
/* 1742 */       i++;
/*      */     }
/* 1744 */     return i;
/*      */   }
/*      */   
/*      */   public static int boundedLength(ISeq list, int limit) {
/* 1748 */     int i = 0;
/* 1749 */     for (ISeq c = list; (c != null) && (i <= limit); c = c.next()) {
/* 1750 */       i++;
/*      */     }
/* 1752 */     return i;
/*      */   }
/*      */   
/*      */ 
/*      */   static Character readRet(int ret)
/*      */   {
/* 1758 */     if (ret == -1)
/* 1759 */       return null;
/* 1760 */     return box((char)ret);
/*      */   }
/*      */   
/*      */   public static Character readChar(Reader r) throws IOException {
/* 1764 */     int ret = r.read();
/* 1765 */     return readRet(ret);
/*      */   }
/*      */   
/*      */   public static Character peekChar(Reader r) throws IOException {
/*      */     int ret;
/* 1770 */     if ((r instanceof PushbackReader)) {
/* 1771 */       int ret = r.read();
/* 1772 */       ((PushbackReader)r).unread(ret);
/*      */     }
/*      */     else {
/* 1775 */       r.mark(1);
/* 1776 */       ret = r.read();
/* 1777 */       r.reset();
/*      */     }
/*      */     
/* 1780 */     return readRet(ret);
/*      */   }
/*      */   
/*      */   public static int getLineNumber(Reader r) {
/* 1784 */     if ((r instanceof LineNumberingPushbackReader))
/* 1785 */       return ((LineNumberingPushbackReader)r).getLineNumber();
/* 1786 */     return 0;
/*      */   }
/*      */   
/*      */   public static int getColumnNumber(Reader r) {
/* 1790 */     if ((r instanceof LineNumberingPushbackReader))
/* 1791 */       return ((LineNumberingPushbackReader)r).getColumnNumber();
/* 1792 */     return 0;
/*      */   }
/*      */   
/*      */   public static LineNumberingPushbackReader getLineNumberingReader(Reader r) {
/* 1796 */     if (isLineNumberingReader(r))
/* 1797 */       return (LineNumberingPushbackReader)r;
/* 1798 */     return new LineNumberingPushbackReader(r);
/*      */   }
/*      */   
/*      */   public static boolean isLineNumberingReader(Reader r) {
/* 1802 */     return r instanceof LineNumberingPushbackReader;
/*      */   }
/*      */   
/*      */   public static boolean isReduced(Object r) {
/* 1806 */     return r instanceof Reduced;
/*      */   }
/*      */   
/*      */   public static String resolveClassNameInContext(String className)
/*      */   {
/* 1811 */     return className;
/*      */   }
/*      */   
/*      */   public static boolean suppressRead() {
/* 1815 */     return booleanCast(SUPPRESS_READ.deref());
/*      */   }
/*      */   
/*      */   public static String printString(Object x) {
/*      */     try {
/* 1820 */       StringWriter sw = new StringWriter();
/* 1821 */       print(x, sw);
/* 1822 */       return sw.toString();
/*      */     }
/*      */     catch (Exception e) {
/* 1825 */       throw Util.sneakyThrow(e);
/*      */     }
/*      */   }
/*      */   
/*      */   public static Object readString(String s) {
/* 1830 */     return readString(s, null);
/*      */   }
/*      */   
/*      */   public static Object readString(String s, Object opts) {
/* 1834 */     PushbackReader r = new PushbackReader(new java.io.StringReader(s));
/* 1835 */     return LispReader.read(r, opts);
/*      */   }
/*      */   
/*      */   public static void print(Object x, Writer w) throws IOException
/*      */   {
/* 1840 */     if ((PRINT_INITIALIZED.isBound()) && (booleanCast(PRINT_INITIALIZED.deref()))) {
/* 1841 */       PR_ON.invoke(x, w);
/*      */     }
/*      */     else {
/* 1844 */       boolean readably = booleanCast(PRINT_READABLY.deref());
/* 1845 */       if ((x instanceof Obj)) {
/* 1846 */         Obj o = (Obj)x;
/* 1847 */         if ((count(o.meta()) > 0) && (((readably) && (booleanCast(PRINT_META.deref()))) || (booleanCast(PRINT_DUP.deref()))))
/*      */         {
/*      */ 
/* 1850 */           IPersistentMap meta = o.meta();
/* 1851 */           w.write("#^");
/* 1852 */           if ((meta.count() == 1) && (meta.containsKey(TAG_KEY))) {
/* 1853 */             print(meta.valAt(TAG_KEY), w);
/*      */           } else
/* 1855 */             print(meta, w);
/* 1856 */           w.write(32);
/*      */         }
/*      */       }
/* 1859 */       if (x == null) {
/* 1860 */         w.write("nil");
/* 1861 */       } else if (((x instanceof ISeq)) || ((x instanceof IPersistentList))) {
/* 1862 */         w.write(40);
/* 1863 */         printInnerSeq(seq(x), w);
/* 1864 */         w.write(41);
/*      */       }
/* 1866 */       else if ((x instanceof String)) {
/* 1867 */         String s = (String)x;
/* 1868 */         if (!readably) {
/* 1869 */           w.write(s);
/*      */         } else {
/* 1871 */           w.write(34);
/*      */           
/* 1873 */           for (int i = 0; i < s.length(); i++) {
/* 1874 */             char c = s.charAt(i);
/* 1875 */             switch (c) {
/*      */             case '\n': 
/* 1877 */               w.write("\\n");
/* 1878 */               break;
/*      */             case '\t': 
/* 1880 */               w.write("\\t");
/* 1881 */               break;
/*      */             case '\r': 
/* 1883 */               w.write("\\r");
/* 1884 */               break;
/*      */             case '"': 
/* 1886 */               w.write("\\\"");
/* 1887 */               break;
/*      */             case '\\': 
/* 1889 */               w.write("\\\\");
/* 1890 */               break;
/*      */             case '\f': 
/* 1892 */               w.write("\\f");
/* 1893 */               break;
/*      */             case '\b': 
/* 1895 */               w.write("\\b");
/* 1896 */               break;
/*      */             default: 
/* 1898 */               w.write(c);
/*      */             }
/*      */           }
/* 1901 */           w.write(34);
/*      */         }
/*      */       }
/* 1904 */       else if ((x instanceof IPersistentMap)) {
/* 1905 */         w.write(123);
/* 1906 */         for (ISeq s = seq(x); s != null; s = s.next()) {
/* 1907 */           IMapEntry e = (IMapEntry)s.first();
/* 1908 */           print(e.key(), w);
/* 1909 */           w.write(32);
/* 1910 */           print(e.val(), w);
/* 1911 */           if (s.next() != null)
/* 1912 */             w.write(", ");
/*      */         }
/* 1914 */         w.write(125);
/*      */       }
/* 1916 */       else if ((x instanceof IPersistentVector)) {
/* 1917 */         IPersistentVector a = (IPersistentVector)x;
/* 1918 */         w.write(91);
/* 1919 */         for (int i = 0; i < a.count(); i++) {
/* 1920 */           print(a.nth(i), w);
/* 1921 */           if (i < a.count() - 1)
/* 1922 */             w.write(32);
/*      */         }
/* 1924 */         w.write(93);
/*      */       }
/* 1926 */       else if ((x instanceof IPersistentSet)) {
/* 1927 */         w.write("#{");
/* 1928 */         for (ISeq s = seq(x); s != null; s = s.next()) {
/* 1929 */           print(s.first(), w);
/* 1930 */           if (s.next() != null)
/* 1931 */             w.write(" ");
/*      */         }
/* 1933 */         w.write(125);
/*      */       }
/* 1935 */       else if ((x instanceof Character)) {
/* 1936 */         char c = ((Character)x).charValue();
/* 1937 */         if (!readably) {
/* 1938 */           w.write(c);
/*      */         } else {
/* 1940 */           w.write(92);
/* 1941 */           switch (c) {
/*      */           case '\n': 
/* 1943 */             w.write("newline");
/* 1944 */             break;
/*      */           case '\t': 
/* 1946 */             w.write("tab");
/* 1947 */             break;
/*      */           case ' ': 
/* 1949 */             w.write("space");
/* 1950 */             break;
/*      */           case '\b': 
/* 1952 */             w.write("backspace");
/* 1953 */             break;
/*      */           case '\f': 
/* 1955 */             w.write("formfeed");
/* 1956 */             break;
/*      */           case '\r': 
/* 1958 */             w.write("return");
/* 1959 */             break;
/*      */           default: 
/* 1961 */             w.write(c);
/*      */           }
/*      */         }
/*      */       }
/* 1965 */       else if ((x instanceof Class)) {
/* 1966 */         w.write("#=");
/* 1967 */         w.write(((Class)x).getName());
/*      */       }
/* 1969 */       else if (((x instanceof BigDecimal)) && (readably)) {
/* 1970 */         w.write(x.toString());
/* 1971 */         w.write(77);
/*      */       }
/* 1973 */       else if (((x instanceof BigInt)) && (readably)) {
/* 1974 */         w.write(x.toString());
/* 1975 */         w.write(78);
/*      */       }
/* 1977 */       else if (((x instanceof BigInteger)) && (readably)) {
/* 1978 */         w.write(x.toString());
/* 1979 */         w.write("BIGINT");
/*      */       }
/* 1981 */       else if ((x instanceof Var)) {
/* 1982 */         Var v = (Var)x;
/* 1983 */         w.write("#=(var " + v.ns.name + "/" + v.sym + ")");
/*      */       }
/* 1985 */       else if ((x instanceof Pattern)) {
/* 1986 */         Pattern p = (Pattern)x;
/* 1987 */         w.write("#\"" + p.pattern() + "\"");
/*      */       } else {
/* 1989 */         w.write(x.toString());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private static void printInnerSeq(ISeq x, Writer w) throws IOException {
/* 1995 */     for (ISeq s = x; s != null; s = s.next()) {
/* 1996 */       print(s.first(), w);
/* 1997 */       if (s.next() != null)
/* 1998 */         w.write(32);
/*      */     }
/*      */   }
/*      */   
/*      */   public static void formatAesthetic(Writer w, Object obj) throws IOException {
/* 2003 */     if (obj == null) {
/* 2004 */       w.write("null");
/*      */     } else
/* 2006 */       w.write(obj.toString());
/*      */   }
/*      */   
/*      */   public static void formatStandard(Writer w, Object obj) throws IOException {
/* 2010 */     if (obj == null) {
/* 2011 */       w.write("null");
/* 2012 */     } else if ((obj instanceof String)) {
/* 2013 */       w.write(34);
/* 2014 */       w.write((String)obj);
/* 2015 */       w.write(34);
/*      */     }
/* 2017 */     else if ((obj instanceof Character)) {
/* 2018 */       w.write(92);
/* 2019 */       char c = ((Character)obj).charValue();
/* 2020 */       switch (c) {
/*      */       case '\n': 
/* 2022 */         w.write("newline");
/* 2023 */         break;
/*      */       case '\t': 
/* 2025 */         w.write("tab");
/* 2026 */         break;
/*      */       case ' ': 
/* 2028 */         w.write("space");
/* 2029 */         break;
/*      */       case '\b': 
/* 2031 */         w.write("backspace");
/* 2032 */         break;
/*      */       case '\f': 
/* 2034 */         w.write("formfeed");
/* 2035 */         break;
/*      */       default: 
/* 2037 */         w.write(c);
/*      */       }
/*      */     }
/*      */     else {
/* 2041 */       w.write(obj.toString());
/*      */     } }
/*      */   
/*      */   public static Object format(Object o, String s, Object... args) throws IOException { Writer w;
/*      */     Writer w;
/* 2046 */     if (o == null) {
/* 2047 */       w = new StringWriter(); } else { Writer w;
/* 2048 */       if (Util.equals(o, T)) {
/* 2049 */         w = (Writer)OUT.deref();
/*      */       } else
/* 2051 */         w = (Writer)o; }
/* 2052 */     doFormat(w, s, ArraySeq.create(args));
/* 2053 */     if (o == null)
/* 2054 */       return w.toString();
/* 2055 */     return null;
/*      */   }
/*      */   
/*      */   public static ISeq doFormat(Writer w, String s, ISeq args) throws IOException {
/* 2059 */     for (int i = 0; i < s.length();) {
/* 2060 */       char c = s.charAt(i++);
/* 2061 */       switch (Character.toLowerCase(c)) {
/*      */       case '~': 
/* 2063 */         char d = s.charAt(i++);
/* 2064 */         switch (Character.toLowerCase(d)) {
/*      */         case '%': 
/* 2066 */           w.write(10);
/* 2067 */           break;
/*      */         case 't': 
/* 2069 */           w.write(9);
/* 2070 */           break;
/*      */         case 'a': 
/* 2072 */           if (args == null)
/* 2073 */             throw new IllegalArgumentException("Missing argument");
/* 2074 */           formatAesthetic(w, first(args));
/* 2075 */           args = next(args);
/* 2076 */           break;
/*      */         case 's': 
/* 2078 */           if (args == null)
/* 2079 */             throw new IllegalArgumentException("Missing argument");
/* 2080 */           formatStandard(w, first(args));
/* 2081 */           args = next(args);
/* 2082 */           break;
/*      */         case '{': 
/* 2084 */           int j = s.indexOf("~}", i);
/* 2085 */           if (j == -1)
/* 2086 */             throw new IllegalArgumentException("Missing ~}");
/* 2087 */           String subs = s.substring(i, j);
/* 2088 */           for (ISeq sargs = seq(first(args)); sargs != null;)
/* 2089 */             sargs = doFormat(w, subs, sargs);
/* 2090 */           args = next(args);
/* 2091 */           i = j + 2;
/* 2092 */           break;
/*      */         case '^': 
/* 2094 */           if (args == null)
/* 2095 */             return null;
/*      */           break;
/*      */         case '~': 
/* 2098 */           w.write(126);
/* 2099 */           break;
/*      */         default: 
/* 2101 */           throw new IllegalArgumentException("Unsupported ~ directive: " + d);
/*      */         }
/* 2103 */         break;
/*      */       default: 
/* 2105 */         w.write(c);
/*      */       }
/*      */     }
/* 2108 */     return args;
/*      */   }
/*      */   
/*      */ 
/*      */   public static Object[] setValues(Object... vals)
/*      */   {
/* 2114 */     if (vals.length > 0)
/* 2115 */       return vals;
/* 2116 */     return null;
/*      */   }
/*      */   
/*      */   public static ClassLoader makeClassLoader()
/*      */   {
/* 2121 */     (ClassLoader)java.security.AccessController.doPrivileged(new java.security.PrivilegedAction() {
/*      */       public Object run() {
/*      */         try {
/* 2124 */           Var.pushThreadBindings(RT.map(new Object[] { RT.USE_CONTEXT_CLASSLOADER, RT.T }));
/*      */           
/* 2126 */           return new DynamicClassLoader(RT.baseLoader());
/*      */         }
/*      */         finally {
/* 2129 */           Var.popThreadBindings();
/*      */         }
/*      */       }
/*      */     });
/*      */   }
/*      */   
/*      */   public static ClassLoader baseLoader() {
/* 2136 */     if (Compiler.LOADER.isBound())
/* 2137 */       return (ClassLoader)Compiler.LOADER.deref();
/* 2138 */     if (booleanCast(USE_CONTEXT_CLASSLOADER.deref()))
/* 2139 */       return Thread.currentThread().getContextClassLoader();
/* 2140 */     return Compiler.class.getClassLoader();
/*      */   }
/*      */   
/*      */   public static InputStream resourceAsStream(ClassLoader loader, String name) {
/* 2144 */     if (loader == null) {
/* 2145 */       return ClassLoader.getSystemResourceAsStream(name);
/*      */     }
/* 2147 */     return loader.getResourceAsStream(name);
/*      */   }
/*      */   
/*      */   public static URL getResource(ClassLoader loader, String name)
/*      */   {
/* 2152 */     if (loader == null) {
/* 2153 */       return ClassLoader.getSystemResource(name);
/*      */     }
/* 2155 */     return loader.getResource(name);
/*      */   }
/*      */   
/*      */ 
/*      */   public static Class classForName(String name, boolean load, ClassLoader loader)
/*      */   {
/*      */     try
/*      */     {
/* 2163 */       Class c = null;
/* 2164 */       if (!(loader instanceof DynamicClassLoader))
/* 2165 */         c = DynamicClassLoader.findInMemoryClass(name);
/* 2166 */       if (c != null)
/* 2167 */         return c;
/* 2168 */       return Class.forName(name, load, loader);
/*      */     }
/*      */     catch (ClassNotFoundException e)
/*      */     {
/* 2172 */       throw Util.sneakyThrow(e);
/*      */     }
/*      */   }
/*      */   
/*      */   public static Class classForName(String name) {
/* 2177 */     return classForName(name, true, baseLoader());
/*      */   }
/*      */   
/*      */   public static Class classForNameNonLoading(String name) {
/* 2181 */     return classForName(name, false, baseLoader());
/*      */   }
/*      */   
/*      */   public static Class loadClassForName(String name)
/*      */   {
/*      */     try {
/* 2187 */       classForNameNonLoading(name);
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 2191 */       if ((e instanceof ClassNotFoundException)) {
/* 2192 */         return null;
/*      */       }
/* 2194 */       throw Util.sneakyThrow(e);
/*      */     }
/* 2196 */     return classForName(name);
/*      */   }
/*      */   
/*      */   public static float aget(float[] xs, int i) {
/* 2200 */     return xs[i];
/*      */   }
/*      */   
/*      */   public static float aset(float[] xs, int i, float v) {
/* 2204 */     xs[i] = v;
/* 2205 */     return v;
/*      */   }
/*      */   
/*      */   public static int alength(float[] xs) {
/* 2209 */     return xs.length;
/*      */   }
/*      */   
/*      */   public static float[] aclone(float[] xs) {
/* 2213 */     return (float[])xs.clone();
/*      */   }
/*      */   
/*      */   public static double aget(double[] xs, int i) {
/* 2217 */     return xs[i];
/*      */   }
/*      */   
/*      */   public static double aset(double[] xs, int i, double v) {
/* 2221 */     xs[i] = v;
/* 2222 */     return v;
/*      */   }
/*      */   
/*      */   public static int alength(double[] xs) {
/* 2226 */     return xs.length;
/*      */   }
/*      */   
/*      */   public static double[] aclone(double[] xs) {
/* 2230 */     return (double[])xs.clone();
/*      */   }
/*      */   
/*      */   public static int aget(int[] xs, int i) {
/* 2234 */     return xs[i];
/*      */   }
/*      */   
/*      */   public static int aset(int[] xs, int i, int v) {
/* 2238 */     xs[i] = v;
/* 2239 */     return v;
/*      */   }
/*      */   
/*      */   public static int alength(int[] xs) {
/* 2243 */     return xs.length;
/*      */   }
/*      */   
/*      */   public static int[] aclone(int[] xs) {
/* 2247 */     return (int[])xs.clone();
/*      */   }
/*      */   
/*      */   public static long aget(long[] xs, int i) {
/* 2251 */     return xs[i];
/*      */   }
/*      */   
/*      */   public static long aset(long[] xs, int i, long v) {
/* 2255 */     xs[i] = v;
/* 2256 */     return v;
/*      */   }
/*      */   
/*      */   public static int alength(long[] xs) {
/* 2260 */     return xs.length;
/*      */   }
/*      */   
/*      */   public static long[] aclone(long[] xs) {
/* 2264 */     return (long[])xs.clone();
/*      */   }
/*      */   
/*      */   public static char aget(char[] xs, int i) {
/* 2268 */     return xs[i];
/*      */   }
/*      */   
/*      */   public static char aset(char[] xs, int i, char v) {
/* 2272 */     xs[i] = v;
/* 2273 */     return v;
/*      */   }
/*      */   
/*      */   public static int alength(char[] xs) {
/* 2277 */     return xs.length;
/*      */   }
/*      */   
/*      */   public static char[] aclone(char[] xs) {
/* 2281 */     return (char[])xs.clone();
/*      */   }
/*      */   
/*      */   public static byte aget(byte[] xs, int i) {
/* 2285 */     return xs[i];
/*      */   }
/*      */   
/*      */   public static byte aset(byte[] xs, int i, byte v) {
/* 2289 */     xs[i] = v;
/* 2290 */     return v;
/*      */   }
/*      */   
/*      */   public static int alength(byte[] xs) {
/* 2294 */     return xs.length;
/*      */   }
/*      */   
/*      */   public static byte[] aclone(byte[] xs) {
/* 2298 */     return (byte[])xs.clone();
/*      */   }
/*      */   
/*      */   public static short aget(short[] xs, int i) {
/* 2302 */     return xs[i];
/*      */   }
/*      */   
/*      */   public static short aset(short[] xs, int i, short v) {
/* 2306 */     xs[i] = v;
/* 2307 */     return v;
/*      */   }
/*      */   
/*      */   public static int alength(short[] xs) {
/* 2311 */     return xs.length;
/*      */   }
/*      */   
/*      */   public static short[] aclone(short[] xs) {
/* 2315 */     return (short[])xs.clone();
/*      */   }
/*      */   
/*      */   public static boolean aget(boolean[] xs, int i) {
/* 2319 */     return xs[i];
/*      */   }
/*      */   
/*      */   public static boolean aset(boolean[] xs, int i, boolean v) {
/* 2323 */     xs[i] = v;
/* 2324 */     return v;
/*      */   }
/*      */   
/*      */   public static int alength(boolean[] xs) {
/* 2328 */     return xs.length;
/*      */   }
/*      */   
/*      */   public static boolean[] aclone(boolean[] xs) {
/* 2332 */     return (boolean[])xs.clone();
/*      */   }
/*      */   
/*      */   public static Object aget(Object[] xs, int i) {
/* 2336 */     return xs[i];
/*      */   }
/*      */   
/*      */   public static Object aset(Object[] xs, int i, Object v) {
/* 2340 */     xs[i] = v;
/* 2341 */     return v;
/*      */   }
/*      */   
/*      */   public static int alength(Object[] xs) {
/* 2345 */     return xs.length;
/*      */   }
/*      */   
/*      */   public static Object[] aclone(Object[] xs) {
/* 2349 */     return (Object[])xs.clone();
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\RT.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */