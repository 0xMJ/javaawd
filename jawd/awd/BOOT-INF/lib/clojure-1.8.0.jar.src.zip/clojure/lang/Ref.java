/*     */ package clojure.lang;
/*     */ 
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*     */ import java.util.concurrent.locks.ReentrantReadWriteLock.ReadLock;
/*     */ import java.util.concurrent.locks.ReentrantReadWriteLock.WriteLock;
/*     */ 
/*     */ public class Ref
/*     */   extends ARef
/*     */   implements IFn, Comparable<Ref>, IRef
/*     */ {
/*     */   TVal tvals;
/*     */   final AtomicInteger faults;
/*     */   final ReentrantReadWriteLock lock;
/*     */   LockingTransaction.Info tinfo;
/*     */   final long id;
/*     */   
/*     */   public int compareTo(Ref ref)
/*     */   {
/*  21 */     if (this.id == ref.id)
/*  22 */       return 0;
/*  23 */     if (this.id < ref.id) {
/*  24 */       return -1;
/*     */     }
/*  26 */     return 1;
/*     */   }
/*     */   
/*     */   public int getMinHistory() {
/*  30 */     return this.minHistory;
/*     */   }
/*     */   
/*     */   public Ref setMinHistory(int minHistory) {
/*  34 */     this.minHistory = minHistory;
/*  35 */     return this;
/*     */   }
/*     */   
/*     */   public int getMaxHistory() {
/*  39 */     return this.maxHistory;
/*     */   }
/*     */   
/*     */   public Ref setMaxHistory(int maxHistory) {
/*  43 */     this.maxHistory = maxHistory;
/*  44 */     return this;
/*     */   }
/*     */   
/*     */   public static class TVal {
/*     */     Object val;
/*     */     long point;
/*     */     TVal prior;
/*     */     TVal next;
/*     */     
/*     */     TVal(Object val, long point, TVal prior) {
/*  54 */       this.val = val;
/*  55 */       this.point = point;
/*  56 */       this.prior = prior;
/*  57 */       this.next = prior.next;
/*  58 */       this.prior.next = this;
/*  59 */       this.next.prior = this;
/*     */     }
/*     */     
/*     */     TVal(Object val, long point) {
/*  63 */       this.val = val;
/*  64 */       this.point = point;
/*  65 */       this.next = this;
/*  66 */       this.prior = this;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  78 */   volatile int minHistory = 0;
/*  79 */   volatile int maxHistory = 10;
/*     */   
/*  81 */   static final AtomicLong ids = new AtomicLong();
/*     */   
/*     */   public Ref(Object initVal) {
/*  84 */     this(initVal, null);
/*     */   }
/*     */   
/*     */   public Ref(Object initVal, IPersistentMap meta) {
/*  88 */     super(meta);
/*  89 */     this.id = ids.getAndIncrement();
/*  90 */     this.faults = new AtomicInteger();
/*  91 */     this.lock = new ReentrantReadWriteLock();
/*  92 */     this.tvals = new TVal(initVal, 0L);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   Object currentVal()
/*     */   {
/*     */     try
/*     */     {
/* 101 */       this.lock.readLock().lock();
/* 102 */       if (this.tvals != null)
/* 103 */         return this.tvals.val;
/* 104 */       throw new IllegalStateException(toString() + " is unbound.");
/*     */     }
/*     */     finally
/*     */     {
/* 108 */       this.lock.readLock().unlock();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public Object deref()
/*     */   {
/* 115 */     LockingTransaction t = LockingTransaction.getRunning();
/* 116 */     if (t == null)
/* 117 */       return currentVal();
/* 118 */     return t.doGet(this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object set(Object val)
/*     */   {
/* 162 */     return LockingTransaction.getEx().doSet(this, val);
/*     */   }
/*     */   
/*     */   public Object commute(IFn fn, ISeq args) {
/* 166 */     return LockingTransaction.getEx().doCommute(this, fn, args);
/*     */   }
/*     */   
/*     */   public Object alter(IFn fn, ISeq args) {
/* 170 */     LockingTransaction t = LockingTransaction.getEx();
/* 171 */     return t.doSet(this, fn.applyTo(RT.cons(t.doGet(this), args)));
/*     */   }
/*     */   
/*     */   public void touch() {
/* 175 */     LockingTransaction.getEx().doEnsure(this);
/*     */   }
/*     */   
/*     */   boolean isBound()
/*     */   {
/*     */     try
/*     */     {
/* 182 */       this.lock.readLock().lock();
/* 183 */       return this.tvals != null;
/*     */     }
/*     */     finally
/*     */     {
/* 187 */       this.lock.readLock().unlock();
/*     */     }
/*     */   }
/*     */   
/*     */   public void trimHistory()
/*     */   {
/*     */     try
/*     */     {
/* 195 */       this.lock.writeLock().lock();
/* 196 */       if (this.tvals != null)
/*     */       {
/* 198 */         this.tvals.next = this.tvals;
/* 199 */         this.tvals.prior = this.tvals;
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/* 204 */       this.lock.writeLock().unlock();
/*     */     }
/*     */   }
/*     */   
/*     */   public int getHistoryCount()
/*     */   {
/*     */     try {
/* 211 */       this.lock.writeLock().lock();
/* 212 */       return histCount();
/*     */     }
/*     */     finally
/*     */     {
/* 216 */       this.lock.writeLock().unlock();
/*     */     }
/*     */   }
/*     */   
/*     */   int histCount() {
/* 221 */     if (this.tvals == null) {
/* 222 */       return 0;
/*     */     }
/*     */     
/* 225 */     int count = 0;
/* 226 */     for (TVal tv = this.tvals.next; tv != this.tvals; tv = tv.next)
/* 227 */       count++;
/* 228 */     return count;
/*     */   }
/*     */   
/*     */   public final IFn fn()
/*     */   {
/* 233 */     return (IFn)deref();
/*     */   }
/*     */   
/*     */   public Object call() {
/* 237 */     return invoke();
/*     */   }
/*     */   
/*     */   public void run() {
/* 241 */     invoke();
/*     */   }
/*     */   
/*     */   public Object invoke() {
/* 245 */     return fn().invoke();
/*     */   }
/*     */   
/*     */   public Object invoke(Object arg1) {
/* 249 */     return fn().invoke(arg1);
/*     */   }
/*     */   
/*     */   public Object invoke(Object arg1, Object arg2) {
/* 253 */     return fn().invoke(arg1, arg2);
/*     */   }
/*     */   
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3) {
/* 257 */     return fn().invoke(arg1, arg2, arg3);
/*     */   }
/*     */   
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4) {
/* 261 */     return fn().invoke(arg1, arg2, arg3, arg4);
/*     */   }
/*     */   
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5) {
/* 265 */     return fn().invoke(arg1, arg2, arg3, arg4, arg5);
/*     */   }
/*     */   
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6) {
/* 269 */     return fn().invoke(arg1, arg2, arg3, arg4, arg5, arg6);
/*     */   }
/*     */   
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7)
/*     */   {
/* 274 */     return fn().invoke(arg1, arg2, arg3, arg4, arg5, arg6, arg7);
/*     */   }
/*     */   
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8)
/*     */   {
/* 279 */     return fn().invoke(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8);
/*     */   }
/*     */   
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9)
/*     */   {
/* 284 */     return fn().invoke(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9);
/*     */   }
/*     */   
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10)
/*     */   {
/* 289 */     return fn().invoke(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10);
/*     */   }
/*     */   
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11)
/*     */   {
/* 294 */     return fn().invoke(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11);
/*     */   }
/*     */   
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12)
/*     */   {
/* 299 */     return fn().invoke(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12);
/*     */   }
/*     */   
/*     */ 
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12, Object arg13)
/*     */   {
/* 305 */     return fn().invoke(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13);
/*     */   }
/*     */   
/*     */ 
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12, Object arg13, Object arg14)
/*     */   {
/* 311 */     return fn().invoke(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14);
/*     */   }
/*     */   
/*     */ 
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12, Object arg13, Object arg14, Object arg15)
/*     */   {
/* 317 */     return fn().invoke(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15);
/*     */   }
/*     */   
/*     */ 
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12, Object arg13, Object arg14, Object arg15, Object arg16)
/*     */   {
/* 323 */     return fn().invoke(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12, Object arg13, Object arg14, Object arg15, Object arg16, Object arg17)
/*     */   {
/* 330 */     return fn().invoke(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12, Object arg13, Object arg14, Object arg15, Object arg16, Object arg17, Object arg18)
/*     */   {
/* 337 */     return fn().invoke(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12, Object arg13, Object arg14, Object arg15, Object arg16, Object arg17, Object arg18, Object arg19)
/*     */   {
/* 344 */     return fn().invoke(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12, Object arg13, Object arg14, Object arg15, Object arg16, Object arg17, Object arg18, Object arg19, Object arg20)
/*     */   {
/* 352 */     return fn().invoke(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12, Object arg13, Object arg14, Object arg15, Object arg16, Object arg17, Object arg18, Object arg19, Object arg20, Object... args)
/*     */   {
/* 361 */     return fn().invoke(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15, arg16, arg17, arg18, arg19, arg20, args);
/*     */   }
/*     */   
/*     */   public Object applyTo(ISeq arglist)
/*     */   {
/* 366 */     return AFn.applyToHelper(this, arglist);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\Ref.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */