/*     */ package clojure.lang;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class LazySeq
/*     */   extends Obj
/*     */   implements ISeq, Sequential, List, IPending, IHashEq
/*     */ {
/*     */   private IFn fn;
/*     */   private Object sv;
/*     */   private ISeq s;
/*     */   
/*     */   public LazySeq(IFn fn)
/*     */   {
/*  24 */     this.fn = fn;
/*     */   }
/*     */   
/*     */   private LazySeq(IPersistentMap meta, ISeq s) {
/*  28 */     super(meta);
/*  29 */     this.fn = null;
/*  30 */     this.s = s;
/*     */   }
/*     */   
/*     */   public Obj withMeta(IPersistentMap meta) {
/*  34 */     return new LazySeq(meta, seq());
/*     */   }
/*     */   
/*     */   final synchronized Object sval() {
/*  38 */     if (this.fn != null)
/*     */     {
/*  40 */       this.sv = this.fn.invoke();
/*  41 */       this.fn = null;
/*     */     }
/*  43 */     if (this.sv != null)
/*  44 */       return this.sv;
/*  45 */     return this.s;
/*     */   }
/*     */   
/*     */   public final synchronized ISeq seq() {
/*  49 */     sval();
/*  50 */     if (this.sv != null)
/*     */     {
/*  52 */       Object ls = this.sv;
/*  53 */       this.sv = null;
/*  54 */       while ((ls instanceof LazySeq))
/*     */       {
/*  56 */         ls = ((LazySeq)ls).sval();
/*     */       }
/*  58 */       this.s = RT.seq(ls);
/*     */     }
/*  60 */     return this.s;
/*     */   }
/*     */   
/*     */   public int count() {
/*  64 */     int c = 0;
/*  65 */     for (ISeq s = seq(); s != null; s = s.next())
/*  66 */       c++;
/*  67 */     return c;
/*     */   }
/*     */   
/*     */   public Object first() {
/*  71 */     seq();
/*  72 */     if (this.s == null)
/*  73 */       return null;
/*  74 */     return this.s.first();
/*     */   }
/*     */   
/*     */   public ISeq next() {
/*  78 */     seq();
/*  79 */     if (this.s == null)
/*  80 */       return null;
/*  81 */     return this.s.next();
/*     */   }
/*     */   
/*     */   public ISeq more() {
/*  85 */     seq();
/*  86 */     if (this.s == null)
/*  87 */       return PersistentList.EMPTY;
/*  88 */     return this.s.more();
/*     */   }
/*     */   
/*     */   public ISeq cons(Object o) {
/*  92 */     return RT.cons(o, seq());
/*     */   }
/*     */   
/*     */   public IPersistentCollection empty() {
/*  96 */     return PersistentList.EMPTY;
/*     */   }
/*     */   
/*     */   public boolean equiv(Object o) {
/* 100 */     ISeq s = seq();
/* 101 */     if (s != null) {
/* 102 */       return s.equiv(o);
/*     */     }
/* 104 */     return (((o instanceof Sequential)) || ((o instanceof List))) && (RT.seq(o) == null);
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 108 */     ISeq s = seq();
/* 109 */     if (s == null)
/* 110 */       return 1;
/* 111 */     return Util.hash(s);
/*     */   }
/*     */   
/*     */   public int hasheq() {
/* 115 */     return Murmur3.hashOrdered(this);
/*     */   }
/*     */   
/*     */   public boolean equals(Object o) {
/* 119 */     ISeq s = seq();
/* 120 */     if (s != null) {
/* 121 */       return s.equals(o);
/*     */     }
/* 123 */     return (((o instanceof Sequential)) || ((o instanceof List))) && (RT.seq(o) == null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object[] toArray()
/*     */   {
/* 130 */     return RT.seqToArray(seq());
/*     */   }
/*     */   
/*     */   public boolean add(Object o) {
/* 134 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public boolean remove(Object o) {
/* 138 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public boolean addAll(Collection c) {
/* 142 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void clear() {
/* 146 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public boolean retainAll(Collection c) {
/* 150 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public boolean removeAll(Collection c) {
/* 154 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public boolean containsAll(Collection c) {
/* 158 */     for (Object o : c)
/*     */     {
/* 160 */       if (!contains(o))
/* 161 */         return false;
/*     */     }
/* 163 */     return true;
/*     */   }
/*     */   
/*     */   public Object[] toArray(Object[] a) {
/* 167 */     return RT.seqToPassedArray(seq(), a);
/*     */   }
/*     */   
/*     */   public int size() {
/* 171 */     return count();
/*     */   }
/*     */   
/*     */   public boolean isEmpty() {
/* 175 */     return seq() == null;
/*     */   }
/*     */   
/*     */   public boolean contains(Object o) {
/* 179 */     for (ISeq s = seq(); s != null; s = s.next())
/*     */     {
/* 181 */       if (Util.equiv(s.first(), o))
/* 182 */         return true;
/*     */     }
/* 184 */     return false;
/*     */   }
/*     */   
/*     */   public Iterator iterator() {
/* 188 */     return new SeqIterator(this);
/*     */   }
/*     */   
/*     */   private List reify()
/*     */   {
/* 193 */     return new ArrayList(this);
/*     */   }
/*     */   
/*     */   public List subList(int fromIndex, int toIndex) {
/* 197 */     return reify().subList(fromIndex, toIndex);
/*     */   }
/*     */   
/*     */   public Object set(int index, Object element) {
/* 201 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public Object remove(int index) {
/* 205 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public int indexOf(Object o) {
/* 209 */     ISeq s = seq();
/* 210 */     for (int i = 0; s != null; i++)
/*     */     {
/* 212 */       if (Util.equiv(s.first(), o)) {
/* 213 */         return i;
/*     */       }
/* 210 */       s = s.next();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 215 */     return -1;
/*     */   }
/*     */   
/*     */   public int lastIndexOf(Object o) {
/* 219 */     return reify().lastIndexOf(o);
/*     */   }
/*     */   
/*     */   public ListIterator listIterator() {
/* 223 */     return reify().listIterator();
/*     */   }
/*     */   
/*     */   public ListIterator listIterator(int index) {
/* 227 */     return reify().listIterator(index);
/*     */   }
/*     */   
/*     */   public Object get(int index) {
/* 231 */     return RT.nth(this, index);
/*     */   }
/*     */   
/*     */   public void add(int index, Object element) {
/* 235 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public boolean addAll(int index, Collection c) {
/* 239 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public synchronized boolean isRealized()
/*     */   {
/* 244 */     return this.fn == null;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\LazySeq.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */