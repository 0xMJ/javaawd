/*    */ package clojure.lang;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ArityException
/*    */   extends IllegalArgumentException
/*    */ {
/*    */   public final int actual;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public final String name;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ArityException(int actual, String name)
/*    */   {
/* 23 */     this(actual, name, null);
/*    */   }
/*    */   
/*    */   public ArityException(int actual, String name, Throwable cause) {
/* 27 */     super("Wrong number of args (" + actual + ") passed to: " + name, cause);
/* 28 */     this.actual = actual;
/* 29 */     this.name = name;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\ArityException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */