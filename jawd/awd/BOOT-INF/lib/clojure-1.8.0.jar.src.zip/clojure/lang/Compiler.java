/*      */ package clojure.lang;
/*      */ 
/*      */ import clojure.asm.Attribute;
/*      */ import clojure.asm.ByteVector;
/*      */ import clojure.asm.ClassVisitor;
/*      */ import clojure.asm.ClassWriter;
/*      */ import clojure.asm.FieldVisitor;
/*      */ import clojure.asm.Label;
/*      */ import clojure.asm.MethodVisitor;
/*      */ import clojure.asm.Opcodes;
/*      */ import clojure.asm.Type;
/*      */ import clojure.asm.commons.GeneratorAdapter;
/*      */ import java.io.File;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.PrintWriter;
/*      */ import java.io.Reader;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.lang.reflect.Field;
/*      */ import java.lang.reflect.Modifier;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.HashMap;
/*      */ import java.util.IdentityHashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Set;
/*      */ import java.util.SortedMap;
/*      */ import java.util.TreeMap;
/*      */ import java.util.regex.Matcher;
/*      */ import java.util.regex.Pattern;
/*      */ 
/*      */ public class Compiler implements Opcodes
/*      */ {
/*   40 */   static final Symbol DEF = Symbol.intern("def");
/*   41 */   static final Symbol LOOP = Symbol.intern("loop*");
/*   42 */   static final Symbol RECUR = Symbol.intern("recur");
/*   43 */   static final Symbol IF = Symbol.intern("if");
/*   44 */   static final Symbol LET = Symbol.intern("let*");
/*   45 */   static final Symbol LETFN = Symbol.intern("letfn*");
/*   46 */   static final Symbol DO = Symbol.intern("do");
/*   47 */   static final Symbol FN = Symbol.intern("fn*");
/*   48 */   static final Symbol FNONCE = (Symbol)Symbol.intern("fn*").withMeta(RT.map(new Object[] { Keyword.intern(null, "once"), RT.T }));
/*   49 */   static final Symbol QUOTE = Symbol.intern("quote");
/*   50 */   static final Symbol THE_VAR = Symbol.intern("var");
/*   51 */   static final Symbol DOT = Symbol.intern(".");
/*   52 */   static final Symbol ASSIGN = Symbol.intern("set!");
/*      */   
/*   54 */   static final Symbol TRY = Symbol.intern("try");
/*   55 */   static final Symbol CATCH = Symbol.intern("catch");
/*   56 */   static final Symbol FINALLY = Symbol.intern("finally");
/*   57 */   static final Symbol THROW = Symbol.intern("throw");
/*   58 */   static final Symbol MONITOR_ENTER = Symbol.intern("monitor-enter");
/*   59 */   static final Symbol MONITOR_EXIT = Symbol.intern("monitor-exit");
/*   60 */   static final Symbol IMPORT = Symbol.intern("clojure.core", "import*");
/*      */   
/*   62 */   static final Symbol DEFTYPE = Symbol.intern("deftype*");
/*   63 */   static final Symbol CASE = Symbol.intern("case*");
/*      */   
/*      */ 
/*   66 */   static final Symbol CLASS = Symbol.intern("Class");
/*   67 */   static final Symbol NEW = Symbol.intern("new");
/*   68 */   static final Symbol THIS = Symbol.intern("this");
/*   69 */   static final Symbol REIFY = Symbol.intern("reify*");
/*      */   
/*      */ 
/*      */ 
/*   73 */   static final Symbol LIST = Symbol.intern("clojure.core", "list");
/*   74 */   static final Symbol HASHMAP = Symbol.intern("clojure.core", "hash-map");
/*   75 */   static final Symbol VECTOR = Symbol.intern("clojure.core", "vector");
/*   76 */   static final Symbol IDENTITY = Symbol.intern("clojure.core", "identity");
/*      */   
/*   78 */   static final Symbol _AMP_ = Symbol.intern("&");
/*   79 */   static final Symbol ISEQ = Symbol.intern("clojure.lang.ISeq");
/*      */   
/*   81 */   static final Keyword loadNs = Keyword.intern(null, "load-ns");
/*   82 */   static final Keyword inlineKey = Keyword.intern(null, "inline");
/*   83 */   static final Keyword inlineAritiesKey = Keyword.intern(null, "inline-arities");
/*   84 */   static final Keyword staticKey = Keyword.intern(null, "static");
/*   85 */   static final Keyword arglistsKey = Keyword.intern(null, "arglists");
/*   86 */   static final Symbol INVOKE_STATIC = Symbol.intern("invokeStatic");
/*      */   
/*   88 */   static final Keyword volatileKey = Keyword.intern(null, "volatile");
/*   89 */   static final Keyword implementsKey = Keyword.intern(null, "implements");
/*      */   
/*      */   static final String COMPILE_STUB_PREFIX = "compile__stub";
/*   92 */   static final Keyword protocolKey = Keyword.intern(null, "protocol");
/*   93 */   static final Keyword onKey = Keyword.intern(null, "on");
/*   94 */   static Keyword dynamicKey = Keyword.intern("dynamic");
/*   95 */   static final Keyword redefKey = Keyword.intern(null, "redef");
/*      */   
/*   97 */   static final Symbol NS = Symbol.intern("ns");
/*   98 */   static final Symbol IN_NS = Symbol.intern("in-ns");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  105 */   public static final IPersistentMap specials = PersistentHashMap.create(new Object[] { DEF, new Compiler.DefExpr.Parser(), LOOP, new Compiler.LetExpr.Parser(), RECUR, new Compiler.RecurExpr.Parser(), IF, new Compiler.IfExpr.Parser(), CASE, new Compiler.CaseExpr.Parser(), LET, new Compiler.LetExpr.Parser(), LETFN, new Compiler.LetFnExpr.Parser(), DO, new Compiler.BodyExpr.Parser(), FN, null, QUOTE, new Compiler.ConstantExpr.Parser(), THE_VAR, new Compiler.TheVarExpr.Parser(), IMPORT, new Compiler.ImportExpr.Parser(), DOT, new Compiler.HostExpr.Parser(), ASSIGN, new Compiler.AssignExpr.Parser(), DEFTYPE, new Compiler.NewInstanceExpr.DeftypeParser(), REIFY, new Compiler.NewInstanceExpr.ReifyParser(), TRY, new Compiler.TryExpr.Parser(), THROW, new Compiler.ThrowExpr.Parser(), MONITOR_ENTER, new Compiler.MonitorEnterExpr.Parser(), MONITOR_EXIT, new Compiler.MonitorExitExpr.Parser(), CATCH, null, FINALLY, null, NEW, new Compiler.NewExpr.Parser(), _AMP_, null });
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int MAX_POSITIONAL_ARITY = 20;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final Type OBJECT_TYPE;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  142 */   private static final Type KEYWORD_TYPE = Type.getType(Keyword.class);
/*  143 */   private static final Type VAR_TYPE = Type.getType(Var.class);
/*  144 */   private static final Type SYMBOL_TYPE = Type.getType(Symbol.class);
/*      */   
/*  146 */   private static final Type IFN_TYPE = Type.getType(IFn.class);
/*  147 */   private static final Type AFUNCTION_TYPE = Type.getType(AFunction.class);
/*  148 */   private static final Type RT_TYPE = Type.getType(RT.class);
/*  149 */   private static final Type NUMBERS_TYPE = Type.getType(Numbers.class);
/*  150 */   static final Type CLASS_TYPE = Type.getType(Class.class);
/*  151 */   static final Type NS_TYPE = Type.getType(Namespace.class);
/*  152 */   static final Type UTIL_TYPE = Type.getType(Util.class);
/*  153 */   static final Type REFLECTOR_TYPE = Type.getType(Reflector.class);
/*  154 */   static final Type THROWABLE_TYPE = Type.getType(Throwable.class);
/*  155 */   static final Type BOOLEAN_OBJECT_TYPE = Type.getType(Boolean.class);
/*  156 */   static final Type IPERSISTENTMAP_TYPE = Type.getType(IPersistentMap.class);
/*  157 */   static final Type IOBJ_TYPE = Type.getType(IObj.class);
/*  158 */   static final Type TUPLE_TYPE = Type.getType(Tuple.class);
/*  159 */   static final clojure.asm.commons.Method[] createTupleMethods = { clojure.asm.commons.Method.getMethod("clojure.lang.IPersistentVector create()"), clojure.asm.commons.Method.getMethod("clojure.lang.IPersistentVector create(Object)"), clojure.asm.commons.Method.getMethod("clojure.lang.IPersistentVector create(Object,Object)"), clojure.asm.commons.Method.getMethod("clojure.lang.IPersistentVector create(Object,Object,Object)"), clojure.asm.commons.Method.getMethod("clojure.lang.IPersistentVector create(Object,Object,Object,Object)"), clojure.asm.commons.Method.getMethod("clojure.lang.IPersistentVector create(Object,Object,Object,Object,Object)"), clojure.asm.commons.Method.getMethod("clojure.lang.IPersistentVector create(Object,Object,Object,Object,Object,Object)") };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final Type[][] ARG_TYPES;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  170 */   private static final Type[] EXCEPTION_TYPES = new Type[0];
/*      */   
/*      */   public static final Var LOCAL_ENV;
/*      */   
/*      */   public static final Var LOOP_LOCALS;
/*      */   
/*      */   public static final Var LOOP_LABEL;
/*      */   
/*      */   public static final Var CONSTANTS;
/*      */   
/*      */   public static final Var CONSTANT_IDS;
/*      */   
/*      */   public static final Var KEYWORD_CALLSITES;
/*      */   
/*      */   public static final Var PROTOCOL_CALLSITES;
/*      */   
/*      */   public static final Var VAR_CALLSITES;
/*      */   
/*      */   public static final Var KEYWORDS;
/*      */   
/*      */   public static final Var VARS;
/*      */   
/*      */   public static final Var METHOD;
/*      */   
/*      */   public static final Var IN_CATCH_FINALLY;
/*      */   
/*      */   public static final Var NO_RECUR;
/*      */   
/*      */   public static final Var LOADER;
/*      */   
/*      */   public static final Var SOURCE;
/*      */   
/*      */   public static final Var SOURCE_PATH;
/*      */   
/*      */   public static final Var COMPILE_PATH;
/*      */   
/*      */   public static final Var COMPILE_FILES;
/*      */   
/*      */   public static final Var INSTANCE;
/*      */   
/*      */   public static final Var ADD_ANNOTATIONS;
/*      */   
/*      */   public static final Keyword disableLocalsClearingKey;
/*      */   
/*      */   public static final Keyword directLinkingKey;
/*      */   
/*      */   public static final Keyword elideMetaKey;
/*      */   
/*      */   public static final Var COMPILER_OPTIONS;
/*      */   
/*      */   public static final Var LINE;
/*      */   
/*      */   public static final Var COLUMN;
/*      */   
/*      */   public static final Var LINE_BEFORE;
/*      */   
/*      */   public static final Var COLUMN_BEFORE;
/*      */   
/*      */   public static final Var LINE_AFTER;
/*      */   
/*      */   public static final Var COLUMN_AFTER;
/*      */   
/*      */   public static final Var NEXT_LOCAL_NUM;
/*      */   
/*      */   public static final Var RET_LOCAL_NUM;
/*      */   
/*      */   public static final Var COMPILE_STUB_SYM;
/*      */   
/*      */   public static final Var COMPILE_STUB_CLASS;
/*      */   
/*      */   public static final Var CLEAR_PATH;
/*      */   
/*      */   public static final Var CLEAR_ROOT;
/*      */   
/*      */   public static final Var CLEAR_SITES;
/*      */   
/*      */   public static final Class RECUR_CLASS;
/*      */   
/*      */   static final NilExpr NIL_EXPR;
/*      */   
/*      */   static final BooleanExpr TRUE_EXPR;
/*      */   
/*      */   static final BooleanExpr FALSE_EXPR;
/*      */   
/*      */   public static final IPersistentMap CHAR_MAP;
/*      */   
/*      */   public static final IPersistentMap DEMUNGE_MAP;
/*      */   
/*      */   public static final Pattern DEMUNGE_PATTERN;
/*      */   
/*      */   public static Object getCompilerOption(Keyword k)
/*      */   {
/*  262 */     return RT.get(COMPILER_OPTIONS.deref(), k);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static Object elideMeta(Object m)
/*      */   {
/*  286 */     Collection<Object> elides = (Collection)getCompilerOption(elideMetaKey);
/*  287 */     if (elides != null)
/*      */     {
/*  289 */       for (Object k : elides)
/*      */       {
/*      */ 
/*  292 */         m = RT.dissoc(m, k);
/*      */       }
/*      */     }
/*      */     
/*  296 */     return m;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   static int lineDeref()
/*      */   {
/*  304 */     return ((Number)LINE.deref()).intValue();
/*      */   }
/*      */   
/*      */   static int columnDeref() {
/*  308 */     return ((Number)COLUMN.deref()).intValue();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static enum C
/*      */   {
/*  338 */     STATEMENT, 
/*  339 */     EXPRESSION, 
/*  340 */     RETURN, 
/*  341 */     EVAL;
/*      */     
/*      */     private C() {}
/*      */   }
/*      */   
/*      */   private class Recur {
/*      */     private Recur() {}
/*      */   }
/*      */   
/*      */   static abstract interface Expr {
/*      */     public abstract Object eval();
/*      */     
/*      */     public abstract void emit(Compiler.C paramC, Compiler.ObjExpr paramObjExpr, GeneratorAdapter paramGeneratorAdapter);
/*      */     
/*      */     public abstract boolean hasJavaClass();
/*      */     
/*      */     public abstract Class getJavaClass();
/*      */   }
/*      */   
/*  360 */   public static abstract class UntypedExpr implements Compiler.Expr { public Class getJavaClass() { throw new IllegalArgumentException("Has no Java class"); }
/*      */     
/*      */     public boolean hasJavaClass()
/*      */     {
/*  364 */       return false;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   static boolean isSpecial(Object sym)
/*      */   {
/*  373 */     return specials.containsKey(sym);
/*      */   }
/*      */   
/*      */   static Symbol resolveSymbol(Symbol sym)
/*      */   {
/*  378 */     if (sym.name.indexOf('.') > 0)
/*  379 */       return sym;
/*  380 */     if (sym.ns != null)
/*      */     {
/*  382 */       Namespace ns = namespaceFor(sym);
/*  383 */       if ((ns == null) || (ns.name.name == null ? sym.ns == null : ns.name.name.equals(sym.ns)))
/*  384 */         return sym;
/*  385 */       return Symbol.intern(ns.name.name, sym.name);
/*      */     }
/*  387 */     Object o = currentNS().getMapping(sym);
/*  388 */     if (o == null)
/*  389 */       return Symbol.intern(currentNS().name.name, sym.name);
/*  390 */     if ((o instanceof Class))
/*  391 */       return Symbol.intern(null, ((Class)o).getName());
/*  392 */     if ((o instanceof Var))
/*      */     {
/*  394 */       Var v = (Var)o;
/*  395 */       return Symbol.intern(v.ns.name.name, v.sym.name);
/*      */     }
/*  397 */     return null;
/*      */   }
/*      */   
/*      */   static abstract interface IParser { public abstract Compiler.Expr parse(Compiler.C paramC, Object paramObject); }
/*      */   
/*      */   static class DefExpr implements Compiler.Expr { public final Var var;
/*      */     public final Compiler.Expr init;
/*      */     public final Compiler.Expr meta;
/*      */     public final boolean initProvided;
/*      */     public final boolean isDynamic;
/*      */     public final boolean shadowsCoreMapping;
/*      */     public final String source;
/*      */     public final int line;
/*      */     public final int column;
/*  411 */     static final clojure.asm.commons.Method bindRootMethod = clojure.asm.commons.Method.getMethod("void bindRoot(Object)");
/*  412 */     static final clojure.asm.commons.Method setTagMethod = clojure.asm.commons.Method.getMethod("void setTag(clojure.lang.Symbol)");
/*  413 */     static final clojure.asm.commons.Method setMetaMethod = clojure.asm.commons.Method.getMethod("void setMeta(clojure.lang.IPersistentMap)");
/*  414 */     static final clojure.asm.commons.Method setDynamicMethod = clojure.asm.commons.Method.getMethod("clojure.lang.Var setDynamic(boolean)");
/*  415 */     static final clojure.asm.commons.Method symintern = clojure.asm.commons.Method.getMethod("clojure.lang.Symbol intern(String, String)");
/*  416 */     static final clojure.asm.commons.Method internVar = clojure.asm.commons.Method.getMethod("clojure.lang.Var refer(clojure.lang.Symbol, clojure.lang.Var)");
/*      */     
/*      */     public DefExpr(String source, int line, int column, Var var, Compiler.Expr init, Compiler.Expr meta, boolean initProvided, boolean isDynamic, boolean shadowsCoreMapping) {
/*  419 */       this.source = source;
/*  420 */       this.line = line;
/*  421 */       this.column = column;
/*  422 */       this.var = var;
/*  423 */       this.init = init;
/*  424 */       this.meta = meta;
/*  425 */       this.isDynamic = isDynamic;
/*  426 */       this.shadowsCoreMapping = shadowsCoreMapping;
/*  427 */       this.initProvided = initProvided;
/*      */     }
/*      */     
/*      */     private boolean includesExplicitMetadata(Compiler.MapExpr expr) {
/*  431 */       for (int i = 0; i < expr.keyvals.count(); i += 2)
/*      */       {
/*  433 */         Keyword k = ((Compiler.KeywordExpr)expr.keyvals.nth(i)).k;
/*  434 */         if ((k != RT.FILE_KEY) && (k != RT.DECLARED_KEY) && (k != RT.LINE_KEY) && (k != RT.COLUMN_KEY))
/*      */         {
/*      */ 
/*      */ 
/*  438 */           return true; }
/*      */       }
/*  440 */       return false;
/*      */     }
/*      */     
/*      */     public Object eval()
/*      */     {
/*      */       try {
/*  446 */         if (this.initProvided)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*  451 */           this.var.bindRoot(this.init.eval());
/*      */         }
/*  453 */         if (this.meta != null)
/*      */         {
/*  455 */           IPersistentMap metaMap = (IPersistentMap)this.meta.eval();
/*  456 */           if (!this.initProvided) {}
/*  457 */           this.var.setMeta(metaMap);
/*      */         }
/*  459 */         return this.var.setDynamic(this.isDynamic);
/*      */       }
/*      */       catch (Throwable e)
/*      */       {
/*  463 */         if (!(e instanceof Compiler.CompilerException)) {
/*  464 */           throw new Compiler.CompilerException(this.source, this.line, this.column, e);
/*      */         }
/*  466 */         throw ((Compiler.CompilerException)e);
/*      */       }
/*      */     }
/*      */     
/*      */     public void emit(Compiler.C context, Compiler.ObjExpr objx, GeneratorAdapter gen) {
/*  471 */       objx.emitVar(gen, this.var);
/*      */       
/*  473 */       if (this.shadowsCoreMapping)
/*      */       {
/*  475 */         gen.dup();
/*  476 */         gen.getField(Compiler.VAR_TYPE, "ns", Compiler.NS_TYPE);
/*  477 */         gen.swap();
/*  478 */         gen.dup();
/*  479 */         gen.getField(Compiler.VAR_TYPE, "sym", Compiler.SYMBOL_TYPE);
/*  480 */         gen.swap();
/*  481 */         gen.invokeVirtual(Compiler.NS_TYPE, internVar);
/*      */       }
/*      */       
/*  484 */       if (this.isDynamic)
/*      */       {
/*  486 */         gen.push(this.isDynamic);
/*  487 */         gen.invokeVirtual(Compiler.VAR_TYPE, setDynamicMethod);
/*      */       }
/*  489 */       if (this.meta != null)
/*      */       {
/*  491 */         if (!this.initProvided) {}
/*      */         
/*  493 */         gen.dup();
/*  494 */         this.meta.emit(Compiler.C.EXPRESSION, objx, gen);
/*  495 */         gen.checkCast(Compiler.IPERSISTENTMAP_TYPE);
/*  496 */         gen.invokeVirtual(Compiler.VAR_TYPE, setMetaMethod);
/*      */       }
/*      */       
/*  499 */       if (this.initProvided)
/*      */       {
/*  501 */         gen.dup();
/*  502 */         if ((this.init instanceof Compiler.FnExpr))
/*      */         {
/*  504 */           ((Compiler.FnExpr)this.init).emitForDefn(objx, gen);
/*      */         }
/*      */         else
/*  507 */           this.init.emit(Compiler.C.EXPRESSION, objx, gen);
/*  508 */         gen.invokeVirtual(Compiler.VAR_TYPE, bindRootMethod);
/*      */       }
/*      */       
/*  511 */       if (context == Compiler.C.STATEMENT)
/*  512 */         gen.pop();
/*      */     }
/*      */     
/*      */     public boolean hasJavaClass() {
/*  516 */       return true;
/*      */     }
/*      */     
/*      */     public Class getJavaClass() {
/*  520 */       return Var.class;
/*      */     }
/*      */     
/*      */     static class Parser implements Compiler.IParser
/*      */     {
/*      */       public Compiler.Expr parse(Compiler.C context, Object form) {
/*  526 */         String docstring = null;
/*  527 */         if ((RT.count(form) == 4) && ((RT.third(form) instanceof String))) {
/*  528 */           docstring = (String)RT.third(form);
/*  529 */           form = RT.list(RT.first(form), RT.second(form), RT.fourth(form));
/*      */         }
/*  531 */         if (RT.count(form) > 3)
/*  532 */           throw Util.runtimeException("Too many arguments to def");
/*  533 */         if (RT.count(form) < 2)
/*  534 */           throw Util.runtimeException("Too few arguments to def");
/*  535 */         if (!(RT.second(form) instanceof Symbol))
/*  536 */           throw Util.runtimeException("First argument to def must be a Symbol");
/*  537 */         Symbol sym = (Symbol)RT.second(form);
/*  538 */         Var v = Compiler.lookupVar(sym, true);
/*  539 */         if (v == null)
/*  540 */           throw Util.runtimeException("Can't refer to qualified var that doesn't exist");
/*  541 */         boolean shadowsCoreMapping = false;
/*  542 */         if (!v.ns.equals(Compiler.currentNS()))
/*      */         {
/*  544 */           if (sym.ns == null)
/*      */           {
/*  546 */             v = Compiler.currentNS().intern(sym);
/*  547 */             shadowsCoreMapping = true;
/*  548 */             Compiler.registerVar(v);
/*      */ 
/*      */           }
/*      */           else
/*      */           {
/*  553 */             throw Util.runtimeException("Can't create defs outside of current ns");
/*      */           } }
/*  555 */         IPersistentMap mm = sym.meta();
/*  556 */         boolean isDynamic = RT.booleanCast(RT.get(mm, Compiler.dynamicKey));
/*  557 */         if (isDynamic)
/*  558 */           v.setDynamic();
/*  559 */         if ((!isDynamic) && (sym.name.startsWith("*")) && (sym.name.endsWith("*")) && (sym.name.length() > 2))
/*      */         {
/*  561 */           RT.errPrintWriter().format("Warning: %1$s not declared dynamic and thus is not dynamically rebindable, but its name suggests otherwise. Please either indicate ^:dynamic %1$s or change the name. (%2$s:%3$d)\n", new Object[] { sym, Compiler.SOURCE_PATH.get(), Compiler.LINE.get() });
/*      */         }
/*      */         
/*      */ 
/*  565 */         if (RT.booleanCast(RT.get(mm, Compiler.arglistsKey)))
/*      */         {
/*  567 */           IPersistentMap vm = v.meta();
/*      */           
/*      */ 
/*  570 */           vm = (IPersistentMap)RT.assoc(vm, Compiler.arglistsKey, RT.second(mm.valAt(Compiler.arglistsKey)));
/*  571 */           v.setMeta(vm);
/*      */         }
/*  573 */         Object source_path = Compiler.SOURCE_PATH.get();
/*  574 */         source_path = source_path == null ? "NO_SOURCE_FILE" : source_path;
/*  575 */         mm = (IPersistentMap)RT.assoc(mm, RT.LINE_KEY, Compiler.LINE.get()).assoc(RT.COLUMN_KEY, Compiler.COLUMN.get()).assoc(RT.FILE_KEY, source_path);
/*  576 */         if (docstring != null) {
/*  577 */           mm = (IPersistentMap)RT.assoc(mm, RT.DOC_KEY, docstring);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  587 */         mm = (IPersistentMap)Compiler.elideMeta(mm);
/*  588 */         Compiler.Expr meta = mm.count() == 0 ? null : Compiler.analyze(context == Compiler.C.EVAL ? context : Compiler.C.EXPRESSION, mm);
/*  589 */         return new Compiler.DefExpr((String)Compiler.SOURCE.deref(), Compiler.lineDeref(), Compiler.columnDeref(), v, Compiler.analyze(context == Compiler.C.EVAL ? context : Compiler.C.EXPRESSION, RT.third(form), v.sym.name), meta, RT.count(form) == 3, isDynamic, shadowsCoreMapping);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public static class AssignExpr implements Compiler.Expr
/*      */   {
/*      */     public final Compiler.AssignableExpr target;
/*      */     public final Compiler.Expr val;
/*      */     
/*      */     public AssignExpr(Compiler.AssignableExpr target, Compiler.Expr val)
/*      */     {
/*  601 */       this.target = target;
/*  602 */       this.val = val;
/*      */     }
/*      */     
/*      */     public Object eval() {
/*  606 */       return this.target.evalAssign(this.val);
/*      */     }
/*      */     
/*      */     public void emit(Compiler.C context, Compiler.ObjExpr objx, GeneratorAdapter gen) {
/*  610 */       this.target.emitAssign(context, objx, gen, this.val);
/*      */     }
/*      */     
/*      */     public boolean hasJavaClass() {
/*  614 */       return this.val.hasJavaClass();
/*      */     }
/*      */     
/*      */     public Class getJavaClass() {
/*  618 */       return this.val.getJavaClass();
/*      */     }
/*      */     
/*      */     static class Parser implements Compiler.IParser {
/*      */       public Compiler.Expr parse(Compiler.C context, Object frm) {
/*  623 */         ISeq form = (ISeq)frm;
/*  624 */         if (RT.length(form) != 3)
/*  625 */           throw new IllegalArgumentException("Malformed assignment, expecting (set! target val)");
/*  626 */         Compiler.Expr target = Compiler.analyze(Compiler.C.EXPRESSION, RT.second(form));
/*  627 */         if (!(target instanceof Compiler.AssignableExpr))
/*  628 */           throw new IllegalArgumentException("Invalid assignment target");
/*  629 */         return new Compiler.AssignExpr((Compiler.AssignableExpr)target, Compiler.analyze(Compiler.C.EXPRESSION, RT.third(form)));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public static class VarExpr implements Compiler.Expr, Compiler.AssignableExpr {
/*      */     public final Var var;
/*      */     public final Object tag;
/*  637 */     static final clojure.asm.commons.Method getMethod = clojure.asm.commons.Method.getMethod("Object get()");
/*  638 */     static final clojure.asm.commons.Method setMethod = clojure.asm.commons.Method.getMethod("Object set(Object)");
/*      */     
/*      */     public VarExpr(Var var, Symbol tag) {
/*  641 */       this.var = var;
/*  642 */       this.tag = (tag != null ? tag : var.getTag());
/*      */     }
/*      */     
/*      */     public Object eval() {
/*  646 */       return this.var.deref();
/*      */     }
/*      */     
/*      */     public void emit(Compiler.C context, Compiler.ObjExpr objx, GeneratorAdapter gen) {
/*  650 */       objx.emitVarValue(gen, this.var);
/*  651 */       if (context == Compiler.C.STATEMENT)
/*      */       {
/*  653 */         gen.pop();
/*      */       }
/*      */     }
/*      */     
/*      */     public boolean hasJavaClass() {
/*  658 */       return this.tag != null;
/*      */     }
/*      */     
/*      */     public Class getJavaClass() {
/*  662 */       return Compiler.HostExpr.tagToClass(this.tag);
/*      */     }
/*      */     
/*      */     public Object evalAssign(Compiler.Expr val) {
/*  666 */       return this.var.set(val.eval());
/*      */     }
/*      */     
/*      */     public void emitAssign(Compiler.C context, Compiler.ObjExpr objx, GeneratorAdapter gen, Compiler.Expr val)
/*      */     {
/*  671 */       objx.emitVar(gen, this.var);
/*  672 */       val.emit(Compiler.C.EXPRESSION, objx, gen);
/*  673 */       gen.invokeVirtual(Compiler.VAR_TYPE, setMethod);
/*  674 */       if (context == Compiler.C.STATEMENT)
/*  675 */         gen.pop();
/*      */     }
/*      */   }
/*      */   
/*      */   public static class TheVarExpr implements Compiler.Expr {
/*      */     public final Var var;
/*      */     
/*      */     public TheVarExpr(Var var) {
/*  683 */       this.var = var;
/*      */     }
/*      */     
/*      */     public Object eval() {
/*  687 */       return this.var;
/*      */     }
/*      */     
/*      */     public void emit(Compiler.C context, Compiler.ObjExpr objx, GeneratorAdapter gen) {
/*  691 */       objx.emitVar(gen, this.var);
/*  692 */       if (context == Compiler.C.STATEMENT)
/*  693 */         gen.pop();
/*      */     }
/*      */     
/*      */     public boolean hasJavaClass() {
/*  697 */       return true;
/*      */     }
/*      */     
/*      */     public Class getJavaClass() {
/*  701 */       return Var.class;
/*      */     }
/*      */     
/*      */     static class Parser implements Compiler.IParser {
/*      */       public Compiler.Expr parse(Compiler.C context, Object form) {
/*  706 */         Symbol sym = (Symbol)RT.second(form);
/*  707 */         Var v = Compiler.lookupVar(sym, false);
/*  708 */         if (v != null)
/*  709 */           return new Compiler.TheVarExpr(v);
/*  710 */         throw Util.runtimeException("Unable to resolve var: " + sym + " in this context");
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public static class KeywordExpr extends Compiler.LiteralExpr {
/*      */     public final Keyword k;
/*      */     
/*      */     public KeywordExpr(Keyword k) {
/*  719 */       this.k = k;
/*      */     }
/*      */     
/*      */     Object val() {
/*  723 */       return this.k;
/*      */     }
/*      */     
/*      */     public Object eval() {
/*  727 */       return this.k;
/*      */     }
/*      */     
/*      */     public void emit(Compiler.C context, Compiler.ObjExpr objx, GeneratorAdapter gen) {
/*  731 */       objx.emitKeyword(gen, this.k);
/*  732 */       if (context == Compiler.C.STATEMENT) {
/*  733 */         gen.pop();
/*      */       }
/*      */     }
/*      */     
/*      */     public boolean hasJavaClass() {
/*  738 */       return true;
/*      */     }
/*      */     
/*      */     public Class getJavaClass() {
/*  742 */       return Keyword.class;
/*      */     }
/*      */   }
/*      */   
/*      */   public static class ImportExpr implements Compiler.Expr {
/*      */     public final String c;
/*  748 */     static final clojure.asm.commons.Method forNameMethod = clojure.asm.commons.Method.getMethod("Class classForNameNonLoading(String)");
/*  749 */     static final clojure.asm.commons.Method importClassMethod = clojure.asm.commons.Method.getMethod("Class importClass(Class)");
/*  750 */     static final clojure.asm.commons.Method derefMethod = clojure.asm.commons.Method.getMethod("Object deref()");
/*      */     
/*      */     public ImportExpr(String c) {
/*  753 */       this.c = c;
/*      */     }
/*      */     
/*      */     public Object eval() {
/*  757 */       Namespace ns = (Namespace)RT.CURRENT_NS.deref();
/*  758 */       ns.importClass(RT.classForNameNonLoading(this.c));
/*  759 */       return null;
/*      */     }
/*      */     
/*      */     public void emit(Compiler.C context, Compiler.ObjExpr objx, GeneratorAdapter gen) {
/*  763 */       gen.getStatic(Compiler.RT_TYPE, "CURRENT_NS", Compiler.VAR_TYPE);
/*  764 */       gen.invokeVirtual(Compiler.VAR_TYPE, derefMethod);
/*  765 */       gen.checkCast(Compiler.NS_TYPE);
/*  766 */       gen.push(this.c);
/*  767 */       gen.invokeStatic(Compiler.RT_TYPE, forNameMethod);
/*  768 */       gen.invokeVirtual(Compiler.NS_TYPE, importClassMethod);
/*  769 */       if (context == Compiler.C.STATEMENT)
/*  770 */         gen.pop();
/*      */     }
/*      */     
/*      */     public boolean hasJavaClass() {
/*  774 */       return false;
/*      */     }
/*      */     
/*      */     public Class getJavaClass() {
/*  778 */       throw new IllegalArgumentException("ImportExpr has no Java class");
/*      */     }
/*      */     
/*      */     static class Parser implements Compiler.IParser {
/*      */       public Compiler.Expr parse(Compiler.C context, Object form) {
/*  783 */         return new Compiler.ImportExpr((String)RT.second(form));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public static abstract class LiteralExpr
/*      */     implements Compiler.Expr {
/*      */     abstract Object val();
/*      */     
/*  792 */     public Object eval() { return val(); }
/*      */   }
/*      */   
/*      */   static abstract interface AssignableExpr {
/*      */     public abstract Object evalAssign(Compiler.Expr paramExpr);
/*      */     
/*      */     public abstract void emitAssign(Compiler.C paramC, Compiler.ObjExpr paramObjExpr, GeneratorAdapter paramGeneratorAdapter, Compiler.Expr paramExpr);
/*      */   }
/*      */   
/*      */   public static abstract interface MaybePrimitiveExpr extends Compiler.Expr {
/*      */     public abstract boolean canEmitPrimitive();
/*      */     
/*      */     public abstract void emitUnboxed(Compiler.C paramC, Compiler.ObjExpr paramObjExpr, GeneratorAdapter paramGeneratorAdapter);
/*      */   }
/*      */   
/*      */   public static abstract class HostExpr implements Compiler.Expr, Compiler.MaybePrimitiveExpr {
/*  808 */     static final Type BOOLEAN_TYPE = Type.getType(Boolean.class);
/*  809 */     static final Type CHAR_TYPE = Type.getType(Character.class);
/*  810 */     static final Type INTEGER_TYPE = Type.getType(Integer.class);
/*  811 */     static final Type LONG_TYPE = Type.getType(Long.class);
/*  812 */     static final Type FLOAT_TYPE = Type.getType(Float.class);
/*  813 */     static final Type DOUBLE_TYPE = Type.getType(Double.class);
/*  814 */     static final Type SHORT_TYPE = Type.getType(Short.class);
/*  815 */     static final Type BYTE_TYPE = Type.getType(Byte.class);
/*  816 */     static final Type NUMBER_TYPE = Type.getType(Number.class);
/*      */     
/*  818 */     static final clojure.asm.commons.Method charValueMethod = clojure.asm.commons.Method.getMethod("char charValue()");
/*  819 */     static final clojure.asm.commons.Method booleanValueMethod = clojure.asm.commons.Method.getMethod("boolean booleanValue()");
/*      */     
/*  821 */     static final clojure.asm.commons.Method charValueOfMethod = clojure.asm.commons.Method.getMethod("Character valueOf(char)");
/*  822 */     static final clojure.asm.commons.Method intValueOfMethod = clojure.asm.commons.Method.getMethod("Integer valueOf(int)");
/*  823 */     static final clojure.asm.commons.Method longValueOfMethod = clojure.asm.commons.Method.getMethod("Long valueOf(long)");
/*  824 */     static final clojure.asm.commons.Method floatValueOfMethod = clojure.asm.commons.Method.getMethod("Float valueOf(float)");
/*  825 */     static final clojure.asm.commons.Method doubleValueOfMethod = clojure.asm.commons.Method.getMethod("Double valueOf(double)");
/*  826 */     static final clojure.asm.commons.Method shortValueOfMethod = clojure.asm.commons.Method.getMethod("Short valueOf(short)");
/*  827 */     static final clojure.asm.commons.Method byteValueOfMethod = clojure.asm.commons.Method.getMethod("Byte valueOf(byte)");
/*      */     
/*  829 */     static final clojure.asm.commons.Method intValueMethod = clojure.asm.commons.Method.getMethod("int intValue()");
/*  830 */     static final clojure.asm.commons.Method longValueMethod = clojure.asm.commons.Method.getMethod("long longValue()");
/*  831 */     static final clojure.asm.commons.Method floatValueMethod = clojure.asm.commons.Method.getMethod("float floatValue()");
/*  832 */     static final clojure.asm.commons.Method doubleValueMethod = clojure.asm.commons.Method.getMethod("double doubleValue()");
/*  833 */     static final clojure.asm.commons.Method byteValueMethod = clojure.asm.commons.Method.getMethod("byte byteValue()");
/*  834 */     static final clojure.asm.commons.Method shortValueMethod = clojure.asm.commons.Method.getMethod("short shortValue()");
/*      */     
/*  836 */     static final clojure.asm.commons.Method fromIntMethod = clojure.asm.commons.Method.getMethod("clojure.lang.Num from(int)");
/*  837 */     static final clojure.asm.commons.Method fromLongMethod = clojure.asm.commons.Method.getMethod("clojure.lang.Num from(long)");
/*  838 */     static final clojure.asm.commons.Method fromDoubleMethod = clojure.asm.commons.Method.getMethod("clojure.lang.Num from(double)");
/*      */     
/*      */ 
/*      */     public static void emitBoxReturn(Compiler.ObjExpr objx, GeneratorAdapter gen, Class returnType)
/*      */     {
/*  843 */       if (returnType.isPrimitive())
/*      */       {
/*  845 */         if (returnType == Boolean.TYPE)
/*      */         {
/*  847 */           Label falseLabel = gen.newLabel();
/*  848 */           Label endLabel = gen.newLabel();
/*  849 */           gen.ifZCmp(153, falseLabel);
/*  850 */           gen.getStatic(Compiler.BOOLEAN_OBJECT_TYPE, "TRUE", Compiler.BOOLEAN_OBJECT_TYPE);
/*  851 */           gen.goTo(endLabel);
/*  852 */           gen.mark(falseLabel);
/*  853 */           gen.getStatic(Compiler.BOOLEAN_OBJECT_TYPE, "FALSE", Compiler.BOOLEAN_OBJECT_TYPE);
/*      */           
/*  855 */           gen.mark(endLabel);
/*      */         }
/*  857 */         else if (returnType == Void.TYPE)
/*      */         {
/*  859 */           Compiler.NIL_EXPR.emit(Compiler.C.EXPRESSION, objx, gen);
/*      */         }
/*  861 */         else if (returnType == Character.TYPE)
/*      */         {
/*  863 */           gen.invokeStatic(CHAR_TYPE, charValueOfMethod);
/*      */ 
/*      */ 
/*      */         }
/*  867 */         else if (returnType == Integer.TYPE)
/*      */         {
/*  869 */           gen.invokeStatic(INTEGER_TYPE, intValueOfMethod);
/*      */ 
/*      */ 
/*      */         }
/*  873 */         else if (returnType == Float.TYPE)
/*      */         {
/*  875 */           gen.invokeStatic(FLOAT_TYPE, floatValueOfMethod);
/*      */ 
/*      */ 
/*      */ 
/*      */         }
/*  880 */         else if (returnType == Double.TYPE) {
/*  881 */           gen.invokeStatic(DOUBLE_TYPE, doubleValueOfMethod);
/*  882 */         } else if (returnType == Long.TYPE) {
/*  883 */           gen.invokeStatic(Compiler.NUMBERS_TYPE, clojure.asm.commons.Method.getMethod("Number num(long)"));
/*  884 */         } else if (returnType == Byte.TYPE) {
/*  885 */           gen.invokeStatic(BYTE_TYPE, byteValueOfMethod);
/*  886 */         } else if (returnType == Short.TYPE) {
/*  887 */           gen.invokeStatic(SHORT_TYPE, shortValueOfMethod);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */     public static void emitUnboxArg(Compiler.ObjExpr objx, GeneratorAdapter gen, Class paramType)
/*      */     {
/*  894 */       if (paramType.isPrimitive())
/*      */       {
/*  896 */         if (paramType == Boolean.TYPE)
/*      */         {
/*  898 */           gen.checkCast(BOOLEAN_TYPE);
/*  899 */           gen.invokeVirtual(BOOLEAN_TYPE, booleanValueMethod);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         }
/*  909 */         else if (paramType == Character.TYPE)
/*      */         {
/*  911 */           gen.checkCast(CHAR_TYPE);
/*  912 */           gen.invokeVirtual(CHAR_TYPE, charValueMethod);
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/*  917 */           clojure.asm.commons.Method m = null;
/*  918 */           gen.checkCast(NUMBER_TYPE);
/*  919 */           if (RT.booleanCast(RT.UNCHECKED_MATH.deref()))
/*      */           {
/*  921 */             if (paramType == Integer.TYPE) {
/*  922 */               m = clojure.asm.commons.Method.getMethod("int uncheckedIntCast(Object)");
/*  923 */             } else if (paramType == Float.TYPE) {
/*  924 */               m = clojure.asm.commons.Method.getMethod("float uncheckedFloatCast(Object)");
/*  925 */             } else if (paramType == Double.TYPE) {
/*  926 */               m = clojure.asm.commons.Method.getMethod("double uncheckedDoubleCast(Object)");
/*  927 */             } else if (paramType == Long.TYPE) {
/*  928 */               m = clojure.asm.commons.Method.getMethod("long uncheckedLongCast(Object)");
/*  929 */             } else if (paramType == Byte.TYPE) {
/*  930 */               m = clojure.asm.commons.Method.getMethod("byte uncheckedByteCast(Object)");
/*  931 */             } else if (paramType == Short.TYPE) {
/*  932 */               m = clojure.asm.commons.Method.getMethod("short uncheckedShortCast(Object)");
/*      */             }
/*      */             
/*      */           }
/*  936 */           else if (paramType == Integer.TYPE) {
/*  937 */             m = clojure.asm.commons.Method.getMethod("int intCast(Object)");
/*  938 */           } else if (paramType == Float.TYPE) {
/*  939 */             m = clojure.asm.commons.Method.getMethod("float floatCast(Object)");
/*  940 */           } else if (paramType == Double.TYPE) {
/*  941 */             m = clojure.asm.commons.Method.getMethod("double doubleCast(Object)");
/*  942 */           } else if (paramType == Long.TYPE) {
/*  943 */             m = clojure.asm.commons.Method.getMethod("long longCast(Object)");
/*  944 */           } else if (paramType == Byte.TYPE) {
/*  945 */             m = clojure.asm.commons.Method.getMethod("byte byteCast(Object)");
/*  946 */           } else if (paramType == Short.TYPE) {
/*  947 */             m = clojure.asm.commons.Method.getMethod("short shortCast(Object)");
/*      */           }
/*  949 */           gen.invokeStatic(Compiler.RT_TYPE, m);
/*      */         }
/*      */         
/*      */       }
/*      */       else {
/*  954 */         gen.checkCast(Type.getType(paramType));
/*      */       }
/*      */     }
/*      */     
/*      */     static class Parser implements Compiler.IParser {
/*      */       public Compiler.Expr parse(Compiler.C context, Object frm) {
/*  960 */         ISeq form = (ISeq)frm;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  965 */         if (RT.length(form) < 3) {
/*  966 */           throw new IllegalArgumentException("Malformed member expression, expecting (. target member ...)");
/*      */         }
/*      */         
/*  969 */         int line = Compiler.lineDeref();
/*  970 */         int column = Compiler.columnDeref();
/*  971 */         String source = (String)Compiler.SOURCE.deref();
/*  972 */         Class c = Compiler.HostExpr.maybeClass(RT.second(form), false);
/*      */         
/*  974 */         Compiler.Expr instance = null;
/*  975 */         if (c == null) {
/*  976 */           instance = Compiler.analyze(context == Compiler.C.EVAL ? context : Compiler.C.EXPRESSION, RT.second(form));
/*      */         }
/*  978 */         boolean maybeField = (RT.length(form) == 3) && ((RT.third(form) instanceof Symbol));
/*      */         
/*  980 */         if ((maybeField) && (((Symbol)RT.third(form)).name.charAt(0) != '-'))
/*      */         {
/*  982 */           Symbol sym = (Symbol)RT.third(form);
/*  983 */           if (c != null) {
/*  984 */             maybeField = Reflector.getMethods(c, 0, Compiler.munge(sym.name), true).size() == 0;
/*  985 */           } else if ((instance != null) && (instance.hasJavaClass()) && (instance.getJavaClass() != null)) {
/*  986 */             maybeField = Reflector.getMethods(instance.getJavaClass(), 0, Compiler.munge(sym.name), false).size() == 0;
/*      */           }
/*      */         }
/*  989 */         if (maybeField)
/*      */         {
/*  991 */           Symbol sym = ((Symbol)RT.third(form)).name.charAt(0) == '-' ? Symbol.intern(((Symbol)RT.third(form)).name.substring(1)) : (Symbol)RT.third(form);
/*      */           
/*      */ 
/*  994 */           Symbol tag = Compiler.tagOf(form);
/*  995 */           if (c != null) {
/*  996 */             return new Compiler.StaticFieldExpr(line, column, c, Compiler.munge(sym.name), tag);
/*      */           }
/*  998 */           return new Compiler.InstanceFieldExpr(line, column, instance, Compiler.munge(sym.name), tag, ((Symbol)RT.third(form)).name.charAt(0) == '-');
/*      */         }
/*      */         
/*      */ 
/* 1002 */         ISeq call = (ISeq)((RT.third(form) instanceof ISeq) ? RT.third(form) : RT.next(RT.next(form)));
/* 1003 */         if (!(RT.first(call) instanceof Symbol))
/* 1004 */           throw new IllegalArgumentException("Malformed member expression");
/* 1005 */         Symbol sym = (Symbol)RT.first(call);
/* 1006 */         Symbol tag = Compiler.tagOf(form);
/* 1007 */         PersistentVector args = PersistentVector.EMPTY;
/* 1008 */         for (ISeq s = RT.next(call); s != null; s = s.next())
/* 1009 */           args = args.cons(Compiler.analyze(context == Compiler.C.EVAL ? context : Compiler.C.EXPRESSION, s.first()));
/* 1010 */         if (c != null) {
/* 1011 */           return new Compiler.StaticMethodExpr(source, line, column, tag, c, Compiler.munge(sym.name), args);
/*      */         }
/* 1013 */         return new Compiler.InstanceMethodExpr(source, line, column, tag, instance, Compiler.munge(sym.name), args);
/*      */       }
/*      */     }
/*      */     
/*      */     public static Class maybeClass(Object form, boolean stringOk)
/*      */     {
/* 1019 */       if ((form instanceof Class))
/* 1020 */         return (Class)form;
/* 1021 */       Class c = null;
/* 1022 */       if ((form instanceof Symbol))
/*      */       {
/* 1024 */         Symbol sym = (Symbol)form;
/* 1025 */         if (sym.ns == null)
/*      */         {
/* 1027 */           if (Util.equals(sym, Compiler.COMPILE_STUB_SYM.get()))
/* 1028 */             return (Class)Compiler.COMPILE_STUB_CLASS.get();
/* 1029 */           if ((sym.name.indexOf('.') > 0) || (sym.name.charAt(0) == '[')) {
/* 1030 */             c = RT.classForName(sym.name);
/*      */           }
/*      */           else {
/* 1033 */             Object o = Compiler.currentNS().getMapping(sym);
/* 1034 */             if ((o instanceof Class)) {
/* 1035 */               c = (Class)o;
/* 1036 */             } else { if ((Compiler.LOCAL_ENV.deref() != null) && (((Map)Compiler.LOCAL_ENV.deref()).containsKey(form))) {
/* 1037 */                 return null;
/*      */               }
/*      */               try
/*      */               {
/* 1041 */                 c = RT.classForName(sym.name);
/*      */ 
/*      */               }
/*      */               catch (Exception e) {}
/*      */             }
/*      */             
/*      */           }
/*      */           
/*      */         }
/*      */       }
/* 1051 */       else if ((stringOk) && ((form instanceof String))) {
/* 1052 */         c = RT.classForName((String)form); }
/* 1053 */       return c;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public static Class maybeSpecialTag(Symbol sym)
/*      */     {
/* 1079 */       Class c = Compiler.primClass(sym);
/* 1080 */       if (c != null)
/* 1081 */         return c;
/* 1082 */       if (sym.name.equals("objects")) {
/* 1083 */         c = Object[].class;
/* 1084 */       } else if (sym.name.equals("ints")) {
/* 1085 */         c = int[].class;
/* 1086 */       } else if (sym.name.equals("longs")) {
/* 1087 */         c = long[].class;
/* 1088 */       } else if (sym.name.equals("floats")) {
/* 1089 */         c = float[].class;
/* 1090 */       } else if (sym.name.equals("doubles")) {
/* 1091 */         c = double[].class;
/* 1092 */       } else if (sym.name.equals("chars")) {
/* 1093 */         c = char[].class;
/* 1094 */       } else if (sym.name.equals("shorts")) {
/* 1095 */         c = short[].class;
/* 1096 */       } else if (sym.name.equals("bytes")) {
/* 1097 */         c = byte[].class;
/* 1098 */       } else if (sym.name.equals("booleans"))
/* 1099 */         c = boolean[].class;
/* 1100 */       return c;
/*      */     }
/*      */     
/*      */     static Class tagToClass(Object tag)
/*      */     {
/* 1105 */       Class c = null;
/* 1106 */       if ((tag instanceof Symbol))
/*      */       {
/* 1108 */         Symbol sym = (Symbol)tag;
/* 1109 */         if (sym.ns == null)
/*      */         {
/* 1111 */           c = maybeSpecialTag(sym);
/*      */         }
/*      */       }
/* 1114 */       if (c == null)
/* 1115 */         c = maybeClass(tag, true);
/* 1116 */       if (c != null)
/* 1117 */         return c;
/* 1118 */       throw new IllegalArgumentException("Unable to resolve classname: " + tag);
/*      */     }
/*      */   }
/*      */   
/*      */   static abstract class FieldExpr extends Compiler.HostExpr
/*      */   {}
/*      */   
/*      */   static class InstanceFieldExpr extends Compiler.FieldExpr implements Compiler.AssignableExpr {
/*      */     public final Compiler.Expr target;
/*      */     public final Class targetClass;
/*      */     public final Field field;
/*      */     public final String fieldName;
/*      */     public final int line;
/*      */     public final int column;
/*      */     public final Symbol tag;
/*      */     public final boolean requireField;
/* 1134 */     static final clojure.asm.commons.Method invokeNoArgInstanceMember = clojure.asm.commons.Method.getMethod("Object invokeNoArgInstanceMember(Object,String,boolean)");
/* 1135 */     static final clojure.asm.commons.Method setInstanceFieldMethod = clojure.asm.commons.Method.getMethod("Object setInstanceField(Object,String,Object)");
/*      */     
/*      */     public InstanceFieldExpr(int line, int column, Compiler.Expr target, String fieldName, Symbol tag, boolean requireField)
/*      */     {
/* 1139 */       this.target = target;
/* 1140 */       this.targetClass = (target.hasJavaClass() ? target.getJavaClass() : null);
/* 1141 */       this.field = (this.targetClass != null ? Reflector.getField(this.targetClass, fieldName, false) : null);
/* 1142 */       this.fieldName = fieldName;
/* 1143 */       this.line = line;
/* 1144 */       this.column = column;
/* 1145 */       this.tag = tag;
/* 1146 */       this.requireField = requireField;
/* 1147 */       if ((this.field == null) && (RT.booleanCast(RT.WARN_ON_REFLECTION.deref())))
/*      */       {
/* 1149 */         if (this.targetClass == null)
/*      */         {
/* 1151 */           RT.errPrintWriter().format("Reflection warning, %s:%d:%d - reference to field %s can't be resolved.\n", new Object[] { Compiler.SOURCE_PATH.deref(), Integer.valueOf(line), Integer.valueOf(column), fieldName });
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/*      */ 
/* 1157 */           RT.errPrintWriter().format("Reflection warning, %s:%d:%d - reference to field %s on %s can't be resolved.\n", new Object[] { Compiler.SOURCE_PATH.deref(), Integer.valueOf(line), Integer.valueOf(column), fieldName, this.targetClass.getName() });
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */     public Object eval()
/*      */     {
/* 1165 */       return Reflector.invokeNoArgInstanceMember(this.target.eval(), this.fieldName, this.requireField);
/*      */     }
/*      */     
/*      */     public boolean canEmitPrimitive() {
/* 1169 */       return (this.targetClass != null) && (this.field != null) && (Util.isPrimitive(this.field.getType()));
/*      */     }
/*      */     
/*      */     public void emitUnboxed(Compiler.C context, Compiler.ObjExpr objx, GeneratorAdapter gen)
/*      */     {
/* 1174 */       if ((this.targetClass != null) && (this.field != null))
/*      */       {
/* 1176 */         this.target.emit(Compiler.C.EXPRESSION, objx, gen);
/* 1177 */         gen.visitLineNumber(this.line, gen.mark());
/* 1178 */         gen.checkCast(Compiler.getType(this.targetClass));
/* 1179 */         gen.getField(Compiler.getType(this.targetClass), this.fieldName, Type.getType(this.field.getType()));
/*      */       }
/*      */       else {
/* 1182 */         throw new UnsupportedOperationException("Unboxed emit of unknown member");
/*      */       }
/*      */     }
/*      */     
/* 1186 */     public void emit(Compiler.C context, Compiler.ObjExpr objx, GeneratorAdapter gen) { if ((this.targetClass != null) && (this.field != null))
/*      */       {
/* 1188 */         this.target.emit(Compiler.C.EXPRESSION, objx, gen);
/* 1189 */         gen.visitLineNumber(this.line, gen.mark());
/* 1190 */         gen.checkCast(Compiler.getType(this.targetClass));
/* 1191 */         gen.getField(Compiler.getType(this.targetClass), this.fieldName, Type.getType(this.field.getType()));
/*      */         
/* 1193 */         Compiler.HostExpr.emitBoxReturn(objx, gen, this.field.getType());
/* 1194 */         if (context == Compiler.C.STATEMENT)
/*      */         {
/* 1196 */           gen.pop();
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/* 1201 */         this.target.emit(Compiler.C.EXPRESSION, objx, gen);
/* 1202 */         gen.visitLineNumber(this.line, gen.mark());
/* 1203 */         gen.push(this.fieldName);
/* 1204 */         gen.push(this.requireField);
/* 1205 */         gen.invokeStatic(Compiler.REFLECTOR_TYPE, invokeNoArgInstanceMember);
/* 1206 */         if (context == Compiler.C.STATEMENT)
/* 1207 */           gen.pop();
/*      */       }
/*      */     }
/*      */     
/*      */     public boolean hasJavaClass() {
/* 1212 */       return (this.field != null) || (this.tag != null);
/*      */     }
/*      */     
/*      */     public Class getJavaClass() {
/* 1216 */       return this.tag != null ? Compiler.HostExpr.tagToClass(this.tag) : this.field.getType();
/*      */     }
/*      */     
/*      */     public Object evalAssign(Compiler.Expr val) {
/* 1220 */       return Reflector.setInstanceField(this.target.eval(), this.fieldName, val.eval());
/*      */     }
/*      */     
/*      */     public void emitAssign(Compiler.C context, Compiler.ObjExpr objx, GeneratorAdapter gen, Compiler.Expr val)
/*      */     {
/* 1225 */       if ((this.targetClass != null) && (this.field != null))
/*      */       {
/* 1227 */         this.target.emit(Compiler.C.EXPRESSION, objx, gen);
/* 1228 */         gen.checkCast(Compiler.getType(this.targetClass));
/* 1229 */         val.emit(Compiler.C.EXPRESSION, objx, gen);
/* 1230 */         gen.visitLineNumber(this.line, gen.mark());
/* 1231 */         gen.dupX1();
/* 1232 */         Compiler.HostExpr.emitUnboxArg(objx, gen, this.field.getType());
/* 1233 */         gen.putField(Compiler.getType(this.targetClass), this.fieldName, Type.getType(this.field.getType()));
/*      */       }
/*      */       else
/*      */       {
/* 1237 */         this.target.emit(Compiler.C.EXPRESSION, objx, gen);
/* 1238 */         gen.push(this.fieldName);
/* 1239 */         val.emit(Compiler.C.EXPRESSION, objx, gen);
/* 1240 */         gen.visitLineNumber(this.line, gen.mark());
/* 1241 */         gen.invokeStatic(Compiler.REFLECTOR_TYPE, setInstanceFieldMethod);
/*      */       }
/* 1243 */       if (context == Compiler.C.STATEMENT) {
/* 1244 */         gen.pop();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   static class StaticFieldExpr
/*      */     extends Compiler.FieldExpr implements Compiler.AssignableExpr
/*      */   {
/*      */     public final String fieldName;
/*      */     public final Class c;
/*      */     public final Field field;
/*      */     public final Symbol tag;
/*      */     final int line;
/*      */     final int column;
/*      */     
/*      */     public StaticFieldExpr(int line, int column, Class c, String fieldName, Symbol tag)
/*      */     {
/* 1261 */       this.fieldName = fieldName;
/* 1262 */       this.line = line;
/* 1263 */       this.column = column;
/*      */       
/* 1265 */       this.c = c;
/*      */       try
/*      */       {
/* 1268 */         this.field = c.getField(fieldName);
/*      */       }
/*      */       catch (NoSuchFieldException e)
/*      */       {
/* 1272 */         throw Util.sneakyThrow(e);
/*      */       }
/* 1274 */       this.tag = tag;
/*      */     }
/*      */     
/*      */     public Object eval() {
/* 1278 */       return Reflector.getStaticField(this.c, this.fieldName);
/*      */     }
/*      */     
/*      */     public boolean canEmitPrimitive() {
/* 1282 */       return Util.isPrimitive(this.field.getType());
/*      */     }
/*      */     
/*      */     public void emitUnboxed(Compiler.C context, Compiler.ObjExpr objx, GeneratorAdapter gen) {
/* 1286 */       gen.visitLineNumber(this.line, gen.mark());
/* 1287 */       gen.getStatic(Type.getType(this.c), this.fieldName, Type.getType(this.field.getType()));
/*      */     }
/*      */     
/*      */     public void emit(Compiler.C context, Compiler.ObjExpr objx, GeneratorAdapter gen) {
/* 1291 */       gen.visitLineNumber(this.line, gen.mark());
/*      */       
/* 1293 */       gen.getStatic(Type.getType(this.c), this.fieldName, Type.getType(this.field.getType()));
/*      */       
/* 1295 */       Compiler.HostExpr.emitBoxReturn(objx, gen, this.field.getType());
/* 1296 */       if (context == Compiler.C.STATEMENT)
/*      */       {
/* 1298 */         gen.pop();
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public boolean hasJavaClass()
/*      */     {
/* 1306 */       return true;
/*      */     }
/*      */     
/*      */ 
/*      */     public Class getJavaClass()
/*      */     {
/* 1312 */       return this.tag != null ? Compiler.HostExpr.tagToClass(this.tag) : this.field.getType();
/*      */     }
/*      */     
/*      */     public Object evalAssign(Compiler.Expr val) {
/* 1316 */       return Reflector.setStaticField(this.c, this.fieldName, val.eval());
/*      */     }
/*      */     
/*      */     public void emitAssign(Compiler.C context, Compiler.ObjExpr objx, GeneratorAdapter gen, Compiler.Expr val)
/*      */     {
/* 1321 */       val.emit(Compiler.C.EXPRESSION, objx, gen);
/* 1322 */       gen.visitLineNumber(this.line, gen.mark());
/* 1323 */       gen.dup();
/* 1324 */       Compiler.HostExpr.emitUnboxArg(objx, gen, this.field.getType());
/* 1325 */       gen.putStatic(Type.getType(this.c), this.fieldName, Type.getType(this.field.getType()));
/* 1326 */       if (context == Compiler.C.STATEMENT) {
/* 1327 */         gen.pop();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   static Class maybePrimitiveType(Expr e)
/*      */   {
/* 1334 */     if (((e instanceof MaybePrimitiveExpr)) && (e.hasJavaClass()) && (((MaybePrimitiveExpr)e).canEmitPrimitive()))
/*      */     {
/* 1336 */       Class c = e.getJavaClass();
/* 1337 */       if (Util.isPrimitive(c))
/* 1338 */         return c;
/*      */     }
/* 1340 */     return null;
/*      */   }
/*      */   
/*      */   static Class maybeJavaClass(Collection<Expr> exprs) {
/* 1344 */     Class match = null;
/*      */     try
/*      */     {
/* 1347 */       for (Expr e : exprs)
/*      */       {
/* 1349 */         if (!(e instanceof ThrowExpr))
/*      */         {
/* 1351 */           if (!e.hasJavaClass())
/* 1352 */             return null;
/* 1353 */           Class c = e.getJavaClass();
/* 1354 */           if (match == null) {
/* 1355 */             match = c;
/* 1356 */           } else if (match != c) {
/* 1357 */             return null;
/*      */           }
/*      */         }
/*      */       }
/*      */     } catch (Exception e) {
/* 1362 */       return null;
/*      */     }
/* 1364 */     return match;
/*      */   }
/*      */   
/*      */   static abstract class MethodExpr extends Compiler.HostExpr
/*      */   {
/*      */     static void emitArgsAsArray(IPersistentVector args, Compiler.ObjExpr objx, GeneratorAdapter gen) {
/* 1370 */       gen.push(args.count());
/* 1371 */       gen.newArray(Compiler.OBJECT_TYPE);
/* 1372 */       for (int i = 0; i < args.count(); i++)
/*      */       {
/* 1374 */         gen.dup();
/* 1375 */         gen.push(i);
/* 1376 */         ((Compiler.Expr)args.nth(i)).emit(Compiler.C.EXPRESSION, objx, gen);
/* 1377 */         gen.arrayStore(Compiler.OBJECT_TYPE);
/*      */       }
/*      */     }
/*      */     
/*      */     public static void emitTypedArgs(Compiler.ObjExpr objx, GeneratorAdapter gen, Class[] parameterTypes, IPersistentVector args) {
/* 1382 */       for (int i = 0; i < parameterTypes.length; i++)
/*      */       {
/* 1384 */         Compiler.Expr e = (Compiler.Expr)args.nth(i);
/*      */         try
/*      */         {
/* 1387 */           Class primc = Compiler.maybePrimitiveType(e);
/* 1388 */           if (primc == parameterTypes[i])
/*      */           {
/* 1390 */             Compiler.MaybePrimitiveExpr pe = (Compiler.MaybePrimitiveExpr)e;
/* 1391 */             pe.emitUnboxed(Compiler.C.EXPRESSION, objx, gen);
/*      */           }
/* 1393 */           else if ((primc == Integer.TYPE) && (parameterTypes[i] == Long.TYPE))
/*      */           {
/* 1395 */             Compiler.MaybePrimitiveExpr pe = (Compiler.MaybePrimitiveExpr)e;
/* 1396 */             pe.emitUnboxed(Compiler.C.EXPRESSION, objx, gen);
/* 1397 */             gen.visitInsn(133);
/*      */           }
/* 1399 */           else if ((primc == Long.TYPE) && (parameterTypes[i] == Integer.TYPE))
/*      */           {
/* 1401 */             Compiler.MaybePrimitiveExpr pe = (Compiler.MaybePrimitiveExpr)e;
/* 1402 */             pe.emitUnboxed(Compiler.C.EXPRESSION, objx, gen);
/* 1403 */             if (RT.booleanCast(RT.UNCHECKED_MATH.deref())) {
/* 1404 */               gen.invokeStatic(Compiler.RT_TYPE, clojure.asm.commons.Method.getMethod("int uncheckedIntCast(long)"));
/*      */             } else {
/* 1406 */               gen.invokeStatic(Compiler.RT_TYPE, clojure.asm.commons.Method.getMethod("int intCast(long)"));
/*      */             }
/* 1408 */           } else if ((primc == Float.TYPE) && (parameterTypes[i] == Double.TYPE))
/*      */           {
/* 1410 */             Compiler.MaybePrimitiveExpr pe = (Compiler.MaybePrimitiveExpr)e;
/* 1411 */             pe.emitUnboxed(Compiler.C.EXPRESSION, objx, gen);
/* 1412 */             gen.visitInsn(141);
/*      */           }
/* 1414 */           else if ((primc == Double.TYPE) && (parameterTypes[i] == Float.TYPE))
/*      */           {
/* 1416 */             Compiler.MaybePrimitiveExpr pe = (Compiler.MaybePrimitiveExpr)e;
/* 1417 */             pe.emitUnboxed(Compiler.C.EXPRESSION, objx, gen);
/* 1418 */             gen.visitInsn(144);
/*      */           }
/*      */           else
/*      */           {
/* 1422 */             e.emit(Compiler.C.EXPRESSION, objx, gen);
/* 1423 */             Compiler.HostExpr.emitUnboxArg(objx, gen, parameterTypes[i]);
/*      */           }
/*      */         }
/*      */         catch (Exception e1)
/*      */         {
/* 1428 */           throw Util.sneakyThrow(e1);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   static class InstanceMethodExpr
/*      */     extends Compiler.MethodExpr
/*      */   {
/*      */     public final Compiler.Expr target;
/*      */     public final String methodName;
/*      */     public final IPersistentVector args;
/*      */     public final String source;
/*      */     public final int line;
/*      */     public final int column;
/*      */     public final Symbol tag;
/*      */     public final java.lang.reflect.Method method;
/* 1445 */     static final clojure.asm.commons.Method invokeInstanceMethodMethod = clojure.asm.commons.Method.getMethod("Object invokeInstanceMethod(Object,String,Object[])");
/*      */     
/*      */ 
/*      */ 
/*      */     public InstanceMethodExpr(String source, int line, int column, Symbol tag, Compiler.Expr target, String methodName, IPersistentVector args)
/*      */     {
/* 1451 */       this.source = source;
/* 1452 */       this.line = line;
/* 1453 */       this.column = column;
/* 1454 */       this.args = args;
/* 1455 */       this.methodName = methodName;
/* 1456 */       this.target = target;
/* 1457 */       this.tag = tag;
/* 1458 */       if ((target.hasJavaClass()) && (target.getJavaClass() != null))
/*      */       {
/* 1460 */         List methods = Reflector.getMethods(target.getJavaClass(), args.count(), methodName, false);
/* 1461 */         if (methods.isEmpty())
/*      */         {
/* 1463 */           this.method = null;
/* 1464 */           if (RT.booleanCast(RT.WARN_ON_REFLECTION.deref()))
/*      */           {
/* 1466 */             RT.errPrintWriter().format("Reflection warning, %s:%d:%d - call to method %s on %s can't be resolved (no such method).\n", new Object[] { Compiler.SOURCE_PATH.deref(), Integer.valueOf(line), Integer.valueOf(column), methodName, target.getJavaClass().getName() });
/*      */           }
/*      */           
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/* 1473 */           int methodidx = 0;
/* 1474 */           if (methods.size() > 1)
/*      */           {
/* 1476 */             ArrayList<Class[]> params = new ArrayList();
/* 1477 */             ArrayList<Class> rets = new ArrayList();
/* 1478 */             for (int i = 0; i < methods.size(); i++)
/*      */             {
/* 1480 */               java.lang.reflect.Method m = (java.lang.reflect.Method)methods.get(i);
/* 1481 */               params.add(m.getParameterTypes());
/* 1482 */               rets.add(m.getReturnType());
/*      */             }
/* 1484 */             methodidx = Compiler.getMatchingParams(methodName, params, args, rets);
/*      */           }
/* 1486 */           java.lang.reflect.Method m = (java.lang.reflect.Method)(methodidx >= 0 ? methods.get(methodidx) : null);
/*      */           
/* 1488 */           if ((m != null) && (!Modifier.isPublic(m.getDeclaringClass().getModifiers())))
/*      */           {
/*      */ 
/* 1491 */             m = Reflector.getAsMethodOfPublicBase(m.getDeclaringClass(), m);
/*      */           }
/* 1493 */           this.method = m;
/* 1494 */           if ((this.method == null) && (RT.booleanCast(RT.WARN_ON_REFLECTION.deref())))
/*      */           {
/* 1496 */             RT.errPrintWriter().format("Reflection warning, %s:%d:%d - call to method %s on %s can't be resolved (argument types: %s).\n", new Object[] { Compiler.SOURCE_PATH.deref(), Integer.valueOf(line), Integer.valueOf(column), methodName, target.getJavaClass().getName(), Compiler.getTypeStringForArgs(args) });
/*      */           }
/*      */           
/*      */         }
/*      */         
/*      */       }
/*      */       else
/*      */       {
/* 1504 */         this.method = null;
/* 1505 */         if (RT.booleanCast(RT.WARN_ON_REFLECTION.deref()))
/*      */         {
/* 1507 */           RT.errPrintWriter().format("Reflection warning, %s:%d:%d - call to method %s can't be resolved (target class is unknown).\n", new Object[] { Compiler.SOURCE_PATH.deref(), Integer.valueOf(line), Integer.valueOf(column), methodName });
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */     public Object eval()
/*      */     {
/*      */       try
/*      */       {
/* 1517 */         Object targetval = this.target.eval();
/* 1518 */         Object[] argvals = new Object[this.args.count()];
/* 1519 */         for (int i = 0; i < this.args.count(); i++)
/* 1520 */           argvals[i] = ((Compiler.Expr)this.args.nth(i)).eval();
/* 1521 */         if (this.method != null)
/*      */         {
/* 1523 */           LinkedList ms = new LinkedList();
/* 1524 */           ms.add(this.method);
/* 1525 */           return Reflector.invokeMatchingMethod(this.methodName, ms, targetval, argvals);
/*      */         }
/* 1527 */         return Reflector.invokeInstanceMethod(targetval, this.methodName, argvals);
/*      */       }
/*      */       catch (Throwable e)
/*      */       {
/* 1531 */         if (!(e instanceof Compiler.CompilerException)) {
/* 1532 */           throw new Compiler.CompilerException(this.source, this.line, this.column, e);
/*      */         }
/* 1534 */         throw ((Compiler.CompilerException)e);
/*      */       }
/*      */     }
/*      */     
/*      */     public boolean canEmitPrimitive() {
/* 1539 */       return (this.method != null) && (Util.isPrimitive(this.method.getReturnType()));
/*      */     }
/*      */     
/*      */     public void emitUnboxed(Compiler.C context, Compiler.ObjExpr objx, GeneratorAdapter gen) {
/* 1543 */       if (this.method != null)
/*      */       {
/* 1545 */         Type type = Type.getType(this.method.getDeclaringClass());
/* 1546 */         this.target.emit(Compiler.C.EXPRESSION, objx, gen);
/*      */         
/* 1548 */         gen.checkCast(type);
/* 1549 */         Compiler.MethodExpr.emitTypedArgs(objx, gen, this.method.getParameterTypes(), this.args);
/* 1550 */         gen.visitLineNumber(this.line, gen.mark());
/* 1551 */         if (context == Compiler.C.RETURN)
/*      */         {
/* 1553 */           Compiler.ObjMethod method = (Compiler.ObjMethod)Compiler.METHOD.deref();
/* 1554 */           method.emitClearLocals(gen);
/*      */         }
/* 1556 */         clojure.asm.commons.Method m = new clojure.asm.commons.Method(this.methodName, Type.getReturnType(this.method), Type.getArgumentTypes(this.method));
/* 1557 */         if (this.method.getDeclaringClass().isInterface()) {
/* 1558 */           gen.invokeInterface(type, m);
/*      */         } else {
/* 1560 */           gen.invokeVirtual(type, m);
/*      */         }
/*      */       } else {
/* 1563 */         throw new UnsupportedOperationException("Unboxed emit of unknown member");
/*      */       }
/*      */     }
/*      */     
/* 1567 */     public void emit(Compiler.C context, Compiler.ObjExpr objx, GeneratorAdapter gen) { if (this.method != null)
/*      */       {
/* 1569 */         Type type = Type.getType(this.method.getDeclaringClass());
/* 1570 */         this.target.emit(Compiler.C.EXPRESSION, objx, gen);
/*      */         
/* 1572 */         gen.checkCast(type);
/* 1573 */         Compiler.MethodExpr.emitTypedArgs(objx, gen, this.method.getParameterTypes(), this.args);
/* 1574 */         gen.visitLineNumber(this.line, gen.mark());
/* 1575 */         if (context == Compiler.C.RETURN)
/*      */         {
/* 1577 */           Compiler.ObjMethod method = (Compiler.ObjMethod)Compiler.METHOD.deref();
/* 1578 */           method.emitClearLocals(gen);
/*      */         }
/* 1580 */         clojure.asm.commons.Method m = new clojure.asm.commons.Method(this.methodName, Type.getReturnType(this.method), Type.getArgumentTypes(this.method));
/* 1581 */         if (this.method.getDeclaringClass().isInterface()) {
/* 1582 */           gen.invokeInterface(type, m);
/*      */         } else {
/* 1584 */           gen.invokeVirtual(type, m);
/*      */         }
/* 1586 */         Compiler.HostExpr.emitBoxReturn(objx, gen, this.method.getReturnType());
/*      */       }
/*      */       else
/*      */       {
/* 1590 */         this.target.emit(Compiler.C.EXPRESSION, objx, gen);
/* 1591 */         gen.push(this.methodName);
/* 1592 */         emitArgsAsArray(this.args, objx, gen);
/* 1593 */         gen.visitLineNumber(this.line, gen.mark());
/* 1594 */         if (context == Compiler.C.RETURN)
/*      */         {
/* 1596 */           Compiler.ObjMethod method = (Compiler.ObjMethod)Compiler.METHOD.deref();
/* 1597 */           method.emitClearLocals(gen);
/*      */         }
/* 1599 */         gen.invokeStatic(Compiler.REFLECTOR_TYPE, invokeInstanceMethodMethod);
/*      */       }
/* 1601 */       if (context == Compiler.C.STATEMENT)
/* 1602 */         gen.pop();
/*      */     }
/*      */     
/*      */     public boolean hasJavaClass() {
/* 1606 */       return (this.method != null) || (this.tag != null);
/*      */     }
/*      */     
/*      */     public Class getJavaClass() {
/* 1610 */       return Compiler.retType(this.tag != null ? Compiler.HostExpr.tagToClass(this.tag) : null, this.method != null ? this.method.getReturnType() : null);
/*      */     }
/*      */   }
/*      */   
/*      */   static class StaticMethodExpr
/*      */     extends Compiler.MethodExpr
/*      */   {
/*      */     public final Class c;
/*      */     public final String methodName;
/*      */     public final IPersistentVector args;
/*      */     public final String source;
/*      */     public final int line;
/*      */     public final int column;
/*      */     public final java.lang.reflect.Method method;
/*      */     public final Symbol tag;
/* 1625 */     static final clojure.asm.commons.Method forNameMethod = clojure.asm.commons.Method.getMethod("Class classForName(String)");
/* 1626 */     static final clojure.asm.commons.Method invokeStaticMethodMethod = clojure.asm.commons.Method.getMethod("Object invokeStaticMethod(Class,String,Object[])");
/*      */     
/* 1628 */     static final Keyword warnOnBoxedKeyword = Keyword.intern("warn-on-boxed");
/*      */     
/*      */     public StaticMethodExpr(String source, int line, int column, Symbol tag, Class c, String methodName, IPersistentVector args)
/*      */     {
/* 1632 */       this.c = c;
/* 1633 */       this.methodName = methodName;
/* 1634 */       this.args = args;
/* 1635 */       this.source = source;
/* 1636 */       this.line = line;
/* 1637 */       this.column = column;
/* 1638 */       this.tag = tag;
/*      */       
/* 1640 */       List methods = Reflector.getMethods(c, args.count(), methodName, true);
/* 1641 */       if (methods.isEmpty()) {
/* 1642 */         throw new IllegalArgumentException("No matching method: " + methodName);
/*      */       }
/* 1644 */       int methodidx = 0;
/* 1645 */       if (methods.size() > 1)
/*      */       {
/* 1647 */         ArrayList<Class[]> params = new ArrayList();
/* 1648 */         ArrayList<Class> rets = new ArrayList();
/* 1649 */         for (int i = 0; i < methods.size(); i++)
/*      */         {
/* 1651 */           java.lang.reflect.Method m = (java.lang.reflect.Method)methods.get(i);
/* 1652 */           params.add(m.getParameterTypes());
/* 1653 */           rets.add(m.getReturnType());
/*      */         }
/* 1655 */         methodidx = Compiler.getMatchingParams(methodName, params, args, rets);
/*      */       }
/* 1657 */       this.method = ((java.lang.reflect.Method)(methodidx >= 0 ? methods.get(methodidx) : null));
/* 1658 */       if ((this.method == null) && (RT.booleanCast(RT.WARN_ON_REFLECTION.deref())))
/*      */       {
/* 1660 */         RT.errPrintWriter().format("Reflection warning, %s:%d:%d - call to static method %s on %s can't be resolved (argument types: %s).\n", new Object[] { Compiler.SOURCE_PATH.deref(), Integer.valueOf(line), Integer.valueOf(column), methodName, c.getName(), Compiler.getTypeStringForArgs(args) });
/*      */       }
/*      */       
/*      */ 
/* 1664 */       if ((this.method != null) && (warnOnBoxedKeyword.equals(RT.UNCHECKED_MATH.deref())) && (isBoxedMath(this.method)))
/*      */       {
/* 1666 */         RT.errPrintWriter().format("Boxed math warning, %s:%d:%d - call: %s.\n", new Object[] { Compiler.SOURCE_PATH.deref(), Integer.valueOf(line), Integer.valueOf(column), this.method.toString() });
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */     public static boolean isBoxedMath(java.lang.reflect.Method m)
/*      */     {
/* 1673 */       Class c = m.getDeclaringClass();
/* 1674 */       if (c.equals(Numbers.class))
/*      */       {
/* 1676 */         WarnBoxedMath boxedMath = (WarnBoxedMath)m.getAnnotation(WarnBoxedMath.class);
/* 1677 */         if (boxedMath != null) {
/* 1678 */           return boxedMath.value();
/*      */         }
/* 1680 */         Class[] argTypes = m.getParameterTypes();
/* 1681 */         for (Class argType : argTypes)
/* 1682 */           if ((argType.equals(Object.class)) || (argType.equals(Number.class)))
/* 1683 */             return true;
/*      */       }
/* 1685 */       return false;
/*      */     }
/*      */     
/*      */     public Object eval()
/*      */     {
/*      */       try {
/* 1691 */         Object[] argvals = new Object[this.args.count()];
/* 1692 */         for (int i = 0; i < this.args.count(); i++)
/* 1693 */           argvals[i] = ((Compiler.Expr)this.args.nth(i)).eval();
/* 1694 */         if (this.method != null)
/*      */         {
/* 1696 */           LinkedList ms = new LinkedList();
/* 1697 */           ms.add(this.method);
/* 1698 */           return Reflector.invokeMatchingMethod(this.methodName, ms, null, argvals);
/*      */         }
/* 1700 */         return Reflector.invokeStaticMethod(this.c, this.methodName, argvals);
/*      */       }
/*      */       catch (Throwable e)
/*      */       {
/* 1704 */         if (!(e instanceof Compiler.CompilerException)) {
/* 1705 */           throw new Compiler.CompilerException(this.source, this.line, this.column, e);
/*      */         }
/* 1707 */         throw ((Compiler.CompilerException)e);
/*      */       }
/*      */     }
/*      */     
/*      */     public boolean canEmitPrimitive() {
/* 1712 */       return (this.method != null) && (Util.isPrimitive(this.method.getReturnType()));
/*      */     }
/*      */     
/*      */     public boolean canEmitIntrinsicPredicate() {
/* 1716 */       return (this.method != null) && (RT.get(Intrinsics.preds, this.method.toString()) != null);
/*      */     }
/*      */     
/*      */     public void emitIntrinsicPredicate(Compiler.C context, Compiler.ObjExpr objx, GeneratorAdapter gen, Label falseLabel) {
/* 1720 */       gen.visitLineNumber(this.line, gen.mark());
/* 1721 */       if (this.method != null)
/*      */       {
/* 1723 */         Compiler.MethodExpr.emitTypedArgs(objx, gen, this.method.getParameterTypes(), this.args);
/* 1724 */         if (context == Compiler.C.RETURN)
/*      */         {
/* 1726 */           Compiler.ObjMethod method = (Compiler.ObjMethod)Compiler.METHOD.deref();
/* 1727 */           method.emitClearLocals(gen);
/*      */         }
/* 1729 */         Object[] predOps = (Object[])RT.get(Intrinsics.preds, this.method.toString());
/* 1730 */         for (int i = 0; i < predOps.length - 1; i++)
/* 1731 */           gen.visitInsn(((Integer)predOps[i]).intValue());
/* 1732 */         gen.visitJumpInsn(((Integer)predOps[(predOps.length - 1)]).intValue(), falseLabel);
/*      */       }
/*      */       else {
/* 1735 */         throw new UnsupportedOperationException("Unboxed emit of unknown member");
/*      */       }
/*      */     }
/*      */     
/* 1739 */     public void emitUnboxed(Compiler.C context, Compiler.ObjExpr objx, GeneratorAdapter gen) { if (this.method != null)
/*      */       {
/* 1741 */         Compiler.MethodExpr.emitTypedArgs(objx, gen, this.method.getParameterTypes(), this.args);
/* 1742 */         gen.visitLineNumber(this.line, gen.mark());
/*      */         
/* 1744 */         if (context == Compiler.C.RETURN)
/*      */         {
/* 1746 */           Compiler.ObjMethod method = (Compiler.ObjMethod)Compiler.METHOD.deref();
/* 1747 */           method.emitClearLocals(gen);
/*      */         }
/* 1749 */         Object ops = RT.get(Intrinsics.ops, this.method.toString());
/* 1750 */         if (ops != null)
/*      */         {
/* 1752 */           if ((ops instanceof Object[]))
/*      */           {
/* 1754 */             for (Object op : (Object[])ops) {
/* 1755 */               gen.visitInsn(((Integer)op).intValue());
/*      */             }
/*      */           } else {
/* 1758 */             gen.visitInsn(((Integer)ops).intValue());
/*      */           }
/*      */         }
/*      */         else {
/* 1762 */           Type type = Type.getType(this.c);
/* 1763 */           clojure.asm.commons.Method m = new clojure.asm.commons.Method(this.methodName, Type.getReturnType(this.method), Type.getArgumentTypes(this.method));
/* 1764 */           gen.invokeStatic(type, m);
/*      */         }
/*      */       }
/*      */       else {
/* 1768 */         throw new UnsupportedOperationException("Unboxed emit of unknown member");
/*      */       }
/*      */     }
/*      */     
/* 1772 */     public void emit(Compiler.C context, Compiler.ObjExpr objx, GeneratorAdapter gen) { if (this.method != null)
/*      */       {
/* 1774 */         Compiler.MethodExpr.emitTypedArgs(objx, gen, this.method.getParameterTypes(), this.args);
/* 1775 */         gen.visitLineNumber(this.line, gen.mark());
/*      */         
/* 1777 */         if (context == Compiler.C.RETURN)
/*      */         {
/* 1779 */           Compiler.ObjMethod method = (Compiler.ObjMethod)Compiler.METHOD.deref();
/* 1780 */           method.emitClearLocals(gen);
/*      */         }
/* 1782 */         Type type = Type.getType(this.c);
/* 1783 */         clojure.asm.commons.Method m = new clojure.asm.commons.Method(this.methodName, Type.getReturnType(this.method), Type.getArgumentTypes(this.method));
/* 1784 */         gen.invokeStatic(type, m);
/*      */         
/* 1786 */         Class retClass = this.method.getReturnType();
/* 1787 */         if (context == Compiler.C.STATEMENT)
/*      */         {
/* 1789 */           if ((retClass == Long.TYPE) || (retClass == Double.TYPE)) {
/* 1790 */             gen.pop2();
/* 1791 */           } else if (retClass != Void.TYPE) {
/* 1792 */             gen.pop();
/*      */           }
/*      */         }
/*      */         else {
/* 1796 */           Compiler.HostExpr.emitBoxReturn(objx, gen, this.method.getReturnType());
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/* 1801 */         gen.visitLineNumber(this.line, gen.mark());
/* 1802 */         gen.push(this.c.getName());
/* 1803 */         gen.invokeStatic(Compiler.RT_TYPE, forNameMethod);
/* 1804 */         gen.push(this.methodName);
/* 1805 */         emitArgsAsArray(this.args, objx, gen);
/* 1806 */         gen.visitLineNumber(this.line, gen.mark());
/* 1807 */         if (context == Compiler.C.RETURN)
/*      */         {
/* 1809 */           Compiler.ObjMethod method = (Compiler.ObjMethod)Compiler.METHOD.deref();
/* 1810 */           method.emitClearLocals(gen);
/*      */         }
/* 1812 */         gen.invokeStatic(Compiler.REFLECTOR_TYPE, invokeStaticMethodMethod);
/* 1813 */         if (context == Compiler.C.STATEMENT)
/* 1814 */           gen.pop();
/*      */       }
/*      */     }
/*      */     
/*      */     public boolean hasJavaClass() {
/* 1819 */       return (this.method != null) || (this.tag != null);
/*      */     }
/*      */     
/*      */     public Class getJavaClass() {
/* 1823 */       return Compiler.retType(this.tag != null ? Compiler.HostExpr.tagToClass(this.tag) : null, this.method != null ? this.method.getReturnType() : null);
/*      */     }
/*      */   }
/*      */   
/*      */   static class UnresolvedVarExpr implements Compiler.Expr {
/*      */     public final Symbol symbol;
/*      */     
/*      */     public UnresolvedVarExpr(Symbol symbol) {
/* 1831 */       this.symbol = symbol;
/*      */     }
/*      */     
/*      */     public boolean hasJavaClass() {
/* 1835 */       return false;
/*      */     }
/*      */     
/*      */     public Class getJavaClass() {
/* 1839 */       throw new IllegalArgumentException("UnresolvedVarExpr has no Java class");
/*      */     }
/*      */     
/*      */ 
/*      */     public void emit(Compiler.C context, Compiler.ObjExpr objx, GeneratorAdapter gen) {}
/*      */     
/*      */     public Object eval()
/*      */     {
/* 1847 */       throw new IllegalArgumentException("UnresolvedVarExpr cannot be evalled");
/*      */     }
/*      */   }
/*      */   
/*      */   static class NumberExpr extends Compiler.LiteralExpr implements Compiler.MaybePrimitiveExpr
/*      */   {
/*      */     final Number n;
/*      */     public final int id;
/*      */     
/*      */     public NumberExpr(Number n) {
/* 1857 */       this.n = n;
/* 1858 */       this.id = Compiler.registerConstant(n);
/*      */     }
/*      */     
/*      */     Object val() {
/* 1862 */       return this.n;
/*      */     }
/*      */     
/*      */     public void emit(Compiler.C context, Compiler.ObjExpr objx, GeneratorAdapter gen) {
/* 1866 */       if (context != Compiler.C.STATEMENT)
/*      */       {
/* 1868 */         objx.emitConstant(gen, this.id);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */     public boolean hasJavaClass()
/*      */     {
/* 1875 */       return true;
/*      */     }
/*      */     
/*      */     public Class getJavaClass() {
/* 1879 */       if ((this.n instanceof Integer))
/* 1880 */         return Long.TYPE;
/* 1881 */       if ((this.n instanceof Double))
/* 1882 */         return Double.TYPE;
/* 1883 */       if ((this.n instanceof Long)) {
/* 1884 */         return Long.TYPE;
/*      */       }
/* 1886 */       throw new IllegalStateException("Unsupported Number type: " + this.n.getClass().getName());
/*      */     }
/*      */     
/*      */     public boolean canEmitPrimitive() {
/* 1890 */       return true;
/*      */     }
/*      */     
/*      */     public void emitUnboxed(Compiler.C context, Compiler.ObjExpr objx, GeneratorAdapter gen) {
/* 1894 */       if ((this.n instanceof Integer)) {
/* 1895 */         gen.push(this.n.longValue());
/* 1896 */       } else if ((this.n instanceof Double)) {
/* 1897 */         gen.push(this.n.doubleValue());
/* 1898 */       } else if ((this.n instanceof Long))
/* 1899 */         gen.push(this.n.longValue());
/*      */     }
/*      */     
/*      */     public static Compiler.Expr parse(Number form) {
/* 1903 */       if (((form instanceof Integer)) || ((form instanceof Double)) || ((form instanceof Long)))
/*      */       {
/*      */ 
/* 1906 */         return new NumberExpr(form);
/*      */       }
/* 1908 */       return new Compiler.ConstantExpr(form);
/*      */     }
/*      */   }
/*      */   
/*      */   static class ConstantExpr extends Compiler.LiteralExpr
/*      */   {
/*      */     public final Object v;
/*      */     public final int id;
/*      */     
/*      */     public ConstantExpr(Object v)
/*      */     {
/* 1919 */       this.v = v;
/* 1920 */       this.id = Compiler.registerConstant(v);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     Object val()
/*      */     {
/* 1927 */       return this.v;
/*      */     }
/*      */     
/*      */     public void emit(Compiler.C context, Compiler.ObjExpr objx, GeneratorAdapter gen) {
/* 1931 */       objx.emitConstant(gen, this.id);
/*      */       
/* 1933 */       if (context == Compiler.C.STATEMENT)
/*      */       {
/* 1935 */         gen.pop();
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public boolean hasJavaClass()
/*      */     {
/* 1946 */       return Modifier.isPublic(this.v.getClass().getModifiers());
/*      */     }
/*      */     
/*      */     public Class getJavaClass()
/*      */     {
/* 1951 */       if ((this.v instanceof APersistentMap))
/* 1952 */         return APersistentMap.class;
/* 1953 */       if ((this.v instanceof APersistentSet))
/* 1954 */         return APersistentSet.class;
/* 1955 */       if ((this.v instanceof APersistentVector)) {
/* 1956 */         return APersistentVector.class;
/*      */       }
/* 1958 */       return this.v.getClass();
/*      */     }
/*      */     
/*      */     static class Parser implements Compiler.IParser
/*      */     {
/* 1963 */       static Keyword formKey = Keyword.intern("form");
/*      */       
/*      */       public Compiler.Expr parse(Compiler.C context, Object form) {
/* 1966 */         int argCount = RT.count(form) - 1;
/* 1967 */         if (argCount != 1) {
/* 1968 */           IPersistentMap exData = new PersistentArrayMap(new Object[] { formKey, form });
/* 1969 */           throw new ExceptionInfo("Wrong number of args (" + argCount + ") passed to quote", exData);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 1974 */         Object v = RT.second(form);
/*      */         
/* 1976 */         if (v == null)
/* 1977 */           return Compiler.NIL_EXPR;
/* 1978 */         if (v == Boolean.TRUE)
/* 1979 */           return Compiler.TRUE_EXPR;
/* 1980 */         if (v == Boolean.FALSE)
/* 1981 */           return Compiler.FALSE_EXPR;
/* 1982 */         if ((v instanceof Number))
/* 1983 */           return Compiler.NumberExpr.parse((Number)v);
/* 1984 */         if ((v instanceof String))
/* 1985 */           return new Compiler.StringExpr((String)v);
/* 1986 */         if (((v instanceof IPersistentCollection)) && (((IPersistentCollection)v).count() == 0)) {
/* 1987 */           return new Compiler.EmptyExpr(v);
/*      */         }
/* 1989 */         return new Compiler.ConstantExpr(v);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   static class NilExpr extends Compiler.LiteralExpr {
/*      */     Object val() {
/* 1996 */       return null;
/*      */     }
/*      */     
/*      */     public void emit(Compiler.C context, Compiler.ObjExpr objx, GeneratorAdapter gen) {
/* 2000 */       gen.visitInsn(1);
/* 2001 */       if (context == Compiler.C.STATEMENT)
/* 2002 */         gen.pop();
/*      */     }
/*      */     
/*      */     public boolean hasJavaClass() {
/* 2006 */       return true;
/*      */     }
/*      */     
/*      */     public Class getJavaClass() {
/* 2010 */       return null;
/*      */     }
/*      */   }
/*      */   
/*      */   static class BooleanExpr
/*      */     extends Compiler.LiteralExpr
/*      */   {
/*      */     public final boolean val;
/*      */     
/*      */     public BooleanExpr(boolean val)
/*      */     {
/* 2021 */       this.val = val;
/*      */     }
/*      */     
/*      */     Object val() {
/* 2025 */       return this.val ? RT.T : RT.F;
/*      */     }
/*      */     
/*      */     public void emit(Compiler.C context, Compiler.ObjExpr objx, GeneratorAdapter gen) {
/* 2029 */       if (this.val) {
/* 2030 */         gen.getStatic(Compiler.BOOLEAN_OBJECT_TYPE, "TRUE", Compiler.BOOLEAN_OBJECT_TYPE);
/*      */       } else
/* 2032 */         gen.getStatic(Compiler.BOOLEAN_OBJECT_TYPE, "FALSE", Compiler.BOOLEAN_OBJECT_TYPE);
/* 2033 */       if (context == Compiler.C.STATEMENT)
/*      */       {
/* 2035 */         gen.pop();
/*      */       }
/*      */     }
/*      */     
/*      */     public boolean hasJavaClass() {
/* 2040 */       return true;
/*      */     }
/*      */     
/*      */     public Class getJavaClass() {
/* 2044 */       return Boolean.class;
/*      */     }
/*      */   }
/*      */   
/*      */   static class StringExpr
/*      */     extends Compiler.LiteralExpr
/*      */   {
/*      */     public final String str;
/*      */     
/*      */     public StringExpr(String str)
/*      */     {
/* 2055 */       this.str = str;
/*      */     }
/*      */     
/*      */     Object val() {
/* 2059 */       return this.str;
/*      */     }
/*      */     
/*      */     public void emit(Compiler.C context, Compiler.ObjExpr objx, GeneratorAdapter gen) {
/* 2063 */       if (context != Compiler.C.STATEMENT)
/* 2064 */         gen.push(this.str);
/*      */     }
/*      */     
/*      */     public boolean hasJavaClass() {
/* 2068 */       return true;
/*      */     }
/*      */     
/*      */     public Class getJavaClass() {
/* 2072 */       return String.class;
/*      */     }
/*      */   }
/*      */   
/*      */   static class MonitorEnterExpr extends Compiler.UntypedExpr
/*      */   {
/*      */     final Compiler.Expr target;
/*      */     
/*      */     public MonitorEnterExpr(Compiler.Expr target) {
/* 2081 */       this.target = target;
/*      */     }
/*      */     
/*      */     public Object eval() {
/* 2085 */       throw new UnsupportedOperationException("Can't eval monitor-enter");
/*      */     }
/*      */     
/*      */     public void emit(Compiler.C context, Compiler.ObjExpr objx, GeneratorAdapter gen) {
/* 2089 */       this.target.emit(Compiler.C.EXPRESSION, objx, gen);
/* 2090 */       gen.monitorEnter();
/* 2091 */       Compiler.NIL_EXPR.emit(context, objx, gen);
/*      */     }
/*      */     
/*      */     static class Parser implements Compiler.IParser {
/*      */       public Compiler.Expr parse(Compiler.C context, Object form) {
/* 2096 */         return new Compiler.MonitorEnterExpr(Compiler.analyze(Compiler.C.EXPRESSION, RT.second(form)));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   static class MonitorExitExpr extends Compiler.UntypedExpr {
/*      */     final Compiler.Expr target;
/*      */     
/*      */     public MonitorExitExpr(Compiler.Expr target) {
/* 2105 */       this.target = target;
/*      */     }
/*      */     
/*      */     public Object eval() {
/* 2109 */       throw new UnsupportedOperationException("Can't eval monitor-exit");
/*      */     }
/*      */     
/*      */     public void emit(Compiler.C context, Compiler.ObjExpr objx, GeneratorAdapter gen) {
/* 2113 */       this.target.emit(Compiler.C.EXPRESSION, objx, gen);
/* 2114 */       gen.monitorExit();
/* 2115 */       Compiler.NIL_EXPR.emit(context, objx, gen);
/*      */     }
/*      */     
/*      */     static class Parser implements Compiler.IParser {
/*      */       public Compiler.Expr parse(Compiler.C context, Object form) {
/* 2120 */         return new Compiler.MonitorExitExpr(Compiler.analyze(Compiler.C.EXPRESSION, RT.second(form)));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public static class TryExpr implements Compiler.Expr
/*      */   {
/*      */     public final Compiler.Expr tryExpr;
/*      */     public final Compiler.Expr finallyExpr;
/*      */     public final PersistentVector catchExprs;
/*      */     public final int retLocal;
/*      */     public final int finallyLocal;
/*      */     
/*      */     public static class CatchClause
/*      */     {
/*      */       public final Class c;
/*      */       public final Compiler.LocalBinding lb;
/*      */       public final Compiler.Expr handler;
/*      */       Label label;
/*      */       Label endLabel;
/*      */       
/*      */       public CatchClause(Class c, Compiler.LocalBinding lb, Compiler.Expr handler)
/*      */       {
/* 2143 */         this.c = c;
/* 2144 */         this.lb = lb;
/* 2145 */         this.handler = handler;
/*      */       }
/*      */     }
/*      */     
/*      */     public TryExpr(Compiler.Expr tryExpr, PersistentVector catchExprs, Compiler.Expr finallyExpr, int retLocal, int finallyLocal) {
/* 2150 */       this.tryExpr = tryExpr;
/* 2151 */       this.catchExprs = catchExprs;
/* 2152 */       this.finallyExpr = finallyExpr;
/* 2153 */       this.retLocal = retLocal;
/* 2154 */       this.finallyLocal = finallyLocal;
/*      */     }
/*      */     
/*      */     public Object eval() {
/* 2158 */       throw new UnsupportedOperationException("Can't eval try");
/*      */     }
/*      */     
/*      */     public void emit(Compiler.C context, Compiler.ObjExpr objx, GeneratorAdapter gen) {
/* 2162 */       Label startTry = gen.newLabel();
/* 2163 */       Label endTry = gen.newLabel();
/* 2164 */       Label end = gen.newLabel();
/* 2165 */       Label ret = gen.newLabel();
/* 2166 */       Label finallyLabel = gen.newLabel();
/* 2167 */       for (int i = 0; i < this.catchExprs.count(); i++)
/*      */       {
/* 2169 */         CatchClause clause = (CatchClause)this.catchExprs.nth(i);
/* 2170 */         clause.label = gen.newLabel();
/* 2171 */         clause.endLabel = gen.newLabel();
/*      */       }
/*      */       
/* 2174 */       gen.mark(startTry);
/* 2175 */       this.tryExpr.emit(context, objx, gen);
/* 2176 */       if (context != Compiler.C.STATEMENT)
/* 2177 */         gen.visitVarInsn(Compiler.OBJECT_TYPE.getOpcode(54), this.retLocal);
/* 2178 */       gen.mark(endTry);
/* 2179 */       if (this.finallyExpr != null)
/* 2180 */         this.finallyExpr.emit(Compiler.C.STATEMENT, objx, gen);
/* 2181 */       gen.goTo(ret);
/*      */       
/* 2183 */       for (int i = 0; i < this.catchExprs.count(); i++)
/*      */       {
/* 2185 */         CatchClause clause = (CatchClause)this.catchExprs.nth(i);
/* 2186 */         gen.mark(clause.label);
/*      */         
/*      */ 
/* 2189 */         gen.visitVarInsn(Compiler.OBJECT_TYPE.getOpcode(54), clause.lb.idx);
/* 2190 */         clause.handler.emit(context, objx, gen);
/* 2191 */         if (context != Compiler.C.STATEMENT)
/* 2192 */           gen.visitVarInsn(Compiler.OBJECT_TYPE.getOpcode(54), this.retLocal);
/* 2193 */         gen.mark(clause.endLabel);
/*      */         
/* 2195 */         if (this.finallyExpr != null)
/* 2196 */           this.finallyExpr.emit(Compiler.C.STATEMENT, objx, gen);
/* 2197 */         gen.goTo(ret);
/*      */       }
/* 2199 */       if (this.finallyExpr != null)
/*      */       {
/* 2201 */         gen.mark(finallyLabel);
/*      */         
/* 2203 */         gen.visitVarInsn(Compiler.OBJECT_TYPE.getOpcode(54), this.finallyLocal);
/* 2204 */         this.finallyExpr.emit(Compiler.C.STATEMENT, objx, gen);
/* 2205 */         gen.visitVarInsn(Compiler.OBJECT_TYPE.getOpcode(21), this.finallyLocal);
/* 2206 */         gen.throwException();
/*      */       }
/* 2208 */       gen.mark(ret);
/* 2209 */       if (context != Compiler.C.STATEMENT)
/* 2210 */         gen.visitVarInsn(Compiler.OBJECT_TYPE.getOpcode(21), this.retLocal);
/* 2211 */       gen.mark(end);
/* 2212 */       for (int i = 0; i < this.catchExprs.count(); i++)
/*      */       {
/* 2214 */         CatchClause clause = (CatchClause)this.catchExprs.nth(i);
/* 2215 */         gen.visitTryCatchBlock(startTry, endTry, clause.label, clause.c.getName().replace('.', '/'));
/*      */       }
/* 2217 */       if (this.finallyExpr != null)
/*      */       {
/* 2219 */         gen.visitTryCatchBlock(startTry, endTry, finallyLabel, null);
/* 2220 */         for (int i = 0; i < this.catchExprs.count(); i++)
/*      */         {
/* 2222 */           CatchClause clause = (CatchClause)this.catchExprs.nth(i);
/* 2223 */           gen.visitTryCatchBlock(clause.label, clause.endLabel, finallyLabel, null);
/*      */         }
/*      */       }
/* 2226 */       for (int i = 0; i < this.catchExprs.count(); i++)
/*      */       {
/* 2228 */         CatchClause clause = (CatchClause)this.catchExprs.nth(i);
/* 2229 */         gen.visitLocalVariable(clause.lb.name, "Ljava/lang/Object;", null, clause.label, clause.endLabel, clause.lb.idx);
/*      */       }
/*      */     }
/*      */     
/*      */     public boolean hasJavaClass()
/*      */     {
/* 2235 */       return this.tryExpr.hasJavaClass();
/*      */     }
/*      */     
/*      */     public Class getJavaClass() {
/* 2239 */       return this.tryExpr.getJavaClass();
/*      */     }
/*      */     
/*      */     static class Parser implements Compiler.IParser
/*      */     {
/*      */       public Compiler.Expr parse(Compiler.C context, Object frm) {
/* 2245 */         ISeq form = (ISeq)frm;
/*      */         
/* 2247 */         if (context != Compiler.C.RETURN) {
/* 2248 */           return Compiler.analyze(context, RT.list(RT.list(Compiler.FNONCE, PersistentVector.EMPTY, form)));
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 2254 */         PersistentVector body = PersistentVector.EMPTY;
/* 2255 */         PersistentVector catches = PersistentVector.EMPTY;
/* 2256 */         Compiler.Expr bodyExpr = null;
/* 2257 */         Compiler.Expr finallyExpr = null;
/* 2258 */         boolean caught = false;
/*      */         
/* 2260 */         int retLocal = Compiler.access$900();
/* 2261 */         int finallyLocal = Compiler.access$900();
/* 2262 */         for (ISeq fs = form.next(); fs != null; fs = fs.next())
/*      */         {
/* 2264 */           Object f = fs.first();
/* 2265 */           Object op = (f instanceof ISeq) ? ((ISeq)f).first() : null;
/* 2266 */           if ((!Util.equals(op, Compiler.CATCH)) && (!Util.equals(op, Compiler.FINALLY)))
/*      */           {
/* 2268 */             if (caught)
/* 2269 */               throw Util.runtimeException("Only catch or finally clause can follow catch in try expression");
/* 2270 */             body = body.cons(f);
/*      */           }
/*      */           else
/*      */           {
/* 2274 */             if (bodyExpr == null)
/*      */               try {
/* 2276 */                 Var.pushThreadBindings(RT.map(new Object[] { Compiler.NO_RECUR, Boolean.valueOf(true) }));
/* 2277 */                 bodyExpr = new Compiler.BodyExpr.Parser().parse(context, RT.seq(body));
/*      */               } finally {
/* 2279 */                 Var.popThreadBindings();
/*      */               }
/* 2281 */             if (Util.equals(op, Compiler.CATCH))
/*      */             {
/* 2283 */               Class c = Compiler.HostExpr.maybeClass(RT.second(f), false);
/* 2284 */               if (c == null)
/* 2285 */                 throw new IllegalArgumentException("Unable to resolve classname: " + RT.second(f));
/* 2286 */               if (!(RT.third(f) instanceof Symbol)) {
/* 2287 */                 throw new IllegalArgumentException("Bad binding form, expected symbol, got: " + RT.third(f));
/*      */               }
/* 2289 */               Symbol sym = (Symbol)RT.third(f);
/* 2290 */               if (sym.getNamespace() != null) {
/* 2291 */                 throw Util.runtimeException("Can't bind qualified name:" + sym);
/*      */               }
/* 2293 */               IPersistentMap dynamicBindings = RT.map(new Object[] { Compiler.LOCAL_ENV, Compiler.LOCAL_ENV.deref(), Compiler.NEXT_LOCAL_NUM, Compiler.NEXT_LOCAL_NUM.deref(), Compiler.IN_CATCH_FINALLY, RT.T });
/*      */               
/*      */ 
/*      */               try
/*      */               {
/* 2298 */                 Var.pushThreadBindings(dynamicBindings);
/* 2299 */                 Compiler.LocalBinding lb = Compiler.registerLocal(sym, (Symbol)((RT.second(f) instanceof Symbol) ? RT.second(f) : null), null, false);
/*      */                 
/*      */ 
/*      */ 
/* 2303 */                 Compiler.Expr handler = new Compiler.BodyExpr.Parser().parse(Compiler.C.EXPRESSION, RT.next(RT.next(RT.next(f))));
/* 2304 */                 catches = catches.cons(new Compiler.TryExpr.CatchClause(c, lb, handler));
/*      */               }
/*      */               finally
/*      */               {
/* 2308 */                 Var.popThreadBindings();
/*      */               }
/* 2310 */               caught = true;
/*      */             }
/*      */             else
/*      */             {
/* 2314 */               if (fs.next() != null) {
/* 2315 */                 throw Util.runtimeException("finally clause must be last in try expression");
/*      */               }
/*      */               try {
/* 2318 */                 Var.pushThreadBindings(RT.map(new Object[] { Compiler.IN_CATCH_FINALLY, RT.T }));
/* 2319 */                 finallyExpr = new Compiler.BodyExpr.Parser().parse(Compiler.C.STATEMENT, RT.next(f));
/*      */               }
/*      */               finally
/*      */               {
/* 2323 */                 Var.popThreadBindings();
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/* 2328 */         if (bodyExpr == null) {
/*      */           try
/*      */           {
/* 2331 */             Var.pushThreadBindings(RT.map(new Object[] { Compiler.NO_RECUR, Boolean.valueOf(true) }));
/* 2332 */             bodyExpr = new Compiler.BodyExpr.Parser().parse(Compiler.C.EXPRESSION, RT.seq(body));
/*      */           }
/*      */           finally
/*      */           {
/* 2336 */             Var.popThreadBindings();
/*      */           }
/*      */         }
/*      */         
/* 2340 */         return new Compiler.TryExpr(bodyExpr, catches, finallyExpr, retLocal, finallyLocal);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static class ThrowExpr
/*      */     extends Compiler.UntypedExpr
/*      */   {
/*      */     public final Compiler.Expr excExpr;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public ThrowExpr(Compiler.Expr excExpr)
/*      */     {
/* 2407 */       this.excExpr = excExpr;
/*      */     }
/*      */     
/*      */     public Object eval()
/*      */     {
/* 2412 */       throw Util.runtimeException("Can't eval throw");
/*      */     }
/*      */     
/*      */     public void emit(Compiler.C context, Compiler.ObjExpr objx, GeneratorAdapter gen) {
/* 2416 */       this.excExpr.emit(Compiler.C.EXPRESSION, objx, gen);
/* 2417 */       gen.checkCast(Compiler.THROWABLE_TYPE);
/* 2418 */       gen.throwException();
/*      */     }
/*      */     
/*      */     static class Parser implements Compiler.IParser {
/*      */       public Compiler.Expr parse(Compiler.C context, Object form) {
/* 2423 */         if (context == Compiler.C.EVAL)
/* 2424 */           return Compiler.analyze(context, RT.list(RT.list(Compiler.FNONCE, PersistentVector.EMPTY, form)));
/* 2425 */         if (RT.count(form) == 1)
/* 2426 */           throw Util.runtimeException("Too few arguments to throw, throw expects a single Throwable instance");
/* 2427 */         if (RT.count(form) > 2)
/* 2428 */           throw Util.runtimeException("Too many arguments to throw, throw expects a single Throwable instance");
/* 2429 */         return new Compiler.ThrowExpr(Compiler.analyze(Compiler.C.EXPRESSION, RT.second(form)));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static boolean subsumes(Class[] c1, Class[] c2)
/*      */   {
/* 2437 */     Boolean better = Boolean.valueOf(false);
/* 2438 */     for (int i = 0; i < c1.length; i++)
/*      */     {
/* 2440 */       if (c1[i] != c2[i])
/*      */       {
/* 2442 */         if (((!c1[i].isPrimitive()) && (c2[i].isPrimitive())) || (c2[i].isAssignableFrom(c1[i])))
/*      */         {
/*      */ 
/*      */ 
/* 2446 */           better = Boolean.valueOf(true);
/*      */         } else
/* 2448 */           return false;
/*      */       }
/*      */     }
/* 2451 */     return better.booleanValue();
/*      */   }
/*      */   
/*      */   static String getTypeStringForArgs(IPersistentVector args) {
/* 2455 */     StringBuilder sb = new StringBuilder();
/* 2456 */     for (int i = 0; i < args.count(); i++)
/*      */     {
/* 2458 */       Expr arg = (Expr)args.nth(i);
/* 2459 */       if (i > 0) sb.append(", ");
/* 2460 */       sb.append((arg.hasJavaClass()) && (arg.getJavaClass() != null) ? arg.getJavaClass().getName() : "unknown");
/*      */     }
/* 2462 */     return sb.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   static int getMatchingParams(String methodName, ArrayList<Class[]> paramlists, IPersistentVector argexprs, List<Class> rets)
/*      */   {
/* 2469 */     int matchIdx = -1;
/* 2470 */     boolean tied = false;
/* 2471 */     boolean foundExact = false;
/* 2472 */     for (int i = 0; i < paramlists.size(); i++)
/*      */     {
/* 2474 */       boolean match = true;
/* 2475 */       ISeq aseq = argexprs.seq();
/* 2476 */       int exact = 0;
/* 2477 */       for (int p = 0; (match) && (p < argexprs.count()) && (aseq != null); aseq = aseq.next())
/*      */       {
/* 2479 */         Expr arg = (Expr)aseq.first();
/* 2480 */         Class aclass = arg.hasJavaClass() ? arg.getJavaClass() : Object.class;
/* 2481 */         Class pclass = ((Class[])paramlists.get(i))[p];
/* 2482 */         if ((arg.hasJavaClass()) && (aclass == pclass)) {
/* 2483 */           exact++;
/*      */         } else {
/* 2485 */           match = Reflector.paramArgTypeMatch(pclass, aclass);
/*      */         }
/* 2477 */         p++;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2487 */       if (exact == argexprs.count())
/*      */       {
/* 2489 */         if ((!foundExact) || (matchIdx == -1) || (((Class)rets.get(matchIdx)).isAssignableFrom((Class)rets.get(i))))
/* 2490 */           matchIdx = i;
/* 2491 */         tied = false;
/* 2492 */         foundExact = true;
/*      */       }
/* 2494 */       else if ((match) && (!foundExact))
/*      */       {
/* 2496 */         if (matchIdx == -1) {
/* 2497 */           matchIdx = i;
/*      */ 
/*      */         }
/* 2500 */         else if (subsumes((Class[])paramlists.get(i), (Class[])paramlists.get(matchIdx)))
/*      */         {
/* 2502 */           matchIdx = i;
/* 2503 */           tied = false;
/*      */         }
/* 2505 */         else if (Arrays.equals((Object[])paramlists.get(matchIdx), (Object[])paramlists.get(i)))
/*      */         {
/* 2507 */           if (((Class)rets.get(matchIdx)).isAssignableFrom((Class)rets.get(i))) {
/* 2508 */             matchIdx = i;
/*      */           }
/* 2510 */         } else if (!subsumes((Class[])paramlists.get(matchIdx), (Class[])paramlists.get(i))) {
/* 2511 */           tied = true;
/*      */         }
/*      */       }
/*      */     }
/* 2515 */     if (tied) {
/* 2516 */       throw new IllegalArgumentException("More than one matching method found: " + methodName);
/*      */     }
/* 2518 */     return matchIdx;
/*      */   }
/*      */   
/*      */   public static class NewExpr implements Compiler.Expr {
/*      */     public final IPersistentVector args;
/*      */     public final Constructor ctor;
/*      */     public final Class c;
/* 2525 */     static final clojure.asm.commons.Method invokeConstructorMethod = clojure.asm.commons.Method.getMethod("Object invokeConstructor(Class,Object[])");
/*      */     
/* 2527 */     static final clojure.asm.commons.Method forNameMethod = clojure.asm.commons.Method.getMethod("Class classForName(String)");
/*      */     
/*      */     public NewExpr(Class c, IPersistentVector args, int line, int column)
/*      */     {
/* 2531 */       this.args = args;
/* 2532 */       this.c = c;
/* 2533 */       Constructor[] allctors = c.getConstructors();
/* 2534 */       ArrayList ctors = new ArrayList();
/* 2535 */       ArrayList<Class[]> params = new ArrayList();
/* 2536 */       ArrayList<Class> rets = new ArrayList();
/* 2537 */       for (int i = 0; i < allctors.length; i++)
/*      */       {
/* 2539 */         Constructor ctor = allctors[i];
/* 2540 */         if (ctor.getParameterTypes().length == args.count())
/*      */         {
/* 2542 */           ctors.add(ctor);
/* 2543 */           params.add(ctor.getParameterTypes());
/* 2544 */           rets.add(c);
/*      */         }
/*      */       }
/* 2547 */       if (ctors.isEmpty()) {
/* 2548 */         throw new IllegalArgumentException("No matching ctor found for " + c);
/*      */       }
/* 2550 */       int ctoridx = 0;
/* 2551 */       if (ctors.size() > 1)
/*      */       {
/* 2553 */         ctoridx = Compiler.getMatchingParams(c.getName(), params, args, rets);
/*      */       }
/*      */       
/* 2556 */       this.ctor = (ctoridx >= 0 ? (Constructor)ctors.get(ctoridx) : null);
/* 2557 */       if ((this.ctor == null) && (RT.booleanCast(RT.WARN_ON_REFLECTION.deref())))
/*      */       {
/* 2559 */         RT.errPrintWriter().format("Reflection warning, %s:%d:%d - call to %s ctor can't be resolved.\n", new Object[] { Compiler.SOURCE_PATH.deref(), Integer.valueOf(line), Integer.valueOf(column), c.getName() });
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */     public Object eval()
/*      */     {
/* 2566 */       Object[] argvals = new Object[this.args.count()];
/* 2567 */       for (int i = 0; i < this.args.count(); i++)
/* 2568 */         argvals[i] = ((Compiler.Expr)this.args.nth(i)).eval();
/* 2569 */       if (this.ctor != null)
/*      */       {
/*      */         try
/*      */         {
/* 2573 */           return this.ctor.newInstance(Reflector.boxArgs(this.ctor.getParameterTypes(), argvals));
/*      */         }
/*      */         catch (Exception e)
/*      */         {
/* 2577 */           throw Util.sneakyThrow(e);
/*      */         }
/*      */       }
/* 2580 */       return Reflector.invokeConstructor(this.c, argvals);
/*      */     }
/*      */     
/*      */     public void emit(Compiler.C context, Compiler.ObjExpr objx, GeneratorAdapter gen) {
/* 2584 */       if (this.ctor != null)
/*      */       {
/* 2586 */         Type type = Compiler.getType(this.c);
/* 2587 */         gen.newInstance(type);
/* 2588 */         gen.dup();
/* 2589 */         Compiler.MethodExpr.emitTypedArgs(objx, gen, this.ctor.getParameterTypes(), this.args);
/* 2590 */         if (context == Compiler.C.RETURN)
/*      */         {
/* 2592 */           Compiler.ObjMethod method = (Compiler.ObjMethod)Compiler.METHOD.deref();
/* 2593 */           method.emitClearLocals(gen);
/*      */         }
/* 2595 */         gen.invokeConstructor(type, new clojure.asm.commons.Method("<init>", Type.getConstructorDescriptor(this.ctor)));
/*      */       }
/*      */       else
/*      */       {
/* 2599 */         gen.push(Compiler.destubClassName(this.c.getName()));
/* 2600 */         gen.invokeStatic(Compiler.RT_TYPE, forNameMethod);
/* 2601 */         Compiler.MethodExpr.emitArgsAsArray(this.args, objx, gen);
/* 2602 */         if (context == Compiler.C.RETURN)
/*      */         {
/* 2604 */           Compiler.ObjMethod method = (Compiler.ObjMethod)Compiler.METHOD.deref();
/* 2605 */           method.emitClearLocals(gen);
/*      */         }
/* 2607 */         gen.invokeStatic(Compiler.REFLECTOR_TYPE, invokeConstructorMethod);
/*      */       }
/* 2609 */       if (context == Compiler.C.STATEMENT)
/* 2610 */         gen.pop();
/*      */     }
/*      */     
/*      */     public boolean hasJavaClass() {
/* 2614 */       return true;
/*      */     }
/*      */     
/*      */     public Class getJavaClass() {
/* 2618 */       return this.c;
/*      */     }
/*      */     
/*      */     static class Parser implements Compiler.IParser {
/*      */       public Compiler.Expr parse(Compiler.C context, Object frm) {
/* 2623 */         int line = Compiler.lineDeref();
/* 2624 */         int column = Compiler.columnDeref();
/* 2625 */         ISeq form = (ISeq)frm;
/*      */         
/* 2627 */         if (form.count() < 2)
/* 2628 */           throw Util.runtimeException("wrong number of arguments, expecting: (new Classname args...)");
/* 2629 */         Class c = Compiler.HostExpr.maybeClass(RT.second(form), false);
/* 2630 */         if (c == null)
/* 2631 */           throw new IllegalArgumentException("Unable to resolve classname: " + RT.second(form));
/* 2632 */         PersistentVector args = PersistentVector.EMPTY;
/* 2633 */         for (ISeq s = RT.next(RT.next(form)); s != null; s = s.next())
/* 2634 */           args = args.cons(Compiler.analyze(context == Compiler.C.EVAL ? context : Compiler.C.EXPRESSION, s.first()));
/* 2635 */         return new Compiler.NewExpr(c, args, line, column);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public static class MetaExpr implements Compiler.Expr
/*      */   {
/*      */     public final Compiler.Expr expr;
/*      */     public final Compiler.Expr meta;
/* 2644 */     static final Type IOBJ_TYPE = Type.getType(IObj.class);
/* 2645 */     static final clojure.asm.commons.Method withMetaMethod = clojure.asm.commons.Method.getMethod("clojure.lang.IObj withMeta(clojure.lang.IPersistentMap)");
/*      */     
/*      */     public MetaExpr(Compiler.Expr expr, Compiler.Expr meta)
/*      */     {
/* 2649 */       this.expr = expr;
/* 2650 */       this.meta = meta;
/*      */     }
/*      */     
/*      */     public Object eval() {
/* 2654 */       return ((IObj)this.expr.eval()).withMeta((IPersistentMap)this.meta.eval());
/*      */     }
/*      */     
/*      */     public void emit(Compiler.C context, Compiler.ObjExpr objx, GeneratorAdapter gen) {
/* 2658 */       this.expr.emit(Compiler.C.EXPRESSION, objx, gen);
/* 2659 */       gen.checkCast(IOBJ_TYPE);
/* 2660 */       this.meta.emit(Compiler.C.EXPRESSION, objx, gen);
/* 2661 */       gen.checkCast(Compiler.IPERSISTENTMAP_TYPE);
/* 2662 */       gen.invokeInterface(IOBJ_TYPE, withMetaMethod);
/* 2663 */       if (context == Compiler.C.STATEMENT)
/*      */       {
/* 2665 */         gen.pop();
/*      */       }
/*      */     }
/*      */     
/*      */     public boolean hasJavaClass() {
/* 2670 */       return this.expr.hasJavaClass();
/*      */     }
/*      */     
/*      */     public Class getJavaClass() {
/* 2674 */       return this.expr.getJavaClass();
/*      */     }
/*      */   }
/*      */   
/*      */   public static class IfExpr implements Compiler.Expr, Compiler.MaybePrimitiveExpr
/*      */   {
/*      */     public final Compiler.Expr testExpr;
/*      */     public final Compiler.Expr thenExpr;
/*      */     public final Compiler.Expr elseExpr;
/*      */     public final int line;
/*      */     public final int column;
/*      */     
/*      */     public IfExpr(int line, int column, Compiler.Expr testExpr, Compiler.Expr thenExpr, Compiler.Expr elseExpr) {
/* 2687 */       this.testExpr = testExpr;
/* 2688 */       this.thenExpr = thenExpr;
/* 2689 */       this.elseExpr = elseExpr;
/* 2690 */       this.line = line;
/* 2691 */       this.column = column;
/*      */     }
/*      */     
/*      */     public Object eval() {
/* 2695 */       Object t = this.testExpr.eval();
/* 2696 */       if ((t != null) && (t != Boolean.FALSE))
/* 2697 */         return this.thenExpr.eval();
/* 2698 */       return this.elseExpr.eval();
/*      */     }
/*      */     
/*      */     public void emit(Compiler.C context, Compiler.ObjExpr objx, GeneratorAdapter gen) {
/* 2702 */       doEmit(context, objx, gen, false);
/*      */     }
/*      */     
/*      */     public void emitUnboxed(Compiler.C context, Compiler.ObjExpr objx, GeneratorAdapter gen) {
/* 2706 */       doEmit(context, objx, gen, true);
/*      */     }
/*      */     
/*      */     public void doEmit(Compiler.C context, Compiler.ObjExpr objx, GeneratorAdapter gen, boolean emitUnboxed) {
/* 2710 */       Label nullLabel = gen.newLabel();
/* 2711 */       Label falseLabel = gen.newLabel();
/* 2712 */       Label endLabel = gen.newLabel();
/*      */       
/* 2714 */       gen.visitLineNumber(this.line, gen.mark());
/*      */       
/* 2716 */       if (((this.testExpr instanceof Compiler.StaticMethodExpr)) && (((Compiler.StaticMethodExpr)this.testExpr).canEmitIntrinsicPredicate()))
/*      */       {
/* 2718 */         ((Compiler.StaticMethodExpr)this.testExpr).emitIntrinsicPredicate(Compiler.C.EXPRESSION, objx, gen, falseLabel);
/*      */       }
/* 2720 */       else if (Compiler.maybePrimitiveType(this.testExpr) == Boolean.TYPE)
/*      */       {
/* 2722 */         ((Compiler.MaybePrimitiveExpr)this.testExpr).emitUnboxed(Compiler.C.EXPRESSION, objx, gen);
/* 2723 */         gen.ifZCmp(153, falseLabel);
/*      */       }
/*      */       else
/*      */       {
/* 2727 */         this.testExpr.emit(Compiler.C.EXPRESSION, objx, gen);
/* 2728 */         gen.dup();
/* 2729 */         gen.ifNull(nullLabel);
/* 2730 */         gen.getStatic(Compiler.BOOLEAN_OBJECT_TYPE, "FALSE", Compiler.BOOLEAN_OBJECT_TYPE);
/* 2731 */         gen.visitJumpInsn(165, falseLabel);
/*      */       }
/* 2733 */       if (emitUnboxed) {
/* 2734 */         ((Compiler.MaybePrimitiveExpr)this.thenExpr).emitUnboxed(context, objx, gen);
/*      */       } else
/* 2736 */         this.thenExpr.emit(context, objx, gen);
/* 2737 */       gen.goTo(endLabel);
/* 2738 */       gen.mark(nullLabel);
/* 2739 */       gen.pop();
/* 2740 */       gen.mark(falseLabel);
/* 2741 */       if (emitUnboxed) {
/* 2742 */         ((Compiler.MaybePrimitiveExpr)this.elseExpr).emitUnboxed(context, objx, gen);
/*      */       } else
/* 2744 */         this.elseExpr.emit(context, objx, gen);
/* 2745 */       gen.mark(endLabel);
/*      */     }
/*      */     
/*      */     public boolean hasJavaClass() {
/* 2749 */       return (this.thenExpr.hasJavaClass()) && (this.elseExpr.hasJavaClass()) && ((this.thenExpr.getJavaClass() == this.elseExpr.getJavaClass()) || (this.thenExpr.getJavaClass() == Compiler.RECUR_CLASS) || (this.elseExpr.getJavaClass() == Compiler.RECUR_CLASS) || ((this.thenExpr.getJavaClass() == null) && (!this.elseExpr.getJavaClass().isPrimitive())) || ((this.elseExpr.getJavaClass() == null) && (!this.thenExpr.getJavaClass().isPrimitive())));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public boolean canEmitPrimitive()
/*      */     {
/*      */       try
/*      */       {
/* 2762 */         return ((this.thenExpr instanceof Compiler.MaybePrimitiveExpr)) && ((this.elseExpr instanceof Compiler.MaybePrimitiveExpr)) && ((this.thenExpr.getJavaClass() == this.elseExpr.getJavaClass()) || (this.thenExpr.getJavaClass() == Compiler.RECUR_CLASS) || (this.elseExpr.getJavaClass() == Compiler.RECUR_CLASS)) && (((Compiler.MaybePrimitiveExpr)this.thenExpr).canEmitPrimitive()) && (((Compiler.MaybePrimitiveExpr)this.elseExpr).canEmitPrimitive());
/*      */       }
/*      */       catch (Exception e) {}
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2772 */       return false;
/*      */     }
/*      */     
/*      */     public Class getJavaClass()
/*      */     {
/* 2777 */       Class thenClass = this.thenExpr.getJavaClass();
/* 2778 */       if ((thenClass != null) && (thenClass != Compiler.RECUR_CLASS))
/* 2779 */         return thenClass;
/* 2780 */       return this.elseExpr.getJavaClass();
/*      */     }
/*      */     
/*      */     static class Parser implements Compiler.IParser {
/*      */       public Compiler.Expr parse(Compiler.C context, Object frm) {
/* 2785 */         ISeq form = (ISeq)frm;
/*      */         
/* 2787 */         if (form.count() > 4)
/* 2788 */           throw Util.runtimeException("Too many arguments to if");
/* 2789 */         if (form.count() < 3)
/* 2790 */           throw Util.runtimeException("Too few arguments to if");
/* 2791 */         Compiler.PathNode branch = new Compiler.PathNode(Compiler.PATHTYPE.BRANCH, (Compiler.PathNode)Compiler.CLEAR_PATH.get());
/* 2792 */         Compiler.Expr testexpr = Compiler.analyze(context == Compiler.C.EVAL ? context : Compiler.C.EXPRESSION, RT.second(form));
/*      */         Compiler.Expr thenexpr;
/*      */         try {
/* 2795 */           Var.pushThreadBindings(RT.map(new Object[] { Compiler.CLEAR_PATH, new Compiler.PathNode(Compiler.PATHTYPE.PATH, branch) }));
/*      */           
/* 2797 */           thenexpr = Compiler.analyze(context, RT.third(form));
/*      */         }
/*      */         finally {
/* 2800 */           Var.popThreadBindings();
/*      */         }
/*      */         Compiler.Expr elseexpr;
/* 2803 */         try { Var.pushThreadBindings(RT.map(new Object[] { Compiler.CLEAR_PATH, new Compiler.PathNode(Compiler.PATHTYPE.PATH, branch) }));
/*      */           
/* 2805 */           elseexpr = Compiler.analyze(context, RT.fourth(form));
/*      */         }
/*      */         finally {
/* 2808 */           Var.popThreadBindings();
/*      */         }
/* 2810 */         return new Compiler.IfExpr(Compiler.lineDeref(), Compiler.columnDeref(), testexpr, thenexpr, elseexpr);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   static
/*      */   {
/*  174 */     OBJECT_TYPE = Type.getType(Object.class);
/*  175 */     ARG_TYPES = new Type[22][];
/*  176 */     for (int i = 0; i <= 20; i++)
/*      */     {
/*  178 */       Type[] a = new Type[i];
/*  179 */       for (int j = 0; j < i; j++)
/*  180 */         a[j] = OBJECT_TYPE;
/*  181 */       ARG_TYPES[i] = a;
/*      */     }
/*  183 */     Type[] a = new Type[21];
/*  184 */     for (int j = 0; j < 20; j++)
/*  185 */       a[j] = OBJECT_TYPE;
/*  186 */     a[20] = Type.getType("[Ljava/lang/Object;");
/*  187 */     ARG_TYPES[21] = a;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  194 */     LOCAL_ENV = Var.create(null).setDynamic();
/*      */     
/*      */ 
/*  197 */     LOOP_LOCALS = Var.create().setDynamic();
/*      */     
/*      */ 
/*  200 */     LOOP_LABEL = Var.create().setDynamic();
/*      */     
/*      */ 
/*  203 */     CONSTANTS = Var.create().setDynamic();
/*      */     
/*      */ 
/*  206 */     CONSTANT_IDS = Var.create().setDynamic();
/*      */     
/*      */ 
/*  209 */     KEYWORD_CALLSITES = Var.create().setDynamic();
/*      */     
/*      */ 
/*  212 */     PROTOCOL_CALLSITES = Var.create().setDynamic();
/*      */     
/*      */ 
/*  215 */     VAR_CALLSITES = Var.create().setDynamic();
/*      */     
/*      */ 
/*  218 */     KEYWORDS = Var.create().setDynamic();
/*      */     
/*      */ 
/*  221 */     VARS = Var.create().setDynamic();
/*      */     
/*      */ 
/*  224 */     METHOD = Var.create(null).setDynamic();
/*      */     
/*      */ 
/*  227 */     IN_CATCH_FINALLY = Var.create(null).setDynamic();
/*      */     
/*  229 */     NO_RECUR = Var.create(null).setDynamic();
/*      */     
/*      */ 
/*  232 */     LOADER = Var.create().setDynamic();
/*      */     
/*      */ 
/*  235 */     SOURCE = Var.intern(Namespace.findOrCreate(Symbol.intern("clojure.core")), Symbol.intern("*source-path*"), "NO_SOURCE_FILE").setDynamic();
/*      */     
/*      */ 
/*      */ 
/*  239 */     SOURCE_PATH = Var.intern(Namespace.findOrCreate(Symbol.intern("clojure.core")), Symbol.intern("*file*"), "NO_SOURCE_PATH").setDynamic();
/*      */     
/*      */ 
/*      */ 
/*  243 */     COMPILE_PATH = Var.intern(Namespace.findOrCreate(Symbol.intern("clojure.core")), Symbol.intern("*compile-path*"), null).setDynamic();
/*      */     
/*      */ 
/*  246 */     COMPILE_FILES = Var.intern(Namespace.findOrCreate(Symbol.intern("clojure.core")), Symbol.intern("*compile-files*"), Boolean.FALSE).setDynamic();
/*      */     
/*      */ 
/*  249 */     INSTANCE = Var.intern(Namespace.findOrCreate(Symbol.intern("clojure.core")), Symbol.intern("instance?"));
/*      */     
/*      */ 
/*  252 */     ADD_ANNOTATIONS = Var.intern(Namespace.findOrCreate(Symbol.intern("clojure.core")), Symbol.intern("add-annotations"));
/*      */     
/*      */ 
/*  255 */     disableLocalsClearingKey = Keyword.intern("disable-locals-clearing");
/*  256 */     directLinkingKey = Keyword.intern("direct-linking");
/*  257 */     elideMetaKey = Keyword.intern("elide-meta");
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  267 */     Object compilerOptions = null;
/*      */     
/*  269 */     for (Map.Entry e : System.getProperties().entrySet())
/*      */     {
/*  271 */       String name = (String)e.getKey();
/*  272 */       String v = (String)e.getValue();
/*  273 */       if (name.startsWith("clojure.compiler."))
/*      */       {
/*  275 */         compilerOptions = RT.assoc(compilerOptions, RT.keyword(null, name.substring(1 + name.lastIndexOf('.'))), RT.readString(v));
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  281 */     COMPILER_OPTIONS = Var.intern(Namespace.findOrCreate(Symbol.intern("clojure.core")), Symbol.intern("*compiler-options*"), compilerOptions).setDynamic();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  300 */     LINE = Var.create(Integer.valueOf(0)).setDynamic();
/*  301 */     COLUMN = Var.create(Integer.valueOf(0)).setDynamic();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  312 */     LINE_BEFORE = Var.create(Integer.valueOf(0)).setDynamic();
/*  313 */     COLUMN_BEFORE = Var.create(Integer.valueOf(0)).setDynamic();
/*  314 */     LINE_AFTER = Var.create(Integer.valueOf(0)).setDynamic();
/*  315 */     COLUMN_AFTER = Var.create(Integer.valueOf(0)).setDynamic();
/*      */     
/*      */ 
/*  318 */     NEXT_LOCAL_NUM = Var.create(Integer.valueOf(0)).setDynamic();
/*      */     
/*      */ 
/*  321 */     RET_LOCAL_NUM = Var.create().setDynamic();
/*      */     
/*      */ 
/*  324 */     COMPILE_STUB_SYM = Var.create(null).setDynamic();
/*  325 */     COMPILE_STUB_CLASS = Var.create(null).setDynamic();
/*      */     
/*      */ 
/*      */ 
/*  329 */     CLEAR_PATH = Var.create(null).setDynamic();
/*      */     
/*      */ 
/*  332 */     CLEAR_ROOT = Var.create(null).setDynamic();
/*      */     
/*      */ 
/*  335 */     CLEAR_SITES = Var.create(null).setDynamic();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  345 */     RECUR_CLASS = Recur.class;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2014 */     NIL_EXPR = new NilExpr();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2048 */     TRUE_EXPR = new BooleanExpr(true);
/* 2049 */     FALSE_EXPR = new BooleanExpr(false);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2819 */     CHAR_MAP = PersistentHashMap.create(new Object[] { Character.valueOf('-'), "_", Character.valueOf(':'), "_COLON_", Character.valueOf('+'), "_PLUS_", Character.valueOf('>'), "_GT_", Character.valueOf('<'), "_LT_", Character.valueOf('='), "_EQ_", Character.valueOf('~'), "_TILDE_", Character.valueOf('!'), "_BANG_", Character.valueOf('@'), "_CIRCA_", Character.valueOf('#'), "_SHARP_", Character.valueOf('\''), "_SINGLEQUOTE_", Character.valueOf('"'), "_DOUBLEQUOTE_", Character.valueOf('%'), "_PERCENT_", Character.valueOf('^'), "_CARET_", Character.valueOf('&'), "_AMPERSAND_", Character.valueOf('*'), "_STAR_", Character.valueOf('|'), "_BAR_", Character.valueOf('{'), "_LBRACE_", Character.valueOf('}'), "_RBRACE_", Character.valueOf('['), "_LBRACK_", Character.valueOf(']'), "_RBRACK_", Character.valueOf('/'), "_SLASH_", Character.valueOf('\\'), "_BSLASH_", Character.valueOf('?'), "_QMARK_" });
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2852 */     IPersistentMap m = RT.map(new Object[] { "$", Character.valueOf('/') });
/* 2853 */     for (ISeq s = RT.seq(CHAR_MAP); s != null; s = s.next())
/*      */     {
/* 2855 */       IMapEntry e = (IMapEntry)s.first();
/* 2856 */       Character origCh = (Character)e.key();
/* 2857 */       String escapeStr = (String)e.val();
/* 2858 */       m = m.assoc(escapeStr, origCh);
/*      */     }
/* 2860 */     DEMUNGE_MAP = m;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2869 */     Object[] mungeStrs = RT.toArray(RT.keys(m));
/* 2870 */     Arrays.sort(mungeStrs, new java.util.Comparator()
/*      */     {
/* 2872 */       public int compare(Object s1, Object s2) { return ((String)s2).length() - ((String)s1).length(); }
/* 2873 */     });
/* 2874 */     StringBuilder sb = new StringBuilder();
/* 2875 */     boolean first = true;
/* 2876 */     for (Object s : mungeStrs)
/*      */     {
/* 2878 */       String escapeStr = (String)s;
/* 2879 */       if (!first)
/* 2880 */         sb.append("|");
/* 2881 */       first = false;
/* 2882 */       sb.append("\\Q");
/* 2883 */       sb.append(escapeStr);
/* 2884 */       sb.append("\\E");
/*      */     }
/* 2886 */     DEMUNGE_PATTERN = Pattern.compile(sb.toString());
/*      */   }
/*      */   
/*      */   public static String munge(String name) {
/* 2890 */     StringBuilder sb = new StringBuilder();
/* 2891 */     for (char c : name.toCharArray())
/*      */     {
/* 2893 */       String sub = (String)CHAR_MAP.valAt(Character.valueOf(c));
/* 2894 */       if (sub != null) {
/* 2895 */         sb.append(sub);
/*      */       } else
/* 2897 */         sb.append(c);
/*      */     }
/* 2899 */     return sb.toString();
/*      */   }
/*      */   
/*      */   public static String demunge(String mungedName) {
/* 2903 */     StringBuilder sb = new StringBuilder();
/* 2904 */     Matcher m = DEMUNGE_PATTERN.matcher(mungedName);
/* 2905 */     int lastMatchEnd = 0;
/* 2906 */     while (m.find())
/*      */     {
/* 2908 */       int start = m.start();
/* 2909 */       int end = m.end();
/*      */       
/* 2911 */       sb.append(mungedName.substring(lastMatchEnd, start));
/* 2912 */       lastMatchEnd = end;
/*      */       
/* 2914 */       Character origCh = (Character)DEMUNGE_MAP.valAt(m.group());
/* 2915 */       sb.append(origCh);
/*      */     }
/*      */     
/* 2918 */     sb.append(mungedName.substring(lastMatchEnd));
/* 2919 */     return sb.toString();
/*      */   }
/*      */   
/*      */   public static class EmptyExpr implements Compiler.Expr {
/*      */     public final Object coll;
/* 2924 */     static final Type HASHMAP_TYPE = Type.getType(PersistentArrayMap.class);
/* 2925 */     static final Type HASHSET_TYPE = Type.getType(PersistentHashSet.class);
/* 2926 */     static final Type VECTOR_TYPE = Type.getType(PersistentVector.class);
/* 2927 */     static final Type IVECTOR_TYPE = Type.getType(IPersistentVector.class);
/* 2928 */     static final Type TUPLE_TYPE = Type.getType(Tuple.class);
/* 2929 */     static final Type LIST_TYPE = Type.getType(PersistentList.class);
/* 2930 */     static final Type EMPTY_LIST_TYPE = Type.getType(PersistentList.EmptyList.class);
/*      */     
/*      */     public EmptyExpr(Object coll)
/*      */     {
/* 2934 */       this.coll = coll;
/*      */     }
/*      */     
/*      */     public Object eval() {
/* 2938 */       return this.coll;
/*      */     }
/*      */     
/*      */     public void emit(Compiler.C context, Compiler.ObjExpr objx, GeneratorAdapter gen) {
/* 2942 */       if ((this.coll instanceof IPersistentList)) {
/* 2943 */         gen.getStatic(LIST_TYPE, "EMPTY", EMPTY_LIST_TYPE);
/* 2944 */       } else if ((this.coll instanceof IPersistentVector)) {
/* 2945 */         gen.getStatic(VECTOR_TYPE, "EMPTY", VECTOR_TYPE);
/* 2946 */       } else if ((this.coll instanceof IPersistentMap)) {
/* 2947 */         gen.getStatic(HASHMAP_TYPE, "EMPTY", HASHMAP_TYPE);
/* 2948 */       } else if ((this.coll instanceof IPersistentSet)) {
/* 2949 */         gen.getStatic(HASHSET_TYPE, "EMPTY", HASHSET_TYPE);
/*      */       } else
/* 2951 */         throw new UnsupportedOperationException("Unknown Collection type");
/* 2952 */       if (context == Compiler.C.STATEMENT)
/*      */       {
/* 2954 */         gen.pop();
/*      */       }
/*      */     }
/*      */     
/*      */     public boolean hasJavaClass() {
/* 2959 */       return true;
/*      */     }
/*      */     
/*      */     public Class getJavaClass() {
/* 2963 */       if ((this.coll instanceof IPersistentList))
/* 2964 */         return IPersistentList.class;
/* 2965 */       if ((this.coll instanceof IPersistentVector))
/* 2966 */         return IPersistentVector.class;
/* 2967 */       if ((this.coll instanceof IPersistentMap))
/* 2968 */         return IPersistentMap.class;
/* 2969 */       if ((this.coll instanceof IPersistentSet)) {
/* 2970 */         return IPersistentSet.class;
/*      */       }
/* 2972 */       throw new UnsupportedOperationException("Unknown Collection type");
/*      */     }
/*      */   }
/*      */   
/*      */   public static class ListExpr implements Compiler.Expr {
/*      */     public final IPersistentVector args;
/* 2978 */     static final clojure.asm.commons.Method arrayToListMethod = clojure.asm.commons.Method.getMethod("clojure.lang.ISeq arrayToList(Object[])");
/*      */     
/*      */     public ListExpr(IPersistentVector args)
/*      */     {
/* 2982 */       this.args = args;
/*      */     }
/*      */     
/*      */     public Object eval() {
/* 2986 */       IPersistentVector ret = PersistentVector.EMPTY;
/* 2987 */       for (int i = 0; i < this.args.count(); i++)
/* 2988 */         ret = ret.cons(((Compiler.Expr)this.args.nth(i)).eval());
/* 2989 */       return ret.seq();
/*      */     }
/*      */     
/*      */     public void emit(Compiler.C context, Compiler.ObjExpr objx, GeneratorAdapter gen) {
/* 2993 */       Compiler.MethodExpr.emitArgsAsArray(this.args, objx, gen);
/* 2994 */       gen.invokeStatic(Compiler.RT_TYPE, arrayToListMethod);
/* 2995 */       if (context == Compiler.C.STATEMENT)
/* 2996 */         gen.pop();
/*      */     }
/*      */     
/*      */     public boolean hasJavaClass() {
/* 3000 */       return true;
/*      */     }
/*      */     
/*      */     public Class getJavaClass() {
/* 3004 */       return IPersistentList.class;
/*      */     }
/*      */   }
/*      */   
/*      */   public static class MapExpr implements Compiler.Expr
/*      */   {
/*      */     public final IPersistentVector keyvals;
/* 3011 */     static final clojure.asm.commons.Method mapMethod = clojure.asm.commons.Method.getMethod("clojure.lang.IPersistentMap map(Object[])");
/* 3012 */     static final clojure.asm.commons.Method mapUniqueKeysMethod = clojure.asm.commons.Method.getMethod("clojure.lang.IPersistentMap mapUniqueKeys(Object[])");
/*      */     
/*      */     public MapExpr(IPersistentVector keyvals)
/*      */     {
/* 3016 */       this.keyvals = keyvals;
/*      */     }
/*      */     
/*      */     public Object eval() {
/* 3020 */       Object[] ret = new Object[this.keyvals.count()];
/* 3021 */       for (int i = 0; i < this.keyvals.count(); i++)
/* 3022 */         ret[i] = ((Compiler.Expr)this.keyvals.nth(i)).eval();
/* 3023 */       return RT.map(ret);
/*      */     }
/*      */     
/*      */     public void emit(Compiler.C context, Compiler.ObjExpr objx, GeneratorAdapter gen) {
/* 3027 */       boolean allKeysConstant = true;
/* 3028 */       boolean allConstantKeysUnique = true;
/* 3029 */       IPersistentSet constantKeys = PersistentHashSet.EMPTY;
/* 3030 */       for (int i = 0; i < this.keyvals.count(); i += 2)
/*      */       {
/* 3032 */         Compiler.Expr k = (Compiler.Expr)this.keyvals.nth(i);
/* 3033 */         if ((k instanceof Compiler.LiteralExpr))
/*      */         {
/* 3035 */           Object kval = k.eval();
/* 3036 */           if (constantKeys.contains(kval)) {
/* 3037 */             allConstantKeysUnique = false;
/*      */           } else {
/* 3039 */             constantKeys = (IPersistentSet)constantKeys.cons(kval);
/*      */           }
/*      */         } else {
/* 3042 */           allKeysConstant = false;
/*      */         } }
/* 3044 */       Compiler.MethodExpr.emitArgsAsArray(this.keyvals, objx, gen);
/* 3045 */       if (((allKeysConstant) && (allConstantKeysUnique)) || (this.keyvals.count() <= 2)) {
/* 3046 */         gen.invokeStatic(Compiler.RT_TYPE, mapUniqueKeysMethod);
/*      */       } else
/* 3048 */         gen.invokeStatic(Compiler.RT_TYPE, mapMethod);
/* 3049 */       if (context == Compiler.C.STATEMENT)
/* 3050 */         gen.pop();
/*      */     }
/*      */     
/*      */     public boolean hasJavaClass() {
/* 3054 */       return true;
/*      */     }
/*      */     
/*      */     public Class getJavaClass() {
/* 3058 */       return IPersistentMap.class;
/*      */     }
/*      */     
/*      */     public static Compiler.Expr parse(Compiler.C context, IPersistentMap form)
/*      */     {
/* 3063 */       IPersistentVector keyvals = PersistentVector.EMPTY;
/* 3064 */       boolean keysConstant = true;
/* 3065 */       boolean valsConstant = true;
/* 3066 */       boolean allConstantKeysUnique = true;
/* 3067 */       IPersistentSet constantKeys = PersistentHashSet.EMPTY;
/* 3068 */       for (ISeq s = RT.seq(form); s != null; s = s.next())
/*      */       {
/* 3070 */         IMapEntry e = (IMapEntry)s.first();
/* 3071 */         Compiler.Expr k = Compiler.analyze(context == Compiler.C.EVAL ? context : Compiler.C.EXPRESSION, e.key());
/* 3072 */         Compiler.Expr v = Compiler.analyze(context == Compiler.C.EVAL ? context : Compiler.C.EXPRESSION, e.val());
/* 3073 */         keyvals = keyvals.cons(k);
/* 3074 */         keyvals = keyvals.cons(v);
/* 3075 */         if ((k instanceof Compiler.LiteralExpr))
/*      */         {
/* 3077 */           Object kval = k.eval();
/* 3078 */           if (constantKeys.contains(kval)) {
/* 3079 */             allConstantKeysUnique = false;
/*      */           } else {
/* 3081 */             constantKeys = (IPersistentSet)constantKeys.cons(kval);
/*      */           }
/*      */         } else {
/* 3084 */           keysConstant = false; }
/* 3085 */         if (!(v instanceof Compiler.LiteralExpr)) {
/* 3086 */           valsConstant = false;
/*      */         }
/*      */       }
/* 3089 */       Compiler.Expr ret = new MapExpr(keyvals);
/* 3090 */       if (((form instanceof IObj)) && (((IObj)form).meta() != null)) {
/* 3091 */         return new Compiler.MetaExpr(ret, parse(context == Compiler.C.EVAL ? context : Compiler.C.EXPRESSION, ((IObj)form).meta()));
/*      */       }
/* 3093 */       if (keysConstant)
/*      */       {
/*      */ 
/* 3096 */         if (!allConstantKeysUnique)
/* 3097 */           throw new IllegalArgumentException("Duplicate constant keys in map");
/* 3098 */         if (valsConstant)
/*      */         {
/* 3100 */           IPersistentMap m = PersistentArrayMap.EMPTY;
/* 3101 */           for (int i = 0; i < keyvals.length(); i += 2)
/*      */           {
/* 3103 */             m = m.assoc(((Compiler.LiteralExpr)keyvals.nth(i)).val(), ((Compiler.LiteralExpr)keyvals.nth(i + 1)).val());
/*      */           }
/*      */           
/* 3106 */           return new Compiler.ConstantExpr(m);
/*      */         }
/*      */         
/* 3109 */         return ret;
/*      */       }
/*      */       
/* 3112 */       return ret;
/*      */     }
/*      */   }
/*      */   
/*      */   public static class SetExpr implements Compiler.Expr {
/*      */     public final IPersistentVector keys;
/* 3118 */     static final clojure.asm.commons.Method setMethod = clojure.asm.commons.Method.getMethod("clojure.lang.IPersistentSet set(Object[])");
/*      */     
/*      */     public SetExpr(IPersistentVector keys)
/*      */     {
/* 3122 */       this.keys = keys;
/*      */     }
/*      */     
/*      */     public Object eval() {
/* 3126 */       Object[] ret = new Object[this.keys.count()];
/* 3127 */       for (int i = 0; i < this.keys.count(); i++)
/* 3128 */         ret[i] = ((Compiler.Expr)this.keys.nth(i)).eval();
/* 3129 */       return RT.set(ret);
/*      */     }
/*      */     
/*      */     public void emit(Compiler.C context, Compiler.ObjExpr objx, GeneratorAdapter gen) {
/* 3133 */       Compiler.MethodExpr.emitArgsAsArray(this.keys, objx, gen);
/* 3134 */       gen.invokeStatic(Compiler.RT_TYPE, setMethod);
/* 3135 */       if (context == Compiler.C.STATEMENT)
/* 3136 */         gen.pop();
/*      */     }
/*      */     
/*      */     public boolean hasJavaClass() {
/* 3140 */       return true;
/*      */     }
/*      */     
/*      */     public Class getJavaClass() {
/* 3144 */       return IPersistentSet.class;
/*      */     }
/*      */     
/*      */     public static Compiler.Expr parse(Compiler.C context, IPersistentSet form)
/*      */     {
/* 3149 */       IPersistentVector keys = PersistentVector.EMPTY;
/* 3150 */       boolean constant = true;
/*      */       
/* 3152 */       for (ISeq s = RT.seq(form); s != null; s = s.next())
/*      */       {
/* 3154 */         Object e = s.first();
/* 3155 */         Compiler.Expr expr = Compiler.analyze(context == Compiler.C.EVAL ? context : Compiler.C.EXPRESSION, e);
/* 3156 */         keys = keys.cons(expr);
/* 3157 */         if (!(expr instanceof Compiler.LiteralExpr))
/* 3158 */           constant = false;
/*      */       }
/* 3160 */       Compiler.Expr ret = new SetExpr(keys);
/* 3161 */       if (((form instanceof IObj)) && (((IObj)form).meta() != null)) {
/* 3162 */         return new Compiler.MetaExpr(ret, Compiler.MapExpr.parse(context == Compiler.C.EVAL ? context : Compiler.C.EXPRESSION, ((IObj)form).meta()));
/*      */       }
/* 3164 */       if (constant)
/*      */       {
/* 3166 */         IPersistentSet set = PersistentHashSet.EMPTY;
/* 3167 */         for (int i = 0; i < keys.count(); i++)
/*      */         {
/* 3169 */           Compiler.LiteralExpr ve = (Compiler.LiteralExpr)keys.nth(i);
/* 3170 */           set = (IPersistentSet)set.cons(ve.val());
/*      */         }
/*      */         
/* 3173 */         return new Compiler.ConstantExpr(set);
/*      */       }
/*      */       
/* 3176 */       return ret;
/*      */     }
/*      */   }
/*      */   
/*      */   public static class VectorExpr implements Compiler.Expr {
/*      */     public final IPersistentVector args;
/* 3182 */     static final clojure.asm.commons.Method vectorMethod = clojure.asm.commons.Method.getMethod("clojure.lang.IPersistentVector vector(Object[])");
/*      */     
/*      */     public VectorExpr(IPersistentVector args) {
/* 3185 */       this.args = args;
/*      */     }
/*      */     
/*      */     public Object eval() {
/* 3189 */       IPersistentVector ret = PersistentVector.EMPTY;
/* 3190 */       for (int i = 0; i < this.args.count(); i++)
/* 3191 */         ret = ret.cons(((Compiler.Expr)this.args.nth(i)).eval());
/* 3192 */       return ret;
/*      */     }
/*      */     
/*      */     public void emit(Compiler.C context, Compiler.ObjExpr objx, GeneratorAdapter gen) {
/* 3196 */       if (this.args.count() <= 6)
/*      */       {
/* 3198 */         for (int i = 0; i < this.args.count(); i++) {
/* 3199 */           ((Compiler.Expr)this.args.nth(i)).emit(Compiler.C.EXPRESSION, objx, gen);
/*      */         }
/* 3201 */         gen.invokeStatic(Compiler.TUPLE_TYPE, Compiler.createTupleMethods[this.args.count()]);
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/* 3206 */         Compiler.MethodExpr.emitArgsAsArray(this.args, objx, gen);
/* 3207 */         gen.invokeStatic(Compiler.RT_TYPE, vectorMethod);
/*      */       }
/*      */       
/* 3210 */       if (context == Compiler.C.STATEMENT)
/* 3211 */         gen.pop();
/*      */     }
/*      */     
/*      */     public boolean hasJavaClass() {
/* 3215 */       return true;
/*      */     }
/*      */     
/*      */     public Class getJavaClass() {
/* 3219 */       return IPersistentVector.class;
/*      */     }
/*      */     
/*      */     public static Compiler.Expr parse(Compiler.C context, IPersistentVector form) {
/* 3223 */       boolean constant = true;
/*      */       
/* 3225 */       IPersistentVector args = PersistentVector.EMPTY;
/* 3226 */       for (int i = 0; i < form.count(); i++)
/*      */       {
/* 3228 */         Compiler.Expr v = Compiler.analyze(context == Compiler.C.EVAL ? context : Compiler.C.EXPRESSION, form.nth(i));
/* 3229 */         args = args.cons(v);
/* 3230 */         if (!(v instanceof Compiler.LiteralExpr))
/* 3231 */           constant = false;
/*      */       }
/* 3233 */       Compiler.Expr ret = new VectorExpr(args);
/* 3234 */       if (((form instanceof IObj)) && (((IObj)form).meta() != null)) {
/* 3235 */         return new Compiler.MetaExpr(ret, Compiler.MapExpr.parse(context == Compiler.C.EVAL ? context : Compiler.C.EXPRESSION, ((IObj)form).meta()));
/*      */       }
/* 3237 */       if (constant)
/*      */       {
/* 3239 */         IPersistentVector rv = PersistentVector.EMPTY;
/* 3240 */         for (int i = 0; i < args.count(); i++)
/*      */         {
/* 3242 */           Compiler.LiteralExpr ve = (Compiler.LiteralExpr)args.nth(i);
/* 3243 */           rv = rv.cons(ve.val());
/*      */         }
/*      */         
/* 3246 */         return new Compiler.ConstantExpr(rv);
/*      */       }
/*      */       
/* 3249 */       return ret;
/*      */     }
/*      */   }
/*      */   
/*      */   static class KeywordInvokeExpr implements Compiler.Expr
/*      */   {
/*      */     public final Compiler.KeywordExpr kw;
/*      */     public final Object tag;
/*      */     public final Compiler.Expr target;
/*      */     public final int line;
/*      */     public final int column;
/*      */     public final int siteIndex;
/*      */     public final String source;
/* 3262 */     static Type ILOOKUP_TYPE = Type.getType(ILookup.class);
/*      */     
/*      */     public KeywordInvokeExpr(String source, int line, int column, Symbol tag, Compiler.KeywordExpr kw, Compiler.Expr target) {
/* 3265 */       this.source = source;
/* 3266 */       this.kw = kw;
/* 3267 */       this.target = target;
/* 3268 */       this.line = line;
/* 3269 */       this.column = column;
/* 3270 */       this.tag = tag;
/* 3271 */       this.siteIndex = Compiler.registerKeywordCallsite(kw.k);
/*      */     }
/*      */     
/*      */     public Object eval()
/*      */     {
/*      */       try {
/* 3277 */         return this.kw.k.invoke(this.target.eval());
/*      */       }
/*      */       catch (Throwable e)
/*      */       {
/* 3281 */         if (!(e instanceof Compiler.CompilerException)) {
/* 3282 */           throw new Compiler.CompilerException(this.source, this.line, this.column, e);
/*      */         }
/* 3284 */         throw ((Compiler.CompilerException)e);
/*      */       }
/*      */     }
/*      */     
/*      */     public void emit(Compiler.C context, Compiler.ObjExpr objx, GeneratorAdapter gen) {
/* 3289 */       Label endLabel = gen.newLabel();
/* 3290 */       Label faultLabel = gen.newLabel();
/*      */       
/* 3292 */       gen.visitLineNumber(this.line, gen.mark());
/* 3293 */       gen.getStatic(objx.objtype, objx.thunkNameStatic(this.siteIndex), Compiler.ObjExpr.ILOOKUP_THUNK_TYPE);
/* 3294 */       gen.dup();
/* 3295 */       this.target.emit(Compiler.C.EXPRESSION, objx, gen);
/* 3296 */       gen.visitLineNumber(this.line, gen.mark());
/* 3297 */       gen.dupX2();
/* 3298 */       gen.invokeInterface(Compiler.ObjExpr.ILOOKUP_THUNK_TYPE, clojure.asm.commons.Method.getMethod("Object get(Object)"));
/* 3299 */       gen.dupX2();
/* 3300 */       gen.visitJumpInsn(165, faultLabel);
/* 3301 */       gen.pop();
/* 3302 */       gen.goTo(endLabel);
/*      */       
/* 3304 */       gen.mark(faultLabel);
/* 3305 */       gen.swap();
/* 3306 */       gen.pop();
/* 3307 */       gen.dup();
/* 3308 */       gen.getStatic(objx.objtype, objx.siteNameStatic(this.siteIndex), Compiler.ObjExpr.KEYWORD_LOOKUPSITE_TYPE);
/* 3309 */       gen.swap();
/* 3310 */       gen.invokeInterface(Compiler.ObjExpr.ILOOKUP_SITE_TYPE, clojure.asm.commons.Method.getMethod("clojure.lang.ILookupThunk fault(Object)"));
/*      */       
/* 3312 */       gen.dup();
/* 3313 */       gen.putStatic(objx.objtype, objx.thunkNameStatic(this.siteIndex), Compiler.ObjExpr.ILOOKUP_THUNK_TYPE);
/* 3314 */       gen.swap();
/* 3315 */       gen.invokeInterface(Compiler.ObjExpr.ILOOKUP_THUNK_TYPE, clojure.asm.commons.Method.getMethod("Object get(Object)"));
/*      */       
/* 3317 */       gen.mark(endLabel);
/* 3318 */       if (context == Compiler.C.STATEMENT)
/* 3319 */         gen.pop();
/*      */     }
/*      */     
/*      */     public boolean hasJavaClass() {
/* 3323 */       return this.tag != null;
/*      */     }
/*      */     
/*      */     public Class getJavaClass() {
/* 3327 */       return Compiler.HostExpr.tagToClass(this.tag);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static class InstanceOfExpr
/*      */     implements Compiler.Expr, Compiler.MaybePrimitiveExpr
/*      */   {
/*      */     Compiler.Expr expr;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     Class c;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public InstanceOfExpr(Class c, Compiler.Expr expr)
/*      */     {
/* 3391 */       this.expr = expr;
/* 3392 */       this.c = c;
/*      */     }
/*      */     
/*      */     public Object eval() {
/* 3396 */       if (this.c.isInstance(this.expr.eval()))
/* 3397 */         return RT.T;
/* 3398 */       return RT.F;
/*      */     }
/*      */     
/*      */     public boolean canEmitPrimitive() {
/* 3402 */       return true;
/*      */     }
/*      */     
/*      */     public void emitUnboxed(Compiler.C context, Compiler.ObjExpr objx, GeneratorAdapter gen) {
/* 3406 */       this.expr.emit(Compiler.C.EXPRESSION, objx, gen);
/* 3407 */       gen.instanceOf(Compiler.getType(this.c));
/*      */     }
/*      */     
/*      */     public void emit(Compiler.C context, Compiler.ObjExpr objx, GeneratorAdapter gen) {
/* 3411 */       emitUnboxed(context, objx, gen);
/* 3412 */       Compiler.HostExpr.emitBoxReturn(objx, gen, Boolean.TYPE);
/* 3413 */       if (context == Compiler.C.STATEMENT)
/* 3414 */         gen.pop();
/*      */     }
/*      */     
/*      */     public boolean hasJavaClass() {
/* 3418 */       return true;
/*      */     }
/*      */     
/*      */     public Class getJavaClass() {
/* 3422 */       return Boolean.TYPE;
/*      */     }
/*      */   }
/*      */   
/*      */   static class StaticInvokeExpr implements Compiler.Expr, Compiler.MaybePrimitiveExpr
/*      */   {
/*      */     public final Type target;
/*      */     public final Class retClass;
/*      */     public final Class[] paramclasses;
/*      */     public final Type[] paramtypes;
/*      */     public final IPersistentVector args;
/*      */     public final boolean variadic;
/*      */     public final Object tag;
/*      */     
/*      */     StaticInvokeExpr(Type target, Class retClass, Class[] paramclasses, Type[] paramtypes, boolean variadic, IPersistentVector args, Object tag)
/*      */     {
/* 3438 */       this.target = target;
/* 3439 */       this.retClass = retClass;
/* 3440 */       this.paramclasses = paramclasses;
/* 3441 */       this.paramtypes = paramtypes;
/* 3442 */       this.args = args;
/* 3443 */       this.variadic = variadic;
/* 3444 */       this.tag = tag;
/*      */     }
/*      */     
/*      */     public Object eval() {
/* 3448 */       throw new UnsupportedOperationException("Can't eval StaticInvokeExpr");
/*      */     }
/*      */     
/*      */     public void emit(Compiler.C context, Compiler.ObjExpr objx, GeneratorAdapter gen) {
/* 3452 */       emitUnboxed(context, objx, gen);
/* 3453 */       if (context != Compiler.C.STATEMENT)
/* 3454 */         Compiler.HostExpr.emitBoxReturn(objx, gen, this.retClass);
/* 3455 */       if (context == Compiler.C.STATEMENT)
/*      */       {
/* 3457 */         if ((this.retClass == Long.TYPE) || (this.retClass == Double.TYPE)) {
/* 3458 */           gen.pop2();
/*      */         } else
/* 3460 */           gen.pop();
/*      */       }
/*      */     }
/*      */     
/*      */     public boolean hasJavaClass() {
/* 3465 */       return true;
/*      */     }
/*      */     
/*      */     public Class getJavaClass() {
/* 3469 */       return Compiler.retType(this.tag != null ? Compiler.HostExpr.tagToClass(this.tag) : null, this.retClass);
/*      */     }
/*      */     
/*      */     public boolean canEmitPrimitive() {
/* 3473 */       return this.retClass.isPrimitive();
/*      */     }
/*      */     
/*      */     public void emitUnboxed(Compiler.C context, Compiler.ObjExpr objx, GeneratorAdapter gen) {
/* 3477 */       clojure.asm.commons.Method ms = new clojure.asm.commons.Method("invokeStatic", getReturnType(), this.paramtypes);
/* 3478 */       if (this.variadic)
/*      */       {
/* 3480 */         for (int i = 0; i < this.paramclasses.length - 1; i++)
/*      */         {
/* 3482 */           Compiler.Expr e = (Compiler.Expr)this.args.nth(i);
/* 3483 */           if (Compiler.maybePrimitiveType(e) == this.paramclasses[i])
/*      */           {
/* 3485 */             ((Compiler.MaybePrimitiveExpr)e).emitUnboxed(Compiler.C.EXPRESSION, objx, gen);
/*      */           }
/*      */           else
/*      */           {
/* 3489 */             e.emit(Compiler.C.EXPRESSION, objx, gen);
/* 3490 */             Compiler.HostExpr.emitUnboxArg(objx, gen, this.paramclasses[i]);
/*      */           }
/*      */         }
/* 3493 */         IPersistentVector restArgs = RT.subvec(this.args, this.paramclasses.length - 1, this.args.count());
/* 3494 */         Compiler.MethodExpr.emitArgsAsArray(restArgs, objx, gen);
/* 3495 */         gen.invokeStatic(Type.getType(ArraySeq.class), clojure.asm.commons.Method.getMethod("clojure.lang.ArraySeq create(Object[])"));
/*      */       }
/*      */       else {
/* 3498 */         Compiler.MethodExpr.emitTypedArgs(objx, gen, this.paramclasses, this.args);
/*      */       }
/* 3500 */       gen.invokeStatic(this.target, ms);
/*      */     }
/*      */     
/*      */     private Type getReturnType() {
/* 3504 */       return Type.getType(this.retClass);
/*      */     }
/*      */     
/*      */     public static Compiler.Expr parse(Var v, ISeq args, Object tag) {
/* 3508 */       if ((!v.isBound()) || (v.get() == null))
/*      */       {
/*      */ 
/* 3511 */         return null;
/*      */       }
/* 3513 */       Class c = v.get().getClass();
/* 3514 */       String cname = c.getName();
/*      */       
/*      */ 
/* 3517 */       java.lang.reflect.Method[] allmethods = c.getMethods();
/*      */       
/* 3519 */       boolean variadic = false;
/* 3520 */       int argcount = RT.count(args);
/* 3521 */       java.lang.reflect.Method method = null;
/* 3522 */       for (java.lang.reflect.Method m : allmethods)
/*      */       {
/*      */ 
/* 3525 */         if ((Modifier.isStatic(m.getModifiers())) && (m.getName().equals("invokeStatic")))
/*      */         {
/* 3527 */           Class[] params = m.getParameterTypes();
/* 3528 */           if (argcount == params.length)
/*      */           {
/* 3530 */             method = m;
/* 3531 */             variadic = (argcount > 0) && (params[(params.length - 1)] == ISeq.class);
/* 3532 */             break;
/*      */           }
/* 3534 */           if ((argcount > params.length) && (params.length > 0) && (params[(params.length - 1)] == ISeq.class))
/*      */           {
/*      */ 
/*      */ 
/* 3538 */             method = m;
/* 3539 */             variadic = true;
/* 3540 */             break;
/*      */           }
/*      */         }
/*      */       }
/* 3544 */       if (method == null) {
/* 3545 */         return null;
/*      */       }
/* 3547 */       Class retClass = method.getReturnType();
/*      */       
/* 3549 */       Class[] paramClasses = method.getParameterTypes();
/* 3550 */       Type[] paramTypes = new Type[paramClasses.length];
/*      */       
/* 3552 */       for (int i = 0; i < paramClasses.length; i++)
/*      */       {
/* 3554 */         paramTypes[i] = Type.getType(paramClasses[i]);
/*      */       }
/*      */       
/* 3557 */       Type target = Type.getType(c);
/*      */       
/* 3559 */       PersistentVector argv = PersistentVector.EMPTY;
/* 3560 */       for (ISeq s = RT.seq(args); s != null; s = s.next()) {
/* 3561 */         argv = argv.cons(Compiler.analyze(Compiler.C.EXPRESSION, s.first()));
/*      */       }
/* 3563 */       return new StaticInvokeExpr(target, retClass, paramClasses, paramTypes, variadic, argv, tag);
/*      */     }
/*      */   }
/*      */   
/*      */   static class InvokeExpr implements Compiler.Expr
/*      */   {
/*      */     public final Compiler.Expr fexpr;
/*      */     public final Object tag;
/*      */     public final IPersistentVector args;
/*      */     public final int line;
/*      */     public final int column;
/*      */     public final String source;
/* 3575 */     public boolean isProtocol = false;
/* 3576 */     public boolean isDirect = false;
/* 3577 */     public int siteIndex = -1;
/*      */     public Class protocolOn;
/*      */     public java.lang.reflect.Method onMethod;
/* 3580 */     static Keyword onKey = Keyword.intern("on");
/* 3581 */     static Keyword methodMapKey = Keyword.intern("method-map");
/*      */     
/*      */     static Object sigTag(int argcount, Var v) {
/* 3584 */       Object arglists = RT.get(RT.meta(v), Compiler.arglistsKey);
/* 3585 */       Object sigTag = null;
/* 3586 */       for (ISeq s = RT.seq(arglists); s != null; s = s.next())
/*      */       {
/* 3588 */         APersistentVector sig = (APersistentVector)s.first();
/* 3589 */         int restOffset = sig.indexOf(Compiler._AMP_);
/* 3590 */         if ((argcount == sig.count()) || ((restOffset > -1) && (argcount >= restOffset)))
/* 3591 */           return Compiler.tagOf(sig);
/*      */       }
/* 3593 */       return null;
/*      */     }
/*      */     
/*      */     public InvokeExpr(String source, int line, int column, Symbol tag, Compiler.Expr fexpr, IPersistentVector args) {
/* 3597 */       this.source = source;
/* 3598 */       this.fexpr = fexpr;
/* 3599 */       this.args = args;
/* 3600 */       this.line = line;
/* 3601 */       this.column = column;
/* 3602 */       if ((fexpr instanceof Compiler.VarExpr))
/*      */       {
/* 3604 */         Var fvar = ((Compiler.VarExpr)fexpr).var;
/* 3605 */         Var pvar = (Var)RT.get(fvar.meta(), Compiler.protocolKey);
/* 3606 */         if ((pvar != null) && (Compiler.PROTOCOL_CALLSITES.isBound()))
/*      */         {
/* 3608 */           this.isProtocol = true;
/* 3609 */           this.siteIndex = Compiler.registerProtocolCallsite(((Compiler.VarExpr)fexpr).var);
/* 3610 */           Object pon = RT.get(pvar.get(), onKey);
/* 3611 */           this.protocolOn = Compiler.HostExpr.maybeClass(pon, false);
/* 3612 */           if (this.protocolOn != null)
/*      */           {
/* 3614 */             IPersistentMap mmap = (IPersistentMap)RT.get(pvar.get(), methodMapKey);
/* 3615 */             Keyword mmapVal = (Keyword)mmap.valAt(Keyword.intern(fvar.sym));
/* 3616 */             if (mmapVal == null) {
/* 3617 */               throw new IllegalArgumentException("No method of interface: " + this.protocolOn.getName() + " found for function: " + fvar.sym + " of protocol: " + pvar.sym + " (The protocol method may have been defined before and removed.)");
/*      */             }
/*      */             
/*      */ 
/*      */ 
/* 3622 */             String mname = Compiler.munge(mmapVal.sym.toString());
/* 3623 */             List methods = Reflector.getMethods(this.protocolOn, args.count() - 1, mname, false);
/* 3624 */             if (methods.size() != 1) {
/* 3625 */               throw new IllegalArgumentException("No single method: " + mname + " of interface: " + this.protocolOn.getName() + " found for function: " + fvar.sym + " of protocol: " + pvar.sym);
/*      */             }
/*      */             
/* 3628 */             this.onMethod = ((java.lang.reflect.Method)methods.get(0));
/*      */           }
/*      */         }
/*      */       }
/*      */       
/* 3633 */       if (tag != null) {
/* 3634 */         this.tag = tag;
/* 3635 */       } else if ((fexpr instanceof Compiler.VarExpr)) {
/* 3636 */         Var v = ((Compiler.VarExpr)fexpr).var;
/* 3637 */         Object arglists = RT.get(RT.meta(v), Compiler.arglistsKey);
/* 3638 */         Object sigTag = sigTag(args.count(), v);
/* 3639 */         this.tag = (sigTag == null ? ((Compiler.VarExpr)fexpr).tag : sigTag);
/*      */       } else {
/* 3641 */         this.tag = null;
/*      */       }
/*      */     }
/*      */     
/*      */     public Object eval()
/*      */     {
/*      */       try {
/* 3648 */         IFn fn = (IFn)this.fexpr.eval();
/* 3649 */         PersistentVector argvs = PersistentVector.EMPTY;
/* 3650 */         for (int i = 0; i < this.args.count(); i++)
/* 3651 */           argvs = argvs.cons(((Compiler.Expr)this.args.nth(i)).eval());
/* 3652 */         return fn.applyTo(RT.seq(Util.ret1(argvs, argvs = null)));
/*      */       }
/*      */       catch (Throwable e)
/*      */       {
/* 3656 */         if (!(e instanceof Compiler.CompilerException)) {
/* 3657 */           throw new Compiler.CompilerException(this.source, this.line, this.column, e);
/*      */         }
/* 3659 */         throw ((Compiler.CompilerException)e);
/*      */       }
/*      */     }
/*      */     
/*      */     public void emit(Compiler.C context, Compiler.ObjExpr objx, GeneratorAdapter gen) {
/* 3664 */       if (this.isProtocol)
/*      */       {
/* 3666 */         gen.visitLineNumber(this.line, gen.mark());
/* 3667 */         emitProto(context, objx, gen);
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/* 3672 */         this.fexpr.emit(Compiler.C.EXPRESSION, objx, gen);
/* 3673 */         gen.visitLineNumber(this.line, gen.mark());
/* 3674 */         gen.checkCast(Compiler.IFN_TYPE);
/* 3675 */         emitArgsAndCall(0, context, objx, gen);
/*      */       }
/* 3677 */       if (context == Compiler.C.STATEMENT)
/* 3678 */         gen.pop();
/*      */     }
/*      */     
/*      */     public void emitProto(Compiler.C context, Compiler.ObjExpr objx, GeneratorAdapter gen) {
/* 3682 */       Label onLabel = gen.newLabel();
/* 3683 */       Label callLabel = gen.newLabel();
/* 3684 */       Label endLabel = gen.newLabel();
/*      */       
/* 3686 */       Var v = ((Compiler.VarExpr)this.fexpr).var;
/*      */       
/* 3688 */       Compiler.Expr e = (Compiler.Expr)this.args.nth(0);
/* 3689 */       e.emit(Compiler.C.EXPRESSION, objx, gen);
/* 3690 */       gen.dup();
/* 3691 */       gen.invokeStatic(Compiler.UTIL_TYPE, clojure.asm.commons.Method.getMethod("Class classOf(Object)"));
/* 3692 */       gen.getStatic(objx.objtype, objx.cachedClassName(this.siteIndex), Compiler.CLASS_TYPE);
/* 3693 */       gen.visitJumpInsn(165, callLabel);
/* 3694 */       if (this.protocolOn != null)
/*      */       {
/* 3696 */         gen.dup();
/* 3697 */         gen.instanceOf(Type.getType(this.protocolOn));
/* 3698 */         gen.ifZCmp(154, onLabel);
/*      */       }
/*      */       
/* 3701 */       gen.dup();
/* 3702 */       gen.invokeStatic(Compiler.UTIL_TYPE, clojure.asm.commons.Method.getMethod("Class classOf(Object)"));
/* 3703 */       gen.putStatic(objx.objtype, objx.cachedClassName(this.siteIndex), Compiler.CLASS_TYPE);
/*      */       
/* 3705 */       gen.mark(callLabel);
/* 3706 */       objx.emitVar(gen, v);
/* 3707 */       gen.invokeVirtual(Compiler.VAR_TYPE, clojure.asm.commons.Method.getMethod("Object getRawRoot()"));
/* 3708 */       gen.swap();
/* 3709 */       emitArgsAndCall(1, context, objx, gen);
/* 3710 */       gen.goTo(endLabel);
/*      */       
/* 3712 */       gen.mark(onLabel);
/* 3713 */       if (this.protocolOn != null)
/*      */       {
/* 3715 */         Compiler.MethodExpr.emitTypedArgs(objx, gen, this.onMethod.getParameterTypes(), RT.subvec(this.args, 1, this.args.count()));
/* 3716 */         if (context == Compiler.C.RETURN)
/*      */         {
/* 3718 */           Compiler.ObjMethod method = (Compiler.ObjMethod)Compiler.METHOD.deref();
/* 3719 */           method.emitClearLocals(gen);
/*      */         }
/* 3721 */         clojure.asm.commons.Method m = new clojure.asm.commons.Method(this.onMethod.getName(), Type.getReturnType(this.onMethod), Type.getArgumentTypes(this.onMethod));
/* 3722 */         gen.invokeInterface(Type.getType(this.protocolOn), m);
/* 3723 */         Compiler.HostExpr.emitBoxReturn(objx, gen, this.onMethod.getReturnType());
/*      */       }
/* 3725 */       gen.mark(endLabel);
/*      */     }
/*      */     
/*      */     void emitArgsAndCall(int firstArgToEmit, Compiler.C context, Compiler.ObjExpr objx, GeneratorAdapter gen) {
/* 3729 */       for (int i = firstArgToEmit; i < Math.min(20, this.args.count()); i++)
/*      */       {
/* 3731 */         Compiler.Expr e = (Compiler.Expr)this.args.nth(i);
/* 3732 */         e.emit(Compiler.C.EXPRESSION, objx, gen);
/*      */       }
/* 3734 */       if (this.args.count() > 20)
/*      */       {
/* 3736 */         PersistentVector restArgs = PersistentVector.EMPTY;
/* 3737 */         for (int i = 20; i < this.args.count(); i++)
/*      */         {
/* 3739 */           restArgs = restArgs.cons(this.args.nth(i));
/*      */         }
/* 3741 */         Compiler.MethodExpr.emitArgsAsArray(restArgs, objx, gen);
/*      */       }
/* 3743 */       gen.visitLineNumber(this.line, gen.mark());
/*      */       
/* 3745 */       if (context == Compiler.C.RETURN)
/*      */       {
/* 3747 */         Compiler.ObjMethod method = (Compiler.ObjMethod)Compiler.METHOD.deref();
/* 3748 */         method.emitClearLocals(gen);
/*      */       }
/*      */       
/* 3751 */       gen.invokeInterface(Compiler.IFN_TYPE, new clojure.asm.commons.Method("invoke", Compiler.OBJECT_TYPE, Compiler.ARG_TYPES[Math.min(21, this.args.count())]));
/*      */     }
/*      */     
/*      */     public boolean hasJavaClass()
/*      */     {
/* 3756 */       return this.tag != null;
/*      */     }
/*      */     
/*      */     public Class getJavaClass() {
/* 3760 */       return Compiler.HostExpr.tagToClass(this.tag);
/*      */     }
/*      */     
/*      */     public static Compiler.Expr parse(Compiler.C context, ISeq form) {
/* 3764 */       if (context != Compiler.C.EVAL)
/* 3765 */         context = Compiler.C.EXPRESSION;
/* 3766 */       Compiler.Expr fexpr = Compiler.analyze(context, form.first());
/* 3767 */       if (((fexpr instanceof Compiler.VarExpr)) && (((Compiler.VarExpr)fexpr).var.equals(Compiler.INSTANCE)) && (RT.count(form) == 3))
/*      */       {
/* 3769 */         Compiler.Expr sexpr = Compiler.analyze(Compiler.C.EXPRESSION, RT.second(form));
/* 3770 */         if ((sexpr instanceof Compiler.ConstantExpr))
/*      */         {
/* 3772 */           Object val = ((Compiler.ConstantExpr)sexpr).val();
/* 3773 */           if ((val instanceof Class))
/*      */           {
/* 3775 */             return new Compiler.InstanceOfExpr((Class)val, Compiler.analyze(context, RT.third(form)));
/*      */           }
/*      */         }
/*      */       }
/*      */       
/* 3780 */       if ((RT.booleanCast(Compiler.getCompilerOption(Compiler.directLinkingKey))) && ((fexpr instanceof Compiler.VarExpr)) && (context != Compiler.C.EVAL))
/*      */       {
/*      */ 
/*      */ 
/* 3784 */         Var v = ((Compiler.VarExpr)fexpr).var;
/* 3785 */         if ((!v.isDynamic()) && (!RT.booleanCast(RT.get(v.meta(), Compiler.redefKey, Boolean.valueOf(false)))))
/*      */         {
/* 3787 */           Symbol formtag = Compiler.tagOf(form);
/* 3788 */           Object arglists = RT.get(RT.meta(v), Compiler.arglistsKey);
/* 3789 */           int arity = RT.count(form.next());
/* 3790 */           Object sigtag = sigTag(arity, v);
/* 3791 */           Object vtag = RT.get(RT.meta(v), RT.TAG_KEY);
/* 3792 */           Compiler.Expr ret = Compiler.StaticInvokeExpr.parse(v, RT.next(form), sigtag != null ? sigtag : formtag != null ? formtag : vtag);
/*      */           
/* 3794 */           if (ret != null)
/*      */           {
/*      */ 
/* 3797 */             return ret;
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 3803 */       if (((fexpr instanceof Compiler.VarExpr)) && (context != Compiler.C.EVAL))
/*      */       {
/* 3805 */         Var v = ((Compiler.VarExpr)fexpr).var;
/* 3806 */         Object arglists = RT.get(RT.meta(v), Compiler.arglistsKey);
/* 3807 */         int arity = RT.count(form.next());
/* 3808 */         for (ISeq s = RT.seq(arglists); s != null; s = s.next())
/*      */         {
/* 3810 */           IPersistentVector args = (IPersistentVector)s.first();
/* 3811 */           if (args.count() == arity)
/*      */           {
/* 3813 */             String primc = Compiler.FnMethod.primInterface(args);
/* 3814 */             if (primc == null) break;
/* 3815 */             return Compiler.analyze(context, ((IObj)RT.listStar(Symbol.intern(".invokePrim"), ((Symbol)form.first()).withMeta(RT.map(new Object[] { RT.TAG_KEY, Symbol.intern(primc) })), form.next())).withMeta((IPersistentMap)RT.conj(RT.meta(v), RT.meta(form))));
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3824 */       if (((fexpr instanceof Compiler.KeywordExpr)) && (RT.count(form) == 2) && (Compiler.KEYWORD_CALLSITES.isBound()))
/*      */       {
/*      */ 
/* 3827 */         Compiler.Expr target = Compiler.analyze(context, RT.second(form));
/* 3828 */         return new Compiler.KeywordInvokeExpr((String)Compiler.SOURCE.deref(), Compiler.lineDeref(), Compiler.columnDeref(), Compiler.tagOf(form), (Compiler.KeywordExpr)fexpr, target);
/*      */       }
/*      */       
/* 3831 */       PersistentVector args = PersistentVector.EMPTY;
/* 3832 */       for (ISeq s = RT.seq(form.next()); s != null; s = s.next())
/*      */       {
/* 3834 */         args = args.cons(Compiler.analyze(context, s.first()));
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 3840 */       return new InvokeExpr((String)Compiler.SOURCE.deref(), Compiler.lineDeref(), Compiler.columnDeref(), Compiler.tagOf(form), fexpr, args);
/*      */     }
/*      */   }
/*      */   
/*      */   static class SourceDebugExtensionAttribute extends Attribute {
/*      */     public SourceDebugExtensionAttribute() {
/* 3846 */       super();
/*      */     }
/*      */     
/*      */     void writeSMAP(ClassWriter cw, String smap) {
/* 3850 */       ByteVector bv = write(cw, null, -1, -1, -1);
/* 3851 */       bv.putUTF8(smap);
/*      */     }
/*      */   }
/*      */   
/*      */   public static class FnExpr extends Compiler.ObjExpr {
/* 3856 */     static final Type aFnType = Type.getType(AFunction.class);
/* 3857 */     static final Type restFnType = Type.getType(RestFn.class);
/*      */     
/* 3859 */     Compiler.FnMethod variadicMethod = null;
/*      */     IPersistentCollection methods;
/*      */     private boolean hasPrimSigs;
/*      */     private boolean hasMeta;
/*      */     private boolean hasEnclosingMethod;
/*      */     
/*      */     public FnExpr(Object tag)
/*      */     {
/* 3867 */       super();
/*      */     }
/*      */     
/*      */     public boolean hasJavaClass() {
/* 3871 */       return true;
/*      */     }
/*      */     
/*      */     boolean supportsMeta() {
/* 3875 */       return this.hasMeta;
/*      */     }
/*      */     
/*      */     public Class getJavaClass() {
/* 3879 */       return this.tag != null ? Compiler.HostExpr.tagToClass(this.tag) : AFunction.class;
/*      */     }
/*      */     
/*      */     protected void emitMethods(ClassVisitor cv)
/*      */     {
/* 3884 */       for (ISeq s = RT.seq(this.methods); s != null; s = s.next())
/*      */       {
/* 3886 */         Compiler.ObjMethod method = (Compiler.ObjMethod)s.first();
/* 3887 */         method.emit(this, cv);
/*      */       }
/*      */       
/* 3890 */       if (isVariadic())
/*      */       {
/* 3892 */         GeneratorAdapter gen = new GeneratorAdapter(1, clojure.asm.commons.Method.getMethod("int getRequiredArity()"), null, null, cv);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 3897 */         gen.visitCode();
/* 3898 */         gen.push(this.variadicMethod.reqParms.count());
/* 3899 */         gen.returnValue();
/* 3900 */         gen.endMethod();
/*      */       }
/*      */     }
/*      */     
/*      */     static Compiler.Expr parse(Compiler.C context, ISeq form, String name) {
/* 3905 */       ISeq origForm = form;
/* 3906 */       FnExpr fn = new FnExpr(Compiler.tagOf(form));
/* 3907 */       Keyword retkey = Keyword.intern(null, "rettag");
/* 3908 */       Object rettag = RT.get(RT.meta(form), retkey);
/* 3909 */       fn.src = form;
/* 3910 */       Compiler.ObjMethod enclosingMethod = (Compiler.ObjMethod)Compiler.METHOD.deref();
/* 3911 */       fn.hasEnclosingMethod = (enclosingMethod != null);
/* 3912 */       if (((IMeta)form.first()).meta() != null)
/*      */       {
/* 3914 */         fn.onceOnly = RT.booleanCast(RT.get(RT.meta(form.first()), Keyword.intern(null, "once")));
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 3919 */       String basename = (enclosingMethod != null ? enclosingMethod.objx.name : Compiler.munge(Compiler.currentNS().name.name)) + "$";
/*      */       
/*      */ 
/*      */ 
/* 3923 */       Symbol nm = null;
/*      */       
/* 3925 */       if ((RT.second(form) instanceof Symbol)) {
/* 3926 */         nm = (Symbol)RT.second(form);
/* 3927 */         name = nm.name + "__" + RT.nextID();
/*      */       }
/* 3929 */       else if (name == null) {
/* 3930 */         name = "fn__" + RT.nextID();
/* 3931 */       } else if (enclosingMethod != null) {
/* 3932 */         name = name + "__" + RT.nextID();
/*      */       }
/*      */       
/* 3935 */       String simpleName = Compiler.munge(name).replace(".", "_DOT_");
/*      */       
/* 3937 */       fn.name = (basename + simpleName);
/* 3938 */       fn.internalName = fn.name.replace('.', '/');
/* 3939 */       fn.objtype = Type.getObjectType(fn.internalName);
/* 3940 */       ArrayList<String> prims = new ArrayList();
/*      */       try
/*      */       {
/* 3943 */         Var.pushThreadBindings(RT.mapUniqueKeys(new Object[] { Compiler.CONSTANTS, PersistentVector.EMPTY, Compiler.CONSTANT_IDS, new IdentityHashMap(), Compiler.KEYWORDS, PersistentHashMap.EMPTY, Compiler.VARS, PersistentHashMap.EMPTY, Compiler.KEYWORD_CALLSITES, PersistentVector.EMPTY, Compiler.PROTOCOL_CALLSITES, PersistentVector.EMPTY, Compiler.VAR_CALLSITES, Compiler.emptyVarCallSites(), Compiler.NO_RECUR, null }));
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3955 */         if (nm != null)
/*      */         {
/* 3957 */           fn.thisName = nm.name;
/* 3958 */           form = RT.cons(Compiler.FN, RT.next(RT.next(form)));
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 3963 */         if ((RT.second(form) instanceof IPersistentVector))
/* 3964 */           form = RT.list(Compiler.FN, RT.next(form));
/* 3965 */         fn.line = Compiler.lineDeref();
/* 3966 */         fn.column = Compiler.columnDeref();
/* 3967 */         Compiler.FnMethod[] methodArray = new Compiler.FnMethod[21];
/* 3968 */         Compiler.FnMethod variadicMethod = null;
/* 3969 */         boolean usesThis = false;
/* 3970 */         for (ISeq s = RT.next(form); s != null; s = RT.next(s))
/*      */         {
/* 3972 */           Compiler.FnMethod f = Compiler.FnMethod.parse(fn, (ISeq)RT.first(s), rettag);
/* 3973 */           if (f.usesThis)
/*      */           {
/*      */ 
/* 3976 */             usesThis = true;
/*      */           }
/* 3978 */           if (f.isVariadic())
/*      */           {
/* 3980 */             if (variadicMethod == null) {
/* 3981 */               variadicMethod = f;
/*      */             } else {
/* 3983 */               throw Util.runtimeException("Can't have more than 1 variadic overload");
/*      */             }
/* 3985 */           } else if (methodArray[f.reqParms.count()] == null) {
/* 3986 */             methodArray[f.reqParms.count()] = f;
/*      */           } else
/* 3988 */             throw Util.runtimeException("Can't have 2 overloads with same arity");
/* 3989 */           if (f.prim != null)
/* 3990 */             prims.add(f.prim);
/*      */         }
/* 3992 */         if (variadicMethod != null)
/*      */         {
/* 3994 */           for (int i = variadicMethod.reqParms.count() + 1; i <= 20; i++) {
/* 3995 */             if (methodArray[i] != null) {
/* 3996 */               throw Util.runtimeException("Can't have fixed arity function with more params than variadic function");
/*      */             }
/*      */           }
/*      */         }
/* 4000 */         fn.canBeDirect = ((!fn.hasEnclosingMethod) && (fn.closes.count() == 0) && (!usesThis));
/*      */         
/* 4002 */         IPersistentCollection methods = null;
/* 4003 */         for (int i = 0; i < methodArray.length; i++)
/* 4004 */           if (methodArray[i] != null)
/* 4005 */             methods = RT.conj(methods, methodArray[i]);
/* 4006 */         if (variadicMethod != null) {
/* 4007 */           methods = RT.conj(methods, variadicMethod);
/*      */         }
/* 4009 */         if (fn.canBeDirect) {
/* 4010 */           for (Compiler.FnMethod fm : (Collection)methods)
/*      */           {
/* 4012 */             if (fm.locals != null)
/*      */             {
/* 4014 */               for (Compiler.LocalBinding lb : (Collection)RT.keys(fm.locals))
/*      */               {
/* 4016 */                 if (lb.isArg) {
/* 4017 */                   lb.idx -= 1;
/*      */                 }
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/* 4023 */         fn.methods = methods;
/* 4024 */         fn.variadicMethod = variadicMethod;
/* 4025 */         fn.keywords = ((IPersistentMap)Compiler.KEYWORDS.deref());
/* 4026 */         fn.vars = ((IPersistentMap)Compiler.VARS.deref());
/* 4027 */         fn.constants = ((PersistentVector)Compiler.CONSTANTS.deref());
/* 4028 */         fn.keywordCallsites = ((IPersistentVector)Compiler.KEYWORD_CALLSITES.deref());
/* 4029 */         fn.protocolCallsites = ((IPersistentVector)Compiler.PROTOCOL_CALLSITES.deref());
/* 4030 */         fn.varCallsites = ((IPersistentSet)Compiler.VAR_CALLSITES.deref());
/*      */         
/* 4032 */         fn.constantsID = RT.nextID();
/*      */ 
/*      */       }
/*      */       finally
/*      */       {
/*      */ 
/* 4038 */         Var.popThreadBindings();
/*      */       }
/* 4040 */       fn.hasPrimSigs = (prims.size() > 0);
/* 4041 */       IPersistentMap fmeta = RT.meta(origForm);
/* 4042 */       if (fmeta != null) {
/* 4043 */         fmeta = fmeta.without(RT.LINE_KEY).without(RT.COLUMN_KEY).without(RT.FILE_KEY).without(retkey);
/*      */       }
/* 4045 */       fn.hasMeta = (RT.count(fmeta) > 0);
/*      */       
/*      */       try
/*      */       {
/* 4049 */         fn.compile(fn.isVariadic() ? "clojure/lang/RestFn" : "clojure/lang/AFunction", prims.size() == 0 ? null : (String[])prims.toArray(new String[prims.size()]), fn.onceOnly);
/*      */ 
/*      */ 
/*      */       }
/*      */       catch (IOException e)
/*      */       {
/*      */ 
/*      */ 
/* 4057 */         throw Util.sneakyThrow(e);
/*      */       }
/* 4059 */       fn.getCompiledClass();
/*      */       
/* 4061 */       if (fn.supportsMeta())
/*      */       {
/*      */ 
/* 4064 */         return new Compiler.MetaExpr(fn, Compiler.MapExpr.parse(context == Compiler.C.EVAL ? context : Compiler.C.EXPRESSION, fmeta));
/*      */       }
/*      */       
/*      */ 
/* 4068 */       return fn;
/*      */     }
/*      */     
/*      */     public final Compiler.ObjMethod variadicMethod() {
/* 4072 */       return this.variadicMethod;
/*      */     }
/*      */     
/*      */     boolean isVariadic() {
/* 4076 */       return this.variadicMethod != null;
/*      */     }
/*      */     
/*      */     public final IPersistentCollection methods() {
/* 4080 */       return this.methods;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void emitForDefn(Compiler.ObjExpr objx, GeneratorAdapter gen)
/*      */     {
/* 4096 */       emit(Compiler.C.EXPRESSION, objx, gen);
/*      */     }
/*      */   }
/*      */   
/*      */   public static class ObjExpr
/*      */     implements Compiler.Expr
/*      */   {
/*      */     static final String CONST_PREFIX = "const__";
/*      */     String name;
/*      */     String internalName;
/*      */     String thisName;
/*      */     Type objtype;
/*      */     public final Object tag;
/* 4109 */     IPersistentMap closes = PersistentHashMap.EMPTY;
/*      */     
/* 4111 */     IPersistentVector closesExprs = PersistentVector.EMPTY;
/*      */     
/* 4113 */     IPersistentSet volatiles = PersistentHashSet.EMPTY;
/*      */     
/*      */ 
/* 4116 */     IPersistentMap fields = null;
/*      */     
/*      */ 
/* 4119 */     IPersistentVector hintedFields = PersistentVector.EMPTY;
/*      */     
/*      */ 
/* 4122 */     IPersistentMap keywords = PersistentHashMap.EMPTY;
/* 4123 */     IPersistentMap vars = PersistentHashMap.EMPTY;
/*      */     Class compiledClass;
/*      */     int line;
/*      */     int column;
/*      */     PersistentVector constants;
/* 4128 */     IPersistentSet usedConstants = PersistentHashSet.EMPTY;
/*      */     
/*      */     int constantsID;
/* 4131 */     int altCtorDrops = 0;
/*      */     
/*      */     IPersistentVector keywordCallsites;
/*      */     IPersistentVector protocolCallsites;
/*      */     IPersistentSet varCallsites;
/* 4136 */     boolean onceOnly = false;
/*      */     
/*      */     Object src;
/*      */     
/* 4140 */     IPersistentMap opts = PersistentHashMap.EMPTY;
/*      */     
/* 4142 */     static final clojure.asm.commons.Method voidctor = clojure.asm.commons.Method.getMethod("void <init>()");
/*      */     protected IPersistentMap classMeta;
/*      */     protected boolean canBeDirect;
/*      */     
/*      */     public final String name() {
/* 4147 */       return this.name;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public final String internalName()
/*      */     {
/* 4155 */       return this.internalName;
/*      */     }
/*      */     
/*      */     public final String thisName() {
/* 4159 */       return this.thisName;
/*      */     }
/*      */     
/*      */     public final Type objtype() {
/* 4163 */       return this.objtype;
/*      */     }
/*      */     
/*      */     public final IPersistentMap closes() {
/* 4167 */       return this.closes;
/*      */     }
/*      */     
/*      */     public final IPersistentMap keywords() {
/* 4171 */       return this.keywords;
/*      */     }
/*      */     
/*      */     public final IPersistentMap vars() {
/* 4175 */       return this.vars;
/*      */     }
/*      */     
/*      */     public final Class compiledClass() {
/* 4179 */       return this.compiledClass;
/*      */     }
/*      */     
/*      */     public final int line() {
/* 4183 */       return this.line;
/*      */     }
/*      */     
/*      */     public final int column() {
/* 4187 */       return this.column;
/*      */     }
/*      */     
/*      */     public final PersistentVector constants() {
/* 4191 */       return this.constants;
/*      */     }
/*      */     
/*      */     public final int constantsID() {
/* 4195 */       return this.constantsID;
/*      */     }
/*      */     
/* 4198 */     static final clojure.asm.commons.Method kwintern = clojure.asm.commons.Method.getMethod("clojure.lang.Keyword intern(String, String)");
/* 4199 */     static final clojure.asm.commons.Method symintern = clojure.asm.commons.Method.getMethod("clojure.lang.Symbol intern(String)");
/* 4200 */     static final clojure.asm.commons.Method varintern = clojure.asm.commons.Method.getMethod("clojure.lang.Var intern(clojure.lang.Symbol, clojure.lang.Symbol)");
/*      */     
/*      */ 
/* 4203 */     static final Type DYNAMIC_CLASSLOADER_TYPE = Type.getType(DynamicClassLoader.class);
/* 4204 */     static final clojure.asm.commons.Method getClassMethod = clojure.asm.commons.Method.getMethod("Class getClass()");
/* 4205 */     static final clojure.asm.commons.Method getClassLoaderMethod = clojure.asm.commons.Method.getMethod("ClassLoader getClassLoader()");
/* 4206 */     static final clojure.asm.commons.Method getConstantsMethod = clojure.asm.commons.Method.getMethod("Object[] getConstants(int)");
/* 4207 */     static final clojure.asm.commons.Method readStringMethod = clojure.asm.commons.Method.getMethod("Object readString(String)");
/*      */     
/* 4209 */     static final Type ILOOKUP_SITE_TYPE = Type.getType(ILookupSite.class);
/* 4210 */     static final Type ILOOKUP_THUNK_TYPE = Type.getType(ILookupThunk.class);
/* 4211 */     static final Type KEYWORD_LOOKUPSITE_TYPE = Type.getType(KeywordLookupSite.class);
/*      */     private DynamicClassLoader loader;
/*      */     private byte[] bytecode;
/*      */     
/*      */     public ObjExpr(Object tag)
/*      */     {
/* 4217 */       this.tag = tag;
/*      */     }
/*      */     
/*      */     static String trimGenID(String name) {
/* 4221 */       int i = name.lastIndexOf("__");
/* 4222 */       return i == -1 ? name : name.substring(0, i);
/*      */     }
/*      */     
/*      */ 
/*      */     Type[] ctorTypes()
/*      */     {
/* 4228 */       IPersistentVector tv = !supportsMeta() ? PersistentVector.EMPTY : RT.vector(new Object[] { Compiler.IPERSISTENTMAP_TYPE });
/* 4229 */       for (ISeq s = RT.keys(this.closes); s != null; s = s.next())
/*      */       {
/* 4231 */         Compiler.LocalBinding lb = (Compiler.LocalBinding)s.first();
/* 4232 */         if (lb.getPrimitiveType() != null) {
/* 4233 */           tv = tv.cons(Type.getType(lb.getPrimitiveType()));
/*      */         } else
/* 4235 */           tv = tv.cons(Compiler.OBJECT_TYPE);
/*      */       }
/* 4237 */       Type[] ret = new Type[tv.count()];
/* 4238 */       for (int i = 0; i < tv.count(); i++)
/* 4239 */         ret[i] = ((Type)tv.nth(i));
/* 4240 */       return ret;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     void compile(String superName, String[] interfaceNames, boolean oneTimeUse)
/*      */       throws IOException
/*      */     {
/* 4248 */       ClassWriter cw = new ClassWriter(1);
/*      */       
/* 4250 */       ClassVisitor cv = cw;
/*      */       
/*      */ 
/* 4253 */       cv.visit(49, 49, this.internalName, null, superName, interfaceNames);
/*      */       
/*      */ 
/* 4256 */       String source = (String)Compiler.SOURCE.deref();
/* 4257 */       int lineBefore = ((Integer)Compiler.LINE_BEFORE.deref()).intValue();
/* 4258 */       int lineAfter = ((Integer)Compiler.LINE_AFTER.deref()).intValue() + 1;
/* 4259 */       int columnBefore = ((Integer)Compiler.COLUMN_BEFORE.deref()).intValue();
/* 4260 */       int columnAfter = ((Integer)Compiler.COLUMN_AFTER.deref()).intValue() + 1;
/*      */       
/* 4262 */       if ((source != null) && (Compiler.SOURCE_PATH.deref() != null))
/*      */       {
/*      */ 
/* 4265 */         String smap = "SMAP\n" + (source.lastIndexOf('.') > 0 ? source.substring(0, source.lastIndexOf('.')) : source) + ".java\n" + "Clojure\n" + "*S Clojure\n" + "*F\n" + "+ 1 " + source + "\n" + (String)Compiler.SOURCE_PATH.deref() + "\n" + "*L\n" + String.format("%d#1,%d:%d\n", new Object[] { Integer.valueOf(lineBefore), Integer.valueOf(lineAfter - lineBefore), Integer.valueOf(lineBefore) }) + "*E";
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4279 */         cv.visitSource(source, smap);
/*      */       }
/* 4281 */       Compiler.addAnnotation(cv, this.classMeta);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4291 */       if (supportsMeta())
/*      */       {
/* 4293 */         cv.visitField(16, "__meta", Compiler.IPERSISTENTMAP_TYPE.getDescriptor(), null, null);
/*      */       }
/*      */       
/* 4296 */       for (ISeq s = RT.keys(this.closes); s != null; s = s.next())
/*      */       {
/* 4298 */         Compiler.LocalBinding lb = (Compiler.LocalBinding)s.first();
/* 4299 */         if (isDeftype())
/*      */         {
/* 4301 */           int access = isMutable(lb) ? 0 : isVolatile(lb) ? 64 : 17;
/*      */           
/*      */           FieldVisitor fv;
/*      */           FieldVisitor fv;
/* 4305 */           if (lb.getPrimitiveType() != null) {
/* 4306 */             fv = cv.visitField(access, lb.name, Type.getType(lb.getPrimitiveType()).getDescriptor(), null, null);
/*      */ 
/*      */           }
/*      */           else
/*      */           {
/* 4311 */             fv = cv.visitField(access, lb.name, Compiler.OBJECT_TYPE.getDescriptor(), null, null);
/*      */           }
/* 4313 */           Compiler.addAnnotation(fv, RT.meta(lb.sym));
/*      */ 
/*      */ 
/*      */ 
/*      */         }
/* 4318 */         else if (lb.getPrimitiveType() != null) {
/* 4319 */           cv.visitField(0 + (isVolatile(lb) ? 64 : 0), lb.name, Type.getType(lb.getPrimitiveType()).getDescriptor(), null, null);
/*      */         }
/*      */         else
/*      */         {
/* 4323 */           cv.visitField(0, lb.name, Compiler.OBJECT_TYPE.getDescriptor(), null, null);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 4329 */       for (int i = 0; i < this.protocolCallsites.count(); i++)
/*      */       {
/* 4331 */         cv.visitField(10, cachedClassName(i), Compiler.CLASS_TYPE.getDescriptor(), null, null);
/*      */       }
/*      */       
/*      */ 
/* 4335 */       clojure.asm.commons.Method m = new clojure.asm.commons.Method("<init>", Type.VOID_TYPE, ctorTypes());
/* 4336 */       GeneratorAdapter ctorgen = new GeneratorAdapter(1, m, null, null, cv);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 4341 */       Label start = ctorgen.newLabel();
/* 4342 */       Label end = ctorgen.newLabel();
/* 4343 */       ctorgen.visitCode();
/* 4344 */       ctorgen.visitLineNumber(this.line, ctorgen.mark());
/* 4345 */       ctorgen.visitLabel(start);
/* 4346 */       ctorgen.loadThis();
/*      */       
/* 4348 */       ctorgen.invokeConstructor(Type.getObjectType(superName), voidctor);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4366 */       if (supportsMeta())
/*      */       {
/* 4368 */         ctorgen.loadThis();
/* 4369 */         ctorgen.visitVarInsn(Compiler.IPERSISTENTMAP_TYPE.getOpcode(21), 1);
/* 4370 */         ctorgen.putField(this.objtype, "__meta", Compiler.IPERSISTENTMAP_TYPE);
/*      */       }
/*      */       
/* 4373 */       int a = supportsMeta() ? 2 : 1;
/* 4374 */       for (ISeq s = RT.keys(this.closes); s != null; a++)
/*      */       {
/* 4376 */         Compiler.LocalBinding lb = (Compiler.LocalBinding)s.first();
/* 4377 */         ctorgen.loadThis();
/* 4378 */         Class primc = lb.getPrimitiveType();
/* 4379 */         if (primc != null)
/*      */         {
/* 4381 */           ctorgen.visitVarInsn(Type.getType(primc).getOpcode(21), a);
/* 4382 */           ctorgen.putField(this.objtype, lb.name, Type.getType(primc));
/* 4383 */           if ((primc == Long.TYPE) || (primc == Double.TYPE)) {
/* 4384 */             a++;
/*      */           }
/*      */         }
/*      */         else {
/* 4388 */           ctorgen.visitVarInsn(Compiler.OBJECT_TYPE.getOpcode(21), a);
/* 4389 */           ctorgen.putField(this.objtype, lb.name, Compiler.OBJECT_TYPE);
/*      */         }
/* 4391 */         this.closesExprs = this.closesExprs.cons(new Compiler.LocalBindingExpr(lb, null));s = s.next();
/*      */       }
/*      */       
/*      */ 
/* 4395 */       ctorgen.visitLabel(end);
/*      */       
/* 4397 */       ctorgen.returnValue();
/*      */       
/* 4399 */       ctorgen.endMethod();
/*      */       
/* 4401 */       if (this.altCtorDrops > 0)
/*      */       {
/*      */ 
/* 4404 */         Type[] ctorTypes = ctorTypes();
/* 4405 */         Type[] altCtorTypes = new Type[ctorTypes.length - this.altCtorDrops];
/* 4406 */         for (int i = 0; i < altCtorTypes.length; i++)
/* 4407 */           altCtorTypes[i] = ctorTypes[i];
/* 4408 */         clojure.asm.commons.Method alt = new clojure.asm.commons.Method("<init>", Type.VOID_TYPE, altCtorTypes);
/* 4409 */         ctorgen = new GeneratorAdapter(1, alt, null, null, cv);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 4414 */         ctorgen.visitCode();
/* 4415 */         ctorgen.loadThis();
/* 4416 */         ctorgen.loadArgs();
/* 4417 */         for (int i = 0; i < this.altCtorDrops; i++) {
/* 4418 */           ctorgen.visitInsn(1);
/*      */         }
/* 4420 */         ctorgen.invokeConstructor(this.objtype, new clojure.asm.commons.Method("<init>", Type.VOID_TYPE, ctorTypes));
/*      */         
/* 4422 */         ctorgen.returnValue();
/* 4423 */         ctorgen.endMethod();
/*      */       }
/*      */       
/* 4426 */       if (supportsMeta())
/*      */       {
/*      */ 
/* 4429 */         Type[] ctorTypes = ctorTypes();
/* 4430 */         Type[] noMetaCtorTypes = new Type[ctorTypes.length - 1];
/* 4431 */         for (int i = 1; i < ctorTypes.length; i++)
/* 4432 */           noMetaCtorTypes[(i - 1)] = ctorTypes[i];
/* 4433 */         clojure.asm.commons.Method alt = new clojure.asm.commons.Method("<init>", Type.VOID_TYPE, noMetaCtorTypes);
/* 4434 */         ctorgen = new GeneratorAdapter(1, alt, null, null, cv);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 4439 */         ctorgen.visitCode();
/* 4440 */         ctorgen.loadThis();
/* 4441 */         ctorgen.visitInsn(1);
/* 4442 */         ctorgen.loadArgs();
/* 4443 */         ctorgen.invokeConstructor(this.objtype, new clojure.asm.commons.Method("<init>", Type.VOID_TYPE, ctorTypes));
/*      */         
/* 4445 */         ctorgen.returnValue();
/* 4446 */         ctorgen.endMethod();
/*      */         
/*      */ 
/* 4449 */         clojure.asm.commons.Method meth = clojure.asm.commons.Method.getMethod("clojure.lang.IPersistentMap meta()");
/*      */         
/* 4451 */         GeneratorAdapter gen = new GeneratorAdapter(1, meth, null, null, cv);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 4456 */         gen.visitCode();
/* 4457 */         gen.loadThis();
/* 4458 */         gen.getField(this.objtype, "__meta", Compiler.IPERSISTENTMAP_TYPE);
/*      */         
/* 4460 */         gen.returnValue();
/* 4461 */         gen.endMethod();
/*      */         
/*      */ 
/* 4464 */         meth = clojure.asm.commons.Method.getMethod("clojure.lang.IObj withMeta(clojure.lang.IPersistentMap)");
/*      */         
/* 4466 */         gen = new GeneratorAdapter(1, meth, null, null, cv);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 4471 */         gen.visitCode();
/* 4472 */         gen.newInstance(this.objtype);
/* 4473 */         gen.dup();
/* 4474 */         gen.loadArg(0);
/*      */         
/* 4476 */         for (ISeq s = RT.keys(this.closes); s != null; a++)
/*      */         {
/* 4478 */           Compiler.LocalBinding lb = (Compiler.LocalBinding)s.first();
/* 4479 */           gen.loadThis();
/* 4480 */           Class primc = lb.getPrimitiveType();
/* 4481 */           if (primc != null)
/*      */           {
/* 4483 */             gen.getField(this.objtype, lb.name, Type.getType(primc));
/*      */           }
/*      */           else
/*      */           {
/* 4487 */             gen.getField(this.objtype, lb.name, Compiler.OBJECT_TYPE);
/*      */           }
/* 4476 */           s = s.next();
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4491 */         gen.invokeConstructor(this.objtype, new clojure.asm.commons.Method("<init>", Type.VOID_TYPE, ctorTypes));
/* 4492 */         gen.returnValue();
/* 4493 */         gen.endMethod();
/*      */       }
/*      */       
/* 4496 */       emitStatics(cv);
/* 4497 */       emitMethods(cv);
/*      */       
/*      */ 
/* 4500 */       for (int i = 0; i < this.constants.count(); i++)
/*      */       {
/* 4502 */         if (this.usedConstants.contains(Integer.valueOf(i))) {
/* 4503 */           cv.visitField(25, constantName(i), constantType(i).getDescriptor(), null, null);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 4509 */       for (int i = 0; i < this.keywordCallsites.count(); i++)
/*      */       {
/* 4511 */         cv.visitField(24, siteNameStatic(i), KEYWORD_LOOKUPSITE_TYPE.getDescriptor(), null, null);
/*      */         
/*      */ 
/* 4514 */         cv.visitField(8, thunkNameStatic(i), ILOOKUP_THUNK_TYPE.getDescriptor(), null, null);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 4519 */       GeneratorAdapter clinitgen = new GeneratorAdapter(9, clojure.asm.commons.Method.getMethod("void <clinit> ()"), null, null, cv);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 4524 */       clinitgen.visitCode();
/* 4525 */       clinitgen.visitLineNumber(this.line, clinitgen.mark());
/*      */       
/* 4527 */       if (this.constants.count() > 0)
/*      */       {
/* 4529 */         emitConstants(clinitgen);
/*      */       }
/*      */       
/* 4532 */       if (this.keywordCallsites.count() > 0) {
/* 4533 */         emitKeywordCallsites(clinitgen);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4563 */       if ((isDeftype()) && (RT.booleanCast(RT.get(this.opts, Compiler.loadNs)))) {
/* 4564 */         String nsname = ((Symbol)RT.second(this.src)).getNamespace();
/* 4565 */         if (!nsname.equals("clojure.core")) {
/* 4566 */           clinitgen.push("clojure.core");
/* 4567 */           clinitgen.push("require");
/* 4568 */           clinitgen.invokeStatic(Compiler.RT_TYPE, clojure.asm.commons.Method.getMethod("clojure.lang.Var var(String,String)"));
/* 4569 */           clinitgen.invokeVirtual(Compiler.VAR_TYPE, clojure.asm.commons.Method.getMethod("Object getRawRoot()"));
/* 4570 */           clinitgen.checkCast(Compiler.IFN_TYPE);
/* 4571 */           clinitgen.push(nsname);
/* 4572 */           clinitgen.invokeStatic(Compiler.SYMBOL_TYPE, clojure.asm.commons.Method.getMethod("clojure.lang.Symbol create(String)"));
/* 4573 */           clinitgen.invokeInterface(Compiler.IFN_TYPE, clojure.asm.commons.Method.getMethod("Object invoke(Object)"));
/* 4574 */           clinitgen.pop();
/*      */         }
/*      */       }
/*      */       
/* 4578 */       clinitgen.returnValue();
/*      */       
/* 4580 */       clinitgen.endMethod();
/*      */       
/*      */ 
/* 4583 */       cv.visitEnd();
/*      */       
/* 4585 */       this.bytecode = cw.toByteArray();
/* 4586 */       if (RT.booleanCast(Compiler.COMPILE_FILES.deref())) {
/* 4587 */         Compiler.writeClassFile(this.internalName, this.bytecode);
/*      */       }
/*      */     }
/*      */     
/*      */     private void emitKeywordCallsites(GeneratorAdapter clinitgen)
/*      */     {
/* 4593 */       for (int i = 0; i < this.keywordCallsites.count(); i++)
/*      */       {
/* 4595 */         Keyword k = (Keyword)this.keywordCallsites.nth(i);
/* 4596 */         clinitgen.newInstance(KEYWORD_LOOKUPSITE_TYPE);
/* 4597 */         clinitgen.dup();
/* 4598 */         emitValue(k, clinitgen);
/* 4599 */         clinitgen.invokeConstructor(KEYWORD_LOOKUPSITE_TYPE, clojure.asm.commons.Method.getMethod("void <init>(clojure.lang.Keyword)"));
/*      */         
/* 4601 */         clinitgen.dup();
/* 4602 */         clinitgen.putStatic(this.objtype, siteNameStatic(i), KEYWORD_LOOKUPSITE_TYPE);
/* 4603 */         clinitgen.putStatic(this.objtype, thunkNameStatic(i), ILOOKUP_THUNK_TYPE);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */     protected void emitStatics(ClassVisitor gen) {}
/*      */     
/*      */     protected void emitMethods(ClassVisitor gen) {}
/*      */     
/*      */     void emitListAsObjectArray(Object value, GeneratorAdapter gen)
/*      */     {
/* 4614 */       gen.push(((List)value).size());
/* 4615 */       gen.newArray(Compiler.OBJECT_TYPE);
/* 4616 */       int i = 0;
/* 4617 */       for (Iterator it = ((List)value).iterator(); it.hasNext(); i++)
/*      */       {
/* 4619 */         gen.dup();
/* 4620 */         gen.push(i);
/* 4621 */         emitValue(it.next(), gen);
/* 4622 */         gen.arrayStore(Compiler.OBJECT_TYPE);
/*      */       }
/*      */     }
/*      */     
/*      */     void emitValue(Object value, GeneratorAdapter gen) {
/* 4627 */       boolean partial = true;
/*      */       
/*      */ 
/* 4630 */       if (value == null) {
/* 4631 */         gen.visitInsn(1);
/* 4632 */       } else if ((value instanceof String))
/*      */       {
/* 4634 */         gen.push((String)value);
/*      */       }
/* 4636 */       else if ((value instanceof Boolean))
/*      */       {
/* 4638 */         if (((Boolean)value).booleanValue()) {
/* 4639 */           gen.getStatic(Compiler.BOOLEAN_OBJECT_TYPE, "TRUE", Compiler.BOOLEAN_OBJECT_TYPE);
/*      */         } else {
/* 4641 */           gen.getStatic(Compiler.BOOLEAN_OBJECT_TYPE, "FALSE", Compiler.BOOLEAN_OBJECT_TYPE);
/*      */         }
/* 4643 */       } else if ((value instanceof Integer))
/*      */       {
/* 4645 */         gen.push(((Integer)value).intValue());
/* 4646 */         gen.invokeStatic(Type.getType(Integer.class), clojure.asm.commons.Method.getMethod("Integer valueOf(int)"));
/*      */       }
/* 4648 */       else if ((value instanceof Long))
/*      */       {
/* 4650 */         gen.push(((Long)value).longValue());
/* 4651 */         gen.invokeStatic(Type.getType(Long.class), clojure.asm.commons.Method.getMethod("Long valueOf(long)"));
/*      */       }
/* 4653 */       else if ((value instanceof Double))
/*      */       {
/* 4655 */         gen.push(((Double)value).doubleValue());
/* 4656 */         gen.invokeStatic(Type.getType(Double.class), clojure.asm.commons.Method.getMethod("Double valueOf(double)"));
/*      */       }
/* 4658 */       else if ((value instanceof Character))
/*      */       {
/* 4660 */         gen.push(((Character)value).charValue());
/* 4661 */         gen.invokeStatic(Type.getType(Character.class), clojure.asm.commons.Method.getMethod("Character valueOf(char)"));
/*      */       }
/* 4663 */       else if ((value instanceof Class))
/*      */       {
/* 4665 */         Class cc = (Class)value;
/* 4666 */         if (cc.isPrimitive())
/*      */         {
/*      */           Type bt;
/* 4669 */           if (cc == Boolean.TYPE) { bt = Type.getType(Boolean.class); } else { Type bt;
/* 4670 */             if (cc == Byte.TYPE) { bt = Type.getType(Byte.class); } else { Type bt;
/* 4671 */               if (cc == Character.TYPE) { bt = Type.getType(Character.class); } else { Type bt;
/* 4672 */                 if (cc == Double.TYPE) { bt = Type.getType(Double.class); } else { Type bt;
/* 4673 */                   if (cc == Float.TYPE) { bt = Type.getType(Float.class); } else { Type bt;
/* 4674 */                     if (cc == Integer.TYPE) { bt = Type.getType(Integer.class); } else { Type bt;
/* 4675 */                       if (cc == Long.TYPE) { bt = Type.getType(Long.class); } else { Type bt;
/* 4676 */                         if (cc == Short.TYPE) bt = Type.getType(Short.class); else
/* 4677 */                           throw Util.runtimeException("Can't embed unknown primitive in code: " + value); } } } } } } }
/*      */           Type bt;
/* 4679 */           gen.getStatic(bt, "TYPE", Type.getType(Class.class));
/*      */         }
/*      */         else
/*      */         {
/* 4683 */           gen.push(Compiler.destubClassName(cc.getName()));
/* 4684 */           gen.invokeStatic(Compiler.RT_TYPE, clojure.asm.commons.Method.getMethod("Class classForName(String)"));
/*      */         }
/*      */       }
/* 4687 */       else if ((value instanceof Symbol))
/*      */       {
/* 4689 */         gen.push(((Symbol)value).ns);
/* 4690 */         gen.push(((Symbol)value).name);
/* 4691 */         gen.invokeStatic(Type.getType(Symbol.class), clojure.asm.commons.Method.getMethod("clojure.lang.Symbol intern(String,String)"));
/*      */ 
/*      */       }
/* 4694 */       else if ((value instanceof Keyword))
/*      */       {
/* 4696 */         gen.push(((Keyword)value).sym.ns);
/* 4697 */         gen.push(((Keyword)value).sym.name);
/* 4698 */         gen.invokeStatic(Compiler.RT_TYPE, clojure.asm.commons.Method.getMethod("clojure.lang.Keyword keyword(String,String)"));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/* 4707 */       else if ((value instanceof Var))
/*      */       {
/* 4709 */         Var var = (Var)value;
/* 4710 */         gen.push(var.ns.name.toString());
/* 4711 */         gen.push(var.sym.toString());
/* 4712 */         gen.invokeStatic(Compiler.RT_TYPE, clojure.asm.commons.Method.getMethod("clojure.lang.Var var(String,String)"));
/*      */       }
/* 4714 */       else if ((value instanceof IType))
/*      */       {
/* 4716 */         clojure.asm.commons.Method ctor = new clojure.asm.commons.Method("<init>", Type.getConstructorDescriptor(value.getClass().getConstructors()[0]));
/* 4717 */         gen.newInstance(Type.getType(value.getClass()));
/* 4718 */         gen.dup();
/* 4719 */         IPersistentVector fields = (IPersistentVector)Reflector.invokeStaticMethod(value.getClass(), "getBasis", new Object[0]);
/* 4720 */         for (ISeq s = RT.seq(fields); s != null; s = s.next())
/*      */         {
/* 4722 */           Symbol field = (Symbol)s.first();
/* 4723 */           Class k = Compiler.tagClass(Compiler.tagOf(field));
/* 4724 */           Object val = Reflector.getInstanceField(value, Compiler.munge(field.name));
/* 4725 */           emitValue(val, gen);
/*      */           
/* 4727 */           if (k.isPrimitive())
/*      */           {
/* 4729 */             Type b = Type.getType(Compiler.boxClass(k));
/* 4730 */             String p = Type.getType(k).getDescriptor();
/* 4731 */             String n = k.getName();
/*      */             
/* 4733 */             gen.invokeVirtual(b, new clojure.asm.commons.Method(n + "Value", "()" + p));
/*      */           }
/*      */         }
/* 4736 */         gen.invokeConstructor(Type.getType(value.getClass()), ctor);
/*      */       }
/* 4738 */       else if ((value instanceof IRecord))
/*      */       {
/* 4740 */         clojure.asm.commons.Method createMethod = clojure.asm.commons.Method.getMethod(value.getClass().getName() + " create(clojure.lang.IPersistentMap)");
/* 4741 */         emitValue(PersistentArrayMap.create((Map)value), gen);
/* 4742 */         gen.invokeStatic(Compiler.getType(value.getClass()), createMethod);
/*      */       }
/* 4744 */       else if ((value instanceof IPersistentMap))
/*      */       {
/* 4746 */         List entries = new ArrayList();
/* 4747 */         for (Map.Entry entry : ((Map)value).entrySet())
/*      */         {
/* 4749 */           entries.add(entry.getKey());
/* 4750 */           entries.add(entry.getValue());
/*      */         }
/* 4752 */         emitListAsObjectArray(entries, gen);
/* 4753 */         gen.invokeStatic(Compiler.RT_TYPE, clojure.asm.commons.Method.getMethod("clojure.lang.IPersistentMap map(Object[])"));
/*      */ 
/*      */       }
/* 4756 */       else if ((value instanceof IPersistentVector))
/*      */       {
/* 4758 */         IPersistentVector args = (IPersistentVector)value;
/* 4759 */         if (args.count() <= 6)
/*      */         {
/* 4761 */           for (int i = 0; i < args.count(); i++) {
/* 4762 */             emitValue(args.nth(i), gen);
/*      */           }
/* 4764 */           gen.invokeStatic(Compiler.TUPLE_TYPE, Compiler.createTupleMethods[args.count()]);
/*      */         }
/*      */         else
/*      */         {
/* 4768 */           emitListAsObjectArray(value, gen);
/* 4769 */           gen.invokeStatic(Compiler.RT_TYPE, clojure.asm.commons.Method.getMethod("clojure.lang.IPersistentVector vector(Object[])"));
/*      */         }
/*      */         
/*      */       }
/* 4773 */       else if ((value instanceof PersistentHashSet))
/*      */       {
/* 4775 */         ISeq vs = RT.seq(value);
/* 4776 */         if (vs == null) {
/* 4777 */           gen.getStatic(Type.getType(PersistentHashSet.class), "EMPTY", Type.getType(PersistentHashSet.class));
/*      */         }
/*      */         else {
/* 4780 */           emitListAsObjectArray(vs, gen);
/* 4781 */           gen.invokeStatic(Type.getType(PersistentHashSet.class), clojure.asm.commons.Method.getMethod("clojure.lang.PersistentHashSet create(Object[])"));
/*      */         }
/*      */         
/*      */       }
/* 4785 */       else if (((value instanceof ISeq)) || ((value instanceof IPersistentList)))
/*      */       {
/* 4787 */         emitListAsObjectArray(value, gen);
/* 4788 */         gen.invokeStatic(Type.getType(Arrays.class), clojure.asm.commons.Method.getMethod("java.util.List asList(Object[])"));
/*      */         
/* 4790 */         gen.invokeStatic(Type.getType(PersistentList.class), clojure.asm.commons.Method.getMethod("clojure.lang.IPersistentList create(java.util.List)"));
/*      */ 
/*      */ 
/*      */       }
/* 4794 */       else if ((value instanceof Pattern))
/*      */       {
/* 4796 */         emitValue(value.toString(), gen);
/* 4797 */         gen.invokeStatic(Type.getType(Pattern.class), clojure.asm.commons.Method.getMethod("java.util.regex.Pattern compile(String)"));
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/* 4802 */         String cs = null;
/*      */         try
/*      */         {
/* 4805 */           cs = RT.printString(value);
/*      */ 
/*      */         }
/*      */         catch (Exception e)
/*      */         {
/* 4810 */           throw Util.runtimeException("Can't embed object in code, maybe print-dup not defined: " + value);
/*      */         }
/*      */         
/*      */ 
/* 4814 */         if (cs.length() == 0) {
/* 4815 */           throw Util.runtimeException("Can't embed unreadable object in code: " + value);
/*      */         }
/*      */         
/* 4818 */         if (cs.startsWith("#<")) {
/* 4819 */           throw Util.runtimeException("Can't embed unreadable object in code: " + cs);
/*      */         }
/*      */         
/* 4822 */         gen.push(cs);
/* 4823 */         gen.invokeStatic(Compiler.RT_TYPE, readStringMethod);
/* 4824 */         partial = false;
/*      */       }
/*      */       
/* 4827 */       if (partial)
/*      */       {
/* 4829 */         if (((value instanceof IObj)) && (RT.count(((IObj)value).meta()) > 0))
/*      */         {
/* 4831 */           gen.checkCast(Compiler.IOBJ_TYPE);
/* 4832 */           Object m = ((IObj)value).meta();
/* 4833 */           emitValue(Compiler.elideMeta(m), gen);
/* 4834 */           gen.checkCast(Compiler.IPERSISTENTMAP_TYPE);
/* 4835 */           gen.invokeInterface(Compiler.IOBJ_TYPE, clojure.asm.commons.Method.getMethod("clojure.lang.IObj withMeta(clojure.lang.IPersistentMap)"));
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */     void emitConstants(GeneratorAdapter clinitgen)
/*      */     {
/*      */       try
/*      */       {
/* 4845 */         Var.pushThreadBindings(RT.map(new Object[] { RT.PRINT_DUP, RT.T }));
/*      */         
/* 4847 */         for (int i = 0; i < this.constants.count(); i++)
/*      */         {
/* 4849 */           if (this.usedConstants.contains(Integer.valueOf(i)))
/*      */           {
/* 4851 */             emitValue(this.constants.nth(i), clinitgen);
/* 4852 */             clinitgen.checkCast(constantType(i));
/* 4853 */             clinitgen.putStatic(this.objtype, constantName(i), constantType(i));
/*      */           }
/*      */         }
/*      */       }
/*      */       finally
/*      */       {
/* 4859 */         Var.popThreadBindings();
/*      */       }
/*      */     }
/*      */     
/*      */     boolean isMutable(Compiler.LocalBinding lb) {
/* 4864 */       return (isVolatile(lb)) || ((RT.booleanCast(RT.contains(this.fields, lb.sym))) && (RT.booleanCast(RT.get(lb.sym.meta(), Keyword.intern("unsynchronized-mutable")))));
/*      */     }
/*      */     
/*      */ 
/*      */     boolean isVolatile(Compiler.LocalBinding lb)
/*      */     {
/* 4870 */       return (RT.booleanCast(RT.contains(this.fields, lb.sym))) && (RT.booleanCast(RT.get(lb.sym.meta(), Keyword.intern("volatile-mutable"))));
/*      */     }
/*      */     
/*      */     boolean isDeftype()
/*      */     {
/* 4875 */       return this.fields != null;
/*      */     }
/*      */     
/*      */     boolean supportsMeta() {
/* 4879 */       return !isDeftype();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     void emitClearCloses(GeneratorAdapter gen) {}
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     synchronized Class getCompiledClass()
/*      */     {
/* 4897 */       if (this.compiledClass == null)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/* 4902 */         this.loader = ((DynamicClassLoader)Compiler.LOADER.deref());
/* 4903 */         this.compiledClass = this.loader.defineClass(this.name, this.bytecode, this.src);
/*      */       }
/* 4905 */       return this.compiledClass;
/*      */     }
/*      */     
/*      */     public Object eval() {
/* 4909 */       if (isDeftype()) {
/* 4910 */         return null;
/*      */       }
/*      */       try {
/* 4913 */         return getCompiledClass().newInstance();
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/* 4917 */         throw Util.sneakyThrow(e);
/*      */       }
/*      */     }
/*      */     
/*      */     public void emitLetFnInits(GeneratorAdapter gen, ObjExpr objx, IPersistentSet letFnLocals)
/*      */     {
/* 4923 */       gen.checkCast(this.objtype);
/*      */       
/* 4925 */       for (ISeq s = RT.keys(this.closes); s != null; s = s.next())
/*      */       {
/* 4927 */         Compiler.LocalBinding lb = (Compiler.LocalBinding)s.first();
/* 4928 */         if (letFnLocals.contains(lb))
/*      */         {
/* 4930 */           Class primc = lb.getPrimitiveType();
/* 4931 */           gen.dup();
/* 4932 */           if (primc != null)
/*      */           {
/* 4934 */             objx.emitUnboxedLocal(gen, lb);
/* 4935 */             gen.putField(this.objtype, lb.name, Type.getType(primc));
/*      */           }
/*      */           else
/*      */           {
/* 4939 */             objx.emitLocal(gen, lb, false);
/* 4940 */             gen.putField(this.objtype, lb.name, Compiler.OBJECT_TYPE);
/*      */           }
/*      */         }
/*      */       }
/* 4944 */       gen.pop();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public void emit(Compiler.C context, ObjExpr objx, GeneratorAdapter gen)
/*      */     {
/* 4952 */       if (isDeftype())
/*      */       {
/* 4954 */         gen.visitInsn(1);
/*      */       }
/*      */       else
/*      */       {
/* 4958 */         gen.newInstance(this.objtype);
/* 4959 */         gen.dup();
/* 4960 */         if (supportsMeta())
/* 4961 */           gen.visitInsn(1);
/* 4962 */         for (ISeq s = RT.seq(this.closesExprs); s != null; s = s.next())
/*      */         {
/* 4964 */           Compiler.LocalBindingExpr lbe = (Compiler.LocalBindingExpr)s.first();
/* 4965 */           Compiler.LocalBinding lb = lbe.b;
/* 4966 */           if (lb.getPrimitiveType() != null) {
/* 4967 */             objx.emitUnboxedLocal(gen, lb);
/*      */           } else
/* 4969 */             objx.emitLocal(gen, lb, lbe.shouldClear);
/*      */         }
/* 4971 */         gen.invokeConstructor(this.objtype, new clojure.asm.commons.Method("<init>", Type.VOID_TYPE, ctorTypes()));
/*      */       }
/* 4973 */       if (context == Compiler.C.STATEMENT)
/* 4974 */         gen.pop();
/*      */     }
/*      */     
/*      */     public boolean hasJavaClass() {
/* 4978 */       return true;
/*      */     }
/*      */     
/*      */     public Class getJavaClass() {
/* 4982 */       return this.tag != null ? Compiler.HostExpr.tagToClass(this.tag) : this.compiledClass != null ? this.compiledClass : IFn.class;
/*      */     }
/*      */     
/*      */ 
/*      */     public void emitAssignLocal(GeneratorAdapter gen, Compiler.LocalBinding lb, Compiler.Expr val)
/*      */     {
/* 4988 */       if (!isMutable(lb))
/* 4989 */         throw new IllegalArgumentException("Cannot assign to non-mutable: " + lb.name);
/* 4990 */       Class primc = lb.getPrimitiveType();
/* 4991 */       gen.loadThis();
/* 4992 */       if (primc != null)
/*      */       {
/* 4994 */         if ((!(val instanceof Compiler.MaybePrimitiveExpr)) || (!((Compiler.MaybePrimitiveExpr)val).canEmitPrimitive()))
/* 4995 */           throw new IllegalArgumentException("Must assign primitive to primitive mutable: " + lb.name);
/* 4996 */         Compiler.MaybePrimitiveExpr me = (Compiler.MaybePrimitiveExpr)val;
/* 4997 */         me.emitUnboxed(Compiler.C.EXPRESSION, this, gen);
/* 4998 */         gen.putField(this.objtype, lb.name, Type.getType(primc));
/*      */       }
/*      */       else
/*      */       {
/* 5002 */         val.emit(Compiler.C.EXPRESSION, this, gen);
/* 5003 */         gen.putField(this.objtype, lb.name, Compiler.OBJECT_TYPE);
/*      */       }
/*      */     }
/*      */     
/*      */     private void emitLocal(GeneratorAdapter gen, Compiler.LocalBinding lb, boolean clear) {
/* 5008 */       if (this.closes.containsKey(lb))
/*      */       {
/* 5010 */         Class primc = lb.getPrimitiveType();
/* 5011 */         gen.loadThis();
/* 5012 */         if (primc != null)
/*      */         {
/* 5014 */           gen.getField(this.objtype, lb.name, Type.getType(primc));
/* 5015 */           Compiler.HostExpr.emitBoxReturn(this, gen, primc);
/*      */         }
/*      */         else
/*      */         {
/* 5019 */           gen.getField(this.objtype, lb.name, Compiler.OBJECT_TYPE);
/* 5020 */           if ((this.onceOnly) && (clear) && (lb.canBeCleared))
/*      */           {
/* 5022 */             gen.loadThis();
/* 5023 */             gen.visitInsn(1);
/* 5024 */             gen.putField(this.objtype, lb.name, Compiler.OBJECT_TYPE);
/*      */           }
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/* 5030 */         int argoff = this.canBeDirect ? 0 : 1;
/* 5031 */         Class primc = lb.getPrimitiveType();
/*      */         
/* 5033 */         if (lb.isArg)
/*      */         {
/* 5035 */           gen.loadArg(lb.idx - argoff);
/* 5036 */           if (primc != null) {
/* 5037 */             Compiler.HostExpr.emitBoxReturn(this, gen, primc);
/*      */ 
/*      */           }
/* 5040 */           else if ((clear) && (lb.canBeCleared))
/*      */           {
/*      */ 
/* 5043 */             gen.visitInsn(1);
/* 5044 */             gen.storeArg(lb.idx - argoff);
/*      */ 
/*      */ 
/*      */ 
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */         }
/* 5054 */         else if (primc != null)
/*      */         {
/* 5056 */           gen.visitVarInsn(Type.getType(primc).getOpcode(21), lb.idx);
/* 5057 */           Compiler.HostExpr.emitBoxReturn(this, gen, primc);
/*      */         }
/*      */         else
/*      */         {
/* 5061 */           gen.visitVarInsn(Compiler.OBJECT_TYPE.getOpcode(21), lb.idx);
/* 5062 */           if ((clear) && (lb.canBeCleared))
/*      */           {
/*      */ 
/* 5065 */             gen.visitInsn(1);
/* 5066 */             gen.visitVarInsn(Compiler.OBJECT_TYPE.getOpcode(54), lb.idx);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private void emitUnboxedLocal(GeneratorAdapter gen, Compiler.LocalBinding lb)
/*      */     {
/* 5078 */       int argoff = this.canBeDirect ? 0 : 1;
/* 5079 */       Class primc = lb.getPrimitiveType();
/* 5080 */       if (this.closes.containsKey(lb))
/*      */       {
/* 5082 */         gen.loadThis();
/* 5083 */         gen.getField(this.objtype, lb.name, Type.getType(primc));
/*      */       }
/* 5085 */       else if (lb.isArg) {
/* 5086 */         gen.loadArg(lb.idx - argoff);
/*      */       } else {
/* 5088 */         gen.visitVarInsn(Type.getType(primc).getOpcode(21), lb.idx);
/*      */       }
/*      */     }
/*      */     
/* 5092 */     public void emitVar(GeneratorAdapter gen, Var var) { Integer i = (Integer)this.vars.valAt(var);
/* 5093 */       emitConstant(gen, i.intValue());
/*      */     }
/*      */     
/*      */ 
/* 5097 */     static final clojure.asm.commons.Method varGetMethod = clojure.asm.commons.Method.getMethod("Object get()");
/* 5098 */     static final clojure.asm.commons.Method varGetRawMethod = clojure.asm.commons.Method.getMethod("Object getRawRoot()");
/*      */     
/*      */     public void emitVarValue(GeneratorAdapter gen, Var v) {
/* 5101 */       Integer i = (Integer)this.vars.valAt(v);
/* 5102 */       if (!v.isDynamic())
/*      */       {
/* 5104 */         emitConstant(gen, i.intValue());
/* 5105 */         gen.invokeVirtual(Compiler.VAR_TYPE, varGetRawMethod);
/*      */       }
/*      */       else
/*      */       {
/* 5109 */         emitConstant(gen, i.intValue());
/* 5110 */         gen.invokeVirtual(Compiler.VAR_TYPE, varGetMethod);
/*      */       }
/*      */     }
/*      */     
/*      */     public void emitKeyword(GeneratorAdapter gen, Keyword k) {
/* 5115 */       Integer i = (Integer)this.keywords.valAt(k);
/* 5116 */       emitConstant(gen, i.intValue());
/*      */     }
/*      */     
/*      */     public void emitConstant(GeneratorAdapter gen, int id)
/*      */     {
/* 5121 */       this.usedConstants = ((IPersistentSet)this.usedConstants.cons(Integer.valueOf(id)));
/* 5122 */       gen.getStatic(this.objtype, constantName(id), constantType(id));
/*      */     }
/*      */     
/*      */     String constantName(int id)
/*      */     {
/* 5127 */       return "const__" + id;
/*      */     }
/*      */     
/*      */     String siteName(int n) {
/* 5131 */       return "__site__" + n;
/*      */     }
/*      */     
/*      */     String siteNameStatic(int n) {
/* 5135 */       return siteName(n) + "__";
/*      */     }
/*      */     
/*      */     String thunkName(int n) {
/* 5139 */       return "__thunk__" + n;
/*      */     }
/*      */     
/*      */     String cachedClassName(int n) {
/* 5143 */       return "__cached_class__" + n;
/*      */     }
/*      */     
/*      */     String cachedVarName(int n) {
/* 5147 */       return "__cached_var__" + n;
/*      */     }
/*      */     
/*      */     String varCallsiteName(int n) {
/* 5151 */       return "__var__callsite__" + n;
/*      */     }
/*      */     
/*      */     String thunkNameStatic(int n) {
/* 5155 */       return thunkName(n) + "__";
/*      */     }
/*      */     
/*      */     Type constantType(int id) {
/* 5159 */       Object o = this.constants.nth(id);
/* 5160 */       Class c = Util.classOf(o);
/* 5161 */       if ((c != null) && (Modifier.isPublic(c.getModifiers())))
/*      */       {
/*      */ 
/* 5164 */         if (LazySeq.class.isAssignableFrom(c))
/* 5165 */           return Type.getType(ISeq.class);
/* 5166 */         if (c == Keyword.class) {
/* 5167 */           return Type.getType(Keyword.class);
/*      */         }
/*      */         
/* 5170 */         if (RestFn.class.isAssignableFrom(c))
/* 5171 */           return Type.getType(RestFn.class);
/* 5172 */         if (AFn.class.isAssignableFrom(c))
/* 5173 */           return Type.getType(AFn.class);
/* 5174 */         if (c == Var.class)
/* 5175 */           return Type.getType(Var.class);
/* 5176 */         if (c == String.class) {
/* 5177 */           return Type.getType(String.class);
/*      */         }
/*      */       }
/*      */       
/* 5181 */       return Compiler.OBJECT_TYPE;
/*      */     }
/*      */   }
/*      */   
/*      */   static enum PATHTYPE
/*      */   {
/* 5187 */     PATH,  BRANCH;
/*      */     
/*      */     private PATHTYPE() {}
/*      */   }
/*      */   
/*      */   static class PathNode { final Compiler.PATHTYPE type;
/*      */     final PathNode parent;
/*      */     
/* 5195 */     PathNode(Compiler.PATHTYPE type, PathNode parent) { this.type = type;
/* 5196 */       this.parent = parent;
/*      */     }
/*      */   }
/*      */   
/*      */   static PathNode clearPathRoot() {
/* 5201 */     return (PathNode)CLEAR_ROOT.get();
/*      */   }
/*      */   
/*      */   static enum PSTATE {
/* 5205 */     REQ,  REST,  DONE;
/*      */     
/*      */     private PSTATE() {}
/*      */   }
/*      */   
/* 5210 */   public static class FnMethod extends Compiler.ObjMethod { PersistentVector reqParms = PersistentVector.EMPTY;
/* 5211 */     Compiler.LocalBinding restParm = null;
/*      */     Type[] argtypes;
/*      */     Class[] argclasses;
/*      */     Class retClass;
/*      */     String prim;
/*      */     
/*      */     public FnMethod(Compiler.ObjExpr objx, Compiler.ObjMethod parent) {
/* 5218 */       super(parent);
/*      */     }
/*      */     
/*      */     public static char classChar(Object x) {
/* 5222 */       Class c = null;
/* 5223 */       if ((x instanceof Class)) {
/* 5224 */         c = (Class)x;
/* 5225 */       } else if ((x instanceof Symbol))
/* 5226 */         c = Compiler.primClass((Symbol)x);
/* 5227 */       if ((c == null) || (!c.isPrimitive()))
/* 5228 */         return 'O';
/* 5229 */       if (c == Long.TYPE)
/* 5230 */         return 'L';
/* 5231 */       if (c == Double.TYPE)
/* 5232 */         return 'D';
/* 5233 */       throw new IllegalArgumentException("Only long and double primitives are supported");
/*      */     }
/*      */     
/*      */     public static String primInterface(IPersistentVector arglist) {
/* 5237 */       StringBuilder sb = new StringBuilder();
/* 5238 */       for (int i = 0; i < arglist.count(); i++)
/* 5239 */         sb.append(classChar(Compiler.tagOf(arglist.nth(i))));
/* 5240 */       sb.append(classChar(Compiler.tagOf(arglist)));
/* 5241 */       String ret = sb.toString();
/* 5242 */       boolean prim = (ret.contains("L")) || (ret.contains("D"));
/* 5243 */       if ((prim) && (arglist.count() > 4))
/* 5244 */         throw new IllegalArgumentException("fns taking primitives support only 4 or fewer args");
/* 5245 */       if (prim)
/* 5246 */         return "clojure.lang.IFn$" + ret;
/* 5247 */       return null;
/*      */     }
/*      */     
/*      */     static FnMethod parse(Compiler.ObjExpr objx, ISeq form, Object rettag)
/*      */     {
/* 5252 */       IPersistentVector parms = (IPersistentVector)RT.first(form);
/* 5253 */       ISeq body = RT.next(form);
/*      */       try
/*      */       {
/* 5256 */         FnMethod method = new FnMethod(objx, (Compiler.ObjMethod)Compiler.METHOD.deref());
/* 5257 */         method.line = Compiler.lineDeref();
/* 5258 */         method.column = Compiler.columnDeref();
/*      */         
/* 5260 */         Compiler.PathNode pnode = (Compiler.PathNode)Compiler.CLEAR_PATH.get();
/* 5261 */         if (pnode == null)
/* 5262 */           pnode = new Compiler.PathNode(Compiler.PATHTYPE.PATH, null);
/* 5263 */         Var.pushThreadBindings(RT.mapUniqueKeys(new Object[] { Compiler.METHOD, method, Compiler.LOCAL_ENV, Compiler.LOCAL_ENV.deref(), Compiler.LOOP_LOCALS, null, Compiler.NEXT_LOCAL_NUM, Integer.valueOf(0), Compiler.CLEAR_PATH, pnode, Compiler.CLEAR_ROOT, pnode, Compiler.CLEAR_SITES, PersistentHashMap.EMPTY }));
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5274 */         method.prim = primInterface(parms);
/* 5275 */         if (method.prim != null) {
/* 5276 */           method.prim = method.prim.replace('.', '/');
/*      */         }
/* 5278 */         if ((rettag instanceof String))
/* 5279 */           rettag = Symbol.intern(null, (String)rettag);
/* 5280 */         if (!(rettag instanceof Symbol))
/* 5281 */           rettag = null;
/* 5282 */         if (rettag != null)
/*      */         {
/* 5284 */           String retstr = ((Symbol)rettag).getName();
/* 5285 */           if ((!retstr.equals("long")) && (!retstr.equals("double")))
/* 5286 */             rettag = null;
/*      */         }
/* 5288 */         method.retClass = Compiler.tagClass(Compiler.tagOf(parms) != null ? Compiler.tagOf(parms) : rettag);
/* 5289 */         if (method.retClass.isPrimitive()) {
/* 5290 */           if ((method.retClass != Double.TYPE) && (method.retClass != Long.TYPE)) {
/* 5291 */             throw new IllegalArgumentException("Only long and double primitives are supported");
/*      */           }
/*      */         } else {
/* 5294 */           method.retClass = Object.class;
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 5299 */         if (objx.thisName != null) {
/* 5300 */           Compiler.registerLocal(Symbol.intern(objx.thisName), null, null, false);
/*      */         } else {
/* 5302 */           Compiler.access$900();
/*      */         }
/* 5304 */         Compiler.PSTATE state = Compiler.PSTATE.REQ;
/* 5305 */         PersistentVector argLocals = PersistentVector.EMPTY;
/* 5306 */         ArrayList<Type> argtypes = new ArrayList();
/* 5307 */         ArrayList<Class> argclasses = new ArrayList();
/* 5308 */         for (int i = 0; i < parms.count(); i++)
/*      */         {
/* 5310 */           if (!(parms.nth(i) instanceof Symbol))
/* 5311 */             throw new IllegalArgumentException("fn params must be Symbols");
/* 5312 */           Symbol p = (Symbol)parms.nth(i);
/* 5313 */           if (p.getNamespace() != null)
/* 5314 */             throw Util.runtimeException("Can't use qualified name as parameter: " + p);
/* 5315 */           if (p.equals(Compiler._AMP_))
/*      */           {
/*      */ 
/*      */ 
/* 5319 */             if (state == Compiler.PSTATE.REQ) {
/* 5320 */               state = Compiler.PSTATE.REST;
/*      */             } else {
/* 5322 */               throw Util.runtimeException("Invalid parameter list");
/*      */             }
/*      */           }
/*      */           else
/*      */           {
/* 5327 */             Class pc = Compiler.primClass(Compiler.tagClass(Compiler.tagOf(p)));
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5334 */             if ((pc.isPrimitive()) && (pc != Double.TYPE) && (pc != Long.TYPE)) {
/* 5335 */               throw new IllegalArgumentException("Only long and double primitives are supported: " + p);
/*      */             }
/* 5337 */             if ((state == Compiler.PSTATE.REST) && (Compiler.tagOf(p) != null))
/* 5338 */               throw Util.runtimeException("& arg cannot have type hint");
/* 5339 */             if ((state == Compiler.PSTATE.REST) && (method.prim != null)) {
/* 5340 */               throw Util.runtimeException("fns taking primitives cannot be variadic");
/*      */             }
/* 5342 */             if (state == Compiler.PSTATE.REST)
/* 5343 */               pc = ISeq.class;
/* 5344 */             argtypes.add(Type.getType(pc));
/* 5345 */             argclasses.add(pc);
/* 5346 */             Compiler.LocalBinding lb = pc.isPrimitive() ? Compiler.registerLocal(p, null, new Compiler.MethodParamExpr(pc), true) : Compiler.registerLocal(p, state == Compiler.PSTATE.REST ? Compiler.ISEQ : Compiler.access$600(p), null, true);
/*      */             
/*      */ 
/* 5349 */             argLocals = argLocals.cons(lb);
/* 5350 */             switch (Compiler.2.$SwitchMap$clojure$lang$Compiler$PSTATE[state.ordinal()])
/*      */             {
/*      */             case 1: 
/* 5353 */               method.reqParms = method.reqParms.cons(lb);
/* 5354 */               break;
/*      */             case 2: 
/* 5356 */               method.restParm = lb;
/* 5357 */               state = Compiler.PSTATE.DONE;
/* 5358 */               break;
/*      */             
/*      */             default: 
/* 5361 */               throw Util.runtimeException("Unexpected parameter");
/*      */             }
/*      */           }
/*      */         }
/* 5365 */         if (method.reqParms.count() > 20)
/* 5366 */           throw Util.runtimeException("Can't specify more than 20 params");
/* 5367 */         Compiler.LOOP_LOCALS.set(argLocals);
/* 5368 */         method.argLocals = argLocals;
/*      */         
/* 5370 */         method.argtypes = ((Type[])argtypes.toArray(new Type[argtypes.size()]));
/* 5371 */         method.argclasses = ((Class[])argclasses.toArray(new Class[argtypes.size()]));
/* 5372 */         int i; if (method.prim != null)
/*      */         {
/* 5374 */           for (i = 0; i < method.argclasses.length; i++)
/*      */           {
/* 5376 */             if ((method.argclasses[i] == Long.TYPE) || (method.argclasses[i] == Double.TYPE))
/* 5377 */               Compiler.access$900();
/*      */           }
/*      */         }
/* 5380 */         method.body = new Compiler.BodyExpr.Parser().parse(Compiler.C.RETURN, body);
/* 5381 */         return method;
/*      */       }
/*      */       finally
/*      */       {
/* 5385 */         Var.popThreadBindings();
/*      */       }
/*      */     }
/*      */     
/*      */     public void emit(Compiler.ObjExpr fn, ClassVisitor cv) {
/* 5390 */       if (fn.canBeDirect)
/*      */       {
/*      */ 
/* 5393 */         doEmitStatic(fn, cv);
/*      */       }
/* 5395 */       else if (this.prim != null)
/*      */       {
/*      */ 
/* 5398 */         doEmitPrim(fn, cv);
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/* 5403 */         doEmit(fn, cv);
/*      */       }
/*      */     }
/*      */     
/*      */     public void doEmitStatic(Compiler.ObjExpr fn, ClassVisitor cv)
/*      */     {
/* 5409 */       Type returnType = Type.getType(this.retClass);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 5414 */       clojure.asm.commons.Method ms = new clojure.asm.commons.Method("invokeStatic", returnType, this.argtypes);
/*      */       
/* 5416 */       GeneratorAdapter gen = new GeneratorAdapter(9, ms, null, Compiler.EXCEPTION_TYPES, cv);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5422 */       gen.visitCode();
/* 5423 */       Label loopLabel = gen.mark();
/* 5424 */       gen.visitLineNumber(this.line, loopLabel);
/*      */       try
/*      */       {
/* 5427 */         Var.pushThreadBindings(RT.map(new Object[] { Compiler.LOOP_LABEL, loopLabel, Compiler.METHOD, this }));
/* 5428 */         emitBody(this.objx, gen, this.retClass, this.body);
/*      */         
/* 5430 */         Label end = gen.mark();
/* 5431 */         for (ISeq lbs = this.argLocals.seq(); lbs != null; lbs = lbs.next())
/*      */         {
/* 5433 */           Compiler.LocalBinding lb = (Compiler.LocalBinding)lbs.first();
/* 5434 */           gen.visitLocalVariable(lb.name, this.argtypes[lb.idx].getDescriptor(), null, loopLabel, end, lb.idx);
/*      */         }
/*      */       }
/*      */       finally
/*      */       {
/* 5439 */         Var.popThreadBindings();
/*      */       }
/*      */       
/* 5442 */       gen.returnValue();
/*      */       
/* 5444 */       gen.endMethod();
/*      */       
/*      */ 
/* 5447 */       clojure.asm.commons.Method m = new clojure.asm.commons.Method(getMethodName(), Compiler.OBJECT_TYPE, getArgTypes());
/*      */       
/* 5449 */       gen = new GeneratorAdapter(1, m, null, Compiler.EXCEPTION_TYPES, cv);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5455 */       gen.visitCode();
/* 5456 */       for (int i = 0; i < this.argtypes.length; i++)
/*      */       {
/* 5458 */         gen.loadArg(i);
/* 5459 */         Compiler.HostExpr.emitUnboxArg(fn, gen, this.argclasses[i]);
/* 5460 */         if (!this.argclasses[i].isPrimitive())
/*      */         {
/* 5462 */           gen.visitInsn(1);
/* 5463 */           gen.storeArg(i);
/*      */         }
/*      */       }
/* 5466 */       Label callLabel = gen.mark();
/* 5467 */       gen.visitLineNumber(this.line, callLabel);
/* 5468 */       gen.invokeStatic(this.objx.objtype, ms);
/* 5469 */       gen.box(returnType);
/*      */       
/*      */ 
/* 5472 */       gen.returnValue();
/*      */       
/* 5474 */       gen.endMethod();
/*      */       
/*      */ 
/* 5477 */       if (this.prim != null)
/*      */       {
/* 5479 */         if ((this.retClass == Double.TYPE) || (this.retClass == Long.TYPE))
/* 5480 */           returnType = getReturnType(); else {
/* 5481 */           returnType = Compiler.OBJECT_TYPE;
/*      */         }
/* 5483 */         clojure.asm.commons.Method pm = new clojure.asm.commons.Method("invokePrim", returnType, this.argtypes);
/*      */         
/* 5485 */         gen = new GeneratorAdapter(17, pm, null, Compiler.EXCEPTION_TYPES, cv);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5491 */         gen.visitCode();
/* 5492 */         for (int i = 0; i < this.argtypes.length; i++)
/*      */         {
/* 5494 */           gen.loadArg(i);
/* 5495 */           if (!this.argclasses[i].isPrimitive())
/*      */           {
/* 5497 */             gen.visitInsn(1);
/* 5498 */             gen.storeArg(i);
/*      */           }
/*      */         }
/* 5501 */         gen.invokeStatic(this.objx.objtype, ms);
/*      */         
/* 5503 */         gen.returnValue();
/*      */         
/* 5505 */         gen.endMethod();
/*      */       }
/*      */     }
/*      */     
/*      */     public void doEmitPrim(Compiler.ObjExpr fn, ClassVisitor cv)
/*      */     {
/*      */       Type returnType;
/*      */       Type returnType;
/* 5513 */       if ((this.retClass == Double.TYPE) || (this.retClass == Long.TYPE))
/* 5514 */         returnType = getReturnType(); else
/* 5515 */         returnType = Compiler.OBJECT_TYPE;
/* 5516 */       clojure.asm.commons.Method ms = new clojure.asm.commons.Method("invokePrim", returnType, this.argtypes);
/*      */       
/* 5518 */       GeneratorAdapter gen = new GeneratorAdapter(17, ms, null, Compiler.EXCEPTION_TYPES, cv);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5524 */       gen.visitCode();
/*      */       
/* 5526 */       Label loopLabel = gen.mark();
/* 5527 */       gen.visitLineNumber(this.line, loopLabel);
/*      */       try
/*      */       {
/* 5530 */         Var.pushThreadBindings(RT.map(new Object[] { Compiler.LOOP_LABEL, loopLabel, Compiler.METHOD, this }));
/* 5531 */         emitBody(this.objx, gen, this.retClass, this.body);
/*      */         
/* 5533 */         Label end = gen.mark();
/* 5534 */         gen.visitLocalVariable("this", "Ljava/lang/Object;", null, loopLabel, end, 0);
/* 5535 */         for (ISeq lbs = this.argLocals.seq(); lbs != null; lbs = lbs.next())
/*      */         {
/* 5537 */           Compiler.LocalBinding lb = (Compiler.LocalBinding)lbs.first();
/* 5538 */           gen.visitLocalVariable(lb.name, this.argtypes[(lb.idx - 1)].getDescriptor(), null, loopLabel, end, lb.idx);
/*      */         }
/*      */       }
/*      */       finally
/*      */       {
/* 5543 */         Var.popThreadBindings();
/*      */       }
/*      */       
/* 5546 */       gen.returnValue();
/*      */       
/* 5548 */       gen.endMethod();
/*      */       
/*      */ 
/* 5551 */       clojure.asm.commons.Method m = new clojure.asm.commons.Method(getMethodName(), Compiler.OBJECT_TYPE, getArgTypes());
/*      */       
/* 5553 */       gen = new GeneratorAdapter(1, m, null, Compiler.EXCEPTION_TYPES, cv);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5559 */       gen.visitCode();
/* 5560 */       gen.loadThis();
/* 5561 */       for (int i = 0; i < this.argtypes.length; i++)
/*      */       {
/* 5563 */         gen.loadArg(i);
/* 5564 */         Compiler.HostExpr.emitUnboxArg(fn, gen, this.argclasses[i]);
/*      */       }
/* 5566 */       gen.invokeInterface(Type.getType("L" + this.prim + ";"), ms);
/* 5567 */       gen.box(getReturnType());
/*      */       
/*      */ 
/* 5570 */       gen.returnValue();
/*      */       
/* 5572 */       gen.endMethod();
/*      */     }
/*      */     
/*      */     public void doEmit(Compiler.ObjExpr fn, ClassVisitor cv) {
/* 5576 */       clojure.asm.commons.Method m = new clojure.asm.commons.Method(getMethodName(), getReturnType(), getArgTypes());
/*      */       
/* 5578 */       GeneratorAdapter gen = new GeneratorAdapter(1, m, null, Compiler.EXCEPTION_TYPES, cv);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5584 */       gen.visitCode();
/*      */       
/* 5586 */       Label loopLabel = gen.mark();
/* 5587 */       gen.visitLineNumber(this.line, loopLabel);
/*      */       try
/*      */       {
/* 5590 */         Var.pushThreadBindings(RT.map(new Object[] { Compiler.LOOP_LABEL, loopLabel, Compiler.METHOD, this }));
/*      */         
/* 5592 */         this.body.emit(Compiler.C.RETURN, fn, gen);
/* 5593 */         Label end = gen.mark();
/*      */         
/* 5595 */         gen.visitLocalVariable("this", "Ljava/lang/Object;", null, loopLabel, end, 0);
/* 5596 */         for (ISeq lbs = this.argLocals.seq(); lbs != null; lbs = lbs.next())
/*      */         {
/* 5598 */           Compiler.LocalBinding lb = (Compiler.LocalBinding)lbs.first();
/* 5599 */           gen.visitLocalVariable(lb.name, "Ljava/lang/Object;", null, loopLabel, end, lb.idx);
/*      */         }
/*      */       }
/*      */       finally
/*      */       {
/* 5604 */         Var.popThreadBindings();
/*      */       }
/*      */       
/* 5607 */       gen.returnValue();
/*      */       
/* 5609 */       gen.endMethod();
/*      */     }
/*      */     
/*      */ 
/*      */     public final PersistentVector reqParms()
/*      */     {
/* 5615 */       return this.reqParms;
/*      */     }
/*      */     
/*      */     public final Compiler.LocalBinding restParm() {
/* 5619 */       return this.restParm;
/*      */     }
/*      */     
/*      */     boolean isVariadic() {
/* 5623 */       return this.restParm != null;
/*      */     }
/*      */     
/*      */     int numParams() {
/* 5627 */       return this.reqParms.count() + (isVariadic() ? 1 : 0);
/*      */     }
/*      */     
/*      */     String getMethodName() {
/* 5631 */       return isVariadic() ? "doInvoke" : "invoke";
/*      */     }
/*      */     
/*      */     Type getReturnType() {
/* 5635 */       if (this.prim != null)
/* 5636 */         return Type.getType(this.retClass);
/* 5637 */       return Compiler.OBJECT_TYPE;
/*      */     }
/*      */     
/*      */     Type[] getArgTypes() {
/* 5641 */       if ((isVariadic()) && (this.reqParms.count() == 20))
/*      */       {
/* 5643 */         Type[] ret = new Type[21];
/* 5644 */         for (int i = 0; i < 21; i++)
/* 5645 */           ret[i] = Compiler.OBJECT_TYPE;
/* 5646 */         return ret;
/*      */       }
/* 5648 */       return Compiler.ARG_TYPES[numParams()];
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     void emitClearLocals(GeneratorAdapter gen) {}
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static abstract class ObjMethod
/*      */   {
/*      */     public final ObjMethod parent;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5684 */     IPersistentMap locals = null;
/*      */     
/* 5686 */     IPersistentMap indexlocals = null;
/* 5687 */     Compiler.Expr body = null;
/*      */     Compiler.ObjExpr objx;
/*      */     PersistentVector argLocals;
/* 5690 */     int maxLocal = 0;
/*      */     int line;
/*      */     int column;
/* 5693 */     boolean usesThis = false;
/* 5694 */     PersistentHashSet localsUsedInCatchFinally = PersistentHashSet.EMPTY;
/*      */     protected IPersistentMap methodMeta;
/*      */     
/*      */     public final IPersistentMap locals()
/*      */     {
/* 5699 */       return this.locals;
/*      */     }
/*      */     
/*      */     public final Compiler.Expr body() {
/* 5703 */       return this.body;
/*      */     }
/*      */     
/*      */     public final Compiler.ObjExpr objx() {
/* 5707 */       return this.objx;
/*      */     }
/*      */     
/*      */     public final PersistentVector argLocals() {
/* 5711 */       return this.argLocals;
/*      */     }
/*      */     
/*      */     public final int maxLocal() {
/* 5715 */       return this.maxLocal;
/*      */     }
/*      */     
/*      */     public final int line() {
/* 5719 */       return this.line;
/*      */     }
/*      */     
/*      */     public final int column() {
/* 5723 */       return this.column;
/*      */     }
/*      */     
/*      */     public ObjMethod(Compiler.ObjExpr objx, ObjMethod parent) {
/* 5727 */       this.parent = parent;
/* 5728 */       this.objx = objx;
/*      */     }
/*      */     
/*      */     static void emitBody(Compiler.ObjExpr objx, GeneratorAdapter gen, Class retClass, Compiler.Expr body) {
/* 5732 */       Compiler.MaybePrimitiveExpr be = (Compiler.MaybePrimitiveExpr)body;
/* 5733 */       if ((Util.isPrimitive(retClass)) && (be.canEmitPrimitive()))
/*      */       {
/* 5735 */         Class bc = Compiler.maybePrimitiveType(be);
/* 5736 */         if (bc == retClass) {
/* 5737 */           be.emitUnboxed(Compiler.C.RETURN, objx, gen);
/* 5738 */         } else if ((retClass == Long.TYPE) && (bc == Integer.TYPE))
/*      */         {
/* 5740 */           be.emitUnboxed(Compiler.C.RETURN, objx, gen);
/* 5741 */           gen.visitInsn(133);
/*      */         }
/* 5743 */         else if ((retClass == Double.TYPE) && (bc == Float.TYPE))
/*      */         {
/* 5745 */           be.emitUnboxed(Compiler.C.RETURN, objx, gen);
/* 5746 */           gen.visitInsn(141);
/*      */         }
/* 5748 */         else if ((retClass == Integer.TYPE) && (bc == Long.TYPE))
/*      */         {
/* 5750 */           be.emitUnboxed(Compiler.C.RETURN, objx, gen);
/* 5751 */           gen.invokeStatic(Compiler.RT_TYPE, clojure.asm.commons.Method.getMethod("int intCast(long)"));
/*      */         }
/* 5753 */         else if ((retClass == Float.TYPE) && (bc == Double.TYPE))
/*      */         {
/* 5755 */           be.emitUnboxed(Compiler.C.RETURN, objx, gen);
/* 5756 */           gen.visitInsn(144);
/*      */         }
/*      */         else {
/* 5759 */           throw new IllegalArgumentException("Mismatched primitive return, expected: " + retClass + ", had: " + be.getJavaClass());
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/* 5764 */         body.emit(Compiler.C.RETURN, objx, gen);
/* 5765 */         if (retClass == Void.TYPE)
/*      */         {
/* 5767 */           gen.pop();
/*      */         }
/*      */         else
/* 5770 */           gen.unbox(Type.getType(retClass)); } }
/*      */     
/*      */     abstract int numParams();
/*      */     
/*      */     abstract String getMethodName();
/*      */     
/*      */     abstract Type getReturnType();
/*      */     
/*      */     abstract Type[] getArgTypes();
/* 5779 */     public void emit(Compiler.ObjExpr fn, ClassVisitor cv) { clojure.asm.commons.Method m = new clojure.asm.commons.Method(getMethodName(), getReturnType(), getArgTypes());
/*      */       
/* 5781 */       GeneratorAdapter gen = new GeneratorAdapter(1, m, null, Compiler.EXCEPTION_TYPES, cv);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5787 */       gen.visitCode();
/*      */       
/* 5789 */       Label loopLabel = gen.mark();
/* 5790 */       gen.visitLineNumber(this.line, loopLabel);
/*      */       try
/*      */       {
/* 5793 */         Var.pushThreadBindings(RT.map(new Object[] { Compiler.LOOP_LABEL, loopLabel, Compiler.METHOD, this }));
/*      */         
/* 5795 */         this.body.emit(Compiler.C.RETURN, fn, gen);
/* 5796 */         Label end = gen.mark();
/* 5797 */         gen.visitLocalVariable("this", "Ljava/lang/Object;", null, loopLabel, end, 0);
/* 5798 */         for (ISeq lbs = this.argLocals.seq(); lbs != null; lbs = lbs.next())
/*      */         {
/* 5800 */           Compiler.LocalBinding lb = (Compiler.LocalBinding)lbs.first();
/* 5801 */           gen.visitLocalVariable(lb.name, "Ljava/lang/Object;", null, loopLabel, end, lb.idx);
/*      */         }
/*      */       }
/*      */       finally
/*      */       {
/* 5806 */         Var.popThreadBindings();
/*      */       }
/*      */       
/* 5809 */       gen.returnValue();
/*      */       
/* 5811 */       gen.endMethod();
/*      */     }
/*      */     
/*      */     void emitClearLocals(GeneratorAdapter gen) {}
/*      */     
/*      */     void emitClearLocalsOld(GeneratorAdapter gen)
/*      */     {
/* 5818 */       for (int i = 0; i < this.argLocals.count(); i++)
/*      */       {
/* 5820 */         Compiler.LocalBinding lb = (Compiler.LocalBinding)this.argLocals.nth(i);
/* 5821 */         if ((!this.localsUsedInCatchFinally.contains(Integer.valueOf(lb.idx))) && (lb.getPrimitiveType() == null))
/*      */         {
/* 5823 */           gen.visitInsn(1);
/* 5824 */           gen.storeArg(lb.idx - 1);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5836 */       for (int i = numParams() + 1; i < this.maxLocal + 1; i++)
/*      */       {
/* 5838 */         if (!this.localsUsedInCatchFinally.contains(Integer.valueOf(i)))
/*      */         {
/* 5840 */           Compiler.LocalBinding b = (Compiler.LocalBinding)RT.get(this.indexlocals, Integer.valueOf(i));
/* 5841 */           if ((b == null) || (Compiler.maybePrimitiveType(b.init) == null))
/*      */           {
/* 5843 */             gen.visitInsn(1);
/* 5844 */             gen.visitVarInsn(Compiler.OBJECT_TYPE.getOpcode(54), i);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public static class LocalBinding {
/*      */     public final Symbol sym;
/*      */     public final Symbol tag;
/*      */     public Compiler.Expr init;
/*      */     int idx;
/*      */     public final String name;
/*      */     public final boolean isArg;
/*      */     public final Compiler.PathNode clearPathRoot;
/* 5859 */     public boolean canBeCleared = !RT.booleanCast(Compiler.getCompilerOption(Compiler.disableLocalsClearingKey));
/* 5860 */     public boolean recurMistmatch = false;
/*      */     
/*      */     public LocalBinding(int num, Symbol sym, Symbol tag, Compiler.Expr init, boolean isArg, Compiler.PathNode clearPathRoot)
/*      */     {
/* 5864 */       if ((Compiler.maybePrimitiveType(init) != null) && (tag != null))
/* 5865 */         throw new UnsupportedOperationException("Can't type hint a local with a primitive initializer");
/* 5866 */       this.idx = num;
/* 5867 */       this.sym = sym;
/* 5868 */       this.tag = tag;
/* 5869 */       this.init = init;
/* 5870 */       this.isArg = isArg;
/* 5871 */       this.clearPathRoot = clearPathRoot;
/* 5872 */       this.name = Compiler.munge(sym.name);
/*      */     }
/*      */     
/*      */     public boolean hasJavaClass() {
/* 5876 */       if ((this.init != null) && (this.init.hasJavaClass()) && (Util.isPrimitive(this.init.getJavaClass())) && (!(this.init instanceof Compiler.MaybePrimitiveExpr)))
/*      */       {
/*      */ 
/* 5879 */         return false; }
/* 5880 */       return (this.tag != null) || ((this.init != null) && (this.init.hasJavaClass()));
/*      */     }
/*      */     
/*      */     public Class getJavaClass()
/*      */     {
/* 5885 */       return this.tag != null ? Compiler.HostExpr.tagToClass(this.tag) : this.init.getJavaClass();
/*      */     }
/*      */     
/*      */     public Class getPrimitiveType()
/*      */     {
/* 5890 */       return Compiler.maybePrimitiveType(this.init);
/*      */     }
/*      */   }
/*      */   
/*      */   public static class LocalBindingExpr implements Compiler.Expr, Compiler.MaybePrimitiveExpr, Compiler.AssignableExpr
/*      */   {
/*      */     public final Compiler.LocalBinding b;
/*      */     public final Symbol tag;
/*      */     public final Compiler.PathNode clearPath;
/*      */     public final Compiler.PathNode clearRoot;
/* 5900 */     public boolean shouldClear = false;
/*      */     
/*      */ 
/*      */     public LocalBindingExpr(Compiler.LocalBinding b, Symbol tag)
/*      */     {
/* 5905 */       if ((b.getPrimitiveType() != null) && (tag != null))
/* 5906 */         throw new UnsupportedOperationException("Can't type hint a primitive local");
/* 5907 */       this.b = b;
/* 5908 */       this.tag = tag;
/*      */       
/* 5910 */       this.clearPath = ((Compiler.PathNode)Compiler.CLEAR_PATH.get());
/* 5911 */       this.clearRoot = ((Compiler.PathNode)Compiler.CLEAR_ROOT.get());
/* 5912 */       IPersistentCollection sites = (IPersistentCollection)RT.get(Compiler.CLEAR_SITES.get(), b);
/*      */       
/* 5914 */       if (b.idx > 0)
/*      */       {
/*      */ 
/*      */ 
/* 5918 */         if (sites != null)
/*      */         {
/* 5920 */           for (ISeq s = sites.seq(); s != null; s = s.next())
/*      */           {
/* 5922 */             LocalBindingExpr o = (LocalBindingExpr)s.first();
/* 5923 */             Compiler.PathNode common = Compiler.commonPath(this.clearPath, o.clearPath);
/* 5924 */             if ((common != null) && (common.type == Compiler.PATHTYPE.PATH)) {
/* 5925 */               o.shouldClear = false;
/*      */             }
/*      */           }
/*      */         }
/*      */         
/*      */ 
/* 5931 */         if (this.clearRoot == b.clearPathRoot)
/*      */         {
/* 5933 */           this.shouldClear = true;
/* 5934 */           sites = RT.conj(sites, this);
/* 5935 */           Compiler.CLEAR_SITES.set(RT.assoc(Compiler.CLEAR_SITES.get(), b, sites));
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */     public Object eval()
/*      */     {
/* 5943 */       throw new UnsupportedOperationException("Can't eval locals");
/*      */     }
/*      */     
/*      */     public boolean canEmitPrimitive() {
/* 5947 */       return this.b.getPrimitiveType() != null;
/*      */     }
/*      */     
/*      */     public void emitUnboxed(Compiler.C context, Compiler.ObjExpr objx, GeneratorAdapter gen) {
/* 5951 */       Compiler.ObjExpr.access$1600(objx, gen, this.b);
/*      */     }
/*      */     
/*      */     public void emit(Compiler.C context, Compiler.ObjExpr objx, GeneratorAdapter gen) {
/* 5955 */       if (context != Compiler.C.STATEMENT)
/* 5956 */         Compiler.ObjExpr.access$1700(objx, gen, this.b, this.shouldClear);
/*      */     }
/*      */     
/*      */     public Object evalAssign(Compiler.Expr val) {
/* 5960 */       throw new UnsupportedOperationException("Can't eval locals");
/*      */     }
/*      */     
/*      */     public void emitAssign(Compiler.C context, Compiler.ObjExpr objx, GeneratorAdapter gen, Compiler.Expr val) {
/* 5964 */       objx.emitAssignLocal(gen, this.b, val);
/* 5965 */       if (context != Compiler.C.STATEMENT)
/* 5966 */         Compiler.ObjExpr.access$1700(objx, gen, this.b, false);
/*      */     }
/*      */     
/*      */     public boolean hasJavaClass() {
/* 5970 */       return (this.tag != null) || (this.b.hasJavaClass());
/*      */     }
/*      */     
/*      */     public Class getJavaClass() {
/* 5974 */       if (this.tag != null)
/* 5975 */         return Compiler.HostExpr.tagToClass(this.tag);
/* 5976 */       return this.b.getJavaClass();
/*      */     }
/*      */   }
/*      */   
/*      */   public static class BodyExpr implements Compiler.Expr, Compiler.MaybePrimitiveExpr
/*      */   {
/*      */     PersistentVector exprs;
/*      */     
/*      */     public final PersistentVector exprs()
/*      */     {
/* 5986 */       return this.exprs;
/*      */     }
/*      */     
/*      */     public BodyExpr(PersistentVector exprs) {
/* 5990 */       this.exprs = exprs;
/*      */     }
/*      */     
/*      */     static class Parser implements Compiler.IParser {
/*      */       public Compiler.Expr parse(Compiler.C context, Object frms) {
/* 5995 */         ISeq forms = (ISeq)frms;
/* 5996 */         if (Util.equals(RT.first(forms), Compiler.DO))
/* 5997 */           forms = RT.next(forms);
/* 5998 */         PersistentVector exprs = PersistentVector.EMPTY;
/* 5999 */         for (; forms != null; forms = forms.next())
/*      */         {
/* 6001 */           Compiler.Expr e = (context != Compiler.C.EVAL) && ((context == Compiler.C.STATEMENT) || (forms.next() != null)) ? Compiler.analyze(Compiler.C.STATEMENT, forms.first()) : Compiler.analyze(context, forms.first());
/*      */           
/*      */ 
/*      */ 
/*      */ 
/* 6006 */           exprs = exprs.cons(e);
/*      */         }
/* 6008 */         if (exprs.count() == 0)
/* 6009 */           exprs = exprs.cons(Compiler.NIL_EXPR);
/* 6010 */         return new Compiler.BodyExpr(exprs);
/*      */       }
/*      */     }
/*      */     
/*      */     public Object eval() {
/* 6015 */       Object ret = null;
/* 6016 */       for (Object o : this.exprs)
/*      */       {
/* 6018 */         Compiler.Expr e = (Compiler.Expr)o;
/* 6019 */         ret = e.eval();
/*      */       }
/* 6021 */       return ret;
/*      */     }
/*      */     
/*      */     public boolean canEmitPrimitive() {
/* 6025 */       return ((lastExpr() instanceof Compiler.MaybePrimitiveExpr)) && (((Compiler.MaybePrimitiveExpr)lastExpr()).canEmitPrimitive());
/*      */     }
/*      */     
/*      */     public void emitUnboxed(Compiler.C context, Compiler.ObjExpr objx, GeneratorAdapter gen) {
/* 6029 */       for (int i = 0; i < this.exprs.count() - 1; i++)
/*      */       {
/* 6031 */         Compiler.Expr e = (Compiler.Expr)this.exprs.nth(i);
/* 6032 */         e.emit(Compiler.C.STATEMENT, objx, gen);
/*      */       }
/* 6034 */       Compiler.MaybePrimitiveExpr last = (Compiler.MaybePrimitiveExpr)this.exprs.nth(this.exprs.count() - 1);
/* 6035 */       last.emitUnboxed(context, objx, gen);
/*      */     }
/*      */     
/*      */     public void emit(Compiler.C context, Compiler.ObjExpr objx, GeneratorAdapter gen) {
/* 6039 */       for (int i = 0; i < this.exprs.count() - 1; i++)
/*      */       {
/* 6041 */         Compiler.Expr e = (Compiler.Expr)this.exprs.nth(i);
/* 6042 */         e.emit(Compiler.C.STATEMENT, objx, gen);
/*      */       }
/* 6044 */       Compiler.Expr last = (Compiler.Expr)this.exprs.nth(this.exprs.count() - 1);
/* 6045 */       last.emit(context, objx, gen);
/*      */     }
/*      */     
/*      */     public boolean hasJavaClass() {
/* 6049 */       return lastExpr().hasJavaClass();
/*      */     }
/*      */     
/*      */     public Class getJavaClass() {
/* 6053 */       return lastExpr().getJavaClass();
/*      */     }
/*      */     
/*      */     private Compiler.Expr lastExpr() {
/* 6057 */       return (Compiler.Expr)this.exprs.nth(this.exprs.count() - 1);
/*      */     }
/*      */   }
/*      */   
/*      */   public static class BindingInit {
/*      */     Compiler.LocalBinding binding;
/*      */     Compiler.Expr init;
/*      */     
/*      */     public final Compiler.LocalBinding binding() {
/* 6066 */       return this.binding;
/*      */     }
/*      */     
/*      */     public final Compiler.Expr init() {
/* 6070 */       return this.init;
/*      */     }
/*      */     
/*      */     public BindingInit(Compiler.LocalBinding binding, Compiler.Expr init) {
/* 6074 */       this.binding = binding;
/* 6075 */       this.init = init;
/*      */     }
/*      */   }
/*      */   
/*      */   public static class LetFnExpr implements Compiler.Expr {
/*      */     public final PersistentVector bindingInits;
/*      */     public final Compiler.Expr body;
/*      */     
/*      */     public LetFnExpr(PersistentVector bindingInits, Compiler.Expr body) {
/* 6084 */       this.bindingInits = bindingInits;
/* 6085 */       this.body = body;
/*      */     }
/*      */     
/*      */     static class Parser implements Compiler.IParser {
/*      */       public Compiler.Expr parse(Compiler.C context, Object frm) {
/* 6090 */         ISeq form = (ISeq)frm;
/*      */         
/* 6092 */         if (!(RT.second(form) instanceof IPersistentVector)) {
/* 6093 */           throw new IllegalArgumentException("Bad binding form, expected vector");
/*      */         }
/* 6095 */         IPersistentVector bindings = (IPersistentVector)RT.second(form);
/* 6096 */         if (bindings.count() % 2 != 0) {
/* 6097 */           throw new IllegalArgumentException("Bad binding form, expected matched symbol expression pairs");
/*      */         }
/* 6099 */         ISeq body = RT.next(RT.next(form));
/*      */         
/* 6101 */         if (context == Compiler.C.EVAL) {
/* 6102 */           return Compiler.analyze(context, RT.list(RT.list(Compiler.FNONCE, PersistentVector.EMPTY, form)));
/*      */         }
/* 6104 */         IPersistentMap dynamicBindings = RT.map(new Object[] { Compiler.LOCAL_ENV, Compiler.LOCAL_ENV.deref(), Compiler.NEXT_LOCAL_NUM, Compiler.NEXT_LOCAL_NUM.deref() });
/*      */         
/*      */ 
/*      */         try
/*      */         {
/* 6109 */           Var.pushThreadBindings(dynamicBindings);
/*      */           
/*      */ 
/* 6112 */           PersistentVector lbs = PersistentVector.EMPTY;
/* 6113 */           for (int i = 0; i < bindings.count(); i += 2)
/*      */           {
/* 6115 */             if (!(bindings.nth(i) instanceof Symbol)) {
/* 6116 */               throw new IllegalArgumentException("Bad binding form, expected symbol, got: " + bindings.nth(i));
/*      */             }
/* 6118 */             Symbol sym = (Symbol)bindings.nth(i);
/* 6119 */             if (sym.getNamespace() != null)
/* 6120 */               throw Util.runtimeException("Can't let qualified name: " + sym);
/* 6121 */             Compiler.LocalBinding lb = Compiler.registerLocal(sym, Compiler.access$600(sym), null, false);
/* 6122 */             lb.canBeCleared = false;
/* 6123 */             lbs = lbs.cons(lb);
/*      */           }
/* 6125 */           PersistentVector bindingInits = PersistentVector.EMPTY;
/* 6126 */           for (int i = 0; i < bindings.count(); i += 2)
/*      */           {
/* 6128 */             Symbol sym = (Symbol)bindings.nth(i);
/* 6129 */             Compiler.Expr init = Compiler.analyze(Compiler.C.EXPRESSION, bindings.nth(i + 1), sym.name);
/* 6130 */             Compiler.LocalBinding lb = (Compiler.LocalBinding)lbs.nth(i / 2);
/* 6131 */             lb.init = init;
/* 6132 */             Compiler.BindingInit bi = new Compiler.BindingInit(lb, init);
/* 6133 */             bindingInits = bindingInits.cons(bi);
/*      */           }
/* 6135 */           return new Compiler.LetFnExpr(bindingInits, new Compiler.BodyExpr.Parser().parse(context, body));
/*      */         }
/*      */         finally
/*      */         {
/* 6139 */           Var.popThreadBindings();
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */     public Object eval() {
/* 6145 */       throw new UnsupportedOperationException("Can't eval letfns");
/*      */     }
/*      */     
/*      */     public void emit(Compiler.C context, Compiler.ObjExpr objx, GeneratorAdapter gen) {
/* 6149 */       for (int i = 0; i < this.bindingInits.count(); i++)
/*      */       {
/* 6151 */         Compiler.BindingInit bi = (Compiler.BindingInit)this.bindingInits.nth(i);
/* 6152 */         gen.visitInsn(1);
/* 6153 */         gen.visitVarInsn(Compiler.OBJECT_TYPE.getOpcode(54), bi.binding.idx);
/*      */       }
/*      */       
/* 6156 */       IPersistentSet lbset = PersistentHashSet.EMPTY;
/*      */       
/* 6158 */       for (int i = 0; i < this.bindingInits.count(); i++)
/*      */       {
/* 6160 */         Compiler.BindingInit bi = (Compiler.BindingInit)this.bindingInits.nth(i);
/* 6161 */         lbset = (IPersistentSet)lbset.cons(bi.binding);
/* 6162 */         bi.init.emit(Compiler.C.EXPRESSION, objx, gen);
/* 6163 */         gen.visitVarInsn(Compiler.OBJECT_TYPE.getOpcode(54), bi.binding.idx);
/*      */       }
/*      */       
/* 6166 */       for (int i = 0; i < this.bindingInits.count(); i++)
/*      */       {
/* 6168 */         Compiler.BindingInit bi = (Compiler.BindingInit)this.bindingInits.nth(i);
/* 6169 */         Compiler.ObjExpr fe = (Compiler.ObjExpr)bi.init;
/* 6170 */         gen.visitVarInsn(Compiler.OBJECT_TYPE.getOpcode(21), bi.binding.idx);
/* 6171 */         fe.emitLetFnInits(gen, objx, lbset);
/*      */       }
/*      */       
/* 6174 */       Label loopLabel = gen.mark();
/*      */       
/* 6176 */       this.body.emit(context, objx, gen);
/*      */       
/* 6178 */       Label end = gen.mark();
/*      */       
/* 6180 */       for (ISeq bis = this.bindingInits.seq(); bis != null; bis = bis.next())
/*      */       {
/* 6182 */         Compiler.BindingInit bi = (Compiler.BindingInit)bis.first();
/* 6183 */         String lname = bi.binding.name;
/* 6184 */         if (lname.endsWith("__auto__"))
/* 6185 */           lname = lname + RT.nextID();
/* 6186 */         Class primc = Compiler.maybePrimitiveType(bi.init);
/* 6187 */         if (primc != null) {
/* 6188 */           gen.visitLocalVariable(lname, Type.getDescriptor(primc), null, loopLabel, end, bi.binding.idx);
/*      */         }
/*      */         else
/* 6191 */           gen.visitLocalVariable(lname, "Ljava/lang/Object;", null, loopLabel, end, bi.binding.idx);
/*      */       }
/*      */     }
/*      */     
/*      */     public boolean hasJavaClass() {
/* 6196 */       return this.body.hasJavaClass();
/*      */     }
/*      */     
/*      */     public Class getJavaClass() {
/* 6200 */       return this.body.getJavaClass();
/*      */     }
/*      */   }
/*      */   
/*      */   public static class LetExpr implements Compiler.Expr, Compiler.MaybePrimitiveExpr {
/*      */     public final PersistentVector bindingInits;
/*      */     public final Compiler.Expr body;
/*      */     public final boolean isLoop;
/*      */     
/*      */     public LetExpr(PersistentVector bindingInits, Compiler.Expr body, boolean isLoop) {
/* 6210 */       this.bindingInits = bindingInits;
/* 6211 */       this.body = body;
/* 6212 */       this.isLoop = isLoop;
/*      */     }
/*      */     
/*      */     static class Parser implements Compiler.IParser {
/*      */       public Compiler.Expr parse(Compiler.C context, Object frm) {
/* 6217 */         ISeq form = (ISeq)frm;
/*      */         
/* 6219 */         boolean isLoop = RT.first(form).equals(Compiler.LOOP);
/* 6220 */         if (!(RT.second(form) instanceof IPersistentVector)) {
/* 6221 */           throw new IllegalArgumentException("Bad binding form, expected vector");
/*      */         }
/* 6223 */         IPersistentVector bindings = (IPersistentVector)RT.second(form);
/* 6224 */         if (bindings.count() % 2 != 0) {
/* 6225 */           throw new IllegalArgumentException("Bad binding form, expected matched symbol expression pairs");
/*      */         }
/* 6227 */         ISeq body = RT.next(RT.next(form));
/*      */         
/* 6229 */         if ((context == Compiler.C.EVAL) || ((context == Compiler.C.EXPRESSION) && (isLoop)))
/*      */         {
/* 6231 */           return Compiler.analyze(context, RT.list(RT.list(Compiler.FNONCE, PersistentVector.EMPTY, form)));
/*      */         }
/* 6233 */         Compiler.ObjMethod method = (Compiler.ObjMethod)Compiler.METHOD.deref();
/* 6234 */         IPersistentMap backupMethodLocals = method.locals;
/* 6235 */         IPersistentMap backupMethodIndexLocals = method.indexlocals;
/* 6236 */         IPersistentVector recurMismatches = PersistentVector.EMPTY;
/* 6237 */         for (int i = 0; i < bindings.count() / 2; i++)
/*      */         {
/* 6239 */           recurMismatches = recurMismatches.cons(RT.F);
/*      */         }
/*      */         
/*      */         for (;;)
/*      */         {
/* 6244 */           IPersistentMap dynamicBindings = RT.map(new Object[] { Compiler.LOCAL_ENV, Compiler.LOCAL_ENV.deref(), Compiler.NEXT_LOCAL_NUM, Compiler.NEXT_LOCAL_NUM.deref() });
/*      */           
/* 6246 */           method.locals = backupMethodLocals;
/* 6247 */           method.indexlocals = backupMethodIndexLocals;
/*      */           
/* 6249 */           Compiler.PathNode looproot = new Compiler.PathNode(Compiler.PATHTYPE.PATH, (Compiler.PathNode)Compiler.CLEAR_PATH.get());
/* 6250 */           Compiler.PathNode clearroot = new Compiler.PathNode(Compiler.PATHTYPE.PATH, looproot);
/* 6251 */           Compiler.PathNode clearpath = new Compiler.PathNode(Compiler.PATHTYPE.PATH, looproot);
/* 6252 */           if (isLoop) {
/* 6253 */             dynamicBindings = dynamicBindings.assoc(Compiler.LOOP_LOCALS, null);
/*      */           }
/*      */           try
/*      */           {
/* 6257 */             Var.pushThreadBindings(dynamicBindings);
/*      */             
/* 6259 */             PersistentVector bindingInits = PersistentVector.EMPTY;
/* 6260 */             PersistentVector loopLocals = PersistentVector.EMPTY;
/* 6261 */             for (int i = 0; i < bindings.count(); i += 2)
/*      */             {
/* 6263 */               if (!(bindings.nth(i) instanceof Symbol)) {
/* 6264 */                 throw new IllegalArgumentException("Bad binding form, expected symbol, got: " + bindings.nth(i));
/*      */               }
/* 6266 */               Symbol sym = (Symbol)bindings.nth(i);
/* 6267 */               if (sym.getNamespace() != null)
/* 6268 */                 throw Util.runtimeException("Can't let qualified name: " + sym);
/* 6269 */               Compiler.Expr init = Compiler.analyze(Compiler.C.EXPRESSION, bindings.nth(i + 1), sym.name);
/* 6270 */               if (isLoop)
/*      */               {
/* 6272 */                 if ((recurMismatches != null) && (RT.booleanCast(recurMismatches.nth(i / 2))))
/*      */                 {
/* 6274 */                   init = new Compiler.StaticMethodExpr("", 0, 0, null, RT.class, "box", RT.vector(new Object[] { init }));
/* 6275 */                   if (RT.booleanCast(RT.WARN_ON_REFLECTION.deref())) {
/* 6276 */                     RT.errPrintWriter().println("Auto-boxing loop arg: " + sym);
/*      */                   }
/* 6278 */                 } else if (Compiler.maybePrimitiveType(init) == Integer.TYPE) {
/* 6279 */                   init = new Compiler.StaticMethodExpr("", 0, 0, null, RT.class, "longCast", RT.vector(new Object[] { init }));
/* 6280 */                 } else if (Compiler.maybePrimitiveType(init) == Float.TYPE) {
/* 6281 */                   init = new Compiler.StaticMethodExpr("", 0, 0, null, RT.class, "doubleCast", RT.vector(new Object[] { init }));
/*      */                 }
/*      */               }
/*      */               try
/*      */               {
/* 6286 */                 if (isLoop)
/*      */                 {
/* 6288 */                   Var.pushThreadBindings(RT.map(new Object[] { Compiler.CLEAR_PATH, clearpath, Compiler.CLEAR_ROOT, clearroot, Compiler.NO_RECUR, null }));
/*      */                 }
/*      */                 
/*      */ 
/*      */ 
/*      */ 
/* 6294 */                 Compiler.LocalBinding lb = Compiler.registerLocal(sym, Compiler.access$600(sym), init, false);
/* 6295 */                 Compiler.BindingInit bi = new Compiler.BindingInit(lb, init);
/* 6296 */                 bindingInits = bindingInits.cons(bi);
/* 6297 */                 if (isLoop) {
/* 6298 */                   loopLocals = loopLocals.cons(lb);
/*      */                 }
/*      */               }
/*      */               finally {
/* 6302 */                 if (!isLoop) {}
/*      */               }
/*      */             }
/*      */             
/* 6306 */             if (isLoop) {
/* 6307 */               Compiler.LOOP_LOCALS.set(loopLocals);
/*      */             }
/* 6309 */             boolean moreMismatches = false;
/*      */             Compiler.Expr bodyExpr;
/* 6311 */             int i; try { if (isLoop)
/*      */               {
/* 6313 */                 Var.pushThreadBindings(RT.map(new Object[] { Compiler.CLEAR_PATH, clearpath, Compiler.CLEAR_ROOT, clearroot, Compiler.NO_RECUR, null }));
/*      */               }
/*      */               
/*      */ 
/*      */ 
/*      */ 
/* 6319 */               bodyExpr = new Compiler.BodyExpr.Parser().parse(isLoop ? Compiler.C.RETURN : context, body);
/*      */             } finally {
/*      */               Compiler.LocalBinding lb;
/* 6322 */               if (isLoop)
/*      */               {
/* 6324 */                 Var.popThreadBindings();
/* 6325 */                 for (int i = 0; i < loopLocals.count(); i++)
/*      */                 {
/* 6327 */                   Compiler.LocalBinding lb = (Compiler.LocalBinding)loopLocals.nth(i);
/* 6328 */                   if (lb.recurMistmatch)
/*      */                   {
/* 6330 */                     recurMismatches = (IPersistentVector)recurMismatches.assoc(Integer.valueOf(i), RT.T);
/* 6331 */                     moreMismatches = true;
/*      */                   }
/*      */                 }
/*      */               }
/*      */             }
/* 6336 */             if (!moreMismatches) {
/* 6337 */               return new Compiler.LetExpr(bindingInits, bodyExpr, isLoop);
/*      */             }
/*      */           }
/*      */           finally {
/* 6341 */             Var.popThreadBindings();
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */     public Object eval() {
/* 6348 */       throw new UnsupportedOperationException("Can't eval let/loop");
/*      */     }
/*      */     
/*      */     public void emit(Compiler.C context, Compiler.ObjExpr objx, GeneratorAdapter gen) {
/* 6352 */       doEmit(context, objx, gen, false);
/*      */     }
/*      */     
/*      */     public void emitUnboxed(Compiler.C context, Compiler.ObjExpr objx, GeneratorAdapter gen) {
/* 6356 */       doEmit(context, objx, gen, true);
/*      */     }
/*      */     
/*      */     public void doEmit(Compiler.C context, Compiler.ObjExpr objx, GeneratorAdapter gen, boolean emitUnboxed)
/*      */     {
/* 6361 */       HashMap<Compiler.BindingInit, Label> bindingLabels = new HashMap();
/* 6362 */       for (int i = 0; i < this.bindingInits.count(); i++)
/*      */       {
/* 6364 */         Compiler.BindingInit bi = (Compiler.BindingInit)this.bindingInits.nth(i);
/* 6365 */         Class primc = Compiler.maybePrimitiveType(bi.init);
/* 6366 */         if (primc != null)
/*      */         {
/* 6368 */           ((Compiler.MaybePrimitiveExpr)bi.init).emitUnboxed(Compiler.C.EXPRESSION, objx, gen);
/* 6369 */           gen.visitVarInsn(Type.getType(primc).getOpcode(54), bi.binding.idx);
/*      */         }
/*      */         else
/*      */         {
/* 6373 */           bi.init.emit(Compiler.C.EXPRESSION, objx, gen);
/* 6374 */           gen.visitVarInsn(Compiler.OBJECT_TYPE.getOpcode(54), bi.binding.idx);
/*      */         }
/* 6376 */         bindingLabels.put(bi, gen.mark());
/*      */       }
/* 6378 */       Label loopLabel = gen.mark();
/* 6379 */       if (this.isLoop)
/*      */       {
/*      */         try
/*      */         {
/* 6383 */           Var.pushThreadBindings(RT.map(new Object[] { Compiler.LOOP_LABEL, loopLabel }));
/* 6384 */           if (emitUnboxed) {
/* 6385 */             ((Compiler.MaybePrimitiveExpr)this.body).emitUnboxed(context, objx, gen);
/*      */           } else {
/* 6387 */             this.body.emit(context, objx, gen);
/*      */           }
/*      */         }
/*      */         finally {
/* 6391 */           Var.popThreadBindings();
/*      */ 
/*      */         }
/*      */         
/*      */       }
/* 6396 */       else if (emitUnboxed) {
/* 6397 */         ((Compiler.MaybePrimitiveExpr)this.body).emitUnboxed(context, objx, gen);
/*      */       } else {
/* 6399 */         this.body.emit(context, objx, gen);
/*      */       }
/* 6401 */       Label end = gen.mark();
/*      */       
/* 6403 */       for (ISeq bis = this.bindingInits.seq(); bis != null; bis = bis.next())
/*      */       {
/* 6405 */         Compiler.BindingInit bi = (Compiler.BindingInit)bis.first();
/* 6406 */         String lname = bi.binding.name;
/* 6407 */         if (lname.endsWith("__auto__"))
/* 6408 */           lname = lname + RT.nextID();
/* 6409 */         Class primc = Compiler.maybePrimitiveType(bi.init);
/* 6410 */         if (primc != null) {
/* 6411 */           gen.visitLocalVariable(lname, Type.getDescriptor(primc), null, (Label)bindingLabels.get(bi), end, bi.binding.idx);
/*      */         }
/*      */         else
/* 6414 */           gen.visitLocalVariable(lname, "Ljava/lang/Object;", null, (Label)bindingLabels.get(bi), end, bi.binding.idx);
/*      */       }
/*      */     }
/*      */     
/*      */     public boolean hasJavaClass() {
/* 6419 */       return this.body.hasJavaClass();
/*      */     }
/*      */     
/*      */     public Class getJavaClass() {
/* 6423 */       return this.body.getJavaClass();
/*      */     }
/*      */     
/*      */     public boolean canEmitPrimitive() {
/* 6427 */       return ((this.body instanceof Compiler.MaybePrimitiveExpr)) && (((Compiler.MaybePrimitiveExpr)this.body).canEmitPrimitive());
/*      */     }
/*      */   }
/*      */   
/*      */   public static class RecurExpr implements Compiler.Expr, Compiler.MaybePrimitiveExpr
/*      */   {
/*      */     public final IPersistentVector args;
/*      */     public final IPersistentVector loopLocals;
/*      */     final int line;
/*      */     final int column;
/*      */     final String source;
/*      */     
/*      */     public RecurExpr(IPersistentVector loopLocals, IPersistentVector args, int line, int column, String source)
/*      */     {
/* 6441 */       this.loopLocals = loopLocals;
/* 6442 */       this.args = args;
/* 6443 */       this.line = line;
/* 6444 */       this.column = column;
/* 6445 */       this.source = source;
/*      */     }
/*      */     
/*      */     public Object eval() {
/* 6449 */       throw new UnsupportedOperationException("Can't eval recur");
/*      */     }
/*      */     
/*      */     public void emit(Compiler.C context, Compiler.ObjExpr objx, GeneratorAdapter gen) {
/* 6453 */       Label loopLabel = (Label)Compiler.LOOP_LABEL.deref();
/* 6454 */       if (loopLabel == null)
/* 6455 */         throw new IllegalStateException();
/* 6456 */       for (int i = 0; i < this.loopLocals.count(); i++)
/*      */       {
/* 6458 */         Compiler.LocalBinding lb = (Compiler.LocalBinding)this.loopLocals.nth(i);
/* 6459 */         Compiler.Expr arg = (Compiler.Expr)this.args.nth(i);
/* 6460 */         if (lb.getPrimitiveType() != null)
/*      */         {
/* 6462 */           Class primc = lb.getPrimitiveType();
/* 6463 */           Class pc = Compiler.maybePrimitiveType(arg);
/* 6464 */           if (pc == primc) {
/* 6465 */             ((Compiler.MaybePrimitiveExpr)arg).emitUnboxed(Compiler.C.EXPRESSION, objx, gen);
/* 6466 */           } else if ((primc == Long.TYPE) && (pc == Integer.TYPE))
/*      */           {
/* 6468 */             ((Compiler.MaybePrimitiveExpr)arg).emitUnboxed(Compiler.C.EXPRESSION, objx, gen);
/* 6469 */             gen.visitInsn(133);
/*      */           }
/* 6471 */           else if ((primc == Double.TYPE) && (pc == Float.TYPE))
/*      */           {
/* 6473 */             ((Compiler.MaybePrimitiveExpr)arg).emitUnboxed(Compiler.C.EXPRESSION, objx, gen);
/* 6474 */             gen.visitInsn(141);
/*      */           }
/* 6476 */           else if ((primc == Integer.TYPE) && (pc == Long.TYPE))
/*      */           {
/* 6478 */             ((Compiler.MaybePrimitiveExpr)arg).emitUnboxed(Compiler.C.EXPRESSION, objx, gen);
/* 6479 */             gen.invokeStatic(Compiler.RT_TYPE, clojure.asm.commons.Method.getMethod("int intCast(long)"));
/*      */           }
/* 6481 */           else if ((primc == Float.TYPE) && (pc == Double.TYPE))
/*      */           {
/* 6483 */             ((Compiler.MaybePrimitiveExpr)arg).emitUnboxed(Compiler.C.EXPRESSION, objx, gen);
/* 6484 */             gen.visitInsn(144);
/*      */ 
/*      */           }
/*      */           else
/*      */           {
/* 6489 */             throw new IllegalArgumentException(" recur arg for primitive local: " + lb.name + " is not matching primitive, had: " + (arg.hasJavaClass() ? arg.getJavaClass().getName() : "Object") + ", needed: " + primc.getName());
/*      */ 
/*      */ 
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/* 6503 */           arg.emit(Compiler.C.EXPRESSION, objx, gen);
/*      */         }
/*      */       }
/*      */       
/* 6507 */       for (int i = this.loopLocals.count() - 1; i >= 0; i--)
/*      */       {
/* 6509 */         Compiler.LocalBinding lb = (Compiler.LocalBinding)this.loopLocals.nth(i);
/* 6510 */         Class primc = lb.getPrimitiveType();
/* 6511 */         if (lb.isArg) {
/* 6512 */           gen.storeArg(lb.idx - (objx.canBeDirect ? 0 : 1));
/*      */ 
/*      */         }
/* 6515 */         else if (primc != null) {
/* 6516 */           gen.visitVarInsn(Type.getType(primc).getOpcode(54), lb.idx);
/*      */         } else {
/* 6518 */           gen.visitVarInsn(Compiler.OBJECT_TYPE.getOpcode(54), lb.idx);
/*      */         }
/*      */       }
/*      */       
/* 6522 */       gen.goTo(loopLabel);
/*      */     }
/*      */     
/*      */     public boolean hasJavaClass() {
/* 6526 */       return true;
/*      */     }
/*      */     
/*      */     public Class getJavaClass() {
/* 6530 */       return Compiler.RECUR_CLASS;
/*      */     }
/*      */     
/*      */     static class Parser implements Compiler.IParser {
/*      */       public Compiler.Expr parse(Compiler.C context, Object frm) {
/* 6535 */         int line = Compiler.lineDeref();
/* 6536 */         int column = Compiler.columnDeref();
/* 6537 */         String source = (String)Compiler.SOURCE.deref();
/*      */         
/* 6539 */         ISeq form = (ISeq)frm;
/* 6540 */         IPersistentVector loopLocals = (IPersistentVector)Compiler.LOOP_LOCALS.deref();
/* 6541 */         if ((context != Compiler.C.RETURN) || (loopLocals == null))
/* 6542 */           throw new UnsupportedOperationException("Can only recur from tail position");
/* 6543 */         if (Compiler.NO_RECUR.deref() != null)
/* 6544 */           throw new UnsupportedOperationException("Cannot recur across try");
/* 6545 */         PersistentVector args = PersistentVector.EMPTY;
/* 6546 */         for (ISeq s = RT.seq(form.next()); s != null; s = s.next())
/*      */         {
/* 6548 */           args = args.cons(Compiler.analyze(Compiler.C.EXPRESSION, s.first()));
/*      */         }
/* 6550 */         if (args.count() != loopLocals.count()) {
/* 6551 */           throw new IllegalArgumentException(String.format("Mismatched argument count to recur, expected: %d args, got: %d", new Object[] { Integer.valueOf(loopLocals.count()), Integer.valueOf(args.count()) }));
/*      */         }
/*      */         
/* 6554 */         for (int i = 0; i < loopLocals.count(); i++)
/*      */         {
/* 6556 */           Compiler.LocalBinding lb = (Compiler.LocalBinding)loopLocals.nth(i);
/* 6557 */           Class primc = lb.getPrimitiveType();
/* 6558 */           if (primc != null)
/*      */           {
/* 6560 */             boolean mismatch = false;
/* 6561 */             Class pc = Compiler.maybePrimitiveType((Compiler.Expr)args.nth(i));
/* 6562 */             if (primc == Long.TYPE)
/*      */             {
/* 6564 */               if ((pc != Long.TYPE) && (pc != Integer.TYPE) && (pc != Short.TYPE) && (pc != Character.TYPE) && (pc != Byte.TYPE))
/*      */               {
/*      */ 
/*      */ 
/*      */ 
/* 6569 */                 mismatch = true;
/*      */               }
/* 6571 */             } else if (primc == Double.TYPE)
/*      */             {
/* 6573 */               if ((pc != Double.TYPE) && (pc != Float.TYPE))
/*      */               {
/* 6575 */                 mismatch = true; }
/*      */             }
/* 6577 */             if (mismatch)
/*      */             {
/* 6579 */               lb.recurMistmatch = true;
/* 6580 */               if (RT.booleanCast(RT.WARN_ON_REFLECTION.deref())) {
/* 6581 */                 RT.errPrintWriter().println(source + ":" + line + " recur arg for primitive local: " + lb.name + " is not matching primitive, had: " + (pc != null ? pc.getName() : "Object") + ", needed: " + primc.getName());
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6591 */         return new Compiler.RecurExpr(loopLocals, args, line, column, source);
/*      */       }
/*      */     }
/*      */     
/*      */     public boolean canEmitPrimitive() {
/* 6596 */       return true;
/*      */     }
/*      */     
/*      */     public void emitUnboxed(Compiler.C context, Compiler.ObjExpr objx, GeneratorAdapter gen) {
/* 6600 */       emit(context, objx, gen);
/*      */     }
/*      */   }
/*      */   
/*      */   private static LocalBinding registerLocal(Symbol sym, Symbol tag, Expr init, boolean isArg) {
/* 6605 */     int num = getAndIncLocalNum();
/* 6606 */     LocalBinding b = new LocalBinding(num, sym, tag, init, isArg, clearPathRoot());
/* 6607 */     IPersistentMap localsMap = (IPersistentMap)LOCAL_ENV.deref();
/* 6608 */     LOCAL_ENV.set(RT.assoc(localsMap, b.sym, b));
/* 6609 */     ObjMethod method = (ObjMethod)METHOD.deref();
/* 6610 */     method.locals = ((IPersistentMap)RT.assoc(method.locals, b, b));
/* 6611 */     method.indexlocals = ((IPersistentMap)RT.assoc(method.indexlocals, Integer.valueOf(num), b));
/* 6612 */     return b;
/*      */   }
/*      */   
/*      */   private static int getAndIncLocalNum() {
/* 6616 */     int num = ((Number)NEXT_LOCAL_NUM.deref()).intValue();
/* 6617 */     ObjMethod m = (ObjMethod)METHOD.deref();
/* 6618 */     if (num > m.maxLocal)
/* 6619 */       m.maxLocal = num;
/* 6620 */     NEXT_LOCAL_NUM.set(Integer.valueOf(num + 1));
/* 6621 */     return num;
/*      */   }
/*      */   
/*      */   public static Expr analyze(C context, Object form) {
/* 6625 */     return analyze(context, form, null);
/*      */   }
/*      */   
/*      */   private static Expr analyze(C context, Object form, String name)
/*      */   {
/*      */     try
/*      */     {
/* 6632 */       if ((form instanceof LazySeq))
/*      */       {
/* 6634 */         Object mform = form;
/* 6635 */         form = RT.seq(form);
/* 6636 */         if (form == null)
/* 6637 */           form = PersistentList.EMPTY;
/* 6638 */         form = ((IObj)form).withMeta(RT.meta(mform));
/*      */       }
/* 6640 */       if (form == null)
/* 6641 */         return NIL_EXPR;
/* 6642 */       if (form == Boolean.TRUE)
/* 6643 */         return TRUE_EXPR;
/* 6644 */       if (form == Boolean.FALSE)
/* 6645 */         return FALSE_EXPR;
/* 6646 */       Class fclass = form.getClass();
/* 6647 */       if (fclass == Symbol.class)
/* 6648 */         return analyzeSymbol((Symbol)form);
/* 6649 */       if (fclass == Keyword.class)
/* 6650 */         return registerKeyword((Keyword)form);
/* 6651 */       if ((form instanceof Number))
/* 6652 */         return NumberExpr.parse((Number)form);
/* 6653 */       if (fclass == String.class) {
/* 6654 */         return new StringExpr(((String)form).intern());
/*      */       }
/*      */       
/* 6657 */       if (((form instanceof IPersistentCollection)) && (!(form instanceof IRecord)) && (!(form instanceof IType)) && (((IPersistentCollection)form).count() == 0))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/* 6662 */         Expr ret = new EmptyExpr(form);
/* 6663 */         if (RT.meta(form) != null) {}
/* 6664 */         return new MetaExpr(ret, MapExpr.parse(context == C.EVAL ? context : C.EXPRESSION, ((IObj)form).meta()));
/*      */       }
/*      */       
/*      */ 
/* 6668 */       if ((form instanceof ISeq))
/* 6669 */         return analyzeSeq(context, (ISeq)form, name);
/* 6670 */       if ((form instanceof IPersistentVector))
/* 6671 */         return VectorExpr.parse(context, (IPersistentVector)form);
/* 6672 */       if ((form instanceof IRecord))
/* 6673 */         return new ConstantExpr(form);
/* 6674 */       if ((form instanceof IType))
/* 6675 */         return new ConstantExpr(form);
/* 6676 */       if ((form instanceof IPersistentMap))
/* 6677 */         return MapExpr.parse(context, (IPersistentMap)form);
/* 6678 */       if ((form instanceof IPersistentSet)) {
/* 6679 */         return SetExpr.parse(context, (IPersistentSet)form);
/*      */       }
/*      */       
/*      */ 
/* 6683 */       return new ConstantExpr(form);
/*      */     }
/*      */     catch (Throwable e)
/*      */     {
/* 6687 */       if (!(e instanceof CompilerException)) {
/* 6688 */         throw new CompilerException((String)SOURCE_PATH.deref(), lineDeref(), columnDeref(), e);
/*      */       }
/* 6690 */       throw ((CompilerException)e);
/*      */     }
/*      */   }
/*      */   
/*      */   public static class CompilerException extends RuntimeException
/*      */   {
/*      */     public final String source;
/*      */     public final int line;
/*      */     
/*      */     public CompilerException(String source, int line, int column, Throwable cause) {
/* 6700 */       super(cause);
/* 6701 */       this.source = source;
/* 6702 */       this.line = line;
/*      */     }
/*      */     
/*      */     public String toString() {
/* 6706 */       return getMessage();
/*      */     }
/*      */   }
/*      */   
/*      */   public static Var isMacro(Object op)
/*      */   {
/* 6712 */     if (((op instanceof Symbol)) && (referenceLocal((Symbol)op) != null))
/* 6713 */       return null;
/* 6714 */     if (((op instanceof Symbol)) || ((op instanceof Var)))
/*      */     {
/* 6716 */       Var v = (op instanceof Var) ? (Var)op : lookupVar((Symbol)op, false, false);
/* 6717 */       if ((v != null) && (v.isMacro()))
/*      */       {
/* 6719 */         if ((v.ns != currentNS()) && (!v.isPublic()))
/* 6720 */           throw new IllegalStateException("var: " + v + " is not public");
/* 6721 */         return v;
/*      */       }
/*      */     }
/* 6724 */     return null;
/*      */   }
/*      */   
/*      */   public static IFn isInline(Object op, int arity)
/*      */   {
/* 6729 */     if (((op instanceof Symbol)) && (referenceLocal((Symbol)op) != null))
/* 6730 */       return null;
/* 6731 */     if (((op instanceof Symbol)) || ((op instanceof Var)))
/*      */     {
/* 6733 */       Var v = (op instanceof Var) ? (Var)op : lookupVar((Symbol)op, false);
/* 6734 */       if (v != null)
/*      */       {
/* 6736 */         if ((v.ns != currentNS()) && (!v.isPublic()))
/* 6737 */           throw new IllegalStateException("var: " + v + " is not public");
/* 6738 */         IFn ret = (IFn)RT.get(v.meta(), inlineKey);
/* 6739 */         if (ret != null)
/*      */         {
/* 6741 */           IFn arityPred = (IFn)RT.get(v.meta(), inlineAritiesKey);
/* 6742 */           if ((arityPred == null) || (RT.booleanCast(arityPred.invoke(Integer.valueOf(arity)))))
/* 6743 */             return ret;
/*      */         }
/*      */       }
/*      */     }
/* 6747 */     return null;
/*      */   }
/*      */   
/*      */   public static boolean namesStaticMember(Symbol sym) {
/* 6751 */     return (sym.ns != null) && (namespaceFor(sym) == null);
/*      */   }
/*      */   
/*      */   public static Object preserveTag(ISeq src, Object dst) {
/* 6755 */     Symbol tag = tagOf(src);
/* 6756 */     if ((tag != null) && ((dst instanceof IObj))) {
/* 6757 */       IPersistentMap meta = RT.meta(dst);
/* 6758 */       return ((IObj)dst).withMeta((IPersistentMap)RT.assoc(meta, RT.TAG_KEY, tag));
/*      */     }
/* 6760 */     return dst;
/*      */   }
/*      */   
/*      */   public static Object macroexpand1(Object x) {
/* 6764 */     if ((x instanceof ISeq))
/*      */     {
/* 6766 */       ISeq form = (ISeq)x;
/* 6767 */       Object op = RT.first(form);
/* 6768 */       if (isSpecial(op)) {
/* 6769 */         return x;
/*      */       }
/* 6771 */       Var v = isMacro(op);
/* 6772 */       if (v != null)
/*      */       {
/*      */         try
/*      */         {
/* 6776 */           return v.applyTo(RT.cons(form, RT.cons(LOCAL_ENV.get(), form.next())));
/*      */ 
/*      */         }
/*      */         catch (ArityException e)
/*      */         {
/* 6781 */           throw new ArityException(e.actual - 2, e.name);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 6786 */       if ((op instanceof Symbol))
/*      */       {
/* 6788 */         Symbol sym = (Symbol)op;
/* 6789 */         String sname = sym.name;
/*      */         
/* 6791 */         if (sym.name.charAt(0) == '.')
/*      */         {
/* 6793 */           if (RT.length(form) < 2) {
/* 6794 */             throw new IllegalArgumentException("Malformed member expression, expecting (.member target ...)");
/*      */           }
/* 6796 */           Symbol meth = Symbol.intern(sname.substring(1));
/* 6797 */           Object target = RT.second(form);
/* 6798 */           if (HostExpr.maybeClass(target, false) != null)
/*      */           {
/* 6800 */             target = ((IObj)RT.list(IDENTITY, target)).withMeta(RT.map(new Object[] { RT.TAG_KEY, CLASS }));
/*      */           }
/* 6802 */           return preserveTag(form, RT.listStar(DOT, target, meth, form.next().next()));
/*      */         }
/* 6804 */         if (namesStaticMember(sym))
/*      */         {
/* 6806 */           Symbol target = Symbol.intern(sym.ns);
/* 6807 */           Class c = HostExpr.maybeClass(target, false);
/* 6808 */           if (c != null)
/*      */           {
/* 6810 */             Symbol meth = Symbol.intern(sym.name);
/* 6811 */             return preserveTag(form, RT.listStar(DOT, target, meth, form.next()));
/*      */           }
/*      */           
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/* 6818 */           int idx = sname.lastIndexOf('.');
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6827 */           if (idx == sname.length() - 1) {
/* 6828 */             return RT.listStar(NEW, Symbol.intern(sname.substring(0, idx)), form.next());
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 6833 */     return x;
/*      */   }
/*      */   
/*      */   static Object macroexpand(Object form) {
/* 6837 */     Object exf = macroexpand1(form);
/* 6838 */     if (exf != form)
/* 6839 */       return macroexpand(exf);
/* 6840 */     return form;
/*      */   }
/*      */   
/*      */   private static Expr analyzeSeq(C context, ISeq form, String name) {
/* 6844 */     Object line = Integer.valueOf(lineDeref());
/* 6845 */     Object column = Integer.valueOf(columnDeref());
/* 6846 */     if ((RT.meta(form) != null) && (RT.meta(form).containsKey(RT.LINE_KEY)))
/* 6847 */       line = RT.meta(form).valAt(RT.LINE_KEY);
/* 6848 */     if ((RT.meta(form) != null) && (RT.meta(form).containsKey(RT.COLUMN_KEY)))
/* 6849 */       column = RT.meta(form).valAt(RT.COLUMN_KEY);
/* 6850 */     Var.pushThreadBindings(RT.map(new Object[] { LINE, line, COLUMN, column }));
/*      */     
/*      */     try
/*      */     {
/* 6854 */       Object me = macroexpand1(form);
/* 6855 */       if (me != form) {
/* 6856 */         return analyze(context, me, name);
/*      */       }
/* 6858 */       Object op = RT.first(form);
/* 6859 */       if (op == null)
/* 6860 */         throw new IllegalArgumentException("Can't call nil, form: " + form);
/* 6861 */       IFn inline = isInline(op, RT.count(RT.next(form)));
/* 6862 */       if (inline != null)
/* 6863 */         return analyze(context, preserveTag(form, inline.applyTo(RT.next(form))));
/*      */       Expr localExpr3;
/* 6865 */       if (op.equals(FN))
/* 6866 */         return FnExpr.parse(context, form, name);
/* 6867 */       IParser p; if ((p = (IParser)specials.valAt(op)) != null) {
/* 6868 */         return p.parse(context, form);
/*      */       }
/* 6870 */       return InvokeExpr.parse(context, form);
/*      */     }
/*      */     catch (Throwable e)
/*      */     {
/* 6874 */       if (!(e instanceof CompilerException)) {
/* 6875 */         throw new CompilerException((String)SOURCE_PATH.deref(), lineDeref(), columnDeref(), e);
/*      */       }
/* 6877 */       throw ((CompilerException)e);
/*      */     }
/*      */     finally
/*      */     {
/* 6881 */       Var.popThreadBindings();
/*      */     }
/*      */   }
/*      */   
/*      */   static String errorMsg(String source, int line, int column, String s) {
/* 6886 */     return String.format("%s, compiling:(%s:%d:%d)", new Object[] { s, source, Integer.valueOf(line), Integer.valueOf(column) });
/*      */   }
/*      */   
/*      */   public static Object eval(Object form) {
/* 6890 */     return eval(form, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static int registerConstant(Object o)
/*      */   {
/* 6949 */     if (!CONSTANTS.isBound())
/* 6950 */       return -1;
/* 6951 */     PersistentVector v = (PersistentVector)CONSTANTS.deref();
/* 6952 */     IdentityHashMap<Object, Integer> ids = (IdentityHashMap)CONSTANT_IDS.deref();
/* 6953 */     Integer i = (Integer)ids.get(o);
/* 6954 */     if (i != null)
/* 6955 */       return i.intValue();
/* 6956 */     CONSTANTS.set(RT.conj(v, o));
/* 6957 */     ids.put(o, Integer.valueOf(v.count()));
/* 6958 */     return v.count();
/*      */   }
/*      */   
/*      */   private static KeywordExpr registerKeyword(Keyword keyword) {
/* 6962 */     if (!KEYWORDS.isBound()) {
/* 6963 */       return new KeywordExpr(keyword);
/*      */     }
/* 6965 */     IPersistentMap keywordsMap = (IPersistentMap)KEYWORDS.deref();
/* 6966 */     Object id = RT.get(keywordsMap, keyword);
/* 6967 */     if (id == null)
/*      */     {
/* 6969 */       KEYWORDS.set(RT.assoc(keywordsMap, keyword, Integer.valueOf(registerConstant(keyword))));
/*      */     }
/* 6971 */     return new KeywordExpr(keyword);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private static int registerKeywordCallsite(Keyword keyword)
/*      */   {
/* 6979 */     if (!KEYWORD_CALLSITES.isBound()) {
/* 6980 */       throw new IllegalAccessError("KEYWORD_CALLSITES is not bound");
/*      */     }
/* 6982 */     IPersistentVector keywordCallsites = (IPersistentVector)KEYWORD_CALLSITES.deref();
/*      */     
/* 6984 */     keywordCallsites = keywordCallsites.cons(keyword);
/* 6985 */     KEYWORD_CALLSITES.set(keywordCallsites);
/* 6986 */     return keywordCallsites.count() - 1;
/*      */   }
/*      */   
/*      */   private static int registerProtocolCallsite(Var v) {
/* 6990 */     if (!PROTOCOL_CALLSITES.isBound()) {
/* 6991 */       throw new IllegalAccessError("PROTOCOL_CALLSITES is not bound");
/*      */     }
/* 6993 */     IPersistentVector protocolCallsites = (IPersistentVector)PROTOCOL_CALLSITES.deref();
/*      */     
/* 6995 */     protocolCallsites = protocolCallsites.cons(v);
/* 6996 */     PROTOCOL_CALLSITES.set(protocolCallsites);
/* 6997 */     return protocolCallsites.count() - 1;
/*      */   }
/*      */   
/*      */   private static void registerVarCallsite(Var v) {
/* 7001 */     if (!VAR_CALLSITES.isBound()) {
/* 7002 */       throw new IllegalAccessError("VAR_CALLSITES is not bound");
/*      */     }
/* 7004 */     IPersistentCollection varCallsites = (IPersistentCollection)VAR_CALLSITES.deref();
/*      */     
/* 7006 */     varCallsites = varCallsites.cons(v);
/* 7007 */     VAR_CALLSITES.set(varCallsites);
/*      */   }
/*      */   
/*      */   static ISeq fwdPath(PathNode p1)
/*      */   {
/* 7012 */     ISeq ret = null;
/* 7013 */     for (; p1 != null; p1 = p1.parent)
/* 7014 */       ret = RT.cons(p1, ret);
/* 7015 */     return ret;
/*      */   }
/*      */   
/*      */   static PathNode commonPath(PathNode n1, PathNode n2) {
/* 7019 */     ISeq xp = fwdPath(n1);
/* 7020 */     ISeq yp = fwdPath(n2);
/* 7021 */     if (RT.first(xp) != RT.first(yp))
/* 7022 */       return null;
/* 7023 */     while ((RT.second(xp) != null) && (RT.second(xp) == RT.second(yp)))
/*      */     {
/* 7025 */       xp = xp.next();
/* 7026 */       yp = yp.next();
/*      */     }
/* 7028 */     return (PathNode)RT.first(xp);
/*      */   }
/*      */   
/*      */   static void addAnnotation(Object visitor, IPersistentMap meta) {
/* 7032 */     if ((meta != null) && (ADD_ANNOTATIONS.isBound()))
/* 7033 */       ADD_ANNOTATIONS.invoke(visitor, meta);
/*      */   }
/*      */   
/*      */   static void addParameterAnnotation(Object visitor, IPersistentMap meta, int i) {
/* 7037 */     if ((meta != null) && (ADD_ANNOTATIONS.isBound()))
/* 7038 */       ADD_ANNOTATIONS.invoke(visitor, meta, Integer.valueOf(i));
/*      */   }
/*      */   
/*      */   private static Expr analyzeSymbol(Symbol sym) {
/* 7042 */     Symbol tag = tagOf(sym);
/* 7043 */     if (sym.ns == null)
/*      */     {
/* 7045 */       LocalBinding b = referenceLocal(sym);
/* 7046 */       if (b != null)
/*      */       {
/* 7048 */         return new LocalBindingExpr(b, tag);
/*      */       }
/*      */       
/*      */ 
/*      */     }
/* 7053 */     else if (namespaceFor(sym) == null)
/*      */     {
/* 7055 */       Symbol nsSym = Symbol.intern(sym.ns);
/* 7056 */       Class c = HostExpr.maybeClass(nsSym, false);
/* 7057 */       if (c != null)
/*      */       {
/* 7059 */         if (Reflector.getField(c, sym.name, true) != null)
/* 7060 */           return new StaticFieldExpr(lineDeref(), columnDeref(), c, sym.name, tag);
/* 7061 */         throw Util.runtimeException("Unable to find static field: " + sym.name + " in " + c);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7069 */     Object o = resolve(sym);
/* 7070 */     if ((o instanceof Var))
/*      */     {
/* 7072 */       Var v = (Var)o;
/* 7073 */       if (isMacro(v) != null)
/* 7074 */         throw Util.runtimeException("Can't take value of a macro: " + v);
/* 7075 */       if (RT.booleanCast(RT.get(v.meta(), RT.CONST_KEY)))
/* 7076 */         return analyze(C.EXPRESSION, RT.list(QUOTE, v.get()));
/* 7077 */       registerVar(v);
/* 7078 */       return new VarExpr(v, tag);
/*      */     }
/* 7080 */     if ((o instanceof Class))
/* 7081 */       return new ConstantExpr(o);
/* 7082 */     if ((o instanceof Symbol)) {
/* 7083 */       return new UnresolvedVarExpr((Symbol)o);
/*      */     }
/* 7085 */     throw Util.runtimeException("Unable to resolve symbol: " + sym + " in this context");
/*      */   }
/*      */   
/*      */ 
/*      */   static String destubClassName(String className)
/*      */   {
/* 7091 */     if (className.startsWith("compile__stub"))
/* 7092 */       return className.substring("compile__stub".length() + 1);
/* 7093 */     return className;
/*      */   }
/*      */   
/*      */   static Type getType(Class c) {
/* 7097 */     String descriptor = Type.getType(c).getDescriptor();
/* 7098 */     if (descriptor.startsWith("L"))
/* 7099 */       descriptor = "L" + destubClassName(descriptor.substring(1));
/* 7100 */     return Type.getType(descriptor);
/*      */   }
/*      */   
/*      */   static Object resolve(Symbol sym, boolean allowPrivate) {
/* 7104 */     return resolveIn(currentNS(), sym, allowPrivate);
/*      */   }
/*      */   
/*      */   static Object resolve(Symbol sym) {
/* 7108 */     return resolveIn(currentNS(), sym, false);
/*      */   }
/*      */   
/*      */   static Namespace namespaceFor(Symbol sym) {
/* 7112 */     return namespaceFor(currentNS(), sym);
/*      */   }
/*      */   
/*      */ 
/*      */   static Namespace namespaceFor(Namespace inns, Symbol sym)
/*      */   {
/* 7118 */     Symbol nsSym = Symbol.intern(sym.ns);
/* 7119 */     Namespace ns = inns.lookupAlias(nsSym);
/* 7120 */     if (ns == null)
/*      */     {
/*      */ 
/* 7123 */       ns = Namespace.find(nsSym);
/*      */     }
/* 7125 */     return ns;
/*      */   }
/*      */   
/*      */   public static Object resolveIn(Namespace n, Symbol sym, boolean allowPrivate)
/*      */   {
/* 7130 */     if (sym.ns != null)
/*      */     {
/* 7132 */       Namespace ns = namespaceFor(n, sym);
/* 7133 */       if (ns == null) {
/* 7134 */         throw Util.runtimeException("No such namespace: " + sym.ns);
/*      */       }
/* 7136 */       Var v = ns.findInternedVar(Symbol.intern(sym.name));
/* 7137 */       if (v == null)
/* 7138 */         throw Util.runtimeException("No such var: " + sym);
/* 7139 */       if ((v.ns != currentNS()) && (!v.isPublic()) && (!allowPrivate))
/* 7140 */         throw new IllegalStateException("var: " + sym + " is not public");
/* 7141 */       return v;
/*      */     }
/* 7143 */     if ((sym.name.indexOf('.') > 0) || (sym.name.charAt(0) == '['))
/*      */     {
/* 7145 */       return RT.classForName(sym.name);
/*      */     }
/* 7147 */     if (sym.equals(NS))
/* 7148 */       return RT.NS_VAR;
/* 7149 */     if (sym.equals(IN_NS)) {
/* 7150 */       return RT.IN_NS_VAR;
/*      */     }
/*      */     
/* 7153 */     if (Util.equals(sym, COMPILE_STUB_SYM.get()))
/* 7154 */       return COMPILE_STUB_CLASS.get();
/* 7155 */     Object o = n.getMapping(sym);
/* 7156 */     if (o == null)
/*      */     {
/* 7158 */       if (RT.booleanCast(RT.ALLOW_UNRESOLVED_VARS.deref()))
/*      */       {
/* 7160 */         return sym;
/*      */       }
/*      */       
/*      */ 
/* 7164 */       throw Util.runtimeException("Unable to resolve symbol: " + sym + " in this context");
/*      */     }
/*      */     
/* 7167 */     return o;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static Object maybeResolveIn(Namespace n, Symbol sym)
/*      */   {
/* 7174 */     if (sym.ns != null)
/*      */     {
/* 7176 */       Namespace ns = namespaceFor(n, sym);
/* 7177 */       if (ns == null)
/* 7178 */         return null;
/* 7179 */       Var v = ns.findInternedVar(Symbol.intern(sym.name));
/* 7180 */       if (v == null)
/* 7181 */         return null;
/* 7182 */       return v;
/*      */     }
/* 7184 */     if (((sym.name.indexOf('.') > 0) && (!sym.name.endsWith("."))) || (sym.name.charAt(0) == '['))
/*      */     {
/*      */ 
/* 7187 */       return RT.classForName(sym.name);
/*      */     }
/* 7189 */     if (sym.equals(NS))
/* 7190 */       return RT.NS_VAR;
/* 7191 */     if (sym.equals(IN_NS)) {
/* 7192 */       return RT.IN_NS_VAR;
/*      */     }
/*      */     
/* 7195 */     Object o = n.getMapping(sym);
/* 7196 */     return o;
/*      */   }
/*      */   
/*      */ 
/*      */   static Var lookupVar(Symbol sym, boolean internNew, boolean registerMacro)
/*      */   {
/* 7202 */     Var var = null;
/*      */     
/*      */ 
/* 7205 */     if (sym.ns != null)
/*      */     {
/* 7207 */       Namespace ns = namespaceFor(sym);
/* 7208 */       if (ns == null) {
/* 7209 */         return null;
/*      */       }
/* 7211 */       Symbol name = Symbol.intern(sym.name);
/* 7212 */       if ((internNew) && (ns == currentNS())) {
/* 7213 */         var = currentNS().intern(name);
/*      */       } else {
/* 7215 */         var = ns.findInternedVar(name);
/*      */       }
/* 7217 */     } else if (sym.equals(NS)) {
/* 7218 */       var = RT.NS_VAR;
/* 7219 */     } else if (sym.equals(IN_NS)) {
/* 7220 */       var = RT.IN_NS_VAR;
/*      */     }
/*      */     else
/*      */     {
/* 7224 */       Object o = currentNS().getMapping(sym);
/* 7225 */       if (o == null)
/*      */       {
/*      */ 
/* 7228 */         if (internNew) {
/* 7229 */           var = currentNS().intern(Symbol.intern(sym.name));
/*      */         }
/* 7231 */       } else if ((o instanceof Var))
/*      */       {
/* 7233 */         var = (Var)o;
/*      */       }
/*      */       else
/*      */       {
/* 7237 */         throw Util.runtimeException("Expecting var, but " + sym + " is mapped to " + o);
/*      */       }
/*      */     }
/* 7240 */     if ((var != null) && ((!var.isMacro()) || (registerMacro)))
/* 7241 */       registerVar(var);
/* 7242 */     return var;
/*      */   }
/*      */   
/* 7245 */   static Var lookupVar(Symbol sym, boolean internNew) { return lookupVar(sym, internNew, true); }
/*      */   
/*      */   private static void registerVar(Var var)
/*      */   {
/* 7249 */     if (!VARS.isBound())
/* 7250 */       return;
/* 7251 */     IPersistentMap varsMap = (IPersistentMap)VARS.deref();
/* 7252 */     Object id = RT.get(varsMap, var);
/* 7253 */     if (id == null)
/*      */     {
/* 7255 */       VARS.set(RT.assoc(varsMap, var, Integer.valueOf(registerConstant(var))));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   static Namespace currentNS()
/*      */   {
/* 7262 */     return (Namespace)RT.CURRENT_NS.deref();
/*      */   }
/*      */   
/*      */   static void closeOver(LocalBinding b, ObjMethod method) {
/* 7266 */     if ((b != null) && (method != null))
/*      */     {
/* 7268 */       LocalBinding lb = (LocalBinding)RT.get(method.locals, b);
/* 7269 */       if (lb == null)
/*      */       {
/* 7271 */         method.objx.closes = ((IPersistentMap)RT.assoc(method.objx.closes, b, b));
/* 7272 */         closeOver(b, method.parent);
/*      */       }
/*      */       else {
/* 7275 */         if (lb.idx == 0)
/* 7276 */           method.usesThis = true;
/* 7277 */         if (IN_CATCH_FINALLY.deref() != null)
/*      */         {
/* 7279 */           method.localsUsedInCatchFinally = ((PersistentHashSet)method.localsUsedInCatchFinally.cons(Integer.valueOf(b.idx)));
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   static LocalBinding referenceLocal(Symbol sym)
/*      */   {
/* 7287 */     if (!LOCAL_ENV.isBound())
/* 7288 */       return null;
/* 7289 */     LocalBinding b = (LocalBinding)RT.get(LOCAL_ENV.deref(), sym);
/* 7290 */     if (b != null)
/*      */     {
/* 7292 */       ObjMethod method = (ObjMethod)METHOD.deref();
/* 7293 */       if (b.idx == 0)
/* 7294 */         method.usesThis = true;
/* 7295 */       closeOver(b, method);
/*      */     }
/* 7297 */     return b;
/*      */   }
/*      */   
/*      */   private static Symbol tagOf(Object o) {
/* 7301 */     Object tag = RT.get(RT.meta(o), RT.TAG_KEY);
/* 7302 */     if ((tag instanceof Symbol))
/* 7303 */       return (Symbol)tag;
/* 7304 */     if ((tag instanceof String))
/* 7305 */       return Symbol.intern(null, (String)tag);
/* 7306 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static Object loadFile(String file)
/*      */     throws IOException
/*      */   {
/* 7314 */     FileInputStream f = new FileInputStream(file);
/*      */     try
/*      */     {
/* 7317 */       return load(new java.io.InputStreamReader(f, RT.UTF8), new File(file).getAbsolutePath(), new File(file).getName());
/*      */     }
/*      */     finally
/*      */     {
/* 7321 */       f.close();
/*      */     }
/*      */   }
/*      */   
/*      */   public static Object load(Reader rdr) {
/* 7326 */     return load(rdr, null, "NO_SOURCE_FILE");
/*      */   }
/*      */   
/*      */   static void consumeWhitespaces(LineNumberingPushbackReader pushbackReader) {
/* 7330 */     int ch = LispReader.read1(pushbackReader);
/* 7331 */     while (LispReader.isWhitespace(ch))
/* 7332 */       ch = LispReader.read1(pushbackReader);
/* 7333 */     LispReader.unread(pushbackReader, ch);
/*      */   }
/*      */   
/* 7336 */   private static final Object OPTS_COND_ALLOWED = RT.mapUniqueKeys(new Object[] { LispReader.OPT_READ_COND, LispReader.COND_ALLOW });
/*      */   
/* 7338 */   private static Object readerOpts(String sourceName) { if ((sourceName != null) && (sourceName.endsWith(".cljc"))) {
/* 7339 */       return OPTS_COND_ALLOWED;
/*      */     }
/* 7341 */     return null;
/*      */   }
/*      */   
/*      */   public static Object load(Reader rdr, String sourcePath, String sourceName) {
/* 7345 */     Object EOF = new Object();
/* 7346 */     Object ret = null;
/* 7347 */     LineNumberingPushbackReader pushbackReader = (rdr instanceof LineNumberingPushbackReader) ? (LineNumberingPushbackReader)rdr : new LineNumberingPushbackReader(rdr);
/*      */     
/*      */ 
/* 7350 */     consumeWhitespaces(pushbackReader);
/* 7351 */     Var.pushThreadBindings(RT.mapUniqueKeys(new Object[] { LOADER, RT.makeClassLoader(), SOURCE_PATH, sourcePath, SOURCE, sourceName, METHOD, null, LOCAL_ENV, null, LOOP_LOCALS, null, NEXT_LOCAL_NUM, Integer.valueOf(0), RT.READEVAL, RT.T, RT.CURRENT_NS, RT.CURRENT_NS.deref(), LINE_BEFORE, Integer.valueOf(pushbackReader.getLineNumber()), COLUMN_BEFORE, Integer.valueOf(pushbackReader.getColumnNumber()), LINE_AFTER, Integer.valueOf(pushbackReader.getLineNumber()), COLUMN_AFTER, Integer.valueOf(pushbackReader.getColumnNumber()), RT.UNCHECKED_MATH, RT.UNCHECKED_MATH.deref(), RT.WARN_ON_REFLECTION, RT.WARN_ON_REFLECTION.deref(), RT.DATA_READERS, RT.DATA_READERS.deref() }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7370 */     Object readerOpts = readerOpts(sourceName);
/*      */     try
/*      */     {
/* 7373 */       for (Object r = LispReader.read(pushbackReader, false, EOF, false, readerOpts); r != EOF; 
/* 7374 */           r = LispReader.read(pushbackReader, false, EOF, false, readerOpts))
/*      */       {
/* 7376 */         consumeWhitespaces(pushbackReader);
/* 7377 */         LINE_AFTER.set(Integer.valueOf(pushbackReader.getLineNumber()));
/* 7378 */         COLUMN_AFTER.set(Integer.valueOf(pushbackReader.getColumnNumber()));
/* 7379 */         ret = eval(r, false);
/* 7380 */         LINE_BEFORE.set(Integer.valueOf(pushbackReader.getLineNumber()));
/* 7381 */         COLUMN_BEFORE.set(Integer.valueOf(pushbackReader.getColumnNumber()));
/*      */       }
/*      */     }
/*      */     catch (LispReader.ReaderException e)
/*      */     {
/* 7386 */       throw new CompilerException(sourcePath, e.line, e.column, e.getCause());
/*      */     }
/*      */     catch (Throwable e)
/*      */     {
/* 7390 */       if (!(e instanceof CompilerException)) {
/* 7391 */         throw new CompilerException(sourcePath, ((Integer)LINE_BEFORE.deref()).intValue(), ((Integer)COLUMN_BEFORE.deref()).intValue(), e);
/*      */       }
/* 7393 */       throw ((CompilerException)e);
/*      */     }
/*      */     finally
/*      */     {
/* 7397 */       Var.popThreadBindings();
/*      */     }
/* 7399 */     return ret;
/*      */   }
/*      */   
/*      */   public static void writeClassFile(String internalName, byte[] bytecode) throws IOException {
/* 7403 */     String genPath = (String)COMPILE_PATH.deref();
/* 7404 */     if (genPath == null)
/* 7405 */       throw Util.runtimeException("*compile-path* not set");
/* 7406 */     String[] dirs = internalName.split("/");
/* 7407 */     String p = genPath;
/* 7408 */     for (int i = 0; i < dirs.length - 1; i++)
/*      */     {
/* 7410 */       p = p + File.separator + dirs[i];
/* 7411 */       new File(p).mkdir();
/*      */     }
/* 7413 */     String path = genPath + File.separator + internalName + ".class";
/* 7414 */     File cf = new File(path);
/* 7415 */     cf.createNewFile();
/* 7416 */     FileOutputStream cfs = new FileOutputStream(cf);
/*      */     try
/*      */     {
/* 7419 */       cfs.write(bytecode);
/* 7420 */       cfs.flush();
/*      */     }
/*      */     finally
/*      */     {
/* 7424 */       cfs.close();
/*      */     }
/*      */   }
/*      */   
/*      */   public static void pushNS() {
/* 7429 */     Var.pushThreadBindings(PersistentHashMap.create(new Object[] { Var.intern(Symbol.intern("clojure.core"), Symbol.intern("*ns*")).setDynamic(), null }));
/*      */   }
/*      */   
/*      */   public static void pushNSandLoader(ClassLoader loader)
/*      */   {
/* 7434 */     Var.pushThreadBindings(RT.map(new Object[] { Var.intern(Symbol.intern("clojure.core"), Symbol.intern("*ns*")).setDynamic(), null, RT.FN_LOADER_VAR, loader, RT.READEVAL, RT.T }));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static ILookupThunk getLookupThunk(Object target, Keyword k)
/*      */   {
/* 7443 */     return null;
/*      */   }
/*      */   
/*      */   static void compile1(GeneratorAdapter gen, ObjExpr objx, Object form) {
/* 7447 */     Object line = Integer.valueOf(lineDeref());
/* 7448 */     Object column = Integer.valueOf(columnDeref());
/* 7449 */     if ((RT.meta(form) != null) && (RT.meta(form).containsKey(RT.LINE_KEY)))
/* 7450 */       line = RT.meta(form).valAt(RT.LINE_KEY);
/* 7451 */     if ((RT.meta(form) != null) && (RT.meta(form).containsKey(RT.COLUMN_KEY)))
/* 7452 */       column = RT.meta(form).valAt(RT.COLUMN_KEY);
/* 7453 */     Var.pushThreadBindings(RT.map(new Object[] { LINE, line, COLUMN, column, LOADER, RT.makeClassLoader() }));
/*      */     
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/* 7459 */       form = macroexpand(form);
/* 7460 */       if (((form instanceof ISeq)) && (Util.equals(RT.first(form), DO)))
/*      */       {
/* 7462 */         for (ISeq s = RT.next(form); s != null; s = RT.next(s))
/*      */         {
/* 7464 */           compile1(gen, objx, RT.first(s));
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/* 7469 */         Expr expr = analyze(C.EVAL, form);
/* 7470 */         objx.keywords = ((IPersistentMap)KEYWORDS.deref());
/* 7471 */         objx.vars = ((IPersistentMap)VARS.deref());
/* 7472 */         objx.constants = ((PersistentVector)CONSTANTS.deref());
/* 7473 */         expr.emit(C.EXPRESSION, objx, gen);
/* 7474 */         expr.eval();
/*      */       }
/*      */     }
/*      */     finally
/*      */     {
/* 7479 */       Var.popThreadBindings();
/*      */     }
/*      */   }
/*      */   
/*      */   public static Object compile(Reader rdr, String sourcePath, String sourceName) throws IOException {
/* 7484 */     if (COMPILE_PATH.deref() == null) {
/* 7485 */       throw Util.runtimeException("*compile-path* not set");
/*      */     }
/* 7487 */     Object EOF = new Object();
/* 7488 */     Object ret = null;
/* 7489 */     LineNumberingPushbackReader pushbackReader = (rdr instanceof LineNumberingPushbackReader) ? (LineNumberingPushbackReader)rdr : new LineNumberingPushbackReader(rdr);
/*      */     
/*      */ 
/* 7492 */     Var.pushThreadBindings(RT.mapUniqueKeys(new Object[] { SOURCE_PATH, sourcePath, SOURCE, sourceName, METHOD, null, LOCAL_ENV, null, LOOP_LOCALS, null, NEXT_LOCAL_NUM, Integer.valueOf(0), RT.READEVAL, RT.T, RT.CURRENT_NS, RT.CURRENT_NS.deref(), LINE_BEFORE, Integer.valueOf(pushbackReader.getLineNumber()), COLUMN_BEFORE, Integer.valueOf(pushbackReader.getColumnNumber()), LINE_AFTER, Integer.valueOf(pushbackReader.getLineNumber()), COLUMN_AFTER, Integer.valueOf(pushbackReader.getColumnNumber()), CONSTANTS, PersistentVector.EMPTY, CONSTANT_IDS, new IdentityHashMap(), KEYWORDS, PersistentHashMap.EMPTY, VARS, PersistentHashMap.EMPTY, RT.UNCHECKED_MATH, RT.UNCHECKED_MATH.deref(), RT.WARN_ON_REFLECTION, RT.WARN_ON_REFLECTION.deref(), RT.DATA_READERS, RT.DATA_READERS.deref() }));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/* 7518 */       ObjExpr objx = new ObjExpr(null);
/* 7519 */       objx.internalName = (sourcePath.replace(File.separator, "/").substring(0, sourcePath.lastIndexOf('.')) + "__init");
/*      */       
/*      */ 
/* 7522 */       objx.objtype = Type.getObjectType(objx.internalName);
/* 7523 */       ClassWriter cw = new ClassWriter(1);
/* 7524 */       ClassVisitor cv = cw;
/* 7525 */       cv.visit(49, 33, objx.internalName, null, "java/lang/Object", null);
/*      */       
/*      */ 
/* 7528 */       GeneratorAdapter gen = new GeneratorAdapter(9, clojure.asm.commons.Method.getMethod("void load ()"), null, null, cv);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 7533 */       gen.visitCode();
/*      */       
/* 7535 */       Object readerOpts = readerOpts(sourceName);
/* 7536 */       for (Object r = LispReader.read(pushbackReader, false, EOF, false, readerOpts); r != EOF; 
/* 7537 */           r = LispReader.read(pushbackReader, false, EOF, false, readerOpts))
/*      */       {
/* 7539 */         LINE_AFTER.set(Integer.valueOf(pushbackReader.getLineNumber()));
/* 7540 */         COLUMN_AFTER.set(Integer.valueOf(pushbackReader.getColumnNumber()));
/* 7541 */         compile1(gen, objx, r);
/* 7542 */         LINE_BEFORE.set(Integer.valueOf(pushbackReader.getLineNumber()));
/* 7543 */         COLUMN_BEFORE.set(Integer.valueOf(pushbackReader.getColumnNumber()));
/*      */       }
/*      */       
/* 7546 */       gen.returnValue();
/* 7547 */       gen.endMethod();
/*      */       
/*      */ 
/* 7550 */       for (int i = 0; i < objx.constants.count(); i++)
/*      */       {
/* 7552 */         if (objx.usedConstants.contains(Integer.valueOf(i))) {
/* 7553 */           cv.visitField(25, objx.constantName(i), objx.constantType(i).getDescriptor(), null, null);
/*      */         }
/*      */       }
/*      */       
/* 7557 */       int INITS_PER = 100;
/* 7558 */       int numInits = objx.constants.count() / 100;
/* 7559 */       if (objx.constants.count() % 100 != 0) {
/* 7560 */         numInits++;
/*      */       }
/* 7562 */       for (int n = 0; n < numInits; n++)
/*      */       {
/* 7564 */         GeneratorAdapter clinitgen = new GeneratorAdapter(9, clojure.asm.commons.Method.getMethod("void __init" + n + "()"), null, null, cv);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 7569 */         clinitgen.visitCode();
/*      */         try
/*      */         {
/* 7572 */           Var.pushThreadBindings(RT.map(new Object[] { RT.PRINT_DUP, RT.T }));
/*      */           
/* 7574 */           for (int i = n * 100; (i < objx.constants.count()) && (i < (n + 1) * 100); i++)
/*      */           {
/* 7576 */             if (objx.usedConstants.contains(Integer.valueOf(i)))
/*      */             {
/* 7578 */               objx.emitValue(objx.constants.nth(i), clinitgen);
/* 7579 */               clinitgen.checkCast(objx.constantType(i));
/* 7580 */               clinitgen.putStatic(objx.objtype, objx.constantName(i), objx.constantType(i));
/*      */             }
/*      */           }
/*      */         }
/*      */         finally {}
/*      */         
/*      */ 
/*      */ 
/* 7588 */         clinitgen.returnValue();
/* 7589 */         clinitgen.endMethod();
/*      */       }
/*      */       
/*      */ 
/* 7593 */       GeneratorAdapter clinitgen = new GeneratorAdapter(9, clojure.asm.commons.Method.getMethod("void <clinit> ()"), null, null, cv);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 7598 */       clinitgen.visitCode();
/* 7599 */       Label startTry = clinitgen.newLabel();
/* 7600 */       Label endTry = clinitgen.newLabel();
/* 7601 */       Label end = clinitgen.newLabel();
/* 7602 */       Label finallyLabel = clinitgen.newLabel();
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7608 */       for (int n = 0; n < numInits; n++) {
/* 7609 */         clinitgen.invokeStatic(objx.objtype, clojure.asm.commons.Method.getMethod("void __init" + n + "()"));
/*      */       }
/* 7611 */       clinitgen.push(objx.internalName.replace('/', '.'));
/* 7612 */       clinitgen.invokeStatic(RT_TYPE, clojure.asm.commons.Method.getMethod("Class classForName(String)"));
/* 7613 */       clinitgen.invokeVirtual(CLASS_TYPE, clojure.asm.commons.Method.getMethod("ClassLoader getClassLoader()"));
/* 7614 */       clinitgen.invokeStatic(Type.getType(Compiler.class), clojure.asm.commons.Method.getMethod("void pushNSandLoader(ClassLoader)"));
/* 7615 */       clinitgen.mark(startTry);
/* 7616 */       clinitgen.invokeStatic(objx.objtype, clojure.asm.commons.Method.getMethod("void load()"));
/* 7617 */       clinitgen.mark(endTry);
/* 7618 */       clinitgen.invokeStatic(VAR_TYPE, clojure.asm.commons.Method.getMethod("void popThreadBindings()"));
/* 7619 */       clinitgen.goTo(end);
/*      */       
/* 7621 */       clinitgen.mark(finallyLabel);
/*      */       
/* 7623 */       clinitgen.invokeStatic(VAR_TYPE, clojure.asm.commons.Method.getMethod("void popThreadBindings()"));
/* 7624 */       clinitgen.throwException();
/* 7625 */       clinitgen.mark(end);
/* 7626 */       clinitgen.visitTryCatchBlock(startTry, endTry, finallyLabel, null);
/*      */       
/*      */ 
/* 7629 */       clinitgen.returnValue();
/* 7630 */       clinitgen.endMethod();
/*      */       
/*      */ 
/* 7633 */       cv.visitEnd();
/*      */       
/* 7635 */       writeClassFile(objx.internalName, cw.toByteArray());
/*      */     }
/*      */     catch (LispReader.ReaderException e)
/*      */     {
/* 7639 */       throw new CompilerException(sourcePath, e.line, e.column, e.getCause());
/*      */     }
/*      */     finally
/*      */     {
/* 7643 */       Var.popThreadBindings();
/*      */     }
/* 7645 */     return ret;
/*      */   }
/*      */   
/*      */   public static class NewInstanceExpr
/*      */     extends Compiler.ObjExpr
/*      */   {
/*      */     IPersistentCollection methods;
/*      */     Map<IPersistentVector, java.lang.reflect.Method> mmap;
/*      */     Map<IPersistentVector, Set<Class>> covariants;
/*      */     
/*      */     public NewInstanceExpr(Object tag)
/*      */     {
/* 7657 */       super();
/*      */     }
/*      */     
/*      */     static class DeftypeParser implements Compiler.IParser {
/*      */       public Compiler.Expr parse(Compiler.C context, Object frm) {
/* 7662 */         ISeq rform = (ISeq)frm;
/*      */         
/* 7664 */         rform = RT.next(rform);
/* 7665 */         String tagname = ((Symbol)rform.first()).getName();
/* 7666 */         rform = rform.next();
/* 7667 */         Symbol classname = (Symbol)rform.first();
/* 7668 */         rform = rform.next();
/* 7669 */         IPersistentVector fields = (IPersistentVector)rform.first();
/* 7670 */         rform = rform.next();
/* 7671 */         IPersistentMap opts = PersistentHashMap.EMPTY;
/* 7672 */         while ((rform != null) && ((rform.first() instanceof Keyword)))
/*      */         {
/* 7674 */           opts = opts.assoc(rform.first(), RT.second(rform));
/* 7675 */           rform = rform.next().next();
/*      */         }
/*      */         
/* 7678 */         Compiler.ObjExpr ret = Compiler.NewInstanceExpr.build((IPersistentVector)RT.get(opts, Compiler.implementsKey, PersistentVector.EMPTY), fields, null, tagname, classname, (Symbol)RT.get(opts, RT.TAG_KEY), rform, frm, opts);
/*      */         
/* 7680 */         return ret;
/*      */       }
/*      */     }
/*      */     
/*      */     static class ReifyParser implements Compiler.IParser
/*      */     {
/*      */       public Compiler.Expr parse(Compiler.C context, Object frm) {
/* 7687 */         ISeq form = (ISeq)frm;
/* 7688 */         Compiler.ObjMethod enclosingMethod = (Compiler.ObjMethod)Compiler.METHOD.deref();
/* 7689 */         String basename = Compiler.munge(Compiler.currentNS().name.name) + "$";
/*      */         
/*      */ 
/* 7692 */         String simpleName = "reify__" + RT.nextID();
/* 7693 */         String classname = basename + simpleName;
/*      */         
/* 7695 */         ISeq rform = RT.next(form);
/*      */         
/* 7697 */         IPersistentVector interfaces = ((IPersistentVector)RT.first(rform)).cons(Symbol.intern("clojure.lang.IObj"));
/*      */         
/*      */ 
/* 7700 */         rform = RT.next(rform);
/*      */         
/*      */ 
/* 7703 */         Compiler.ObjExpr ret = Compiler.NewInstanceExpr.build(interfaces, null, null, classname, Symbol.intern(classname), null, rform, frm, null);
/* 7704 */         if (((frm instanceof IObj)) && (((IObj)frm).meta() != null)) {
/* 7705 */           return new Compiler.MetaExpr(ret, Compiler.MapExpr.parse(context == Compiler.C.EVAL ? context : Compiler.C.EXPRESSION, ((IObj)frm).meta()));
/*      */         }
/*      */         
/* 7708 */         return ret;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */     static Compiler.ObjExpr build(IPersistentVector interfaceSyms, IPersistentVector fieldSyms, Symbol thisSym, String tagName, Symbol className, Symbol typeTag, ISeq methodForms, Object frm, IPersistentMap opts)
/*      */     {
/* 7715 */       NewInstanceExpr ret = new NewInstanceExpr(null);
/*      */       
/* 7717 */       ret.src = frm;
/* 7718 */       ret.name = className.toString();
/* 7719 */       ret.classMeta = RT.meta(className);
/* 7720 */       ret.internalName = ret.name.replace('.', '/');
/* 7721 */       ret.objtype = Type.getObjectType(ret.internalName);
/* 7722 */       ret.opts = opts;
/*      */       
/* 7724 */       if (thisSym != null) {
/* 7725 */         ret.thisName = thisSym.name;
/*      */       }
/* 7727 */       if (fieldSyms != null)
/*      */       {
/* 7729 */         IPersistentMap fmap = PersistentHashMap.EMPTY;
/* 7730 */         Object[] closesvec = new Object[2 * fieldSyms.count()];
/* 7731 */         for (int i = 0; i < fieldSyms.count(); i++)
/*      */         {
/* 7733 */           Symbol sym = (Symbol)fieldSyms.nth(i);
/* 7734 */           Compiler.LocalBinding lb = new Compiler.LocalBinding(-1, sym, null, new Compiler.MethodParamExpr(Compiler.tagClass(Compiler.tagOf(sym))), false, null);
/*      */           
/* 7736 */           fmap = fmap.assoc(sym, lb);
/* 7737 */           closesvec[(i * 2)] = lb;
/* 7738 */           closesvec[(i * 2 + 1)] = lb;
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 7743 */         ret.closes = new PersistentArrayMap(closesvec);
/* 7744 */         ret.fields = fmap;
/* 7745 */         for (int i = fieldSyms.count() - 1; (i >= 0) && ((((Symbol)fieldSyms.nth(i)).name.equals("__meta")) || (((Symbol)fieldSyms.nth(i)).name.equals("__extmap"))); i--) {
/* 7746 */           ret.altCtorDrops += 1;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 7751 */       PersistentVector interfaces = PersistentVector.EMPTY;
/* 7752 */       for (ISeq s = RT.seq(interfaceSyms); s != null; s = s.next())
/*      */       {
/* 7754 */         Class c = (Class)Compiler.resolve((Symbol)s.first());
/* 7755 */         if (!c.isInterface())
/* 7756 */           throw new IllegalArgumentException("only interfaces are supported, had: " + c.getName());
/* 7757 */         interfaces = interfaces.cons(c);
/*      */       }
/* 7759 */       Class superClass = Object.class;
/* 7760 */       Map[] mc = gatherMethods(superClass, RT.seq(interfaces));
/* 7761 */       Map overrideables = mc[0];
/* 7762 */       Map covariants = mc[1];
/* 7763 */       ret.mmap = overrideables;
/* 7764 */       ret.covariants = covariants;
/*      */       
/* 7766 */       String[] inames = interfaceNames(interfaces);
/*      */       
/* 7768 */       Class stub = compileStub(slashname(superClass), ret, inames, frm);
/* 7769 */       Symbol thistag = Symbol.intern(null, stub.getName());
/*      */       
/*      */       try
/*      */       {
/* 7773 */         Var.pushThreadBindings(RT.mapUniqueKeys(new Object[] { Compiler.CONSTANTS, PersistentVector.EMPTY, Compiler.CONSTANT_IDS, new IdentityHashMap(), Compiler.KEYWORDS, PersistentHashMap.EMPTY, Compiler.VARS, PersistentHashMap.EMPTY, Compiler.KEYWORD_CALLSITES, PersistentVector.EMPTY, Compiler.PROTOCOL_CALLSITES, PersistentVector.EMPTY, Compiler.VAR_CALLSITES, Compiler.emptyVarCallSites(), Compiler.NO_RECUR, null }));
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7782 */         if (ret.isDeftype())
/*      */         {
/* 7784 */           Var.pushThreadBindings(RT.mapUniqueKeys(new Object[] { Compiler.METHOD, null, Compiler.LOCAL_ENV, ret.fields, Compiler.COMPILE_STUB_SYM, Symbol.intern(null, tagName), Compiler.COMPILE_STUB_CLASS, stub }));
/*      */           
/*      */ 
/*      */ 
/*      */ 
/* 7789 */           ret.hintedFields = RT.subvec(fieldSyms, 0, fieldSyms.count() - ret.altCtorDrops);
/*      */         }
/*      */         
/*      */ 
/* 7793 */         ret.line = Compiler.lineDeref();
/* 7794 */         ret.column = Compiler.columnDeref();
/* 7795 */         IPersistentCollection methods = null;
/* 7796 */         for (ISeq s = methodForms; s != null; s = RT.next(s))
/*      */         {
/* 7798 */           Compiler.NewInstanceMethod m = Compiler.NewInstanceMethod.parse(ret, (ISeq)RT.first(s), thistag, overrideables);
/* 7799 */           methods = RT.conj(methods, m);
/*      */         }
/*      */         
/*      */ 
/* 7803 */         ret.methods = methods;
/* 7804 */         ret.keywords = ((IPersistentMap)Compiler.KEYWORDS.deref());
/* 7805 */         ret.vars = ((IPersistentMap)Compiler.VARS.deref());
/* 7806 */         ret.constants = ((PersistentVector)Compiler.CONSTANTS.deref());
/* 7807 */         ret.constantsID = RT.nextID();
/* 7808 */         ret.keywordCallsites = ((IPersistentVector)Compiler.KEYWORD_CALLSITES.deref());
/* 7809 */         ret.protocolCallsites = ((IPersistentVector)Compiler.PROTOCOL_CALLSITES.deref());
/* 7810 */         ret.varCallsites = ((IPersistentSet)Compiler.VAR_CALLSITES.deref());
/*      */       }
/*      */       finally
/*      */       {
/* 7814 */         if (ret.isDeftype())
/* 7815 */           Var.popThreadBindings();
/* 7816 */         Var.popThreadBindings();
/*      */       }
/*      */       
/*      */       try
/*      */       {
/* 7821 */         ret.compile(slashname(superClass), inames, false);
/*      */       }
/*      */       catch (IOException e)
/*      */       {
/* 7825 */         throw Util.sneakyThrow(e);
/*      */       }
/* 7827 */       ret.getCompiledClass();
/* 7828 */       return ret;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     static Class compileStub(String superName, NewInstanceExpr ret, String[] interfaceNames, Object frm)
/*      */     {
/* 7839 */       ClassWriter cw = new ClassWriter(1);
/* 7840 */       ClassVisitor cv = cw;
/* 7841 */       cv.visit(49, 33, "compile__stub/" + ret.internalName, null, superName, interfaceNames);
/*      */       
/*      */ 
/*      */ 
/* 7845 */       for (ISeq s = RT.keys(ret.closes); s != null; s = s.next())
/*      */       {
/* 7847 */         Compiler.LocalBinding lb = (Compiler.LocalBinding)s.first();
/* 7848 */         int access = 1 + (ret.isMutable(lb) ? 0 : ret.isVolatile(lb) ? 64 : 16);
/*      */         
/*      */ 
/* 7851 */         if (lb.getPrimitiveType() != null) {
/* 7852 */           cv.visitField(access, lb.name, Type.getType(lb.getPrimitiveType()).getDescriptor(), null, null);
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/* 7857 */           cv.visitField(access, lb.name, Compiler.OBJECT_TYPE.getDescriptor(), null, null);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 7862 */       clojure.asm.commons.Method m = new clojure.asm.commons.Method("<init>", Type.VOID_TYPE, ret.ctorTypes());
/* 7863 */       GeneratorAdapter ctorgen = new GeneratorAdapter(1, m, null, null, cv);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 7868 */       ctorgen.visitCode();
/* 7869 */       ctorgen.loadThis();
/* 7870 */       ctorgen.invokeConstructor(Type.getObjectType(superName), voidctor);
/* 7871 */       ctorgen.returnValue();
/* 7872 */       ctorgen.endMethod();
/*      */       
/* 7874 */       if (ret.altCtorDrops > 0)
/*      */       {
/* 7876 */         Type[] ctorTypes = ret.ctorTypes();
/* 7877 */         Type[] altCtorTypes = new Type[ctorTypes.length - ret.altCtorDrops];
/* 7878 */         for (int i = 0; i < altCtorTypes.length; i++)
/* 7879 */           altCtorTypes[i] = ctorTypes[i];
/* 7880 */         clojure.asm.commons.Method alt = new clojure.asm.commons.Method("<init>", Type.VOID_TYPE, altCtorTypes);
/* 7881 */         ctorgen = new GeneratorAdapter(1, alt, null, null, cv);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 7886 */         ctorgen.visitCode();
/* 7887 */         ctorgen.loadThis();
/* 7888 */         ctorgen.loadArgs();
/* 7889 */         for (int i = 0; i < ret.altCtorDrops; i++) {
/* 7890 */           ctorgen.visitInsn(1);
/*      */         }
/* 7892 */         ctorgen.invokeConstructor(Type.getObjectType("compile__stub/" + ret.internalName), new clojure.asm.commons.Method("<init>", Type.VOID_TYPE, ctorTypes));
/*      */         
/*      */ 
/* 7895 */         ctorgen.returnValue();
/* 7896 */         ctorgen.endMethod();
/*      */       }
/*      */       
/* 7899 */       cv.visitEnd();
/*      */       
/* 7901 */       byte[] bytecode = cw.toByteArray();
/* 7902 */       DynamicClassLoader loader = (DynamicClassLoader)Compiler.LOADER.deref();
/* 7903 */       return loader.defineClass("compile__stub." + ret.name, bytecode, frm);
/*      */     }
/*      */     
/*      */     static String[] interfaceNames(IPersistentVector interfaces) {
/* 7907 */       int icnt = interfaces.count();
/* 7908 */       String[] inames = icnt > 0 ? new String[icnt] : null;
/* 7909 */       for (int i = 0; i < icnt; i++)
/* 7910 */         inames[i] = slashname((Class)interfaces.nth(i));
/* 7911 */       return inames;
/*      */     }
/*      */     
/*      */     static String slashname(Class c)
/*      */     {
/* 7916 */       return c.getName().replace('.', '/');
/*      */     }
/*      */     
/*      */     protected void emitStatics(ClassVisitor cv) {
/* 7920 */       if (isDeftype())
/*      */       {
/*      */ 
/* 7923 */         clojure.asm.commons.Method meth = clojure.asm.commons.Method.getMethod("clojure.lang.IPersistentVector getBasis()");
/* 7924 */         GeneratorAdapter gen = new GeneratorAdapter(9, meth, null, null, cv);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 7929 */         emitValue(this.hintedFields, gen);
/* 7930 */         gen.returnValue();
/* 7931 */         gen.endMethod();
/*      */         
/* 7933 */         if ((isDeftype()) && (this.fields.count() > this.hintedFields.count()))
/*      */         {
/*      */ 
/* 7936 */           String className = this.name.replace('.', '/');
/* 7937 */           int i = 1;
/* 7938 */           int fieldCount = this.hintedFields.count();
/*      */           
/* 7940 */           MethodVisitor mv = cv.visitMethod(9, "create", "(Lclojure/lang/IPersistentMap;)L" + className + ";", null, null);
/* 7941 */           mv.visitCode();
/*      */           
/* 7943 */           for (ISeq s = RT.seq(this.hintedFields); s != null; i++)
/*      */           {
/* 7945 */             String bName = ((Symbol)s.first()).name;
/* 7946 */             Class k = Compiler.tagClass(Compiler.tagOf(s.first()));
/*      */             
/* 7948 */             mv.visitVarInsn(25, 0);
/* 7949 */             mv.visitLdcInsn(bName);
/* 7950 */             mv.visitMethodInsn(184, "clojure/lang/Keyword", "intern", "(Ljava/lang/String;)Lclojure/lang/Keyword;");
/* 7951 */             mv.visitInsn(1);
/* 7952 */             mv.visitMethodInsn(185, "clojure/lang/IPersistentMap", "valAt", "(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;");
/* 7953 */             if (k.isPrimitive())
/*      */             {
/* 7955 */               mv.visitTypeInsn(192, Type.getType(Compiler.boxClass(k)).getInternalName());
/*      */             }
/* 7957 */             mv.visitVarInsn(58, i);
/* 7958 */             mv.visitVarInsn(25, 0);
/* 7959 */             mv.visitLdcInsn(bName);
/* 7960 */             mv.visitMethodInsn(184, "clojure/lang/Keyword", "intern", "(Ljava/lang/String;)Lclojure/lang/Keyword;");
/* 7961 */             mv.visitMethodInsn(185, "clojure/lang/IPersistentMap", "without", "(Ljava/lang/Object;)Lclojure/lang/IPersistentMap;");
/* 7962 */             mv.visitVarInsn(58, 0);s = s.next();
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 7965 */           mv.visitTypeInsn(187, className);
/* 7966 */           mv.visitInsn(89);
/*      */           
/* 7968 */           clojure.asm.commons.Method ctor = new clojure.asm.commons.Method("<init>", Type.VOID_TYPE, ctorTypes());
/*      */           
/* 7970 */           if (this.hintedFields.count() > 0) {
/* 7971 */             for (i = 1; i <= fieldCount; i++)
/*      */             {
/* 7973 */               mv.visitVarInsn(25, i);
/* 7974 */               Class k = Compiler.tagClass(Compiler.tagOf(this.hintedFields.nth(i - 1)));
/* 7975 */               if (k.isPrimitive())
/*      */               {
/* 7977 */                 String b = Type.getType(Compiler.boxClass(k)).getInternalName();
/* 7978 */                 String p = Type.getType(k).getDescriptor();
/* 7979 */                 String n = k.getName();
/*      */                 
/* 7981 */                 mv.visitMethodInsn(182, b, n + "Value", "()" + p);
/*      */               }
/*      */             }
/*      */           }
/* 7985 */           mv.visitInsn(1);
/* 7986 */           mv.visitVarInsn(25, 0);
/* 7987 */           mv.visitMethodInsn(184, "clojure/lang/RT", "seqOrElse", "(Ljava/lang/Object;)Ljava/lang/Object;");
/* 7988 */           mv.visitMethodInsn(183, className, "<init>", ctor.getDescriptor());
/* 7989 */           mv.visitInsn(176);
/* 7990 */           mv.visitMaxs(4 + fieldCount, 1 + fieldCount);
/* 7991 */           mv.visitEnd();
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */     protected void emitMethods(ClassVisitor cv) {
/* 7997 */       for (ISeq s = RT.seq(this.methods); s != null; s = s.next())
/*      */       {
/* 7999 */         Compiler.ObjMethod method = (Compiler.ObjMethod)s.first();
/* 8000 */         method.emit(this, cv);
/*      */       }
/*      */       
/* 8003 */       for (Map.Entry<IPersistentVector, Set<Class>> e : this.covariants.entrySet())
/*      */       {
/* 8005 */         m = (java.lang.reflect.Method)this.mmap.get(e.getKey());
/* 8006 */         Class[] params = m.getParameterTypes();
/* 8007 */         argTypes = new Type[params.length];
/*      */         
/* 8009 */         for (int i = 0; i < params.length; i++)
/*      */         {
/* 8011 */           argTypes[i] = Type.getType(params[i]);
/*      */         }
/*      */         
/* 8014 */         target = new clojure.asm.commons.Method(m.getName(), Type.getType(m.getReturnType()), argTypes);
/*      */         
/* 8016 */         for (Class retType : (Set)e.getValue())
/*      */         {
/* 8018 */           clojure.asm.commons.Method meth = new clojure.asm.commons.Method(m.getName(), Type.getType(retType), argTypes);
/*      */           
/* 8020 */           GeneratorAdapter gen = new GeneratorAdapter(65, meth, null, Compiler.EXCEPTION_TYPES, cv);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 8026 */           gen.visitCode();
/* 8027 */           gen.loadThis();
/* 8028 */           gen.loadArgs();
/* 8029 */           gen.invokeInterface(Type.getType(m.getDeclaringClass()), target);
/* 8030 */           gen.returnValue();
/* 8031 */           gen.endMethod();
/*      */         } }
/*      */       java.lang.reflect.Method m;
/*      */       Type[] argTypes;
/*      */       clojure.asm.commons.Method target; }
/*      */     
/* 8037 */     public static IPersistentVector msig(java.lang.reflect.Method m) { return RT.vector(new Object[] { m.getName(), RT.seq(m.getParameterTypes()), m.getReturnType() }); }
/*      */     
/*      */     static void considerMethod(java.lang.reflect.Method m, Map mm)
/*      */     {
/* 8041 */       IPersistentVector mk = msig(m);
/* 8042 */       int mods = m.getModifiers();
/*      */       
/* 8044 */       if ((!mm.containsKey(mk)) && ((Modifier.isPublic(mods)) || (Modifier.isProtected(mods))) && (!Modifier.isStatic(mods)) && (!Modifier.isFinal(mods)))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/* 8049 */         mm.put(mk, m);
/*      */       }
/*      */     }
/*      */     
/*      */     static void gatherMethods(Class c, Map mm) {
/* 8054 */       for (; c != null; c = c.getSuperclass())
/*      */       {
/* 8056 */         for (java.lang.reflect.Method m : c.getDeclaredMethods())
/* 8057 */           considerMethod(m, mm);
/* 8058 */         for (java.lang.reflect.Method m : c.getMethods())
/* 8059 */           considerMethod(m, mm);
/*      */       }
/*      */     }
/*      */     
/*      */     public static Map[] gatherMethods(Class sc, ISeq interfaces) {
/* 8064 */       Map allm = new HashMap();
/* 8065 */       gatherMethods(sc, allm);
/* 8066 */       for (; interfaces != null; interfaces = interfaces.next()) {
/* 8067 */         gatherMethods((Class)interfaces.first(), allm);
/*      */       }
/* 8069 */       Map<IPersistentVector, java.lang.reflect.Method> mm = new HashMap();
/* 8070 */       Map<IPersistentVector, Set<Class>> covariants = new HashMap();
/* 8071 */       for (Object o : allm.entrySet())
/*      */       {
/* 8073 */         Map.Entry e = (Map.Entry)o;
/* 8074 */         IPersistentVector mk = (IPersistentVector)e.getKey();
/* 8075 */         mk = (IPersistentVector)mk.pop();
/* 8076 */         java.lang.reflect.Method m = (java.lang.reflect.Method)e.getValue();
/* 8077 */         if (mm.containsKey(mk))
/*      */         {
/* 8079 */           Set<Class> cvs = (Set)covariants.get(mk);
/* 8080 */           if (cvs == null)
/*      */           {
/* 8082 */             cvs = new java.util.HashSet();
/* 8083 */             covariants.put(mk, cvs);
/*      */           }
/* 8085 */           java.lang.reflect.Method om = (java.lang.reflect.Method)mm.get(mk);
/* 8086 */           if (om.getReturnType().isAssignableFrom(m.getReturnType()))
/*      */           {
/* 8088 */             cvs.add(om.getReturnType());
/* 8089 */             mm.put(mk, m);
/*      */           }
/*      */           else {
/* 8092 */             cvs.add(m.getReturnType());
/*      */           }
/*      */         } else {
/* 8095 */           mm.put(mk, m);
/*      */         } }
/* 8097 */       return new Map[] { mm, covariants };
/*      */     }
/*      */   }
/*      */   
/*      */   public static class NewInstanceMethod extends Compiler.ObjMethod
/*      */   {
/*      */     String name;
/*      */     Type[] argTypes;
/*      */     Type retType;
/*      */     Class retClass;
/*      */     Class[] exclasses;
/* 8108 */     static Symbol dummyThis = Symbol.intern(null, "dummy_this_dlskjsdfower");
/*      */     private IPersistentVector parms;
/*      */     
/*      */     public NewInstanceMethod(Compiler.ObjExpr objx, Compiler.ObjMethod parent) {
/* 8112 */       super(parent);
/*      */     }
/*      */     
/*      */     int numParams() {
/* 8116 */       return this.argLocals.count();
/*      */     }
/*      */     
/*      */     String getMethodName() {
/* 8120 */       return this.name;
/*      */     }
/*      */     
/*      */     Type getReturnType() {
/* 8124 */       return this.retType;
/*      */     }
/*      */     
/*      */     Type[] getArgTypes() {
/* 8128 */       return this.argTypes;
/*      */     }
/*      */     
/*      */ 
/*      */     public static IPersistentVector msig(String name, Class[] paramTypes)
/*      */     {
/* 8134 */       return RT.vector(new Object[] { name, RT.seq(paramTypes) });
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     static NewInstanceMethod parse(Compiler.ObjExpr objx, ISeq form, Symbol thistag, Map overrideables)
/*      */     {
/* 8141 */       NewInstanceMethod method = new NewInstanceMethod(objx, (Compiler.ObjMethod)Compiler.METHOD.deref());
/* 8142 */       Symbol dotname = (Symbol)RT.first(form);
/* 8143 */       Symbol name = (Symbol)Symbol.intern(null, Compiler.munge(dotname.name)).withMeta(RT.meta(dotname));
/* 8144 */       IPersistentVector parms = (IPersistentVector)RT.second(form);
/* 8145 */       if (parms.count() == 0)
/*      */       {
/* 8147 */         throw new IllegalArgumentException("Must supply at least one argument for 'this' in: " + dotname);
/*      */       }
/* 8149 */       Symbol thisName = (Symbol)parms.nth(0);
/* 8150 */       parms = RT.subvec(parms, 1, parms.count());
/* 8151 */       ISeq body = RT.next(RT.next(form));
/*      */       try
/*      */       {
/* 8154 */         method.line = Compiler.lineDeref();
/* 8155 */         method.column = Compiler.columnDeref();
/*      */         
/* 8157 */         Compiler.PathNode pnode = new Compiler.PathNode(Compiler.PATHTYPE.PATH, (Compiler.PathNode)Compiler.CLEAR_PATH.get());
/* 8158 */         Var.pushThreadBindings(RT.mapUniqueKeys(new Object[] { Compiler.METHOD, method, Compiler.LOCAL_ENV, Compiler.LOCAL_ENV.deref(), Compiler.LOOP_LOCALS, null, Compiler.NEXT_LOCAL_NUM, Integer.valueOf(0), Compiler.CLEAR_PATH, pnode, Compiler.CLEAR_ROOT, pnode, Compiler.CLEAR_SITES, PersistentHashMap.EMPTY }));
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 8170 */         if (thisName != null) {
/* 8171 */           Compiler.registerLocal(thisName == null ? dummyThis : thisName, thistag, null, false);
/*      */         } else {
/* 8173 */           Compiler.access$900();
/*      */         }
/* 8175 */         PersistentVector argLocals = PersistentVector.EMPTY;
/* 8176 */         method.retClass = Compiler.tagClass(Compiler.tagOf(name));
/* 8177 */         method.argTypes = new Type[parms.count()];
/* 8178 */         boolean hinted = Compiler.tagOf(name) != null;
/* 8179 */         Class[] pclasses = new Class[parms.count()];
/* 8180 */         Symbol[] psyms = new Symbol[parms.count()];
/*      */         
/* 8182 */         for (int i = 0; i < parms.count(); i++)
/*      */         {
/* 8184 */           if (!(parms.nth(i) instanceof Symbol))
/* 8185 */             throw new IllegalArgumentException("params must be Symbols");
/* 8186 */           Symbol p = (Symbol)parms.nth(i);
/* 8187 */           Object tag = Compiler.tagOf(p);
/* 8188 */           if (tag != null)
/* 8189 */             hinted = true;
/* 8190 */           if (p.getNamespace() != null)
/* 8191 */             p = Symbol.intern(p.name);
/* 8192 */           Class pclass = Compiler.tagClass(tag);
/* 8193 */           pclasses[i] = pclass;
/* 8194 */           psyms[i] = p;
/*      */         }
/* 8196 */         Map matches = findMethodsWithNameAndArity(name.name, parms.count(), overrideables);
/* 8197 */         Object mk = msig(name.name, pclasses);
/* 8198 */         java.lang.reflect.Method m = null;
/* 8199 */         if (matches.size() > 0)
/*      */         {
/*      */ 
/* 8202 */           if (matches.size() > 1)
/*      */           {
/*      */ 
/* 8205 */             if (!hinted)
/* 8206 */               throw new IllegalArgumentException("Must hint overloaded method: " + name.name);
/* 8207 */             m = (java.lang.reflect.Method)matches.get(mk);
/* 8208 */             if (m == null)
/* 8209 */               throw new IllegalArgumentException("Can't find matching overloaded method: " + name.name);
/* 8210 */             if (m.getReturnType() != method.retClass) {
/* 8211 */               throw new IllegalArgumentException("Mismatched return type: " + name.name + ", expected: " + m.getReturnType().getName() + ", had: " + method.retClass.getName());
/*      */ 
/*      */             }
/*      */             
/*      */ 
/*      */           }
/* 8217 */           else if (hinted)
/*      */           {
/* 8219 */             m = (java.lang.reflect.Method)matches.get(mk);
/* 8220 */             if (m == null) {
/* 8221 */               throw new IllegalArgumentException("Can't find matching method: " + name.name + ", leave off hints for auto match.");
/*      */             }
/* 8223 */             if (m.getReturnType() != method.retClass) {
/* 8224 */               throw new IllegalArgumentException("Mismatched return type: " + name.name + ", expected: " + m.getReturnType().getName() + ", had: " + method.retClass.getName());
/*      */             }
/*      */           }
/*      */           else
/*      */           {
/* 8229 */             m = (java.lang.reflect.Method)matches.values().iterator().next();
/* 8230 */             method.retClass = m.getReturnType();
/* 8231 */             pclasses = m.getParameterTypes();
/*      */           }
/*      */           
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/* 8238 */           throw new IllegalArgumentException("Can't define method not in interfaces: " + name.name);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 8243 */         method.retType = Type.getType(method.retClass);
/* 8244 */         method.exclasses = m.getExceptionTypes();
/*      */         
/* 8246 */         for (int i = 0; i < parms.count(); i++)
/*      */         {
/* 8248 */           Compiler.LocalBinding lb = Compiler.registerLocal(psyms[i], null, new Compiler.MethodParamExpr(pclasses[i]), true);
/* 8249 */           argLocals = argLocals.assocN(i, lb);
/* 8250 */           method.argTypes[i] = Type.getType(pclasses[i]);
/*      */         }
/* 8252 */         for (int i = 0; i < parms.count(); i++)
/*      */         {
/* 8254 */           if ((pclasses[i] == Long.TYPE) || (pclasses[i] == Double.TYPE))
/* 8255 */             Compiler.access$900();
/*      */         }
/* 8257 */         Compiler.LOOP_LOCALS.set(argLocals);
/* 8258 */         method.name = name.name;
/* 8259 */         method.methodMeta = RT.meta(name);
/* 8260 */         method.parms = parms;
/* 8261 */         method.argLocals = argLocals;
/* 8262 */         method.body = new Compiler.BodyExpr.Parser().parse(Compiler.C.RETURN, body);
/* 8263 */         return method;
/*      */       }
/*      */       finally
/*      */       {
/* 8267 */         Var.popThreadBindings();
/*      */       }
/*      */     }
/*      */     
/*      */     private static Map findMethodsWithNameAndArity(String name, int arity, Map mm) {
/* 8272 */       Map ret = new HashMap();
/* 8273 */       for (Object o : mm.entrySet())
/*      */       {
/* 8275 */         Map.Entry e = (Map.Entry)o;
/* 8276 */         java.lang.reflect.Method m = (java.lang.reflect.Method)e.getValue();
/* 8277 */         if ((name.equals(m.getName())) && (m.getParameterTypes().length == arity))
/* 8278 */           ret.put(e.getKey(), e.getValue());
/*      */       }
/* 8280 */       return ret;
/*      */     }
/*      */     
/*      */     private static Map findMethodsWithName(String name, Map mm) {
/* 8284 */       Map ret = new HashMap();
/* 8285 */       for (Object o : mm.entrySet())
/*      */       {
/* 8287 */         Map.Entry e = (Map.Entry)o;
/* 8288 */         java.lang.reflect.Method m = (java.lang.reflect.Method)e.getValue();
/* 8289 */         if (name.equals(m.getName()))
/* 8290 */           ret.put(e.getKey(), e.getValue());
/*      */       }
/* 8292 */       return ret;
/*      */     }
/*      */     
/*      */     public void emit(Compiler.ObjExpr obj, ClassVisitor cv) {
/* 8296 */       clojure.asm.commons.Method m = new clojure.asm.commons.Method(getMethodName(), getReturnType(), getArgTypes());
/*      */       
/* 8298 */       Type[] extypes = null;
/* 8299 */       if (this.exclasses.length > 0)
/*      */       {
/* 8301 */         extypes = new Type[this.exclasses.length];
/* 8302 */         for (int i = 0; i < this.exclasses.length; i++)
/* 8303 */           extypes[i] = Type.getType(this.exclasses[i]);
/*      */       }
/* 8305 */       GeneratorAdapter gen = new GeneratorAdapter(1, m, null, extypes, cv);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 8310 */       Compiler.addAnnotation(gen, this.methodMeta);
/* 8311 */       for (int i = 0; i < this.parms.count(); i++)
/*      */       {
/* 8313 */         IPersistentMap meta = RT.meta(this.parms.nth(i));
/* 8314 */         Compiler.addParameterAnnotation(gen, meta, i);
/*      */       }
/* 8316 */       gen.visitCode();
/*      */       
/* 8318 */       Label loopLabel = gen.mark();
/*      */       
/* 8320 */       gen.visitLineNumber(this.line, loopLabel);
/*      */       try
/*      */       {
/* 8323 */         Var.pushThreadBindings(RT.map(new Object[] { Compiler.LOOP_LABEL, loopLabel, Compiler.METHOD, this }));
/*      */         
/* 8325 */         emitBody(this.objx, gen, this.retClass, this.body);
/* 8326 */         Label end = gen.mark();
/* 8327 */         gen.visitLocalVariable("this", obj.objtype.getDescriptor(), null, loopLabel, end, 0);
/* 8328 */         for (ISeq lbs = this.argLocals.seq(); lbs != null; lbs = lbs.next())
/*      */         {
/* 8330 */           Compiler.LocalBinding lb = (Compiler.LocalBinding)lbs.first();
/* 8331 */           gen.visitLocalVariable(lb.name, this.argTypes[(lb.idx - 1)].getDescriptor(), null, loopLabel, end, lb.idx);
/*      */         }
/*      */       }
/*      */       finally
/*      */       {
/* 8336 */         Var.popThreadBindings();
/*      */       }
/*      */       
/* 8339 */       gen.returnValue();
/*      */       
/* 8341 */       gen.endMethod();
/*      */     }
/*      */   }
/*      */   
/*      */   static boolean inty(Class c) {
/* 8346 */     return (c == Integer.TYPE) || (c == Short.TYPE) || (c == Byte.TYPE) || (c == Character.TYPE);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   static Class retType(Class tc, Class ret)
/*      */   {
/* 8353 */     if (tc == null)
/* 8354 */       return ret;
/* 8355 */     if (ret == null)
/* 8356 */       return tc;
/* 8357 */     if ((ret.isPrimitive()) && (tc.isPrimitive())) {
/* 8358 */       if (((inty(ret)) && (inty(tc))) || (ret == tc))
/* 8359 */         return tc;
/* 8360 */       throw new UnsupportedOperationException("Cannot coerce " + ret + " to " + tc + ", use a cast instead");
/*      */     }
/*      */     
/* 8363 */     return tc;
/*      */   }
/*      */   
/*      */   static Class primClass(Symbol sym) {
/* 8367 */     if (sym == null)
/* 8368 */       return null;
/* 8369 */     Class c = null;
/* 8370 */     if (sym.name.equals("int")) {
/* 8371 */       c = Integer.TYPE;
/* 8372 */     } else if (sym.name.equals("long")) {
/* 8373 */       c = Long.TYPE;
/* 8374 */     } else if (sym.name.equals("float")) {
/* 8375 */       c = Float.TYPE;
/* 8376 */     } else if (sym.name.equals("double")) {
/* 8377 */       c = Double.TYPE;
/* 8378 */     } else if (sym.name.equals("char")) {
/* 8379 */       c = Character.TYPE;
/* 8380 */     } else if (sym.name.equals("short")) {
/* 8381 */       c = Short.TYPE;
/* 8382 */     } else if (sym.name.equals("byte")) {
/* 8383 */       c = Byte.TYPE;
/* 8384 */     } else if (sym.name.equals("boolean")) {
/* 8385 */       c = Boolean.TYPE;
/* 8386 */     } else if (sym.name.equals("void"))
/* 8387 */       c = Void.TYPE;
/* 8388 */     return c;
/*      */   }
/*      */   
/*      */   static Class tagClass(Object tag) {
/* 8392 */     if (tag == null)
/* 8393 */       return Object.class;
/* 8394 */     Class c = null;
/* 8395 */     if ((tag instanceof Symbol))
/* 8396 */       c = primClass((Symbol)tag);
/* 8397 */     if (c == null)
/* 8398 */       c = HostExpr.tagToClass(tag);
/* 8399 */     return c;
/*      */   }
/*      */   
/*      */   static Class primClass(Class c) {
/* 8403 */     return c.isPrimitive() ? c : Object.class;
/*      */   }
/*      */   
/*      */   static Class boxClass(Class p) {
/* 8407 */     if (!p.isPrimitive()) {
/* 8408 */       return p;
/*      */     }
/* 8410 */     Class c = null;
/*      */     
/* 8412 */     if (p == Integer.TYPE) {
/* 8413 */       c = Integer.class;
/* 8414 */     } else if (p == Long.TYPE) {
/* 8415 */       c = Long.class;
/* 8416 */     } else if (p == Float.TYPE) {
/* 8417 */       c = Float.class;
/* 8418 */     } else if (p == Double.TYPE) {
/* 8419 */       c = Double.class;
/* 8420 */     } else if (p == Character.TYPE) {
/* 8421 */       c = Character.class;
/* 8422 */     } else if (p == Short.TYPE) {
/* 8423 */       c = Short.class;
/* 8424 */     } else if (p == Byte.TYPE) {
/* 8425 */       c = Byte.class;
/* 8426 */     } else if (p == Boolean.TYPE) {
/* 8427 */       c = Boolean.class;
/*      */     }
/* 8429 */     return c;
/*      */   }
/*      */   
/*      */   public static class MethodParamExpr implements Compiler.Expr, Compiler.MaybePrimitiveExpr {
/*      */     final Class c;
/*      */     
/*      */     public MethodParamExpr(Class c) {
/* 8436 */       this.c = c;
/*      */     }
/*      */     
/*      */     public Object eval() {
/* 8440 */       throw Util.runtimeException("Can't eval");
/*      */     }
/*      */     
/*      */     public void emit(Compiler.C context, Compiler.ObjExpr objx, GeneratorAdapter gen) {
/* 8444 */       throw Util.runtimeException("Can't emit");
/*      */     }
/*      */     
/*      */     public boolean hasJavaClass() {
/* 8448 */       return this.c != null;
/*      */     }
/*      */     
/*      */     public Class getJavaClass() {
/* 8452 */       return this.c;
/*      */     }
/*      */     
/*      */     public boolean canEmitPrimitive() {
/* 8456 */       return Util.isPrimitive(this.c);
/*      */     }
/*      */     
/*      */ 
/* 8460 */     public void emitUnboxed(Compiler.C context, Compiler.ObjExpr objx, GeneratorAdapter gen) { throw Util.runtimeException("Can't emit"); }
/*      */   }
/*      */   
/*      */   public static class CaseExpr implements Compiler.Expr, Compiler.MaybePrimitiveExpr { public final Compiler.LocalBindingExpr expr;
/*      */     public final int shift;
/*      */     public final int mask;
/*      */     public final int low;
/*      */     public final int high;
/*      */     public final Compiler.Expr defaultExpr;
/*      */     public final SortedMap<Integer, Compiler.Expr> tests;
/*      */     public final HashMap<Integer, Compiler.Expr> thens;
/*      */     public final Keyword switchType;
/*      */     public final Keyword testType;
/*      */     public final Set<Integer> skipCheck;
/*      */     public final Class returnType;
/*      */     public final int line;
/*      */     public final int column;
/* 8477 */     static final Type NUMBER_TYPE = Type.getType(Number.class);
/* 8478 */     static final clojure.asm.commons.Method intValueMethod = clojure.asm.commons.Method.getMethod("int intValue()");
/*      */     
/* 8480 */     static final clojure.asm.commons.Method hashMethod = clojure.asm.commons.Method.getMethod("int hash(Object)");
/* 8481 */     static final clojure.asm.commons.Method hashCodeMethod = clojure.asm.commons.Method.getMethod("int hashCode()");
/* 8482 */     static final clojure.asm.commons.Method equivMethod = clojure.asm.commons.Method.getMethod("boolean equiv(Object, Object)");
/* 8483 */     static final Keyword compactKey = Keyword.intern(null, "compact");
/* 8484 */     static final Keyword sparseKey = Keyword.intern(null, "sparse");
/* 8485 */     static final Keyword hashIdentityKey = Keyword.intern(null, "hash-identity");
/* 8486 */     static final Keyword hashEquivKey = Keyword.intern(null, "hash-equiv");
/* 8487 */     static final Keyword intKey = Keyword.intern(null, "int");
/*      */     
/*      */     public CaseExpr(int line, int column, Compiler.LocalBindingExpr expr, int shift, int mask, int low, int high, Compiler.Expr defaultExpr, SortedMap<Integer, Compiler.Expr> tests, HashMap<Integer, Compiler.Expr> thens, Keyword switchType, Keyword testType, Set<Integer> skipCheck)
/*      */     {
/* 8491 */       this.expr = expr;
/* 8492 */       this.shift = shift;
/* 8493 */       this.mask = mask;
/* 8494 */       this.low = low;
/* 8495 */       this.high = high;
/* 8496 */       this.defaultExpr = defaultExpr;
/* 8497 */       this.tests = tests;
/* 8498 */       this.thens = thens;
/* 8499 */       this.line = line;
/* 8500 */       this.column = column;
/* 8501 */       if ((switchType != compactKey) && (switchType != sparseKey))
/* 8502 */         throw new IllegalArgumentException("Unexpected switch type: " + switchType);
/* 8503 */       this.switchType = switchType;
/* 8504 */       if ((testType != intKey) && (testType != hashEquivKey) && (testType != hashIdentityKey))
/* 8505 */         throw new IllegalArgumentException("Unexpected test type: " + switchType);
/* 8506 */       this.testType = testType;
/* 8507 */       this.skipCheck = skipCheck;
/* 8508 */       Collection<Compiler.Expr> returns = new ArrayList(thens.values());
/* 8509 */       returns.add(defaultExpr);
/* 8510 */       this.returnType = Compiler.maybeJavaClass(returns);
/* 8511 */       if ((RT.count(skipCheck) > 0) && (RT.booleanCast(RT.WARN_ON_REFLECTION.deref())))
/*      */       {
/* 8513 */         RT.errPrintWriter().format("Performance warning, %s:%d:%d - hash collision of some case test constants; if selected, those entries will be tested sequentially.\n", new Object[] { Compiler.SOURCE_PATH.deref(), Integer.valueOf(line), Integer.valueOf(column) });
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */     public boolean hasJavaClass()
/*      */     {
/* 8520 */       return this.returnType != null;
/*      */     }
/*      */     
/*      */     public boolean canEmitPrimitive() {
/* 8524 */       return Util.isPrimitive(this.returnType);
/*      */     }
/*      */     
/*      */     public Class getJavaClass() {
/* 8528 */       return this.returnType;
/*      */     }
/*      */     
/*      */     public Object eval() {
/* 8532 */       throw new UnsupportedOperationException("Can't eval case");
/*      */     }
/*      */     
/*      */     public void emit(Compiler.C context, Compiler.ObjExpr objx, GeneratorAdapter gen) {
/* 8536 */       doEmit(context, objx, gen, false);
/*      */     }
/*      */     
/*      */     public void emitUnboxed(Compiler.C context, Compiler.ObjExpr objx, GeneratorAdapter gen) {
/* 8540 */       doEmit(context, objx, gen, true);
/*      */     }
/*      */     
/*      */     public void doEmit(Compiler.C context, Compiler.ObjExpr objx, GeneratorAdapter gen, boolean emitUnboxed) {
/* 8544 */       Label defaultLabel = gen.newLabel();
/* 8545 */       Label endLabel = gen.newLabel();
/* 8546 */       SortedMap<Integer, Label> labels = new TreeMap();
/*      */       
/* 8548 */       for (Integer i : this.tests.keySet())
/*      */       {
/* 8550 */         labels.put(i, gen.newLabel());
/*      */       }
/*      */       
/* 8553 */       gen.visitLineNumber(this.line, gen.mark());
/*      */       
/* 8555 */       Class primExprClass = Compiler.maybePrimitiveType(this.expr);
/* 8556 */       Type primExprType = primExprClass == null ? null : Type.getType(primExprClass);
/*      */       
/* 8558 */       if (this.testType == intKey) {
/* 8559 */         emitExprForInts(objx, gen, primExprType, defaultLabel);
/*      */       } else {
/* 8561 */         emitExprForHashes(objx, gen);
/*      */       }
/* 8563 */       if (this.switchType == sparseKey)
/*      */       {
/* 8565 */         Label[] la = new Label[labels.size()];
/* 8566 */         la = (Label[])labels.values().toArray(la);
/* 8567 */         int[] ints = Numbers.int_array(this.tests.keySet());
/* 8568 */         gen.visitLookupSwitchInsn(defaultLabel, ints, la);
/*      */       }
/*      */       else
/*      */       {
/* 8572 */         Label[] la = new Label[this.high - this.low + 1];
/* 8573 */         for (int i = this.low; i <= this.high; i++)
/*      */         {
/* 8575 */           la[(i - this.low)] = (labels.containsKey(Integer.valueOf(i)) ? (Label)labels.get(Integer.valueOf(i)) : defaultLabel);
/*      */         }
/* 8577 */         gen.visitTableSwitchInsn(this.low, this.high, defaultLabel, la);
/*      */       }
/*      */       
/* 8580 */       for (Integer i : labels.keySet())
/*      */       {
/* 8582 */         gen.mark((Label)labels.get(i));
/* 8583 */         if (this.testType == intKey) {
/* 8584 */           emitThenForInts(objx, gen, primExprType, (Compiler.Expr)this.tests.get(i), (Compiler.Expr)this.thens.get(i), defaultLabel, emitUnboxed);
/* 8585 */         } else if (RT.contains(this.skipCheck, i) == RT.T) {
/* 8586 */           emitExpr(objx, gen, (Compiler.Expr)this.thens.get(i), emitUnboxed);
/*      */         } else
/* 8588 */           emitThenForHashes(objx, gen, (Compiler.Expr)this.tests.get(i), (Compiler.Expr)this.thens.get(i), defaultLabel, emitUnboxed);
/* 8589 */         gen.goTo(endLabel);
/*      */       }
/*      */       
/* 8592 */       gen.mark(defaultLabel);
/* 8593 */       emitExpr(objx, gen, this.defaultExpr, emitUnboxed);
/* 8594 */       gen.mark(endLabel);
/* 8595 */       if (context == Compiler.C.STATEMENT)
/* 8596 */         gen.pop();
/*      */     }
/*      */     
/*      */     private boolean isShiftMasked() {
/* 8600 */       return this.mask != 0;
/*      */     }
/*      */     
/*      */     private void emitShiftMask(GeneratorAdapter gen) {
/* 8604 */       if (isShiftMasked())
/*      */       {
/* 8606 */         gen.push(this.shift);
/* 8607 */         gen.visitInsn(122);
/* 8608 */         gen.push(this.mask);
/* 8609 */         gen.visitInsn(126);
/*      */       }
/*      */     }
/*      */     
/*      */     private void emitExprForInts(Compiler.ObjExpr objx, GeneratorAdapter gen, Type exprType, Label defaultLabel) {
/* 8614 */       if (exprType == null)
/*      */       {
/* 8616 */         if (RT.booleanCast(RT.WARN_ON_REFLECTION.deref()))
/*      */         {
/* 8618 */           RT.errPrintWriter().format("Performance warning, %s:%d:%d - case has int tests, but tested expression is not primitive.\n", new Object[] { Compiler.SOURCE_PATH.deref(), Integer.valueOf(this.line), Integer.valueOf(this.column) });
/*      */         }
/*      */         
/*      */ 
/* 8622 */         this.expr.emit(Compiler.C.EXPRESSION, objx, gen);
/* 8623 */         gen.instanceOf(NUMBER_TYPE);
/* 8624 */         gen.ifZCmp(153, defaultLabel);
/* 8625 */         this.expr.emit(Compiler.C.EXPRESSION, objx, gen);
/* 8626 */         gen.checkCast(NUMBER_TYPE);
/* 8627 */         gen.invokeVirtual(NUMBER_TYPE, intValueMethod);
/* 8628 */         emitShiftMask(gen);
/*      */       }
/* 8630 */       else if ((exprType == Type.LONG_TYPE) || (exprType == Type.INT_TYPE) || (exprType == Type.SHORT_TYPE) || (exprType == Type.BYTE_TYPE))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/* 8635 */         this.expr.emitUnboxed(Compiler.C.EXPRESSION, objx, gen);
/* 8636 */         gen.cast(exprType, Type.INT_TYPE);
/* 8637 */         emitShiftMask(gen);
/*      */       }
/*      */       else
/*      */       {
/* 8641 */         gen.goTo(defaultLabel);
/*      */       }
/*      */     }
/*      */     
/*      */     private void emitThenForInts(Compiler.ObjExpr objx, GeneratorAdapter gen, Type exprType, Compiler.Expr test, Compiler.Expr then, Label defaultLabel, boolean emitUnboxed) {
/* 8646 */       if (exprType == null)
/*      */       {
/* 8648 */         this.expr.emit(Compiler.C.EXPRESSION, objx, gen);
/* 8649 */         test.emit(Compiler.C.EXPRESSION, objx, gen);
/* 8650 */         gen.invokeStatic(Compiler.UTIL_TYPE, equivMethod);
/* 8651 */         gen.ifZCmp(153, defaultLabel);
/* 8652 */         emitExpr(objx, gen, then, emitUnboxed);
/*      */       }
/* 8654 */       else if (exprType == Type.LONG_TYPE)
/*      */       {
/* 8656 */         ((Compiler.NumberExpr)test).emitUnboxed(Compiler.C.EXPRESSION, objx, gen);
/* 8657 */         this.expr.emitUnboxed(Compiler.C.EXPRESSION, objx, gen);
/* 8658 */         gen.ifCmp(Type.LONG_TYPE, 154, defaultLabel);
/* 8659 */         emitExpr(objx, gen, then, emitUnboxed);
/*      */       }
/* 8661 */       else if ((exprType == Type.INT_TYPE) || (exprType == Type.SHORT_TYPE) || (exprType == Type.BYTE_TYPE))
/*      */       {
/*      */ 
/*      */ 
/* 8665 */         if (isShiftMasked())
/*      */         {
/* 8667 */           ((Compiler.NumberExpr)test).emitUnboxed(Compiler.C.EXPRESSION, objx, gen);
/* 8668 */           this.expr.emitUnboxed(Compiler.C.EXPRESSION, objx, gen);
/* 8669 */           gen.cast(exprType, Type.LONG_TYPE);
/* 8670 */           gen.ifCmp(Type.LONG_TYPE, 154, defaultLabel);
/*      */         }
/*      */         
/* 8673 */         emitExpr(objx, gen, then, emitUnboxed);
/*      */       }
/*      */       else
/*      */       {
/* 8677 */         gen.goTo(defaultLabel);
/*      */       }
/*      */     }
/*      */     
/*      */     private void emitExprForHashes(Compiler.ObjExpr objx, GeneratorAdapter gen) {
/* 8682 */       this.expr.emit(Compiler.C.EXPRESSION, objx, gen);
/* 8683 */       gen.invokeStatic(Compiler.UTIL_TYPE, hashMethod);
/* 8684 */       emitShiftMask(gen);
/*      */     }
/*      */     
/*      */     private void emitThenForHashes(Compiler.ObjExpr objx, GeneratorAdapter gen, Compiler.Expr test, Compiler.Expr then, Label defaultLabel, boolean emitUnboxed) {
/* 8688 */       this.expr.emit(Compiler.C.EXPRESSION, objx, gen);
/* 8689 */       test.emit(Compiler.C.EXPRESSION, objx, gen);
/* 8690 */       if (this.testType == hashIdentityKey)
/*      */       {
/* 8692 */         gen.visitJumpInsn(166, defaultLabel);
/*      */       }
/*      */       else
/*      */       {
/* 8696 */         gen.invokeStatic(Compiler.UTIL_TYPE, equivMethod);
/* 8697 */         gen.ifZCmp(153, defaultLabel);
/*      */       }
/* 8699 */       emitExpr(objx, gen, then, emitUnboxed);
/*      */     }
/*      */     
/*      */     private static void emitExpr(Compiler.ObjExpr objx, GeneratorAdapter gen, Compiler.Expr expr, boolean emitUnboxed) {
/* 8703 */       if ((emitUnboxed) && ((expr instanceof Compiler.MaybePrimitiveExpr))) {
/* 8704 */         ((Compiler.MaybePrimitiveExpr)expr).emitUnboxed(Compiler.C.EXPRESSION, objx, gen);
/*      */       } else {
/* 8706 */         expr.emit(Compiler.C.EXPRESSION, objx, gen);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */     static class Parser
/*      */       implements Compiler.IParser
/*      */     {
/*      */       public Compiler.Expr parse(Compiler.C context, Object frm)
/*      */       {
/* 8716 */         ISeq form = (ISeq)frm;
/* 8717 */         if (context == Compiler.C.EVAL)
/* 8718 */           return Compiler.analyze(context, RT.list(RT.list(Compiler.FNONCE, PersistentVector.EMPTY, form)));
/* 8719 */         IPersistentVector args = LazilyPersistentVector.create(form.next());
/*      */         
/* 8721 */         Object exprForm = args.nth(0);
/* 8722 */         int shift = ((Number)args.nth(1)).intValue();
/* 8723 */         int mask = ((Number)args.nth(2)).intValue();
/* 8724 */         Object defaultForm = args.nth(3);
/* 8725 */         Map caseMap = (Map)args.nth(4);
/* 8726 */         Keyword switchType = (Keyword)args.nth(5);
/* 8727 */         Keyword testType = (Keyword)args.nth(6);
/* 8728 */         Set skipCheck = RT.count(args) < 8 ? null : (Set)args.nth(7);
/*      */         
/* 8730 */         ISeq keys = RT.keys(caseMap);
/* 8731 */         int low = ((Number)RT.first(keys)).intValue();
/* 8732 */         int high = ((Number)RT.nth(keys, RT.count(keys) - 1)).intValue();
/*      */         
/* 8734 */         Compiler.LocalBindingExpr testexpr = (Compiler.LocalBindingExpr)Compiler.analyze(Compiler.C.EXPRESSION, exprForm);
/* 8735 */         testexpr.shouldClear = false;
/*      */         
/* 8737 */         SortedMap<Integer, Compiler.Expr> tests = new TreeMap();
/* 8738 */         HashMap<Integer, Compiler.Expr> thens = new HashMap();
/*      */         
/* 8740 */         Compiler.PathNode branch = new Compiler.PathNode(Compiler.PATHTYPE.BRANCH, (Compiler.PathNode)Compiler.CLEAR_PATH.get());
/*      */         
/* 8742 */         for (Object o : caseMap.entrySet())
/*      */         {
/* 8744 */           Map.Entry e = (Map.Entry)o;
/* 8745 */           Integer minhash = Integer.valueOf(((Number)e.getKey()).intValue());
/* 8746 */           Object pair = e.getValue();
/* 8747 */           Compiler.Expr testExpr = testType == Compiler.CaseExpr.intKey ? Compiler.NumberExpr.parse(Integer.valueOf(((Number)RT.first(pair)).intValue())) : new Compiler.ConstantExpr(RT.first(pair));
/*      */           
/*      */ 
/* 8750 */           tests.put(minhash, testExpr);
/*      */           Compiler.Expr thenExpr;
/*      */           try
/*      */           {
/* 8754 */             Var.pushThreadBindings(RT.map(new Object[] { Compiler.CLEAR_PATH, new Compiler.PathNode(Compiler.PATHTYPE.PATH, branch) }));
/*      */             
/* 8756 */             thenExpr = Compiler.analyze(context, RT.second(pair));
/*      */           }
/*      */           finally {
/* 8759 */             Var.popThreadBindings();
/*      */           }
/* 8761 */           thens.put(minhash, thenExpr);
/*      */         }
/*      */         Compiler.Expr defaultExpr;
/*      */         try
/*      */         {
/* 8766 */           Var.pushThreadBindings(RT.map(new Object[] { Compiler.CLEAR_PATH, new Compiler.PathNode(Compiler.PATHTYPE.PATH, branch) }));
/*      */           
/* 8768 */           defaultExpr = Compiler.analyze(context, args.nth(3));
/*      */         }
/*      */         finally {
/* 8771 */           Var.popThreadBindings();
/*      */         }
/*      */         
/* 8774 */         int line = ((Number)Compiler.LINE.deref()).intValue();
/* 8775 */         int column = ((Number)Compiler.COLUMN.deref()).intValue();
/* 8776 */         return new Compiler.CaseExpr(line, column, testexpr, shift, mask, low, high, defaultExpr, tests, thens, switchType, testType, skipCheck);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   static IPersistentCollection emptyVarCallSites() {
/* 8782 */     return PersistentHashSet.EMPTY;
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   public static Object eval(Object form, boolean freshLoader)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: iconst_0
/*      */     //   1: istore_2
/*      */     //   2: iconst_2
/*      */     //   3: anewarray 71	java/lang/Object
/*      */     //   6: dup
/*      */     //   7: iconst_0
/*      */     //   8: getstatic 228	clojure/lang/Compiler:LOADER	Lclojure/lang/Var;
/*      */     //   11: aastore
/*      */     //   12: dup
/*      */     //   13: iconst_1
/*      */     //   14: invokestatic 229	clojure/lang/RT:makeClassLoader	()Ljava/lang/ClassLoader;
/*      */     //   17: aastore
/*      */     //   18: invokestatic 198	clojure/lang/RT:map	([Ljava/lang/Object;)Lclojure/lang/IPersistentMap;
/*      */     //   21: invokestatic 211	clojure/lang/Var:pushThreadBindings	(Lclojure/lang/Associative;)V
/*      */     //   24: iconst_1
/*      */     //   25: istore_2
/*      */     //   26: invokestatic 161	clojure/lang/Compiler:lineDeref	()I
/*      */     //   29: invokestatic 115	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
/*      */     //   32: astore_3
/*      */     //   33: invokestatic 162	clojure/lang/Compiler:columnDeref	()I
/*      */     //   36: invokestatic 115	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
/*      */     //   39: astore 4
/*      */     //   41: aload_0
/*      */     //   42: invokestatic 122	clojure/lang/RT:meta	(Ljava/lang/Object;)Lclojure/lang/IPersistentMap;
/*      */     //   45: ifnull +31 -> 76
/*      */     //   48: aload_0
/*      */     //   49: invokestatic 122	clojure/lang/RT:meta	(Ljava/lang/Object;)Lclojure/lang/IPersistentMap;
/*      */     //   52: getstatic 209	clojure/lang/RT:LINE_KEY	Lclojure/lang/Keyword;
/*      */     //   55: invokeinterface 33 2 0
/*      */     //   60: ifeq +16 -> 76
/*      */     //   63: aload_0
/*      */     //   64: invokestatic 122	clojure/lang/RT:meta	(Ljava/lang/Object;)Lclojure/lang/IPersistentMap;
/*      */     //   67: getstatic 209	clojure/lang/RT:LINE_KEY	Lclojure/lang/Keyword;
/*      */     //   70: invokeinterface 86 2 0
/*      */     //   75: astore_3
/*      */     //   76: aload_0
/*      */     //   77: invokestatic 122	clojure/lang/RT:meta	(Ljava/lang/Object;)Lclojure/lang/IPersistentMap;
/*      */     //   80: ifnull +32 -> 112
/*      */     //   83: aload_0
/*      */     //   84: invokestatic 122	clojure/lang/RT:meta	(Ljava/lang/Object;)Lclojure/lang/IPersistentMap;
/*      */     //   87: getstatic 210	clojure/lang/RT:COLUMN_KEY	Lclojure/lang/Keyword;
/*      */     //   90: invokeinterface 33 2 0
/*      */     //   95: ifeq +17 -> 112
/*      */     //   98: aload_0
/*      */     //   99: invokestatic 122	clojure/lang/RT:meta	(Ljava/lang/Object;)Lclojure/lang/IPersistentMap;
/*      */     //   102: getstatic 210	clojure/lang/RT:COLUMN_KEY	Lclojure/lang/Keyword;
/*      */     //   105: invokeinterface 86 2 0
/*      */     //   110: astore 4
/*      */     //   112: iconst_4
/*      */     //   113: anewarray 71	java/lang/Object
/*      */     //   116: dup
/*      */     //   117: iconst_0
/*      */     //   118: getstatic 28	clojure/lang/Compiler:LINE	Lclojure/lang/Var;
/*      */     //   121: aastore
/*      */     //   122: dup
/*      */     //   123: iconst_1
/*      */     //   124: aload_3
/*      */     //   125: aastore
/*      */     //   126: dup
/*      */     //   127: iconst_2
/*      */     //   128: getstatic 31	clojure/lang/Compiler:COLUMN	Lclojure/lang/Var;
/*      */     //   131: aastore
/*      */     //   132: dup
/*      */     //   133: iconst_3
/*      */     //   134: aload 4
/*      */     //   136: aastore
/*      */     //   137: invokestatic 198	clojure/lang/RT:map	([Ljava/lang/Object;)Lclojure/lang/IPersistentMap;
/*      */     //   140: invokestatic 211	clojure/lang/Var:pushThreadBindings	(Lclojure/lang/Associative;)V
/*      */     //   143: aload_0
/*      */     //   144: invokestatic 208	clojure/lang/Compiler:macroexpand	(Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   147: astore_0
/*      */     //   148: aload_0
/*      */     //   149: instanceof 150
/*      */     //   152: ifeq +74 -> 226
/*      */     //   155: aload_0
/*      */     //   156: invokestatic 180	clojure/lang/RT:first	(Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   159: getstatic 230	clojure/lang/Compiler:DO	Lclojure/lang/Symbol;
/*      */     //   162: invokestatic 231	clojure/lang/Util:equals	(Ljava/lang/Object;Ljava/lang/Object;)Z
/*      */     //   165: ifeq +61 -> 226
/*      */     //   168: aload_0
/*      */     //   169: invokestatic 214	clojure/lang/RT:next	(Ljava/lang/Object;)Lclojure/lang/ISeq;
/*      */     //   172: astore 5
/*      */     //   174: aload 5
/*      */     //   176: invokestatic 214	clojure/lang/RT:next	(Ljava/lang/Object;)Lclojure/lang/ISeq;
/*      */     //   179: ifnull +23 -> 202
/*      */     //   182: aload 5
/*      */     //   184: invokestatic 180	clojure/lang/RT:first	(Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   187: iconst_0
/*      */     //   188: invokestatic 227	clojure/lang/Compiler:eval	(Ljava/lang/Object;Z)Ljava/lang/Object;
/*      */     //   191: pop
/*      */     //   192: aload 5
/*      */     //   194: invokestatic 214	clojure/lang/RT:next	(Ljava/lang/Object;)Lclojure/lang/ISeq;
/*      */     //   197: astore 5
/*      */     //   199: goto -25 -> 174
/*      */     //   202: aload 5
/*      */     //   204: invokestatic 180	clojure/lang/RT:first	(Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   207: iconst_0
/*      */     //   208: invokestatic 227	clojure/lang/Compiler:eval	(Ljava/lang/Object;Z)Ljava/lang/Object;
/*      */     //   211: astore 6
/*      */     //   213: invokestatic 212	clojure/lang/Var:popThreadBindings	()V
/*      */     //   216: iload_2
/*      */     //   217: ifeq +6 -> 223
/*      */     //   220: invokestatic 212	clojure/lang/Var:popThreadBindings	()V
/*      */     //   223: aload 6
/*      */     //   225: areturn
/*      */     //   226: aload_0
/*      */     //   227: instanceof 140
/*      */     //   230: ifne +38 -> 268
/*      */     //   233: aload_0
/*      */     //   234: instanceof 138
/*      */     //   237: ifeq +105 -> 342
/*      */     //   240: aload_0
/*      */     //   241: invokestatic 180	clojure/lang/RT:first	(Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   244: instanceof 130
/*      */     //   247: ifeq +21 -> 268
/*      */     //   250: aload_0
/*      */     //   251: invokestatic 180	clojure/lang/RT:first	(Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   254: checkcast 130	clojure/lang/Symbol
/*      */     //   257: getfield 34	clojure/lang/Symbol:name	Ljava/lang/String;
/*      */     //   260: ldc -24
/*      */     //   262: invokevirtual 233	java/lang/String:startsWith	(Ljava/lang/String;)Z
/*      */     //   265: ifne +77 -> 342
/*      */     //   268: getstatic 146	clojure/lang/Compiler$C:EXPRESSION	Lclojure/lang/Compiler$C;
/*      */     //   271: getstatic 219	clojure/lang/Compiler:FN	Lclojure/lang/Symbol;
/*      */     //   274: getstatic 234	clojure/lang/PersistentVector:EMPTY	Lclojure/lang/PersistentVector;
/*      */     //   277: aload_0
/*      */     //   278: invokestatic 235	clojure/lang/RT:list	(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Lclojure/lang/ISeq;
/*      */     //   281: new 60	java/lang/StringBuilder
/*      */     //   284: dup
/*      */     //   285: invokespecial 61	java/lang/StringBuilder:<init>	()V
/*      */     //   288: ldc -20
/*      */     //   290: invokevirtual 65	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   293: invokestatic 237	clojure/lang/RT:nextID	()I
/*      */     //   296: invokevirtual 238	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
/*      */     //   299: invokevirtual 67	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*      */     //   302: invokestatic 13	clojure/lang/Compiler:analyze	(Lclojure/lang/Compiler$C;Ljava/lang/Object;Ljava/lang/String;)Lclojure/lang/Compiler$Expr;
/*      */     //   305: checkcast 239	clojure/lang/Compiler$ObjExpr
/*      */     //   308: astore 5
/*      */     //   310: aload 5
/*      */     //   312: invokevirtual 240	clojure/lang/Compiler$ObjExpr:eval	()Ljava/lang/Object;
/*      */     //   315: checkcast 175	clojure/lang/IFn
/*      */     //   318: astore 6
/*      */     //   320: aload 6
/*      */     //   322: invokeinterface 241 1 0
/*      */     //   327: astore 7
/*      */     //   329: invokestatic 212	clojure/lang/Var:popThreadBindings	()V
/*      */     //   332: iload_2
/*      */     //   333: ifeq +6 -> 339
/*      */     //   336: invokestatic 212	clojure/lang/Var:popThreadBindings	()V
/*      */     //   339: aload 7
/*      */     //   341: areturn
/*      */     //   342: getstatic 145	clojure/lang/Compiler$C:EVAL	Lclojure/lang/Compiler$C;
/*      */     //   345: aload_0
/*      */     //   346: invokestatic 218	clojure/lang/Compiler:analyze	(Lclojure/lang/Compiler$C;Ljava/lang/Object;)Lclojure/lang/Compiler$Expr;
/*      */     //   349: astore 5
/*      */     //   351: aload 5
/*      */     //   353: invokeinterface 242 1 0
/*      */     //   358: astore 6
/*      */     //   360: invokestatic 212	clojure/lang/Var:popThreadBindings	()V
/*      */     //   363: iload_2
/*      */     //   364: ifeq +6 -> 370
/*      */     //   367: invokestatic 212	clojure/lang/Var:popThreadBindings	()V
/*      */     //   370: aload 6
/*      */     //   372: areturn
/*      */     //   373: astore 8
/*      */     //   375: invokestatic 212	clojure/lang/Var:popThreadBindings	()V
/*      */     //   378: aload 8
/*      */     //   380: athrow
/*      */     //   381: astore 9
/*      */     //   383: iload_2
/*      */     //   384: ifeq +6 -> 390
/*      */     //   387: invokestatic 212	clojure/lang/Var:popThreadBindings	()V
/*      */     //   390: aload 9
/*      */     //   392: athrow
/*      */     // Line number table:
/*      */     //   Java source line #6894	-> byte code offset #0
/*      */     //   Java source line #6897	-> byte code offset #2
/*      */     //   Java source line #6898	-> byte code offset #24
/*      */     //   Java source line #6902	-> byte code offset #26
/*      */     //   Java source line #6903	-> byte code offset #33
/*      */     //   Java source line #6904	-> byte code offset #41
/*      */     //   Java source line #6905	-> byte code offset #63
/*      */     //   Java source line #6906	-> byte code offset #76
/*      */     //   Java source line #6907	-> byte code offset #98
/*      */     //   Java source line #6908	-> byte code offset #112
/*      */     //   Java source line #6911	-> byte code offset #143
/*      */     //   Java source line #6912	-> byte code offset #148
/*      */     //   Java source line #6914	-> byte code offset #168
/*      */     //   Java source line #6915	-> byte code offset #174
/*      */     //   Java source line #6916	-> byte code offset #182
/*      */     //   Java source line #6915	-> byte code offset #192
/*      */     //   Java source line #6917	-> byte code offset #202
/*      */     //   Java source line #6937	-> byte code offset #213
/*      */     //   Java source line #6943	-> byte code offset #216
/*      */     //   Java source line #6944	-> byte code offset #220
/*      */     //   Java source line #6919	-> byte code offset #226
/*      */     //   Java source line #6924	-> byte code offset #268
/*      */     //   Java source line #6926	-> byte code offset #310
/*      */     //   Java source line #6927	-> byte code offset #320
/*      */     //   Java source line #6937	-> byte code offset #329
/*      */     //   Java source line #6943	-> byte code offset #332
/*      */     //   Java source line #6944	-> byte code offset #336
/*      */     //   Java source line #6931	-> byte code offset #342
/*      */     //   Java source line #6932	-> byte code offset #351
/*      */     //   Java source line #6937	-> byte code offset #360
/*      */     //   Java source line #6943	-> byte code offset #363
/*      */     //   Java source line #6944	-> byte code offset #367
/*      */     //   Java source line #6937	-> byte code offset #373
/*      */     //   Java source line #6943	-> byte code offset #381
/*      */     //   Java source line #6944	-> byte code offset #387
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	393	0	form	Object
/*      */     //   0	393	1	freshLoader	boolean
/*      */     //   1	383	2	createdLoader	boolean
/*      */     //   32	93	3	line	Object
/*      */     //   39	96	4	column	Object
/*      */     //   172	31	5	s	ISeq
/*      */     //   308	3	5	fexpr	ObjExpr
/*      */     //   349	3	5	expr	Expr
/*      */     //   211	13	6	localObject1	Object
/*      */     //   318	53	6	fn	Object
/*      */     //   327	13	7	localObject2	Object
/*      */     //   373	6	8	localObject3	Object
/*      */     //   381	10	9	localObject4	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   143	213	373	finally
/*      */     //   226	329	373	finally
/*      */     //   342	360	373	finally
/*      */     //   373	375	373	finally
/*      */     //   26	216	381	finally
/*      */     //   226	332	381	finally
/*      */     //   342	363	381	finally
/*      */     //   373	383	381	finally
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\Compiler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */