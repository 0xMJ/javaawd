/*    */ package clojure.lang;
/*    */ 
/*    */ import clojure.main;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Repl
/*    */ {
/*    */   public static void main(String[] args)
/*    */   {
/* 20 */     main.legacy_repl(args);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\Repl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */