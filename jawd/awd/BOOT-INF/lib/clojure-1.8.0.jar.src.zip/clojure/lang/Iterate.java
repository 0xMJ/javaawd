/*    */ package clojure.lang;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Iterate
/*    */   extends ASeq
/*    */   implements IReduce, IPending
/*    */ {
/* 17 */   private static final Object UNREALIZED_SEED = new Object();
/*    */   private final IFn f;
/*    */   private final Object prevSeed;
/*    */   private volatile Object _seed;
/*    */   private volatile ISeq _next;
/*    */   
/*    */   private Iterate(IFn f, Object prevSeed, Object seed) {
/* 24 */     this.f = f;
/* 25 */     this.prevSeed = prevSeed;
/* 26 */     this._seed = seed;
/*    */   }
/*    */   
/*    */   private Iterate(IPersistentMap meta, IFn f, Object prevSeed, Object seed, ISeq next) {
/* 30 */     super(meta);
/* 31 */     this.f = f;
/* 32 */     this.prevSeed = prevSeed;
/* 33 */     this._seed = seed;
/* 34 */     this._next = next;
/*    */   }
/*    */   
/*    */   public static ISeq create(IFn f, Object seed) {
/* 38 */     return new Iterate(f, null, seed);
/*    */   }
/*    */   
/*    */   public boolean isRealized() {
/* 42 */     return this._seed != UNREALIZED_SEED;
/*    */   }
/*    */   
/*    */   public Object first() {
/* 46 */     if (this._seed == UNREALIZED_SEED) {
/* 47 */       this._seed = this.f.invoke(this.prevSeed);
/*    */     }
/* 49 */     return this._seed;
/*    */   }
/*    */   
/*    */   public ISeq next() {
/* 53 */     if (this._next == null) {
/* 54 */       this._next = new Iterate(this.f, first(), UNREALIZED_SEED);
/*    */     }
/* 56 */     return this._next;
/*    */   }
/*    */   
/*    */   public Iterate withMeta(IPersistentMap meta) {
/* 60 */     return new Iterate(meta, this.f, this.prevSeed, this._seed, this._next);
/*    */   }
/*    */   
/*    */   public Object reduce(IFn rf) {
/* 64 */     Object first = first();
/* 65 */     Object ret = first;
/* 66 */     Object v = this.f.invoke(first);
/*    */     for (;;) {
/* 68 */       ret = rf.invoke(ret, v);
/* 69 */       if (RT.isReduced(ret))
/* 70 */         return ((IDeref)ret).deref();
/* 71 */       v = this.f.invoke(v);
/*    */     }
/*    */   }
/*    */   
/*    */   public Object reduce(IFn rf, Object start) {
/* 76 */     Object ret = start;
/* 77 */     Object v = first();
/*    */     for (;;) {
/* 79 */       ret = rf.invoke(ret, v);
/* 80 */       if (RT.isReduced(ret))
/* 81 */         return ((IDeref)ret).deref();
/* 82 */       v = this.f.invoke(v);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\Iterate.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */