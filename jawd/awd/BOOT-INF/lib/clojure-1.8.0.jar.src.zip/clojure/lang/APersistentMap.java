/*     */ package clojure.lang;
/*     */ 
/*     */ import java.util.AbstractSet;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ 
/*     */ public abstract class APersistentMap extends AFn implements IPersistentMap, Map, Iterable, java.io.Serializable, MapEquivalence, IHashEq
/*     */ {
/*     */   int _hash;
/*     */   int _hasheq;
/*     */   
/*     */   public APersistentMap()
/*     */   {
/*  17 */     this._hash = -1;
/*  18 */     this._hasheq = -1;
/*     */   }
/*     */   
/*  21 */   public String toString() { return RT.printString(this); }
/*     */   
/*     */   public IPersistentCollection cons(Object o)
/*     */   {
/*  25 */     if ((o instanceof Map.Entry))
/*     */     {
/*  27 */       Map.Entry e = (Map.Entry)o;
/*     */       
/*  29 */       return assoc(e.getKey(), e.getValue());
/*     */     }
/*  31 */     if ((o instanceof IPersistentVector))
/*     */     {
/*  33 */       IPersistentVector v = (IPersistentVector)o;
/*  34 */       if (v.count() != 2)
/*  35 */         throw new IllegalArgumentException("Vector arg to map conj must be a pair");
/*  36 */       return assoc(v.nth(0), v.nth(1));
/*     */     }
/*     */     
/*  39 */     IPersistentMap ret = this;
/*  40 */     for (ISeq es = RT.seq(o); es != null; es = es.next())
/*     */     {
/*  42 */       Map.Entry e = (Map.Entry)es.first();
/*  43 */       ret = ret.assoc(e.getKey(), e.getValue());
/*     */     }
/*  45 */     return ret;
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj) {
/*  49 */     return mapEquals(this, obj);
/*     */   }
/*     */   
/*     */   public static boolean mapEquals(IPersistentMap m1, Object obj) {
/*  53 */     if (m1 == obj) return true;
/*  54 */     if (!(obj instanceof Map))
/*  55 */       return false;
/*  56 */     Map m = (Map)obj;
/*     */     
/*  58 */     if (m.size() != m1.count()) {
/*  59 */       return false;
/*     */     }
/*  61 */     for (ISeq s = m1.seq(); s != null; s = s.next())
/*     */     {
/*  63 */       Map.Entry e = (Map.Entry)s.first();
/*  64 */       boolean found = m.containsKey(e.getKey());
/*     */       
/*  66 */       if ((!found) || (!Util.equals(e.getValue(), m.get(e.getKey())))) {
/*  67 */         return false;
/*     */       }
/*     */     }
/*  70 */     return true;
/*     */   }
/*     */   
/*     */   public boolean equiv(Object obj) {
/*  74 */     if (!(obj instanceof Map))
/*  75 */       return false;
/*  76 */     if (((obj instanceof IPersistentMap)) && (!(obj instanceof MapEquivalence))) {
/*  77 */       return false;
/*     */     }
/*  79 */     Map m = (Map)obj;
/*     */     
/*  81 */     if (m.size() != size()) {
/*  82 */       return false;
/*     */     }
/*  84 */     for (ISeq s = seq(); s != null; s = s.next())
/*     */     {
/*  86 */       Map.Entry e = (Map.Entry)s.first();
/*  87 */       boolean found = m.containsKey(e.getKey());
/*     */       
/*  89 */       if ((!found) || (!Util.equiv(e.getValue(), m.get(e.getKey())))) {
/*  90 */         return false;
/*     */       }
/*     */     }
/*  93 */     return true;
/*     */   }
/*     */   
/*  96 */   public int hashCode() { if (this._hash == -1)
/*     */     {
/*  98 */       this._hash = mapHash(this);
/*     */     }
/* 100 */     return this._hash;
/*     */   }
/*     */   
/*     */   public static int mapHash(IPersistentMap m) {
/* 104 */     int hash = 0;
/* 105 */     for (ISeq s = m.seq(); s != null; s = s.next())
/*     */     {
/* 107 */       Map.Entry e = (Map.Entry)s.first();
/* 108 */       hash += ((e.getKey() == null ? 0 : e.getKey().hashCode()) ^ (e.getValue() == null ? 0 : e.getValue().hashCode()));
/*     */     }
/*     */     
/* 111 */     return hash;
/*     */   }
/*     */   
/*     */   public int hasheq() {
/* 115 */     if (this._hasheq == -1)
/*     */     {
/*     */ 
/* 118 */       this._hasheq = Murmur3.hashUnordered(this);
/*     */     }
/* 120 */     return this._hasheq;
/*     */   }
/*     */   
/*     */   public static int mapHasheq(IPersistentMap m) {
/* 124 */     return Murmur3.hashUnordered(m);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static class KeySeq
/*     */     extends ASeq
/*     */   {
/*     */     final ISeq seq;
/*     */     
/*     */ 
/*     */     final Iterable iterable;
/*     */     
/*     */ 
/*     */     public static KeySeq create(ISeq seq)
/*     */     {
/* 140 */       if (seq == null)
/* 141 */         return null;
/* 142 */       return new KeySeq(seq, null);
/*     */     }
/*     */     
/*     */     public static KeySeq createFromMap(IPersistentMap map) {
/* 146 */       if (map == null)
/* 147 */         return null;
/* 148 */       ISeq seq = map.seq();
/* 149 */       if (seq == null)
/* 150 */         return null;
/* 151 */       return new KeySeq(seq, map);
/*     */     }
/*     */     
/*     */     private KeySeq(ISeq seq, Iterable iterable) {
/* 155 */       this.seq = seq;
/* 156 */       this.iterable = iterable;
/*     */     }
/*     */     
/*     */     private KeySeq(IPersistentMap meta, ISeq seq, Iterable iterable) {
/* 160 */       super();
/* 161 */       this.seq = seq;
/* 162 */       this.iterable = iterable;
/*     */     }
/*     */     
/*     */     public Object first() {
/* 166 */       return ((Map.Entry)this.seq.first()).getKey();
/*     */     }
/*     */     
/*     */     public ISeq next() {
/* 170 */       return create(this.seq.next());
/*     */     }
/*     */     
/*     */     public KeySeq withMeta(IPersistentMap meta) {
/* 174 */       return new KeySeq(meta, this.seq, this.iterable);
/*     */     }
/*     */     
/*     */     public Iterator iterator() {
/* 178 */       if (this.iterable == null) {
/* 179 */         return super.iterator();
/*     */       }
/* 181 */       if ((this.iterable instanceof IMapIterable)) {
/* 182 */         return ((IMapIterable)this.iterable).keyIterator();
/*     */       }
/* 184 */       final Iterator mapIter = this.iterable.iterator();
/* 185 */       new Iterator() {
/*     */         public boolean hasNext() {
/* 187 */           return mapIter.hasNext();
/*     */         }
/*     */         
/*     */         public Object next() {
/* 191 */           return ((Map.Entry)mapIter.next()).getKey();
/*     */         }
/*     */         
/*     */         public void remove() {
/* 195 */           throw new UnsupportedOperationException();
/*     */         }
/*     */       };
/*     */     }
/*     */   }
/*     */   
/*     */   public static class ValSeq extends ASeq {
/*     */     final ISeq seq;
/*     */     final Iterable iterable;
/*     */     
/*     */     public static ValSeq create(ISeq seq) {
/* 206 */       if (seq == null)
/* 207 */         return null;
/* 208 */       return new ValSeq(seq, null);
/*     */     }
/*     */     
/*     */     public static ValSeq createFromMap(IPersistentMap map) {
/* 212 */       if (map == null)
/* 213 */         return null;
/* 214 */       ISeq seq = map.seq();
/* 215 */       if (seq == null)
/* 216 */         return null;
/* 217 */       return new ValSeq(seq, map);
/*     */     }
/*     */     
/*     */     private ValSeq(ISeq seq, Iterable iterable) {
/* 221 */       this.seq = seq;
/* 222 */       this.iterable = iterable;
/*     */     }
/*     */     
/*     */     private ValSeq(IPersistentMap meta, ISeq seq, Iterable iterable) {
/* 226 */       super();
/* 227 */       this.seq = seq;
/* 228 */       this.iterable = iterable;
/*     */     }
/*     */     
/*     */     public Object first() {
/* 232 */       return ((Map.Entry)this.seq.first()).getValue();
/*     */     }
/*     */     
/*     */     public ISeq next() {
/* 236 */       return create(this.seq.next());
/*     */     }
/*     */     
/*     */     public ValSeq withMeta(IPersistentMap meta) {
/* 240 */       return new ValSeq(meta, this.seq, this.iterable);
/*     */     }
/*     */     
/*     */     public Iterator iterator() {
/* 244 */       if (this.iterable == null) {
/* 245 */         return super.iterator();
/*     */       }
/* 247 */       if ((this.iterable instanceof IMapIterable)) {
/* 248 */         return ((IMapIterable)this.iterable).valIterator();
/*     */       }
/* 250 */       final Iterator mapIter = this.iterable.iterator();
/* 251 */       new Iterator() {
/*     */         public boolean hasNext() {
/* 253 */           return mapIter.hasNext();
/*     */         }
/*     */         
/*     */         public Object next() {
/* 257 */           return ((Map.Entry)mapIter.next()).getValue();
/*     */         }
/*     */         
/*     */         public void remove() {
/* 261 */           throw new UnsupportedOperationException();
/*     */         }
/*     */       };
/*     */     }
/*     */   }
/*     */   
/* 267 */   static final IFn MAKE_ENTRY = new AFn() {
/*     */     public Object invoke(Object key, Object val) {
/* 269 */       return MapEntry.create(key, val);
/*     */     }
/*     */   };
/*     */   
/* 273 */   static final IFn MAKE_KEY = new AFn() {
/*     */     public Object invoke(Object key, Object val) {
/* 275 */       return key;
/*     */     }
/*     */   };
/*     */   
/* 279 */   static final IFn MAKE_VAL = new AFn() {
/*     */     public Object invoke(Object key, Object val) {
/* 281 */       return val;
/*     */     }
/*     */   };
/*     */   
/*     */   public Object invoke(Object arg1) {
/* 286 */     return valAt(arg1);
/*     */   }
/*     */   
/*     */   public Object invoke(Object arg1, Object notFound) {
/* 290 */     return valAt(arg1, notFound);
/*     */   }
/*     */   
/*     */ 
/*     */   public void clear()
/*     */   {
/* 296 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public boolean containsValue(Object value) {
/* 300 */     return values().contains(value);
/*     */   }
/*     */   
/*     */   public Set entrySet() {
/* 304 */     new AbstractSet()
/*     */     {
/*     */       public Iterator iterator() {
/* 307 */         return APersistentMap.this.iterator();
/*     */       }
/*     */       
/*     */       public int size() {
/* 311 */         return APersistentMap.this.count();
/*     */       }
/*     */       
/*     */       public int hashCode() {
/* 315 */         return APersistentMap.this.hashCode();
/*     */       }
/*     */       
/*     */       public boolean contains(Object o) {
/* 319 */         if ((o instanceof Map.Entry))
/*     */         {
/* 321 */           Map.Entry e = (Map.Entry)o;
/* 322 */           Map.Entry found = APersistentMap.this.entryAt(e.getKey());
/* 323 */           if ((found != null) && (Util.equals(found.getValue(), e.getValue())))
/* 324 */             return true;
/*     */         }
/* 326 */         return false;
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */   public Object get(Object key) {
/* 332 */     return valAt(key);
/*     */   }
/*     */   
/*     */   public boolean isEmpty() {
/* 336 */     return count() == 0;
/*     */   }
/*     */   
/*     */   public Set keySet() {
/* 340 */     new AbstractSet()
/*     */     {
/*     */       public Iterator iterator() {
/* 343 */         final Iterator mi = APersistentMap.this.iterator();
/*     */         
/* 345 */         new Iterator()
/*     */         {
/*     */           public boolean hasNext()
/*     */           {
/* 349 */             return mi.hasNext();
/*     */           }
/*     */           
/*     */           public Object next() {
/* 353 */             Map.Entry e = (Map.Entry)mi.next();
/* 354 */             return e.getKey();
/*     */           }
/*     */           
/*     */           public void remove() {
/* 358 */             throw new UnsupportedOperationException();
/*     */           }
/*     */         };
/*     */       }
/*     */       
/*     */       public int size() {
/* 364 */         return APersistentMap.this.count();
/*     */       }
/*     */       
/*     */       public boolean contains(Object o) {
/* 368 */         return APersistentMap.this.containsKey(o);
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */   public Object put(Object key, Object value) {
/* 374 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void putAll(Map t) {
/* 378 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public Object remove(Object key) {
/* 382 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public int size() {
/* 386 */     return count();
/*     */   }
/*     */   
/*     */   public Collection values() {
/* 390 */     new java.util.AbstractCollection()
/*     */     {
/*     */       public Iterator iterator() {
/* 393 */         final Iterator mi = APersistentMap.this.iterator();
/*     */         
/* 395 */         new Iterator()
/*     */         {
/*     */           public boolean hasNext()
/*     */           {
/* 399 */             return mi.hasNext();
/*     */           }
/*     */           
/*     */           public Object next() {
/* 403 */             Map.Entry e = (Map.Entry)mi.next();
/* 404 */             return e.getValue();
/*     */           }
/*     */           
/*     */           public void remove() {
/* 408 */             throw new UnsupportedOperationException();
/*     */           }
/*     */         };
/*     */       }
/*     */       
/*     */       public int size() {
/* 414 */         return APersistentMap.this.count();
/*     */       }
/*     */     };
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\APersistentMap.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */