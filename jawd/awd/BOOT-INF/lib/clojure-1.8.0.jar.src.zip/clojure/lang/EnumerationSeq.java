/*    */ package clojure.lang;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.NotSerializableException;
/*    */ import java.io.ObjectOutputStream;
/*    */ import java.util.Enumeration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EnumerationSeq
/*    */   extends ASeq
/*    */ {
/*    */   final Enumeration iter;
/*    */   final State state;
/*    */   
/*    */   public static EnumerationSeq create(Enumeration iter)
/*    */   {
/* 29 */     if (iter.hasMoreElements())
/* 30 */       return new EnumerationSeq(iter);
/* 31 */     return null;
/*    */   }
/*    */   
/*    */   EnumerationSeq(Enumeration iter) {
/* 35 */     this.iter = iter;
/* 36 */     this.state = new State();
/* 37 */     this.state.val = this.state;
/* 38 */     this.state._rest = this.state;
/*    */   }
/*    */   
/*    */   EnumerationSeq(IPersistentMap meta, Enumeration iter, State state) {
/* 42 */     super(meta);
/* 43 */     this.iter = iter;
/* 44 */     this.state = state;
/*    */   }
/*    */   
/*    */   public Object first() {
/* 48 */     if (this.state.val == this.state)
/* 49 */       synchronized (this.state)
/*    */       {
/* 51 */         if (this.state.val == this.state)
/* 52 */           this.state.val = this.iter.nextElement();
/*    */       }
/* 54 */     return this.state.val;
/*    */   }
/*    */   
/*    */   public ISeq next() {
/* 58 */     if (this.state._rest == this.state)
/* 59 */       synchronized (this.state)
/*    */       {
/* 61 */         if (this.state._rest == this.state)
/*    */         {
/* 63 */           first();
/* 64 */           this.state._rest = create(this.iter);
/*    */         }
/*    */       }
/* 67 */     return (ISeq)this.state._rest;
/*    */   }
/*    */   
/*    */   public EnumerationSeq withMeta(IPersistentMap meta) {
/* 71 */     return new EnumerationSeq(meta, this.iter, this.state);
/*    */   }
/*    */   
/*    */   private void writeObject(ObjectOutputStream out) throws IOException {
/* 75 */     throw new NotSerializableException(getClass().getName());
/*    */   }
/*    */   
/*    */   static class State
/*    */   {
/*    */     volatile Object val;
/*    */     volatile Object _rest;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\EnumerationSeq.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */