/*     */ package clojure.lang;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class BigInt
/*     */   extends Number
/*     */   implements IHashEq
/*     */ {
/*     */   public final long lpart;
/*     */   public final BigInteger bipart;
/*  23 */   public static final BigInt ZERO = new BigInt(0L, null);
/*  24 */   public static final BigInt ONE = new BigInt(1L, null);
/*     */   
/*     */ 
/*     */   public int hashCode()
/*     */   {
/*  29 */     if (this.bipart == null)
/*  30 */       return (int)(this.lpart ^ this.lpart >>> 32);
/*  31 */     return this.bipart.hashCode();
/*     */   }
/*     */   
/*     */   public int hasheq() {
/*  35 */     if (this.bipart == null)
/*  36 */       return Murmur3.hashLong(this.lpart);
/*  37 */     return this.bipart.hashCode();
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/*  42 */     if (this == obj)
/*  43 */       return true;
/*  44 */     if ((obj instanceof BigInt))
/*     */     {
/*  46 */       BigInt o = (BigInt)obj;
/*  47 */       if (this.bipart == null)
/*  48 */         return (o.bipart == null) && (this.lpart == o.lpart);
/*  49 */       return (o.bipart != null) && (this.bipart.equals(o.bipart));
/*     */     }
/*  51 */     return false;
/*     */   }
/*     */   
/*     */   private BigInt(long lpart, BigInteger bipart) {
/*  55 */     this.lpart = lpart;
/*  56 */     this.bipart = bipart;
/*     */   }
/*     */   
/*     */   public static BigInt fromBigInteger(BigInteger val) {
/*  60 */     if (val.bitLength() < 64) {
/*  61 */       return new BigInt(val.longValue(), null);
/*     */     }
/*  63 */     return new BigInt(0L, val);
/*     */   }
/*     */   
/*     */   public static BigInt fromLong(long val) {
/*  67 */     return new BigInt(val, null);
/*     */   }
/*     */   
/*     */   public BigInteger toBigInteger() {
/*  71 */     if (this.bipart == null) {
/*  72 */       return BigInteger.valueOf(this.lpart);
/*     */     }
/*  74 */     return this.bipart;
/*     */   }
/*     */   
/*     */   public BigDecimal toBigDecimal() {
/*  78 */     if (this.bipart == null) {
/*  79 */       return BigDecimal.valueOf(this.lpart);
/*     */     }
/*  81 */     return new BigDecimal(this.bipart);
/*     */   }
/*     */   
/*     */ 
/*     */   public int intValue()
/*     */   {
/*  87 */     if (this.bipart == null) {
/*  88 */       return (int)this.lpart;
/*     */     }
/*  90 */     return this.bipart.intValue();
/*     */   }
/*     */   
/*     */   public long longValue() {
/*  94 */     if (this.bipart == null) {
/*  95 */       return this.lpart;
/*     */     }
/*  97 */     return this.bipart.longValue();
/*     */   }
/*     */   
/*     */   public float floatValue() {
/* 101 */     if (this.bipart == null) {
/* 102 */       return (float)this.lpart;
/*     */     }
/* 104 */     return this.bipart.floatValue();
/*     */   }
/*     */   
/*     */   public double doubleValue() {
/* 108 */     if (this.bipart == null) {
/* 109 */       return this.lpart;
/*     */     }
/* 111 */     return this.bipart.doubleValue();
/*     */   }
/*     */   
/*     */   public byte byteValue() {
/* 115 */     if (this.bipart == null) {
/* 116 */       return (byte)(int)this.lpart;
/*     */     }
/* 118 */     return this.bipart.byteValue();
/*     */   }
/*     */   
/*     */   public short shortValue() {
/* 122 */     if (this.bipart == null) {
/* 123 */       return (short)(int)this.lpart;
/*     */     }
/* 125 */     return this.bipart.shortValue();
/*     */   }
/*     */   
/*     */   public static BigInt valueOf(long val) {
/* 129 */     return new BigInt(val, null);
/*     */   }
/*     */   
/*     */   public String toString() {
/* 133 */     if (this.bipart == null)
/* 134 */       return String.valueOf(this.lpart);
/* 135 */     return this.bipart.toString();
/*     */   }
/*     */   
/*     */   public int bitLength() {
/* 139 */     return toBigInteger().bitLength();
/*     */   }
/*     */   
/*     */   public BigInt add(BigInt y) {
/* 143 */     if ((this.bipart == null) && (y.bipart == null)) {
/* 144 */       long ret = this.lpart + y.lpart;
/* 145 */       if (((ret ^ this.lpart) >= 0L) || ((ret ^ y.lpart) >= 0L))
/* 146 */         return valueOf(ret);
/*     */     }
/* 148 */     return fromBigInteger(toBigInteger().add(y.toBigInteger()));
/*     */   }
/*     */   
/*     */   public BigInt multiply(BigInt y) {
/* 152 */     if ((this.bipart == null) && (y.bipart == null)) {
/* 153 */       long ret = this.lpart * y.lpart;
/* 154 */       if ((y.lpart == 0L) || ((ret / y.lpart == this.lpart) && (this.lpart != Long.MIN_VALUE)))
/*     */       {
/* 156 */         return valueOf(ret); }
/*     */     }
/* 158 */     return fromBigInteger(toBigInteger().multiply(y.toBigInteger()));
/*     */   }
/*     */   
/*     */   public BigInt quotient(BigInt y) {
/* 162 */     if ((this.bipart == null) && (y.bipart == null)) {
/* 163 */       if ((this.lpart == Long.MIN_VALUE) && (y.lpart == -1L))
/* 164 */         return fromBigInteger(toBigInteger().negate());
/* 165 */       return valueOf(this.lpart / y.lpart);
/*     */     }
/* 167 */     return fromBigInteger(toBigInteger().divide(y.toBigInteger()));
/*     */   }
/*     */   
/*     */   public BigInt remainder(BigInt y) {
/* 171 */     if ((this.bipart == null) && (y.bipart == null)) {
/* 172 */       return valueOf(this.lpart % y.lpart);
/*     */     }
/* 174 */     return fromBigInteger(toBigInteger().remainder(y.toBigInteger()));
/*     */   }
/*     */   
/*     */   public boolean lt(BigInt y) {
/* 178 */     if ((this.bipart == null) && (y.bipart == null)) {
/* 179 */       return this.lpart < y.lpart;
/*     */     }
/* 181 */     return toBigInteger().compareTo(y.toBigInteger()) < 0;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\BigInt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */