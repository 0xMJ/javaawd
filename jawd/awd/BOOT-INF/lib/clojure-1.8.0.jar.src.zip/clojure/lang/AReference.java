/*    */ package clojure.lang;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AReference
/*    */   implements IReference
/*    */ {
/*    */   private IPersistentMap _meta;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public AReference()
/*    */   {
/* 19 */     this(null);
/*    */   }
/*    */   
/*    */   public AReference(IPersistentMap meta) {
/* 23 */     this._meta = meta;
/*    */   }
/*    */   
/*    */   public synchronized IPersistentMap meta() {
/* 27 */     return this._meta;
/*    */   }
/*    */   
/*    */   public synchronized IPersistentMap alterMeta(IFn alter, ISeq args) {
/* 31 */     this._meta = ((IPersistentMap)alter.applyTo(new Cons(this._meta, args)));
/* 32 */     return this._meta;
/*    */   }
/*    */   
/*    */   public synchronized IPersistentMap resetMeta(IPersistentMap m) {
/* 36 */     this._meta = m;
/* 37 */     return m;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\AReference.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */