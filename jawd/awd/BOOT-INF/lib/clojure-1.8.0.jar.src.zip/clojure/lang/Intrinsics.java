/*     */ package clojure.lang;
/*     */ 
/*     */ import clojure.asm.Opcodes;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Intrinsics
/*     */   implements Opcodes
/*     */ {
/*     */   private static Object[] oa(Object... arr)
/*     */   {
/*  19 */     return arr;
/*     */   }
/*     */   
/*  22 */   static IPersistentMap ops = RT.map(new Object[] { "public static double clojure.lang.Numbers.add(double,double)", Integer.valueOf(99), "public static long clojure.lang.Numbers.and(long,long)", Integer.valueOf(127), "public static long clojure.lang.Numbers.or(long,long)", Integer.valueOf(129), "public static long clojure.lang.Numbers.xor(long,long)", Integer.valueOf(131), "public static double clojure.lang.Numbers.multiply(double,double)", Integer.valueOf(107), "public static double clojure.lang.Numbers.divide(double,double)", Integer.valueOf(111), "public static long clojure.lang.Numbers.remainder(long,long)", Integer.valueOf(113), "public static long clojure.lang.Numbers.shiftLeft(long,long)", oa(new Object[] { Integer.valueOf(136), Integer.valueOf(121) }), "public static long clojure.lang.Numbers.shiftRight(long,long)", oa(new Object[] { Integer.valueOf(136), Integer.valueOf(123) }), "public static long clojure.lang.Numbers.unsignedShiftRight(long,long)", oa(new Object[] { Integer.valueOf(136), Integer.valueOf(125) }), "public static double clojure.lang.Numbers.minus(double)", Integer.valueOf(119), "public static double clojure.lang.Numbers.minus(double,double)", Integer.valueOf(103), "public static double clojure.lang.Numbers.inc(double)", oa(new Object[] { Integer.valueOf(15), Integer.valueOf(99) }), "public static double clojure.lang.Numbers.dec(double)", oa(new Object[] { Integer.valueOf(15), Integer.valueOf(103) }), "public static long clojure.lang.Numbers.quotient(long,long)", Integer.valueOf(109), "public static int clojure.lang.Numbers.shiftLeftInt(int,int)", Integer.valueOf(120), "public static int clojure.lang.Numbers.shiftRightInt(int,int)", Integer.valueOf(122), "public static int clojure.lang.Numbers.unsignedShiftRightInt(int,int)", Integer.valueOf(124), "public static int clojure.lang.Numbers.unchecked_int_add(int,int)", Integer.valueOf(96), "public static int clojure.lang.Numbers.unchecked_int_subtract(int,int)", Integer.valueOf(100), "public static int clojure.lang.Numbers.unchecked_int_negate(int)", Integer.valueOf(116), "public static int clojure.lang.Numbers.unchecked_int_inc(int)", oa(new Object[] { Integer.valueOf(4), Integer.valueOf(96) }), "public static int clojure.lang.Numbers.unchecked_int_dec(int)", oa(new Object[] { Integer.valueOf(4), Integer.valueOf(100) }), "public static int clojure.lang.Numbers.unchecked_int_multiply(int,int)", Integer.valueOf(104), "public static int clojure.lang.Numbers.unchecked_int_divide(int,int)", Integer.valueOf(108), "public static int clojure.lang.Numbers.unchecked_int_remainder(int,int)", Integer.valueOf(112), "public static long clojure.lang.Numbers.unchecked_add(long,long)", Integer.valueOf(97), "public static double clojure.lang.Numbers.unchecked_add(double,double)", Integer.valueOf(99), "public static long clojure.lang.Numbers.unchecked_minus(long)", Integer.valueOf(117), "public static double clojure.lang.Numbers.unchecked_minus(double)", Integer.valueOf(119), "public static double clojure.lang.Numbers.unchecked_minus(double,double)", Integer.valueOf(103), "public static long clojure.lang.Numbers.unchecked_minus(long,long)", Integer.valueOf(101), "public static long clojure.lang.Numbers.unchecked_multiply(long,long)", Integer.valueOf(105), "public static double clojure.lang.Numbers.unchecked_multiply(double,double)", Integer.valueOf(107), "public static double clojure.lang.Numbers.unchecked_inc(double)", oa(new Object[] { Integer.valueOf(15), Integer.valueOf(99) }), "public static long clojure.lang.Numbers.unchecked_inc(long)", oa(new Object[] { Integer.valueOf(10), Integer.valueOf(97) }), "public static double clojure.lang.Numbers.unchecked_dec(double)", oa(new Object[] { Integer.valueOf(15), Integer.valueOf(103) }), "public static long clojure.lang.Numbers.unchecked_dec(long)", oa(new Object[] { Integer.valueOf(10), Integer.valueOf(101) }), "public static short clojure.lang.RT.aget(short[],int)", Integer.valueOf(53), "public static float clojure.lang.RT.aget(float[],int)", Integer.valueOf(48), "public static double clojure.lang.RT.aget(double[],int)", Integer.valueOf(49), "public static int clojure.lang.RT.aget(int[],int)", Integer.valueOf(46), "public static long clojure.lang.RT.aget(long[],int)", Integer.valueOf(47), "public static char clojure.lang.RT.aget(char[],int)", Integer.valueOf(52), "public static byte clojure.lang.RT.aget(byte[],int)", Integer.valueOf(51), "public static boolean clojure.lang.RT.aget(boolean[],int)", Integer.valueOf(51), "public static java.lang.Object clojure.lang.RT.aget(java.lang.Object[],int)", Integer.valueOf(50), "public static int clojure.lang.RT.alength(int[])", Integer.valueOf(190), "public static int clojure.lang.RT.alength(long[])", Integer.valueOf(190), "public static int clojure.lang.RT.alength(char[])", Integer.valueOf(190), "public static int clojure.lang.RT.alength(java.lang.Object[])", Integer.valueOf(190), "public static int clojure.lang.RT.alength(byte[])", Integer.valueOf(190), "public static int clojure.lang.RT.alength(float[])", Integer.valueOf(190), "public static int clojure.lang.RT.alength(short[])", Integer.valueOf(190), "public static int clojure.lang.RT.alength(boolean[])", Integer.valueOf(190), "public static int clojure.lang.RT.alength(double[])", Integer.valueOf(190), "public static double clojure.lang.RT.doubleCast(long)", Integer.valueOf(138), "public static double clojure.lang.RT.doubleCast(double)", Integer.valueOf(0), "public static double clojure.lang.RT.doubleCast(float)", Integer.valueOf(141), "public static double clojure.lang.RT.doubleCast(int)", Integer.valueOf(135), "public static double clojure.lang.RT.doubleCast(short)", Integer.valueOf(135), "public static double clojure.lang.RT.doubleCast(byte)", Integer.valueOf(135), "public static double clojure.lang.RT.uncheckedDoubleCast(double)", Integer.valueOf(0), "public static double clojure.lang.RT.uncheckedDoubleCast(float)", Integer.valueOf(141), "public static double clojure.lang.RT.uncheckedDoubleCast(long)", Integer.valueOf(138), "public static double clojure.lang.RT.uncheckedDoubleCast(int)", Integer.valueOf(135), "public static double clojure.lang.RT.uncheckedDoubleCast(short)", Integer.valueOf(135), "public static double clojure.lang.RT.uncheckedDoubleCast(byte)", Integer.valueOf(135), "public static long clojure.lang.RT.longCast(long)", Integer.valueOf(0), "public static long clojure.lang.RT.longCast(short)", Integer.valueOf(133), "public static long clojure.lang.RT.longCast(byte)", Integer.valueOf(133), "public static long clojure.lang.RT.longCast(int)", Integer.valueOf(133), "public static int clojure.lang.RT.uncheckedIntCast(long)", Integer.valueOf(136), "public static int clojure.lang.RT.uncheckedIntCast(double)", Integer.valueOf(142), "public static int clojure.lang.RT.uncheckedIntCast(byte)", Integer.valueOf(0), "public static int clojure.lang.RT.uncheckedIntCast(short)", Integer.valueOf(0), "public static int clojure.lang.RT.uncheckedIntCast(char)", Integer.valueOf(0), "public static int clojure.lang.RT.uncheckedIntCast(int)", Integer.valueOf(0), "public static int clojure.lang.RT.uncheckedIntCast(float)", Integer.valueOf(139), "public static long clojure.lang.RT.uncheckedLongCast(short)", Integer.valueOf(133), "public static long clojure.lang.RT.uncheckedLongCast(float)", Integer.valueOf(140), "public static long clojure.lang.RT.uncheckedLongCast(double)", Integer.valueOf(143), "public static long clojure.lang.RT.uncheckedLongCast(byte)", Integer.valueOf(133), "public static long clojure.lang.RT.uncheckedLongCast(long)", Integer.valueOf(0), "public static long clojure.lang.RT.uncheckedLongCast(int)", Integer.valueOf(133) });
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 114 */   static IPersistentMap preds = RT.map(new Object[] { "public static boolean clojure.lang.Numbers.lt(double,double)", oa(new Object[] { Integer.valueOf(152), Integer.valueOf(156) }), "public static boolean clojure.lang.Numbers.lt(long,long)", oa(new Object[] { Integer.valueOf(148), Integer.valueOf(156) }), "public static boolean clojure.lang.Numbers.equiv(double,double)", oa(new Object[] { Integer.valueOf(151), Integer.valueOf(154) }), "public static boolean clojure.lang.Numbers.equiv(long,long)", oa(new Object[] { Integer.valueOf(148), Integer.valueOf(154) }), "public static boolean clojure.lang.Numbers.lte(double,double)", oa(new Object[] { Integer.valueOf(152), Integer.valueOf(157) }), "public static boolean clojure.lang.Numbers.lte(long,long)", oa(new Object[] { Integer.valueOf(148), Integer.valueOf(157) }), "public static boolean clojure.lang.Numbers.gt(long,long)", oa(new Object[] { Integer.valueOf(148), Integer.valueOf(158) }), "public static boolean clojure.lang.Numbers.gt(double,double)", oa(new Object[] { Integer.valueOf(151), Integer.valueOf(158) }), "public static boolean clojure.lang.Numbers.gte(long,long)", oa(new Object[] { Integer.valueOf(148), Integer.valueOf(155) }), "public static boolean clojure.lang.Numbers.gte(double,double)", oa(new Object[] { Integer.valueOf(151), Integer.valueOf(155) }), "public static boolean clojure.lang.Util.equiv(long,long)", oa(new Object[] { Integer.valueOf(148), Integer.valueOf(154) }), "public static boolean clojure.lang.Util.equiv(boolean,boolean)", oa(new Object[] { Integer.valueOf(160) }), "public static boolean clojure.lang.Util.equiv(double,double)", oa(new Object[] { Integer.valueOf(151), Integer.valueOf(154) }), "public static boolean clojure.lang.Numbers.isZero(double)", oa(new Object[] { Integer.valueOf(14), Integer.valueOf(151), Integer.valueOf(154) }), "public static boolean clojure.lang.Numbers.isZero(long)", oa(new Object[] { Integer.valueOf(9), Integer.valueOf(148), Integer.valueOf(154) }), "public static boolean clojure.lang.Numbers.isPos(long)", oa(new Object[] { Integer.valueOf(9), Integer.valueOf(148), Integer.valueOf(158) }), "public static boolean clojure.lang.Numbers.isPos(double)", oa(new Object[] { Integer.valueOf(14), Integer.valueOf(151), Integer.valueOf(158) }), "public static boolean clojure.lang.Numbers.isNeg(long)", oa(new Object[] { Integer.valueOf(9), Integer.valueOf(148), Integer.valueOf(156) }), "public static boolean clojure.lang.Numbers.isNeg(double)", oa(new Object[] { Integer.valueOf(14), Integer.valueOf(152), Integer.valueOf(156) }) });
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\Intrinsics.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */