/*    */ package clojure.lang;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Cons
/*    */   extends ASeq
/*    */   implements Serializable
/*    */ {
/*    */   private final Object _first;
/*    */   private final ISeq _more;
/*    */   
/*    */   public Cons(Object first, ISeq _more)
/*    */   {
/* 23 */     this._first = first;
/* 24 */     this._more = _more;
/*    */   }
/*    */   
/*    */   public Cons(IPersistentMap meta, Object _first, ISeq _more)
/*    */   {
/* 29 */     super(meta);
/* 30 */     this._first = _first;
/* 31 */     this._more = _more;
/*    */   }
/*    */   
/*    */   public Object first() {
/* 35 */     return this._first;
/*    */   }
/*    */   
/*    */   public ISeq next() {
/* 39 */     return more().seq();
/*    */   }
/*    */   
/*    */   public ISeq more() {
/* 43 */     if (this._more == null)
/* 44 */       return PersistentList.EMPTY;
/* 45 */     return this._more;
/*    */   }
/*    */   
/*    */   public int count() {
/* 49 */     return 1 + RT.count(this._more);
/*    */   }
/*    */   
/*    */   public Cons withMeta(IPersistentMap meta) {
/* 53 */     return new Cons(meta, this._first, this._more);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\Cons.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */