/*    */ package clojure.lang;
/*    */ 
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class MethodImplCache
/*    */ {
/*    */   public final IPersistentMap protocol;
/*    */   public final Keyword methodk;
/*    */   public final int shift;
/*    */   public final int mask;
/*    */   public final Object[] table;
/*    */   public final Map map;
/*    */   
/*    */   public static class Entry
/*    */   {
/*    */     public final Class c;
/*    */     public final IFn fn;
/*    */     
/*    */     public Entry(Class c, IFn fn)
/*    */     {
/* 24 */       this.c = c;
/* 25 */       this.fn = fn;
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 36 */   Entry mre = null;
/*    */   
/*    */   public MethodImplCache(IPersistentMap protocol, Keyword methodk) {
/* 39 */     this(protocol, methodk, 0, 0, RT.EMPTY_ARRAY);
/*    */   }
/*    */   
/*    */   public MethodImplCache(IPersistentMap protocol, Keyword methodk, int shift, int mask, Object[] table) {
/* 43 */     this.protocol = protocol;
/* 44 */     this.methodk = methodk;
/* 45 */     this.shift = shift;
/* 46 */     this.mask = mask;
/* 47 */     this.table = table;
/* 48 */     this.map = null;
/*    */   }
/*    */   
/*    */   public MethodImplCache(IPersistentMap protocol, Keyword methodk, Map map) {
/* 52 */     this.protocol = protocol;
/* 53 */     this.methodk = methodk;
/* 54 */     this.shift = 0;
/* 55 */     this.mask = 0;
/* 56 */     this.table = null;
/* 57 */     this.map = map;
/*    */   }
/*    */   
/*    */   public IFn fnFor(Class c) {
/* 61 */     Entry last = this.mre;
/* 62 */     if ((last != null) && (last.c == c))
/* 63 */       return last.fn;
/* 64 */     return findFnFor(c);
/*    */   }
/*    */   
/*    */   IFn findFnFor(Class c) {
/* 68 */     if (this.map != null)
/*    */     {
/* 70 */       Entry e = (Entry)this.map.get(c);
/* 71 */       this.mre = e;
/* 72 */       return e != null ? e.fn : null;
/*    */     }
/*    */     
/*    */ 
/* 76 */     int idx = (Util.hash(c) >> this.shift & this.mask) << 1;
/* 77 */     if ((idx < this.table.length) && (this.table[idx] == c))
/*    */     {
/* 79 */       Entry e = (Entry)this.table[(idx + 1)];
/* 80 */       this.mre = e;
/* 81 */       return e != null ? e.fn : null;
/*    */     }
/* 83 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\MethodImplCache.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */