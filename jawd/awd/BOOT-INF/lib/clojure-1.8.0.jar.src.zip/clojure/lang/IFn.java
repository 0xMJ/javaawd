package clojure.lang;

import java.util.concurrent.Callable;

public abstract interface IFn
  extends Callable, Runnable
{
  public abstract Object invoke();
  
  public abstract Object invoke(Object paramObject);
  
  public abstract Object invoke(Object paramObject1, Object paramObject2);
  
  public abstract Object invoke(Object paramObject1, Object paramObject2, Object paramObject3);
  
  public abstract Object invoke(Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4);
  
  public abstract Object invoke(Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4, Object paramObject5);
  
  public abstract Object invoke(Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4, Object paramObject5, Object paramObject6);
  
  public abstract Object invoke(Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4, Object paramObject5, Object paramObject6, Object paramObject7);
  
  public abstract Object invoke(Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4, Object paramObject5, Object paramObject6, Object paramObject7, Object paramObject8);
  
  public abstract Object invoke(Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4, Object paramObject5, Object paramObject6, Object paramObject7, Object paramObject8, Object paramObject9);
  
  public abstract Object invoke(Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4, Object paramObject5, Object paramObject6, Object paramObject7, Object paramObject8, Object paramObject9, Object paramObject10);
  
  public abstract Object invoke(Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4, Object paramObject5, Object paramObject6, Object paramObject7, Object paramObject8, Object paramObject9, Object paramObject10, Object paramObject11);
  
  public abstract Object invoke(Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4, Object paramObject5, Object paramObject6, Object paramObject7, Object paramObject8, Object paramObject9, Object paramObject10, Object paramObject11, Object paramObject12);
  
  public abstract Object invoke(Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4, Object paramObject5, Object paramObject6, Object paramObject7, Object paramObject8, Object paramObject9, Object paramObject10, Object paramObject11, Object paramObject12, Object paramObject13);
  
  public abstract Object invoke(Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4, Object paramObject5, Object paramObject6, Object paramObject7, Object paramObject8, Object paramObject9, Object paramObject10, Object paramObject11, Object paramObject12, Object paramObject13, Object paramObject14);
  
  public abstract Object invoke(Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4, Object paramObject5, Object paramObject6, Object paramObject7, Object paramObject8, Object paramObject9, Object paramObject10, Object paramObject11, Object paramObject12, Object paramObject13, Object paramObject14, Object paramObject15);
  
  public abstract Object invoke(Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4, Object paramObject5, Object paramObject6, Object paramObject7, Object paramObject8, Object paramObject9, Object paramObject10, Object paramObject11, Object paramObject12, Object paramObject13, Object paramObject14, Object paramObject15, Object paramObject16);
  
  public abstract Object invoke(Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4, Object paramObject5, Object paramObject6, Object paramObject7, Object paramObject8, Object paramObject9, Object paramObject10, Object paramObject11, Object paramObject12, Object paramObject13, Object paramObject14, Object paramObject15, Object paramObject16, Object paramObject17);
  
  public abstract Object invoke(Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4, Object paramObject5, Object paramObject6, Object paramObject7, Object paramObject8, Object paramObject9, Object paramObject10, Object paramObject11, Object paramObject12, Object paramObject13, Object paramObject14, Object paramObject15, Object paramObject16, Object paramObject17, Object paramObject18);
  
  public abstract Object invoke(Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4, Object paramObject5, Object paramObject6, Object paramObject7, Object paramObject8, Object paramObject9, Object paramObject10, Object paramObject11, Object paramObject12, Object paramObject13, Object paramObject14, Object paramObject15, Object paramObject16, Object paramObject17, Object paramObject18, Object paramObject19);
  
  public abstract Object invoke(Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4, Object paramObject5, Object paramObject6, Object paramObject7, Object paramObject8, Object paramObject9, Object paramObject10, Object paramObject11, Object paramObject12, Object paramObject13, Object paramObject14, Object paramObject15, Object paramObject16, Object paramObject17, Object paramObject18, Object paramObject19, Object paramObject20);
  
  public abstract Object invoke(Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4, Object paramObject5, Object paramObject6, Object paramObject7, Object paramObject8, Object paramObject9, Object paramObject10, Object paramObject11, Object paramObject12, Object paramObject13, Object paramObject14, Object paramObject15, Object paramObject16, Object paramObject17, Object paramObject18, Object paramObject19, Object paramObject20, Object... paramVarArgs);
  
  public abstract Object applyTo(ISeq paramISeq);
  
  public static abstract interface DDDDD
  {
    public abstract double invokePrim(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4);
  }
  
  public static abstract interface DDDDL
  {
    public abstract long invokePrim(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4);
  }
  
  public static abstract interface DDDDO
  {
    public abstract Object invokePrim(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4);
  }
  
  public static abstract interface DDDLD
  {
    public abstract double invokePrim(double paramDouble1, double paramDouble2, double paramDouble3, long paramLong);
  }
  
  public static abstract interface DDDLL
  {
    public abstract long invokePrim(double paramDouble1, double paramDouble2, double paramDouble3, long paramLong);
  }
  
  public static abstract interface DDDLO
  {
    public abstract Object invokePrim(double paramDouble1, double paramDouble2, double paramDouble3, long paramLong);
  }
  
  public static abstract interface DDDOD
  {
    public abstract double invokePrim(double paramDouble1, double paramDouble2, double paramDouble3, Object paramObject);
  }
  
  public static abstract interface DDDOL
  {
    public abstract long invokePrim(double paramDouble1, double paramDouble2, double paramDouble3, Object paramObject);
  }
  
  public static abstract interface DDDOO
  {
    public abstract Object invokePrim(double paramDouble1, double paramDouble2, double paramDouble3, Object paramObject);
  }
  
  public static abstract interface DDLDD
  {
    public abstract double invokePrim(double paramDouble1, double paramDouble2, long paramLong, double paramDouble3);
  }
  
  public static abstract interface DDLDL
  {
    public abstract long invokePrim(double paramDouble1, double paramDouble2, long paramLong, double paramDouble3);
  }
  
  public static abstract interface DDLDO
  {
    public abstract Object invokePrim(double paramDouble1, double paramDouble2, long paramLong, double paramDouble3);
  }
  
  public static abstract interface DDLLD
  {
    public abstract double invokePrim(double paramDouble1, double paramDouble2, long paramLong1, long paramLong2);
  }
  
  public static abstract interface DDLLL
  {
    public abstract long invokePrim(double paramDouble1, double paramDouble2, long paramLong1, long paramLong2);
  }
  
  public static abstract interface DDLLO
  {
    public abstract Object invokePrim(double paramDouble1, double paramDouble2, long paramLong1, long paramLong2);
  }
  
  public static abstract interface DDLOD
  {
    public abstract double invokePrim(double paramDouble1, double paramDouble2, long paramLong, Object paramObject);
  }
  
  public static abstract interface DDLOL
  {
    public abstract long invokePrim(double paramDouble1, double paramDouble2, long paramLong, Object paramObject);
  }
  
  public static abstract interface DDLOO
  {
    public abstract Object invokePrim(double paramDouble1, double paramDouble2, long paramLong, Object paramObject);
  }
  
  public static abstract interface DDODD
  {
    public abstract double invokePrim(double paramDouble1, double paramDouble2, Object paramObject, double paramDouble3);
  }
  
  public static abstract interface DDODL
  {
    public abstract long invokePrim(double paramDouble1, double paramDouble2, Object paramObject, double paramDouble3);
  }
  
  public static abstract interface DDODO
  {
    public abstract Object invokePrim(double paramDouble1, double paramDouble2, Object paramObject, double paramDouble3);
  }
  
  public static abstract interface DDOLD
  {
    public abstract double invokePrim(double paramDouble1, double paramDouble2, Object paramObject, long paramLong);
  }
  
  public static abstract interface DDOLL
  {
    public abstract long invokePrim(double paramDouble1, double paramDouble2, Object paramObject, long paramLong);
  }
  
  public static abstract interface DDOLO
  {
    public abstract Object invokePrim(double paramDouble1, double paramDouble2, Object paramObject, long paramLong);
  }
  
  public static abstract interface DDOOD
  {
    public abstract double invokePrim(double paramDouble1, double paramDouble2, Object paramObject1, Object paramObject2);
  }
  
  public static abstract interface DDOOL
  {
    public abstract long invokePrim(double paramDouble1, double paramDouble2, Object paramObject1, Object paramObject2);
  }
  
  public static abstract interface DDOOO
  {
    public abstract Object invokePrim(double paramDouble1, double paramDouble2, Object paramObject1, Object paramObject2);
  }
  
  public static abstract interface DLDDD
  {
    public abstract double invokePrim(double paramDouble1, long paramLong, double paramDouble2, double paramDouble3);
  }
  
  public static abstract interface DLDDL
  {
    public abstract long invokePrim(double paramDouble1, long paramLong, double paramDouble2, double paramDouble3);
  }
  
  public static abstract interface DLDDO
  {
    public abstract Object invokePrim(double paramDouble1, long paramLong, double paramDouble2, double paramDouble3);
  }
  
  public static abstract interface DLDLD
  {
    public abstract double invokePrim(double paramDouble1, long paramLong1, double paramDouble2, long paramLong2);
  }
  
  public static abstract interface DLDLL
  {
    public abstract long invokePrim(double paramDouble1, long paramLong1, double paramDouble2, long paramLong2);
  }
  
  public static abstract interface DLDLO
  {
    public abstract Object invokePrim(double paramDouble1, long paramLong1, double paramDouble2, long paramLong2);
  }
  
  public static abstract interface DLDOD
  {
    public abstract double invokePrim(double paramDouble1, long paramLong, double paramDouble2, Object paramObject);
  }
  
  public static abstract interface DLDOL
  {
    public abstract long invokePrim(double paramDouble1, long paramLong, double paramDouble2, Object paramObject);
  }
  
  public static abstract interface DLDOO
  {
    public abstract Object invokePrim(double paramDouble1, long paramLong, double paramDouble2, Object paramObject);
  }
  
  public static abstract interface DLLDD
  {
    public abstract double invokePrim(double paramDouble1, long paramLong1, long paramLong2, double paramDouble2);
  }
  
  public static abstract interface DLLDL
  {
    public abstract long invokePrim(double paramDouble1, long paramLong1, long paramLong2, double paramDouble2);
  }
  
  public static abstract interface DLLDO
  {
    public abstract Object invokePrim(double paramDouble1, long paramLong1, long paramLong2, double paramDouble2);
  }
  
  public static abstract interface DLLLD
  {
    public abstract double invokePrim(double paramDouble, long paramLong1, long paramLong2, long paramLong3);
  }
  
  public static abstract interface DLLLL
  {
    public abstract long invokePrim(double paramDouble, long paramLong1, long paramLong2, long paramLong3);
  }
  
  public static abstract interface DLLLO
  {
    public abstract Object invokePrim(double paramDouble, long paramLong1, long paramLong2, long paramLong3);
  }
  
  public static abstract interface DLLOD
  {
    public abstract double invokePrim(double paramDouble, long paramLong1, long paramLong2, Object paramObject);
  }
  
  public static abstract interface DLLOL
  {
    public abstract long invokePrim(double paramDouble, long paramLong1, long paramLong2, Object paramObject);
  }
  
  public static abstract interface DLLOO
  {
    public abstract Object invokePrim(double paramDouble, long paramLong1, long paramLong2, Object paramObject);
  }
  
  public static abstract interface DLODD
  {
    public abstract double invokePrim(double paramDouble1, long paramLong, Object paramObject, double paramDouble2);
  }
  
  public static abstract interface DLODL
  {
    public abstract long invokePrim(double paramDouble1, long paramLong, Object paramObject, double paramDouble2);
  }
  
  public static abstract interface DLODO
  {
    public abstract Object invokePrim(double paramDouble1, long paramLong, Object paramObject, double paramDouble2);
  }
  
  public static abstract interface DLOLD
  {
    public abstract double invokePrim(double paramDouble, long paramLong1, Object paramObject, long paramLong2);
  }
  
  public static abstract interface DLOLL
  {
    public abstract long invokePrim(double paramDouble, long paramLong1, Object paramObject, long paramLong2);
  }
  
  public static abstract interface DLOLO
  {
    public abstract Object invokePrim(double paramDouble, long paramLong1, Object paramObject, long paramLong2);
  }
  
  public static abstract interface DLOOD
  {
    public abstract double invokePrim(double paramDouble, long paramLong, Object paramObject1, Object paramObject2);
  }
  
  public static abstract interface DLOOL
  {
    public abstract long invokePrim(double paramDouble, long paramLong, Object paramObject1, Object paramObject2);
  }
  
  public static abstract interface DLOOO
  {
    public abstract Object invokePrim(double paramDouble, long paramLong, Object paramObject1, Object paramObject2);
  }
  
  public static abstract interface DODDD
  {
    public abstract double invokePrim(double paramDouble1, Object paramObject, double paramDouble2, double paramDouble3);
  }
  
  public static abstract interface DODDL
  {
    public abstract long invokePrim(double paramDouble1, Object paramObject, double paramDouble2, double paramDouble3);
  }
  
  public static abstract interface DODDO
  {
    public abstract Object invokePrim(double paramDouble1, Object paramObject, double paramDouble2, double paramDouble3);
  }
  
  public static abstract interface DODLD
  {
    public abstract double invokePrim(double paramDouble1, Object paramObject, double paramDouble2, long paramLong);
  }
  
  public static abstract interface DODLL
  {
    public abstract long invokePrim(double paramDouble1, Object paramObject, double paramDouble2, long paramLong);
  }
  
  public static abstract interface DODLO
  {
    public abstract Object invokePrim(double paramDouble1, Object paramObject, double paramDouble2, long paramLong);
  }
  
  public static abstract interface DODOD
  {
    public abstract double invokePrim(double paramDouble1, Object paramObject1, double paramDouble2, Object paramObject2);
  }
  
  public static abstract interface DODOL
  {
    public abstract long invokePrim(double paramDouble1, Object paramObject1, double paramDouble2, Object paramObject2);
  }
  
  public static abstract interface DODOO
  {
    public abstract Object invokePrim(double paramDouble1, Object paramObject1, double paramDouble2, Object paramObject2);
  }
  
  public static abstract interface DOLDD
  {
    public abstract double invokePrim(double paramDouble1, Object paramObject, long paramLong, double paramDouble2);
  }
  
  public static abstract interface DOLDL
  {
    public abstract long invokePrim(double paramDouble1, Object paramObject, long paramLong, double paramDouble2);
  }
  
  public static abstract interface DOLDO
  {
    public abstract Object invokePrim(double paramDouble1, Object paramObject, long paramLong, double paramDouble2);
  }
  
  public static abstract interface DOLLD
  {
    public abstract double invokePrim(double paramDouble, Object paramObject, long paramLong1, long paramLong2);
  }
  
  public static abstract interface DOLLL
  {
    public abstract long invokePrim(double paramDouble, Object paramObject, long paramLong1, long paramLong2);
  }
  
  public static abstract interface DOLLO
  {
    public abstract Object invokePrim(double paramDouble, Object paramObject, long paramLong1, long paramLong2);
  }
  
  public static abstract interface DOLOD
  {
    public abstract double invokePrim(double paramDouble, Object paramObject1, long paramLong, Object paramObject2);
  }
  
  public static abstract interface DOLOL
  {
    public abstract long invokePrim(double paramDouble, Object paramObject1, long paramLong, Object paramObject2);
  }
  
  public static abstract interface DOLOO
  {
    public abstract Object invokePrim(double paramDouble, Object paramObject1, long paramLong, Object paramObject2);
  }
  
  public static abstract interface DOODD
  {
    public abstract double invokePrim(double paramDouble1, Object paramObject1, Object paramObject2, double paramDouble2);
  }
  
  public static abstract interface DOODL
  {
    public abstract long invokePrim(double paramDouble1, Object paramObject1, Object paramObject2, double paramDouble2);
  }
  
  public static abstract interface DOODO
  {
    public abstract Object invokePrim(double paramDouble1, Object paramObject1, Object paramObject2, double paramDouble2);
  }
  
  public static abstract interface DOOLD
  {
    public abstract double invokePrim(double paramDouble, Object paramObject1, Object paramObject2, long paramLong);
  }
  
  public static abstract interface DOOLL
  {
    public abstract long invokePrim(double paramDouble, Object paramObject1, Object paramObject2, long paramLong);
  }
  
  public static abstract interface DOOLO
  {
    public abstract Object invokePrim(double paramDouble, Object paramObject1, Object paramObject2, long paramLong);
  }
  
  public static abstract interface DOOOD
  {
    public abstract double invokePrim(double paramDouble, Object paramObject1, Object paramObject2, Object paramObject3);
  }
  
  public static abstract interface DOOOL
  {
    public abstract long invokePrim(double paramDouble, Object paramObject1, Object paramObject2, Object paramObject3);
  }
  
  public static abstract interface DOOOO
  {
    public abstract Object invokePrim(double paramDouble, Object paramObject1, Object paramObject2, Object paramObject3);
  }
  
  public static abstract interface LDDDD
  {
    public abstract double invokePrim(long paramLong, double paramDouble1, double paramDouble2, double paramDouble3);
  }
  
  public static abstract interface LDDDL
  {
    public abstract long invokePrim(long paramLong, double paramDouble1, double paramDouble2, double paramDouble3);
  }
  
  public static abstract interface LDDDO
  {
    public abstract Object invokePrim(long paramLong, double paramDouble1, double paramDouble2, double paramDouble3);
  }
  
  public static abstract interface LDDLD
  {
    public abstract double invokePrim(long paramLong1, double paramDouble1, double paramDouble2, long paramLong2);
  }
  
  public static abstract interface LDDLL
  {
    public abstract long invokePrim(long paramLong1, double paramDouble1, double paramDouble2, long paramLong2);
  }
  
  public static abstract interface LDDLO
  {
    public abstract Object invokePrim(long paramLong1, double paramDouble1, double paramDouble2, long paramLong2);
  }
  
  public static abstract interface LDDOD
  {
    public abstract double invokePrim(long paramLong, double paramDouble1, double paramDouble2, Object paramObject);
  }
  
  public static abstract interface LDDOL
  {
    public abstract long invokePrim(long paramLong, double paramDouble1, double paramDouble2, Object paramObject);
  }
  
  public static abstract interface LDDOO
  {
    public abstract Object invokePrim(long paramLong, double paramDouble1, double paramDouble2, Object paramObject);
  }
  
  public static abstract interface LDLDD
  {
    public abstract double invokePrim(long paramLong1, double paramDouble1, long paramLong2, double paramDouble2);
  }
  
  public static abstract interface LDLDL
  {
    public abstract long invokePrim(long paramLong1, double paramDouble1, long paramLong2, double paramDouble2);
  }
  
  public static abstract interface LDLDO
  {
    public abstract Object invokePrim(long paramLong1, double paramDouble1, long paramLong2, double paramDouble2);
  }
  
  public static abstract interface LDLLD
  {
    public abstract double invokePrim(long paramLong1, double paramDouble, long paramLong2, long paramLong3);
  }
  
  public static abstract interface LDLLL
  {
    public abstract long invokePrim(long paramLong1, double paramDouble, long paramLong2, long paramLong3);
  }
  
  public static abstract interface LDLLO
  {
    public abstract Object invokePrim(long paramLong1, double paramDouble, long paramLong2, long paramLong3);
  }
  
  public static abstract interface LDLOD
  {
    public abstract double invokePrim(long paramLong1, double paramDouble, long paramLong2, Object paramObject);
  }
  
  public static abstract interface LDLOL
  {
    public abstract long invokePrim(long paramLong1, double paramDouble, long paramLong2, Object paramObject);
  }
  
  public static abstract interface LDLOO
  {
    public abstract Object invokePrim(long paramLong1, double paramDouble, long paramLong2, Object paramObject);
  }
  
  public static abstract interface LDODD
  {
    public abstract double invokePrim(long paramLong, double paramDouble1, Object paramObject, double paramDouble2);
  }
  
  public static abstract interface LDODL
  {
    public abstract long invokePrim(long paramLong, double paramDouble1, Object paramObject, double paramDouble2);
  }
  
  public static abstract interface LDODO
  {
    public abstract Object invokePrim(long paramLong, double paramDouble1, Object paramObject, double paramDouble2);
  }
  
  public static abstract interface LDOLD
  {
    public abstract double invokePrim(long paramLong1, double paramDouble, Object paramObject, long paramLong2);
  }
  
  public static abstract interface LDOLL
  {
    public abstract long invokePrim(long paramLong1, double paramDouble, Object paramObject, long paramLong2);
  }
  
  public static abstract interface LDOLO
  {
    public abstract Object invokePrim(long paramLong1, double paramDouble, Object paramObject, long paramLong2);
  }
  
  public static abstract interface LDOOD
  {
    public abstract double invokePrim(long paramLong, double paramDouble, Object paramObject1, Object paramObject2);
  }
  
  public static abstract interface LDOOL
  {
    public abstract long invokePrim(long paramLong, double paramDouble, Object paramObject1, Object paramObject2);
  }
  
  public static abstract interface LDOOO
  {
    public abstract Object invokePrim(long paramLong, double paramDouble, Object paramObject1, Object paramObject2);
  }
  
  public static abstract interface LLDDD
  {
    public abstract double invokePrim(long paramLong1, long paramLong2, double paramDouble1, double paramDouble2);
  }
  
  public static abstract interface LLDDL
  {
    public abstract long invokePrim(long paramLong1, long paramLong2, double paramDouble1, double paramDouble2);
  }
  
  public static abstract interface LLDDO
  {
    public abstract Object invokePrim(long paramLong1, long paramLong2, double paramDouble1, double paramDouble2);
  }
  
  public static abstract interface LLDLD
  {
    public abstract double invokePrim(long paramLong1, long paramLong2, double paramDouble, long paramLong3);
  }
  
  public static abstract interface LLDLL
  {
    public abstract long invokePrim(long paramLong1, long paramLong2, double paramDouble, long paramLong3);
  }
  
  public static abstract interface LLDLO
  {
    public abstract Object invokePrim(long paramLong1, long paramLong2, double paramDouble, long paramLong3);
  }
  
  public static abstract interface LLDOD
  {
    public abstract double invokePrim(long paramLong1, long paramLong2, double paramDouble, Object paramObject);
  }
  
  public static abstract interface LLDOL
  {
    public abstract long invokePrim(long paramLong1, long paramLong2, double paramDouble, Object paramObject);
  }
  
  public static abstract interface LLDOO
  {
    public abstract Object invokePrim(long paramLong1, long paramLong2, double paramDouble, Object paramObject);
  }
  
  public static abstract interface LLLDD
  {
    public abstract double invokePrim(long paramLong1, long paramLong2, long paramLong3, double paramDouble);
  }
  
  public static abstract interface LLLDL
  {
    public abstract long invokePrim(long paramLong1, long paramLong2, long paramLong3, double paramDouble);
  }
  
  public static abstract interface LLLDO
  {
    public abstract Object invokePrim(long paramLong1, long paramLong2, long paramLong3, double paramDouble);
  }
  
  public static abstract interface LLLLD
  {
    public abstract double invokePrim(long paramLong1, long paramLong2, long paramLong3, long paramLong4);
  }
  
  public static abstract interface LLLLL
  {
    public abstract long invokePrim(long paramLong1, long paramLong2, long paramLong3, long paramLong4);
  }
  
  public static abstract interface LLLLO
  {
    public abstract Object invokePrim(long paramLong1, long paramLong2, long paramLong3, long paramLong4);
  }
  
  public static abstract interface LLLOD
  {
    public abstract double invokePrim(long paramLong1, long paramLong2, long paramLong3, Object paramObject);
  }
  
  public static abstract interface LLLOL
  {
    public abstract long invokePrim(long paramLong1, long paramLong2, long paramLong3, Object paramObject);
  }
  
  public static abstract interface LLLOO
  {
    public abstract Object invokePrim(long paramLong1, long paramLong2, long paramLong3, Object paramObject);
  }
  
  public static abstract interface LLODD
  {
    public abstract double invokePrim(long paramLong1, long paramLong2, Object paramObject, double paramDouble);
  }
  
  public static abstract interface LLODL
  {
    public abstract long invokePrim(long paramLong1, long paramLong2, Object paramObject, double paramDouble);
  }
  
  public static abstract interface LLODO
  {
    public abstract Object invokePrim(long paramLong1, long paramLong2, Object paramObject, double paramDouble);
  }
  
  public static abstract interface LLOLD
  {
    public abstract double invokePrim(long paramLong1, long paramLong2, Object paramObject, long paramLong3);
  }
  
  public static abstract interface LLOLL
  {
    public abstract long invokePrim(long paramLong1, long paramLong2, Object paramObject, long paramLong3);
  }
  
  public static abstract interface LLOLO
  {
    public abstract Object invokePrim(long paramLong1, long paramLong2, Object paramObject, long paramLong3);
  }
  
  public static abstract interface LLOOD
  {
    public abstract double invokePrim(long paramLong1, long paramLong2, Object paramObject1, Object paramObject2);
  }
  
  public static abstract interface LLOOL
  {
    public abstract long invokePrim(long paramLong1, long paramLong2, Object paramObject1, Object paramObject2);
  }
  
  public static abstract interface LLOOO
  {
    public abstract Object invokePrim(long paramLong1, long paramLong2, Object paramObject1, Object paramObject2);
  }
  
  public static abstract interface LODDD
  {
    public abstract double invokePrim(long paramLong, Object paramObject, double paramDouble1, double paramDouble2);
  }
  
  public static abstract interface LODDL
  {
    public abstract long invokePrim(long paramLong, Object paramObject, double paramDouble1, double paramDouble2);
  }
  
  public static abstract interface LODDO
  {
    public abstract Object invokePrim(long paramLong, Object paramObject, double paramDouble1, double paramDouble2);
  }
  
  public static abstract interface LODLD
  {
    public abstract double invokePrim(long paramLong1, Object paramObject, double paramDouble, long paramLong2);
  }
  
  public static abstract interface LODLL
  {
    public abstract long invokePrim(long paramLong1, Object paramObject, double paramDouble, long paramLong2);
  }
  
  public static abstract interface LODLO
  {
    public abstract Object invokePrim(long paramLong1, Object paramObject, double paramDouble, long paramLong2);
  }
  
  public static abstract interface LODOD
  {
    public abstract double invokePrim(long paramLong, Object paramObject1, double paramDouble, Object paramObject2);
  }
  
  public static abstract interface LODOL
  {
    public abstract long invokePrim(long paramLong, Object paramObject1, double paramDouble, Object paramObject2);
  }
  
  public static abstract interface LODOO
  {
    public abstract Object invokePrim(long paramLong, Object paramObject1, double paramDouble, Object paramObject2);
  }
  
  public static abstract interface LOLDD
  {
    public abstract double invokePrim(long paramLong1, Object paramObject, long paramLong2, double paramDouble);
  }
  
  public static abstract interface LOLDL
  {
    public abstract long invokePrim(long paramLong1, Object paramObject, long paramLong2, double paramDouble);
  }
  
  public static abstract interface LOLDO
  {
    public abstract Object invokePrim(long paramLong1, Object paramObject, long paramLong2, double paramDouble);
  }
  
  public static abstract interface LOLLD
  {
    public abstract double invokePrim(long paramLong1, Object paramObject, long paramLong2, long paramLong3);
  }
  
  public static abstract interface LOLLL
  {
    public abstract long invokePrim(long paramLong1, Object paramObject, long paramLong2, long paramLong3);
  }
  
  public static abstract interface LOLLO
  {
    public abstract Object invokePrim(long paramLong1, Object paramObject, long paramLong2, long paramLong3);
  }
  
  public static abstract interface LOLOD
  {
    public abstract double invokePrim(long paramLong1, Object paramObject1, long paramLong2, Object paramObject2);
  }
  
  public static abstract interface LOLOL
  {
    public abstract long invokePrim(long paramLong1, Object paramObject1, long paramLong2, Object paramObject2);
  }
  
  public static abstract interface LOLOO
  {
    public abstract Object invokePrim(long paramLong1, Object paramObject1, long paramLong2, Object paramObject2);
  }
  
  public static abstract interface LOODD
  {
    public abstract double invokePrim(long paramLong, Object paramObject1, Object paramObject2, double paramDouble);
  }
  
  public static abstract interface LOODL
  {
    public abstract long invokePrim(long paramLong, Object paramObject1, Object paramObject2, double paramDouble);
  }
  
  public static abstract interface LOODO
  {
    public abstract Object invokePrim(long paramLong, Object paramObject1, Object paramObject2, double paramDouble);
  }
  
  public static abstract interface LOOLD
  {
    public abstract double invokePrim(long paramLong1, Object paramObject1, Object paramObject2, long paramLong2);
  }
  
  public static abstract interface LOOLL
  {
    public abstract long invokePrim(long paramLong1, Object paramObject1, Object paramObject2, long paramLong2);
  }
  
  public static abstract interface LOOLO
  {
    public abstract Object invokePrim(long paramLong1, Object paramObject1, Object paramObject2, long paramLong2);
  }
  
  public static abstract interface LOOOD
  {
    public abstract double invokePrim(long paramLong, Object paramObject1, Object paramObject2, Object paramObject3);
  }
  
  public static abstract interface LOOOL
  {
    public abstract long invokePrim(long paramLong, Object paramObject1, Object paramObject2, Object paramObject3);
  }
  
  public static abstract interface LOOOO
  {
    public abstract Object invokePrim(long paramLong, Object paramObject1, Object paramObject2, Object paramObject3);
  }
  
  public static abstract interface ODDDD
  {
    public abstract double invokePrim(Object paramObject, double paramDouble1, double paramDouble2, double paramDouble3);
  }
  
  public static abstract interface ODDDL
  {
    public abstract long invokePrim(Object paramObject, double paramDouble1, double paramDouble2, double paramDouble3);
  }
  
  public static abstract interface ODDDO
  {
    public abstract Object invokePrim(Object paramObject, double paramDouble1, double paramDouble2, double paramDouble3);
  }
  
  public static abstract interface ODDLD
  {
    public abstract double invokePrim(Object paramObject, double paramDouble1, double paramDouble2, long paramLong);
  }
  
  public static abstract interface ODDLL
  {
    public abstract long invokePrim(Object paramObject, double paramDouble1, double paramDouble2, long paramLong);
  }
  
  public static abstract interface ODDLO
  {
    public abstract Object invokePrim(Object paramObject, double paramDouble1, double paramDouble2, long paramLong);
  }
  
  public static abstract interface ODDOD
  {
    public abstract double invokePrim(Object paramObject1, double paramDouble1, double paramDouble2, Object paramObject2);
  }
  
  public static abstract interface ODDOL
  {
    public abstract long invokePrim(Object paramObject1, double paramDouble1, double paramDouble2, Object paramObject2);
  }
  
  public static abstract interface ODDOO
  {
    public abstract Object invokePrim(Object paramObject1, double paramDouble1, double paramDouble2, Object paramObject2);
  }
  
  public static abstract interface ODLDD
  {
    public abstract double invokePrim(Object paramObject, double paramDouble1, long paramLong, double paramDouble2);
  }
  
  public static abstract interface ODLDL
  {
    public abstract long invokePrim(Object paramObject, double paramDouble1, long paramLong, double paramDouble2);
  }
  
  public static abstract interface ODLDO
  {
    public abstract Object invokePrim(Object paramObject, double paramDouble1, long paramLong, double paramDouble2);
  }
  
  public static abstract interface ODLLD
  {
    public abstract double invokePrim(Object paramObject, double paramDouble, long paramLong1, long paramLong2);
  }
  
  public static abstract interface ODLLL
  {
    public abstract long invokePrim(Object paramObject, double paramDouble, long paramLong1, long paramLong2);
  }
  
  public static abstract interface ODLLO
  {
    public abstract Object invokePrim(Object paramObject, double paramDouble, long paramLong1, long paramLong2);
  }
  
  public static abstract interface ODLOD
  {
    public abstract double invokePrim(Object paramObject1, double paramDouble, long paramLong, Object paramObject2);
  }
  
  public static abstract interface ODLOL
  {
    public abstract long invokePrim(Object paramObject1, double paramDouble, long paramLong, Object paramObject2);
  }
  
  public static abstract interface ODLOO
  {
    public abstract Object invokePrim(Object paramObject1, double paramDouble, long paramLong, Object paramObject2);
  }
  
  public static abstract interface ODODD
  {
    public abstract double invokePrim(Object paramObject1, double paramDouble1, Object paramObject2, double paramDouble2);
  }
  
  public static abstract interface ODODL
  {
    public abstract long invokePrim(Object paramObject1, double paramDouble1, Object paramObject2, double paramDouble2);
  }
  
  public static abstract interface ODODO
  {
    public abstract Object invokePrim(Object paramObject1, double paramDouble1, Object paramObject2, double paramDouble2);
  }
  
  public static abstract interface ODOLD
  {
    public abstract double invokePrim(Object paramObject1, double paramDouble, Object paramObject2, long paramLong);
  }
  
  public static abstract interface ODOLL
  {
    public abstract long invokePrim(Object paramObject1, double paramDouble, Object paramObject2, long paramLong);
  }
  
  public static abstract interface ODOLO
  {
    public abstract Object invokePrim(Object paramObject1, double paramDouble, Object paramObject2, long paramLong);
  }
  
  public static abstract interface ODOOD
  {
    public abstract double invokePrim(Object paramObject1, double paramDouble, Object paramObject2, Object paramObject3);
  }
  
  public static abstract interface ODOOL
  {
    public abstract long invokePrim(Object paramObject1, double paramDouble, Object paramObject2, Object paramObject3);
  }
  
  public static abstract interface ODOOO
  {
    public abstract Object invokePrim(Object paramObject1, double paramDouble, Object paramObject2, Object paramObject3);
  }
  
  public static abstract interface OLDDD
  {
    public abstract double invokePrim(Object paramObject, long paramLong, double paramDouble1, double paramDouble2);
  }
  
  public static abstract interface OLDDL
  {
    public abstract long invokePrim(Object paramObject, long paramLong, double paramDouble1, double paramDouble2);
  }
  
  public static abstract interface OLDDO
  {
    public abstract Object invokePrim(Object paramObject, long paramLong, double paramDouble1, double paramDouble2);
  }
  
  public static abstract interface OLDLD
  {
    public abstract double invokePrim(Object paramObject, long paramLong1, double paramDouble, long paramLong2);
  }
  
  public static abstract interface OLDLL
  {
    public abstract long invokePrim(Object paramObject, long paramLong1, double paramDouble, long paramLong2);
  }
  
  public static abstract interface OLDLO
  {
    public abstract Object invokePrim(Object paramObject, long paramLong1, double paramDouble, long paramLong2);
  }
  
  public static abstract interface OLDOD
  {
    public abstract double invokePrim(Object paramObject1, long paramLong, double paramDouble, Object paramObject2);
  }
  
  public static abstract interface OLDOL
  {
    public abstract long invokePrim(Object paramObject1, long paramLong, double paramDouble, Object paramObject2);
  }
  
  public static abstract interface OLDOO
  {
    public abstract Object invokePrim(Object paramObject1, long paramLong, double paramDouble, Object paramObject2);
  }
  
  public static abstract interface OLLDD
  {
    public abstract double invokePrim(Object paramObject, long paramLong1, long paramLong2, double paramDouble);
  }
  
  public static abstract interface OLLDL
  {
    public abstract long invokePrim(Object paramObject, long paramLong1, long paramLong2, double paramDouble);
  }
  
  public static abstract interface OLLDO
  {
    public abstract Object invokePrim(Object paramObject, long paramLong1, long paramLong2, double paramDouble);
  }
  
  public static abstract interface OLLLD
  {
    public abstract double invokePrim(Object paramObject, long paramLong1, long paramLong2, long paramLong3);
  }
  
  public static abstract interface OLLLL
  {
    public abstract long invokePrim(Object paramObject, long paramLong1, long paramLong2, long paramLong3);
  }
  
  public static abstract interface OLLLO
  {
    public abstract Object invokePrim(Object paramObject, long paramLong1, long paramLong2, long paramLong3);
  }
  
  public static abstract interface OLLOD
  {
    public abstract double invokePrim(Object paramObject1, long paramLong1, long paramLong2, Object paramObject2);
  }
  
  public static abstract interface OLLOL
  {
    public abstract long invokePrim(Object paramObject1, long paramLong1, long paramLong2, Object paramObject2);
  }
  
  public static abstract interface OLLOO
  {
    public abstract Object invokePrim(Object paramObject1, long paramLong1, long paramLong2, Object paramObject2);
  }
  
  public static abstract interface OLODD
  {
    public abstract double invokePrim(Object paramObject1, long paramLong, Object paramObject2, double paramDouble);
  }
  
  public static abstract interface OLODL
  {
    public abstract long invokePrim(Object paramObject1, long paramLong, Object paramObject2, double paramDouble);
  }
  
  public static abstract interface OLODO
  {
    public abstract Object invokePrim(Object paramObject1, long paramLong, Object paramObject2, double paramDouble);
  }
  
  public static abstract interface OLOLD
  {
    public abstract double invokePrim(Object paramObject1, long paramLong1, Object paramObject2, long paramLong2);
  }
  
  public static abstract interface OLOLL
  {
    public abstract long invokePrim(Object paramObject1, long paramLong1, Object paramObject2, long paramLong2);
  }
  
  public static abstract interface OLOLO
  {
    public abstract Object invokePrim(Object paramObject1, long paramLong1, Object paramObject2, long paramLong2);
  }
  
  public static abstract interface OLOOD
  {
    public abstract double invokePrim(Object paramObject1, long paramLong, Object paramObject2, Object paramObject3);
  }
  
  public static abstract interface OLOOL
  {
    public abstract long invokePrim(Object paramObject1, long paramLong, Object paramObject2, Object paramObject3);
  }
  
  public static abstract interface OLOOO
  {
    public abstract Object invokePrim(Object paramObject1, long paramLong, Object paramObject2, Object paramObject3);
  }
  
  public static abstract interface OODDD
  {
    public abstract double invokePrim(Object paramObject1, Object paramObject2, double paramDouble1, double paramDouble2);
  }
  
  public static abstract interface OODDL
  {
    public abstract long invokePrim(Object paramObject1, Object paramObject2, double paramDouble1, double paramDouble2);
  }
  
  public static abstract interface OODDO
  {
    public abstract Object invokePrim(Object paramObject1, Object paramObject2, double paramDouble1, double paramDouble2);
  }
  
  public static abstract interface OODLD
  {
    public abstract double invokePrim(Object paramObject1, Object paramObject2, double paramDouble, long paramLong);
  }
  
  public static abstract interface OODLL
  {
    public abstract long invokePrim(Object paramObject1, Object paramObject2, double paramDouble, long paramLong);
  }
  
  public static abstract interface OODLO
  {
    public abstract Object invokePrim(Object paramObject1, Object paramObject2, double paramDouble, long paramLong);
  }
  
  public static abstract interface OODOD
  {
    public abstract double invokePrim(Object paramObject1, Object paramObject2, double paramDouble, Object paramObject3);
  }
  
  public static abstract interface OODOL
  {
    public abstract long invokePrim(Object paramObject1, Object paramObject2, double paramDouble, Object paramObject3);
  }
  
  public static abstract interface OODOO
  {
    public abstract Object invokePrim(Object paramObject1, Object paramObject2, double paramDouble, Object paramObject3);
  }
  
  public static abstract interface OOLDD
  {
    public abstract double invokePrim(Object paramObject1, Object paramObject2, long paramLong, double paramDouble);
  }
  
  public static abstract interface OOLDL
  {
    public abstract long invokePrim(Object paramObject1, Object paramObject2, long paramLong, double paramDouble);
  }
  
  public static abstract interface OOLDO
  {
    public abstract Object invokePrim(Object paramObject1, Object paramObject2, long paramLong, double paramDouble);
  }
  
  public static abstract interface OOLLD
  {
    public abstract double invokePrim(Object paramObject1, Object paramObject2, long paramLong1, long paramLong2);
  }
  
  public static abstract interface OOLLL
  {
    public abstract long invokePrim(Object paramObject1, Object paramObject2, long paramLong1, long paramLong2);
  }
  
  public static abstract interface OOLLO
  {
    public abstract Object invokePrim(Object paramObject1, Object paramObject2, long paramLong1, long paramLong2);
  }
  
  public static abstract interface OOLOD
  {
    public abstract double invokePrim(Object paramObject1, Object paramObject2, long paramLong, Object paramObject3);
  }
  
  public static abstract interface OOLOL
  {
    public abstract long invokePrim(Object paramObject1, Object paramObject2, long paramLong, Object paramObject3);
  }
  
  public static abstract interface OOLOO
  {
    public abstract Object invokePrim(Object paramObject1, Object paramObject2, long paramLong, Object paramObject3);
  }
  
  public static abstract interface OOODD
  {
    public abstract double invokePrim(Object paramObject1, Object paramObject2, Object paramObject3, double paramDouble);
  }
  
  public static abstract interface OOODL
  {
    public abstract long invokePrim(Object paramObject1, Object paramObject2, Object paramObject3, double paramDouble);
  }
  
  public static abstract interface OOODO
  {
    public abstract Object invokePrim(Object paramObject1, Object paramObject2, Object paramObject3, double paramDouble);
  }
  
  public static abstract interface OOOLD
  {
    public abstract double invokePrim(Object paramObject1, Object paramObject2, Object paramObject3, long paramLong);
  }
  
  public static abstract interface OOOLL
  {
    public abstract long invokePrim(Object paramObject1, Object paramObject2, Object paramObject3, long paramLong);
  }
  
  public static abstract interface OOOLO
  {
    public abstract Object invokePrim(Object paramObject1, Object paramObject2, Object paramObject3, long paramLong);
  }
  
  public static abstract interface OOOOD
  {
    public abstract double invokePrim(Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4);
  }
  
  public static abstract interface OOOOL
  {
    public abstract long invokePrim(Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4);
  }
  
  public static abstract interface DDDD
  {
    public abstract double invokePrim(double paramDouble1, double paramDouble2, double paramDouble3);
  }
  
  public static abstract interface DDDL
  {
    public abstract long invokePrim(double paramDouble1, double paramDouble2, double paramDouble3);
  }
  
  public static abstract interface DDDO
  {
    public abstract Object invokePrim(double paramDouble1, double paramDouble2, double paramDouble3);
  }
  
  public static abstract interface DDLD
  {
    public abstract double invokePrim(double paramDouble1, double paramDouble2, long paramLong);
  }
  
  public static abstract interface DDLL
  {
    public abstract long invokePrim(double paramDouble1, double paramDouble2, long paramLong);
  }
  
  public static abstract interface DDLO
  {
    public abstract Object invokePrim(double paramDouble1, double paramDouble2, long paramLong);
  }
  
  public static abstract interface DDOD
  {
    public abstract double invokePrim(double paramDouble1, double paramDouble2, Object paramObject);
  }
  
  public static abstract interface DDOL
  {
    public abstract long invokePrim(double paramDouble1, double paramDouble2, Object paramObject);
  }
  
  public static abstract interface DDOO
  {
    public abstract Object invokePrim(double paramDouble1, double paramDouble2, Object paramObject);
  }
  
  public static abstract interface DLDD
  {
    public abstract double invokePrim(double paramDouble1, long paramLong, double paramDouble2);
  }
  
  public static abstract interface DLDL
  {
    public abstract long invokePrim(double paramDouble1, long paramLong, double paramDouble2);
  }
  
  public static abstract interface DLDO
  {
    public abstract Object invokePrim(double paramDouble1, long paramLong, double paramDouble2);
  }
  
  public static abstract interface DLLD
  {
    public abstract double invokePrim(double paramDouble, long paramLong1, long paramLong2);
  }
  
  public static abstract interface DLLL
  {
    public abstract long invokePrim(double paramDouble, long paramLong1, long paramLong2);
  }
  
  public static abstract interface DLLO
  {
    public abstract Object invokePrim(double paramDouble, long paramLong1, long paramLong2);
  }
  
  public static abstract interface DLOD
  {
    public abstract double invokePrim(double paramDouble, long paramLong, Object paramObject);
  }
  
  public static abstract interface DLOL
  {
    public abstract long invokePrim(double paramDouble, long paramLong, Object paramObject);
  }
  
  public static abstract interface DLOO
  {
    public abstract Object invokePrim(double paramDouble, long paramLong, Object paramObject);
  }
  
  public static abstract interface DODD
  {
    public abstract double invokePrim(double paramDouble1, Object paramObject, double paramDouble2);
  }
  
  public static abstract interface DODL
  {
    public abstract long invokePrim(double paramDouble1, Object paramObject, double paramDouble2);
  }
  
  public static abstract interface DODO
  {
    public abstract Object invokePrim(double paramDouble1, Object paramObject, double paramDouble2);
  }
  
  public static abstract interface DOLD
  {
    public abstract double invokePrim(double paramDouble, Object paramObject, long paramLong);
  }
  
  public static abstract interface DOLL
  {
    public abstract long invokePrim(double paramDouble, Object paramObject, long paramLong);
  }
  
  public static abstract interface DOLO
  {
    public abstract Object invokePrim(double paramDouble, Object paramObject, long paramLong);
  }
  
  public static abstract interface DOOD
  {
    public abstract double invokePrim(double paramDouble, Object paramObject1, Object paramObject2);
  }
  
  public static abstract interface DOOL
  {
    public abstract long invokePrim(double paramDouble, Object paramObject1, Object paramObject2);
  }
  
  public static abstract interface DOOO
  {
    public abstract Object invokePrim(double paramDouble, Object paramObject1, Object paramObject2);
  }
  
  public static abstract interface LDDD
  {
    public abstract double invokePrim(long paramLong, double paramDouble1, double paramDouble2);
  }
  
  public static abstract interface LDDL
  {
    public abstract long invokePrim(long paramLong, double paramDouble1, double paramDouble2);
  }
  
  public static abstract interface LDDO
  {
    public abstract Object invokePrim(long paramLong, double paramDouble1, double paramDouble2);
  }
  
  public static abstract interface LDLD
  {
    public abstract double invokePrim(long paramLong1, double paramDouble, long paramLong2);
  }
  
  public static abstract interface LDLL
  {
    public abstract long invokePrim(long paramLong1, double paramDouble, long paramLong2);
  }
  
  public static abstract interface LDLO
  {
    public abstract Object invokePrim(long paramLong1, double paramDouble, long paramLong2);
  }
  
  public static abstract interface LDOD
  {
    public abstract double invokePrim(long paramLong, double paramDouble, Object paramObject);
  }
  
  public static abstract interface LDOL
  {
    public abstract long invokePrim(long paramLong, double paramDouble, Object paramObject);
  }
  
  public static abstract interface LDOO
  {
    public abstract Object invokePrim(long paramLong, double paramDouble, Object paramObject);
  }
  
  public static abstract interface LLDD
  {
    public abstract double invokePrim(long paramLong1, long paramLong2, double paramDouble);
  }
  
  public static abstract interface LLDL
  {
    public abstract long invokePrim(long paramLong1, long paramLong2, double paramDouble);
  }
  
  public static abstract interface LLDO
  {
    public abstract Object invokePrim(long paramLong1, long paramLong2, double paramDouble);
  }
  
  public static abstract interface LLLD
  {
    public abstract double invokePrim(long paramLong1, long paramLong2, long paramLong3);
  }
  
  public static abstract interface LLLL
  {
    public abstract long invokePrim(long paramLong1, long paramLong2, long paramLong3);
  }
  
  public static abstract interface LLLO
  {
    public abstract Object invokePrim(long paramLong1, long paramLong2, long paramLong3);
  }
  
  public static abstract interface LLOD
  {
    public abstract double invokePrim(long paramLong1, long paramLong2, Object paramObject);
  }
  
  public static abstract interface LLOL
  {
    public abstract long invokePrim(long paramLong1, long paramLong2, Object paramObject);
  }
  
  public static abstract interface LLOO
  {
    public abstract Object invokePrim(long paramLong1, long paramLong2, Object paramObject);
  }
  
  public static abstract interface LODD
  {
    public abstract double invokePrim(long paramLong, Object paramObject, double paramDouble);
  }
  
  public static abstract interface LODL
  {
    public abstract long invokePrim(long paramLong, Object paramObject, double paramDouble);
  }
  
  public static abstract interface LODO
  {
    public abstract Object invokePrim(long paramLong, Object paramObject, double paramDouble);
  }
  
  public static abstract interface LOLD
  {
    public abstract double invokePrim(long paramLong1, Object paramObject, long paramLong2);
  }
  
  public static abstract interface LOLL
  {
    public abstract long invokePrim(long paramLong1, Object paramObject, long paramLong2);
  }
  
  public static abstract interface LOLO
  {
    public abstract Object invokePrim(long paramLong1, Object paramObject, long paramLong2);
  }
  
  public static abstract interface LOOD
  {
    public abstract double invokePrim(long paramLong, Object paramObject1, Object paramObject2);
  }
  
  public static abstract interface LOOL
  {
    public abstract long invokePrim(long paramLong, Object paramObject1, Object paramObject2);
  }
  
  public static abstract interface LOOO
  {
    public abstract Object invokePrim(long paramLong, Object paramObject1, Object paramObject2);
  }
  
  public static abstract interface ODDD
  {
    public abstract double invokePrim(Object paramObject, double paramDouble1, double paramDouble2);
  }
  
  public static abstract interface ODDL
  {
    public abstract long invokePrim(Object paramObject, double paramDouble1, double paramDouble2);
  }
  
  public static abstract interface ODDO
  {
    public abstract Object invokePrim(Object paramObject, double paramDouble1, double paramDouble2);
  }
  
  public static abstract interface ODLD
  {
    public abstract double invokePrim(Object paramObject, double paramDouble, long paramLong);
  }
  
  public static abstract interface ODLL
  {
    public abstract long invokePrim(Object paramObject, double paramDouble, long paramLong);
  }
  
  public static abstract interface ODLO
  {
    public abstract Object invokePrim(Object paramObject, double paramDouble, long paramLong);
  }
  
  public static abstract interface ODOD
  {
    public abstract double invokePrim(Object paramObject1, double paramDouble, Object paramObject2);
  }
  
  public static abstract interface ODOL
  {
    public abstract long invokePrim(Object paramObject1, double paramDouble, Object paramObject2);
  }
  
  public static abstract interface ODOO
  {
    public abstract Object invokePrim(Object paramObject1, double paramDouble, Object paramObject2);
  }
  
  public static abstract interface OLDD
  {
    public abstract double invokePrim(Object paramObject, long paramLong, double paramDouble);
  }
  
  public static abstract interface OLDL
  {
    public abstract long invokePrim(Object paramObject, long paramLong, double paramDouble);
  }
  
  public static abstract interface OLDO
  {
    public abstract Object invokePrim(Object paramObject, long paramLong, double paramDouble);
  }
  
  public static abstract interface OLLD
  {
    public abstract double invokePrim(Object paramObject, long paramLong1, long paramLong2);
  }
  
  public static abstract interface OLLL
  {
    public abstract long invokePrim(Object paramObject, long paramLong1, long paramLong2);
  }
  
  public static abstract interface OLLO
  {
    public abstract Object invokePrim(Object paramObject, long paramLong1, long paramLong2);
  }
  
  public static abstract interface OLOD
  {
    public abstract double invokePrim(Object paramObject1, long paramLong, Object paramObject2);
  }
  
  public static abstract interface OLOL
  {
    public abstract long invokePrim(Object paramObject1, long paramLong, Object paramObject2);
  }
  
  public static abstract interface OLOO
  {
    public abstract Object invokePrim(Object paramObject1, long paramLong, Object paramObject2);
  }
  
  public static abstract interface OODD
  {
    public abstract double invokePrim(Object paramObject1, Object paramObject2, double paramDouble);
  }
  
  public static abstract interface OODL
  {
    public abstract long invokePrim(Object paramObject1, Object paramObject2, double paramDouble);
  }
  
  public static abstract interface OODO
  {
    public abstract Object invokePrim(Object paramObject1, Object paramObject2, double paramDouble);
  }
  
  public static abstract interface OOLD
  {
    public abstract double invokePrim(Object paramObject1, Object paramObject2, long paramLong);
  }
  
  public static abstract interface OOLL
  {
    public abstract long invokePrim(Object paramObject1, Object paramObject2, long paramLong);
  }
  
  public static abstract interface OOLO
  {
    public abstract Object invokePrim(Object paramObject1, Object paramObject2, long paramLong);
  }
  
  public static abstract interface OOOD
  {
    public abstract double invokePrim(Object paramObject1, Object paramObject2, Object paramObject3);
  }
  
  public static abstract interface OOOL
  {
    public abstract long invokePrim(Object paramObject1, Object paramObject2, Object paramObject3);
  }
  
  public static abstract interface DDD
  {
    public abstract double invokePrim(double paramDouble1, double paramDouble2);
  }
  
  public static abstract interface DDL
  {
    public abstract long invokePrim(double paramDouble1, double paramDouble2);
  }
  
  public static abstract interface DDO
  {
    public abstract Object invokePrim(double paramDouble1, double paramDouble2);
  }
  
  public static abstract interface DLD
  {
    public abstract double invokePrim(double paramDouble, long paramLong);
  }
  
  public static abstract interface DLL
  {
    public abstract long invokePrim(double paramDouble, long paramLong);
  }
  
  public static abstract interface DLO
  {
    public abstract Object invokePrim(double paramDouble, long paramLong);
  }
  
  public static abstract interface DOD
  {
    public abstract double invokePrim(double paramDouble, Object paramObject);
  }
  
  public static abstract interface DOL
  {
    public abstract long invokePrim(double paramDouble, Object paramObject);
  }
  
  public static abstract interface DOO
  {
    public abstract Object invokePrim(double paramDouble, Object paramObject);
  }
  
  public static abstract interface LDD
  {
    public abstract double invokePrim(long paramLong, double paramDouble);
  }
  
  public static abstract interface LDL
  {
    public abstract long invokePrim(long paramLong, double paramDouble);
  }
  
  public static abstract interface LDO
  {
    public abstract Object invokePrim(long paramLong, double paramDouble);
  }
  
  public static abstract interface LLD
  {
    public abstract double invokePrim(long paramLong1, long paramLong2);
  }
  
  public static abstract interface LLL
  {
    public abstract long invokePrim(long paramLong1, long paramLong2);
  }
  
  public static abstract interface LLO
  {
    public abstract Object invokePrim(long paramLong1, long paramLong2);
  }
  
  public static abstract interface LOD
  {
    public abstract double invokePrim(long paramLong, Object paramObject);
  }
  
  public static abstract interface LOL
  {
    public abstract long invokePrim(long paramLong, Object paramObject);
  }
  
  public static abstract interface LOO
  {
    public abstract Object invokePrim(long paramLong, Object paramObject);
  }
  
  public static abstract interface ODD
  {
    public abstract double invokePrim(Object paramObject, double paramDouble);
  }
  
  public static abstract interface ODL
  {
    public abstract long invokePrim(Object paramObject, double paramDouble);
  }
  
  public static abstract interface ODO
  {
    public abstract Object invokePrim(Object paramObject, double paramDouble);
  }
  
  public static abstract interface OLD
  {
    public abstract double invokePrim(Object paramObject, long paramLong);
  }
  
  public static abstract interface OLL
  {
    public abstract long invokePrim(Object paramObject, long paramLong);
  }
  
  public static abstract interface OLO
  {
    public abstract Object invokePrim(Object paramObject, long paramLong);
  }
  
  public static abstract interface OOD
  {
    public abstract double invokePrim(Object paramObject1, Object paramObject2);
  }
  
  public static abstract interface OOL
  {
    public abstract long invokePrim(Object paramObject1, Object paramObject2);
  }
  
  public static abstract interface DD
  {
    public abstract double invokePrim(double paramDouble);
  }
  
  public static abstract interface DL
  {
    public abstract long invokePrim(double paramDouble);
  }
  
  public static abstract interface DO
  {
    public abstract Object invokePrim(double paramDouble);
  }
  
  public static abstract interface LD
  {
    public abstract double invokePrim(long paramLong);
  }
  
  public static abstract interface LL
  {
    public abstract long invokePrim(long paramLong);
  }
  
  public static abstract interface LO
  {
    public abstract Object invokePrim(long paramLong);
  }
  
  public static abstract interface OD
  {
    public abstract double invokePrim(Object paramObject);
  }
  
  public static abstract interface OL
  {
    public abstract long invokePrim(Object paramObject);
  }
  
  public static abstract interface D
  {
    public abstract double invokePrim();
  }
  
  public static abstract interface L
  {
    public abstract long invokePrim();
  }
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\lang\IFn.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */