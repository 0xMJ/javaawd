package clojure.inspector.proxy$javax.swing.table;

import clojure.lang.IPersistentCollection;
import clojure.lang.IPersistentMap;
import clojure.lang.IProxy;
import javax.swing.table.AbstractTableModel;

public class AbstractTableModel$ff19274a
  extends AbstractTableModel
  implements IProxy
{
  private volatile IPersistentMap __clojureFnMap;
  
  public void __initClojureFnMappings(IPersistentMap paramIPersistentMap)
  {
    this.__clojureFnMap = paramIPersistentMap;
  }
  
  public void __updateClojureFnMappings(IPersistentMap paramIPersistentMap)
  {
    this.__clojureFnMap = ((IPersistentMap)((IPersistentCollection)this.__clojureFnMap).cons(paramIPersistentMap));
  }
  
  public IPersistentMap __getClojureFnMappings()
  {
    return this.__clojureFnMap;
  }
  
  /* Error */
  public void addTableModelListener(javax.swing.event.TableModelListener arg1)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/inspector/proxy$javax/swing/table/AbstractTableModel$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 30
    //   6: invokestatic 36	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +17 -> 27
    //   13: checkcast 38	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: invokeinterface 41 3 0
    //   23: pop
    //   24: goto +9 -> 33
    //   27: pop
    //   28: aload_0
    //   29: aload_1
    //   30: invokespecial 43	javax/swing/table/AbstractTableModel:addTableModelListener	(Ljavax/swing/event/TableModelListener;)V
    //   33: return
  }
  
  /* Error */
  public boolean equals(Object arg1)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/inspector/proxy$javax/swing/table/AbstractTableModel$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 46
    //   6: invokestatic 36	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +22 -> 32
    //   13: checkcast 38	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: invokeinterface 41 3 0
    //   23: checkcast 48	java/lang/Boolean
    //   26: invokevirtual 52	java/lang/Boolean:booleanValue	()Z
    //   29: goto +9 -> 38
    //   32: pop
    //   33: aload_0
    //   34: aload_1
    //   35: invokespecial 54	javax/swing/table/AbstractTableModel:equals	(Ljava/lang/Object;)Z
    //   38: ireturn
  }
  
  /* Error */
  public int findColumn(String arg1)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/inspector/proxy$javax/swing/table/AbstractTableModel$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 57
    //   6: invokestatic 36	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +22 -> 32
    //   13: checkcast 38	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: invokeinterface 41 3 0
    //   23: checkcast 59	java/lang/Number
    //   26: invokevirtual 63	java/lang/Number:intValue	()I
    //   29: goto +9 -> 38
    //   32: pop
    //   33: aload_0
    //   34: aload_1
    //   35: invokespecial 65	javax/swing/table/AbstractTableModel:findColumn	(Ljava/lang/String;)I
    //   38: ireturn
  }
  
  /* Error */
  public String toString()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/inspector/proxy$javax/swing/table/AbstractTableModel$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 68
    //   6: invokestatic 36	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +18 -> 28
    //   13: checkcast 38	clojure/lang/IFn
    //   16: aload_0
    //   17: invokeinterface 71 2 0
    //   22: checkcast 73	java/lang/String
    //   25: goto +8 -> 33
    //   28: pop
    //   29: aload_0
    //   30: invokespecial 75	javax/swing/table/AbstractTableModel:toString	()Ljava/lang/String;
    //   33: areturn
  }
  
  /* Error */
  public void fireTableCellUpdated(int arg1, int arg2)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/inspector/proxy$javax/swing/table/AbstractTableModel$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 78
    //   6: invokestatic 36	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +24 -> 34
    //   13: checkcast 38	clojure/lang/IFn
    //   16: aload_0
    //   17: iload_1
    //   18: invokestatic 84	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   21: iload_2
    //   22: invokestatic 84	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   25: invokeinterface 87 4 0
    //   30: pop
    //   31: goto +10 -> 41
    //   34: pop
    //   35: aload_0
    //   36: iload_1
    //   37: iload_2
    //   38: invokespecial 89	javax/swing/table/AbstractTableModel:fireTableCellUpdated	(II)V
    //   41: return
  }
  
  /* Error */
  public void fireTableRowsDeleted(int arg1, int arg2)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/inspector/proxy$javax/swing/table/AbstractTableModel$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 91
    //   6: invokestatic 36	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +24 -> 34
    //   13: checkcast 38	clojure/lang/IFn
    //   16: aload_0
    //   17: iload_1
    //   18: invokestatic 84	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   21: iload_2
    //   22: invokestatic 84	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   25: invokeinterface 87 4 0
    //   30: pop
    //   31: goto +10 -> 41
    //   34: pop
    //   35: aload_0
    //   36: iload_1
    //   37: iload_2
    //   38: invokespecial 93	javax/swing/table/AbstractTableModel:fireTableRowsDeleted	(II)V
    //   41: return
  }
  
  /* Error */
  public String getColumnName(int arg1)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/inspector/proxy$javax/swing/table/AbstractTableModel$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 96
    //   6: invokestatic 36	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +22 -> 32
    //   13: checkcast 38	clojure/lang/IFn
    //   16: aload_0
    //   17: iload_1
    //   18: invokestatic 84	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   21: invokeinterface 41 3 0
    //   26: checkcast 73	java/lang/String
    //   29: goto +9 -> 38
    //   32: pop
    //   33: aload_0
    //   34: iload_1
    //   35: invokespecial 98	javax/swing/table/AbstractTableModel:getColumnName	(I)Ljava/lang/String;
    //   38: areturn
  }
  
  /* Error */
  public boolean isCellEditable(int arg1, int arg2)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/inspector/proxy$javax/swing/table/AbstractTableModel$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 101
    //   6: invokestatic 36	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +29 -> 39
    //   13: checkcast 38	clojure/lang/IFn
    //   16: aload_0
    //   17: iload_1
    //   18: invokestatic 84	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   21: iload_2
    //   22: invokestatic 84	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   25: invokeinterface 87 4 0
    //   30: checkcast 48	java/lang/Boolean
    //   33: invokevirtual 52	java/lang/Boolean:booleanValue	()Z
    //   36: goto +10 -> 46
    //   39: pop
    //   40: aload_0
    //   41: iload_1
    //   42: iload_2
    //   43: invokespecial 103	javax/swing/table/AbstractTableModel:isCellEditable	(II)Z
    //   46: ireturn
  }
  
  /* Error */
  public Class getColumnClass(int arg1)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/inspector/proxy$javax/swing/table/AbstractTableModel$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 106
    //   6: invokestatic 36	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +22 -> 32
    //   13: checkcast 38	clojure/lang/IFn
    //   16: aload_0
    //   17: iload_1
    //   18: invokestatic 84	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   21: invokeinterface 41 3 0
    //   26: checkcast 108	java/lang/Class
    //   29: goto +9 -> 38
    //   32: pop
    //   33: aload_0
    //   34: iload_1
    //   35: invokespecial 110	javax/swing/table/AbstractTableModel:getColumnClass	(I)Ljava/lang/Class;
    //   38: areturn
  }
  
  /* Error */
  public javax.swing.event.TableModelListener[] getTableModelListeners()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/inspector/proxy$javax/swing/table/AbstractTableModel$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 113
    //   6: invokestatic 36	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +18 -> 28
    //   13: checkcast 38	clojure/lang/IFn
    //   16: aload_0
    //   17: invokeinterface 71 2 0
    //   22: checkcast 115	[Ljavax/swing/event/TableModelListener;
    //   25: goto +8 -> 33
    //   28: pop
    //   29: aload_0
    //   30: invokespecial 117	javax/swing/table/AbstractTableModel:getTableModelListeners	()[Ljavax/swing/event/TableModelListener;
    //   33: areturn
  }
  
  /* Error */
  public void fireTableDataChanged()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/inspector/proxy$javax/swing/table/AbstractTableModel$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 119
    //   6: invokestatic 36	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +16 -> 26
    //   13: checkcast 38	clojure/lang/IFn
    //   16: aload_0
    //   17: invokeinterface 71 2 0
    //   22: pop
    //   23: goto +8 -> 31
    //   26: pop
    //   27: aload_0
    //   28: invokespecial 121	javax/swing/table/AbstractTableModel:fireTableDataChanged	()V
    //   31: return
  }
  
  /* Error */
  public void fireTableStructureChanged()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/inspector/proxy$javax/swing/table/AbstractTableModel$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 123
    //   6: invokestatic 36	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +16 -> 26
    //   13: checkcast 38	clojure/lang/IFn
    //   16: aload_0
    //   17: invokeinterface 71 2 0
    //   22: pop
    //   23: goto +8 -> 31
    //   26: pop
    //   27: aload_0
    //   28: invokespecial 125	javax/swing/table/AbstractTableModel:fireTableStructureChanged	()V
    //   31: return
  }
  
  /* Error */
  public java.util.EventListener[] getListeners(Class arg1)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/inspector/proxy$javax/swing/table/AbstractTableModel$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc -128
    //   6: invokestatic 36	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +19 -> 29
    //   13: checkcast 38	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: invokeinterface 41 3 0
    //   23: checkcast 130	[Ljava/util/EventListener;
    //   26: goto +9 -> 35
    //   29: pop
    //   30: aload_0
    //   31: aload_1
    //   32: invokespecial 132	javax/swing/table/AbstractTableModel:getListeners	(Ljava/lang/Class;)[Ljava/util/EventListener;
    //   35: areturn
  }
  
  /* Error */
  public void setValueAt(Object arg1, int arg2, int arg3)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/inspector/proxy$javax/swing/table/AbstractTableModel$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc -121
    //   6: invokestatic 36	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +25 -> 35
    //   13: checkcast 38	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: iload_2
    //   19: invokestatic 84	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   22: iload_3
    //   23: invokestatic 84	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   26: invokeinterface 138 5 0
    //   31: pop
    //   32: goto +11 -> 43
    //   35: pop
    //   36: aload_0
    //   37: aload_1
    //   38: iload_2
    //   39: iload_3
    //   40: invokespecial 140	javax/swing/table/AbstractTableModel:setValueAt	(Ljava/lang/Object;II)V
    //   43: return
  }
  
  /* Error */
  public void fireTableRowsInserted(int arg1, int arg2)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/inspector/proxy$javax/swing/table/AbstractTableModel$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc -114
    //   6: invokestatic 36	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +24 -> 34
    //   13: checkcast 38	clojure/lang/IFn
    //   16: aload_0
    //   17: iload_1
    //   18: invokestatic 84	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   21: iload_2
    //   22: invokestatic 84	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   25: invokeinterface 87 4 0
    //   30: pop
    //   31: goto +10 -> 41
    //   34: pop
    //   35: aload_0
    //   36: iload_1
    //   37: iload_2
    //   38: invokespecial 144	javax/swing/table/AbstractTableModel:fireTableRowsInserted	(II)V
    //   41: return
  }
  
  /* Error */
  public int hashCode()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/inspector/proxy$javax/swing/table/AbstractTableModel$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc -110
    //   6: invokestatic 36	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +21 -> 31
    //   13: checkcast 38	clojure/lang/IFn
    //   16: aload_0
    //   17: invokeinterface 71 2 0
    //   22: checkcast 59	java/lang/Number
    //   25: invokevirtual 63	java/lang/Number:intValue	()I
    //   28: goto +8 -> 36
    //   31: pop
    //   32: aload_0
    //   33: invokespecial 148	javax/swing/table/AbstractTableModel:hashCode	()I
    //   36: ireturn
  }
  
  /* Error */
  public void fireTableRowsUpdated(int arg1, int arg2)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/inspector/proxy$javax/swing/table/AbstractTableModel$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc -106
    //   6: invokestatic 36	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +24 -> 34
    //   13: checkcast 38	clojure/lang/IFn
    //   16: aload_0
    //   17: iload_1
    //   18: invokestatic 84	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   21: iload_2
    //   22: invokestatic 84	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   25: invokeinterface 87 4 0
    //   30: pop
    //   31: goto +10 -> 41
    //   34: pop
    //   35: aload_0
    //   36: iload_1
    //   37: iload_2
    //   38: invokespecial 152	javax/swing/table/AbstractTableModel:fireTableRowsUpdated	(II)V
    //   41: return
  }
  
  /* Error */
  public void fireTableChanged(javax.swing.event.TableModelEvent arg1)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/inspector/proxy$javax/swing/table/AbstractTableModel$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc -101
    //   6: invokestatic 36	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +17 -> 27
    //   13: checkcast 38	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: invokeinterface 41 3 0
    //   23: pop
    //   24: goto +9 -> 33
    //   27: pop
    //   28: aload_0
    //   29: aload_1
    //   30: invokespecial 157	javax/swing/table/AbstractTableModel:fireTableChanged	(Ljavax/swing/event/TableModelEvent;)V
    //   33: return
  }
  
  /* Error */
  public void removeTableModelListener(javax.swing.event.TableModelListener arg1)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/inspector/proxy$javax/swing/table/AbstractTableModel$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc -97
    //   6: invokestatic 36	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +17 -> 27
    //   13: checkcast 38	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: invokeinterface 41 3 0
    //   23: pop
    //   24: goto +9 -> 33
    //   27: pop
    //   28: aload_0
    //   29: aload_1
    //   30: invokespecial 161	javax/swing/table/AbstractTableModel:removeTableModelListener	(Ljavax/swing/event/TableModelListener;)V
    //   33: return
  }
  
  /* Error */
  public Object clone()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/inspector/proxy$javax/swing/table/AbstractTableModel$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc -92
    //   6: invokestatic 36	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +15 -> 25
    //   13: checkcast 38	clojure/lang/IFn
    //   16: aload_0
    //   17: invokeinterface 71 2 0
    //   22: goto +8 -> 30
    //   25: pop
    //   26: aload_0
    //   27: invokespecial 166	javax/swing/table/AbstractTableModel:clone	()Ljava/lang/Object;
    //   30: areturn
  }
  
  /* Error */
  public Object getValueAt(int arg1, int arg2)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/inspector/proxy$javax/swing/table/AbstractTableModel$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc -87
    //   6: invokestatic 36	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +23 -> 33
    //   13: checkcast 38	clojure/lang/IFn
    //   16: aload_0
    //   17: iload_1
    //   18: invokestatic 84	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   21: iload_2
    //   22: invokestatic 84	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   25: invokeinterface 87 4 0
    //   30: goto +14 -> 44
    //   33: pop
    //   34: new 171	java/lang/UnsupportedOperationException
    //   37: dup
    //   38: ldc -87
    //   40: invokespecial 174	java/lang/UnsupportedOperationException:<init>	(Ljava/lang/String;)V
    //   43: athrow
    //   44: areturn
  }
  
  /* Error */
  public int getRowCount()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/inspector/proxy$javax/swing/table/AbstractTableModel$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc -80
    //   6: invokestatic 36	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +21 -> 31
    //   13: checkcast 38	clojure/lang/IFn
    //   16: aload_0
    //   17: invokeinterface 71 2 0
    //   22: checkcast 59	java/lang/Number
    //   25: invokevirtual 63	java/lang/Number:intValue	()I
    //   28: goto +14 -> 42
    //   31: pop
    //   32: new 171	java/lang/UnsupportedOperationException
    //   35: dup
    //   36: ldc -80
    //   38: invokespecial 174	java/lang/UnsupportedOperationException:<init>	(Ljava/lang/String;)V
    //   41: athrow
    //   42: ireturn
  }
  
  /* Error */
  public int getColumnCount()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 16	clojure/inspector/proxy$javax/swing/table/AbstractTableModel$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc -78
    //   6: invokestatic 36	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +21 -> 31
    //   13: checkcast 38	clojure/lang/IFn
    //   16: aload_0
    //   17: invokeinterface 71 2 0
    //   22: checkcast 59	java/lang/Number
    //   25: invokevirtual 63	java/lang/Number:intValue	()I
    //   28: goto +14 -> 42
    //   31: pop
    //   32: new 171	java/lang/UnsupportedOperationException
    //   35: dup
    //   36: ldc -78
    //   38: invokespecial 174	java/lang/UnsupportedOperationException:<init>	(Ljava/lang/String;)V
    //   41: athrow
    //   42: ireturn
  }
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\inspector\proxy$javax\swing\table\AbstractTableModel$ff19274a.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */