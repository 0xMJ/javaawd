package clojure.inspector.proxy$java.lang;

import clojure.lang.IPersistentCollection;
import clojure.lang.IPersistentMap;
import clojure.lang.IProxy;
import javax.swing.tree.TreeModel;

public class Object$TreeModel$775afa87
  implements IProxy, TreeModel
{
  private volatile IPersistentMap __clojureFnMap;
  
  public void __initClojureFnMappings(IPersistentMap paramIPersistentMap)
  {
    this.__clojureFnMap = paramIPersistentMap;
  }
  
  public void __updateClojureFnMappings(IPersistentMap paramIPersistentMap)
  {
    this.__clojureFnMap = ((IPersistentMap)((IPersistentCollection)this.__clojureFnMap).cons(paramIPersistentMap));
  }
  
  public IPersistentMap __getClojureFnMappings()
  {
    return this.__clojureFnMap;
  }
  
  /* Error */
  public boolean equals(Object arg1)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 18	clojure/inspector/proxy$java/lang/Object$TreeModel$775afa87:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 32
    //   6: invokestatic 38	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +22 -> 32
    //   13: checkcast 40	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: invokeinterface 43 3 0
    //   23: checkcast 45	java/lang/Boolean
    //   26: invokevirtual 49	java/lang/Boolean:booleanValue	()Z
    //   29: goto +9 -> 38
    //   32: pop
    //   33: aload_0
    //   34: aload_1
    //   35: invokespecial 51	java/lang/Object:equals	(Ljava/lang/Object;)Z
    //   38: ireturn
  }
  
  /* Error */
  public String toString()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 18	clojure/inspector/proxy$java/lang/Object$TreeModel$775afa87:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 54
    //   6: invokestatic 38	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +18 -> 28
    //   13: checkcast 40	clojure/lang/IFn
    //   16: aload_0
    //   17: invokeinterface 57 2 0
    //   22: checkcast 59	java/lang/String
    //   25: goto +8 -> 33
    //   28: pop
    //   29: aload_0
    //   30: invokespecial 61	java/lang/Object:toString	()Ljava/lang/String;
    //   33: areturn
  }
  
  /* Error */
  public int hashCode()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 18	clojure/inspector/proxy$java/lang/Object$TreeModel$775afa87:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 64
    //   6: invokestatic 38	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +21 -> 31
    //   13: checkcast 40	clojure/lang/IFn
    //   16: aload_0
    //   17: invokeinterface 57 2 0
    //   22: checkcast 66	java/lang/Number
    //   25: invokevirtual 69	java/lang/Number:intValue	()I
    //   28: goto +8 -> 36
    //   31: pop
    //   32: aload_0
    //   33: invokespecial 71	java/lang/Object:hashCode	()I
    //   36: ireturn
  }
  
  /* Error */
  public Object clone()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 18	clojure/inspector/proxy$java/lang/Object$TreeModel$775afa87:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 74
    //   6: invokestatic 38	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +15 -> 25
    //   13: checkcast 40	clojure/lang/IFn
    //   16: aload_0
    //   17: invokeinterface 57 2 0
    //   22: goto +8 -> 30
    //   25: pop
    //   26: aload_0
    //   27: invokespecial 76	java/lang/Object:clone	()Ljava/lang/Object;
    //   30: areturn
  }
  
  /* Error */
  public Object getChild(Object arg1, int arg2)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 18	clojure/inspector/proxy$java/lang/Object$TreeModel$775afa87:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 79
    //   6: invokestatic 38	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +20 -> 30
    //   13: checkcast 40	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: iload_2
    //   19: invokestatic 85	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   22: invokeinterface 88 4 0
    //   27: goto +14 -> 41
    //   30: pop
    //   31: new 90	java/lang/UnsupportedOperationException
    //   34: dup
    //   35: ldc 79
    //   37: invokespecial 93	java/lang/UnsupportedOperationException:<init>	(Ljava/lang/String;)V
    //   40: athrow
    //   41: areturn
  }
  
  /* Error */
  public void addTreeModelListener(javax.swing.event.TreeModelListener arg1)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 18	clojure/inspector/proxy$java/lang/Object$TreeModel$775afa87:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 96
    //   6: invokestatic 38	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +17 -> 27
    //   13: checkcast 40	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: invokeinterface 43 3 0
    //   23: pop
    //   24: goto +14 -> 38
    //   27: pop
    //   28: new 90	java/lang/UnsupportedOperationException
    //   31: dup
    //   32: ldc 96
    //   34: invokespecial 93	java/lang/UnsupportedOperationException:<init>	(Ljava/lang/String;)V
    //   37: athrow
    //   38: return
  }
  
  /* Error */
  public int getChildCount(Object arg1)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 18	clojure/inspector/proxy$java/lang/Object$TreeModel$775afa87:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 99
    //   6: invokestatic 38	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +22 -> 32
    //   13: checkcast 40	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: invokeinterface 43 3 0
    //   23: checkcast 66	java/lang/Number
    //   26: invokevirtual 69	java/lang/Number:intValue	()I
    //   29: goto +14 -> 43
    //   32: pop
    //   33: new 90	java/lang/UnsupportedOperationException
    //   36: dup
    //   37: ldc 99
    //   39: invokespecial 93	java/lang/UnsupportedOperationException:<init>	(Ljava/lang/String;)V
    //   42: athrow
    //   43: ireturn
  }
  
  /* Error */
  public int getIndexOfChild(Object arg1, Object arg2)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 18	clojure/inspector/proxy$java/lang/Object$TreeModel$775afa87:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 102
    //   6: invokestatic 38	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +23 -> 33
    //   13: checkcast 40	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: aload_2
    //   19: invokeinterface 88 4 0
    //   24: checkcast 66	java/lang/Number
    //   27: invokevirtual 69	java/lang/Number:intValue	()I
    //   30: goto +14 -> 44
    //   33: pop
    //   34: new 90	java/lang/UnsupportedOperationException
    //   37: dup
    //   38: ldc 102
    //   40: invokespecial 93	java/lang/UnsupportedOperationException:<init>	(Ljava/lang/String;)V
    //   43: athrow
    //   44: ireturn
  }
  
  /* Error */
  public Object getRoot()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 18	clojure/inspector/proxy$java/lang/Object$TreeModel$775afa87:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 104
    //   6: invokestatic 38	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +15 -> 25
    //   13: checkcast 40	clojure/lang/IFn
    //   16: aload_0
    //   17: invokeinterface 57 2 0
    //   22: goto +14 -> 36
    //   25: pop
    //   26: new 90	java/lang/UnsupportedOperationException
    //   29: dup
    //   30: ldc 104
    //   32: invokespecial 93	java/lang/UnsupportedOperationException:<init>	(Ljava/lang/String;)V
    //   35: athrow
    //   36: areturn
  }
  
  /* Error */
  public boolean isLeaf(Object arg1)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 18	clojure/inspector/proxy$java/lang/Object$TreeModel$775afa87:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 106
    //   6: invokestatic 38	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +22 -> 32
    //   13: checkcast 40	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: invokeinterface 43 3 0
    //   23: checkcast 45	java/lang/Boolean
    //   26: invokevirtual 49	java/lang/Boolean:booleanValue	()Z
    //   29: goto +14 -> 43
    //   32: pop
    //   33: new 90	java/lang/UnsupportedOperationException
    //   36: dup
    //   37: ldc 106
    //   39: invokespecial 93	java/lang/UnsupportedOperationException:<init>	(Ljava/lang/String;)V
    //   42: athrow
    //   43: ireturn
  }
  
  /* Error */
  public void removeTreeModelListener(javax.swing.event.TreeModelListener arg1)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 18	clojure/inspector/proxy$java/lang/Object$TreeModel$775afa87:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 108
    //   6: invokestatic 38	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +17 -> 27
    //   13: checkcast 40	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: invokeinterface 43 3 0
    //   23: pop
    //   24: goto +14 -> 38
    //   27: pop
    //   28: new 90	java/lang/UnsupportedOperationException
    //   31: dup
    //   32: ldc 108
    //   34: invokespecial 93	java/lang/UnsupportedOperationException:<init>	(Ljava/lang/String;)V
    //   37: athrow
    //   38: return
  }
  
  /* Error */
  public void valueForPathChanged(javax.swing.tree.TreePath arg1, Object arg2)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 18	clojure/inspector/proxy$java/lang/Object$TreeModel$775afa87:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 111
    //   6: invokestatic 38	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +18 -> 28
    //   13: checkcast 40	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: aload_2
    //   19: invokeinterface 88 4 0
    //   24: pop
    //   25: goto +14 -> 39
    //   28: pop
    //   29: new 90	java/lang/UnsupportedOperationException
    //   32: dup
    //   33: ldc 111
    //   35: invokespecial 93	java/lang/UnsupportedOperationException:<init>	(Ljava/lang/String;)V
    //   38: athrow
    //   39: return
  }
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\inspector\proxy$java\lang\Object$TreeModel$775afa87.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */