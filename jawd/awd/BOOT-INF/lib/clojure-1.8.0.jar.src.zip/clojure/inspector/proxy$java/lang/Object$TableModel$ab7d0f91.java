package clojure.inspector.proxy$java.lang;

import clojure.lang.IPersistentCollection;
import clojure.lang.IPersistentMap;
import clojure.lang.IProxy;
import javax.swing.table.TableModel;

public class Object$TableModel$ab7d0f91
  implements IProxy, TableModel
{
  private volatile IPersistentMap __clojureFnMap;
  
  public void __initClojureFnMappings(IPersistentMap paramIPersistentMap)
  {
    this.__clojureFnMap = paramIPersistentMap;
  }
  
  public void __updateClojureFnMappings(IPersistentMap paramIPersistentMap)
  {
    this.__clojureFnMap = ((IPersistentMap)((IPersistentCollection)this.__clojureFnMap).cons(paramIPersistentMap));
  }
  
  public IPersistentMap __getClojureFnMappings()
  {
    return this.__clojureFnMap;
  }
  
  /* Error */
  public boolean equals(Object arg1)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 18	clojure/inspector/proxy$java/lang/Object$TableModel$ab7d0f91:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 32
    //   6: invokestatic 38	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +22 -> 32
    //   13: checkcast 40	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: invokeinterface 43 3 0
    //   23: checkcast 45	java/lang/Boolean
    //   26: invokevirtual 49	java/lang/Boolean:booleanValue	()Z
    //   29: goto +9 -> 38
    //   32: pop
    //   33: aload_0
    //   34: aload_1
    //   35: invokespecial 51	java/lang/Object:equals	(Ljava/lang/Object;)Z
    //   38: ireturn
  }
  
  /* Error */
  public String toString()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 18	clojure/inspector/proxy$java/lang/Object$TableModel$ab7d0f91:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 54
    //   6: invokestatic 38	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +18 -> 28
    //   13: checkcast 40	clojure/lang/IFn
    //   16: aload_0
    //   17: invokeinterface 57 2 0
    //   22: checkcast 59	java/lang/String
    //   25: goto +8 -> 33
    //   28: pop
    //   29: aload_0
    //   30: invokespecial 61	java/lang/Object:toString	()Ljava/lang/String;
    //   33: areturn
  }
  
  /* Error */
  public int hashCode()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 18	clojure/inspector/proxy$java/lang/Object$TableModel$ab7d0f91:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 64
    //   6: invokestatic 38	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +21 -> 31
    //   13: checkcast 40	clojure/lang/IFn
    //   16: aload_0
    //   17: invokeinterface 57 2 0
    //   22: checkcast 66	java/lang/Number
    //   25: invokevirtual 69	java/lang/Number:intValue	()I
    //   28: goto +8 -> 36
    //   31: pop
    //   32: aload_0
    //   33: invokespecial 71	java/lang/Object:hashCode	()I
    //   36: ireturn
  }
  
  /* Error */
  public Object clone()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 18	clojure/inspector/proxy$java/lang/Object$TableModel$ab7d0f91:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 74
    //   6: invokestatic 38	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +15 -> 25
    //   13: checkcast 40	clojure/lang/IFn
    //   16: aload_0
    //   17: invokeinterface 57 2 0
    //   22: goto +8 -> 30
    //   25: pop
    //   26: aload_0
    //   27: invokespecial 76	java/lang/Object:clone	()Ljava/lang/Object;
    //   30: areturn
  }
  
  /* Error */
  public void addTableModelListener(javax.swing.event.TableModelListener arg1)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 18	clojure/inspector/proxy$java/lang/Object$TableModel$ab7d0f91:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 79
    //   6: invokestatic 38	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +17 -> 27
    //   13: checkcast 40	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: invokeinterface 43 3 0
    //   23: pop
    //   24: goto +14 -> 38
    //   27: pop
    //   28: new 81	java/lang/UnsupportedOperationException
    //   31: dup
    //   32: ldc 79
    //   34: invokespecial 84	java/lang/UnsupportedOperationException:<init>	(Ljava/lang/String;)V
    //   37: athrow
    //   38: return
  }
  
  /* Error */
  public Object getValueAt(int arg1, int arg2)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 18	clojure/inspector/proxy$java/lang/Object$TableModel$ab7d0f91:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 87
    //   6: invokestatic 38	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +23 -> 33
    //   13: checkcast 40	clojure/lang/IFn
    //   16: aload_0
    //   17: iload_1
    //   18: invokestatic 93	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   21: iload_2
    //   22: invokestatic 93	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   25: invokeinterface 96 4 0
    //   30: goto +14 -> 44
    //   33: pop
    //   34: new 81	java/lang/UnsupportedOperationException
    //   37: dup
    //   38: ldc 87
    //   40: invokespecial 84	java/lang/UnsupportedOperationException:<init>	(Ljava/lang/String;)V
    //   43: athrow
    //   44: areturn
  }
  
  /* Error */
  public String getColumnName(int arg1)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 18	clojure/inspector/proxy$java/lang/Object$TableModel$ab7d0f91:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 99
    //   6: invokestatic 38	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +22 -> 32
    //   13: checkcast 40	clojure/lang/IFn
    //   16: aload_0
    //   17: iload_1
    //   18: invokestatic 93	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   21: invokeinterface 43 3 0
    //   26: checkcast 59	java/lang/String
    //   29: goto +14 -> 43
    //   32: pop
    //   33: new 81	java/lang/UnsupportedOperationException
    //   36: dup
    //   37: ldc 99
    //   39: invokespecial 84	java/lang/UnsupportedOperationException:<init>	(Ljava/lang/String;)V
    //   42: athrow
    //   43: areturn
  }
  
  /* Error */
  public boolean isCellEditable(int arg1, int arg2)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 18	clojure/inspector/proxy$java/lang/Object$TableModel$ab7d0f91:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 102
    //   6: invokestatic 38	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +29 -> 39
    //   13: checkcast 40	clojure/lang/IFn
    //   16: aload_0
    //   17: iload_1
    //   18: invokestatic 93	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   21: iload_2
    //   22: invokestatic 93	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   25: invokeinterface 96 4 0
    //   30: checkcast 45	java/lang/Boolean
    //   33: invokevirtual 49	java/lang/Boolean:booleanValue	()Z
    //   36: goto +14 -> 50
    //   39: pop
    //   40: new 81	java/lang/UnsupportedOperationException
    //   43: dup
    //   44: ldc 102
    //   46: invokespecial 84	java/lang/UnsupportedOperationException:<init>	(Ljava/lang/String;)V
    //   49: athrow
    //   50: ireturn
  }
  
  /* Error */
  public Class getColumnClass(int arg1)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 18	clojure/inspector/proxy$java/lang/Object$TableModel$ab7d0f91:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 105
    //   6: invokestatic 38	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +22 -> 32
    //   13: checkcast 40	clojure/lang/IFn
    //   16: aload_0
    //   17: iload_1
    //   18: invokestatic 93	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   21: invokeinterface 43 3 0
    //   26: checkcast 107	java/lang/Class
    //   29: goto +14 -> 43
    //   32: pop
    //   33: new 81	java/lang/UnsupportedOperationException
    //   36: dup
    //   37: ldc 105
    //   39: invokespecial 84	java/lang/UnsupportedOperationException:<init>	(Ljava/lang/String;)V
    //   42: athrow
    //   43: areturn
  }
  
  /* Error */
  public int getRowCount()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 18	clojure/inspector/proxy$java/lang/Object$TableModel$ab7d0f91:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 109
    //   6: invokestatic 38	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +21 -> 31
    //   13: checkcast 40	clojure/lang/IFn
    //   16: aload_0
    //   17: invokeinterface 57 2 0
    //   22: checkcast 66	java/lang/Number
    //   25: invokevirtual 69	java/lang/Number:intValue	()I
    //   28: goto +14 -> 42
    //   31: pop
    //   32: new 81	java/lang/UnsupportedOperationException
    //   35: dup
    //   36: ldc 109
    //   38: invokespecial 84	java/lang/UnsupportedOperationException:<init>	(Ljava/lang/String;)V
    //   41: athrow
    //   42: ireturn
  }
  
  /* Error */
  public void setValueAt(Object arg1, int arg2, int arg3)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 18	clojure/inspector/proxy$java/lang/Object$TableModel$ab7d0f91:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 112
    //   6: invokestatic 38	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +25 -> 35
    //   13: checkcast 40	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: iload_2
    //   19: invokestatic 93	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   22: iload_3
    //   23: invokestatic 93	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   26: invokeinterface 115 5 0
    //   31: pop
    //   32: goto +14 -> 46
    //   35: pop
    //   36: new 81	java/lang/UnsupportedOperationException
    //   39: dup
    //   40: ldc 112
    //   42: invokespecial 84	java/lang/UnsupportedOperationException:<init>	(Ljava/lang/String;)V
    //   45: athrow
    //   46: return
  }
  
  /* Error */
  public int getColumnCount()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 18	clojure/inspector/proxy$java/lang/Object$TableModel$ab7d0f91:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 117
    //   6: invokestatic 38	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +21 -> 31
    //   13: checkcast 40	clojure/lang/IFn
    //   16: aload_0
    //   17: invokeinterface 57 2 0
    //   22: checkcast 66	java/lang/Number
    //   25: invokevirtual 69	java/lang/Number:intValue	()I
    //   28: goto +14 -> 42
    //   31: pop
    //   32: new 81	java/lang/UnsupportedOperationException
    //   35: dup
    //   36: ldc 117
    //   38: invokespecial 84	java/lang/UnsupportedOperationException:<init>	(Ljava/lang/String;)V
    //   41: athrow
    //   42: ireturn
  }
  
  /* Error */
  public void removeTableModelListener(javax.swing.event.TableModelListener arg1)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 18	clojure/inspector/proxy$java/lang/Object$TableModel$ab7d0f91:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 119
    //   6: invokestatic 38	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +17 -> 27
    //   13: checkcast 40	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: invokeinterface 43 3 0
    //   23: pop
    //   24: goto +14 -> 38
    //   27: pop
    //   28: new 81	java/lang/UnsupportedOperationException
    //   31: dup
    //   32: ldc 119
    //   34: invokespecial 84	java/lang/UnsupportedOperationException:<init>	(Ljava/lang/String;)V
    //   37: athrow
    //   38: return
  }
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\inspector\proxy$java\lang\Object$TableModel$ab7d0f91.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */