/*    */ package clojure.java;
/*    */ 
/*    */ import clojure.java.io.IOFactory;
/*    */ import clojure.lang.AFunction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class io$fn__9433$G__9427__9436
/*    */   extends AFunction
/*    */ {
/*    */   public Object invoke(Object gf__x__9434, Object gf__opts__9435)
/*    */   {
/* 69 */     gf__x__9434 = null;gf__opts__9435 = null;return ((IOFactory)gf__x__9434).make_input_stream(gf__opts__9435);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\java\io$fn__9433$G__9427__9436.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */