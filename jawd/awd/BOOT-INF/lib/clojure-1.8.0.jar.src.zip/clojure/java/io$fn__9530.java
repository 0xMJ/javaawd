/*     */ package clojure.java;
/*     */ 
/*     */ import clojure.lang.AFunction;
/*     */ import clojure.lang.RT;
/*     */ import clojure.lang.Var;
/*     */ 
/*     */ public final class io$fn__9530
/*     */   extends AFunction
/*     */ {
/*     */   private static Class __cached_class__0;
/*     */   
/*     */   /* Error */
/*     */   public static Object invokeStatic(Object x, Object opts)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: aconst_null
/*     */     //   2: astore_0
/*     */     //   3: checkcast 15	java/net/URI
/*     */     //   6: invokevirtual 19	java/net/URI:toURL	()Ljava/net/URL;
/*     */     //   9: dup
/*     */     //   10: invokestatic 25	clojure/lang/Util:classOf	(Ljava/lang/Object;)Ljava/lang/Class;
/*     */     //   13: getstatic 27	clojure/java/io$fn__9530:__cached_class__0	Ljava/lang/Class;
/*     */     //   16: if_acmpeq +17 -> 33
/*     */     //   19: dup
/*     */     //   20: instanceof 29
/*     */     //   23: ifne +28 -> 51
/*     */     //   26: dup
/*     */     //   27: invokestatic 25	clojure/lang/Util:classOf	(Ljava/lang/Object;)Ljava/lang/Class;
/*     */     //   30: putstatic 27	clojure/java/io$fn__9530:__cached_class__0	Ljava/lang/Class;
/*     */     //   33: getstatic 33	clojure/java/io$fn__9530:const__0	Lclojure/lang/Var;
/*     */     //   36: invokevirtual 39	clojure/lang/Var:getRawRoot	()Ljava/lang/Object;
/*     */     //   39: swap
/*     */     //   40: aload_1
/*     */     //   41: aconst_null
/*     */     //   42: astore_1
/*     */     //   43: invokeinterface 44 3 0
/*     */     //   48: goto +11 -> 59
/*     */     //   51: aload_1
/*     */     //   52: aconst_null
/*     */     //   53: astore_1
/*     */     //   54: invokeinterface 48 2 0
/*     */     //   59: areturn
/*     */     // Line number table:
/*     */     //   Java source line #249	-> byte code offset #0
/*     */     //   Java source line #249	-> byte code offset #0
/*     */     //   Java source line #249	-> byte code offset #6
/*     */     //   Java source line #249	-> byte code offset #43
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	59	0	x	Object
/*     */     //   0	59	1	opts	Object
/*     */   }
/*     */   
/*     */   public Object invoke(Object paramObject1, Object paramObject2)
/*     */   {
/* 249 */     paramObject1 = null;paramObject2 = null;return invokeStatic(paramObject1, paramObject2); } public static final Var const__0 = (Var)RT.var("clojure.java.io", "make-output-stream");
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\java\io$fn__9530.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */