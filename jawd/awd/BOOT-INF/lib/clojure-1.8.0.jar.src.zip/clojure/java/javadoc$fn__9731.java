/*    */ package clojure.java;
/*    */ 
/*    */ import clojure.lang.AFunction;
/*    */ import clojure.lang.Util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class javadoc$fn__9731
/*    */   extends AFunction
/*    */ {
/* 22 */   public Object invoke() { return invokeStatic(); } public static Object invokeStatic() { Object G__9730 = System.getProperty((String)"java.specification.version"); switch (Util.hash(G__9730)) {} return Util.equiv(G__9730, const__0) ? "http://java.sun.com/javase/6/docs/api/" : "http://java.sun.com/javase/7/docs/api/"; } public static final String const__0 = (String)"1.6";
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\java\javadoc$fn__9731.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */