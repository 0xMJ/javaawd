/*     */ package clojure.java;
/*     */ 
/*     */ import clojure.lang.AFn;
/*     */ import clojure.lang.AFunction;
/*     */ import clojure.lang.IObj;
/*     */ import clojure.lang.IPersistentMap;
/*     */ import clojure.lang.Keyword;
/*     */ import clojure.lang.PersistentList;
/*     */ import clojure.lang.RT;
/*     */ import clojure.lang.Symbol;
/*     */ import clojure.lang.Tuple;
/*     */ import clojure.lang.Var;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ public final class io$fn__9548
/*     */   extends AFunction
/*     */ {
/*     */   /* Error */
/*     */   public static Object invokeStatic()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: getstatic 15	clojure/java/io$fn__9548:const__0	Lclojure/lang/Var;
/*     */     //   3: dup
/*     */     //   4: getstatic 19	clojure/java/io$fn__9548:const__10	Lclojure/lang/AFn;
/*     */     //   7: checkcast 21	clojure/lang/IPersistentMap
/*     */     //   10: invokevirtual 27	clojure/lang/Var:setMeta	(Lclojure/lang/IPersistentMap;)V
/*     */     //   13: astore_0
/*     */     //   14: aload_0
/*     */     //   15: checkcast 23	clojure/lang/Var
/*     */     //   18: invokevirtual 31	clojure/lang/Var:hasRoot	()Z
/*     */     //   21: istore_1
/*     */     //   22: iload_1
/*     */     //   23: ifeq +16 -> 39
/*     */     //   26: aload_0
/*     */     //   27: aconst_null
/*     */     //   28: astore_0
/*     */     //   29: invokestatic 36	clojure/core$deref:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   32: instanceof 38
/*     */     //   35: goto +5 -> 40
/*     */     //   38: pop
/*     */     //   39: iload_1
/*     */     //   40: ifeq +8 -> 48
/*     */     //   43: aconst_null
/*     */     //   44: goto +52 -> 96
/*     */     //   47: pop
/*     */     //   48: getstatic 15	clojure/java/io$fn__9548:const__0	Lclojure/lang/Var;
/*     */     //   51: dup
/*     */     //   52: getstatic 43	clojure/java/io$fn__9548:const__15	Lclojure/lang/AFn;
/*     */     //   55: checkcast 21	clojure/lang/IPersistentMap
/*     */     //   58: invokevirtual 27	clojure/lang/Var:setMeta	(Lclojure/lang/IPersistentMap;)V
/*     */     //   61: dup
/*     */     //   62: new 38	clojure/lang/MultiFn
/*     */     //   65: dup
/*     */     //   66: ldc 45
/*     */     //   68: checkcast 47	java/lang/String
/*     */     //   71: new 49	clojure/java/io$fn__9548$fn__9549
/*     */     //   74: dup
/*     */     //   75: invokespecial 50	clojure/java/io$fn__9548$fn__9549:<init>	()V
/*     */     //   78: checkcast 52	clojure/lang/IFn
/*     */     //   81: getstatic 56	clojure/java/io$fn__9548:const__16	Lclojure/lang/Keyword;
/*     */     //   84: getstatic 59	clojure/java/io$fn__9548:const__17	Lclojure/lang/Var;
/*     */     //   87: checkcast 61	clojure/lang/IRef
/*     */     //   90: invokespecial 64	clojure/lang/MultiFn:<init>	(Ljava/lang/String;Lclojure/lang/IFn;Ljava/lang/Object;Lclojure/lang/IRef;)V
/*     */     //   93: invokevirtual 68	clojure/lang/Var:bindRoot	(Ljava/lang/Object;)V
/*     */     //   96: areturn
/*     */     // Line number table:
/*     */     //   Java source line #295	-> byte code offset #0
/*     */     //   Java source line #295	-> byte code offset #14
/*     */     //   Java source line #295	-> byte code offset #18
/*     */     //   Java source line #295	-> byte code offset #22
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   14	82	0	v__4645__auto__9553	Object
/*     */     //   22	18	1	and__4467__auto__9552	boolean
/*     */   }
/*     */   
/* 295 */   public Object invoke() { return invokeStatic(); } public static final Var const__17 = (Var)RT.var("clojure.core", "global-hierarchy"); public static final Keyword const__16 = (Keyword)RT.keyword(null, "default"); public static final AFn const__15 = (AFn)RT.map(new Object[] { RT.keyword(null, "doc"), "Internal helper for copy", RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), ((IObj)PersistentList.create(Arrays.asList(new Object[] { Tuple.create(Symbol.intern(null, "input"), Symbol.intern(null, "output"), Symbol.intern(null, "opts")) }))).withMeta((IPersistentMap)RT.map(new Object[] { RT.keyword(null, "line"), Integer.valueOf(298), RT.keyword(null, "column"), Integer.valueOf(17) })), RT.keyword(null, "line"), Integer.valueOf(295), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/java/io.clj" }); public static final AFn const__10 = (AFn)RT.map(new Object[] { RT.keyword(null, "doc"), "Internal helper for copy", RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), ((IObj)PersistentList.create(Arrays.asList(new Object[] { Tuple.create(Symbol.intern(null, "input"), Symbol.intern(null, "output"), Symbol.intern(null, "opts")) }))).withMeta((IPersistentMap)RT.map(new Object[] { RT.keyword(null, "line"), Integer.valueOf(298), RT.keyword(null, "column"), Integer.valueOf(17) })), RT.keyword(null, "line"), Integer.valueOf(295), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/java/io.clj" }); public static final Var const__0 = (Var)RT.var("clojure.java.io", "do-copy");
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\java\io$fn__9548.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */