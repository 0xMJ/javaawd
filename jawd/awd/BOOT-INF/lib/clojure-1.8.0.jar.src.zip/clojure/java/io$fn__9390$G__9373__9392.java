/*    */ package clojure.java;
/*    */ 
/*    */ import clojure.java.io.Coercions;
/*    */ import clojure.lang.AFunction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class io$fn__9390$G__9373__9392
/*    */   extends AFunction
/*    */ {
/*    */   public Object invoke(Object gf__x__9391)
/*    */   {
/* 35 */     gf__x__9391 = null;return ((Coercions)gf__x__9391).as_file();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\java\io$fn__9390$G__9373__9392.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */