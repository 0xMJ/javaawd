/*    */ package clojure.java;
/*    */ 
/*    */ import clojure.java.io.Coercions;
/*    */ import clojure.lang.AFunction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class io$fn__9379$G__9375__9381
/*    */   extends AFunction
/*    */ {
/*    */   public Object invoke(Object gf__x__9380)
/*    */   {
/* 35 */     gf__x__9380 = null;return ((Coercions)gf__x__9380).as_url();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\java\io$fn__9379$G__9375__9381.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */