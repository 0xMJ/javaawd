/*    */ package clojure.java;
/*    */ 
/*    */ import clojure.lang.AFunction;
/*    */ import clojure.lang.RT;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class io$fn__9472$G__9424__9479
/*    */   extends AFunction
/*    */ {
/*    */   Object G__9425;
/*    */   
/* 69 */   public io$fn__9472$G__9424__9479(Object paramObject) { this.G__9425 = paramObject; } public static final Object const__1 = RT.classForName("clojure.java.io.IOFactory");
/*    */   
/*    */   /* Error */
/*    */   public Object invoke(Object gf__x__9477, Object gf__opts__9478)
/*    */   {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: checkcast 4	clojure/lang/AFunction
/*    */     //   4: getfield 20	clojure/lang/AFunction:__methodImplCache	Lclojure/lang/MethodImplCache;
/*    */     //   7: astore_3
/*    */     //   8: aload_3
/*    */     //   9: aconst_null
/*    */     //   10: astore_3
/*    */     //   11: checkcast 22	clojure/lang/MethodImplCache
/*    */     //   14: aload_1
/*    */     //   15: invokestatic 28	clojure/lang/Util:classOf	(Ljava/lang/Object;)Ljava/lang/Class;
/*    */     //   18: checkcast 30	java/lang/Class
/*    */     //   21: invokevirtual 34	clojure/lang/MethodImplCache:fnFor	(Ljava/lang/Class;)Lclojure/lang/IFn;
/*    */     //   24: astore 4
/*    */     //   26: aload 4
/*    */     //   28: dup
/*    */     //   29: ifnull +31 -> 60
/*    */     //   32: getstatic 40	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*    */     //   35: if_acmpeq +26 -> 61
/*    */     //   38: aload 4
/*    */     //   40: aconst_null
/*    */     //   41: astore 4
/*    */     //   43: checkcast 42	clojure/lang/IFn
/*    */     //   46: aload_1
/*    */     //   47: aconst_null
/*    */     //   48: astore_1
/*    */     //   49: aload_2
/*    */     //   50: aconst_null
/*    */     //   51: astore_2
/*    */     //   52: invokeinterface 44 3 0
/*    */     //   57: goto +30 -> 87
/*    */     //   60: pop
/*    */     //   61: aload_0
/*    */     //   62: aload_1
/*    */     //   63: getstatic 47	clojure/java/io$fn__9472$G__9424__9479:const__1	Ljava/lang/Object;
/*    */     //   66: aload_0
/*    */     //   67: getfield 14	clojure/java/io$fn__9472$G__9424__9479:G__9425	Ljava/lang/Object;
/*    */     //   70: invokestatic 53	clojure/core$_cache_protocol_fn:invokeStatic	(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   73: checkcast 42	clojure/lang/IFn
/*    */     //   76: aload_1
/*    */     //   77: aconst_null
/*    */     //   78: astore_1
/*    */     //   79: aload_2
/*    */     //   80: aconst_null
/*    */     //   81: astore_2
/*    */     //   82: invokeinterface 44 3 0
/*    */     //   87: areturn
/*    */     // Line number table:
/*    */     //   Java source line #69	-> byte code offset #0
/*    */     //   Java source line #69	-> byte code offset #1
/*    */     //   Java source line #69	-> byte code offset #15
/*    */     //   Java source line #69	-> byte code offset #21
/*    */     //   Java source line #69	-> byte code offset #26
/*    */     //   Java source line #69	-> byte code offset #43
/*    */     //   Java source line #69	-> byte code offset #52
/*    */     //   Java source line #69	-> byte code offset #73
/*    */     //   Java source line #69	-> byte code offset #82
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	signature
/*    */     //   0	87	0	this	Object
/*    */     //   0	87	1	gf__x__9477	Object
/*    */     //   0	87	2	gf__opts__9478	Object
/*    */     //   8	79	3	cache__6568__auto__9481	Object
/*    */     //   26	61	4	f__6569__auto__9482	Object
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\java\io$fn__9472$G__9424__9479.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */