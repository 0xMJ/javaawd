/*   */ package clojure.java;
/*   */ 
/*   */ import clojure.lang.RT;
/*   */ 
/*   */ 
/*   */ public final class browse$fn__9714
/*   */   extends clojure.lang.AFunction
/*   */ {
/* 9 */   public Object invoke() { return invokeStatic(); } public static Object invokeStatic() { return clojure.core.commute.invokeStatic(clojure.core.deref.invokeStatic(const__2), const__3.getRawRoot(), clojure.lang.ArraySeq.create(new Object[] { const__4 })); } public static final clojure.lang.AFn const__4 = (clojure.lang.AFn)((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "clojure.java.browse")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "author"), "Christophe Grand", RT.keyword(null, "doc"), "Start a web browser from Clojure" })); public static final clojure.lang.Var const__3 = (clojure.lang.Var)RT.var("clojure.core", "conj"); public static final clojure.lang.Var const__2 = (clojure.lang.Var)RT.var("clojure.core", "*loaded-libs*");
/*   */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\java\browse$fn__9714.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */