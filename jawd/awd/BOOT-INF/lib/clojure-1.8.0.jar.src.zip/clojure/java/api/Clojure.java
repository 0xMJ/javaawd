/*    */ package clojure.java.api;
/*    */ 
/*    */ import clojure.lang.IFn;
/*    */ import clojure.lang.Symbol;
/*    */ import clojure.lang.Var;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Clojure
/*    */ {
/*    */   private static Symbol asSym(Object o)
/*    */   {
/*    */     Symbol s;
/*    */     Symbol s;
/* 55 */     if ((o instanceof String)) {
/* 56 */       s = Symbol.intern((String)o);
/*    */     } else {
/* 58 */       s = (Symbol)o;
/*    */     }
/* 60 */     return s;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static IFn var(Object qualifiedName)
/*    */   {
/* 70 */     Symbol s = asSym(qualifiedName);
/* 71 */     return var(s.getNamespace(), s.getName());
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static IFn var(Object ns, Object name)
/*    */   {
/* 82 */     return Var.intern(asSym(ns), asSym(name));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static Object read(String s)
/*    */   {
/* 92 */     return EDN_READ_STRING.invoke(s);
/*    */   }
/*    */   
/*    */   static {
/* 96 */     Symbol edn = (Symbol)var("clojure.core", "symbol").invoke("clojure.edn");
/* 97 */     var("clojure.core", "require").invoke(edn); }
/*    */   
/* 99 */   private static final IFn EDN_READ_STRING = var("clojure.edn", "read-string");
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\java\api\Clojure.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */