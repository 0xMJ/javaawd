/*     */ package clojure.java;
/*     */ 
/*     */ import clojure.lang.AFunction;
/*     */ import clojure.lang.ILookupThunk;
/*     */ import clojure.lang.KeywordLookupSite;
/*     */ import clojure.lang.RT;
/*     */ 
/*     */ public final class io$encoding
/*     */   extends AFunction
/*     */ {
/*     */   static final KeywordLookupSite __site__0__;
/*     */   
/*     */   /* Error */
/*     */   public static Object invokeStatic(Object opts)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: getstatic 15	clojure/java/io$encoding:__thunk__0__	Lclojure/lang/ILookupThunk;
/*     */     //   3: dup
/*     */     //   4: aload_0
/*     */     //   5: aconst_null
/*     */     //   6: astore_0
/*     */     //   7: dup_x2
/*     */     //   8: invokeinterface 20 2 0
/*     */     //   13: dup_x2
/*     */     //   14: if_acmpeq +7 -> 21
/*     */     //   17: pop
/*     */     //   18: goto +25 -> 43
/*     */     //   21: swap
/*     */     //   22: pop
/*     */     //   23: dup
/*     */     //   24: getstatic 24	clojure/java/io$encoding:__site__0__	Lclojure/lang/KeywordLookupSite;
/*     */     //   27: swap
/*     */     //   28: invokeinterface 30 2 0
/*     */     //   33: dup
/*     */     //   34: putstatic 15	clojure/java/io$encoding:__thunk__0__	Lclojure/lang/ILookupThunk;
/*     */     //   37: swap
/*     */     //   38: invokeinterface 20 2 0
/*     */     //   43: astore_1
/*     */     //   44: aload_1
/*     */     //   45: dup
/*     */     //   46: ifnull +15 -> 61
/*     */     //   49: getstatic 36	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   52: if_acmpeq +10 -> 62
/*     */     //   55: aload_1
/*     */     //   56: aconst_null
/*     */     //   57: astore_1
/*     */     //   58: goto +6 -> 64
/*     */     //   61: pop
/*     */     //   62: ldc 38
/*     */     //   64: areturn
/*     */     // Line number table:
/*     */     //   Java source line #158	-> byte code offset #0
/*     */     //   Java source line #159	-> byte code offset #0
/*     */     //   Java source line #159	-> byte code offset #7
/*     */     //   Java source line #159	-> byte code offset #44
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	64	0	opts	Object
/*     */     //   44	20	1	or__4469__auto__9491	Object
/*     */   }
/*     */   
/*     */   public Object invoke(Object paramObject)
/*     */   {
/* 158 */     paramObject = null;return invokeStatic(paramObject); } static ILookupThunk __thunk__0__ = __site__0__ = new KeywordLookupSite(RT.keyword(null, "encoding"));
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\java\io$encoding.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */