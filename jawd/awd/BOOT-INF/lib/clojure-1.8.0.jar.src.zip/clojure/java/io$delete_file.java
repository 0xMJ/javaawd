/*     */ package clojure.java;
/*     */ 
/*     */ import clojure.lang.ISeq;
/*     */ import clojure.lang.RestFn;
/*     */ 
/*     */ public final class io$delete_file
/*     */   extends RestFn
/*     */ {
/*     */   /* Error */
/*     */   public static Object invokeStatic(Object f, ISeq p__9593)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_1
/*     */     //   1: aconst_null
/*     */     //   2: astore_1
/*     */     //   3: astore_2
/*     */     //   4: aload_2
/*     */     //   5: aconst_null
/*     */     //   6: astore_2
/*     */     //   7: lconst_0
/*     */     //   8: invokestatic 17	clojure/lang/RT:intCast	(J)I
/*     */     //   11: aconst_null
/*     */     //   12: invokestatic 21	clojure/lang/RT:nth	(Ljava/lang/Object;ILjava/lang/Object;)Ljava/lang/Object;
/*     */     //   15: astore_3
/*     */     //   16: aload_0
/*     */     //   17: invokestatic 26	clojure/java/io$file:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   20: checkcast 28	java/io/File
/*     */     //   23: invokevirtual 32	java/io/File:delete	()Z
/*     */     //   26: istore 4
/*     */     //   28: iload 4
/*     */     //   30: ifeq +21 -> 51
/*     */     //   33: iload 4
/*     */     //   35: ifeq +9 -> 44
/*     */     //   38: getstatic 38	java/lang/Boolean:TRUE	Ljava/lang/Boolean;
/*     */     //   41: goto +6 -> 47
/*     */     //   44: getstatic 41	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   47: goto +62 -> 109
/*     */     //   50: pop
/*     */     //   51: aload_3
/*     */     //   52: aconst_null
/*     */     //   53: astore_3
/*     */     //   54: astore 5
/*     */     //   56: aload 5
/*     */     //   58: dup
/*     */     //   59: ifnull +17 -> 76
/*     */     //   62: getstatic 41	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   65: if_acmpeq +12 -> 77
/*     */     //   68: aload 5
/*     */     //   70: aconst_null
/*     */     //   71: astore 5
/*     */     //   73: goto +36 -> 109
/*     */     //   76: pop
/*     */     //   77: new 43	java/io/IOException
/*     */     //   80: dup
/*     */     //   81: ldc 45
/*     */     //   83: iconst_1
/*     */     //   84: anewarray 47	java/lang/Object
/*     */     //   87: dup
/*     */     //   88: iconst_0
/*     */     //   89: aload_0
/*     */     //   90: aconst_null
/*     */     //   91: astore_0
/*     */     //   92: aastore
/*     */     //   93: invokestatic 53	clojure/lang/ArraySeq:create	([Ljava/lang/Object;)Lclojure/lang/ArraySeq;
/*     */     //   96: invokestatic 57	clojure/core$str:invokeStatic	(Ljava/lang/Object;Lclojure/lang/ISeq;)Ljava/lang/Object;
/*     */     //   99: checkcast 59	java/lang/String
/*     */     //   102: invokespecial 62	java/io/IOException:<init>	(Ljava/lang/String;)V
/*     */     //   105: checkcast 64	java/lang/Throwable
/*     */     //   108: athrow
/*     */     //   109: areturn
/*     */     // Line number table:
/*     */     //   Java source line #430	-> byte code offset #0
/*     */     //   Java source line #430	-> byte code offset #12
/*     */     //   Java source line #434	-> byte code offset #23
/*     */     //   Java source line #434	-> byte code offset #28
/*     */     //   Java source line #434	-> byte code offset #56
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	109	0	f	Object
/*     */     //   0	109	1	p__9593	ISeq
/*     */     //   4	105	2	vec__9594	Object
/*     */     //   16	93	3	silently	Object
/*     */     //   28	81	4	or__4469__auto__9597	boolean
/*     */     //   56	53	5	or__4469__auto__9596	Object
/*     */   }
/*     */   
/*     */   public Object doInvoke(Object paramObject1, Object paramObject2)
/*     */   {
/* 430 */     paramObject1 = null;paramObject2 = null;return invokeStatic(paramObject1, (ISeq)paramObject2);
/*     */   }
/*     */   
/*     */   public int getRequiredArity()
/*     */   {
/*     */     return 1;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\java\io$delete_file.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */