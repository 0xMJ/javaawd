/*    */ package clojure.java;
/*    */ 
/*    */ import clojure.lang.AFunction;
/*    */ 
/*    */ public final class browse$open_url_script_val
/*    */   extends AFunction
/*    */ {
/*    */   /* Error */
/*    */   public static Object invokeStatic()
/*    */   {
/*    */     // Byte code:
/*    */     //   0: invokestatic 15	clojure/java/browse$macosx_QMARK_:invokeStatic	()Ljava/lang/Object;
/*    */     //   3: dup
/*    */     //   4: ifnull +14 -> 18
/*    */     //   7: getstatic 21	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*    */     //   10: if_acmpeq +9 -> 19
/*    */     //   13: ldc 23
/*    */     //   15: goto +7 -> 22
/*    */     //   18: pop
/*    */     //   19: invokestatic 26	clojure/java/browse$xdg_open_loc:invokeStatic	()Ljava/lang/Object;
/*    */     //   22: areturn
/*    */     // Line number table:
/*    */     //   Java source line #29	-> byte code offset #0
/*    */     //   Java source line #30	-> byte code offset #0
/*    */   }
/*    */   
/*    */   public Object invoke()
/*    */   {
/* 29 */     return invokeStatic();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\java\browse$open_url_script_val.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */