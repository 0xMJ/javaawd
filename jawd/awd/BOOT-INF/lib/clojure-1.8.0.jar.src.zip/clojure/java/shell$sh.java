/*    */ package clojure.java;
/*    */ 
/*    */ import clojure.lang.ILookupThunk;
/*    */ import clojure.lang.ISeq;
/*    */ import clojure.lang.Keyword;
/*    */ import clojure.lang.KeywordLookupSite;
/*    */ import clojure.lang.RT;
/*    */ import clojure.lang.RestFn;
/*    */ import clojure.lang.Var;
/*    */ 
/*    */ public final class shell$sh
/*    */   extends RestFn
/*    */ {
/*    */   /* Error */
/*    */   public static Object invokeStatic(ISeq args)
/*    */   {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: aconst_null
/*    */     //   2: astore_0
/*    */     //   3: invokestatic 18	clojure/java/shell$parse_args:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   6: astore_1
/*    */     //   7: aload_1
/*    */     //   8: lconst_0
/*    */     //   9: invokestatic 24	clojure/lang/RT:intCast	(J)I
/*    */     //   12: aconst_null
/*    */     //   13: invokestatic 28	clojure/lang/RT:nth	(Ljava/lang/Object;ILjava/lang/Object;)Ljava/lang/Object;
/*    */     //   16: astore_2
/*    */     //   17: aload_1
/*    */     //   18: aconst_null
/*    */     //   19: astore_1
/*    */     //   20: lconst_1
/*    */     //   21: invokestatic 24	clojure/lang/RT:intCast	(J)I
/*    */     //   24: aconst_null
/*    */     //   25: invokestatic 28	clojure/lang/RT:nth	(Ljava/lang/Object;ILjava/lang/Object;)Ljava/lang/Object;
/*    */     //   28: astore_3
/*    */     //   29: invokestatic 34	java/lang/Runtime:getRuntime	()Ljava/lang/Runtime;
/*    */     //   32: checkcast 30	java/lang/Runtime
/*    */     //   35: aload_2
/*    */     //   36: aconst_null
/*    */     //   37: astore_2
/*    */     //   38: invokestatic 37	clojure/core$into_array:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   41: checkcast 39	[Ljava/lang/String;
/*    */     //   44: getstatic 43	clojure/java/shell$sh:__thunk__0__	Lclojure/lang/ILookupThunk;
/*    */     //   47: dup
/*    */     //   48: aload_3
/*    */     //   49: dup_x2
/*    */     //   50: invokeinterface 48 2 0
/*    */     //   55: dup_x2
/*    */     //   56: if_acmpeq +7 -> 63
/*    */     //   59: pop
/*    */     //   60: goto +25 -> 85
/*    */     //   63: swap
/*    */     //   64: pop
/*    */     //   65: dup
/*    */     //   66: getstatic 52	clojure/java/shell$sh:__site__0__	Lclojure/lang/KeywordLookupSite;
/*    */     //   69: swap
/*    */     //   70: invokeinterface 58 2 0
/*    */     //   75: dup
/*    */     //   76: putstatic 43	clojure/java/shell$sh:__thunk__0__	Lclojure/lang/ILookupThunk;
/*    */     //   79: swap
/*    */     //   80: invokeinterface 48 2 0
/*    */     //   85: invokestatic 61	clojure/java/shell$as_env_strings:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   88: checkcast 39	[Ljava/lang/String;
/*    */     //   91: getstatic 64	clojure/java/shell$sh:__thunk__1__	Lclojure/lang/ILookupThunk;
/*    */     //   94: dup
/*    */     //   95: aload_3
/*    */     //   96: dup_x2
/*    */     //   97: invokeinterface 48 2 0
/*    */     //   102: dup_x2
/*    */     //   103: if_acmpeq +7 -> 110
/*    */     //   106: pop
/*    */     //   107: goto +25 -> 132
/*    */     //   110: swap
/*    */     //   111: pop
/*    */     //   112: dup
/*    */     //   113: getstatic 67	clojure/java/shell$sh:__site__1__	Lclojure/lang/KeywordLookupSite;
/*    */     //   116: swap
/*    */     //   117: invokeinterface 58 2 0
/*    */     //   122: dup
/*    */     //   123: putstatic 64	clojure/java/shell$sh:__thunk__1__	Lclojure/lang/ILookupThunk;
/*    */     //   126: swap
/*    */     //   127: invokeinterface 48 2 0
/*    */     //   132: dup
/*    */     //   133: invokestatic 73	clojure/lang/Util:classOf	(Ljava/lang/Object;)Ljava/lang/Class;
/*    */     //   136: getstatic 75	clojure/java/shell$sh:__cached_class__0	Ljava/lang/Class;
/*    */     //   139: if_acmpeq +17 -> 156
/*    */     //   142: dup
/*    */     //   143: instanceof 77
/*    */     //   146: ifne +25 -> 171
/*    */     //   149: dup
/*    */     //   150: invokestatic 73	clojure/lang/Util:classOf	(Ljava/lang/Object;)Ljava/lang/Class;
/*    */     //   153: putstatic 75	clojure/java/shell$sh:__cached_class__0	Ljava/lang/Class;
/*    */     //   156: getstatic 81	clojure/java/shell$sh:const__7	Lclojure/lang/Var;
/*    */     //   159: invokevirtual 87	clojure/lang/Var:getRawRoot	()Ljava/lang/Object;
/*    */     //   162: swap
/*    */     //   163: invokeinterface 92 2 0
/*    */     //   168: goto +8 -> 176
/*    */     //   171: invokeinterface 95 1 0
/*    */     //   176: checkcast 97	java/io/File
/*    */     //   179: invokevirtual 101	java/lang/Runtime:exec	([Ljava/lang/String;[Ljava/lang/String;Ljava/io/File;)Ljava/lang/Process;
/*    */     //   182: astore 4
/*    */     //   184: aload_3
/*    */     //   185: aconst_null
/*    */     //   186: astore_3
/*    */     //   187: astore 5
/*    */     //   189: aload 5
/*    */     //   191: invokestatic 104	clojure/core$seq_QMARK___4361:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   194: dup
/*    */     //   195: ifnull +26 -> 221
/*    */     //   198: getstatic 110	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*    */     //   201: if_acmpeq +21 -> 222
/*    */     //   204: aload 5
/*    */     //   206: aconst_null
/*    */     //   207: astore 5
/*    */     //   209: invokestatic 113	clojure/core$seq__4357:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   212: checkcast 115	clojure/lang/ISeq
/*    */     //   215: invokestatic 121	clojure/lang/PersistentHashMap:create	(Lclojure/lang/ISeq;)Lclojure/lang/PersistentHashMap;
/*    */     //   218: goto +9 -> 227
/*    */     //   221: pop
/*    */     //   222: aload 5
/*    */     //   224: aconst_null
/*    */     //   225: astore 5
/*    */     //   227: astore 6
/*    */     //   229: aload 6
/*    */     //   231: getstatic 125	clojure/java/shell$sh:const__12	Lclojure/lang/Keyword;
/*    */     //   234: invokestatic 128	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   237: astore 7
/*    */     //   239: aload 6
/*    */     //   241: getstatic 131	clojure/java/shell$sh:const__13	Lclojure/lang/Keyword;
/*    */     //   244: invokestatic 128	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   247: astore 8
/*    */     //   249: aload 6
/*    */     //   251: aconst_null
/*    */     //   252: astore 6
/*    */     //   254: getstatic 134	clojure/java/shell$sh:const__14	Lclojure/lang/Keyword;
/*    */     //   257: invokestatic 128	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   260: astore 9
/*    */     //   262: aload 7
/*    */     //   264: dup
/*    */     //   265: ifnull +35 -> 300
/*    */     //   268: getstatic 110	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*    */     //   271: if_acmpeq +30 -> 301
/*    */     //   274: new 136	clojure/java/shell$sh$fn__9707
/*    */     //   277: dup
/*    */     //   278: aload 8
/*    */     //   280: aconst_null
/*    */     //   281: astore 8
/*    */     //   283: aload 4
/*    */     //   285: aload 7
/*    */     //   287: aconst_null
/*    */     //   288: astore 7
/*    */     //   290: invokespecial 139	clojure/java/shell$sh$fn__9707:<init>	(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
/*    */     //   293: invokestatic 142	clojure/core$future_call:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   296: pop
/*    */     //   297: goto +20 -> 317
/*    */     //   300: pop
/*    */     //   301: aload 4
/*    */     //   303: checkcast 144	java/lang/Process
/*    */     //   306: invokevirtual 148	java/lang/Process:getOutputStream	()Ljava/io/OutputStream;
/*    */     //   309: checkcast 150	java/io/OutputStream
/*    */     //   312: invokevirtual 153	java/io/OutputStream:close	()V
/*    */     //   315: aconst_null
/*    */     //   316: pop
/*    */     //   317: aload 4
/*    */     //   319: checkcast 144	java/lang/Process
/*    */     //   322: invokevirtual 157	java/lang/Process:getInputStream	()Ljava/io/InputStream;
/*    */     //   325: astore 10
/*    */     //   327: aload 4
/*    */     //   329: checkcast 144	java/lang/Process
/*    */     //   332: invokevirtual 160	java/lang/Process:getErrorStream	()Ljava/io/InputStream;
/*    */     //   335: astore 11
/*    */     //   337: new 162	clojure/java/shell$sh$fn__9709
/*    */     //   340: dup
/*    */     //   341: aload 10
/*    */     //   343: aload 9
/*    */     //   345: aconst_null
/*    */     //   346: astore 9
/*    */     //   348: invokespecial 165	clojure/java/shell$sh$fn__9709:<init>	(Ljava/lang/Object;Ljava/lang/Object;)V
/*    */     //   351: invokestatic 142	clojure/core$future_call:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   354: astore 12
/*    */     //   356: new 167	clojure/java/shell$sh$fn__9711
/*    */     //   359: dup
/*    */     //   360: aload 11
/*    */     //   362: invokespecial 170	clojure/java/shell$sh$fn__9711:<init>	(Ljava/lang/Object;)V
/*    */     //   365: invokestatic 142	clojure/core$future_call:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   368: astore 13
/*    */     //   370: aload 4
/*    */     //   372: aconst_null
/*    */     //   373: astore 4
/*    */     //   375: checkcast 144	java/lang/Process
/*    */     //   378: invokevirtual 174	java/lang/Process:waitFor	()I
/*    */     //   381: istore 14
/*    */     //   383: bipush 6
/*    */     //   385: anewarray 176	java/lang/Object
/*    */     //   388: dup
/*    */     //   389: iconst_0
/*    */     //   390: getstatic 179	clojure/java/shell$sh:const__16	Lclojure/lang/Keyword;
/*    */     //   393: aastore
/*    */     //   394: dup
/*    */     //   395: iconst_1
/*    */     //   396: iload 14
/*    */     //   398: invokestatic 185	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
/*    */     //   401: aastore
/*    */     //   402: dup
/*    */     //   403: iconst_2
/*    */     //   404: getstatic 188	clojure/java/shell$sh:const__17	Lclojure/lang/Keyword;
/*    */     //   407: aastore
/*    */     //   408: dup
/*    */     //   409: iconst_3
/*    */     //   410: aload 12
/*    */     //   412: aconst_null
/*    */     //   413: astore 12
/*    */     //   415: invokestatic 191	clojure/core$deref:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   418: aastore
/*    */     //   419: dup
/*    */     //   420: iconst_4
/*    */     //   421: getstatic 194	clojure/java/shell$sh:const__19	Lclojure/lang/Keyword;
/*    */     //   424: aastore
/*    */     //   425: dup
/*    */     //   426: iconst_5
/*    */     //   427: aload 13
/*    */     //   429: aconst_null
/*    */     //   430: astore 13
/*    */     //   432: invokestatic 191	clojure/core$deref:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   435: aastore
/*    */     //   436: invokestatic 198	clojure/lang/RT:mapUniqueKeys	([Ljava/lang/Object;)Lclojure/lang/IPersistentMap;
/*    */     //   439: astore 15
/*    */     //   441: aload 11
/*    */     //   443: aconst_null
/*    */     //   444: astore 11
/*    */     //   446: checkcast 205	java/io/InputStream
/*    */     //   449: invokevirtual 206	java/io/InputStream:close	()V
/*    */     //   452: aconst_null
/*    */     //   453: pop
/*    */     //   454: goto +21 -> 475
/*    */     //   457: astore 16
/*    */     //   459: aload 11
/*    */     //   461: aconst_null
/*    */     //   462: astore 11
/*    */     //   464: checkcast 205	java/io/InputStream
/*    */     //   467: invokevirtual 206	java/io/InputStream:close	()V
/*    */     //   470: aconst_null
/*    */     //   471: pop
/*    */     //   472: aload 16
/*    */     //   474: athrow
/*    */     //   475: aload 15
/*    */     //   477: astore 17
/*    */     //   479: aload 10
/*    */     //   481: aconst_null
/*    */     //   482: astore 10
/*    */     //   484: checkcast 205	java/io/InputStream
/*    */     //   487: invokevirtual 206	java/io/InputStream:close	()V
/*    */     //   490: aconst_null
/*    */     //   491: pop
/*    */     //   492: goto +21 -> 513
/*    */     //   495: astore 18
/*    */     //   497: aload 10
/*    */     //   499: aconst_null
/*    */     //   500: astore 10
/*    */     //   502: checkcast 205	java/io/InputStream
/*    */     //   505: invokevirtual 206	java/io/InputStream:close	()V
/*    */     //   508: aconst_null
/*    */     //   509: pop
/*    */     //   510: aload 18
/*    */     //   512: athrow
/*    */     //   513: aload 17
/*    */     //   515: areturn
/*    */     // Line number table:
/*    */     //   Java source line #79	-> byte code offset #0
/*    */     //   Java source line #112	-> byte code offset #13
/*    */     //   Java source line #112	-> byte code offset #25
/*    */     //   Java source line #113	-> byte code offset #29
/*    */     //   Java source line #115	-> byte code offset #44
/*    */     //   Java source line #115	-> byte code offset #49
/*    */     //   Java source line #116	-> byte code offset #91
/*    */     //   Java source line #116	-> byte code offset #91
/*    */     //   Java source line #116	-> byte code offset #96
/*    */     //   Java source line #116	-> byte code offset #163
/*    */     //   Java source line #113	-> byte code offset #179
/*    */     //   Java source line #112	-> byte code offset #189
/*    */     //   Java source line #112	-> byte code offset #215
/*    */     //   Java source line #112	-> byte code offset #234
/*    */     //   Java source line #112	-> byte code offset #244
/*    */     //   Java source line #112	-> byte code offset #257
/*    */     //   Java source line #118	-> byte code offset #262
/*    */     //   Java source line #122	-> byte code offset #306
/*    */     //   Java source line #122	-> byte code offset #312
/*    */     //   Java source line #123	-> byte code offset #322
/*    */     //   Java source line #124	-> byte code offset #332
/*    */     //   Java source line #127	-> byte code offset #378
/*    */     //   Java source line #123	-> byte code offset #449
/*    */     //   Java source line #123	-> byte code offset #467
/*    */     //   Java source line #123	-> byte code offset #487
/*    */     //   Java source line #123	-> byte code offset #505
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	signature
/*    */     //   0	515	0	args	ISeq
/*    */     //   7	508	1	vec__9705	Object
/*    */     //   17	498	2	cmd	Object
/*    */     //   29	486	3	opts	Object
/*    */     //   184	331	4	proc	Object
/*    */     //   189	326	5	map__9706	Object
/*    */     //   229	286	6	map__9706	Object
/*    */     //   239	276	7	in	Object
/*    */     //   249	266	8	in_enc	Object
/*    */     //   262	253	9	out_enc	Object
/*    */     //   327	188	10	stdout	Object
/*    */     //   337	140	11	stderr	Object
/*    */     //   356	83	12	out	Object
/*    */     //   370	69	13	err	Object
/*    */     //   383	56	14	exit_code	int
/*    */     // Exception table:
/*    */     //   from	to	target	type
/*    */     //   337	441	457	finally
/*    */     //   327	479	495	finally
/*    */   }
/*    */   
/*    */   public Object doInvoke(Object paramObject)
/*    */   {
/* 79 */     paramObject = null;return invokeStatic((ISeq)paramObject); } static ILookupThunk __thunk__1__ = __site__1__ = new KeywordLookupSite(RT.keyword(null, "dir")); static final KeywordLookupSite __site__1__; static ILookupThunk __thunk__0__ = __site__0__ = new KeywordLookupSite(RT.keyword(null, "env")); static final KeywordLookupSite __site__0__; public static final Keyword const__19 = (Keyword)RT.keyword(null, "err"); public static final Keyword const__17 = (Keyword)RT.keyword(null, "out"); public static final Keyword const__16 = (Keyword)RT.keyword(null, "exit"); public static final Keyword const__14 = (Keyword)RT.keyword(null, "out-enc"); public static final Keyword const__13 = (Keyword)RT.keyword(null, "in-enc"); public static final Keyword const__12 = (Keyword)RT.keyword(null, "in"); public static final Var const__7 = (Var)RT.var("clojure.java.io", "as-file");
/*    */   private static Class __cached_class__0;
/*    */   
/*    */   public int getRequiredArity()
/*    */   {
/*    */     return 0;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\java\shell$sh.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */