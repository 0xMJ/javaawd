/*     */ package clojure.java;
/*     */ 
/*     */ import clojure.lang.AFunction;
/*     */ import clojure.lang.RT;
/*     */ import clojure.lang.Var;
/*     */ 
/*     */ public final class io$inputstream__GT_reader
/*     */   extends AFunction
/*     */ {
/*     */   private static Class __cached_class__0;
/*     */   
/*     */   /* Error */
/*     */   public static Object invokeStatic(Object is, Object opts)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: new 15	java/io/InputStreamReader
/*     */     //   3: dup
/*     */     //   4: aload_0
/*     */     //   5: aconst_null
/*     */     //   6: astore_0
/*     */     //   7: checkcast 17	java/io/InputStream
/*     */     //   10: aload_1
/*     */     //   11: invokestatic 22	clojure/java/io$encoding:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   14: checkcast 24	java/lang/String
/*     */     //   17: invokespecial 27	java/io/InputStreamReader:<init>	(Ljava/io/InputStream;Ljava/lang/String;)V
/*     */     //   20: dup
/*     */     //   21: invokestatic 33	clojure/lang/Util:classOf	(Ljava/lang/Object;)Ljava/lang/Class;
/*     */     //   24: getstatic 35	clojure/java/io$inputstream__GT_reader:__cached_class__0	Ljava/lang/Class;
/*     */     //   27: if_acmpeq +17 -> 44
/*     */     //   30: dup
/*     */     //   31: instanceof 37
/*     */     //   34: ifne +28 -> 62
/*     */     //   37: dup
/*     */     //   38: invokestatic 33	clojure/lang/Util:classOf	(Ljava/lang/Object;)Ljava/lang/Class;
/*     */     //   41: putstatic 35	clojure/java/io$inputstream__GT_reader:__cached_class__0	Ljava/lang/Class;
/*     */     //   44: getstatic 41	clojure/java/io$inputstream__GT_reader:const__0	Lclojure/lang/Var;
/*     */     //   47: invokevirtual 47	clojure/lang/Var:getRawRoot	()Ljava/lang/Object;
/*     */     //   50: swap
/*     */     //   51: aload_1
/*     */     //   52: aconst_null
/*     */     //   53: astore_1
/*     */     //   54: invokeinterface 52 3 0
/*     */     //   59: goto +11 -> 70
/*     */     //   62: aload_1
/*     */     //   63: aconst_null
/*     */     //   64: astore_1
/*     */     //   65: invokeinterface 55 2 0
/*     */     //   70: areturn
/*     */     // Line number table:
/*     */     //   Java source line #174	-> byte code offset #0
/*     */     //   Java source line #176	-> byte code offset #0
/*     */     //   Java source line #176	-> byte code offset #54
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	70	0	is	Object
/*     */     //   0	70	1	opts	Object
/*     */   }
/*     */   
/*     */   public Object invoke(Object paramObject1, Object paramObject2)
/*     */   {
/* 174 */     paramObject1 = null;paramObject2 = null;return invokeStatic(paramObject1, paramObject2); } public static final Var const__0 = (Var)RT.var("clojure.java.io", "make-reader");
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\java\io$inputstream__GT_reader.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */