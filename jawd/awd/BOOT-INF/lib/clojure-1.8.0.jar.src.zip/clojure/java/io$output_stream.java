/*     */ package clojure.java;
/*     */ 
/*     */ import clojure.lang.ISeq;
/*     */ import clojure.lang.RT;
/*     */ import clojure.lang.RestFn;
/*     */ import clojure.lang.Var;
/*     */ 
/*     */ public final class io$output_stream
/*     */   extends RestFn
/*     */ {
/*     */   /* Error */
/*     */   public static Object invokeStatic(Object x, ISeq opts)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: aconst_null
/*     */     //   2: astore_0
/*     */     //   3: dup
/*     */     //   4: invokestatic 19	clojure/lang/Util:classOf	(Ljava/lang/Object;)Ljava/lang/Class;
/*     */     //   7: getstatic 21	clojure/java/io$output_stream:__cached_class__0	Ljava/lang/Class;
/*     */     //   10: if_acmpeq +17 -> 27
/*     */     //   13: dup
/*     */     //   14: instanceof 23
/*     */     //   17: ifne +53 -> 70
/*     */     //   20: dup
/*     */     //   21: invokestatic 19	clojure/lang/Util:classOf	(Ljava/lang/Object;)Ljava/lang/Class;
/*     */     //   24: putstatic 21	clojure/java/io$output_stream:__cached_class__0	Ljava/lang/Class;
/*     */     //   27: getstatic 27	clojure/java/io$output_stream:const__0	Lclojure/lang/Var;
/*     */     //   30: invokevirtual 33	clojure/lang/Var:getRawRoot	()Ljava/lang/Object;
/*     */     //   33: swap
/*     */     //   34: aload_1
/*     */     //   35: dup
/*     */     //   36: ifnull +24 -> 60
/*     */     //   39: getstatic 39	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   42: if_acmpeq +19 -> 61
/*     */     //   45: getstatic 42	clojure/java/io$output_stream:const__2	Lclojure/lang/Var;
/*     */     //   48: invokevirtual 33	clojure/lang/Var:getRawRoot	()Ljava/lang/Object;
/*     */     //   51: aload_1
/*     */     //   52: aconst_null
/*     */     //   53: astore_1
/*     */     //   54: invokestatic 47	clojure/core$apply:invokeStatic	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   57: goto +5 -> 62
/*     */     //   60: pop
/*     */     //   61: aconst_null
/*     */     //   62: invokeinterface 52 3 0
/*     */     //   67: goto +36 -> 103
/*     */     //   70: aload_1
/*     */     //   71: dup
/*     */     //   72: ifnull +24 -> 96
/*     */     //   75: getstatic 39	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   78: if_acmpeq +19 -> 97
/*     */     //   81: getstatic 42	clojure/java/io$output_stream:const__2	Lclojure/lang/Var;
/*     */     //   84: invokevirtual 33	clojure/lang/Var:getRawRoot	()Ljava/lang/Object;
/*     */     //   87: aload_1
/*     */     //   88: aconst_null
/*     */     //   89: astore_1
/*     */     //   90: invokestatic 47	clojure/core$apply:invokeStatic	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   93: goto +5 -> 98
/*     */     //   96: pop
/*     */     //   97: aconst_null
/*     */     //   98: invokeinterface 56 2 0
/*     */     //   103: areturn
/*     */     // Line number table:
/*     */     //   Java source line #138	-> byte code offset #0
/*     */     //   Java source line #153	-> byte code offset #0
/*     */     //   Java source line #153	-> byte code offset #34
/*     */     //   Java source line #153	-> byte code offset #62
/*     */     //   Java source line #153	-> byte code offset #70
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	103	0	x	Object
/*     */     //   0	103	1	opts	ISeq
/*     */   }
/*     */   
/*     */   public Object doInvoke(Object paramObject1, Object paramObject2)
/*     */   {
/* 138 */     paramObject1 = null;paramObject2 = null;return invokeStatic(paramObject1, (ISeq)paramObject2); } public static final Var const__2 = (Var)RT.var("clojure.core", "hash-map"); public static final Var const__0 = (Var)RT.var("clojure.java.io", "make-output-stream");
/*     */   private static Class __cached_class__0;
/*     */   
/*     */   public int getRequiredArity()
/*     */   {
/*     */     return 1;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\java\io$output_stream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */