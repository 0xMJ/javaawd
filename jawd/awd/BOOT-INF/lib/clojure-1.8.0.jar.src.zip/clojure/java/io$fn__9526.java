/*     */ package clojure.java;
/*     */ 
/*     */ import clojure.lang.AFunction;
/*     */ import clojure.lang.RT;
/*     */ import clojure.lang.Var;
/*     */ 
/*     */ public final class io$fn__9526
/*     */   extends AFunction
/*     */ {
/*     */   /* Error */
/*     */   public static Object invokeStatic(Object x, Object opts)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: ldc 16
/*     */     //   2: aload_0
/*     */     //   3: checkcast 18	java/net/URL
/*     */     //   6: invokevirtual 22	java/net/URL:getProtocol	()Ljava/lang/String;
/*     */     //   9: invokestatic 28	clojure/lang/Util:equiv	(Ljava/lang/Object;Ljava/lang/Object;)Z
/*     */     //   12: ifeq +104 -> 116
/*     */     //   15: aload_0
/*     */     //   16: aconst_null
/*     */     //   17: astore_0
/*     */     //   18: dup
/*     */     //   19: invokestatic 32	clojure/lang/Util:classOf	(Ljava/lang/Object;)Ljava/lang/Class;
/*     */     //   22: getstatic 34	clojure/java/io$fn__9526:__cached_class__0	Ljava/lang/Class;
/*     */     //   25: if_acmpeq +17 -> 42
/*     */     //   28: dup
/*     */     //   29: instanceof 36
/*     */     //   32: ifne +25 -> 57
/*     */     //   35: dup
/*     */     //   36: invokestatic 32	clojure/lang/Util:classOf	(Ljava/lang/Object;)Ljava/lang/Class;
/*     */     //   39: putstatic 34	clojure/java/io$fn__9526:__cached_class__0	Ljava/lang/Class;
/*     */     //   42: getstatic 40	clojure/java/io$fn__9526:const__2	Lclojure/lang/Var;
/*     */     //   45: invokevirtual 46	clojure/lang/Var:getRawRoot	()Ljava/lang/Object;
/*     */     //   48: swap
/*     */     //   49: invokeinterface 52 2 0
/*     */     //   54: goto +8 -> 62
/*     */     //   57: invokeinterface 55 1 0
/*     */     //   62: dup
/*     */     //   63: invokestatic 32	clojure/lang/Util:classOf	(Ljava/lang/Object;)Ljava/lang/Class;
/*     */     //   66: getstatic 57	clojure/java/io$fn__9526:__cached_class__1	Ljava/lang/Class;
/*     */     //   69: if_acmpeq +17 -> 86
/*     */     //   72: dup
/*     */     //   73: instanceof 59
/*     */     //   76: ifne +28 -> 104
/*     */     //   79: dup
/*     */     //   80: invokestatic 32	clojure/lang/Util:classOf	(Ljava/lang/Object;)Ljava/lang/Class;
/*     */     //   83: putstatic 57	clojure/java/io$fn__9526:__cached_class__1	Ljava/lang/Class;
/*     */     //   86: getstatic 62	clojure/java/io$fn__9526:const__1	Lclojure/lang/Var;
/*     */     //   89: invokevirtual 46	clojure/lang/Var:getRawRoot	()Ljava/lang/Object;
/*     */     //   92: swap
/*     */     //   93: aload_1
/*     */     //   94: aconst_null
/*     */     //   95: astore_1
/*     */     //   96: invokeinterface 64 3 0
/*     */     //   101: goto +11 -> 112
/*     */     //   104: aload_1
/*     */     //   105: aconst_null
/*     */     //   106: astore_1
/*     */     //   107: invokeinterface 67 2 0
/*     */     //   112: goto +41 -> 153
/*     */     //   115: pop
/*     */     //   116: new 69	java/lang/IllegalArgumentException
/*     */     //   119: dup
/*     */     //   120: ldc 71
/*     */     //   122: iconst_2
/*     */     //   123: anewarray 73	java/lang/Object
/*     */     //   126: dup
/*     */     //   127: iconst_0
/*     */     //   128: aload_0
/*     */     //   129: aconst_null
/*     */     //   130: astore_0
/*     */     //   131: aastore
/*     */     //   132: dup
/*     */     //   133: iconst_1
/*     */     //   134: ldc 75
/*     */     //   136: aastore
/*     */     //   137: invokestatic 81	clojure/lang/ArraySeq:create	([Ljava/lang/Object;)Lclojure/lang/ArraySeq;
/*     */     //   140: invokestatic 86	clojure/core$str:invokeStatic	(Ljava/lang/Object;Lclojure/lang/ISeq;)Ljava/lang/Object;
/*     */     //   143: checkcast 88	java/lang/String
/*     */     //   146: invokespecial 91	java/lang/IllegalArgumentException:<init>	(Ljava/lang/String;)V
/*     */     //   149: checkcast 93	java/lang/Throwable
/*     */     //   152: athrow
/*     */     //   153: areturn
/*     */     // Line number table:
/*     */     //   Java source line #240	-> byte code offset #0
/*     */     //   Java source line #241	-> byte code offset #0
/*     */     //   Java source line #241	-> byte code offset #6
/*     */     //   Java source line #241	-> byte code offset #9
/*     */     //   Java source line #242	-> byte code offset #15
/*     */     //   Java source line #242	-> byte code offset #15
/*     */     //   Java source line #242	-> byte code offset #49
/*     */     //   Java source line #242	-> byte code offset #96
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	153	0	x	Object
/*     */     //   0	153	1	opts	Object
/*     */   }
/*     */   
/*     */   public Object invoke(Object paramObject1, Object paramObject2)
/*     */   {
/* 240 */     paramObject1 = null;paramObject2 = null;return invokeStatic(paramObject1, paramObject2); } public static final Var const__2 = (Var)RT.var("clojure.java.io", "as-file"); public static final Var const__1 = (Var)RT.var("clojure.java.io", "make-output-stream");
/*     */   private static Class __cached_class__1;
/*     */   private static Class __cached_class__0;
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\java\io$fn__9526.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */