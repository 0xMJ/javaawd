/*    */ package clojure.java;
/*    */ 
/*    */ import clojure.core.apply;
/*    */ import clojure.core.concat;
/*    */ import clojure.core.seq__4357;
/*    */ import clojure.lang.AFn;
/*    */ import clojure.lang.ArraySeq;
/*    */ import clojure.lang.ISeq;
/*    */ import clojure.lang.PersistentList.Primordial;
/*    */ import clojure.lang.RT;
/*    */ import clojure.lang.RestFn;
/*    */ import clojure.lang.Symbol;
/*    */ import clojure.lang.Var;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class shell$with_sh_env
/*    */   extends RestFn
/*    */ {
/*    */   public int getRequiredArity()
/*    */   {
/*    */     return 3;
/*    */   }
/*    */   
/*    */   public Object doInvoke(Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4)
/*    */   {
/* 28 */     paramObject1 = null;paramObject2 = null;paramObject3 = null;paramObject4 = null;return invokeStatic(paramObject1, paramObject2, paramObject3, (ISeq)paramObject4); } public static Object invokeStatic(Object _AMPERSAND_form, Object _AMPERSAND_env, Object env, ISeq forms) { Object[] tmp20_17 = new Object[1]; Object[] tmp48_45 = new Object[1];env = null;tmp48_45[0] = env;tmp20_17[0] = core.apply.invokeStatic(const__5.getRawRoot(), core.seq__4357.invokeStatic(core.concat.invokeStatic(PersistentList.Primordial.invokeStatic(ArraySeq.create(new Object[] { const__6 })), PersistentList.Primordial.invokeStatic(ArraySeq.create(tmp48_45))))); Object[] tmp80_77 = new Object[1];forms = null;tmp80_77[0] = forms;return core.seq__4357.invokeStatic(core.concat.invokeStatic(PersistentList.Primordial.invokeStatic(ArraySeq.create(new Object[] { const__3 })), PersistentList.Primordial.invokeStatic(ArraySeq.create(tmp20_17)), ArraySeq.create(tmp80_77))); } public static final AFn const__6 = (AFn)Symbol.intern("clojure.java.shell", "*sh-env*"); public static final Var const__5 = (Var)RT.var("clojure.core", "vector"); public static final AFn const__3 = (AFn)Symbol.intern("clojure.core", "binding");
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\java\shell$with_sh_env.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */