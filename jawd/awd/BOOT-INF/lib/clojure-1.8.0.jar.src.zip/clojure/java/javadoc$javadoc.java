/*    */ package clojure.java;
/*    */ 
/*    */ import clojure.lang.AFunction;
/*    */ 
/*    */ public final class javadoc$javadoc
/*    */   extends AFunction
/*    */ {
/*    */   /* Error */
/*    */   public static Object invokeStatic(Object class_or_object)
/*    */   {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: instanceof 13
/*    */     //   4: ifeq +10 -> 14
/*    */     //   7: aload_0
/*    */     //   8: aconst_null
/*    */     //   9: astore_0
/*    */     //   10: goto +10 -> 20
/*    */     //   13: pop
/*    */     //   14: aload_0
/*    */     //   15: aconst_null
/*    */     //   16: astore_0
/*    */     //   17: invokestatic 17	clojure/core$class:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   20: astore_1
/*    */     //   21: aload_1
/*    */     //   22: checkcast 13	java/lang/Class
/*    */     //   25: invokevirtual 21	java/lang/Class:getName	()Ljava/lang/String;
/*    */     //   28: invokestatic 24	clojure/java/javadoc$javadoc_url:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   31: astore_2
/*    */     //   32: aload_2
/*    */     //   33: dup
/*    */     //   34: ifnull +22 -> 56
/*    */     //   37: getstatic 30	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*    */     //   40: if_acmpeq +17 -> 57
/*    */     //   43: aload_2
/*    */     //   44: aconst_null
/*    */     //   45: astore_2
/*    */     //   46: astore_3
/*    */     //   47: aload_3
/*    */     //   48: aconst_null
/*    */     //   49: astore_3
/*    */     //   50: invokestatic 33	clojure/java/browse$browse_url:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   53: goto +25 -> 78
/*    */     //   56: pop
/*    */     //   57: iconst_2
/*    */     //   58: anewarray 37	java/lang/Object
/*    */     //   61: dup
/*    */     //   62: iconst_0
/*    */     //   63: ldc 39
/*    */     //   65: aastore
/*    */     //   66: dup
/*    */     //   67: iconst_1
/*    */     //   68: aload_1
/*    */     //   69: aconst_null
/*    */     //   70: astore_1
/*    */     //   71: aastore
/*    */     //   72: invokestatic 45	clojure/lang/ArraySeq:create	([Ljava/lang/Object;)Lclojure/lang/ArraySeq;
/*    */     //   75: invokestatic 50	clojure/core$println:invokeStatic	(Lclojure/lang/ISeq;)Ljava/lang/Object;
/*    */     //   78: areturn
/*    */     // Line number table:
/*    */     //   Java source line #72	-> byte code offset #0
/*    */     //   Java source line #77	-> byte code offset #0
/*    */     //   Java source line #80	-> byte code offset #25
/*    */     //   Java source line #80	-> byte code offset #32
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	signature
/*    */     //   0	78	0	class_or_object	Object
/*    */     //   21	57	1	c	Object
/*    */     //   32	46	2	temp__4655__auto__9753	Object
/*    */     //   47	6	3	url	Object
/*    */   }
/*    */   
/*    */   public Object invoke(Object paramObject)
/*    */   {
/* 72 */     paramObject = null;return invokeStatic(paramObject);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\java\javadoc$javadoc.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */