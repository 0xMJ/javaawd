/*    */ package clojure.java;
/*    */ 
/*    */ import clojure.lang.AFunction;
/*    */ import clojure.lang.IFn;
/*    */ import clojure.lang.Keyword;
/*    */ import clojure.lang.RT;
/*    */ import clojure.lang.Var;
/*    */ import java.nio.charset.Charset;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class shell$stream_to_string
/*    */   extends AFunction
/*    */ {
/*    */   public Object invoke(Object paramObject1, Object paramObject2)
/*    */   {
/* 66 */     paramObject1 = null;paramObject2 = null;return invokeStatic(paramObject1, paramObject2); } public Object invoke(Object paramObject) { paramObject = null;return invokeStatic(paramObject); } public static final Keyword const__2 = (Keyword)RT.keyword(null, "encoding"); public static final Var const__0 = (Var)RT.var("clojure.java.shell", "stream-to-string");
/* 67 */   public static Object invokeStatic(Object in) { in = null;return ((IFn)const__0.getRawRoot()).invoke(in, ((Charset)Charset.defaultCharset()).name());
/*    */   }
/*    */   
/*    */   /* Error */
/*    */   public static Object invokeStatic(Object in, Object enc)
/*    */   {
/*    */     // Byte code:
/*    */     //   0: new 13	java/io/StringWriter
/*    */     //   3: dup
/*    */     //   4: invokespecial 14	java/io/StringWriter:<init>	()V
/*    */     //   7: astore_2
/*    */     //   8: aload_0
/*    */     //   9: aconst_null
/*    */     //   10: astore_0
/*    */     //   11: aload_2
/*    */     //   12: iconst_2
/*    */     //   13: anewarray 16	java/lang/Object
/*    */     //   16: dup
/*    */     //   17: iconst_0
/*    */     //   18: getstatic 20	clojure/java/shell$stream_to_string:const__2	Lclojure/lang/Keyword;
/*    */     //   21: aastore
/*    */     //   22: dup
/*    */     //   23: iconst_1
/*    */     //   24: aload_1
/*    */     //   25: aconst_null
/*    */     //   26: astore_1
/*    */     //   27: aastore
/*    */     //   28: invokestatic 26	clojure/lang/ArraySeq:create	([Ljava/lang/Object;)Lclojure/lang/ArraySeq;
/*    */     //   31: invokestatic 31	clojure/java/io$copy:invokeStatic	(Ljava/lang/Object;Ljava/lang/Object;Lclojure/lang/ISeq;)Ljava/lang/Object;
/*    */     //   34: pop
/*    */     //   35: aload_2
/*    */     //   36: checkcast 13	java/io/StringWriter
/*    */     //   39: invokevirtual 35	java/io/StringWriter:toString	()Ljava/lang/String;
/*    */     //   42: astore_3
/*    */     //   43: aload_2
/*    */     //   44: aconst_null
/*    */     //   45: astore_2
/*    */     //   46: checkcast 13	java/io/StringWriter
/*    */     //   49: invokevirtual 38	java/io/StringWriter:close	()V
/*    */     //   52: aconst_null
/*    */     //   53: pop
/*    */     //   54: goto +19 -> 73
/*    */     //   57: astore 4
/*    */     //   59: aload_2
/*    */     //   60: aconst_null
/*    */     //   61: astore_2
/*    */     //   62: checkcast 13	java/io/StringWriter
/*    */     //   65: invokevirtual 38	java/io/StringWriter:close	()V
/*    */     //   68: aconst_null
/*    */     //   69: pop
/*    */     //   70: aload 4
/*    */     //   72: athrow
/*    */     //   73: aload_3
/*    */     //   74: areturn
/*    */     // Line number table:
/*    */     //   Java source line #66	-> byte code offset #0
/*    */     //   Java source line #71	-> byte code offset #39
/*    */     //   Java source line #69	-> byte code offset #49
/*    */     //   Java source line #69	-> byte code offset #65
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	signature
/*    */     //   0	74	0	in	Object
/*    */     //   0	74	1	enc	Object
/*    */     //   7	55	2	bout	Object
/*    */     //   42	32	3	str	String
/*    */     //   57	14	4	localObject1	Object
/*    */     // Exception table:
/*    */     //   from	to	target	type
/*    */     //   8	43	57	finally
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\java\shell$stream_to_string.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */