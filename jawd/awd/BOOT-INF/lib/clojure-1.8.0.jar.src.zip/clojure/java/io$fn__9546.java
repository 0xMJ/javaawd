/*     */ package clojure.java;
/*     */ 
/*     */ import clojure.lang.AFunction;
/*     */ 
/*     */ public final class io$fn__9546
/*     */   extends AFunction
/*     */ {
/*     */   /* Error */
/*     */   public static Object invokeStatic(Object x, Object opts)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: new 13	java/lang/IllegalArgumentException
/*     */     //   3: dup
/*     */     //   4: ldc 15
/*     */     //   6: iconst_2
/*     */     //   7: anewarray 17	java/lang/Object
/*     */     //   10: dup
/*     */     //   11: iconst_0
/*     */     //   12: iconst_1
/*     */     //   13: anewarray 17	java/lang/Object
/*     */     //   16: dup
/*     */     //   17: iconst_0
/*     */     //   18: aload_0
/*     */     //   19: aconst_null
/*     */     //   20: astore_0
/*     */     //   21: aastore
/*     */     //   22: invokestatic 23	clojure/lang/ArraySeq:create	([Ljava/lang/Object;)Lclojure/lang/ArraySeq;
/*     */     //   25: invokestatic 28	clojure/core$pr_str:invokeStatic	(Lclojure/lang/ISeq;)Ljava/lang/Object;
/*     */     //   28: aastore
/*     */     //   29: dup
/*     */     //   30: iconst_1
/*     */     //   31: ldc 30
/*     */     //   33: aastore
/*     */     //   34: invokestatic 23	clojure/lang/ArraySeq:create	([Ljava/lang/Object;)Lclojure/lang/ArraySeq;
/*     */     //   37: invokestatic 35	clojure/core$str:invokeStatic	(Ljava/lang/Object;Lclojure/lang/ISeq;)Ljava/lang/Object;
/*     */     //   40: checkcast 37	java/lang/String
/*     */     //   43: invokespecial 40	java/lang/IllegalArgumentException:<init>	(Ljava/lang/String;)V
/*     */     //   46: checkcast 42	java/lang/Throwable
/*     */     //   49: athrow
/*     */     //   50: areturn
/*     */     // Line number table:
/*     */     //   Java source line #291	-> byte code offset #0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	50	0	x	Object
/*     */     //   0	50	1	opts	Object
/*     */   }
/*     */   
/*     */   public Object invoke(Object paramObject1, Object paramObject2)
/*     */   {
/* 291 */     paramObject1 = null;paramObject2 = null;return invokeStatic(paramObject1, paramObject2);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\java\io$fn__9546.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */