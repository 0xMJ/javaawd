/*    */ package clojure.java;
/*    */ 
/*    */ import clojure.lang.AFunction;
/*    */ import clojure.lang.RT;
/*    */ import clojure.lang.Var;
/*    */ 
/*    */ public final class io$fn__9416
/*    */   extends AFunction
/*    */ {
/*    */   /* Error */
/*    */   public static Object invokeStatic(Object u)
/*    */   {
/*    */     // Byte code:
/*    */     //   0: ldc 15
/*    */     //   2: aload_0
/*    */     //   3: checkcast 17	java/net/URL
/*    */     //   6: invokevirtual 21	java/net/URL:getProtocol	()Ljava/lang/String;
/*    */     //   9: invokestatic 27	clojure/lang/Util:equiv	(Ljava/lang/Object;Ljava/lang/Object;)Z
/*    */     //   12: ifeq +81 -> 93
/*    */     //   15: aload_0
/*    */     //   16: aconst_null
/*    */     //   17: astore_0
/*    */     //   18: checkcast 17	java/net/URL
/*    */     //   21: invokevirtual 30	java/net/URL:getFile	()Ljava/lang/String;
/*    */     //   24: checkcast 32	java/lang/String
/*    */     //   27: getstatic 36	clojure/java/io$fn__9416:const__3	Ljava/lang/Object;
/*    */     //   30: checkcast 38	java/lang/Character
/*    */     //   33: invokevirtual 42	java/lang/Character:charValue	()C
/*    */     //   36: getstatic 48	java/io/File:separatorChar	C
/*    */     //   39: invokevirtual 52	java/lang/String:replace	(CC)Ljava/lang/String;
/*    */     //   42: invokestatic 56	clojure/java/io$escaped_utf8_urlstring__GT_str:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   45: dup
/*    */     //   46: invokestatic 60	clojure/lang/Util:classOf	(Ljava/lang/Object;)Ljava/lang/Class;
/*    */     //   49: getstatic 62	clojure/java/io$fn__9416:__cached_class__0	Ljava/lang/Class;
/*    */     //   52: if_acmpeq +17 -> 69
/*    */     //   55: dup
/*    */     //   56: instanceof 64
/*    */     //   59: ifne +25 -> 84
/*    */     //   62: dup
/*    */     //   63: invokestatic 60	clojure/lang/Util:classOf	(Ljava/lang/Object;)Ljava/lang/Class;
/*    */     //   66: putstatic 62	clojure/java/io$fn__9416:__cached_class__0	Ljava/lang/Class;
/*    */     //   69: getstatic 68	clojure/java/io$fn__9416:const__1	Lclojure/lang/Var;
/*    */     //   72: invokevirtual 74	clojure/lang/Var:getRawRoot	()Ljava/lang/Object;
/*    */     //   75: swap
/*    */     //   76: invokeinterface 79 2 0
/*    */     //   81: goto +8 -> 89
/*    */     //   84: invokeinterface 82 1 0
/*    */     //   89: goto +36 -> 125
/*    */     //   92: pop
/*    */     //   93: new 84	java/lang/IllegalArgumentException
/*    */     //   96: dup
/*    */     //   97: ldc 86
/*    */     //   99: iconst_1
/*    */     //   100: anewarray 88	java/lang/Object
/*    */     //   103: dup
/*    */     //   104: iconst_0
/*    */     //   105: aload_0
/*    */     //   106: aconst_null
/*    */     //   107: astore_0
/*    */     //   108: aastore
/*    */     //   109: invokestatic 94	clojure/lang/ArraySeq:create	([Ljava/lang/Object;)Lclojure/lang/ArraySeq;
/*    */     //   112: invokestatic 99	clojure/core$str:invokeStatic	(Ljava/lang/Object;Lclojure/lang/ISeq;)Ljava/lang/Object;
/*    */     //   115: checkcast 32	java/lang/String
/*    */     //   118: invokespecial 102	java/lang/IllegalArgumentException:<init>	(Ljava/lang/String;)V
/*    */     //   121: checkcast 104	java/lang/Throwable
/*    */     //   124: athrow
/*    */     //   125: areturn
/*    */     // Line number table:
/*    */     //   Java source line #44	-> byte code offset #0
/*    */     //   Java source line #60	-> byte code offset #0
/*    */     //   Java source line #60	-> byte code offset #6
/*    */     //   Java source line #60	-> byte code offset #9
/*    */     //   Java source line #61	-> byte code offset #15
/*    */     //   Java source line #62	-> byte code offset #21
/*    */     //   Java source line #62	-> byte code offset #36
/*    */     //   Java source line #62	-> byte code offset #39
/*    */     //   Java source line #61	-> byte code offset #76
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	signature
/*    */     //   0	125	0	u	Object
/*    */   }
/*    */   
/*    */   public Object invoke(Object paramObject)
/*    */   {
/* 44 */     paramObject = null;return invokeStatic(paramObject); } public static final Object const__3 = Character.valueOf('/'); public static final Var const__1 = (Var)RT.var("clojure.java.io", "as-file");
/*    */   private static Class __cached_class__0;
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\java\io$fn__9416.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */