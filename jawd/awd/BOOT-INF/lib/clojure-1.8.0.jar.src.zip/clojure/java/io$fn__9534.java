/*     */ package clojure.java;
/*     */ 
/*     */ import clojure.lang.AFunction;
/*     */ import clojure.lang.RT;
/*     */ import clojure.lang.Var;
/*     */ 
/*     */ public final class io$fn__9534
/*     */   extends AFunction
/*     */ {
/*     */   private static Class __cached_class__0;
/*     */   private static Class __cached_class__1;
/*     */   
/*     */   /* Error */
/*     */   public static Object invokeStatic(Object x, Object opts)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: new 16	java/net/URL
/*     */     //   3: dup
/*     */     //   4: aload_0
/*     */     //   5: checkcast 18	java/lang/String
/*     */     //   8: invokespecial 21	java/net/URL:<init>	(Ljava/lang/String;)V
/*     */     //   11: dup
/*     */     //   12: invokestatic 27	clojure/lang/Util:classOf	(Ljava/lang/Object;)Ljava/lang/Class;
/*     */     //   15: getstatic 29	clojure/java/io$fn__9534:__cached_class__0	Ljava/lang/Class;
/*     */     //   18: if_acmpeq +17 -> 35
/*     */     //   21: dup
/*     */     //   22: instanceof 31
/*     */     //   25: ifne +26 -> 51
/*     */     //   28: dup
/*     */     //   29: invokestatic 27	clojure/lang/Util:classOf	(Ljava/lang/Object;)Ljava/lang/Class;
/*     */     //   32: putstatic 29	clojure/java/io$fn__9534:__cached_class__0	Ljava/lang/Class;
/*     */     //   35: getstatic 35	clojure/java/io$fn__9534:const__0	Lclojure/lang/Var;
/*     */     //   38: invokevirtual 41	clojure/lang/Var:getRawRoot	()Ljava/lang/Object;
/*     */     //   41: swap
/*     */     //   42: aload_1
/*     */     //   43: invokeinterface 46 3 0
/*     */     //   48: goto +9 -> 57
/*     */     //   51: aload_1
/*     */     //   52: invokeinterface 50 2 0
/*     */     //   57: astore_2
/*     */     //   58: goto +71 -> 129
/*     */     //   61: astore_3
/*     */     //   62: new 52	java/io/File
/*     */     //   65: dup
/*     */     //   66: aload_0
/*     */     //   67: aconst_null
/*     */     //   68: astore_0
/*     */     //   69: checkcast 18	java/lang/String
/*     */     //   72: invokespecial 53	java/io/File:<init>	(Ljava/lang/String;)V
/*     */     //   75: dup
/*     */     //   76: invokestatic 27	clojure/lang/Util:classOf	(Ljava/lang/Object;)Ljava/lang/Class;
/*     */     //   79: getstatic 55	clojure/java/io$fn__9534:__cached_class__1	Ljava/lang/Class;
/*     */     //   82: if_acmpeq +17 -> 99
/*     */     //   85: dup
/*     */     //   86: instanceof 31
/*     */     //   89: ifne +28 -> 117
/*     */     //   92: dup
/*     */     //   93: invokestatic 27	clojure/lang/Util:classOf	(Ljava/lang/Object;)Ljava/lang/Class;
/*     */     //   96: putstatic 55	clojure/java/io$fn__9534:__cached_class__1	Ljava/lang/Class;
/*     */     //   99: getstatic 35	clojure/java/io$fn__9534:const__0	Lclojure/lang/Var;
/*     */     //   102: invokevirtual 41	clojure/lang/Var:getRawRoot	()Ljava/lang/Object;
/*     */     //   105: swap
/*     */     //   106: aload_1
/*     */     //   107: aconst_null
/*     */     //   108: astore_1
/*     */     //   109: invokeinterface 46 3 0
/*     */     //   114: goto +11 -> 125
/*     */     //   117: aload_1
/*     */     //   118: aconst_null
/*     */     //   119: astore_1
/*     */     //   120: invokeinterface 50 2 0
/*     */     //   125: astore_2
/*     */     //   126: goto +3 -> 129
/*     */     //   129: aload_2
/*     */     //   130: areturn
/*     */     // Line number table:
/*     */     //   Java source line #259	-> byte code offset #0
/*     */     //   Java source line #261	-> byte code offset #0
/*     */     //   Java source line #261	-> byte code offset #43
/*     */     //   Java source line #263	-> byte code offset #62
/*     */     //   Java source line #263	-> byte code offset #109
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	130	0	x	Object
/*     */     //   0	130	1	opts	Object
/*     */     //   61	65	3	err	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   0	58	61	java/net/MalformedURLException
/*     */   }
/*     */   
/*     */   public Object invoke(Object paramObject1, Object paramObject2)
/*     */   {
/* 259 */     paramObject1 = null;paramObject2 = null;return invokeStatic(paramObject1, paramObject2); } public static final Var const__0 = (Var)RT.var("clojure.java.io", "make-output-stream");
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\java\io$fn__9534.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */