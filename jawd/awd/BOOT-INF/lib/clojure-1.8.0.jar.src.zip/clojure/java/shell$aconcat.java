/*    */ package clojure.java;
/*    */ 
/*    */ import clojure.lang.ISeq;
/*    */ import clojure.lang.RT;
/*    */ import clojure.lang.RestFn;
/*    */ import clojure.lang.Var;
/*    */ 
/*    */ public final class shell$aconcat
/*    */   extends RestFn
/*    */ {
/*    */   /* Error */
/*    */   public static Object invokeStatic(Object type, ISeq xs)
/*    */   {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: aconst_null
/*    */     //   2: astore_0
/*    */     //   3: getstatic 15	clojure/java/shell$aconcat:const__2	Lclojure/lang/Var;
/*    */     //   6: invokevirtual 21	clojure/lang/Var:getRawRoot	()Ljava/lang/Object;
/*    */     //   9: getstatic 24	clojure/java/shell$aconcat:const__4	Lclojure/lang/Var;
/*    */     //   12: invokevirtual 21	clojure/lang/Var:getRawRoot	()Ljava/lang/Object;
/*    */     //   15: aload_1
/*    */     //   16: invokestatic 29	clojure/core$map:invokeStatic	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   19: invokestatic 32	clojure/core$apply:invokeStatic	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   22: invokestatic 35	clojure/core$make_array:invokeStatic	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   25: astore_2
/*    */     //   26: lconst_0
/*    */     //   27: lstore_3
/*    */     //   28: lconst_0
/*    */     //   29: lstore 5
/*    */     //   31: aload_1
/*    */     //   32: lload_3
/*    */     //   33: invokestatic 41	clojure/lang/RT:intCast	(J)I
/*    */     //   36: aconst_null
/*    */     //   37: invokestatic 45	clojure/lang/RT:nth	(Ljava/lang/Object;ILjava/lang/Object;)Ljava/lang/Object;
/*    */     //   40: astore 7
/*    */     //   42: aload 7
/*    */     //   44: dup
/*    */     //   45: ifnull +63 -> 108
/*    */     //   48: getstatic 51	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*    */     //   51: if_acmpeq +58 -> 109
/*    */     //   54: aload 7
/*    */     //   56: aconst_null
/*    */     //   57: astore 7
/*    */     //   59: astore 8
/*    */     //   61: aload 8
/*    */     //   63: lconst_0
/*    */     //   64: invokestatic 41	clojure/lang/RT:intCast	(J)I
/*    */     //   67: aload_2
/*    */     //   68: lload 5
/*    */     //   70: invokestatic 41	clojure/lang/RT:intCast	(J)I
/*    */     //   73: aload 8
/*    */     //   75: invokestatic 55	clojure/lang/RT:count	(Ljava/lang/Object;)I
/*    */     //   78: invokestatic 61	java/lang/System:arraycopy	(Ljava/lang/Object;ILjava/lang/Object;II)V
/*    */     //   81: lload_3
/*    */     //   82: invokestatic 67	clojure/lang/Numbers:inc	(J)J
/*    */     //   85: lload 5
/*    */     //   87: aload 8
/*    */     //   89: aconst_null
/*    */     //   90: astore 8
/*    */     //   92: invokestatic 55	clojure/lang/RT:count	(Ljava/lang/Object;)I
/*    */     //   95: i2l
/*    */     //   96: invokestatic 71	clojure/lang/Numbers:add	(JJ)J
/*    */     //   99: lstore 5
/*    */     //   101: lstore_3
/*    */     //   102: goto -71 -> 31
/*    */     //   105: goto +6 -> 111
/*    */     //   108: pop
/*    */     //   109: aconst_null
/*    */     //   110: pop
/*    */     //   111: aload_2
/*    */     //   112: aconst_null
/*    */     //   113: astore_2
/*    */     //   114: areturn
/*    */     // Line number table:
/*    */     //   Java source line #35	-> byte code offset #0
/*    */     //   Java source line #40	-> byte code offset #37
/*    */     //   Java source line #40	-> byte code offset #42
/*    */     //   Java source line #41	-> byte code offset #75
/*    */     //   Java source line #41	-> byte code offset #78
/*    */     //   Java source line #42	-> byte code offset #82
/*    */     //   Java source line #42	-> byte code offset #92
/*    */     //   Java source line #42	-> byte code offset #96
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	signature
/*    */     //   0	114	0	type	Object
/*    */     //   0	114	1	xs	ISeq
/*    */     //   26	88	2	target	Object
/*    */     //   28	83	3	i	long
/*    */     //   31	80	5	idx	long
/*    */     //   42	69	7	temp__4657__auto__9694	Object
/*    */     //   61	44	8	a	Object
/*    */   }
/*    */   
/*    */   public Object doInvoke(Object paramObject1, Object paramObject2)
/*    */   {
/* 35 */     paramObject1 = null;paramObject2 = null;return invokeStatic(paramObject1, (ISeq)paramObject2); } public static final Var const__4 = (Var)RT.var("clojure.core", "count"); public static final Var const__2 = (Var)RT.var("clojure.core", "+");
/*    */   
/*    */   public int getRequiredArity()
/*    */   {
/*    */     return 1;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\java\shell$aconcat.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */