/*     */ package clojure.java;
/*     */ 
/*     */ import clojure.lang.AFunction;
/*     */ 
/*     */ public final class io$fn__9556
/*     */   extends AFunction
/*     */ {
/*     */   /* Error */
/*     */   public static Object invokeStatic(Object input, Object output, Object opts)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: getstatic 17	java/lang/Character:TYPE	Ljava/lang/Class;
/*     */     //   3: aload_2
/*     */     //   4: invokestatic 22	clojure/java/io$buffer_size:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   7: invokestatic 27	clojure/core$make_array:invokeStatic	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   10: astore_3
/*     */     //   11: new 29	java/io/InputStreamReader
/*     */     //   14: dup
/*     */     //   15: aload_0
/*     */     //   16: aconst_null
/*     */     //   17: astore_0
/*     */     //   18: checkcast 31	java/io/InputStream
/*     */     //   21: aload_2
/*     */     //   22: aconst_null
/*     */     //   23: astore_2
/*     */     //   24: invokestatic 34	clojure/java/io$encoding:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   27: checkcast 36	java/lang/String
/*     */     //   30: invokespecial 39	java/io/InputStreamReader:<init>	(Ljava/io/InputStream;Ljava/lang/String;)V
/*     */     //   33: astore 4
/*     */     //   35: aload 4
/*     */     //   37: checkcast 29	java/io/InputStreamReader
/*     */     //   40: aload_3
/*     */     //   41: checkcast 41	[C
/*     */     //   44: lconst_0
/*     */     //   45: invokestatic 47	clojure/lang/RT:intCast	(J)I
/*     */     //   48: aload_3
/*     */     //   49: checkcast 41	[C
/*     */     //   52: arraylength
/*     */     //   53: invokevirtual 51	java/io/InputStreamReader:read	([CII)I
/*     */     //   56: istore 5
/*     */     //   58: iload 5
/*     */     //   60: i2l
/*     */     //   61: lconst_0
/*     */     //   62: lcmp
/*     */     //   63: ifle +29 -> 92
/*     */     //   66: aload_1
/*     */     //   67: checkcast 53	java/io/Writer
/*     */     //   70: aload_3
/*     */     //   71: checkcast 41	[C
/*     */     //   74: lconst_0
/*     */     //   75: invokestatic 47	clojure/lang/RT:intCast	(J)I
/*     */     //   78: iload 5
/*     */     //   80: invokevirtual 57	java/io/Writer:write	([CII)V
/*     */     //   83: aconst_null
/*     */     //   84: pop
/*     */     //   85: goto -50 -> 35
/*     */     //   88: goto +5 -> 93
/*     */     //   91: pop
/*     */     //   92: aconst_null
/*     */     //   93: areturn
/*     */     // Line number table:
/*     */     //   Java source line #310	-> byte code offset #0
/*     */     //   Java source line #311	-> byte code offset #0
/*     */     //   Java source line #314	-> byte code offset #52
/*     */     //   Java source line #314	-> byte code offset #53
/*     */     //   Java source line #315	-> byte code offset #58
/*     */     //   Java source line #315	-> byte code offset #58
/*     */     //   Java source line #316	-> byte code offset #80
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	93	0	input	Object
/*     */     //   0	93	1	output	Object
/*     */     //   0	93	2	opts	Object
/*     */     //   11	82	3	buffer	Object
/*     */     //   35	58	4	in	Object
/*     */     //   58	35	5	size	int
/*     */   }
/*     */   
/*     */   public Object invoke(Object paramObject1, Object paramObject2, Object paramObject3)
/*     */   {
/* 310 */     paramObject1 = null;paramObject2 = null;paramObject3 = null;return invokeStatic(paramObject1, paramObject2, paramObject3);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\java\io$fn__9556.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */