/*    */ package clojure.java;
/*    */ 
/*    */ import clojure.lang.AFunction;
/*    */ import clojure.lang.RT;
/*    */ import clojure.lang.Var;
/*    */ 
/*    */ public final class shell$stream_to_bytes
/*    */   extends AFunction
/*    */ {
/*    */   /* Error */
/*    */   public static Object invokeStatic(Object in)
/*    */   {
/*    */     // Byte code:
/*    */     //   0: new 13	java/io/ByteArrayOutputStream
/*    */     //   3: dup
/*    */     //   4: invokespecial 14	java/io/ByteArrayOutputStream:<init>	()V
/*    */     //   7: astore_1
/*    */     //   8: getstatic 18	clojure/java/shell$stream_to_bytes:const__0	Lclojure/lang/Var;
/*    */     //   11: invokevirtual 24	clojure/lang/Var:getRawRoot	()Ljava/lang/Object;
/*    */     //   14: checkcast 26	clojure/lang/IFn
/*    */     //   17: aload_0
/*    */     //   18: aconst_null
/*    */     //   19: astore_0
/*    */     //   20: aload_1
/*    */     //   21: invokeinterface 30 3 0
/*    */     //   26: pop
/*    */     //   27: aload_1
/*    */     //   28: checkcast 13	java/io/ByteArrayOutputStream
/*    */     //   31: invokevirtual 34	java/io/ByteArrayOutputStream:toByteArray	()[B
/*    */     //   34: astore_2
/*    */     //   35: aload_1
/*    */     //   36: aconst_null
/*    */     //   37: astore_1
/*    */     //   38: checkcast 13	java/io/ByteArrayOutputStream
/*    */     //   41: invokevirtual 37	java/io/ByteArrayOutputStream:close	()V
/*    */     //   44: aconst_null
/*    */     //   45: pop
/*    */     //   46: goto +17 -> 63
/*    */     //   49: astore_3
/*    */     //   50: aload_1
/*    */     //   51: aconst_null
/*    */     //   52: astore_1
/*    */     //   53: checkcast 13	java/io/ByteArrayOutputStream
/*    */     //   56: invokevirtual 37	java/io/ByteArrayOutputStream:close	()V
/*    */     //   59: aconst_null
/*    */     //   60: pop
/*    */     //   61: aload_3
/*    */     //   62: athrow
/*    */     //   63: aload_2
/*    */     //   64: areturn
/*    */     // Line number table:
/*    */     //   Java source line #60	-> byte code offset #0
/*    */     //   Java source line #63	-> byte code offset #14
/*    */     //   Java source line #63	-> byte code offset #21
/*    */     //   Java source line #64	-> byte code offset #31
/*    */     //   Java source line #62	-> byte code offset #41
/*    */     //   Java source line #62	-> byte code offset #56
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	signature
/*    */     //   0	64	0	in	Object
/*    */     //   7	46	1	bout	Object
/*    */     //   34	30	2	arrayOfByte	byte[]
/*    */     //   49	13	3	localObject1	Object
/*    */     // Exception table:
/*    */     //   from	to	target	type
/*    */     //   8	35	49	finally
/*    */   }
/*    */   
/*    */   public Object invoke(Object paramObject)
/*    */   {
/* 60 */     paramObject = null;return invokeStatic(paramObject); } public static final Var const__0 = (Var)RT.var("clojure.java.io", "copy");
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\java\shell$stream_to_bytes.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */