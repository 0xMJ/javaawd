/*     */ package clojure.java;
/*     */ 
/*     */ import clojure.lang.AFunction;
/*     */ import clojure.lang.RT;
/*     */ import clojure.lang.Var;
/*     */ 
/*     */ public final class io$as_relative_path
/*     */   extends AFunction
/*     */ {
/*     */   private static Class __cached_class__0;
/*     */   
/*     */   /* Error */
/*     */   public static Object invokeStatic(Object x)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: aconst_null
/*     */     //   2: astore_0
/*     */     //   3: dup
/*     */     //   4: invokestatic 19	clojure/lang/Util:classOf	(Ljava/lang/Object;)Ljava/lang/Class;
/*     */     //   7: getstatic 21	clojure/java/io$as_relative_path:__cached_class__0	Ljava/lang/Class;
/*     */     //   10: if_acmpeq +17 -> 27
/*     */     //   13: dup
/*     */     //   14: instanceof 23
/*     */     //   17: ifne +25 -> 42
/*     */     //   20: dup
/*     */     //   21: invokestatic 19	clojure/lang/Util:classOf	(Ljava/lang/Object;)Ljava/lang/Class;
/*     */     //   24: putstatic 21	clojure/java/io$as_relative_path:__cached_class__0	Ljava/lang/Class;
/*     */     //   27: getstatic 27	clojure/java/io$as_relative_path:const__0	Lclojure/lang/Var;
/*     */     //   30: invokevirtual 33	clojure/lang/Var:getRawRoot	()Ljava/lang/Object;
/*     */     //   33: swap
/*     */     //   34: invokeinterface 38 2 0
/*     */     //   39: goto +8 -> 47
/*     */     //   42: invokeinterface 41 1 0
/*     */     //   47: astore_1
/*     */     //   48: aload_1
/*     */     //   49: checkcast 43	java/io/File
/*     */     //   52: invokevirtual 47	java/io/File:isAbsolute	()Z
/*     */     //   55: ifeq +39 -> 94
/*     */     //   58: new 49	java/lang/IllegalArgumentException
/*     */     //   61: dup
/*     */     //   62: aload_1
/*     */     //   63: aconst_null
/*     */     //   64: astore_1
/*     */     //   65: iconst_1
/*     */     //   66: anewarray 51	java/lang/Object
/*     */     //   69: dup
/*     */     //   70: iconst_0
/*     */     //   71: ldc 53
/*     */     //   73: aastore
/*     */     //   74: invokestatic 59	clojure/lang/ArraySeq:create	([Ljava/lang/Object;)Lclojure/lang/ArraySeq;
/*     */     //   77: invokestatic 64	clojure/core$str:invokeStatic	(Ljava/lang/Object;Lclojure/lang/ISeq;)Ljava/lang/Object;
/*     */     //   80: checkcast 66	java/lang/String
/*     */     //   83: invokespecial 69	java/lang/IllegalArgumentException:<init>	(Ljava/lang/String;)V
/*     */     //   86: checkcast 71	java/lang/Throwable
/*     */     //   89: athrow
/*     */     //   90: goto +13 -> 103
/*     */     //   93: pop
/*     */     //   94: aload_1
/*     */     //   95: aconst_null
/*     */     //   96: astore_1
/*     */     //   97: checkcast 43	java/io/File
/*     */     //   100: invokevirtual 75	java/io/File:getPath	()Ljava/lang/String;
/*     */     //   103: areturn
/*     */     // Line number table:
/*     */     //   Java source line #408	-> byte code offset #0
/*     */     //   Java source line #413	-> byte code offset #0
/*     */     //   Java source line #413	-> byte code offset #34
/*     */     //   Java source line #414	-> byte code offset #48
/*     */     //   Java source line #414	-> byte code offset #52
/*     */     //   Java source line #416	-> byte code offset #100
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	103	0	x	Object
/*     */     //   48	55	1	f	Object
/*     */   }
/*     */   
/*     */   public Object invoke(Object paramObject)
/*     */   {
/* 408 */     paramObject = null;return invokeStatic(paramObject); } public static final Var const__0 = (Var)RT.var("clojure.java.io", "as-file");
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\java\io$as_relative_path.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */