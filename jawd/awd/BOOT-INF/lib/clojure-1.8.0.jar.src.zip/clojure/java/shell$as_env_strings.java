/*    */ package clojure.java;
/*    */ 
/*    */ import clojure.lang.AFunction;
/*    */ import clojure.lang.RT;
/*    */ 
/*    */ public final class shell$as_env_strings
/*    */   extends AFunction
/*    */ {
/*    */   /* Error */
/*    */   public static Object invokeStatic(Object arg)
/*    */   {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: aconst_null
/*    */     //   2: invokestatic 17	clojure/lang/Util:identical	(Ljava/lang/Object;Ljava/lang/Object;)Z
/*    */     //   5: ifeq +8 -> 13
/*    */     //   8: aconst_null
/*    */     //   9: goto +62 -> 71
/*    */     //   12: pop
/*    */     //   13: aload_0
/*    */     //   14: invokestatic 21	clojure/core$map_QMARK___4367:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   17: dup
/*    */     //   18: ifnull +31 -> 49
/*    */     //   21: getstatic 27	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*    */     //   24: if_acmpeq +26 -> 50
/*    */     //   27: getstatic 31	clojure/java/shell$as_env_strings:const__3	Ljava/lang/Object;
/*    */     //   30: new 33	clojure/java/shell$as_env_strings$fn__9698
/*    */     //   33: dup
/*    */     //   34: invokespecial 34	clojure/java/shell$as_env_strings$fn__9698:<init>	()V
/*    */     //   37: aload_0
/*    */     //   38: aconst_null
/*    */     //   39: astore_0
/*    */     //   40: invokestatic 39	clojure/core$map:invokeStatic	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   43: invokestatic 42	clojure/core$into_array:invokeStatic	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   46: goto +25 -> 71
/*    */     //   49: pop
/*    */     //   50: getstatic 45	java/lang/Boolean:TRUE	Ljava/lang/Boolean;
/*    */     //   53: dup
/*    */     //   54: ifnull +15 -> 69
/*    */     //   57: getstatic 27	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*    */     //   60: if_acmpeq +10 -> 70
/*    */     //   63: aload_0
/*    */     //   64: aconst_null
/*    */     //   65: astore_0
/*    */     //   66: goto +5 -> 71
/*    */     //   69: pop
/*    */     //   70: aconst_null
/*    */     //   71: areturn
/*    */     // Line number table:
/*    */     //   Java source line #52	-> byte code offset #0
/*    */     //   Java source line #55	-> byte code offset #0
/*    */     //   Java source line #56	-> byte code offset #2
/*    */     //   Java source line #55	-> byte code offset #13
/*    */     //   Java source line #55	-> byte code offset #50
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	signature
/*    */     //   0	71	0	arg	Object
/*    */   }
/*    */   
/*    */   public Object invoke(Object paramObject)
/*    */   {
/* 52 */     paramObject = null;return invokeStatic(paramObject); } public static final Object const__3 = RT.classForName("java.lang.String");
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\java\shell$as_env_strings.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */