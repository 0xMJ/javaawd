/*     */ package clojure.java;
/*     */ 
/*     */ import clojure.lang.AFunction;
/*     */ import clojure.lang.RT;
/*     */ import clojure.lang.Var;
/*     */ 
/*     */ public final class io$fn__9568
/*     */   extends AFunction
/*     */ {
/*     */   /* Error */
/*     */   public static Object invokeStatic(Object input, Object output, Object opts)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: new 13	java/io/FileInputStream
/*     */     //   3: dup
/*     */     //   4: aload_0
/*     */     //   5: aconst_null
/*     */     //   6: astore_0
/*     */     //   7: checkcast 15	java/io/File
/*     */     //   10: invokespecial 18	java/io/FileInputStream:<init>	(Ljava/io/File;)V
/*     */     //   13: astore_3
/*     */     //   14: getstatic 22	clojure/java/io$fn__9568:const__0	Lclojure/lang/Var;
/*     */     //   17: invokevirtual 28	clojure/lang/Var:getRawRoot	()Ljava/lang/Object;
/*     */     //   20: checkcast 30	clojure/lang/IFn
/*     */     //   23: aload_3
/*     */     //   24: aload_1
/*     */     //   25: aconst_null
/*     */     //   26: astore_1
/*     */     //   27: aload_2
/*     */     //   28: aconst_null
/*     */     //   29: astore_2
/*     */     //   30: invokeinterface 33 4 0
/*     */     //   35: astore 4
/*     */     //   37: aload_3
/*     */     //   38: aconst_null
/*     */     //   39: astore_3
/*     */     //   40: checkcast 13	java/io/FileInputStream
/*     */     //   43: invokevirtual 36	java/io/FileInputStream:close	()V
/*     */     //   46: aconst_null
/*     */     //   47: pop
/*     */     //   48: goto +19 -> 67
/*     */     //   51: astore 5
/*     */     //   53: aload_3
/*     */     //   54: aconst_null
/*     */     //   55: astore_3
/*     */     //   56: checkcast 13	java/io/FileInputStream
/*     */     //   59: invokevirtual 36	java/io/FileInputStream:close	()V
/*     */     //   62: aconst_null
/*     */     //   63: pop
/*     */     //   64: aload 5
/*     */     //   66: athrow
/*     */     //   67: aload 4
/*     */     //   69: areturn
/*     */     // Line number table:
/*     */     //   Java source line #350	-> byte code offset #0
/*     */     //   Java source line #352	-> byte code offset #20
/*     */     //   Java source line #352	-> byte code offset #30
/*     */     //   Java source line #351	-> byte code offset #43
/*     */     //   Java source line #351	-> byte code offset #59
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	69	0	input	Object
/*     */     //   0	69	1	output	Object
/*     */     //   0	69	2	opts	Object
/*     */     //   13	43	3	in	Object
/*     */     //   35	33	4	localObject1	Object
/*     */     //   51	14	5	localObject2	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   14	37	51	finally
/*     */   }
/*     */   
/*     */   public Object invoke(Object paramObject1, Object paramObject2, Object paramObject3)
/*     */   {
/* 350 */     paramObject1 = null;paramObject2 = null;paramObject3 = null;return invokeStatic(paramObject1, paramObject2, paramObject3); } public static final Var const__0 = (Var)RT.var("clojure.java.io", "do-copy");
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\java\io$fn__9568.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */