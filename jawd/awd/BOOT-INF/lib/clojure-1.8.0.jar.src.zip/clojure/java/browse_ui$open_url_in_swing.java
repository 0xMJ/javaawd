/*    */ package clojure.java;
/*    */ 
/*    */ import clojure.lang.RT;
/*    */ import clojure.lang.Reflector;
/*    */ import java.awt.Window;
/*    */ import javax.swing.JEditorPane;
/*    */ import javax.swing.JFrame;
/*    */ import javax.swing.event.HyperlinkListener;
/*    */ import javax.swing.text.JTextComponent;
/*    */ 
/*    */ public final class browse_ui$open_url_in_swing extends clojure.lang.AFunction
/*    */ {
/*    */   public Object invoke(Object paramObject)
/*    */   {
/* 15 */     paramObject = null;return invokeStatic(paramObject); } public static Object invokeStatic(Object url) { Object[] tmp9_6 = new Object[1];url = null;tmp9_6[0] = url;Object htmlpane = Reflector.invokeConstructor(RT.classForName("javax.swing.JEditorPane"), tmp9_6);((JTextComponent)htmlpane)
/*    */     
/*    */ 
/* 18 */       .setEditable(((Boolean)Boolean.FALSE).booleanValue());null;Object p__5959__auto__9762 = new clojure.java.browse_ui.proxy.java.lang.Object.HyperlinkListener.60e7c888();clojure.core.init_proxy.invokeStatic(p__5959__auto__9762, RT.mapUniqueKeys(new Object[] { "hyperlinkUpdate", new browse_ui.open_url_in_swing.fn__9758(htmlpane) }));p__5959__auto__9762 = null;((JEditorPane)htmlpane)
/* 19 */       .addHyperlinkListener((HyperlinkListener)p__5959__auto__9762);null;Object G__9760 = new JFrame();htmlpane = null;((JFrame)G__9760)
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 26 */       .setContentPane((java.awt.Container)new javax.swing.JScrollPane((java.awt.Component)htmlpane));null;((Window)G__9760).setBounds(RT.intCast(32L), RT.intCast(32L), RT.intCast(700L), RT.intCast(900L));null;((Window)G__9760).show();null;G__9760 = null;return G__9760;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\java\browse_ui$open_url_in_swing.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */