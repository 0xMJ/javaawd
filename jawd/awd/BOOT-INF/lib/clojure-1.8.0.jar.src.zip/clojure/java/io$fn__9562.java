/*     */ package clojure.java;
/*     */ 
/*     */ import clojure.lang.AFunction;
/*     */ 
/*     */ public final class io$fn__9562
/*     */   extends AFunction
/*     */ {
/*     */   /* Error */
/*     */   public static Object invokeStatic(Object input, Object output, Object opts)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: getstatic 17	java/lang/Character:TYPE	Ljava/lang/Class;
/*     */     //   3: aload_2
/*     */     //   4: aconst_null
/*     */     //   5: astore_2
/*     */     //   6: invokestatic 22	clojure/java/io$buffer_size:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   9: invokestatic 27	clojure/core$make_array:invokeStatic	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   12: astore_3
/*     */     //   13: aload_0
/*     */     //   14: checkcast 29	java/io/Reader
/*     */     //   17: aload_3
/*     */     //   18: checkcast 31	[C
/*     */     //   21: invokevirtual 35	java/io/Reader:read	([C)I
/*     */     //   24: istore 4
/*     */     //   26: iload 4
/*     */     //   28: i2l
/*     */     //   29: lconst_0
/*     */     //   30: lcmp
/*     */     //   31: ifle +29 -> 60
/*     */     //   34: aload_1
/*     */     //   35: checkcast 37	java/io/Writer
/*     */     //   38: aload_3
/*     */     //   39: checkcast 31	[C
/*     */     //   42: lconst_0
/*     */     //   43: invokestatic 43	clojure/lang/RT:intCast	(J)I
/*     */     //   46: iload 4
/*     */     //   48: invokevirtual 47	java/io/Writer:write	([CII)V
/*     */     //   51: aconst_null
/*     */     //   52: pop
/*     */     //   53: goto -40 -> 13
/*     */     //   56: goto +5 -> 61
/*     */     //   59: pop
/*     */     //   60: aconst_null
/*     */     //   61: areturn
/*     */     // Line number table:
/*     */     //   Java source line #334	-> byte code offset #0
/*     */     //   Java source line #335	-> byte code offset #0
/*     */     //   Java source line #337	-> byte code offset #21
/*     */     //   Java source line #338	-> byte code offset #26
/*     */     //   Java source line #338	-> byte code offset #26
/*     */     //   Java source line #339	-> byte code offset #48
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	61	0	input	Object
/*     */     //   0	61	1	output	Object
/*     */     //   0	61	2	opts	Object
/*     */     //   13	48	3	buffer	Object
/*     */     //   26	35	4	size	int
/*     */   }
/*     */   
/*     */   public Object invoke(Object paramObject1, Object paramObject2, Object paramObject3)
/*     */   {
/* 334 */     paramObject1 = null;paramObject2 = null;paramObject3 = null;return invokeStatic(paramObject1, paramObject2, paramObject3);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\java\io$fn__9562.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */