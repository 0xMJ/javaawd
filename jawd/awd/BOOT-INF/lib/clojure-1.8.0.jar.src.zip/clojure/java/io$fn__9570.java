/*     */ package clojure.java;
/*     */ 
/*     */ import clojure.lang.AFunction;
/*     */ 
/*     */ public final class io$fn__9570
/*     */   extends AFunction
/*     */ {
/*     */   /* Error */
/*     */   public static Object invokeStatic(Object input, Object output, Object opts)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: new 13	java/io/FileInputStream
/*     */     //   3: dup
/*     */     //   4: aload_0
/*     */     //   5: aconst_null
/*     */     //   6: astore_0
/*     */     //   7: checkcast 15	java/io/File
/*     */     //   10: invokespecial 18	java/io/FileInputStream:<init>	(Ljava/io/File;)V
/*     */     //   13: checkcast 13	java/io/FileInputStream
/*     */     //   16: invokevirtual 22	java/io/FileInputStream:getChannel	()Ljava/nio/channels/FileChannel;
/*     */     //   19: astore_3
/*     */     //   20: new 24	java/io/FileOutputStream
/*     */     //   23: dup
/*     */     //   24: aload_1
/*     */     //   25: aconst_null
/*     */     //   26: astore_1
/*     */     //   27: checkcast 15	java/io/File
/*     */     //   30: invokespecial 25	java/io/FileOutputStream:<init>	(Ljava/io/File;)V
/*     */     //   33: checkcast 24	java/io/FileOutputStream
/*     */     //   36: invokevirtual 26	java/io/FileOutputStream:getChannel	()Ljava/nio/channels/FileChannel;
/*     */     //   39: astore 4
/*     */     //   41: aload_3
/*     */     //   42: checkcast 28	java/nio/channels/FileChannel
/*     */     //   45: invokevirtual 32	java/nio/channels/FileChannel:size	()J
/*     */     //   48: lstore 5
/*     */     //   50: lconst_0
/*     */     //   51: lstore 7
/*     */     //   53: aload_3
/*     */     //   54: checkcast 28	java/nio/channels/FileChannel
/*     */     //   57: lload 7
/*     */     //   59: lload 5
/*     */     //   61: lload 7
/*     */     //   63: invokestatic 38	clojure/lang/Numbers:minus	(JJ)J
/*     */     //   66: aload 4
/*     */     //   68: checkcast 40	java/nio/channels/WritableByteChannel
/*     */     //   71: invokevirtual 44	java/nio/channels/FileChannel:transferTo	(JJLjava/nio/channels/WritableByteChannel;)J
/*     */     //   74: lstore 9
/*     */     //   76: lload 7
/*     */     //   78: lload 9
/*     */     //   80: invokestatic 47	clojure/lang/Numbers:add	(JJ)J
/*     */     //   83: lstore 11
/*     */     //   85: lload 11
/*     */     //   87: lload 5
/*     */     //   89: lcmp
/*     */     //   90: ifge +14 -> 104
/*     */     //   93: lload 11
/*     */     //   95: lstore 7
/*     */     //   97: goto -44 -> 53
/*     */     //   100: goto +5 -> 105
/*     */     //   103: pop
/*     */     //   104: aconst_null
/*     */     //   105: astore 13
/*     */     //   107: aload 4
/*     */     //   109: aconst_null
/*     */     //   110: astore 4
/*     */     //   112: checkcast 53	java/nio/channels/spi/AbstractInterruptibleChannel
/*     */     //   115: invokevirtual 56	java/nio/channels/spi/AbstractInterruptibleChannel:close	()V
/*     */     //   118: aconst_null
/*     */     //   119: pop
/*     */     //   120: goto +21 -> 141
/*     */     //   123: astore 14
/*     */     //   125: aload 4
/*     */     //   127: aconst_null
/*     */     //   128: astore 4
/*     */     //   130: checkcast 53	java/nio/channels/spi/AbstractInterruptibleChannel
/*     */     //   133: invokevirtual 56	java/nio/channels/spi/AbstractInterruptibleChannel:close	()V
/*     */     //   136: aconst_null
/*     */     //   137: pop
/*     */     //   138: aload 14
/*     */     //   140: athrow
/*     */     //   141: aload 13
/*     */     //   143: astore 15
/*     */     //   145: aload_3
/*     */     //   146: aconst_null
/*     */     //   147: astore_3
/*     */     //   148: checkcast 53	java/nio/channels/spi/AbstractInterruptibleChannel
/*     */     //   151: invokevirtual 56	java/nio/channels/spi/AbstractInterruptibleChannel:close	()V
/*     */     //   154: aconst_null
/*     */     //   155: pop
/*     */     //   156: goto +19 -> 175
/*     */     //   159: astore 16
/*     */     //   161: aload_3
/*     */     //   162: aconst_null
/*     */     //   163: astore_3
/*     */     //   164: checkcast 53	java/nio/channels/spi/AbstractInterruptibleChannel
/*     */     //   167: invokevirtual 56	java/nio/channels/spi/AbstractInterruptibleChannel:close	()V
/*     */     //   170: aconst_null
/*     */     //   171: pop
/*     */     //   172: aload 16
/*     */     //   174: athrow
/*     */     //   175: aload 15
/*     */     //   177: areturn
/*     */     // Line number table:
/*     */     //   Java source line #354	-> byte code offset #0
/*     */     //   Java source line #355	-> byte code offset #16
/*     */     //   Java source line #356	-> byte code offset #36
/*     */     //   Java source line #357	-> byte code offset #45
/*     */     //   Java source line #359	-> byte code offset #63
/*     */     //   Java source line #359	-> byte code offset #71
/*     */     //   Java source line #360	-> byte code offset #80
/*     */     //   Java source line #361	-> byte code offset #85
/*     */     //   Java source line #361	-> byte code offset #85
/*     */     //   Java source line #355	-> byte code offset #115
/*     */     //   Java source line #355	-> byte code offset #133
/*     */     //   Java source line #355	-> byte code offset #151
/*     */     //   Java source line #355	-> byte code offset #167
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	177	0	input	Object
/*     */     //   0	177	1	output	Object
/*     */     //   0	177	2	opts	Object
/*     */     //   20	157	3	in	Object
/*     */     //   41	102	4	out	Object
/*     */     //   50	55	5	sz	long
/*     */     //   53	52	7	pos	long
/*     */     //   76	29	9	bytes_xferred	long
/*     */     //   85	20	11	pos	long
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   41	107	123	finally
/*     */     //   20	145	159	finally
/*     */   }
/*     */   
/*     */   public Object invoke(Object paramObject1, Object paramObject2, Object paramObject3)
/*     */   {
/* 354 */     paramObject1 = null;paramObject2 = null;paramObject3 = null;return invokeStatic(paramObject1, paramObject2, paramObject3);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\java\io$fn__9570.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */