/*    */ package clojure.java;
/*    */ 
/*    */ import clojure.lang.RT;
/*    */ 
/*    */ public class shell__init { public static final clojure.lang.Var const__0;
/*    */   public static final clojure.lang.AFn const__1;
/*    */   public static final clojure.lang.AFn const__4;
/*    */   
/*  9 */   public static void load() { if (((clojure.lang.Symbol)const__1).equals(const__5)) { tmpTernaryOp = null; break label88; ((clojure.lang.IFn)new shell.loading__5569__auto____9687()).invoke(); } else { clojure.lang.LockingTransaction.runInTransaction((java.util.concurrent.Callable)new shell.fn__9689()); } label88: tmp95_92 = const__6.setDynamic(true); tmp95_92.setMeta((clojure.lang.IPersistentMap)const__13);tmp95_92.bindRoot(null); clojure.lang.Var tmp117_114 = const__14.setDynamic(true);tmp117_114.setMeta((clojure.lang.IPersistentMap)const__16);tmp117_114.bindRoot(null); clojure.lang.Var tmp135_132 = const__17;tmp135_132.setMeta((clojure.lang.IPersistentMap)const__22);tmp135_132.bindRoot(new shell.with_sh_dir());((clojure.lang.Var)const__17)
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 21 */       .setMacro(); clojure.lang.Var tmp172_169 = const__23;tmp172_169.setMeta((clojure.lang.IPersistentMap)const__26);tmp172_169.bindRoot(new shell.with_sh_env());((clojure.lang.Var)const__23)
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 28 */       .setMacro(); clojure.lang.Var tmp209_206 = const__27;tmp209_206.setMeta((clojure.lang.IPersistentMap)const__31);tmp209_206.bindRoot(new shell.aconcat()); clojure.lang.Var tmp233_230 = const__32;tmp233_230.setMeta((clojure.lang.IPersistentMap)const__35);tmp233_230.bindRoot(new shell.parse_args()); clojure.lang.Var tmp257_254 = const__36;tmp257_254.setMeta((clojure.lang.IPersistentMap)const__40);tmp257_254.bindRoot(new shell.as_env_strings()); clojure.lang.Var tmp281_278 = const__41;tmp281_278.setMeta((clojure.lang.IPersistentMap)const__44);tmp281_278.bindRoot(new shell.stream_to_bytes()); clojure.lang.Var tmp305_302 = const__45;tmp305_302.setMeta((clojure.lang.IPersistentMap)const__48);tmp305_302.bindRoot(new shell.stream_to_string()); clojure.lang.Var tmp329_326 = const__49;tmp329_326.setMeta((clojure.lang.IPersistentMap)const__52);tmp329_326.bindRoot(new shell.stream_to_enc()); clojure.lang.Var tmp353_350 = const__53;tmp353_350.setMeta((clojure.lang.IPersistentMap)const__56);tmp353_350.bindRoot(new shell.sh());
/*    */   }
/*    */   
/*    */   public static final clojure.lang.AFn const__5;
/*    */   public static final clojure.lang.Var const__6;
/*    */   public static final clojure.lang.AFn const__13;
/*    */   public static final clojure.lang.Var const__14;
/*    */   public static final clojure.lang.AFn const__16;
/*    */   public static final clojure.lang.Var const__17;
/*    */   public static final clojure.lang.AFn const__22;
/*    */   public static final clojure.lang.Var const__23;
/*    */   public static final clojure.lang.AFn const__26;
/*    */   public static final clojure.lang.Var const__27;
/*    */   public static final clojure.lang.AFn const__31;
/*    */   public static final clojure.lang.Var const__32;
/*    */   public static final clojure.lang.AFn const__35;
/*    */   public static final clojure.lang.Var const__36;
/*    */   public static final clojure.lang.AFn const__40;
/*    */   public static final clojure.lang.Var const__41;
/*    */   public static final clojure.lang.AFn const__44;
/*    */   public static final clojure.lang.Var const__45;
/*    */   public static final clojure.lang.AFn const__48;
/*    */   public static final clojure.lang.Var const__49;
/*    */   public static final clojure.lang.AFn const__52;
/*    */   public static final clojure.lang.Var const__53;
/*    */   public static final clojure.lang.AFn const__56;
/*    */   public static void __init0()
/*    */   {
/*    */     const__0 = (clojure.lang.Var)RT.var("clojure.core", "in-ns");
/*    */     const__1 = (clojure.lang.AFn)((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "clojure.java.shell")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "author"), "Chris Houser, Stuart Halloway", RT.keyword(null, "doc"), "Conveniently launch a sub-process providing its stdin and\ncollecting its stdout" }));
/*    */     const__4 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "author"), "Chris Houser, Stuart Halloway", RT.keyword(null, "doc"), "Conveniently launch a sub-process providing its stdin and\ncollecting its stdout" });
/*    */     const__5 = (clojure.lang.AFn)clojure.lang.Symbol.intern(null, "clojure.core");
/*    */     const__6 = (clojure.lang.Var)RT.var("clojure.java.shell", "*sh-dir*");
/*    */     const__13 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "dynamic"), Boolean.TRUE, RT.keyword(null, "line"), Integer.valueOf(18), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/java/shell.clj" });
/*    */     const__14 = (clojure.lang.Var)RT.var("clojure.java.shell", "*sh-env*");
/*    */     const__16 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "dynamic"), Boolean.TRUE, RT.keyword(null, "line"), Integer.valueOf(19), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/java/shell.clj" });
/*    */     const__17 = (clojure.lang.Var)RT.var("clojure.java.shell", "with-sh-dir");
/*    */     const__22 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "dir"), clojure.lang.Symbol.intern(null, "&"), clojure.lang.Symbol.intern(null, "forms")) })), RT.keyword(null, "doc"), "Sets the directory for use with sh, see sh for details.", RT.keyword(null, "added"), "1.2", RT.keyword(null, "line"), Integer.valueOf(21), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/java/shell.clj" });
/*    */     const__23 = (clojure.lang.Var)RT.var("clojure.java.shell", "with-sh-env");
/*    */     const__26 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "env"), clojure.lang.Symbol.intern(null, "&"), clojure.lang.Symbol.intern(null, "forms")) })), RT.keyword(null, "doc"), "Sets the environment for use with sh, see sh for details.", RT.keyword(null, "added"), "1.2", RT.keyword(null, "line"), Integer.valueOf(28), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/java/shell.clj" });
/*    */     const__27 = (clojure.lang.Var)RT.var("clojure.java.shell", "aconcat");
/*    */     const__31 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "type"), clojure.lang.Symbol.intern(null, "&"), clojure.lang.Symbol.intern(null, "xs")) })), RT.keyword(null, "doc"), "Concatenates arrays of given type.", RT.keyword(null, "line"), Integer.valueOf(35), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/java/shell.clj" });
/*    */     const__32 = (clojure.lang.Var)RT.var("clojure.java.shell", "parse-args");
/*    */     const__35 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "args")) })), RT.keyword(null, "line"), Integer.valueOf(45), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/java/shell.clj" });
/*    */     const__36 = (clojure.lang.Var)RT.var("clojure.java.shell", "as-env-strings");
/*    */     const__40 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "tag"), "[Ljava.lang.String;", RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "arg")) })), RT.keyword(null, "doc"), "Helper so that callers can pass a Clojure map for the :env to sh.", RT.keyword(null, "line"), Integer.valueOf(52), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/java/shell.clj" });
/*    */     const__41 = (clojure.lang.Var)RT.var("clojure.java.shell", "stream-to-bytes");
/*    */     const__44 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "in")) })), RT.keyword(null, "line"), Integer.valueOf(60), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/java/shell.clj" });
/*    */     const__45 = (clojure.lang.Var)RT.var("clojure.java.shell", "stream-to-string");
/*    */     const__48 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "in")), clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "in"), clojure.lang.Symbol.intern(null, "enc")) })), RT.keyword(null, "line"), Integer.valueOf(66), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/java/shell.clj" });
/*    */     const__49 = (clojure.lang.Var)RT.var("clojure.java.shell", "stream-to-enc");
/*    */     const__52 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "stream"), clojure.lang.Symbol.intern(null, "enc")) })), RT.keyword(null, "line"), Integer.valueOf(73), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/java/shell.clj" });
/*    */     const__53 = (clojure.lang.Var)RT.var("clojure.java.shell", "sh");
/*    */     const__56 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "&"), clojure.lang.Symbol.intern(null, "args")) })), RT.keyword(null, "doc"), "Passes the given strings to Runtime.exec() to launch a sub-process.\n\n  Options are\n\n  :in      may be given followed by any legal input source for\n           clojure.java.io/copy, e.g. InputStream, Reader, File, byte[],\n           or String, to be fed to the sub-process's stdin.\n  :in-enc  option may be given followed by a String, used as a character\n           encoding name (for example \"UTF-8\" or \"ISO-8859-1\") to\n           convert the input string specified by the :in option to the\n           sub-process's stdin.  Defaults to UTF-8.\n           If the :in option provides a byte array, then the bytes are passed\n           unencoded, and this option is ignored.\n  :out-enc option may be given followed by :bytes or a String. If a\n           String is given, it will be used as a character encoding\n           name (for example \"UTF-8\" or \"ISO-8859-1\") to convert\n           the sub-process's stdout to a String which is returned.\n           If :bytes is given, the sub-process's stdout will be stored\n           in a byte array and returned.  Defaults to UTF-8.\n  :env     override the process env with a map (or the underlying Java\n           String[] if you are a masochist).\n  :dir     override the process dir with a String or java.io.File.\n\n  You can bind :env or :dir for multiple operations using with-sh-env\n  and with-sh-dir.\n\n  sh returns a map of\n    :exit => sub-process's exit code\n    :out  => sub-process's stdout (as byte[] or String)\n    :err  => sub-process's stderr (String via platform default encoding)", RT.keyword(null, "added"), "1.2", RT.keyword(null, "line"), Integer.valueOf(79), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/java/shell.clj" });
/*    */   }
/*    */   
/*    */   static
/*    */   {
/*    */     __init0();
/*    */     clojure.lang.Compiler.pushNSandLoader(RT.classForName("clojure.java.shell__init").getClassLoader());
/*    */     try
/*    */     {
/*    */       load();
/*    */       clojure.lang.Var.popThreadBindings();
/*    */     }
/*    */     finally
/*    */     {
/*    */       clojure.lang.Var.popThreadBindings();
/*    */       throw finally;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\java\shell__init.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */