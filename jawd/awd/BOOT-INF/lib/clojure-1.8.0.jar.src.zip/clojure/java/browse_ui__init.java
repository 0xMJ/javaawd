/*   */ package clojure.java;
/*   */ 
/*   */ import clojure.lang.RT;
/*   */ 
/*   */ public class browse_ui__init { public static final clojure.lang.Var const__0;
/*   */   public static final clojure.lang.AFn const__1;
/*   */   public static final clojure.lang.AFn const__4;
/*   */   
/* 9 */   public static void load() { if (((clojure.lang.Symbol)const__1).equals(const__5)) { tmpTernaryOp = null; break label88; ((clojure.lang.IFn)new browse_ui.loading__5569__auto____9754()).invoke(); } else { clojure.lang.LockingTransaction.runInTransaction((java.util.concurrent.Callable)new browse_ui.fn__9756()); } label88: tmp91_88 = const__6; tmp91_88.setMeta((clojure.lang.IPersistentMap)const__15);tmp91_88.bindRoot(new browse_ui.open_url_in_swing());
/*   */   }
/*   */   
/*   */   public static final clojure.lang.AFn const__5;
/*   */   public static final clojure.lang.Var const__6;
/*   */   public static final clojure.lang.AFn const__15;
/*   */   public static void __init0()
/*   */   {
/*   */     const__0 = (clojure.lang.Var)RT.var("clojure.core", "in-ns");
/*   */     const__1 = (clojure.lang.AFn)((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "clojure.java.browse-ui")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "author"), "Christophe Grand", RT.keyword(null, "doc"), "Helper namespace for clojure.java.browse.\n            Prevents console apps from becoming GUI unnecessarily." }));
/*   */     const__4 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "author"), "Christophe Grand", RT.keyword(null, "doc"), "Helper namespace for clojure.java.browse.\n            Prevents console apps from becoming GUI unnecessarily." });
/*   */     const__5 = (clojure.lang.AFn)clojure.lang.Symbol.intern(null, "clojure.core");
/*   */     const__6 = (clojure.lang.Var)RT.var("clojure.java.browse-ui", "open-url-in-swing");
/*   */     const__15 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "url")) })), RT.keyword(null, "line"), Integer.valueOf(15), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/java/browse_ui.clj" });
/*   */   }
/*   */   
/*   */   static
/*   */   {
/*   */     __init0();
/*   */     clojure.lang.Compiler.pushNSandLoader(RT.classForName("clojure.java.browse_ui__init").getClassLoader());
/*   */     try
/*   */     {
/*   */       load();
/*   */       clojure.lang.Var.popThreadBindings();
/*   */     }
/*   */     finally
/*   */     {
/*   */       clojure.lang.Var.popThreadBindings();
/*   */       throw finally;
/*   */     }
/*   */   }
/*   */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\java\browse_ui__init.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */