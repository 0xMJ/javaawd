/*    */ package clojure.java;
/*    */ 
/*    */ import clojure.java.io.IOFactory;
/*    */ import clojure.lang.AFunction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class io$fn__9472$G__9425__9475
/*    */   extends AFunction
/*    */ {
/*    */   public Object invoke(Object gf__x__9473, Object gf__opts__9474)
/*    */   {
/* 69 */     gf__x__9473 = null;gf__opts__9474 = null;return ((IOFactory)gf__x__9473).make_writer(gf__opts__9474);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\java\io$fn__9472$G__9425__9475.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */