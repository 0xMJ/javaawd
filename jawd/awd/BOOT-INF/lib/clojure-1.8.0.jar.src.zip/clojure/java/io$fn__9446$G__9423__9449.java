/*    */ package clojure.java;
/*    */ 
/*    */ import clojure.java.io.IOFactory;
/*    */ import clojure.lang.AFunction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class io$fn__9446$G__9423__9449
/*    */   extends AFunction
/*    */ {
/*    */   public Object invoke(Object gf__x__9447, Object gf__opts__9448)
/*    */   {
/* 69 */     gf__x__9447 = null;gf__opts__9448 = null;return ((IOFactory)gf__x__9447).make_reader(gf__opts__9448);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\java\io$fn__9446$G__9423__9449.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */