/*     */ package clojure.java;
/*     */ 
/*     */ import clojure.lang.AFunction;
/*     */ 
/*     */ public final class io$fn__9560
/*     */   extends AFunction
/*     */ {
/*     */   /* Error */
/*     */   public static Object invokeStatic(Object input, Object output, Object opts)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: getstatic 17	java/lang/Character:TYPE	Ljava/lang/Class;
/*     */     //   3: aload_2
/*     */     //   4: invokestatic 22	clojure/java/io$buffer_size:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   7: invokestatic 27	clojure/core$make_array:invokeStatic	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   10: astore_3
/*     */     //   11: new 29	java/io/OutputStreamWriter
/*     */     //   14: dup
/*     */     //   15: aload_1
/*     */     //   16: aconst_null
/*     */     //   17: astore_1
/*     */     //   18: checkcast 31	java/io/OutputStream
/*     */     //   21: aload_2
/*     */     //   22: aconst_null
/*     */     //   23: astore_2
/*     */     //   24: invokestatic 34	clojure/java/io$encoding:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   27: checkcast 36	java/lang/String
/*     */     //   30: invokespecial 39	java/io/OutputStreamWriter:<init>	(Ljava/io/OutputStream;Ljava/lang/String;)V
/*     */     //   33: astore 4
/*     */     //   35: aload_0
/*     */     //   36: checkcast 41	java/io/Reader
/*     */     //   39: aload_3
/*     */     //   40: checkcast 43	[C
/*     */     //   43: invokevirtual 47	java/io/Reader:read	([C)I
/*     */     //   46: istore 5
/*     */     //   48: iload 5
/*     */     //   50: i2l
/*     */     //   51: lconst_0
/*     */     //   52: lcmp
/*     */     //   53: ifle +30 -> 83
/*     */     //   56: aload 4
/*     */     //   58: checkcast 29	java/io/OutputStreamWriter
/*     */     //   61: aload_3
/*     */     //   62: checkcast 43	[C
/*     */     //   65: lconst_0
/*     */     //   66: invokestatic 53	clojure/lang/RT:intCast	(J)I
/*     */     //   69: iload 5
/*     */     //   71: invokevirtual 57	java/io/OutputStreamWriter:write	([CII)V
/*     */     //   74: aconst_null
/*     */     //   75: pop
/*     */     //   76: goto -41 -> 35
/*     */     //   79: goto +13 -> 92
/*     */     //   82: pop
/*     */     //   83: aload 4
/*     */     //   85: checkcast 29	java/io/OutputStreamWriter
/*     */     //   88: invokevirtual 60	java/io/OutputStreamWriter:flush	()V
/*     */     //   91: aconst_null
/*     */     //   92: areturn
/*     */     // Line number table:
/*     */     //   Java source line #323	-> byte code offset #0
/*     */     //   Java source line #324	-> byte code offset #0
/*     */     //   Java source line #327	-> byte code offset #43
/*     */     //   Java source line #328	-> byte code offset #48
/*     */     //   Java source line #328	-> byte code offset #48
/*     */     //   Java source line #330	-> byte code offset #71
/*     */     //   Java source line #332	-> byte code offset #88
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	92	0	input	Object
/*     */     //   0	92	1	output	Object
/*     */     //   0	92	2	opts	Object
/*     */     //   11	81	3	buffer	Object
/*     */     //   35	57	4	out	Object
/*     */     //   48	44	5	size	int
/*     */   }
/*     */   
/*     */   public Object invoke(Object paramObject1, Object paramObject2, Object paramObject3)
/*     */   {
/* 323 */     paramObject1 = null;paramObject2 = null;paramObject3 = null;return invokeStatic(paramObject1, paramObject2, paramObject3);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\java\io$fn__9560.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */