/*     */ package clojure.java;
/*     */ 
/*     */ import clojure.lang.AFunction;
/*     */ import clojure.lang.RT;
/*     */ import clojure.lang.Var;
/*     */ 
/*     */ public final class io$fn__9522
/*     */   extends AFunction
/*     */ {
/*     */   private static Class __cached_class__0;
/*     */   
/*     */   /* Error */
/*     */   public static Object invokeStatic(Object x, Object opts)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: new 15	java/io/FileOutputStream
/*     */     //   3: dup
/*     */     //   4: aload_0
/*     */     //   5: aconst_null
/*     */     //   6: astore_0
/*     */     //   7: checkcast 17	java/io/File
/*     */     //   10: aload_1
/*     */     //   11: invokestatic 22	clojure/java/io$append_QMARK_:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   14: checkcast 24	java/lang/Boolean
/*     */     //   17: invokevirtual 28	java/lang/Boolean:booleanValue	()Z
/*     */     //   20: invokespecial 31	java/io/FileOutputStream:<init>	(Ljava/io/File;Z)V
/*     */     //   23: dup
/*     */     //   24: invokestatic 37	clojure/lang/Util:classOf	(Ljava/lang/Object;)Ljava/lang/Class;
/*     */     //   27: getstatic 39	clojure/java/io$fn__9522:__cached_class__0	Ljava/lang/Class;
/*     */     //   30: if_acmpeq +17 -> 47
/*     */     //   33: dup
/*     */     //   34: instanceof 41
/*     */     //   37: ifne +28 -> 65
/*     */     //   40: dup
/*     */     //   41: invokestatic 37	clojure/lang/Util:classOf	(Ljava/lang/Object;)Ljava/lang/Class;
/*     */     //   44: putstatic 39	clojure/java/io$fn__9522:__cached_class__0	Ljava/lang/Class;
/*     */     //   47: getstatic 45	clojure/java/io$fn__9522:const__0	Lclojure/lang/Var;
/*     */     //   50: invokevirtual 51	clojure/lang/Var:getRawRoot	()Ljava/lang/Object;
/*     */     //   53: swap
/*     */     //   54: aload_1
/*     */     //   55: aconst_null
/*     */     //   56: astore_1
/*     */     //   57: invokeinterface 56 3 0
/*     */     //   62: goto +11 -> 73
/*     */     //   65: aload_1
/*     */     //   66: aconst_null
/*     */     //   67: astore_1
/*     */     //   68: invokeinterface 59 2 0
/*     */     //   73: areturn
/*     */     // Line number table:
/*     */     //   Java source line #230	-> byte code offset #0
/*     */     //   Java source line #230	-> byte code offset #0
/*     */     //   Java source line #230	-> byte code offset #57
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	73	0	x	Object
/*     */     //   0	73	1	opts	Object
/*     */   }
/*     */   
/*     */   public Object invoke(Object paramObject1, Object paramObject2)
/*     */   {
/* 230 */     paramObject1 = null;paramObject2 = null;return invokeStatic(paramObject1, paramObject2); } public static final Var const__0 = (Var)RT.var("clojure.java.io", "make-output-stream");
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\java\io$fn__9522.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */