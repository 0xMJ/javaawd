/*     */ package clojure.java;
/*     */ 
/*     */ import clojure.lang.RT;
/*     */ 
/*     */ public class io__init { public static final clojure.lang.Var const__0;
/*     */   public static final clojure.lang.AFn const__1;
/*     */   public static final clojure.lang.Keyword const__3;
/*     */   
/*   9 */   public static void load() { if (((clojure.lang.Symbol)const__1).equals(const__5)) { tmpTernaryOp = null; break label88; ((clojure.lang.IFn)new io.loading__5569__auto____9368()).invoke(); } else { clojure.lang.LockingTransaction.runInTransaction((java.util.concurrent.Callable)new io.fn__9370()); } label88: tmp91_88 = const__6; tmp91_88.setMeta((clojure.lang.IPersistentMap)const__13);tmp91_88
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  28 */       .bindRoot(((clojure.lang.IFn)const__14.getRawRoot()).invoke(((clojure.lang.IFn)const__15.getRawRoot()).invoke(Byte.TYPE, const__16))); clojure.lang.Var tmp142_139 = const__17;tmp142_139.setMeta((clojure.lang.IPersistentMap)const__19);tmp142_139
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  33 */       .bindRoot(((clojure.lang.IFn)const__14.getRawRoot()).invoke(((clojure.lang.IFn)const__15.getRawRoot()).invoke(Character.TYPE, const__16)));new io.fn__9376(); clojure.lang.Var 
/*     */     
/*  35 */       tmp519_516 = const__50;tmp519_516.setMeta((clojure.lang.IPersistentMap)const__54);tmp519_516.bindRoot(new io.escaped_utf8_urlstring__GT_str());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  44 */     new io.fn__9430(); clojure.lang.Var 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  69 */       tmp1353_1350 = const__80;tmp1353_1350.setMeta((clojure.lang.IPersistentMap)const__86);tmp1353_1350.bindRoot(new io.reader()); clojure.lang.Var tmp1377_1374 = const__87;tmp1377_1374.setMeta((clojure.lang.IPersistentMap)const__91);tmp1377_1374.bindRoot(new io.writer()); clojure.lang.Var tmp1401_1398 = const__92;tmp1401_1398.setMeta((clojure.lang.IPersistentMap)const__96);tmp1401_1398.bindRoot(new io.input_stream()); clojure.lang.Var tmp1425_1422 = const__97;tmp1425_1422.setMeta((clojure.lang.IPersistentMap)const__101);tmp1425_1422.bindRoot(new io.output_stream()); clojure.lang.Var tmp1449_1446 = const__102;tmp1449_1446.setMeta((clojure.lang.IPersistentMap)const__106);tmp1449_1446.bindRoot(new io.append_QMARK_()); clojure.lang.Var tmp1473_1470 = const__107;tmp1473_1470.setMeta((clojure.lang.IPersistentMap)const__110);tmp1473_1470.bindRoot(new io.encoding()); clojure.lang.Var tmp1497_1494 = const__111;tmp1497_1494.setMeta((clojure.lang.IPersistentMap)const__114);tmp1497_1494.bindRoot(new io.buffer_size()); clojure.lang.Var tmp1521_1518 = const__115;tmp1521_1518.setMeta((clojure.lang.IPersistentMap)const__117);tmp1521_1518.bindRoot(RT.mapUniqueKeys(new Object[] { const__67, new io.fn__9494(), const__66, new io.fn__9496(), const__68, new io.fn__9498(), const__69, new io.fn__9500() })); clojure.lang.Var tmp1612_1609 = const__118;tmp1612_1609.setMeta((clojure.lang.IPersistentMap)const__121);tmp1612_1609.bindRoot(new io.inputstream__GT_reader()); clojure.lang.Var tmp1636_1633 = const__122;tmp1636_1633.setMeta((clojure.lang.IPersistentMap)const__125);tmp1636_1633.bindRoot(new io.outputstream__GT_writer());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 184 */     new io.fn__9504();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 190 */     new io.fn__9506();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 196 */     new io.fn__9508();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 201 */     new io.fn__9510();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 206 */     new io.fn__9512();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 211 */     new io.fn__9514();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 216 */     new io.fn__9516();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 222 */     new io.fn__9518();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 228 */     new io.fn__9520();new io.fn__9522();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 234 */     new io.fn__9524();new io.fn__9526();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 247 */     new io.fn__9528();new io.fn__9530();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 253 */     new io.fn__9532();new io.fn__9534();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 267 */     new io.fn__9536();new io.fn__9538();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 273 */     new io.fn__9540();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 278 */     new io.fn__9542();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 287 */     new io.fn__9544();new io.fn__9546();new io.fn__9548();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 295 */     new io.fn__9554();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 302 */     new io.fn__9556();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 310 */     new io.fn__9558();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 319 */     new io.fn__9560();
/*     */     
/*     */ 
/*     */ 
/* 323 */     new io.fn__9562();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 334 */     new io.fn__9564();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 342 */     new io.fn__9566();
/*     */     
/*     */ 
/*     */ 
/* 346 */     new io.fn__9568();
/*     */     
/*     */ 
/*     */ 
/* 350 */     new io.fn__9570();
/*     */     
/*     */ 
/*     */ 
/* 354 */     new io.fn__9572();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 364 */     new io.fn__9574();
/*     */     
/*     */ 
/* 367 */     new io.fn__9576();
/*     */     
/*     */ 
/* 370 */     new io.fn__9578();
/*     */     
/*     */ 
/* 373 */     new io.fn__9580();
/*     */     
/*     */ 
/* 376 */     new io.fn__9582();
/*     */     
/*     */ 
/* 379 */     new io.fn__9584();
/*     */     
/*     */ 
/* 382 */     new io.fn__9586();
/*     */     
/*     */ 
/* 385 */     new io.fn__9588(); clojure.lang.Var 
/*     */     
/*     */ 
/* 388 */       tmp3156_3153 = const__145;tmp3156_3153.setMeta((clojure.lang.IPersistentMap)const__148);tmp3156_3153.bindRoot(new io.copy()); clojure.lang.Var tmp3180_3177 = const__149;tmp3180_3177.setMeta((clojure.lang.IPersistentMap)const__152);tmp3180_3177.bindRoot(new io.as_relative_path()); clojure.lang.Var tmp3204_3201 = const__153;tmp3204_3201.setMeta((clojure.lang.IPersistentMap)const__156);tmp3204_3201.bindRoot(new io.file()); clojure.lang.Var tmp3228_3225 = const__157;tmp3228_3225.setMeta((clojure.lang.IPersistentMap)const__160);tmp3228_3225.bindRoot(new io.delete_file()); clojure.lang.Var tmp3252_3249 = const__161;tmp3252_3249.setMeta((clojure.lang.IPersistentMap)const__164);tmp3252_3249.bindRoot(new io.make_parents()); clojure.lang.Var tmp3276_3273 = const__165;tmp3276_3273.setMeta((clojure.lang.IPersistentMap)const__168);tmp3276_3273.bindRoot(new io.resource());
/*     */   }
/*     */   
/*     */   public static final clojure.lang.AFn const__4;
/*     */   public static final clojure.lang.AFn const__5;
/*     */   public static final clojure.lang.Var const__6;
/*     */   public static final clojure.lang.AFn const__13;
/*     */   public static final clojure.lang.Var const__14;
/*     */   public static final clojure.lang.Var const__15;
/*     */   public static final Object const__16;
/*     */   public static final clojure.lang.Var const__17;
/*     */   public static final clojure.lang.AFn const__19;
/*     */   public static final Object const__20;
/*     */   public static final clojure.lang.Var const__21;
/*     */   public static final clojure.lang.Var const__22;
/*     */   public static final clojure.lang.Var const__23;
/*     */   public static final clojure.lang.Var const__24;
/*     */   public static final clojure.lang.ISeq const__25;
/*     */   public static final clojure.lang.Var const__26;
/*     */   public static final clojure.lang.Var const__27;
/*     */   public static final clojure.lang.AFn const__31;
/*     */   public static final clojure.lang.Keyword const__32;
/*     */   public static final clojure.lang.AFn const__33;
/*     */   public static final clojure.lang.Keyword const__34;
/*     */   public static final clojure.lang.Keyword const__35;
/*     */   public static final clojure.lang.Keyword const__36;
/*     */   public static final clojure.lang.Keyword const__37;
/*     */   public static final clojure.lang.AFn const__38;
/*     */   public static final clojure.lang.Keyword const__39;
/*     */   public static final clojure.lang.Var const__40;
/*     */   public static final clojure.lang.Var const__41;
/*     */   public static final clojure.lang.Var const__42;
/*     */   public static final clojure.lang.AFn const__43;
/*     */   public static final clojure.lang.AFn const__44;
/*     */   public static final clojure.lang.Keyword const__45;
/*     */   public static final clojure.lang.AFn const__46;
/*     */   public static final clojure.lang.AFn const__47;
/*     */   public static final clojure.lang.Var const__48;
/*     */   public static final clojure.lang.AFn const__49;
/*     */   public static final clojure.lang.Var const__50;
/*     */   public static final clojure.lang.AFn const__54;
/*     */   public static final clojure.lang.Var const__55;
/*     */   public static final Object const__56;
/*     */   public static final Object const__57;
/*     */   public static final Object const__58;
/*     */   public static final Object const__59;
/*     */   public static final Object const__60;
/*     */   public static final clojure.lang.Var const__61;
/*     */   public static final clojure.lang.ISeq const__62;
/*     */   public static final clojure.lang.AFn const__64;
/*     */   public static final clojure.lang.AFn const__65;
/*     */   public static final clojure.lang.Keyword const__66;
/*     */   public static final clojure.lang.Keyword const__67;
/*     */   public static final clojure.lang.Keyword const__68;
/*     */   public static final clojure.lang.Keyword const__69;
/*     */   public static final clojure.lang.AFn const__70;
/*     */   public static final clojure.lang.AFn const__71;
/*     */   public static final clojure.lang.AFn const__72;
/*     */   public static final clojure.lang.AFn const__73;
/*     */   public static final clojure.lang.AFn const__74;
/*     */   public static final clojure.lang.AFn const__75;
/*     */   public static final clojure.lang.AFn const__76;
/*     */   public static final clojure.lang.AFn const__77;
/*     */   public static final clojure.lang.AFn const__78;
/*     */   public static final clojure.lang.AFn const__79;
/*     */   public static final clojure.lang.Var const__80;
/*     */   public static final Object const__82;
/*     */   public static final clojure.lang.AFn const__86;
/*     */   public static final clojure.lang.Var const__87;
/*     */   public static final Object const__88;
/*     */   public static final clojure.lang.AFn const__91;
/*     */   public static final clojure.lang.Var const__92;
/*     */   public static final Object const__93;
/*     */   public static final clojure.lang.AFn const__96;
/*     */   public static final clojure.lang.Var const__97;
/*     */   public static final Object const__98;
/*     */   public static final clojure.lang.AFn const__101;
/*     */   public static final clojure.lang.Var const__102;
/*     */   public static final clojure.lang.AFn const__106;
/*     */   public static final clojure.lang.Var const__107;
/*     */   public static final clojure.lang.AFn const__110;
/*     */   public static final clojure.lang.Var const__111;
/*     */   public static final clojure.lang.AFn const__114;
/*     */   public static final clojure.lang.Var const__115;
/*     */   public static final clojure.lang.AFn const__117;
/*     */   public static final clojure.lang.Var const__118;
/*     */   public static final clojure.lang.AFn const__121;
/*     */   public static final clojure.lang.Var const__122;
/*     */   public static final clojure.lang.AFn const__125;
/*     */   public static final Object const__126;
/*     */   public static final Object const__127;
/*     */   public static final Object const__128;
/*     */   public static final Object const__129;
/*     */   public static final Object const__130;
/*     */   public static final Object const__131;
/*     */   public static final clojure.lang.Var const__132;
/*     */   public static final clojure.lang.AFn const__133;
/*     */   public static final clojure.lang.AFn const__134;
/*     */   public static final clojure.lang.AFn const__135;
/*     */   public static final clojure.lang.AFn const__136;
/*     */   public static final clojure.lang.AFn const__137;
/*     */   public static final clojure.lang.AFn const__138;
/*     */   public static final clojure.lang.AFn const__139;
/*     */   public static final clojure.lang.AFn const__140;
/*     */   public static final clojure.lang.AFn const__141;
/*     */   public static final clojure.lang.AFn const__142;
/*     */   public static final clojure.lang.AFn const__143;
/*     */   public static final clojure.lang.AFn const__144;
/*     */   public static final clojure.lang.Var const__145;
/*     */   public static final clojure.lang.AFn const__148;
/*     */   public static final clojure.lang.Var const__149;
/*     */   public static final clojure.lang.AFn const__152;
/*     */   public static final clojure.lang.Var const__153;
/*     */   public static final clojure.lang.AFn const__156;
/*     */   public static final clojure.lang.Var const__157;
/*     */   public static final clojure.lang.AFn const__160;
/*     */   public static final clojure.lang.Var const__161;
/*     */   public static final clojure.lang.AFn const__164;
/*     */   public static final clojure.lang.Var const__165;
/*     */   public static final clojure.lang.AFn const__168;
/*     */   public static void __init0()
/*     */   {
/*     */     const__0 = (clojure.lang.Var)RT.var("clojure.core", "in-ns");
/*     */     const__1 = (clojure.lang.AFn)((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "clojure.java.io")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "author"), "Stuart Sierra, Chas Emerick, Stuart Halloway", RT.keyword(null, "doc"), "This file defines polymorphic I/O utility functions for Clojure." }));
/*     */     const__3 = (clojure.lang.Keyword)RT.keyword(null, "doc");
/*     */     const__4 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "author"), "Stuart Sierra, Chas Emerick, Stuart Halloway", RT.keyword(null, "doc"), "This file defines polymorphic I/O utility functions for Clojure." });
/*     */     const__5 = (clojure.lang.AFn)clojure.lang.Symbol.intern(null, "clojure.core");
/*     */     const__6 = (clojure.lang.Var)RT.var("clojure.java.io", "byte-array-type");
/*     */     const__13 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "doc"), "Type object for a Java primitive byte array.", RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "line"), Integer.valueOf(24), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/java/io.clj" });
/*     */     const__14 = (clojure.lang.Var)RT.var("clojure.core", "class");
/*     */     const__15 = (clojure.lang.Var)RT.var("clojure.core", "make-array");
/*     */     const__16 = Long.valueOf(0L);
/*     */     const__17 = (clojure.lang.Var)RT.var("clojure.java.io", "char-array-type");
/*     */     const__19 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "doc"), "Type object for a Java primitive char array.", RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "line"), Integer.valueOf(30), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/java/io.clj" });
/*     */     const__20 = RT.classForName("clojure.java.io.Coercions");
/*     */     const__21 = (clojure.lang.Var)RT.var("clojure.core", "alter-meta!");
/*     */     const__22 = (clojure.lang.Var)RT.var("clojure.java.io", "Coercions");
/*     */     const__23 = (clojure.lang.Var)RT.var("clojure.core", "assoc");
/*     */     const__24 = (clojure.lang.Var)RT.var("clojure.core", "assert-same-protocol");
/*     */     const__25 = (clojure.lang.ISeq)clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { ((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "as-file")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "doc"), "Coerce argument to a file.", RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "x")) })) })), ((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "as-url")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "doc"), "Coerce argument to a URL.", RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "x")) })) })) }));
/*     */     const__26 = (clojure.lang.Var)RT.var("clojure.core", "alter-var-root");
/*     */     const__27 = (clojure.lang.Var)RT.var("clojure.core", "merge");
/*     */     const__31 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "on"), clojure.lang.Symbol.intern(null, "clojure.java.io.Coercions"), RT.keyword(null, "on-interface"), RT.classForName("clojure.java.io.Coercions"), RT.keyword(null, "doc"), "Coerce between various 'resource-namish' things." });
/*     */     const__32 = (clojure.lang.Keyword)RT.keyword(null, "sigs");
/*     */     const__33 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "as-file"), RT.map(new Object[] { RT.keyword(null, "tag"), clojure.lang.Symbol.intern(null, "java.io.File"), RT.keyword(null, "added"), "1.2", RT.keyword(null, "name"), ((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "as-file")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "doc"), "Coerce argument to a file.", RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "x")) })) })), RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "x")) })), RT.keyword(null, "doc"), "Coerce argument to a file." }), RT.keyword(null, "as-url"), RT.map(new Object[] { RT.keyword(null, "tag"), clojure.lang.Symbol.intern(null, "java.net.URL"), RT.keyword(null, "added"), "1.2", RT.keyword(null, "name"), ((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "as-url")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "doc"), "Coerce argument to a URL.", RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "x")) })) })), RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "x")) })), RT.keyword(null, "doc"), "Coerce argument to a URL." }) });
/*     */     const__34 = (clojure.lang.Keyword)RT.keyword(null, "var");
/*     */     const__35 = (clojure.lang.Keyword)RT.keyword(null, "method-map");
/*     */     const__36 = (clojure.lang.Keyword)RT.keyword(null, "as-file");
/*     */     const__37 = (clojure.lang.Keyword)RT.keyword(null, "as-url");
/*     */     const__38 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "as-file"), RT.keyword(null, "as-file"), RT.keyword(null, "as-url"), RT.keyword(null, "as-url") });
/*     */     const__39 = (clojure.lang.Keyword)RT.keyword(null, "method-builders");
/*     */     const__40 = (clojure.lang.Var)RT.var("clojure.core", "intern");
/*     */     const__41 = (clojure.lang.Var)RT.var("clojure.core", "*ns*");
/*     */     const__42 = (clojure.lang.Var)RT.var("clojure.core", "with-meta");
/*     */     const__43 = (clojure.lang.AFn)((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "as-url")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "doc"), "Coerce argument to a URL.", RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "x")) })) }));
/*     */     const__44 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "tag"), clojure.lang.Symbol.intern(null, "java.net.URL"), RT.keyword(null, "added"), "1.2", RT.keyword(null, "name"), ((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "as-url")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "doc"), "Coerce argument to a URL.", RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "x")) })) })), RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "x")) })), RT.keyword(null, "doc"), "Coerce argument to a URL." });
/*     */     const__45 = (clojure.lang.Keyword)RT.keyword(null, "protocol");
/*     */     const__46 = (clojure.lang.AFn)((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "as-file")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "doc"), "Coerce argument to a file.", RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "x")) })) }));
/*     */     const__47 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "tag"), clojure.lang.Symbol.intern(null, "java.io.File"), RT.keyword(null, "added"), "1.2", RT.keyword(null, "name"), ((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "as-file")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "doc"), "Coerce argument to a file.", RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "x")) })) })), RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "x")) })), RT.keyword(null, "doc"), "Coerce argument to a file." });
/*     */     const__48 = (clojure.lang.Var)RT.var("clojure.core", "-reset-methods");
/*     */     const__49 = (clojure.lang.AFn)((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "Coercions")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "added"), "1.2" }));
/*     */     const__50 = (clojure.lang.Var)RT.var("clojure.java.io", "escaped-utf8-urlstring->str");
/*     */     const__54 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "s")) })), RT.keyword(null, "line"), Integer.valueOf(40), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/java/io.clj" });
/*     */     const__55 = (clojure.lang.Var)RT.var("clojure.core", "extend");
/*     */     const__56 = RT.classForName("java.lang.String");
/*     */     const__57 = RT.classForName("java.io.File");
/*     */     const__58 = RT.classForName("java.net.URL");
/*     */     const__59 = RT.classForName("java.net.URI");
/*     */     const__60 = RT.classForName("clojure.java.io.IOFactory");
/*     */     const__61 = (clojure.lang.Var)RT.var("clojure.java.io", "IOFactory");
/*     */     const__62 = (clojure.lang.ISeq)clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { ((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "make-reader")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "doc"), "Creates a BufferedReader. See also IOFactory docs.", RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "x"), clojure.lang.Symbol.intern(null, "opts")) })) })), ((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "make-writer")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "doc"), "Creates a BufferedWriter. See also IOFactory docs.", RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "x"), clojure.lang.Symbol.intern(null, "opts")) })) })), ((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "make-input-stream")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "doc"), "Creates a BufferedInputStream. See also IOFactory docs.", RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "x"), clojure.lang.Symbol.intern(null, "opts")) })) })), ((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "make-output-stream")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "doc"), "Creates a BufferedOutputStream. See also IOFactory docs.", RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "x"), clojure.lang.Symbol.intern(null, "opts")) })) })) }));
/*     */     const__64 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "on"), clojure.lang.Symbol.intern(null, "clojure.java.io.IOFactory"), RT.keyword(null, "on-interface"), RT.classForName("clojure.java.io.IOFactory"), RT.keyword(null, "doc"), "Factory functions that create ready-to-use, buffered versions of\n   the various Java I/O stream types, on top of anything that can\n   be unequivocally converted to the requested kind of stream.\n\n   Common options include\n   \n     :append    true to open stream in append mode\n     :encoding  string name of encoding to use, e.g. \"UTF-8\".\n\n   Callers should generally prefer the higher level API provided by\n   reader, writer, input-stream, and output-stream." });
/*     */     const__65 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "make-reader"), RT.map(new Object[] { RT.keyword(null, "added"), "1.2", RT.keyword(null, "name"), ((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "make-reader")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "doc"), "Creates a BufferedReader. See also IOFactory docs.", RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "x"), clojure.lang.Symbol.intern(null, "opts")) })) })), RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "x"), clojure.lang.Symbol.intern(null, "opts")) })), RT.keyword(null, "doc"), "Creates a BufferedReader. See also IOFactory docs." }), RT.keyword(null, "make-writer"), RT.map(new Object[] { RT.keyword(null, "added"), "1.2", RT.keyword(null, "name"), ((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "make-writer")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "doc"), "Creates a BufferedWriter. See also IOFactory docs.", RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "x"), clojure.lang.Symbol.intern(null, "opts")) })) })), RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "x"), clojure.lang.Symbol.intern(null, "opts")) })), RT.keyword(null, "doc"), "Creates a BufferedWriter. See also IOFactory docs." }), RT.keyword(null, "make-input-stream"), RT.map(new Object[] { RT.keyword(null, "added"), "1.2", RT.keyword(null, "name"), ((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "make-input-stream")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "doc"), "Creates a BufferedInputStream. See also IOFactory docs.", RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "x"), clojure.lang.Symbol.intern(null, "opts")) })) })), RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "x"), clojure.lang.Symbol.intern(null, "opts")) })), RT.keyword(null, "doc"), "Creates a BufferedInputStream. See also IOFactory docs." }), RT.keyword(null, "make-output-stream"), RT.map(new Object[] { RT.keyword(null, "added"), "1.2", RT.keyword(null, "name"), ((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "make-output-stream")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "doc"), "Creates a BufferedOutputStream. See also IOFactory docs.", RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "x"), clojure.lang.Symbol.intern(null, "opts")) })) })), RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "x"), clojure.lang.Symbol.intern(null, "opts")) })), RT.keyword(null, "doc"), "Creates a BufferedOutputStream. See also IOFactory docs." }) });
/*     */     const__66 = (clojure.lang.Keyword)RT.keyword(null, "make-writer");
/*     */     const__67 = (clojure.lang.Keyword)RT.keyword(null, "make-reader");
/*     */     const__68 = (clojure.lang.Keyword)RT.keyword(null, "make-input-stream");
/*     */     const__69 = (clojure.lang.Keyword)RT.keyword(null, "make-output-stream");
/*     */     const__70 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "make-writer"), RT.keyword(null, "make-writer"), RT.keyword(null, "make-reader"), RT.keyword(null, "make-reader"), RT.keyword(null, "make-input-stream"), RT.keyword(null, "make-input-stream"), RT.keyword(null, "make-output-stream"), RT.keyword(null, "make-output-stream") });
/*     */     const__71 = (clojure.lang.AFn)((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "make-input-stream")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "doc"), "Creates a BufferedInputStream. See also IOFactory docs.", RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "x"), clojure.lang.Symbol.intern(null, "opts")) })) }));
/*     */     const__72 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "added"), "1.2", RT.keyword(null, "name"), ((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "make-input-stream")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "doc"), "Creates a BufferedInputStream. See also IOFactory docs.", RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "x"), clojure.lang.Symbol.intern(null, "opts")) })) })), RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "x"), clojure.lang.Symbol.intern(null, "opts")) })), RT.keyword(null, "doc"), "Creates a BufferedInputStream. See also IOFactory docs." });
/*     */     const__73 = (clojure.lang.AFn)((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "make-reader")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "doc"), "Creates a BufferedReader. See also IOFactory docs.", RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "x"), clojure.lang.Symbol.intern(null, "opts")) })) }));
/*     */     const__74 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "added"), "1.2", RT.keyword(null, "name"), ((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "make-reader")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "doc"), "Creates a BufferedReader. See also IOFactory docs.", RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "x"), clojure.lang.Symbol.intern(null, "opts")) })) })), RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "x"), clojure.lang.Symbol.intern(null, "opts")) })), RT.keyword(null, "doc"), "Creates a BufferedReader. See also IOFactory docs." });
/*     */     const__75 = (clojure.lang.AFn)((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "make-output-stream")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "doc"), "Creates a BufferedOutputStream. See also IOFactory docs.", RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "x"), clojure.lang.Symbol.intern(null, "opts")) })) }));
/*     */     const__76 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "added"), "1.2", RT.keyword(null, "name"), ((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "make-output-stream")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "doc"), "Creates a BufferedOutputStream. See also IOFactory docs.", RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "x"), clojure.lang.Symbol.intern(null, "opts")) })) })), RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "x"), clojure.lang.Symbol.intern(null, "opts")) })), RT.keyword(null, "doc"), "Creates a BufferedOutputStream. See also IOFactory docs." });
/*     */     const__77 = (clojure.lang.AFn)((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "make-writer")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "doc"), "Creates a BufferedWriter. See also IOFactory docs.", RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "x"), clojure.lang.Symbol.intern(null, "opts")) })) }));
/*     */     const__78 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "added"), "1.2", RT.keyword(null, "name"), ((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "make-writer")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "doc"), "Creates a BufferedWriter. See also IOFactory docs.", RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "x"), clojure.lang.Symbol.intern(null, "opts")) })) })), RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "x"), clojure.lang.Symbol.intern(null, "opts")) })), RT.keyword(null, "doc"), "Creates a BufferedWriter. See also IOFactory docs." });
/*     */     const__79 = (clojure.lang.AFn)((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "IOFactory")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "added"), "1.2" }));
/*     */     const__80 = (clojure.lang.Var)RT.var("clojure.java.io", "reader");
/*     */     const__82 = RT.classForName("java.io.Reader");
/*     */     const__86 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "tag"), RT.classForName("java.io.Reader"), RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "x"), clojure.lang.Symbol.intern(null, "&"), clojure.lang.Symbol.intern(null, "opts")) })), RT.keyword(null, "doc"), "Attempts to coerce its argument into an open java.io.Reader.\n   Default implementations always return a java.io.BufferedReader.\n\n   Default implementations are provided for Reader, BufferedReader,\n   InputStream, File, URI, URL, Socket, byte arrays, character arrays,\n   and String.\n\n   If argument is a String, it tries to resolve it first as a URI, then\n   as a local file name.  URIs with a 'file' protocol are converted to\n   local file names.\n\n   Should be used inside with-open to ensure the Reader is properly\n   closed.", RT.keyword(null, "added"), "1.2", RT.keyword(null, "line"), Integer.valueOf(86), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/java/io.clj" });
/*     */     const__87 = (clojure.lang.Var)RT.var("clojure.java.io", "writer");
/*     */     const__88 = RT.classForName("java.io.Writer");
/*     */     const__91 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "tag"), RT.classForName("java.io.Writer"), RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "x"), clojure.lang.Symbol.intern(null, "&"), clojure.lang.Symbol.intern(null, "opts")) })), RT.keyword(null, "doc"), "Attempts to coerce its argument into an open java.io.Writer.\n   Default implementations always return a java.io.BufferedWriter.\n\n   Default implementations are provided for Writer, BufferedWriter,\n   OutputStream, File, URI, URL, Socket, and String.\n\n   If the argument is a String, it tries to resolve it first as a URI, then\n   as a local file name.  URIs with a 'file' protocol are converted to\n   local file names.\n\n   Should be used inside with-open to ensure the Writer is properly\n   closed.", RT.keyword(null, "added"), "1.2", RT.keyword(null, "line"), Integer.valueOf(104), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/java/io.clj" });
/*     */     const__92 = (clojure.lang.Var)RT.var("clojure.java.io", "input-stream");
/*     */     const__93 = RT.classForName("java.io.InputStream");
/*     */     const__96 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "tag"), RT.classForName("java.io.InputStream"), RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "x"), clojure.lang.Symbol.intern(null, "&"), clojure.lang.Symbol.intern(null, "opts")) })), RT.keyword(null, "doc"), "Attempts to coerce its argument into an open java.io.InputStream.\n   Default implementations always return a java.io.BufferedInputStream.\n\n   Default implementations are defined for InputStream, File, URI, URL,\n   Socket, byte array, and String arguments.\n\n   If the argument is a String, it tries to resolve it first as a URI, then\n   as a local file name.  URIs with a 'file' protocol are converted to\n   local file names.\n\n   Should be used inside with-open to ensure the InputStream is properly\n   closed.", RT.keyword(null, "added"), "1.2", RT.keyword(null, "line"), Integer.valueOf(121), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/java/io.clj" });
/*     */     const__97 = (clojure.lang.Var)RT.var("clojure.java.io", "output-stream");
/*     */     const__98 = RT.classForName("java.io.OutputStream");
/*     */   }
/*     */   
/*     */   public static void __init1()
/*     */   {
/*     */     const__101 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "tag"), RT.classForName("java.io.OutputStream"), RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "x"), clojure.lang.Symbol.intern(null, "&"), clojure.lang.Symbol.intern(null, "opts")) })), RT.keyword(null, "doc"), "Attempts to coerce its argument into an open java.io.OutputStream.\n   Default implementations always return a java.io.BufferedOutputStream.\n\n   Default implementations are defined for OutputStream, File, URI, URL,\n   Socket, and String arguments.\n\n   If the argument is a String, it tries to resolve it first as a URI, then\n   as a local file name.  URIs with a 'file' protocol are converted to\n   local file names.\n\n   Should be used inside with-open to ensure the OutputStream is\n   properly closed.", RT.keyword(null, "added"), "1.2", RT.keyword(null, "line"), Integer.valueOf(138), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/java/io.clj" });
/*     */     const__102 = (clojure.lang.Var)RT.var("clojure.java.io", "append?");
/*     */     const__106 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "tag"), RT.classForName("java.lang.Boolean"), RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "opts")) })), RT.keyword(null, "line"), Integer.valueOf(155), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/java/io.clj" });
/*     */     const__107 = (clojure.lang.Var)RT.var("clojure.java.io", "encoding");
/*     */     const__110 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "tag"), RT.classForName("java.lang.String"), RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "opts")) })), RT.keyword(null, "line"), Integer.valueOf(158), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/java/io.clj" });
/*     */     const__111 = (clojure.lang.Var)RT.var("clojure.java.io", "buffer-size");
/*     */     const__114 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "opts")) })), RT.keyword(null, "line"), Integer.valueOf(161), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/java/io.clj" });
/*     */     const__115 = (clojure.lang.Var)RT.var("clojure.java.io", "default-streams-impl");
/*     */     const__117 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "line"), Integer.valueOf(164), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/java/io.clj" });
/*     */     const__118 = (clojure.lang.Var)RT.var("clojure.java.io", "inputstream->reader");
/*     */     const__121 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "is")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "tag"), clojure.lang.Symbol.intern(null, "InputStream") })), clojure.lang.Symbol.intern(null, "opts")) })), RT.keyword(null, "line"), Integer.valueOf(174), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/java/io.clj" });
/*     */     const__122 = (clojure.lang.Var)RT.var("clojure.java.io", "outputstream->writer");
/*     */     const__125 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "os")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "tag"), clojure.lang.Symbol.intern(null, "OutputStream") })), clojure.lang.Symbol.intern(null, "opts")) })), RT.keyword(null, "line"), Integer.valueOf(178), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/java/io.clj" });
/*     */     const__126 = RT.classForName("java.io.BufferedInputStream");
/*     */     const__127 = RT.classForName("java.io.BufferedReader");
/*     */     const__128 = RT.classForName("java.io.BufferedWriter");
/*     */     const__129 = RT.classForName("java.io.BufferedOutputStream");
/*     */     const__130 = RT.classForName("java.net.Socket");
/*     */     const__131 = RT.classForName("java.lang.Object");
/*     */     const__132 = (clojure.lang.Var)RT.var("clojure.java.io", "do-copy");
/*     */     const__133 = (clojure.lang.AFn)clojure.lang.Tuple.create(RT.classForName("java.io.InputStream"), RT.classForName("java.io.OutputStream"));
/*     */     const__134 = (clojure.lang.AFn)clojure.lang.Tuple.create(RT.classForName("java.io.InputStream"), RT.classForName("java.io.Writer"));
/*     */     const__135 = (clojure.lang.AFn)clojure.lang.Tuple.create(RT.classForName("java.io.InputStream"), RT.classForName("java.io.File"));
/*     */     const__136 = (clojure.lang.AFn)clojure.lang.Tuple.create(RT.classForName("java.io.Reader"), RT.classForName("java.io.OutputStream"));
/*     */     const__137 = (clojure.lang.AFn)clojure.lang.Tuple.create(RT.classForName("java.io.Reader"), RT.classForName("java.io.Writer"));
/*     */     const__138 = (clojure.lang.AFn)clojure.lang.Tuple.create(RT.classForName("java.io.Reader"), RT.classForName("java.io.File"));
/*     */     const__139 = (clojure.lang.AFn)clojure.lang.Tuple.create(RT.classForName("java.io.File"), RT.classForName("java.io.OutputStream"));
/*     */     const__140 = (clojure.lang.AFn)clojure.lang.Tuple.create(RT.classForName("java.io.File"), RT.classForName("java.io.Writer"));
/*     */     const__141 = (clojure.lang.AFn)clojure.lang.Tuple.create(RT.classForName("java.io.File"), RT.classForName("java.io.File"));
/*     */     const__142 = (clojure.lang.AFn)clojure.lang.Tuple.create(RT.classForName("java.lang.String"), RT.classForName("java.io.OutputStream"));
/*     */     const__143 = (clojure.lang.AFn)clojure.lang.Tuple.create(RT.classForName("java.lang.String"), RT.classForName("java.io.Writer"));
/*     */     const__144 = (clojure.lang.AFn)clojure.lang.Tuple.create(RT.classForName("java.lang.String"), RT.classForName("java.io.File"));
/*     */     const__145 = (clojure.lang.Var)RT.var("clojure.java.io", "copy");
/*     */     const__148 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "input"), clojure.lang.Symbol.intern(null, "output"), clojure.lang.Symbol.intern(null, "&"), clojure.lang.Symbol.intern(null, "opts")) })), RT.keyword(null, "doc"), "Copies input to output.  Returns nil or throws IOException.\n  Input may be an InputStream, Reader, File, byte[], or String.\n  Output may be an OutputStream, Writer, or File.\n\n  Options are key/value pairs and may be one of\n\n    :buffer-size  buffer size to use, default is 1024.\n    :encoding     encoding to use if converting between\n                  byte and char streams.   \n\n  Does not close any streams except those it opens itself \n  (on a File).", RT.keyword(null, "added"), "1.2", RT.keyword(null, "line"), Integer.valueOf(391), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/java/io.clj" });
/*     */     const__149 = (clojure.lang.Var)RT.var("clojure.java.io", "as-relative-path");
/*     */     const__152 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "tag"), RT.classForName("java.lang.String"), RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "x")) })), RT.keyword(null, "doc"), "Take an as-file-able thing and return a string if it is\n   a relative path, else IllegalArgumentException.", RT.keyword(null, "added"), "1.2", RT.keyword(null, "line"), Integer.valueOf(408), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/java/io.clj" });
/*     */     const__153 = (clojure.lang.Var)RT.var("clojure.java.io", "file");
/*     */     const__156 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "tag"), RT.classForName("java.io.File"), RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "arg")), clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "parent"), clojure.lang.Symbol.intern(null, "child")), clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "parent"), clojure.lang.Symbol.intern(null, "child"), clojure.lang.Symbol.intern(null, "&"), clojure.lang.Symbol.intern(null, "more")) })), RT.keyword(null, "doc"), "Returns a java.io.File, passing each arg to as-file.  Multiple-arg\n   versions treat the first argument as parent and subsequent args as\n   children relative to the parent.", RT.keyword(null, "added"), "1.2", RT.keyword(null, "line"), Integer.valueOf(418), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/java/io.clj" });
/*     */     const__157 = (clojure.lang.Var)RT.var("clojure.java.io", "delete-file");
/*     */     const__160 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "f"), clojure.lang.Symbol.intern(null, "&"), clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "silently"))) })), RT.keyword(null, "doc"), "Delete file f. Raise an exception if it fails unless silently is true.", RT.keyword(null, "added"), "1.2", RT.keyword(null, "line"), Integer.valueOf(430), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/java/io.clj" });
/*     */     const__161 = (clojure.lang.Var)RT.var("clojure.java.io", "make-parents");
/*     */     const__164 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "f"), clojure.lang.Symbol.intern(null, "&"), clojure.lang.Symbol.intern(null, "more")) })), RT.keyword(null, "doc"), "Given the same arg(s) as for file, creates all parent directories of\n   the file they represent.", RT.keyword(null, "added"), "1.2", RT.keyword(null, "line"), Integer.valueOf(438), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/java/io.clj" });
/*     */     const__165 = (clojure.lang.Var)RT.var("clojure.java.io", "resource");
/*     */     const__168 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "tag"), RT.classForName("java.net.URL"), RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "n")), clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "n"), ((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "loader")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "tag"), clojure.lang.Symbol.intern(null, "ClassLoader") }))) })), RT.keyword(null, "doc"), "Returns the URL for a named resource. Use the context class loader\n   if no loader is specified.", RT.keyword(null, "added"), "1.2", RT.keyword(null, "line"), Integer.valueOf(446), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/java/io.clj" });
/*     */   }
/*     */   
/*     */   static
/*     */   {
/*     */     __init0();
/*     */     __init1();
/*     */     clojure.lang.Compiler.pushNSandLoader(RT.classForName("clojure.java.io__init").getClassLoader());
/*     */     try
/*     */     {
/*     */       load();
/*     */       clojure.lang.Var.popThreadBindings();
/*     */     }
/*     */     finally
/*     */     {
/*     */       clojure.lang.Var.popThreadBindings();
/*     */       throw finally;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\java\io__init.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */