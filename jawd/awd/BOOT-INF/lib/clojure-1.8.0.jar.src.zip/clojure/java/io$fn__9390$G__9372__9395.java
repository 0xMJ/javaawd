/*    */ package clojure.java;
/*    */ 
/*    */ import clojure.lang.AFunction;
/*    */ import clojure.lang.RT;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class io$fn__9390$G__9372__9395
/*    */   extends AFunction
/*    */ {
/*    */   Object G__9373;
/*    */   
/* 35 */   public io$fn__9390$G__9372__9395(Object paramObject) { this.G__9373 = paramObject; } public static final Object const__1 = RT.classForName("clojure.java.io.Coercions");
/*    */   
/*    */   /* Error */
/*    */   public Object invoke(Object gf__x__9394)
/*    */   {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: checkcast 4	clojure/lang/AFunction
/*    */     //   4: getfield 20	clojure/lang/AFunction:__methodImplCache	Lclojure/lang/MethodImplCache;
/*    */     //   7: astore_2
/*    */     //   8: aload_2
/*    */     //   9: aconst_null
/*    */     //   10: astore_2
/*    */     //   11: checkcast 22	clojure/lang/MethodImplCache
/*    */     //   14: aload_1
/*    */     //   15: invokestatic 28	clojure/lang/Util:classOf	(Ljava/lang/Object;)Ljava/lang/Class;
/*    */     //   18: checkcast 30	java/lang/Class
/*    */     //   21: invokevirtual 34	clojure/lang/MethodImplCache:fnFor	(Ljava/lang/Class;)Lclojure/lang/IFn;
/*    */     //   24: astore_3
/*    */     //   25: aload_3
/*    */     //   26: dup
/*    */     //   27: ifnull +26 -> 53
/*    */     //   30: getstatic 40	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*    */     //   33: if_acmpeq +21 -> 54
/*    */     //   36: aload_3
/*    */     //   37: aconst_null
/*    */     //   38: astore_3
/*    */     //   39: checkcast 42	clojure/lang/IFn
/*    */     //   42: aload_1
/*    */     //   43: aconst_null
/*    */     //   44: astore_1
/*    */     //   45: invokeinterface 44 2 0
/*    */     //   50: goto +27 -> 77
/*    */     //   53: pop
/*    */     //   54: aload_0
/*    */     //   55: aload_1
/*    */     //   56: getstatic 47	clojure/java/io$fn__9390$G__9372__9395:const__1	Ljava/lang/Object;
/*    */     //   59: aload_0
/*    */     //   60: getfield 14	clojure/java/io$fn__9390$G__9372__9395:G__9373	Ljava/lang/Object;
/*    */     //   63: invokestatic 53	clojure/core$_cache_protocol_fn:invokeStatic	(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   66: checkcast 42	clojure/lang/IFn
/*    */     //   69: aload_1
/*    */     //   70: aconst_null
/*    */     //   71: astore_1
/*    */     //   72: invokeinterface 44 2 0
/*    */     //   77: areturn
/*    */     // Line number table:
/*    */     //   Java source line #35	-> byte code offset #0
/*    */     //   Java source line #35	-> byte code offset #1
/*    */     //   Java source line #35	-> byte code offset #15
/*    */     //   Java source line #35	-> byte code offset #21
/*    */     //   Java source line #35	-> byte code offset #25
/*    */     //   Java source line #35	-> byte code offset #39
/*    */     //   Java source line #35	-> byte code offset #45
/*    */     //   Java source line #35	-> byte code offset #66
/*    */     //   Java source line #35	-> byte code offset #72
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	signature
/*    */     //   0	77	0	this	Object
/*    */     //   0	77	1	gf__x__9394	Object
/*    */     //   8	69	2	cache__6568__auto__9397	Object
/*    */     //   25	52	3	f__6569__auto__9398	Object
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\java\io$fn__9390$G__9372__9395.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */