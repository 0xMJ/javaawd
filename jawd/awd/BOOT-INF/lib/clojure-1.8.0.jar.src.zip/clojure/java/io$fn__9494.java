/*     */ package clojure.java;
/*     */ 
/*     */ import clojure.lang.AFunction;
/*     */ import clojure.lang.RT;
/*     */ import clojure.lang.Var;
/*     */ 
/*     */ public final class io$fn__9494
/*     */   extends AFunction
/*     */ {
/*     */   /* Error */
/*     */   public static Object invokeStatic(Object x, Object opts)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: aconst_null
/*     */     //   2: astore_0
/*     */     //   3: dup
/*     */     //   4: invokestatic 20	clojure/lang/Util:classOf	(Ljava/lang/Object;)Ljava/lang/Class;
/*     */     //   7: getstatic 22	clojure/java/io$fn__9494:__cached_class__0	Ljava/lang/Class;
/*     */     //   10: if_acmpeq +17 -> 27
/*     */     //   13: dup
/*     */     //   14: instanceof 24
/*     */     //   17: ifne +26 -> 43
/*     */     //   20: dup
/*     */     //   21: invokestatic 20	clojure/lang/Util:classOf	(Ljava/lang/Object;)Ljava/lang/Class;
/*     */     //   24: putstatic 22	clojure/java/io$fn__9494:__cached_class__0	Ljava/lang/Class;
/*     */     //   27: getstatic 28	clojure/java/io$fn__9494:const__1	Lclojure/lang/Var;
/*     */     //   30: invokevirtual 34	clojure/lang/Var:getRawRoot	()Ljava/lang/Object;
/*     */     //   33: swap
/*     */     //   34: aload_1
/*     */     //   35: invokeinterface 39 3 0
/*     */     //   40: goto +9 -> 49
/*     */     //   43: aload_1
/*     */     //   44: invokeinterface 43 2 0
/*     */     //   49: dup
/*     */     //   50: invokestatic 20	clojure/lang/Util:classOf	(Ljava/lang/Object;)Ljava/lang/Class;
/*     */     //   53: getstatic 45	clojure/java/io$fn__9494:__cached_class__1	Ljava/lang/Class;
/*     */     //   56: if_acmpeq +17 -> 73
/*     */     //   59: dup
/*     */     //   60: instanceof 24
/*     */     //   63: ifne +28 -> 91
/*     */     //   66: dup
/*     */     //   67: invokestatic 20	clojure/lang/Util:classOf	(Ljava/lang/Object;)Ljava/lang/Class;
/*     */     //   70: putstatic 45	clojure/java/io$fn__9494:__cached_class__1	Ljava/lang/Class;
/*     */     //   73: getstatic 48	clojure/java/io$fn__9494:const__0	Lclojure/lang/Var;
/*     */     //   76: invokevirtual 34	clojure/lang/Var:getRawRoot	()Ljava/lang/Object;
/*     */     //   79: swap
/*     */     //   80: aload_1
/*     */     //   81: aconst_null
/*     */     //   82: astore_1
/*     */     //   83: invokeinterface 39 3 0
/*     */     //   88: goto +11 -> 99
/*     */     //   91: aload_1
/*     */     //   92: aconst_null
/*     */     //   93: astore_1
/*     */     //   94: invokeinterface 51 2 0
/*     */     //   99: areturn
/*     */     // Line number table:
/*     */     //   Java source line #165	-> byte code offset #0
/*     */     //   Java source line #165	-> byte code offset #0
/*     */     //   Java source line #165	-> byte code offset #0
/*     */     //   Java source line #165	-> byte code offset #35
/*     */     //   Java source line #165	-> byte code offset #83
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	99	0	x	Object
/*     */     //   0	99	1	opts	Object
/*     */   }
/*     */   
/*     */   public Object invoke(Object paramObject1, Object paramObject2)
/*     */   {
/* 165 */     paramObject1 = null;paramObject2 = null;return invokeStatic(paramObject1, paramObject2); } public static final Var const__1 = (Var)RT.var("clojure.java.io", "make-input-stream"); public static final Var const__0 = (Var)RT.var("clojure.java.io", "make-reader");
/*     */   private static Class __cached_class__1;
/*     */   private static Class __cached_class__0;
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\java\io$fn__9494.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */