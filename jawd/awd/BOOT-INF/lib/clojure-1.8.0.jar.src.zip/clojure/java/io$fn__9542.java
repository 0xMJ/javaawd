/*     */ package clojure.java;
/*     */ 
/*     */ import clojure.lang.AFunction;
/*     */ import clojure.lang.RT;
/*     */ import clojure.lang.Var;
/*     */ 
/*     */ public final class io$fn__9542
/*     */   extends AFunction
/*     */ {
/*     */   private static Class __cached_class__0;
/*     */   
/*     */   /* Error */
/*     */   public static Object invokeStatic(Object x, Object opts)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: new 15	java/io/CharArrayReader
/*     */     //   3: dup
/*     */     //   4: aload_0
/*     */     //   5: aconst_null
/*     */     //   6: astore_0
/*     */     //   7: checkcast 17	[C
/*     */     //   10: invokespecial 20	java/io/CharArrayReader:<init>	([C)V
/*     */     //   13: dup
/*     */     //   14: invokestatic 26	clojure/lang/Util:classOf	(Ljava/lang/Object;)Ljava/lang/Class;
/*     */     //   17: getstatic 28	clojure/java/io$fn__9542:__cached_class__0	Ljava/lang/Class;
/*     */     //   20: if_acmpeq +17 -> 37
/*     */     //   23: dup
/*     */     //   24: instanceof 30
/*     */     //   27: ifne +28 -> 55
/*     */     //   30: dup
/*     */     //   31: invokestatic 26	clojure/lang/Util:classOf	(Ljava/lang/Object;)Ljava/lang/Class;
/*     */     //   34: putstatic 28	clojure/java/io$fn__9542:__cached_class__0	Ljava/lang/Class;
/*     */     //   37: getstatic 34	clojure/java/io$fn__9542:const__0	Lclojure/lang/Var;
/*     */     //   40: invokevirtual 40	clojure/lang/Var:getRawRoot	()Ljava/lang/Object;
/*     */     //   43: swap
/*     */     //   44: aload_1
/*     */     //   45: aconst_null
/*     */     //   46: astore_1
/*     */     //   47: invokeinterface 45 3 0
/*     */     //   52: goto +11 -> 63
/*     */     //   55: aload_1
/*     */     //   56: aconst_null
/*     */     //   57: astore_1
/*     */     //   58: invokeinterface 49 2 0
/*     */     //   63: areturn
/*     */     // Line number table:
/*     */     //   Java source line #279	-> byte code offset #0
/*     */     //   Java source line #279	-> byte code offset #0
/*     */     //   Java source line #279	-> byte code offset #47
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	63	0	x	Object
/*     */     //   0	63	1	opts	Object
/*     */   }
/*     */   
/*     */   public Object invoke(Object paramObject1, Object paramObject2)
/*     */   {
/* 279 */     paramObject1 = null;paramObject2 = null;return invokeStatic(paramObject1, paramObject2); } public static final Var const__0 = (Var)RT.var("clojure.java.io", "make-reader");
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\java\io$fn__9542.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */