/*    */ package clojure.java;
/*    */ 
/*    */ import clojure.lang.AFunction;
/*    */ 
/*    */ public final class browse$xdg_open_loc
/*    */   extends AFunction
/*    */ {
/*    */   /* Error */
/*    */   public static Object invokeStatic()
/*    */   {
/*    */     // Byte code:
/*    */     //   0: new 13	clojure/java/browse$xdg_open_loc$fn__9717
/*    */     //   3: dup
/*    */     //   4: invokespecial 14	clojure/java/browse$xdg_open_loc$fn__9717:<init>	()V
/*    */     //   7: checkcast 16	clojure/lang/IFn
/*    */     //   10: invokeinterface 19 1 0
/*    */     //   15: astore_0
/*    */     //   16: aload_0
/*    */     //   17: ldc 21
/*    */     //   19: invokestatic 27	clojure/lang/Util:equiv	(Ljava/lang/Object;Ljava/lang/Object;)Z
/*    */     //   22: ifeq +8 -> 30
/*    */     //   25: aconst_null
/*    */     //   26: goto +10 -> 36
/*    */     //   29: pop
/*    */     //   30: aload_0
/*    */     //   31: aconst_null
/*    */     //   32: astore_0
/*    */     //   33: invokestatic 32	clojure/string$trim_newline:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   36: areturn
/*    */     // Line number table:
/*    */     //   Java source line #21	-> byte code offset #0
/*    */     //   Java source line #23	-> byte code offset #7
/*    */     //   Java source line #23	-> byte code offset #10
/*    */     //   Java source line #25	-> byte code offset #16
/*    */     //   Java source line #25	-> byte code offset #19
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	signature
/*    */     //   16	20	0	which_out	Object
/*    */   }
/*    */   
/*    */   public Object invoke()
/*    */   {
/* 21 */     return invokeStatic();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\java\browse$xdg_open_loc.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */