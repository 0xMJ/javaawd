/*    */ package clojure.java;
/*    */ 
/*    */ import clojure.core.find_var;
/*    */ import clojure.core.require;
/*    */ import clojure.lang.AFn;
/*    */ import clojure.lang.AFunction;
/*    */ import clojure.lang.ArraySeq;
/*    */ import clojure.lang.IFn;
/*    */ import clojure.lang.Symbol;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class browse$open_url_in_swing
/*    */   extends AFunction
/*    */ {
/*    */   public Object invoke(Object paramObject)
/*    */   {
/* 57 */     paramObject = null;return invokeStatic(paramObject); } public static final AFn const__3 = (AFn)Symbol.intern("clojure.java.browse-ui", "open-url-in-swing"); public static final AFn const__1 = (AFn)Symbol.intern(null, "clojure.java.browse-ui"); public static Object invokeStatic(Object url) { core.require.invokeStatic(ArraySeq.create(new Object[] { const__1 }));
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 64 */     url = null;return ((IFn)core.find_var.invokeStatic(const__3)).invoke(url);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\java\browse$open_url_in_swing.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */