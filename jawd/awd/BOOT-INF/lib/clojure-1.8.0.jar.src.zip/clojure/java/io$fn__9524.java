/*     */ package clojure.java;
/*     */ 
/*     */ import clojure.lang.AFunction;
/*     */ import clojure.lang.RT;
/*     */ import clojure.lang.Var;
/*     */ 
/*     */ public final class io$fn__9524
/*     */   extends AFunction
/*     */ {
/*     */   /* Error */
/*     */   public static Object invokeStatic(Object x, Object opts)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: ldc 16
/*     */     //   2: aload_0
/*     */     //   3: checkcast 18	java/net/URL
/*     */     //   6: invokevirtual 22	java/net/URL:getProtocol	()Ljava/lang/String;
/*     */     //   9: invokestatic 28	clojure/lang/Util:equiv	(Ljava/lang/Object;Ljava/lang/Object;)Z
/*     */     //   12: ifeq +64 -> 76
/*     */     //   15: new 30	java/io/FileInputStream
/*     */     //   18: dup
/*     */     //   19: aload_0
/*     */     //   20: aconst_null
/*     */     //   21: astore_0
/*     */     //   22: dup
/*     */     //   23: invokestatic 34	clojure/lang/Util:classOf	(Ljava/lang/Object;)Ljava/lang/Class;
/*     */     //   26: getstatic 36	clojure/java/io$fn__9524:__cached_class__0	Ljava/lang/Class;
/*     */     //   29: if_acmpeq +17 -> 46
/*     */     //   32: dup
/*     */     //   33: instanceof 38
/*     */     //   36: ifne +25 -> 61
/*     */     //   39: dup
/*     */     //   40: invokestatic 34	clojure/lang/Util:classOf	(Ljava/lang/Object;)Ljava/lang/Class;
/*     */     //   43: putstatic 36	clojure/java/io$fn__9524:__cached_class__0	Ljava/lang/Class;
/*     */     //   46: getstatic 42	clojure/java/io$fn__9524:const__2	Lclojure/lang/Var;
/*     */     //   49: invokevirtual 48	clojure/lang/Var:getRawRoot	()Ljava/lang/Object;
/*     */     //   52: swap
/*     */     //   53: invokeinterface 54 2 0
/*     */     //   58: goto +8 -> 66
/*     */     //   61: invokeinterface 57 1 0
/*     */     //   66: checkcast 59	java/io/File
/*     */     //   69: invokespecial 62	java/io/FileInputStream:<init>	(Ljava/io/File;)V
/*     */     //   72: goto +13 -> 85
/*     */     //   75: pop
/*     */     //   76: aload_0
/*     */     //   77: aconst_null
/*     */     //   78: astore_0
/*     */     //   79: checkcast 18	java/net/URL
/*     */     //   82: invokevirtual 66	java/net/URL:openStream	()Ljava/io/InputStream;
/*     */     //   85: dup
/*     */     //   86: invokestatic 34	clojure/lang/Util:classOf	(Ljava/lang/Object;)Ljava/lang/Class;
/*     */     //   89: getstatic 68	clojure/java/io$fn__9524:__cached_class__1	Ljava/lang/Class;
/*     */     //   92: if_acmpeq +17 -> 109
/*     */     //   95: dup
/*     */     //   96: instanceof 70
/*     */     //   99: ifne +28 -> 127
/*     */     //   102: dup
/*     */     //   103: invokestatic 34	clojure/lang/Util:classOf	(Ljava/lang/Object;)Ljava/lang/Class;
/*     */     //   106: putstatic 68	clojure/java/io$fn__9524:__cached_class__1	Ljava/lang/Class;
/*     */     //   109: getstatic 73	clojure/java/io$fn__9524:const__0	Lclojure/lang/Var;
/*     */     //   112: invokevirtual 48	clojure/lang/Var:getRawRoot	()Ljava/lang/Object;
/*     */     //   115: swap
/*     */     //   116: aload_1
/*     */     //   117: aconst_null
/*     */     //   118: astore_1
/*     */     //   119: invokeinterface 75 3 0
/*     */     //   124: goto +11 -> 135
/*     */     //   127: aload_1
/*     */     //   128: aconst_null
/*     */     //   129: astore_1
/*     */     //   130: invokeinterface 78 2 0
/*     */     //   135: areturn
/*     */     // Line number table:
/*     */     //   Java source line #235	-> byte code offset #0
/*     */     //   Java source line #236	-> byte code offset #0
/*     */     //   Java source line #237	-> byte code offset #0
/*     */     //   Java source line #237	-> byte code offset #6
/*     */     //   Java source line #237	-> byte code offset #9
/*     */     //   Java source line #238	-> byte code offset #19
/*     */     //   Java source line #238	-> byte code offset #53
/*     */     //   Java source line #239	-> byte code offset #82
/*     */     //   Java source line #236	-> byte code offset #119
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	135	0	x	Object
/*     */     //   0	135	1	opts	Object
/*     */   }
/*     */   
/*     */   public Object invoke(Object paramObject1, Object paramObject2)
/*     */   {
/* 235 */     paramObject1 = null;paramObject2 = null;return invokeStatic(paramObject1, paramObject2); } public static final Var const__2 = (Var)RT.var("clojure.java.io", "as-file"); public static final Var const__0 = (Var)RT.var("clojure.java.io", "make-input-stream");
/*     */   private static Class __cached_class__1;
/*     */   private static Class __cached_class__0;
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\java\io$fn__9524.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */