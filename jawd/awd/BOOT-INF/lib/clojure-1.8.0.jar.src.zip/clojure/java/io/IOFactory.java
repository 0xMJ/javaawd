package clojure.java.io;

public abstract interface IOFactory
{
  public abstract Object make_reader(Object paramObject);
  
  public abstract Object make_writer(Object paramObject);
  
  public abstract Object make_input_stream(Object paramObject);
  
  public abstract Object make_output_stream(Object paramObject);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\java\io\IOFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */