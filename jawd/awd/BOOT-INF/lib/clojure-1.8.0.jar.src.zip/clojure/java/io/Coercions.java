package clojure.java.io;

public abstract interface Coercions
{
  public abstract Object as_file();
  
  public abstract Object as_url();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\java\io\Coercions.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */