/*    */ package clojure.java;
/*    */ 
/*    */ import clojure.lang.AFunction;
/*    */ import clojure.lang.Keyword;
/*    */ import clojure.lang.RT;
/*    */ 
/*    */ public final class shell$stream_to_enc
/*    */   extends AFunction
/*    */ {
/*    */   /* Error */
/*    */   public static Object invokeStatic(Object stream, Object enc)
/*    */   {
/*    */     // Byte code:
/*    */     //   0: aload_1
/*    */     //   1: getstatic 15	clojure/java/shell$stream_to_enc:const__1	Lclojure/lang/Keyword;
/*    */     //   4: invokestatic 21	clojure/lang/Util:equiv	(Ljava/lang/Object;Ljava/lang/Object;)Z
/*    */     //   7: ifeq +13 -> 20
/*    */     //   10: aload_0
/*    */     //   11: aconst_null
/*    */     //   12: astore_0
/*    */     //   13: invokestatic 26	clojure/java/shell$stream_to_bytes:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   16: goto +13 -> 29
/*    */     //   19: pop
/*    */     //   20: aload_0
/*    */     //   21: aconst_null
/*    */     //   22: astore_0
/*    */     //   23: aload_1
/*    */     //   24: aconst_null
/*    */     //   25: astore_1
/*    */     //   26: invokestatic 30	clojure/java/shell$stream_to_string:invokeStatic	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   29: areturn
/*    */     // Line number table:
/*    */     //   Java source line #73	-> byte code offset #0
/*    */     //   Java source line #75	-> byte code offset #0
/*    */     //   Java source line #75	-> byte code offset #4
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	signature
/*    */     //   0	29	0	stream	Object
/*    */     //   0	29	1	enc	Object
/*    */   }
/*    */   
/*    */   public Object invoke(Object paramObject1, Object paramObject2)
/*    */   {
/* 73 */     paramObject1 = null;paramObject2 = null;return invokeStatic(paramObject1, paramObject2); } public static final Keyword const__1 = (Keyword)RT.keyword(null, "bytes");
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\java\shell$stream_to_enc.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */