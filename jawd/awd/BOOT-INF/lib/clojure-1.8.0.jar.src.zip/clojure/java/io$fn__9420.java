/*    */ package clojure.java;
/*    */ 
/*    */ import clojure.lang.AFunction;
/*    */ import clojure.lang.RT;
/*    */ import clojure.lang.Var;
/*    */ 
/*    */ public final class io$fn__9420
/*    */   extends AFunction
/*    */ {
/*    */   /* Error */
/*    */   public static Object invokeStatic(Object u)
/*    */   {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: aconst_null
/*    */     //   2: astore_0
/*    */     //   3: dup
/*    */     //   4: invokestatic 20	clojure/lang/Util:classOf	(Ljava/lang/Object;)Ljava/lang/Class;
/*    */     //   7: getstatic 22	clojure/java/io$fn__9420:__cached_class__0	Ljava/lang/Class;
/*    */     //   10: if_acmpeq +17 -> 27
/*    */     //   13: dup
/*    */     //   14: instanceof 24
/*    */     //   17: ifne +25 -> 42
/*    */     //   20: dup
/*    */     //   21: invokestatic 20	clojure/lang/Util:classOf	(Ljava/lang/Object;)Ljava/lang/Class;
/*    */     //   24: putstatic 22	clojure/java/io$fn__9420:__cached_class__0	Ljava/lang/Class;
/*    */     //   27: getstatic 28	clojure/java/io$fn__9420:const__1	Lclojure/lang/Var;
/*    */     //   30: invokevirtual 34	clojure/lang/Var:getRawRoot	()Ljava/lang/Object;
/*    */     //   33: swap
/*    */     //   34: invokeinterface 39 2 0
/*    */     //   39: goto +8 -> 47
/*    */     //   42: invokeinterface 42 1 0
/*    */     //   47: dup
/*    */     //   48: invokestatic 20	clojure/lang/Util:classOf	(Ljava/lang/Object;)Ljava/lang/Class;
/*    */     //   51: getstatic 44	clojure/java/io$fn__9420:__cached_class__1	Ljava/lang/Class;
/*    */     //   54: if_acmpeq +17 -> 71
/*    */     //   57: dup
/*    */     //   58: instanceof 24
/*    */     //   61: ifne +25 -> 86
/*    */     //   64: dup
/*    */     //   65: invokestatic 20	clojure/lang/Util:classOf	(Ljava/lang/Object;)Ljava/lang/Class;
/*    */     //   68: putstatic 44	clojure/java/io$fn__9420:__cached_class__1	Ljava/lang/Class;
/*    */     //   71: getstatic 47	clojure/java/io$fn__9420:const__0	Lclojure/lang/Var;
/*    */     //   74: invokevirtual 34	clojure/lang/Var:getRawRoot	()Ljava/lang/Object;
/*    */     //   77: swap
/*    */     //   78: invokeinterface 39 2 0
/*    */     //   83: goto +8 -> 91
/*    */     //   86: invokeinterface 50 1 0
/*    */     //   91: areturn
/*    */     // Line number table:
/*    */     //   Java source line #44	-> byte code offset #0
/*    */     //   Java source line #67	-> byte code offset #0
/*    */     //   Java source line #67	-> byte code offset #0
/*    */     //   Java source line #67	-> byte code offset #34
/*    */     //   Java source line #67	-> byte code offset #78
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	signature
/*    */     //   0	91	0	u	Object
/*    */   }
/*    */   
/*    */   public Object invoke(Object paramObject)
/*    */   {
/* 44 */     paramObject = null;return invokeStatic(paramObject); } public static final Var const__1 = (Var)RT.var("clojure.java.io", "as-url"); public static final Var const__0 = (Var)RT.var("clojure.java.io", "as-file");
/*    */   private static Class __cached_class__1;
/*    */   private static Class __cached_class__0;
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\java\io$fn__9420.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */