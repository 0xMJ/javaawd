/*     */ package clojure.java;
/*     */ 
/*     */ import clojure.lang.ISeq;
/*     */ import clojure.lang.RT;
/*     */ import clojure.lang.RestFn;
/*     */ import clojure.lang.Var;
/*     */ 
/*     */ public final class io$copy
/*     */   extends RestFn
/*     */ {
/*     */   /* Error */
/*     */   public static Object invokeStatic(Object input, Object output, ISeq opts)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: getstatic 15	clojure/java/io$copy:const__0	Lclojure/lang/Var;
/*     */     //   3: invokevirtual 21	clojure/lang/Var:getRawRoot	()Ljava/lang/Object;
/*     */     //   6: checkcast 23	clojure/lang/IFn
/*     */     //   9: aload_0
/*     */     //   10: aconst_null
/*     */     //   11: astore_0
/*     */     //   12: aload_1
/*     */     //   13: aconst_null
/*     */     //   14: astore_1
/*     */     //   15: aload_2
/*     */     //   16: dup
/*     */     //   17: ifnull +24 -> 41
/*     */     //   20: getstatic 29	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   23: if_acmpeq +19 -> 42
/*     */     //   26: getstatic 32	clojure/java/io$copy:const__2	Lclojure/lang/Var;
/*     */     //   29: invokevirtual 21	clojure/lang/Var:getRawRoot	()Ljava/lang/Object;
/*     */     //   32: aload_2
/*     */     //   33: aconst_null
/*     */     //   34: astore_2
/*     */     //   35: invokestatic 37	clojure/core$apply:invokeStatic	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   38: goto +5 -> 43
/*     */     //   41: pop
/*     */     //   42: aconst_null
/*     */     //   43: invokeinterface 41 4 0
/*     */     //   48: areturn
/*     */     // Line number table:
/*     */     //   Java source line #391	-> byte code offset #0
/*     */     //   Java source line #406	-> byte code offset #6
/*     */     //   Java source line #406	-> byte code offset #15
/*     */     //   Java source line #406	-> byte code offset #43
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	48	0	input	Object
/*     */     //   0	48	1	output	Object
/*     */     //   0	48	2	opts	ISeq
/*     */   }
/*     */   
/*     */   public Object doInvoke(Object paramObject1, Object paramObject2, Object paramObject3)
/*     */   {
/* 391 */     paramObject1 = null;paramObject2 = null;paramObject3 = null;return invokeStatic(paramObject1, paramObject2, (ISeq)paramObject3); } public static final Var const__2 = (Var)RT.var("clojure.core", "hash-map"); public static final Var const__0 = (Var)RT.var("clojure.java.io", "do-copy");
/*     */   
/*     */   public int getRequiredArity()
/*     */   {
/*     */     return 2;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\java\io$copy.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */