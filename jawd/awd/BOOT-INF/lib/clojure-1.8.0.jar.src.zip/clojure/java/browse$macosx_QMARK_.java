/*    */ package clojure.java;
/*    */ 
/*    */ import clojure.lang.AFunction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class browse$macosx_QMARK_
/*    */   extends AFunction
/*    */ {
/* 17 */   public Object invoke() { return invokeStatic(); }
/*    */   
/* 19 */   public static Object invokeStatic() { return ((String)((String)System.getProperty((String)"os.name")).toLowerCase()).startsWith((String)"mac os x") ? Boolean.TRUE : Boolean.FALSE; }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\java\browse$macosx_QMARK_.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */