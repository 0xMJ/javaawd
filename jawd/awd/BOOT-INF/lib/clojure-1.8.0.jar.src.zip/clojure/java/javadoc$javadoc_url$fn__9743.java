/*    */ package clojure.java;
/*    */ 
/*    */ import clojure.core.str;
/*    */ import clojure.lang.AFunction;
/*    */ import clojure.lang.ArraySeq;
/*    */ import java.io.File;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class javadoc$javadoc_url$fn__9743
/*    */   extends AFunction
/*    */ {
/*    */   Object file_path;
/*    */   
/*    */   public Object invoke(Object p1__9740_SHARP_)
/*    */   {
/* 61 */     p1__9740_SHARP_ = null;return new File((String)core.str.invokeStatic(p1__9740_SHARP_), (String)core.str.invokeStatic(((fn__9743)this).file_path, ArraySeq.create(new Object[] { ".html" }))); } public javadoc$javadoc_url$fn__9743(Object paramObject) { this.file_path = paramObject; }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\java\javadoc$javadoc_url$fn__9743.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */