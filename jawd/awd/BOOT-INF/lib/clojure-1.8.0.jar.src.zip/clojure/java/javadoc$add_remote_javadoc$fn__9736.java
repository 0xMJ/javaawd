/*    */ package clojure.java;
/*    */ 
/*    */ import clojure.core.commute;
/*    */ import clojure.lang.AFunction;
/*    */ import clojure.lang.ArraySeq;
/*    */ import clojure.lang.RT;
/*    */ import clojure.lang.Var;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class javadoc$add_remote_javadoc$fn__9736
/*    */   extends AFunction
/*    */ {
/* 49 */   public Object invoke() { return core.commute.invokeStatic(const__1.get(), const__2.getRawRoot(), ArraySeq.create(new Object[] { ((fn__9736)this).package_prefix, ((fn__9736)this).url })); } public javadoc$add_remote_javadoc$fn__9736(Object paramObject1, Object paramObject2) { this.url = paramObject1;this.package_prefix = paramObject2; } public static final Var const__2 = (Var)RT.var("clojure.core", "assoc"); public static final Var const__1 = (Var)RT.var("clojure.java.javadoc", "*remote-javadocs*");
/*    */   Object package_prefix;
/*    */   Object url;
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\java\javadoc$add_remote_javadoc$fn__9736.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */