/*    */ package clojure.java;
/*    */ 
/*    */ import clojure.core.apply;
/*    */ import clojure.core.merge;
/*    */ import clojure.core.split_with;
/*    */ import clojure.lang.AFunction;
/*    */ import clojure.lang.ArraySeq;
/*    */ import clojure.lang.Keyword;
/*    */ import clojure.lang.RT;
/*    */ import clojure.lang.Tuple;
/*    */ import clojure.lang.Var;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class shell$parse_args
/*    */   extends AFunction
/*    */ {
/*    */   public Object invoke(Object paramObject)
/*    */   {
/* 45 */     paramObject = null;return invokeStatic(paramObject); } public static final Var const__13 = (Var)RT.var("clojure.core", "hash-map"); public static final Var const__7 = (Var)RT.var("clojure.core", "string?"); public static final Var const__5 = (Var)RT.var("clojure.java.shell", "*sh-env*"); public static final Keyword const__4 = (Keyword)RT.keyword(null, "env"); public static final Var const__3 = (Var)RT.var("clojure.java.shell", "*sh-dir*"); public static final Keyword const__2 = (Keyword)RT.keyword(null, "dir"); public static final Keyword const__1 = (Keyword)RT.keyword(null, "in-enc"); public static final Keyword const__0 = (Keyword)RT.keyword(null, "out-enc"); public static Object invokeStatic(Object args) { Object default_encoding = "UTF-8";default_encoding = null;{ const__0, default_encoding, const__1 }[3] = default_encoding; Object[] tmp30_24 = tmp24_18;tmp30_24[4] = const__2; Object[] tmp36_30 = tmp30_24;tmp36_30[5] = const__3.get(); Object[] tmp45_36 = tmp36_30;tmp45_36[6] = const__4; Object[] tmp52_45 = tmp45_36;tmp52_45[7] = const__5.get();Object default_opts = RT.mapUniqueKeys(tmp52_45);args = null;Object vec__9695 = core.split_with.invokeStatic(const__7.getRawRoot(), args);
/*    */     
/* 47 */     Object cmd = RT.nth(vec__9695, RT.intCast(0L), null);vec__9695 = null;Object opts = RT.nth(vec__9695, RT.intCast(1L), null);cmd = null; Object[] tmp112_109 = new Object[2];default_opts = null;tmp112_109[0] = default_opts; Object[] tmp118_112 = tmp112_109;opts = null;tmp118_112[1] = core.apply.invokeStatic(const__13.getRawRoot(), opts);return Tuple.create(cmd, core.merge.invokeStatic(ArraySeq.create(tmp118_112)));
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\java\shell$parse_args.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */