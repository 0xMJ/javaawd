/*    */ package clojure.java;
/*    */ 
/*    */ import clojure.lang.AFunction;
/*    */ import clojure.lang.LockingTransaction;
/*    */ import java.util.concurrent.Callable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class javadoc$add_remote_javadoc
/*    */   extends AFunction
/*    */ {
/*    */   public Object invoke(Object paramObject1, Object paramObject2)
/*    */   {
/* 44 */     paramObject1 = null;paramObject2 = null;return invokeStatic(paramObject1, paramObject2); } public static Object invokeStatic(Object package_prefix, Object url) { url = null;package_prefix = null;
/*    */     
/*    */ 
/*    */ 
/*    */ 
/* 49 */     return LockingTransaction.runInTransaction((Callable)new javadoc.add_remote_javadoc.fn__9736(url, package_prefix));
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\java\javadoc$add_remote_javadoc.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */