/*     */ package clojure.reflect;
/*     */ 
/*     */ import clojure.lang.IPersistentVector;
/*     */ import clojure.lang.IType;
/*     */ import clojure.lang.Keyword;
/*     */ import clojure.lang.RT;
/*     */ import clojure.lang.Symbol;
/*     */ import clojure.lang.Tuple;
/*     */ import clojure.lang.Var;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AsmReflector
/*     */   implements Reflector, IType
/*     */ {
/* 196 */   public AsmReflector(Object paramObject) { this.class_resolver = paramObject; } public static final Keyword const__5 = (Keyword)RT.keyword(null, "members"); public static final Keyword const__4 = (Keyword)RT.keyword(null, "flags"); public static final Keyword const__3 = (Keyword)RT.keyword(null, "bases"); public static final Var const__0 = (Var)RT.var("clojure.reflect", "resolve-class");
/*     */   private static Class __cached_class__0;
/*     */   public final Object class_resolver;
/*     */   
/*     */   public static IPersistentVector getBasis()
/*     */   {
/*     */     return Tuple.create(Symbol.intern(null, "class-resolver"));
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public Object do_reflect(Object typeref)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 20	clojure/reflect/AsmReflector:class_resolver	Ljava/lang/Object;
/*     */     //   4: dup
/*     */     //   5: invokestatic 44	clojure/lang/Util:classOf	(Ljava/lang/Object;)Ljava/lang/Class;
/*     */     //   8: getstatic 46	clojure/reflect/AsmReflector:__cached_class__0	Ljava/lang/Class;
/*     */     //   11: if_acmpeq +17 -> 28
/*     */     //   14: dup
/*     */     //   15: instanceof 48
/*     */     //   18: ifne +26 -> 44
/*     */     //   21: dup
/*     */     //   22: invokestatic 44	clojure/lang/Util:classOf	(Ljava/lang/Object;)Ljava/lang/Class;
/*     */     //   25: putstatic 46	clojure/reflect/AsmReflector:__cached_class__0	Ljava/lang/Class;
/*     */     //   28: getstatic 52	clojure/reflect/AsmReflector:const__0	Lclojure/lang/Var;
/*     */     //   31: invokevirtual 58	clojure/lang/Var:getRawRoot	()Ljava/lang/Object;
/*     */     //   34: swap
/*     */     //   35: aload_1
/*     */     //   36: invokeinterface 64 3 0
/*     */     //   41: goto +9 -> 50
/*     */     //   44: aload_1
/*     */     //   45: invokeinterface 67 2 0
/*     */     //   50: astore_2
/*     */     //   51: aload_1
/*     */     //   52: aconst_null
/*     */     //   53: astore_1
/*     */     //   54: invokestatic 72	clojure/reflect$typesym:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   57: astore_3
/*     */     //   58: new 74	clojure/asm/ClassReader
/*     */     //   61: dup
/*     */     //   62: aload_2
/*     */     //   63: checkcast 76	java/io/InputStream
/*     */     //   66: invokespecial 79	clojure/asm/ClassReader:<init>	(Ljava/io/InputStream;)V
/*     */     //   69: astore 4
/*     */     //   71: bipush 6
/*     */     //   73: anewarray 4	java/lang/Object
/*     */     //   76: dup
/*     */     //   77: iconst_0
/*     */     //   78: getstatic 83	clojure/reflect/AsmReflector:const__3	Lclojure/lang/Keyword;
/*     */     //   81: aastore
/*     */     //   82: dup
/*     */     //   83: iconst_1
/*     */     //   84: getstatic 89	clojure/lang/PersistentHashSet:EMPTY	Lclojure/lang/PersistentHashSet;
/*     */     //   87: aastore
/*     */     //   88: dup
/*     */     //   89: iconst_2
/*     */     //   90: getstatic 92	clojure/reflect/AsmReflector:const__4	Lclojure/lang/Keyword;
/*     */     //   93: aastore
/*     */     //   94: dup
/*     */     //   95: iconst_3
/*     */     //   96: getstatic 89	clojure/lang/PersistentHashSet:EMPTY	Lclojure/lang/PersistentHashSet;
/*     */     //   99: aastore
/*     */     //   100: dup
/*     */     //   101: iconst_4
/*     */     //   102: getstatic 95	clojure/reflect/AsmReflector:const__5	Lclojure/lang/Keyword;
/*     */     //   105: aastore
/*     */     //   106: dup
/*     */     //   107: iconst_5
/*     */     //   108: getstatic 89	clojure/lang/PersistentHashSet:EMPTY	Lclojure/lang/PersistentHashSet;
/*     */     //   111: aastore
/*     */     //   112: invokestatic 101	clojure/lang/RT:mapUniqueKeys	([Ljava/lang/Object;)Lclojure/lang/IPersistentMap;
/*     */     //   115: invokestatic 104	clojure/core$atom:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   118: astore 5
/*     */     //   120: aload 4
/*     */     //   122: aconst_null
/*     */     //   123: astore 4
/*     */     //   125: checkcast 74	clojure/asm/ClassReader
/*     */     //   128: new 106	clojure/reflect/proxy$clojure/asm/ClassVisitor$ff19274a
/*     */     //   131: dup
/*     */     //   132: getstatic 112	clojure/asm/Opcodes:ASM4	I
/*     */     //   135: invokespecial 115	clojure/reflect/proxy$clojure/asm/ClassVisitor$ff19274a:<init>	(I)V
/*     */     //   138: astore 6
/*     */     //   140: aload 6
/*     */     //   142: bipush 14
/*     */     //   144: anewarray 4	java/lang/Object
/*     */     //   147: dup
/*     */     //   148: iconst_0
/*     */     //   149: ldc 117
/*     */     //   151: aastore
/*     */     //   152: dup
/*     */     //   153: iconst_1
/*     */     //   154: new 119	clojure/reflect/AsmReflector$fn__10057
/*     */     //   157: dup
/*     */     //   158: aload 5
/*     */     //   160: invokespecial 121	clojure/reflect/AsmReflector$fn__10057:<init>	(Ljava/lang/Object;)V
/*     */     //   163: aastore
/*     */     //   164: dup
/*     */     //   165: iconst_2
/*     */     //   166: ldc 123
/*     */     //   168: aastore
/*     */     //   169: dup
/*     */     //   170: iconst_3
/*     */     //   171: new 125	clojure/reflect/AsmReflector$fn__10060
/*     */     //   174: dup
/*     */     //   175: invokespecial 126	clojure/reflect/AsmReflector$fn__10060:<init>	()V
/*     */     //   178: aastore
/*     */     //   179: dup
/*     */     //   180: iconst_4
/*     */     //   181: ldc -128
/*     */     //   183: aastore
/*     */     //   184: dup
/*     */     //   185: iconst_5
/*     */     //   186: new 130	clojure/reflect/AsmReflector$fn__10062
/*     */     //   189: dup
/*     */     //   190: invokespecial 131	clojure/reflect/AsmReflector$fn__10062:<init>	()V
/*     */     //   193: aastore
/*     */     //   194: dup
/*     */     //   195: bipush 6
/*     */     //   197: ldc -123
/*     */     //   199: aastore
/*     */     //   200: dup
/*     */     //   201: bipush 7
/*     */     //   203: new 135	clojure/reflect/AsmReflector$fn__10064
/*     */     //   206: dup
/*     */     //   207: invokespecial 136	clojure/reflect/AsmReflector$fn__10064:<init>	()V
/*     */     //   210: aastore
/*     */     //   211: dup
/*     */     //   212: bipush 8
/*     */     //   214: ldc -118
/*     */     //   216: aastore
/*     */     //   217: dup
/*     */     //   218: bipush 9
/*     */     //   220: new 140	clojure/reflect/AsmReflector$fn__10066
/*     */     //   223: dup
/*     */     //   224: aload 5
/*     */     //   226: aload_3
/*     */     //   227: invokespecial 143	clojure/reflect/AsmReflector$fn__10066:<init>	(Ljava/lang/Object;Ljava/lang/Object;)V
/*     */     //   230: aastore
/*     */     //   231: dup
/*     */     //   232: bipush 10
/*     */     //   234: ldc -111
/*     */     //   236: aastore
/*     */     //   237: dup
/*     */     //   238: bipush 11
/*     */     //   240: new 147	clojure/reflect/AsmReflector$fn__10068
/*     */     //   243: dup
/*     */     //   244: aload 5
/*     */     //   246: aload_3
/*     */     //   247: aconst_null
/*     */     //   248: astore_3
/*     */     //   249: invokespecial 148	clojure/reflect/AsmReflector$fn__10068:<init>	(Ljava/lang/Object;Ljava/lang/Object;)V
/*     */     //   252: aastore
/*     */     //   253: dup
/*     */     //   254: bipush 12
/*     */     //   256: ldc -106
/*     */     //   258: aastore
/*     */     //   259: dup
/*     */     //   260: bipush 13
/*     */     //   262: new 152	clojure/reflect/AsmReflector$fn__10071
/*     */     //   265: dup
/*     */     //   266: invokespecial 153	clojure/reflect/AsmReflector$fn__10071:<init>	()V
/*     */     //   269: aastore
/*     */     //   270: invokestatic 101	clojure/lang/RT:mapUniqueKeys	([Ljava/lang/Object;)Lclojure/lang/IPersistentMap;
/*     */     //   273: invokestatic 157	clojure/core$init_proxy:invokeStatic	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   276: pop
/*     */     //   277: aload 6
/*     */     //   279: aconst_null
/*     */     //   280: astore 6
/*     */     //   282: checkcast 160	clojure/asm/ClassVisitor
/*     */     //   285: lconst_0
/*     */     //   286: invokestatic 164	clojure/lang/RT:intCast	(J)I
/*     */     //   289: invokevirtual 168	clojure/asm/ClassReader:accept	(Lclojure/asm/ClassVisitor;I)V
/*     */     //   292: aconst_null
/*     */     //   293: pop
/*     */     //   294: aload 5
/*     */     //   296: aconst_null
/*     */     //   297: astore 5
/*     */     //   299: invokestatic 171	clojure/core$deref:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   302: astore 7
/*     */     //   304: aload_2
/*     */     //   305: aconst_null
/*     */     //   306: astore_2
/*     */     //   307: checkcast 76	java/io/InputStream
/*     */     //   310: invokevirtual 177	java/io/InputStream:close	()V
/*     */     //   313: aconst_null
/*     */     //   314: pop
/*     */     //   315: goto +19 -> 334
/*     */     //   318: astore 8
/*     */     //   320: aload_2
/*     */     //   321: aconst_null
/*     */     //   322: astore_2
/*     */     //   323: checkcast 76	java/io/InputStream
/*     */     //   326: invokevirtual 177	java/io/InputStream:close	()V
/*     */     //   329: aconst_null
/*     */     //   330: pop
/*     */     //   331: aload 8
/*     */     //   333: athrow
/*     */     //   334: aload 7
/*     */     //   336: areturn
/*     */     // Line number table:
/*     */     //   Java source line #196	-> byte code offset #0
/*     */     //   Java source line #199	-> byte code offset #0
/*     */     //   Java source line #199	-> byte code offset #36
/*     */     //   Java source line #205	-> byte code offset #132
/*     */     //   Java source line #203	-> byte code offset #289
/*     */     //   Java source line #199	-> byte code offset #310
/*     */     //   Java source line #199	-> byte code offset #326
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	336	0	this	AsmReflector
/*     */     //   0	336	1	typeref	Object
/*     */     //   51	285	2	is	Object
/*     */     //   58	244	3	class_symbol	Object
/*     */     //   71	231	4	r	Object
/*     */     //   120	182	5	result	Object
/*     */     //   140	142	6	p__5959__auto__10074	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   51	304	318	finally
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\reflect\AsmReflector.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */