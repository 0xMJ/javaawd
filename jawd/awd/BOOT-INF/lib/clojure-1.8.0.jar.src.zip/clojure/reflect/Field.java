/*     */ package clojure.reflect;
/*     */ 
/*     */ import clojure.core.class;
/*     */ import clojure.core.concat;
/*     */ import clojure.core.keys;
/*     */ import clojure.core.not;
/*     */ import clojure.core.seq__4357;
/*     */ import clojure.core.set;
/*     */ import clojure.core.some;
/*     */ import clojure.core.vals;
/*     */ import clojure.lang.AFn;
/*     */ import clojure.lang.APersistentMap;
/*     */ import clojure.lang.Counted;
/*     */ import clojure.lang.IFn;
/*     */ import clojure.lang.IHashEq;
/*     */ import clojure.lang.IKeywordLookup;
/*     */ import clojure.lang.ILookup;
/*     */ import clojure.lang.ILookupThunk;
/*     */ import clojure.lang.IObj;
/*     */ import clojure.lang.IPersistentCollection;
/*     */ import clojure.lang.IPersistentMap;
/*     */ import clojure.lang.IPersistentVector;
/*     */ import clojure.lang.IRecord;
/*     */ import clojure.lang.ISeq;
/*     */ import clojure.lang.Keyword;
/*     */ import clojure.lang.MapEntry;
/*     */ import clojure.lang.Numbers;
/*     */ import clojure.lang.PersistentHashSet;
/*     */ import clojure.lang.RT;
/*     */ import clojure.lang.RecordIterator;
/*     */ import clojure.lang.Symbol;
/*     */ import clojure.lang.Tuple;
/*     */ import clojure.lang.Util;
/*     */ import clojure.lang.Var;
/*     */ import java.io.Serializable;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Field
/*     */   implements IRecord, IHashEq, IObj, ILookup, IKeywordLookup, IPersistentMap, Map, Serializable
/*     */ {
/* 148 */   public Set entrySet() { return (Set)core.set.invokeStatic(this); } public Collection values() { return (Collection)core.vals.invokeStatic(this); } public Set keySet() { return (Set)core.set.invokeStatic(core.keys.invokeStatic(this)); }
/*     */   
/*     */   /* Error */
/*     */   public void clear()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: new 188	java/lang/UnsupportedOperationException
/*     */     //   3: dup
/*     */     //   4: invokespecial 367	java/lang/UnsupportedOperationException:<init>	()V
/*     */     //   7: checkcast 209	java/lang/Throwable
/*     */     //   10: athrow
/*     */     //   11: pop
/*     */     //   12: return
/*     */     // Line number table:
/*     */     //   Java source line #148	-> byte code offset #0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	12	0	this	Field
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public void putAll(Map m__6461__auto__)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: new 188	java/lang/UnsupportedOperationException
/*     */     //   3: dup
/*     */     //   4: invokespecial 367	java/lang/UnsupportedOperationException:<init>	()V
/*     */     //   7: checkcast 209	java/lang/Throwable
/*     */     //   10: athrow
/*     */     //   11: pop
/*     */     //   12: return
/*     */     // Line number table:
/*     */     //   Java source line #148	-> byte code offset #0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	12	0	this	Field
/*     */     //   0	12	1	m__6461__auto__	Map
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public Object remove(Object k__6459__auto__)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: new 188	java/lang/UnsupportedOperationException
/*     */     //   3: dup
/*     */     //   4: invokespecial 367	java/lang/UnsupportedOperationException:<init>	()V
/*     */     //   7: checkcast 209	java/lang/Throwable
/*     */     //   10: athrow
/*     */     //   11: areturn
/*     */     // Line number table:
/*     */     //   Java source line #148	-> byte code offset #0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	11	0	this	Field
/*     */     //   0	11	1	k__6459__auto__	Object
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public Object put(Object k__6456__auto__, Object v__6457__auto__)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: new 188	java/lang/UnsupportedOperationException
/*     */     //   3: dup
/*     */     //   4: invokespecial 367	java/lang/UnsupportedOperationException:<init>	()V
/*     */     //   7: checkcast 209	java/lang/Throwable
/*     */     //   10: athrow
/*     */     //   11: areturn
/*     */     // Line number table:
/*     */     //   Java source line #148	-> byte code offset #0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	11	0	this	Field
/*     */     //   0	11	1	k__6456__auto__	Object
/*     */     //   0	11	2	v__6457__auto__	Object
/*     */   }
/*     */   
/*     */   public Object get(Object k__6454__auto__)
/*     */   {
/* 148 */     k__6454__auto__ = null;return ((ILookup)this).valAt(k__6454__auto__); } public boolean containsValue(Object v__6452__auto__) { Object[] tmp4_1 = new Object[1];v__6452__auto__ = null;tmp4_1[0] = v__6452__auto__;return RT.booleanCast(core.some.invokeStatic(RT.set(tmp4_1), core.vals.invokeStatic(this))); } public boolean isEmpty() { return Util.equiv(0L, ((Counted)this).count()); } public int size() { return ((Counted)this).count(); }
/*     */   
/*     */   /* Error */
/*     */   public IPersistentMap without(Object k__6448__auto__)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: getstatic 319	clojure/reflect/Field:const__12	Lclojure/lang/AFn;
/*     */     //   3: aload_1
/*     */     //   4: invokestatic 322	clojure/core$contains_QMARK_:invokeStatic	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   7: dup
/*     */     //   8: ifnull +32 -> 40
/*     */     //   11: getstatic 237	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   14: if_acmpeq +27 -> 41
/*     */     //   17: getstatic 328	clojure/lang/PersistentArrayMap:EMPTY	Lclojure/lang/PersistentArrayMap;
/*     */     //   20: aload_0
/*     */     //   21: invokestatic 331	clojure/core$into:invokeStatic	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   24: aload_0
/*     */     //   25: getfield 43	clojure/reflect/Field:__meta	Ljava/lang/Object;
/*     */     //   28: invokestatic 334	clojure/core$with_meta__4375:invokeStatic	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   31: aload_1
/*     */     //   32: aconst_null
/*     */     //   33: astore_1
/*     */     //   34: invokestatic 337	clojure/core$dissoc:invokeStatic	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   37: goto +44 -> 81
/*     */     //   40: pop
/*     */     //   41: new 2	clojure/reflect/Field
/*     */     //   44: dup
/*     */     //   45: aload_0
/*     */     //   46: getfield 35	clojure/reflect/Field:name	Ljava/lang/Object;
/*     */     //   49: aload_0
/*     */     //   50: getfield 37	clojure/reflect/Field:type	Ljava/lang/Object;
/*     */     //   53: aload_0
/*     */     //   54: getfield 39	clojure/reflect/Field:declaring_class	Ljava/lang/Object;
/*     */     //   57: aload_0
/*     */     //   58: getfield 41	clojure/reflect/Field:flags	Ljava/lang/Object;
/*     */     //   61: aload_0
/*     */     //   62: getfield 43	clojure/reflect/Field:__meta	Ljava/lang/Object;
/*     */     //   65: aload_0
/*     */     //   66: getfield 45	clojure/reflect/Field:__extmap	Ljava/lang/Object;
/*     */     //   69: aload_1
/*     */     //   70: aconst_null
/*     */     //   71: astore_1
/*     */     //   72: invokestatic 337	clojure/core$dissoc:invokeStatic	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   75: invokestatic 340	clojure/core$not_empty:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   78: invokespecial 48	clojure/reflect/Field:<init>	(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
/*     */     //   81: checkcast 16	clojure/lang/IPersistentMap
/*     */     //   84: areturn
/*     */     // Line number table:
/*     */     //   Java source line #148	-> byte code offset #0
/*     */     //   Java source line #148	-> byte code offset #0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	84	0	this	Field
/*     */     //   0	84	1	k__6448__auto__	Object
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public IPersistentMap assoc(Object k__6446__auto__, Object G__10000)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: getstatic 303	clojure/reflect/Field:const__17	Lclojure/lang/Var;
/*     */     //   3: invokevirtual 309	clojure/lang/Var:getRawRoot	()Ljava/lang/Object;
/*     */     //   6: astore_3
/*     */     //   7: aload_1
/*     */     //   8: astore 4
/*     */     //   10: aload_3
/*     */     //   11: checkcast 219	clojure/lang/IFn
/*     */     //   14: getstatic 134	clojure/reflect/Field:const__8	Lclojure/lang/Keyword;
/*     */     //   17: aload 4
/*     */     //   19: invokeinterface 222 3 0
/*     */     //   24: dup
/*     */     //   25: ifnull +42 -> 67
/*     */     //   28: getstatic 237	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   31: if_acmpeq +37 -> 68
/*     */     //   34: new 2	clojure/reflect/Field
/*     */     //   37: dup
/*     */     //   38: aload_2
/*     */     //   39: aconst_null
/*     */     //   40: astore_2
/*     */     //   41: aload_0
/*     */     //   42: getfield 37	clojure/reflect/Field:type	Ljava/lang/Object;
/*     */     //   45: aload_0
/*     */     //   46: getfield 39	clojure/reflect/Field:declaring_class	Ljava/lang/Object;
/*     */     //   49: aload_0
/*     */     //   50: getfield 41	clojure/reflect/Field:flags	Ljava/lang/Object;
/*     */     //   53: aload_0
/*     */     //   54: getfield 43	clojure/reflect/Field:__meta	Ljava/lang/Object;
/*     */     //   57: aload_0
/*     */     //   58: getfield 45	clojure/reflect/Field:__extmap	Ljava/lang/Object;
/*     */     //   61: invokespecial 48	clojure/reflect/Field:<init>	(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
/*     */     //   64: goto +223 -> 287
/*     */     //   67: pop
/*     */     //   68: aload_3
/*     */     //   69: checkcast 219	clojure/lang/IFn
/*     */     //   72: getstatic 137	clojure/reflect/Field:const__9	Lclojure/lang/Keyword;
/*     */     //   75: aload 4
/*     */     //   77: invokeinterface 222 3 0
/*     */     //   82: dup
/*     */     //   83: ifnull +42 -> 125
/*     */     //   86: getstatic 237	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   89: if_acmpeq +37 -> 126
/*     */     //   92: new 2	clojure/reflect/Field
/*     */     //   95: dup
/*     */     //   96: aload_0
/*     */     //   97: getfield 35	clojure/reflect/Field:name	Ljava/lang/Object;
/*     */     //   100: aload_2
/*     */     //   101: aconst_null
/*     */     //   102: astore_2
/*     */     //   103: aload_0
/*     */     //   104: getfield 39	clojure/reflect/Field:declaring_class	Ljava/lang/Object;
/*     */     //   107: aload_0
/*     */     //   108: getfield 41	clojure/reflect/Field:flags	Ljava/lang/Object;
/*     */     //   111: aload_0
/*     */     //   112: getfield 43	clojure/reflect/Field:__meta	Ljava/lang/Object;
/*     */     //   115: aload_0
/*     */     //   116: getfield 45	clojure/reflect/Field:__extmap	Ljava/lang/Object;
/*     */     //   119: invokespecial 48	clojure/reflect/Field:<init>	(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
/*     */     //   122: goto +165 -> 287
/*     */     //   125: pop
/*     */     //   126: aload_3
/*     */     //   127: checkcast 219	clojure/lang/IFn
/*     */     //   130: getstatic 140	clojure/reflect/Field:const__10	Lclojure/lang/Keyword;
/*     */     //   133: aload 4
/*     */     //   135: invokeinterface 222 3 0
/*     */     //   140: dup
/*     */     //   141: ifnull +42 -> 183
/*     */     //   144: getstatic 237	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   147: if_acmpeq +37 -> 184
/*     */     //   150: new 2	clojure/reflect/Field
/*     */     //   153: dup
/*     */     //   154: aload_0
/*     */     //   155: getfield 35	clojure/reflect/Field:name	Ljava/lang/Object;
/*     */     //   158: aload_0
/*     */     //   159: getfield 37	clojure/reflect/Field:type	Ljava/lang/Object;
/*     */     //   162: aload_2
/*     */     //   163: aconst_null
/*     */     //   164: astore_2
/*     */     //   165: aload_0
/*     */     //   166: getfield 41	clojure/reflect/Field:flags	Ljava/lang/Object;
/*     */     //   169: aload_0
/*     */     //   170: getfield 43	clojure/reflect/Field:__meta	Ljava/lang/Object;
/*     */     //   173: aload_0
/*     */     //   174: getfield 45	clojure/reflect/Field:__extmap	Ljava/lang/Object;
/*     */     //   177: invokespecial 48	clojure/reflect/Field:<init>	(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
/*     */     //   180: goto +107 -> 287
/*     */     //   183: pop
/*     */     //   184: aload_3
/*     */     //   185: aconst_null
/*     */     //   186: astore_3
/*     */     //   187: checkcast 219	clojure/lang/IFn
/*     */     //   190: getstatic 131	clojure/reflect/Field:const__11	Lclojure/lang/Keyword;
/*     */     //   193: aload 4
/*     */     //   195: aconst_null
/*     */     //   196: astore 4
/*     */     //   198: invokeinterface 222 3 0
/*     */     //   203: dup
/*     */     //   204: ifnull +42 -> 246
/*     */     //   207: getstatic 237	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   210: if_acmpeq +37 -> 247
/*     */     //   213: new 2	clojure/reflect/Field
/*     */     //   216: dup
/*     */     //   217: aload_0
/*     */     //   218: getfield 35	clojure/reflect/Field:name	Ljava/lang/Object;
/*     */     //   221: aload_0
/*     */     //   222: getfield 37	clojure/reflect/Field:type	Ljava/lang/Object;
/*     */     //   225: aload_0
/*     */     //   226: getfield 39	clojure/reflect/Field:declaring_class	Ljava/lang/Object;
/*     */     //   229: aload_2
/*     */     //   230: aconst_null
/*     */     //   231: astore_2
/*     */     //   232: aload_0
/*     */     //   233: getfield 43	clojure/reflect/Field:__meta	Ljava/lang/Object;
/*     */     //   236: aload_0
/*     */     //   237: getfield 45	clojure/reflect/Field:__extmap	Ljava/lang/Object;
/*     */     //   240: invokespecial 48	clojure/reflect/Field:<init>	(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
/*     */     //   243: goto +44 -> 287
/*     */     //   246: pop
/*     */     //   247: new 2	clojure/reflect/Field
/*     */     //   250: dup
/*     */     //   251: aload_0
/*     */     //   252: getfield 35	clojure/reflect/Field:name	Ljava/lang/Object;
/*     */     //   255: aload_0
/*     */     //   256: getfield 37	clojure/reflect/Field:type	Ljava/lang/Object;
/*     */     //   259: aload_0
/*     */     //   260: getfield 39	clojure/reflect/Field:declaring_class	Ljava/lang/Object;
/*     */     //   263: aload_0
/*     */     //   264: getfield 41	clojure/reflect/Field:flags	Ljava/lang/Object;
/*     */     //   267: aload_0
/*     */     //   268: getfield 43	clojure/reflect/Field:__meta	Ljava/lang/Object;
/*     */     //   271: aload_0
/*     */     //   272: getfield 45	clojure/reflect/Field:__extmap	Ljava/lang/Object;
/*     */     //   275: aload_1
/*     */     //   276: aconst_null
/*     */     //   277: astore_1
/*     */     //   278: aload_2
/*     */     //   279: aconst_null
/*     */     //   280: astore_2
/*     */     //   281: invokestatic 313	clojure/core$assoc__4371:invokeStatic	(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   284: invokespecial 48	clojure/reflect/Field:<init>	(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
/*     */     //   287: checkcast 16	clojure/lang/IPersistentMap
/*     */     //   290: areturn
/*     */     // Line number table:
/*     */     //   Java source line #148	-> byte code offset #0
/*     */     //   Java source line #148	-> byte code offset #10
/*     */     //   Java source line #148	-> byte code offset #11
/*     */     //   Java source line #148	-> byte code offset #19
/*     */     //   Java source line #148	-> byte code offset #68
/*     */     //   Java source line #148	-> byte code offset #69
/*     */     //   Java source line #148	-> byte code offset #77
/*     */     //   Java source line #148	-> byte code offset #126
/*     */     //   Java source line #148	-> byte code offset #127
/*     */     //   Java source line #148	-> byte code offset #135
/*     */     //   Java source line #148	-> byte code offset #184
/*     */     //   Java source line #148	-> byte code offset #187
/*     */     //   Java source line #148	-> byte code offset #198
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	290	0	this	Field
/*     */     //   0	290	1	k__6446__auto__	Object
/*     */     //   0	290	2	G__10000	Object
/*     */     //   7	280	3	pred__10002	Object
/*     */     //   10	277	4	expr__10003	Object
/*     */   }
/*     */   
/* 148 */   public Iterator iterator() { return (Iterator)new RecordIterator((ILookup)this, (IPersistentVector)const__19, (Iterator)RT.iter(this.__extmap)); } public ISeq seq() { return (ISeq)core.seq__4357.invokeStatic(core.concat.invokeStatic(Tuple.create(MapEntry.create(const__8, this.name), MapEntry.create(const__9, this.type), MapEntry.create(const__10, this.declaring_class), MapEntry.create(const__11, this.flags)), this.__extmap)); }
/*     */   
/*     */   /* Error */
/*     */   public clojure.lang.IMapEntry entryAt(Object k__6441__auto__)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: checkcast 12	clojure/lang/ILookup
/*     */     //   4: aload_1
/*     */     //   5: aload_0
/*     */     //   6: invokeinterface 120 3 0
/*     */     //   11: astore_2
/*     */     //   12: aload_0
/*     */     //   13: aload_2
/*     */     //   14: invokestatic 228	clojure/lang/Util:identical	(Ljava/lang/Object;Ljava/lang/Object;)Z
/*     */     //   17: ifeq +8 -> 25
/*     */     //   20: aconst_null
/*     */     //   21: goto +13 -> 34
/*     */     //   24: pop
/*     */     //   25: aload_1
/*     */     //   26: aconst_null
/*     */     //   27: astore_1
/*     */     //   28: aload_2
/*     */     //   29: aconst_null
/*     */     //   30: astore_2
/*     */     //   31: invokestatic 264	clojure/lang/MapEntry:create	(Ljava/lang/Object;Ljava/lang/Object;)Lclojure/lang/MapEntry;
/*     */     //   34: checkcast 267	clojure/lang/IMapEntry
/*     */     //   37: areturn
/*     */     // Line number table:
/*     */     //   Java source line #148	-> byte code offset #0
/*     */     //   Java source line #148	-> byte code offset #6
/*     */     //   Java source line #148	-> byte code offset #12
/*     */     //   Java source line #148	-> byte code offset #14
/*     */     //   Java source line #148	-> byte code offset #31
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	37	0	this	Field
/*     */     //   0	37	1	k__6441__auto__	Object
/*     */     //   12	22	2	v__6442__auto__10020	Object
/*     */   }
/*     */   
/*     */   public boolean containsKey(Object k__6439__auto__)
/*     */   {
/* 148 */     k__6439__auto__ = null;return ((Boolean)core.not.invokeStatic(Util.identical(this, ((ILookup)this).valAt(k__6439__auto__, this)) ? Boolean.TRUE : Boolean.FALSE)).booleanValue();
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public boolean equiv(Object G__10000)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: aload_1
/*     */     //   2: invokestatic 228	clojure/lang/Util:identical	(Ljava/lang/Object;Ljava/lang/Object;)Z
/*     */     //   5: istore_2
/*     */     //   6: iload_2
/*     */     //   7: ifeq +20 -> 27
/*     */     //   10: iload_2
/*     */     //   11: ifeq +9 -> 20
/*     */     //   14: getstatic 234	java/lang/Boolean:TRUE	Ljava/lang/Boolean;
/*     */     //   17: goto +6 -> 23
/*     */     //   20: getstatic 237	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   23: goto +211 -> 234
/*     */     //   26: pop
/*     */     //   27: aload_0
/*     */     //   28: invokestatic 154	clojure/core$class:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   31: aload_1
/*     */     //   32: invokestatic 154	clojure/core$class:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   35: invokestatic 228	clojure/lang/Util:identical	(Ljava/lang/Object;Ljava/lang/Object;)Z
/*     */     //   38: ifeq +195 -> 233
/*     */     //   41: aload_1
/*     */     //   42: aconst_null
/*     */     //   43: astore_1
/*     */     //   44: astore_3
/*     */     //   45: aload_0
/*     */     //   46: getfield 35	clojure/reflect/Field:name	Ljava/lang/Object;
/*     */     //   49: aload_3
/*     */     //   50: checkcast 2	clojure/reflect/Field
/*     */     //   53: getfield 35	clojure/reflect/Field:name	Ljava/lang/Object;
/*     */     //   56: invokestatic 239	clojure/lang/Util:equiv	(Ljava/lang/Object;Ljava/lang/Object;)Z
/*     */     //   59: istore 4
/*     */     //   61: iload 4
/*     */     //   63: ifeq +152 -> 215
/*     */     //   66: aload_0
/*     */     //   67: getfield 37	clojure/reflect/Field:type	Ljava/lang/Object;
/*     */     //   70: aload_3
/*     */     //   71: checkcast 2	clojure/reflect/Field
/*     */     //   74: getfield 37	clojure/reflect/Field:type	Ljava/lang/Object;
/*     */     //   77: invokestatic 239	clojure/lang/Util:equiv	(Ljava/lang/Object;Ljava/lang/Object;)Z
/*     */     //   80: istore 5
/*     */     //   82: iload 5
/*     */     //   84: ifeq +113 -> 197
/*     */     //   87: aload_0
/*     */     //   88: getfield 39	clojure/reflect/Field:declaring_class	Ljava/lang/Object;
/*     */     //   91: aload_3
/*     */     //   92: checkcast 2	clojure/reflect/Field
/*     */     //   95: getfield 39	clojure/reflect/Field:declaring_class	Ljava/lang/Object;
/*     */     //   98: invokestatic 239	clojure/lang/Util:equiv	(Ljava/lang/Object;Ljava/lang/Object;)Z
/*     */     //   101: istore 6
/*     */     //   103: iload 6
/*     */     //   105: ifeq +74 -> 179
/*     */     //   108: aload_0
/*     */     //   109: getfield 41	clojure/reflect/Field:flags	Ljava/lang/Object;
/*     */     //   112: aload_3
/*     */     //   113: checkcast 2	clojure/reflect/Field
/*     */     //   116: getfield 41	clojure/reflect/Field:flags	Ljava/lang/Object;
/*     */     //   119: invokestatic 239	clojure/lang/Util:equiv	(Ljava/lang/Object;Ljava/lang/Object;)Z
/*     */     //   122: istore 7
/*     */     //   124: iload 7
/*     */     //   126: ifeq +35 -> 161
/*     */     //   129: aload_0
/*     */     //   130: getfield 45	clojure/reflect/Field:__extmap	Ljava/lang/Object;
/*     */     //   133: aload_3
/*     */     //   134: aconst_null
/*     */     //   135: astore_3
/*     */     //   136: checkcast 2	clojure/reflect/Field
/*     */     //   139: getfield 45	clojure/reflect/Field:__extmap	Ljava/lang/Object;
/*     */     //   142: invokestatic 239	clojure/lang/Util:equiv	(Ljava/lang/Object;Ljava/lang/Object;)Z
/*     */     //   145: ifeq +9 -> 154
/*     */     //   148: getstatic 234	java/lang/Boolean:TRUE	Ljava/lang/Boolean;
/*     */     //   151: goto +6 -> 157
/*     */     //   154: getstatic 237	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   157: goto +18 -> 175
/*     */     //   160: pop
/*     */     //   161: iload 7
/*     */     //   163: ifeq +9 -> 172
/*     */     //   166: getstatic 234	java/lang/Boolean:TRUE	Ljava/lang/Boolean;
/*     */     //   169: goto +6 -> 175
/*     */     //   172: getstatic 237	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   175: goto +18 -> 193
/*     */     //   178: pop
/*     */     //   179: iload 6
/*     */     //   181: ifeq +9 -> 190
/*     */     //   184: getstatic 234	java/lang/Boolean:TRUE	Ljava/lang/Boolean;
/*     */     //   187: goto +6 -> 193
/*     */     //   190: getstatic 237	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   193: goto +18 -> 211
/*     */     //   196: pop
/*     */     //   197: iload 5
/*     */     //   199: ifeq +9 -> 208
/*     */     //   202: getstatic 234	java/lang/Boolean:TRUE	Ljava/lang/Boolean;
/*     */     //   205: goto +6 -> 211
/*     */     //   208: getstatic 237	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   211: goto +18 -> 229
/*     */     //   214: pop
/*     */     //   215: iload 4
/*     */     //   217: ifeq +9 -> 226
/*     */     //   220: getstatic 234	java/lang/Boolean:TRUE	Ljava/lang/Boolean;
/*     */     //   223: goto +6 -> 229
/*     */     //   226: getstatic 237	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   229: goto +5 -> 234
/*     */     //   232: pop
/*     */     //   233: aconst_null
/*     */     //   234: invokestatic 248	clojure/lang/RT:booleanCast	(Ljava/lang/Object;)Z
/*     */     //   237: ireturn
/*     */     // Line number table:
/*     */     //   Java source line #148	-> byte code offset #0
/*     */     //   Java source line #148	-> byte code offset #2
/*     */     //   Java source line #148	-> byte code offset #6
/*     */     //   Java source line #148	-> byte code offset #27
/*     */     //   Java source line #148	-> byte code offset #35
/*     */     //   Java source line #148	-> byte code offset #50
/*     */     //   Java source line #148	-> byte code offset #56
/*     */     //   Java source line #148	-> byte code offset #61
/*     */     //   Java source line #148	-> byte code offset #71
/*     */     //   Java source line #148	-> byte code offset #77
/*     */     //   Java source line #148	-> byte code offset #82
/*     */     //   Java source line #148	-> byte code offset #92
/*     */     //   Java source line #148	-> byte code offset #98
/*     */     //   Java source line #148	-> byte code offset #103
/*     */     //   Java source line #148	-> byte code offset #113
/*     */     //   Java source line #148	-> byte code offset #119
/*     */     //   Java source line #148	-> byte code offset #124
/*     */     //   Java source line #148	-> byte code offset #136
/*     */     //   Java source line #148	-> byte code offset #142
/*     */     //   Java source line #148	-> byte code offset #234
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	237	0	this	Field
/*     */     //   0	237	1	G__10000	Object
/*     */     //   6	228	2	or__4469__auto__10019	boolean
/*     */     //   45	184	3	G__10000	Object
/*     */     //   61	168	4	and__4467__auto__10018	boolean
/*     */     //   82	129	5	and__4467__auto__10017	boolean
/*     */     //   103	90	6	and__4467__auto__10016	boolean
/*     */     //   124	51	7	and__4467__auto__10015	boolean
/*     */   }
/*     */   
/*     */   public IPersistentCollection cons(Object e__6436__auto__)
/*     */   {
/* 148 */     e__6436__auto__ = null;return (IPersistentCollection)((IFn)const__24).invoke(this, e__6436__auto__);
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public IPersistentCollection empty()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: new 188	java/lang/UnsupportedOperationException
/*     */     //   3: dup
/*     */     //   4: ldc -66
/*     */     //   6: iconst_1
/*     */     //   7: anewarray 4	java/lang/Object
/*     */     //   10: dup
/*     */     //   11: iconst_0
/*     */     //   12: ldc -64
/*     */     //   14: aastore
/*     */     //   15: invokestatic 197	clojure/lang/ArraySeq:create	([Ljava/lang/Object;)Lclojure/lang/ArraySeq;
/*     */     //   18: invokestatic 202	clojure/core$str:invokeStatic	(Ljava/lang/Object;Lclojure/lang/ISeq;)Ljava/lang/Object;
/*     */     //   21: checkcast 204	java/lang/String
/*     */     //   24: invokespecial 207	java/lang/UnsupportedOperationException:<init>	(Ljava/lang/String;)V
/*     */     //   27: checkcast 209	java/lang/Throwable
/*     */     //   30: athrow
/*     */     //   31: checkcast 211	clojure/lang/IPersistentCollection
/*     */     //   34: areturn
/*     */     // Line number table:
/*     */     //   Java source line #148	-> byte code offset #0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	34	0	this	Field
/*     */   }
/*     */   
/* 148 */   public int count() { return RT.intCast(Numbers.add(4L, RT.count(this.__extmap))); } public ILookupThunk getLookupThunk(Keyword k__6432__auto__) { Object gclass = core.class.invokeStatic(this);k__6432__auto__ = null;Object G__10004 = k__6432__auto__; switch (Util.hash(G__10004) >> 19 & 0x3) {case 0:  if (G__10004 == const__11) { gclass = null;tmpTernaryOp = new Field.reify__10005(null, gclass); } break; case 1:  if (G__10004 == const__8) { gclass = null;tmpTernaryOp = new Field.reify__10007(null, gclass); } break; case 2:  if (G__10004 == const__9) { gclass = null;tmpTernaryOp = new Field.reify__10009(null, gclass); } break; case 3:  gclass = null; } return (ILookupThunk)(G__10004 == const__10 ? new Field.reify__10011(null, gclass) : null); } public Object valAt(Object k__6429__auto__, Object else__6430__auto__) { Object G__10013 = k__6429__auto__; switch (Util.hash(G__10013) >> 19 & 0x3) {case 0:  if (G__10013 == const__11) tmpTernaryOp = this.flags; break; case 1:  if (G__10013 == const__8) tmpTernaryOp = this.name; break; case 2:  if (G__10013 == const__9) tmpTernaryOp = this.type; break; } k__6429__auto__ = null;else__6430__auto__ = null;return G__10013 == const__10 ? this.declaring_class : RT.get(this.__extmap, k__6429__auto__, else__6430__auto__); } public Object valAt(Object k__6427__auto__) { k__6427__auto__ = null;return ((ILookup)this).valAt(k__6427__auto__, null); } public IObj withMeta(IPersistentMap G__10000) { G__10000 = null;return (IObj)new Field(this.name, this.type, this.declaring_class, this.flags, G__10000, this.__extmap); } public IPersistentMap meta() { return (IPersistentMap)this.__meta; } public boolean equals(Object G__10000) { G__10000 = null;return APersistentMap.mapEquals((IPersistentMap)this, G__10000); } public int hashCode() { return APersistentMap.mapHash((IPersistentMap)this); } public int hasheq() { return RT.intCast(0xD22CBDF ^ APersistentMap.mapHasheq((IPersistentMap)this)); } public static Field create(IPersistentMap paramIPersistentMap) { Object localObject1 = paramIPersistentMap.valAt(Keyword.intern("name"), null);
/*     */     paramIPersistentMap = paramIPersistentMap.without(Keyword.intern("name"));
/*     */     Object localObject2 = paramIPersistentMap.valAt(Keyword.intern("type"), null);
/*     */     paramIPersistentMap = paramIPersistentMap.without(Keyword.intern("type"));
/*     */     Object localObject3 = paramIPersistentMap.valAt(Keyword.intern("declaring-class"), null);
/*     */     paramIPersistentMap = paramIPersistentMap.without(Keyword.intern("declaring-class"));
/*     */     Object localObject4 = paramIPersistentMap.valAt(Keyword.intern("flags"), null);
/*     */     paramIPersistentMap = paramIPersistentMap.without(Keyword.intern("flags"));
/*     */     return new Field(localObject1, localObject2, localObject3, localObject4, null, RT.seqOrElse(paramIPersistentMap)); } public static IPersistentVector getBasis() { return Tuple.create(Symbol.intern(null, "name"), Symbol.intern(null, "type"), Symbol.intern(null, "declaring-class"), Symbol.intern(null, "flags")); } public Field(Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4) { this(paramObject1, paramObject2, paramObject3, paramObject4, null, null); } public Field(Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4, Object paramObject5, Object paramObject6) { this.name = paramObject1;this.type = paramObject2;this.declaring_class = paramObject3;this.flags = paramObject4;this.__meta = paramObject5;this.__extmap = paramObject6; } public static final Var const__24 = (Var)RT.var("clojure.core", "imap-cons"); public static final AFn const__19 = (AFn)Tuple.create(RT.keyword(null, "name"), RT.keyword(null, "type"), RT.keyword(null, "declaring-class"), RT.keyword(null, "flags")); public static final Var const__17 = (Var)RT.var("clojure.core", "identical?"); public static final AFn const__12 = (AFn)PersistentHashSet.create(new Object[] { RT.keyword(null, "name"), RT.keyword(null, "type"), RT.keyword(null, "declaring-class"), RT.keyword(null, "flags") }); public static final Keyword const__11 = (Keyword)RT.keyword(null, "flags"); public static final Keyword const__10 = (Keyword)RT.keyword(null, "declaring-class"); public static final Keyword const__9 = (Keyword)RT.keyword(null, "type"); public static final Keyword const__8 = (Keyword)RT.keyword(null, "name");
/*     */   public final Object __extmap;
/*     */   public final Object __meta;
/*     */   public final Object flags;
/*     */   public final Object declaring_class;
/*     */   public final Object type;
/*     */   public final Object name;
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\reflect\Field.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */