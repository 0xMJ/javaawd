/*     */ package clojure.reflect;
/*     */ 
/*     */ import clojure.lang.AFunction;
/*     */ import clojure.lang.Keyword;
/*     */ import clojure.lang.RT;
/*     */ import clojure.lang.Var;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AsmReflector$fn__10057
/*     */   extends AFunction
/*     */ {
/* 205 */   public AsmReflector$fn__10057(Object paramObject) { this.result = paramObject; } public static final Keyword const__15 = (Keyword)RT.keyword(null, "flags"); public static final Keyword const__14 = (Keyword)RT.keyword(null, "bases"); public static final Var const__13 = (Var)RT.var("clojure.core", "merge"); public static final Var const__10 = (Var)RT.var("clojure.core", "nil?"); public static final Var const__8 = (Var)RT.var("clojure.reflect", "internal-name->class-symbol"); public static final Var const__7 = (Var)RT.var("clojure.core", "symbol"); public static final Keyword const__2 = (Keyword)RT.keyword(null, "interface"); public static final Keyword const__1 = (Keyword)RT.keyword(null, "class");
/*     */   Object result;
/*     */   
/*     */   /* Error */
/*     */   public Object invoke(Object this, Object version, Object access, Object name, Object signature, Object superName, Object interfaces)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_3
/*     */     //   1: aconst_null
/*     */     //   2: astore_3
/*     */     //   3: getstatic 20	clojure/reflect/AsmReflector$fn__10057:const__1	Lclojure/lang/Keyword;
/*     */     //   6: invokestatic 26	clojure/reflect$parse_flags:invokeStatic	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   9: astore 8
/*     */     //   11: aload 8
/*     */     //   13: checkcast 28	clojure/lang/IFn
/*     */     //   16: getstatic 31	clojure/reflect/AsmReflector$fn__10057:const__2	Lclojure/lang/Keyword;
/*     */     //   19: invokeinterface 34 2 0
/*     */     //   24: astore 9
/*     */     //   26: aload 9
/*     */     //   28: dup
/*     */     //   29: ifnull +31 -> 60
/*     */     //   32: getstatic 40	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   35: if_acmpeq +26 -> 61
/*     */     //   38: aload 6
/*     */     //   40: ldc 42
/*     */     //   42: invokestatic 48	clojure/lang/Util:equiv	(Ljava/lang/Object;Ljava/lang/Object;)Z
/*     */     //   45: ifeq +9 -> 54
/*     */     //   48: getstatic 51	java/lang/Boolean:TRUE	Ljava/lang/Boolean;
/*     */     //   51: goto +6 -> 57
/*     */     //   54: getstatic 40	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   57: goto +9 -> 66
/*     */     //   60: pop
/*     */     //   61: aload 9
/*     */     //   63: aconst_null
/*     */     //   64: astore 9
/*     */     //   66: dup
/*     */     //   67: ifnull +13 -> 80
/*     */     //   70: getstatic 40	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   73: if_acmpeq +8 -> 81
/*     */     //   76: aconst_null
/*     */     //   77: goto +9 -> 86
/*     */     //   80: pop
/*     */     //   81: aload 6
/*     */     //   83: aconst_null
/*     */     //   84: astore 6
/*     */     //   86: astore 9
/*     */     //   88: getstatic 56	clojure/reflect/AsmReflector$fn__10057:const__7	Lclojure/lang/Var;
/*     */     //   91: invokevirtual 62	clojure/lang/Var:getRawRoot	()Ljava/lang/Object;
/*     */     //   94: getstatic 65	clojure/reflect/AsmReflector$fn__10057:const__8	Lclojure/lang/Var;
/*     */     //   97: invokevirtual 62	clojure/lang/Var:getRawRoot	()Ljava/lang/Object;
/*     */     //   100: getstatic 68	clojure/reflect/AsmReflector$fn__10057:const__10	Lclojure/lang/Var;
/*     */     //   103: invokevirtual 62	clojure/lang/Var:getRawRoot	()Ljava/lang/Object;
/*     */     //   106: aload 9
/*     */     //   108: aconst_null
/*     */     //   109: astore 9
/*     */     //   111: aload 7
/*     */     //   113: aconst_null
/*     */     //   114: astore 7
/*     */     //   116: invokestatic 71	clojure/core$cons__4331:invokeStatic	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   119: invokestatic 74	clojure/core$remove:invokeStatic	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   122: invokestatic 77	clojure/core$map:invokeStatic	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   125: invokestatic 77	clojure/core$map:invokeStatic	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   128: invokestatic 81	clojure/core$set:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   131: invokestatic 84	clojure/core$not_empty:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   134: astore 10
/*     */     //   136: aload_0
/*     */     //   137: getfield 14	clojure/reflect/AsmReflector$fn__10057:result	Ljava/lang/Object;
/*     */     //   140: getstatic 87	clojure/reflect/AsmReflector$fn__10057:const__13	Lclojure/lang/Var;
/*     */     //   143: invokevirtual 62	clojure/lang/Var:getRawRoot	()Ljava/lang/Object;
/*     */     //   146: iconst_4
/*     */     //   147: anewarray 88	java/lang/Object
/*     */     //   150: dup
/*     */     //   151: iconst_0
/*     */     //   152: getstatic 91	clojure/reflect/AsmReflector$fn__10057:const__14	Lclojure/lang/Keyword;
/*     */     //   155: aastore
/*     */     //   156: dup
/*     */     //   157: iconst_1
/*     */     //   158: aload 10
/*     */     //   160: aconst_null
/*     */     //   161: astore 10
/*     */     //   163: aastore
/*     */     //   164: dup
/*     */     //   165: iconst_2
/*     */     //   166: getstatic 94	clojure/reflect/AsmReflector$fn__10057:const__15	Lclojure/lang/Keyword;
/*     */     //   169: aastore
/*     */     //   170: dup
/*     */     //   171: iconst_3
/*     */     //   172: aload 8
/*     */     //   174: aconst_null
/*     */     //   175: astore 8
/*     */     //   177: aastore
/*     */     //   178: invokestatic 100	clojure/lang/RT:mapUniqueKeys	([Ljava/lang/Object;)Lclojure/lang/IPersistentMap;
/*     */     //   181: invokestatic 105	clojure/core$swap_BANG_:invokeStatic	(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   184: areturn
/*     */     // Line number table:
/*     */     //   Java source line #205	-> byte code offset #0
/*     */     //   Java source line #211	-> byte code offset #11
/*     */     //   Java source line #211	-> byte code offset #13
/*     */     //   Java source line #211	-> byte code offset #19
/*     */     //   Java source line #211	-> byte code offset #26
/*     */     //   Java source line #212	-> byte code offset #42
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	184	0	this	Object
/*     */     //   0	184	1	this	Object
/*     */     //   0	184	2	version	Object
/*     */     //   0	184	3	access	Object
/*     */     //   0	184	4	name	Object
/*     */     //   0	184	5	signature	Object
/*     */     //   0	184	6	superName	Object
/*     */     //   0	184	7	interfaces	Object
/*     */     //   11	173	8	flags	Object
/*     */     //   26	40	9	and__4467__auto__10059	Object
/*     */     //   88	96	9	superName	Object
/*     */     //   136	48	10	bases	Object
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\reflect\AsmReflector$fn__10057.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */