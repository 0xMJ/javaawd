/*     */ package clojure.reflect;
/*     */ 
/*     */ import clojure.core.class;
/*     */ import clojure.core.concat;
/*     */ import clojure.core.keys;
/*     */ import clojure.core.not;
/*     */ import clojure.core.seq__4357;
/*     */ import clojure.core.set;
/*     */ import clojure.core.some;
/*     */ import clojure.core.vals;
/*     */ import clojure.lang.AFn;
/*     */ import clojure.lang.APersistentMap;
/*     */ import clojure.lang.Counted;
/*     */ import clojure.lang.IFn;
/*     */ import clojure.lang.IHashEq;
/*     */ import clojure.lang.IKeywordLookup;
/*     */ import clojure.lang.ILookup;
/*     */ import clojure.lang.ILookupThunk;
/*     */ import clojure.lang.IObj;
/*     */ import clojure.lang.IPersistentCollection;
/*     */ import clojure.lang.IPersistentMap;
/*     */ import clojure.lang.IPersistentVector;
/*     */ import clojure.lang.IRecord;
/*     */ import clojure.lang.ISeq;
/*     */ import clojure.lang.Keyword;
/*     */ import clojure.lang.MapEntry;
/*     */ import clojure.lang.Numbers;
/*     */ import clojure.lang.PersistentHashSet;
/*     */ import clojure.lang.RT;
/*     */ import clojure.lang.RecordIterator;
/*     */ import clojure.lang.Symbol;
/*     */ import clojure.lang.Tuple;
/*     */ import clojure.lang.Util;
/*     */ import clojure.lang.Var;
/*     */ import java.io.Serializable;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Method
/*     */   implements IRecord, IHashEq, IObj, ILookup, IKeywordLookup, IPersistentMap, Map, Serializable
/*     */ {
/* 128 */   public Set entrySet() { return (Set)core.set.invokeStatic(this); } public Collection values() { return (Collection)core.vals.invokeStatic(this); } public Set keySet() { return (Set)core.set.invokeStatic(core.keys.invokeStatic(this)); }
/*     */   
/*     */   /* Error */
/*     */   public void clear()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: new 211	java/lang/UnsupportedOperationException
/*     */     //   3: dup
/*     */     //   4: invokespecial 392	java/lang/UnsupportedOperationException:<init>	()V
/*     */     //   7: checkcast 232	java/lang/Throwable
/*     */     //   10: athrow
/*     */     //   11: pop
/*     */     //   12: return
/*     */     // Line number table:
/*     */     //   Java source line #128	-> byte code offset #0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	12	0	this	Method
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public void putAll(Map m__6461__auto__)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: new 211	java/lang/UnsupportedOperationException
/*     */     //   3: dup
/*     */     //   4: invokespecial 392	java/lang/UnsupportedOperationException:<init>	()V
/*     */     //   7: checkcast 232	java/lang/Throwable
/*     */     //   10: athrow
/*     */     //   11: pop
/*     */     //   12: return
/*     */     // Line number table:
/*     */     //   Java source line #128	-> byte code offset #0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	12	0	this	Method
/*     */     //   0	12	1	m__6461__auto__	Map
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public Object remove(Object k__6459__auto__)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: new 211	java/lang/UnsupportedOperationException
/*     */     //   3: dup
/*     */     //   4: invokespecial 392	java/lang/UnsupportedOperationException:<init>	()V
/*     */     //   7: checkcast 232	java/lang/Throwable
/*     */     //   10: athrow
/*     */     //   11: areturn
/*     */     // Line number table:
/*     */     //   Java source line #128	-> byte code offset #0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	11	0	this	Method
/*     */     //   0	11	1	k__6459__auto__	Object
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public Object put(Object k__6456__auto__, Object v__6457__auto__)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: new 211	java/lang/UnsupportedOperationException
/*     */     //   3: dup
/*     */     //   4: invokespecial 392	java/lang/UnsupportedOperationException:<init>	()V
/*     */     //   7: checkcast 232	java/lang/Throwable
/*     */     //   10: athrow
/*     */     //   11: areturn
/*     */     // Line number table:
/*     */     //   Java source line #128	-> byte code offset #0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	11	0	this	Method
/*     */     //   0	11	1	k__6456__auto__	Object
/*     */     //   0	11	2	v__6457__auto__	Object
/*     */   }
/*     */   
/*     */   public Object get(Object k__6454__auto__)
/*     */   {
/* 128 */     k__6454__auto__ = null;return ((ILookup)this).valAt(k__6454__auto__); } public boolean containsValue(Object v__6452__auto__) { Object[] tmp4_1 = new Object[1];v__6452__auto__ = null;tmp4_1[0] = v__6452__auto__;return RT.booleanCast(core.some.invokeStatic(RT.set(tmp4_1), core.vals.invokeStatic(this))); } public boolean isEmpty() { return Util.equiv(0L, ((Counted)this).count()); } public int size() { return ((Counted)this).count(); }
/*     */   
/*     */   /* Error */
/*     */   public IPersistentMap without(Object k__6448__auto__)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: getstatic 344	clojure/reflect/Method:const__14	Lclojure/lang/AFn;
/*     */     //   3: aload_1
/*     */     //   4: invokestatic 347	clojure/core$contains_QMARK_:invokeStatic	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   7: dup
/*     */     //   8: ifnull +32 -> 40
/*     */     //   11: getstatic 260	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   14: if_acmpeq +27 -> 41
/*     */     //   17: getstatic 353	clojure/lang/PersistentArrayMap:EMPTY	Lclojure/lang/PersistentArrayMap;
/*     */     //   20: aload_0
/*     */     //   21: invokestatic 356	clojure/core$into:invokeStatic	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   24: aload_0
/*     */     //   25: getfield 49	clojure/reflect/Method:__meta	Ljava/lang/Object;
/*     */     //   28: invokestatic 359	clojure/core$with_meta__4375:invokeStatic	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   31: aload_1
/*     */     //   32: aconst_null
/*     */     //   33: astore_1
/*     */     //   34: invokestatic 362	clojure/core$dissoc:invokeStatic	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   37: goto +52 -> 89
/*     */     //   40: pop
/*     */     //   41: new 2	clojure/reflect/Method
/*     */     //   44: dup
/*     */     //   45: aload_0
/*     */     //   46: getfield 37	clojure/reflect/Method:name	Ljava/lang/Object;
/*     */     //   49: aload_0
/*     */     //   50: getfield 39	clojure/reflect/Method:return_type	Ljava/lang/Object;
/*     */     //   53: aload_0
/*     */     //   54: getfield 41	clojure/reflect/Method:declaring_class	Ljava/lang/Object;
/*     */     //   57: aload_0
/*     */     //   58: getfield 43	clojure/reflect/Method:parameter_types	Ljava/lang/Object;
/*     */     //   61: aload_0
/*     */     //   62: getfield 45	clojure/reflect/Method:exception_types	Ljava/lang/Object;
/*     */     //   65: aload_0
/*     */     //   66: getfield 47	clojure/reflect/Method:flags	Ljava/lang/Object;
/*     */     //   69: aload_0
/*     */     //   70: getfield 49	clojure/reflect/Method:__meta	Ljava/lang/Object;
/*     */     //   73: aload_0
/*     */     //   74: getfield 51	clojure/reflect/Method:__extmap	Ljava/lang/Object;
/*     */     //   77: aload_1
/*     */     //   78: aconst_null
/*     */     //   79: astore_1
/*     */     //   80: invokestatic 362	clojure/core$dissoc:invokeStatic	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   83: invokestatic 365	clojure/core$not_empty:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   86: invokespecial 54	clojure/reflect/Method:<init>	(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
/*     */     //   89: checkcast 16	clojure/lang/IPersistentMap
/*     */     //   92: areturn
/*     */     // Line number table:
/*     */     //   Java source line #128	-> byte code offset #0
/*     */     //   Java source line #128	-> byte code offset #0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	92	0	this	Method
/*     */     //   0	92	1	k__6448__auto__	Object
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public IPersistentMap assoc(Object k__6446__auto__, Object G__9966)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: getstatic 328	clojure/reflect/Method:const__19	Lclojure/lang/Var;
/*     */     //   3: invokevirtual 334	clojure/lang/Var:getRawRoot	()Ljava/lang/Object;
/*     */     //   6: astore_3
/*     */     //   7: aload_1
/*     */     //   8: astore 4
/*     */     //   10: aload_3
/*     */     //   11: checkcast 242	clojure/lang/IFn
/*     */     //   14: getstatic 145	clojure/reflect/Method:const__9	Lclojure/lang/Keyword;
/*     */     //   17: aload 4
/*     */     //   19: invokeinterface 245 3 0
/*     */     //   24: dup
/*     */     //   25: ifnull +50 -> 75
/*     */     //   28: getstatic 260	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   31: if_acmpeq +45 -> 76
/*     */     //   34: new 2	clojure/reflect/Method
/*     */     //   37: dup
/*     */     //   38: aload_2
/*     */     //   39: aconst_null
/*     */     //   40: astore_2
/*     */     //   41: aload_0
/*     */     //   42: getfield 39	clojure/reflect/Method:return_type	Ljava/lang/Object;
/*     */     //   45: aload_0
/*     */     //   46: getfield 41	clojure/reflect/Method:declaring_class	Ljava/lang/Object;
/*     */     //   49: aload_0
/*     */     //   50: getfield 43	clojure/reflect/Method:parameter_types	Ljava/lang/Object;
/*     */     //   53: aload_0
/*     */     //   54: getfield 45	clojure/reflect/Method:exception_types	Ljava/lang/Object;
/*     */     //   57: aload_0
/*     */     //   58: getfield 47	clojure/reflect/Method:flags	Ljava/lang/Object;
/*     */     //   61: aload_0
/*     */     //   62: getfield 49	clojure/reflect/Method:__meta	Ljava/lang/Object;
/*     */     //   65: aload_0
/*     */     //   66: getfield 51	clojure/reflect/Method:__extmap	Ljava/lang/Object;
/*     */     //   69: invokespecial 54	clojure/reflect/Method:<init>	(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
/*     */     //   72: goto +387 -> 459
/*     */     //   75: pop
/*     */     //   76: aload_3
/*     */     //   77: checkcast 242	clojure/lang/IFn
/*     */     //   80: getstatic 148	clojure/reflect/Method:const__8	Lclojure/lang/Keyword;
/*     */     //   83: aload 4
/*     */     //   85: invokeinterface 245 3 0
/*     */     //   90: dup
/*     */     //   91: ifnull +50 -> 141
/*     */     //   94: getstatic 260	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   97: if_acmpeq +45 -> 142
/*     */     //   100: new 2	clojure/reflect/Method
/*     */     //   103: dup
/*     */     //   104: aload_0
/*     */     //   105: getfield 37	clojure/reflect/Method:name	Ljava/lang/Object;
/*     */     //   108: aload_2
/*     */     //   109: aconst_null
/*     */     //   110: astore_2
/*     */     //   111: aload_0
/*     */     //   112: getfield 41	clojure/reflect/Method:declaring_class	Ljava/lang/Object;
/*     */     //   115: aload_0
/*     */     //   116: getfield 43	clojure/reflect/Method:parameter_types	Ljava/lang/Object;
/*     */     //   119: aload_0
/*     */     //   120: getfield 45	clojure/reflect/Method:exception_types	Ljava/lang/Object;
/*     */     //   123: aload_0
/*     */     //   124: getfield 47	clojure/reflect/Method:flags	Ljava/lang/Object;
/*     */     //   127: aload_0
/*     */     //   128: getfield 49	clojure/reflect/Method:__meta	Ljava/lang/Object;
/*     */     //   131: aload_0
/*     */     //   132: getfield 51	clojure/reflect/Method:__extmap	Ljava/lang/Object;
/*     */     //   135: invokespecial 54	clojure/reflect/Method:<init>	(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
/*     */     //   138: goto +321 -> 459
/*     */     //   141: pop
/*     */     //   142: aload_3
/*     */     //   143: checkcast 242	clojure/lang/IFn
/*     */     //   146: getstatic 142	clojure/reflect/Method:const__10	Lclojure/lang/Keyword;
/*     */     //   149: aload 4
/*     */     //   151: invokeinterface 245 3 0
/*     */     //   156: dup
/*     */     //   157: ifnull +50 -> 207
/*     */     //   160: getstatic 260	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   163: if_acmpeq +45 -> 208
/*     */     //   166: new 2	clojure/reflect/Method
/*     */     //   169: dup
/*     */     //   170: aload_0
/*     */     //   171: getfield 37	clojure/reflect/Method:name	Ljava/lang/Object;
/*     */     //   174: aload_0
/*     */     //   175: getfield 39	clojure/reflect/Method:return_type	Ljava/lang/Object;
/*     */     //   178: aload_2
/*     */     //   179: aconst_null
/*     */     //   180: astore_2
/*     */     //   181: aload_0
/*     */     //   182: getfield 43	clojure/reflect/Method:parameter_types	Ljava/lang/Object;
/*     */     //   185: aload_0
/*     */     //   186: getfield 45	clojure/reflect/Method:exception_types	Ljava/lang/Object;
/*     */     //   189: aload_0
/*     */     //   190: getfield 47	clojure/reflect/Method:flags	Ljava/lang/Object;
/*     */     //   193: aload_0
/*     */     //   194: getfield 49	clojure/reflect/Method:__meta	Ljava/lang/Object;
/*     */     //   197: aload_0
/*     */     //   198: getfield 51	clojure/reflect/Method:__extmap	Ljava/lang/Object;
/*     */     //   201: invokespecial 54	clojure/reflect/Method:<init>	(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
/*     */     //   204: goto +255 -> 459
/*     */     //   207: pop
/*     */     //   208: aload_3
/*     */     //   209: checkcast 242	clojure/lang/IFn
/*     */     //   212: getstatic 151	clojure/reflect/Method:const__11	Lclojure/lang/Keyword;
/*     */     //   215: aload 4
/*     */     //   217: invokeinterface 245 3 0
/*     */     //   222: dup
/*     */     //   223: ifnull +50 -> 273
/*     */     //   226: getstatic 260	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   229: if_acmpeq +45 -> 274
/*     */     //   232: new 2	clojure/reflect/Method
/*     */     //   235: dup
/*     */     //   236: aload_0
/*     */     //   237: getfield 37	clojure/reflect/Method:name	Ljava/lang/Object;
/*     */     //   240: aload_0
/*     */     //   241: getfield 39	clojure/reflect/Method:return_type	Ljava/lang/Object;
/*     */     //   244: aload_0
/*     */     //   245: getfield 41	clojure/reflect/Method:declaring_class	Ljava/lang/Object;
/*     */     //   248: aload_2
/*     */     //   249: aconst_null
/*     */     //   250: astore_2
/*     */     //   251: aload_0
/*     */     //   252: getfield 45	clojure/reflect/Method:exception_types	Ljava/lang/Object;
/*     */     //   255: aload_0
/*     */     //   256: getfield 47	clojure/reflect/Method:flags	Ljava/lang/Object;
/*     */     //   259: aload_0
/*     */     //   260: getfield 49	clojure/reflect/Method:__meta	Ljava/lang/Object;
/*     */     //   263: aload_0
/*     */     //   264: getfield 51	clojure/reflect/Method:__extmap	Ljava/lang/Object;
/*     */     //   267: invokespecial 54	clojure/reflect/Method:<init>	(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
/*     */     //   270: goto +189 -> 459
/*     */     //   273: pop
/*     */     //   274: aload_3
/*     */     //   275: checkcast 242	clojure/lang/IFn
/*     */     //   278: getstatic 154	clojure/reflect/Method:const__12	Lclojure/lang/Keyword;
/*     */     //   281: aload 4
/*     */     //   283: invokeinterface 245 3 0
/*     */     //   288: dup
/*     */     //   289: ifnull +50 -> 339
/*     */     //   292: getstatic 260	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   295: if_acmpeq +45 -> 340
/*     */     //   298: new 2	clojure/reflect/Method
/*     */     //   301: dup
/*     */     //   302: aload_0
/*     */     //   303: getfield 37	clojure/reflect/Method:name	Ljava/lang/Object;
/*     */     //   306: aload_0
/*     */     //   307: getfield 39	clojure/reflect/Method:return_type	Ljava/lang/Object;
/*     */     //   310: aload_0
/*     */     //   311: getfield 41	clojure/reflect/Method:declaring_class	Ljava/lang/Object;
/*     */     //   314: aload_0
/*     */     //   315: getfield 43	clojure/reflect/Method:parameter_types	Ljava/lang/Object;
/*     */     //   318: aload_2
/*     */     //   319: aconst_null
/*     */     //   320: astore_2
/*     */     //   321: aload_0
/*     */     //   322: getfield 47	clojure/reflect/Method:flags	Ljava/lang/Object;
/*     */     //   325: aload_0
/*     */     //   326: getfield 49	clojure/reflect/Method:__meta	Ljava/lang/Object;
/*     */     //   329: aload_0
/*     */     //   330: getfield 51	clojure/reflect/Method:__extmap	Ljava/lang/Object;
/*     */     //   333: invokespecial 54	clojure/reflect/Method:<init>	(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
/*     */     //   336: goto +123 -> 459
/*     */     //   339: pop
/*     */     //   340: aload_3
/*     */     //   341: aconst_null
/*     */     //   342: astore_3
/*     */     //   343: checkcast 242	clojure/lang/IFn
/*     */     //   346: getstatic 157	clojure/reflect/Method:const__13	Lclojure/lang/Keyword;
/*     */     //   349: aload 4
/*     */     //   351: aconst_null
/*     */     //   352: astore 4
/*     */     //   354: invokeinterface 245 3 0
/*     */     //   359: dup
/*     */     //   360: ifnull +50 -> 410
/*     */     //   363: getstatic 260	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   366: if_acmpeq +45 -> 411
/*     */     //   369: new 2	clojure/reflect/Method
/*     */     //   372: dup
/*     */     //   373: aload_0
/*     */     //   374: getfield 37	clojure/reflect/Method:name	Ljava/lang/Object;
/*     */     //   377: aload_0
/*     */     //   378: getfield 39	clojure/reflect/Method:return_type	Ljava/lang/Object;
/*     */     //   381: aload_0
/*     */     //   382: getfield 41	clojure/reflect/Method:declaring_class	Ljava/lang/Object;
/*     */     //   385: aload_0
/*     */     //   386: getfield 43	clojure/reflect/Method:parameter_types	Ljava/lang/Object;
/*     */     //   389: aload_0
/*     */     //   390: getfield 45	clojure/reflect/Method:exception_types	Ljava/lang/Object;
/*     */     //   393: aload_2
/*     */     //   394: aconst_null
/*     */     //   395: astore_2
/*     */     //   396: aload_0
/*     */     //   397: getfield 49	clojure/reflect/Method:__meta	Ljava/lang/Object;
/*     */     //   400: aload_0
/*     */     //   401: getfield 51	clojure/reflect/Method:__extmap	Ljava/lang/Object;
/*     */     //   404: invokespecial 54	clojure/reflect/Method:<init>	(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
/*     */     //   407: goto +52 -> 459
/*     */     //   410: pop
/*     */     //   411: new 2	clojure/reflect/Method
/*     */     //   414: dup
/*     */     //   415: aload_0
/*     */     //   416: getfield 37	clojure/reflect/Method:name	Ljava/lang/Object;
/*     */     //   419: aload_0
/*     */     //   420: getfield 39	clojure/reflect/Method:return_type	Ljava/lang/Object;
/*     */     //   423: aload_0
/*     */     //   424: getfield 41	clojure/reflect/Method:declaring_class	Ljava/lang/Object;
/*     */     //   427: aload_0
/*     */     //   428: getfield 43	clojure/reflect/Method:parameter_types	Ljava/lang/Object;
/*     */     //   431: aload_0
/*     */     //   432: getfield 45	clojure/reflect/Method:exception_types	Ljava/lang/Object;
/*     */     //   435: aload_0
/*     */     //   436: getfield 47	clojure/reflect/Method:flags	Ljava/lang/Object;
/*     */     //   439: aload_0
/*     */     //   440: getfield 49	clojure/reflect/Method:__meta	Ljava/lang/Object;
/*     */     //   443: aload_0
/*     */     //   444: getfield 51	clojure/reflect/Method:__extmap	Ljava/lang/Object;
/*     */     //   447: aload_1
/*     */     //   448: aconst_null
/*     */     //   449: astore_1
/*     */     //   450: aload_2
/*     */     //   451: aconst_null
/*     */     //   452: astore_2
/*     */     //   453: invokestatic 338	clojure/core$assoc__4371:invokeStatic	(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   456: invokespecial 54	clojure/reflect/Method:<init>	(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
/*     */     //   459: checkcast 16	clojure/lang/IPersistentMap
/*     */     //   462: areturn
/*     */     // Line number table:
/*     */     //   Java source line #128	-> byte code offset #0
/*     */     //   Java source line #128	-> byte code offset #10
/*     */     //   Java source line #128	-> byte code offset #11
/*     */     //   Java source line #128	-> byte code offset #19
/*     */     //   Java source line #128	-> byte code offset #76
/*     */     //   Java source line #128	-> byte code offset #77
/*     */     //   Java source line #128	-> byte code offset #85
/*     */     //   Java source line #128	-> byte code offset #142
/*     */     //   Java source line #128	-> byte code offset #143
/*     */     //   Java source line #128	-> byte code offset #151
/*     */     //   Java source line #128	-> byte code offset #208
/*     */     //   Java source line #128	-> byte code offset #209
/*     */     //   Java source line #128	-> byte code offset #217
/*     */     //   Java source line #128	-> byte code offset #274
/*     */     //   Java source line #128	-> byte code offset #275
/*     */     //   Java source line #128	-> byte code offset #283
/*     */     //   Java source line #128	-> byte code offset #340
/*     */     //   Java source line #128	-> byte code offset #343
/*     */     //   Java source line #128	-> byte code offset #354
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	462	0	this	Method
/*     */     //   0	462	1	k__6446__auto__	Object
/*     */     //   0	462	2	G__9966	Object
/*     */     //   7	452	3	pred__9968	Object
/*     */     //   10	449	4	expr__9969	Object
/*     */   }
/*     */   
/* 128 */   public Iterator iterator() { return (Iterator)new RecordIterator((ILookup)this, (IPersistentVector)const__21, (Iterator)RT.iter(this.__extmap)); } public ISeq seq() { return (ISeq)core.seq__4357.invokeStatic(core.concat.invokeStatic(Tuple.create(MapEntry.create(const__9, this.name), MapEntry.create(const__8, this.return_type), MapEntry.create(const__10, this.declaring_class), MapEntry.create(const__11, this.parameter_types), MapEntry.create(const__12, this.exception_types), MapEntry.create(const__13, this.flags)), this.__extmap)); }
/*     */   
/*     */   /* Error */
/*     */   public clojure.lang.IMapEntry entryAt(Object k__6441__auto__)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: checkcast 12	clojure/lang/ILookup
/*     */     //   4: aload_1
/*     */     //   5: aload_0
/*     */     //   6: invokeinterface 131 3 0
/*     */     //   11: astore_2
/*     */     //   12: aload_0
/*     */     //   13: aload_2
/*     */     //   14: invokestatic 251	clojure/lang/Util:identical	(Ljava/lang/Object;Ljava/lang/Object;)Z
/*     */     //   17: ifeq +8 -> 25
/*     */     //   20: aconst_null
/*     */     //   21: goto +13 -> 34
/*     */     //   24: pop
/*     */     //   25: aload_1
/*     */     //   26: aconst_null
/*     */     //   27: astore_1
/*     */     //   28: aload_2
/*     */     //   29: aconst_null
/*     */     //   30: astore_2
/*     */     //   31: invokestatic 289	clojure/lang/MapEntry:create	(Ljava/lang/Object;Ljava/lang/Object;)Lclojure/lang/MapEntry;
/*     */     //   34: checkcast 292	clojure/lang/IMapEntry
/*     */     //   37: areturn
/*     */     // Line number table:
/*     */     //   Java source line #128	-> byte code offset #0
/*     */     //   Java source line #128	-> byte code offset #6
/*     */     //   Java source line #128	-> byte code offset #12
/*     */     //   Java source line #128	-> byte code offset #14
/*     */     //   Java source line #128	-> byte code offset #31
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	37	0	this	Method
/*     */     //   0	37	1	k__6441__auto__	Object
/*     */     //   12	22	2	v__6442__auto__9992	Object
/*     */   }
/*     */   
/*     */   public boolean containsKey(Object k__6439__auto__)
/*     */   {
/* 128 */     k__6439__auto__ = null;return ((Boolean)core.not.invokeStatic(Util.identical(this, ((ILookup)this).valAt(k__6439__auto__, this)) ? Boolean.TRUE : Boolean.FALSE)).booleanValue();
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public boolean equiv(Object G__9966)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: aload_1
/*     */     //   2: invokestatic 251	clojure/lang/Util:identical	(Ljava/lang/Object;Ljava/lang/Object;)Z
/*     */     //   5: istore_2
/*     */     //   6: iload_2
/*     */     //   7: ifeq +20 -> 27
/*     */     //   10: iload_2
/*     */     //   11: ifeq +9 -> 20
/*     */     //   14: getstatic 257	java/lang/Boolean:TRUE	Ljava/lang/Boolean;
/*     */     //   17: goto +6 -> 23
/*     */     //   20: getstatic 260	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   23: goto +289 -> 312
/*     */     //   26: pop
/*     */     //   27: aload_0
/*     */     //   28: invokestatic 171	clojure/core$class:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   31: aload_1
/*     */     //   32: invokestatic 171	clojure/core$class:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   35: invokestatic 251	clojure/lang/Util:identical	(Ljava/lang/Object;Ljava/lang/Object;)Z
/*     */     //   38: ifeq +273 -> 311
/*     */     //   41: aload_1
/*     */     //   42: aconst_null
/*     */     //   43: astore_1
/*     */     //   44: astore_3
/*     */     //   45: aload_0
/*     */     //   46: getfield 37	clojure/reflect/Method:name	Ljava/lang/Object;
/*     */     //   49: aload_3
/*     */     //   50: checkcast 2	clojure/reflect/Method
/*     */     //   53: getfield 37	clojure/reflect/Method:name	Ljava/lang/Object;
/*     */     //   56: invokestatic 262	clojure/lang/Util:equiv	(Ljava/lang/Object;Ljava/lang/Object;)Z
/*     */     //   59: istore 4
/*     */     //   61: iload 4
/*     */     //   63: ifeq +230 -> 293
/*     */     //   66: aload_0
/*     */     //   67: getfield 39	clojure/reflect/Method:return_type	Ljava/lang/Object;
/*     */     //   70: aload_3
/*     */     //   71: checkcast 2	clojure/reflect/Method
/*     */     //   74: getfield 39	clojure/reflect/Method:return_type	Ljava/lang/Object;
/*     */     //   77: invokestatic 262	clojure/lang/Util:equiv	(Ljava/lang/Object;Ljava/lang/Object;)Z
/*     */     //   80: istore 5
/*     */     //   82: iload 5
/*     */     //   84: ifeq +191 -> 275
/*     */     //   87: aload_0
/*     */     //   88: getfield 41	clojure/reflect/Method:declaring_class	Ljava/lang/Object;
/*     */     //   91: aload_3
/*     */     //   92: checkcast 2	clojure/reflect/Method
/*     */     //   95: getfield 41	clojure/reflect/Method:declaring_class	Ljava/lang/Object;
/*     */     //   98: invokestatic 262	clojure/lang/Util:equiv	(Ljava/lang/Object;Ljava/lang/Object;)Z
/*     */     //   101: istore 6
/*     */     //   103: iload 6
/*     */     //   105: ifeq +152 -> 257
/*     */     //   108: aload_0
/*     */     //   109: getfield 43	clojure/reflect/Method:parameter_types	Ljava/lang/Object;
/*     */     //   112: aload_3
/*     */     //   113: checkcast 2	clojure/reflect/Method
/*     */     //   116: getfield 43	clojure/reflect/Method:parameter_types	Ljava/lang/Object;
/*     */     //   119: invokestatic 262	clojure/lang/Util:equiv	(Ljava/lang/Object;Ljava/lang/Object;)Z
/*     */     //   122: istore 7
/*     */     //   124: iload 7
/*     */     //   126: ifeq +113 -> 239
/*     */     //   129: aload_0
/*     */     //   130: getfield 45	clojure/reflect/Method:exception_types	Ljava/lang/Object;
/*     */     //   133: aload_3
/*     */     //   134: checkcast 2	clojure/reflect/Method
/*     */     //   137: getfield 45	clojure/reflect/Method:exception_types	Ljava/lang/Object;
/*     */     //   140: invokestatic 262	clojure/lang/Util:equiv	(Ljava/lang/Object;Ljava/lang/Object;)Z
/*     */     //   143: istore 8
/*     */     //   145: iload 8
/*     */     //   147: ifeq +74 -> 221
/*     */     //   150: aload_0
/*     */     //   151: getfield 47	clojure/reflect/Method:flags	Ljava/lang/Object;
/*     */     //   154: aload_3
/*     */     //   155: checkcast 2	clojure/reflect/Method
/*     */     //   158: getfield 47	clojure/reflect/Method:flags	Ljava/lang/Object;
/*     */     //   161: invokestatic 262	clojure/lang/Util:equiv	(Ljava/lang/Object;Ljava/lang/Object;)Z
/*     */     //   164: istore 9
/*     */     //   166: iload 9
/*     */     //   168: ifeq +35 -> 203
/*     */     //   171: aload_0
/*     */     //   172: getfield 51	clojure/reflect/Method:__extmap	Ljava/lang/Object;
/*     */     //   175: aload_3
/*     */     //   176: aconst_null
/*     */     //   177: astore_3
/*     */     //   178: checkcast 2	clojure/reflect/Method
/*     */     //   181: getfield 51	clojure/reflect/Method:__extmap	Ljava/lang/Object;
/*     */     //   184: invokestatic 262	clojure/lang/Util:equiv	(Ljava/lang/Object;Ljava/lang/Object;)Z
/*     */     //   187: ifeq +9 -> 196
/*     */     //   190: getstatic 257	java/lang/Boolean:TRUE	Ljava/lang/Boolean;
/*     */     //   193: goto +6 -> 199
/*     */     //   196: getstatic 260	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   199: goto +18 -> 217
/*     */     //   202: pop
/*     */     //   203: iload 9
/*     */     //   205: ifeq +9 -> 214
/*     */     //   208: getstatic 257	java/lang/Boolean:TRUE	Ljava/lang/Boolean;
/*     */     //   211: goto +6 -> 217
/*     */     //   214: getstatic 260	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   217: goto +18 -> 235
/*     */     //   220: pop
/*     */     //   221: iload 8
/*     */     //   223: ifeq +9 -> 232
/*     */     //   226: getstatic 257	java/lang/Boolean:TRUE	Ljava/lang/Boolean;
/*     */     //   229: goto +6 -> 235
/*     */     //   232: getstatic 260	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   235: goto +18 -> 253
/*     */     //   238: pop
/*     */     //   239: iload 7
/*     */     //   241: ifeq +9 -> 250
/*     */     //   244: getstatic 257	java/lang/Boolean:TRUE	Ljava/lang/Boolean;
/*     */     //   247: goto +6 -> 253
/*     */     //   250: getstatic 260	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   253: goto +18 -> 271
/*     */     //   256: pop
/*     */     //   257: iload 6
/*     */     //   259: ifeq +9 -> 268
/*     */     //   262: getstatic 257	java/lang/Boolean:TRUE	Ljava/lang/Boolean;
/*     */     //   265: goto +6 -> 271
/*     */     //   268: getstatic 260	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   271: goto +18 -> 289
/*     */     //   274: pop
/*     */     //   275: iload 5
/*     */     //   277: ifeq +9 -> 286
/*     */     //   280: getstatic 257	java/lang/Boolean:TRUE	Ljava/lang/Boolean;
/*     */     //   283: goto +6 -> 289
/*     */     //   286: getstatic 260	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   289: goto +18 -> 307
/*     */     //   292: pop
/*     */     //   293: iload 4
/*     */     //   295: ifeq +9 -> 304
/*     */     //   298: getstatic 257	java/lang/Boolean:TRUE	Ljava/lang/Boolean;
/*     */     //   301: goto +6 -> 307
/*     */     //   304: getstatic 260	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   307: goto +5 -> 312
/*     */     //   310: pop
/*     */     //   311: aconst_null
/*     */     //   312: invokestatic 273	clojure/lang/RT:booleanCast	(Ljava/lang/Object;)Z
/*     */     //   315: ireturn
/*     */     // Line number table:
/*     */     //   Java source line #128	-> byte code offset #0
/*     */     //   Java source line #128	-> byte code offset #2
/*     */     //   Java source line #128	-> byte code offset #6
/*     */     //   Java source line #128	-> byte code offset #27
/*     */     //   Java source line #128	-> byte code offset #35
/*     */     //   Java source line #128	-> byte code offset #50
/*     */     //   Java source line #128	-> byte code offset #56
/*     */     //   Java source line #128	-> byte code offset #61
/*     */     //   Java source line #128	-> byte code offset #71
/*     */     //   Java source line #128	-> byte code offset #77
/*     */     //   Java source line #128	-> byte code offset #82
/*     */     //   Java source line #128	-> byte code offset #92
/*     */     //   Java source line #128	-> byte code offset #98
/*     */     //   Java source line #128	-> byte code offset #103
/*     */     //   Java source line #128	-> byte code offset #113
/*     */     //   Java source line #128	-> byte code offset #119
/*     */     //   Java source line #128	-> byte code offset #124
/*     */     //   Java source line #128	-> byte code offset #134
/*     */     //   Java source line #128	-> byte code offset #140
/*     */     //   Java source line #128	-> byte code offset #145
/*     */     //   Java source line #128	-> byte code offset #155
/*     */     //   Java source line #128	-> byte code offset #161
/*     */     //   Java source line #128	-> byte code offset #166
/*     */     //   Java source line #128	-> byte code offset #178
/*     */     //   Java source line #128	-> byte code offset #184
/*     */     //   Java source line #128	-> byte code offset #312
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	315	0	this	Method
/*     */     //   0	315	1	G__9966	Object
/*     */     //   6	306	2	or__4469__auto__9991	boolean
/*     */     //   45	262	3	G__9966	Object
/*     */     //   61	246	4	and__4467__auto__9990	boolean
/*     */     //   82	207	5	and__4467__auto__9989	boolean
/*     */     //   103	168	6	and__4467__auto__9988	boolean
/*     */     //   124	129	7	and__4467__auto__9987	boolean
/*     */     //   145	90	8	and__4467__auto__9986	boolean
/*     */     //   166	51	9	and__4467__auto__9985	boolean
/*     */   }
/*     */   
/*     */   public IPersistentCollection cons(Object e__6436__auto__)
/*     */   {
/* 128 */     e__6436__auto__ = null;return (IPersistentCollection)((IFn)const__26).invoke(this, e__6436__auto__);
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public IPersistentCollection empty()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: new 211	java/lang/UnsupportedOperationException
/*     */     //   3: dup
/*     */     //   4: ldc -43
/*     */     //   6: iconst_1
/*     */     //   7: anewarray 4	java/lang/Object
/*     */     //   10: dup
/*     */     //   11: iconst_0
/*     */     //   12: ldc -41
/*     */     //   14: aastore
/*     */     //   15: invokestatic 220	clojure/lang/ArraySeq:create	([Ljava/lang/Object;)Lclojure/lang/ArraySeq;
/*     */     //   18: invokestatic 225	clojure/core$str:invokeStatic	(Ljava/lang/Object;Lclojure/lang/ISeq;)Ljava/lang/Object;
/*     */     //   21: checkcast 227	java/lang/String
/*     */     //   24: invokespecial 230	java/lang/UnsupportedOperationException:<init>	(Ljava/lang/String;)V
/*     */     //   27: checkcast 232	java/lang/Throwable
/*     */     //   30: athrow
/*     */     //   31: checkcast 234	clojure/lang/IPersistentCollection
/*     */     //   34: areturn
/*     */     // Line number table:
/*     */     //   Java source line #128	-> byte code offset #0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	34	0	this	Method
/*     */   }
/*     */   
/* 128 */   public int count() { return RT.intCast(Numbers.add(6L, RT.count(this.__extmap))); } public ILookupThunk getLookupThunk(Keyword k__6432__auto__) { Object gclass = core.class.invokeStatic(this);k__6432__auto__ = null;Object G__9970 = k__6432__auto__; switch (Util.hash(G__9970) >> 0 & 0x7) {case 0:  if (G__9970 == const__10) { gclass = null;tmpTernaryOp = new Method.reify__9971(null, gclass); } break; case 1:  if (G__9970 == const__9) { gclass = null;tmpTernaryOp = new Method.reify__9973(null, gclass); } break; case 2:  if (G__9970 == const__8) { gclass = null;tmpTernaryOp = new Method.reify__9975(null, gclass); } break; case 4:  if (G__9970 == const__11) { gclass = null;tmpTernaryOp = new Method.reify__9977(null, gclass); } break; case 5:  if (G__9970 == const__12) { gclass = null;tmpTernaryOp = new Method.reify__9979(null, gclass); } break; case 6:  gclass = null; } return (ILookupThunk)(G__9970 == const__13 ? new Method.reify__9981(null, gclass) : null); } public Object valAt(Object k__6429__auto__, Object else__6430__auto__) { Object G__9983 = k__6429__auto__; switch (Util.hash(G__9983) >> 0 & 0x7) {case 0:  if (G__9983 == const__10) tmpTernaryOp = this.declaring_class; break; case 1:  if (G__9983 == const__9) tmpTernaryOp = this.name; break; case 2:  if (G__9983 == const__8) tmpTernaryOp = this.return_type; break; case 4:  if (G__9983 == const__11) tmpTernaryOp = this.parameter_types; break; case 5:  if (G__9983 == const__12) tmpTernaryOp = this.exception_types; break; } k__6429__auto__ = null;else__6430__auto__ = null;return G__9983 == const__13 ? this.flags : RT.get(this.__extmap, k__6429__auto__, else__6430__auto__); } public Object valAt(Object k__6427__auto__) { k__6427__auto__ = null;return ((ILookup)this).valAt(k__6427__auto__, null); } public IObj withMeta(IPersistentMap G__9966) { G__9966 = null;return (IObj)new Method(this.name, this.return_type, this.declaring_class, this.parameter_types, this.exception_types, this.flags, G__9966, this.__extmap); } public IPersistentMap meta() { return (IPersistentMap)this.__meta; } public boolean equals(Object G__9966) { G__9966 = null;return APersistentMap.mapEquals((IPersistentMap)this, G__9966); } public int hashCode() { return APersistentMap.mapHash((IPersistentMap)this); } public int hasheq() { return RT.intCast(0xFFFFFFFFE1D6579E ^ APersistentMap.mapHasheq((IPersistentMap)this)); } public static Method create(IPersistentMap paramIPersistentMap) { Object localObject1 = paramIPersistentMap.valAt(Keyword.intern("name"), null);
/*     */     paramIPersistentMap = paramIPersistentMap.without(Keyword.intern("name"));
/*     */     Object localObject2 = paramIPersistentMap.valAt(Keyword.intern("return-type"), null);
/*     */     paramIPersistentMap = paramIPersistentMap.without(Keyword.intern("return-type"));
/*     */     Object localObject3 = paramIPersistentMap.valAt(Keyword.intern("declaring-class"), null);
/*     */     paramIPersistentMap = paramIPersistentMap.without(Keyword.intern("declaring-class"));
/*     */     Object localObject4 = paramIPersistentMap.valAt(Keyword.intern("parameter-types"), null);
/*     */     paramIPersistentMap = paramIPersistentMap.without(Keyword.intern("parameter-types"));
/*     */     Object localObject5 = paramIPersistentMap.valAt(Keyword.intern("exception-types"), null);
/*     */     paramIPersistentMap = paramIPersistentMap.without(Keyword.intern("exception-types"));
/*     */     Object localObject6 = paramIPersistentMap.valAt(Keyword.intern("flags"), null);
/*     */     paramIPersistentMap = paramIPersistentMap.without(Keyword.intern("flags"));
/*     */     return new Method(localObject1, localObject2, localObject3, localObject4, localObject5, localObject6, null, RT.seqOrElse(paramIPersistentMap)); } public static IPersistentVector getBasis() { return Tuple.create(Symbol.intern(null, "name"), Symbol.intern(null, "return-type"), Symbol.intern(null, "declaring-class"), Symbol.intern(null, "parameter-types"), Symbol.intern(null, "exception-types"), Symbol.intern(null, "flags")); } public Method(Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4, Object paramObject5, Object paramObject6) { this(paramObject1, paramObject2, paramObject3, paramObject4, paramObject5, paramObject6, null, null); } public Method(Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4, Object paramObject5, Object paramObject6, Object paramObject7, Object paramObject8) { this.name = paramObject1;this.return_type = paramObject2;this.declaring_class = paramObject3;this.parameter_types = paramObject4;this.exception_types = paramObject5;this.flags = paramObject6;this.__meta = paramObject7;this.__extmap = paramObject8; } public static final Var const__26 = (Var)RT.var("clojure.core", "imap-cons"); public static final AFn const__21 = (AFn)Tuple.create(RT.keyword(null, "name"), RT.keyword(null, "return-type"), RT.keyword(null, "declaring-class"), RT.keyword(null, "parameter-types"), RT.keyword(null, "exception-types"), RT.keyword(null, "flags")); public static final Var const__19 = (Var)RT.var("clojure.core", "identical?"); public static final AFn const__14 = (AFn)PersistentHashSet.create(new Object[] { RT.keyword(null, "return-type"), RT.keyword(null, "name"), RT.keyword(null, "declaring-class"), RT.keyword(null, "parameter-types"), RT.keyword(null, "exception-types"), RT.keyword(null, "flags") }); public static final Keyword const__13 = (Keyword)RT.keyword(null, "flags"); public static final Keyword const__12 = (Keyword)RT.keyword(null, "exception-types"); public static final Keyword const__11 = (Keyword)RT.keyword(null, "parameter-types"); public static final Keyword const__10 = (Keyword)RT.keyword(null, "declaring-class"); public static final Keyword const__9 = (Keyword)RT.keyword(null, "name"); public static final Keyword const__8 = (Keyword)RT.keyword(null, "return-type");
/*     */   public final Object __extmap;
/*     */   public final Object __meta;
/*     */   public final Object flags;
/*     */   public final Object exception_types;
/*     */   public final Object parameter_types;
/*     */   public final Object declaring_class;
/*     */   public final Object return_type;
/*     */   public final Object name;
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\reflect\Method.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */