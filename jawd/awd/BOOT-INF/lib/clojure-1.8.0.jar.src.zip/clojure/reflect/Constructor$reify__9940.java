/*     */ package clojure.reflect;
/*     */ 
/*     */ import clojure.lang.ILookupThunk;
/*     */ import clojure.lang.IObj;
/*     */ import clojure.lang.IPersistentMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Constructor$reify__9940
/*     */   implements ILookupThunk, IObj
/*     */ {
/*     */   final IPersistentMap __meta;
/*     */   Object gclass;
/*     */   
/*     */   public Constructor$reify__9940(IPersistentMap paramIPersistentMap, Object paramObject)
/*     */   {
/* 109 */     this.__meta = paramIPersistentMap;this.gclass = paramObject;
/*     */   }
/*     */   
/*     */   public Constructor$reify__9940(Object paramObject)
/*     */   {
/*     */     this(null, paramObject);
/*     */   }
/*     */   
/*     */   public IPersistentMap meta()
/*     */   {
/*     */     return this.__meta;
/*     */   }
/*     */   
/*     */   public IObj withMeta(IPersistentMap paramIPersistentMap)
/*     */   {
/*     */     return new reify__9940(paramIPersistentMap, this.gclass);
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public Object get(Object gtarget)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_1
/*     */     //   1: invokestatic 36	clojure/core$class:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   4: aload_0
/*     */     //   5: getfield 22	clojure/reflect/Constructor$reify__9940:gclass	Ljava/lang/Object;
/*     */     //   8: invokestatic 42	clojure/lang/Util:identical	(Ljava/lang/Object;Ljava/lang/Object;)Z
/*     */     //   11: ifeq +16 -> 27
/*     */     //   14: aload_1
/*     */     //   15: aconst_null
/*     */     //   16: astore_1
/*     */     //   17: checkcast 44	clojure/reflect/Constructor
/*     */     //   20: getfield 47	clojure/reflect/Constructor:declaring_class	Ljava/lang/Object;
/*     */     //   23: goto +5 -> 28
/*     */     //   26: pop
/*     */     //   27: aload_0
/*     */     //   28: areturn
/*     */     // Line number table:
/*     */     //   Java source line #109	-> byte code offset #0
/*     */     //   Java source line #109	-> byte code offset #0
/*     */     //   Java source line #109	-> byte code offset #8
/*     */     //   Java source line #109	-> byte code offset #17
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	28	0	this	reify__9940
/*     */     //   0	28	1	gtarget	Object
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\reflect\Constructor$reify__9940.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */