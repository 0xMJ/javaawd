/*     */ package clojure.reflect;
/*     */ 
/*     */ import clojure.core.class;
/*     */ import clojure.core.concat;
/*     */ import clojure.core.keys;
/*     */ import clojure.core.not;
/*     */ import clojure.core.seq__4357;
/*     */ import clojure.core.set;
/*     */ import clojure.core.some;
/*     */ import clojure.core.vals;
/*     */ import clojure.lang.AFn;
/*     */ import clojure.lang.APersistentMap;
/*     */ import clojure.lang.Counted;
/*     */ import clojure.lang.IFn;
/*     */ import clojure.lang.IHashEq;
/*     */ import clojure.lang.IKeywordLookup;
/*     */ import clojure.lang.ILookup;
/*     */ import clojure.lang.ILookupThunk;
/*     */ import clojure.lang.IObj;
/*     */ import clojure.lang.IPersistentCollection;
/*     */ import clojure.lang.IPersistentMap;
/*     */ import clojure.lang.IPersistentVector;
/*     */ import clojure.lang.IRecord;
/*     */ import clojure.lang.ISeq;
/*     */ import clojure.lang.Keyword;
/*     */ import clojure.lang.MapEntry;
/*     */ import clojure.lang.Numbers;
/*     */ import clojure.lang.PersistentHashSet;
/*     */ import clojure.lang.RT;
/*     */ import clojure.lang.RecordIterator;
/*     */ import clojure.lang.Symbol;
/*     */ import clojure.lang.Tuple;
/*     */ import clojure.lang.Util;
/*     */ import clojure.lang.Var;
/*     */ import java.io.Serializable;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Constructor
/*     */   implements IRecord, IHashEq, IObj, ILookup, IKeywordLookup, IPersistentMap, Map, Serializable
/*     */ {
/* 109 */   public Set entrySet() { return (Set)core.set.invokeStatic(this); } public Collection values() { return (Collection)core.vals.invokeStatic(this); } public Set keySet() { return (Set)core.set.invokeStatic(core.keys.invokeStatic(this)); }
/*     */   
/*     */   /* Error */
/*     */   public void clear()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: new 200	java/lang/UnsupportedOperationException
/*     */     //   3: dup
/*     */     //   4: invokespecial 380	java/lang/UnsupportedOperationException:<init>	()V
/*     */     //   7: checkcast 221	java/lang/Throwable
/*     */     //   10: athrow
/*     */     //   11: pop
/*     */     //   12: return
/*     */     // Line number table:
/*     */     //   Java source line #109	-> byte code offset #0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	12	0	this	Constructor
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public void putAll(Map m__6461__auto__)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: new 200	java/lang/UnsupportedOperationException
/*     */     //   3: dup
/*     */     //   4: invokespecial 380	java/lang/UnsupportedOperationException:<init>	()V
/*     */     //   7: checkcast 221	java/lang/Throwable
/*     */     //   10: athrow
/*     */     //   11: pop
/*     */     //   12: return
/*     */     // Line number table:
/*     */     //   Java source line #109	-> byte code offset #0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	12	0	this	Constructor
/*     */     //   0	12	1	m__6461__auto__	Map
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public Object remove(Object k__6459__auto__)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: new 200	java/lang/UnsupportedOperationException
/*     */     //   3: dup
/*     */     //   4: invokespecial 380	java/lang/UnsupportedOperationException:<init>	()V
/*     */     //   7: checkcast 221	java/lang/Throwable
/*     */     //   10: athrow
/*     */     //   11: areturn
/*     */     // Line number table:
/*     */     //   Java source line #109	-> byte code offset #0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	11	0	this	Constructor
/*     */     //   0	11	1	k__6459__auto__	Object
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public Object put(Object k__6456__auto__, Object v__6457__auto__)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: new 200	java/lang/UnsupportedOperationException
/*     */     //   3: dup
/*     */     //   4: invokespecial 380	java/lang/UnsupportedOperationException:<init>	()V
/*     */     //   7: checkcast 221	java/lang/Throwable
/*     */     //   10: athrow
/*     */     //   11: areturn
/*     */     // Line number table:
/*     */     //   Java source line #109	-> byte code offset #0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	11	0	this	Constructor
/*     */     //   0	11	1	k__6456__auto__	Object
/*     */     //   0	11	2	v__6457__auto__	Object
/*     */   }
/*     */   
/*     */   public Object get(Object k__6454__auto__)
/*     */   {
/* 109 */     k__6454__auto__ = null;return ((ILookup)this).valAt(k__6454__auto__); } public boolean containsValue(Object v__6452__auto__) { Object[] tmp4_1 = new Object[1];v__6452__auto__ = null;tmp4_1[0] = v__6452__auto__;return RT.booleanCast(core.some.invokeStatic(RT.set(tmp4_1), core.vals.invokeStatic(this))); } public boolean isEmpty() { return Util.equiv(0L, ((Counted)this).count()); } public int size() { return ((Counted)this).count(); }
/*     */   
/*     */   /* Error */
/*     */   public IPersistentMap without(Object k__6448__auto__)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: getstatic 332	clojure/reflect/Constructor:const__13	Lclojure/lang/AFn;
/*     */     //   3: aload_1
/*     */     //   4: invokestatic 335	clojure/core$contains_QMARK_:invokeStatic	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   7: dup
/*     */     //   8: ifnull +32 -> 40
/*     */     //   11: getstatic 249	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   14: if_acmpeq +27 -> 41
/*     */     //   17: getstatic 341	clojure/lang/PersistentArrayMap:EMPTY	Lclojure/lang/PersistentArrayMap;
/*     */     //   20: aload_0
/*     */     //   21: invokestatic 344	clojure/core$into:invokeStatic	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   24: aload_0
/*     */     //   25: getfield 46	clojure/reflect/Constructor:__meta	Ljava/lang/Object;
/*     */     //   28: invokestatic 347	clojure/core$with_meta__4375:invokeStatic	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   31: aload_1
/*     */     //   32: aconst_null
/*     */     //   33: astore_1
/*     */     //   34: invokestatic 350	clojure/core$dissoc:invokeStatic	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   37: goto +48 -> 85
/*     */     //   40: pop
/*     */     //   41: new 2	clojure/reflect/Constructor
/*     */     //   44: dup
/*     */     //   45: aload_0
/*     */     //   46: getfield 36	clojure/reflect/Constructor:name	Ljava/lang/Object;
/*     */     //   49: aload_0
/*     */     //   50: getfield 38	clojure/reflect/Constructor:declaring_class	Ljava/lang/Object;
/*     */     //   53: aload_0
/*     */     //   54: getfield 40	clojure/reflect/Constructor:parameter_types	Ljava/lang/Object;
/*     */     //   57: aload_0
/*     */     //   58: getfield 42	clojure/reflect/Constructor:exception_types	Ljava/lang/Object;
/*     */     //   61: aload_0
/*     */     //   62: getfield 44	clojure/reflect/Constructor:flags	Ljava/lang/Object;
/*     */     //   65: aload_0
/*     */     //   66: getfield 46	clojure/reflect/Constructor:__meta	Ljava/lang/Object;
/*     */     //   69: aload_0
/*     */     //   70: getfield 48	clojure/reflect/Constructor:__extmap	Ljava/lang/Object;
/*     */     //   73: aload_1
/*     */     //   74: aconst_null
/*     */     //   75: astore_1
/*     */     //   76: invokestatic 350	clojure/core$dissoc:invokeStatic	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   79: invokestatic 353	clojure/core$not_empty:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   82: invokespecial 51	clojure/reflect/Constructor:<init>	(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
/*     */     //   85: checkcast 16	clojure/lang/IPersistentMap
/*     */     //   88: areturn
/*     */     // Line number table:
/*     */     //   Java source line #109	-> byte code offset #0
/*     */     //   Java source line #109	-> byte code offset #0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	88	0	this	Constructor
/*     */     //   0	88	1	k__6448__auto__	Object
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public IPersistentMap assoc(Object k__6446__auto__, Object G__9935)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: getstatic 316	clojure/reflect/Constructor:const__18	Lclojure/lang/Var;
/*     */     //   3: invokevirtual 322	clojure/lang/Var:getRawRoot	()Ljava/lang/Object;
/*     */     //   6: astore_3
/*     */     //   7: aload_1
/*     */     //   8: astore 4
/*     */     //   10: aload_3
/*     */     //   11: checkcast 231	clojure/lang/IFn
/*     */     //   14: getstatic 140	clojure/reflect/Constructor:const__8	Lclojure/lang/Keyword;
/*     */     //   17: aload 4
/*     */     //   19: invokeinterface 234 3 0
/*     */     //   24: dup
/*     */     //   25: ifnull +46 -> 71
/*     */     //   28: getstatic 249	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   31: if_acmpeq +41 -> 72
/*     */     //   34: new 2	clojure/reflect/Constructor
/*     */     //   37: dup
/*     */     //   38: aload_2
/*     */     //   39: aconst_null
/*     */     //   40: astore_2
/*     */     //   41: aload_0
/*     */     //   42: getfield 38	clojure/reflect/Constructor:declaring_class	Ljava/lang/Object;
/*     */     //   45: aload_0
/*     */     //   46: getfield 40	clojure/reflect/Constructor:parameter_types	Ljava/lang/Object;
/*     */     //   49: aload_0
/*     */     //   50: getfield 42	clojure/reflect/Constructor:exception_types	Ljava/lang/Object;
/*     */     //   53: aload_0
/*     */     //   54: getfield 44	clojure/reflect/Constructor:flags	Ljava/lang/Object;
/*     */     //   57: aload_0
/*     */     //   58: getfield 46	clojure/reflect/Constructor:__meta	Ljava/lang/Object;
/*     */     //   61: aload_0
/*     */     //   62: getfield 48	clojure/reflect/Constructor:__extmap	Ljava/lang/Object;
/*     */     //   65: invokespecial 51	clojure/reflect/Constructor:<init>	(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
/*     */     //   68: goto +301 -> 369
/*     */     //   71: pop
/*     */     //   72: aload_3
/*     */     //   73: checkcast 231	clojure/lang/IFn
/*     */     //   76: getstatic 137	clojure/reflect/Constructor:const__9	Lclojure/lang/Keyword;
/*     */     //   79: aload 4
/*     */     //   81: invokeinterface 234 3 0
/*     */     //   86: dup
/*     */     //   87: ifnull +46 -> 133
/*     */     //   90: getstatic 249	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   93: if_acmpeq +41 -> 134
/*     */     //   96: new 2	clojure/reflect/Constructor
/*     */     //   99: dup
/*     */     //   100: aload_0
/*     */     //   101: getfield 36	clojure/reflect/Constructor:name	Ljava/lang/Object;
/*     */     //   104: aload_2
/*     */     //   105: aconst_null
/*     */     //   106: astore_2
/*     */     //   107: aload_0
/*     */     //   108: getfield 40	clojure/reflect/Constructor:parameter_types	Ljava/lang/Object;
/*     */     //   111: aload_0
/*     */     //   112: getfield 42	clojure/reflect/Constructor:exception_types	Ljava/lang/Object;
/*     */     //   115: aload_0
/*     */     //   116: getfield 44	clojure/reflect/Constructor:flags	Ljava/lang/Object;
/*     */     //   119: aload_0
/*     */     //   120: getfield 46	clojure/reflect/Constructor:__meta	Ljava/lang/Object;
/*     */     //   123: aload_0
/*     */     //   124: getfield 48	clojure/reflect/Constructor:__extmap	Ljava/lang/Object;
/*     */     //   127: invokespecial 51	clojure/reflect/Constructor:<init>	(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
/*     */     //   130: goto +239 -> 369
/*     */     //   133: pop
/*     */     //   134: aload_3
/*     */     //   135: checkcast 231	clojure/lang/IFn
/*     */     //   138: getstatic 143	clojure/reflect/Constructor:const__10	Lclojure/lang/Keyword;
/*     */     //   141: aload 4
/*     */     //   143: invokeinterface 234 3 0
/*     */     //   148: dup
/*     */     //   149: ifnull +46 -> 195
/*     */     //   152: getstatic 249	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   155: if_acmpeq +41 -> 196
/*     */     //   158: new 2	clojure/reflect/Constructor
/*     */     //   161: dup
/*     */     //   162: aload_0
/*     */     //   163: getfield 36	clojure/reflect/Constructor:name	Ljava/lang/Object;
/*     */     //   166: aload_0
/*     */     //   167: getfield 38	clojure/reflect/Constructor:declaring_class	Ljava/lang/Object;
/*     */     //   170: aload_2
/*     */     //   171: aconst_null
/*     */     //   172: astore_2
/*     */     //   173: aload_0
/*     */     //   174: getfield 42	clojure/reflect/Constructor:exception_types	Ljava/lang/Object;
/*     */     //   177: aload_0
/*     */     //   178: getfield 44	clojure/reflect/Constructor:flags	Ljava/lang/Object;
/*     */     //   181: aload_0
/*     */     //   182: getfield 46	clojure/reflect/Constructor:__meta	Ljava/lang/Object;
/*     */     //   185: aload_0
/*     */     //   186: getfield 48	clojure/reflect/Constructor:__extmap	Ljava/lang/Object;
/*     */     //   189: invokespecial 51	clojure/reflect/Constructor:<init>	(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
/*     */     //   192: goto +177 -> 369
/*     */     //   195: pop
/*     */     //   196: aload_3
/*     */     //   197: checkcast 231	clojure/lang/IFn
/*     */     //   200: getstatic 146	clojure/reflect/Constructor:const__11	Lclojure/lang/Keyword;
/*     */     //   203: aload 4
/*     */     //   205: invokeinterface 234 3 0
/*     */     //   210: dup
/*     */     //   211: ifnull +46 -> 257
/*     */     //   214: getstatic 249	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   217: if_acmpeq +41 -> 258
/*     */     //   220: new 2	clojure/reflect/Constructor
/*     */     //   223: dup
/*     */     //   224: aload_0
/*     */     //   225: getfield 36	clojure/reflect/Constructor:name	Ljava/lang/Object;
/*     */     //   228: aload_0
/*     */     //   229: getfield 38	clojure/reflect/Constructor:declaring_class	Ljava/lang/Object;
/*     */     //   232: aload_0
/*     */     //   233: getfield 40	clojure/reflect/Constructor:parameter_types	Ljava/lang/Object;
/*     */     //   236: aload_2
/*     */     //   237: aconst_null
/*     */     //   238: astore_2
/*     */     //   239: aload_0
/*     */     //   240: getfield 44	clojure/reflect/Constructor:flags	Ljava/lang/Object;
/*     */     //   243: aload_0
/*     */     //   244: getfield 46	clojure/reflect/Constructor:__meta	Ljava/lang/Object;
/*     */     //   247: aload_0
/*     */     //   248: getfield 48	clojure/reflect/Constructor:__extmap	Ljava/lang/Object;
/*     */     //   251: invokespecial 51	clojure/reflect/Constructor:<init>	(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
/*     */     //   254: goto +115 -> 369
/*     */     //   257: pop
/*     */     //   258: aload_3
/*     */     //   259: aconst_null
/*     */     //   260: astore_3
/*     */     //   261: checkcast 231	clojure/lang/IFn
/*     */     //   264: getstatic 149	clojure/reflect/Constructor:const__12	Lclojure/lang/Keyword;
/*     */     //   267: aload 4
/*     */     //   269: aconst_null
/*     */     //   270: astore 4
/*     */     //   272: invokeinterface 234 3 0
/*     */     //   277: dup
/*     */     //   278: ifnull +46 -> 324
/*     */     //   281: getstatic 249	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   284: if_acmpeq +41 -> 325
/*     */     //   287: new 2	clojure/reflect/Constructor
/*     */     //   290: dup
/*     */     //   291: aload_0
/*     */     //   292: getfield 36	clojure/reflect/Constructor:name	Ljava/lang/Object;
/*     */     //   295: aload_0
/*     */     //   296: getfield 38	clojure/reflect/Constructor:declaring_class	Ljava/lang/Object;
/*     */     //   299: aload_0
/*     */     //   300: getfield 40	clojure/reflect/Constructor:parameter_types	Ljava/lang/Object;
/*     */     //   303: aload_0
/*     */     //   304: getfield 42	clojure/reflect/Constructor:exception_types	Ljava/lang/Object;
/*     */     //   307: aload_2
/*     */     //   308: aconst_null
/*     */     //   309: astore_2
/*     */     //   310: aload_0
/*     */     //   311: getfield 46	clojure/reflect/Constructor:__meta	Ljava/lang/Object;
/*     */     //   314: aload_0
/*     */     //   315: getfield 48	clojure/reflect/Constructor:__extmap	Ljava/lang/Object;
/*     */     //   318: invokespecial 51	clojure/reflect/Constructor:<init>	(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
/*     */     //   321: goto +48 -> 369
/*     */     //   324: pop
/*     */     //   325: new 2	clojure/reflect/Constructor
/*     */     //   328: dup
/*     */     //   329: aload_0
/*     */     //   330: getfield 36	clojure/reflect/Constructor:name	Ljava/lang/Object;
/*     */     //   333: aload_0
/*     */     //   334: getfield 38	clojure/reflect/Constructor:declaring_class	Ljava/lang/Object;
/*     */     //   337: aload_0
/*     */     //   338: getfield 40	clojure/reflect/Constructor:parameter_types	Ljava/lang/Object;
/*     */     //   341: aload_0
/*     */     //   342: getfield 42	clojure/reflect/Constructor:exception_types	Ljava/lang/Object;
/*     */     //   345: aload_0
/*     */     //   346: getfield 44	clojure/reflect/Constructor:flags	Ljava/lang/Object;
/*     */     //   349: aload_0
/*     */     //   350: getfield 46	clojure/reflect/Constructor:__meta	Ljava/lang/Object;
/*     */     //   353: aload_0
/*     */     //   354: getfield 48	clojure/reflect/Constructor:__extmap	Ljava/lang/Object;
/*     */     //   357: aload_1
/*     */     //   358: aconst_null
/*     */     //   359: astore_1
/*     */     //   360: aload_2
/*     */     //   361: aconst_null
/*     */     //   362: astore_2
/*     */     //   363: invokestatic 326	clojure/core$assoc__4371:invokeStatic	(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   366: invokespecial 51	clojure/reflect/Constructor:<init>	(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
/*     */     //   369: checkcast 16	clojure/lang/IPersistentMap
/*     */     //   372: areturn
/*     */     // Line number table:
/*     */     //   Java source line #109	-> byte code offset #0
/*     */     //   Java source line #109	-> byte code offset #10
/*     */     //   Java source line #109	-> byte code offset #11
/*     */     //   Java source line #109	-> byte code offset #19
/*     */     //   Java source line #109	-> byte code offset #72
/*     */     //   Java source line #109	-> byte code offset #73
/*     */     //   Java source line #109	-> byte code offset #81
/*     */     //   Java source line #109	-> byte code offset #134
/*     */     //   Java source line #109	-> byte code offset #135
/*     */     //   Java source line #109	-> byte code offset #143
/*     */     //   Java source line #109	-> byte code offset #196
/*     */     //   Java source line #109	-> byte code offset #197
/*     */     //   Java source line #109	-> byte code offset #205
/*     */     //   Java source line #109	-> byte code offset #258
/*     */     //   Java source line #109	-> byte code offset #261
/*     */     //   Java source line #109	-> byte code offset #272
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	372	0	this	Constructor
/*     */     //   0	372	1	k__6446__auto__	Object
/*     */     //   0	372	2	G__9935	Object
/*     */     //   7	362	3	pred__9937	Object
/*     */     //   10	359	4	expr__9938	Object
/*     */   }
/*     */   
/* 109 */   public Iterator iterator() { return (Iterator)new RecordIterator((ILookup)this, (IPersistentVector)const__20, (Iterator)RT.iter(this.__extmap)); } public ISeq seq() { return (ISeq)core.seq__4357.invokeStatic(core.concat.invokeStatic(Tuple.create(MapEntry.create(const__8, this.name), MapEntry.create(const__9, this.declaring_class), MapEntry.create(const__10, this.parameter_types), MapEntry.create(const__11, this.exception_types), MapEntry.create(const__12, this.flags)), this.__extmap)); }
/*     */   
/*     */   /* Error */
/*     */   public clojure.lang.IMapEntry entryAt(Object k__6441__auto__)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: checkcast 12	clojure/lang/ILookup
/*     */     //   4: aload_1
/*     */     //   5: aload_0
/*     */     //   6: invokeinterface 126 3 0
/*     */     //   11: astore_2
/*     */     //   12: aload_0
/*     */     //   13: aload_2
/*     */     //   14: invokestatic 240	clojure/lang/Util:identical	(Ljava/lang/Object;Ljava/lang/Object;)Z
/*     */     //   17: ifeq +8 -> 25
/*     */     //   20: aconst_null
/*     */     //   21: goto +13 -> 34
/*     */     //   24: pop
/*     */     //   25: aload_1
/*     */     //   26: aconst_null
/*     */     //   27: astore_1
/*     */     //   28: aload_2
/*     */     //   29: aconst_null
/*     */     //   30: astore_2
/*     */     //   31: invokestatic 277	clojure/lang/MapEntry:create	(Ljava/lang/Object;Ljava/lang/Object;)Lclojure/lang/MapEntry;
/*     */     //   34: checkcast 280	clojure/lang/IMapEntry
/*     */     //   37: areturn
/*     */     // Line number table:
/*     */     //   Java source line #109	-> byte code offset #0
/*     */     //   Java source line #109	-> byte code offset #6
/*     */     //   Java source line #109	-> byte code offset #12
/*     */     //   Java source line #109	-> byte code offset #14
/*     */     //   Java source line #109	-> byte code offset #31
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	37	0	this	Constructor
/*     */     //   0	37	1	k__6441__auto__	Object
/*     */     //   12	22	2	v__6442__auto__9958	Object
/*     */   }
/*     */   
/*     */   public boolean containsKey(Object k__6439__auto__)
/*     */   {
/* 109 */     k__6439__auto__ = null;return ((Boolean)core.not.invokeStatic(Util.identical(this, ((ILookup)this).valAt(k__6439__auto__, this)) ? Boolean.TRUE : Boolean.FALSE)).booleanValue();
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public boolean equiv(Object G__9935)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: aload_1
/*     */     //   2: invokestatic 240	clojure/lang/Util:identical	(Ljava/lang/Object;Ljava/lang/Object;)Z
/*     */     //   5: istore_2
/*     */     //   6: iload_2
/*     */     //   7: ifeq +20 -> 27
/*     */     //   10: iload_2
/*     */     //   11: ifeq +9 -> 20
/*     */     //   14: getstatic 246	java/lang/Boolean:TRUE	Ljava/lang/Boolean;
/*     */     //   17: goto +6 -> 23
/*     */     //   20: getstatic 249	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   23: goto +250 -> 273
/*     */     //   26: pop
/*     */     //   27: aload_0
/*     */     //   28: invokestatic 163	clojure/core$class:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   31: aload_1
/*     */     //   32: invokestatic 163	clojure/core$class:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   35: invokestatic 240	clojure/lang/Util:identical	(Ljava/lang/Object;Ljava/lang/Object;)Z
/*     */     //   38: ifeq +234 -> 272
/*     */     //   41: aload_1
/*     */     //   42: aconst_null
/*     */     //   43: astore_1
/*     */     //   44: astore_3
/*     */     //   45: aload_0
/*     */     //   46: getfield 36	clojure/reflect/Constructor:name	Ljava/lang/Object;
/*     */     //   49: aload_3
/*     */     //   50: checkcast 2	clojure/reflect/Constructor
/*     */     //   53: getfield 36	clojure/reflect/Constructor:name	Ljava/lang/Object;
/*     */     //   56: invokestatic 251	clojure/lang/Util:equiv	(Ljava/lang/Object;Ljava/lang/Object;)Z
/*     */     //   59: istore 4
/*     */     //   61: iload 4
/*     */     //   63: ifeq +191 -> 254
/*     */     //   66: aload_0
/*     */     //   67: getfield 38	clojure/reflect/Constructor:declaring_class	Ljava/lang/Object;
/*     */     //   70: aload_3
/*     */     //   71: checkcast 2	clojure/reflect/Constructor
/*     */     //   74: getfield 38	clojure/reflect/Constructor:declaring_class	Ljava/lang/Object;
/*     */     //   77: invokestatic 251	clojure/lang/Util:equiv	(Ljava/lang/Object;Ljava/lang/Object;)Z
/*     */     //   80: istore 5
/*     */     //   82: iload 5
/*     */     //   84: ifeq +152 -> 236
/*     */     //   87: aload_0
/*     */     //   88: getfield 40	clojure/reflect/Constructor:parameter_types	Ljava/lang/Object;
/*     */     //   91: aload_3
/*     */     //   92: checkcast 2	clojure/reflect/Constructor
/*     */     //   95: getfield 40	clojure/reflect/Constructor:parameter_types	Ljava/lang/Object;
/*     */     //   98: invokestatic 251	clojure/lang/Util:equiv	(Ljava/lang/Object;Ljava/lang/Object;)Z
/*     */     //   101: istore 6
/*     */     //   103: iload 6
/*     */     //   105: ifeq +113 -> 218
/*     */     //   108: aload_0
/*     */     //   109: getfield 42	clojure/reflect/Constructor:exception_types	Ljava/lang/Object;
/*     */     //   112: aload_3
/*     */     //   113: checkcast 2	clojure/reflect/Constructor
/*     */     //   116: getfield 42	clojure/reflect/Constructor:exception_types	Ljava/lang/Object;
/*     */     //   119: invokestatic 251	clojure/lang/Util:equiv	(Ljava/lang/Object;Ljava/lang/Object;)Z
/*     */     //   122: istore 7
/*     */     //   124: iload 7
/*     */     //   126: ifeq +74 -> 200
/*     */     //   129: aload_0
/*     */     //   130: getfield 44	clojure/reflect/Constructor:flags	Ljava/lang/Object;
/*     */     //   133: aload_3
/*     */     //   134: checkcast 2	clojure/reflect/Constructor
/*     */     //   137: getfield 44	clojure/reflect/Constructor:flags	Ljava/lang/Object;
/*     */     //   140: invokestatic 251	clojure/lang/Util:equiv	(Ljava/lang/Object;Ljava/lang/Object;)Z
/*     */     //   143: istore 8
/*     */     //   145: iload 8
/*     */     //   147: ifeq +35 -> 182
/*     */     //   150: aload_0
/*     */     //   151: getfield 48	clojure/reflect/Constructor:__extmap	Ljava/lang/Object;
/*     */     //   154: aload_3
/*     */     //   155: aconst_null
/*     */     //   156: astore_3
/*     */     //   157: checkcast 2	clojure/reflect/Constructor
/*     */     //   160: getfield 48	clojure/reflect/Constructor:__extmap	Ljava/lang/Object;
/*     */     //   163: invokestatic 251	clojure/lang/Util:equiv	(Ljava/lang/Object;Ljava/lang/Object;)Z
/*     */     //   166: ifeq +9 -> 175
/*     */     //   169: getstatic 246	java/lang/Boolean:TRUE	Ljava/lang/Boolean;
/*     */     //   172: goto +6 -> 178
/*     */     //   175: getstatic 249	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   178: goto +18 -> 196
/*     */     //   181: pop
/*     */     //   182: iload 8
/*     */     //   184: ifeq +9 -> 193
/*     */     //   187: getstatic 246	java/lang/Boolean:TRUE	Ljava/lang/Boolean;
/*     */     //   190: goto +6 -> 196
/*     */     //   193: getstatic 249	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   196: goto +18 -> 214
/*     */     //   199: pop
/*     */     //   200: iload 7
/*     */     //   202: ifeq +9 -> 211
/*     */     //   205: getstatic 246	java/lang/Boolean:TRUE	Ljava/lang/Boolean;
/*     */     //   208: goto +6 -> 214
/*     */     //   211: getstatic 249	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   214: goto +18 -> 232
/*     */     //   217: pop
/*     */     //   218: iload 6
/*     */     //   220: ifeq +9 -> 229
/*     */     //   223: getstatic 246	java/lang/Boolean:TRUE	Ljava/lang/Boolean;
/*     */     //   226: goto +6 -> 232
/*     */     //   229: getstatic 249	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   232: goto +18 -> 250
/*     */     //   235: pop
/*     */     //   236: iload 5
/*     */     //   238: ifeq +9 -> 247
/*     */     //   241: getstatic 246	java/lang/Boolean:TRUE	Ljava/lang/Boolean;
/*     */     //   244: goto +6 -> 250
/*     */     //   247: getstatic 249	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   250: goto +18 -> 268
/*     */     //   253: pop
/*     */     //   254: iload 4
/*     */     //   256: ifeq +9 -> 265
/*     */     //   259: getstatic 246	java/lang/Boolean:TRUE	Ljava/lang/Boolean;
/*     */     //   262: goto +6 -> 268
/*     */     //   265: getstatic 249	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   268: goto +5 -> 273
/*     */     //   271: pop
/*     */     //   272: aconst_null
/*     */     //   273: invokestatic 261	clojure/lang/RT:booleanCast	(Ljava/lang/Object;)Z
/*     */     //   276: ireturn
/*     */     // Line number table:
/*     */     //   Java source line #109	-> byte code offset #0
/*     */     //   Java source line #109	-> byte code offset #2
/*     */     //   Java source line #109	-> byte code offset #6
/*     */     //   Java source line #109	-> byte code offset #27
/*     */     //   Java source line #109	-> byte code offset #35
/*     */     //   Java source line #109	-> byte code offset #50
/*     */     //   Java source line #109	-> byte code offset #56
/*     */     //   Java source line #109	-> byte code offset #61
/*     */     //   Java source line #109	-> byte code offset #71
/*     */     //   Java source line #109	-> byte code offset #77
/*     */     //   Java source line #109	-> byte code offset #82
/*     */     //   Java source line #109	-> byte code offset #92
/*     */     //   Java source line #109	-> byte code offset #98
/*     */     //   Java source line #109	-> byte code offset #103
/*     */     //   Java source line #109	-> byte code offset #113
/*     */     //   Java source line #109	-> byte code offset #119
/*     */     //   Java source line #109	-> byte code offset #124
/*     */     //   Java source line #109	-> byte code offset #134
/*     */     //   Java source line #109	-> byte code offset #140
/*     */     //   Java source line #109	-> byte code offset #145
/*     */     //   Java source line #109	-> byte code offset #157
/*     */     //   Java source line #109	-> byte code offset #163
/*     */     //   Java source line #109	-> byte code offset #273
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	276	0	this	Constructor
/*     */     //   0	276	1	G__9935	Object
/*     */     //   6	267	2	or__4469__auto__9957	boolean
/*     */     //   45	223	3	G__9935	Object
/*     */     //   61	207	4	and__4467__auto__9956	boolean
/*     */     //   82	168	5	and__4467__auto__9955	boolean
/*     */     //   103	129	6	and__4467__auto__9954	boolean
/*     */     //   124	90	7	and__4467__auto__9953	boolean
/*     */     //   145	51	8	and__4467__auto__9952	boolean
/*     */   }
/*     */   
/*     */   public IPersistentCollection cons(Object e__6436__auto__)
/*     */   {
/* 109 */     e__6436__auto__ = null;return (IPersistentCollection)((IFn)const__25).invoke(this, e__6436__auto__);
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public IPersistentCollection empty()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: new 200	java/lang/UnsupportedOperationException
/*     */     //   3: dup
/*     */     //   4: ldc -54
/*     */     //   6: iconst_1
/*     */     //   7: anewarray 4	java/lang/Object
/*     */     //   10: dup
/*     */     //   11: iconst_0
/*     */     //   12: ldc -52
/*     */     //   14: aastore
/*     */     //   15: invokestatic 209	clojure/lang/ArraySeq:create	([Ljava/lang/Object;)Lclojure/lang/ArraySeq;
/*     */     //   18: invokestatic 214	clojure/core$str:invokeStatic	(Ljava/lang/Object;Lclojure/lang/ISeq;)Ljava/lang/Object;
/*     */     //   21: checkcast 216	java/lang/String
/*     */     //   24: invokespecial 219	java/lang/UnsupportedOperationException:<init>	(Ljava/lang/String;)V
/*     */     //   27: checkcast 221	java/lang/Throwable
/*     */     //   30: athrow
/*     */     //   31: checkcast 223	clojure/lang/IPersistentCollection
/*     */     //   34: areturn
/*     */     // Line number table:
/*     */     //   Java source line #109	-> byte code offset #0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	34	0	this	Constructor
/*     */   }
/*     */   
/* 109 */   public int count() { return RT.intCast(Numbers.add(5L, RT.count(this.__extmap))); } public ILookupThunk getLookupThunk(Keyword k__6432__auto__) { Object gclass = core.class.invokeStatic(this);k__6432__auto__ = null;Object G__9939 = k__6432__auto__; switch (Util.hash(G__9939) >> 0 & 0x7) {case 0:  if (G__9939 == const__9) { gclass = null;tmpTernaryOp = new Constructor.reify__9940(null, gclass); } break; case 1:  if (G__9939 == const__8) { gclass = null;tmpTernaryOp = new Constructor.reify__9942(null, gclass); } break; case 4:  if (G__9939 == const__10) { gclass = null;tmpTernaryOp = new Constructor.reify__9944(null, gclass); } break; case 5:  if (G__9939 == const__11) { gclass = null;tmpTernaryOp = new Constructor.reify__9946(null, gclass); } break; case 6:  gclass = null; } return (ILookupThunk)(G__9939 == const__12 ? new Constructor.reify__9948(null, gclass) : null); } public Object valAt(Object k__6429__auto__, Object else__6430__auto__) { Object G__9950 = k__6429__auto__; switch (Util.hash(G__9950) >> 0 & 0x7) {case 0:  if (G__9950 == const__9) tmpTernaryOp = this.declaring_class; break; case 1:  if (G__9950 == const__8) tmpTernaryOp = this.name; break; case 4:  if (G__9950 == const__10) tmpTernaryOp = this.parameter_types; break; case 5:  if (G__9950 == const__11) tmpTernaryOp = this.exception_types; break; } k__6429__auto__ = null;else__6430__auto__ = null;return G__9950 == const__12 ? this.flags : RT.get(this.__extmap, k__6429__auto__, else__6430__auto__); } public Object valAt(Object k__6427__auto__) { k__6427__auto__ = null;return ((ILookup)this).valAt(k__6427__auto__, null); } public IObj withMeta(IPersistentMap G__9935) { G__9935 = null;return (IObj)new Constructor(this.name, this.declaring_class, this.parameter_types, this.exception_types, this.flags, G__9935, this.__extmap); } public IPersistentMap meta() { return (IPersistentMap)this.__meta; } public boolean equals(Object G__9935) { G__9935 = null;return APersistentMap.mapEquals((IPersistentMap)this, G__9935); } public int hashCode() { return APersistentMap.mapHash((IPersistentMap)this); } public int hasheq() { return RT.intCast(0x178D27A7 ^ APersistentMap.mapHasheq((IPersistentMap)this)); } public static Constructor create(IPersistentMap paramIPersistentMap) { Object localObject1 = paramIPersistentMap.valAt(Keyword.intern("name"), null);
/*     */     paramIPersistentMap = paramIPersistentMap.without(Keyword.intern("name"));
/*     */     Object localObject2 = paramIPersistentMap.valAt(Keyword.intern("declaring-class"), null);
/*     */     paramIPersistentMap = paramIPersistentMap.without(Keyword.intern("declaring-class"));
/*     */     Object localObject3 = paramIPersistentMap.valAt(Keyword.intern("parameter-types"), null);
/*     */     paramIPersistentMap = paramIPersistentMap.without(Keyword.intern("parameter-types"));
/*     */     Object localObject4 = paramIPersistentMap.valAt(Keyword.intern("exception-types"), null);
/*     */     paramIPersistentMap = paramIPersistentMap.without(Keyword.intern("exception-types"));
/*     */     Object localObject5 = paramIPersistentMap.valAt(Keyword.intern("flags"), null);
/*     */     paramIPersistentMap = paramIPersistentMap.without(Keyword.intern("flags"));
/*     */     return new Constructor(localObject1, localObject2, localObject3, localObject4, localObject5, null, RT.seqOrElse(paramIPersistentMap)); } public static IPersistentVector getBasis() { return Tuple.create(Symbol.intern(null, "name"), Symbol.intern(null, "declaring-class"), Symbol.intern(null, "parameter-types"), Symbol.intern(null, "exception-types"), Symbol.intern(null, "flags")); } public Constructor(Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4, Object paramObject5) { this(paramObject1, paramObject2, paramObject3, paramObject4, paramObject5, null, null); } public Constructor(Object paramObject1, Object paramObject2, Object paramObject3, Object paramObject4, Object paramObject5, Object paramObject6, Object paramObject7) { this.name = paramObject1;this.declaring_class = paramObject2;this.parameter_types = paramObject3;this.exception_types = paramObject4;this.flags = paramObject5;this.__meta = paramObject6;this.__extmap = paramObject7; } public static final Var const__25 = (Var)RT.var("clojure.core", "imap-cons"); public static final AFn const__20 = (AFn)Tuple.create(RT.keyword(null, "name"), RT.keyword(null, "declaring-class"), RT.keyword(null, "parameter-types"), RT.keyword(null, "exception-types"), RT.keyword(null, "flags")); public static final Var const__18 = (Var)RT.var("clojure.core", "identical?"); public static final AFn const__13 = (AFn)PersistentHashSet.create(new Object[] { RT.keyword(null, "name"), RT.keyword(null, "declaring-class"), RT.keyword(null, "parameter-types"), RT.keyword(null, "exception-types"), RT.keyword(null, "flags") }); public static final Keyword const__12 = (Keyword)RT.keyword(null, "flags"); public static final Keyword const__11 = (Keyword)RT.keyword(null, "exception-types"); public static final Keyword const__10 = (Keyword)RT.keyword(null, "parameter-types"); public static final Keyword const__9 = (Keyword)RT.keyword(null, "declaring-class"); public static final Keyword const__8 = (Keyword)RT.keyword(null, "name");
/*     */   public final Object __extmap;
/*     */   public final Object __meta;
/*     */   public final Object flags;
/*     */   public final Object exception_types;
/*     */   public final Object parameter_types;
/*     */   public final Object declaring_class;
/*     */   public final Object name;
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\reflect\Constructor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */