/*     */ package clojure.reflect;
/*     */ 
/*     */ import clojure.lang.AFunction;
/*     */ import clojure.lang.Keyword;
/*     */ import clojure.lang.RT;
/*     */ import clojure.lang.Var;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AsmReflector$fn__10068
/*     */   extends AFunction
/*     */ {
/*     */   public AsmReflector$fn__10068(Object paramObject1, Object paramObject2)
/*     */   {
/* 205 */     this.result = paramObject1;this.class_symbol = paramObject2; } public static final Var const__16 = (Var)RT.var("clojure.reflect", "internal-name->class-symbol"); public static final Keyword const__13 = (Keyword)RT.keyword(null, "method"); public static final Keyword const__11 = (Keyword)RT.keyword(null, "return-type"); public static final Keyword const__10 = (Keyword)RT.keyword(null, "parameter-types"); public static final Var const__5 = (Var)RT.var("clojure.core", "conj"); public static final Keyword const__3 = (Keyword)RT.keyword(null, "members"); public static final Var const__2 = (Var)RT.var("clojure.core", "update");
/*     */   Object class_symbol;
/*     */   Object result;
/*     */   
/*     */   /* Error */
/*     */   public Object invoke(Object this, Object access, Object name, Object desc, Object signature, Object exceptions)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_3
/*     */     //   1: ldc 21
/*     */     //   3: invokestatic 27	clojure/lang/Util:equiv	(Ljava/lang/Object;Ljava/lang/Object;)Z
/*     */     //   6: ifeq +9 -> 15
/*     */     //   9: aconst_null
/*     */     //   10: pop
/*     */     //   11: goto +235 -> 246
/*     */     //   14: pop
/*     */     //   15: aload_3
/*     */     //   16: ldc 28
/*     */     //   18: invokestatic 27	clojure/lang/Util:equiv	(Ljava/lang/Object;Ljava/lang/Object;)Z
/*     */     //   21: istore 7
/*     */     //   23: aload_0
/*     */     //   24: getfield 15	clojure/reflect/AsmReflector$fn__10068:result	Ljava/lang/Object;
/*     */     //   27: getstatic 32	clojure/reflect/AsmReflector$fn__10068:const__2	Lclojure/lang/Var;
/*     */     //   30: invokevirtual 38	clojure/lang/Var:getRawRoot	()Ljava/lang/Object;
/*     */     //   33: getstatic 42	clojure/reflect/AsmReflector$fn__10068:const__3	Lclojure/lang/Keyword;
/*     */     //   36: getstatic 45	clojure/reflect/AsmReflector$fn__10068:const__5	Lclojure/lang/Var;
/*     */     //   39: invokevirtual 38	clojure/lang/Var:getRawRoot	()Ljava/lang/Object;
/*     */     //   42: getstatic 51	clojure/lang/PersistentHashSet:EMPTY	Lclojure/lang/PersistentHashSet;
/*     */     //   45: invokestatic 57	clojure/core$fnil:invokeStatic	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   48: iconst_1
/*     */     //   49: anewarray 59	java/lang/Object
/*     */     //   52: dup
/*     */     //   53: iconst_0
/*     */     //   54: aload 4
/*     */     //   56: aconst_null
/*     */     //   57: astore 4
/*     */     //   59: invokestatic 64	clojure/reflect$parse_method_descriptor:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   62: astore 8
/*     */     //   64: aload 8
/*     */     //   66: invokestatic 67	clojure/core$seq_QMARK___4361:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   69: dup
/*     */     //   70: ifnull +26 -> 96
/*     */     //   73: getstatic 73	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   76: if_acmpeq +21 -> 97
/*     */     //   79: aload 8
/*     */     //   81: aconst_null
/*     */     //   82: astore 8
/*     */     //   84: invokestatic 76	clojure/core$seq__4357:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   87: checkcast 78	clojure/lang/ISeq
/*     */     //   90: invokestatic 84	clojure/lang/PersistentHashMap:create	(Lclojure/lang/ISeq;)Lclojure/lang/PersistentHashMap;
/*     */     //   93: goto +9 -> 102
/*     */     //   96: pop
/*     */     //   97: aload 8
/*     */     //   99: aconst_null
/*     */     //   100: astore 8
/*     */     //   102: astore 9
/*     */     //   104: aload 9
/*     */     //   106: getstatic 87	clojure/reflect/AsmReflector$fn__10068:const__10	Lclojure/lang/Keyword;
/*     */     //   109: invokestatic 92	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   112: astore 10
/*     */     //   114: aload 9
/*     */     //   116: aconst_null
/*     */     //   117: astore 9
/*     */     //   119: getstatic 95	clojure/reflect/AsmReflector$fn__10068:const__11	Lclojure/lang/Keyword;
/*     */     //   122: invokestatic 92	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   125: astore 11
/*     */     //   127: aload_2
/*     */     //   128: aconst_null
/*     */     //   129: astore_2
/*     */     //   130: getstatic 98	clojure/reflect/AsmReflector$fn__10068:const__13	Lclojure/lang/Keyword;
/*     */     //   133: invokestatic 101	clojure/reflect$parse_flags:invokeStatic	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   136: astore 12
/*     */     //   138: iload 7
/*     */     //   140: ifeq +49 -> 189
/*     */     //   143: new 103	clojure/reflect/Constructor
/*     */     //   146: dup
/*     */     //   147: aload_0
/*     */     //   148: getfield 17	clojure/reflect/AsmReflector$fn__10068:class_symbol	Ljava/lang/Object;
/*     */     //   151: aload_0
/*     */     //   152: getfield 17	clojure/reflect/AsmReflector$fn__10068:class_symbol	Ljava/lang/Object;
/*     */     //   155: aload 10
/*     */     //   157: aconst_null
/*     */     //   158: astore 10
/*     */     //   160: getstatic 106	clojure/reflect/AsmReflector$fn__10068:const__16	Lclojure/lang/Var;
/*     */     //   163: invokevirtual 38	clojure/lang/Var:getRawRoot	()Ljava/lang/Object;
/*     */     //   166: aload 6
/*     */     //   168: aconst_null
/*     */     //   169: astore 6
/*     */     //   171: invokestatic 109	clojure/core$map:invokeStatic	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   174: invokestatic 112	clojure/core$vec:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   177: aload 12
/*     */     //   179: aconst_null
/*     */     //   180: astore 12
/*     */     //   182: invokespecial 115	clojure/reflect/Constructor:<init>	(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
/*     */     //   185: goto +53 -> 238
/*     */     //   188: pop
/*     */     //   189: new 117	clojure/reflect/Method
/*     */     //   192: dup
/*     */     //   193: aload_3
/*     */     //   194: aconst_null
/*     */     //   195: astore_3
/*     */     //   196: invokestatic 120	clojure/core$symbol:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   199: aload 11
/*     */     //   201: aconst_null
/*     */     //   202: astore 11
/*     */     //   204: aload_0
/*     */     //   205: getfield 17	clojure/reflect/AsmReflector$fn__10068:class_symbol	Ljava/lang/Object;
/*     */     //   208: aload 10
/*     */     //   210: aconst_null
/*     */     //   211: astore 10
/*     */     //   213: getstatic 106	clojure/reflect/AsmReflector$fn__10068:const__16	Lclojure/lang/Var;
/*     */     //   216: invokevirtual 38	clojure/lang/Var:getRawRoot	()Ljava/lang/Object;
/*     */     //   219: aload 6
/*     */     //   221: aconst_null
/*     */     //   222: astore 6
/*     */     //   224: invokestatic 109	clojure/core$map:invokeStatic	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   227: invokestatic 112	clojure/core$vec:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   230: aload 12
/*     */     //   232: aconst_null
/*     */     //   233: astore 12
/*     */     //   235: invokespecial 123	clojure/reflect/Method:<init>	(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
/*     */     //   238: aastore
/*     */     //   239: invokestatic 132	clojure/lang/ArraySeq:create	([Ljava/lang/Object;)Lclojure/lang/ArraySeq;
/*     */     //   242: invokestatic 137	clojure/core$swap_BANG_:invokeStatic	(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lclojure/lang/ISeq;)Ljava/lang/Object;
/*     */     //   245: pop
/*     */     //   246: aconst_null
/*     */     //   247: areturn
/*     */     // Line number table:
/*     */     //   Java source line #205	-> byte code offset #0
/*     */     //   Java source line #234	-> byte code offset #0
/*     */     //   Java source line #234	-> byte code offset #3
/*     */     //   Java source line #235	-> byte code offset #18
/*     */     //   Java source line #237	-> byte code offset #64
/*     */     //   Java source line #237	-> byte code offset #90
/*     */     //   Java source line #237	-> byte code offset #109
/*     */     //   Java source line #237	-> byte code offset #122
/*     */     //   Java source line #239	-> byte code offset #138
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	247	0	this	Object
/*     */     //   0	247	1	this	Object
/*     */     //   0	247	2	access	Object
/*     */     //   0	247	3	name	Object
/*     */     //   0	247	4	desc	Object
/*     */     //   0	247	5	signature	Object
/*     */     //   0	247	6	exceptions	Object
/*     */     //   23	223	7	constructor_QMARK_	boolean
/*     */     //   64	174	8	map__10069	Object
/*     */     //   104	134	9	map__10069	Object
/*     */     //   114	124	10	parameter_types	Object
/*     */     //   127	111	11	return_type	Object
/*     */     //   138	100	12	flags	Object
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\reflect\AsmReflector$fn__10068.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */