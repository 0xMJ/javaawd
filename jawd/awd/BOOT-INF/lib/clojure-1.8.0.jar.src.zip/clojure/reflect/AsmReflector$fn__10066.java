/*     */ package clojure.reflect;
/*     */ 
/*     */ import clojure.core.fnil;
/*     */ import clojure.core.swap_BANG_;
/*     */ import clojure.core.symbol;
/*     */ import clojure.lang.AFunction;
/*     */ import clojure.lang.ArraySeq;
/*     */ import clojure.lang.Keyword;
/*     */ import clojure.lang.PersistentHashSet;
/*     */ import clojure.lang.RT;
/*     */ import clojure.lang.Var;
/*     */ import clojure.reflect.field_descriptor__GT_class_symbol;
/*     */ import clojure.reflect.parse_flags;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AsmReflector$fn__10066
/*     */   extends AFunction
/*     */ {
/*     */   public Object invoke(Object this, Object access, Object name, Object desc, Object signature, Object value)
/*     */   {
/* 205 */     Object[] tmp29_26 = new Object[1];name = null;desc = null;access = null;tmp29_26[0] = new Field(core.symbol.invokeStatic(name), reflect.field_descriptor__GT_class_symbol.invokeStatic(desc), ((fn__10066)this).class_symbol, reflect.parse_flags.invokeStatic(access, const__8));core.swap_BANG_.invokeStatic(((fn__10066)this).result, const__1.getRawRoot(), const__2, core.fnil.invokeStatic(const__4.getRawRoot(), PersistentHashSet.EMPTY), ArraySeq.create(tmp29_26));return null; } public AsmReflector$fn__10066(Object paramObject1, Object paramObject2) { this.result = paramObject1;this.class_symbol = paramObject2; } public static final Keyword const__8 = (Keyword)RT.keyword(null, "field"); public static final Var const__4 = (Var)RT.var("clojure.core", "conj"); public static final Keyword const__2 = (Keyword)RT.keyword(null, "members"); public static final Var const__1 = (Var)RT.var("clojure.core", "update");
/*     */   Object class_symbol;
/*     */   Object result;
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\reflect\AsmReflector$fn__10066.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */