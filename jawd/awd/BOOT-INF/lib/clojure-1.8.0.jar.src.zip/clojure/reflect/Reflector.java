package clojure.reflect;

public abstract interface Reflector
{
  public abstract Object do_reflect(Object paramObject);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\reflect\Reflector.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */