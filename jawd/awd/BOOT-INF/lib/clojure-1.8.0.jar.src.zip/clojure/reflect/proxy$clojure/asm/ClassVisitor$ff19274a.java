package clojure.reflect.proxy$clojure.asm;

import clojure.asm.ClassVisitor;
import clojure.lang.IPersistentCollection;
import clojure.lang.IPersistentMap;
import clojure.lang.IProxy;

public class ClassVisitor$ff19274a
  extends ClassVisitor
  implements IProxy
{
  private volatile IPersistentMap __clojureFnMap;
  
  public ClassVisitor$ff19274a(int paramInt)
  {
    super(paramInt);
  }
  
  public ClassVisitor$ff19274a(int paramInt, ClassVisitor paramClassVisitor)
  {
    super(paramInt, paramClassVisitor);
  }
  
  public void __initClojureFnMappings(IPersistentMap paramIPersistentMap)
  {
    this.__clojureFnMap = paramIPersistentMap;
  }
  
  public void __updateClojureFnMappings(IPersistentMap paramIPersistentMap)
  {
    this.__clojureFnMap = ((IPersistentMap)((IPersistentCollection)this.__clojureFnMap).cons(paramIPersistentMap));
  }
  
  public IPersistentMap __getClojureFnMappings()
  {
    return this.__clojureFnMap;
  }
  
  /* Error */
  public boolean equals(Object arg1)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 19	clojure/reflect/proxy$clojure/asm/ClassVisitor$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 33
    //   6: invokestatic 39	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +22 -> 32
    //   13: checkcast 41	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: invokeinterface 44 3 0
    //   23: checkcast 46	java/lang/Boolean
    //   26: invokevirtual 50	java/lang/Boolean:booleanValue	()Z
    //   29: goto +9 -> 38
    //   32: pop
    //   33: aload_0
    //   34: aload_1
    //   35: invokespecial 52	clojure/asm/ClassVisitor:equals	(Ljava/lang/Object;)Z
    //   38: ireturn
  }
  
  /* Error */
  public clojure.asm.FieldVisitor visitField(int arg1, String arg2, String arg3, String arg4, Object arg5)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 19	clojure/reflect/proxy$clojure/asm/ClassVisitor$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 55
    //   6: invokestatic 39	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +28 -> 38
    //   13: checkcast 41	clojure/lang/IFn
    //   16: aload_0
    //   17: iload_1
    //   18: invokestatic 61	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   21: aload_2
    //   22: aload_3
    //   23: aload 4
    //   25: aload 5
    //   27: invokeinterface 64 7 0
    //   32: checkcast 66	clojure/asm/FieldVisitor
    //   35: goto +15 -> 50
    //   38: pop
    //   39: aload_0
    //   40: iload_1
    //   41: aload_2
    //   42: aload_3
    //   43: aload 4
    //   45: aload 5
    //   47: invokespecial 68	clojure/asm/ClassVisitor:visitField	(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)Lclojure/asm/FieldVisitor;
    //   50: areturn
  }
  
  /* Error */
  public String toString()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 19	clojure/reflect/proxy$clojure/asm/ClassVisitor$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 71
    //   6: invokestatic 39	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +18 -> 28
    //   13: checkcast 41	clojure/lang/IFn
    //   16: aload_0
    //   17: invokeinterface 74 2 0
    //   22: checkcast 76	java/lang/String
    //   25: goto +8 -> 33
    //   28: pop
    //   29: aload_0
    //   30: invokespecial 78	clojure/asm/ClassVisitor:toString	()Ljava/lang/String;
    //   33: areturn
  }
  
  /* Error */
  public void visitEnd()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 19	clojure/reflect/proxy$clojure/asm/ClassVisitor$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 81
    //   6: invokestatic 39	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +16 -> 26
    //   13: checkcast 41	clojure/lang/IFn
    //   16: aload_0
    //   17: invokeinterface 74 2 0
    //   22: pop
    //   23: goto +8 -> 31
    //   26: pop
    //   27: aload_0
    //   28: invokespecial 83	clojure/asm/ClassVisitor:visitEnd	()V
    //   31: return
  }
  
  /* Error */
  public void visitInnerClass(String arg1, String arg2, String arg3, int arg4)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 19	clojure/reflect/proxy$clojure/asm/ClassVisitor$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 86
    //   6: invokestatic 39	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +24 -> 34
    //   13: checkcast 41	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: aload_2
    //   19: aload_3
    //   20: iload 4
    //   22: invokestatic 61	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   25: invokeinterface 89 6 0
    //   30: pop
    //   31: goto +13 -> 44
    //   34: pop
    //   35: aload_0
    //   36: aload_1
    //   37: aload_2
    //   38: aload_3
    //   39: iload 4
    //   41: invokespecial 91	clojure/asm/ClassVisitor:visitInnerClass	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)V
    //   44: return
  }
  
  /* Error */
  public void visitAttribute(clojure.asm.Attribute arg1)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 19	clojure/reflect/proxy$clojure/asm/ClassVisitor$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 94
    //   6: invokestatic 39	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +17 -> 27
    //   13: checkcast 41	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: invokeinterface 44 3 0
    //   23: pop
    //   24: goto +9 -> 33
    //   27: pop
    //   28: aload_0
    //   29: aload_1
    //   30: invokespecial 96	clojure/asm/ClassVisitor:visitAttribute	(Lclojure/asm/Attribute;)V
    //   33: return
  }
  
  /* Error */
  public void visitSource(String arg1, String arg2)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 19	clojure/reflect/proxy$clojure/asm/ClassVisitor$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 99
    //   6: invokestatic 39	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +18 -> 28
    //   13: checkcast 41	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: aload_2
    //   19: invokeinterface 102 4 0
    //   24: pop
    //   25: goto +10 -> 35
    //   28: pop
    //   29: aload_0
    //   30: aload_1
    //   31: aload_2
    //   32: invokespecial 104	clojure/asm/ClassVisitor:visitSource	(Ljava/lang/String;Ljava/lang/String;)V
    //   35: return
  }
  
  /* Error */
  public void visit(int arg1, int arg2, String arg3, String arg4, String arg5, String[] arg6)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 19	clojure/reflect/proxy$clojure/asm/ClassVisitor$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 107
    //   6: invokestatic 39	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +31 -> 41
    //   13: checkcast 41	clojure/lang/IFn
    //   16: aload_0
    //   17: iload_1
    //   18: invokestatic 61	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   21: iload_2
    //   22: invokestatic 61	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   25: aload_3
    //   26: aload 4
    //   28: aload 5
    //   30: aload 6
    //   32: invokeinterface 110 8 0
    //   37: pop
    //   38: goto +17 -> 55
    //   41: pop
    //   42: aload_0
    //   43: iload_1
    //   44: iload_2
    //   45: aload_3
    //   46: aload 4
    //   48: aload 5
    //   50: aload 6
    //   52: invokespecial 112	clojure/asm/ClassVisitor:visit	(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)V
    //   55: return
  }
  
  /* Error */
  public clojure.asm.AnnotationVisitor visitAnnotation(String arg1, boolean arg2)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 19	clojure/reflect/proxy$clojure/asm/ClassVisitor$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc 115
    //   6: invokestatic 39	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +32 -> 42
    //   13: checkcast 41	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: iload_2
    //   19: ifeq +9 -> 28
    //   22: getstatic 119	java/lang/Boolean:TRUE	Ljava/lang/Boolean;
    //   25: goto +6 -> 31
    //   28: getstatic 122	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
    //   31: invokeinterface 102 4 0
    //   36: checkcast 124	clojure/asm/AnnotationVisitor
    //   39: goto +10 -> 49
    //   42: pop
    //   43: aload_0
    //   44: aload_1
    //   45: iload_2
    //   46: invokespecial 126	clojure/asm/ClassVisitor:visitAnnotation	(Ljava/lang/String;Z)Lclojure/asm/AnnotationVisitor;
    //   49: areturn
  }
  
  /* Error */
  public clojure.asm.MethodVisitor visitMethod(int arg1, String arg2, String arg3, String arg4, String[] arg5)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 19	clojure/reflect/proxy$clojure/asm/ClassVisitor$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc -127
    //   6: invokestatic 39	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +28 -> 38
    //   13: checkcast 41	clojure/lang/IFn
    //   16: aload_0
    //   17: iload_1
    //   18: invokestatic 61	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   21: aload_2
    //   22: aload_3
    //   23: aload 4
    //   25: aload 5
    //   27: invokeinterface 64 7 0
    //   32: checkcast 131	clojure/asm/MethodVisitor
    //   35: goto +15 -> 50
    //   38: pop
    //   39: aload_0
    //   40: iload_1
    //   41: aload_2
    //   42: aload_3
    //   43: aload 4
    //   45: aload 5
    //   47: invokespecial 133	clojure/asm/ClassVisitor:visitMethod	(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Lclojure/asm/MethodVisitor;
    //   50: areturn
  }
  
  /* Error */
  public int hashCode()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 19	clojure/reflect/proxy$clojure/asm/ClassVisitor$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc -120
    //   6: invokestatic 39	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +21 -> 31
    //   13: checkcast 41	clojure/lang/IFn
    //   16: aload_0
    //   17: invokeinterface 74 2 0
    //   22: checkcast 138	java/lang/Number
    //   25: invokevirtual 141	java/lang/Number:intValue	()I
    //   28: goto +8 -> 36
    //   31: pop
    //   32: aload_0
    //   33: invokespecial 143	clojure/asm/ClassVisitor:hashCode	()I
    //   36: ireturn
  }
  
  /* Error */
  public void visitOuterClass(String arg1, String arg2, String arg3)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 19	clojure/reflect/proxy$clojure/asm/ClassVisitor$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc -110
    //   6: invokestatic 39	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +19 -> 29
    //   13: checkcast 41	clojure/lang/IFn
    //   16: aload_0
    //   17: aload_1
    //   18: aload_2
    //   19: aload_3
    //   20: invokeinterface 149 5 0
    //   25: pop
    //   26: goto +11 -> 37
    //   29: pop
    //   30: aload_0
    //   31: aload_1
    //   32: aload_2
    //   33: aload_3
    //   34: invokespecial 151	clojure/asm/ClassVisitor:visitOuterClass	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    //   37: return
  }
  
  /* Error */
  public Object clone()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 19	clojure/reflect/proxy$clojure/asm/ClassVisitor$ff19274a:__clojureFnMap	Lclojure/lang/IPersistentMap;
    //   4: ldc -102
    //   6: invokestatic 39	clojure/lang/RT:get	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   9: dup
    //   10: ifnull +15 -> 25
    //   13: checkcast 41	clojure/lang/IFn
    //   16: aload_0
    //   17: invokeinterface 74 2 0
    //   22: goto +8 -> 30
    //   25: pop
    //   26: aload_0
    //   27: invokespecial 156	clojure/asm/ClassVisitor:clone	()Ljava/lang/Object;
    //   30: areturn
  }
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\reflect\proxy$clojure\asm\ClassVisitor$ff19274a.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */