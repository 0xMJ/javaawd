/*     */ package clojure.reflect;
/*     */ 
/*     */ import clojure.lang.RT;
/*     */ 
/*     */ public class java__init
/*     */ {
/*     */   public static final clojure.lang.Var const__0;
/*     */   public static final clojure.lang.AFn const__1;
/*     */   public static final clojure.lang.Var const__2;
/*     */   public static final clojure.lang.AFn const__3;
/*     */   public static final clojure.lang.AFn const__4;
/*     */   public static final clojure.lang.Var const__5;
/*     */   public static final Object const__6;
/*     */   public static final clojure.lang.Var const__7;
/*     */   
/*     */   public static void load()
/*     */   {
/*  18 */     clojure.lang.Var tmp280_277 = const__11;tmp280_277.setMeta((clojure.lang.IPersistentMap)const__21);tmp280_277.bindRoot(new clojure.reflect.typesym()); clojure.lang.Var tmp304_301 = const__22;tmp304_301.setMeta((clojure.lang.IPersistentMap)const__25);tmp304_301.bindRoot(new clojure.reflect.resource_name()); clojure.lang.Var tmp328_325 = const__26;tmp328_325.setMeta((clojure.lang.IPersistentMap)const__29);tmp328_325.bindRoot(new clojure.reflect.access_flag()); clojure.lang.Var tmp352_349 = const__30;tmp352_349.setMeta((clojure.lang.IPersistentMap)const__33);tmp352_349.bindRoot(new clojure.reflect.field_descriptor__GT_class_symbol()); clojure.lang.Var tmp376_373 = const__34;tmp376_373.setMeta((clojure.lang.IPersistentMap)const__37);tmp376_373.bindRoot(new clojure.reflect.internal_name__GT_class_symbol()); clojure.lang.Var tmp400_397 = const__38;tmp400_397.setMeta((clojure.lang.IPersistentMap)const__40);tmp400_397
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  74 */       .bindRoot(((clojure.lang.IFn)const__41.getRawRoot()).invoke(
/*  75 */       ((clojure.lang.IFn)const__42.getRawRoot()).invoke(const__26.getRawRoot(), const__96))); clojure.lang.Var tmp454_451 = const__97;tmp454_451.setMeta((clojure.lang.IPersistentMap)const__100);tmp454_451.bindRoot(new clojure.reflect.parse_flags());new clojure.reflect.fn__9936(); clojure.lang.Var 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 109 */       tmp493_490 = const__101;tmp493_490.setMeta((clojure.lang.IPersistentMap)const__104);tmp493_490.bindRoot(new clojure.reflect.constructor__GT_map()); clojure.lang.Var tmp517_514 = const__105;tmp517_514.setMeta((clojure.lang.IPersistentMap)const__108);tmp517_514.bindRoot(new clojure.reflect.declared_constructors());new clojure.reflect.fn__9967(); clojure.lang.Var 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 128 */       tmp556_553 = const__109;tmp556_553.setMeta((clojure.lang.IPersistentMap)const__112);tmp556_553.bindRoot(new clojure.reflect.method__GT_map()); clojure.lang.Var tmp580_577 = const__113;tmp580_577.setMeta((clojure.lang.IPersistentMap)const__116);tmp580_577.bindRoot(new clojure.reflect.declared_methods());new clojure.reflect.fn__10001(); clojure.lang.Var 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 148 */       tmp619_616 = const__117;tmp619_616.setMeta((clojure.lang.IPersistentMap)const__120);tmp619_616.bindRoot(new clojure.reflect.field__GT_map()); clojure.lang.Var tmp643_640 = const__121;tmp643_640.setMeta((clojure.lang.IPersistentMap)const__124);tmp643_640.bindRoot(new clojure.reflect.declared_fields());new clojure.reflect.fn__10028(); clojure.lang.Var 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 166 */       tmp682_679 = const__125;tmp682_679.setMeta((clojure.lang.IPersistentMap)const__127);tmp682_679
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 177 */       .bindRoot(new JavaReflector(((Thread)Thread.currentThread()).getContextClassLoader())); clojure.lang.Var tmp715_712 = const__128;tmp715_712.setMeta((clojure.lang.IPersistentMap)const__131);tmp715_712.bindRoot(new clojure.reflect.parse_method_descriptor());new clojure.reflect.fn__10036();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 188 */     new clojure.reflect.fn__10056();
/*     */   }
/*     */   
/*     */   public static final clojure.lang.Keyword const__8;
/*     */   public static final Object const__9;
/*     */   public static final Object const__10;
/*     */   public static final clojure.lang.Var const__11;
/*     */   public static final clojure.lang.Keyword const__15;
/*     */   public static final clojure.lang.AFn const__21;
/*     */   public static final clojure.lang.Var const__22;
/*     */   public static final clojure.lang.AFn const__25;
/*     */   public static final clojure.lang.Var const__26;
/*     */   public static final clojure.lang.AFn const__29;
/*     */   public static final clojure.lang.Var const__30;
/*     */   public static final clojure.lang.AFn const__33;
/*     */   public static final clojure.lang.Var const__34;
/*     */   public static final clojure.lang.AFn const__37;
/*     */   public static final clojure.lang.Var const__38;
/*     */   public static final clojure.lang.AFn const__40;
/*     */   public static final clojure.lang.Var const__41;
/*     */   public static final clojure.lang.Var const__42;
/*     */   public static final clojure.lang.AFn const__96;
/*     */   public static final clojure.lang.Var const__97;
/*     */   public static final clojure.lang.AFn const__100;
/*     */   public static final clojure.lang.Var const__101;
/*     */   public static final clojure.lang.AFn const__104;
/*     */   public static final clojure.lang.Var const__105;
/*     */   public static final clojure.lang.AFn const__108;
/*     */   public static final clojure.lang.Var const__109;
/*     */   public static final clojure.lang.AFn const__112;
/*     */   public static final clojure.lang.Var const__113;
/*     */   public static final clojure.lang.AFn const__116;
/*     */   public static final clojure.lang.Var const__117;
/*     */   public static final clojure.lang.AFn const__120;
/*     */   public static final clojure.lang.Var const__121;
/*     */   public static final clojure.lang.AFn const__124;
/*     */   public static final clojure.lang.Var const__125;
/*     */   public static final clojure.lang.AFn const__127;
/*     */   public static final clojure.lang.Var const__128;
/*     */   public static final clojure.lang.AFn const__131;
/*     */   public static final Object const__132;
/*     */   public static final clojure.lang.Var const__133;
/*     */   public static final clojure.lang.Var const__134;
/*     */   public static final clojure.lang.Var const__135;
/*     */   public static final clojure.lang.Var const__136;
/*     */   public static final clojure.lang.ISeq const__137;
/*     */   public static final clojure.lang.Var const__138;
/*     */   public static final clojure.lang.Var const__139;
/*     */   public static final clojure.lang.AFn const__143;
/*     */   public static final clojure.lang.Keyword const__144;
/*     */   public static final clojure.lang.AFn const__145;
/*     */   public static final clojure.lang.Keyword const__146;
/*     */   public static final clojure.lang.Keyword const__147;
/*     */   public static final clojure.lang.Keyword const__148;
/*     */   public static final clojure.lang.AFn const__149;
/*     */   public static final clojure.lang.Keyword const__150;
/*     */   public static final clojure.lang.Var const__151;
/*     */   public static final clojure.lang.Var const__152;
/*     */   public static final clojure.lang.Var const__153;
/*     */   public static final clojure.lang.AFn const__154;
/*     */   public static final clojure.lang.AFn const__155;
/*     */   public static final clojure.lang.Keyword const__156;
/*     */   public static final clojure.lang.Var const__157;
/*     */   public static final clojure.lang.AFn const__158;
/*     */   public static final Object const__159;
/*     */   public static final Object const__160;
/*     */   public static void __init0()
/*     */   {
/*     */     const__0 = (clojure.lang.Var)RT.var("clojure.core", "in-ns");
/*     */     const__1 = (clojure.lang.AFn)clojure.lang.Symbol.intern(null, "clojure.reflect");
/*     */     const__2 = (clojure.lang.Var)RT.var("clojure.core", "require");
/*     */     const__3 = (clojure.lang.AFn)clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "clojure.set"), RT.keyword(null, "as"), clojure.lang.Symbol.intern(null, "set"));
/*     */     const__4 = (clojure.lang.AFn)clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "clojure.string"), RT.keyword(null, "as"), clojure.lang.Symbol.intern(null, "str"));
/*     */     const__5 = (clojure.lang.Var)RT.var("clojure.core", "extend");
/*     */     const__6 = RT.classForName("clojure.lang.Symbol");
/*     */     const__7 = (clojure.lang.Var)RT.var("clojure.reflect", "TypeReference");
/*     */     const__8 = (clojure.lang.Keyword)RT.keyword(null, "typename");
/*     */     const__9 = RT.classForName("java.lang.Class");
/*     */     const__10 = RT.classForName("clojure.asm.Type");
/*     */     const__11 = (clojure.lang.Var)RT.var("clojure.reflect", "typesym");
/*     */     const__15 = (clojure.lang.Keyword)RT.keyword(null, "doc");
/*     */     const__21 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "t")) })), RT.keyword(null, "doc"), "Given a typeref, create a legal Clojure symbol version of the\n   type's name.", RT.keyword(null, "line"), Integer.valueOf(33), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/reflect/java.clj" });
/*     */     const__22 = (clojure.lang.Var)RT.var("clojure.reflect", "resource-name");
/*     */     const__25 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "typeref")) })), RT.keyword(null, "doc"), "Given a typeref, return implied resource name. Used by Reflectors\n   such as ASM that need to find and read classbytes from files.", RT.keyword(null, "line"), Integer.valueOf(41), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/reflect/java.clj" });
/*     */     const__26 = (clojure.lang.Var)RT.var("clojure.reflect", "access-flag");
/*     */     const__29 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "name"), clojure.lang.Symbol.intern(null, "flag"), clojure.lang.Symbol.intern(null, "&"), clojure.lang.Symbol.intern(null, "contexts"))) })), RT.keyword(null, "line"), Integer.valueOf(49), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/reflect/java.clj" });
/*     */     const__30 = (clojure.lang.Var)RT.var("clojure.reflect", "field-descriptor->class-symbol");
/*     */     const__33 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { ((clojure.lang.IObj)clojure.lang.Tuple.create(((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "d")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "tag"), clojure.lang.Symbol.intern(null, "String") })))).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "pre"), clojure.lang.Tuple.create(((clojure.lang.IObj)clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Symbol.intern(null, "string?"), clojure.lang.Symbol.intern(null, "d") }))).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "line"), Integer.valueOf(58), RT.keyword(null, "column"), Integer.valueOf(10) }))) })) })), RT.keyword(null, "doc"), "Convert a Java field descriptor to a Clojure class symbol. Field\n   descriptors are described in section 4.3.2 of the JVM spec, 2nd ed.:\n   http://java.sun.com/docs/books/jvms/second_edition/html/ClassFile.doc.html#14152", RT.keyword(null, "line"), Integer.valueOf(53), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/reflect/java.clj" });
/*     */     const__34 = (clojure.lang.Var)RT.var("clojure.reflect", "internal-name->class-symbol");
/*     */     const__37 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { ((clojure.lang.IObj)clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "d"))).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "pre"), clojure.lang.Tuple.create(((clojure.lang.IObj)clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Symbol.intern(null, "string?"), clojure.lang.Symbol.intern(null, "d") }))).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "line"), Integer.valueOf(68), RT.keyword(null, "column"), Integer.valueOf(10) }))) })) })), RT.keyword(null, "doc"), "Convert a Java internal name to a Clojure class symbol. Internal\n   names uses slashes instead of dots, e.g. java/lang/String. See\n   Section 4.2 of the JVM spec, 2nd ed.:\n\n   http://java.sun.com/docs/books/jvms/second_edition/html/ClassFile.doc.html#14757", RT.keyword(null, "line"), Integer.valueOf(61), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/reflect/java.clj" });
/*     */     const__38 = (clojure.lang.Var)RT.var("clojure.reflect", "flag-descriptors");
/*     */     const__40 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "doc"), "The Java access bitflags, along with their friendly names and\nthe kinds of objects to which they can apply.", RT.keyword(null, "line"), Integer.valueOf(71), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/reflect/java.clj" });
/*     */     const__41 = (clojure.lang.Var)RT.var("clojure.core", "vec");
/*     */     const__42 = (clojure.lang.Var)RT.var("clojure.core", "map");
/*     */     const__96 = (clojure.lang.AFn)RT.vector(new Object[] { clojure.lang.Tuple.create(RT.keyword(null, "public"), Long.valueOf(1L), RT.keyword(null, "class"), RT.keyword(null, "field"), RT.keyword(null, "method")), clojure.lang.Tuple.create(RT.keyword(null, "private"), Long.valueOf(2L), RT.keyword(null, "class"), RT.keyword(null, "field"), RT.keyword(null, "method")), clojure.lang.Tuple.create(RT.keyword(null, "protected"), Long.valueOf(4L), RT.keyword(null, "class"), RT.keyword(null, "field"), RT.keyword(null, "method")), clojure.lang.Tuple.create(RT.keyword(null, "static"), Long.valueOf(8L), RT.keyword(null, "field"), RT.keyword(null, "method")), clojure.lang.Tuple.create(RT.keyword(null, "final"), Long.valueOf(16L), RT.keyword(null, "class"), RT.keyword(null, "field"), RT.keyword(null, "method")), clojure.lang.Tuple.create(RT.keyword(null, "synchronized"), Long.valueOf(32L), RT.keyword(null, "method")), clojure.lang.Tuple.create(RT.keyword(null, "volatile"), Long.valueOf(64L), RT.keyword(null, "field")), clojure.lang.Tuple.create(RT.keyword(null, "bridge"), Long.valueOf(64L), RT.keyword(null, "method")), clojure.lang.Tuple.create(RT.keyword(null, "varargs"), Long.valueOf(128L), RT.keyword(null, "method")), clojure.lang.Tuple.create(RT.keyword(null, "transient"), Long.valueOf(128L), RT.keyword(null, "field")), clojure.lang.Tuple.create(RT.keyword(null, "native"), Long.valueOf(256L), RT.keyword(null, "method")), clojure.lang.Tuple.create(RT.keyword(null, "interface"), Long.valueOf(512L), RT.keyword(null, "class")), clojure.lang.Tuple.create(RT.keyword(null, "abstract"), Long.valueOf(1024L), RT.keyword(null, "class"), RT.keyword(null, "method")), clojure.lang.Tuple.create(RT.keyword(null, "strict"), Long.valueOf(2048L), RT.keyword(null, "method")), clojure.lang.Tuple.create(RT.keyword(null, "synthetic"), Long.valueOf(4096L), RT.keyword(null, "class"), RT.keyword(null, "field"), RT.keyword(null, "method")), clojure.lang.Tuple.create(RT.keyword(null, "annotation"), Long.valueOf(8192L), RT.keyword(null, "class")), clojure.lang.Tuple.create(RT.keyword(null, "enum"), Long.valueOf(16384L), RT.keyword(null, "class"), RT.keyword(null, "field"), RT.keyword(null, "inner")) });
/*     */     const__97 = (clojure.lang.Var)RT.var("clojure.reflect", "parse-flags");
/*     */   }
/*     */   
/*     */   public static void __init1()
/*     */   {
/*     */     const__100 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "flags"), clojure.lang.Symbol.intern(null, "context")) })), RT.keyword(null, "doc"), "Convert reflection bitflags into a set of keywords.", RT.keyword(null, "line"), Integer.valueOf(97), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/reflect/java.clj" });
/*     */     const__101 = (clojure.lang.Var)RT.var("clojure.reflect", "constructor->map");
/*     */     const__104 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "constructor")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "tag"), clojure.lang.Symbol.intern(null, "java.lang.reflect.Constructor") }))) })), RT.keyword(null, "line"), Integer.valueOf(112), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/reflect/java.clj" });
/*     */     const__105 = (clojure.lang.Var)RT.var("clojure.reflect", "declared-constructors");
/*     */     const__108 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "cls")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "tag"), clojure.lang.Symbol.intern(null, "Class") }))) })), RT.keyword(null, "doc"), "Return a set of the declared constructors of class as a Clojure map.", RT.keyword(null, "line"), Integer.valueOf(121), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/reflect/java.clj" });
/*     */     const__109 = (clojure.lang.Var)RT.var("clojure.reflect", "method->map");
/*     */     const__112 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "method")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "tag"), clojure.lang.Symbol.intern(null, "java.lang.reflect.Method") }))) })), RT.keyword(null, "line"), Integer.valueOf(131), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/reflect/java.clj" });
/*     */     const__113 = (clojure.lang.Var)RT.var("clojure.reflect", "declared-methods");
/*     */     const__116 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "cls")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "tag"), clojure.lang.Symbol.intern(null, "Class") }))) })), RT.keyword(null, "doc"), "Return a set of the declared constructors of class as a Clojure map.", RT.keyword(null, "line"), Integer.valueOf(141), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/reflect/java.clj" });
/*     */     const__117 = (clojure.lang.Var)RT.var("clojure.reflect", "field->map");
/*     */     const__120 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "field")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "tag"), clojure.lang.Symbol.intern(null, "java.lang.reflect.Field") }))) })), RT.keyword(null, "line"), Integer.valueOf(151), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/reflect/java.clj" });
/*     */     const__121 = (clojure.lang.Var)RT.var("clojure.reflect", "declared-fields");
/*     */     const__124 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "cls")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "tag"), clojure.lang.Symbol.intern(null, "Class") }))) })), RT.keyword(null, "doc"), "Return a set of the declared fields of class as a Clojure map.", RT.keyword(null, "line"), Integer.valueOf(159), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/reflect/java.clj" });
/*     */     const__125 = (clojure.lang.Var)RT.var("clojure.reflect", "default-reflector");
/*     */     const__127 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "line"), Integer.valueOf(176), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/reflect/java.clj" });
/*     */     const__128 = (clojure.lang.Var)RT.var("clojure.reflect", "parse-method-descriptor");
/*     */     const__131 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "private"), Boolean.TRUE, RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "md")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "tag"), clojure.lang.Symbol.intern(null, "String") }))) })), RT.keyword(null, "line"), Integer.valueOf(179), RT.keyword(null, "column"), Integer.valueOf(1), RT.keyword(null, "file"), "clojure/reflect/java.clj" });
/*     */     const__132 = RT.classForName("clojure.reflect.ClassResolver");
/*     */     const__133 = (clojure.lang.Var)RT.var("clojure.core", "alter-meta!");
/*     */     const__134 = (clojure.lang.Var)RT.var("clojure.reflect", "ClassResolver");
/*     */     const__135 = (clojure.lang.Var)RT.var("clojure.core", "assoc");
/*     */     const__136 = (clojure.lang.Var)RT.var("clojure.core", "assert-same-protocol");
/*     */     const__137 = (clojure.lang.ISeq)clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { ((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "resolve-class")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "doc"), "Given a class name, return that typeref's class bytes as an InputStream.", RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "this"), clojure.lang.Symbol.intern(null, "name")) })) })) }));
/*     */     const__138 = (clojure.lang.Var)RT.var("clojure.core", "alter-var-root");
/*     */     const__139 = (clojure.lang.Var)RT.var("clojure.core", "merge");
/*     */     const__143 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "on"), clojure.lang.Symbol.intern(null, "clojure.reflect.ClassResolver"), RT.keyword(null, "on-interface"), RT.classForName("clojure.reflect.ClassResolver") });
/*     */     const__144 = (clojure.lang.Keyword)RT.keyword(null, "sigs");
/*     */     const__145 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "resolve-class"), RT.map(new Object[] { RT.keyword(null, "tag"), clojure.lang.Symbol.intern(null, "InputStream"), RT.keyword(null, "name"), ((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "resolve-class")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "doc"), "Given a class name, return that typeref's class bytes as an InputStream.", RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "this"), clojure.lang.Symbol.intern(null, "name")) })) })), RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "this"), clojure.lang.Symbol.intern(null, "name")) })), RT.keyword(null, "doc"), "Given a class name, return that typeref's class bytes as an InputStream." }) });
/*     */     const__146 = (clojure.lang.Keyword)RT.keyword(null, "var");
/*     */     const__147 = (clojure.lang.Keyword)RT.keyword(null, "method-map");
/*     */     const__148 = (clojure.lang.Keyword)RT.keyword(null, "resolve-class");
/*     */     const__149 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "resolve-class"), RT.keyword(null, "resolve-class") });
/*     */     const__150 = (clojure.lang.Keyword)RT.keyword(null, "method-builders");
/*     */     const__151 = (clojure.lang.Var)RT.var("clojure.core", "intern");
/*     */     const__152 = (clojure.lang.Var)RT.var("clojure.core", "*ns*");
/*     */     const__153 = (clojure.lang.Var)RT.var("clojure.core", "with-meta");
/*     */     const__154 = (clojure.lang.AFn)((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "resolve-class")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "doc"), "Given a class name, return that typeref's class bytes as an InputStream.", RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "this"), clojure.lang.Symbol.intern(null, "name")) })) }));
/*     */     const__155 = (clojure.lang.AFn)RT.map(new Object[] { RT.keyword(null, "tag"), clojure.lang.Symbol.intern(null, "InputStream"), RT.keyword(null, "name"), ((clojure.lang.IObj)clojure.lang.Symbol.intern(null, "resolve-class")).withMeta((clojure.lang.IPersistentMap)RT.map(new Object[] { RT.keyword(null, "doc"), "Given a class name, return that typeref's class bytes as an InputStream.", RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "this"), clojure.lang.Symbol.intern(null, "name")) })) })), RT.keyword(null, "arglists"), clojure.lang.PersistentList.create(java.util.Arrays.asList(new Object[] { clojure.lang.Tuple.create(clojure.lang.Symbol.intern(null, "this"), clojure.lang.Symbol.intern(null, "name")) })), RT.keyword(null, "doc"), "Given a class name, return that typeref's class bytes as an InputStream." });
/*     */     const__156 = (clojure.lang.Keyword)RT.keyword(null, "protocol");
/*     */     const__157 = (clojure.lang.Var)RT.var("clojure.core", "-reset-methods");
/*     */     const__158 = (clojure.lang.AFn)clojure.lang.Symbol.intern(null, "ClassResolver");
/*     */     const__159 = RT.classForName("clojure.lang.Fn");
/*     */     const__160 = RT.classForName("java.lang.ClassLoader");
/*     */   }
/*     */   
/*     */   static
/*     */   {
/*     */     __init0();
/*     */     __init1();
/*     */     clojure.lang.Compiler.pushNSandLoader(RT.classForName("clojure.reflect.java__init").getClassLoader());
/*     */     try
/*     */     {
/*     */       load();
/*     */       clojure.lang.Var.popThreadBindings();
/*     */     }
/*     */     finally
/*     */     {
/*     */       clojure.lang.Var.popThreadBindings();
/*     */       throw finally;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\reflect\java__init.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */