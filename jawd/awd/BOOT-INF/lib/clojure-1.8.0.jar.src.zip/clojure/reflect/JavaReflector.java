/*     */ package clojure.reflect;
/*     */ 
/*     */ import clojure.lang.IPersistentVector;
/*     */ import clojure.lang.IType;
/*     */ import clojure.lang.Keyword;
/*     */ import clojure.lang.RT;
/*     */ import clojure.lang.Symbol;
/*     */ import clojure.lang.Tuple;
/*     */ import clojure.lang.Var;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class JavaReflector
/*     */   implements Reflector, IType
/*     */ {
/* 166 */   public JavaReflector(Object paramObject) { this.classloader = paramObject; } public static final Keyword const__10 = (Keyword)RT.keyword(null, "members"); public static final Keyword const__9 = (Keyword)RT.keyword(null, "class"); public static final Keyword const__7 = (Keyword)RT.keyword(null, "flags"); public static final Var const__5 = (Var)RT.var("clojure.reflect", "typesym"); public static final Keyword const__1 = (Keyword)RT.keyword(null, "bases"); public static final Var const__0 = (Var)RT.var("clojure.reflect", "typename");
/*     */   private static Class __cached_class__0;
/*     */   public final Object classloader;
/*     */   
/*     */   public static IPersistentVector getBasis()
/*     */   {
/*     */     return Tuple.create(Symbol.intern(null, "classloader"));
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public Object do_reflect(Object typeref)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_1
/*     */     //   1: aconst_null
/*     */     //   2: astore_1
/*     */     //   3: dup
/*     */     //   4: invokestatic 43	clojure/lang/Util:classOf	(Ljava/lang/Object;)Ljava/lang/Class;
/*     */     //   7: getstatic 45	clojure/reflect/JavaReflector:__cached_class__0	Ljava/lang/Class;
/*     */     //   10: if_acmpeq +17 -> 27
/*     */     //   13: dup
/*     */     //   14: instanceof 47
/*     */     //   17: ifne +25 -> 42
/*     */     //   20: dup
/*     */     //   21: invokestatic 43	clojure/lang/Util:classOf	(Ljava/lang/Object;)Ljava/lang/Class;
/*     */     //   24: putstatic 45	clojure/reflect/JavaReflector:__cached_class__0	Ljava/lang/Class;
/*     */     //   27: getstatic 51	clojure/reflect/JavaReflector:const__0	Lclojure/lang/Var;
/*     */     //   30: invokevirtual 57	clojure/lang/Var:getRawRoot	()Ljava/lang/Object;
/*     */     //   33: swap
/*     */     //   34: invokeinterface 62 2 0
/*     */     //   39: goto +8 -> 47
/*     */     //   42: invokeinterface 65 1 0
/*     */     //   47: checkcast 67	java/lang/String
/*     */     //   50: getstatic 73	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*     */     //   53: checkcast 69	java/lang/Boolean
/*     */     //   56: invokevirtual 77	java/lang/Boolean:booleanValue	()Z
/*     */     //   59: aload_0
/*     */     //   60: getfield 20	clojure/reflect/JavaReflector:classloader	Ljava/lang/Object;
/*     */     //   63: checkcast 79	java/lang/ClassLoader
/*     */     //   66: invokestatic 85	clojure/lang/RT:classForName	(Ljava/lang/String;ZLjava/lang/ClassLoader;)Ljava/lang/Class;
/*     */     //   69: astore_2
/*     */     //   70: bipush 6
/*     */     //   72: anewarray 4	java/lang/Object
/*     */     //   75: dup
/*     */     //   76: iconst_0
/*     */     //   77: getstatic 89	clojure/reflect/JavaReflector:const__1	Lclojure/lang/Keyword;
/*     */     //   80: aastore
/*     */     //   81: dup
/*     */     //   82: iconst_1
/*     */     //   83: getstatic 92	clojure/reflect/JavaReflector:const__5	Lclojure/lang/Var;
/*     */     //   86: invokevirtual 57	clojure/lang/Var:getRawRoot	()Ljava/lang/Object;
/*     */     //   89: aload_2
/*     */     //   90: invokestatic 97	clojure/core$bases:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   93: invokestatic 102	clojure/core$map:invokeStatic	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   96: invokestatic 105	clojure/core$set:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   99: invokestatic 108	clojure/core$not_empty:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   102: aastore
/*     */     //   103: dup
/*     */     //   104: iconst_2
/*     */     //   105: getstatic 111	clojure/reflect/JavaReflector:const__7	Lclojure/lang/Keyword;
/*     */     //   108: aastore
/*     */     //   109: dup
/*     */     //   110: iconst_3
/*     */     //   111: aload_2
/*     */     //   112: checkcast 113	java/lang/Class
/*     */     //   115: invokevirtual 117	java/lang/Class:getModifiers	()I
/*     */     //   118: invokestatic 123	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
/*     */     //   121: getstatic 126	clojure/reflect/JavaReflector:const__9	Lclojure/lang/Keyword;
/*     */     //   124: invokestatic 129	clojure/reflect$parse_flags:invokeStatic	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   127: aastore
/*     */     //   128: dup
/*     */     //   129: iconst_4
/*     */     //   130: getstatic 132	clojure/reflect/JavaReflector:const__10	Lclojure/lang/Keyword;
/*     */     //   133: aastore
/*     */     //   134: dup
/*     */     //   135: iconst_5
/*     */     //   136: aload_2
/*     */     //   137: invokestatic 135	clojure/reflect$declared_fields:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   140: aload_2
/*     */     //   141: invokestatic 138	clojure/reflect$declared_methods:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   144: iconst_1
/*     */     //   145: anewarray 4	java/lang/Object
/*     */     //   148: dup
/*     */     //   149: iconst_0
/*     */     //   150: aload_2
/*     */     //   151: aconst_null
/*     */     //   152: astore_2
/*     */     //   153: invokestatic 141	clojure/reflect$declared_constructors:invokeStatic	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   156: aastore
/*     */     //   157: invokestatic 146	clojure/lang/ArraySeq:create	([Ljava/lang/Object;)Lclojure/lang/ArraySeq;
/*     */     //   160: invokestatic 151	clojure/set$union:invokeStatic	(Ljava/lang/Object;Ljava/lang/Object;Lclojure/lang/ISeq;)Ljava/lang/Object;
/*     */     //   163: aastore
/*     */     //   164: invokestatic 155	clojure/lang/RT:mapUniqueKeys	([Ljava/lang/Object;)Lclojure/lang/IPersistentMap;
/*     */     //   167: areturn
/*     */     // Line number table:
/*     */     //   Java source line #166	-> byte code offset #0
/*     */     //   Java source line #169	-> byte code offset #0
/*     */     //   Java source line #169	-> byte code offset #34
/*     */     //   Java source line #169	-> byte code offset #66
/*     */     //   Java source line #171	-> byte code offset #115
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	167	0	this	JavaReflector
/*     */     //   0	167	1	typeref	Object
/*     */     //   70	97	2	cls	Object
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\clojure-1.8.0.jar!\clojure\reflect\JavaReflector.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */