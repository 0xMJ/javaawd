package org.aopalliance.intercept;

import javax.annotation.Nonnull;

public abstract interface Invocation
  extends Joinpoint
{
  @Nonnull
  public abstract Object[] getArguments();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-aop-5.3.12.jar!\org\aopalliance\intercept\Invocation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */