package org.aopalliance.intercept;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

@FunctionalInterface
public abstract interface MethodInterceptor
  extends Interceptor
{
  @Nullable
  public abstract Object invoke(@Nonnull MethodInvocation paramMethodInvocation)
    throws Throwable;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-aop-5.3.12.jar!\org\aopalliance\intercept\MethodInterceptor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */