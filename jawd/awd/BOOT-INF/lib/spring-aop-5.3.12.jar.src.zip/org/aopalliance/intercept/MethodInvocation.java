package org.aopalliance.intercept;

import java.lang.reflect.Method;
import javax.annotation.Nonnull;

public abstract interface MethodInvocation
  extends Invocation
{
  @Nonnull
  public abstract Method getMethod();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-aop-5.3.12.jar!\org\aopalliance\intercept\MethodInvocation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */