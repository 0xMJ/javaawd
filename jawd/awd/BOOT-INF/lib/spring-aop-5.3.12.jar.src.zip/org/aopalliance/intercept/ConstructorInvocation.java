package org.aopalliance.intercept;

import java.lang.reflect.Constructor;
import javax.annotation.Nonnull;

public abstract interface ConstructorInvocation
  extends Invocation
{
  @Nonnull
  public abstract Constructor<?> getConstructor();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-aop-5.3.12.jar!\org\aopalliance\intercept\ConstructorInvocation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */