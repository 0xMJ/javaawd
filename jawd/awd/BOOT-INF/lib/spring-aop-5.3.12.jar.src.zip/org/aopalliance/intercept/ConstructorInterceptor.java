package org.aopalliance.intercept;

import javax.annotation.Nonnull;

public abstract interface ConstructorInterceptor
  extends Interceptor
{
  @Nonnull
  public abstract Object construct(ConstructorInvocation paramConstructorInvocation)
    throws Throwable;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-aop-5.3.12.jar!\org\aopalliance\intercept\ConstructorInterceptor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */