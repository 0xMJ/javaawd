package org.aopalliance.intercept;

import java.lang.reflect.AccessibleObject;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;

public abstract interface Joinpoint
{
  @Nullable
  public abstract Object proceed()
    throws Throwable;
  
  @Nullable
  public abstract Object getThis();
  
  @Nonnull
  public abstract AccessibleObject getStaticPart();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-aop-5.3.12.jar!\org\aopalliance\intercept\Joinpoint.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */