/*     */ package org.springframework.aop.framework.autoproxy;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.aopalliance.aop.Advice;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.aop.Advisor;
/*     */ import org.springframework.aop.Pointcut;
/*     */ import org.springframework.aop.TargetSource;
/*     */ import org.springframework.aop.framework.AopInfrastructureBean;
/*     */ import org.springframework.aop.framework.ProxyFactory;
/*     */ import org.springframework.aop.framework.ProxyProcessorSupport;
/*     */ import org.springframework.aop.framework.adapter.AdvisorAdapterRegistry;
/*     */ import org.springframework.aop.framework.adapter.GlobalAdvisorAdapterRegistry;
/*     */ import org.springframework.aop.target.SingletonTargetSource;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.PropertyValues;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.config.SmartInstantiationAwareBeanPostProcessor;
/*     */ import org.springframework.core.SmartClassLoader;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractAutoProxyCreator
/*     */   extends ProxyProcessorSupport
/*     */   implements SmartInstantiationAwareBeanPostProcessor, BeanFactoryAware
/*     */ {
/*     */   @Nullable
/* 103 */   protected static final Object[] DO_NOT_PROXY = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 110 */   protected static final Object[] PROXY_WITHOUT_ADDITIONAL_INTERCEPTORS = new Object[0];
/*     */   
/*     */ 
/*     */ 
/* 114 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/*     */ 
/* 117 */   private AdvisorAdapterRegistry advisorAdapterRegistry = GlobalAdvisorAdapterRegistry.getInstance();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 123 */   private boolean freezeProxy = false;
/*     */   
/*     */ 
/* 126 */   private String[] interceptorNames = new String[0];
/*     */   
/* 128 */   private boolean applyCommonInterceptorsFirst = true;
/*     */   
/*     */   @Nullable
/*     */   private TargetSourceCreator[] customTargetSourceCreators;
/*     */   
/*     */   @Nullable
/*     */   private BeanFactory beanFactory;
/*     */   
/* 136 */   private final Set<String> targetSourcedBeans = Collections.newSetFromMap(new ConcurrentHashMap(16));
/*     */   
/* 138 */   private final Map<Object, Object> earlyProxyReferences = new ConcurrentHashMap(16);
/*     */   
/* 140 */   private final Map<Object, Class<?>> proxyTypes = new ConcurrentHashMap(16);
/*     */   
/* 142 */   private final Map<Object, Boolean> advisedBeans = new ConcurrentHashMap(256);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFrozen(boolean frozen)
/*     */   {
/* 153 */     this.freezeProxy = frozen;
/*     */   }
/*     */   
/*     */   public boolean isFrozen()
/*     */   {
/* 158 */     return this.freezeProxy;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAdvisorAdapterRegistry(AdvisorAdapterRegistry advisorAdapterRegistry)
/*     */   {
/* 167 */     this.advisorAdapterRegistry = advisorAdapterRegistry;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCustomTargetSourceCreators(TargetSourceCreator... targetSourceCreators)
/*     */   {
/* 185 */     this.customTargetSourceCreators = targetSourceCreators;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setInterceptorNames(String... interceptorNames)
/*     */   {
/* 196 */     this.interceptorNames = interceptorNames;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setApplyCommonInterceptorsFirst(boolean applyCommonInterceptorsFirst)
/*     */   {
/* 204 */     this.applyCommonInterceptorsFirst = applyCommonInterceptorsFirst;
/*     */   }
/*     */   
/*     */   public void setBeanFactory(BeanFactory beanFactory)
/*     */   {
/* 209 */     this.beanFactory = beanFactory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected BeanFactory getBeanFactory()
/*     */   {
/* 218 */     return this.beanFactory;
/*     */   }
/*     */   
/*     */ 
/*     */   @Nullable
/*     */   public Class<?> predictBeanType(Class<?> beanClass, String beanName)
/*     */   {
/* 225 */     if (this.proxyTypes.isEmpty()) {
/* 226 */       return null;
/*     */     }
/* 228 */     Object cacheKey = getCacheKey(beanClass, beanName);
/* 229 */     return (Class)this.proxyTypes.get(cacheKey);
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public Constructor<?>[] determineCandidateConstructors(Class<?> beanClass, String beanName)
/*     */   {
/* 235 */     return null;
/*     */   }
/*     */   
/*     */   public Object getEarlyBeanReference(Object bean, String beanName)
/*     */   {
/* 240 */     Object cacheKey = getCacheKey(bean.getClass(), beanName);
/* 241 */     this.earlyProxyReferences.put(cacheKey, bean);
/* 242 */     return wrapIfNecessary(bean, beanName, cacheKey);
/*     */   }
/*     */   
/*     */   public Object postProcessBeforeInstantiation(Class<?> beanClass, String beanName)
/*     */   {
/* 247 */     Object cacheKey = getCacheKey(beanClass, beanName);
/*     */     
/* 249 */     if ((!StringUtils.hasLength(beanName)) || (!this.targetSourcedBeans.contains(beanName))) {
/* 250 */       if (this.advisedBeans.containsKey(cacheKey)) {
/* 251 */         return null;
/*     */       }
/* 253 */       if ((isInfrastructureClass(beanClass)) || (shouldSkip(beanClass, beanName))) {
/* 254 */         this.advisedBeans.put(cacheKey, Boolean.FALSE);
/* 255 */         return null;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 262 */     TargetSource targetSource = getCustomTargetSource(beanClass, beanName);
/* 263 */     if (targetSource != null) {
/* 264 */       if (StringUtils.hasLength(beanName)) {
/* 265 */         this.targetSourcedBeans.add(beanName);
/*     */       }
/* 267 */       Object[] specificInterceptors = getAdvicesAndAdvisorsForBean(beanClass, beanName, targetSource);
/* 268 */       Object proxy = createProxy(beanClass, beanName, specificInterceptors, targetSource);
/* 269 */       this.proxyTypes.put(cacheKey, proxy.getClass());
/* 270 */       return proxy;
/*     */     }
/*     */     
/* 273 */     return null;
/*     */   }
/*     */   
/*     */   public PropertyValues postProcessProperties(PropertyValues pvs, Object bean, String beanName)
/*     */   {
/* 278 */     return pvs;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object postProcessAfterInitialization(@Nullable Object bean, String beanName)
/*     */   {
/* 288 */     if (bean != null) {
/* 289 */       Object cacheKey = getCacheKey(bean.getClass(), beanName);
/* 290 */       if (this.earlyProxyReferences.remove(cacheKey) != bean) {
/* 291 */         return wrapIfNecessary(bean, beanName, cacheKey);
/*     */       }
/*     */     }
/* 294 */     return bean;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Object getCacheKey(Class<?> beanClass, @Nullable String beanName)
/*     */   {
/* 310 */     if (StringUtils.hasLength(beanName)) {
/* 311 */       return FactoryBean.class.isAssignableFrom(beanClass) ? "&" + beanName : beanName;
/*     */     }
/*     */     
/*     */ 
/* 315 */     return beanClass;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Object wrapIfNecessary(Object bean, String beanName, Object cacheKey)
/*     */   {
/* 327 */     if ((StringUtils.hasLength(beanName)) && (this.targetSourcedBeans.contains(beanName))) {
/* 328 */       return bean;
/*     */     }
/* 330 */     if (Boolean.FALSE.equals(this.advisedBeans.get(cacheKey))) {
/* 331 */       return bean;
/*     */     }
/* 333 */     if ((isInfrastructureClass(bean.getClass())) || (shouldSkip(bean.getClass(), beanName))) {
/* 334 */       this.advisedBeans.put(cacheKey, Boolean.FALSE);
/* 335 */       return bean;
/*     */     }
/*     */     
/*     */ 
/* 339 */     Object[] specificInterceptors = getAdvicesAndAdvisorsForBean(bean.getClass(), beanName, null);
/* 340 */     if (specificInterceptors != DO_NOT_PROXY) {
/* 341 */       this.advisedBeans.put(cacheKey, Boolean.TRUE);
/* 342 */       Object proxy = createProxy(bean
/* 343 */         .getClass(), beanName, specificInterceptors, new SingletonTargetSource(bean));
/* 344 */       this.proxyTypes.put(cacheKey, proxy.getClass());
/* 345 */       return proxy;
/*     */     }
/*     */     
/* 348 */     this.advisedBeans.put(cacheKey, Boolean.FALSE);
/* 349 */     return bean;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isInfrastructureClass(Class<?> beanClass)
/*     */   {
/* 368 */     boolean retVal = (Advice.class.isAssignableFrom(beanClass)) || (Pointcut.class.isAssignableFrom(beanClass)) || (Advisor.class.isAssignableFrom(beanClass)) || (AopInfrastructureBean.class.isAssignableFrom(beanClass));
/* 369 */     if ((retVal) && (this.logger.isTraceEnabled())) {
/* 370 */       this.logger.trace("Did not attempt to auto-proxy infrastructure class [" + beanClass.getName() + "]");
/*     */     }
/* 372 */     return retVal;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean shouldSkip(Class<?> beanClass, String beanName)
/*     */   {
/* 388 */     return AutoProxyUtils.isOriginalInstance(beanName, beanClass);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected TargetSource getCustomTargetSource(Class<?> beanClass, String beanName)
/*     */   {
/* 404 */     if ((this.customTargetSourceCreators != null) && (this.beanFactory != null) && 
/* 405 */       (this.beanFactory.containsBean(beanName))) {
/* 406 */       for (TargetSourceCreator tsc : this.customTargetSourceCreators) {
/* 407 */         TargetSource ts = tsc.getTargetSource(beanClass, beanName);
/* 408 */         if (ts != null)
/*     */         {
/* 410 */           if (this.logger.isTraceEnabled()) {
/* 411 */             this.logger.trace("TargetSourceCreator [" + tsc + "] found custom TargetSource for bean with name '" + beanName + "'");
/*     */           }
/*     */           
/* 414 */           return ts;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 420 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Object createProxy(Class<?> beanClass, @Nullable String beanName, @Nullable Object[] specificInterceptors, TargetSource targetSource)
/*     */   {
/* 437 */     if ((this.beanFactory instanceof ConfigurableListableBeanFactory)) {
/* 438 */       AutoProxyUtils.exposeTargetClass((ConfigurableListableBeanFactory)this.beanFactory, beanName, beanClass);
/*     */     }
/*     */     
/* 441 */     ProxyFactory proxyFactory = new ProxyFactory();
/* 442 */     proxyFactory.copyFrom(this);
/*     */     
/* 444 */     if (proxyFactory.isProxyTargetClass())
/*     */     {
/* 446 */       if (Proxy.isProxyClass(beanClass))
/*     */       {
/* 448 */         for (Class<?> ifc : beanClass.getInterfaces()) {
/* 449 */           proxyFactory.addInterface(ifc);
/*     */         }
/*     */         
/*     */       }
/*     */       
/*     */     }
/* 455 */     else if (shouldProxyTargetClass(beanClass, beanName)) {
/* 456 */       proxyFactory.setProxyTargetClass(true);
/*     */     }
/*     */     else {
/* 459 */       evaluateProxyInterfaces(beanClass, proxyFactory);
/*     */     }
/*     */     
/*     */ 
/* 463 */     Advisor[] advisors = buildAdvisors(beanName, specificInterceptors);
/* 464 */     proxyFactory.addAdvisors(advisors);
/* 465 */     proxyFactory.setTargetSource(targetSource);
/* 466 */     customizeProxyFactory(proxyFactory);
/*     */     
/* 468 */     proxyFactory.setFrozen(this.freezeProxy);
/* 469 */     if (advisorsPreFiltered()) {
/* 470 */       proxyFactory.setPreFiltered(true);
/*     */     }
/*     */     
/*     */ 
/* 474 */     ClassLoader classLoader = getProxyClassLoader();
/* 475 */     if (((classLoader instanceof SmartClassLoader)) && (classLoader != beanClass.getClassLoader())) {
/* 476 */       classLoader = ((SmartClassLoader)classLoader).getOriginalClassLoader();
/*     */     }
/* 478 */     return proxyFactory.getProxy(classLoader);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean shouldProxyTargetClass(Class<?> beanClass, @Nullable String beanName)
/*     */   {
/* 491 */     return ((this.beanFactory instanceof ConfigurableListableBeanFactory)) && 
/* 492 */       (AutoProxyUtils.shouldProxyTargetClass((ConfigurableListableBeanFactory)this.beanFactory, beanName));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean advisorsPreFiltered()
/*     */   {
/* 506 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Advisor[] buildAdvisors(@Nullable String beanName, @Nullable Object[] specificInterceptors)
/*     */   {
/* 519 */     Advisor[] commonInterceptors = resolveInterceptorNames();
/*     */     
/* 521 */     List<Object> allInterceptors = new ArrayList();
/* 522 */     if (specificInterceptors != null) {
/* 523 */       if (specificInterceptors.length > 0)
/*     */       {
/* 525 */         allInterceptors.addAll(Arrays.asList(specificInterceptors));
/*     */       }
/* 527 */       if (commonInterceptors.length > 0) {
/* 528 */         if (this.applyCommonInterceptorsFirst) {
/* 529 */           allInterceptors.addAll(0, Arrays.asList(commonInterceptors));
/*     */         }
/*     */         else {
/* 532 */           allInterceptors.addAll(Arrays.asList(commonInterceptors));
/*     */         }
/*     */       }
/*     */     }
/* 536 */     if (this.logger.isTraceEnabled()) {
/* 537 */       int nrOfCommonInterceptors = commonInterceptors.length;
/* 538 */       int nrOfSpecificInterceptors = specificInterceptors != null ? specificInterceptors.length : 0;
/* 539 */       this.logger.trace("Creating implicit proxy for bean '" + beanName + "' with " + nrOfCommonInterceptors + " common interceptors and " + nrOfSpecificInterceptors + " specific interceptors");
/*     */     }
/*     */     
/*     */ 
/* 543 */     Advisor[] advisors = new Advisor[allInterceptors.size()];
/* 544 */     for (int i = 0; i < allInterceptors.size(); i++) {
/* 545 */       advisors[i] = this.advisorAdapterRegistry.wrap(allInterceptors.get(i));
/*     */     }
/* 547 */     return advisors;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private Advisor[] resolveInterceptorNames()
/*     */   {
/* 555 */     BeanFactory bf = this.beanFactory;
/* 556 */     ConfigurableBeanFactory cbf = (bf instanceof ConfigurableBeanFactory) ? (ConfigurableBeanFactory)bf : null;
/* 557 */     List<Advisor> advisors = new ArrayList();
/* 558 */     for (String beanName : this.interceptorNames) {
/* 559 */       if ((cbf == null) || (!cbf.isCurrentlyInCreation(beanName))) {
/* 560 */         Assert.state(bf != null, "BeanFactory required for resolving interceptor names");
/* 561 */         Object next = bf.getBean(beanName);
/* 562 */         advisors.add(this.advisorAdapterRegistry.wrap(next));
/*     */       }
/*     */     }
/* 565 */     return (Advisor[])advisors.toArray(new Advisor[0]);
/*     */   }
/*     */   
/*     */   protected void customizeProxyFactory(ProxyFactory proxyFactory) {}
/*     */   
/*     */   @Nullable
/*     */   protected abstract Object[] getAdvicesAndAdvisorsForBean(Class<?> paramClass, String paramString, @Nullable TargetSource paramTargetSource)
/*     */     throws BeansException;
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-aop-5.3.12.jar!\org\springframework\aop\framework\autoproxy\AbstractAutoProxyCreator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */