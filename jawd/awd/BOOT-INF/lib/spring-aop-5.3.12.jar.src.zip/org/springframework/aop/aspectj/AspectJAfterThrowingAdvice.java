/*    */ package org.springframework.aop.aspectj;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.lang.reflect.Method;
/*    */ import org.aopalliance.intercept.MethodInterceptor;
/*    */ import org.aopalliance.intercept.MethodInvocation;
/*    */ import org.springframework.aop.AfterAdvice;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AspectJAfterThrowingAdvice
/*    */   extends AbstractAspectJAdvice
/*    */   implements MethodInterceptor, AfterAdvice, Serializable
/*    */ {
/*    */   public AspectJAfterThrowingAdvice(Method aspectJBeforeAdviceMethod, AspectJExpressionPointcut pointcut, AspectInstanceFactory aif)
/*    */   {
/* 41 */     super(aspectJBeforeAdviceMethod, pointcut, aif);
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean isBeforeAdvice()
/*    */   {
/* 47 */     return false;
/*    */   }
/*    */   
/*    */   public boolean isAfterAdvice()
/*    */   {
/* 52 */     return true;
/*    */   }
/*    */   
/*    */   public void setThrowingName(String name)
/*    */   {
/* 57 */     setThrowingNameNoCheck(name);
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   public Object invoke(MethodInvocation mi) throws Throwable
/*    */   {
/*    */     try {
/* 64 */       return mi.proceed();
/*    */     }
/*    */     catch (Throwable ex) {
/* 67 */       if (shouldInvokeOnThrowing(ex)) {
/* 68 */         invokeAdviceMethod(getJoinPointMatch(), null, ex);
/*    */       }
/* 70 */       throw ex;
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   private boolean shouldInvokeOnThrowing(Throwable ex)
/*    */   {
/* 79 */     return getDiscoveredThrowingType().isAssignableFrom(ex.getClass());
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-aop-5.3.12.jar!\org\springframework\aop\aspectj\AspectJAfterThrowingAdvice.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */