package org.springframework.aop;

import org.aopalliance.intercept.MethodInvocation;
import org.springframework.lang.Nullable;

public abstract interface ProxyMethodInvocation
  extends MethodInvocation
{
  public abstract Object getProxy();
  
  public abstract MethodInvocation invocableClone();
  
  public abstract MethodInvocation invocableClone(Object... paramVarArgs);
  
  public abstract void setArguments(Object... paramVarArgs);
  
  public abstract void setUserAttribute(String paramString, @Nullable Object paramObject);
  
  @Nullable
  public abstract Object getUserAttribute(String paramString);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-aop-5.3.12.jar!\org\springframework\aop\ProxyMethodInvocation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */