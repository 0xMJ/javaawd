/*      */ package org.springframework.aop.framework;
/*      */ 
/*      */ import java.io.Serializable;
/*      */ import java.lang.reflect.Method;
/*      */ import java.lang.reflect.Modifier;
/*      */ import java.lang.reflect.UndeclaredThrowableException;
/*      */ import java.util.Collections;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.WeakHashMap;
/*      */ import org.aopalliance.aop.Advice;
/*      */ import org.aopalliance.intercept.MethodInvocation;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ import org.springframework.aop.Advisor;
/*      */ import org.springframework.aop.AopInvocationException;
/*      */ import org.springframework.aop.PointcutAdvisor;
/*      */ import org.springframework.aop.RawTargetAccess;
/*      */ import org.springframework.aop.TargetSource;
/*      */ import org.springframework.aop.support.AopUtils;
/*      */ import org.springframework.cglib.core.ClassLoaderAwareGeneratorStrategy;
/*      */ import org.springframework.cglib.core.CodeGenerationException;
/*      */ import org.springframework.cglib.core.SpringNamingPolicy;
/*      */ import org.springframework.cglib.proxy.Callback;
/*      */ import org.springframework.cglib.proxy.CallbackFilter;
/*      */ import org.springframework.cglib.proxy.Dispatcher;
/*      */ import org.springframework.cglib.proxy.Enhancer;
/*      */ import org.springframework.cglib.proxy.Factory;
/*      */ import org.springframework.cglib.proxy.MethodInterceptor;
/*      */ import org.springframework.cglib.proxy.MethodProxy;
/*      */ import org.springframework.cglib.proxy.NoOp;
/*      */ import org.springframework.core.KotlinDetector;
/*      */ import org.springframework.core.SmartClassLoader;
/*      */ import org.springframework.lang.Nullable;
/*      */ import org.springframework.util.Assert;
/*      */ import org.springframework.util.ClassUtils;
/*      */ import org.springframework.util.CollectionUtils;
/*      */ import org.springframework.util.ObjectUtils;
/*      */ import org.springframework.util.ReflectionUtils;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class CglibAopProxy
/*      */   implements AopProxy, Serializable
/*      */ {
/*      */   private static final int AOP_PROXY = 0;
/*      */   private static final int INVOKE_TARGET = 1;
/*      */   private static final int NO_OVERRIDE = 2;
/*      */   private static final int DISPATCH_TARGET = 3;
/*      */   private static final int DISPATCH_ADVISED = 4;
/*      */   private static final int INVOKE_EQUALS = 5;
/*      */   private static final int INVOKE_HASHCODE = 6;
/*   98 */   protected static final Log logger = LogFactory.getLog(CglibAopProxy.class);
/*      */   
/*      */ 
/*  101 */   private static final Map<Class<?>, Boolean> validatedClasses = new WeakHashMap();
/*      */   
/*      */ 
/*      */   protected final AdvisedSupport advised;
/*      */   
/*      */ 
/*      */   @Nullable
/*      */   protected Object[] constructorArgs;
/*      */   
/*      */ 
/*      */   @Nullable
/*      */   protected Class<?>[] constructorArgTypes;
/*      */   
/*      */   private final transient AdvisedDispatcher advisedDispatcher;
/*      */   
/*  116 */   private transient Map<Method, Integer> fixedInterceptorMap = Collections.emptyMap();
/*      */   
/*      */ 
/*      */ 
/*      */   private transient int fixedInterceptorOffset;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public CglibAopProxy(AdvisedSupport config)
/*      */     throws AopConfigException
/*      */   {
/*  128 */     Assert.notNull(config, "AdvisedSupport must not be null");
/*  129 */     if ((config.getAdvisorCount() == 0) && (config.getTargetSource() == AdvisedSupport.EMPTY_TARGET_SOURCE)) {
/*  130 */       throw new AopConfigException("No advisors and no TargetSource specified");
/*      */     }
/*  132 */     this.advised = config;
/*  133 */     this.advisedDispatcher = new AdvisedDispatcher(this.advised);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setConstructorArguments(@Nullable Object[] constructorArgs, @Nullable Class<?>[] constructorArgTypes)
/*      */   {
/*  142 */     if ((constructorArgs == null) || (constructorArgTypes == null)) {
/*  143 */       throw new IllegalArgumentException("Both 'constructorArgs' and 'constructorArgTypes' need to be specified");
/*      */     }
/*  145 */     if (constructorArgs.length != constructorArgTypes.length) {
/*  146 */       throw new IllegalArgumentException("Number of 'constructorArgs' (" + constructorArgs.length + ") must match number of 'constructorArgTypes' (" + constructorArgTypes.length + ")");
/*      */     }
/*      */     
/*  149 */     this.constructorArgs = constructorArgs;
/*  150 */     this.constructorArgTypes = constructorArgTypes;
/*      */   }
/*      */   
/*      */ 
/*      */   public Object getProxy()
/*      */   {
/*  156 */     return getProxy(null);
/*      */   }
/*      */   
/*      */   public Object getProxy(@Nullable ClassLoader classLoader)
/*      */   {
/*  161 */     if (logger.isTraceEnabled()) {
/*  162 */       logger.trace("Creating CGLIB proxy: " + this.advised.getTargetSource());
/*      */     }
/*      */     try
/*      */     {
/*  166 */       Class<?> rootClass = this.advised.getTargetClass();
/*  167 */       Assert.state(rootClass != null, "Target class must be available for creating a CGLIB proxy");
/*      */       
/*  169 */       Class<?> proxySuperClass = rootClass;
/*  170 */       if (rootClass.getName().contains("$$")) {
/*  171 */         proxySuperClass = rootClass.getSuperclass();
/*  172 */         Class<?>[] additionalInterfaces = rootClass.getInterfaces();
/*  173 */         for (Class<?> additionalInterface : additionalInterfaces) {
/*  174 */           this.advised.addInterface(additionalInterface);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*  179 */       validateClassIfNecessary(proxySuperClass, classLoader);
/*      */       
/*      */ 
/*  182 */       Enhancer enhancer = createEnhancer();
/*  183 */       if (classLoader != null) {
/*  184 */         enhancer.setClassLoader(classLoader);
/*  185 */         if (((classLoader instanceof SmartClassLoader)) && 
/*  186 */           (((SmartClassLoader)classLoader).isClassReloadable(proxySuperClass))) {
/*  187 */           enhancer.setUseCache(false);
/*      */         }
/*      */       }
/*  190 */       enhancer.setSuperclass(proxySuperClass);
/*  191 */       enhancer.setInterfaces(AopProxyUtils.completeProxiedInterfaces(this.advised));
/*  192 */       enhancer.setNamingPolicy(SpringNamingPolicy.INSTANCE);
/*  193 */       enhancer.setStrategy(new ClassLoaderAwareGeneratorStrategy(classLoader));
/*      */       
/*  195 */       Callback[] callbacks = getCallbacks(rootClass);
/*  196 */       Object types = new Class[callbacks.length];
/*  197 */       for (int x = 0; x < types.length; x++) {
/*  198 */         types[x] = callbacks[x].getClass();
/*      */       }
/*      */       
/*  201 */       enhancer.setCallbackFilter(new ProxyCallbackFilter(this.advised
/*  202 */         .getConfigurationOnlyCopy(), this.fixedInterceptorMap, this.fixedInterceptorOffset));
/*  203 */       enhancer.setCallbackTypes((Class[])types);
/*      */       
/*      */ 
/*  206 */       return createProxyClassAndInstance(enhancer, callbacks);
/*      */     }
/*      */     catch (CodeGenerationException|IllegalArgumentException ex) {
/*  209 */       throw new AopConfigException("Could not generate CGLIB subclass of " + this.advised.getTargetClass() + ": Common causes of this problem include using a final class or a non-visible class", ex);
/*      */ 
/*      */     }
/*      */     catch (Throwable ex)
/*      */     {
/*      */ 
/*  215 */       throw new AopConfigException("Unexpected AOP exception", ex);
/*      */     }
/*      */   }
/*      */   
/*      */   protected Object createProxyClassAndInstance(Enhancer enhancer, Callback[] callbacks) {
/*  220 */     enhancer.setInterceptDuringConstruction(false);
/*  221 */     enhancer.setCallbacks(callbacks);
/*  222 */     return (this.constructorArgs != null) && (this.constructorArgTypes != null) ? enhancer
/*  223 */       .create(this.constructorArgTypes, this.constructorArgs) : enhancer
/*  224 */       .create();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Enhancer createEnhancer()
/*      */   {
/*  232 */     return new Enhancer();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void validateClassIfNecessary(Class<?> proxySuperClass, @Nullable ClassLoader proxyClassLoader)
/*      */   {
/*  240 */     if ((!this.advised.isOptimize()) && (logger.isInfoEnabled())) {
/*  241 */       synchronized (validatedClasses) {
/*  242 */         if (!validatedClasses.containsKey(proxySuperClass)) {
/*  243 */           doValidateClass(proxySuperClass, proxyClassLoader, 
/*  244 */             ClassUtils.getAllInterfacesForClassAsSet(proxySuperClass));
/*  245 */           validatedClasses.put(proxySuperClass, Boolean.TRUE);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void doValidateClass(Class<?> proxySuperClass, @Nullable ClassLoader proxyClassLoader, Set<Class<?>> ifcs)
/*      */   {
/*  256 */     if (proxySuperClass != Object.class) {
/*  257 */       Method[] methods = proxySuperClass.getDeclaredMethods();
/*  258 */       for (Method method : methods) {
/*  259 */         int mod = method.getModifiers();
/*  260 */         if ((!Modifier.isStatic(mod)) && (!Modifier.isPrivate(mod))) {
/*  261 */           if (Modifier.isFinal(mod)) {
/*  262 */             if ((logger.isInfoEnabled()) && (implementsInterface(method, ifcs))) {
/*  263 */               logger.info("Unable to proxy interface-implementing method [" + method + "] because it is marked as final: Consider using interface-based JDK proxies instead!");
/*      */             }
/*      */             
/*  266 */             if (logger.isDebugEnabled()) {
/*  267 */               logger.debug("Final method [" + method + "] cannot get proxied via CGLIB: Calls to this method will NOT be routed to the target instance and might lead to NPEs against uninitialized fields in the proxy instance.");
/*      */             }
/*      */             
/*      */ 
/*      */           }
/*  272 */           else if ((logger.isDebugEnabled()) && (!Modifier.isPublic(mod)) && (!Modifier.isProtected(mod)) && (proxyClassLoader != null) && 
/*  273 */             (proxySuperClass.getClassLoader() != proxyClassLoader)) {
/*  274 */             logger.debug("Method [" + method + "] is package-visible across different ClassLoaders and cannot get proxied via CGLIB: Declare this method as public or protected if you need to support invocations through the proxy.");
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*  280 */       doValidateClass(proxySuperClass.getSuperclass(), proxyClassLoader, ifcs);
/*      */     }
/*      */   }
/*      */   
/*      */   private Callback[] getCallbacks(Class<?> rootClass) throws Exception
/*      */   {
/*  286 */     boolean exposeProxy = this.advised.isExposeProxy();
/*  287 */     boolean isFrozen = this.advised.isFrozen();
/*  288 */     boolean isStatic = this.advised.getTargetSource().isStatic();
/*      */     
/*      */ 
/*  291 */     Callback aopInterceptor = new DynamicAdvisedInterceptor(this.advised);
/*      */     
/*      */     Callback targetInterceptor;
/*      */     
/*      */     Callback targetInterceptor;
/*  296 */     if (exposeProxy)
/*      */     {
/*      */ 
/*  299 */       targetInterceptor = isStatic ? new StaticUnadvisedExposedInterceptor(this.advised.getTargetSource().getTarget()) : new DynamicUnadvisedExposedInterceptor(this.advised.getTargetSource());
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*  304 */       targetInterceptor = isStatic ? new StaticUnadvisedInterceptor(this.advised.getTargetSource().getTarget()) : new DynamicUnadvisedInterceptor(this.advised.getTargetSource());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  310 */     Callback targetDispatcher = isStatic ? new StaticDispatcher(this.advised.getTargetSource().getTarget()) : new SerializableNoOp();
/*      */     
/*  312 */     Callback[] mainCallbacks = { aopInterceptor, targetInterceptor, new SerializableNoOp(), targetDispatcher, this.advisedDispatcher, new EqualsInterceptor(this.advised), new HashCodeInterceptor(this.advised) };
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     Callback[] callbacks;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  326 */     if ((isStatic) && (isFrozen)) {
/*  327 */       Method[] methods = rootClass.getMethods();
/*  328 */       Callback[] fixedCallbacks = new Callback[methods.length];
/*  329 */       this.fixedInterceptorMap = CollectionUtils.newHashMap(methods.length);
/*      */       
/*      */ 
/*  332 */       for (int x = 0; x < methods.length; x++) {
/*  333 */         Method method = methods[x];
/*  334 */         List<Object> chain = this.advised.getInterceptorsAndDynamicInterceptionAdvice(method, rootClass);
/*  335 */         fixedCallbacks[x] = new FixedChainStaticTargetInterceptor(chain, this.advised
/*  336 */           .getTargetSource().getTarget(), this.advised.getTargetClass());
/*  337 */         this.fixedInterceptorMap.put(method, Integer.valueOf(x));
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  342 */       Callback[] callbacks = new Callback[mainCallbacks.length + fixedCallbacks.length];
/*  343 */       System.arraycopy(mainCallbacks, 0, callbacks, 0, mainCallbacks.length);
/*  344 */       System.arraycopy(fixedCallbacks, 0, callbacks, mainCallbacks.length, fixedCallbacks.length);
/*  345 */       this.fixedInterceptorOffset = mainCallbacks.length;
/*      */     }
/*      */     else {
/*  348 */       callbacks = mainCallbacks;
/*      */     }
/*  350 */     return callbacks;
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean equals(@Nullable Object other)
/*      */   {
/*  356 */     return (this == other) || (((other instanceof CglibAopProxy)) && 
/*  357 */       (AopProxyUtils.equalsInProxy(this.advised, ((CglibAopProxy)other).advised)));
/*      */   }
/*      */   
/*      */   public int hashCode()
/*      */   {
/*  362 */     return CglibAopProxy.class.hashCode() * 13 + this.advised.getTargetSource().hashCode();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private static boolean implementsInterface(Method method, Set<Class<?>> ifcs)
/*      */   {
/*  370 */     for (Class<?> ifc : ifcs) {
/*  371 */       if (ClassUtils.hasMethod(ifc, method)) {
/*  372 */         return true;
/*      */       }
/*      */     }
/*  375 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Nullable
/*      */   private static Object processReturnType(Object proxy, @Nullable Object target, Method method, @Nullable Object returnValue)
/*      */   {
/*  387 */     if ((returnValue != null) && (returnValue == target) && 
/*  388 */       (!RawTargetAccess.class.isAssignableFrom(method.getDeclaringClass())))
/*      */     {
/*      */ 
/*  391 */       returnValue = proxy;
/*      */     }
/*  393 */     Class<?> returnType = method.getReturnType();
/*  394 */     if ((returnValue == null) && (returnType != Void.TYPE) && (returnType.isPrimitive())) {
/*  395 */       throw new AopInvocationException("Null return value from advice does not match primitive return type for: " + method);
/*      */     }
/*      */     
/*  398 */     return returnValue;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static class SerializableNoOp
/*      */     implements NoOp, Serializable
/*      */   {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private static class StaticUnadvisedInterceptor
/*      */     implements MethodInterceptor, Serializable
/*      */   {
/*      */     @Nullable
/*      */     private final Object target;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public StaticUnadvisedInterceptor(@Nullable Object target)
/*      */     {
/*  422 */       this.target = target;
/*      */     }
/*      */     
/*      */     @Nullable
/*      */     public Object intercept(Object proxy, Method method, Object[] args, MethodProxy methodProxy) throws Throwable
/*      */     {
/*  428 */       Object retVal = methodProxy.invoke(this.target, args);
/*  429 */       return CglibAopProxy.processReturnType(proxy, this.target, method, retVal);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static class StaticUnadvisedExposedInterceptor
/*      */     implements MethodInterceptor, Serializable
/*      */   {
/*      */     @Nullable
/*      */     private final Object target;
/*      */     
/*      */ 
/*      */     public StaticUnadvisedExposedInterceptor(@Nullable Object target)
/*      */     {
/*  444 */       this.target = target;
/*      */     }
/*      */     
/*      */     @Nullable
/*      */     public Object intercept(Object proxy, Method method, Object[] args, MethodProxy methodProxy) throws Throwable
/*      */     {
/*  450 */       Object oldProxy = null;
/*      */       try {
/*  452 */         oldProxy = AopContext.setCurrentProxy(proxy);
/*  453 */         Object retVal = methodProxy.invoke(this.target, args);
/*  454 */         return CglibAopProxy.processReturnType(proxy, this.target, method, retVal);
/*      */       }
/*      */       finally {
/*  457 */         AopContext.setCurrentProxy(oldProxy);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static class DynamicUnadvisedInterceptor
/*      */     implements MethodInterceptor, Serializable
/*      */   {
/*      */     private final TargetSource targetSource;
/*      */     
/*      */ 
/*      */ 
/*      */     public DynamicUnadvisedInterceptor(TargetSource targetSource)
/*      */     {
/*  473 */       this.targetSource = targetSource;
/*      */     }
/*      */     
/*      */     @Nullable
/*      */     public Object intercept(Object proxy, Method method, Object[] args, MethodProxy methodProxy) throws Throwable
/*      */     {
/*  479 */       Object target = this.targetSource.getTarget();
/*      */       try {
/*  481 */         Object retVal = methodProxy.invoke(target, args);
/*  482 */         return CglibAopProxy.processReturnType(proxy, target, method, retVal);
/*      */       }
/*      */       finally {
/*  485 */         if (target != null) {
/*  486 */           this.targetSource.releaseTarget(target);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private static class DynamicUnadvisedExposedInterceptor
/*      */     implements MethodInterceptor, Serializable
/*      */   {
/*      */     private final TargetSource targetSource;
/*      */     
/*      */ 
/*      */     public DynamicUnadvisedExposedInterceptor(TargetSource targetSource)
/*      */     {
/*  501 */       this.targetSource = targetSource;
/*      */     }
/*      */     
/*      */     @Nullable
/*      */     public Object intercept(Object proxy, Method method, Object[] args, MethodProxy methodProxy) throws Throwable
/*      */     {
/*  507 */       Object oldProxy = null;
/*  508 */       Object target = this.targetSource.getTarget();
/*      */       try {
/*  510 */         oldProxy = AopContext.setCurrentProxy(proxy);
/*  511 */         Object retVal = methodProxy.invoke(target, args);
/*  512 */         return CglibAopProxy.processReturnType(proxy, target, method, retVal);
/*      */       }
/*      */       finally {
/*  515 */         AopContext.setCurrentProxy(oldProxy);
/*  516 */         if (target != null) {
/*  517 */           this.targetSource.releaseTarget(target);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static class StaticDispatcher
/*      */     implements Dispatcher, Serializable
/*      */   {
/*      */     @Nullable
/*      */     private final Object target;
/*      */     
/*      */ 
/*      */ 
/*      */     public StaticDispatcher(@Nullable Object target)
/*      */     {
/*  535 */       this.target = target;
/*      */     }
/*      */     
/*      */     @Nullable
/*      */     public Object loadObject()
/*      */     {
/*  541 */       return this.target;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private static class AdvisedDispatcher
/*      */     implements Dispatcher, Serializable
/*      */   {
/*      */     private final AdvisedSupport advised;
/*      */     
/*      */ 
/*      */     public AdvisedDispatcher(AdvisedSupport advised)
/*      */     {
/*  554 */       this.advised = advised;
/*      */     }
/*      */     
/*      */     public Object loadObject()
/*      */     {
/*  559 */       return this.advised;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static class EqualsInterceptor
/*      */     implements MethodInterceptor, Serializable
/*      */   {
/*      */     private final AdvisedSupport advised;
/*      */     
/*      */ 
/*      */     public EqualsInterceptor(AdvisedSupport advised)
/*      */     {
/*  573 */       this.advised = advised;
/*      */     }
/*      */     
/*      */     public Object intercept(Object proxy, Method method, Object[] args, MethodProxy methodProxy)
/*      */     {
/*  578 */       Object other = args[0];
/*  579 */       if (proxy == other) {
/*  580 */         return Boolean.valueOf(true);
/*      */       }
/*  582 */       if ((other instanceof Factory)) {
/*  583 */         Callback callback = ((Factory)other).getCallback(5);
/*  584 */         if (!(callback instanceof EqualsInterceptor)) {
/*  585 */           return Boolean.valueOf(false);
/*      */         }
/*  587 */         AdvisedSupport otherAdvised = ((EqualsInterceptor)callback).advised;
/*  588 */         return Boolean.valueOf(AopProxyUtils.equalsInProxy(this.advised, otherAdvised));
/*      */       }
/*      */       
/*  591 */       return Boolean.valueOf(false);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static class HashCodeInterceptor
/*      */     implements MethodInterceptor, Serializable
/*      */   {
/*      */     private final AdvisedSupport advised;
/*      */     
/*      */ 
/*      */ 
/*      */     public HashCodeInterceptor(AdvisedSupport advised)
/*      */     {
/*  606 */       this.advised = advised;
/*      */     }
/*      */     
/*      */     public Object intercept(Object proxy, Method method, Object[] args, MethodProxy methodProxy)
/*      */     {
/*  611 */       return Integer.valueOf(CglibAopProxy.class.hashCode() * 13 + this.advised.getTargetSource().hashCode());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static class FixedChainStaticTargetInterceptor
/*      */     implements MethodInterceptor, Serializable
/*      */   {
/*      */     private final List<Object> adviceChain;
/*      */     
/*      */ 
/*      */     @Nullable
/*      */     private final Object target;
/*      */     
/*      */     @Nullable
/*      */     private final Class<?> targetClass;
/*      */     
/*      */ 
/*      */     public FixedChainStaticTargetInterceptor(List<Object> adviceChain, @Nullable Object target, @Nullable Class<?> targetClass)
/*      */     {
/*  632 */       this.adviceChain = adviceChain;
/*  633 */       this.target = target;
/*  634 */       this.targetClass = targetClass;
/*      */     }
/*      */     
/*      */     @Nullable
/*      */     public Object intercept(Object proxy, Method method, Object[] args, MethodProxy methodProxy) throws Throwable
/*      */     {
/*  640 */       MethodInvocation invocation = new CglibAopProxy.CglibMethodInvocation(proxy, this.target, method, args, this.targetClass, this.adviceChain, methodProxy);
/*      */       
/*      */ 
/*  643 */       Object retVal = invocation.proceed();
/*  644 */       retVal = CglibAopProxy.processReturnType(proxy, this.target, method, retVal);
/*  645 */       return retVal;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static class DynamicAdvisedInterceptor
/*      */     implements MethodInterceptor, Serializable
/*      */   {
/*      */     private final AdvisedSupport advised;
/*      */     
/*      */ 
/*      */     public DynamicAdvisedInterceptor(AdvisedSupport advised)
/*      */     {
/*  659 */       this.advised = advised;
/*      */     }
/*      */     
/*      */     @Nullable
/*      */     public Object intercept(Object proxy, Method method, Object[] args, MethodProxy methodProxy) throws Throwable
/*      */     {
/*  665 */       Object oldProxy = null;
/*  666 */       boolean setProxyContext = false;
/*  667 */       Object target = null;
/*  668 */       TargetSource targetSource = this.advised.getTargetSource();
/*      */       try {
/*  670 */         if (this.advised.exposeProxy)
/*      */         {
/*  672 */           oldProxy = AopContext.setCurrentProxy(proxy);
/*  673 */           setProxyContext = true;
/*      */         }
/*      */         
/*  676 */         target = targetSource.getTarget();
/*  677 */         Class<?> targetClass = target != null ? target.getClass() : null;
/*  678 */         List<Object> chain = this.advised.getInterceptorsAndDynamicInterceptionAdvice(method, targetClass);
/*      */         
/*      */         Object[] argsToUse;
/*      */         Object retVal;
/*  682 */         if ((chain.isEmpty()) && (CglibAopProxy.CglibMethodInvocation.isMethodProxyCompatible(method)))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*  687 */           argsToUse = AopProxyUtils.adaptArgumentsIfNecessary(method, args);
/*      */           try {
/*  689 */             retVal = methodProxy.invoke(target, argsToUse);
/*      */           } catch (CodeGenerationException ex) {
/*      */             Object retVal;
/*  692 */             CglibAopProxy.CglibMethodInvocation.logFastClassGenerationFailure(method);
/*  693 */             retVal = AopUtils.invokeJoinpointUsingReflection(target, method, argsToUse);
/*      */           }
/*      */         }
/*      */         else
/*      */         {
/*  698 */           retVal = new CglibAopProxy.CglibMethodInvocation(proxy, target, method, args, targetClass, chain, methodProxy).proceed();
/*      */         }
/*  700 */         Object retVal = CglibAopProxy.processReturnType(proxy, target, method, retVal);
/*  701 */         return (Object[])retVal;
/*      */       }
/*      */       finally {
/*  704 */         if ((target != null) && (!targetSource.isStatic())) {
/*  705 */           targetSource.releaseTarget(target);
/*      */         }
/*  707 */         if (setProxyContext)
/*      */         {
/*  709 */           AopContext.setCurrentProxy(oldProxy);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */     public boolean equals(@Nullable Object other)
/*      */     {
/*  716 */       if (this != other) if (!(other instanceof DynamicAdvisedInterceptor)) break label33; label33: return this.advised
/*      */       
/*  718 */         .equals(((DynamicAdvisedInterceptor)other).advised);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public int hashCode()
/*      */     {
/*  726 */       return this.advised.hashCode();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private static class CglibMethodInvocation
/*      */     extends ReflectiveMethodInvocation
/*      */   {
/*      */     @Nullable
/*      */     private final MethodProxy methodProxy;
/*      */     
/*      */ 
/*      */ 
/*      */     public CglibMethodInvocation(Object proxy, @Nullable Object target, Method method, Object[] arguments, @Nullable Class<?> targetClass, List<Object> interceptorsAndDynamicMethodMatchers, MethodProxy methodProxy)
/*      */     {
/*  743 */       super(target, method, arguments, targetClass, interceptorsAndDynamicMethodMatchers);
/*      */       
/*      */ 
/*  746 */       this.methodProxy = (isMethodProxyCompatible(method) ? methodProxy : null);
/*      */     }
/*      */     
/*      */     @Nullable
/*      */     public Object proceed() throws Throwable
/*      */     {
/*      */       try {
/*  753 */         return super.proceed();
/*      */       }
/*      */       catch (RuntimeException ex) {
/*  756 */         throw ex;
/*      */       }
/*      */       catch (Exception ex) {
/*  759 */         if ((ReflectionUtils.declaresException(getMethod(), ex.getClass())) || 
/*  760 */           (KotlinDetector.isKotlinType(getMethod().getDeclaringClass())))
/*      */         {
/*      */ 
/*      */ 
/*  764 */           throw ex;
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  770 */         throw new UndeclaredThrowableException(ex);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     protected Object invokeJoinpoint()
/*      */       throws Throwable
/*      */     {
/*  781 */       if (this.methodProxy != null) {
/*      */         try {
/*  783 */           return this.methodProxy.invoke(this.target, this.arguments);
/*      */         }
/*      */         catch (CodeGenerationException ex) {
/*  786 */           logFastClassGenerationFailure(this.method);
/*      */         }
/*      */       }
/*  789 */       return super.invokeJoinpoint();
/*      */     }
/*      */     
/*      */     static boolean isMethodProxyCompatible(Method method) {
/*  793 */       return (Modifier.isPublic(method.getModifiers())) && 
/*  794 */         (method.getDeclaringClass() != Object.class) && (!AopUtils.isEqualsMethod(method)) && 
/*  795 */         (!AopUtils.isHashCodeMethod(method)) && (!AopUtils.isToStringMethod(method));
/*      */     }
/*      */     
/*      */     static void logFastClassGenerationFailure(Method method) {
/*  799 */       if (CglibAopProxy.logger.isDebugEnabled()) {
/*  800 */         CglibAopProxy.logger.debug("Failed to generate CGLIB fast class for method: " + method);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static class ProxyCallbackFilter
/*      */     implements CallbackFilter
/*      */   {
/*      */     private final AdvisedSupport advised;
/*      */     
/*      */ 
/*      */     private final Map<Method, Integer> fixedInterceptorMap;
/*      */     
/*      */     private final int fixedInterceptorOffset;
/*      */     
/*      */ 
/*      */     public ProxyCallbackFilter(AdvisedSupport advised, Map<Method, Integer> fixedInterceptorMap, int fixedInterceptorOffset)
/*      */     {
/*  820 */       this.advised = advised;
/*  821 */       this.fixedInterceptorMap = fixedInterceptorMap;
/*  822 */       this.fixedInterceptorOffset = fixedInterceptorOffset;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public int accept(Method method)
/*      */     {
/*  863 */       if (AopUtils.isFinalizeMethod(method)) {
/*  864 */         CglibAopProxy.logger.trace("Found finalize() method - using NO_OVERRIDE");
/*  865 */         return 2;
/*      */       }
/*  867 */       if ((!this.advised.isOpaque()) && (method.getDeclaringClass().isInterface()) && 
/*  868 */         (method.getDeclaringClass().isAssignableFrom(Advised.class))) {
/*  869 */         if (CglibAopProxy.logger.isTraceEnabled()) {
/*  870 */           CglibAopProxy.logger.trace("Method is declared on Advised interface: " + method);
/*      */         }
/*  872 */         return 4;
/*      */       }
/*      */       
/*  875 */       if (AopUtils.isEqualsMethod(method)) {
/*  876 */         if (CglibAopProxy.logger.isTraceEnabled()) {
/*  877 */           CglibAopProxy.logger.trace("Found 'equals' method: " + method);
/*      */         }
/*  879 */         return 5;
/*      */       }
/*      */       
/*  882 */       if (AopUtils.isHashCodeMethod(method)) {
/*  883 */         if (CglibAopProxy.logger.isTraceEnabled()) {
/*  884 */           CglibAopProxy.logger.trace("Found 'hashCode' method: " + method);
/*      */         }
/*  886 */         return 6;
/*      */       }
/*  888 */       Class<?> targetClass = this.advised.getTargetClass();
/*      */       
/*  890 */       List<?> chain = this.advised.getInterceptorsAndDynamicInterceptionAdvice(method, targetClass);
/*  891 */       boolean haveAdvice = !chain.isEmpty();
/*  892 */       boolean exposeProxy = this.advised.isExposeProxy();
/*  893 */       boolean isStatic = this.advised.getTargetSource().isStatic();
/*  894 */       boolean isFrozen = this.advised.isFrozen();
/*  895 */       if ((haveAdvice) || (!isFrozen))
/*      */       {
/*  897 */         if (exposeProxy) {
/*  898 */           if (CglibAopProxy.logger.isTraceEnabled()) {
/*  899 */             CglibAopProxy.logger.trace("Must expose proxy on advised method: " + method);
/*      */           }
/*  901 */           return 0;
/*      */         }
/*      */         
/*      */ 
/*  905 */         if ((isStatic) && (isFrozen) && (this.fixedInterceptorMap.containsKey(method))) {
/*  906 */           if (CglibAopProxy.logger.isTraceEnabled()) {
/*  907 */             CglibAopProxy.logger.trace("Method has advice and optimizations are enabled: " + method);
/*      */           }
/*      */           
/*  910 */           int index = ((Integer)this.fixedInterceptorMap.get(method)).intValue();
/*  911 */           return index + this.fixedInterceptorOffset;
/*      */         }
/*      */         
/*  914 */         if (CglibAopProxy.logger.isTraceEnabled()) {
/*  915 */           CglibAopProxy.logger.trace("Unable to apply any optimizations to advised method: " + method);
/*      */         }
/*  917 */         return 0;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  926 */       if ((exposeProxy) || (!isStatic)) {
/*  927 */         return 1;
/*      */       }
/*  929 */       Class<?> returnType = method.getReturnType();
/*  930 */       if ((targetClass != null) && (returnType.isAssignableFrom(targetClass))) {
/*  931 */         if (CglibAopProxy.logger.isTraceEnabled()) {
/*  932 */           CglibAopProxy.logger.trace("Method return type is assignable from target type and may therefore return 'this' - using INVOKE_TARGET: " + method);
/*      */         }
/*      */         
/*  935 */         return 1;
/*      */       }
/*      */       
/*  938 */       if (CglibAopProxy.logger.isTraceEnabled()) {
/*  939 */         CglibAopProxy.logger.trace("Method return type ensures 'this' cannot be returned - using DISPATCH_TARGET: " + method);
/*      */       }
/*      */       
/*  942 */       return 3;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public boolean equals(@Nullable Object other)
/*      */     {
/*  949 */       if (this == other) {
/*  950 */         return true;
/*      */       }
/*  952 */       if (!(other instanceof ProxyCallbackFilter)) {
/*  953 */         return false;
/*      */       }
/*  955 */       ProxyCallbackFilter otherCallbackFilter = (ProxyCallbackFilter)other;
/*  956 */       AdvisedSupport otherAdvised = otherCallbackFilter.advised;
/*  957 */       if (this.advised.isFrozen() != otherAdvised.isFrozen()) {
/*  958 */         return false;
/*      */       }
/*  960 */       if (this.advised.isExposeProxy() != otherAdvised.isExposeProxy()) {
/*  961 */         return false;
/*      */       }
/*  963 */       if (this.advised.getTargetSource().isStatic() != otherAdvised.getTargetSource().isStatic()) {
/*  964 */         return false;
/*      */       }
/*  966 */       if (!AopProxyUtils.equalsProxiedInterfaces(this.advised, otherAdvised)) {
/*  967 */         return false;
/*      */       }
/*      */       
/*      */ 
/*  971 */       if (this.advised.getAdvisorCount() != otherAdvised.getAdvisorCount()) {
/*  972 */         return false;
/*      */       }
/*  974 */       Advisor[] thisAdvisors = this.advised.getAdvisors();
/*  975 */       Advisor[] thatAdvisors = otherAdvised.getAdvisors();
/*  976 */       for (int i = 0; i < thisAdvisors.length; i++) {
/*  977 */         Advisor thisAdvisor = thisAdvisors[i];
/*  978 */         Advisor thatAdvisor = thatAdvisors[i];
/*  979 */         if (!equalsAdviceClasses(thisAdvisor, thatAdvisor)) {
/*  980 */           return false;
/*      */         }
/*  982 */         if (!equalsPointcuts(thisAdvisor, thatAdvisor)) {
/*  983 */           return false;
/*      */         }
/*      */       }
/*  986 */       return true;
/*      */     }
/*      */     
/*      */     private static boolean equalsAdviceClasses(Advisor a, Advisor b) {
/*  990 */       return a.getAdvice().getClass() == b.getAdvice().getClass();
/*      */     }
/*      */     
/*      */ 
/*      */     private static boolean equalsPointcuts(Advisor a, Advisor b)
/*      */     {
/*  996 */       if ((a instanceof PointcutAdvisor)) if (!(b instanceof PointcutAdvisor)) break label42; label42: return 
/*      */       
/*  998 */         ObjectUtils.nullSafeEquals(((PointcutAdvisor)a).getPointcut(), ((PointcutAdvisor)b).getPointcut());
/*      */     }
/*      */     
/*      */     public int hashCode()
/*      */     {
/* 1003 */       int hashCode = 0;
/* 1004 */       Advisor[] advisors = this.advised.getAdvisors();
/* 1005 */       for (Advisor advisor : advisors) {
/* 1006 */         Advice advice = advisor.getAdvice();
/* 1007 */         hashCode = 13 * hashCode + advice.getClass().hashCode();
/*      */       }
/* 1009 */       hashCode = 13 * hashCode + (this.advised.isFrozen() ? 1 : 0);
/* 1010 */       hashCode = 13 * hashCode + (this.advised.isExposeProxy() ? 1 : 0);
/* 1011 */       hashCode = 13 * hashCode + (this.advised.isOptimize() ? 1 : 0);
/* 1012 */       hashCode = 13 * hashCode + (this.advised.isOpaque() ? 1 : 0);
/* 1013 */       return hashCode;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-aop-5.3.12.jar!\org\springframework\aop\framework\CglibAopProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */