package org.springframework.aop.support;

import org.springframework.aop.Pointcut;
import org.springframework.lang.Nullable;

public abstract interface ExpressionPointcut
  extends Pointcut
{
  @Nullable
  public abstract String getExpression();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-aop-5.3.12.jar!\org\springframework\aop\support\ExpressionPointcut.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */