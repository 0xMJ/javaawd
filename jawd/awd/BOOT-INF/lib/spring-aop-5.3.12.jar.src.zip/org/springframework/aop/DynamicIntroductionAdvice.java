package org.springframework.aop;

import org.aopalliance.aop.Advice;

public abstract interface DynamicIntroductionAdvice
  extends Advice
{
  public abstract boolean implementsInterface(Class<?> paramClass);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-aop-5.3.12.jar!\org\springframework\aop\DynamicIntroductionAdvice.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */