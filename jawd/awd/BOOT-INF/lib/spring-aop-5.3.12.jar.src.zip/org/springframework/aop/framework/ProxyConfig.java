/*     */ package org.springframework.aop.framework;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProxyConfig
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -8409359707199703185L;
/*  37 */   private boolean proxyTargetClass = false;
/*     */   
/*  39 */   private boolean optimize = false;
/*     */   
/*  41 */   boolean opaque = false;
/*     */   
/*  43 */   boolean exposeProxy = false;
/*     */   
/*  45 */   private boolean frozen = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setProxyTargetClass(boolean proxyTargetClass)
/*     */   {
/*  61 */     this.proxyTargetClass = proxyTargetClass;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isProxyTargetClass()
/*     */   {
/*  68 */     return this.proxyTargetClass;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOptimize(boolean optimize)
/*     */   {
/*  81 */     this.optimize = optimize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isOptimize()
/*     */   {
/*  88 */     return this.optimize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOpaque(boolean opaque)
/*     */   {
/*  98 */     this.opaque = opaque;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isOpaque()
/*     */   {
/* 106 */     return this.opaque;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setExposeProxy(boolean exposeProxy)
/*     */   {
/* 119 */     this.exposeProxy = exposeProxy;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isExposeProxy()
/*     */   {
/* 127 */     return this.exposeProxy;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFrozen(boolean frozen)
/*     */   {
/* 137 */     this.frozen = frozen;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isFrozen()
/*     */   {
/* 144 */     return this.frozen;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void copyFrom(ProxyConfig other)
/*     */   {
/* 153 */     Assert.notNull(other, "Other ProxyConfig object must not be null");
/* 154 */     this.proxyTargetClass = other.proxyTargetClass;
/* 155 */     this.optimize = other.optimize;
/* 156 */     this.exposeProxy = other.exposeProxy;
/* 157 */     this.frozen = other.frozen;
/* 158 */     this.opaque = other.opaque;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 163 */     StringBuilder sb = new StringBuilder();
/* 164 */     sb.append("proxyTargetClass=").append(this.proxyTargetClass).append("; ");
/* 165 */     sb.append("optimize=").append(this.optimize).append("; ");
/* 166 */     sb.append("opaque=").append(this.opaque).append("; ");
/* 167 */     sb.append("exposeProxy=").append(this.exposeProxy).append("; ");
/* 168 */     sb.append("frozen=").append(this.frozen);
/* 169 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-aop-5.3.12.jar!\org\springframework\aop\framework\ProxyConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */