/*    */ package org.springframework.aop.framework.autoproxy;
/*    */ 
/*    */ import org.springframework.beans.factory.config.BeanDefinition;
/*    */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InfrastructureAdvisorAutoProxyCreator
/*    */   extends AbstractAdvisorAutoProxyCreator
/*    */ {
/*    */   @Nullable
/*    */   private ConfigurableListableBeanFactory beanFactory;
/*    */   
/*    */   protected void initBeanFactory(ConfigurableListableBeanFactory beanFactory)
/*    */   {
/* 39 */     super.initBeanFactory(beanFactory);
/* 40 */     this.beanFactory = beanFactory;
/*    */   }
/*    */   
/*    */   protected boolean isEligibleAdvisorBean(String beanName)
/*    */   {
/* 45 */     return (this.beanFactory != null) && (this.beanFactory.containsBeanDefinition(beanName)) && 
/* 46 */       (this.beanFactory.getBeanDefinition(beanName).getRole() == 2);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-aop-5.3.12.jar!\org\springframework\aop\framework\autoproxy\InfrastructureAdvisorAutoProxyCreator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */