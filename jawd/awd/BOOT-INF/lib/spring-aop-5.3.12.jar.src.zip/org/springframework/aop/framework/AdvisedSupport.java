/*     */ package org.springframework.aop.framework;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.aopalliance.aop.Advice;
/*     */ import org.springframework.aop.Advisor;
/*     */ import org.springframework.aop.DynamicIntroductionAdvice;
/*     */ import org.springframework.aop.IntroductionAdvisor;
/*     */ import org.springframework.aop.IntroductionInfo;
/*     */ import org.springframework.aop.TargetSource;
/*     */ import org.springframework.aop.support.DefaultIntroductionAdvisor;
/*     */ import org.springframework.aop.support.DefaultPointcutAdvisor;
/*     */ import org.springframework.aop.target.EmptyTargetSource;
/*     */ import org.springframework.aop.target.SingletonTargetSource;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AdvisedSupport
/*     */   extends ProxyConfig
/*     */   implements Advised
/*     */ {
/*     */   private static final long serialVersionUID = 2651364800145442165L;
/*  71 */   public static final TargetSource EMPTY_TARGET_SOURCE = EmptyTargetSource.INSTANCE;
/*     */   
/*     */ 
/*     */ 
/*  75 */   TargetSource targetSource = EMPTY_TARGET_SOURCE;
/*     */   
/*     */ 
/*  78 */   private boolean preFiltered = false;
/*     */   
/*     */ 
/*  81 */   AdvisorChainFactory advisorChainFactory = new DefaultAdvisorChainFactory();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private transient Map<MethodCacheKey, List<Object>> methodCache;
/*     */   
/*     */ 
/*     */ 
/*  90 */   private List<Class<?>> interfaces = new ArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  96 */   private List<Advisor> advisors = new ArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public AdvisedSupport()
/*     */   {
/* 103 */     this.methodCache = new ConcurrentHashMap(32);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public AdvisedSupport(Class<?>... interfaces)
/*     */   {
/* 111 */     this();
/* 112 */     setInterfaces(interfaces);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTarget(Object target)
/*     */   {
/* 123 */     setTargetSource(new SingletonTargetSource(target));
/*     */   }
/*     */   
/*     */   public void setTargetSource(@Nullable TargetSource targetSource)
/*     */   {
/* 128 */     this.targetSource = (targetSource != null ? targetSource : EMPTY_TARGET_SOURCE);
/*     */   }
/*     */   
/*     */   public TargetSource getTargetSource()
/*     */   {
/* 133 */     return this.targetSource;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTargetClass(@Nullable Class<?> targetClass)
/*     */   {
/* 150 */     this.targetSource = EmptyTargetSource.forClass(targetClass);
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public Class<?> getTargetClass()
/*     */   {
/* 156 */     return this.targetSource.getTargetClass();
/*     */   }
/*     */   
/*     */   public void setPreFiltered(boolean preFiltered)
/*     */   {
/* 161 */     this.preFiltered = preFiltered;
/*     */   }
/*     */   
/*     */   public boolean isPreFiltered()
/*     */   {
/* 166 */     return this.preFiltered;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAdvisorChainFactory(AdvisorChainFactory advisorChainFactory)
/*     */   {
/* 174 */     Assert.notNull(advisorChainFactory, "AdvisorChainFactory must not be null");
/* 175 */     this.advisorChainFactory = advisorChainFactory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public AdvisorChainFactory getAdvisorChainFactory()
/*     */   {
/* 182 */     return this.advisorChainFactory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setInterfaces(Class<?>... interfaces)
/*     */   {
/* 190 */     Assert.notNull(interfaces, "Interfaces must not be null");
/* 191 */     this.interfaces.clear();
/* 192 */     for (Class<?> ifc : interfaces) {
/* 193 */       addInterface(ifc);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addInterface(Class<?> intf)
/*     */   {
/* 202 */     Assert.notNull(intf, "Interface must not be null");
/* 203 */     if (!intf.isInterface()) {
/* 204 */       throw new IllegalArgumentException("[" + intf.getName() + "] is not an interface");
/*     */     }
/* 206 */     if (!this.interfaces.contains(intf)) {
/* 207 */       this.interfaces.add(intf);
/* 208 */       adviceChanged();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean removeInterface(Class<?> intf)
/*     */   {
/* 220 */     return this.interfaces.remove(intf);
/*     */   }
/*     */   
/*     */   public Class<?>[] getProxiedInterfaces()
/*     */   {
/* 225 */     return ClassUtils.toClassArray(this.interfaces);
/*     */   }
/*     */   
/*     */   public boolean isInterfaceProxied(Class<?> intf)
/*     */   {
/* 230 */     for (Class<?> proxyIntf : this.interfaces) {
/* 231 */       if (intf.isAssignableFrom(proxyIntf)) {
/* 232 */         return true;
/*     */       }
/*     */     }
/* 235 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public final Advisor[] getAdvisors()
/*     */   {
/* 241 */     return (Advisor[])this.advisors.toArray(new Advisor[0]);
/*     */   }
/*     */   
/*     */   public int getAdvisorCount()
/*     */   {
/* 246 */     return this.advisors.size();
/*     */   }
/*     */   
/*     */   public void addAdvisor(Advisor advisor)
/*     */   {
/* 251 */     int pos = this.advisors.size();
/* 252 */     addAdvisor(pos, advisor);
/*     */   }
/*     */   
/*     */   public void addAdvisor(int pos, Advisor advisor) throws AopConfigException
/*     */   {
/* 257 */     if ((advisor instanceof IntroductionAdvisor)) {
/* 258 */       validateIntroductionAdvisor((IntroductionAdvisor)advisor);
/*     */     }
/* 260 */     addAdvisorInternal(pos, advisor);
/*     */   }
/*     */   
/*     */   public boolean removeAdvisor(Advisor advisor)
/*     */   {
/* 265 */     int index = indexOf(advisor);
/* 266 */     if (index == -1) {
/* 267 */       return false;
/*     */     }
/*     */     
/* 270 */     removeAdvisor(index);
/* 271 */     return true;
/*     */   }
/*     */   
/*     */   public void removeAdvisor(int index)
/*     */     throws AopConfigException
/*     */   {
/* 277 */     if (isFrozen()) {
/* 278 */       throw new AopConfigException("Cannot remove Advisor: Configuration is frozen.");
/*     */     }
/* 280 */     if ((index < 0) || (index > this.advisors.size() - 1))
/*     */     {
/* 282 */       throw new AopConfigException("Advisor index " + index + " is out of bounds: This configuration only has " + this.advisors.size() + " advisors.");
/*     */     }
/*     */     
/* 285 */     Advisor advisor = (Advisor)this.advisors.remove(index);
/* 286 */     if ((advisor instanceof IntroductionAdvisor)) {
/* 287 */       IntroductionAdvisor ia = (IntroductionAdvisor)advisor;
/*     */       
/* 289 */       for (Class<?> ifc : ia.getInterfaces()) {
/* 290 */         removeInterface(ifc);
/*     */       }
/*     */     }
/*     */     
/* 294 */     adviceChanged();
/*     */   }
/*     */   
/*     */   public int indexOf(Advisor advisor)
/*     */   {
/* 299 */     Assert.notNull(advisor, "Advisor must not be null");
/* 300 */     return this.advisors.indexOf(advisor);
/*     */   }
/*     */   
/*     */   public boolean replaceAdvisor(Advisor a, Advisor b) throws AopConfigException
/*     */   {
/* 305 */     Assert.notNull(a, "Advisor a must not be null");
/* 306 */     Assert.notNull(b, "Advisor b must not be null");
/* 307 */     int index = indexOf(a);
/* 308 */     if (index == -1) {
/* 309 */       return false;
/*     */     }
/* 311 */     removeAdvisor(index);
/* 312 */     addAdvisor(index, b);
/* 313 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addAdvisors(Advisor... advisors)
/*     */   {
/* 321 */     addAdvisors(Arrays.asList(advisors));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addAdvisors(Collection<Advisor> advisors)
/*     */   {
/* 329 */     if (isFrozen()) {
/* 330 */       throw new AopConfigException("Cannot add advisor: Configuration is frozen.");
/*     */     }
/* 332 */     if (!CollectionUtils.isEmpty(advisors)) {
/* 333 */       for (Advisor advisor : advisors) {
/* 334 */         if ((advisor instanceof IntroductionAdvisor)) {
/* 335 */           validateIntroductionAdvisor((IntroductionAdvisor)advisor);
/*     */         }
/* 337 */         Assert.notNull(advisor, "Advisor must not be null");
/* 338 */         this.advisors.add(advisor);
/*     */       }
/* 340 */       adviceChanged();
/*     */     }
/*     */   }
/*     */   
/*     */   private void validateIntroductionAdvisor(IntroductionAdvisor advisor) {
/* 345 */     advisor.validateInterfaces();
/*     */     
/* 347 */     Class<?>[] ifcs = advisor.getInterfaces();
/* 348 */     for (Class<?> ifc : ifcs) {
/* 349 */       addInterface(ifc);
/*     */     }
/*     */   }
/*     */   
/*     */   private void addAdvisorInternal(int pos, Advisor advisor) throws AopConfigException {
/* 354 */     Assert.notNull(advisor, "Advisor must not be null");
/* 355 */     if (isFrozen()) {
/* 356 */       throw new AopConfigException("Cannot add advisor: Configuration is frozen.");
/*     */     }
/* 358 */     if (pos > this.advisors.size())
/*     */     {
/* 360 */       throw new IllegalArgumentException("Illegal position " + pos + " in advisor list with size " + this.advisors.size());
/*     */     }
/* 362 */     this.advisors.add(pos, advisor);
/* 363 */     adviceChanged();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final List<Advisor> getAdvisorsInternal()
/*     */   {
/* 372 */     return this.advisors;
/*     */   }
/*     */   
/*     */   public void addAdvice(Advice advice) throws AopConfigException
/*     */   {
/* 377 */     int pos = this.advisors.size();
/* 378 */     addAdvice(pos, advice);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void addAdvice(int pos, Advice advice)
/*     */     throws AopConfigException
/*     */   {
/* 386 */     Assert.notNull(advice, "Advice must not be null");
/* 387 */     if ((advice instanceof IntroductionInfo))
/*     */     {
/*     */ 
/* 390 */       addAdvisor(pos, new DefaultIntroductionAdvisor(advice, (IntroductionInfo)advice));
/*     */     } else {
/* 392 */       if ((advice instanceof DynamicIntroductionAdvice))
/*     */       {
/* 394 */         throw new AopConfigException("DynamicIntroductionAdvice may only be added as part of IntroductionAdvisor");
/*     */       }
/*     */       
/* 397 */       addAdvisor(pos, new DefaultPointcutAdvisor(advice));
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean removeAdvice(Advice advice) throws AopConfigException
/*     */   {
/* 403 */     int index = indexOf(advice);
/* 404 */     if (index == -1) {
/* 405 */       return false;
/*     */     }
/*     */     
/* 408 */     removeAdvisor(index);
/* 409 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public int indexOf(Advice advice)
/*     */   {
/* 415 */     Assert.notNull(advice, "Advice must not be null");
/* 416 */     for (int i = 0; i < this.advisors.size(); i++) {
/* 417 */       Advisor advisor = (Advisor)this.advisors.get(i);
/* 418 */       if (advisor.getAdvice() == advice) {
/* 419 */         return i;
/*     */       }
/*     */     }
/* 422 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean adviceIncluded(@Nullable Advice advice)
/*     */   {
/* 431 */     if (advice != null) {
/* 432 */       for (Advisor advisor : this.advisors) {
/* 433 */         if (advisor.getAdvice() == advice) {
/* 434 */           return true;
/*     */         }
/*     */       }
/*     */     }
/* 438 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int countAdvicesOfType(@Nullable Class<?> adviceClass)
/*     */   {
/* 447 */     int count = 0;
/* 448 */     if (adviceClass != null) {
/* 449 */       for (Advisor advisor : this.advisors) {
/* 450 */         if (adviceClass.isInstance(advisor.getAdvice())) {
/* 451 */           count++;
/*     */         }
/*     */       }
/*     */     }
/* 455 */     return count;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<Object> getInterceptorsAndDynamicInterceptionAdvice(Method method, @Nullable Class<?> targetClass)
/*     */   {
/* 467 */     MethodCacheKey cacheKey = new MethodCacheKey(method);
/* 468 */     List<Object> cached = (List)this.methodCache.get(cacheKey);
/* 469 */     if (cached == null) {
/* 470 */       cached = this.advisorChainFactory.getInterceptorsAndDynamicInterceptionAdvice(this, method, targetClass);
/*     */       
/* 472 */       this.methodCache.put(cacheKey, cached);
/*     */     }
/* 474 */     return cached;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void adviceChanged()
/*     */   {
/* 481 */     this.methodCache.clear();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void copyConfigurationFrom(AdvisedSupport other)
/*     */   {
/* 490 */     copyConfigurationFrom(other, other.targetSource, new ArrayList(other.advisors));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void copyConfigurationFrom(AdvisedSupport other, TargetSource targetSource, List<Advisor> advisors)
/*     */   {
/* 501 */     copyFrom(other);
/* 502 */     this.targetSource = targetSource;
/* 503 */     this.advisorChainFactory = other.advisorChainFactory;
/* 504 */     this.interfaces = new ArrayList(other.interfaces);
/* 505 */     for (Advisor advisor : advisors) {
/* 506 */       if ((advisor instanceof IntroductionAdvisor)) {
/* 507 */         validateIntroductionAdvisor((IntroductionAdvisor)advisor);
/*     */       }
/* 509 */       Assert.notNull(advisor, "Advisor must not be null");
/* 510 */       this.advisors.add(advisor);
/*     */     }
/* 512 */     adviceChanged();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   AdvisedSupport getConfigurationOnlyCopy()
/*     */   {
/* 520 */     AdvisedSupport copy = new AdvisedSupport();
/* 521 */     copy.copyFrom(this);
/* 522 */     copy.targetSource = EmptyTargetSource.forClass(getTargetClass(), getTargetSource().isStatic());
/* 523 */     copy.advisorChainFactory = this.advisorChainFactory;
/* 524 */     copy.interfaces = new ArrayList(this.interfaces);
/* 525 */     copy.advisors = new ArrayList(this.advisors);
/* 526 */     return copy;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void readObject(ObjectInputStream ois)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 536 */     ois.defaultReadObject();
/*     */     
/*     */ 
/* 539 */     this.methodCache = new ConcurrentHashMap(32);
/*     */   }
/*     */   
/*     */   public String toProxyConfigString()
/*     */   {
/* 544 */     return toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 552 */     StringBuilder sb = new StringBuilder(getClass().getName());
/* 553 */     sb.append(": ").append(this.interfaces.size()).append(" interfaces ");
/* 554 */     sb.append(ClassUtils.classNamesToString(this.interfaces)).append("; ");
/* 555 */     sb.append(this.advisors.size()).append(" advisors ");
/* 556 */     sb.append(this.advisors).append("; ");
/* 557 */     sb.append("targetSource [").append(this.targetSource).append("]; ");
/* 558 */     sb.append(super.toString());
/* 559 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static final class MethodCacheKey
/*     */     implements Comparable<MethodCacheKey>
/*     */   {
/*     */     private final Method method;
/*     */     
/*     */     private final int hashCode;
/*     */     
/*     */ 
/*     */     public MethodCacheKey(Method method)
/*     */     {
/* 574 */       this.method = method;
/* 575 */       this.hashCode = method.hashCode();
/*     */     }
/*     */     
/*     */     public boolean equals(@Nullable Object other)
/*     */     {
/* 580 */       return (this == other) || (((other instanceof MethodCacheKey)) && (this.method == ((MethodCacheKey)other).method));
/*     */     }
/*     */     
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 586 */       return this.hashCode;
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/* 591 */       return this.method.toString();
/*     */     }
/*     */     
/*     */     public int compareTo(MethodCacheKey other)
/*     */     {
/* 596 */       int result = this.method.getName().compareTo(other.method.getName());
/* 597 */       if (result == 0) {
/* 598 */         result = this.method.toString().compareTo(other.method.toString());
/*     */       }
/* 600 */       return result;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-aop-5.3.12.jar!\org\springframework\aop\framework\AdvisedSupport.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */