/*    */ package org.springframework.aop.support.annotation;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import org.springframework.aop.ClassFilter;
/*    */ import org.springframework.core.annotation.AnnotatedElementUtils;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AnnotationClassFilter
/*    */   implements ClassFilter
/*    */ {
/*    */   private final Class<? extends Annotation> annotationType;
/*    */   private final boolean checkInherited;
/*    */   
/*    */   public AnnotationClassFilter(Class<? extends Annotation> annotationType)
/*    */   {
/* 46 */     this(annotationType, false);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public AnnotationClassFilter(Class<? extends Annotation> annotationType, boolean checkInherited)
/*    */   {
/* 58 */     Assert.notNull(annotationType, "Annotation type must not be null");
/* 59 */     this.annotationType = annotationType;
/* 60 */     this.checkInherited = checkInherited;
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean matches(Class<?> clazz)
/*    */   {
/* 66 */     return this.checkInherited ? AnnotatedElementUtils.hasAnnotation(clazz, this.annotationType) : clazz
/* 67 */       .isAnnotationPresent(this.annotationType);
/*    */   }
/*    */   
/*    */   public boolean equals(@Nullable Object other)
/*    */   {
/* 72 */     if (this == other) {
/* 73 */       return true;
/*    */     }
/* 75 */     if (!(other instanceof AnnotationClassFilter)) {
/* 76 */       return false;
/*    */     }
/* 78 */     AnnotationClassFilter otherCf = (AnnotationClassFilter)other;
/* 79 */     return (this.annotationType.equals(otherCf.annotationType)) && (this.checkInherited == otherCf.checkInherited);
/*    */   }
/*    */   
/*    */   public int hashCode()
/*    */   {
/* 84 */     return this.annotationType.hashCode();
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 89 */     return getClass().getName() + ": " + this.annotationType;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-aop-5.3.12.jar!\org\springframework\aop\support\annotation\AnnotationClassFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */