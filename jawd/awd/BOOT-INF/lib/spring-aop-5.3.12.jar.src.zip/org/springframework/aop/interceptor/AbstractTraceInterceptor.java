/*     */ package org.springframework.aop.interceptor;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import org.aopalliance.intercept.MethodInterceptor;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.aop.support.AopUtils;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractTraceInterceptor
/*     */   implements MethodInterceptor, Serializable
/*     */ {
/*     */   @Nullable
/*  56 */   protected transient Log defaultLogger = LogFactory.getLog(getClass());
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  62 */   private boolean hideProxyClassNames = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  68 */   private boolean logExceptionStackTrace = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUseDynamicLogger(boolean useDynamicLogger)
/*     */   {
/*  83 */     this.defaultLogger = (useDynamicLogger ? null : LogFactory.getLog(getClass()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLoggerName(String loggerName)
/*     */   {
/*  98 */     this.defaultLogger = LogFactory.getLog(loggerName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setHideProxyClassNames(boolean hideProxyClassNames)
/*     */   {
/* 106 */     this.hideProxyClassNames = hideProxyClassNames;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLogExceptionStackTrace(boolean logExceptionStackTrace)
/*     */   {
/* 117 */     this.logExceptionStackTrace = logExceptionStackTrace;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public Object invoke(MethodInvocation invocation)
/*     */     throws Throwable
/*     */   {
/* 130 */     Log logger = getLoggerForInvocation(invocation);
/* 131 */     if (isInterceptorEnabled(invocation, logger)) {
/* 132 */       return invokeUnderTrace(invocation, logger);
/*     */     }
/*     */     
/* 135 */     return invocation.proceed();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Log getLoggerForInvocation(MethodInvocation invocation)
/*     */   {
/* 150 */     if (this.defaultLogger != null) {
/* 151 */       return this.defaultLogger;
/*     */     }
/*     */     
/* 154 */     Object target = invocation.getThis();
/* 155 */     Assert.state(target != null, "Target must not be null");
/* 156 */     return LogFactory.getLog(getClassForLogging(target));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Class<?> getClassForLogging(Object target)
/*     */   {
/* 167 */     return this.hideProxyClassNames ? AopUtils.getTargetClass(target) : target.getClass();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isInterceptorEnabled(MethodInvocation invocation, Log logger)
/*     */   {
/* 182 */     return isLogEnabled(logger);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isLogEnabled(Log logger)
/*     */   {
/* 192 */     return logger.isTraceEnabled();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void writeToLog(Log logger, String message)
/*     */   {
/* 204 */     writeToLog(logger, message, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void writeToLog(Log logger, String message, @Nullable Throwable ex)
/*     */   {
/* 221 */     if ((ex != null) && (this.logExceptionStackTrace)) {
/* 222 */       logger.trace(message, ex);
/*     */     }
/*     */     else {
/* 225 */       logger.trace(message);
/*     */     }
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   protected abstract Object invokeUnderTrace(MethodInvocation paramMethodInvocation, Log paramLog)
/*     */     throws Throwable;
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-aop-5.3.12.jar!\org\springframework\aop\interceptor\AbstractTraceInterceptor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */