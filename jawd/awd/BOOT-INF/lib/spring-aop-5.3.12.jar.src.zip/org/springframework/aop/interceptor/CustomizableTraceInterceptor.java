/*     */ package org.springframework.aop.interceptor;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Set;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.core.Constants;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StopWatch;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CustomizableTraceInterceptor
/*     */   extends AbstractTraceInterceptor
/*     */ {
/*     */   public static final String PLACEHOLDER_METHOD_NAME = "$[methodName]";
/*     */   public static final String PLACEHOLDER_TARGET_CLASS_NAME = "$[targetClassName]";
/*     */   public static final String PLACEHOLDER_TARGET_CLASS_SHORT_NAME = "$[targetClassShortName]";
/*     */   public static final String PLACEHOLDER_RETURN_VALUE = "$[returnValue]";
/*     */   public static final String PLACEHOLDER_ARGUMENT_TYPES = "$[argumentTypes]";
/*     */   public static final String PLACEHOLDER_ARGUMENTS = "$[arguments]";
/*     */   public static final String PLACEHOLDER_EXCEPTION = "$[exception]";
/*     */   public static final String PLACEHOLDER_INVOCATION_TIME = "$[invocationTime]";
/*     */   private static final String DEFAULT_ENTER_MESSAGE = "Entering method '$[methodName]' of class [$[targetClassName]]";
/*     */   private static final String DEFAULT_EXIT_MESSAGE = "Exiting method '$[methodName]' of class [$[targetClassName]]";
/*     */   private static final String DEFAULT_EXCEPTION_MESSAGE = "Exception thrown in method '$[methodName]' of class [$[targetClassName]]";
/* 150 */   private static final Pattern PATTERN = Pattern.compile("\\$\\[\\p{Alpha}+]");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 155 */   private static final Set<Object> ALLOWED_PLACEHOLDERS = new Constants(CustomizableTraceInterceptor.class)
/* 156 */     .getValues("PLACEHOLDER_");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 162 */   private String enterMessage = "Entering method '$[methodName]' of class [$[targetClassName]]";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 167 */   private String exitMessage = "Exiting method '$[methodName]' of class [$[targetClassName]]";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 172 */   private String exceptionMessage = "Exception thrown in method '$[methodName]' of class [$[targetClassName]]";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEnterMessage(String enterMessage)
/*     */     throws IllegalArgumentException
/*     */   {
/* 186 */     Assert.hasText(enterMessage, "enterMessage must not be empty");
/* 187 */     checkForInvalidPlaceholders(enterMessage);
/* 188 */     Assert.doesNotContain(enterMessage, "$[returnValue]", "enterMessage cannot contain placeholder $[returnValue]");
/*     */     
/* 190 */     Assert.doesNotContain(enterMessage, "$[exception]", "enterMessage cannot contain placeholder $[exception]");
/*     */     
/* 192 */     Assert.doesNotContain(enterMessage, "$[invocationTime]", "enterMessage cannot contain placeholder $[invocationTime]");
/*     */     
/* 194 */     this.enterMessage = enterMessage;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setExitMessage(String exitMessage)
/*     */   {
/* 210 */     Assert.hasText(exitMessage, "exitMessage must not be empty");
/* 211 */     checkForInvalidPlaceholders(exitMessage);
/* 212 */     Assert.doesNotContain(exitMessage, "$[exception]", "exitMessage cannot contain placeholder$[exception]");
/*     */     
/* 214 */     this.exitMessage = exitMessage;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setExceptionMessage(String exceptionMessage)
/*     */   {
/* 229 */     Assert.hasText(exceptionMessage, "exceptionMessage must not be empty");
/* 230 */     checkForInvalidPlaceholders(exceptionMessage);
/* 231 */     Assert.doesNotContain(exceptionMessage, "$[returnValue]", "exceptionMessage cannot contain placeholder $[returnValue]");
/*     */     
/* 233 */     this.exceptionMessage = exceptionMessage;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Object invokeUnderTrace(MethodInvocation invocation, Log logger)
/*     */     throws Throwable
/*     */   {
/* 248 */     String name = ClassUtils.getQualifiedMethodName(invocation.getMethod());
/* 249 */     StopWatch stopWatch = new StopWatch(name);
/* 250 */     Object returnValue = null;
/* 251 */     boolean exitThroughException = false;
/*     */     try {
/* 253 */       stopWatch.start(name);
/* 254 */       writeToLog(logger, 
/* 255 */         replacePlaceholders(this.enterMessage, invocation, null, null, -1L));
/* 256 */       returnValue = invocation.proceed();
/* 257 */       return returnValue;
/*     */     }
/*     */     catch (Throwable ex) {
/* 260 */       if (stopWatch.isRunning()) {
/* 261 */         stopWatch.stop();
/*     */       }
/* 263 */       exitThroughException = true;
/* 264 */       writeToLog(logger, replacePlaceholders(this.exceptionMessage, invocation, null, ex, stopWatch
/* 265 */         .getTotalTimeMillis()), ex);
/* 266 */       throw ex;
/*     */     }
/*     */     finally {
/* 269 */       if (!exitThroughException) {
/* 270 */         if (stopWatch.isRunning()) {
/* 271 */           stopWatch.stop();
/*     */         }
/* 273 */         writeToLog(logger, replacePlaceholders(this.exitMessage, invocation, returnValue, null, stopWatch
/* 274 */           .getTotalTimeMillis()));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String replacePlaceholders(String message, MethodInvocation methodInvocation, @Nullable Object returnValue, @Nullable Throwable throwable, long invocationTime)
/*     */   {
/* 298 */     Matcher matcher = PATTERN.matcher(message);
/* 299 */     Object target = methodInvocation.getThis();
/* 300 */     Assert.state(target != null, "Target must not be null");
/*     */     
/* 302 */     StringBuffer output = new StringBuffer();
/* 303 */     while (matcher.find()) {
/* 304 */       String match = matcher.group();
/* 305 */       if ("$[methodName]".equals(match)) {
/* 306 */         matcher.appendReplacement(output, Matcher.quoteReplacement(methodInvocation.getMethod().getName()));
/*     */       }
/* 308 */       else if ("$[targetClassName]".equals(match)) {
/* 309 */         String className = getClassForLogging(target).getName();
/* 310 */         matcher.appendReplacement(output, Matcher.quoteReplacement(className));
/*     */       }
/* 312 */       else if ("$[targetClassShortName]".equals(match)) {
/* 313 */         String shortName = ClassUtils.getShortName(getClassForLogging(target));
/* 314 */         matcher.appendReplacement(output, Matcher.quoteReplacement(shortName));
/*     */       }
/* 316 */       else if ("$[arguments]".equals(match)) {
/* 317 */         matcher.appendReplacement(output, 
/* 318 */           Matcher.quoteReplacement(StringUtils.arrayToCommaDelimitedString(methodInvocation.getArguments())));
/*     */       }
/* 320 */       else if ("$[argumentTypes]".equals(match)) {
/* 321 */         appendArgumentTypes(methodInvocation, matcher, output);
/*     */       }
/* 323 */       else if ("$[returnValue]".equals(match)) {
/* 324 */         appendReturnValue(methodInvocation, matcher, output, returnValue);
/*     */       }
/* 326 */       else if ((throwable != null) && ("$[exception]".equals(match))) {
/* 327 */         matcher.appendReplacement(output, Matcher.quoteReplacement(throwable.toString()));
/*     */       }
/* 329 */       else if ("$[invocationTime]".equals(match)) {
/* 330 */         matcher.appendReplacement(output, Long.toString(invocationTime));
/*     */       }
/*     */       else
/*     */       {
/* 334 */         throw new IllegalArgumentException("Unknown placeholder [" + match + "]");
/*     */       }
/*     */     }
/* 337 */     matcher.appendTail(output);
/*     */     
/* 339 */     return output.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void appendReturnValue(MethodInvocation methodInvocation, Matcher matcher, StringBuffer output, @Nullable Object returnValue)
/*     */   {
/* 354 */     if (methodInvocation.getMethod().getReturnType() == Void.TYPE) {
/* 355 */       matcher.appendReplacement(output, "void");
/*     */     }
/* 357 */     else if (returnValue == null) {
/* 358 */       matcher.appendReplacement(output, "null");
/*     */     }
/*     */     else {
/* 361 */       matcher.appendReplacement(output, Matcher.quoteReplacement(returnValue.toString()));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void appendArgumentTypes(MethodInvocation methodInvocation, Matcher matcher, StringBuffer output)
/*     */   {
/* 376 */     Class<?>[] argumentTypes = methodInvocation.getMethod().getParameterTypes();
/* 377 */     String[] argumentTypeShortNames = new String[argumentTypes.length];
/* 378 */     for (int i = 0; i < argumentTypeShortNames.length; i++) {
/* 379 */       argumentTypeShortNames[i] = ClassUtils.getShortName(argumentTypes[i]);
/*     */     }
/* 381 */     matcher.appendReplacement(output, 
/* 382 */       Matcher.quoteReplacement(StringUtils.arrayToCommaDelimitedString(argumentTypeShortNames)));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void checkForInvalidPlaceholders(String message)
/*     */     throws IllegalArgumentException
/*     */   {
/* 391 */     Matcher matcher = PATTERN.matcher(message);
/* 392 */     while (matcher.find()) {
/* 393 */       String match = matcher.group();
/* 394 */       if (!ALLOWED_PLACEHOLDERS.contains(match)) {
/* 395 */         throw new IllegalArgumentException("Placeholder [" + match + "] is not valid");
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-aop-5.3.12.jar!\org\springframework\aop\interceptor\CustomizableTraceInterceptor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */