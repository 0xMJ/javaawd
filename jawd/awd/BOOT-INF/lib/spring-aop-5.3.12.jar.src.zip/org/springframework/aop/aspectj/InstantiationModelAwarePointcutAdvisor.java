package org.springframework.aop.aspectj;

import org.springframework.aop.PointcutAdvisor;

public abstract interface InstantiationModelAwarePointcutAdvisor
  extends PointcutAdvisor
{
  public abstract boolean isLazy();
  
  public abstract boolean isAdviceInstantiated();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-aop-5.3.12.jar!\org\springframework\aop\aspectj\InstantiationModelAwarePointcutAdvisor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */