/*     */ package org.springframework.aop.support;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Arrays;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractRegexpMethodPointcut
/*     */   extends StaticMethodMatcherPointcut
/*     */   implements Serializable
/*     */ {
/*  58 */   private String[] patterns = new String[0];
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  63 */   private String[] excludedPatterns = new String[0];
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPattern(String pattern)
/*     */   {
/*  72 */     setPatterns(new String[] { pattern });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPatterns(String... patterns)
/*     */   {
/*  81 */     Assert.notEmpty(patterns, "'patterns' must not be empty");
/*  82 */     this.patterns = new String[patterns.length];
/*  83 */     for (int i = 0; i < patterns.length; i++) {
/*  84 */       this.patterns[i] = StringUtils.trimWhitespace(patterns[i]);
/*     */     }
/*  86 */     initPatternRepresentation(this.patterns);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String[] getPatterns()
/*     */   {
/*  93 */     return this.patterns;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setExcludedPattern(String excludedPattern)
/*     */   {
/* 102 */     setExcludedPatterns(new String[] { excludedPattern });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setExcludedPatterns(String... excludedPatterns)
/*     */   {
/* 111 */     Assert.notEmpty(excludedPatterns, "'excludedPatterns' must not be empty");
/* 112 */     this.excludedPatterns = new String[excludedPatterns.length];
/* 113 */     for (int i = 0; i < excludedPatterns.length; i++) {
/* 114 */       this.excludedPatterns[i] = StringUtils.trimWhitespace(excludedPatterns[i]);
/*     */     }
/* 116 */     initExcludedPatternRepresentation(this.excludedPatterns);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String[] getExcludedPatterns()
/*     */   {
/* 123 */     return this.excludedPatterns;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean matches(Method method, Class<?> targetClass)
/*     */   {
/* 134 */     return (matchesPattern(ClassUtils.getQualifiedMethodName(method, targetClass))) || (
/* 135 */       (targetClass != method.getDeclaringClass()) && 
/* 136 */       (matchesPattern(ClassUtils.getQualifiedMethodName(method, method.getDeclaringClass()))));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean matchesPattern(String signatureString)
/*     */   {
/* 145 */     for (int i = 0; i < this.patterns.length; i++) {
/* 146 */       boolean matched = matches(signatureString, i);
/* 147 */       if (matched) {
/* 148 */         for (int j = 0; j < this.excludedPatterns.length; j++) {
/* 149 */           boolean excluded = matchesExclusion(signatureString, j);
/* 150 */           if (excluded) {
/* 151 */             return false;
/*     */           }
/*     */         }
/* 154 */         return true;
/*     */       }
/*     */     }
/* 157 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract void initPatternRepresentation(String[] paramArrayOfString)
/*     */     throws IllegalArgumentException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract void initExcludedPatternRepresentation(String[] paramArrayOfString)
/*     */     throws IllegalArgumentException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract boolean matches(String paramString, int paramInt);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract boolean matchesExclusion(String paramString, int paramInt);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(@Nullable Object other)
/*     */   {
/* 200 */     if (this == other) {
/* 201 */       return true;
/*     */     }
/* 203 */     if (!(other instanceof AbstractRegexpMethodPointcut)) {
/* 204 */       return false;
/*     */     }
/* 206 */     AbstractRegexpMethodPointcut otherPointcut = (AbstractRegexpMethodPointcut)other;
/* 207 */     return (Arrays.equals(this.patterns, otherPointcut.patterns)) && 
/* 208 */       (Arrays.equals(this.excludedPatterns, otherPointcut.excludedPatterns));
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 213 */     int result = 27;
/* 214 */     for (String pattern : this.patterns) {
/* 215 */       result = 13 * result + pattern.hashCode();
/*     */     }
/* 217 */     for (String excludedPattern : this.excludedPatterns) {
/* 218 */       result = 13 * result + excludedPattern.hashCode();
/*     */     }
/* 220 */     return result;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 225 */     return 
/* 226 */       getClass().getName() + ": patterns " + ObjectUtils.nullSafeToString(this.patterns) + ", excluded patterns " + ObjectUtils.nullSafeToString(this.excludedPatterns);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-aop-5.3.12.jar!\org\springframework\aop\support\AbstractRegexpMethodPointcut.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */