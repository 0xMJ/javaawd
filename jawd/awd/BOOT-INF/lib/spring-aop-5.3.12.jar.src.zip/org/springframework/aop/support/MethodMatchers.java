/*     */ package org.springframework.aop.support;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Method;
/*     */ import org.springframework.aop.ClassFilter;
/*     */ import org.springframework.aop.IntroductionAwareMethodMatcher;
/*     */ import org.springframework.aop.MethodMatcher;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MethodMatchers
/*     */ {
/*     */   public static MethodMatcher union(MethodMatcher mm1, MethodMatcher mm2)
/*     */   {
/*  53 */     return ((mm1 instanceof IntroductionAwareMethodMatcher)) || ((mm2 instanceof IntroductionAwareMethodMatcher)) ? new UnionIntroductionAwareMethodMatcher(mm1, mm2) : new UnionMethodMatcher(mm1, mm2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static MethodMatcher union(MethodMatcher mm1, ClassFilter cf1, MethodMatcher mm2, ClassFilter cf2)
/*     */   {
/*  67 */     return ((mm1 instanceof IntroductionAwareMethodMatcher)) || ((mm2 instanceof IntroductionAwareMethodMatcher)) ? new ClassFilterAwareUnionIntroductionAwareMethodMatcher(mm1, cf1, mm2, cf2) : new ClassFilterAwareUnionMethodMatcher(mm1, cf1, mm2, cf2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static MethodMatcher intersection(MethodMatcher mm1, MethodMatcher mm2)
/*     */   {
/*  80 */     return ((mm1 instanceof IntroductionAwareMethodMatcher)) || ((mm2 instanceof IntroductionAwareMethodMatcher)) ? new IntersectionIntroductionAwareMethodMatcher(mm1, mm2) : new IntersectionMethodMatcher(mm1, mm2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean matches(MethodMatcher mm, Method method, Class<?> targetClass, boolean hasIntroductions)
/*     */   {
/*  96 */     Assert.notNull(mm, "MethodMatcher must not be null");
/*  97 */     return (mm instanceof IntroductionAwareMethodMatcher) ? ((IntroductionAwareMethodMatcher)mm)
/*  98 */       .matches(method, targetClass, hasIntroductions) : mm
/*  99 */       .matches(method, targetClass);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static class UnionMethodMatcher
/*     */     implements MethodMatcher, Serializable
/*     */   {
/*     */     protected final MethodMatcher mm1;
/*     */     
/*     */     protected final MethodMatcher mm2;
/*     */     
/*     */ 
/*     */     public UnionMethodMatcher(MethodMatcher mm1, MethodMatcher mm2)
/*     */     {
/* 114 */       Assert.notNull(mm1, "First MethodMatcher must not be null");
/* 115 */       Assert.notNull(mm2, "Second MethodMatcher must not be null");
/* 116 */       this.mm1 = mm1;
/* 117 */       this.mm2 = mm2;
/*     */     }
/*     */     
/*     */     public boolean matches(Method method, Class<?> targetClass)
/*     */     {
/* 122 */       return ((matchesClass1(targetClass)) && (this.mm1.matches(method, targetClass))) || (
/* 123 */         (matchesClass2(targetClass)) && (this.mm2.matches(method, targetClass)));
/*     */     }
/*     */     
/*     */     protected boolean matchesClass1(Class<?> targetClass) {
/* 127 */       return true;
/*     */     }
/*     */     
/*     */     protected boolean matchesClass2(Class<?> targetClass) {
/* 131 */       return true;
/*     */     }
/*     */     
/*     */     public boolean isRuntime()
/*     */     {
/* 136 */       return (this.mm1.isRuntime()) || (this.mm2.isRuntime());
/*     */     }
/*     */     
/*     */     public boolean matches(Method method, Class<?> targetClass, Object... args)
/*     */     {
/* 141 */       return (this.mm1.matches(method, targetClass, args)) || (this.mm2.matches(method, targetClass, args));
/*     */     }
/*     */     
/*     */     public boolean equals(@Nullable Object other)
/*     */     {
/* 146 */       if (this == other) {
/* 147 */         return true;
/*     */       }
/* 149 */       if (!(other instanceof UnionMethodMatcher)) {
/* 150 */         return false;
/*     */       }
/* 152 */       UnionMethodMatcher that = (UnionMethodMatcher)other;
/* 153 */       return (this.mm1.equals(that.mm1)) && (this.mm2.equals(that.mm2));
/*     */     }
/*     */     
/*     */     public int hashCode()
/*     */     {
/* 158 */       return 37 * this.mm1.hashCode() + this.mm2.hashCode();
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/* 163 */       return getClass().getName() + ": " + this.mm1 + ", " + this.mm2;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class UnionIntroductionAwareMethodMatcher
/*     */     extends MethodMatchers.UnionMethodMatcher
/*     */     implements IntroductionAwareMethodMatcher
/*     */   {
/*     */     public UnionIntroductionAwareMethodMatcher(MethodMatcher mm1, MethodMatcher mm2)
/*     */     {
/* 178 */       super(mm2);
/*     */     }
/*     */     
/*     */     public boolean matches(Method method, Class<?> targetClass, boolean hasIntroductions)
/*     */     {
/* 183 */       return ((matchesClass1(targetClass)) && (MethodMatchers.matches(this.mm1, method, targetClass, hasIntroductions))) || (
/* 184 */         (matchesClass2(targetClass)) && (MethodMatchers.matches(this.mm2, method, targetClass, hasIntroductions)));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static class ClassFilterAwareUnionMethodMatcher
/*     */     extends MethodMatchers.UnionMethodMatcher
/*     */   {
/*     */     private final ClassFilter cf1;
/*     */     
/*     */ 
/*     */     private final ClassFilter cf2;
/*     */     
/*     */ 
/*     */     public ClassFilterAwareUnionMethodMatcher(MethodMatcher mm1, ClassFilter cf1, MethodMatcher mm2, ClassFilter cf2)
/*     */     {
/* 201 */       super(mm2);
/* 202 */       this.cf1 = cf1;
/* 203 */       this.cf2 = cf2;
/*     */     }
/*     */     
/*     */     protected boolean matchesClass1(Class<?> targetClass)
/*     */     {
/* 208 */       return this.cf1.matches(targetClass);
/*     */     }
/*     */     
/*     */     protected boolean matchesClass2(Class<?> targetClass)
/*     */     {
/* 213 */       return this.cf2.matches(targetClass);
/*     */     }
/*     */     
/*     */     public boolean equals(@Nullable Object other)
/*     */     {
/* 218 */       if (this == other) {
/* 219 */         return true;
/*     */       }
/* 221 */       if (!super.equals(other)) {
/* 222 */         return false;
/*     */       }
/* 224 */       ClassFilter otherCf1 = ClassFilter.TRUE;
/* 225 */       ClassFilter otherCf2 = ClassFilter.TRUE;
/* 226 */       if ((other instanceof ClassFilterAwareUnionMethodMatcher)) {
/* 227 */         ClassFilterAwareUnionMethodMatcher cfa = (ClassFilterAwareUnionMethodMatcher)other;
/* 228 */         otherCf1 = cfa.cf1;
/* 229 */         otherCf2 = cfa.cf2;
/*     */       }
/* 231 */       return (this.cf1.equals(otherCf1)) && (this.cf2.equals(otherCf2));
/*     */     }
/*     */     
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 237 */       return super.hashCode();
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/* 242 */       return getClass().getName() + ": " + this.cf1 + ", " + this.mm1 + ", " + this.cf2 + ", " + this.mm2;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class ClassFilterAwareUnionIntroductionAwareMethodMatcher
/*     */     extends MethodMatchers.ClassFilterAwareUnionMethodMatcher
/*     */     implements IntroductionAwareMethodMatcher
/*     */   {
/*     */     public ClassFilterAwareUnionIntroductionAwareMethodMatcher(MethodMatcher mm1, ClassFilter cf1, MethodMatcher mm2, ClassFilter cf2)
/*     */     {
/* 260 */       super(cf1, mm2, cf2);
/*     */     }
/*     */     
/*     */     public boolean matches(Method method, Class<?> targetClass, boolean hasIntroductions)
/*     */     {
/* 265 */       return ((matchesClass1(targetClass)) && (MethodMatchers.matches(this.mm1, method, targetClass, hasIntroductions))) || (
/* 266 */         (matchesClass2(targetClass)) && (MethodMatchers.matches(this.mm2, method, targetClass, hasIntroductions)));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static class IntersectionMethodMatcher
/*     */     implements MethodMatcher, Serializable
/*     */   {
/*     */     protected final MethodMatcher mm1;
/*     */     
/*     */     protected final MethodMatcher mm2;
/*     */     
/*     */ 
/*     */     public IntersectionMethodMatcher(MethodMatcher mm1, MethodMatcher mm2)
/*     */     {
/* 282 */       Assert.notNull(mm1, "First MethodMatcher must not be null");
/* 283 */       Assert.notNull(mm2, "Second MethodMatcher must not be null");
/* 284 */       this.mm1 = mm1;
/* 285 */       this.mm2 = mm2;
/*     */     }
/*     */     
/*     */     public boolean matches(Method method, Class<?> targetClass)
/*     */     {
/* 290 */       return (this.mm1.matches(method, targetClass)) && (this.mm2.matches(method, targetClass));
/*     */     }
/*     */     
/*     */     public boolean isRuntime()
/*     */     {
/* 295 */       return (this.mm1.isRuntime()) || (this.mm2.isRuntime());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public boolean matches(Method method, Class<?> targetClass, Object... args)
/*     */     {
/* 304 */       boolean aMatches = this.mm1.isRuntime() ? this.mm1.matches(method, targetClass, args) : this.mm1.matches(method, targetClass);
/*     */       
/* 306 */       boolean bMatches = this.mm2.isRuntime() ? this.mm2.matches(method, targetClass, args) : this.mm2.matches(method, targetClass);
/* 307 */       return (aMatches) && (bMatches);
/*     */     }
/*     */     
/*     */     public boolean equals(@Nullable Object other)
/*     */     {
/* 312 */       if (this == other) {
/* 313 */         return true;
/*     */       }
/* 315 */       if (!(other instanceof IntersectionMethodMatcher)) {
/* 316 */         return false;
/*     */       }
/* 318 */       IntersectionMethodMatcher that = (IntersectionMethodMatcher)other;
/* 319 */       return (this.mm1.equals(that.mm1)) && (this.mm2.equals(that.mm2));
/*     */     }
/*     */     
/*     */     public int hashCode()
/*     */     {
/* 324 */       return 37 * this.mm1.hashCode() + this.mm2.hashCode();
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/* 329 */       return getClass().getName() + ": " + this.mm1 + ", " + this.mm2;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class IntersectionIntroductionAwareMethodMatcher
/*     */     extends MethodMatchers.IntersectionMethodMatcher
/*     */     implements IntroductionAwareMethodMatcher
/*     */   {
/*     */     public IntersectionIntroductionAwareMethodMatcher(MethodMatcher mm1, MethodMatcher mm2)
/*     */     {
/* 344 */       super(mm2);
/*     */     }
/*     */     
/*     */     public boolean matches(Method method, Class<?> targetClass, boolean hasIntroductions)
/*     */     {
/* 349 */       return (MethodMatchers.matches(this.mm1, method, targetClass, hasIntroductions)) && 
/* 350 */         (MethodMatchers.matches(this.mm2, method, targetClass, hasIntroductions));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-aop-5.3.12.jar!\org\springframework\aop\support\MethodMatchers.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */