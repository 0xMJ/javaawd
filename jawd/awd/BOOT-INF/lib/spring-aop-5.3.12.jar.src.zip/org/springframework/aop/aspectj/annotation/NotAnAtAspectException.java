/*    */ package org.springframework.aop.aspectj.annotation;
/*    */ 
/*    */ import org.springframework.aop.framework.AopConfigException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NotAnAtAspectException
/*    */   extends AopConfigException
/*    */ {
/*    */   private final Class<?> nonAspectClass;
/*    */   
/*    */   public NotAnAtAspectException(Class<?> nonAspectClass)
/*    */   {
/* 40 */     super(nonAspectClass.getName() + " is not an @AspectJ aspect");
/* 41 */     this.nonAspectClass = nonAspectClass;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public Class<?> getNonAspectClass()
/*    */   {
/* 48 */     return this.nonAspectClass;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-aop-5.3.12.jar!\org\springframework\aop\aspectj\annotation\NotAnAtAspectException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */