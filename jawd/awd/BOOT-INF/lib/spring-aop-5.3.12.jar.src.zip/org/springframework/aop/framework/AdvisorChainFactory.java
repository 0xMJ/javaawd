package org.springframework.aop.framework;

import java.lang.reflect.Method;
import java.util.List;
import org.springframework.lang.Nullable;

public abstract interface AdvisorChainFactory
{
  public abstract List<Object> getInterceptorsAndDynamicInterceptionAdvice(Advised paramAdvised, Method paramMethod, @Nullable Class<?> paramClass);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-aop-5.3.12.jar!\org\springframework\aop\framework\AdvisorChainFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */