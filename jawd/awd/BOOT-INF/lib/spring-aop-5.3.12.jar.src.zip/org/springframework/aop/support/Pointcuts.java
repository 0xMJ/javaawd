/*     */ package org.springframework.aop.support;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Method;
/*     */ import org.springframework.aop.ClassFilter;
/*     */ import org.springframework.aop.MethodMatcher;
/*     */ import org.springframework.aop.Pointcut;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Pointcuts
/*     */ {
/*  39 */   public static final Pointcut SETTERS = SetterPointcut.INSTANCE;
/*     */   
/*     */ 
/*  42 */   public static final Pointcut GETTERS = GetterPointcut.INSTANCE;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Pointcut union(Pointcut pc1, Pointcut pc2)
/*     */   {
/*  53 */     return new ComposablePointcut(pc1).union(pc2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Pointcut intersection(Pointcut pc1, Pointcut pc2)
/*     */   {
/*  64 */     return new ComposablePointcut(pc1).intersection(pc2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean matches(Pointcut pointcut, Method method, Class<?> targetClass, Object... args)
/*     */   {
/*  76 */     Assert.notNull(pointcut, "Pointcut must not be null");
/*  77 */     if (pointcut == Pointcut.TRUE) {
/*  78 */       return true;
/*     */     }
/*  80 */     if (pointcut.getClassFilter().matches(targetClass))
/*     */     {
/*  82 */       MethodMatcher mm = pointcut.getMethodMatcher();
/*  83 */       if (mm.matches(method, targetClass))
/*     */       {
/*  85 */         return (!mm.isRuntime()) || (mm.matches(method, targetClass, args));
/*     */       }
/*     */     }
/*  88 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class SetterPointcut
/*     */     extends StaticMethodMatcherPointcut
/*     */     implements Serializable
/*     */   {
/*  98 */     public static final SetterPointcut INSTANCE = new SetterPointcut();
/*     */     
/*     */     public boolean matches(Method method, Class<?> targetClass)
/*     */     {
/* 102 */       return (method.getName().startsWith("set")) && 
/* 103 */         (method.getParameterCount() == 1) && 
/* 104 */         (method.getReturnType() == Void.TYPE);
/*     */     }
/*     */     
/*     */     private Object readResolve() {
/* 108 */       return INSTANCE;
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/* 113 */       return "Pointcuts.SETTERS";
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class GetterPointcut
/*     */     extends StaticMethodMatcherPointcut
/*     */     implements Serializable
/*     */   {
/* 124 */     public static final GetterPointcut INSTANCE = new GetterPointcut();
/*     */     
/*     */     public boolean matches(Method method, Class<?> targetClass)
/*     */     {
/* 128 */       return (method.getName().startsWith("get")) && 
/* 129 */         (method.getParameterCount() == 0);
/*     */     }
/*     */     
/*     */     private Object readResolve() {
/* 133 */       return INSTANCE;
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/* 138 */       return "Pointcuts.GETTERS";
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-aop-5.3.12.jar!\org\springframework\aop\support\Pointcuts.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */