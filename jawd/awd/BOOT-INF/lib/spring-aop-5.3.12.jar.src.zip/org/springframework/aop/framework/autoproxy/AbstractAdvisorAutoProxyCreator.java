/*     */ package org.springframework.aop.framework.autoproxy;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.springframework.aop.Advisor;
/*     */ import org.springframework.aop.TargetSource;
/*     */ import org.springframework.aop.support.AopUtils;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.core.annotation.AnnotationAwareOrderComparator;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractAdvisorAutoProxyCreator
/*     */   extends AbstractAutoProxyCreator
/*     */ {
/*     */   @Nullable
/*     */   private BeanFactoryAdvisorRetrievalHelper advisorRetrievalHelper;
/*     */   
/*     */   public void setBeanFactory(BeanFactory beanFactory)
/*     */   {
/*  60 */     super.setBeanFactory(beanFactory);
/*  61 */     if (!(beanFactory instanceof ConfigurableListableBeanFactory)) {
/*  62 */       throw new IllegalArgumentException("AdvisorAutoProxyCreator requires a ConfigurableListableBeanFactory: " + beanFactory);
/*     */     }
/*     */     
/*  65 */     initBeanFactory((ConfigurableListableBeanFactory)beanFactory);
/*     */   }
/*     */   
/*     */   protected void initBeanFactory(ConfigurableListableBeanFactory beanFactory) {
/*  69 */     this.advisorRetrievalHelper = new BeanFactoryAdvisorRetrievalHelperAdapter(beanFactory);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected Object[] getAdvicesAndAdvisorsForBean(Class<?> beanClass, String beanName, @Nullable TargetSource targetSource)
/*     */   {
/*  78 */     List<Advisor> advisors = findEligibleAdvisors(beanClass, beanName);
/*  79 */     if (advisors.isEmpty()) {
/*  80 */       return DO_NOT_PROXY;
/*     */     }
/*  82 */     return advisors.toArray();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected List<Advisor> findEligibleAdvisors(Class<?> beanClass, String beanName)
/*     */   {
/*  96 */     List<Advisor> candidateAdvisors = findCandidateAdvisors();
/*  97 */     List<Advisor> eligibleAdvisors = findAdvisorsThatCanApply(candidateAdvisors, beanClass, beanName);
/*  98 */     extendAdvisors(eligibleAdvisors);
/*  99 */     if (!eligibleAdvisors.isEmpty()) {
/* 100 */       eligibleAdvisors = sortAdvisors(eligibleAdvisors);
/*     */     }
/* 102 */     return eligibleAdvisors;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected List<Advisor> findCandidateAdvisors()
/*     */   {
/* 110 */     Assert.state(this.advisorRetrievalHelper != null, "No BeanFactoryAdvisorRetrievalHelper available");
/* 111 */     return this.advisorRetrievalHelper.findAdvisorBeans();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected List<Advisor> findAdvisorsThatCanApply(List<Advisor> candidateAdvisors, Class<?> beanClass, String beanName)
/*     */   {
/* 126 */     ProxyCreationContext.setCurrentProxiedBeanName(beanName);
/*     */     try {
/* 128 */       return AopUtils.findAdvisorsThatCanApply(candidateAdvisors, beanClass);
/*     */     }
/*     */     finally {
/* 131 */       ProxyCreationContext.setCurrentProxiedBeanName(null);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isEligibleAdvisorBean(String beanName)
/*     */   {
/* 142 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected List<Advisor> sortAdvisors(List<Advisor> advisors)
/*     */   {
/* 155 */     AnnotationAwareOrderComparator.sort(advisors);
/* 156 */     return advisors;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void extendAdvisors(List<Advisor> candidateAdvisors) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean advisorsPreFiltered()
/*     */   {
/* 176 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private class BeanFactoryAdvisorRetrievalHelperAdapter
/*     */     extends BeanFactoryAdvisorRetrievalHelper
/*     */   {
/*     */     public BeanFactoryAdvisorRetrievalHelperAdapter(ConfigurableListableBeanFactory beanFactory)
/*     */     {
/* 187 */       super();
/*     */     }
/*     */     
/*     */     protected boolean isEligibleBean(String beanName)
/*     */     {
/* 192 */       return AbstractAdvisorAutoProxyCreator.this.isEligibleAdvisorBean(beanName);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-aop-5.3.12.jar!\org\springframework\aop\framework\autoproxy\AbstractAdvisorAutoProxyCreator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */