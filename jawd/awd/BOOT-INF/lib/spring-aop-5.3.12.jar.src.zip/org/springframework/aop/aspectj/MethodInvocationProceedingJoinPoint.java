/*     */ package org.springframework.aop.aspectj;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.aspectj.lang.JoinPoint.StaticPart;
/*     */ import org.aspectj.lang.ProceedingJoinPoint;
/*     */ import org.aspectj.lang.Signature;
/*     */ import org.aspectj.lang.reflect.MethodSignature;
/*     */ import org.aspectj.lang.reflect.SourceLocation;
/*     */ import org.aspectj.runtime.internal.AroundClosure;
/*     */ import org.springframework.aop.ProxyMethodInvocation;
/*     */ import org.springframework.core.DefaultParameterNameDiscoverer;
/*     */ import org.springframework.core.ParameterNameDiscoverer;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MethodInvocationProceedingJoinPoint
/*     */   implements ProceedingJoinPoint, JoinPoint.StaticPart
/*     */ {
/*  54 */   private static final ParameterNameDiscoverer parameterNameDiscoverer = new DefaultParameterNameDiscoverer();
/*     */   
/*     */ 
/*     */ 
/*     */   private final ProxyMethodInvocation methodInvocation;
/*     */   
/*     */ 
/*     */   @Nullable
/*     */   private Object[] args;
/*     */   
/*     */ 
/*     */   @Nullable
/*     */   private Signature signature;
/*     */   
/*     */ 
/*     */   @Nullable
/*     */   private SourceLocation sourceLocation;
/*     */   
/*     */ 
/*     */ 
/*     */   public MethodInvocationProceedingJoinPoint(ProxyMethodInvocation methodInvocation)
/*     */   {
/*  76 */     Assert.notNull(methodInvocation, "MethodInvocation must not be null");
/*  77 */     this.methodInvocation = methodInvocation;
/*     */   }
/*     */   
/*     */ 
/*     */   public void set$AroundClosure(AroundClosure aroundClosure)
/*     */   {
/*  83 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public Object proceed() throws Throwable
/*     */   {
/*  89 */     return this.methodInvocation.invocableClone().proceed();
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public Object proceed(Object[] arguments) throws Throwable
/*     */   {
/*  95 */     Assert.notNull(arguments, "Argument array passed to proceed cannot be null");
/*  96 */     if (arguments.length != this.methodInvocation.getArguments().length)
/*     */     {
/*  98 */       throw new IllegalArgumentException("Expecting " + this.methodInvocation.getArguments().length + " arguments to proceed, but was passed " + arguments.length + " arguments");
/*     */     }
/*     */     
/* 101 */     this.methodInvocation.setArguments(arguments);
/* 102 */     return this.methodInvocation.invocableClone(arguments).proceed();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getThis()
/*     */   {
/* 110 */     return this.methodInvocation.getProxy();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public Object getTarget()
/*     */   {
/* 119 */     return this.methodInvocation.getThis();
/*     */   }
/*     */   
/*     */   public Object[] getArgs()
/*     */   {
/* 124 */     if (this.args == null) {
/* 125 */       this.args = ((Object[])this.methodInvocation.getArguments().clone());
/*     */     }
/* 127 */     return this.args;
/*     */   }
/*     */   
/*     */   public Signature getSignature()
/*     */   {
/* 132 */     if (this.signature == null) {
/* 133 */       this.signature = new MethodSignatureImpl(null);
/*     */     }
/* 135 */     return this.signature;
/*     */   }
/*     */   
/*     */   public SourceLocation getSourceLocation()
/*     */   {
/* 140 */     if (this.sourceLocation == null) {
/* 141 */       this.sourceLocation = new SourceLocationImpl(null);
/*     */     }
/* 143 */     return this.sourceLocation;
/*     */   }
/*     */   
/*     */   public String getKind()
/*     */   {
/* 148 */     return "method-execution";
/*     */   }
/*     */   
/*     */ 
/*     */   public int getId()
/*     */   {
/* 154 */     return 0;
/*     */   }
/*     */   
/*     */   public JoinPoint.StaticPart getStaticPart()
/*     */   {
/* 159 */     return this;
/*     */   }
/*     */   
/*     */   public String toShortString()
/*     */   {
/* 164 */     return "execution(" + getSignature().toShortString() + ")";
/*     */   }
/*     */   
/*     */   public String toLongString()
/*     */   {
/* 169 */     return "execution(" + getSignature().toLongString() + ")";
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 174 */     return "execution(" + getSignature().toString() + ")";
/*     */   }
/*     */   
/*     */ 
/*     */   private class MethodSignatureImpl
/*     */     implements MethodSignature
/*     */   {
/*     */     @Nullable
/*     */     private volatile String[] parameterNames;
/*     */     
/*     */     private MethodSignatureImpl() {}
/*     */     
/*     */     public String getName()
/*     */     {
/* 188 */       return MethodInvocationProceedingJoinPoint.this.methodInvocation.getMethod().getName();
/*     */     }
/*     */     
/*     */     public int getModifiers()
/*     */     {
/* 193 */       return MethodInvocationProceedingJoinPoint.this.methodInvocation.getMethod().getModifiers();
/*     */     }
/*     */     
/*     */     public Class<?> getDeclaringType()
/*     */     {
/* 198 */       return MethodInvocationProceedingJoinPoint.this.methodInvocation.getMethod().getDeclaringClass();
/*     */     }
/*     */     
/*     */     public String getDeclaringTypeName()
/*     */     {
/* 203 */       return MethodInvocationProceedingJoinPoint.this.methodInvocation.getMethod().getDeclaringClass().getName();
/*     */     }
/*     */     
/*     */     public Class<?> getReturnType()
/*     */     {
/* 208 */       return MethodInvocationProceedingJoinPoint.this.methodInvocation.getMethod().getReturnType();
/*     */     }
/*     */     
/*     */     public Method getMethod()
/*     */     {
/* 213 */       return MethodInvocationProceedingJoinPoint.this.methodInvocation.getMethod();
/*     */     }
/*     */     
/*     */     public Class<?>[] getParameterTypes()
/*     */     {
/* 218 */       return MethodInvocationProceedingJoinPoint.this.methodInvocation.getMethod().getParameterTypes();
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     public String[] getParameterNames()
/*     */     {
/* 224 */       String[] parameterNames = this.parameterNames;
/* 225 */       if (parameterNames == null) {
/* 226 */         parameterNames = MethodInvocationProceedingJoinPoint.parameterNameDiscoverer.getParameterNames(getMethod());
/* 227 */         this.parameterNames = parameterNames;
/*     */       }
/* 229 */       return parameterNames;
/*     */     }
/*     */     
/*     */     public Class<?>[] getExceptionTypes()
/*     */     {
/* 234 */       return MethodInvocationProceedingJoinPoint.this.methodInvocation.getMethod().getExceptionTypes();
/*     */     }
/*     */     
/*     */     public String toShortString()
/*     */     {
/* 239 */       return toString(false, false, false, false);
/*     */     }
/*     */     
/*     */     public String toLongString()
/*     */     {
/* 244 */       return toString(true, true, true, true);
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/* 249 */       return toString(false, true, false, true);
/*     */     }
/*     */     
/*     */ 
/*     */     private String toString(boolean includeModifier, boolean includeReturnTypeAndArgs, boolean useLongReturnAndArgumentTypeName, boolean useLongTypeName)
/*     */     {
/* 255 */       StringBuilder sb = new StringBuilder();
/* 256 */       if (includeModifier) {
/* 257 */         sb.append(Modifier.toString(getModifiers()));
/* 258 */         sb.append(' ');
/*     */       }
/* 260 */       if (includeReturnTypeAndArgs) {
/* 261 */         appendType(sb, getReturnType(), useLongReturnAndArgumentTypeName);
/* 262 */         sb.append(' ');
/*     */       }
/* 264 */       appendType(sb, getDeclaringType(), useLongTypeName);
/* 265 */       sb.append('.');
/* 266 */       sb.append(getMethod().getName());
/* 267 */       sb.append('(');
/* 268 */       Class<?>[] parametersTypes = getParameterTypes();
/* 269 */       appendTypes(sb, parametersTypes, includeReturnTypeAndArgs, useLongReturnAndArgumentTypeName);
/* 270 */       sb.append(')');
/* 271 */       return sb.toString();
/*     */     }
/*     */     
/*     */ 
/*     */     private void appendTypes(StringBuilder sb, Class<?>[] types, boolean includeArgs, boolean useLongReturnAndArgumentTypeName)
/*     */     {
/* 277 */       if (includeArgs) {
/* 278 */         int size = types.length; for (int i = 0; i < size; i++) {
/* 279 */           appendType(sb, types[i], useLongReturnAndArgumentTypeName);
/* 280 */           if (i < size - 1) {
/* 281 */             sb.append(',');
/*     */           }
/*     */           
/*     */         }
/*     */       }
/* 286 */       else if (types.length != 0) {
/* 287 */         sb.append("..");
/*     */       }
/*     */     }
/*     */     
/*     */     private void appendType(StringBuilder sb, Class<?> type, boolean useLongTypeName)
/*     */     {
/* 293 */       if (type.isArray()) {
/* 294 */         appendType(sb, type.getComponentType(), useLongTypeName);
/* 295 */         sb.append("[]");
/*     */       }
/*     */       else {
/* 298 */         sb.append(useLongTypeName ? type.getName() : type.getSimpleName());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private class SourceLocationImpl
/*     */     implements SourceLocation
/*     */   {
/*     */     private SourceLocationImpl() {}
/*     */     
/*     */     public Class<?> getWithinType()
/*     */     {
/* 311 */       if (MethodInvocationProceedingJoinPoint.this.methodInvocation.getThis() == null) {
/* 312 */         throw new UnsupportedOperationException("No source location joinpoint available: target is null");
/*     */       }
/* 314 */       return MethodInvocationProceedingJoinPoint.this.methodInvocation.getThis().getClass();
/*     */     }
/*     */     
/*     */     public String getFileName()
/*     */     {
/* 319 */       throw new UnsupportedOperationException();
/*     */     }
/*     */     
/*     */     public int getLine()
/*     */     {
/* 324 */       throw new UnsupportedOperationException();
/*     */     }
/*     */     
/*     */     @Deprecated
/*     */     public int getColumn()
/*     */     {
/* 330 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-aop-5.3.12.jar!\org\springframework\aop\aspectj\MethodInvocationProceedingJoinPoint.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */