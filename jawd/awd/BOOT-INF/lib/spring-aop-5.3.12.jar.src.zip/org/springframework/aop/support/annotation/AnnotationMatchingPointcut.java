/*     */ package org.springframework.aop.support.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import org.springframework.aop.ClassFilter;
/*     */ import org.springframework.aop.MethodMatcher;
/*     */ import org.springframework.aop.Pointcut;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnnotationMatchingPointcut
/*     */   implements Pointcut
/*     */ {
/*     */   private final ClassFilter classFilter;
/*     */   private final MethodMatcher methodMatcher;
/*     */   
/*     */   public AnnotationMatchingPointcut(Class<? extends Annotation> classAnnotationType)
/*     */   {
/*  51 */     this(classAnnotationType, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AnnotationMatchingPointcut(Class<? extends Annotation> classAnnotationType, boolean checkInherited)
/*     */   {
/*  62 */     this.classFilter = new AnnotationClassFilter(classAnnotationType, checkInherited);
/*  63 */     this.methodMatcher = MethodMatcher.TRUE;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AnnotationMatchingPointcut(@Nullable Class<? extends Annotation> classAnnotationType, @Nullable Class<? extends Annotation> methodAnnotationType)
/*     */   {
/*  76 */     this(classAnnotationType, methodAnnotationType, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AnnotationMatchingPointcut(@Nullable Class<? extends Annotation> classAnnotationType, @Nullable Class<? extends Annotation> methodAnnotationType, boolean checkInherited)
/*     */   {
/*  94 */     Assert.isTrue((classAnnotationType != null) || (methodAnnotationType != null), "Either Class annotation type or Method annotation type needs to be specified (or both)");
/*     */     
/*     */ 
/*  97 */     if (classAnnotationType != null) {
/*  98 */       this.classFilter = new AnnotationClassFilter(classAnnotationType, checkInherited);
/*     */     }
/*     */     else {
/* 101 */       this.classFilter = new AnnotationCandidateClassFilter(methodAnnotationType);
/*     */     }
/*     */     
/* 104 */     if (methodAnnotationType != null) {
/* 105 */       this.methodMatcher = new AnnotationMethodMatcher(methodAnnotationType, checkInherited);
/*     */     }
/*     */     else {
/* 108 */       this.methodMatcher = MethodMatcher.TRUE;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public ClassFilter getClassFilter()
/*     */   {
/* 115 */     return this.classFilter;
/*     */   }
/*     */   
/*     */   public MethodMatcher getMethodMatcher()
/*     */   {
/* 120 */     return this.methodMatcher;
/*     */   }
/*     */   
/*     */   public boolean equals(@Nullable Object other)
/*     */   {
/* 125 */     if (this == other) {
/* 126 */       return true;
/*     */     }
/* 128 */     if (!(other instanceof AnnotationMatchingPointcut)) {
/* 129 */       return false;
/*     */     }
/* 131 */     AnnotationMatchingPointcut otherPointcut = (AnnotationMatchingPointcut)other;
/* 132 */     return (this.classFilter.equals(otherPointcut.classFilter)) && 
/* 133 */       (this.methodMatcher.equals(otherPointcut.methodMatcher));
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 138 */     return this.classFilter.hashCode() * 37 + this.methodMatcher.hashCode();
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 143 */     return "AnnotationMatchingPointcut: " + this.classFilter + ", " + this.methodMatcher;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static AnnotationMatchingPointcut forClassAnnotation(Class<? extends Annotation> annotationType)
/*     */   {
/* 153 */     Assert.notNull(annotationType, "Annotation type must not be null");
/* 154 */     return new AnnotationMatchingPointcut(annotationType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static AnnotationMatchingPointcut forMethodAnnotation(Class<? extends Annotation> annotationType)
/*     */   {
/* 164 */     Assert.notNull(annotationType, "Annotation type must not be null");
/* 165 */     return new AnnotationMatchingPointcut(null, annotationType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static class AnnotationCandidateClassFilter
/*     */     implements ClassFilter
/*     */   {
/*     */     private final Class<? extends Annotation> annotationType;
/*     */     
/*     */ 
/*     */ 
/*     */     AnnotationCandidateClassFilter(Class<? extends Annotation> annotationType)
/*     */     {
/* 179 */       this.annotationType = annotationType;
/*     */     }
/*     */     
/*     */     public boolean matches(Class<?> clazz)
/*     */     {
/* 184 */       return AnnotationUtils.isCandidateClass(clazz, this.annotationType);
/*     */     }
/*     */     
/*     */     public boolean equals(Object obj)
/*     */     {
/* 189 */       if (this == obj) {
/* 190 */         return true;
/*     */       }
/* 192 */       if (!(obj instanceof AnnotationCandidateClassFilter)) {
/* 193 */         return false;
/*     */       }
/* 195 */       AnnotationCandidateClassFilter that = (AnnotationCandidateClassFilter)obj;
/* 196 */       return this.annotationType.equals(that.annotationType);
/*     */     }
/*     */     
/*     */     public int hashCode()
/*     */     {
/* 201 */       return this.annotationType.hashCode();
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/* 206 */       return getClass().getName() + ": " + this.annotationType;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-aop-5.3.12.jar!\org\springframework\aop\support\annotation\AnnotationMatchingPointcut.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */