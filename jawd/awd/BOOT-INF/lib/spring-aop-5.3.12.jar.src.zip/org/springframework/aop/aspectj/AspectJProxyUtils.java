/*    */ package org.springframework.aop.aspectj;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.springframework.aop.Advisor;
/*    */ import org.springframework.aop.PointcutAdvisor;
/*    */ import org.springframework.aop.interceptor.ExposeInvocationInterceptor;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AspectJProxyUtils
/*    */ {
/*    */   public static boolean makeAdvisorChainAspectJCapableIfNecessary(List<Advisor> advisors)
/*    */   {
/* 49 */     if (!advisors.isEmpty()) {
/* 50 */       boolean foundAspectJAdvice = false;
/* 51 */       for (Advisor advisor : advisors)
/*    */       {
/*    */ 
/* 54 */         if (isAspectJAdvice(advisor)) {
/* 55 */           foundAspectJAdvice = true;
/* 56 */           break;
/*    */         }
/*    */       }
/* 59 */       if ((foundAspectJAdvice) && (!advisors.contains(ExposeInvocationInterceptor.ADVISOR))) {
/* 60 */         advisors.add(0, ExposeInvocationInterceptor.ADVISOR);
/* 61 */         return true;
/*    */       }
/*    */     }
/* 64 */     return false;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   private static boolean isAspectJAdvice(Advisor advisor)
/*    */   {
/* 72 */     if ((!(advisor instanceof InstantiationModelAwarePointcutAdvisor)) && 
/* 73 */       (!(advisor.getAdvice() instanceof AbstractAspectJAdvice))) if (!(advisor instanceof PointcutAdvisor)) {
/*    */         break label45;
/*    */       }
/*    */     label45:
/* 72 */     return 
/*    */     
/*    */ 
/* 75 */       (((PointcutAdvisor)advisor).getPointcut() instanceof AspectJExpressionPointcut);
/*    */   }
/*    */   
/*    */   static boolean isVariableName(@Nullable String name) {
/* 79 */     if (!StringUtils.hasLength(name)) {
/* 80 */       return false;
/*    */     }
/* 82 */     if (!Character.isJavaIdentifierStart(name.charAt(0))) {
/* 83 */       return false;
/*    */     }
/* 85 */     for (int i = 1; i < name.length(); i++) {
/* 86 */       if (!Character.isJavaIdentifierPart(name.charAt(i))) {
/* 87 */         return false;
/*    */       }
/*    */     }
/* 90 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-aop-5.3.12.jar!\org\springframework\aop\aspectj\AspectJProxyUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */