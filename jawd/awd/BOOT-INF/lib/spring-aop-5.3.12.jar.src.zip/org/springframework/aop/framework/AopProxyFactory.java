package org.springframework.aop.framework;

public abstract interface AopProxyFactory
{
  public abstract AopProxy createAopProxy(AdvisedSupport paramAdvisedSupport)
    throws AopConfigException;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-aop-5.3.12.jar!\org\springframework\aop\framework\AopProxyFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */