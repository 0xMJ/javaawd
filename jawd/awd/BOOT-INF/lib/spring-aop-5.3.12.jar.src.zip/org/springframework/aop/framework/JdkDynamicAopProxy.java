/*     */ package org.springframework.aop.framework;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.util.List;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.aop.AopInvocationException;
/*     */ import org.springframework.aop.RawTargetAccess;
/*     */ import org.springframework.aop.TargetSource;
/*     */ import org.springframework.aop.support.AopUtils;
/*     */ import org.springframework.core.DecoratingProxy;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class JdkDynamicAopProxy
/*     */   implements AopProxy, InvocationHandler, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 5531744639992436476L;
/*  81 */   private static final Log logger = LogFactory.getLog(JdkDynamicAopProxy.class);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final AdvisedSupport advised;
/*     */   
/*     */ 
/*     */ 
/*     */   private final Class<?>[] proxiedInterfaces;
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean equalsDefined;
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean hashCodeDefined;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public JdkDynamicAopProxy(AdvisedSupport config)
/*     */     throws AopConfigException
/*     */   {
/* 106 */     Assert.notNull(config, "AdvisedSupport must not be null");
/* 107 */     if ((config.getAdvisorCount() == 0) && (config.getTargetSource() == AdvisedSupport.EMPTY_TARGET_SOURCE)) {
/* 108 */       throw new AopConfigException("No advisors and no TargetSource specified");
/*     */     }
/* 110 */     this.advised = config;
/* 111 */     this.proxiedInterfaces = AopProxyUtils.completeProxiedInterfaces(this.advised, true);
/* 112 */     findDefinedEqualsAndHashCodeMethods(this.proxiedInterfaces);
/*     */   }
/*     */   
/*     */ 
/*     */   public Object getProxy()
/*     */   {
/* 118 */     return getProxy(ClassUtils.getDefaultClassLoader());
/*     */   }
/*     */   
/*     */   public Object getProxy(@Nullable ClassLoader classLoader)
/*     */   {
/* 123 */     if (logger.isTraceEnabled()) {
/* 124 */       logger.trace("Creating JDK dynamic proxy: " + this.advised.getTargetSource());
/*     */     }
/* 126 */     return Proxy.newProxyInstance(classLoader, this.proxiedInterfaces, this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void findDefinedEqualsAndHashCodeMethods(Class<?>[] proxiedInterfaces)
/*     */   {
/* 135 */     for (Class<?> proxiedInterface : proxiedInterfaces) {
/* 136 */       Method[] methods = proxiedInterface.getDeclaredMethods();
/* 137 */       for (Method method : methods) {
/* 138 */         if (AopUtils.isEqualsMethod(method)) {
/* 139 */           this.equalsDefined = true;
/*     */         }
/* 141 */         if (AopUtils.isHashCodeMethod(method)) {
/* 142 */           this.hashCodeDefined = true;
/*     */         }
/* 144 */         if ((this.equalsDefined) && (this.hashCodeDefined)) {
/* 145 */           return;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public Object invoke(Object proxy, Method method, Object[] args)
/*     */     throws Throwable
/*     */   {
/* 160 */     Object oldProxy = null;
/* 161 */     boolean setProxyContext = false;
/*     */     
/* 163 */     TargetSource targetSource = this.advised.targetSource;
/* 164 */     Object target = null;
/*     */     try {
/*     */       Object localObject1;
/* 167 */       if ((!this.equalsDefined) && (AopUtils.isEqualsMethod(method)))
/*     */       {
/* 169 */         return Boolean.valueOf(equals(args[0]));
/*     */       }
/* 171 */       if ((!this.hashCodeDefined) && (AopUtils.isHashCodeMethod(method)))
/*     */       {
/* 173 */         return Integer.valueOf(hashCode());
/*     */       }
/* 175 */       if (method.getDeclaringClass() == DecoratingProxy.class)
/*     */       {
/* 177 */         return AopProxyUtils.ultimateTargetClass(this.advised);
/*     */       }
/* 179 */       if ((!this.advised.opaque) && (method.getDeclaringClass().isInterface()) && 
/* 180 */         (method.getDeclaringClass().isAssignableFrom(Advised.class)))
/*     */       {
/* 182 */         return AopUtils.invokeJoinpointUsingReflection(this.advised, method, args);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 187 */       if (this.advised.exposeProxy)
/*     */       {
/* 189 */         oldProxy = AopContext.setCurrentProxy(proxy);
/* 190 */         setProxyContext = true;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 195 */       target = targetSource.getTarget();
/* 196 */       Class<?> targetClass = target != null ? target.getClass() : null;
/*     */       
/*     */ 
/* 199 */       List<Object> chain = this.advised.getInterceptorsAndDynamicInterceptionAdvice(method, targetClass);
/*     */       
/*     */       Object retVal;
/*     */       Object retVal;
/* 203 */       if (chain.isEmpty())
/*     */       {
/*     */ 
/*     */ 
/* 207 */         Object[] argsToUse = AopProxyUtils.adaptArgumentsIfNecessary(method, args);
/* 208 */         retVal = AopUtils.invokeJoinpointUsingReflection(target, method, argsToUse);
/*     */       }
/*     */       else
/*     */       {
/* 212 */         MethodInvocation invocation = new ReflectiveMethodInvocation(proxy, target, method, args, targetClass, chain);
/*     */         
/*     */ 
/* 215 */         retVal = invocation.proceed();
/*     */       }
/*     */       
/*     */ 
/* 219 */       Class<?> returnType = method.getReturnType();
/* 220 */       if ((retVal != null) && (retVal == target) && (returnType != Object.class) && 
/* 221 */         (returnType.isInstance(proxy)) && 
/* 222 */         (!RawTargetAccess.class.isAssignableFrom(method.getDeclaringClass())))
/*     */       {
/*     */ 
/*     */ 
/* 226 */         retVal = proxy;
/*     */       }
/* 228 */       else if ((retVal == null) && (returnType != Void.TYPE) && (returnType.isPrimitive())) {
/* 229 */         throw new AopInvocationException("Null return value from advice does not match primitive return type for: " + method);
/*     */       }
/*     */       
/* 232 */       return retVal;
/*     */     }
/*     */     finally {
/* 235 */       if ((target != null) && (!targetSource.isStatic()))
/*     */       {
/* 237 */         targetSource.releaseTarget(target);
/*     */       }
/* 239 */       if (setProxyContext)
/*     */       {
/* 241 */         AopContext.setCurrentProxy(oldProxy);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(@Nullable Object other)
/*     */   {
/* 254 */     if (other == this) {
/* 255 */       return true;
/*     */     }
/* 257 */     if (other == null) {
/* 258 */       return false;
/*     */     }
/*     */     
/*     */     JdkDynamicAopProxy otherProxy;
/* 262 */     if ((other instanceof JdkDynamicAopProxy)) {
/* 263 */       otherProxy = (JdkDynamicAopProxy)other;
/*     */     } else { JdkDynamicAopProxy otherProxy;
/* 265 */       if (Proxy.isProxyClass(other.getClass())) {
/* 266 */         InvocationHandler ih = Proxy.getInvocationHandler(other);
/* 267 */         if (!(ih instanceof JdkDynamicAopProxy)) {
/* 268 */           return false;
/*     */         }
/* 270 */         otherProxy = (JdkDynamicAopProxy)ih;
/*     */       }
/*     */       else
/*     */       {
/* 274 */         return false;
/*     */       }
/*     */     }
/*     */     JdkDynamicAopProxy otherProxy;
/* 278 */     return AopProxyUtils.equalsInProxy(this.advised, otherProxy.advised);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 286 */     return JdkDynamicAopProxy.class.hashCode() * 13 + this.advised.getTargetSource().hashCode();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-aop-5.3.12.jar!\org\springframework\aop\framework\JdkDynamicAopProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */