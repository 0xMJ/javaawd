package org.springframework.aop.framework;

public abstract interface AdvisedSupportListener
{
  public abstract void activated(AdvisedSupport paramAdvisedSupport);
  
  public abstract void adviceChanged(AdvisedSupport paramAdvisedSupport);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-aop-5.3.12.jar!\org\springframework\aop\framework\AdvisedSupportListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */