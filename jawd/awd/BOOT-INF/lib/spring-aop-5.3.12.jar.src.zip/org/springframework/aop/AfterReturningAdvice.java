package org.springframework.aop;

import java.lang.reflect.Method;
import org.springframework.lang.Nullable;

public abstract interface AfterReturningAdvice
  extends AfterAdvice
{
  public abstract void afterReturning(@Nullable Object paramObject1, Method paramMethod, Object[] paramArrayOfObject, @Nullable Object paramObject2)
    throws Throwable;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-aop-5.3.12.jar!\org\springframework\aop\AfterReturningAdvice.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */