/*     */ package org.springframework.aop.interceptor;
/*     */ 
/*     */ import org.aopalliance.intercept.MethodInterceptor;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.springframework.aop.Advisor;
/*     */ import org.springframework.aop.ProxyMethodInvocation;
/*     */ import org.springframework.aop.support.DefaultIntroductionAdvisor;
/*     */ import org.springframework.aop.support.DefaultPointcutAdvisor;
/*     */ import org.springframework.aop.support.DelegatingIntroductionInterceptor;
/*     */ import org.springframework.beans.factory.NamedBean;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ExposeBeanNameAdvisors
/*     */ {
/*  49 */   private static final String BEAN_NAME_ATTRIBUTE = ExposeBeanNameAdvisors.class.getName() + ".BEAN_NAME";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getBeanName()
/*     */     throws IllegalStateException
/*     */   {
/*  60 */     return getBeanName(ExposeInvocationInterceptor.currentInvocation());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getBeanName(MethodInvocation mi)
/*     */     throws IllegalStateException
/*     */   {
/*  71 */     if (!(mi instanceof ProxyMethodInvocation)) {
/*  72 */       throw new IllegalArgumentException("MethodInvocation is not a Spring ProxyMethodInvocation: " + mi);
/*     */     }
/*  74 */     ProxyMethodInvocation pmi = (ProxyMethodInvocation)mi;
/*  75 */     String beanName = (String)pmi.getUserAttribute(BEAN_NAME_ATTRIBUTE);
/*  76 */     if (beanName == null) {
/*  77 */       throw new IllegalStateException("Cannot get bean name; not set on MethodInvocation: " + mi);
/*     */     }
/*  79 */     return beanName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Advisor createAdvisorWithoutIntroduction(String beanName)
/*     */   {
/*  88 */     return new DefaultPointcutAdvisor(new ExposeBeanNameInterceptor(beanName));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Advisor createAdvisorIntroducingNamedBean(String beanName)
/*     */   {
/*  98 */     return new DefaultIntroductionAdvisor(new ExposeBeanNameIntroduction(beanName));
/*     */   }
/*     */   
/*     */ 
/*     */   private static class ExposeBeanNameInterceptor
/*     */     implements MethodInterceptor
/*     */   {
/*     */     private final String beanName;
/*     */     
/*     */ 
/*     */     public ExposeBeanNameInterceptor(String beanName)
/*     */     {
/* 110 */       this.beanName = beanName;
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     public Object invoke(MethodInvocation mi) throws Throwable
/*     */     {
/* 116 */       if (!(mi instanceof ProxyMethodInvocation)) {
/* 117 */         throw new IllegalStateException("MethodInvocation is not a Spring ProxyMethodInvocation: " + mi);
/*     */       }
/* 119 */       ProxyMethodInvocation pmi = (ProxyMethodInvocation)mi;
/* 120 */       pmi.setUserAttribute(ExposeBeanNameAdvisors.BEAN_NAME_ATTRIBUTE, this.beanName);
/* 121 */       return mi.proceed();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static class ExposeBeanNameIntroduction
/*     */     extends DelegatingIntroductionInterceptor
/*     */     implements NamedBean
/*     */   {
/*     */     private final String beanName;
/*     */     
/*     */ 
/*     */     public ExposeBeanNameIntroduction(String beanName)
/*     */     {
/* 135 */       this.beanName = beanName;
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     public Object invoke(MethodInvocation mi) throws Throwable
/*     */     {
/* 141 */       if (!(mi instanceof ProxyMethodInvocation)) {
/* 142 */         throw new IllegalStateException("MethodInvocation is not a Spring ProxyMethodInvocation: " + mi);
/*     */       }
/* 144 */       ProxyMethodInvocation pmi = (ProxyMethodInvocation)mi;
/* 145 */       pmi.setUserAttribute(ExposeBeanNameAdvisors.BEAN_NAME_ATTRIBUTE, this.beanName);
/* 146 */       return super.invoke(mi);
/*     */     }
/*     */     
/*     */     public String getBeanName()
/*     */     {
/* 151 */       return this.beanName;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-aop-5.3.12.jar!\org\springframework\aop\interceptor\ExposeBeanNameAdvisors.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */