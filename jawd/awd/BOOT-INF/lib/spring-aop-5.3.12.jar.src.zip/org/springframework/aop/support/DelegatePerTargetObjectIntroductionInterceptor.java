/*     */ package org.springframework.aop.support;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.Map;
/*     */ import java.util.WeakHashMap;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.springframework.aop.DynamicIntroductionAdvice;
/*     */ import org.springframework.aop.IntroductionInterceptor;
/*     */ import org.springframework.aop.ProxyMethodInvocation;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DelegatePerTargetObjectIntroductionInterceptor
/*     */   extends IntroductionInfoSupport
/*     */   implements IntroductionInterceptor
/*     */ {
/*  62 */   private final Map<Object, Object> delegateMap = new WeakHashMap();
/*     */   
/*     */   private Class<?> defaultImplType;
/*     */   
/*     */   private Class<?> interfaceType;
/*     */   
/*     */   public DelegatePerTargetObjectIntroductionInterceptor(Class<?> defaultImplType, Class<?> interfaceType)
/*     */   {
/*  70 */     this.defaultImplType = defaultImplType;
/*  71 */     this.interfaceType = interfaceType;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  76 */     Object delegate = createNewDelegate();
/*  77 */     implementInterfacesOnObject(delegate);
/*  78 */     suppressInterface(IntroductionInterceptor.class);
/*  79 */     suppressInterface(DynamicIntroductionAdvice.class);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public Object invoke(MethodInvocation mi)
/*     */     throws Throwable
/*     */   {
/*  91 */     if (isMethodOnIntroducedInterface(mi)) {
/*  92 */       Object delegate = getIntroductionDelegateFor(mi.getThis());
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*  97 */       Object retVal = AopUtils.invokeJoinpointUsingReflection(delegate, mi.getMethod(), mi.getArguments());
/*     */       
/*     */ 
/*     */ 
/* 101 */       if ((retVal == delegate) && ((mi instanceof ProxyMethodInvocation))) {
/* 102 */         retVal = ((ProxyMethodInvocation)mi).getProxy();
/*     */       }
/* 104 */       return retVal;
/*     */     }
/*     */     
/* 107 */     return doProceed(mi);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected Object doProceed(MethodInvocation mi)
/*     */     throws Throwable
/*     */   {
/* 120 */     return mi.proceed();
/*     */   }
/*     */   
/*     */   private Object getIntroductionDelegateFor(@Nullable Object targetObject) {
/* 124 */     synchronized (this.delegateMap) {
/* 125 */       if (this.delegateMap.containsKey(targetObject)) {
/* 126 */         return this.delegateMap.get(targetObject);
/*     */       }
/*     */       
/* 129 */       Object delegate = createNewDelegate();
/* 130 */       this.delegateMap.put(targetObject, delegate);
/* 131 */       return delegate;
/*     */     }
/*     */   }
/*     */   
/*     */   private Object createNewDelegate()
/*     */   {
/*     */     try {
/* 138 */       return ReflectionUtils.accessibleConstructor(this.defaultImplType, new Class[0]).newInstance(new Object[0]);
/*     */     }
/*     */     catch (Throwable ex)
/*     */     {
/* 142 */       throw new IllegalArgumentException("Cannot create default implementation for '" + this.interfaceType.getName() + "' mixin (" + this.defaultImplType.getName() + "): " + ex);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-aop-5.3.12.jar!\org\springframework\aop\support\DelegatePerTargetObjectIntroductionInterceptor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */