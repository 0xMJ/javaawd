/*     */ package org.springframework.aop.framework;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.aopalliance.aop.Advice;
/*     */ import org.aopalliance.intercept.Interceptor;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.aop.Advisor;
/*     */ import org.springframework.aop.TargetSource;
/*     */ import org.springframework.aop.framework.adapter.AdvisorAdapterRegistry;
/*     */ import org.springframework.aop.framework.adapter.GlobalAdvisorAdapterRegistry;
/*     */ import org.springframework.aop.framework.adapter.UnknownAdviceTypeException;
/*     */ import org.springframework.aop.target.SingletonTargetSource;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.BeanFactoryUtils;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.FactoryBeanNotInitializedException;
/*     */ import org.springframework.beans.factory.ListableBeanFactory;
/*     */ import org.springframework.core.annotation.AnnotationAwareOrderComparator;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProxyFactoryBean
/*     */   extends ProxyCreatorSupport
/*     */   implements FactoryBean<Object>, BeanClassLoaderAware, BeanFactoryAware
/*     */ {
/*     */   public static final String GLOBAL_SUFFIX = "*";
/* 101 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/*     */   @Nullable
/*     */   private String[] interceptorNames;
/*     */   
/*     */   @Nullable
/*     */   private String targetName;
/*     */   
/* 109 */   private boolean autodetectInterfaces = true;
/*     */   
/* 111 */   private boolean singleton = true;
/*     */   
/* 113 */   private AdvisorAdapterRegistry advisorAdapterRegistry = GlobalAdvisorAdapterRegistry.getInstance();
/*     */   
/* 115 */   private boolean freezeProxy = false;
/*     */   
/*     */   @Nullable
/* 118 */   private transient ClassLoader proxyClassLoader = ClassUtils.getDefaultClassLoader();
/*     */   
/* 120 */   private transient boolean classLoaderConfigured = false;
/*     */   
/*     */ 
/*     */   @Nullable
/*     */   private transient BeanFactory beanFactory;
/*     */   
/* 126 */   private boolean advisorChainInitialized = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   private Object singletonInstance;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setProxyInterfaces(Class<?>[] proxyInterfaces)
/*     */     throws ClassNotFoundException
/*     */   {
/* 142 */     setInterfaces(proxyInterfaces);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setInterceptorNames(String... interceptorNames)
/*     */   {
/* 163 */     this.interceptorNames = interceptorNames;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTargetName(String targetName)
/*     */   {
/* 176 */     this.targetName = targetName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAutodetectInterfaces(boolean autodetectInterfaces)
/*     */   {
/* 186 */     this.autodetectInterfaces = autodetectInterfaces;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSingleton(boolean singleton)
/*     */   {
/* 198 */     this.singleton = singleton;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAdvisorAdapterRegistry(AdvisorAdapterRegistry advisorAdapterRegistry)
/*     */   {
/* 207 */     this.advisorAdapterRegistry = advisorAdapterRegistry;
/*     */   }
/*     */   
/*     */   public void setFrozen(boolean frozen)
/*     */   {
/* 212 */     this.freezeProxy = frozen;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setProxyClassLoader(@Nullable ClassLoader classLoader)
/*     */   {
/* 222 */     this.proxyClassLoader = classLoader;
/* 223 */     this.classLoaderConfigured = (classLoader != null);
/*     */   }
/*     */   
/*     */   public void setBeanClassLoader(ClassLoader classLoader)
/*     */   {
/* 228 */     if (!this.classLoaderConfigured) {
/* 229 */       this.proxyClassLoader = classLoader;
/*     */     }
/*     */   }
/*     */   
/*     */   public void setBeanFactory(BeanFactory beanFactory)
/*     */   {
/* 235 */     this.beanFactory = beanFactory;
/* 236 */     checkInterceptorNames();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public Object getObject()
/*     */     throws BeansException
/*     */   {
/* 250 */     initializeAdvisorChain();
/* 251 */     if (isSingleton()) {
/* 252 */       return getSingletonInstance();
/*     */     }
/*     */     
/* 255 */     if (this.targetName == null) {
/* 256 */       this.logger.info("Using non-singleton proxies with singleton targets is often undesirable. Enable prototype proxies by setting the 'targetName' property.");
/*     */     }
/*     */     
/* 259 */     return newPrototypeInstance();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Class<?> getObjectType()
/*     */   {
/* 271 */     synchronized (this) {
/* 272 */       if (this.singletonInstance != null) {
/* 273 */         return this.singletonInstance.getClass();
/*     */       }
/*     */     }
/* 276 */     Class<?>[] ifcs = getProxiedInterfaces();
/* 277 */     if (ifcs.length == 1) {
/* 278 */       return ifcs[0];
/*     */     }
/* 280 */     if (ifcs.length > 1) {
/* 281 */       return createCompositeInterface(ifcs);
/*     */     }
/* 283 */     if ((this.targetName != null) && (this.beanFactory != null)) {
/* 284 */       return this.beanFactory.getType(this.targetName);
/*     */     }
/*     */     
/* 287 */     return getTargetClass();
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isSingleton()
/*     */   {
/* 293 */     return this.singleton;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Class<?> createCompositeInterface(Class<?>[] interfaces)
/*     */   {
/* 307 */     return ClassUtils.createCompositeInterface(interfaces, this.proxyClassLoader);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private synchronized Object getSingletonInstance()
/*     */   {
/* 316 */     if (this.singletonInstance == null) {
/* 317 */       this.targetSource = freshTargetSource();
/* 318 */       if ((this.autodetectInterfaces) && (getProxiedInterfaces().length == 0) && (!isProxyTargetClass()))
/*     */       {
/* 320 */         Class<?> targetClass = getTargetClass();
/* 321 */         if (targetClass == null) {
/* 322 */           throw new FactoryBeanNotInitializedException("Cannot determine target class for proxy");
/*     */         }
/* 324 */         setInterfaces(ClassUtils.getAllInterfacesForClass(targetClass, this.proxyClassLoader));
/*     */       }
/*     */       
/* 327 */       super.setFrozen(this.freezeProxy);
/* 328 */       this.singletonInstance = getProxy(createAopProxy());
/*     */     }
/* 330 */     return this.singletonInstance;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private synchronized Object newPrototypeInstance()
/*     */   {
/* 343 */     ProxyCreatorSupport copy = new ProxyCreatorSupport(getAopProxyFactory());
/*     */     
/*     */ 
/* 346 */     TargetSource targetSource = freshTargetSource();
/* 347 */     copy.copyConfigurationFrom(this, targetSource, freshAdvisorChain());
/* 348 */     if ((this.autodetectInterfaces) && (getProxiedInterfaces().length == 0) && (!isProxyTargetClass()))
/*     */     {
/* 350 */       Class<?> targetClass = targetSource.getTargetClass();
/* 351 */       if (targetClass != null) {
/* 352 */         copy.setInterfaces(ClassUtils.getAllInterfacesForClass(targetClass, this.proxyClassLoader));
/*     */       }
/*     */     }
/* 355 */     copy.setFrozen(this.freezeProxy);
/*     */     
/* 357 */     return getProxy(copy.createAopProxy());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Object getProxy(AopProxy aopProxy)
/*     */   {
/* 370 */     return aopProxy.getProxy(this.proxyClassLoader);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void checkInterceptorNames()
/*     */   {
/* 378 */     if (!ObjectUtils.isEmpty(this.interceptorNames)) {
/* 379 */       String finalName = this.interceptorNames[(this.interceptorNames.length - 1)];
/* 380 */       if ((this.targetName == null) && (this.targetSource == EMPTY_TARGET_SOURCE))
/*     */       {
/*     */ 
/* 383 */         if ((!finalName.endsWith("*")) && (!isNamedBeanAnAdvisorOrAdvice(finalName)))
/*     */         {
/* 385 */           this.targetName = finalName;
/* 386 */           if (this.logger.isDebugEnabled()) {
/* 387 */             this.logger.debug("Bean with name '" + finalName + "' concluding interceptor chain is not an advisor class: treating it as a target or TargetSource");
/*     */           }
/*     */           
/* 390 */           this.interceptorNames = ((String[])Arrays.copyOf(this.interceptorNames, this.interceptorNames.length - 1));
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean isNamedBeanAnAdvisorOrAdvice(String beanName)
/*     */   {
/* 404 */     Assert.state(this.beanFactory != null, "No BeanFactory set");
/* 405 */     Class<?> namedBeanClass = this.beanFactory.getType(beanName);
/* 406 */     if (namedBeanClass != null) {
/* 407 */       return (Advisor.class.isAssignableFrom(namedBeanClass)) || (Advice.class.isAssignableFrom(namedBeanClass));
/*     */     }
/*     */     
/* 410 */     if (this.logger.isDebugEnabled()) {
/* 411 */       this.logger.debug("Could not determine type of bean with name '" + beanName + "' - assuming it is neither an Advisor nor an Advice");
/*     */     }
/*     */     
/* 414 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private synchronized void initializeAdvisorChain()
/*     */     throws AopConfigException, BeansException
/*     */   {
/* 424 */     if (this.advisorChainInitialized) {
/* 425 */       return;
/*     */     }
/*     */     
/* 428 */     if (!ObjectUtils.isEmpty(this.interceptorNames)) {
/* 429 */       if (this.beanFactory == null)
/*     */       {
/* 431 */         throw new IllegalStateException("No BeanFactory available anymore (probably due to serialization) - cannot resolve interceptor names " + Arrays.asList(this.interceptorNames));
/*     */       }
/*     */       
/*     */ 
/* 435 */       if ((this.interceptorNames[(this.interceptorNames.length - 1)].endsWith("*")) && (this.targetName == null) && (this.targetSource == EMPTY_TARGET_SOURCE))
/*     */       {
/* 437 */         throw new AopConfigException("Target required after globals");
/*     */       }
/*     */       
/*     */ 
/* 441 */       for (String name : this.interceptorNames) {
/* 442 */         if (name.endsWith("*")) {
/* 443 */           if (!(this.beanFactory instanceof ListableBeanFactory)) {
/* 444 */             throw new AopConfigException("Can only use global advisors or interceptors with a ListableBeanFactory");
/*     */           }
/*     */           
/* 447 */           addGlobalAdvisors((ListableBeanFactory)this.beanFactory, name
/* 448 */             .substring(0, name.length() - "*".length()));
/*     */         }
/*     */         else
/*     */         {
/*     */           Object advice;
/*     */           
/*     */           Object advice;
/* 455 */           if ((this.singleton) || (this.beanFactory.isSingleton(name)))
/*     */           {
/* 457 */             advice = this.beanFactory.getBean(name);
/*     */ 
/*     */           }
/*     */           else
/*     */           {
/* 462 */             advice = new PrototypePlaceholderAdvisor(name);
/*     */           }
/* 464 */           addAdvisorOnChainCreation(advice);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 469 */     this.advisorChainInitialized = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private List<Advisor> freshAdvisorChain()
/*     */   {
/* 479 */     Advisor[] advisors = getAdvisors();
/* 480 */     List<Advisor> freshAdvisors = new ArrayList(advisors.length);
/* 481 */     for (Advisor advisor : advisors) {
/* 482 */       if ((advisor instanceof PrototypePlaceholderAdvisor)) {
/* 483 */         PrototypePlaceholderAdvisor pa = (PrototypePlaceholderAdvisor)advisor;
/* 484 */         if (this.logger.isDebugEnabled()) {
/* 485 */           this.logger.debug("Refreshing bean named '" + pa.getBeanName() + "'");
/*     */         }
/*     */         
/* 488 */         if (this.beanFactory == null)
/*     */         {
/* 490 */           throw new IllegalStateException("No BeanFactory available anymore (probably due to serialization) - cannot resolve prototype advisor '" + pa.getBeanName() + "'");
/*     */         }
/* 492 */         Object bean = this.beanFactory.getBean(pa.getBeanName());
/* 493 */         Advisor refreshedAdvisor = namedBeanToAdvisor(bean);
/* 494 */         freshAdvisors.add(refreshedAdvisor);
/*     */       }
/*     */       else
/*     */       {
/* 498 */         freshAdvisors.add(advisor);
/*     */       }
/*     */     }
/* 501 */     return freshAdvisors;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void addGlobalAdvisors(ListableBeanFactory beanFactory, String prefix)
/*     */   {
/* 509 */     String[] globalAdvisorNames = BeanFactoryUtils.beanNamesForTypeIncludingAncestors(beanFactory, Advisor.class);
/*     */     
/* 511 */     String[] globalInterceptorNames = BeanFactoryUtils.beanNamesForTypeIncludingAncestors(beanFactory, Interceptor.class);
/* 512 */     if ((globalAdvisorNames.length > 0) || (globalInterceptorNames.length > 0)) {
/* 513 */       List<Object> beans = new ArrayList(globalAdvisorNames.length + globalInterceptorNames.length);
/* 514 */       for (String name : globalAdvisorNames) {
/* 515 */         if (name.startsWith(prefix)) {
/* 516 */           beans.add(beanFactory.getBean(name));
/*     */         }
/*     */       }
/* 519 */       for (String name : globalInterceptorNames) {
/* 520 */         if (name.startsWith(prefix)) {
/* 521 */           beans.add(beanFactory.getBean(name));
/*     */         }
/*     */       }
/* 524 */       AnnotationAwareOrderComparator.sort(beans);
/* 525 */       for (??? = beans.iterator(); ((Iterator)???).hasNext();) { Object bean = ((Iterator)???).next();
/* 526 */         addAdvisorOnChainCreation(bean);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void addAdvisorOnChainCreation(Object next)
/*     */   {
/* 541 */     addAdvisor(namedBeanToAdvisor(next));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private TargetSource freshTargetSource()
/*     */   {
/* 551 */     if (this.targetName == null)
/*     */     {
/* 553 */       return this.targetSource;
/*     */     }
/*     */     
/* 556 */     if (this.beanFactory == null) {
/* 557 */       throw new IllegalStateException("No BeanFactory available anymore (probably due to serialization) - cannot resolve target with name '" + this.targetName + "'");
/*     */     }
/*     */     
/* 560 */     if (this.logger.isDebugEnabled()) {
/* 561 */       this.logger.debug("Refreshing target with name '" + this.targetName + "'");
/*     */     }
/* 563 */     Object target = this.beanFactory.getBean(this.targetName);
/* 564 */     return (target instanceof TargetSource) ? (TargetSource)target : new SingletonTargetSource(target);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private Advisor namedBeanToAdvisor(Object next)
/*     */   {
/*     */     try
/*     */     {
/* 574 */       return this.advisorAdapterRegistry.wrap(next);
/*     */ 
/*     */     }
/*     */     catch (UnknownAdviceTypeException ex)
/*     */     {
/* 579 */       throw new AopConfigException("Unknown advisor type " + next.getClass() + "; can only include Advisor or Advice type beans in interceptorNames chain except for last entry which may also be target instance or TargetSource", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void adviceChanged()
/*     */   {
/* 590 */     super.adviceChanged();
/* 591 */     if (this.singleton) {
/* 592 */       this.logger.debug("Advice has changed; re-caching singleton instance");
/* 593 */       synchronized (this) {
/* 594 */         this.singletonInstance = null;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void readObject(ObjectInputStream ois)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 606 */     ois.defaultReadObject();
/*     */     
/*     */ 
/* 609 */     this.proxyClassLoader = ClassUtils.getDefaultClassLoader();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static class PrototypePlaceholderAdvisor
/*     */     implements Advisor, Serializable
/*     */   {
/*     */     private final String beanName;
/*     */     
/*     */     private final String message;
/*     */     
/*     */ 
/*     */     public PrototypePlaceholderAdvisor(String beanName)
/*     */     {
/* 624 */       this.beanName = beanName;
/* 625 */       this.message = ("Placeholder for prototype Advisor/Advice with bean name '" + beanName + "'");
/*     */     }
/*     */     
/*     */     public String getBeanName() {
/* 629 */       return this.beanName;
/*     */     }
/*     */     
/*     */     public Advice getAdvice()
/*     */     {
/* 634 */       throw new UnsupportedOperationException("Cannot invoke methods: " + this.message);
/*     */     }
/*     */     
/*     */     public boolean isPerInstance()
/*     */     {
/* 639 */       throw new UnsupportedOperationException("Cannot invoke methods: " + this.message);
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/* 644 */       return this.message;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-aop-5.3.12.jar!\org\springframework\aop\framework\ProxyFactoryBean.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */