/*    */ package org.springframework.aop.support;
/*    */ 
/*    */ import org.springframework.aop.Pointcut;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultBeanFactoryPointcutAdvisor
/*    */   extends AbstractBeanFactoryPointcutAdvisor
/*    */ {
/* 39 */   private Pointcut pointcut = Pointcut.TRUE;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setPointcut(@Nullable Pointcut pointcut)
/*    */   {
/* 48 */     this.pointcut = (pointcut != null ? pointcut : Pointcut.TRUE);
/*    */   }
/*    */   
/*    */   public Pointcut getPointcut()
/*    */   {
/* 53 */     return this.pointcut;
/*    */   }
/*    */   
/*    */ 
/*    */   public String toString()
/*    */   {
/* 59 */     return getClass().getName() + ": pointcut [" + getPointcut() + "]; advice bean '" + getAdviceBeanName() + "'";
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-aop-5.3.12.jar!\org\springframework\aop\support\DefaultBeanFactoryPointcutAdvisor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */