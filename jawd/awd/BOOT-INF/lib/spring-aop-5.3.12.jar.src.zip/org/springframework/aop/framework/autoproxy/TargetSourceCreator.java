package org.springframework.aop.framework.autoproxy;

import org.springframework.aop.TargetSource;
import org.springframework.lang.Nullable;

@FunctionalInterface
public abstract interface TargetSourceCreator
{
  @Nullable
  public abstract TargetSource getTargetSource(Class<?> paramClass, String paramString);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-aop-5.3.12.jar!\org\springframework\aop\framework\autoproxy\TargetSourceCreator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */