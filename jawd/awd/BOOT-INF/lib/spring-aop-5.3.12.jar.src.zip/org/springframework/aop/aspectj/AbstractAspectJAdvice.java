/*     */ package org.springframework.aop.aspectj;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.aopalliance.aop.Advice;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.aspectj.lang.JoinPoint;
/*     */ import org.aspectj.lang.JoinPoint.StaticPart;
/*     */ import org.aspectj.lang.ProceedingJoinPoint;
/*     */ import org.aspectj.weaver.tools.JoinPointMatch;
/*     */ import org.aspectj.weaver.tools.PointcutParameter;
/*     */ import org.springframework.aop.AopInvocationException;
/*     */ import org.springframework.aop.MethodMatcher;
/*     */ import org.springframework.aop.Pointcut;
/*     */ import org.springframework.aop.ProxyMethodInvocation;
/*     */ import org.springframework.aop.interceptor.ExposeInvocationInterceptor;
/*     */ import org.springframework.aop.support.ComposablePointcut;
/*     */ import org.springframework.aop.support.MethodMatchers;
/*     */ import org.springframework.aop.support.StaticMethodMatcher;
/*     */ import org.springframework.core.DefaultParameterNameDiscoverer;
/*     */ import org.springframework.core.ParameterNameDiscoverer;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractAspectJAdvice
/*     */   implements Advice, AspectJPrecedenceInformation, Serializable
/*     */ {
/*  68 */   protected static final String JOIN_POINT_KEY = JoinPoint.class.getName();
/*     */   
/*     */   private final Class<?> declaringClass;
/*     */   
/*     */   private final String methodName;
/*     */   private final Class<?>[] parameterTypes;
/*     */   protected transient Method aspectJAdviceMethod;
/*     */   private final AspectJExpressionPointcut pointcut;
/*     */   private final AspectInstanceFactory aspectInstanceFactory;
/*     */   
/*     */   public static JoinPoint currentJoinPoint()
/*     */   {
/*  80 */     MethodInvocation mi = ExposeInvocationInterceptor.currentInvocation();
/*  81 */     if (!(mi instanceof ProxyMethodInvocation)) {
/*  82 */       throw new IllegalStateException("MethodInvocation is not a Spring ProxyMethodInvocation: " + mi);
/*     */     }
/*  84 */     ProxyMethodInvocation pmi = (ProxyMethodInvocation)mi;
/*  85 */     JoinPoint jp = (JoinPoint)pmi.getUserAttribute(JOIN_POINT_KEY);
/*  86 */     if (jp == null) {
/*  87 */       jp = new MethodInvocationProceedingJoinPoint(pmi);
/*  88 */       pmi.setUserAttribute(JOIN_POINT_KEY, jp);
/*     */     }
/*  90 */     return jp;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 111 */   private String aspectName = "";
/*     */   
/*     */ 
/*     */ 
/*     */   private int declarationOrder;
/*     */   
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   private String[] argumentNames;
/*     */   
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   private String throwingName;
/*     */   
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   private String returningName;
/*     */   
/*     */ 
/* 133 */   private Class<?> discoveredReturningType = Object.class;
/*     */   
/* 135 */   private Class<?> discoveredThrowingType = Object.class;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 141 */   private int joinPointArgumentIndex = -1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 147 */   private int joinPointStaticPartArgumentIndex = -1;
/*     */   
/*     */   @Nullable
/*     */   private Map<String, Integer> argumentBindings;
/*     */   
/* 152 */   private boolean argumentsIntrospected = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   private Type discoveredReturningGenericType;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractAspectJAdvice(Method aspectJAdviceMethod, AspectJExpressionPointcut pointcut, AspectInstanceFactory aspectInstanceFactory)
/*     */   {
/* 169 */     Assert.notNull(aspectJAdviceMethod, "Advice method must not be null");
/* 170 */     this.declaringClass = aspectJAdviceMethod.getDeclaringClass();
/* 171 */     this.methodName = aspectJAdviceMethod.getName();
/* 172 */     this.parameterTypes = aspectJAdviceMethod.getParameterTypes();
/* 173 */     this.aspectJAdviceMethod = aspectJAdviceMethod;
/* 174 */     this.pointcut = pointcut;
/* 175 */     this.aspectInstanceFactory = aspectInstanceFactory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final Method getAspectJAdviceMethod()
/*     */   {
/* 183 */     return this.aspectJAdviceMethod;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final AspectJExpressionPointcut getPointcut()
/*     */   {
/* 190 */     calculateArgumentBindings();
/* 191 */     return this.pointcut;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final Pointcut buildSafePointcut()
/*     */   {
/* 200 */     Pointcut pc = getPointcut();
/* 201 */     MethodMatcher safeMethodMatcher = MethodMatchers.intersection(new AdviceExcludingMethodMatcher(this.aspectJAdviceMethod), pc
/* 202 */       .getMethodMatcher());
/* 203 */     return new ComposablePointcut(pc.getClassFilter(), safeMethodMatcher);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final AspectInstanceFactory getAspectInstanceFactory()
/*     */   {
/* 210 */     return this.aspectInstanceFactory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public final ClassLoader getAspectClassLoader()
/*     */   {
/* 218 */     return this.aspectInstanceFactory.getAspectClassLoader();
/*     */   }
/*     */   
/*     */   public int getOrder()
/*     */   {
/* 223 */     return this.aspectInstanceFactory.getOrder();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAspectName(String name)
/*     */   {
/* 231 */     this.aspectName = name;
/*     */   }
/*     */   
/*     */   public String getAspectName()
/*     */   {
/* 236 */     return this.aspectName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setDeclarationOrder(int order)
/*     */   {
/* 243 */     this.declarationOrder = order;
/*     */   }
/*     */   
/*     */   public int getDeclarationOrder()
/*     */   {
/* 248 */     return this.declarationOrder;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setArgumentNames(String argNames)
/*     */   {
/* 258 */     String[] tokens = StringUtils.commaDelimitedListToStringArray(argNames);
/* 259 */     setArgumentNamesFromStringArray(tokens);
/*     */   }
/*     */   
/*     */   public void setArgumentNamesFromStringArray(String... args) {
/* 263 */     this.argumentNames = new String[args.length];
/* 264 */     for (int i = 0; i < args.length; i++) {
/* 265 */       this.argumentNames[i] = StringUtils.trimWhitespace(args[i]);
/* 266 */       if (!isVariableName(this.argumentNames[i])) {
/* 267 */         throw new IllegalArgumentException("'argumentNames' property of AbstractAspectJAdvice contains an argument name '" + this.argumentNames[i] + "' that is not a valid Java identifier");
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 272 */     if ((this.argumentNames != null) && 
/* 273 */       (this.aspectJAdviceMethod.getParameterCount() == this.argumentNames.length + 1))
/*     */     {
/* 275 */       Class<?> firstArgType = this.aspectJAdviceMethod.getParameterTypes()[0];
/* 276 */       if ((firstArgType == JoinPoint.class) || (firstArgType == ProceedingJoinPoint.class) || (firstArgType == JoinPoint.StaticPart.class))
/*     */       {
/*     */ 
/* 279 */         String[] oldNames = this.argumentNames;
/* 280 */         this.argumentNames = new String[oldNames.length + 1];
/* 281 */         this.argumentNames[0] = "THIS_JOIN_POINT";
/* 282 */         System.arraycopy(oldNames, 0, this.argumentNames, 1, oldNames.length);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void setReturningName(String name)
/*     */   {
/* 289 */     throw new UnsupportedOperationException("Only afterReturning advice can be used to bind a return value");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setReturningNameNoCheck(String name)
/*     */   {
/* 298 */     if (isVariableName(name)) {
/* 299 */       this.returningName = name;
/*     */     }
/*     */     else {
/*     */       try
/*     */       {
/* 304 */         this.discoveredReturningType = ClassUtils.forName(name, getAspectClassLoader());
/*     */       }
/*     */       catch (Throwable ex) {
/* 307 */         throw new IllegalArgumentException("Returning name '" + name + "' is neither a valid argument name nor the fully-qualified name of a Java type on the classpath. Root cause: " + ex);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected Class<?> getDiscoveredReturningType()
/*     */   {
/* 315 */     return this.discoveredReturningType;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   protected Type getDiscoveredReturningGenericType() {
/* 320 */     return this.discoveredReturningGenericType;
/*     */   }
/*     */   
/*     */   public void setThrowingName(String name) {
/* 324 */     throw new UnsupportedOperationException("Only afterThrowing advice can be used to bind a thrown exception");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setThrowingNameNoCheck(String name)
/*     */   {
/* 333 */     if (isVariableName(name)) {
/* 334 */       this.throwingName = name;
/*     */     }
/*     */     else {
/*     */       try
/*     */       {
/* 339 */         this.discoveredThrowingType = ClassUtils.forName(name, getAspectClassLoader());
/*     */       }
/*     */       catch (Throwable ex) {
/* 342 */         throw new IllegalArgumentException("Throwing name '" + name + "' is neither a valid argument name nor the fully-qualified name of a Java type on the classpath. Root cause: " + ex);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected Class<?> getDiscoveredThrowingType()
/*     */   {
/* 350 */     return this.discoveredThrowingType;
/*     */   }
/*     */   
/*     */   private static boolean isVariableName(String name) {
/* 354 */     return AspectJProxyUtils.isVariableName(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final synchronized void calculateArgumentBindings()
/*     */   {
/* 373 */     if ((this.argumentsIntrospected) || (this.parameterTypes.length == 0)) {
/* 374 */       return;
/*     */     }
/*     */     
/* 377 */     int numUnboundArgs = this.parameterTypes.length;
/* 378 */     Class<?>[] parameterTypes = this.aspectJAdviceMethod.getParameterTypes();
/* 379 */     if ((maybeBindJoinPoint(parameterTypes[0])) || (maybeBindProceedingJoinPoint(parameterTypes[0])) || 
/* 380 */       (maybeBindJoinPointStaticPart(parameterTypes[0]))) {
/* 381 */       numUnboundArgs--;
/*     */     }
/*     */     
/* 384 */     if (numUnboundArgs > 0)
/*     */     {
/* 386 */       bindArgumentsByName(numUnboundArgs);
/*     */     }
/*     */     
/* 389 */     this.argumentsIntrospected = true;
/*     */   }
/*     */   
/*     */   private boolean maybeBindJoinPoint(Class<?> candidateParameterType) {
/* 393 */     if (JoinPoint.class == candidateParameterType) {
/* 394 */       this.joinPointArgumentIndex = 0;
/* 395 */       return true;
/*     */     }
/*     */     
/* 398 */     return false;
/*     */   }
/*     */   
/*     */   private boolean maybeBindProceedingJoinPoint(Class<?> candidateParameterType)
/*     */   {
/* 403 */     if (ProceedingJoinPoint.class == candidateParameterType) {
/* 404 */       if (!supportsProceedingJoinPoint()) {
/* 405 */         throw new IllegalArgumentException("ProceedingJoinPoint is only supported for around advice");
/*     */       }
/* 407 */       this.joinPointArgumentIndex = 0;
/* 408 */       return true;
/*     */     }
/*     */     
/* 411 */     return false;
/*     */   }
/*     */   
/*     */   protected boolean supportsProceedingJoinPoint()
/*     */   {
/* 416 */     return false;
/*     */   }
/*     */   
/*     */   private boolean maybeBindJoinPointStaticPart(Class<?> candidateParameterType) {
/* 420 */     if (JoinPoint.StaticPart.class == candidateParameterType) {
/* 421 */       this.joinPointStaticPartArgumentIndex = 0;
/* 422 */       return true;
/*     */     }
/*     */     
/* 425 */     return false;
/*     */   }
/*     */   
/*     */   private void bindArgumentsByName(int numArgumentsExpectingToBind)
/*     */   {
/* 430 */     if (this.argumentNames == null) {
/* 431 */       this.argumentNames = createParameterNameDiscoverer().getParameterNames(this.aspectJAdviceMethod);
/*     */     }
/* 433 */     if (this.argumentNames != null)
/*     */     {
/* 435 */       bindExplicitArguments(numArgumentsExpectingToBind);
/*     */     }
/*     */     else {
/* 438 */       throw new IllegalStateException("Advice method [" + this.aspectJAdviceMethod.getName() + "] requires " + numArgumentsExpectingToBind + " arguments to be bound by name, but the argument names were not specified and could not be discovered.");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ParameterNameDiscoverer createParameterNameDiscoverer()
/*     */   {
/* 452 */     DefaultParameterNameDiscoverer discoverer = new DefaultParameterNameDiscoverer();
/*     */     
/* 454 */     AspectJAdviceParameterNameDiscoverer adviceParameterNameDiscoverer = new AspectJAdviceParameterNameDiscoverer(this.pointcut.getExpression());
/* 455 */     adviceParameterNameDiscoverer.setReturningName(this.returningName);
/* 456 */     adviceParameterNameDiscoverer.setThrowingName(this.throwingName);
/*     */     
/* 458 */     adviceParameterNameDiscoverer.setRaiseExceptions(true);
/* 459 */     discoverer.addDiscoverer(adviceParameterNameDiscoverer);
/* 460 */     return discoverer;
/*     */   }
/*     */   
/*     */   private void bindExplicitArguments(int numArgumentsLeftToBind) {
/* 464 */     Assert.state(this.argumentNames != null, "No argument names available");
/* 465 */     this.argumentBindings = new HashMap();
/*     */     
/* 467 */     int numExpectedArgumentNames = this.aspectJAdviceMethod.getParameterCount();
/* 468 */     if (this.argumentNames.length != numExpectedArgumentNames) {
/* 469 */       throw new IllegalStateException("Expecting to find " + numExpectedArgumentNames + " arguments to bind by name in advice, but actually found " + this.argumentNames.length + " arguments.");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 475 */     int argumentIndexOffset = this.parameterTypes.length - numArgumentsLeftToBind;
/* 476 */     for (int i = argumentIndexOffset; i < this.argumentNames.length; i++) {
/* 477 */       this.argumentBindings.put(this.argumentNames[i], Integer.valueOf(i));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 482 */     if (this.returningName != null) {
/* 483 */       if (!this.argumentBindings.containsKey(this.returningName)) {
/* 484 */         throw new IllegalStateException("Returning argument name '" + this.returningName + "' was not bound in advice arguments");
/*     */       }
/*     */       
/*     */ 
/* 488 */       Integer index = (Integer)this.argumentBindings.get(this.returningName);
/* 489 */       this.discoveredReturningType = this.aspectJAdviceMethod.getParameterTypes()[index.intValue()];
/* 490 */       this.discoveredReturningGenericType = this.aspectJAdviceMethod.getGenericParameterTypes()[index.intValue()];
/*     */     }
/*     */     
/* 493 */     if (this.throwingName != null) {
/* 494 */       if (!this.argumentBindings.containsKey(this.throwingName)) {
/* 495 */         throw new IllegalStateException("Throwing argument name '" + this.throwingName + "' was not bound in advice arguments");
/*     */       }
/*     */       
/*     */ 
/* 499 */       Integer index = (Integer)this.argumentBindings.get(this.throwingName);
/* 500 */       this.discoveredThrowingType = this.aspectJAdviceMethod.getParameterTypes()[index.intValue()];
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 505 */     configurePointcutParameters(this.argumentNames, argumentIndexOffset);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void configurePointcutParameters(String[] argumentNames, int argumentIndexOffset)
/*     */   {
/* 514 */     int numParametersToRemove = argumentIndexOffset;
/* 515 */     if (this.returningName != null) {
/* 516 */       numParametersToRemove++;
/*     */     }
/* 518 */     if (this.throwingName != null) {
/* 519 */       numParametersToRemove++;
/*     */     }
/* 521 */     String[] pointcutParameterNames = new String[argumentNames.length - numParametersToRemove];
/* 522 */     Class<?>[] pointcutParameterTypes = new Class[pointcutParameterNames.length];
/* 523 */     Class<?>[] methodParameterTypes = this.aspectJAdviceMethod.getParameterTypes();
/*     */     
/* 525 */     int index = 0;
/* 526 */     for (int i = 0; i < argumentNames.length; i++) {
/* 527 */       if (i >= argumentIndexOffset)
/*     */       {
/*     */ 
/* 530 */         if ((!argumentNames[i].equals(this.returningName)) && 
/* 531 */           (!argumentNames[i].equals(this.throwingName)))
/*     */         {
/*     */ 
/* 534 */           pointcutParameterNames[index] = argumentNames[i];
/* 535 */           pointcutParameterTypes[index] = methodParameterTypes[i];
/* 536 */           index++;
/*     */         } }
/*     */     }
/* 539 */     this.pointcut.setParameterNames(pointcutParameterNames);
/* 540 */     this.pointcut.setParameterTypes(pointcutParameterTypes);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Object[] argBinding(JoinPoint jp, @Nullable JoinPointMatch jpMatch, @Nullable Object returnValue, @Nullable Throwable ex)
/*     */   {
/* 555 */     calculateArgumentBindings();
/*     */     
/*     */ 
/* 558 */     Object[] adviceInvocationArgs = new Object[this.parameterTypes.length];
/* 559 */     int numBound = 0;
/*     */     
/* 561 */     if (this.joinPointArgumentIndex != -1) {
/* 562 */       adviceInvocationArgs[this.joinPointArgumentIndex] = jp;
/* 563 */       numBound++;
/*     */     }
/* 565 */     else if (this.joinPointStaticPartArgumentIndex != -1) {
/* 566 */       adviceInvocationArgs[this.joinPointStaticPartArgumentIndex] = jp.getStaticPart();
/* 567 */       numBound++;
/*     */     }
/*     */     
/* 570 */     if (!CollectionUtils.isEmpty(this.argumentBindings))
/*     */     {
/* 572 */       if (jpMatch != null) {
/* 573 */         PointcutParameter[] parameterBindings = jpMatch.getParameterBindings();
/* 574 */         for (PointcutParameter parameter : parameterBindings) {
/* 575 */           String name = parameter.getName();
/* 576 */           Integer index = (Integer)this.argumentBindings.get(name);
/* 577 */           adviceInvocationArgs[index.intValue()] = parameter.getBinding();
/* 578 */           numBound++;
/*     */         }
/*     */       }
/*     */       
/* 582 */       if (this.returningName != null) {
/* 583 */         Integer index = (Integer)this.argumentBindings.get(this.returningName);
/* 584 */         adviceInvocationArgs[index.intValue()] = returnValue;
/* 585 */         numBound++;
/*     */       }
/*     */       
/* 588 */       if (this.throwingName != null) {
/* 589 */         Integer index = (Integer)this.argumentBindings.get(this.throwingName);
/* 590 */         adviceInvocationArgs[index.intValue()] = ex;
/* 591 */         numBound++;
/*     */       }
/*     */     }
/*     */     
/* 595 */     if (numBound != this.parameterTypes.length) {
/* 596 */       throw new IllegalStateException("Required to bind " + this.parameterTypes.length + " arguments, but only bound " + numBound + " (JoinPointMatch " + (jpMatch == null ? "was NOT" : "WAS") + " bound in invocation)");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 601 */     return adviceInvocationArgs;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Object invokeAdviceMethod(@Nullable JoinPointMatch jpMatch, @Nullable Object returnValue, @Nullable Throwable ex)
/*     */     throws Throwable
/*     */   {
/* 617 */     return invokeAdviceMethodWithGivenArgs(argBinding(getJoinPoint(), jpMatch, returnValue, ex));
/*     */   }
/*     */   
/*     */ 
/*     */   protected Object invokeAdviceMethod(JoinPoint jp, @Nullable JoinPointMatch jpMatch, @Nullable Object returnValue, @Nullable Throwable t)
/*     */     throws Throwable
/*     */   {
/* 624 */     return invokeAdviceMethodWithGivenArgs(argBinding(jp, jpMatch, returnValue, t));
/*     */   }
/*     */   
/*     */   protected Object invokeAdviceMethodWithGivenArgs(Object[] args) throws Throwable {
/* 628 */     Object[] actualArgs = args;
/* 629 */     if (this.aspectJAdviceMethod.getParameterCount() == 0) {
/* 630 */       actualArgs = null;
/*     */     }
/*     */     try {
/* 633 */       ReflectionUtils.makeAccessible(this.aspectJAdviceMethod);
/* 634 */       return this.aspectJAdviceMethod.invoke(this.aspectInstanceFactory.getAspectInstance(), actualArgs);
/*     */ 
/*     */     }
/*     */     catch (IllegalArgumentException ex)
/*     */     {
/* 639 */       throw new AopInvocationException("Mismatch on arguments to advice method [" + this.aspectJAdviceMethod + "]; pointcut expression [" + this.pointcut.getPointcutExpression() + "]", ex);
/*     */     }
/*     */     catch (InvocationTargetException ex) {
/* 642 */       throw ex.getTargetException();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected JoinPoint getJoinPoint()
/*     */   {
/* 650 */     return currentJoinPoint();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected JoinPointMatch getJoinPointMatch()
/*     */   {
/* 658 */     MethodInvocation mi = ExposeInvocationInterceptor.currentInvocation();
/* 659 */     if (!(mi instanceof ProxyMethodInvocation)) {
/* 660 */       throw new IllegalStateException("MethodInvocation is not a Spring ProxyMethodInvocation: " + mi);
/*     */     }
/* 662 */     return getJoinPointMatch((ProxyMethodInvocation)mi);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected JoinPointMatch getJoinPointMatch(ProxyMethodInvocation pmi)
/*     */   {
/* 673 */     String expression = this.pointcut.getExpression();
/* 674 */     return expression != null ? (JoinPointMatch)pmi.getUserAttribute(expression) : null;
/*     */   }
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/* 680 */     return getClass().getName() + ": advice method [" + this.aspectJAdviceMethod + "]; aspect name '" + this.aspectName + "'";
/*     */   }
/*     */   
/*     */   private void readObject(ObjectInputStream inputStream) throws IOException, ClassNotFoundException
/*     */   {
/* 685 */     inputStream.defaultReadObject();
/*     */     try {
/* 687 */       this.aspectJAdviceMethod = this.declaringClass.getMethod(this.methodName, this.parameterTypes);
/*     */     }
/*     */     catch (NoSuchMethodException ex) {
/* 690 */       throw new IllegalStateException("Failed to find advice method on deserialization", ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static class AdviceExcludingMethodMatcher
/*     */     extends StaticMethodMatcher
/*     */   {
/*     */     private final Method adviceMethod;
/*     */     
/*     */ 
/*     */     public AdviceExcludingMethodMatcher(Method adviceMethod)
/*     */     {
/* 704 */       this.adviceMethod = adviceMethod;
/*     */     }
/*     */     
/*     */     public boolean matches(Method method, Class<?> targetClass)
/*     */     {
/* 709 */       return !this.adviceMethod.equals(method);
/*     */     }
/*     */     
/*     */     public boolean equals(@Nullable Object other)
/*     */     {
/* 714 */       if (this == other) {
/* 715 */         return true;
/*     */       }
/* 717 */       if (!(other instanceof AdviceExcludingMethodMatcher)) {
/* 718 */         return false;
/*     */       }
/* 720 */       AdviceExcludingMethodMatcher otherMm = (AdviceExcludingMethodMatcher)other;
/* 721 */       return this.adviceMethod.equals(otherMm.adviceMethod);
/*     */     }
/*     */     
/*     */     public int hashCode()
/*     */     {
/* 726 */       return this.adviceMethod.hashCode();
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/* 731 */       return getClass().getName() + ": " + this.adviceMethod;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-aop-5.3.12.jar!\org\springframework\aop\aspectj\AbstractAspectJAdvice.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */