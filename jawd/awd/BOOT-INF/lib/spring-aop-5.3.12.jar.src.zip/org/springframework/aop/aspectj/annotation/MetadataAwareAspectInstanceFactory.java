package org.springframework.aop.aspectj.annotation;

import org.springframework.aop.aspectj.AspectInstanceFactory;
import org.springframework.lang.Nullable;

public abstract interface MetadataAwareAspectInstanceFactory
  extends AspectInstanceFactory
{
  public abstract AspectMetadata getAspectMetadata();
  
  @Nullable
  public abstract Object getAspectCreationMutex();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-aop-5.3.12.jar!\org\springframework\aop\aspectj\annotation\MetadataAwareAspectInstanceFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */