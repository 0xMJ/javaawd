/*    */ package org.springframework.aop.interceptor;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import org.aopalliance.intercept.MethodInvocation;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SimpleTraceInterceptor
/*    */   extends AbstractTraceInterceptor
/*    */ {
/*    */   public SimpleTraceInterceptor() {}
/*    */   
/*    */   public SimpleTraceInterceptor(boolean useDynamicLogger)
/*    */   {
/* 53 */     setUseDynamicLogger(useDynamicLogger);
/*    */   }
/*    */   
/*    */   protected Object invokeUnderTrace(MethodInvocation invocation, Log logger)
/*    */     throws Throwable
/*    */   {
/* 59 */     String invocationDescription = getInvocationDescription(invocation);
/* 60 */     writeToLog(logger, "Entering " + invocationDescription);
/*    */     try {
/* 62 */       Object rval = invocation.proceed();
/* 63 */       writeToLog(logger, "Exiting " + invocationDescription);
/* 64 */       return rval;
/*    */     }
/*    */     catch (Throwable ex) {
/* 67 */       writeToLog(logger, "Exception thrown in " + invocationDescription, ex);
/* 68 */       throw ex;
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected String getInvocationDescription(MethodInvocation invocation)
/*    */   {
/* 78 */     Object target = invocation.getThis();
/* 79 */     Assert.state(target != null, "Target must not be null");
/* 80 */     String className = target.getClass().getName();
/* 81 */     return "method '" + invocation.getMethod().getName() + "' of class [" + className + "]";
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-aop-5.3.12.jar!\org\springframework\aop\interceptor\SimpleTraceInterceptor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */