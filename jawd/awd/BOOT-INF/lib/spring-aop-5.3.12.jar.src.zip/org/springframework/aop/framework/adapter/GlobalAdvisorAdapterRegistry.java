/*    */ package org.springframework.aop.framework.adapter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class GlobalAdvisorAdapterRegistry
/*    */ {
/* 36 */   private static AdvisorAdapterRegistry instance = new DefaultAdvisorAdapterRegistry();
/*    */   
/*    */ 
/*    */ 
/*    */   public static AdvisorAdapterRegistry getInstance()
/*    */   {
/* 42 */     return instance;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   static void reset()
/*    */   {
/* 51 */     instance = new DefaultAdvisorAdapterRegistry();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-aop-5.3.12.jar!\org\springframework\aop\framework\adapter\GlobalAdvisorAdapterRegistry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */