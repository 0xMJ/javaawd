/*     */ package org.springframework.aop.framework.adapter;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.aopalliance.intercept.MethodInterceptor;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.aop.AfterAdvice;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ThrowsAdviceInterceptor
/*     */   implements MethodInterceptor, AfterAdvice
/*     */ {
/*     */   private static final String AFTER_THROWING = "afterThrowing";
/*  61 */   private static final Log logger = LogFactory.getLog(ThrowsAdviceInterceptor.class);
/*     */   
/*     */ 
/*     */   private final Object throwsAdvice;
/*     */   
/*     */ 
/*  67 */   private final Map<Class<?>, Method> exceptionHandlerMap = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ThrowsAdviceInterceptor(Object throwsAdvice)
/*     */   {
/*  76 */     Assert.notNull(throwsAdvice, "Advice must not be null");
/*  77 */     this.throwsAdvice = throwsAdvice;
/*     */     
/*  79 */     Method[] methods = throwsAdvice.getClass().getMethods();
/*  80 */     for (Method method : methods) {
/*  81 */       if ((method.getName().equals("afterThrowing")) && (
/*  82 */         (method.getParameterCount() == 1) || (method.getParameterCount() == 4))) {
/*  83 */         Class<?> throwableParam = method.getParameterTypes()[(method.getParameterCount() - 1)];
/*  84 */         if (Throwable.class.isAssignableFrom(throwableParam))
/*     */         {
/*  86 */           this.exceptionHandlerMap.put(throwableParam, method);
/*  87 */           if (logger.isDebugEnabled()) {
/*  88 */             logger.debug("Found exception handler method on throws advice: " + method);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*  94 */     if (this.exceptionHandlerMap.isEmpty())
/*     */     {
/*  96 */       throw new IllegalArgumentException("At least one handler method must be found in class [" + throwsAdvice.getClass() + "]");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getHandlerMethodCount()
/*     */   {
/* 105 */     return this.exceptionHandlerMap.size();
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public Object invoke(MethodInvocation mi) throws Throwable
/*     */   {
/*     */     try
/*     */     {
/* 113 */       return mi.proceed();
/*     */     }
/*     */     catch (Throwable ex) {
/* 116 */       Method handlerMethod = getExceptionHandler(ex);
/* 117 */       if (handlerMethod != null) {
/* 118 */         invokeHandlerMethod(mi, ex, handlerMethod);
/*     */       }
/* 120 */       throw ex;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   private Method getExceptionHandler(Throwable exception)
/*     */   {
/* 131 */     Class<?> exceptionClass = exception.getClass();
/* 132 */     if (logger.isTraceEnabled()) {
/* 133 */       logger.trace("Trying to find handler for exception of type [" + exceptionClass.getName() + "]");
/*     */     }
/* 135 */     Method handler = (Method)this.exceptionHandlerMap.get(exceptionClass);
/* 136 */     while ((handler == null) && (exceptionClass != Throwable.class)) {
/* 137 */       exceptionClass = exceptionClass.getSuperclass();
/* 138 */       handler = (Method)this.exceptionHandlerMap.get(exceptionClass);
/*     */     }
/* 140 */     if ((handler != null) && (logger.isTraceEnabled())) {
/* 141 */       logger.trace("Found handler for exception of type [" + exceptionClass.getName() + "]: " + handler);
/*     */     }
/* 143 */     return handler;
/*     */   }
/*     */   
/*     */   private void invokeHandlerMethod(MethodInvocation mi, Throwable ex, Method method) throws Throwable { Object[] handlerArgs;
/*     */     Object[] handlerArgs;
/* 148 */     if (method.getParameterCount() == 1) {
/* 149 */       handlerArgs = new Object[] { ex };
/*     */     }
/*     */     else {
/* 152 */       handlerArgs = new Object[] { mi.getMethod(), mi.getArguments(), mi.getThis(), ex };
/*     */     }
/*     */     try {
/* 155 */       method.invoke(this.throwsAdvice, handlerArgs);
/*     */     }
/*     */     catch (InvocationTargetException targetEx) {
/* 158 */       throw targetEx.getTargetException();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-aop-5.3.12.jar!\org\springframework\aop\framework\adapter\ThrowsAdviceInterceptor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */