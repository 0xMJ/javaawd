/*     */ package org.springframework.aop.framework;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import org.springframework.aop.SpringProxy;
/*     */ import org.springframework.aop.TargetClassAware;
/*     */ import org.springframework.aop.TargetSource;
/*     */ import org.springframework.aop.support.AopUtils;
/*     */ import org.springframework.aop.target.SingletonTargetSource;
/*     */ import org.springframework.core.DecoratingProxy;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AopProxyUtils
/*     */ {
/*     */   @Nullable
/*  53 */   private static final Method isSealedMethod = ClassUtils.getMethodIfAvailable(Class.class, "isSealed", new Class[0]);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public static Object getSingletonTarget(Object candidate)
/*     */   {
/*  67 */     if ((candidate instanceof Advised)) {
/*  68 */       TargetSource targetSource = ((Advised)candidate).getTargetSource();
/*  69 */       if ((targetSource instanceof SingletonTargetSource)) {
/*  70 */         return ((SingletonTargetSource)targetSource).getTarget();
/*     */       }
/*     */     }
/*  73 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Class<?> ultimateTargetClass(Object candidate)
/*     */   {
/*  87 */     Assert.notNull(candidate, "Candidate object must not be null");
/*  88 */     Object current = candidate;
/*  89 */     Class<?> result = null;
/*  90 */     while ((current instanceof TargetClassAware)) {
/*  91 */       result = ((TargetClassAware)current).getTargetClass();
/*  92 */       current = getSingletonTarget(current);
/*     */     }
/*  94 */     if (result == null) {
/*  95 */       result = AopUtils.isCglibProxy(candidate) ? candidate.getClass().getSuperclass() : candidate.getClass();
/*     */     }
/*  97 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Class<?>[] completeProxiedInterfaces(AdvisedSupport advised)
/*     */   {
/* 111 */     return completeProxiedInterfaces(advised, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static Class<?>[] completeProxiedInterfaces(AdvisedSupport advised, boolean decoratingProxy)
/*     */   {
/* 128 */     Class<?>[] specifiedInterfaces = advised.getProxiedInterfaces();
/* 129 */     if (specifiedInterfaces.length == 0)
/*     */     {
/* 131 */       Class<?> targetClass = advised.getTargetClass();
/* 132 */       if (targetClass != null) {
/* 133 */         if (targetClass.isInterface()) {
/* 134 */           advised.setInterfaces(new Class[] { targetClass });
/*     */         }
/* 136 */         else if (Proxy.isProxyClass(targetClass)) {
/* 137 */           advised.setInterfaces(targetClass.getInterfaces());
/*     */         }
/* 139 */         specifiedInterfaces = advised.getProxiedInterfaces();
/*     */       }
/*     */     }
/* 142 */     List<Class<?>> proxiedInterfaces = new ArrayList(specifiedInterfaces.length + 3);
/* 143 */     for (Class<?> ifc : specifiedInterfaces)
/*     */     {
/* 145 */       if ((isSealedMethod == null) || (Boolean.FALSE.equals(ReflectionUtils.invokeMethod(isSealedMethod, ifc)))) {
/* 146 */         proxiedInterfaces.add(ifc);
/*     */       }
/*     */     }
/* 149 */     if (!advised.isInterfaceProxied(SpringProxy.class)) {
/* 150 */       proxiedInterfaces.add(SpringProxy.class);
/*     */     }
/* 152 */     if ((!advised.isOpaque()) && (!advised.isInterfaceProxied(Advised.class))) {
/* 153 */       proxiedInterfaces.add(Advised.class);
/*     */     }
/* 155 */     if ((decoratingProxy) && (!advised.isInterfaceProxied(DecoratingProxy.class))) {
/* 156 */       proxiedInterfaces.add(DecoratingProxy.class);
/*     */     }
/* 158 */     return ClassUtils.toClassArray(proxiedInterfaces);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Class<?>[] proxiedUserInterfaces(Object proxy)
/*     */   {
/* 170 */     Class<?>[] proxyInterfaces = proxy.getClass().getInterfaces();
/* 171 */     int nonUserIfcCount = 0;
/* 172 */     if ((proxy instanceof SpringProxy)) {
/* 173 */       nonUserIfcCount++;
/*     */     }
/* 175 */     if ((proxy instanceof Advised)) {
/* 176 */       nonUserIfcCount++;
/*     */     }
/* 178 */     if ((proxy instanceof DecoratingProxy)) {
/* 179 */       nonUserIfcCount++;
/*     */     }
/* 181 */     Class<?>[] userInterfaces = (Class[])Arrays.copyOf(proxyInterfaces, proxyInterfaces.length - nonUserIfcCount);
/* 182 */     Assert.notEmpty(userInterfaces, "JDK proxy must implement one or more interfaces");
/* 183 */     return userInterfaces;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean equalsInProxy(AdvisedSupport a, AdvisedSupport b)
/*     */   {
/* 192 */     return (a == b) || (
/* 193 */       (equalsProxiedInterfaces(a, b)) && (equalsAdvisors(a, b)) && (a.getTargetSource().equals(b.getTargetSource())));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static boolean equalsProxiedInterfaces(AdvisedSupport a, AdvisedSupport b)
/*     */   {
/* 200 */     return Arrays.equals(a.getProxiedInterfaces(), b.getProxiedInterfaces());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static boolean equalsAdvisors(AdvisedSupport a, AdvisedSupport b)
/*     */   {
/* 207 */     return (a.getAdvisorCount() == b.getAdvisorCount()) && (Arrays.equals(a.getAdvisors(), b.getAdvisors()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static Object[] adaptArgumentsIfNecessary(Method method, @Nullable Object[] arguments)
/*     */   {
/* 221 */     if (ObjectUtils.isEmpty(arguments)) {
/* 222 */       return new Object[0];
/*     */     }
/* 224 */     if ((method.isVarArgs()) && 
/* 225 */       (method.getParameterCount() == arguments.length)) {
/* 226 */       Class<?>[] paramTypes = method.getParameterTypes();
/* 227 */       int varargIndex = paramTypes.length - 1;
/* 228 */       Class<?> varargType = paramTypes[varargIndex];
/* 229 */       if (varargType.isArray()) {
/* 230 */         Object varargArray = arguments[varargIndex];
/* 231 */         if (((varargArray instanceof Object[])) && (!varargType.isInstance(varargArray))) {
/* 232 */           Object[] newArguments = new Object[arguments.length];
/* 233 */           System.arraycopy(arguments, 0, newArguments, 0, varargIndex);
/* 234 */           Class<?> targetElementType = varargType.getComponentType();
/* 235 */           int varargLength = Array.getLength(varargArray);
/* 236 */           Object newVarargArray = Array.newInstance(targetElementType, varargLength);
/* 237 */           System.arraycopy(varargArray, 0, newVarargArray, 0, varargLength);
/* 238 */           newArguments[varargIndex] = newVarargArray;
/* 239 */           return newArguments;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 244 */     return arguments;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-aop-5.3.12.jar!\org\springframework\aop\framework\AopProxyUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */