/*    */ package org.springframework.aop;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class TruePointcut
/*    */   implements Pointcut, Serializable
/*    */ {
/* 29 */   public static final TruePointcut INSTANCE = new TruePointcut();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ClassFilter getClassFilter()
/*    */   {
/* 39 */     return ClassFilter.TRUE;
/*    */   }
/*    */   
/*    */   public MethodMatcher getMethodMatcher()
/*    */   {
/* 44 */     return MethodMatcher.TRUE;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private Object readResolve()
/*    */   {
/* 53 */     return INSTANCE;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 58 */     return "Pointcut.TRUE";
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-aop-5.3.12.jar!\org\springframework\aop\TruePointcut.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */