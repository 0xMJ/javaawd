/*     */ package org.springframework.aop.framework;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.springframework.aop.Advisor;
/*     */ import org.springframework.aop.support.AopUtils;
/*     */ import org.springframework.beans.factory.config.BeanPostProcessor;
/*     */ import org.springframework.core.SmartClassLoader;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractAdvisingBeanPostProcessor
/*     */   extends ProxyProcessorSupport
/*     */   implements BeanPostProcessor
/*     */ {
/*     */   @Nullable
/*     */   protected Advisor advisor;
/*  41 */   protected boolean beforeExistingAdvisors = false;
/*     */   
/*  43 */   private final Map<Class<?>, Boolean> eligibleBeans = new ConcurrentHashMap(256);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBeforeExistingAdvisors(boolean beforeExistingAdvisors)
/*     */   {
/*  56 */     this.beforeExistingAdvisors = beforeExistingAdvisors;
/*     */   }
/*     */   
/*     */ 
/*     */   public Object postProcessBeforeInitialization(Object bean, String beanName)
/*     */   {
/*  62 */     return bean;
/*     */   }
/*     */   
/*     */   public Object postProcessAfterInitialization(Object bean, String beanName)
/*     */   {
/*  67 */     if ((this.advisor == null) || ((bean instanceof AopInfrastructureBean)))
/*     */     {
/*  69 */       return bean;
/*     */     }
/*     */     
/*  72 */     if ((bean instanceof Advised)) {
/*  73 */       Advised advised = (Advised)bean;
/*  74 */       if ((!advised.isFrozen()) && (isEligible(AopUtils.getTargetClass(bean))))
/*     */       {
/*  76 */         if (this.beforeExistingAdvisors) {
/*  77 */           advised.addAdvisor(0, this.advisor);
/*     */         }
/*     */         else {
/*  80 */           advised.addAdvisor(this.advisor);
/*     */         }
/*  82 */         return bean;
/*     */       }
/*     */     }
/*     */     
/*  86 */     if (isEligible(bean, beanName)) {
/*  87 */       ProxyFactory proxyFactory = prepareProxyFactory(bean, beanName);
/*  88 */       if (!proxyFactory.isProxyTargetClass()) {
/*  89 */         evaluateProxyInterfaces(bean.getClass(), proxyFactory);
/*     */       }
/*  91 */       proxyFactory.addAdvisor(this.advisor);
/*  92 */       customizeProxyFactory(proxyFactory);
/*     */       
/*     */ 
/*  95 */       ClassLoader classLoader = getProxyClassLoader();
/*  96 */       if (((classLoader instanceof SmartClassLoader)) && (classLoader != bean.getClass().getClassLoader())) {
/*  97 */         classLoader = ((SmartClassLoader)classLoader).getOriginalClassLoader();
/*     */       }
/*  99 */       return proxyFactory.getProxy(classLoader);
/*     */     }
/*     */     
/*     */ 
/* 103 */     return bean;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isEligible(Object bean, String beanName)
/*     */   {
/* 122 */     return isEligible(bean.getClass());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isEligible(Class<?> targetClass)
/*     */   {
/* 133 */     Boolean eligible = (Boolean)this.eligibleBeans.get(targetClass);
/* 134 */     if (eligible != null) {
/* 135 */       return eligible.booleanValue();
/*     */     }
/* 137 */     if (this.advisor == null) {
/* 138 */       return false;
/*     */     }
/* 140 */     eligible = Boolean.valueOf(AopUtils.canApply(this.advisor, targetClass));
/* 141 */     this.eligibleBeans.put(targetClass, eligible);
/* 142 */     return eligible.booleanValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ProxyFactory prepareProxyFactory(Object bean, String beanName)
/*     */   {
/* 160 */     ProxyFactory proxyFactory = new ProxyFactory();
/* 161 */     proxyFactory.copyFrom(this);
/* 162 */     proxyFactory.setTarget(bean);
/* 163 */     return proxyFactory;
/*     */   }
/*     */   
/*     */   protected void customizeProxyFactory(ProxyFactory proxyFactory) {}
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-aop-5.3.12.jar!\org\springframework\aop\framework\AbstractAdvisingBeanPostProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */