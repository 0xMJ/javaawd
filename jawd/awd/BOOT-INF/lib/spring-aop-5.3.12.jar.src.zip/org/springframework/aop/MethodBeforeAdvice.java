package org.springframework.aop;

import java.lang.reflect.Method;
import org.springframework.lang.Nullable;

public abstract interface MethodBeforeAdvice
  extends BeforeAdvice
{
  public abstract void before(Method paramMethod, Object[] paramArrayOfObject, @Nullable Object paramObject)
    throws Throwable;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-aop-5.3.12.jar!\org\springframework\aop\MethodBeforeAdvice.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */