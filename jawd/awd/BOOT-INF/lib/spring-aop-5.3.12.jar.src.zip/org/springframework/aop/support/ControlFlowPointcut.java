/*     */ package org.springframework.aop.support;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import org.springframework.aop.ClassFilter;
/*     */ import org.springframework.aop.MethodMatcher;
/*     */ import org.springframework.aop.Pointcut;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ControlFlowPointcut
/*     */   implements Pointcut, ClassFilter, MethodMatcher, Serializable
/*     */ {
/*     */   private final Class<?> clazz;
/*     */   @Nullable
/*     */   private final String methodName;
/*  48 */   private final AtomicInteger evaluations = new AtomicInteger();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ControlFlowPointcut(Class<?> clazz)
/*     */   {
/*  56 */     this(clazz, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ControlFlowPointcut(Class<?> clazz, @Nullable String methodName)
/*     */   {
/*  67 */     Assert.notNull(clazz, "Class must not be null");
/*  68 */     this.clazz = clazz;
/*  69 */     this.methodName = methodName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean matches(Class<?> clazz)
/*     */   {
/*  78 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean matches(Method method, Class<?> targetClass)
/*     */   {
/*  86 */     return true;
/*     */   }
/*     */   
/*     */   public boolean isRuntime()
/*     */   {
/*  91 */     return true;
/*     */   }
/*     */   
/*     */   public boolean matches(Method method, Class<?> targetClass, Object... args)
/*     */   {
/*  96 */     this.evaluations.incrementAndGet();
/*     */     
/*  98 */     for (StackTraceElement element : new Throwable().getStackTrace()) {
/*  99 */       if ((element.getClassName().equals(this.clazz.getName())) && ((this.methodName == null) || 
/* 100 */         (element.getMethodName().equals(this.methodName)))) {
/* 101 */         return true;
/*     */       }
/*     */     }
/* 104 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getEvaluations()
/*     */   {
/* 111 */     return this.evaluations.get();
/*     */   }
/*     */   
/*     */ 
/*     */   public ClassFilter getClassFilter()
/*     */   {
/* 117 */     return this;
/*     */   }
/*     */   
/*     */   public MethodMatcher getMethodMatcher()
/*     */   {
/* 122 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean equals(@Nullable Object other)
/*     */   {
/* 128 */     if (this == other) {
/* 129 */       return true;
/*     */     }
/* 131 */     if (!(other instanceof ControlFlowPointcut)) {
/* 132 */       return false;
/*     */     }
/* 134 */     ControlFlowPointcut that = (ControlFlowPointcut)other;
/* 135 */     return (this.clazz.equals(that.clazz)) && (ObjectUtils.nullSafeEquals(this.methodName, that.methodName));
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 140 */     int code = this.clazz.hashCode();
/* 141 */     if (this.methodName != null) {
/* 142 */       code = 37 * code + this.methodName.hashCode();
/*     */     }
/* 144 */     return code;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 149 */     return getClass().getName() + ": class = " + this.clazz.getName() + "; methodName = " + this.methodName;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-aop-5.3.12.jar!\org\springframework\aop\support\ControlFlowPointcut.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */