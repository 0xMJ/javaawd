/*    */ package org.springframework.aop.framework;
/*    */ 
/*    */ import org.springframework.core.NamedThreadLocal;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AopContext
/*    */ {
/* 50 */   private static final ThreadLocal<Object> currentProxy = new NamedThreadLocal("Current AOP proxy");
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static Object currentProxy()
/*    */     throws IllegalStateException
/*    */   {
/* 67 */     Object proxy = currentProxy.get();
/* 68 */     if (proxy == null) {
/* 69 */       throw new IllegalStateException("Cannot find current proxy: Set 'exposeProxy' property on Advised to 'true' to make it available, and ensure that AopContext.currentProxy() is invoked in the same thread as the AOP invocation context.");
/*    */     }
/*    */     
/*    */ 
/* 73 */     return proxy;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   @Nullable
/*    */   static Object setCurrentProxy(@Nullable Object proxy)
/*    */   {
/* 85 */     Object old = currentProxy.get();
/* 86 */     if (proxy != null) {
/* 87 */       currentProxy.set(proxy);
/*    */     }
/*    */     else {
/* 90 */       currentProxy.remove();
/*    */     }
/* 92 */     return old;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-aop-5.3.12.jar!\org\springframework\aop\framework\AopContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */