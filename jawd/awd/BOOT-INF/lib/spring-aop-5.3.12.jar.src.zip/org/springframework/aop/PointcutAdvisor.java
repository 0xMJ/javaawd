package org.springframework.aop;

public abstract interface PointcutAdvisor
  extends Advisor
{
  public abstract Pointcut getPointcut();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-aop-5.3.12.jar!\org\springframework\aop\PointcutAdvisor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */