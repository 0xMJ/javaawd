/*    */ package org.springframework.aop.framework.adapter;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.aopalliance.intercept.MethodInterceptor;
/*    */ import org.aopalliance.intercept.MethodInvocation;
/*    */ import org.springframework.aop.BeforeAdvice;
/*    */ import org.springframework.aop.MethodBeforeAdvice;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MethodBeforeAdviceInterceptor
/*    */   implements MethodInterceptor, BeforeAdvice, Serializable
/*    */ {
/*    */   private final MethodBeforeAdvice advice;
/*    */   
/*    */   public MethodBeforeAdviceInterceptor(MethodBeforeAdvice advice)
/*    */   {
/* 49 */     Assert.notNull(advice, "Advice must not be null");
/* 50 */     this.advice = advice;
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   public Object invoke(MethodInvocation mi)
/*    */     throws Throwable
/*    */   {
/* 57 */     this.advice.before(mi.getMethod(), mi.getArguments(), mi.getThis());
/* 58 */     return mi.proceed();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-aop-5.3.12.jar!\org\springframework\aop\framework\adapter\MethodBeforeAdviceInterceptor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */