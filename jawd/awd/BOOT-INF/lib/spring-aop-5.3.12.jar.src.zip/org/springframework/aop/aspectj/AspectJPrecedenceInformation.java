package org.springframework.aop.aspectj;

import org.springframework.core.Ordered;

public abstract interface AspectJPrecedenceInformation
  extends Ordered
{
  public abstract String getAspectName();
  
  public abstract int getDeclarationOrder();
  
  public abstract boolean isBeforeAdvice();
  
  public abstract boolean isAfterAdvice();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-aop-5.3.12.jar!\org\springframework\aop\aspectj\AspectJPrecedenceInformation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */