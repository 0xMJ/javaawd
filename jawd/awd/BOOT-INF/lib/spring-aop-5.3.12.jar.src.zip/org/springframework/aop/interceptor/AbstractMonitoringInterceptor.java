/*     */ package org.springframework.aop.interceptor;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractMonitoringInterceptor
/*     */   extends AbstractTraceInterceptor
/*     */ {
/*  44 */   private String prefix = "";
/*     */   
/*  46 */   private String suffix = "";
/*     */   
/*  48 */   private boolean logTargetClassInvocation = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPrefix(@Nullable String prefix)
/*     */   {
/*  56 */     this.prefix = (prefix != null ? prefix : "");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected String getPrefix()
/*     */   {
/*  63 */     return this.prefix;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSuffix(@Nullable String suffix)
/*     */   {
/*  71 */     this.suffix = (suffix != null ? suffix : "");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected String getSuffix()
/*     */   {
/*  78 */     return this.suffix;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLogTargetClassInvocation(boolean logTargetClassInvocation)
/*     */   {
/*  88 */     this.logTargetClassInvocation = logTargetClassInvocation;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String createInvocationTraceName(MethodInvocation invocation)
/*     */   {
/* 101 */     Method method = invocation.getMethod();
/* 102 */     Class<?> clazz = method.getDeclaringClass();
/* 103 */     if ((this.logTargetClassInvocation) && (clazz.isInstance(invocation.getThis()))) {
/* 104 */       clazz = invocation.getThis().getClass();
/*     */     }
/* 106 */     String className = clazz.getName();
/* 107 */     return getPrefix() + className + '.' + method.getName() + getSuffix();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-aop-5.3.12.jar!\org\springframework\aop\interceptor\AbstractMonitoringInterceptor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */