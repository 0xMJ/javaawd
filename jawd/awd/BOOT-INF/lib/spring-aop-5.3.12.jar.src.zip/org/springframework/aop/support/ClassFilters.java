/*     */ package org.springframework.aop.support;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Arrays;
/*     */ import org.springframework.aop.ClassFilter;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ClassFilters
/*     */ {
/*     */   public static ClassFilter union(ClassFilter cf1, ClassFilter cf2)
/*     */   {
/*  48 */     Assert.notNull(cf1, "First ClassFilter must not be null");
/*  49 */     Assert.notNull(cf2, "Second ClassFilter must not be null");
/*  50 */     return new UnionClassFilter(new ClassFilter[] { cf1, cf2 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ClassFilter union(ClassFilter[] classFilters)
/*     */   {
/*  60 */     Assert.notEmpty(classFilters, "ClassFilter array must not be empty");
/*  61 */     return new UnionClassFilter(classFilters);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ClassFilter intersection(ClassFilter cf1, ClassFilter cf2)
/*     */   {
/*  72 */     Assert.notNull(cf1, "First ClassFilter must not be null");
/*  73 */     Assert.notNull(cf2, "Second ClassFilter must not be null");
/*  74 */     return new IntersectionClassFilter(new ClassFilter[] { cf1, cf2 });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ClassFilter intersection(ClassFilter[] classFilters)
/*     */   {
/*  84 */     Assert.notEmpty(classFilters, "ClassFilter array must not be empty");
/*  85 */     return new IntersectionClassFilter(classFilters);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static class UnionClassFilter
/*     */     implements ClassFilter, Serializable
/*     */   {
/*     */     private final ClassFilter[] filters;
/*     */     
/*     */ 
/*     */     UnionClassFilter(ClassFilter[] filters)
/*     */     {
/*  98 */       this.filters = filters;
/*     */     }
/*     */     
/*     */     public boolean matches(Class<?> clazz)
/*     */     {
/* 103 */       for (ClassFilter filter : this.filters) {
/* 104 */         if (filter.matches(clazz)) {
/* 105 */           return true;
/*     */         }
/*     */       }
/* 108 */       return false;
/*     */     }
/*     */     
/*     */     public boolean equals(@Nullable Object other)
/*     */     {
/* 113 */       return (this == other) || (((other instanceof UnionClassFilter)) && 
/* 114 */         (ObjectUtils.nullSafeEquals(this.filters, ((UnionClassFilter)other).filters)));
/*     */     }
/*     */     
/*     */     public int hashCode()
/*     */     {
/* 119 */       return ObjectUtils.nullSafeHashCode(this.filters);
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/* 124 */       return getClass().getName() + ": " + Arrays.toString(this.filters);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static class IntersectionClassFilter
/*     */     implements ClassFilter, Serializable
/*     */   {
/*     */     private final ClassFilter[] filters;
/*     */     
/*     */ 
/*     */ 
/*     */     IntersectionClassFilter(ClassFilter[] filters)
/*     */     {
/* 139 */       this.filters = filters;
/*     */     }
/*     */     
/*     */     public boolean matches(Class<?> clazz)
/*     */     {
/* 144 */       for (ClassFilter filter : this.filters) {
/* 145 */         if (!filter.matches(clazz)) {
/* 146 */           return false;
/*     */         }
/*     */       }
/* 149 */       return true;
/*     */     }
/*     */     
/*     */     public boolean equals(@Nullable Object other)
/*     */     {
/* 154 */       return (this == other) || (((other instanceof IntersectionClassFilter)) && 
/* 155 */         (ObjectUtils.nullSafeEquals(this.filters, ((IntersectionClassFilter)other).filters)));
/*     */     }
/*     */     
/*     */     public int hashCode()
/*     */     {
/* 160 */       return ObjectUtils.nullSafeHashCode(this.filters);
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/* 165 */       return getClass().getName() + ": " + Arrays.toString(this.filters);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-aop-5.3.12.jar!\org\springframework\aop\support\ClassFilters.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */