package org.springframework.aop;

import org.springframework.lang.Nullable;

public abstract interface TargetSource
  extends TargetClassAware
{
  @Nullable
  public abstract Class<?> getTargetClass();
  
  public abstract boolean isStatic();
  
  @Nullable
  public abstract Object getTarget()
    throws Exception;
  
  public abstract void releaseTarget(Object paramObject)
    throws Exception;
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-aop-5.3.12.jar!\org\springframework\aop\TargetSource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */