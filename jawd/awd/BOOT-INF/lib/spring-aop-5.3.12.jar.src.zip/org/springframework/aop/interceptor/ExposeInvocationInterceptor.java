/*     */ package org.springframework.aop.interceptor;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import org.aopalliance.aop.Advice;
/*     */ import org.aopalliance.intercept.MethodInterceptor;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.springframework.aop.Advisor;
/*     */ import org.springframework.aop.support.DefaultPointcutAdvisor;
/*     */ import org.springframework.core.NamedThreadLocal;
/*     */ import org.springframework.core.PriorityOrdered;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ExposeInvocationInterceptor
/*     */   implements MethodInterceptor, PriorityOrdered, Serializable
/*     */ {
/*  48 */   public static final ExposeInvocationInterceptor INSTANCE = new ExposeInvocationInterceptor();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  54 */   public static final Advisor ADVISOR = new DefaultPointcutAdvisor(INSTANCE)
/*     */   {
/*     */     public String toString() {
/*  57 */       return ExposeInvocationInterceptor.class.getName() + ".ADVISOR";
/*     */     }
/*     */   };
/*     */   
/*  61 */   private static final ThreadLocal<MethodInvocation> invocation = new NamedThreadLocal("Current AOP method invocation");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static MethodInvocation currentInvocation()
/*     */     throws IllegalStateException
/*     */   {
/*  72 */     MethodInvocation mi = (MethodInvocation)invocation.get();
/*  73 */     if (mi == null) {
/*  74 */       throw new IllegalStateException("No MethodInvocation found: Check that an AOP invocation is in progress and that the ExposeInvocationInterceptor is upfront in the interceptor chain. Specifically, note that advices with order HIGHEST_PRECEDENCE will execute before ExposeInvocationInterceptor! In addition, ExposeInvocationInterceptor and ExposeInvocationInterceptor.currentInvocation() must be invoked from the same thread.");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  81 */     return mi;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public Object invoke(MethodInvocation mi)
/*     */     throws Throwable
/*     */   {
/*  94 */     MethodInvocation oldInvocation = (MethodInvocation)invocation.get();
/*  95 */     invocation.set(mi);
/*     */     try {
/*  97 */       return mi.proceed();
/*     */     }
/*     */     finally {
/* 100 */       invocation.set(oldInvocation);
/*     */     }
/*     */   }
/*     */   
/*     */   public int getOrder()
/*     */   {
/* 106 */     return -2147483647;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Object readResolve()
/*     */   {
/* 115 */     return INSTANCE;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-aop-5.3.12.jar!\org\springframework\aop\interceptor\ExposeInvocationInterceptor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */