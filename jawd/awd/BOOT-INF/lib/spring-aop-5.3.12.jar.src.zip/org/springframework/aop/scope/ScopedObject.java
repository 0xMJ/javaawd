package org.springframework.aop.scope;

import org.springframework.aop.RawTargetAccess;

public abstract interface ScopedObject
  extends RawTargetAccess
{
  public abstract Object getTargetObject();
  
  public abstract void removeFromScope();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-aop-5.3.12.jar!\org\springframework\aop\scope\ScopedObject.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */