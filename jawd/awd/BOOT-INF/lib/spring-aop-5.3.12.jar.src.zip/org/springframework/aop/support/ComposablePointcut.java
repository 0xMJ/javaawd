/*     */ package org.springframework.aop.support;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import org.springframework.aop.ClassFilter;
/*     */ import org.springframework.aop.MethodMatcher;
/*     */ import org.springframework.aop.Pointcut;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ComposablePointcut
/*     */   implements Pointcut, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -2743223737633663832L;
/*     */   private ClassFilter classFilter;
/*     */   private MethodMatcher methodMatcher;
/*     */   
/*     */   public ComposablePointcut()
/*     */   {
/*  59 */     this.classFilter = ClassFilter.TRUE;
/*  60 */     this.methodMatcher = MethodMatcher.TRUE;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ComposablePointcut(Pointcut pointcut)
/*     */   {
/*  68 */     Assert.notNull(pointcut, "Pointcut must not be null");
/*  69 */     this.classFilter = pointcut.getClassFilter();
/*  70 */     this.methodMatcher = pointcut.getMethodMatcher();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ComposablePointcut(ClassFilter classFilter)
/*     */   {
/*  79 */     Assert.notNull(classFilter, "ClassFilter must not be null");
/*  80 */     this.classFilter = classFilter;
/*  81 */     this.methodMatcher = MethodMatcher.TRUE;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ComposablePointcut(MethodMatcher methodMatcher)
/*     */   {
/*  90 */     Assert.notNull(methodMatcher, "MethodMatcher must not be null");
/*  91 */     this.classFilter = ClassFilter.TRUE;
/*  92 */     this.methodMatcher = methodMatcher;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ComposablePointcut(ClassFilter classFilter, MethodMatcher methodMatcher)
/*     */   {
/* 101 */     Assert.notNull(classFilter, "ClassFilter must not be null");
/* 102 */     Assert.notNull(methodMatcher, "MethodMatcher must not be null");
/* 103 */     this.classFilter = classFilter;
/* 104 */     this.methodMatcher = methodMatcher;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ComposablePointcut union(ClassFilter other)
/*     */   {
/* 114 */     this.classFilter = ClassFilters.union(this.classFilter, other);
/* 115 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ComposablePointcut intersection(ClassFilter other)
/*     */   {
/* 124 */     this.classFilter = ClassFilters.intersection(this.classFilter, other);
/* 125 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ComposablePointcut union(MethodMatcher other)
/*     */   {
/* 134 */     this.methodMatcher = MethodMatchers.union(this.methodMatcher, other);
/* 135 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ComposablePointcut intersection(MethodMatcher other)
/*     */   {
/* 144 */     this.methodMatcher = MethodMatchers.intersection(this.methodMatcher, other);
/* 145 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ComposablePointcut union(Pointcut other)
/*     */   {
/* 158 */     this.methodMatcher = MethodMatchers.union(this.methodMatcher, this.classFilter, other
/* 159 */       .getMethodMatcher(), other.getClassFilter());
/* 160 */     this.classFilter = ClassFilters.union(this.classFilter, other.getClassFilter());
/* 161 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ComposablePointcut intersection(Pointcut other)
/*     */   {
/* 170 */     this.classFilter = ClassFilters.intersection(this.classFilter, other.getClassFilter());
/* 171 */     this.methodMatcher = MethodMatchers.intersection(this.methodMatcher, other.getMethodMatcher());
/* 172 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */   public ClassFilter getClassFilter()
/*     */   {
/* 178 */     return this.classFilter;
/*     */   }
/*     */   
/*     */   public MethodMatcher getMethodMatcher()
/*     */   {
/* 183 */     return this.methodMatcher;
/*     */   }
/*     */   
/*     */   public boolean equals(@Nullable Object other)
/*     */   {
/* 188 */     if (this == other) {
/* 189 */       return true;
/*     */     }
/* 191 */     if (!(other instanceof ComposablePointcut)) {
/* 192 */       return false;
/*     */     }
/* 194 */     ComposablePointcut otherPointcut = (ComposablePointcut)other;
/* 195 */     return (this.classFilter.equals(otherPointcut.classFilter)) && 
/* 196 */       (this.methodMatcher.equals(otherPointcut.methodMatcher));
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 201 */     return this.classFilter.hashCode() * 37 + this.methodMatcher.hashCode();
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 206 */     return getClass().getName() + ": " + this.classFilter + ", " + this.methodMatcher;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-aop-5.3.12.jar!\org\springframework\aop\support\ComposablePointcut.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */