/*    */ package org.springframework.aop.support;
/*    */ 
/*    */ import org.springframework.aop.ClassFilter;
/*    */ import org.springframework.aop.MethodMatcher;
/*    */ import org.springframework.aop.Pointcut;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class DynamicMethodMatcherPointcut
/*    */   extends DynamicMethodMatcher
/*    */   implements Pointcut
/*    */ {
/*    */   public ClassFilter getClassFilter()
/*    */   {
/* 35 */     return ClassFilter.TRUE;
/*    */   }
/*    */   
/*    */   public final MethodMatcher getMethodMatcher()
/*    */   {
/* 40 */     return this;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-aop-5.3.12.jar!\org\springframework\aop\support\DynamicMethodMatcherPointcut.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */