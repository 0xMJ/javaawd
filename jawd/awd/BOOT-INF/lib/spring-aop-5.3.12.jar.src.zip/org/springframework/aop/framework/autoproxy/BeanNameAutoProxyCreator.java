/*     */ package org.springframework.aop.framework.autoproxy;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.springframework.aop.TargetSource;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.PatternMatchUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BeanNameAutoProxyCreator
/*     */   extends AbstractAutoProxyCreator
/*     */ {
/*  50 */   private static final String[] NO_ALIASES = new String[0];
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   private List<String> beanNames;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBeanNames(String... beanNames)
/*     */   {
/*  69 */     Assert.notEmpty(beanNames, "'beanNames' must not be empty");
/*  70 */     this.beanNames = new ArrayList(beanNames.length);
/*  71 */     for (String mappedName : beanNames) {
/*  72 */       this.beanNames.add(StringUtils.trimWhitespace(mappedName));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected TargetSource getCustomTargetSource(Class<?> beanClass, String beanName)
/*     */   {
/*  86 */     return isSupportedBeanName(beanClass, beanName) ? 
/*  87 */       super.getCustomTargetSource(beanClass, beanName) : null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   protected Object[] getAdvicesAndAdvisorsForBean(Class<?> beanClass, String beanName, @Nullable TargetSource targetSource)
/*     */   {
/* 100 */     return isSupportedBeanName(beanClass, beanName) ? PROXY_WITHOUT_ADDITIONAL_INTERCEPTORS : DO_NOT_PROXY;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean isSupportedBeanName(Class<?> beanClass, String beanName)
/*     */   {
/* 113 */     if (this.beanNames != null) {
/* 114 */       boolean isFactoryBean = FactoryBean.class.isAssignableFrom(beanClass);
/* 115 */       for (String mappedName : this.beanNames) {
/* 116 */         if (isFactoryBean) {
/* 117 */           if (mappedName.startsWith("&"))
/*     */           {
/*     */ 
/* 120 */             mappedName = mappedName.substring("&".length());
/*     */           }
/* 122 */         } else if (isMatch(beanName, mappedName)) {
/* 123 */           return true;
/*     */         }
/*     */       }
/*     */       
/* 127 */       BeanFactory beanFactory = getBeanFactory();
/* 128 */       String[] aliases = beanFactory != null ? beanFactory.getAliases(beanName) : NO_ALIASES;
/* 129 */       String alias; for (alias : aliases) {
/* 130 */         for (String mappedName : this.beanNames) {
/* 131 */           if (isMatch(alias, mappedName)) {
/* 132 */             return true;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 137 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isMatch(String beanName, String mappedName)
/*     */   {
/* 150 */     return PatternMatchUtils.simpleMatch(mappedName, beanName);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-aop-5.3.12.jar!\org\springframework\aop\framework\autoproxy\BeanNameAutoProxyCreator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */