package org.springframework.aop.framework;

import org.springframework.lang.Nullable;

public abstract interface AopProxy
{
  public abstract Object getProxy();
  
  public abstract Object getProxy(@Nullable ClassLoader paramClassLoader);
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-aop-5.3.12.jar!\org\springframework\aop\framework\AopProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */