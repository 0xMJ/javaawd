/*    */ package org.springframework.aop.framework;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.lang.reflect.Proxy;
/*    */ import org.springframework.aop.SpringProxy;
/*    */ import org.springframework.core.NativeDetector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultAopProxyFactory
/*    */   implements AopProxyFactory, Serializable
/*    */ {
/*    */   public AopProxy createAopProxy(AdvisedSupport config)
/*    */     throws AopConfigException
/*    */   {
/* 54 */     if ((!NativeDetector.inNativeImage()) && (
/* 55 */       (config.isOptimize()) || (config.isProxyTargetClass()) || (hasNoUserSuppliedProxyInterfaces(config)))) {
/* 56 */       Class<?> targetClass = config.getTargetClass();
/* 57 */       if (targetClass == null) {
/* 58 */         throw new AopConfigException("TargetSource cannot determine target class: Either an interface or a target is required for proxy creation.");
/*    */       }
/*    */       
/* 61 */       if ((targetClass.isInterface()) || (Proxy.isProxyClass(targetClass))) {
/* 62 */         return new JdkDynamicAopProxy(config);
/*    */       }
/* 64 */       return new ObjenesisCglibAopProxy(config);
/*    */     }
/*    */     
/* 67 */     return new JdkDynamicAopProxy(config);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private boolean hasNoUserSuppliedProxyInterfaces(AdvisedSupport config)
/*    */   {
/* 77 */     Class<?>[] ifcs = config.getProxiedInterfaces();
/* 78 */     return (ifcs.length == 0) || ((ifcs.length == 1) && (SpringProxy.class.isAssignableFrom(ifcs[0])));
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-aop-5.3.12.jar!\org\springframework\aop\framework\DefaultAopProxyFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */