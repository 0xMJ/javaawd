/*    */ package org.springframework.aop.aspectj;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.lang.reflect.Method;
/*    */ import org.aopalliance.intercept.MethodInterceptor;
/*    */ import org.aopalliance.intercept.MethodInvocation;
/*    */ import org.aspectj.lang.ProceedingJoinPoint;
/*    */ import org.aspectj.weaver.tools.JoinPointMatch;
/*    */ import org.springframework.aop.ProxyMethodInvocation;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AspectJAroundAdvice
/*    */   extends AbstractAspectJAdvice
/*    */   implements MethodInterceptor, Serializable
/*    */ {
/*    */   public AspectJAroundAdvice(Method aspectJAroundAdviceMethod, AspectJExpressionPointcut pointcut, AspectInstanceFactory aif)
/*    */   {
/* 44 */     super(aspectJAroundAdviceMethod, pointcut, aif);
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean isBeforeAdvice()
/*    */   {
/* 50 */     return false;
/*    */   }
/*    */   
/*    */   public boolean isAfterAdvice()
/*    */   {
/* 55 */     return false;
/*    */   }
/*    */   
/*    */   protected boolean supportsProceedingJoinPoint()
/*    */   {
/* 60 */     return true;
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   public Object invoke(MethodInvocation mi) throws Throwable
/*    */   {
/* 66 */     if (!(mi instanceof ProxyMethodInvocation)) {
/* 67 */       throw new IllegalStateException("MethodInvocation is not a Spring ProxyMethodInvocation: " + mi);
/*    */     }
/* 69 */     ProxyMethodInvocation pmi = (ProxyMethodInvocation)mi;
/* 70 */     ProceedingJoinPoint pjp = lazyGetProceedingJoinPoint(pmi);
/* 71 */     JoinPointMatch jpm = getJoinPointMatch(pmi);
/* 72 */     return invokeAdviceMethod(pjp, jpm, null, null);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected ProceedingJoinPoint lazyGetProceedingJoinPoint(ProxyMethodInvocation rmi)
/*    */   {
/* 83 */     return new MethodInvocationProceedingJoinPoint(rmi);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-aop-5.3.12.jar!\org\springframework\aop\aspectj\AspectJAroundAdvice.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */