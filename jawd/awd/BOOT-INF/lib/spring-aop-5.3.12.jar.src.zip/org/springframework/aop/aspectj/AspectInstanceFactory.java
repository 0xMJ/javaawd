package org.springframework.aop.aspectj;

import org.springframework.core.Ordered;
import org.springframework.lang.Nullable;

public abstract interface AspectInstanceFactory
  extends Ordered
{
  public abstract Object getAspectInstance();
  
  @Nullable
  public abstract ClassLoader getAspectClassLoader();
}


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-aop-5.3.12.jar!\org\springframework\aop\aspectj\AspectInstanceFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */