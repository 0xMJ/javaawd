/*     */ package org.springframework.aop.support;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import org.aopalliance.aop.Advice;
/*     */ import org.springframework.aop.ClassFilter;
/*     */ import org.springframework.aop.DynamicIntroductionAdvice;
/*     */ import org.springframework.aop.IntroductionAdvisor;
/*     */ import org.springframework.aop.IntroductionInfo;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultIntroductionAdvisor
/*     */   implements IntroductionAdvisor, ClassFilter, Ordered, Serializable
/*     */ {
/*     */   private final Advice advice;
/*  47 */   private final Set<Class<?>> interfaces = new LinkedHashSet();
/*     */   
/*  49 */   private int order = Integer.MAX_VALUE;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DefaultIntroductionAdvisor(Advice advice)
/*     */   {
/*  59 */     this(advice, (advice instanceof IntroductionInfo) ? (IntroductionInfo)advice : null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DefaultIntroductionAdvisor(Advice advice, @Nullable IntroductionInfo introductionInfo)
/*     */   {
/*  69 */     Assert.notNull(advice, "Advice must not be null");
/*  70 */     this.advice = advice;
/*  71 */     if (introductionInfo != null) {
/*  72 */       Class<?>[] introducedInterfaces = introductionInfo.getInterfaces();
/*  73 */       if (introducedInterfaces.length == 0) {
/*  74 */         throw new IllegalArgumentException("IntroductionInfo defines no interfaces to introduce: " + introductionInfo);
/*     */       }
/*     */       
/*  77 */       for (Class<?> ifc : introducedInterfaces) {
/*  78 */         addInterface(ifc);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DefaultIntroductionAdvisor(DynamicIntroductionAdvice advice, Class<?> ifc)
/*     */   {
/*  89 */     Assert.notNull(advice, "Advice must not be null");
/*  90 */     this.advice = advice;
/*  91 */     addInterface(ifc);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addInterface(Class<?> ifc)
/*     */   {
/* 100 */     Assert.notNull(ifc, "Interface must not be null");
/* 101 */     if (!ifc.isInterface()) {
/* 102 */       throw new IllegalArgumentException("Specified class [" + ifc.getName() + "] must be an interface");
/*     */     }
/* 104 */     this.interfaces.add(ifc);
/*     */   }
/*     */   
/*     */   public Class<?>[] getInterfaces()
/*     */   {
/* 109 */     return ClassUtils.toClassArray(this.interfaces);
/*     */   }
/*     */   
/*     */   public void validateInterfaces() throws IllegalArgumentException
/*     */   {
/* 114 */     for (Class<?> ifc : this.interfaces) {
/* 115 */       if (((this.advice instanceof DynamicIntroductionAdvice)) && 
/* 116 */         (!((DynamicIntroductionAdvice)this.advice).implementsInterface(ifc)))
/*     */       {
/* 118 */         throw new IllegalArgumentException("DynamicIntroductionAdvice [" + this.advice + "] does not implement interface [" + ifc.getName() + "] specified for introduction");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void setOrder(int order) {
/* 124 */     this.order = order;
/*     */   }
/*     */   
/*     */   public int getOrder()
/*     */   {
/* 129 */     return this.order;
/*     */   }
/*     */   
/*     */   public Advice getAdvice()
/*     */   {
/* 134 */     return this.advice;
/*     */   }
/*     */   
/*     */   public boolean isPerInstance()
/*     */   {
/* 139 */     return true;
/*     */   }
/*     */   
/*     */   public ClassFilter getClassFilter()
/*     */   {
/* 144 */     return this;
/*     */   }
/*     */   
/*     */   public boolean matches(Class<?> clazz)
/*     */   {
/* 149 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean equals(@Nullable Object other)
/*     */   {
/* 155 */     if (this == other) {
/* 156 */       return true;
/*     */     }
/* 158 */     if (!(other instanceof DefaultIntroductionAdvisor)) {
/* 159 */       return false;
/*     */     }
/* 161 */     DefaultIntroductionAdvisor otherAdvisor = (DefaultIntroductionAdvisor)other;
/* 162 */     return (this.advice.equals(otherAdvisor.advice)) && (this.interfaces.equals(otherAdvisor.interfaces));
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 167 */     return this.advice.hashCode() * 13 + this.interfaces.hashCode();
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 172 */     return 
/* 173 */       getClass().getName() + ": advice [" + this.advice + "]; interfaces " + ClassUtils.classNamesToString(this.interfaces);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-aop-5.3.12.jar!\org\springframework\aop\support\DefaultIntroductionAdvisor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */