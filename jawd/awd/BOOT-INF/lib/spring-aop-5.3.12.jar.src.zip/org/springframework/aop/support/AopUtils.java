/*     */ package org.springframework.aop.support;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.springframework.aop.Advisor;
/*     */ import org.springframework.aop.AopInvocationException;
/*     */ import org.springframework.aop.ClassFilter;
/*     */ import org.springframework.aop.IntroductionAdvisor;
/*     */ import org.springframework.aop.IntroductionAwareMethodMatcher;
/*     */ import org.springframework.aop.MethodMatcher;
/*     */ import org.springframework.aop.Pointcut;
/*     */ import org.springframework.aop.PointcutAdvisor;
/*     */ import org.springframework.aop.SpringProxy;
/*     */ import org.springframework.aop.TargetClassAware;
/*     */ import org.springframework.core.BridgeMethodResolver;
/*     */ import org.springframework.core.MethodIntrospector;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AopUtils
/*     */ {
/*     */   public static boolean isAopProxy(@Nullable Object object)
/*     */   {
/*  69 */     return ((object instanceof SpringProxy)) && ((Proxy.isProxyClass(object.getClass())) || 
/*  70 */       (object.getClass().getName().contains("$$")));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isJdkDynamicProxy(@Nullable Object object)
/*     */   {
/*  82 */     return ((object instanceof SpringProxy)) && (Proxy.isProxyClass(object.getClass()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isCglibProxy(@Nullable Object object)
/*     */   {
/*  94 */     return ((object instanceof SpringProxy)) && 
/*  95 */       (object.getClass().getName().contains("$$"));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Class<?> getTargetClass(Object candidate)
/*     */   {
/* 108 */     Assert.notNull(candidate, "Candidate object must not be null");
/* 109 */     Class<?> result = null;
/* 110 */     if ((candidate instanceof TargetClassAware)) {
/* 111 */       result = ((TargetClassAware)candidate).getTargetClass();
/*     */     }
/* 113 */     if (result == null) {
/* 114 */       result = isCglibProxy(candidate) ? candidate.getClass().getSuperclass() : candidate.getClass();
/*     */     }
/* 116 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Method selectInvocableMethod(Method method, @Nullable Class<?> targetType)
/*     */   {
/* 132 */     if (targetType == null) {
/* 133 */       return method;
/*     */     }
/* 135 */     Method methodToUse = MethodIntrospector.selectInvocableMethod(method, targetType);
/* 136 */     if ((Modifier.isPrivate(methodToUse.getModifiers())) && (!Modifier.isStatic(methodToUse.getModifiers())) && 
/* 137 */       (SpringProxy.class.isAssignableFrom(targetType))) {
/* 138 */       throw new IllegalStateException(String.format("Need to invoke method '%s' found on proxy for target class '%s' but cannot be delegated to target bean. Switch its visibility to package or protected.", new Object[] {method
/*     */       
/*     */ 
/* 141 */         .getName(), method.getDeclaringClass().getSimpleName() }));
/*     */     }
/* 143 */     return methodToUse;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isEqualsMethod(@Nullable Method method)
/*     */   {
/* 151 */     return ReflectionUtils.isEqualsMethod(method);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isHashCodeMethod(@Nullable Method method)
/*     */   {
/* 159 */     return ReflectionUtils.isHashCodeMethod(method);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isToStringMethod(@Nullable Method method)
/*     */   {
/* 167 */     return ReflectionUtils.isToStringMethod(method);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isFinalizeMethod(@Nullable Method method)
/*     */   {
/* 175 */     return (method != null) && (method.getName().equals("finalize")) && 
/* 176 */       (method.getParameterCount() == 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Method getMostSpecificMethod(Method method, @Nullable Class<?> targetClass)
/*     */   {
/* 196 */     Class<?> specificTargetClass = targetClass != null ? ClassUtils.getUserClass(targetClass) : null;
/* 197 */     Method resolvedMethod = ClassUtils.getMostSpecificMethod(method, specificTargetClass);
/*     */     
/* 199 */     return BridgeMethodResolver.findBridgedMethod(resolvedMethod);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean canApply(Pointcut pc, Class<?> targetClass)
/*     */   {
/* 211 */     return canApply(pc, targetClass, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean canApply(Pointcut pc, Class<?> targetClass, boolean hasIntroductions)
/*     */   {
/* 225 */     Assert.notNull(pc, "Pointcut must not be null");
/* 226 */     if (!pc.getClassFilter().matches(targetClass)) {
/* 227 */       return false;
/*     */     }
/*     */     
/* 230 */     MethodMatcher methodMatcher = pc.getMethodMatcher();
/* 231 */     if (methodMatcher == MethodMatcher.TRUE)
/*     */     {
/* 233 */       return true;
/*     */     }
/*     */     
/* 236 */     IntroductionAwareMethodMatcher introductionAwareMethodMatcher = null;
/* 237 */     if ((methodMatcher instanceof IntroductionAwareMethodMatcher)) {
/* 238 */       introductionAwareMethodMatcher = (IntroductionAwareMethodMatcher)methodMatcher;
/*     */     }
/*     */     
/* 241 */     Set<Class<?>> classes = new LinkedHashSet();
/* 242 */     if (!Proxy.isProxyClass(targetClass)) {
/* 243 */       classes.add(ClassUtils.getUserClass(targetClass));
/*     */     }
/* 245 */     classes.addAll(ClassUtils.getAllInterfacesForClassAsSet(targetClass));
/*     */     
/* 247 */     for (Class<?> clazz : classes) {
/* 248 */       Method[] methods = ReflectionUtils.getAllDeclaredMethods(clazz);
/* 249 */       for (Method method : methods) {
/* 250 */         if (introductionAwareMethodMatcher != null ? introductionAwareMethodMatcher
/* 251 */           .matches(method, targetClass, hasIntroductions) : methodMatcher
/* 252 */           .matches(method, targetClass)) {
/* 253 */           return true;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 258 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean canApply(Advisor advisor, Class<?> targetClass)
/*     */   {
/* 270 */     return canApply(advisor, targetClass, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean canApply(Advisor advisor, Class<?> targetClass, boolean hasIntroductions)
/*     */   {
/* 284 */     if ((advisor instanceof IntroductionAdvisor)) {
/* 285 */       return ((IntroductionAdvisor)advisor).getClassFilter().matches(targetClass);
/*     */     }
/* 287 */     if ((advisor instanceof PointcutAdvisor)) {
/* 288 */       PointcutAdvisor pca = (PointcutAdvisor)advisor;
/* 289 */       return canApply(pca.getPointcut(), targetClass, hasIntroductions);
/*     */     }
/*     */     
/*     */ 
/* 293 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static List<Advisor> findAdvisorsThatCanApply(List<Advisor> candidateAdvisors, Class<?> clazz)
/*     */   {
/* 306 */     if (candidateAdvisors.isEmpty()) {
/* 307 */       return candidateAdvisors;
/*     */     }
/* 309 */     List<Advisor> eligibleAdvisors = new ArrayList();
/* 310 */     for (Iterator localIterator = candidateAdvisors.iterator(); localIterator.hasNext();) { candidate = (Advisor)localIterator.next();
/* 311 */       if (((candidate instanceof IntroductionAdvisor)) && (canApply(candidate, clazz)))
/* 312 */         eligibleAdvisors.add(candidate);
/*     */     }
/*     */     Advisor candidate;
/* 315 */     boolean hasIntroductions = !eligibleAdvisors.isEmpty();
/* 316 */     for (Advisor candidate : candidateAdvisors) {
/* 317 */       if (!(candidate instanceof IntroductionAdvisor))
/*     */       {
/*     */ 
/*     */ 
/* 321 */         if (canApply(candidate, clazz, hasIntroductions))
/* 322 */           eligibleAdvisors.add(candidate);
/*     */       }
/*     */     }
/* 325 */     return eligibleAdvisors;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Nullable
/*     */   public static Object invokeJoinpointUsingReflection(@Nullable Object target, Method method, Object[] args)
/*     */     throws Throwable
/*     */   {
/*     */     try
/*     */     {
/* 343 */       ReflectionUtils.makeAccessible(method);
/* 344 */       return method.invoke(target, args);
/*     */ 
/*     */     }
/*     */     catch (InvocationTargetException ex)
/*     */     {
/* 349 */       throw ex.getTargetException();
/*     */     }
/*     */     catch (IllegalArgumentException ex) {
/* 352 */       throw new AopInvocationException("AOP configuration seems to be invalid: tried calling method [" + method + "] on target [" + target + "]", ex);
/*     */     }
/*     */     catch (IllegalAccessException ex)
/*     */     {
/* 356 */       throw new AopInvocationException("Could not access method [" + method + "]", ex);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-aop-5.3.12.jar!\org\springframework\aop\support\AopUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */