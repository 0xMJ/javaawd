/*    */ package org.springframework.aop.support;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.springframework.aop.ClassFilter;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RootClassFilter
/*    */   implements ClassFilter, Serializable
/*    */ {
/*    */   private final Class<?> clazz;
/*    */   
/*    */   public RootClassFilter(Class<?> clazz)
/*    */   {
/* 37 */     Assert.notNull(clazz, "Class must not be null");
/* 38 */     this.clazz = clazz;
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean matches(Class<?> candidate)
/*    */   {
/* 44 */     return this.clazz.isAssignableFrom(candidate);
/*    */   }
/*    */   
/*    */   public boolean equals(Object other)
/*    */   {
/* 49 */     return (this == other) || (((other instanceof RootClassFilter)) && 
/* 50 */       (this.clazz.equals(((RootClassFilter)other).clazz)));
/*    */   }
/*    */   
/*    */   public int hashCode()
/*    */   {
/* 55 */     return this.clazz.hashCode();
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 60 */     return getClass().getName() + ": " + this.clazz.getName();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\spring-aop-5.3.12.jar!\org\springframework\aop\support\RootClassFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */