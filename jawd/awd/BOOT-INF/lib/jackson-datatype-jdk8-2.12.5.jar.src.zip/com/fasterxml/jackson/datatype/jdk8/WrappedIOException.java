/*    */ package com.fasterxml.jackson.datatype.jdk8;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WrappedIOException
/*    */   extends RuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public WrappedIOException(IOException cause)
/*    */   {
/* 21 */     super(cause);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public IOException getCause()
/*    */   {
/* 31 */     return (IOException)super.getCause();
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-datatype-jdk8-2.12.5.jar!\com\fasterxml\jackson\datatype\jdk8\WrappedIOException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */