/*    */ package com.fasterxml.jackson.datatype.jdk8;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.BeanDescription;
/*    */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*    */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*    */ import com.fasterxml.jackson.databind.deser.Deserializers.Base;
/*    */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*    */ import com.fasterxml.jackson.databind.type.ReferenceType;
/*    */ import java.io.Serializable;
/*    */ import java.util.Optional;
/*    */ import java.util.OptionalDouble;
/*    */ import java.util.OptionalInt;
/*    */ import java.util.OptionalLong;
/*    */ 
/*    */ public class Jdk8Deserializers extends Deserializers.Base implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public JsonDeserializer<?> findReferenceDeserializer(ReferenceType refType, DeserializationConfig config, BeanDescription beanDesc, TypeDeserializer contentTypeDeserializer, JsonDeserializer<?> contentDeserializer)
/*    */   {
/* 21 */     if (refType.hasRawClass(Optional.class)) {
/* 22 */       return new OptionalDeserializer(refType, null, contentTypeDeserializer, contentDeserializer);
/*    */     }
/*    */     
/*    */ 
/*    */ 
/*    */ 
/* 28 */     if (refType.hasRawClass(OptionalInt.class)) {
/* 29 */       return OptionalIntDeserializer.INSTANCE;
/*    */     }
/* 31 */     if (refType.hasRawClass(OptionalLong.class)) {
/* 32 */       return OptionalLongDeserializer.INSTANCE;
/*    */     }
/* 34 */     if (refType.hasRawClass(OptionalDouble.class)) {
/* 35 */       return OptionalDoubleDeserializer.INSTANCE;
/*    */     }
/* 37 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-datatype-jdk8-2.12.5.jar!\com\fasterxml\jackson\datatype\jdk8\Jdk8Deserializers.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */