/*    */ package com.fasterxml.jackson.datatype.jdk8;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.DeserializationContext;
/*    */ import com.fasterxml.jackson.databind.deser.std.StdScalarDeserializer;
/*    */ 
/*    */ public abstract class BaseScalarOptionalDeserializer<T>
/*    */   extends StdScalarDeserializer<T>
/*    */ {
/*    */   protected final T _empty;
/*    */   
/*    */   protected BaseScalarOptionalDeserializer(Class<T> cls, T empty)
/*    */   {
/* 13 */     super(cls);
/* 14 */     this._empty = empty;
/*    */   }
/*    */   
/*    */   public T getNullValue(DeserializationContext ctxt)
/*    */   {
/* 19 */     return (T)this._empty;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-datatype-jdk8-2.12.5.jar!\com\fasterxml\jackson\datatype\jdk8\BaseScalarOptionalDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */