/*    */ package com.fasterxml.jackson.datatype.jdk8;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.BeanDescription;
/*    */ import com.fasterxml.jackson.databind.JavaType;
/*    */ import com.fasterxml.jackson.databind.SerializationConfig;
/*    */ import com.fasterxml.jackson.databind.ser.BeanPropertyWriter;
/*    */ import com.fasterxml.jackson.databind.ser.BeanSerializerModifier;
/*    */ import java.util.List;
/*    */ import java.util.Optional;
/*    */ import java.util.OptionalDouble;
/*    */ import java.util.OptionalInt;
/*    */ import java.util.OptionalLong;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Jdk8BeanSerializerModifier
/*    */   extends BeanSerializerModifier
/*    */ {
/*    */   public List<BeanPropertyWriter> changeProperties(SerializationConfig config, BeanDescription beanDesc, List<BeanPropertyWriter> beanProperties)
/*    */   {
/* 26 */     for (int i = 0; i < beanProperties.size(); i++) {
/* 27 */       BeanPropertyWriter writer = (BeanPropertyWriter)beanProperties.get(i);
/* 28 */       JavaType type = writer.getType();
/*    */       Object empty;
/*    */       Object empty;
/* 31 */       if (type.isTypeOrSubTypeOf(Optional.class)) {
/* 32 */         empty = Optional.empty(); } else { Object empty;
/* 33 */         if (type.hasRawClass(OptionalLong.class)) {
/* 34 */           empty = OptionalLong.empty(); } else { Object empty;
/* 35 */           if (type.hasRawClass(OptionalInt.class)) {
/* 36 */             empty = OptionalInt.empty();
/* 37 */           } else { if (!type.hasRawClass(OptionalDouble.class)) continue;
/* 38 */             empty = OptionalDouble.empty();
/*    */           }
/*    */         }
/*    */       }
/* 42 */       beanProperties.set(i, new Jdk8OptionalBeanPropertyWriter(writer, empty));
/*    */     }
/* 44 */     return beanProperties;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-datatype-jdk8-2.12.5.jar!\com\fasterxml\jackson\datatype\jdk8\Jdk8BeanSerializerModifier.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */