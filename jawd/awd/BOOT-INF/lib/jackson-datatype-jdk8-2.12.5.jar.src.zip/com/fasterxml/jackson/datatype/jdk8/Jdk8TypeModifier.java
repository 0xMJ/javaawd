/*    */ package com.fasterxml.jackson.datatype.jdk8;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.JavaType;
/*    */ import com.fasterxml.jackson.databind.type.ReferenceType;
/*    */ import com.fasterxml.jackson.databind.type.TypeBindings;
/*    */ import com.fasterxml.jackson.databind.type.TypeFactory;
/*    */ import com.fasterxml.jackson.databind.type.TypeModifier;
/*    */ import java.io.Serializable;
/*    */ import java.lang.reflect.Type;
/*    */ import java.util.Optional;
/*    */ import java.util.OptionalDouble;
/*    */ import java.util.OptionalInt;
/*    */ import java.util.OptionalLong;
/*    */ 
/*    */ public class Jdk8TypeModifier
/*    */   extends TypeModifier
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public JavaType modifyType(JavaType type, Type jdkType, TypeBindings bindings, TypeFactory typeFactory)
/*    */   {
/* 23 */     if ((type.isReferenceType()) || (type.isContainerType())) {
/* 24 */       return type;
/*    */     }
/* 26 */     Class<?> raw = type.getRawClass();
/*    */     
/*    */     JavaType refType;
/*    */     
/* 30 */     if (raw == Optional.class)
/*    */     {
/*    */ 
/* 33 */       refType = type.containedTypeOrUnknown(0); } else { JavaType refType;
/* 34 */       if (raw == OptionalInt.class) {
/* 35 */         refType = typeFactory.constructType(Integer.TYPE); } else { JavaType refType;
/* 36 */         if (raw == OptionalLong.class) {
/* 37 */           refType = typeFactory.constructType(Long.TYPE); } else { JavaType refType;
/* 38 */           if (raw == OptionalDouble.class) {
/* 39 */             refType = typeFactory.constructType(Double.TYPE);
/*    */           } else
/* 41 */             return type; } } }
/*    */     JavaType refType;
/* 43 */     return ReferenceType.upgradeFrom(type, refType);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-datatype-jdk8-2.12.5.jar!\com\fasterxml\jackson\datatype\jdk8\Jdk8TypeModifier.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */