/*     */ package com.fasterxml.jackson.datatype.jsr310.ser;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat.Shape;
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.core.type.WritableTypeId;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.SerializerProvider;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatVisitorWrapper;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonStringFormatVisitor;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonValueFormat;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*     */ import java.io.IOException;
/*     */ import java.time.LocalTime;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ import java.time.temporal.ChronoField;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocalTimeSerializer
/*     */   extends JSR310FormattedSerializerBase<LocalTime>
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  45 */   public static final LocalTimeSerializer INSTANCE = new LocalTimeSerializer();
/*     */   
/*     */   protected LocalTimeSerializer() {
/*  48 */     this(null);
/*     */   }
/*     */   
/*     */   public LocalTimeSerializer(DateTimeFormatter formatter) {
/*  52 */     super(LocalTime.class, formatter);
/*     */   }
/*     */   
/*     */   protected LocalTimeSerializer(LocalTimeSerializer base, Boolean useTimestamp, DateTimeFormatter formatter) {
/*  56 */     this(base, useTimestamp, null, formatter);
/*     */   }
/*     */   
/*     */   protected LocalTimeSerializer(LocalTimeSerializer base, Boolean useTimestamp, Boolean useNanoseconds, DateTimeFormatter formatter) {
/*  60 */     super(base, useTimestamp, useNanoseconds, formatter, null);
/*     */   }
/*     */   
/*     */   protected JSR310FormattedSerializerBase<LocalTime> withFormat(Boolean useTimestamp, DateTimeFormatter dtf, JsonFormat.Shape shape)
/*     */   {
/*  65 */     return new LocalTimeSerializer(this, useTimestamp, dtf);
/*     */   }
/*     */   
/*     */   protected DateTimeFormatter _defaultFormatter()
/*     */   {
/*  70 */     return DateTimeFormatter.ISO_LOCAL_TIME;
/*     */   }
/*     */   
/*     */ 
/*     */   public void serialize(LocalTime value, JsonGenerator g, SerializerProvider provider)
/*     */     throws IOException
/*     */   {
/*  77 */     if (useTimestamp(provider)) {
/*  78 */       g.writeStartArray();
/*  79 */       _serializeAsArrayContents(value, g, provider);
/*  80 */       g.writeEndArray();
/*     */     } else {
/*  82 */       DateTimeFormatter dtf = this._formatter;
/*  83 */       if (dtf == null) {
/*  84 */         dtf = _defaultFormatter();
/*     */       }
/*  86 */       g.writeString(value.format(dtf));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void serializeWithType(LocalTime value, JsonGenerator g, SerializerProvider provider, TypeSerializer typeSer)
/*     */     throws IOException
/*     */   {
/*  94 */     WritableTypeId typeIdDef = typeSer.writeTypePrefix(g, typeSer
/*  95 */       .typeId(value, serializationShape(provider)));
/*     */     
/*  97 */     if (typeIdDef.valueShape == JsonToken.START_ARRAY) {
/*  98 */       _serializeAsArrayContents(value, g, provider);
/*     */     } else {
/* 100 */       DateTimeFormatter dtf = this._formatter;
/* 101 */       if (dtf == null) {
/* 102 */         dtf = _defaultFormatter();
/*     */       }
/* 104 */       g.writeString(value.format(dtf));
/*     */     }
/* 106 */     typeSer.writeTypeSuffix(g, typeIdDef);
/*     */   }
/*     */   
/*     */   private final void _serializeAsArrayContents(LocalTime value, JsonGenerator g, SerializerProvider provider)
/*     */     throws IOException
/*     */   {
/* 112 */     g.writeNumber(value.getHour());
/* 113 */     g.writeNumber(value.getMinute());
/* 114 */     int secs = value.getSecond();
/* 115 */     int nanos = value.getNano();
/* 116 */     if ((secs > 0) || (nanos > 0))
/*     */     {
/* 118 */       g.writeNumber(secs);
/* 119 */       if (nanos > 0) {
/* 120 */         if (useNanoseconds(provider)) {
/* 121 */           g.writeNumber(nanos);
/*     */         } else {
/* 123 */           g.writeNumber(value.get(ChronoField.MILLI_OF_SECOND));
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected JsonToken serializationShape(SerializerProvider provider)
/*     */   {
/* 131 */     return useTimestamp(provider) ? JsonToken.START_ARRAY : JsonToken.VALUE_STRING;
/*     */   }
/*     */   
/*     */   protected JSR310FormattedSerializerBase<?> withFeatures(Boolean writeZoneId, Boolean writeNanoseconds)
/*     */   {
/* 136 */     return new LocalTimeSerializer(this, this._useTimestamp, writeNanoseconds, this._formatter);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void acceptJsonFormatVisitor(JsonFormatVisitorWrapper visitor, JavaType typeHint)
/*     */     throws JsonMappingException
/*     */   {
/* 144 */     if (useTimestamp(visitor.getProvider())) {
/* 145 */       _acceptTimestampVisitor(visitor, typeHint);
/*     */     } else {
/* 147 */       JsonStringFormatVisitor v2 = visitor.expectStringFormat(typeHint);
/* 148 */       if (v2 != null) {
/* 149 */         v2.format(JsonValueFormat.TIME);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-datatype-jsr310-2.12.5.jar!\com\fasterxml\jackson\datatype\jsr310\ser\LocalTimeSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */