/*     */ package com.fasterxml.jackson.datatype.jsr310.ser;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat.Shape;
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.JsonParser.NumberType;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.SerializationConfig;
/*     */ import com.fasterxml.jackson.databind.SerializerProvider;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatVisitorWrapper;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonIntegerFormatVisitor;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonNumberFormatVisitor;
/*     */ import com.fasterxml.jackson.datatype.jsr310.DecimalUtils;
/*     */ import java.io.IOException;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ import java.time.temporal.Temporal;
/*     */ import java.util.TimeZone;
/*     */ import java.util.function.ToIntFunction;
/*     */ import java.util.function.ToLongFunction;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class InstantSerializerBase<T extends Temporal>
/*     */   extends JSR310FormattedSerializerBase<T>
/*     */ {
/*     */   private final DateTimeFormatter defaultFormat;
/*     */   private final ToLongFunction<T> getEpochMillis;
/*     */   private final ToLongFunction<T> getEpochSeconds;
/*     */   private final ToIntFunction<T> getNanoseconds;
/*     */   
/*     */   protected InstantSerializerBase(Class<T> supportedType, ToLongFunction<T> getEpochMillis, ToLongFunction<T> getEpochSeconds, ToIntFunction<T> getNanoseconds, DateTimeFormatter formatter)
/*     */   {
/*  61 */     super(supportedType, null);
/*  62 */     this.defaultFormat = formatter;
/*  63 */     this.getEpochMillis = getEpochMillis;
/*  64 */     this.getEpochSeconds = getEpochSeconds;
/*  65 */     this.getNanoseconds = getNanoseconds;
/*     */   }
/*     */   
/*     */ 
/*     */   protected InstantSerializerBase(InstantSerializerBase<T> base, Boolean useTimestamp, DateTimeFormatter dtf)
/*     */   {
/*  71 */     this(base, useTimestamp, null, dtf);
/*     */   }
/*     */   
/*     */ 
/*     */   protected InstantSerializerBase(InstantSerializerBase<T> base, Boolean useTimestamp, Boolean useNanoseconds, DateTimeFormatter dtf)
/*     */   {
/*  77 */     super(base, useTimestamp, useNanoseconds, dtf, null);
/*  78 */     this.defaultFormat = base.defaultFormat;
/*  79 */     this.getEpochMillis = base.getEpochMillis;
/*  80 */     this.getEpochSeconds = base.getEpochSeconds;
/*  81 */     this.getNanoseconds = base.getNanoseconds;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected abstract JSR310FormattedSerializerBase<?> withFormat(Boolean paramBoolean, DateTimeFormatter paramDateTimeFormatter, JsonFormat.Shape paramShape);
/*     */   
/*     */ 
/*     */   public void serialize(T value, JsonGenerator generator, SerializerProvider provider)
/*     */     throws IOException
/*     */   {
/*  92 */     if (useTimestamp(provider)) {
/*  93 */       if (useNanoseconds(provider)) {
/*  94 */         generator.writeNumber(DecimalUtils.toBigDecimal(this.getEpochSeconds
/*  95 */           .applyAsLong(value), this.getNanoseconds.applyAsInt(value)));
/*     */         
/*  97 */         return;
/*     */       }
/*  99 */       generator.writeNumber(this.getEpochMillis.applyAsLong(value));
/* 100 */       return;
/*     */     }
/*     */     
/* 103 */     generator.writeString(formatValue(value, provider));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void _acceptTimestampVisitor(JsonFormatVisitorWrapper visitor, JavaType typeHint)
/*     */     throws JsonMappingException
/*     */   {
/* 111 */     if (useNanoseconds(visitor.getProvider())) {
/* 112 */       JsonNumberFormatVisitor v2 = visitor.expectNumberFormat(typeHint);
/* 113 */       if (v2 != null) {
/* 114 */         v2.numberType(JsonParser.NumberType.BIG_DECIMAL);
/*     */       }
/*     */     } else {
/* 117 */       JsonIntegerFormatVisitor v2 = visitor.expectIntegerFormat(typeHint);
/* 118 */       if (v2 != null) {
/* 119 */         v2.numberType(JsonParser.NumberType.LONG);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected JsonToken serializationShape(SerializerProvider provider)
/*     */   {
/* 126 */     if (useTimestamp(provider)) {
/* 127 */       if (useNanoseconds(provider)) {
/* 128 */         return JsonToken.VALUE_NUMBER_FLOAT;
/*     */       }
/* 130 */       return JsonToken.VALUE_NUMBER_INT;
/*     */     }
/* 132 */     return JsonToken.VALUE_STRING;
/*     */   }
/*     */   
/*     */ 
/*     */   protected String formatValue(T value, SerializerProvider provider)
/*     */   {
/* 138 */     DateTimeFormatter formatter = this._formatter != null ? this._formatter : this.defaultFormat;
/* 139 */     if (formatter != null) {
/* 140 */       if (formatter.getZone() == null)
/*     */       {
/*     */ 
/*     */ 
/* 144 */         if (provider.getConfig().hasExplicitTimeZone()) {
/* 145 */           formatter = formatter.withZone(provider.getTimeZone().toZoneId());
/*     */         }
/*     */       }
/* 148 */       return formatter.format(value);
/*     */     }
/*     */     
/* 151 */     return value.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-datatype-jsr310-2.12.5.jar!\com\fasterxml\jackson\datatype\jsr310\ser\InstantSerializerBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */