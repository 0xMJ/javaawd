/*    */ package com.fasterxml.jackson.datatype.jsr310.deser.key;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.DeserializationContext;
/*    */ import java.io.IOException;
/*    */ import java.time.DateTimeException;
/*    */ import java.time.OffsetDateTime;
/*    */ import java.time.format.DateTimeFormatter;
/*    */ 
/*    */ public class OffsetDateTimeKeyDeserializer
/*    */   extends Jsr310KeyDeserializer
/*    */ {
/* 12 */   public static final OffsetDateTimeKeyDeserializer INSTANCE = new OffsetDateTimeKeyDeserializer();
/*    */   
/*    */ 
/*    */ 
/*    */   protected OffsetDateTime deserialize(String key, DeserializationContext ctxt)
/*    */     throws IOException
/*    */   {
/*    */     try
/*    */     {
/* 21 */       return OffsetDateTime.parse(key, DateTimeFormatter.ISO_OFFSET_DATE_TIME);
/*    */     } catch (DateTimeException e) {
/* 23 */       return (OffsetDateTime)_handleDateTimeException(ctxt, OffsetDateTime.class, e, key);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-datatype-jsr310-2.12.5.jar!\com\fasterxml\jackson\datatype\jsr310\deser\key\OffsetDateTimeKeyDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */