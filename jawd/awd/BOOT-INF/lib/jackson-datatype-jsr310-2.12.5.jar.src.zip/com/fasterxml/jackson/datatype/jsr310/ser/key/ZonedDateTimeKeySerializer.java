/*    */ package com.fasterxml.jackson.datatype.jsr310.ser.key;
/*    */ 
/*    */ import com.fasterxml.jackson.core.JsonGenerator;
/*    */ import com.fasterxml.jackson.core.JsonProcessingException;
/*    */ import com.fasterxml.jackson.databind.JsonSerializer;
/*    */ import com.fasterxml.jackson.databind.SerializationFeature;
/*    */ import com.fasterxml.jackson.databind.SerializerProvider;
/*    */ import com.fasterxml.jackson.datatype.jsr310.DecimalUtils;
/*    */ import java.io.IOException;
/*    */ import java.time.Instant;
/*    */ import java.time.ZonedDateTime;
/*    */ import java.time.format.DateTimeFormatter;
/*    */ 
/*    */ public class ZonedDateTimeKeySerializer extends JsonSerializer<ZonedDateTime>
/*    */ {
/* 16 */   public static final ZonedDateTimeKeySerializer INSTANCE = new ZonedDateTimeKeySerializer();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void serialize(ZonedDateTime value, JsonGenerator gen, SerializerProvider serializers)
/*    */     throws IOException, JsonProcessingException
/*    */   {
/* 28 */     if (serializers.isEnabled(SerializationFeature.WRITE_DATES_WITH_ZONE_ID)) {
/* 29 */       gen.writeFieldName(DateTimeFormatter.ISO_ZONED_DATE_TIME.format(value));
/* 30 */     } else if (useTimestamps(serializers)) {
/* 31 */       if (useNanos(serializers)) {
/* 32 */         gen.writeFieldName(DecimalUtils.toBigDecimal(value.toEpochSecond(), value.getNano()).toString());
/*    */       } else {
/* 34 */         gen.writeFieldName(String.valueOf(value.toInstant().toEpochMilli()));
/*    */       }
/*    */     } else {
/* 37 */       gen.writeFieldName(DateTimeFormatter.ISO_OFFSET_DATE_TIME.format(value));
/*    */     }
/*    */   }
/*    */   
/*    */   private static boolean useNanos(SerializerProvider serializers) {
/* 42 */     return serializers.isEnabled(SerializationFeature.WRITE_DATE_TIMESTAMPS_AS_NANOSECONDS);
/*    */   }
/*    */   
/*    */   private static boolean useTimestamps(SerializerProvider serializers) {
/* 46 */     return serializers.isEnabled(SerializationFeature.WRITE_DATE_KEYS_AS_TIMESTAMPS);
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-datatype-jsr310-2.12.5.jar!\com\fasterxml\jackson\datatype\jsr310\ser\key\ZonedDateTimeKeySerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */