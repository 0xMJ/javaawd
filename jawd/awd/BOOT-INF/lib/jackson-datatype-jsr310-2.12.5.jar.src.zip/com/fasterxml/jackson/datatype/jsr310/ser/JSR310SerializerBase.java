/*    */ package com.fasterxml.jackson.datatype.jsr310.ser;
/*    */ 
/*    */ import com.fasterxml.jackson.core.JsonGenerator;
/*    */ import com.fasterxml.jackson.core.JsonToken;
/*    */ import com.fasterxml.jackson.core.type.WritableTypeId;
/*    */ import com.fasterxml.jackson.databind.SerializerProvider;
/*    */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*    */ import com.fasterxml.jackson.databind.ser.std.StdSerializer;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class JSR310SerializerBase<T>
/*    */   extends StdSerializer<T>
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   protected JSR310SerializerBase(Class<?> supportedType)
/*    */   {
/* 22 */     super(supportedType, false);
/*    */   }
/*    */   
/*    */ 
/*    */   public void serializeWithType(T value, JsonGenerator g, SerializerProvider provider, TypeSerializer typeSer)
/*    */     throws IOException
/*    */   {
/* 29 */     WritableTypeId typeIdDef = typeSer.writeTypePrefix(g, typeSer
/* 30 */       .typeId(value, serializationShape(provider)));
/* 31 */     serialize(value, g, provider);
/* 32 */     typeSer.writeTypeSuffix(g, typeIdDef);
/*    */   }
/*    */   
/*    */   protected abstract JsonToken serializationShape(SerializerProvider paramSerializerProvider);
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-datatype-jsr310-2.12.5.jar!\com\fasterxml\jackson\datatype\jsr310\ser\JSR310SerializerBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */