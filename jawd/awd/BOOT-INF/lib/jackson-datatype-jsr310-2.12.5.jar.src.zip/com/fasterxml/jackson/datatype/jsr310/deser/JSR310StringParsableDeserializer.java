/*     */ package com.fasterxml.jackson.datatype.jsr310.deser;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat.Value;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.core.util.VersionUtil;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.cfg.CoercionAction;
/*     */ import com.fasterxml.jackson.databind.cfg.CoercionInputShape;
/*     */ import com.fasterxml.jackson.databind.deser.ContextualDeserializer;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*     */ import java.io.IOException;
/*     */ import java.time.DateTimeException;
/*     */ import java.time.Period;
/*     */ import java.time.ZoneId;
/*     */ import java.time.ZoneOffset;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JSR310StringParsableDeserializer
/*     */   extends JSR310DeserializerBase<Object>
/*     */   implements ContextualDeserializer
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected static final int TYPE_PERIOD = 1;
/*     */   protected static final int TYPE_ZONE_ID = 2;
/*     */   protected static final int TYPE_ZONE_OFFSET = 3;
/*  60 */   public static final JsonDeserializer<Period> PERIOD = createDeserializer(Period.class, 1);
/*     */   
/*     */ 
/*  63 */   public static final JsonDeserializer<ZoneId> ZONE_ID = createDeserializer(ZoneId.class, 2);
/*     */   
/*     */ 
/*  66 */   public static final JsonDeserializer<ZoneOffset> ZONE_OFFSET = createDeserializer(ZoneOffset.class, 3);
/*     */   
/*     */   protected final int _typeSelector;
/*     */   
/*     */ 
/*     */   protected JSR310StringParsableDeserializer(Class<?> supportedType, int typeSelector)
/*     */   {
/*  73 */     super(supportedType);
/*  74 */     this._typeSelector = typeSelector;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected JSR310StringParsableDeserializer(JSR310StringParsableDeserializer base, Boolean leniency)
/*     */   {
/*  81 */     super(base, leniency);
/*  82 */     this._typeSelector = base._typeSelector;
/*     */   }
/*     */   
/*     */   protected static <T> JsonDeserializer<T> createDeserializer(Class<T> type, int typeId)
/*     */   {
/*  87 */     return new JSR310StringParsableDeserializer(type, typeId);
/*     */   }
/*     */   
/*     */   protected JSR310StringParsableDeserializer withLeniency(Boolean leniency)
/*     */   {
/*  92 */     if (this._isLenient == (!Boolean.FALSE.equals(leniency))) {
/*  93 */       return this;
/*     */     }
/*     */     
/*     */ 
/*  97 */     return new JSR310StringParsableDeserializer(this, leniency);
/*     */   }
/*     */   
/*     */ 
/*     */   public JsonDeserializer<?> createContextual(DeserializationContext ctxt, BeanProperty property)
/*     */     throws JsonMappingException
/*     */   {
/* 104 */     JsonFormat.Value format = findFormatOverrides(ctxt, property, handledType());
/* 105 */     JSR310StringParsableDeserializer deser = this;
/* 106 */     if ((format != null) && 
/* 107 */       (format.hasLenient())) {
/* 108 */       Boolean leniency = format.getLenient();
/* 109 */       if (leniency != null) {
/* 110 */         deser = withLeniency(leniency);
/*     */       }
/*     */     }
/*     */     
/* 114 */     return deser;
/*     */   }
/*     */   
/*     */   public Object deserialize(JsonParser p, DeserializationContext ctxt)
/*     */     throws IOException
/*     */   {
/* 120 */     if (p.hasToken(JsonToken.VALUE_STRING)) {
/* 121 */       return _fromString(p, ctxt, p.getText());
/*     */     }
/*     */     
/* 124 */     if (p.isExpectedStartObjectToken()) {
/* 125 */       return _fromString(p, ctxt, ctxt
/* 126 */         .extractScalarFromObject(p, this, handledType()));
/*     */     }
/* 128 */     if (p.hasToken(JsonToken.VALUE_EMBEDDED_OBJECT))
/*     */     {
/*     */ 
/* 131 */       return p.getEmbeddedObject();
/*     */     }
/* 133 */     if (p.isExpectedStartArrayToken()) {
/* 134 */       return _deserializeFromArray(p, ctxt);
/*     */     }
/*     */     
/* 137 */     throw ctxt.wrongTokenException(p, handledType(), JsonToken.VALUE_STRING, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object deserializeWithType(JsonParser parser, DeserializationContext context, TypeDeserializer deserializer)
/*     */     throws IOException
/*     */   {
/* 147 */     JsonToken t = parser.getCurrentToken();
/* 148 */     if ((t != null) && (t.isScalarValue())) {
/* 149 */       return deserialize(parser, context);
/*     */     }
/* 151 */     return deserializer.deserializeTypedFromAny(parser, context);
/*     */   }
/*     */   
/*     */   protected Object _fromString(JsonParser p, DeserializationContext ctxt, String string)
/*     */     throws IOException
/*     */   {
/* 157 */     string = string.trim();
/* 158 */     if (string.length() == 0) {
/* 159 */       CoercionAction act = ctxt.findCoercionAction(logicalType(), this._valueClass, CoercionInputShape.EmptyString);
/*     */       
/* 161 */       if (act == CoercionAction.Fail) {
/* 162 */         ctxt.reportInputMismatch(this, "Cannot coerce empty String (\"\") to %s (but could if enabling coercion using `CoercionConfig`)", new Object[] {
/*     */         
/* 164 */           _coercedTypeDesc() });
/*     */       }
/*     */       
/*     */ 
/* 168 */       if (!isLenient()) {
/* 169 */         return _failForNotLenient(p, ctxt, JsonToken.VALUE_STRING);
/*     */       }
/* 171 */       if (act == CoercionAction.AsEmpty) {
/* 172 */         return getEmptyValue(ctxt);
/*     */       }
/*     */       
/* 175 */       return null;
/*     */     }
/*     */     try {
/* 178 */       switch (this._typeSelector) {
/*     */       case 1: 
/* 180 */         return Period.parse(string);
/*     */       case 2: 
/* 182 */         return ZoneId.of(string);
/*     */       case 3: 
/* 184 */         return ZoneOffset.of(string);
/*     */       }
/*     */     } catch (DateTimeException e) {
/* 187 */       return _handleDateTimeException(ctxt, e, string);
/*     */     }
/* 189 */     VersionUtil.throwInternal();
/* 190 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-datatype-jsr310-2.12.5.jar!\com\fasterxml\jackson\datatype\jsr310\deser\JSR310StringParsableDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */