/*     */ package com.fasterxml.jackson.datatype.jsr310.deser;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat.Shape;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.core.StreamReadCapability;
/*     */ import com.fasterxml.jackson.core.io.NumberInput;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import java.io.IOException;
/*     */ import java.time.DateTimeException;
/*     */ import java.time.Year;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class YearDeserializer
/*     */   extends JSR310DateTimeDeserializerBase<Year>
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  40 */   public static final YearDeserializer INSTANCE = new YearDeserializer();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public YearDeserializer()
/*     */   {
/*  47 */     this(null);
/*     */   }
/*     */   
/*     */   public YearDeserializer(DateTimeFormatter formatter) {
/*  51 */     super(Year.class, formatter);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected YearDeserializer(YearDeserializer base, Boolean leniency)
/*     */   {
/*  58 */     super(base, leniency);
/*     */   }
/*     */   
/*     */   protected YearDeserializer withDateFormat(DateTimeFormatter dtf)
/*     */   {
/*  63 */     return new YearDeserializer(dtf);
/*     */   }
/*     */   
/*     */   protected YearDeserializer withLeniency(Boolean leniency)
/*     */   {
/*  68 */     return new YearDeserializer(this, leniency);
/*     */   }
/*     */   
/*     */   protected YearDeserializer withShape(JsonFormat.Shape shape) {
/*  72 */     return this;
/*     */   }
/*     */   
/*     */   public Year deserialize(JsonParser parser, DeserializationContext context) throws IOException
/*     */   {
/*  77 */     JsonToken t = parser.currentToken();
/*  78 */     if (t == JsonToken.VALUE_STRING) {
/*  79 */       return _fromString(parser, context, parser.getText());
/*     */     }
/*     */     
/*  82 */     if (t == JsonToken.START_OBJECT) {
/*  83 */       return _fromString(parser, context, context
/*  84 */         .extractScalarFromObject(parser, this, handledType()));
/*     */     }
/*  86 */     if (t == JsonToken.VALUE_NUMBER_INT) {
/*  87 */       return _fromNumber(context, parser.getIntValue());
/*     */     }
/*  89 */     if (t == JsonToken.VALUE_EMBEDDED_OBJECT) {
/*  90 */       return (Year)parser.getEmbeddedObject();
/*     */     }
/*  92 */     if (parser.hasToken(JsonToken.START_ARRAY)) {
/*  93 */       return (Year)_deserializeFromArray(parser, context);
/*     */     }
/*  95 */     return (Year)_handleUnexpectedToken(context, parser, new JsonToken[] { JsonToken.VALUE_STRING, JsonToken.VALUE_NUMBER_INT });
/*     */   }
/*     */   
/*     */   protected Year _fromString(JsonParser p, DeserializationContext ctxt, String string0)
/*     */     throws IOException
/*     */   {
/* 101 */     String string = string0.trim();
/* 102 */     if (string.length() == 0)
/*     */     {
/*     */ 
/*     */ 
/* 106 */       return (Year)_fromEmptyString(p, ctxt, string);
/*     */     }
/*     */     
/* 109 */     if ((ctxt.isEnabled(StreamReadCapability.UNTYPED_SCALARS)) && 
/* 110 */       (_isValidTimestampString(string))) {
/* 111 */       return _fromNumber(ctxt, NumberInput.parseInt(string));
/*     */     }
/*     */     try {
/* 114 */       if (this._formatter == null) {
/* 115 */         return Year.parse(string);
/*     */       }
/* 117 */       return Year.parse(string, this._formatter);
/*     */     } catch (DateTimeException e) {
/* 119 */       return (Year)_handleDateTimeException(ctxt, e, string);
/*     */     }
/*     */   }
/*     */   
/*     */   protected Year _fromNumber(DeserializationContext ctxt, int value) {
/* 124 */     return Year.of(value);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-datatype-jsr310-2.12.5.jar!\com\fasterxml\jackson\datatype\jsr310\deser\YearDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */