/*     */ package com.fasterxml.jackson.datatype.jsr310.deser;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat.Shape;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*     */ import java.io.IOException;
/*     */ import java.time.DateTimeException;
/*     */ import java.time.Instant;
/*     */ import java.time.LocalDate;
/*     */ import java.time.LocalDateTime;
/*     */ import java.time.ZoneOffset;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocalDateDeserializer
/*     */   extends JSR310DateTimeDeserializerBase<LocalDate>
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  41 */   private static final DateTimeFormatter DEFAULT_FORMATTER = DateTimeFormatter.ISO_LOCAL_DATE;
/*     */   
/*  43 */   public static final LocalDateDeserializer INSTANCE = new LocalDateDeserializer();
/*     */   
/*     */   protected LocalDateDeserializer() {
/*  46 */     this(DEFAULT_FORMATTER);
/*     */   }
/*     */   
/*     */   public LocalDateDeserializer(DateTimeFormatter dtf) {
/*  50 */     super(LocalDate.class, dtf);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public LocalDateDeserializer(LocalDateDeserializer base, DateTimeFormatter dtf)
/*     */   {
/*  57 */     super(base, dtf);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected LocalDateDeserializer(LocalDateDeserializer base, Boolean leniency)
/*     */   {
/*  64 */     super(base, leniency);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected LocalDateDeserializer(LocalDateDeserializer base, JsonFormat.Shape shape)
/*     */   {
/*  71 */     super(base, shape);
/*     */   }
/*     */   
/*     */   protected LocalDateDeserializer withDateFormat(DateTimeFormatter dtf)
/*     */   {
/*  76 */     return new LocalDateDeserializer(this, dtf);
/*     */   }
/*     */   
/*     */   protected LocalDateDeserializer withLeniency(Boolean leniency)
/*     */   {
/*  81 */     return new LocalDateDeserializer(this, leniency);
/*     */   }
/*     */   
/*     */   protected LocalDateDeserializer withShape(JsonFormat.Shape shape) {
/*  85 */     return new LocalDateDeserializer(this, shape);
/*     */   }
/*     */   
/*     */   public LocalDate deserialize(JsonParser parser, DeserializationContext context) throws IOException
/*     */   {
/*  90 */     if (parser.hasToken(JsonToken.VALUE_STRING)) {
/*  91 */       return _fromString(parser, context, parser.getText());
/*     */     }
/*     */     
/*  94 */     if (parser.isExpectedStartObjectToken()) {
/*  95 */       return _fromString(parser, context, context
/*  96 */         .extractScalarFromObject(parser, this, handledType()));
/*     */     }
/*  98 */     if (parser.isExpectedStartArrayToken()) {
/*  99 */       JsonToken t = parser.nextToken();
/* 100 */       if (t == JsonToken.END_ARRAY) {
/* 101 */         return null;
/*     */       }
/* 103 */       if ((context.isEnabled(DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS)) && ((t == JsonToken.VALUE_STRING) || (t == JsonToken.VALUE_EMBEDDED_OBJECT)))
/*     */       {
/* 105 */         LocalDate parsed = deserialize(parser, context);
/* 106 */         if (parser.nextToken() != JsonToken.END_ARRAY) {
/* 107 */           handleMissingEndArrayForSingle(parser, context);
/*     */         }
/* 109 */         return parsed;
/*     */       }
/* 111 */       if (t == JsonToken.VALUE_NUMBER_INT) {
/* 112 */         int year = parser.getIntValue();
/* 113 */         int month = parser.nextIntValue(-1);
/* 114 */         int day = parser.nextIntValue(-1);
/*     */         
/* 116 */         if (parser.nextToken() != JsonToken.END_ARRAY) {
/* 117 */           throw context.wrongTokenException(parser, handledType(), JsonToken.END_ARRAY, "Expected array to end");
/*     */         }
/*     */         
/* 120 */         return LocalDate.of(year, month, day);
/*     */       }
/* 122 */       context.reportInputMismatch(handledType(), "Unexpected token (%s) within Array, expected VALUE_NUMBER_INT", new Object[] { t });
/*     */     }
/*     */     
/*     */ 
/* 126 */     if (parser.hasToken(JsonToken.VALUE_EMBEDDED_OBJECT)) {
/* 127 */       return (LocalDate)parser.getEmbeddedObject();
/*     */     }
/*     */     
/* 130 */     if (parser.hasToken(JsonToken.VALUE_NUMBER_INT))
/*     */     {
/* 132 */       if ((this._shape == JsonFormat.Shape.NUMBER_INT) || (isLenient())) {
/* 133 */         return LocalDate.ofEpochDay(parser.getLongValue());
/*     */       }
/* 135 */       return (LocalDate)_failForNotLenient(parser, context, JsonToken.VALUE_STRING);
/*     */     }
/* 137 */     return (LocalDate)_handleUnexpectedToken(context, parser, "Expected array or string.", new Object[0]);
/*     */   }
/*     */   
/*     */   protected LocalDate _fromString(JsonParser p, DeserializationContext ctxt, String string0)
/*     */     throws IOException
/*     */   {
/* 143 */     String string = string0.trim();
/* 144 */     if (string.length() == 0)
/*     */     {
/*     */ 
/*     */ 
/* 148 */       return (LocalDate)_fromEmptyString(p, ctxt, string);
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 153 */       DateTimeFormatter format = this._formatter;
/* 154 */       if (format == DEFAULT_FORMATTER)
/*     */       {
/* 156 */         if ((string.length() > 10) && (string.charAt(10) == 'T')) {
/* 157 */           if (string.endsWith("Z")) {
/* 158 */             return LocalDateTime.ofInstant(Instant.parse(string), ZoneOffset.UTC).toLocalDate();
/*     */           }
/* 160 */           return LocalDate.parse(string, DateTimeFormatter.ISO_LOCAL_DATE_TIME);
/*     */         }
/*     */       }
/*     */       
/* 164 */       return LocalDate.parse(string, format);
/*     */     } catch (DateTimeException e) {
/* 166 */       return (LocalDate)_handleDateTimeException(ctxt, e, string);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-datatype-jsr310-2.12.5.jar!\com\fasterxml\jackson\datatype\jsr310\deser\LocalDateDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */