/*     */ package com.fasterxml.jackson.datatype.jsr310.ser;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat.Shape;
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.core.type.WritableTypeId;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.SerializerProvider;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatVisitorWrapper;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonStringFormatVisitor;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonValueFormat;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*     */ import java.io.IOException;
/*     */ import java.time.YearMonth;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class YearMonthSerializer
/*     */   extends JSR310FormattedSerializerBase<YearMonth>
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  45 */   public static final YearMonthSerializer INSTANCE = new YearMonthSerializer();
/*     */   
/*     */   protected YearMonthSerializer() {
/*  48 */     this(null);
/*     */   }
/*     */   
/*     */   public YearMonthSerializer(DateTimeFormatter formatter) {
/*  52 */     super(YearMonth.class, formatter);
/*     */   }
/*     */   
/*     */   private YearMonthSerializer(YearMonthSerializer base, Boolean useTimestamp, DateTimeFormatter formatter)
/*     */   {
/*  57 */     super(base, useTimestamp, formatter, null);
/*     */   }
/*     */   
/*     */ 
/*     */   protected YearMonthSerializer withFormat(Boolean useTimestamp, DateTimeFormatter formatter, JsonFormat.Shape shape)
/*     */   {
/*  63 */     return new YearMonthSerializer(this, useTimestamp, formatter);
/*     */   }
/*     */   
/*     */   public void serialize(YearMonth value, JsonGenerator g, SerializerProvider provider)
/*     */     throws IOException
/*     */   {
/*  69 */     if (useTimestamp(provider)) {
/*  70 */       g.writeStartArray();
/*  71 */       _serializeAsArrayContents(value, g, provider);
/*  72 */       g.writeEndArray();
/*  73 */       return;
/*     */     }
/*  75 */     g.writeString(this._formatter == null ? value.toString() : value.format(this._formatter));
/*     */   }
/*     */   
/*     */ 
/*     */   public void serializeWithType(YearMonth value, JsonGenerator g, SerializerProvider provider, TypeSerializer typeSer)
/*     */     throws IOException
/*     */   {
/*  82 */     WritableTypeId typeIdDef = typeSer.writeTypePrefix(g, typeSer
/*  83 */       .typeId(value, serializationShape(provider)));
/*     */     
/*  85 */     if (typeIdDef.valueShape == JsonToken.START_ARRAY) {
/*  86 */       _serializeAsArrayContents(value, g, provider);
/*     */     } else {
/*  88 */       g.writeString(this._formatter == null ? value.toString() : value.format(this._formatter));
/*     */     }
/*  90 */     typeSer.writeTypeSuffix(g, typeIdDef);
/*     */   }
/*     */   
/*     */   protected void _serializeAsArrayContents(YearMonth value, JsonGenerator g, SerializerProvider provider)
/*     */     throws IOException
/*     */   {
/*  96 */     g.writeNumber(value.getYear());
/*  97 */     g.writeNumber(value.getMonthValue());
/*     */   }
/*     */   
/*     */   protected void _acceptTimestampVisitor(JsonFormatVisitorWrapper visitor, JavaType typeHint)
/*     */     throws JsonMappingException
/*     */   {
/* 103 */     SerializerProvider provider = visitor.getProvider();
/* 104 */     boolean useTimestamp = (provider != null) && (useTimestamp(provider));
/* 105 */     if (useTimestamp) {
/* 106 */       super._acceptTimestampVisitor(visitor, typeHint);
/*     */     } else {
/* 108 */       JsonStringFormatVisitor v2 = visitor.expectStringFormat(typeHint);
/* 109 */       if (v2 != null) {
/* 110 */         v2.format(JsonValueFormat.DATE_TIME);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected JsonToken serializationShape(SerializerProvider provider)
/*     */   {
/* 117 */     return useTimestamp(provider) ? JsonToken.START_ARRAY : JsonToken.VALUE_STRING;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-datatype-jsr310-2.12.5.jar!\com\fasterxml\jackson\datatype\jsr310\ser\YearMonthSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */