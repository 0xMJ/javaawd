/*     */ package com.fasterxml.jackson.datatype.jsr310.deser;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat.Shape;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*     */ import java.io.IOException;
/*     */ import java.time.DateTimeException;
/*     */ import java.time.OffsetTime;
/*     */ import java.time.ZoneOffset;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OffsetTimeDeserializer
/*     */   extends JSR310DateTimeDeserializerBase<OffsetTime>
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  38 */   public static final OffsetTimeDeserializer INSTANCE = new OffsetTimeDeserializer();
/*     */   
/*     */   protected OffsetTimeDeserializer() {
/*  41 */     this(DateTimeFormatter.ISO_OFFSET_TIME);
/*     */   }
/*     */   
/*     */   protected OffsetTimeDeserializer(DateTimeFormatter dtf) {
/*  45 */     super(OffsetTime.class, dtf);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected OffsetTimeDeserializer(OffsetTimeDeserializer base, Boolean leniency)
/*     */   {
/*  52 */     super(base, leniency);
/*     */   }
/*     */   
/*     */   protected OffsetTimeDeserializer withDateFormat(DateTimeFormatter dtf)
/*     */   {
/*  57 */     return new OffsetTimeDeserializer(dtf);
/*     */   }
/*     */   
/*     */   protected OffsetTimeDeserializer withLeniency(Boolean leniency)
/*     */   {
/*  62 */     return new OffsetTimeDeserializer(this, leniency);
/*     */   }
/*     */   
/*     */   protected OffsetTimeDeserializer withShape(JsonFormat.Shape shape) {
/*  66 */     return this;
/*     */   }
/*     */   
/*     */   public OffsetTime deserialize(JsonParser parser, DeserializationContext context) throws IOException
/*     */   {
/*  71 */     if (parser.hasToken(JsonToken.VALUE_STRING)) {
/*  72 */       return _fromString(parser, context, parser.getText());
/*     */     }
/*     */     
/*  75 */     if (parser.isExpectedStartObjectToken()) {
/*  76 */       return _fromString(parser, context, context
/*  77 */         .extractScalarFromObject(parser, this, handledType()));
/*     */     }
/*  79 */     if (!parser.isExpectedStartArrayToken()) {
/*  80 */       if (parser.hasToken(JsonToken.VALUE_EMBEDDED_OBJECT)) {
/*  81 */         return (OffsetTime)parser.getEmbeddedObject();
/*     */       }
/*  83 */       if (parser.hasToken(JsonToken.VALUE_NUMBER_INT)) {
/*  84 */         _throwNoNumericTimestampNeedTimeZone(parser, context);
/*     */       }
/*  86 */       throw context.wrongTokenException(parser, handledType(), JsonToken.START_ARRAY, "Expected array or string.");
/*     */     }
/*     */     
/*  89 */     JsonToken t = parser.nextToken();
/*  90 */     if (t != JsonToken.VALUE_NUMBER_INT) {
/*  91 */       if (t == JsonToken.END_ARRAY) {
/*  92 */         return null;
/*     */       }
/*  94 */       if (((t == JsonToken.VALUE_STRING) || (t == JsonToken.VALUE_EMBEDDED_OBJECT)) && 
/*  95 */         (context.isEnabled(DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS))) {
/*  96 */         OffsetTime parsed = deserialize(parser, context);
/*  97 */         if (parser.nextToken() != JsonToken.END_ARRAY) {
/*  98 */           handleMissingEndArrayForSingle(parser, context);
/*     */         }
/* 100 */         return parsed;
/*     */       }
/* 102 */       context.reportInputMismatch(handledType(), "Unexpected token (%s) within Array, expected VALUE_NUMBER_INT", new Object[] { t });
/*     */     }
/*     */     
/*     */ 
/* 106 */     int hour = parser.getIntValue();
/* 107 */     int minute = parser.nextIntValue(-1);
/* 108 */     if (minute == -1) {
/* 109 */       t = parser.getCurrentToken();
/* 110 */       if (t == JsonToken.END_ARRAY) {
/* 111 */         return null;
/*     */       }
/* 113 */       if (t != JsonToken.VALUE_NUMBER_INT) {
/* 114 */         _reportWrongToken(context, JsonToken.VALUE_NUMBER_INT, "minutes");
/*     */       }
/* 116 */       minute = parser.getIntValue();
/*     */     }
/* 118 */     int partialSecond = 0;
/* 119 */     int second = 0;
/* 120 */     if (parser.nextToken() == JsonToken.VALUE_NUMBER_INT) {
/* 121 */       second = parser.getIntValue();
/* 122 */       if (parser.nextToken() == JsonToken.VALUE_NUMBER_INT) {
/* 123 */         partialSecond = parser.getIntValue();
/* 124 */         if ((partialSecond < 1000) && 
/* 125 */           (!context.isEnabled(DeserializationFeature.READ_DATE_TIMESTAMPS_AS_NANOSECONDS))) {
/* 126 */           partialSecond *= 1000000;
/*     */         }
/* 128 */         parser.nextToken();
/*     */       }
/*     */     }
/* 131 */     if (parser.getCurrentToken() == JsonToken.VALUE_STRING) {
/* 132 */       OffsetTime result = OffsetTime.of(hour, minute, second, partialSecond, ZoneOffset.of(parser.getText()));
/* 133 */       if (parser.nextToken() != JsonToken.END_ARRAY) {
/* 134 */         _reportWrongToken(context, JsonToken.END_ARRAY, "timezone");
/*     */       }
/* 136 */       return result;
/*     */     }
/* 138 */     throw context.wrongTokenException(parser, handledType(), JsonToken.VALUE_STRING, "Expected string for TimeZone after numeric values");
/*     */   }
/*     */   
/*     */ 
/*     */   protected OffsetTime _fromString(JsonParser p, DeserializationContext ctxt, String string0)
/*     */     throws IOException
/*     */   {
/* 145 */     String string = string0.trim();
/* 146 */     if (string.length() == 0)
/*     */     {
/*     */ 
/*     */ 
/* 150 */       return (OffsetTime)_fromEmptyString(p, ctxt, string);
/*     */     }
/*     */     try {
/* 153 */       return OffsetTime.parse(string, this._formatter);
/*     */     } catch (DateTimeException e) {
/* 155 */       return (OffsetTime)_handleDateTimeException(ctxt, e, string);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-datatype-jsr310-2.12.5.jar!\com\fasterxml\jackson\datatype\jsr310\deser\OffsetTimeDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */