/*    */ package com.fasterxml.jackson.datatype.jsr310.ser.key;
/*    */ 
/*    */ import com.fasterxml.jackson.core.JsonGenerator;
/*    */ import com.fasterxml.jackson.databind.JsonMappingException;
/*    */ import com.fasterxml.jackson.databind.JsonSerializer;
/*    */ import com.fasterxml.jackson.databind.SerializerProvider;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class Jsr310NullKeySerializer
/*    */   extends JsonSerializer<Object>
/*    */ {
/*    */   public static final String NULL_KEY = "";
/*    */   
/*    */   public void serialize(Object value, JsonGenerator gen, SerializerProvider serializers)
/*    */     throws IOException
/*    */   {
/* 28 */     if (value != null) {
/* 29 */       throw JsonMappingException.from(gen, "Jsr310NullKeySerializer is only for serializing null values.");
/*    */     }
/*    */     
/* 32 */     gen.writeFieldName("");
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-datatype-jsr310-2.12.5.jar!\com\fasterxml\jackson\datatype\jsr310\ser\key\Jsr310NullKeySerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */