/*     */ package com.fasterxml.jackson.datatype.jsr310.ser;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat.Shape;
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.core.type.WritableTypeId;
/*     */ import com.fasterxml.jackson.databind.SerializerProvider;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*     */ import java.io.IOException;
/*     */ import java.time.OffsetTime;
/*     */ import java.time.ZoneOffset;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ import java.time.temporal.ChronoField;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OffsetTimeSerializer
/*     */   extends JSR310FormattedSerializerBase<OffsetTime>
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  41 */   public static final OffsetTimeSerializer INSTANCE = new OffsetTimeSerializer();
/*     */   
/*     */   protected OffsetTimeSerializer() {
/*  44 */     super(OffsetTime.class);
/*     */   }
/*     */   
/*     */   protected OffsetTimeSerializer(OffsetTimeSerializer base, Boolean useTimestamp, DateTimeFormatter dtf)
/*     */   {
/*  49 */     this(base, useTimestamp, null, dtf);
/*     */   }
/*     */   
/*     */   protected OffsetTimeSerializer(OffsetTimeSerializer base, Boolean useTimestamp, Boolean useNanoseconds, DateTimeFormatter dtf)
/*     */   {
/*  54 */     super(base, useTimestamp, useNanoseconds, dtf, null);
/*     */   }
/*     */   
/*     */   protected OffsetTimeSerializer withFormat(Boolean useTimestamp, DateTimeFormatter dtf, JsonFormat.Shape shape)
/*     */   {
/*  59 */     return new OffsetTimeSerializer(this, useTimestamp, dtf);
/*     */   }
/*     */   
/*     */   public void serialize(OffsetTime time, JsonGenerator g, SerializerProvider provider)
/*     */     throws IOException
/*     */   {
/*  65 */     if (useTimestamp(provider)) {
/*  66 */       g.writeStartArray();
/*  67 */       _serializeAsArrayContents(time, g, provider);
/*  68 */       g.writeEndArray();
/*     */     } else {
/*  70 */       String str = this._formatter == null ? time.toString() : time.format(this._formatter);
/*  71 */       g.writeString(str);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void serializeWithType(OffsetTime value, JsonGenerator g, SerializerProvider provider, TypeSerializer typeSer)
/*     */     throws IOException
/*     */   {
/*  79 */     WritableTypeId typeIdDef = typeSer.writeTypePrefix(g, typeSer
/*  80 */       .typeId(value, serializationShape(provider)));
/*     */     
/*  82 */     if (typeIdDef.valueShape == JsonToken.START_ARRAY) {
/*  83 */       _serializeAsArrayContents(value, g, provider);
/*     */     } else {
/*  85 */       String str = this._formatter == null ? value.toString() : value.format(this._formatter);
/*  86 */       g.writeString(str);
/*     */     }
/*  88 */     typeSer.writeTypeSuffix(g, typeIdDef);
/*     */   }
/*     */   
/*     */   private final void _serializeAsArrayContents(OffsetTime value, JsonGenerator g, SerializerProvider provider)
/*     */     throws IOException
/*     */   {
/*  94 */     g.writeNumber(value.getHour());
/*  95 */     g.writeNumber(value.getMinute());
/*  96 */     int secs = value.getSecond();
/*  97 */     int nanos = value.getNano();
/*  98 */     if ((secs > 0) || (nanos > 0)) {
/*  99 */       g.writeNumber(secs);
/* 100 */       if (nanos > 0) {
/* 101 */         if (useNanoseconds(provider)) {
/* 102 */           g.writeNumber(nanos);
/*     */         } else {
/* 104 */           g.writeNumber(value.get(ChronoField.MILLI_OF_SECOND));
/*     */         }
/*     */       }
/*     */     }
/* 108 */     g.writeString(value.getOffset().toString());
/*     */   }
/*     */   
/*     */   protected JsonToken serializationShape(SerializerProvider provider)
/*     */   {
/* 113 */     return useTimestamp(provider) ? JsonToken.START_ARRAY : JsonToken.VALUE_STRING;
/*     */   }
/*     */   
/*     */   protected JSR310FormattedSerializerBase<?> withFeatures(Boolean writeZoneId, Boolean writeNanoseconds)
/*     */   {
/* 118 */     return new OffsetTimeSerializer(this, this._useTimestamp, writeNanoseconds, this._formatter);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-datatype-jsr310-2.12.5.jar!\com\fasterxml\jackson\datatype\jsr310\ser\OffsetTimeSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */