/*     */ package com.fasterxml.jackson.datatype.jsr310.deser;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat.Shape;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*     */ import java.io.IOException;
/*     */ import java.time.DateTimeException;
/*     */ import java.time.MonthDay;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MonthDayDeserializer
/*     */   extends JSR310DateTimeDeserializerBase<MonthDay>
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  21 */   public static final MonthDayDeserializer INSTANCE = new MonthDayDeserializer();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MonthDayDeserializer()
/*     */   {
/*  30 */     this(null);
/*     */   }
/*     */   
/*     */   public MonthDayDeserializer(DateTimeFormatter formatter) {
/*  34 */     super(MonthDay.class, formatter);
/*     */   }
/*     */   
/*     */   protected MonthDayDeserializer withDateFormat(DateTimeFormatter dtf)
/*     */   {
/*  39 */     return new MonthDayDeserializer(dtf);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected MonthDayDeserializer(MonthDayDeserializer base, Boolean leniency)
/*     */   {
/*  46 */     super(base, leniency);
/*     */   }
/*     */   
/*     */   protected MonthDayDeserializer withLeniency(Boolean leniency)
/*     */   {
/*  51 */     return new MonthDayDeserializer(this, leniency);
/*     */   }
/*     */   
/*     */   protected MonthDayDeserializer withShape(JsonFormat.Shape shape) {
/*  55 */     return this;
/*     */   }
/*     */   
/*     */   public MonthDay deserialize(JsonParser parser, DeserializationContext context) throws IOException
/*     */   {
/*  60 */     if (parser.hasToken(JsonToken.VALUE_STRING)) {
/*  61 */       return _fromString(parser, context, parser.getText());
/*     */     }
/*     */     
/*  64 */     if (parser.isExpectedStartObjectToken()) {
/*  65 */       return _fromString(parser, context, context
/*  66 */         .extractScalarFromObject(parser, this, handledType()));
/*     */     }
/*  68 */     if (parser.isExpectedStartArrayToken()) {
/*  69 */       JsonToken t = parser.nextToken();
/*  70 */       if (t == JsonToken.END_ARRAY) {
/*  71 */         return null;
/*     */       }
/*  73 */       if (((t == JsonToken.VALUE_STRING) || (t == JsonToken.VALUE_EMBEDDED_OBJECT)) && 
/*  74 */         (context.isEnabled(DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS))) {
/*  75 */         MonthDay parsed = deserialize(parser, context);
/*  76 */         if (parser.nextToken() != JsonToken.END_ARRAY) {
/*  77 */           handleMissingEndArrayForSingle(parser, context);
/*     */         }
/*  79 */         return parsed;
/*     */       }
/*  81 */       if (t != JsonToken.VALUE_NUMBER_INT) {
/*  82 */         _reportWrongToken(context, JsonToken.VALUE_NUMBER_INT, "month");
/*     */       }
/*  84 */       int month = parser.getIntValue();
/*  85 */       int day = parser.nextIntValue(-1);
/*  86 */       if (day == -1) {
/*  87 */         if (!parser.hasToken(JsonToken.VALUE_NUMBER_INT)) {
/*  88 */           _reportWrongToken(context, JsonToken.VALUE_NUMBER_INT, "day");
/*     */         }
/*  90 */         day = parser.getIntValue();
/*     */       }
/*  92 */       if (parser.nextToken() != JsonToken.END_ARRAY) {
/*  93 */         throw context.wrongTokenException(parser, handledType(), JsonToken.END_ARRAY, "Expected array to end");
/*     */       }
/*     */       
/*  96 */       return MonthDay.of(month, day);
/*     */     }
/*  98 */     if (parser.hasToken(JsonToken.VALUE_EMBEDDED_OBJECT)) {
/*  99 */       return (MonthDay)parser.getEmbeddedObject();
/*     */     }
/* 101 */     return (MonthDay)_handleUnexpectedToken(context, parser, new JsonToken[] { JsonToken.VALUE_STRING, JsonToken.START_ARRAY });
/*     */   }
/*     */   
/*     */ 
/*     */   protected MonthDay _fromString(JsonParser p, DeserializationContext ctxt, String string0)
/*     */     throws IOException
/*     */   {
/* 108 */     String string = string0.trim();
/* 109 */     if (string.length() == 0)
/*     */     {
/*     */ 
/*     */ 
/* 113 */       return (MonthDay)_fromEmptyString(p, ctxt, string);
/*     */     }
/*     */     try {
/* 116 */       if (this._formatter == null) {
/* 117 */         return MonthDay.parse(string);
/*     */       }
/* 119 */       return MonthDay.parse(string, this._formatter);
/*     */     } catch (DateTimeException e) {
/* 121 */       return (MonthDay)_handleDateTimeException(ctxt, e, string);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-datatype-jsr310-2.12.5.jar!\com\fasterxml\jackson\datatype\jsr310\deser\MonthDayDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */