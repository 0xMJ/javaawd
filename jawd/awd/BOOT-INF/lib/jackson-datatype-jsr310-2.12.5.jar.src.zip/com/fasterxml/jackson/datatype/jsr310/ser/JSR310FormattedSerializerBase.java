/*     */ package com.fasterxml.jackson.datatype.jsr310.ser;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat.Feature;
/*     */ import com.fasterxml.jackson.annotation.JsonFormat.Shape;
/*     */ import com.fasterxml.jackson.annotation.JsonFormat.Value;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.JsonNode;
/*     */ import com.fasterxml.jackson.databind.JsonSerializer;
/*     */ import com.fasterxml.jackson.databind.SerializationFeature;
/*     */ import com.fasterxml.jackson.databind.SerializerProvider;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonArrayFormatVisitor;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatTypes;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatVisitorWrapper;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonStringFormatVisitor;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonValueFormat;
/*     */ import com.fasterxml.jackson.databind.ser.ContextualSerializer;
/*     */ import com.fasterxml.jackson.databind.type.TypeFactory;
/*     */ import java.lang.reflect.Type;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class JSR310FormattedSerializerBase<T>
/*     */   extends JSR310SerializerBase<T>
/*     */   implements ContextualSerializer
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected final Boolean _useTimestamp;
/*     */   protected final Boolean _useNanoseconds;
/*     */   protected final DateTimeFormatter _formatter;
/*     */   protected final JsonFormat.Shape _shape;
/*     */   protected volatile transient JavaType _integerListType;
/*     */   
/*     */   protected JSR310FormattedSerializerBase(Class<T> supportedType)
/*     */   {
/*  79 */     this(supportedType, null);
/*     */   }
/*     */   
/*     */   protected JSR310FormattedSerializerBase(Class<T> supportedType, DateTimeFormatter formatter)
/*     */   {
/*  84 */     super(supportedType);
/*  85 */     this._useTimestamp = null;
/*  86 */     this._useNanoseconds = null;
/*  87 */     this._shape = null;
/*  88 */     this._formatter = formatter;
/*     */   }
/*     */   
/*     */ 
/*     */   protected JSR310FormattedSerializerBase(JSR310FormattedSerializerBase<?> base, Boolean useTimestamp, DateTimeFormatter dtf, JsonFormat.Shape shape)
/*     */   {
/*  94 */     this(base, useTimestamp, null, dtf, shape);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected JSR310FormattedSerializerBase(JSR310FormattedSerializerBase<?> base, Boolean useTimestamp, Boolean useNanoseconds, DateTimeFormatter dtf, JsonFormat.Shape shape)
/*     */   {
/* 101 */     super(base.handledType());
/* 102 */     this._useTimestamp = useTimestamp;
/* 103 */     this._useNanoseconds = useNanoseconds;
/* 104 */     this._formatter = dtf;
/* 105 */     this._shape = shape;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected abstract JSR310FormattedSerializerBase<?> withFormat(Boolean paramBoolean, DateTimeFormatter paramDateTimeFormatter, JsonFormat.Shape paramShape);
/*     */   
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   protected JSR310FormattedSerializerBase<?> withFeatures(Boolean writeZoneId)
/*     */   {
/* 117 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected JSR310FormattedSerializerBase<?> withFeatures(Boolean writeZoneId, Boolean writeNanoseconds)
/*     */   {
/* 125 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */   public JsonSerializer<?> createContextual(SerializerProvider prov, BeanProperty property)
/*     */     throws JsonMappingException
/*     */   {
/* 132 */     JsonFormat.Value format = findFormatOverrides(prov, property, handledType());
/* 133 */     if (format != null) {
/* 134 */       Boolean useTimestamp = null;
/*     */       
/*     */ 
/* 137 */       JsonFormat.Shape shape = format.getShape();
/* 138 */       if ((shape == JsonFormat.Shape.ARRAY) || (shape.isNumeric())) {
/* 139 */         useTimestamp = Boolean.TRUE;
/*     */       } else {
/* 141 */         useTimestamp = shape == JsonFormat.Shape.STRING ? Boolean.FALSE : null;
/*     */       }
/* 143 */       DateTimeFormatter dtf = this._formatter;
/*     */       
/*     */ 
/* 146 */       if (format.hasPattern()) {
/* 147 */         dtf = _useDateTimeFormatter(prov, format);
/*     */       }
/* 149 */       JSR310FormattedSerializerBase<?> ser = this;
/* 150 */       if ((shape != this._shape) || (useTimestamp != this._useTimestamp) || (dtf != this._formatter)) {
/* 151 */         ser = ser.withFormat(useTimestamp, dtf, shape);
/*     */       }
/* 153 */       Boolean writeZoneId = format.getFeature(JsonFormat.Feature.WRITE_DATES_WITH_ZONE_ID);
/* 154 */       Boolean writeNanoseconds = format.getFeature(JsonFormat.Feature.WRITE_DATE_TIMESTAMPS_AS_NANOSECONDS);
/* 155 */       if ((writeZoneId != null) || (writeNanoseconds != null)) {
/* 156 */         ser = ser.withFeatures(writeZoneId, writeNanoseconds);
/*     */       }
/* 158 */       return ser;
/*     */     }
/* 160 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */   public JsonNode getSchema(SerializerProvider provider, Type typeHint)
/*     */   {
/* 166 */     return createSchemaNode(provider
/* 167 */       .isEnabled(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS) ? "array" : "string", true);
/*     */   }
/*     */   
/*     */ 
/*     */   public void acceptJsonFormatVisitor(JsonFormatVisitorWrapper visitor, JavaType typeHint)
/*     */     throws JsonMappingException
/*     */   {
/* 174 */     if (useTimestamp(visitor.getProvider())) {
/* 175 */       _acceptTimestampVisitor(visitor, typeHint);
/*     */     } else {
/* 177 */       JsonStringFormatVisitor v2 = visitor.expectStringFormat(typeHint);
/* 178 */       if (v2 != null) {
/* 179 */         v2.format(JsonValueFormat.DATE_TIME);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected void _acceptTimestampVisitor(JsonFormatVisitorWrapper visitor, JavaType typeHint)
/*     */     throws JsonMappingException
/*     */   {
/* 188 */     JsonArrayFormatVisitor v2 = visitor.expectArrayFormat(_integerListType(visitor.getProvider()));
/* 189 */     if (v2 != null) {
/* 190 */       v2.itemsFormat(JsonFormatTypes.INTEGER);
/*     */     }
/*     */   }
/*     */   
/*     */   protected JavaType _integerListType(SerializerProvider prov) {
/* 195 */     JavaType t = this._integerListType;
/* 196 */     if (t == null)
/*     */     {
/* 198 */       t = prov.getTypeFactory().constructCollectionType(List.class, Integer.class);
/* 199 */       this._integerListType = t;
/*     */     }
/* 201 */     return t;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected SerializationFeature getTimestampsFeature()
/*     */   {
/* 215 */     return SerializationFeature.WRITE_DATES_AS_TIMESTAMPS;
/*     */   }
/*     */   
/*     */   protected boolean useTimestamp(SerializerProvider provider) {
/* 219 */     if (this._useTimestamp != null) {
/* 220 */       return this._useTimestamp.booleanValue();
/*     */     }
/* 222 */     if (this._shape != null) {
/* 223 */       if (this._shape == JsonFormat.Shape.STRING) {
/* 224 */         return false;
/*     */       }
/* 226 */       if (this._shape == JsonFormat.Shape.NUMBER_INT) {
/* 227 */         return true;
/*     */       }
/*     */     }
/*     */     
/* 231 */     return (this._formatter == null) && (provider != null) && 
/* 232 */       (provider.isEnabled(getTimestampsFeature()));
/*     */   }
/*     */   
/*     */   protected boolean _useTimestampExplicitOnly(SerializerProvider provider) {
/* 236 */     if (this._useTimestamp != null) {
/* 237 */       return this._useTimestamp.booleanValue();
/*     */     }
/* 239 */     return false;
/*     */   }
/*     */   
/*     */   protected boolean useNanoseconds(SerializerProvider provider) {
/* 243 */     if (this._useNanoseconds != null) {
/* 244 */       return this._useNanoseconds.booleanValue();
/*     */     }
/* 246 */     if (this._shape != null) {
/* 247 */       if (this._shape == JsonFormat.Shape.NUMBER_INT) {
/* 248 */         return false;
/*     */       }
/* 250 */       if (this._shape == JsonFormat.Shape.NUMBER_FLOAT) {
/* 251 */         return true;
/*     */       }
/*     */     }
/* 254 */     return (provider != null) && 
/* 255 */       (provider.isEnabled(SerializationFeature.WRITE_DATE_TIMESTAMPS_AS_NANOSECONDS));
/*     */   }
/*     */   
/*     */ 
/*     */   protected DateTimeFormatter _useDateTimeFormatter(SerializerProvider prov, JsonFormat.Value format)
/*     */   {
/* 261 */     String pattern = format.getPattern();
/* 262 */     Locale locale = format.hasLocale() ? format.getLocale() : prov.getLocale();
/* 263 */     DateTimeFormatter dtf; DateTimeFormatter dtf; if (locale == null) {
/* 264 */       dtf = DateTimeFormatter.ofPattern(pattern);
/*     */     } else {
/* 266 */       dtf = DateTimeFormatter.ofPattern(pattern, locale);
/*     */     }
/*     */     
/*     */ 
/* 270 */     if (format.hasTimeZone()) {
/* 271 */       dtf = dtf.withZone(format.getTimeZone().toZoneId());
/*     */     }
/* 273 */     return dtf;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-datatype-jsr310-2.12.5.jar!\com\fasterxml\jackson\datatype\jsr310\ser\JSR310FormattedSerializerBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */