/*     */ package com.fasterxml.jackson.datatype.jsr310.deser;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat.Shape;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import java.io.IOException;
/*     */ import java.time.DateTimeException;
/*     */ import java.time.LocalDateTime;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocalDateTimeDeserializer
/*     */   extends JSR310DateTimeDeserializerBase<LocalDateTime>
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  45 */   private static final DateTimeFormatter DEFAULT_FORMATTER = DateTimeFormatter.ISO_LOCAL_DATE_TIME;
/*     */   
/*  47 */   public static final LocalDateTimeDeserializer INSTANCE = new LocalDateTimeDeserializer();
/*     */   
/*     */   protected LocalDateTimeDeserializer() {
/*  50 */     this(DEFAULT_FORMATTER);
/*     */   }
/*     */   
/*     */   public LocalDateTimeDeserializer(DateTimeFormatter formatter) {
/*  54 */     super(LocalDateTime.class, formatter);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected LocalDateTimeDeserializer(LocalDateTimeDeserializer base, Boolean leniency)
/*     */   {
/*  61 */     super(base, leniency);
/*     */   }
/*     */   
/*     */   protected LocalDateTimeDeserializer withDateFormat(DateTimeFormatter formatter)
/*     */   {
/*  66 */     return new LocalDateTimeDeserializer(formatter);
/*     */   }
/*     */   
/*     */   protected LocalDateTimeDeserializer withLeniency(Boolean leniency)
/*     */   {
/*  71 */     return new LocalDateTimeDeserializer(this, leniency);
/*     */   }
/*     */   
/*     */   protected LocalDateTimeDeserializer withShape(JsonFormat.Shape shape) {
/*  75 */     return this;
/*     */   }
/*     */   
/*     */   public LocalDateTime deserialize(JsonParser parser, DeserializationContext context) throws IOException
/*     */   {
/*  80 */     if (parser.hasTokenId(6)) {
/*  81 */       return _fromString(parser, context, parser.getText());
/*     */     }
/*     */     
/*  84 */     if (parser.isExpectedStartObjectToken()) {
/*  85 */       return _fromString(parser, context, context
/*  86 */         .extractScalarFromObject(parser, this, handledType()));
/*     */     }
/*  88 */     if (parser.isExpectedStartArrayToken()) {
/*  89 */       JsonToken t = parser.nextToken();
/*  90 */       if (t == JsonToken.END_ARRAY) {
/*  91 */         return null;
/*     */       }
/*  93 */       if (((t == JsonToken.VALUE_STRING) || (t == JsonToken.VALUE_EMBEDDED_OBJECT)) && 
/*  94 */         (context.isEnabled(DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS))) {
/*  95 */         LocalDateTime parsed = deserialize(parser, context);
/*  96 */         if (parser.nextToken() != JsonToken.END_ARRAY) {
/*  97 */           handleMissingEndArrayForSingle(parser, context);
/*     */         }
/*  99 */         return parsed;
/*     */       }
/* 101 */       if (t == JsonToken.VALUE_NUMBER_INT)
/*     */       {
/*     */ 
/* 104 */         int year = parser.getIntValue();
/* 105 */         int month = parser.nextIntValue(-1);
/* 106 */         int day = parser.nextIntValue(-1);
/* 107 */         int hour = parser.nextIntValue(-1);
/* 108 */         int minute = parser.nextIntValue(-1);
/*     */         
/* 110 */         t = parser.nextToken();
/* 111 */         LocalDateTime result; LocalDateTime result; if (t == JsonToken.END_ARRAY) {
/* 112 */           result = LocalDateTime.of(year, month, day, hour, minute);
/*     */         } else {
/* 114 */           int second = parser.getIntValue();
/* 115 */           t = parser.nextToken();
/* 116 */           LocalDateTime result; if (t == JsonToken.END_ARRAY) {
/* 117 */             result = LocalDateTime.of(year, month, day, hour, minute, second);
/*     */           } else {
/* 119 */             int partialSecond = parser.getIntValue();
/* 120 */             if ((partialSecond < 1000) && 
/* 121 */               (!context.isEnabled(DeserializationFeature.READ_DATE_TIMESTAMPS_AS_NANOSECONDS)))
/* 122 */               partialSecond *= 1000000;
/* 123 */             if (parser.nextToken() != JsonToken.END_ARRAY) {
/* 124 */               throw context.wrongTokenException(parser, handledType(), JsonToken.END_ARRAY, "Expected array to end");
/*     */             }
/*     */             
/* 127 */             result = LocalDateTime.of(year, month, day, hour, minute, second, partialSecond);
/*     */           }
/*     */         }
/* 130 */         return result;
/*     */       }
/* 132 */       context.reportInputMismatch(handledType(), "Unexpected token (%s) within Array, expected VALUE_NUMBER_INT", new Object[] { t });
/*     */     }
/*     */     
/*     */ 
/* 136 */     if (parser.hasToken(JsonToken.VALUE_EMBEDDED_OBJECT)) {
/* 137 */       return (LocalDateTime)parser.getEmbeddedObject();
/*     */     }
/* 139 */     if (parser.hasToken(JsonToken.VALUE_NUMBER_INT)) {
/* 140 */       _throwNoNumericTimestampNeedTimeZone(parser, context);
/*     */     }
/* 142 */     return (LocalDateTime)_handleUnexpectedToken(context, parser, "Expected array or string.", new Object[0]);
/*     */   }
/*     */   
/*     */   protected LocalDateTime _fromString(JsonParser p, DeserializationContext ctxt, String string0)
/*     */     throws IOException
/*     */   {
/* 148 */     String string = string0.trim();
/* 149 */     if (string.length() == 0)
/*     */     {
/*     */ 
/*     */ 
/* 153 */       return (LocalDateTime)_fromEmptyString(p, ctxt, string);
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 158 */       if (this._formatter == DEFAULT_FORMATTER)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 163 */         if ((string.length() > 10) && (string.charAt(10) == 'T') && 
/* 164 */           (string.endsWith("Z"))) {
/* 165 */           if (isLenient()) {
/* 166 */             return LocalDateTime.parse(string.substring(0, string.length() - 1), this._formatter);
/*     */           }
/*     */           
/* 169 */           JavaType t = getValueType(ctxt);
/* 170 */           return (LocalDateTime)ctxt.handleWeirdStringValue(t.getRawClass(), string, "Should not contain offset when 'strict' mode set for property or type (enable 'lenient' handling to allow)", new Object[0]);
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 177 */       return LocalDateTime.parse(string, this._formatter);
/*     */     } catch (DateTimeException e) {
/* 179 */       return (LocalDateTime)_handleDateTimeException(ctxt, e, string);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-datatype-jsr310-2.12.5.jar!\com\fasterxml\jackson\datatype\jsr310\deser\LocalDateTimeDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */