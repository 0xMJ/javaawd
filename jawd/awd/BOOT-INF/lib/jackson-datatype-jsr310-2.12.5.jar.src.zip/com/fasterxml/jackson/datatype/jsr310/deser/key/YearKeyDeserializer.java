/*    */ package com.fasterxml.jackson.datatype.jsr310.deser.key;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.DeserializationContext;
/*    */ import java.io.IOException;
/*    */ import java.time.DateTimeException;
/*    */ import java.time.Year;
/*    */ 
/*    */ public class YearKeyDeserializer
/*    */   extends Jsr310KeyDeserializer
/*    */ {
/* 11 */   public static final YearKeyDeserializer INSTANCE = new YearKeyDeserializer();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   protected Year deserialize(String key, DeserializationContext ctxt)
/*    */     throws IOException
/*    */   {
/*    */     try
/*    */     {
/* 21 */       return Year.of(Integer.parseInt(key));
/*    */     } catch (NumberFormatException nfe) {
/* 23 */       return (Year)_handleDateTimeException(ctxt, Year.class, new DateTimeException("Number format exception", nfe), key);
/*    */     } catch (DateTimeException dte) {
/* 25 */       return (Year)_handleDateTimeException(ctxt, Year.class, dte, key);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-datatype-jsr310-2.12.5.jar!\com\fasterxml\jackson\datatype\jsr310\deser\key\YearKeyDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */