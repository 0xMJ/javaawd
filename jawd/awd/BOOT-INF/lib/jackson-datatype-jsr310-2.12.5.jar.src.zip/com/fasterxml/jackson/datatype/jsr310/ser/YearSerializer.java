/*    */ package com.fasterxml.jackson.datatype.jsr310.ser;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonFormat.Shape;
/*    */ import com.fasterxml.jackson.core.JsonGenerator;
/*    */ import com.fasterxml.jackson.core.JsonParser.NumberType;
/*    */ import com.fasterxml.jackson.core.JsonToken;
/*    */ import com.fasterxml.jackson.databind.JavaType;
/*    */ import com.fasterxml.jackson.databind.JsonMappingException;
/*    */ import com.fasterxml.jackson.databind.SerializerProvider;
/*    */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatVisitorWrapper;
/*    */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonIntegerFormatVisitor;
/*    */ import java.io.IOException;
/*    */ import java.time.Year;
/*    */ import java.time.format.DateTimeFormatter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class YearSerializer
/*    */   extends JSR310FormattedSerializerBase<Year>
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/* 45 */   public static final YearSerializer INSTANCE = new YearSerializer();
/*    */   
/*    */   protected YearSerializer() {
/* 48 */     this(null);
/*    */   }
/*    */   
/*    */   public YearSerializer(DateTimeFormatter formatter) {
/* 52 */     super(Year.class, formatter);
/*    */   }
/*    */   
/*    */   protected YearSerializer(YearSerializer base, Boolean useTimestamp, DateTimeFormatter formatter) {
/* 56 */     super(base, useTimestamp, formatter, null);
/*    */   }
/*    */   
/*    */   protected YearSerializer withFormat(Boolean useTimestamp, DateTimeFormatter formatter, JsonFormat.Shape shape)
/*    */   {
/* 61 */     return new YearSerializer(this, useTimestamp, formatter);
/*    */   }
/*    */   
/*    */   public void serialize(Year year, JsonGenerator generator, SerializerProvider provider)
/*    */     throws IOException
/*    */   {
/* 67 */     if (useTimestamp(provider)) {
/* 68 */       generator.writeNumber(year.getValue());
/*    */     } else {
/* 70 */       String str = this._formatter == null ? year.toString() : year.format(this._formatter);
/* 71 */       generator.writeString(str);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   protected void _acceptTimestampVisitor(JsonFormatVisitorWrapper visitor, JavaType typeHint)
/*    */     throws JsonMappingException
/*    */   {
/* 80 */     JsonIntegerFormatVisitor v2 = visitor.expectIntegerFormat(typeHint);
/* 81 */     if (v2 != null) {
/* 82 */       v2.numberType(JsonParser.NumberType.LONG);
/*    */     }
/*    */   }
/*    */   
/*    */   protected JsonToken serializationShape(SerializerProvider provider)
/*    */   {
/* 88 */     return useTimestamp(provider) ? JsonToken.VALUE_NUMBER_INT : JsonToken.VALUE_STRING;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-datatype-jsr310-2.12.5.jar!\com\fasterxml\jackson\datatype\jsr310\ser\YearSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */