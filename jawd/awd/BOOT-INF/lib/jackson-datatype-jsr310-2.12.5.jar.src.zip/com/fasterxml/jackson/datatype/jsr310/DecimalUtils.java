/*     */ package com.fasterxml.jackson.datatype.jsr310;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.time.Instant;
/*     */ import java.util.function.BiFunction;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DecimalUtils
/*     */ {
/*  31 */   private static final BigDecimal ONE_BILLION = new BigDecimal(1000000000L);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String toDecimal(long seconds, int nanoseconds)
/*     */   {
/*  39 */     StringBuilder sb = new StringBuilder(20).append(seconds).append('.');
/*     */     
/*     */ 
/*  42 */     if (nanoseconds == 0L)
/*     */     {
/*     */ 
/*  45 */       if (seconds == 0L) {
/*  46 */         return "0.0";
/*     */       }
/*     */       
/*     */ 
/*  50 */       sb.append("000000000");
/*     */     } else {
/*  52 */       StringBuilder nanoSB = new StringBuilder(9);
/*  53 */       nanoSB.append(nanoseconds);
/*     */       
/*  55 */       int nanosLen = nanoSB.length();
/*  56 */       int prepZeroes = 9 - nanosLen;
/*  57 */       while (prepZeroes > 0) {
/*  58 */         prepZeroes--;
/*  59 */         sb.append('0');
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  74 */       sb.append(nanoSB);
/*     */     }
/*  76 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static BigDecimal toBigDecimal(long seconds, int nanoseconds)
/*     */   {
/*  87 */     if (nanoseconds == 0L)
/*     */     {
/*     */ 
/*  90 */       if (seconds == 0L) {
/*  91 */         return BigDecimal.ZERO.setScale(1);
/*     */       }
/*  93 */       return BigDecimal.valueOf(seconds).setScale(9);
/*     */     }
/*  95 */     return new BigDecimal(toDecimal(seconds, nanoseconds));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public static int extractNanosecondDecimal(BigDecimal value, long integer)
/*     */   {
/* 107 */     return value.subtract(new BigDecimal(integer)).multiply(ONE_BILLION).intValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static <T> T extractSecondsAndNanos(BigDecimal seconds, BiFunction<Long, Integer, T> convert)
/*     */   {
/* 125 */     BigDecimal nanoseconds = seconds.scaleByPowerOfTen(9);
/* 126 */     long secondsOnly; long secondsOnly; int nanosOnly; if (nanoseconds.precision() - nanoseconds.scale() <= 0)
/*     */     {
/*     */       int nanosOnly;
/* 129 */       secondsOnly = nanosOnly = 0;
/*     */     } else { long secondsOnly;
/* 131 */       if (seconds.scale() < -63)
/*     */       {
/*     */         int nanosOnly;
/* 134 */         secondsOnly = nanosOnly = 0;
/*     */       }
/*     */       else
/*     */       {
/* 138 */         secondsOnly = seconds.longValue();
/* 139 */         nanosOnly = nanoseconds.subtract(new BigDecimal(secondsOnly).scaleByPowerOfTen(9)).intValue();
/*     */         
/* 141 */         if ((secondsOnly < 0L) && (secondsOnly > Instant.MIN.getEpochSecond()))
/*     */         {
/* 143 */           nanosOnly = Math.abs(nanosOnly);
/*     */         }
/*     */       }
/*     */     }
/* 147 */     return (T)convert.apply(Long.valueOf(secondsOnly), Integer.valueOf(nanosOnly));
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-datatype-jsr310-2.12.5.jar!\com\fasterxml\jackson\datatype\jsr310\DecimalUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */