/*    */ package com.fasterxml.jackson.datatype.jsr310;
/*    */ 
/*    */ import com.fasterxml.jackson.core.Version;
/*    */ import com.fasterxml.jackson.core.Versioned;
/*    */ import com.fasterxml.jackson.core.util.VersionUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class PackageVersion
/*    */   implements Versioned
/*    */ {
/* 30 */   public static final Version VERSION = VersionUtil.parseVersion("2.12.5", "com.fasterxml.jackson.datatype", "jackson-datatype-jsr310");
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public Version version()
/*    */   {
/* 37 */     return VERSION;
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-datatype-jsr310-2.12.5.jar!\com\fasterxml\jackson\datatype\jsr310\PackageVersion.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */