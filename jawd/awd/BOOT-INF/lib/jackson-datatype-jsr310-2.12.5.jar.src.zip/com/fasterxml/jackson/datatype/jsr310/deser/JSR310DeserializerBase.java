/*     */ package com.fasterxml.jackson.datatype.jsr310.deser;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.core.io.NumberInput;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.cfg.CoercionAction;
/*     */ import com.fasterxml.jackson.databind.deser.std.StdScalarDeserializer;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*     */ import com.fasterxml.jackson.databind.type.LogicalType;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import java.io.IOException;
/*     */ import java.time.DateTimeException;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class JSR310DeserializerBase<T>
/*     */   extends StdScalarDeserializer<T>
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected final boolean _isLenient;
/*     */   
/*     */   protected JSR310DeserializerBase(Class<T> supportedType)
/*     */   {
/*  67 */     super(supportedType);
/*  68 */     this._isLenient = true;
/*     */   }
/*     */   
/*     */   protected JSR310DeserializerBase(Class<T> supportedType, Boolean leniency)
/*     */   {
/*  73 */     super(supportedType);
/*  74 */     this._isLenient = (!Boolean.FALSE.equals(leniency));
/*     */   }
/*     */   
/*     */   protected JSR310DeserializerBase(JSR310DeserializerBase<T> base) {
/*  78 */     super(base);
/*  79 */     this._isLenient = base._isLenient;
/*     */   }
/*     */   
/*     */   protected JSR310DeserializerBase(JSR310DeserializerBase<T> base, Boolean leniency) {
/*  83 */     super(base);
/*  84 */     this._isLenient = (!Boolean.FALSE.equals(leniency));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract JSR310DeserializerBase<T> withLeniency(Boolean paramBoolean);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isLenient()
/*     */   {
/*  98 */     return this._isLenient;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected T _fromEmptyString(JsonParser p, DeserializationContext ctxt, String str)
/*     */     throws IOException
/*     */   {
/* 112 */     CoercionAction act = _checkFromStringCoercion(ctxt, str);
/* 113 */     switch (act) {
/*     */     case AsEmpty: 
/* 115 */       return (T)getEmptyValue(ctxt);
/*     */     }
/*     */     
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 123 */     if (!this._isLenient) {
/* 124 */       return (T)_failForNotLenient(p, ctxt, JsonToken.VALUE_STRING);
/*     */     }
/*     */     
/* 127 */     return null;
/*     */   }
/*     */   
/*     */   public LogicalType logicalType()
/*     */   {
/* 132 */     return LogicalType.DateTime;
/*     */   }
/*     */   
/*     */ 
/*     */   public Object deserializeWithType(JsonParser parser, DeserializationContext context, TypeDeserializer typeDeserializer)
/*     */     throws IOException
/*     */   {
/* 139 */     return typeDeserializer.deserializeTypedFromAny(parser, context);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean _isValidTimestampString(String str)
/*     */   {
/* 147 */     if (_isIntNumber(str)) {} return NumberInput.inLongRange(str, str.charAt(0) == '-');
/*     */   }
/*     */   
/*     */   protected <BOGUS> BOGUS _reportWrongToken(DeserializationContext context, JsonToken exp, String unit)
/*     */     throws IOException
/*     */   {
/* 153 */     context.reportWrongTokenException(this, exp, "Expected %s for '%s' of %s value", new Object[] {exp
/*     */     
/* 155 */       .name(), unit, handledType().getName() });
/* 156 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected <BOGUS> BOGUS _reportWrongToken(JsonParser parser, DeserializationContext context, JsonToken... expTypes)
/*     */     throws IOException
/*     */   {
/* 164 */     return (BOGUS)context.reportInputMismatch(handledType(), "Unexpected token (%s), expected one of %s for %s value", new Object[] {parser
/*     */     
/* 166 */       .getCurrentToken(), 
/* 167 */       Arrays.asList(expTypes).toString(), 
/* 168 */       handledType().getName() });
/*     */   }
/*     */   
/*     */   protected <R> R _handleDateTimeException(DeserializationContext context, DateTimeException e0, String value)
/*     */     throws JsonMappingException
/*     */   {
/*     */     try
/*     */     {
/* 176 */       return (R)context.handleWeirdStringValue(handledType(), value, "Failed to deserialize %s: (%s) %s", new Object[] {
/*     */       
/* 178 */         handledType().getName(), e0.getClass().getName(), e0.getMessage() });
/*     */     }
/*     */     catch (JsonMappingException e) {
/* 181 */       e.initCause(e0);
/* 182 */       throw e;
/*     */     } catch (IOException e) {
/* 184 */       if (null == e.getCause()) {
/* 185 */         e.initCause(e0);
/*     */       }
/* 187 */       throw JsonMappingException.fromUnexpectedIOE(e);
/*     */     }
/*     */   }
/*     */   
/*     */   protected <R> R _handleUnexpectedToken(DeserializationContext context, JsonParser parser, String message, Object... args) throws JsonMappingException
/*     */   {
/*     */     try
/*     */     {
/* 195 */       return (R)context.handleUnexpectedToken(handledType(), parser.getCurrentToken(), parser, message, args);
/*     */     }
/*     */     catch (JsonMappingException e)
/*     */     {
/* 199 */       throw e;
/*     */     } catch (IOException e) {
/* 201 */       throw JsonMappingException.fromUnexpectedIOE(e);
/*     */     }
/*     */   }
/*     */   
/*     */   protected <R> R _handleUnexpectedToken(DeserializationContext context, JsonParser parser, JsonToken... expTypes) throws JsonMappingException
/*     */   {
/* 207 */     return (R)_handleUnexpectedToken(context, parser, "Unexpected token (%s), expected one of %s for %s value", new Object[] {parser
/*     */     
/* 209 */       .currentToken(), 
/* 210 */       Arrays.asList(expTypes), 
/* 211 */       handledType().getName() });
/*     */   }
/*     */   
/*     */ 
/*     */   protected T _failForNotLenient(JsonParser p, DeserializationContext ctxt, JsonToken expToken)
/*     */     throws IOException
/*     */   {
/* 218 */     return (T)ctxt.handleUnexpectedToken(handledType(), expToken, p, "Cannot deserialize instance of %s out of %s token: not allowed because 'strict' mode set for property or type (enable 'lenient' handling to allow)", new Object[] {
/*     */     
/* 220 */       ClassUtil.nameOf(handledType()), p.currentToken() });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected DateTimeException _peelDTE(DateTimeException e)
/*     */   {
/*     */     for (;;)
/*     */     {
/* 232 */       Throwable t = e.getCause();
/* 233 */       if ((t == null) || (!(t instanceof DateTimeException))) break;
/* 234 */       e = (DateTimeException)t;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 239 */     return e;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-datatype-jsr310-2.12.5.jar!\com\fasterxml\jackson\datatype\jsr310\deser\JSR310DeserializerBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */