/*    */ package com.fasterxml.jackson.datatype.jsr310.deser.key;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.DeserializationContext;
/*    */ import java.io.IOException;
/*    */ import java.time.DateTimeException;
/*    */ import java.time.LocalTime;
/*    */ import java.time.format.DateTimeFormatter;
/*    */ 
/*    */ public class LocalTimeKeyDeserializer
/*    */   extends Jsr310KeyDeserializer
/*    */ {
/* 12 */   public static final LocalTimeKeyDeserializer INSTANCE = new LocalTimeKeyDeserializer();
/*    */   
/*    */ 
/*    */ 
/*    */   protected LocalTime deserialize(String key, DeserializationContext ctxt)
/*    */     throws IOException
/*    */   {
/*    */     try
/*    */     {
/* 21 */       return LocalTime.parse(key, DateTimeFormatter.ISO_LOCAL_TIME);
/*    */     } catch (DateTimeException e) {
/* 23 */       return (LocalTime)_handleDateTimeException(ctxt, LocalTime.class, e, key);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-datatype-jsr310-2.12.5.jar!\com\fasterxml\jackson\datatype\jsr310\deser\key\LocalTimeKeyDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */