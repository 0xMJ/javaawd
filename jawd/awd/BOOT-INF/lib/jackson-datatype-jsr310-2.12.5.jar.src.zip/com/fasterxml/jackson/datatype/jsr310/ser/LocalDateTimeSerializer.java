/*     */ package com.fasterxml.jackson.datatype.jsr310.ser;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat.Shape;
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.core.type.WritableTypeId;
/*     */ import com.fasterxml.jackson.databind.SerializerProvider;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*     */ import java.io.IOException;
/*     */ import java.time.LocalDateTime;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ import java.time.temporal.ChronoField;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocalDateTimeSerializer
/*     */   extends JSR310FormattedSerializerBase<LocalDateTime>
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  41 */   public static final LocalDateTimeSerializer INSTANCE = new LocalDateTimeSerializer();
/*     */   
/*     */   protected LocalDateTimeSerializer() {
/*  44 */     this(null);
/*     */   }
/*     */   
/*     */   public LocalDateTimeSerializer(DateTimeFormatter f) {
/*  48 */     super(LocalDateTime.class, f);
/*     */   }
/*     */   
/*     */   private LocalDateTimeSerializer(LocalDateTimeSerializer base, Boolean useTimestamp, Boolean useNanoseconds, DateTimeFormatter f) {
/*  52 */     super(base, useTimestamp, useNanoseconds, f, null);
/*     */   }
/*     */   
/*     */   protected JSR310FormattedSerializerBase<LocalDateTime> withFormat(Boolean useTimestamp, DateTimeFormatter f, JsonFormat.Shape shape)
/*     */   {
/*  57 */     return new LocalDateTimeSerializer(this, useTimestamp, this._useNanoseconds, f);
/*     */   }
/*     */   
/*     */   protected DateTimeFormatter _defaultFormatter() {
/*  61 */     return DateTimeFormatter.ISO_LOCAL_DATE_TIME;
/*     */   }
/*     */   
/*     */ 
/*     */   public void serialize(LocalDateTime value, JsonGenerator g, SerializerProvider provider)
/*     */     throws IOException
/*     */   {
/*  68 */     if (useTimestamp(provider)) {
/*  69 */       g.writeStartArray();
/*  70 */       _serializeAsArrayContents(value, g, provider);
/*  71 */       g.writeEndArray();
/*     */     } else {
/*  73 */       DateTimeFormatter dtf = this._formatter;
/*  74 */       if (dtf == null) {
/*  75 */         dtf = _defaultFormatter();
/*     */       }
/*  77 */       g.writeString(value.format(dtf));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void serializeWithType(LocalDateTime value, JsonGenerator g, SerializerProvider provider, TypeSerializer typeSer)
/*     */     throws IOException
/*     */   {
/*  85 */     WritableTypeId typeIdDef = typeSer.writeTypePrefix(g, typeSer
/*  86 */       .typeId(value, serializationShape(provider)));
/*     */     
/*  88 */     if (typeIdDef.valueShape == JsonToken.START_ARRAY) {
/*  89 */       _serializeAsArrayContents(value, g, provider);
/*     */     } else {
/*  91 */       DateTimeFormatter dtf = this._formatter;
/*  92 */       if (dtf == null) {
/*  93 */         dtf = _defaultFormatter();
/*     */       }
/*  95 */       g.writeString(value.format(dtf));
/*     */     }
/*  97 */     typeSer.writeTypeSuffix(g, typeIdDef);
/*     */   }
/*     */   
/*     */   private final void _serializeAsArrayContents(LocalDateTime value, JsonGenerator g, SerializerProvider provider)
/*     */     throws IOException
/*     */   {
/* 103 */     g.writeNumber(value.getYear());
/* 104 */     g.writeNumber(value.getMonthValue());
/* 105 */     g.writeNumber(value.getDayOfMonth());
/* 106 */     g.writeNumber(value.getHour());
/* 107 */     g.writeNumber(value.getMinute());
/* 108 */     int secs = value.getSecond();
/* 109 */     int nanos = value.getNano();
/* 110 */     if ((secs > 0) || (nanos > 0)) {
/* 111 */       g.writeNumber(secs);
/* 112 */       if (nanos > 0) {
/* 113 */         if (useNanoseconds(provider)) {
/* 114 */           g.writeNumber(nanos);
/*     */         } else {
/* 116 */           g.writeNumber(value.get(ChronoField.MILLI_OF_SECOND));
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected JsonToken serializationShape(SerializerProvider provider)
/*     */   {
/* 124 */     return useTimestamp(provider) ? JsonToken.START_ARRAY : JsonToken.VALUE_STRING;
/*     */   }
/*     */   
/*     */   protected JSR310FormattedSerializerBase<?> withFeatures(Boolean writeZoneId, Boolean writeNanoseconds)
/*     */   {
/* 129 */     return new LocalDateTimeSerializer(this, this._useTimestamp, writeNanoseconds, this._formatter);
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-datatype-jsr310-2.12.5.jar!\com\fasterxml\jackson\datatype\jsr310\ser\LocalDateTimeSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */