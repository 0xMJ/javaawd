/*     */ package com.fasterxml.jackson.datatype.jsr310.ser;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat.Shape;
/*     */ import com.fasterxml.jackson.annotation.JsonFormat.Value;
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.JsonParser.NumberType;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.JsonSerializer;
/*     */ import com.fasterxml.jackson.databind.SerializationFeature;
/*     */ import com.fasterxml.jackson.databind.SerializerProvider;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatVisitorWrapper;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonIntegerFormatVisitor;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonValueFormat;
/*     */ import com.fasterxml.jackson.datatype.jsr310.DecimalUtils;
/*     */ import com.fasterxml.jackson.datatype.jsr310.util.DurationUnitConverter;
/*     */ import java.io.IOException;
/*     */ import java.math.BigDecimal;
/*     */ import java.time.Duration;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DurationSerializer
/*     */   extends JSR310FormattedSerializerBase<Duration>
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  56 */   public static final DurationSerializer INSTANCE = new DurationSerializer();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private DurationUnitConverter _durationUnitConverter;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected DurationSerializer()
/*     */   {
/*  69 */     super(Duration.class);
/*     */   }
/*     */   
/*     */   protected DurationSerializer(DurationSerializer base, Boolean useTimestamp, DateTimeFormatter dtf)
/*     */   {
/*  74 */     super(base, useTimestamp, dtf, null);
/*     */   }
/*     */   
/*     */   protected DurationSerializer(DurationSerializer base, Boolean useTimestamp, Boolean useNanoseconds, DateTimeFormatter dtf)
/*     */   {
/*  79 */     super(base, useTimestamp, useNanoseconds, dtf, null);
/*     */   }
/*     */   
/*     */   protected DurationSerializer(DurationSerializer base, DurationUnitConverter converter) {
/*  83 */     super(base, base._useTimestamp, base._useNanoseconds, base._formatter, base._shape);
/*  84 */     this._durationUnitConverter = converter;
/*     */   }
/*     */   
/*     */   protected DurationSerializer withFormat(Boolean useTimestamp, DateTimeFormatter dtf, JsonFormat.Shape shape)
/*     */   {
/*  89 */     return new DurationSerializer(this, useTimestamp, dtf);
/*     */   }
/*     */   
/*     */   protected DurationSerializer withConverter(DurationUnitConverter converter) {
/*  93 */     return new DurationSerializer(this, converter);
/*     */   }
/*     */   
/*     */ 
/*     */   protected SerializationFeature getTimestampsFeature()
/*     */   {
/*  99 */     return SerializationFeature.WRITE_DURATIONS_AS_TIMESTAMPS;
/*     */   }
/*     */   
/*     */   public JsonSerializer<?> createContextual(SerializerProvider prov, BeanProperty property) throws JsonMappingException
/*     */   {
/* 104 */     DurationSerializer ser = (DurationSerializer)super.createContextual(prov, property);
/* 105 */     JsonFormat.Value format = findFormatOverrides(prov, property, handledType());
/* 106 */     if ((format != null) && (format.hasPattern())) {
/* 107 */       String pattern = format.getPattern();
/* 108 */       DurationUnitConverter p = DurationUnitConverter.from(pattern);
/* 109 */       if (p == null) {
/* 110 */         prov.reportBadDefinition(handledType(), 
/* 111 */           String.format("Bad 'pattern' definition (\"%s\") for `Duration`: expected one of [%s]", new Object[] { pattern, 
/*     */           
/* 113 */           DurationUnitConverter.descForAllowed() }));
/*     */       }
/*     */       
/* 116 */       ser = ser.withConverter(p);
/*     */     }
/* 118 */     return ser;
/*     */   }
/*     */   
/*     */   public void serialize(Duration duration, JsonGenerator generator, SerializerProvider provider)
/*     */     throws IOException
/*     */   {
/* 124 */     if (useTimestamp(provider)) {
/* 125 */       if (useNanoseconds(provider)) {
/* 126 */         generator.writeNumber(_toNanos(duration));
/*     */       }
/* 128 */       else if (this._durationUnitConverter != null) {
/* 129 */         generator.writeNumber(this._durationUnitConverter.convert(duration));
/*     */       } else {
/* 131 */         generator.writeNumber(duration.toMillis());
/*     */       }
/*     */     }
/*     */     else {
/* 135 */       generator.writeString(duration.toString());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private BigDecimal _toNanos(Duration duration)
/*     */   {
/*     */     BigDecimal bd;
/*     */     BigDecimal bd;
/* 144 */     if (duration.isNegative()) {
/* 145 */       duration = duration.abs();
/*     */       
/*     */ 
/* 148 */       bd = DecimalUtils.toBigDecimal(duration.getSeconds(), duration.getNano()).negate();
/*     */     } else {
/* 150 */       bd = DecimalUtils.toBigDecimal(duration.getSeconds(), duration
/* 151 */         .getNano());
/*     */     }
/* 153 */     return bd;
/*     */   }
/*     */   
/*     */   protected void _acceptTimestampVisitor(JsonFormatVisitorWrapper visitor, JavaType typeHint)
/*     */     throws JsonMappingException
/*     */   {
/* 159 */     JsonIntegerFormatVisitor v2 = visitor.expectIntegerFormat(typeHint);
/* 160 */     if (v2 != null) {
/* 161 */       v2.numberType(JsonParser.NumberType.LONG);
/* 162 */       SerializerProvider provider = visitor.getProvider();
/* 163 */       if ((provider == null) || (!useNanoseconds(provider)))
/*     */       {
/*     */ 
/* 166 */         v2.format(JsonValueFormat.UTC_MILLISEC);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected JsonToken serializationShape(SerializerProvider provider)
/*     */   {
/* 173 */     if (useTimestamp(provider)) {
/* 174 */       if (useNanoseconds(provider)) {
/* 175 */         return JsonToken.VALUE_NUMBER_FLOAT;
/*     */       }
/* 177 */       return JsonToken.VALUE_NUMBER_INT;
/*     */     }
/* 179 */     return JsonToken.VALUE_STRING;
/*     */   }
/*     */   
/*     */   protected JSR310FormattedSerializerBase<?> withFeatures(Boolean writeZoneId, Boolean writeNanoseconds)
/*     */   {
/* 184 */     return new DurationSerializer(this, this._useTimestamp, writeNanoseconds, this._formatter);
/*     */   }
/*     */   
/*     */   protected DateTimeFormatter _useDateTimeFormatter(SerializerProvider prov, JsonFormat.Value format)
/*     */   {
/* 189 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-datatype-jsr310-2.12.5.jar!\com\fasterxml\jackson\datatype\jsr310\ser\DurationSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */