/*     */ package com.fasterxml.jackson.datatype.jsr310.deser;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat.Shape;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*     */ import java.io.IOException;
/*     */ import java.time.DateTimeException;
/*     */ import java.time.YearMonth;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class YearMonthDeserializer
/*     */   extends JSR310DateTimeDeserializerBase<YearMonth>
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  40 */   public static final YearMonthDeserializer INSTANCE = new YearMonthDeserializer();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public YearMonthDeserializer()
/*     */   {
/*  48 */     this(DateTimeFormatter.ofPattern("uuuu-MM"));
/*     */   }
/*     */   
/*     */   public YearMonthDeserializer(DateTimeFormatter formatter)
/*     */   {
/*  53 */     super(YearMonth.class, formatter);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected YearMonthDeserializer(YearMonthDeserializer base, Boolean leniency)
/*     */   {
/*  60 */     super(base, leniency);
/*     */   }
/*     */   
/*     */   protected YearMonthDeserializer withDateFormat(DateTimeFormatter dtf)
/*     */   {
/*  65 */     return new YearMonthDeserializer(dtf);
/*     */   }
/*     */   
/*     */   protected YearMonthDeserializer withLeniency(Boolean leniency)
/*     */   {
/*  70 */     return new YearMonthDeserializer(this, leniency);
/*     */   }
/*     */   
/*     */   protected YearMonthDeserializer withShape(JsonFormat.Shape shape) {
/*  74 */     return this;
/*     */   }
/*     */   
/*     */   public YearMonth deserialize(JsonParser parser, DeserializationContext context) throws IOException
/*     */   {
/*  79 */     if (parser.hasToken(JsonToken.VALUE_STRING)) {
/*  80 */       return _fromString(parser, context, parser.getText());
/*     */     }
/*     */     
/*  83 */     if (parser.isExpectedStartObjectToken()) {
/*  84 */       return _fromString(parser, context, context
/*  85 */         .extractScalarFromObject(parser, this, handledType()));
/*     */     }
/*  87 */     if (parser.isExpectedStartArrayToken()) {
/*  88 */       JsonToken t = parser.nextToken();
/*  89 */       if (t == JsonToken.END_ARRAY) {
/*  90 */         return null;
/*     */       }
/*  92 */       if (((t == JsonToken.VALUE_STRING) || (t == JsonToken.VALUE_EMBEDDED_OBJECT)) && 
/*  93 */         (context.isEnabled(DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS))) {
/*  94 */         YearMonth parsed = deserialize(parser, context);
/*  95 */         if (parser.nextToken() != JsonToken.END_ARRAY) {
/*  96 */           handleMissingEndArrayForSingle(parser, context);
/*     */         }
/*  98 */         return parsed;
/*     */       }
/* 100 */       if (t != JsonToken.VALUE_NUMBER_INT) {
/* 101 */         _reportWrongToken(context, JsonToken.VALUE_NUMBER_INT, "years");
/*     */       }
/* 103 */       int year = parser.getIntValue();
/* 104 */       int month = parser.nextIntValue(-1);
/* 105 */       if (month == -1) {
/* 106 */         if (!parser.hasToken(JsonToken.VALUE_NUMBER_INT)) {
/* 107 */           _reportWrongToken(context, JsonToken.VALUE_NUMBER_INT, "months");
/*     */         }
/* 109 */         month = parser.getIntValue();
/*     */       }
/* 111 */       if (parser.nextToken() != JsonToken.END_ARRAY) {
/* 112 */         throw context.wrongTokenException(parser, handledType(), JsonToken.END_ARRAY, "Expected array to end");
/*     */       }
/*     */       
/* 115 */       return YearMonth.of(year, month);
/*     */     }
/* 117 */     if (parser.hasToken(JsonToken.VALUE_EMBEDDED_OBJECT)) {
/* 118 */       return (YearMonth)parser.getEmbeddedObject();
/*     */     }
/* 120 */     return (YearMonth)_handleUnexpectedToken(context, parser, new JsonToken[] { JsonToken.VALUE_STRING, JsonToken.START_ARRAY });
/*     */   }
/*     */   
/*     */ 
/*     */   protected YearMonth _fromString(JsonParser p, DeserializationContext ctxt, String string0)
/*     */     throws IOException
/*     */   {
/* 127 */     String string = string0.trim();
/* 128 */     if (string.length() == 0)
/*     */     {
/*     */ 
/*     */ 
/* 132 */       return (YearMonth)_fromEmptyString(p, ctxt, string);
/*     */     }
/*     */     try {
/* 135 */       return YearMonth.parse(string, this._formatter);
/*     */     } catch (DateTimeException e) {
/* 137 */       return (YearMonth)_handleDateTimeException(ctxt, e, string);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-datatype-jsr310-2.12.5.jar!\com\fasterxml\jackson\datatype\jsr310\deser\YearMonthDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */