/*     */ package com.fasterxml.jackson.datatype.jsr310.deser;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat.Feature;
/*     */ import com.fasterxml.jackson.annotation.JsonFormat.Shape;
/*     */ import com.fasterxml.jackson.annotation.JsonFormat.Value;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.MapperFeature;
/*     */ import com.fasterxml.jackson.databind.deser.ContextualDeserializer;
/*     */ import java.io.IOException;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ import java.time.format.DateTimeFormatterBuilder;
/*     */ import java.time.format.ResolverStyle;
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class JSR310DateTimeDeserializerBase<T>
/*     */   extends JSR310DeserializerBase<T>
/*     */   implements ContextualDeserializer
/*     */ {
/*     */   protected final DateTimeFormatter _formatter;
/*     */   protected final JsonFormat.Shape _shape;
/*     */   
/*     */   protected JSR310DateTimeDeserializerBase(Class<T> supportedType, DateTimeFormatter f)
/*     */   {
/*  42 */     super(supportedType);
/*  43 */     this._formatter = f;
/*  44 */     this._shape = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public JSR310DateTimeDeserializerBase(Class<T> supportedType, DateTimeFormatter f, Boolean leniency)
/*     */   {
/*  51 */     super(supportedType, leniency);
/*  52 */     this._formatter = f;
/*  53 */     this._shape = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected JSR310DateTimeDeserializerBase(JSR310DateTimeDeserializerBase<T> base, DateTimeFormatter f)
/*     */   {
/*  61 */     super(base);
/*  62 */     this._formatter = f;
/*  63 */     this._shape = base._shape;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected JSR310DateTimeDeserializerBase(JSR310DateTimeDeserializerBase<T> base, Boolean leniency)
/*     */   {
/*  71 */     super(base, leniency);
/*  72 */     this._formatter = base._formatter;
/*  73 */     this._shape = base._shape;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected JSR310DateTimeDeserializerBase(JSR310DateTimeDeserializerBase<T> base, JsonFormat.Shape shape)
/*     */   {
/*  81 */     super(base);
/*  82 */     this._formatter = base._formatter;
/*  83 */     this._shape = shape;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected abstract JSR310DateTimeDeserializerBase<T> withDateFormat(DateTimeFormatter paramDateTimeFormatter);
/*     */   
/*     */ 
/*     */ 
/*     */   protected abstract JSR310DateTimeDeserializerBase<T> withLeniency(Boolean paramBoolean);
/*     */   
/*     */ 
/*     */ 
/*     */   protected abstract JSR310DateTimeDeserializerBase<T> withShape(JsonFormat.Shape paramShape);
/*     */   
/*     */ 
/*     */ 
/*     */   public JsonDeserializer<?> createContextual(DeserializationContext ctxt, BeanProperty property)
/*     */     throws JsonMappingException
/*     */   {
/* 103 */     JsonFormat.Value format = findFormatOverrides(ctxt, property, handledType());
/* 104 */     return format == null ? this : _withFormatOverrides(ctxt, property, format);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected JSR310DateTimeDeserializerBase<?> _withFormatOverrides(DeserializationContext ctxt, BeanProperty property, JsonFormat.Value formatOverrides)
/*     */   {
/* 121 */     JSR310DateTimeDeserializerBase<?> deser = this;
/*     */     
/*     */ 
/* 124 */     if (formatOverrides.hasLenient()) {
/* 125 */       Boolean leniency = formatOverrides.getLenient();
/* 126 */       if (leniency != null) {
/* 127 */         deser = deser.withLeniency(leniency);
/*     */       }
/*     */     }
/* 130 */     if (formatOverrides.hasPattern()) {
/* 131 */       String pattern = formatOverrides.getPattern();
/* 132 */       Locale locale = formatOverrides.hasLocale() ? formatOverrides.getLocale() : ctxt.getLocale();
/* 133 */       DateTimeFormatterBuilder builder = new DateTimeFormatterBuilder();
/* 134 */       if (acceptCaseInsensitiveValues(ctxt, formatOverrides)) {
/* 135 */         builder.parseCaseInsensitive();
/*     */       }
/* 137 */       builder.appendPattern(pattern);
/*     */       DateTimeFormatter df;
/* 139 */       DateTimeFormatter df; if (locale == null) {
/* 140 */         df = builder.toFormatter();
/*     */       } else {
/* 142 */         df = builder.toFormatter(locale);
/*     */       }
/*     */       
/*     */ 
/* 146 */       if (!deser.isLenient()) {
/* 147 */         df = df.withResolverStyle(ResolverStyle.STRICT);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 152 */       if (formatOverrides.hasTimeZone()) {
/* 153 */         df = df.withZone(formatOverrides.getTimeZone().toZoneId());
/*     */       }
/* 155 */       deser = deser.withDateFormat(df);
/*     */     }
/*     */     
/*     */ 
/* 159 */     JsonFormat.Shape shape = formatOverrides.getShape();
/* 160 */     if ((shape != null) && (shape != this._shape)) {
/* 161 */       deser = deser.withShape(shape);
/*     */     }
/*     */     
/*     */ 
/* 165 */     return deser;
/*     */   }
/*     */   
/*     */   private boolean acceptCaseInsensitiveValues(DeserializationContext ctxt, JsonFormat.Value format)
/*     */   {
/* 170 */     Boolean enabled = format.getFeature(JsonFormat.Feature.ACCEPT_CASE_INSENSITIVE_VALUES);
/* 171 */     if (enabled == null) {
/* 172 */       enabled = Boolean.valueOf(ctxt.isEnabled(MapperFeature.ACCEPT_CASE_INSENSITIVE_VALUES));
/*     */     }
/* 174 */     return enabled.booleanValue();
/*     */   }
/*     */   
/*     */   protected void _throwNoNumericTimestampNeedTimeZone(JsonParser p, DeserializationContext ctxt)
/*     */     throws IOException
/*     */   {
/* 180 */     ctxt.reportInputMismatch(handledType(), "raw timestamp (%d) not allowed for `%s`: need additional information such as an offset or time-zone (see class Javadocs)", new Object[] {p
/*     */     
/* 182 */       .getNumberValue(), handledType().getName() });
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-datatype-jsr310-2.12.5.jar!\com\fasterxml\jackson\datatype\jsr310\deser\JSR310DateTimeDeserializerBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */