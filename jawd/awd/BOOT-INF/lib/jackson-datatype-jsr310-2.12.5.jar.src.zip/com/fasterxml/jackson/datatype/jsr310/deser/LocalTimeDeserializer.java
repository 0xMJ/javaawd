/*     */ package com.fasterxml.jackson.datatype.jsr310.deser;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat.Shape;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*     */ import java.io.IOException;
/*     */ import java.time.DateTimeException;
/*     */ import java.time.LocalTime;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocalTimeDeserializer
/*     */   extends JSR310DateTimeDeserializerBase<LocalTime>
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  39 */   private static final DateTimeFormatter DEFAULT_FORMATTER = DateTimeFormatter.ISO_LOCAL_TIME;
/*     */   
/*  41 */   public static final LocalTimeDeserializer INSTANCE = new LocalTimeDeserializer();
/*     */   
/*     */   protected LocalTimeDeserializer() {
/*  44 */     this(DEFAULT_FORMATTER);
/*     */   }
/*     */   
/*     */   public LocalTimeDeserializer(DateTimeFormatter formatter) {
/*  48 */     super(LocalTime.class, formatter);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected LocalTimeDeserializer(LocalTimeDeserializer base, Boolean leniency)
/*     */   {
/*  55 */     super(base, leniency);
/*     */   }
/*     */   
/*     */   protected LocalTimeDeserializer withDateFormat(DateTimeFormatter formatter)
/*     */   {
/*  60 */     return new LocalTimeDeserializer(formatter);
/*     */   }
/*     */   
/*     */   protected LocalTimeDeserializer withLeniency(Boolean leniency)
/*     */   {
/*  65 */     return new LocalTimeDeserializer(this, leniency);
/*     */   }
/*     */   
/*     */   protected LocalTimeDeserializer withShape(JsonFormat.Shape shape) {
/*  69 */     return this;
/*     */   }
/*     */   
/*     */   public LocalTime deserialize(JsonParser parser, DeserializationContext context) throws IOException
/*     */   {
/*  74 */     if (parser.hasToken(JsonToken.VALUE_STRING)) {
/*  75 */       return _fromString(parser, context, parser.getText());
/*     */     }
/*     */     
/*  78 */     if (parser.isExpectedStartObjectToken()) {
/*  79 */       return _fromString(parser, context, context
/*  80 */         .extractScalarFromObject(parser, this, handledType()));
/*     */     }
/*  82 */     if (parser.isExpectedStartArrayToken()) {
/*  83 */       JsonToken t = parser.nextToken();
/*  84 */       if (t == JsonToken.END_ARRAY) {
/*  85 */         return null;
/*     */       }
/*  87 */       if ((context.isEnabled(DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS)) && ((t == JsonToken.VALUE_STRING) || (t == JsonToken.VALUE_EMBEDDED_OBJECT)))
/*     */       {
/*  89 */         LocalTime parsed = deserialize(parser, context);
/*  90 */         if (parser.nextToken() != JsonToken.END_ARRAY) {
/*  91 */           handleMissingEndArrayForSingle(parser, context);
/*     */         }
/*  93 */         return parsed;
/*     */       }
/*  95 */       if (t == JsonToken.VALUE_NUMBER_INT) {
/*  96 */         int hour = parser.getIntValue();
/*     */         
/*  98 */         parser.nextToken();
/*  99 */         int minute = parser.getIntValue();
/*     */         
/*     */ 
/* 102 */         t = parser.nextToken();
/* 103 */         LocalTime result; LocalTime result; if (t == JsonToken.END_ARRAY) {
/* 104 */           result = LocalTime.of(hour, minute);
/*     */         } else {
/* 106 */           int second = parser.getIntValue();
/* 107 */           t = parser.nextToken();
/* 108 */           LocalTime result; if (t == JsonToken.END_ARRAY) {
/* 109 */             result = LocalTime.of(hour, minute, second);
/*     */           } else {
/* 111 */             int partialSecond = parser.getIntValue();
/* 112 */             if ((partialSecond < 1000) && 
/* 113 */               (!context.isEnabled(DeserializationFeature.READ_DATE_TIMESTAMPS_AS_NANOSECONDS)))
/* 114 */               partialSecond *= 1000000;
/* 115 */             t = parser.nextToken();
/* 116 */             if (t != JsonToken.END_ARRAY) {
/* 117 */               throw context.wrongTokenException(parser, handledType(), JsonToken.END_ARRAY, "Expected array to end");
/*     */             }
/*     */             
/* 120 */             result = LocalTime.of(hour, minute, second, partialSecond);
/*     */           }
/*     */         }
/* 123 */         return result;
/*     */       }
/* 125 */       context.reportInputMismatch(handledType(), "Unexpected token (%s) within Array, expected VALUE_NUMBER_INT", new Object[] { t });
/*     */     }
/*     */     
/*     */ 
/* 129 */     if (parser.hasToken(JsonToken.VALUE_EMBEDDED_OBJECT)) {
/* 130 */       return (LocalTime)parser.getEmbeddedObject();
/*     */     }
/* 132 */     if (parser.hasToken(JsonToken.VALUE_NUMBER_INT)) {
/* 133 */       _throwNoNumericTimestampNeedTimeZone(parser, context);
/*     */     }
/* 135 */     return (LocalTime)_handleUnexpectedToken(context, parser, "Expected array or string.", new Object[0]);
/*     */   }
/*     */   
/*     */   protected LocalTime _fromString(JsonParser p, DeserializationContext ctxt, String string0)
/*     */     throws IOException
/*     */   {
/* 141 */     String string = string0.trim();
/* 142 */     if (string.length() == 0)
/*     */     {
/*     */ 
/*     */ 
/* 146 */       return (LocalTime)_fromEmptyString(p, ctxt, string);
/*     */     }
/* 148 */     DateTimeFormatter format = this._formatter;
/*     */     try {
/* 150 */       if ((format == DEFAULT_FORMATTER) && 
/* 151 */         (string.contains("T"))) {
/* 152 */         return LocalTime.parse(string, DateTimeFormatter.ISO_LOCAL_DATE_TIME);
/*     */       }
/*     */       
/* 155 */       return LocalTime.parse(string, format);
/*     */     } catch (DateTimeException e) {
/* 157 */       return (LocalTime)_handleDateTimeException(ctxt, e, string);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-datatype-jsr310-2.12.5.jar!\com\fasterxml\jackson\datatype\jsr310\deser\LocalTimeDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */