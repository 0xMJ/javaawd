/*     */ package com.fasterxml.jackson.datatype.jsr310.ser;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat.Shape;
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.core.type.WritableTypeId;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.SerializerProvider;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatVisitorWrapper;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonStringFormatVisitor;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonValueFormat;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*     */ import java.io.IOException;
/*     */ import java.time.LocalDate;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocalDateSerializer
/*     */   extends JSR310FormattedSerializerBase<LocalDate>
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  43 */   public static final LocalDateSerializer INSTANCE = new LocalDateSerializer();
/*     */   
/*     */   protected LocalDateSerializer() {
/*  46 */     super(LocalDate.class);
/*     */   }
/*     */   
/*     */   protected LocalDateSerializer(LocalDateSerializer base, Boolean useTimestamp, DateTimeFormatter dtf, JsonFormat.Shape shape)
/*     */   {
/*  51 */     super(base, useTimestamp, dtf, shape);
/*     */   }
/*     */   
/*     */   public LocalDateSerializer(DateTimeFormatter formatter) {
/*  55 */     super(LocalDate.class, formatter);
/*     */   }
/*     */   
/*     */   protected LocalDateSerializer withFormat(Boolean useTimestamp, DateTimeFormatter dtf, JsonFormat.Shape shape)
/*     */   {
/*  60 */     return new LocalDateSerializer(this, useTimestamp, dtf, shape);
/*     */   }
/*     */   
/*     */   public void serialize(LocalDate date, JsonGenerator g, SerializerProvider provider)
/*     */     throws IOException
/*     */   {
/*  66 */     if (useTimestamp(provider)) {
/*  67 */       if (this._shape == JsonFormat.Shape.NUMBER_INT) {
/*  68 */         g.writeNumber(date.toEpochDay());
/*     */       } else {
/*  70 */         g.writeStartArray();
/*  71 */         _serializeAsArrayContents(date, g, provider);
/*  72 */         g.writeEndArray();
/*     */       }
/*     */     } else {
/*  75 */       g.writeString(this._formatter == null ? date.toString() : date.format(this._formatter));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void serializeWithType(LocalDate value, JsonGenerator g, SerializerProvider provider, TypeSerializer typeSer)
/*     */     throws IOException
/*     */   {
/*  83 */     WritableTypeId typeIdDef = typeSer.writeTypePrefix(g, typeSer
/*  84 */       .typeId(value, serializationShape(provider)));
/*     */     
/*  86 */     switch (typeIdDef.valueShape) {
/*     */     case START_ARRAY: 
/*  88 */       _serializeAsArrayContents(value, g, provider);
/*  89 */       break;
/*     */     case VALUE_NUMBER_INT: 
/*  91 */       g.writeNumber(value.toEpochDay());
/*  92 */       break;
/*     */     default: 
/*  94 */       g.writeString(this._formatter == null ? value.toString() : value.format(this._formatter));
/*     */     }
/*  96 */     typeSer.writeTypeSuffix(g, typeIdDef);
/*     */   }
/*     */   
/*     */   protected void _serializeAsArrayContents(LocalDate value, JsonGenerator g, SerializerProvider provider)
/*     */     throws IOException
/*     */   {
/* 102 */     g.writeNumber(value.getYear());
/* 103 */     g.writeNumber(value.getMonthValue());
/* 104 */     g.writeNumber(value.getDayOfMonth());
/*     */   }
/*     */   
/*     */   public void acceptJsonFormatVisitor(JsonFormatVisitorWrapper visitor, JavaType typeHint)
/*     */     throws JsonMappingException
/*     */   {
/* 110 */     SerializerProvider provider = visitor.getProvider();
/* 111 */     boolean useTimestamp = (provider != null) && (useTimestamp(provider));
/* 112 */     if (useTimestamp) {
/* 113 */       _acceptTimestampVisitor(visitor, typeHint);
/*     */     } else {
/* 115 */       JsonStringFormatVisitor v2 = visitor.expectStringFormat(typeHint);
/* 116 */       if (v2 != null) {
/* 117 */         v2.format(JsonValueFormat.DATE);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected JsonToken serializationShape(SerializerProvider provider)
/*     */   {
/* 124 */     if (useTimestamp(provider)) {
/* 125 */       if (this._shape == JsonFormat.Shape.NUMBER_INT) {
/* 126 */         return JsonToken.VALUE_NUMBER_INT;
/*     */       }
/* 128 */       return JsonToken.START_ARRAY;
/*     */     }
/* 130 */     return JsonToken.VALUE_STRING;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-datatype-jsr310-2.12.5.jar!\com\fasterxml\jackson\datatype\jsr310\ser\LocalDateSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */