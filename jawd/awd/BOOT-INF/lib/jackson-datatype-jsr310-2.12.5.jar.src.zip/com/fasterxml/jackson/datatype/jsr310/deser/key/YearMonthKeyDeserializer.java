/*    */ package com.fasterxml.jackson.datatype.jsr310.deser.key;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.DeserializationContext;
/*    */ import java.io.IOException;
/*    */ import java.time.DateTimeException;
/*    */ import java.time.YearMonth;
/*    */ import java.time.format.DateTimeFormatter;
/*    */ import java.time.format.DateTimeFormatterBuilder;
/*    */ import java.time.format.SignStyle;
/*    */ import java.time.temporal.ChronoField;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class YearMonthKeyDeserializer
/*    */   extends Jsr310KeyDeserializer
/*    */ {
/* 19 */   public static final YearMonthKeyDeserializer INSTANCE = new YearMonthKeyDeserializer();
/*    */   
/*    */ 
/* 22 */   private static final DateTimeFormatter FORMATTER = new DateTimeFormatterBuilder()
/* 23 */     .appendValue(ChronoField.YEAR, 4, 10, SignStyle.EXCEEDS_PAD)
/* 24 */     .appendLiteral('-')
/* 25 */     .appendValue(ChronoField.MONTH_OF_YEAR, 2)
/* 26 */     .toFormatter();
/*    */   
/*    */   protected YearMonth deserialize(String key, DeserializationContext ctxt)
/*    */     throws IOException
/*    */   {
/*    */     try
/*    */     {
/* 33 */       return YearMonth.parse(key, FORMATTER);
/*    */     } catch (DateTimeException e) {
/* 35 */       return (YearMonth)_handleDateTimeException(ctxt, YearMonth.class, e, key);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-datatype-jsr310-2.12.5.jar!\com\fasterxml\jackson\datatype\jsr310\deser\key\YearMonthKeyDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */