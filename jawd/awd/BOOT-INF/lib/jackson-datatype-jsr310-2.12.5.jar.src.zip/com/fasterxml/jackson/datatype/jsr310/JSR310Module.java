/*     */ package com.fasterxml.jackson.datatype.jsr310;
/*     */ 
/*     */ import com.fasterxml.jackson.databind.BeanDescription;
/*     */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonSerializer;
/*     */ import com.fasterxml.jackson.databind.Module.SetupContext;
/*     */ import com.fasterxml.jackson.databind.deser.ValueInstantiator;
/*     */ import com.fasterxml.jackson.databind.deser.ValueInstantiators.Base;
/*     */ import com.fasterxml.jackson.databind.deser.std.StdValueInstantiator;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedClass;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedMethod;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedParameter;
/*     */ import com.fasterxml.jackson.databind.module.SimpleModule;
/*     */ import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.DurationDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.InstantDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.JSR310StringParsableDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.LocalTimeDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.MonthDayDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.OffsetTimeDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.YearDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.YearMonthDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.key.DurationKeyDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.key.InstantKeyDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.key.LocalDateKeyDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.key.LocalDateTimeKeyDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.key.LocalTimeKeyDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.key.MonthDayKeyDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.key.OffsetDateTimeKeyDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.key.OffsetTimeKeyDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.key.PeriodKeyDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.key.YearKeyDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.key.YearMonthKeyDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.key.ZoneIdKeyDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.key.ZoneOffsetKeyDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.deser.key.ZonedDateTimeKeyDeserializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.ser.DurationSerializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.ser.InstantSerializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.ser.LocalTimeSerializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.ser.MonthDaySerializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.ser.OffsetDateTimeSerializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.ser.OffsetTimeSerializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.ser.YearMonthSerializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.ser.YearSerializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.ser.ZoneIdSerializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.ser.ZonedDateTimeWithZoneIdSerializer;
/*     */ import com.fasterxml.jackson.datatype.jsr310.ser.key.ZonedDateTimeKeySerializer;
/*     */ import java.time.Duration;
/*     */ import java.time.Instant;
/*     */ import java.time.LocalDate;
/*     */ import java.time.LocalDateTime;
/*     */ import java.time.LocalTime;
/*     */ import java.time.MonthDay;
/*     */ import java.time.OffsetDateTime;
/*     */ import java.time.OffsetTime;
/*     */ import java.time.Period;
/*     */ import java.time.Year;
/*     */ import java.time.YearMonth;
/*     */ import java.time.ZoneId;
/*     */ import java.time.ZoneOffset;
/*     */ import java.time.ZonedDateTime;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public final class JSR310Module
/*     */   extends SimpleModule
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   
/*     */   public JSR310Module()
/*     */   {
/*  93 */     super(PackageVersion.VERSION);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  98 */     addDeserializer(Instant.class, InstantDeserializer.INSTANT);
/*  99 */     addDeserializer(OffsetDateTime.class, InstantDeserializer.OFFSET_DATE_TIME);
/* 100 */     addDeserializer(ZonedDateTime.class, InstantDeserializer.ZONED_DATE_TIME);
/*     */     
/*     */ 
/* 103 */     addDeserializer(Duration.class, DurationDeserializer.INSTANCE);
/* 104 */     addDeserializer(LocalDateTime.class, LocalDateTimeDeserializer.INSTANCE);
/* 105 */     addDeserializer(LocalDate.class, LocalDateDeserializer.INSTANCE);
/* 106 */     addDeserializer(LocalTime.class, LocalTimeDeserializer.INSTANCE);
/* 107 */     addDeserializer(MonthDay.class, MonthDayDeserializer.INSTANCE);
/* 108 */     addDeserializer(OffsetTime.class, OffsetTimeDeserializer.INSTANCE);
/* 109 */     addDeserializer(Period.class, JSR310StringParsableDeserializer.PERIOD);
/* 110 */     addDeserializer(Year.class, YearDeserializer.INSTANCE);
/* 111 */     addDeserializer(YearMonth.class, YearMonthDeserializer.INSTANCE);
/* 112 */     addDeserializer(ZoneId.class, JSR310StringParsableDeserializer.ZONE_ID);
/* 113 */     addDeserializer(ZoneOffset.class, JSR310StringParsableDeserializer.ZONE_OFFSET);
/*     */     
/*     */ 
/* 116 */     addSerializer(Duration.class, DurationSerializer.INSTANCE);
/* 117 */     addSerializer(Instant.class, InstantSerializer.INSTANCE);
/* 118 */     addSerializer(LocalDateTime.class, LocalDateTimeSerializer.INSTANCE);
/* 119 */     addSerializer(LocalDate.class, LocalDateSerializer.INSTANCE);
/* 120 */     addSerializer(LocalTime.class, LocalTimeSerializer.INSTANCE);
/* 121 */     addSerializer(MonthDay.class, MonthDaySerializer.INSTANCE);
/* 122 */     addSerializer(OffsetDateTime.class, OffsetDateTimeSerializer.INSTANCE);
/* 123 */     addSerializer(OffsetTime.class, OffsetTimeSerializer.INSTANCE);
/* 124 */     addSerializer(Period.class, new ToStringSerializer(Period.class));
/* 125 */     addSerializer(Year.class, YearSerializer.INSTANCE);
/* 126 */     addSerializer(YearMonth.class, YearMonthSerializer.INSTANCE);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 131 */     addSerializer(ZonedDateTime.class, _zonedWithZoneId());
/*     */     
/*     */ 
/* 134 */     addSerializer(ZoneId.class, new ZoneIdSerializer());
/*     */     
/* 136 */     addSerializer(ZoneOffset.class, new ToStringSerializer(ZoneOffset.class));
/*     */     
/*     */ 
/* 139 */     addKeySerializer(ZonedDateTime.class, ZonedDateTimeKeySerializer.INSTANCE);
/*     */     
/*     */ 
/* 142 */     addKeyDeserializer(Duration.class, DurationKeyDeserializer.INSTANCE);
/* 143 */     addKeyDeserializer(Instant.class, InstantKeyDeserializer.INSTANCE);
/* 144 */     addKeyDeserializer(LocalDateTime.class, LocalDateTimeKeyDeserializer.INSTANCE);
/* 145 */     addKeyDeserializer(LocalDate.class, LocalDateKeyDeserializer.INSTANCE);
/* 146 */     addKeyDeserializer(LocalTime.class, LocalTimeKeyDeserializer.INSTANCE);
/* 147 */     addKeyDeserializer(MonthDay.class, MonthDayKeyDeserializer.INSTANCE);
/* 148 */     addKeyDeserializer(OffsetDateTime.class, OffsetDateTimeKeyDeserializer.INSTANCE);
/* 149 */     addKeyDeserializer(OffsetTime.class, OffsetTimeKeyDeserializer.INSTANCE);
/* 150 */     addKeyDeserializer(Period.class, PeriodKeyDeserializer.INSTANCE);
/* 151 */     addKeyDeserializer(Year.class, YearKeyDeserializer.INSTANCE);
/* 152 */     addKeyDeserializer(YearMonth.class, YearMonthKeyDeserializer.INSTANCE);
/* 153 */     addKeyDeserializer(ZonedDateTime.class, ZonedDateTimeKeyDeserializer.INSTANCE);
/* 154 */     addKeyDeserializer(ZoneId.class, ZoneIdKeyDeserializer.INSTANCE);
/* 155 */     addKeyDeserializer(ZoneOffset.class, ZoneOffsetKeyDeserializer.INSTANCE);
/*     */   }
/*     */   
/*     */   private static JsonSerializer<ZonedDateTime> _zonedWithZoneId() {
/* 159 */     return ZonedDateTimeWithZoneIdSerializer.INSTANCE;
/*     */   }
/*     */   
/*     */   public void setupModule(Module.SetupContext context)
/*     */   {
/* 164 */     super.setupModule(context);
/* 165 */     context.addValueInstantiators(new ValueInstantiators.Base()
/*     */     {
/*     */ 
/*     */       public ValueInstantiator findValueInstantiator(DeserializationConfig config, BeanDescription beanDesc, ValueInstantiator defaultInstantiator)
/*     */       {
/* 170 */         JavaType type = beanDesc.getType();
/* 171 */         Class<?> raw = type.getRawClass();
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 176 */         if (ZoneId.class.isAssignableFrom(raw))
/*     */         {
/* 178 */           if ((defaultInstantiator instanceof StdValueInstantiator)) {
/* 179 */             StdValueInstantiator inst = (StdValueInstantiator)defaultInstantiator;
/*     */             AnnotatedClass ac;
/*     */             AnnotatedClass ac;
/* 182 */             if (raw == ZoneId.class) {
/* 183 */               ac = beanDesc.getClassInfo();
/*     */             }
/*     */             else
/*     */             {
/* 187 */               ac = AnnotatedClass.construct(config.constructType(ZoneId.class), config);
/*     */             }
/* 189 */             if (!inst.canCreateFromString()) {
/* 190 */               AnnotatedMethod factory = JSR310Module.this._findFactory(ac, "of", new Class[] { String.class });
/* 191 */               if (factory != null) {
/* 192 */                 inst.configureFromStringCreator(factory);
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */         
/*     */ 
/* 199 */         return defaultInstantiator;
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   protected AnnotatedMethod _findFactory(AnnotatedClass cls, String name, Class<?>... argTypes)
/*     */   {
/* 206 */     int argCount = argTypes.length;
/* 207 */     for (AnnotatedMethod method : cls.getFactoryMethods())
/* 208 */       if ((name.equals(method.getName())) && 
/* 209 */         (method.getParameterCount() == argCount))
/*     */       {
/*     */ 
/* 212 */         for (int i = 0; i < argCount; i++) {
/* 213 */           Class<?> argType = method.getParameter(i).getRawType();
/* 214 */           if (!argType.isAssignableFrom(argTypes[i])) {}
/*     */         }
/*     */         
/*     */ 
/* 218 */         return method;
/*     */       }
/* 220 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-datatype-jsr310-2.12.5.jar!\com\fasterxml\jackson\datatype\jsr310\JSR310Module.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */