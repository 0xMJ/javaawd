/*   */ package com.fasterxml.jackson.datatype.jsr310.deser.key;
/*   */ 
/*   */ 
/*   */ 
/*   */ @Deprecated
/*   */ public class YearMothKeyDeserializer
/*   */   extends YearMonthKeyDeserializer
/*   */ {
/* 9 */   public static final YearMothKeyDeserializer INSTANCE = new YearMothKeyDeserializer();
/*   */ }


/* Location:              C:\Users\Asus\Desktop\awd.jar!\BOOT-INF\lib\jackson-datatype-jsr310-2.12.5.jar!\com\fasterxml\jackson\datatype\jsr310\deser\key\YearMothKeyDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */