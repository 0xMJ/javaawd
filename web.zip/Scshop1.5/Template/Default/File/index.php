<?php
include_once  '<{dirpaths}>Include/web_inc.php';
include_once  '<{dirpaths}>Templete/<{Template}>/Include/Function.php';
$file_url="<{dirpaths}>";
include_once  '<{dirpaths}>Templete/<{Template}>/Include/default.php';
?>
