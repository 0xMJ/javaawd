<?php
header("location:article.manage.php");
exit();
?>